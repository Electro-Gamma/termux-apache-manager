pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // usb-serial-for-android (UART adapters) is only published on JitPack.
        maven { url = uri("https://jitpack.io") }
    }
}
rootProject.name = "TerminalSSH"
include(":app")
