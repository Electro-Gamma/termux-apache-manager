# Third-party notices

This product includes software developed by third parties.

## mwiede/JSch — 2.28.6
BSD-style licence (JSch original licence, Atsuhiko Yamanaka / JCraft).
https://github.com/mwiede/jsch
Provides the SSH-2 transport, authentication and channel layer.

## ConnectBot termlib — 0.1.0
Apache License 2.0.
https://github.com/connectbot
Provides the terminal emulator and its Compose renderer.

## libvterm (bundled inside termlib as libjni_cb_term.so)
MIT licence, Paul "LeoNerd" Evans.
Provides VT100/ANSI parsing.

## AndroidX / Jetpack Compose
Apache License 2.0, The Android Open Source Project.

> Before publishing to any store, verify each licence text against the exact
> artifact version you ship and include the full licence files in the release.

## Highlight.js
The File Manager editor colours code with Highlight.js 11.12.0 (BSD-3-Clause,
(c) 2006 Ivan Sagalaev and contributors), bundled in
`app/src/main/assets/editor/highlight.min.js` (taken from the
android-compose-highlight 0.39.0 release). Its licence text must accompany releases.

## android-compose-highlight
The approach (Highlight.js in a hidden WebView, HTML converted to native text styles)
follows android-compose-highlight 0.39.0, MIT License, (c) 2026 Hossain Khan.
