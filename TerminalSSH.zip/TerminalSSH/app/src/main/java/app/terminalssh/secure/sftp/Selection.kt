package app.terminalssh.secure.sftp

/**
 * The set of remote entries the user has ticked in the Files tab.
 *
 * Keyed by absolute path rather than by position in the current listing, so a selection
 * survives navigating into another folder: you can tick a file here, go up two levels,
 * tick a folder there, and act on both at once. Insertion order is kept so the batch
 * runs in the order the user picked things.
 *
 * Pure data with no I/O, so the rules are unit-testable.
 */
data class Selection(val items: Map<String, RemoteEntry> = emptyMap()) {

    /** Selection mode is simply "something is selected"; deselecting the last item leaves it. */
    val isActive: Boolean get() = items.isNotEmpty()

    val count: Int get() = items.size

    val entries: List<RemoteEntry> get() = items.values.toList()

    val hasDirectories: Boolean get() = items.values.any { it.isDirectory }

    /** The one selected entry when exactly one is selected, else null. */
    val single: RemoteEntry? get() = if (items.size == 1) items.values.first() else null

    fun contains(path: String): Boolean = items.containsKey(path)

    fun toggle(entry: RemoteEntry): Selection =
        if (contains(entry.path)) Selection(items - entry.path) else Selection(items + (entry.path to entry))

    fun addAll(entries: List<RemoteEntry>): Selection {
        var next = items
        for (entry in entries) {
            if (!next.containsKey(entry.path)) next = next + (entry.path to entry)
        }
        return Selection(next)
    }

    /** True when every entry of [listing] is already selected (and there is at least one). */
    fun coversAll(listing: List<RemoteEntry>): Boolean =
        listing.isNotEmpty() && listing.all { contains(it.path) }

    /** How many selected entries live outside [directory]. */
    fun countOutside(directory: String): Int =
        items.values.count { RemotePath.parent(it.path) != directory }

    /**
     * Drops selected entries of [directory] that are no longer in [listing] (deleted or
     * renamed elsewhere). Entries from other directories cannot be checked and stay.
     */
    fun pruned(directory: String, listing: List<RemoteEntry>): Selection {
        val present = listing.mapTo(HashSet<String>()) { it.path }
        val kept = items.filter { (path, _) ->
            RemotePath.parent(path) != directory || path in present
        }
        return if (kept.size == items.size) this else Selection(kept)
    }
}

enum class ClipboardMode { COPY, CUT }

/** Entries waiting to be pasted into whichever folder the user navigates to. */
data class Clipboard(val mode: ClipboardMode, val items: List<RemoteEntry>)
