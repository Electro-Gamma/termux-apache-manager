package app.terminalssh.secure.sftp

enum class SortKey { NAME, SIZE, MODIFIED }

/**
 * How the Files tab presents a folder. Display only: it never changes what is listed on
 * the server, what is selected, or what an operation touches.
 *
 * Hidden files are shown by default because that is how the tab always behaved.
 */
data class ViewOptions(
    val showHidden: Boolean = true,
    val sortKey: SortKey = SortKey.NAME,
    val descending: Boolean = false,
)

object ListingView {

    /** Unix convention: a leading dot means hidden. */
    fun isHidden(entry: RemoteEntry): Boolean = entry.name.startsWith(".")

    /** How many entries [options] currently hides from [entries]. */
    fun hiddenCount(entries: List<RemoteEntry>, options: ViewOptions): Int =
        if (options.showHidden) 0 else entries.count { isHidden(it) }

    /** Filters and orders [entries]. Folders always come first, as in every file manager. */
    fun apply(entries: List<RemoteEntry>, options: ViewOptions): List<RemoteEntry> {
        val visible = if (options.showHidden) entries else entries.filterNot { isHidden(it) }
        val byName = compareBy<RemoteEntry> { it.name.lowercase() }.thenBy { it.name }
        val comparator: Comparator<RemoteEntry> = when (options.sortKey) {
            SortKey.NAME -> byName
            SortKey.SIZE -> compareBy<RemoteEntry> { it.sizeBytes }.then(byName)
            SortKey.MODIFIED -> compareBy<RemoteEntry> { it.modifiedEpochSeconds }.then(byName)
        }
        val ordered = if (options.descending) comparator.reversed() else comparator
        val folders = visible.filter { it.isDirectory }
        val files = visible.filter { !it.isDirectory }
        return folders.sortedWith(ordered) + files.sortedWith(ordered)
    }
}
