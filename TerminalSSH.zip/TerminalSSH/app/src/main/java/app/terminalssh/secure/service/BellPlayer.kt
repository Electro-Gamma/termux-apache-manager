package app.terminalssh.secure.service

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator

/**
 * The terminal bell (the BEL character, `\a`) as the user chose it: silent, a short
 * vibration, or a short beep. Rate-limited, because a program that rings the bell in a
 * loop would otherwise buzz the phone continuously.
 */
class BellPlayer(private val context: Context) {
    private var lastRangAt = 0L

    /** @param behavior one of "none", "vibrate", "sound" (the Terminal bell setting's values). */
    fun ring(behavior: String) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastRangAt < MIN_GAP_MS) return
        when (behavior) {
            "vibrate" -> vibrate()
            "sound" -> beep()
            else -> return
        }
        lastRangAt = now
    }

    private fun vibrate() {
        val vibrator = context.getSystemService(Vibrator::class.java) ?: return
        if (!vibrator.hasVibrator()) return
        vibrator.vibrate(VibrationEffect.createOneShot(VIBRATE_MS, VibrationEffect.DEFAULT_AMPLITUDE))
    }

    private fun beep() {
        runCatching {
            val tone = ToneGenerator(AudioManager.STREAM_NOTIFICATION, TONE_VOLUME)
            tone.startTone(ToneGenerator.TONE_PROP_BEEP, TONE_MS)
            Handler(Looper.getMainLooper()).postDelayed({ tone.release() }, TONE_MS + 300L)
        }
    }

    private companion object {
        const val MIN_GAP_MS = 500L
        const val VIBRATE_MS = 60L
        const val TONE_MS = 120
        const val TONE_VOLUME = 60
    }
}
