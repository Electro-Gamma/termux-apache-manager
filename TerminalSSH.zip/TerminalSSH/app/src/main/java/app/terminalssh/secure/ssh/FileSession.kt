package app.terminalssh.secure.ssh

import app.terminalssh.secure.model.AuthMethod
import app.terminalssh.secure.model.HostProfile
import app.terminalssh.secure.sftp.SftpClient
import app.terminalssh.secure.sftp.SftpSource
import com.jcraft.jsch.Session
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicLong

/**
 * The File Manager's own SSH connection to one server.
 *
 * It authenticates and verifies the host key like a terminal does, but opens no shell:
 * the File Manager works whether or not a terminal for the same server exists, and
 * closing either never touches the other. It owns its connection, drops are noticed and
 * retried with the same backoff policy as the terminal, and it only ends when the user
 * disconnects it.
 *
 * Threading: connecting and closing run on [io]; a daemon watcher thread polls the
 * connection so a silent drop turns into a state change rather than a surprise error on
 * the next click.
 */
class FileSession(
    val id: String,
    @Volatile var profile: HostProfile,
    private val client: JschSshClient,
    private val keepAlive: Boolean,
) : SftpSource {

    private val io = Executors.newSingleThreadExecutor { r -> Thread(r, "files-io-$id") }
    private val generation = AtomicLong(0)

    private val _state = MutableStateFlow<SshSessionState>(SshSessionState.Idle)
    val state: StateFlow<SshSessionState> = _state.asStateFlow()

    @Volatile private var session: Session? = null
    @Volatile private var pendingPassword: ByteArray? = null
    @Volatile private var autoReconnect = true

    val title: String get() = profile.displayName

    /** @param password only for hosts without a stored secret; zeroed once used. */
    fun connect(password: ByteArray? = null) {
        pendingPassword?.fill(0)
        pendingPassword = password
        autoReconnect = true
        val gen = generation.incrementAndGet()
        _state.value = SshSessionState.Connecting
        io.execute { doConnect(gen, attempt = 0) }
    }

    private fun doConnect(gen: Long, attempt: Int) {
        if (gen != generation.get()) return
        try {
            val opened = client.openSession(
                profile = profile,
                passwordOverride = pendingPassword?.copyOf(),
                keepAlive = keepAlive,
            )
            if (gen != generation.get()) {
                runCatching { opened.disconnect() }
                return
            }
            session = opened
            _state.value = SshSessionState.Connected
            if (hasStoredCredential()) clearPendingPassword()
            startWatcher(opened, gen)
        } catch (first: FirstUseRequired) {
            if (gen != generation.get()) {
                first.key.fill(0)
                return
            }
            _state.value = SshSessionState.AwaitingHostKeyApproval(
                host = first.host,
                port = first.port,
                algorithm = first.algorithm,
                fingerprint = first.fingerprint,
                key = first.key,
            )
        } catch (changed: HostKeyRejected) {
            if (gen != generation.get()) return
            clearPendingPassword()
            _state.value = SshSessionState.Failed(
                message = changed.message ?: "host key rejected",
                hostKeyChanged = true,
                kind = ConnectionErrorKind.HOST_KEY_CHANGED,
            )
        } catch (t: Throwable) {
            if (gen != generation.get()) return
            val maxAttempts = profile.maxReconnectAttempts
            if (autoReconnect && attempt < maxAttempts && ReconnectPolicy.isTransient(t)) {
                _state.value = SshSessionState.Reconnecting(attempt + 1, maxAttempts)
                try {
                    Thread.sleep(ReconnectPolicy.delayMillis(attempt))
                } catch (_: InterruptedException) {
                    return
                }
                doConnect(gen, attempt + 1)
            } else {
                clearPendingPassword()
                _state.value = SshSessionState.Failed(
                    message = t.message ?: t.javaClass.simpleName,
                    kind = ConnectionError.classify(t),
                )
            }
        }
    }

    /** Called after the user approves a first-use fingerprint; the caller stores the key. */
    fun retryAfterTrust() {
        clearPendingHostKey()
        val gen = generation.incrementAndGet()
        _state.value = SshSessionState.Connecting
        io.execute { doConnect(gen, attempt = 0) }
    }

    /** Watches one connection; when it goes away, retries or reports the drop. */
    private fun startWatcher(open: Session, gen: Long) {
        val thread = Thread({
            var interrupted = false
            try {
                while (gen == generation.get() && open.isConnected) {
                    Thread.sleep(WATCH_INTERVAL_MS)
                }
            } catch (_: InterruptedException) {
                interrupted = true
            }
            if (!interrupted && gen == generation.get()) {
                session = null
                runCatching { open.disconnect() }
                if (autoReconnect && profile.maxReconnectAttempts > 0) {
                    _state.value = SshSessionState.Reconnecting(1, profile.maxReconnectAttempts)
                    io.execute { doConnect(gen, attempt = 0) }
                } else {
                    _state.value = SshSessionState.Closed
                }
            }
        }, "files-watch-$id")
        thread.isDaemon = true
        thread.start()
    }

    override fun openSftp(): SftpClient? =
        session?.takeIf { it.isConnected }?.let { SftpClient(it) }

    /** The user chose to end it: no retries, and the connection is closed. */
    fun disconnect() {
        autoReconnect = false
        generation.incrementAndGet()
        clearPendingHostKey()
        val open = session
        session = null
        clearPendingPassword()
        _state.value = SshSessionState.Closed
        if (open != null) io.execute { runCatching { open.disconnect() } }
    }

    fun destroy() {
        disconnect()
        io.shutdown()
    }

    private fun clearPendingHostKey() {
        (state.value as? SshSessionState.AwaitingHostKeyApproval)?.key?.fill(0)
    }

    private fun clearPendingPassword() {
        pendingPassword?.fill(0)
        pendingPassword = null
    }

    private fun hasStoredCredential(): Boolean = when (val auth = profile.auth) {
        is AuthMethod.Password -> auth.vaultRef.isNotBlank()
        is AuthMethod.PrivateKey -> true
    }

    private companion object {
        const val WATCH_INTERVAL_MS = 3_000L
    }
}
