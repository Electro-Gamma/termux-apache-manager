package app.terminalssh.secure.viewer

import android.content.Context
import android.util.Base64
import org.commonmark.ext.autolink.AutolinkExtension
import org.commonmark.ext.gfm.strikethrough.StrikethroughExtension
import org.commonmark.ext.gfm.tables.TablesExtension
import org.commonmark.ext.task.list.items.TaskListItemsExtension
import org.commonmark.parser.Parser
import org.commonmark.renderer.html.HtmlRenderer
import org.json.JSONArray
import org.json.JSONObject

/** File types the editor opens in the rendered Viewer first (the pencil shows their source). */
internal enum class ViewerKind(val label: String) {
    MARKDOWN("markdown"),
    NOTEBOOK("notebook"),
    SVG("svg"),

    /** Binary bitmap: viewer only. It is never decoded into the text editor. */
    PBM("pbm image"),
}

internal fun viewerKindFor(fileName: String): ViewerKind? =
    when (fileName.substringAfterLast('.', "").lowercase()) {
        "md", "markdown" -> ViewerKind.MARKDOWN
        "ipynb" -> ViewerKind.NOTEBOOK
        "svg" -> ViewerKind.SVG
        "pbm" -> ViewerKind.PBM
        else -> null
    }

/**
 * Turns a file into a self-contained HTML page for the Viewer WebView.
 *
 * The page is locked down: no network at all (images must be data: URIs), and only our own
 * nonce'd script may run, so scripts, event handlers or remote resources inside a remote
 * file can never execute or phone home. SVG goes through <img>, which runs no script either.
 */
internal object ViewerRenderer {
    private val extensions = listOf(
        TablesExtension.create(),
        StrikethroughExtension.create(),
        TaskListItemsExtension.create(),
        AutolinkExtension.create(),
    )
    private val parser = Parser.builder().extensions(extensions).build()
    private val renderer = HtmlRenderer.builder().extensions(extensions).sanitizeUrls(true).build()

    class Assets(val css: String, val js: String)

    @Volatile private var cached: Assets? = null

    fun assets(context: Context): Assets = cached ?: synchronized(this) {
        cached ?: Assets(read(context, "viewer/github.css"), read(context, "viewer/viewer.js")).also { cached = it }
    }

    private fun read(context: Context, path: String): String =
        context.applicationContext.assets.open(path).bufferedReader(Charsets.UTF_8).use { it.readText() }

    fun markdown(text: String): String = renderer.render(parser.parse(text))

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    private fun notice(message: String) = "<p><em>${esc(message)}</em></p>"

    /** The HTML fragment for [kind]. Never throws: a file that cannot be drawn gets a message. */
    fun body(kind: ViewerKind, text: String?, bytes: ByteArray?): String = try {
        when (kind) {
            ViewerKind.MARKDOWN -> markdown(text.orEmpty())
            ViewerKind.NOTEBOOK -> NotebookRenderer.body(JSONObject(text.orEmpty()))
            ViewerKind.SVG -> "<div class=\"svg-view\"><img alt=\"SVG\" src=\"data:image/svg+xml;base64," +
                Base64.encodeToString(text.orEmpty().toByteArray(Charsets.UTF_8), Base64.NO_WRAP) + "\"></div>"
            ViewerKind.PBM -> {
                val png = Pbm.toPng(Pbm.decode(bytes ?: ByteArray(0)))
                "<div class=\"svg-view pbm\"><img alt=\"PBM\" src=\"data:image/png;base64," +
                    Base64.encodeToString(png, Base64.NO_WRAP) + "\"></div>"
            }
        }
    } catch (e: OutOfMemoryError) {
        notice("This file is too large to display.")
    } catch (e: Exception) {
        val what = when (kind) {
            ViewerKind.NOTEBOOK -> "Cannot display this notebook (it may not be valid JSON)"
            ViewerKind.PBM -> "Cannot display this PBM image"
            else -> "Cannot display this file"
        }
        notice(what + ": " + e.message.orEmpty().take(120))
    }

    fun page(body: String, dark: Boolean, assets: Assets, nonce: String): String {
        val viewport = "width=device-width, initial-scale=1, minimum-scale=0.5, maximum-scale=5, user-scalable=yes"
        val csp = "default-src 'none'; img-src data:; style-src 'unsafe-inline'; " +
            "script-src 'nonce-$nonce'; font-src data:; base-uri 'none'; form-action 'none'"
        return """<!DOCTYPE html>
<html data-theme="${if (dark) "dark" else "light"}"><head><meta charset="utf-8">
<meta name="viewport" content="$viewport">
<meta http-equiv="Content-Security-Policy" content="$csp">
<style>${assets.css}</style></head>
<body><article class="markdown-body">$body</article>
<script nonce="$nonce">${assets.js}</script></body></html>"""
    }
}

/** Renders a notebook (markdown cells, highlighted code, outputs) to an HTML fragment. */
internal object NotebookRenderer {
    private val ansi = Regex("\u001B\\[[0-9;?]*[A-Za-z]")

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    private fun joinText(v: Any?): String = when (v) {
        is String -> v
        is JSONArray -> (0 until v.length()).joinToString("") { v.optString(it) }
        else -> ""
    }

    fun body(nb: JSONObject): String {
        if (!nb.has("cells")) throw IllegalArgumentException("only nbformat 4 notebooks are supported")
        val meta = nb.optJSONObject("metadata")
        val lang = (meta?.optJSONObject("language_info")?.optString("name")?.takeIf { it.isNotBlank() }
            ?: meta?.optJSONObject("kernelspec")?.optString("language")?.takeIf { it.isNotBlank() }
            ?: "python").lowercase().filter { it.isLetterOrDigit() || it == '+' || it == '#' || it == '-' }
        val cells = nb.optJSONArray("cells") ?: JSONArray()
        val sb = StringBuilder()
        for (i in 0 until cells.length()) {
            val c = cells.optJSONObject(i) ?: continue
            val src = joinText(c.opt("source"))
            when (c.optString("cell_type")) {
                "markdown" -> sb.append("<section class=\"nb-md\">").append(ViewerRenderer.markdown(src)).append("</section>")
                "raw" -> sb.append("<pre class=\"nb-out nb-raw\">").append(esc(src)).append("</pre>")
                else -> {
                    val n = c.opt("execution_count")
                    val prompt = if (n is Number) "[$n]" else "[ ]"
                    sb.append("<div class=\"nb-cell\"><div class=\"nb-prompt\">In $prompt</div>")
                    sb.append("<pre><code class=\"language-$lang\">").append(esc(src)).append("</code></pre>")
                    outputs(c.optJSONArray("outputs"), sb)
                    sb.append("</div>")
                }
            }
        }
        if (cells.length() == 0) sb.append("<p><em>This notebook has no cells.</em></p>")
        return sb.toString()
    }

    private fun outputs(arr: JSONArray?, sb: StringBuilder) {
        if (arr == null) return
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            when (o.optString("output_type")) {
                "stream" -> {
                    val cls = if (o.optString("name") == "stderr") "nb-out nb-err" else "nb-out"
                    sb.append("<pre class=\"$cls\">").append(esc(joinText(o.opt("text")))).append("</pre>")
                }
                "error" -> {
                    val tb = (o.optJSONArray("traceback")?.let { a -> (0 until a.length()).joinToString("\n") { a.optString(it) } } ?: "")
                        .replace(ansi, "")
                    val text = tb.ifBlank { o.optString("ename") + ": " + o.optString("evalue") }
                    sb.append("<pre class=\"nb-out nb-err\">").append(esc(text)).append("</pre>")
                }
                "display_data", "execute_result" -> o.optJSONObject("data")?.let { sb.append(data(it)) }
            }
        }
    }

    private fun img(mime: String, b64: String) = "<img class=\"nb-out-img\" src=\"data:$mime;base64,$b64\">"

    private fun data(d: JSONObject): String {
        fun text(k: String): String? = if (d.has(k)) joinText(d.opt(k)) else null
        val html = text("text/html")
        if (html != null && !html.contains("<script", ignoreCase = true)) return "<div class=\"nb-html\">$html</div>"
        text("text/markdown")?.let { return "<div class=\"nb-html\">${ViewerRenderer.markdown(it)}</div>" }
        text("image/svg+xml")?.let {
            return img("image/svg+xml", Base64.encodeToString(it.toByteArray(Charsets.UTF_8), Base64.NO_WRAP))
        }
        for (mime in listOf("image/png", "image/jpeg", "image/gif")) {
            // The payload goes into an attribute: keep only base64 characters.
            text(mime)?.let { raw -> return img(mime, raw.filter { ch -> ch.isLetterOrDigit() || ch == '+' || ch == '/' || ch == '=' }) }
        }
        text("text/plain")?.let { return "<pre class=\"nb-out\">${esc(it)}</pre>" }
        if (html != null) return "<pre class=\"nb-out\">(interactive output needs JavaScript and is not shown)</pre>"
        return ""
    }
}
