package app.terminalssh.secure.ssh

sealed interface SshSessionState {
    data object Idle : SshSessionState
    data object Connecting : SshSessionState
    data class AwaitingHostKeyApproval(
        val host: String,
        val port: Int,
        val algorithm: String,
        val fingerprint: String,
        val key: ByteArray,
    ) : SshSessionState
    data object Connected : SshSessionState
    data class Reconnecting(val attempt: Int, val max: Int) : SshSessionState
    data class Failed(
        val message: String,
        val hostKeyChanged: Boolean = false,
        val kind: ConnectionErrorKind = ConnectionErrorKind.UNKNOWN,
    ) : SshSessionState
    data object Closed : SshSessionState

    val isBusy: Boolean get() = this is Connecting || this is Reconnecting
    val isLive: Boolean get() = this is Connected

    /**
     * Connected, or on its way (connecting, reconnecting, waiting for a host-key
     * decision). These are the sessions the app must keep alive in the background; a
     * session that is merely retrying must not let the service stop underneath it.
     */
    val isKeptAlive: Boolean get() = this is Connected || isBusy || this is AwaitingHostKeyApproval
}

/** Higher wins when one host has several connections (terminal and files, or two terminals). */
fun SshSessionState.interest(): Int = when {
    isLive -> 3
    isBusy -> 2
    this is SshSessionState.Failed -> 1
    else -> 0
}
