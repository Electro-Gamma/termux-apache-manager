package app.terminalssh.secure.sftp

/** Everything the server will tell us about one remote entry (`lstat`, so links are not followed). */
data class RemoteStat(
    val sizeBytes: Long,
    val isDirectory: Boolean,
    val isSymlink: Boolean,
    /** `-rw-r--r--` style string. */
    val permissionsString: String,
    /** Octal permission bits such as `0644`. */
    val permissionsOctal: String,
    val uid: Int,
    val gid: Int,
    val accessedEpochSeconds: Long,
    val modifiedEpochSeconds: Long,
    /** Where a symbolic link points, when it is one and the server would say. */
    val linkTarget: String?,
)

/** What a multi-item operation is doing. Single-file downloads keep using the transfer queue. */
enum class BatchKind { DOWNLOAD, DELETE, COPY, MOVE, RENAME, NEW_FOLDER, NEW_FILE }

enum class BatchPhase {
    /** Walking folders to learn how much work there is. */
    PREPARING,
    RUNNING,
    FINISHED,
    CANCELLED,
}

/** Reasons that are not a plain I/O failure, so the report can say something specific. */
enum class BatchProblem { ALREADY_EXISTS, INTO_ITSELF, INVALID_NAME }

data class BatchFailure(
    val path: String,
    val kind: TransferErrorKind,
    val problem: BatchProblem? = null,
)

/**
 * Live state of the one multi-item operation that may run at a time.
 *
 * Failures never abort the run (except a lost connection): one unreadable folder in a
 * 500-file download should cost that folder, not the other 499 files.
 */
data class BatchState(
    val id: String,
    val kind: BatchKind,
    val phase: BatchPhase = BatchPhase.PREPARING,
    /** Files and folders to process, known once scanning has finished. */
    val totalItems: Int = 0,
    val doneItems: Int = 0,
    val totalBytes: Long = 0L,
    val doneBytes: Long = 0L,
    /** Name of whatever is being processed right now. */
    val current: String = "",
    val failures: List<BatchFailure> = emptyList(),
    /** Failures beyond [MAX_FAILURES_KEPT]; counted but not listed. */
    val failuresNotListed: Int = 0,
    /** Symbolic links to folders, which are never followed. */
    val skipped: Int = 0,
    /** The run stopped early because the connection dropped. */
    val aborted: Boolean = false,
) {
    val isFinished: Boolean get() = phase == BatchPhase.FINISHED || phase == BatchPhase.CANCELLED

    val failureCount: Int get() = failures.size + failuresNotListed

    /** 0f..1f, or null while there is nothing meaningful to measure. */
    val progress: Float?
        get() = when {
            phase == BatchPhase.PREPARING -> null
            phase == BatchPhase.FINISHED -> 1f
            totalBytes > 0L && (kind == BatchKind.DOWNLOAD || kind == BatchKind.COPY) ->
                (doneBytes.toFloat() / totalBytes).coerceIn(0f, 1f)
            totalItems > 0 -> (doneItems.toFloat() / totalItems).coerceIn(0f, 1f)
            else -> null
        }

    companion object {
        const val MAX_FAILURES_KEPT = 200
    }
}

/** One selected entry as shown in Properties. [stat] is null if the server refused. */
data class PropertyItem(val entry: RemoteEntry, val stat: RemoteStat?)

data class PropertiesState(
    val items: List<PropertyItem> = emptyList(),
    /** Selected entries' parent folders, de-duplicated, in selection order. */
    val locations: List<String> = emptyList(),
    val loadingDetails: Boolean = true,
    /** Folders are measured recursively in the background. */
    val measuring: Boolean = true,
    val fileCount: Int = 0,
    val folderCount: Int = 0,
    val totalBytes: Long = 0L,
    /** Folders that could not be read, so the totals may be low. */
    val unreadableFolders: Int = 0,
)
