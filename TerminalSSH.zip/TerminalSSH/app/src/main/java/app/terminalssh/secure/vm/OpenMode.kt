package app.terminalssh.secure.vm

/** What opening a server from the host list should start. */
enum class OpenMode { TERMINAL, FILES, BOTH }
