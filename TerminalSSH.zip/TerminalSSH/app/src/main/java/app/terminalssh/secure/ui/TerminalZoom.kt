package app.terminalssh.secure.ui

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalViewConfiguration
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * The terminal's text zoom, as a multiple of the normal size (1.0 = 100%).
 *
 * Kept as plain arithmetic so the limits and steps are testable; the pinch gesture below
 * and the zoom buttons both go through it, which is what keeps them agreeing.
 */
object TerminalZoom {
    const val DEFAULT = 1f
    const val MIN = 0.5f
    const val MAX = 3f

    /** One tap of A− / A+. */
    const val STEP = 0.1f

    /** Pinch changes smaller than this are accumulated rather than applied. */
    const val PINCH_THRESHOLD = 0.02f

    fun clamp(zoom: Float): Float = zoom.coerceIn(MIN, MAX)

    /** One button step in [direction] (+1 or -1), landing on a tidy multiple of [STEP]. */
    fun step(zoom: Float, direction: Int): Float {
        val stepped = ((zoom / STEP).roundToInt() + direction) * STEP
        return clamp((stepped * 100f).roundToInt() / 100f)
    }

    fun percent(zoom: Float): Int = (zoom * 100f).roundToInt()

    /**
     * Folds a pinch factor into the not-yet-applied remainder. Returns the new zoom and
     * the remainder to carry, so slow pinches are not lost to the threshold.
     */
    fun applyPinch(zoom: Float, pending: Float, factor: Float): Pair<Float, Float> {
        val combined = pending * factor
        if (abs(combined - 1f) < PINCH_THRESHOLD) return zoom to combined
        return clamp(zoom * combined) to 1f
    }
}

/**
 * Two-finger pinch to zoom, like Termux.
 *
 * Watches in the Initial pass so it sees the gesture before the terminal does, and
 * consumes only once a second finger is down: a single finger still scrolls and selects
 * exactly as before. [onZoomBy] receives the incremental factor of each movement; [onEnd]
 * fires once when the fingers lift, which is when the result is worth saving.
 */
fun Modifier.pinchToZoom(onZoomBy: (Float) -> Unit, onEnd: () -> Unit): Modifier =
    pointerInput(Unit) {
        awaitEachGesture {
            awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
            var zooming = false
            do {
                val event = awaitPointerEvent(PointerEventPass.Initial)
                if (event.changes.count { it.pressed } >= 2) {
                    zooming = true
                    val factor = event.calculateZoom()
                    if (factor != 1f) onZoomBy(factor)
                }
                if (zooming) event.changes.forEach { it.consume() }
            } while (event.changes.any { it.pressed })
            if (zooming) onEnd()
        }
    }

/**
 * Calls [onTap] for a quick one-finger tap, like Termux raising the keyboard.
 *
 * Observes in the Initial pass and never consumes, so the terminal still gets the touch
 * (selection, scrolling). A gesture that ever has a second finger down, moves past the
 * touch slop, or is held past the long-press time is not a tap, so pinch-zooming can never
 * raise the keyboard.
 */
fun Modifier.onSingleTap(onTap: () -> Unit): Modifier = composed {
    val config = LocalViewConfiguration.current
    val latest = rememberUpdatedState(onTap)
    pointerInput(Unit) {
        awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
            val start = down.position
            val startTime = down.uptimeMillis
            var isTap = true
            while (true) {
                val event = awaitPointerEvent(PointerEventPass.Initial)
                if (event.changes.size > 1 || event.changes.count { it.pressed } > 1) isTap = false
                val change = event.changes.firstOrNull() ?: break
                if ((change.position - start).getDistance() > config.touchSlop) isTap = false
                if (change.uptimeMillis - startTime > config.longPressTimeoutMillis) isTap = false
                if (!event.changes.any { it.pressed }) {
                    if (isTap) latest.value()
                    break
                }
            }
        }
    }
}
