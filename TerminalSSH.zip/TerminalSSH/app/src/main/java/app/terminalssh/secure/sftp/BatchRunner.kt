package app.terminalssh.secure.sftp

import android.content.ContentResolver
import android.net.Uri
import android.provider.DocumentsContract
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

/**
 * Runs the multi-item operations: recursive download, delete, copy, move and rename.
 *
 * One operation at a time, on its own SFTP client, so a long batch never shares a channel
 * with folder listings or with the single-file transfer queue (which is untouched).
 * Every operation first walks the selected folders to learn the total work, then does it;
 * individual failures are collected and reported rather than aborting the run.
 */
class BatchRunner(
    private val session: SftpSource,
    private val contentResolver: ContentResolver,
    private val scope: CoroutineScope,
    private val onFinished: (BatchKind) -> Unit,
) {
    private val _state = MutableStateFlow<BatchState?>(null)
    val state: StateFlow<BatchState?> = _state.asStateFlow()

    val isBusy: Boolean get() = _state.value?.let { !it.isFinished } ?: false

    @Volatile
    private var cancelRequested = false
    private var job: Job? = null

    fun download(items: List<RemoteEntry>, treeUri: Uri): Boolean =
        start(BatchKind.DOWNLOAD) { sftp, rep -> runDownload(sftp, rep, items, treeUri) }

    fun delete(items: List<RemoteEntry>): Boolean =
        start(BatchKind.DELETE) { sftp, rep -> runDelete(sftp, rep, items) }

    fun copy(items: List<RemoteEntry>, destination: String): Boolean =
        start(BatchKind.COPY) { sftp, rep -> runCopy(sftp, rep, items, destination) }

    fun move(items: List<RemoteEntry>, destination: String): Boolean =
        start(BatchKind.MOVE) { sftp, rep -> runMove(sftp, rep, items, destination) }

    fun rename(entry: RemoteEntry, newName: String): Boolean =
        start(BatchKind.RENAME) { sftp, rep -> runRename(sftp, rep, entry, newName) }

    fun createFolder(parent: String, name: String): Boolean =
        start(BatchKind.NEW_FOLDER) { sftp, rep -> runCreateFolder(sftp, rep, parent, name) }

    fun createFile(parent: String, name: String): Boolean =
        start(BatchKind.NEW_FILE) { sftp, rep -> runCreateFile(sftp, rep, parent, name) }

    fun cancel() {
        cancelRequested = true
    }

    /** Hides a finished operation's card. A running one is left alone. */
    fun dismiss() {
        if (_state.value?.isFinished == true) _state.value = null
    }

    /** Session gone or screen left: stop, and make sure the card never stays "running". */
    fun close() {
        cancelRequested = true
        job?.cancel()
        _state.update { s ->
            if (s != null && !s.isFinished) s.copy(phase = BatchPhase.CANCELLED, current = "") else s
        }
    }

    private fun start(kind: BatchKind, work: (SftpClient, Reporter) -> Unit): Boolean {
        if (isBusy) return false
        val id = UUID.randomUUID().toString()
        _state.value = BatchState(id = id, kind = kind)
        cancelRequested = false
        val reporter = Reporter(id)
        job = scope.launch {
            val outcome = runCatching {
                withContext(Dispatchers.IO) {
                    val sftp = session.openSftp() ?: throw java.io.IOException("connection is not available")
                    try {
                        work(sftp, reporter)
                    } finally {
                        sftp.close()
                    }
                }
            }
            val failure = outcome.exceptionOrNull()
            if (failure is CancellationException) {
                reporter.finish(cancelled = true)
                return@launch
            }
            if (failure != null) reporter.fail("", failure)
            reporter.finish(cancelled = cancelRequested)
            onFinished(kind)
        }
        return true
    }

    // ---- reporting ----

    /** Mutated only by the single worker thread; published to the UI at a throttled rate. */
    private inner class Reporter(private val id: String) {
        var phase = BatchPhase.PREPARING
        var totalItems = 0
        var doneItems = 0
        var totalBytes = 0L
        var doneBytes = 0L
        var current = ""
        var skipped = 0
        var aborted = false
        private val failures = ArrayList<BatchFailure>()
        private val failedPaths = HashSet<String>()
        private var notListed = 0
        private var lastPublishedAt = 0L

        /** True once the user cancelled or the connection dropped. */
        val stopped: Boolean get() = cancelRequested || aborted

        fun fail(path: String, kind: TransferErrorKind, problem: BatchProblem? = null) {
            // The same path can fail twice (unreadable folder, then its removal): report once.
            if (path.isNotEmpty() && !failedPaths.add(path)) return
            if (failures.size < BatchState.MAX_FAILURES_KEPT) {
                failures.add(BatchFailure(path, kind, problem))
            } else {
                notListed++
            }
            if (kind == TransferErrorKind.CONNECTION_LOST) aborted = true
            publish()
        }

        fun fail(path: String, error: Throwable): Unit = fail(path, SftpClient.classify(error))

        fun startRunning(fixedItems: Int = -1) {
            if (fixedItems >= 0) totalItems = fixedItems
            phase = BatchPhase.RUNNING
            publish()
        }

        fun begin(name: String) {
            current = name
            publishThrottled()
        }

        fun itemDone() {
            doneItems++
            publishThrottled()
        }

        fun bytes(delta: Long) {
            if (delta > 0L) doneBytes += delta
            publishThrottled()
        }

        fun finish(cancelled: Boolean) {
            phase = if (cancelled) BatchPhase.CANCELLED else BatchPhase.FINISHED
            current = ""
            publish()
        }

        fun publishThrottled() {
            val now = System.nanoTime() / 1_000_000L
            if (now - lastPublishedAt >= PUBLISH_INTERVAL_MS) publish()
        }

        fun publish() {
            lastPublishedAt = System.nanoTime() / 1_000_000L
            val snapshot = failures.toList()
            _state.update { s ->
                if (s == null || s.id != id) {
                    s
                } else {
                    s.copy(
                        phase = phase,
                        totalItems = totalItems,
                        doneItems = doneItems,
                        totalBytes = totalBytes,
                        doneBytes = doneBytes,
                        current = current,
                        failures = snapshot,
                        failuresNotListed = notListed,
                        skipped = skipped,
                        aborted = aborted,
                    )
                }
            }
        }
    }

    /** Thrown from a progress callback to unwind a blocking transfer after a cancel. */
    private class StopRequested : RuntimeException("stopped by the user")

    // ---- planning ----

    /** One file or folder to process; [parentIndex] points at its folder in the same plan, -1 for a selected root. */
    private class PlanItem(val entry: RemoteEntry, val parentIndex: Int)

    private fun scan(
        sftp: SftpClient,
        rep: Reporter,
        roots: List<RemoteEntry>,
        skipLinkedFolders: Boolean,
    ): List<PlanItem> {
        val plan = ArrayList<PlanItem>()
        for (root in roots) {
            if (rep.stopped) break
            scanInto(sftp, rep, root, -1, 0, skipLinkedFolders, plan)
        }
        return plan
    }

    private fun scanInto(
        sftp: SftpClient,
        rep: Reporter,
        entry: RemoteEntry,
        parentIndex: Int,
        depth: Int,
        skipLinkedFolders: Boolean,
        plan: MutableList<PlanItem>,
    ) {
        if (rep.stopped) return
        // A link to a folder is never followed: it could point back up the tree and
        // turn a download into an endless loop.
        if (skipLinkedFolders && entry.isSymlink && sftp.isDirectoryFollowingLinks(entry.path)) {
            rep.skipped++
            return
        }
        val index = plan.size
        plan.add(PlanItem(entry, parentIndex))
        rep.totalItems++
        if (!entry.isDirectory && entry.sizeBytes > 0L) rep.totalBytes += entry.sizeBytes
        rep.publishThrottled()
        if (!entry.isDirectory) return
        if (depth >= MAX_DEPTH) {
            rep.fail(entry.path, TransferErrorKind.UNKNOWN)
            return
        }
        val children = try {
            sftp.list(entry.path)
        } catch (e: Exception) {
            rep.fail(entry.path, e)
            return
        }
        for (child in children) {
            scanInto(sftp, rep, child, index, depth + 1, skipLinkedFolders, plan)
        }
    }

    private fun existingNames(sftp: SftpClient, rep: Reporter, directory: String): MutableSet<String>? =
        try {
            sftp.list(directory).mapTo(HashSet<String>()) { it.name }
        } catch (e: Exception) {
            rep.fail(directory, e)
            null
        }

    /** Drops folders that would be put inside themselves, reporting each one. */
    private fun withoutIntoItself(rep: Reporter, items: List<RemoteEntry>, destination: String): List<RemoteEntry> =
        items.filter { entry ->
            val bad = entry.isDirectory && RemotePath.isSameOrInside(destination, entry.path)
            if (bad) rep.fail(entry.path, TransferErrorKind.UNKNOWN, BatchProblem.INTO_ITSELF)
            !bad
        }

    // ---- download ----

    private fun runDownload(sftp: SftpClient, rep: Reporter, items: List<RemoteEntry>, treeUri: Uri) {
        val plan = scan(sftp, rep, items, skipLinkedFolders = true)
        if (rep.stopped) return
        val rootDocument = try {
            DocumentsContract.buildDocumentUriUsingTree(treeUri, DocumentsContract.getTreeDocumentId(treeUri))
        } catch (e: Exception) {
            rep.fail("", TransferErrorKind.LOCAL_UNAVAILABLE)
            return
        }
        rep.startRunning()
        val folders = HashMap<Int, Uri>()
        for (index in plan.indices) {
            if (rep.stopped) break
            val item = plan[index]
            val entry = item.entry
            val parent: Uri? = if (item.parentIndex < 0) rootDocument else folders[item.parentIndex]
            if (parent == null) {
                // Its folder could not be created; that failure is already on the report.
                rep.itemDone()
                continue
            }
            val name = RemotePath.sanitizeDownloadName(entry.name)
            rep.begin(entry.name)
            if (entry.isDirectory) {
                try {
                    folders[index] = createLocal(parent, DocumentsContract.Document.MIME_TYPE_DIR, name)
                } catch (e: Exception) {
                    rep.fail(entry.path, TransferErrorKind.LOCAL_UNAVAILABLE)
                }
            } else {
                downloadFile(sftp, rep, entry, parent, name)
            }
            rep.itemDone()
        }
    }

    private fun createLocal(parent: Uri, mimeType: String, name: String): Uri =
        DocumentsContract.createDocument(contentResolver, parent, mimeType, name)
            ?: throw IllegalStateException("cannot create $name")

    private fun discardLocal(uri: Uri?) {
        if (uri != null) runCatching { DocumentsContract.deleteDocument(contentResolver, uri) }
    }

    private fun downloadFile(sftp: SftpClient, rep: Reporter, entry: RemoteEntry, parent: Uri, name: String) {
        val target = try {
            createLocal(parent, "application/octet-stream", name)
        } catch (e: Exception) {
            rep.fail(entry.path, TransferErrorKind.LOCAL_UNAVAILABLE)
            return
        }
        val sink = try {
            contentResolver.openOutputStream(target, "wt")
        } catch (e: Exception) {
            null
        }
        if (sink == null) {
            discardLocal(target)
            rep.fail(entry.path, TransferErrorKind.LOCAL_UNAVAILABLE)
            return
        }
        try {
            var last = 0L
            sink.use { out ->
                sftp.download(entry.path, out, resumeFrom = 0L) { total ->
                    if (cancelRequested) throw StopRequested()
                    rep.bytes(total - last)
                    last = total
                }
            }
        } catch (e: Exception) {
            // Never leave a half-written file that looks like a finished one.
            discardLocal(target)
            if (!cancelRequested) rep.fail(entry.path, e)
        }
    }

    // ---- delete ----

    private fun runDelete(sftp: SftpClient, rep: Reporter, items: List<RemoteEntry>) {
        // Links are removed as links, never followed, so nothing outside the selection is touched.
        val plan = scan(sftp, rep, items, skipLinkedFolders = false)
        // A scan cut short must not turn into a partial delete the user never confirmed.
        if (rep.stopped) return
        rep.startRunning()
        deletePlan(sftp, rep, plan, countProgress = true)
    }

    private fun deletePlan(sftp: SftpClient, rep: Reporter, plan: List<PlanItem>, countProgress: Boolean): Boolean {
        // Children precede their folder in the plan's reverse order, so folders are empty when reached.
        var ok = true
        val blocked = HashSet<Int>()
        for (index in plan.indices.reversed()) {
            if (rep.stopped) return false
            val item = plan[index]
            val entry = item.entry
            if (index in blocked) {
                // Something inside failed, so this folder cannot be removed; do not pile on.
                if (item.parentIndex >= 0) blocked.add(item.parentIndex)
                ok = false
                if (countProgress) rep.itemDone()
                continue
            }
            rep.begin(entry.name)
            try {
                sftp.delete(entry.path, entry.isDirectory)
            } catch (e: Exception) {
                rep.fail(entry.path, e)
                if (item.parentIndex >= 0) blocked.add(item.parentIndex)
                ok = false
            }
            if (countProgress) rep.itemDone()
        }
        return ok
    }

    // ---- copy ----

    private fun runCopy(sftp: SftpClient, rep: Reporter, items: List<RemoteEntry>, destination: String) {
        val dest = RemotePath.normalize(destination)
        val valid = withoutIntoItself(rep, items, dest)
        val plan = scan(sftp, rep, valid, skipLinkedFolders = true)
        if (rep.stopped) return
        val existing = existingNames(sftp, rep, dest) ?: return
        rep.startRunning()
        copyPlan(sftp, rep, plan, dest, existing, forcedTopName = null)
    }

    /** Returns true when everything in [plan] was copied without a failure. */
    private fun copyPlan(
        sftp: SftpClient,
        rep: Reporter,
        plan: List<PlanItem>,
        destination: String,
        existing: MutableSet<String>,
        forcedTopName: String?,
    ): Boolean {
        var ok = true
        val targets = HashMap<Int, String>()
        for (index in plan.indices) {
            if (rep.stopped) return false
            val item = plan[index]
            val entry = item.entry
            val parentPath: String?
            val name: String
            if (item.parentIndex < 0) {
                parentPath = destination
                name = forcedTopName ?: RemotePath.uniqueName(existing, entry.name)
                existing.add(name)
            } else {
                parentPath = targets[item.parentIndex]
                name = entry.name
            }
            if (parentPath == null) {
                // The folder this belongs in could not be created; already reported.
                rep.itemDone()
                continue
            }
            val targetPath = RemotePath.join(parentPath, name)
            rep.begin(entry.name)
            if (entry.isDirectory) {
                try {
                    sftp.makeDirectory(targetPath)
                    targets[index] = targetPath
                } catch (e: Exception) {
                    rep.fail(entry.path, e)
                    ok = false
                }
            } else {
                try {
                    var last = 0L
                    sftp.copyFile(entry.path, targetPath) { total ->
                        if (cancelRequested) throw StopRequested()
                        rep.bytes(total - last)
                        last = total
                    }
                } catch (e: Exception) {
                    if (!cancelRequested) rep.fail(entry.path, e)
                    ok = false
                    // Remove the partial copy rather than leave a truncated file behind.
                    runCatching { sftp.delete(targetPath, false) }
                }
            }
            rep.itemDone()
        }
        return ok
    }

    // ---- move ----

    private fun runMove(sftp: SftpClient, rep: Reporter, items: List<RemoteEntry>, destination: String) {
        val dest = RemotePath.normalize(destination)
        val valid = withoutIntoItself(rep, items, dest)
        val existing = existingNames(sftp, rep, dest) ?: return
        rep.startRunning(fixedItems = valid.size)
        for (entry in valid) {
            if (rep.stopped) break
            rep.begin(entry.name)
            if (RemotePath.parent(entry.path) == dest) {
                // Already in that folder; nothing to move.
                rep.itemDone()
                continue
            }
            val name = RemotePath.uniqueName(existing, entry.name)
            val target = RemotePath.join(dest, name)
            try {
                sftp.rename(entry.path, target)
                existing.add(name)
                rep.itemDone()
            } catch (renameFailure: Exception) {
                val kind = SftpClient.classify(renameFailure)
                val hopeless = kind == TransferErrorKind.PERMISSION_DENIED ||
                    kind == TransferErrorKind.NOT_FOUND ||
                    kind == TransferErrorKind.CONNECTION_LOST
                if (hopeless) {
                    rep.fail(entry.path, kind)
                    rep.itemDone()
                } else {
                    moveByCopying(sftp, rep, entry, dest, name, existing)
                }
            }
        }
    }

    /**
     * Rename can fail across filesystems. Fall back to copy-then-delete, and delete the
     * original only if every byte of the copy succeeded.
     */
    private fun moveByCopying(
        sftp: SftpClient,
        rep: Reporter,
        entry: RemoteEntry,
        destination: String,
        name: String,
        existing: MutableSet<String>,
    ) {
        // This one counted as a single item; its expansion replaces it.
        rep.totalItems--
        val plan = scan(sftp, rep, listOf(entry), skipLinkedFolders = true)
        if (rep.stopped) return
        val copied = copyPlan(sftp, rep, plan, destination, existing, forcedTopName = name)
        if (copied && !rep.stopped) {
            deletePlan(sftp, rep, plan, countProgress = false)
        }
    }

    // ---- rename ----

    private fun runRename(sftp: SftpClient, rep: Reporter, entry: RemoteEntry, newName: String) {
        rep.startRunning(fixedItems = 1)
        rep.begin(entry.name)
        if (!RemotePath.isValidEntryName(newName)) {
            rep.fail(entry.path, TransferErrorKind.UNKNOWN, BatchProblem.INVALID_NAME)
            return
        }
        if (newName == entry.name) {
            rep.itemDone()
            return
        }
        val parent = RemotePath.parent(entry.path)
        val existing = existingNames(sftp, rep, parent) ?: return
        if (newName in existing) {
            rep.fail(entry.path, TransferErrorKind.UNKNOWN, BatchProblem.ALREADY_EXISTS)
            return
        }
        try {
            sftp.rename(entry.path, RemotePath.join(parent, newName))
        } catch (e: Exception) {
            rep.fail(entry.path, e)
        }
        rep.itemDone()
    }

    // ---- new folder ----

    private fun runCreateFolder(sftp: SftpClient, rep: Reporter, parent: String, name: String) {
        val folderName = name.trim()
        rep.startRunning(fixedItems = 1)
        rep.begin(folderName)
        if (!RemotePath.isValidEntryName(folderName)) {
            rep.fail(parent, TransferErrorKind.UNKNOWN, BatchProblem.INVALID_NAME)
            return
        }
        val target = RemotePath.join(parent, folderName)
        val existing = existingNames(sftp, rep, parent) ?: return
        if (folderName in existing) {
            rep.fail(target, TransferErrorKind.UNKNOWN, BatchProblem.ALREADY_EXISTS)
            return
        }
        try {
            sftp.makeDirectory(target)
        } catch (e: Exception) {
            rep.fail(target, e)
        }
        rep.itemDone()
    }

    private fun runCreateFile(sftp: SftpClient, rep: Reporter, parent: String, name: String) {
        val fileName = name.trim()
        rep.startRunning(fixedItems = 1)
        rep.begin(fileName)
        if (!RemotePath.isValidEntryName(fileName)) {
            rep.fail(parent, TransferErrorKind.UNKNOWN, BatchProblem.INVALID_NAME)
            return
        }
        val target = RemotePath.join(parent, fileName)
        val existing = existingNames(sftp, rep, parent) ?: return
        if (fileName in existing) {
            rep.fail(target, TransferErrorKind.UNKNOWN, BatchProblem.ALREADY_EXISTS)
            return
        }
        try {
            sftp.createEmptyFile(target)
        } catch (e: Exception) {
            rep.fail(target, e)
        }
        rep.itemDone()
    }

    private companion object {
        const val PUBLISH_INTERVAL_MS = 150L
        const val MAX_DEPTH = 64
    }
}
