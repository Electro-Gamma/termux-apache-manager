package app.terminalssh.secure.sftp

/**
 * POSIX path arithmetic for the remote browser.
 *
 * Deliberately not `java.io.File`: that resolves against the *device's* filesystem rules,
 * and on a phone the separator and root semantics happen to match POSIX only by accident.
 * Remote paths are always POSIX regardless of what the phone runs.
 */
object RemotePath {

    const val ROOT = "/"

    /** Normalises `.`, `..`, duplicate slashes, and trailing slashes. */
    fun normalize(path: String): String {
        val absolute = path.startsWith('/')
        val parts = ArrayDeque<String>()
        for (segment in path.split('/')) {
            when (segment) {
                "", "." -> Unit
                ".." -> if (parts.isNotEmpty() && parts.last() != "..") {
                    parts.removeLast()
                } else if (!absolute) {
                    // A relative path may legitimately climb above its own start.
                    parts.addLast("..")
                }
                else -> parts.addLast(segment)
            }
        }
        val joined = parts.joinToString("/")
        return when {
            absolute -> "/$joined"
            joined.isEmpty() -> "."
            else -> joined
        }
    }

    /** Appends [child] to [base], treating an absolute [child] as a replacement. */
    fun join(base: String, child: String): String = when {
        child.startsWith('/') -> normalize(child)
        base.endsWith('/') -> normalize(base + child)
        else -> normalize("$base/$child")
    }

    /** The containing directory, or [ROOT] when already at the top. */
    fun parent(path: String): String {
        val normalized = normalize(path)
        if (normalized == ROOT) return ROOT
        val cut = normalized.lastIndexOf('/')
        return when {
            cut <= 0 -> ROOT
            else -> normalized.substring(0, cut)
        }
    }

    /** The final component, or [ROOT] for the root itself. */
    fun name(path: String): String {
        val normalized = normalize(path)
        if (normalized == ROOT) return ROOT
        return normalized.substringAfterLast('/')
    }

    /**
     * Breadcrumb segments with the absolute path each one navigates to.
     * `/var/log` becomes `[("/", "/"), ("var", "/var"), ("log", "/var/log")]`.
     */
    fun breadcrumbs(path: String): List<Pair<String, String>> {
        val normalized = normalize(path)
        val crumbs = mutableListOf(ROOT to ROOT)
        if (normalized == ROOT) return crumbs
        var accumulated = ""
        for (segment in normalized.trim('/').split('/')) {
            accumulated += "/$segment"
            crumbs += segment to accumulated
        }
        return crumbs
    }

    /**
     * A filename safe to write into device storage.
     *
     * A remote server is untrusted: a file literally named `../../evil` must not be able
     * to steer a download outside the folder the user picked.
     */
    fun sanitizeDownloadName(remoteName: String): String {
        val base = remoteName.substringAfterLast('/').substringAfterLast('\\')
        val cleaned = base.filterNot { it.isISOControl() }.trim()
        return when {
            cleaned.isEmpty() || cleaned == "." || cleaned == ".." -> "download"
            else -> cleaned
        }
    }

    /** True when [path] is [ancestor] itself or lies anywhere beneath it. */
    fun isSameOrInside(path: String, ancestor: String): Boolean {
        val candidate = normalize(path)
        val root = normalize(ancestor)
        if (root == ROOT) return true
        return candidate == root || candidate.startsWith("$root/")
    }

    /**
     * A name for a new entry that does not collide with [existing].
     * `report.txt` becomes `report (copy).txt`, then `report (copy 2).txt`, and so on.
     * Pasting never overwrites: silently replacing a file is the one mistake that cannot
     * be undone from a phone.
     */
    fun uniqueName(existing: Set<String>, desired: String): String {
        if (desired !in existing) return desired
        val dot = desired.lastIndexOf('.')
        val hasExtension = dot > 0 && dot < desired.length - 1
        val stem = if (hasExtension) desired.substring(0, dot) else desired
        val extension = if (hasExtension) desired.substring(dot) else ""
        var attempt = 1
        var candidate = "$stem (copy)$extension"
        while (candidate in existing) {
            attempt++
            candidate = "$stem (copy $attempt)$extension"
        }
        return candidate
    }

    /** Whether [name] can be used as a single path component when renaming. */
    fun isValidEntryName(name: String): Boolean =
        name.isNotBlank() &&
            name != "." &&
            name != ".." &&
            !name.contains('/') &&
            name.none { it.isISOControl() }
}
