package app.terminalssh.secure.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.ContentCut
import androidx.compose.material.icons.outlined.CreateNewFolder
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Deselect
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.DriveFileRenameOutline
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.SelectAll
import androidx.compose.material.icons.outlined.SortByAlpha
import androidx.compose.material.icons.outlined.Storage
import androidx.compose.material.icons.outlined.SwapVert
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import app.terminalssh.secure.sftp.ListingView
import app.terminalssh.secure.sftp.RemotePath
import app.terminalssh.secure.sftp.SortKey
import app.terminalssh.secure.ui.theme.Danger
import app.terminalssh.secure.ui.theme.Turquoise
import app.terminalssh.secure.R
import app.terminalssh.secure.sftp.RemoteEntry
import app.terminalssh.secure.sftp.SftpController
import app.terminalssh.secure.ui.theme.TextSecondary
import app.terminalssh.secure.vm.AppViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel

/**
 * SFTP tab. Rides the currently selected terminal session rather than opening its own
 * connection, so browsing files never means authenticating a second time.
 */
@Composable
fun FilesScreen(viewModel: AppViewModel, onGoToHosts: () -> Unit) {
    val sessions by viewModel.sessions.sessions.collectAsStateWithLifecycle()
    val session = sessions.firstOrNull { it.state.value.isLive } ?: sessions.firstOrNull()

    if (session == null) {
        NoSession(onGoToHosts)
        return
    }

    val context = LocalContext.current
    // Tied to this session: switching sessions rebuilds the controller and its queue.
    val controller = remember(session.id) {
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
        SftpController(session, context.contentResolver, scope) to scope
    }
    val sftp = controller.first

    DisposableEffect(session.id) {
        sftp.openHome()
        onDispose {
            sftp.close()
            controller.second.cancel()
        }
    }

    val browser by sftp.browser.collectAsStateWithLifecycle()
    val transfers by sftp.queue.transfers.collectAsStateWithLifecycle()
    val selection by sftp.selection.collectAsStateWithLifecycle()
    val clipboard by sftp.clipboard.collectAsStateWithLifecycle()
    val batch by sftp.batch.collectAsStateWithLifecycle()
    val properties by sftp.properties.collectAsStateWithLifecycle()
    var pendingDownload by remember { mutableStateOf<RemoteEntry?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }
    var renaming by remember { mutableStateOf<RemoteEntry?>(null) }
    var showReport by remember { mutableStateOf(false) }
    var creatingFolder by remember { mutableStateOf(false) }

    // What is on screen: hidden files and sort order are display choices, so everything
    // that acts on "all items here" works from this list, not from the raw listing.
    val viewOptions by viewModel.sftpViewOptions.collectAsStateWithLifecycle()
    val visibleEntries = remember(browser.entries, viewOptions) {
        ListingView.apply(browser.entries, viewOptions)
    }
    val hiddenCount = remember(browser.entries, viewOptions) {
        ListingView.hiddenCount(browser.entries, viewOptions)
    }
    val busy = batch?.isFinished == false
    val allHereSelected = selection.coversAll(visibleEntries)

    // Back leaves selection mode before it leaves the screen.
    BackHandler(enabled = selection.isActive) { sftp.clearSelection() }

    val saveLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream"),
    ) { uri ->
        val entry = pendingDownload
        pendingDownload = null
        if (uri != null && entry != null) {
            sftp.enqueueDownload(entry, uri)
            // Only once the file is really queued: cancelling the picker keeps the selection.
            sftp.clearSelection()
        }
    }

    // Several items, or any folder: pick one destination folder and recreate the structure in it.
    val treeLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree(),
    ) { uri ->
        if (uri != null) sftp.downloadSelectionTo(uri)
    }

    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            sftp.enqueueUpload(uri, viewModel.displayNameFor(uri), browser.path)
        }
    }

    Column(Modifier.fillMaxSize().navigationBarsPadding()) {
        FileManagerTopBar(
            selection = selection,
            currentPath = browser.path,
            canGoUp = browser.path != RemotePath.ROOT,
            onGoUp = sftp::navigateUp,
            onExitSelection = sftp::clearSelection,
        ) { closeMenu ->
            if (selection.isActive) {
                // Selection actions live here, not in a toolbar.
                MenuEntry(
                    Icons.Outlined.Download,
                    stringResource(R.string.sftp_action_download),
                    closeMenu,
                    enabled = !busy,
                ) {
                    val only = selection.single
                    if (only != null && !only.isDirectory) {
                        // A lone file keeps the original save-as flow exactly as it was.
                        pendingDownload = only
                        saveLauncher.launch(RemotePath.sanitizeDownloadName(only.name))
                    } else {
                        treeLauncher.launch(null)
                    }
                }
                MenuEntry(Icons.Outlined.ContentCopy, stringResource(R.string.sftp_action_copy), closeMenu) {
                    sftp.copySelection()
                }
                MenuEntry(Icons.Outlined.ContentCut, stringResource(R.string.sftp_action_cut), closeMenu) {
                    sftp.cutSelection()
                }
                // Renaming several items to one name makes no sense, so it needs a single item.
                MenuEntry(
                    Icons.Outlined.DriveFileRenameOutline,
                    stringResource(R.string.sftp_action_rename),
                    closeMenu,
                    enabled = !busy && selection.count == 1,
                ) {
                    renaming = selection.single
                }
                MenuEntry(
                    Icons.Outlined.Delete,
                    stringResource(R.string.sftp_action_delete),
                    closeMenu,
                    enabled = !busy,
                    tint = Danger,
                ) {
                    confirmDelete = true
                }
                MenuEntry(Icons.Outlined.Info, stringResource(R.string.sftp_action_properties), closeMenu) {
                    sftp.showProperties()
                }
                HorizontalDivider()
                MenuEntry(
                    if (allHereSelected) Icons.Outlined.Deselect else Icons.Outlined.SelectAll,
                    stringResource(if (allHereSelected) R.string.sftp_deselect_all else R.string.sftp_select_all),
                    closeMenu,
                ) {
                    // "Deselect all" empties the whole selection, other folders included.
                    if (allHereSelected) sftp.clearSelection() else sftp.selectAll(visibleEntries)
                }
            } else {
                MenuEntry(Icons.Outlined.Refresh, stringResource(R.string.sftp_refresh), closeMenu) {
                    sftp.refresh()
                }
                MenuEntry(
                    if (viewOptions.showHidden) Icons.Outlined.VisibilityOff else Icons.Outlined.Visibility,
                    stringResource(
                        if (viewOptions.showHidden) R.string.sftp_menu_hide_hidden else R.string.sftp_menu_show_hidden,
                    ),
                    closeMenu,
                ) {
                    viewModel.updateSftpViewOptions { it.copy(showHidden = !it.showHidden) }
                }
                MenuEntry(
                    Icons.Outlined.CreateNewFolder,
                    stringResource(R.string.sftp_menu_new_folder),
                    closeMenu,
                    enabled = !busy,
                ) {
                    creatingFolder = true
                }
                MenuEntry(
                    Icons.Outlined.SelectAll,
                    stringResource(R.string.sftp_select_all),
                    closeMenu,
                    enabled = visibleEntries.isNotEmpty(),
                ) {
                    sftp.selectAll(visibleEntries)
                }
                HorizontalDivider()
                MenuEntry(
                    Icons.Outlined.SortByAlpha,
                    stringResource(R.string.sftp_menu_sort_name),
                    closeMenu,
                    checked = viewOptions.sortKey == SortKey.NAME,
                ) {
                    viewModel.updateSftpViewOptions { it.copy(sortKey = SortKey.NAME) }
                }
                MenuEntry(
                    Icons.Outlined.Storage,
                    stringResource(R.string.sftp_menu_sort_size),
                    closeMenu,
                    checked = viewOptions.sortKey == SortKey.SIZE,
                ) {
                    viewModel.updateSftpViewOptions { it.copy(sortKey = SortKey.SIZE) }
                }
                MenuEntry(
                    Icons.Outlined.Schedule,
                    stringResource(R.string.sftp_menu_sort_date),
                    closeMenu,
                    checked = viewOptions.sortKey == SortKey.MODIFIED,
                ) {
                    viewModel.updateSftpViewOptions { it.copy(sortKey = SortKey.MODIFIED) }
                }
                MenuEntry(
                    Icons.Outlined.SwapVert,
                    stringResource(R.string.sftp_menu_sort_reverse),
                    closeMenu,
                    checked = viewOptions.descending,
                ) {
                    viewModel.updateSftpViewOptions { it.copy(descending = !it.descending) }
                }
            }
        }
        HostChip(session.title)
        batch?.let { current ->
            BatchCard(
                state = current,
                onCancel = sftp::cancelBatch,
                onDismiss = sftp::dismissBatch,
                onDetails = { showReport = true },
            )
        }
        TransferStrip(
            transfers = transfers,
            onPause = sftp::pause,
            onResume = sftp::resume,
            onCancel = sftp::cancel,
            onClearFinished = sftp::clearFinished,
        )
        Box(Modifier.weight(1f)) {
            SftpBrowser(
                state = browser.copy(entries = visibleEntries),
                onNavigate = sftp::navigate,
                onDownload = { entry ->
                    pendingDownload = entry
                    // SAF picks the destination, so the app never needs storage permission
                    // and the user stays in control of where their files land.
                    saveLauncher.launch(RemotePath.sanitizeDownloadName(entry.name))
                },
                selection = selection,
                onToggleSelect = sftp::toggleSelection,
                hiddenCount = hiddenCount,
                modifier = Modifier.fillMaxSize(),
            )
            // Upload is the one primary action of this screen, so it is the floating button.
            if (!selection.isActive) {
                FloatingActionButton(
                    onClick = { openLauncher.launch(arrayOf("*/*")) },
                    containerColor = Turquoise,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
                ) {
                    Icon(Icons.Outlined.Add, stringResource(R.string.sftp_upload))
                }
            }
        }
        clipboard?.let { clip ->
            PasteBar(
                clipboard = clip,
                busy = busy,
                onPaste = { sftp.pasteHere() },
                onClear = sftp::clearClipboard,
            )
        }
    }

    if (confirmDelete && selection.isActive) {
        DeleteConfirmDialog(
            selection = selection,
            onConfirm = {
                confirmDelete = false
                sftp.deleteSelection()
            },
            onDismiss = { confirmDelete = false },
        )
    }

    if (creatingFolder) {
        NewFolderDialog(
            onConfirm = { name ->
                creatingFolder = false
                sftp.createFolder(name)
            },
            onDismiss = { creatingFolder = false },
        )
    }

    renaming?.let { target ->
        RenameDialog(
            entry = target,
            onConfirm = { newName ->
                renaming = null
                sftp.renameSelected(newName)
            },
            onDismiss = { renaming = null },
        )
    }

    properties?.let { state ->
        PropertiesDialog(state = state, onDismiss = sftp::dismissProperties)
    }

    // A report belongs to one operation: a new or dismissed batch closes it.
    LaunchedEffect(batch?.id) { showReport = false }
    val finished = batch
    if (showReport && finished != null && finished.failureCount > 0) {
        BatchReportDialog(state = finished, onDismiss = { showReport = false })
    }
}

@Composable
private fun NoSession(onGoToHosts: () -> Unit) {
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text(
                stringResource(R.string.sftp_no_session),
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
                textAlign = TextAlign.Center,
            )
            Button(onClick = onGoToHosts, modifier = Modifier.height(48.dp)) {
                Text(stringResource(R.string.tab_hosts))
            }
        }
    }
}
