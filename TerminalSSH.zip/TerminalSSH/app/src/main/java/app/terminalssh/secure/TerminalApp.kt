package app.terminalssh.secure

import android.app.Application
import app.terminalssh.secure.security.AndroidKeyStoreVault
import app.terminalssh.secure.service.SshForegroundService
import app.terminalssh.secure.ssh.FileSessionRegistry
import app.terminalssh.secure.ssh.HostStatusMonitor
import app.terminalssh.secure.ssh.JschSshClient
import app.terminalssh.secure.ssh.SessionRegistry
import app.terminalssh.secure.storage.HostStore
import app.terminalssh.secure.storage.KnownHostsStore
import app.terminalssh.secure.settings.SettingsStore
import app.terminalssh.secure.storage.Settings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch

/** Single composition root. No DI framework: the graph is six objects. */
class TerminalApp : Application() {
    lateinit var vault: AndroidKeyStoreVault; private set
    lateinit var knownHosts: KnownHostsStore; private set
    lateinit var hosts: HostStore; private set
    lateinit var settings: Settings; private set

    /** Schema-driven store; [settings] stays for the paths not yet migrated to it. */
    lateinit var settingsStore: SettingsStore; private set
    lateinit var client: JschSshClient; private set
    lateinit var sessions: SessionRegistry; private set

    /** File Manager connections, one per server, independent of the terminal sessions. */
    lateinit var files: FileSessionRegistry; private set

    /** Online/offline state of every configured server. */
    lateinit var reachability: HostStatusMonitor; private set

    /** Outlives every Activity: sessions and their tasks belong to the app, not to a screen. */
    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    override fun onCreate() {
        super.onCreate()
        vault = AndroidKeyStoreVault(this)
        knownHosts = KnownHostsStore(this)
        hosts = HostStore(this)
        settings = Settings(this)
        settingsStore = SettingsStore(this)
        client = JschSshClient(vault, knownHosts)
        sessions = SessionRegistry()
        files = FileSessionRegistry(contentResolver, client)
        reachability = HostStatusMonitor(appScope)

        // The foreground service is what keeps the process, and so every connection and
        // running task, alive once the UI is gone. Its lifetime follows the sessions
        // themselves rather than any screen, so it stays up exactly as long as something
        // is connected or reconnecting, and stops when the last one is closed.
        appScope.launch {
            combine(sessions.keepAliveCountFlow, files.keepAliveCountFlow) { terminals, fileManagers ->
                terminals + fileManagers
            }.distinctUntilChanged().collect { count ->
                SshForegroundService.sync(this@TerminalApp, count)
            }
        }
    }

    /** True while any terminal or File Manager is connected or reconnecting. */
    fun hasBackgroundWork(): Boolean = sessions.keepAliveCount() + files.keepAliveCount() > 0

    /** The explicit "disconnect everything" action. The only way, besides closing one by one, that sessions end. */
    fun closeAllSessions() {
        sessions.closeAll()
        files.closeAll()
    }
}
