package app.terminalssh.secure.viewer

import android.graphics.Bitmap
import android.graphics.Color as AColor
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import app.terminalssh.secure.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException

/**
 * A PDF opened with the platform [PdfRenderer]. The bytes go through an unlinked temp file
 * (deleted the moment the descriptor is open, so nothing stays on disk) and pages are drawn
 * one at a time; the renderer is not thread-safe, hence the lock.
 */
internal class PdfDoc private constructor(
    private val pfd: ParcelFileDescriptor,
    private val renderer: PdfRenderer,
    /** Page size in points, so every page has its final height before it is drawn. */
    val sizes: List<Pair<Int, Int>>,
) {
    private val lock = Any()
    private var closed = false

    val pageCount: Int get() = sizes.size

    suspend fun render(index: Int, widthPx: Int): Bitmap? = withContext(Dispatchers.Default) {
        synchronized(lock) {
            if (closed) return@synchronized null
            val page = renderer.openPage(index)
            try {
                val w = widthPx.coerceAtLeast(1)
                var h = (w.toLong() * page.height / page.width.coerceAtLeast(1)).toInt().coerceAtLeast(1)
                var bw = w
                // Keep one page bitmap under ~12M pixels however big the page is.
                if (bw.toLong() * h > MAX_PAGE_PIXELS) {
                    val k = Math.sqrt(MAX_PAGE_PIXELS.toDouble() / (bw.toLong() * h))
                    bw = (bw * k).toInt().coerceAtLeast(1)
                    h = (h * k).toInt().coerceAtLeast(1)
                }
                val bitmap = Bitmap.createBitmap(bw, h, Bitmap.Config.ARGB_8888)
                bitmap.eraseColor(AColor.WHITE) // PdfRenderer draws onto transparent
                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                bitmap
            } finally {
                page.close()
            }
        }
    }

    fun close() {
        synchronized(lock) {
            if (closed) return
            closed = true
            runCatching { renderer.close() }
            runCatching { pfd.close() }
        }
    }

    companion object {
        private const val MAX_PAGE_PIXELS = 12_000_000L

        fun open(cacheDir: File, bytes: ByteArray): PdfDoc {
            val head = String(bytes, 0, minOf(bytes.size, 1024), Charsets.ISO_8859_1)
            if (!head.contains("%PDF-")) throw IOException("not a PDF file")
            val tmp = File.createTempFile("view", ".pdf", cacheDir)
            val pfd = try {
                tmp.writeBytes(bytes)
                ParcelFileDescriptor.open(tmp, ParcelFileDescriptor.MODE_READ_ONLY)
            } finally {
                tmp.delete() // the open descriptor keeps the data readable
            }
            try {
                val renderer = try {
                    PdfRenderer(pfd)
                } catch (e: SecurityException) {
                    throw IOException("password-protected PDFs cannot be shown")
                }
                if (renderer.pageCount == 0) {
                    renderer.close()
                    throw IOException("this PDF has no pages")
                }
                val sizes = ArrayList<Pair<Int, Int>>(renderer.pageCount)
                for (i in 0 until renderer.pageCount) {
                    val p = renderer.openPage(i)
                    try {
                        sizes += p.width.coerceAtLeast(1) to p.height.coerceAtLeast(1)
                    } finally {
                        p.close()
                    }
                }
                return PdfDoc(pfd, renderer, sizes)
            } catch (e: Throwable) {
                runCatching { pfd.close() }
                throw e
            }
        }
    }
}

private sealed interface PdfLoad {
    data object Loading : PdfLoad
    class Ready(val doc: PdfDoc) : PdfLoad
    class Failed(val message: String) : PdfLoad
}

/**
 * The page list of a PDF. Pinch with two fingers to zoom: the pages get wider (and are
 * redrawn sharp once the pinch settles), and a horizontal drag pans when zoomed in.
 */
@Composable
internal fun PdfPane(bytes: ByteArray?, dark: Boolean, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val load by produceState<PdfLoad>(PdfLoad.Loading, bytes) {
        if (bytes == null) {
            value = PdfLoad.Failed("no data")
            return@produceState
        }
        val result = withContext(Dispatchers.IO) { runCatching { PdfDoc.open(context.cacheDir, bytes) } }
        val doc = result.getOrNull()
        value = if (doc != null) PdfLoad.Ready(doc)
        else PdfLoad.Failed(result.exceptionOrNull()?.message ?: "cannot open this PDF")
        awaitDispose { doc?.close() }
    }
    val backdrop = if (dark) Color(0xFF1B1F24) else Color(0xFFDDDDDD)

    when (val state = load) {
        PdfLoad.Loading -> Box(modifier.fillMaxSize().background(backdrop), contentAlignment = Alignment.Center) {
            Text(stringResource(R.string.editor_loading), color = MaterialTheme.colorScheme.onSurface)
        }
        is PdfLoad.Failed -> Box(modifier.fillMaxSize().background(backdrop).padding(24.dp), contentAlignment = Alignment.Center) {
            Text("Cannot display this PDF: " + state.message.take(120), color = MaterialTheme.colorScheme.onSurface)
        }
        is PdfLoad.Ready -> PdfPages(state.doc, backdrop, modifier)
    }
}

@Composable
private fun PdfPages(doc: PdfDoc, backdrop: Color, modifier: Modifier) {
    BoxWithConstraints(modifier.fillMaxSize().background(backdrop)) {
        val viewWidthPx = constraints.maxWidth
        val density = LocalDensity.current
        var scale by remember { mutableFloatStateOf(1f) }
        // Pages are redrawn at this scale only after the fingers pause; until then the
        // bitmap already on screen is stretched, so pinching stays smooth.
        var renderScale by remember { mutableFloatStateOf(1f) }
        LaunchedEffect(scale) {
            delay(250)
            renderScale = scale
        }

        Box(
            Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    awaitEachGesture {
                        awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                        do {
                            val event = awaitPointerEvent(PointerEventPass.Initial)
                            if (event.changes.count { it.pressed } >= 2) {
                                val zoom = event.calculateZoom()
                                if (zoom != 1f) scale = (scale * zoom).coerceIn(1f, MAX_ZOOM)
                                // Two fingers belong to the pinch, not to the scrolling lists below.
                                event.changes.forEach { it.consume() }
                            }
                        } while (event.changes.any { it.pressed })
                    }
                }
                .horizontalScroll(rememberScrollState()),
        ) {
            LazyColumn(
                Modifier.width(with(density) { (viewWidthPx * scale).toDp() }),
                contentPadding = PaddingValues(vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(count = doc.pageCount, key = { it }) { index ->
                    val (pw, ph) = doc.sizes[index]
                    val renderWidth = (viewWidthPx * renderScale).toInt().coerceIn(200, MAX_RENDER_WIDTH)
                    // The previous bitmap stays until the sharper one is ready.
                    val bitmap by produceState<ImageBitmap?>(null, doc, index, renderWidth) {
                        doc.render(index, renderWidth)?.let { value = it.asImageBitmap() }
                    }
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp)
                            .aspectRatio(pw.toFloat() / ph)
                            .background(Color.White),
                    ) {
                        bitmap?.let {
                            Image(it, "Page ${index + 1}", Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
                        }
                    }
                }
            }
        }
    }
}

private const val MAX_ZOOM = 5f
private const val MAX_RENDER_WIDTH = 3000
