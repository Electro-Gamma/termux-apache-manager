package app.terminalssh.secure.ui

import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.isImeVisible
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import kotlinx.coroutines.delay
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.key
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.unit.sp
import app.terminalssh.secure.settings.SettingsRegistry
import app.terminalssh.secure.ui.theme.terminalPalette
import app.terminalssh.secure.ui.theme.Danger
import app.terminalssh.secure.R
import app.terminalssh.secure.ssh.SshSession
import app.terminalssh.secure.ssh.SshSessionState
import app.terminalssh.secure.ui.theme.Stroke
import app.terminalssh.secure.ui.theme.TextSecondary
import app.terminalssh.secure.ui.theme.Turquoise
import app.terminalssh.secure.vm.AppViewModel
import kotlinx.coroutines.launch
import org.connectbot.terminal.Terminal

@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
fun TerminalScreen(viewModel: AppViewModel, onGoToHosts: () -> Unit) {
    val sessions by viewModel.sessions.sessions.collectAsStateWithLifecycle()
    val activeId by viewModel.sessions.activeId.collectAsStateWithLifecycle()
    val active = sessions.firstOrNull { it.id == activeId }

    if (active == null) {
        Column(
            Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(stringResource(R.string.hosts_empty_title), style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(12.dp))
            Text(
                stringResource(R.string.hosts_empty_body),
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
            )
            Spacer(Modifier.height(16.dp))
            Text(
                stringResource(R.string.tab_hosts),
                color = Turquoise,
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    .clickable(onClick = onGoToHosts)
                    .padding(horizontal = 24.dp, vertical = 12.dp),
            )
        }
        return
    }

    var snippetsOpen by remember(active.id) { mutableStateOf(false) }
    val terminalFocusRequester = remember(active.id) { FocusRequester() }

    // Everything the user chose in Settings that shapes this screen. Reading the store's
    // revision means a change made in Settings is picked up here without a restart.
    val store = viewModel.settingsStore
    val settingsRevision by store.revision.collectAsStateWithLifecycle()
    val palette = remember(settingsRevision) { terminalPalette(store.get(SettingsRegistry.theme)) }
    val fontFamilyName = remember(settingsRevision) { store.get(SettingsRegistry.fontFamily) }
    val typeface = remember(fontFamilyName) { TerminalFonts.typeface(fontFamilyName) }
    val baseFontSp = remember(settingsRevision) { store.get(SettingsRegistry.fontSize).toFloat() }
    val keyHaptics = remember(settingsRevision) { store.get(SettingsRegistry.hapticKeys) }
    val keepScreenOn = remember(settingsRevision) { store.get(SettingsRegistry.keepScreenOn) }
    val cursorStyle = remember(settingsRevision) { store.get(SettingsRegistry.cursorStyle) }
    val cursorBlink = remember(settingsRevision) { store.get(SettingsRegistry.cursorBlink) }
    val confirmCloseRunning = remember(settingsRevision) { store.get(SettingsRegistry.confirmCloseRunning) }
    var confirmCloseId by remember { mutableStateOf<String?>(null) }

    // One zoom for every session, remembered across launches. Pinch and the A-/A+ keys
    // both write through applyZoom, so they cannot disagree.
    var zoom by remember { mutableFloatStateOf(viewModel.settings.terminalZoom) }
    var pendingPinch by remember { mutableFloatStateOf(1f) }
    var zoomHudTick by remember { mutableIntStateOf(0) }
    var zoomHudVisible by remember { mutableStateOf(false) }
    val applyZoom: (Float) -> Unit = { target ->
        val next = TerminalZoom.clamp(target)
        if (next != zoom) {
            zoom = next
            zoomHudTick++
        }
    }
    // The size the user is asking for, and the size the terminal is actually built at. They
    // differ only for a moment while zooming: the terminal component takes its font size
    // when it is created, so a change is shown at once by scaling what is on screen, then
    // committed by rebuilding the terminal at the new size (see the commit effect below).
    val targetSp = baseFontSp * zoom
    var appliedSp by remember { mutableFloatStateOf(targetSp) }
    LaunchedEffect(zoomHudTick) {
        if (zoomHudTick > 0) {
            zoomHudVisible = true
            delay(ZOOM_HUD_MS)
            zoomHudVisible = false
        }
    }
    val keyboardController = LocalSoftwareKeyboardController.current
    val rootView = LocalView.current
    val keyboardScope = rememberCoroutineScope()

    // "Keep the screen on", only while this session is actually connected.
    val sessionState by active.state.collectAsStateWithLifecycle()
    DisposableEffect(keepScreenOn, sessionState.isLive) {
        rootView.keepScreenOn = keepScreenOn && sessionState.isLive
        onDispose { rootView.keepScreenOn = false }
    }

    val showKeyboard = {
        keyboardScope.launch {
            terminalFocusRequester.requestFocus()
            // Terminal is a custom editor. Let focus publish its input connection before
            // asking the IME to attach, otherwise rapid dismiss/reopen taps can be ignored.
            withFrameNanos { }
            // The actual input connection belongs to termlib's embedded Android View, not
            // the surrounding Compose focus node. Target it directly when available.
            val imeView = rootView.findTerminalInputView()
            if (imeView != null) {
                imeView.requestFocus()
                val inputMethodManager = imeView.context
                    .getSystemService(InputMethodManager::class.java)
                inputMethodManager.showSoftInput(imeView, InputMethodManager.SHOW_IMPLICIT)
            } else {
                keyboardController?.show()
            }
        }
        Unit
    }

    // Commit a zoom change: after the fingers pause (or a button is tapped), rebuild the
    // terminal at the new size. The shell is told the new grid by the terminal itself, and
    // the emulator keeps the whole screen and scrollback, so nothing is lost. If the
    // keyboard was up it is brought back, since rebuilding the terminal drops its focus.
    val imeVisibleNow by rememberUpdatedState(WindowInsets.isImeVisible)
    LaunchedEffect(targetSp) {
        if (targetSp == appliedSp) return@LaunchedEffect
        delay(ZOOM_COMMIT_MS)
        val keyboardWasUp = imeVisibleNow
        appliedSp = targetSp
        if (keyboardWasUp) {
            delay(150)
            showKeyboard()
        }
    }

    // Cursor shape and blink, sent to the session whenever the setting or the session changes.
    LaunchedEffect(active.id, cursorStyle, cursorBlink) {
        active.applyCursorStyle(cursorStyle, cursorBlink)
    }

    // No imePadding here: RootScreen's dock already reserves max(tab bar, keyboard) below
    // this screen, so the toolbar sits flush on the tab bar or on the keyboard. Padding for
    // the keyboard here as well is what used to double-count it and leave a tall empty
    // strip for about a second after the terminal opened.
    Column(Modifier.fillMaxSize()) {
        SessionTabs(
            sessions = sessions,
            activeId = activeId,
            onSelect = viewModel.sessions::select,
            onClose = { id ->
                val target = sessions.firstOrNull { it.id == id }
                // Closing ends whatever is running in it, so a live session asks first
                // (unless the user turned that off); a dead one just goes.
                if (confirmCloseRunning && target != null && target.state.value.isLive) {
                    confirmCloseId = id
                } else {
                    viewModel.closeSession(id)
                }
            },
        )
        StatusBar(active)
        confirmCloseId?.let { id ->
            AlertDialog(
                onDismissRequest = { confirmCloseId = null },
                title = { Text(stringResource(R.string.terminal_close_confirm_title)) },
                text = { Text(stringResource(R.string.terminal_close_confirm_body)) },
                confirmButton = {
                    TextButton(onClick = {
                        confirmCloseId = null
                        viewModel.closeSession(id)
                    }) { Text(stringResource(R.string.terminal_close_confirm_action), color = Danger) }
                },
                dismissButton = {
                    TextButton(onClick = { confirmCloseId = null }) { Text(stringResource(R.string.cancel)) }
                },
                containerColor = MaterialTheme.colorScheme.surface,
            )
        }
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(palette.background)
                .clipToBounds()
                .pinchToZoom(
                    onZoomBy = { factor ->
                        val (nextZoom, remainder) = TerminalZoom.applyPinch(zoom, pendingPinch, factor)
                        pendingPinch = remainder
                        applyZoom(nextZoom)
                    },
                    onEnd = {
                        pendingPinch = 1f
                        viewModel.settings.terminalZoom = zoom
                    },
                ),
        ) {
            // While the size is catching up, what is already drawn is simply scaled, so the
            // text follows the fingers at once. key() then rebuilds the terminal at the
            // committed size, which is what makes the grid and the shell's idea of the
            // window size match the new text.
            Box(
                Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        val preview = targetSp / appliedSp
                        scaleX = preview
                        scaleY = preview
                        transformOrigin = TransformOrigin(0f, 0f)
                    },
            ) {
                key(appliedSp, fontFamilyName, palette) {
                    Terminal(
                        terminalEmulator = active.emulator,
                        typeface = typeface,
                        initialFontSize = appliedSp.sp,
                        minFontSize = MIN_FONT_SP.sp,
                        maxFontSize = MAX_FONT_SP.sp,
                        backgroundColor = palette.background,
                        foregroundColor = palette.foreground,
                        keyboardEnabled = true,
                        showSoftKeyboard = true,
                        focusRequester = terminalFocusRequester,
                        onPasteRequest = { active.requestPaste() },
                    )
                }
            }
            // Faded with a plain alpha rather than AnimatedVisibility: this Box sits inside a
            // Column, and the compiler will not let an AnimatedVisibility here borrow the
            // Column's scope.
            val zoomHudAlpha by animateFloatAsState(
                if (zoomHudVisible) 1f else 0f,
                Motion.normal(),
                label = "zoom-hud",
            )
            if (zoomHudAlpha > 0f) {
                Box(
                    Modifier
                        .align(Alignment.TopEnd)
                        .padding(12.dp)
                        .graphicsLayer { alpha = zoomHudAlpha },
                ) {
                    ZoomHud(
                        zoom = zoom,
                        onZoomOut = { applyZoom(TerminalZoom.step(zoom, -1)); viewModel.settings.terminalZoom = zoom },
                        onZoomIn = { applyZoom(TerminalZoom.step(zoom, +1)); viewModel.settings.terminalZoom = zoom },
                        onReset = { applyZoom(TerminalZoom.DEFAULT); viewModel.settings.terminalZoom = zoom },
                    )
                }
            }
        }
        CompositionLocalProvider(LocalKeyHaptics provides keyHaptics) {
        KeyToolbar(
            active,
            onZoomOut = { applyZoom(TerminalZoom.step(zoom, -1)); viewModel.settings.terminalZoom = zoom },
            onZoomIn = { applyZoom(TerminalZoom.step(zoom, +1)); viewModel.settings.terminalZoom = zoom },
            onShowKeyboard = showKeyboard,
            onSnippets = { snippetsOpen = true },
        )
        }
        PasteAndHostKeyDialogs(viewModel, active)
        if (snippetsOpen) {
            val snippets by viewModel.snippets.collectAsStateWithLifecycle()
            SnippetSheet(
                snippets = snippets,
                onDismiss = { snippetsOpen = false },
                onSave = viewModel::saveSnippet,
                onInsert = { entry ->
                    viewModel.insertSnippet(entry, active)
                    snippetsOpen = false
                },
                onDelete = viewModel::deleteSnippet,
            )
        }
    }
}

private fun View.findTerminalInputView(): View? {
    // ImeInputView is an internal Kotlin type in termlib, so identify the embedded text
    // editor without reflecting into its implementation.
    if (javaClass.name == TERMINAL_IME_VIEW_CLASS) return this
    if (this !is ViewGroup) return null
    for (index in 0 until childCount) {
        getChildAt(index).findTerminalInputView()?.let { return it }
    }
    return null
}

private const val TERMINAL_IME_VIEW_CLASS = "org.connectbot.terminal.ImeInputView"

@Composable
private fun SessionTabs(
    sessions: List<SshSession>,
    activeId: String?,
    onSelect: (String) -> Unit,
    onClose: (String) -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        sessions.forEach { session ->
            val selected = session.id == activeId
            val state by session.state.collectAsStateWithLifecycle()
            val closeDescription = stringResource(R.string.close_session, session.title)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        if (selected) MaterialTheme.colorScheme.surfaceVariant
                        else MaterialTheme.colorScheme.surface,
                    )
                    .border(1.dp, if (selected) Turquoise.copy(alpha = 0.4f) else Stroke, RoundedCornerShape(12.dp))
                    .selectable(
                        selected = selected,
                        role = Role.Tab,
                        onClick = { onSelect(session.id) },
                    )
                    .padding(start = 12.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
            ) {
                StatusDot(state)
                Spacer(Modifier.width(8.dp))
                Text(session.title, style = MaterialTheme.typography.labelLarge)
                Icon(
                    Icons.Outlined.Close,
                    contentDescription = closeDescription,
                    tint = TextSecondary,
                    modifier = Modifier
                        .size(48.dp)
                        .clickable { onClose(session.id) }
                        .padding(12.dp),
                )
            }
        }
    }
}

@Composable
private fun StatusDot(state: SshSessionState) {
    // Shared with the host list rather than restated here: the two screens had already
    // drifted apart on what colour a connecting session is.
    val color by animateColorAsState(state.status().color, label = "status")

    // While a connection is being established the dot pulses, so "working" is readable
    // at a glance without occupying any more space than the idle indicator. Everything
    // else is a steady dot: motion here would mean nothing and cost battery.
    val busy = state.isBusy
    val transition = rememberInfiniteTransition(label = "status-pulse")
    val pulse by transition.animateFloat(
        initialValue = 1f,
        targetValue = if (busy) 1.55f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(760, easing = Motion.Standard),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "status-pulse-scale",
    )

    Box(Modifier.size(16.dp), contentAlignment = Alignment.Center) {
        if (busy) {
            Box(
                Modifier
                    .size(8.dp)
                    .graphicsLayer {
                        scaleX = pulse
                        scaleY = pulse
                        alpha = (1.6f - pulse).coerceIn(0f, 1f)
                    }
                    .clip(CircleShape)
                    .background(color),
            )
        }
        Box(Modifier.size(8.dp).clip(CircleShape).background(color))
    }
}

@Composable
private fun StatusBar(session: SshSession) {
    val state by session.state.collectAsStateWithLifecycle()
    val text = when (val s = state) {
        SshSessionState.Idle -> stringResource(R.string.state_idle)
        SshSessionState.Connecting -> stringResource(R.string.state_connecting)
        is SshSessionState.AwaitingHostKeyApproval -> stringResource(R.string.state_verifying)
        SshSessionState.Connected -> stringResource(R.string.state_connected)
        is SshSessionState.Reconnecting -> stringResource(R.string.state_reconnecting) + " ${s.attempt}/${s.max}"
        is SshSessionState.Failed -> stringResource(s.kind.stringRes)
        SshSessionState.Closed -> stringResource(R.string.state_disconnected)
    }
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
    ) {
        StatusDot(state)
        Spacer(Modifier.width(8.dp))
        Text(text, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        Spacer(Modifier.weight(1f))
        Text(
            ltr(session.profile.subtitle),
            style = MaterialTheme.typography.labelSmall,
            color = TextSecondary,
            fontFamily = FontFamily.Monospace,
        )
    }
}

/**
 * The single most important mobile-SSH affordance: keys a soft keyboard does not have.
 * Ctrl and Alt latch for exactly one following keystroke, like a real terminal.
 */
@Composable
private fun KeyToolbar(
    session: SshSession,
    onZoomOut: () -> Unit,
    onZoomIn: () -> Unit,
    onShowKeyboard: () -> Unit,
    onSnippets: () -> Unit,
) {
    var ctrl by remember { mutableStateOf(false) }
    var alt by remember { mutableStateOf(false) }

    fun sendText(text: String) {
        when {
            ctrl && text.length == 1 -> {
                val code = text.uppercase()[0].code - 64
                if (code in 1..31) session.send(byteArrayOf(code.toByte()))
                ctrl = false
            }
            alt && text.length == 1 -> {
                session.send(byteArrayOf(0x1B) + text.encodeToByteArray())
                alt = false
            }
            else -> session.send(text)
        }
    }

    // Keys are ordered by how often they are actually reached for, because on a narrow
    // phone everything past the first handful costs a scroll. Arrows stay adjacent so the
    // cluster is findable by shape rather than by reading each label.
    BoxWithConstraints(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface)) {
        // A 600dp-wide window (large phone landscape, tablet, unfolded foldable) has room
        // for two rows, which removes the scroll entirely on those devices.
        val twoRows = maxWidth >= 600.dp

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            ToolKey(
                label = "⌨",
                contentDescription = stringResource(R.string.show_keyboard),
                onClick = onShowKeyboard,
            )

            val primary: @Composable () -> Unit = {
                ToolKey(stringResource(R.string.snippets_short)) { onSnippets() }
                ToolKey("Esc") { session.send(byteArrayOf(0x1B)) }
                ToolKey("Tab") { session.send(byteArrayOf(0x09)) }
                ToolKey("Ctrl", active = ctrl, toggle = true) { ctrl = !ctrl; alt = false }
                ToolKey("Alt", active = alt, toggle = true) { alt = !alt; ctrl = false }
                ToolKey("^C", contentDescription = stringResource(R.string.terminal_key_interrupt)) {
                    session.send(byteArrayOf(0x03)); ctrl = false
                }
                ToolKey("^D", contentDescription = stringResource(R.string.terminal_key_eof)) {
                    session.send(byteArrayOf(0x04)); ctrl = false
                }
                ToolKey("^L", contentDescription = stringResource(R.string.terminal_key_clear)) {
                    session.send(byteArrayOf(0x0C)); ctrl = false
                }
                ToolKey("↑", contentDescription = stringResource(R.string.terminal_key_up)) { session.send("\u001B[A") }
                ToolKey("↓", contentDescription = stringResource(R.string.terminal_key_down)) { session.send("\u001B[B") }
                ToolKey("←", contentDescription = stringResource(R.string.terminal_key_left)) { session.send("\u001B[D") }
                ToolKey("→", contentDescription = stringResource(R.string.terminal_key_right)) { session.send("\u001B[C") }
            }

            val secondary: @Composable () -> Unit = {
                ToolKey("A−", contentDescription = stringResource(R.string.terminal_zoom_out)) { onZoomOut() }
                ToolKey("A+", contentDescription = stringResource(R.string.terminal_zoom_in)) { onZoomIn() }
                ToolKey("|") { sendText("|") }
                ToolKey("/") { sendText("/") }
                ToolKey("-") { sendText("-") }
                ToolKey("~") { sendText("~") }
                ToolKey("Home") { session.send("\u001B[H") }
                ToolKey("End") { session.send("\u001B[F") }
                ToolKey("PgUp") { session.send("\u001B[5~") }
                ToolKey("PgDn") { session.send("\u001B[6~") }
            }

            if (twoRows) {
                Column(
                    Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { primary() }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { secondary() }
                }
            } else {
                Row(
                    Modifier.weight(1f).horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    primary()
                    secondary()
                }
            }
        }
    }
}

@Composable
private fun ToolKey(
    label: String,
    active: Boolean = false,
    toggle: Boolean = false,
    contentDescription: String? = null,
    onClick: () -> Unit,
) {
    val haptics = LocalHapticFeedback.current
    val hapticsEnabled = LocalKeyHaptics.current
    val interactions = remember { MutableInteractionSource() }
    val isPressed by interactions.collectIsPressedAsState()
    // A physical key gives travel; a glass one has to give something back instead.
    val scale by animateFloatAsState(if (isPressed) 0.92f else 1f, Motion.press(), label = "key-press")

    val press: () -> Unit = {
        if (hapticsEnabled) haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        onClick()
    }

    Text(
        label,
        style = MaterialTheme.typography.labelLarge,
        color = if (active) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
        modifier = Modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(RoundedCornerShape(8.dp))
            .background(if (active) Turquoise else MaterialTheme.colorScheme.surfaceVariant)
            .then(
                if (contentDescription != null) Modifier.semantics {
                    this.contentDescription = contentDescription
                } else Modifier,
            )
            .then(
                if (toggle) Modifier.toggleable(
                    value = active,
                    interactionSource = interactions,
                    indication = null,
                    role = Role.Button,
                    onValueChange = { press() },
                ) else Modifier.clickable(
                    interactionSource = interactions,
                    indication = null,
                    onClick = press,
                ),
            )
            .defaultMinSize(minWidth = 48.dp, minHeight = 48.dp)
            .padding(horizontal = 12.dp, vertical = 8.dp),
    )
}

private const val ZOOM_HUD_MS = 2_200L

/** How long the fingers must pause before the zoom is committed by rebuilding the terminal. */
private const val ZOOM_COMMIT_MS = 160L

/** Bounds handed to the terminal component; the zoom range and font setting stay well inside them. */
private const val MIN_FONT_SP = 4f
private const val MAX_FONT_SP = 96f

/** Whether the special-key bar gives haptic feedback (the Vibrate on key press setting). */
private val LocalKeyHaptics = compositionLocalOf { true }

/**
 * Appears while zooming: shows the current size and offers the same steps as the toolbar
 * keys, with the percentage doubling as "back to 100%". Fades on its own so it never sits
 * over the output.
 */
@Composable
private fun ZoomHud(zoom: Float, onZoomOut: () -> Unit, onZoomIn: () -> Unit, onReset: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(RoundedCornerShape(24.dp))
            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.94f))
            .border(1.dp, Stroke, RoundedCornerShape(24.dp))
            .padding(horizontal = 4.dp),
    ) {
        val zoomOutDescription = stringResource(R.string.terminal_zoom_out)
        val zoomInDescription = stringResource(R.string.terminal_zoom_in)
        Text(
            "A−",
            style = MaterialTheme.typography.labelLarge,
            modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .semantics { contentDescription = zoomOutDescription }
                .clickable(onClick = onZoomOut)
                .defaultMinSize(minWidth = 48.dp, minHeight = 48.dp)
                .padding(horizontal = 12.dp, vertical = 12.dp),
        )
        val resetDescription = stringResource(R.string.terminal_zoom_reset)
        Text(
            "${TerminalZoom.percent(zoom)}%",
            style = MaterialTheme.typography.labelLarge,
            color = Turquoise,
            modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .semantics { contentDescription = resetDescription }
                .clickable(onClick = onReset)
                .defaultMinSize(minHeight = 48.dp)
                .padding(horizontal = 8.dp, vertical = 12.dp),
        )
        Text(
            "A+",
            style = MaterialTheme.typography.labelLarge,
            modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .semantics { contentDescription = zoomInDescription }
                .clickable(onClick = onZoomIn)
                .defaultMinSize(minWidth = 48.dp, minHeight = 48.dp)
                .padding(horizontal = 12.dp, vertical = 12.dp),
        )
    }
}
