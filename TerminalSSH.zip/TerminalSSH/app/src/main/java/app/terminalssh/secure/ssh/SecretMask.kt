package app.terminalssh.secure.ssh

/**
 * Hides API keys and tokens in terminal output.
 *
 * Replacement keeps every byte's position (each masked character becomes one `*`), so the
 * screen layout, cursor column and line wrapping are exactly what the program intended; only
 * the secret itself is gone. Bytes are treated as Latin-1, which maps one byte to one
 * character, so multi-byte UTF-8 text passes through untouched.
 *
 * It works on one chunk at a time: a token split across two network reads can slip through.
 * That is a deliberate trade against holding output back to wait for more, which would make
 * prompts and keystrokes feel laggy.
 */
object SecretMask {
    private const val MASK = '*'.code.toByte()
    private const val MIN_TOKEN_LENGTH = 20

    // Each token is only recognised when it starts at a word edge, so ordinary text that
    // happens to end in the same letters ("task-runner-configuration") is left alone.
    private const val EDGE = "(?<![A-Za-z0-9_])"

    private val tokens = listOf(
        Regex("${EDGE}AKIA[0-9A-Z]{16}"),
        Regex("${EDGE}gh[pousr]_[A-Za-z0-9]{36,}"),
        Regex("${EDGE}github_pat_[A-Za-z0-9_]{22,}"),
        Regex("${EDGE}xox[baprs]-[A-Za-z0-9-]{10,}"),
        Regex("${EDGE}sk-[A-Za-z0-9_-]{20,}"),
        Regex("${EDGE}AIza[0-9A-Za-z_-]{35}"),
        Regex("${EDGE}eyJ[A-Za-z0-9_-]{10,}\\.[A-Za-z0-9_-]{10,}\\.[A-Za-z0-9_-]{10,}"),
    )

    /** `Authorization: Bearer <token>`: the word stays readable, the token goes. */
    private val bearer = Regex("(?i)(bearer\\s+)([A-Za-z0-9._~+/=-]{20,})")

    /** Masks secrets in the first [length] bytes of [buffer], in place. Returns true if anything changed. */
    fun maskInPlace(buffer: ByteArray, length: Int): Boolean {
        if (length < MIN_TOKEN_LENGTH) return false
        val text = String(buffer, 0, length, Charsets.ISO_8859_1)
        var changed = false
        for (pattern in tokens) {
            for (match in pattern.findAll(text)) {
                buffer.fill(MASK, match.range.first, match.range.last + 1)
                changed = true
            }
        }
        for (match in bearer.findAll(text)) {
            val secret = match.groups[2] ?: continue
            buffer.fill(MASK, secret.range.first, secret.range.last + 1)
            changed = true
        }
        return changed
    }
}
