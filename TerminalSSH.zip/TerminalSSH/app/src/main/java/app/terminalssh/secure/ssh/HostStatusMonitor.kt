package app.terminalssh.secure.ssh

import android.os.SystemClock
import app.terminalssh.secure.model.HostProfile
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket

/** Whether a configured server answered on its SSH port the last time we asked. */
enum class Reachability { UNKNOWN, CHECKING, ONLINE, OFFLINE }

/**
 * Checks which of the user's servers are reachable.
 *
 * "Online" means the server accepted a TCP connection on its SSH port. That is cheap,
 * needs no credentials, never opens a login attempt (so nothing shows up in the server's
 * auth log) and answers the question the user actually has: can I get to this machine
 * right now? It says nothing about whether the password is right.
 *
 * Probes run a few at a time so a long host list does not open dozens of sockets at once.
 * Lives in the Application, so results survive screen changes.
 */
class HostStatusMonitor(
    private val scope: CoroutineScope,
    private val probe: suspend (HostProfile) -> Boolean = { profile -> HostStatusMonitor.tcpProbe(profile) },
) {
    private val _status = MutableStateFlow<Map<String, Reachability>>(emptyMap())
    val status: StateFlow<Map<String, Reachability>> = _status.asStateFlow()

    private val gate = Semaphore(MAX_PARALLEL_PROBES)
    private val inFlight = HashMap<String, Job>()
    private var lastFullCheckAt = 0L

    /**
     * Checks every host. Called each time the app comes to the foreground; a second call
     * within [MIN_INTERVAL_MS] (a permission dialog, a quick app switch) is ignored unless
     * [force] is set, which is what an explicit refresh uses.
     */
    fun checkAll(hosts: List<HostProfile>, force: Boolean = false) {
        val now = SystemClock.elapsedRealtime()
        if (!force && lastFullCheckAt != 0L && now - lastFullCheckAt < MIN_INTERVAL_MS) return
        lastFullCheckAt = now
        val ids = hosts.mapTo(HashSet<String>()) { it.id }
        // Forget hosts that were deleted.
        _status.update { current -> current.filterKeys { it in ids } }
        hosts.forEach { check(it) }
    }

    /** Checks hosts that have no result yet, such as one the user just added. */
    fun checkMissing(hosts: List<HostProfile>) {
        val known = _status.value
        hosts.filter { it.id !in known }.forEach { check(it) }
    }

    fun check(profile: HostProfile) {
        if (inFlight[profile.id]?.isActive == true) return
        setStatus(profile.id, Reachability.CHECKING)
        inFlight[profile.id] = scope.launch {
            val online = gate.withPermit { withContext(Dispatchers.IO) { runCatching { probe(profile) }.getOrDefault(false) } }
            setStatus(profile.id, if (online) Reachability.ONLINE else Reachability.OFFLINE)
        }
    }

    private fun setStatus(id: String, value: Reachability) {
        _status.update { it + (id to value) }
    }

    companion object {
        const val MAX_PARALLEL_PROBES = 6
        const val CONNECT_TIMEOUT_MS = 4_000
        const val MIN_INTERVAL_MS = 10_000L

        /** True when [profile]'s host accepts a TCP connection on its port within the timeout. */
        suspend fun tcpProbe(profile: HostProfile): Boolean = withContext(Dispatchers.IO) {
            try {
                Socket().use { socket ->
                    socket.connect(InetSocketAddress(profile.host, profile.port), CONNECT_TIMEOUT_MS)
                    true
                }
            } catch (_: Exception) {
                false
            }
        }
    }
}
