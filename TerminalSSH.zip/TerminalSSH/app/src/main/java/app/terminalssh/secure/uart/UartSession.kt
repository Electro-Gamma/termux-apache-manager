package app.terminalssh.secure.uart

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import app.terminalssh.secure.ssh.ConnectionErrorKind
import app.terminalssh.secure.ssh.SshSessionState
import app.terminalssh.secure.ssh.TerminalSession
import app.terminalssh.secure.ui.theme.TerminalPalette
import com.hoho.android.usbserial.driver.UsbSerialDriver
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.connectbot.terminal.TerminalEmulator
import org.connectbot.terminal.TerminalEmulatorFactory
import java.util.concurrent.Executors

/**
 * One UART serial console on a USB-to-UART adapter, shown in the same terminal as an SSH shell.
 *
 * It is the serial counterpart of [app.terminalssh.secure.ssh.SshSession]: the same emulator and
 * the same threading rules (port I/O on [io], emulator changes on the main thread), but the
 * transport is a [SerialPortController] instead of an SSH channel. Differences that come from
 * the medium rather than from this code:
 *  - there is no local echo; the far end (getty, bash) echoes what you type;
 *  - there is no way to tell the far end the window size on a plain UART, so a resize only
 *    changes the local screen (`stty rows R cols C` on the board fixes wrapping);
 *  - the cable can be pulled, so detach is a normal event, and plugging the adapter back in
 *    reconnects by itself.
 */
class UartSession(
    override val id: String,
    @Volatile var profile: UartProfile,
    private val usb: UsbSerialManager,
    scope: CoroutineScope,
    private val onClipboardCopy: (String) -> Unit,
    private val onPasteRequest: () -> Unit,
    private val onBell: () -> Unit = {},
    defaultForeground: Color = Color.White,
    defaultBackground: Color = Color.Black,
) : TerminalSession {
    private val io = Executors.newSingleThreadExecutor { r -> Thread(r, "uart-io-$id") }
    private val main = Handler(Looper.getMainLooper())

    private val _state = MutableStateFlow<SshSessionState>(SshSessionState.Idle)
    override val state: StateFlow<SshSessionState> = _state.asStateFlow()

    private val port = SerialPortController()

    /** The adapter this session has open, and the one it is waiting for permission on. */
    @Volatile private var openDeviceId: Int? = null
    @Volatile private var permissionDeviceId: Int? = null

    /** Set when the cable was pulled: plugging a matching adapter back in then reconnects. */
    @Volatile private var reconnectOnAttach = false
    @Volatile private var destroyed = false

    override val emulator: TerminalEmulator = TerminalEmulatorFactory.create(
        initialRows = INITIAL_ROWS,
        initialCols = INITIAL_COLS,
        defaultForeground = defaultForeground,
        defaultBackground = defaultBackground,
        onKeyboardInput = { bytes -> sendKey(bytes) },
        onBell = { onBell() },
        // Nothing to tell: a serial line has no side channel for the window size.
        onResize = { _ -> },
        onClipboardCopy = onClipboardCopy,
    )

    override val hostId: String get() = profile.id
    override val title: String get() = profile.displayName
    override val subtitle: String get() = profile.subtitle

    /** A serial console is meant to sit idle, and its cable is not something to reopen blindly at launch. */
    override val lastActivityAt: Long get() = SystemClock.elapsedRealtime()
    override val restorable: Boolean get() = false

    private val events: Job = scope.launch {
        usb.events.collect { event -> onUsbEvent(event) }
    }

    init {
        port.onDataReceived = { bytes -> onSerialData(bytes) }
        port.onError = { e -> onSerialError(e) }
    }

    // ---- connecting ----

    fun connect() {
        if (destroyed) return
        reconnectOnAttach = false
        _state.value = SshSessionState.Connecting
        if (!usb.isUsbHostSupported()) return fail(ConnectionErrorKind.USB_UNSUPPORTED)
        val driver = pickDriver() ?: return fail(ConnectionErrorKind.USB_NO_DEVICE)
        if (!usb.hasPermission(driver.device)) {
            permissionDeviceId = driver.device.deviceId
            usb.requestPermission(driver.device) // the answer arrives as a PermissionResult event
            return
        }
        open(driver)
    }

    /** The adapter this profile names, or the first one plugged in when it names none. */
    private fun pickDriver(): UsbSerialDriver? {
        val drivers = usb.listDrivers()
        val p = profile
        return drivers.firstOrNull { p.matches(it.device.vendorId, it.device.productId) }
    }

    private fun open(driver: UsbSerialDriver) {
        _state.value = SshSessionState.Connecting
        io.execute {
            if (destroyed) return@execute
            val connection = usb.openConnection(driver.device)
            if (connection == null) {
                fail(ConnectionErrorKind.USB_OPEN_FAILED)
                return@execute
            }
            try {
                port.open(driver, connection, profile.settings)
                openDeviceId = driver.device.deviceId
                main.post {
                    // Reset any colour left over from before, so the first prompt starts clean.
                    runCatching { emulator.writeInput("\u001b[0m".encodeToByteArray(), 0, 4) }
                }
                _state.value = SshSessionState.Connected
            } catch (e: Exception) {
                runCatching { connection.close() }
                fail(ConnectionErrorKind.USB_OPEN_FAILED, e.message)
            }
        }
    }

    private fun fail(kind: ConnectionErrorKind, message: String? = null) {
        _state.value = SshSessionState.Failed(message ?: kind.name, kind = kind)
    }

    private fun onUsbEvent(event: UsbEvent) {
        if (destroyed) return
        when (event) {
            is UsbEvent.PermissionResult -> {
                if (event.device.deviceId != permissionDeviceId) return
                permissionDeviceId = null
                if (!event.granted) return fail(ConnectionErrorKind.USB_PERMISSION_DENIED)
                val driver = usb.listDrivers().firstOrNull { it.device.deviceId == event.device.deviceId }
                if (driver == null) fail(ConnectionErrorKind.USB_NO_DEVICE) else open(driver)
            }
            is UsbEvent.Detached -> {
                if (event.device.deviceId == openDeviceId) {
                    // The cable was pulled: drop the port, say so, and wait for it to come back.
                    openDeviceId = null
                    io.execute { port.close() }
                    reconnectOnAttach = true
                    fail(ConnectionErrorKind.USB_DISCONNECTED)
                } else if (event.device.deviceId == permissionDeviceId) {
                    permissionDeviceId = null
                    fail(ConnectionErrorKind.USB_NO_DEVICE)
                }
            }
            is UsbEvent.Attached -> {
                val d = event.device
                if (reconnectOnAttach && profile.matches(d.vendorId, d.productId)) connect()
            }
        }
    }

    // ---- data ----

    /** Called on the serial read thread; the emulator is only ever touched on the main thread. */
    private fun onSerialData(bytes: ByteArray) {
        main.post {
            if (!destroyed) runCatching { emulator.writeInput(bytes, 0, bytes.size) }
        }
    }

    private fun onSerialError(e: Exception) {
        if (destroyed || _state.value !is SshSessionState.Connected) return
        openDeviceId = null
        io.execute { port.close() }
        reconnectOnAttach = true
        fail(ConnectionErrorKind.USB_DISCONNECTED, e.message)
    }

    override fun send(bytes: ByteArray) {
        if (_state.value !is SshSessionState.Connected) return
        val copy = bytes.copyOf()
        io.execute { port.write(copy) }
    }

    override fun send(text: String) = send(text.encodeToByteArray())

    // ---- Ctrl / Alt latches, identical to the SSH terminal ----

    private val _ctrlLatched = MutableStateFlow(false)
    override val ctrlLatched: StateFlow<Boolean> = _ctrlLatched.asStateFlow()
    private val _altLatched = MutableStateFlow(false)
    override val altLatched: StateFlow<Boolean> = _altLatched.asStateFlow()

    override fun toggleCtrl() { _ctrlLatched.value = !_ctrlLatched.value; _altLatched.value = false }
    override fun toggleAlt() { _altLatched.value = !_altLatched.value; _ctrlLatched.value = false }

    override fun sendKey(bytes: ByteArray) {
        val ctrl = _ctrlLatched.value
        val alt = _altLatched.value
        if (!ctrl && !alt) return send(bytes)
        _ctrlLatched.value = false
        _altLatched.value = false
        var out = bytes
        if (ctrl && bytes.size == 1) {
            val c = bytes[0].toInt().toChar()
            val code = when (c) {
                in 'a'..'z' -> c - 'a' + 1
                in 'A'..'Z' -> c - 'A' + 1
                '@', ' ' -> 0
                '[' -> 27
                '\\' -> 28
                ']' -> 29
                '^' -> 30
                '_', '/' -> 31
                '?' -> 127
                else -> -1
            }
            if (code >= 0) out = byteArrayOf(code.toByte())
        } else if (alt && bytes.isNotEmpty() && bytes[0] != 0x1B.toByte()) {
            out = byteArrayOf(0x1B) + bytes
        }
        send(out)
    }

    override fun sendKey(text: String) = sendKey(text.encodeToByteArray())

    override fun requestPaste() = onPasteRequest()

    // ---- appearance ----

    override fun applyPalette(palette: TerminalPalette) {
        val ansi = IntArray(16) { palette.ansi[it].toArgb() }
        val fg = palette.foreground.toArgb()
        val bg = palette.background.toArgb()
        main.post {
            runCatching {
                val method = emulator.javaClass.methods.firstOrNull {
                    it.name == "applyColorScheme" && it.parameterTypes.size == 3 &&
                        it.parameterTypes[0] == IntArray::class.java
                } ?: return@runCatching
                method.invoke(emulator, ansi, fg, bg)
            }
        }
    }

    override fun applyCursorStyle(style: String, blink: Boolean) {
        val code = when (style) {
            "bar" -> if (blink) 5 else 6
            "underline" -> if (blink) 3 else 4
            else -> if (blink) 1 else 2
        }
        val bytes = "\u001b[$code q".encodeToByteArray()
        main.post { emulator.writeInput(bytes, 0, bytes.size) }
    }

    override fun clearScreen() { main.post { runCatching { emulator.clearScreen() } } }

    // ---- ending ----

    override fun disconnect() {
        reconnectOnAttach = false
        permissionDeviceId = null
        openDeviceId = null
        _state.value = SshSessionState.Closed
        io.execute { port.close() }
    }

    override fun destroy() {
        if (destroyed) return
        disconnect()
        destroyed = true
        events.cancel()
        io.shutdown()
    }

    private companion object {
        const val INITIAL_ROWS = 24
        const val INITIAL_COLS = 80
    }
}
