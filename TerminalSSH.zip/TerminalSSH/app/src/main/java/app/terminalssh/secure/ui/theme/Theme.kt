package app.terminalssh.secure.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontVariation
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.LineHeightStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.terminalssh.secure.R

// Iranian-premium identity: deep graphite with four accents that each mean one thing.
// Turquoise is the brand and marks what succeeded; cyan means work in progress; amber
// means the app has stopped and is waiting on the user; red means it failed. See
// ConnectionStatus, which is where that mapping is actually enforced.
val Ink = Color(0xFF07090C)
val Surface1 = Color(0xFF101317)
val Surface2 = Color(0xFF171B20)
val Surface3 = Color(0xFF20262D)
val Stroke = Color(0xFF2A3037)
val TextPrimary = Color(0xFFF4F7F8)
val TextSecondary = Color(0xFF9AA4AC)
val Turquoise = Color(0xFF35D7AE)
val Cyan = Color(0xFF5AC8FA)
val Amber = Color(0xFFFFC66D)
val Danger = Color(0xFFFF7082)

private val Scheme = darkColorScheme(
    primary = Turquoise,
    onPrimary = Ink,
    primaryContainer = Color(0xFF0C3A31),
    onPrimaryContainer = Color(0xFFC7FFF0),
    secondary = Cyan,
    onSecondary = Ink,
    secondaryContainer = Color(0xFF12323B),
    onSecondaryContainer = Color(0xFFD4F8FF),
    tertiary = Cyan,
    onTertiary = Ink,
    background = Ink,
    onBackground = TextPrimary,
    surface = Surface1,
    onSurface = TextPrimary,
    surfaceVariant = Surface2,
    onSurfaceVariant = TextSecondary,
    outline = Stroke,
    error = Danger,
    onError = Ink,
)

/**
 * Corner radii on a 4dp grid like everything else. The previous 9/13/18/24/30 were close
 * to these but off the grid, which is invisible on any one component and reads as
 * carelessness once several sit next to each other.
 */
private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp),
)

/**
 * Vazirmatn (SIL OFL 1.1) as a single variable file: one 240 KB asset covers every weight,
 * where four static cuts would cost twice that. Android's default Persian face is a naskh
 * design meant for running text; a UI-proportioned face is what makes Persian labels read
 * as deliberately set rather than defaulted.
 */
@OptIn(ExperimentalTextApi::class)
private fun vazirmatn(weight: FontWeight) = Font(
    R.font.vazirmatn_variable,
    weight = weight,
    variationSettings = FontVariation.Settings(FontVariation.weight(weight.weight)),
)

private val Vazirmatn = FontFamily(
    vazirmatn(FontWeight.Normal),
    vazirmatn(FontWeight.Medium),
    vazirmatn(FontWeight.SemiBold),
    vazirmatn(FontWeight.Bold),
)

/**
 * Persian is a connected script: tracking pulls joined letterforms apart and distorts the
 * measured width of a word, so every style keeps letterSpacing at zero. Line height is
 * trimmed to the text box rather than the font's Latin-first ascent, which otherwise leaves
 * Persian looking top-heavy inside its row.
 */
private val PersianLineHeight = LineHeightStyle(
    alignment = LineHeightStyle.Alignment.Center,
    trim = LineHeightStyle.Trim.None,
)

private fun persian(
    size: Int,
    line: Int,
    weight: FontWeight = FontWeight.Normal,
    color: Color = Color.Unspecified,
) = TextStyle(
    fontFamily = Vazirmatn,
    fontSize = size.sp,
    lineHeight = line.sp,
    fontWeight = weight,
    letterSpacing = 0.sp,
    color = color,
    lineHeightStyle = PersianLineHeight,
    platformStyle = PlatformTextStyle(includeFontPadding = false),
)

/**
 * Every Material 3 style is defined, not just the ones in use today.
 *
 * An undefined style silently falls back to the Material default, which is a Latin-first
 * face with non-zero letterSpacing — the exact thing the note above says breaks a
 * connected script. Two styles were previously left undefined and were rendering Persian
 * in the fallback font, letter-spaced. Filling the whole scale means the next screen that
 * reaches for titleSmall cannot reintroduce that.
 */
private val AppTypography = Typography(
    displayLarge = persian(45, 56, FontWeight.Bold),
    displayMedium = persian(36, 46, FontWeight.Bold),
    displaySmall = persian(32, 41, FontWeight.Bold),

    headlineLarge = persian(34, 45, FontWeight.Bold),
    headlineMedium = persian(29, 42, FontWeight.Bold),
    headlineSmall = persian(24, 34, FontWeight.SemiBold),

    titleLarge = persian(20, 31, FontWeight.SemiBold),
    titleMedium = persian(16, 26, FontWeight.Medium),
    titleSmall = persian(14, 22, FontWeight.SemiBold),

    bodyLarge = persian(16, 27),
    bodyMedium = persian(14, 24),
    bodySmall = persian(12, 20),

    labelLarge = persian(14, 21, FontWeight.Medium),
    labelMedium = persian(12, 18, FontWeight.Medium),
    labelSmall = persian(12, 19, color = TextSecondary),
)

val MonoStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp)

@Composable
fun TerminalTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = Scheme,
        shapes = AppShapes,
        typography = AppTypography,
        content = content,
    )
}

data class TerminalPalette(
    val id: String,
    val label: String,
    val background: Color,
    val foreground: Color,
    val accent: Color,
    /** The 16 ANSI colours: 0-7 normal (black..white), 8-15 bright. */
    val ansi: List<Color> = DefaultAnsi,
)

private fun ansi(vararg rgb: Long): List<Color> = rgb.map { Color(0xFF000000 or it) }

/** A neutral set (the VS Code terminal defaults) for themes that do not define their own. */
private val DefaultAnsi = ansi(
    0x000000, 0xCD3131, 0x0DBC79, 0xE5E510, 0x2472C8, 0xBC3FBC, 0x11A8CD, 0xE5E5E5,
    0x666666, 0xF14C4C, 0x23D18B, 0xF5F543, 0x3B8EEA, 0xD670D6, 0x29B8DB, 0xFFFFFF,
)

val TerminalPalettes = listOf(
    TerminalPalette("persian_neon", "نئون ایرانی", Color(0xFF05080B), Color(0xFFF0F6F8), Turquoise),
    TerminalPalette("oled", "مشکی OLED", Color(0xFF000000), Color(0xFFD6DEE6), Cyan),
    TerminalPalette("midnight", "نیمه‌شب", Color(0xFF09121E), Color(0xFFDCE8F2), Color(0xFF79A7FF)),
    TerminalPalette("solarized", "سولاریزد", Color(0xFF002B36), Color(0xFF93A1A1), Color(0xFFB58900),
        ansi(0x073642, 0xDC322F, 0x859900, 0xB58900, 0x268BD2, 0xD33682, 0x2AA198, 0xEEE8D5,
            0x002B36, 0xCB4B16, 0x586E75, 0x657B83, 0x839496, 0x6C71C4, 0x93A1A1, 0xFDF6E3)),
    TerminalPalette("classic", "سبز کلاسیک", Color(0xFF031008), Color(0xFF58F58A), Color(0xFF58F58A)),
    TerminalPalette("amber", "کهربایی", Color(0xFF100B04), Color(0xFFFFC66D), Amber),
    // Community palettes, using each project's published background, foreground and a
    // representative accent rather than an approximation.
    TerminalPalette("dracula", "Dracula", Color(0xFF282A36), Color(0xFFF8F8F2), Color(0xFFBD93F9),
        ansi(0x21222C, 0xFF5555, 0x50FA7B, 0xF1FA8C, 0xBD93F9, 0xFF79C6, 0x8BE9FD, 0xF8F8F2,
            0x6272A4, 0xFF6E6E, 0x69FF94, 0xFFFFA5, 0xD6ACFF, 0xFF92DF, 0xA4FFFF, 0xFFFFFF)),
    TerminalPalette("nord", "Nord", Color(0xFF2E3440), Color(0xFFD8DEE9), Color(0xFF88C0D0),
        ansi(0x3B4252, 0xBF616A, 0xA3BE8C, 0xEBCB8B, 0x81A1C1, 0xB48EAD, 0x88C0D0, 0xE5E9F0,
            0x4C566A, 0xBF616A, 0xA3BE8C, 0xEBCB8B, 0x81A1C1, 0xB48EAD, 0x8FBCBB, 0xECEFF4)),
    TerminalPalette("gruvbox", "Gruvbox", Color(0xFF282828), Color(0xFFEBDBB2), Color(0xFFFABD2F),
        ansi(0x282828, 0xCC241D, 0x98971A, 0xD79921, 0x458588, 0xB16286, 0x689D6A, 0xA89984,
            0x928374, 0xFB4934, 0xB8BB26, 0xFABD2F, 0x83A598, 0xD3869B, 0x8EC07C, 0xEBDBB2)),
    TerminalPalette("catppuccin", "Catppuccin", Color(0xFF1E1E2E), Color(0xFFCDD6F4), Color(0xFFF5C2E7),
        ansi(0x45475A, 0xF38BA8, 0xA6E3A1, 0xF9E2AF, 0x89B4FA, 0xF5C2E7, 0x94E2D5, 0xBAC2DE,
            0x585B70, 0xF38BA8, 0xA6E3A1, 0xF9E2AF, 0x89B4FA, 0xF5C2E7, 0x94E2D5, 0xA6ADC8)),
    TerminalPalette("tokyo_night", "Tokyo Night", Color(0xFF1A1B26), Color(0xFFC0CAF5), Color(0xFF7AA2F7),
        ansi(0x15161E, 0xF7768E, 0x9ECE6A, 0xE0AF68, 0x7AA2F7, 0xBB9AF7, 0x7DCFFF, 0xA9B1D6,
            0x414868, 0xF7768E, 0x9ECE6A, 0xE0AF68, 0x7AA2F7, 0xBB9AF7, 0x7DCFFF, 0xC0CAF5)),
)

/** The palette for a stored theme id; an unknown id (an old or imported value) gets the default. */
fun terminalPalette(id: String): TerminalPalette =
    TerminalPalettes.firstOrNull { it.id == id } ?: TerminalPalettes.first()
