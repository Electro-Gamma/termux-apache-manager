package app.terminalssh.secure.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.ContentCut
import androidx.compose.material.icons.outlined.ContentPaste
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Deselect
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.DriveFileRenameOutline
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.SelectAll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import app.terminalssh.secure.R
import app.terminalssh.secure.sftp.BatchKind
import app.terminalssh.secure.sftp.BatchPhase
import app.terminalssh.secure.sftp.BatchProblem
import app.terminalssh.secure.sftp.BatchState
import app.terminalssh.secure.sftp.Clipboard
import app.terminalssh.secure.sftp.ClipboardMode
import app.terminalssh.secure.sftp.PropertiesState
import app.terminalssh.secure.sftp.PropertyItem
import app.terminalssh.secure.sftp.RemoteEntry
import app.terminalssh.secure.sftp.RemotePath
import app.terminalssh.secure.sftp.Selection
import app.terminalssh.secure.ui.theme.Amber
import app.terminalssh.secure.ui.theme.Danger
import app.terminalssh.secure.ui.theme.Stroke
import app.terminalssh.secure.ui.theme.TextSecondary
import app.terminalssh.secure.ui.theme.Turquoise
import kotlinx.coroutines.delay
import java.text.DateFormat
import java.util.Date
import java.util.Locale

// ---------------------------------------------------------------------------
// Selection mode chrome
// ---------------------------------------------------------------------------

/** Header shown while items are selected: count, where they are, and select/deselect all. */
@Composable
fun SelectionTopBar(
    selection: Selection,
    currentPath: String,
    allHereSelected: Boolean,
    onClose: () -> Unit,
    onToggleAll: () -> Unit,
) {
    val elsewhere = selection.countOutside(currentPath)
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surface)
            .padding(horizontal = 4.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(onClick = onClose) {
            Icon(Icons.Outlined.Close, stringResource(R.string.sftp_selection_exit), tint = TextSecondary)
        }
        Column(Modifier.weight(1f)) {
            Text(
                stringResource(R.string.sftp_selected_count, selection.count),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
            )
            if (elsewhere > 0) {
                Text(
                    stringResource(R.string.sftp_selected_elsewhere, elsewhere),
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary,
                    maxLines = 1,
                )
            }
        }
        TextButton(onClick = onToggleAll) {
            Icon(
                if (allHereSelected) Icons.Outlined.Deselect else Icons.Outlined.SelectAll,
                contentDescription = null,
                tint = Turquoise,
                modifier = Modifier.size(18.dp),
            )
            Spacer(Modifier.width(6.dp))
            Text(
                stringResource(if (allHereSelected) R.string.sftp_deselect_all else R.string.sftp_select_all),
                color = Turquoise,
                style = MaterialTheme.typography.labelLarge,
            )
        }
    }
}

/** Bottom action bar. Scrolls sideways so every action stays reachable on a narrow phone. */
@Composable
fun SelectionActionBar(
    selection: Selection,
    busy: Boolean,
    onDownload: () -> Unit,
    onDelete: () -> Unit,
    onRename: () -> Unit,
    onCopy: () -> Unit,
    onCut: () -> Unit,
    onProperties: () -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surface)
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 4.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        ActionButton(Icons.Outlined.Download, R.string.sftp_action_download, !busy, Turquoise, onDownload)
        ActionButton(Icons.Outlined.ContentCopy, R.string.sftp_action_copy, true, TextSecondary, onCopy)
        ActionButton(Icons.Outlined.ContentCut, R.string.sftp_action_cut, true, TextSecondary, onCut)
        // Renaming several items to one name makes no sense, so it is a single-item action.
        ActionButton(
            Icons.Outlined.DriveFileRenameOutline,
            R.string.sftp_action_rename,
            !busy && selection.count == 1,
            TextSecondary,
            onRename,
        )
        ActionButton(Icons.Outlined.Info, R.string.sftp_action_properties, true, TextSecondary, onProperties)
        ActionButton(Icons.Outlined.Delete, R.string.sftp_action_delete, !busy, Danger, onDelete)
    }
}

@Composable
private fun ActionButton(
    icon: ImageVector,
    label: Int,
    enabled: Boolean,
    tint: Color,
    onClick: () -> Unit,
) {
    val alpha = if (enabled) 1f else 0.38f
    Column(
        Modifier
            .width(76.dp)
            .clip(RoundedCornerShape(12.dp))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Icon(icon, contentDescription = null, tint = tint.copy(alpha = alpha), modifier = Modifier.size(24.dp))
        Text(
            stringResource(label),
            style = MaterialTheme.typography.labelSmall,
            color = TextSecondary.copy(alpha = alpha),
            maxLines = 1,
        )
    }
}

/** Shown after Copy / Cut until the items are pasted or the clipboard is cleared. */
@Composable
fun PasteBar(
    clipboard: Clipboard,
    busy: Boolean,
    onPaste: () -> Unit,
    onClear: () -> Unit,
) {
    val cut = clipboard.mode == ClipboardMode.CUT
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surface)
            .padding(start = 16.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            if (cut) Icons.Outlined.ContentCut else Icons.Outlined.ContentCopy,
            contentDescription = null,
            tint = TextSecondary,
            modifier = Modifier.size(20.dp),
        )
        Spacer(Modifier.width(12.dp))
        Text(
            stringResource(
                if (cut) R.string.sftp_clipboard_cut else R.string.sftp_clipboard_copy,
                clipboard.items.size,
            ),
            style = MaterialTheme.typography.bodyMedium,
            maxLines = 1,
            modifier = Modifier.weight(1f),
        )
        TextButton(onClick = onPaste, enabled = !busy) {
            Icon(
                Icons.Outlined.ContentPaste,
                contentDescription = null,
                tint = if (busy) TextSecondary else Turquoise,
                modifier = Modifier.size(18.dp),
            )
            Spacer(Modifier.width(6.dp))
            Text(
                stringResource(R.string.sftp_paste_here),
                color = if (busy) TextSecondary else Turquoise,
                style = MaterialTheme.typography.labelLarge,
            )
        }
        IconButton(onClick = onClear) {
            Icon(Icons.Outlined.Close, stringResource(R.string.sftp_clipboard_clear), tint = TextSecondary)
        }
    }
}

// ---------------------------------------------------------------------------
// Progress and error reporting for multi-item operations
// ---------------------------------------------------------------------------

@Composable
fun BatchCard(
    state: BatchState,
    onCancel: () -> Unit,
    onDismiss: () -> Unit,
    onDetails: () -> Unit,
) {
    // A clean finish needs no acknowledgement; anything noteworthy stays until dismissed.
    LaunchedEffect(state.id, state.phase, state.failureCount, state.skipped) {
        if (state.phase == BatchPhase.FINISHED && state.failureCount == 0 && state.skipped == 0) {
            delay(AUTO_DISMISS_MS)
            onDismiss()
        }
    }

    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surface)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                stringResource(state.kind.titleRes),
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f),
            )
            if (state.isFinished) {
                IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                    Icon(
                        Icons.Outlined.Close,
                        stringResource(R.string.sftp_batch_dismiss),
                        tint = TextSecondary,
                        modifier = Modifier.size(16.dp),
                    )
                }
            } else {
                TextButton(onClick = onCancel) {
                    Text(stringResource(R.string.sftp_cancel), style = MaterialTheme.typography.labelMedium)
                }
            }
        }

        when (state.phase) {
            BatchPhase.PREPARING -> {
                LinearProgressIndicator(
                    modifier = Modifier.fillMaxWidth().height(3.dp),
                    color = Turquoise,
                    trackColor = Stroke,
                )
                Text(
                    stringResource(R.string.sftp_batch_scanning, state.totalItems),
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary,
                )
            }
            BatchPhase.RUNNING -> {
                val progress = state.progress
                val animated by animateFloatAsState(progress ?: 0f, Motion.normal(), label = "batch")
                if (progress != null) {
                    LinearProgressIndicator(
                        progress = { animated },
                        modifier = Modifier.fillMaxWidth().height(3.dp),
                        color = Turquoise,
                        trackColor = Stroke,
                    )
                } else {
                    LinearProgressIndicator(
                        modifier = Modifier.fillMaxWidth().height(3.dp),
                        color = Turquoise,
                        trackColor = Stroke,
                    )
                }
                Text(
                    state.runningLine(),
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary,
                )
                if (state.current.isNotEmpty()) {
                    Text(
                        ltr(state.current),
                        style = MaterialTheme.typography.bodySmall,
                        maxLines = 1,
                    )
                }
            }
            else -> {
                val hasProblems = state.failureCount > 0
                Text(
                    when {
                        state.phase == BatchPhase.CANCELLED -> stringResource(R.string.sftp_batch_cancelled)
                        hasProblems -> stringResource(R.string.sftp_batch_done_problems, state.failureCount)
                        else -> stringResource(R.string.sftp_batch_done)
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (hasProblems) MaterialTheme.colorScheme.error else Turquoise,
                )
                if (state.aborted) {
                    Text(
                        stringResource(R.string.sftp_batch_stopped_connection),
                        style = MaterialTheme.typography.labelSmall,
                        color = Amber,
                    )
                }
                if (state.skipped > 0) {
                    Text(
                        stringResource(R.string.sftp_batch_skipped, state.skipped),
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary,
                    )
                }
                if (hasProblems) {
                    TextButton(onClick = onDetails) {
                        Text(stringResource(R.string.sftp_batch_details), color = Turquoise)
                    }
                }
            }
        }
    }
}

private const val AUTO_DISMISS_MS = 4_000L

private val BatchKind.titleRes: Int
    get() = when (this) {
        BatchKind.DOWNLOAD -> R.string.sftp_batch_download
        BatchKind.DELETE -> R.string.sftp_batch_delete
        BatchKind.COPY -> R.string.sftp_batch_copy
        BatchKind.MOVE -> R.string.sftp_batch_move
        BatchKind.RENAME -> R.string.sftp_batch_rename
    }

@Composable
private fun BatchState.runningLine(): String {
    val items = stringResource(R.string.sftp_batch_progress, doneItems, totalItems)
    val moves = kind == BatchKind.DOWNLOAD || kind == BatchKind.COPY
    return if (moves && totalBytes > 0L) {
        "$items · ${FileSize.format(doneBytes)} / ${FileSize.format(totalBytes)}"
    } else {
        items
    }
}

@Composable
fun BatchReportDialog(state: BatchState, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.sftp_report_title)) },
        text = {
            Column(
                Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                state.failures.forEach { failure ->
                    Column {
                        Text(
                            ltr(failure.path.ifEmpty { "/" }),
                            style = MaterialTheme.typography.bodySmall,
                            maxLines = 2,
                        )
                        Text(
                            stringResource(
                                when (failure.problem) {
                                    BatchProblem.ALREADY_EXISTS -> R.string.sftp_problem_exists
                                    BatchProblem.INTO_ITSELF -> R.string.sftp_problem_into_itself
                                    BatchProblem.INVALID_NAME -> R.string.sftp_problem_invalid_name
                                    null -> failure.kind.stringRes
                                },
                            ),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.error,
                        )
                    }
                }
                if (state.failuresNotListed > 0) {
                    Text(
                        stringResource(R.string.sftp_more_items, state.failuresNotListed),
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary,
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.sftp_close)) }
        },
        containerColor = MaterialTheme.colorScheme.surface,
    )
}

// ---------------------------------------------------------------------------
// Dialogs: delete, rename, properties
// ---------------------------------------------------------------------------

@Composable
fun DeleteConfirmDialog(selection: Selection, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    val names = selection.entries.map { it.name }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                if (selection.count == 1) {
                    stringResource(R.string.sftp_delete_title_one)
                } else {
                    stringResource(R.string.sftp_delete_title_many, selection.count)
                },
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(stringResource(R.string.sftp_delete_body), style = MaterialTheme.typography.bodyMedium)
                if (selection.hasDirectories) {
                    Text(
                        stringResource(R.string.sftp_delete_folders_note),
                        style = MaterialTheme.typography.bodyMedium,
                        color = Amber,
                    )
                }
                names.take(DELETE_PREVIEW_COUNT).forEach { name ->
                    Text(ltr(name), style = MaterialTheme.typography.bodySmall, color = TextSecondary, maxLines = 1)
                }
                if (names.size > DELETE_PREVIEW_COUNT) {
                    Text(
                        stringResource(R.string.sftp_more_items, names.size - DELETE_PREVIEW_COUNT),
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary,
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onConfirm) {
                Text(stringResource(R.string.delete), color = Danger)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
        },
        containerColor = MaterialTheme.colorScheme.surface,
    )
}

private const val DELETE_PREVIEW_COUNT = 5

@Composable
fun RenameDialog(entry: RemoteEntry, onConfirm: (String) -> Unit, onDismiss: () -> Unit) {
    var name by remember(entry.path) { mutableStateOf(entry.name) }
    val trimmed = name.trim()
    val valid = RemotePath.isValidEntryName(trimmed)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.sftp_rename_title)) },
        text = {
            Column {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    singleLine = true,
                    label = { Text(stringResource(R.string.sftp_rename_label)) },
                    isError = name.isNotEmpty() && !valid,
                    modifier = Modifier.fillMaxWidth(),
                )
                if (name.isNotEmpty() && !valid) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        stringResource(R.string.sftp_rename_invalid),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(trimmed) }, enabled = valid && trimmed != entry.name) {
                Text(stringResource(R.string.sftp_rename_confirm))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
        },
        containerColor = MaterialTheme.colorScheme.surface,
    )
}

@Composable
fun PropertiesDialog(state: PropertiesState, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.sftp_props_title)) },
        text = {
            Column(
                Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                if (state.measuring || state.loadingDetails) {
                    LinearProgressIndicator(
                        modifier = Modifier.fillMaxWidth().height(2.dp),
                        color = Turquoise,
                        trackColor = Stroke,
                    )
                }
                if (state.items.size == 1) {
                    SingleProperties(state, state.items.first())
                } else {
                    MultipleProperties(state)
                }
                if (state.unreadableFolders > 0) {
                    Text(
                        stringResource(R.string.sftp_props_scan_errors, state.unreadableFolders),
                        style = MaterialTheme.typography.labelSmall,
                        color = Amber,
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.sftp_close)) }
        },
        containerColor = MaterialTheme.colorScheme.surface,
    )
}

@Composable
private fun SingleProperties(state: PropertiesState, item: PropertyItem) {
    val entry = item.entry
    val stat = item.stat
    val isDirectory = stat?.isDirectory ?: entry.isDirectory
    val isLink = stat?.isSymlink ?: entry.isSymlink

    PropRow(R.string.sftp_props_name, ltr(entry.name))
    PropRow(
        R.string.sftp_props_type,
        stringResource(
            when {
                isLink -> R.string.sftp_type_link
                isDirectory -> R.string.sftp_type_folder
                else -> R.string.sftp_type_file
            },
        ),
    )
    PropRow(R.string.sftp_props_location, ltr(RemotePath.parent(entry.path)))
    PropRow(R.string.sftp_props_path, ltr(entry.path))

    if (isDirectory) {
        val size = if (state.measuring) {
            stringResource(R.string.sftp_props_calculating)
        } else {
            exactSize(state.totalBytes)
        }
        PropRow(R.string.sftp_props_size, size)
        // The folder itself is counted once in folderCount; "contents" excludes it.
        PropRow(
            R.string.sftp_props_contents,
            stringResource(
                R.string.sftp_props_contents_fmt,
                state.fileCount,
                (state.folderCount - 1).coerceAtLeast(0),
            ),
        )
    } else {
        PropRow(R.string.sftp_props_size, exactSize(stat?.sizeBytes ?: entry.sizeBytes))
    }

    val permissions = stat?.permissionsString?.ifEmpty { null } ?: entry.permissions
    val octal = stat?.permissionsOctal
    if (permissions.isNotEmpty()) {
        PropRow(R.string.sftp_props_permissions, if (octal != null) "$permissions  ($octal)" else permissions)
    }
    if (stat != null) {
        PropRow(R.string.sftp_props_owner, stringResource(R.string.sftp_props_owner_fmt, stat.uid, stat.gid))
    }
    val modified = stat?.modifiedEpochSeconds ?: entry.modifiedEpochSeconds
    PropRow(R.string.sftp_props_modified, formatDate(modified))
    if (stat != null) {
        PropRow(R.string.sftp_props_accessed, formatDate(stat.accessedEpochSeconds))
    }
    stat?.linkTarget?.let { PropRow(R.string.sftp_props_link_target, ltr(it)) }
    if (stat == null && !state.loadingDetails) {
        Text(
            stringResource(R.string.sftp_props_unavailable),
            style = MaterialTheme.typography.labelSmall,
            color = TextSecondary,
        )
    }
}

@Composable
private fun MultipleProperties(state: PropertiesState) {
    val folders = state.items.count { it.entry.isDirectory }
    val files = state.items.size - folders
    PropRow(R.string.sftp_props_items, stringResource(R.string.sftp_props_contents_fmt, files, folders))
    PropRow(
        R.string.sftp_props_total_size,
        if (state.measuring) stringResource(R.string.sftp_props_calculating) else exactSize(state.totalBytes),
    )
    if (folders > 0) {
        PropRow(
            R.string.sftp_props_contents,
            stringResource(
                R.string.sftp_props_contents_fmt,
                state.fileCount,
                (state.folderCount - folders).coerceAtLeast(0),
            ),
        )
    }
    if (state.locations.size == 1) {
        PropRow(R.string.sftp_props_location, ltr(state.locations.first()))
    } else {
        PropRow(
            R.string.sftp_props_locations,
            stringResource(R.string.sftp_props_other_folders, state.locations.size),
        )
    }
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        state.items.take(PROPS_PREVIEW_COUNT).forEach { item ->
            Text(
                ltr(item.entry.path),
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
                maxLines = 1,
            )
        }
        if (state.items.size > PROPS_PREVIEW_COUNT) {
            Text(
                stringResource(R.string.sftp_more_items, state.items.size - PROPS_PREVIEW_COUNT),
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary,
            )
        }
    }
}

private const val PROPS_PREVIEW_COUNT = 8

@Composable
private fun PropRow(label: Int, value: String) {
    Column {
        Text(stringResource(label), style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        Text(value, style = MaterialTheme.typography.bodyMedium)
    }
}

/** "1.4 MB (1,468,006 bytes)"; the exact count is what you compare against `ls -l`. */
private fun exactSize(bytes: Long): String {
    if (bytes < 0L) return "—"
    return "${FileSize.format(bytes)} (${String.format(Locale.getDefault(), "%,d", bytes)} B)"
}

private fun formatDate(epochSeconds: Long): String {
    if (epochSeconds <= 0L) return "—"
    val format = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.MEDIUM)
    return format.format(Date(epochSeconds * 1000L))
}
