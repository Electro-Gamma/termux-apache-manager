package app.terminalssh.secure.ssh

import android.content.ContentResolver
import app.terminalssh.secure.model.HostProfile
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import java.util.UUID

/**
 * Every open File Manager, one per server. Lives in the Application next to the terminal
 * [SessionRegistry], and is deliberately separate from it: a terminal can be closed while
 * its files stay open, and the other way round.
 */
class FileSessionRegistry(
    private val contentResolver: ContentResolver,
    private val client: JschSshClient,
) {
    private val _workspaces = MutableStateFlow<List<FileWorkspace>>(emptyList())
    val workspaces: StateFlow<List<FileWorkspace>> = _workspaces.asStateFlow()

    private val _activeId = MutableStateFlow<String?>(null)
    val activeId: StateFlow<String?> = _activeId.asStateFlow()

    /** The workspace already open for [hostId] that can still be used, if any. */
    fun reusableFor(hostId: String): FileWorkspace? =
        _workspaces.value.firstOrNull { it.profile.id == hostId && it.session.state.value.isKeptAlive }

    /**
     * Opens the File Manager for [profile], or switches to the one already open for that
     * server. Returns the workspace and whether it was newly created.
     */
    fun open(profile: HostProfile, keepAlive: Boolean, password: ByteArray?): FileWorkspace {
        reusableFor(profile.id)?.let { existing ->
            // Already running: attach to it, never start a second connection.
            password?.fill(0)
            _activeId.value = existing.id
            return existing
        }
        // A dead one for the same server (closed, failed) is replaced rather than piled up.
        _workspaces.value.filter { it.profile.id == profile.id }.forEach { close(it.id) }
        val session = FileSession(UUID.randomUUID().toString(), profile, client, keepAlive)
        val workspace = FileWorkspace(session, contentResolver)
        _workspaces.value = _workspaces.value + workspace
        _activeId.value = workspace.id
        session.connect(password)
        return workspace
    }

    fun select(id: String) {
        if (_workspaces.value.any { it.id == id }) _activeId.value = id
    }

    /** The user disconnected: ends the connection, its transfers and its state. */
    fun close(id: String) {
        val workspace = _workspaces.value.firstOrNull { it.id == id } ?: return
        workspace.destroy()
        val remaining = _workspaces.value.filterNot { it.id == id }
        _workspaces.value = remaining
        if (_activeId.value == id) _activeId.value = remaining.lastOrNull()?.id
    }

    fun closeAll() {
        _workspaces.value.forEach { it.destroy() }
        _workspaces.value = emptyList()
        _activeId.value = null
    }

    /** Workspaces whose connection is up or being brought up, which keep the app's service running. */
    fun keepAliveCount(): Int = _workspaces.value.count { it.session.state.value.isKeptAlive }

    @OptIn(ExperimentalCoroutinesApi::class)
    val keepAliveCountFlow: Flow<Int> = _workspaces.flatMapLatest { open ->
        if (open.isEmpty()) {
            flowOf(0)
        } else {
            combine(open.map { it.session.state }) { states -> states.count { it.isKeptAlive } }
        }
    }

    /** Per-host state of the File Manager connections, for the host list. */
    @OptIn(ExperimentalCoroutinesApi::class)
    val hostStates: Flow<Map<String, SshSessionState>> = _workspaces.flatMapLatest { open ->
        if (open.isEmpty()) {
            flowOf(emptyMap())
        } else {
            combine(open.map { ws -> ws.session.state.map { ws.profile.id to it } }) { pairs ->
                pairs.groupBy({ it.first }, { it.second })
                    .mapValues { (_, states) -> states.maxBy { it.interest() } }
            }
        }
    }
}
