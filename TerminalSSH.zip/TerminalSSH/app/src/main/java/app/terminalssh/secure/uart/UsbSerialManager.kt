package app.terminalssh.secure.uart

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbManager
import android.os.Build
import com.hoho.android.usbserial.driver.UsbSerialDriver
import com.hoho.android.usbserial.driver.UsbSerialProber
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow

sealed class UsbEvent {
    data class Attached(val device: UsbDevice) : UsbEvent()
    data class Detached(val device: UsbDevice) : UsbEvent()
    data class PermissionResult(val device: UsbDevice, val granted: Boolean) : UsbEvent()
}

/**
 * USB device discovery (through usb-serial-for-android's prober), Android's asynchronous
 * permission dance, and attach/detach broadcasts, reduced to a plain event stream. One instance
 * lives for the whole process so a UART session keeps hearing about its adapter in the background.
 */
class UsbSerialManager(private val context: Context) {

    private val usbManager = context.getSystemService(Context.USB_SERVICE) as UsbManager
    private val permissionAction = "${context.packageName}.USB_PERMISSION"

    private val _events = MutableSharedFlow<UsbEvent>(extraBufferCapacity = 16)
    val events: SharedFlow<UsbEvent> = _events

    private var registered = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            val device: UsbDevice? = if (Build.VERSION.SDK_INT >= 33) {
                intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)
            }
            when (intent.action) {
                permissionAction -> {
                    val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
                    device?.let { _events.tryEmit(UsbEvent.PermissionResult(it, granted)) }
                }
                UsbManager.ACTION_USB_DEVICE_ATTACHED -> device?.let { _events.tryEmit(UsbEvent.Attached(it)) }
                UsbManager.ACTION_USB_DEVICE_DETACHED -> device?.let { _events.tryEmit(UsbEvent.Detached(it)) }
            }
        }
    }

    /** Safe to call more than once. */
    fun register() {
        if (registered) return
        val filter = IntentFilter().apply {
            addAction(permissionAction)
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            context.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            context.registerReceiver(receiver, filter)
        }
        registered = true
    }

    /** Every USB-serial-capable device plugged in, from any supported chip family. */
    fun listDrivers(): List<UsbSerialDriver> =
        runCatching { UsbSerialProber.getDefaultProber().findAllDrivers(usbManager) }.getOrDefault(emptyList())

    fun displayName(device: UsbDevice): String {
        val name = listOfNotNull(
            device.manufacturerName?.takeIf { it.isNotBlank() },
            device.productName?.takeIf { it.isNotBlank() },
        ).joinToString(" ")
        return name.ifBlank { "USB %04X:%04X".format(device.vendorId, device.productId) }
    }

    fun hasPermission(device: UsbDevice): Boolean = usbManager.hasPermission(device)

    fun requestPermission(device: UsbDevice) {
        // The system fills the result into this intent, so it has to be mutable (Android 12+).
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
        val pending = PendingIntent.getBroadcast(
            context, 0, Intent(permissionAction).setPackage(context.packageName), flags,
        )
        usbManager.requestPermission(device, pending)
    }

    fun openConnection(device: UsbDevice): UsbDeviceConnection? = usbManager.openDevice(device)

    fun isUsbHostSupported(): Boolean = context.packageManager.hasSystemFeature(PackageManager.FEATURE_USB_HOST)
}
