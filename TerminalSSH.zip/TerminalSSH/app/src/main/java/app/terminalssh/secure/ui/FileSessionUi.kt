package app.terminalssh.secure.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowDropDown
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.LinkOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.terminalssh.secure.R
import app.terminalssh.secure.ssh.FileSession
import app.terminalssh.secure.ssh.FileWorkspace
import app.terminalssh.secure.ssh.SshSessionState
import app.terminalssh.secure.ui.theme.Amber
import app.terminalssh.secure.ui.theme.Cyan
import app.terminalssh.secure.ui.theme.Danger
import app.terminalssh.secure.ui.theme.Stroke
import app.terminalssh.secure.ui.theme.TextSecondary
import app.terminalssh.secure.ui.theme.Turquoise
import app.terminalssh.secure.vm.AppViewModel

/**
 * The server pill under the title: which server the File Manager is on and whether its
 * connection is up. Tapping it switches between open File Managers or disconnects this
 * one, which is the only thing here that ends a session.
 */
@Composable
fun FileServerChip(
    active: FileWorkspace,
    all: List<FileWorkspace>,
    onSelect: (String) -> Unit,
    onDisconnect: (String) -> Unit,
) {
    val state by active.session.state.collectAsStateWithLifecycle()
    var open by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(MaterialTheme.colorScheme.surface)
                .clickable { open = true }
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.size(10.dp).clip(CircleShape).background(state.status().color))
            Spacer(Modifier.width(12.dp))
            Text(
                ltr(active.profile.displayName),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                modifier = Modifier.weight(1f),
            )
            Text(
                stringResource(state.status().labelRes),
                style = MaterialTheme.typography.labelSmall,
                color = state.status().color,
            )
            Icon(Icons.Outlined.ArrowDropDown, contentDescription = null, tint = TextSecondary)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            all.forEach { workspace ->
                val workspaceState = workspace.session.state.value
                DropdownMenuItem(
                    text = { Text(ltr(workspace.profile.displayName)) },
                    onClick = {
                        open = false
                        onSelect(workspace.id)
                    },
                    leadingIcon = {
                        Box(Modifier.size(10.dp).clip(CircleShape).background(workspaceState.status().color))
                    },
                    trailingIcon = if (workspace.id == active.id) {
                        { Icon(Icons.Outlined.Check, contentDescription = null, tint = Turquoise) }
                    } else {
                        null
                    },
                )
            }
            HorizontalDivider()
            DropdownMenuItem(
                text = { Text(stringResource(R.string.files_disconnect), color = Danger) },
                onClick = {
                    open = false
                    onDisconnect(active.id)
                },
                leadingIcon = { Icon(Icons.Outlined.LinkOff, contentDescription = null, tint = Danger) },
            )
        }
    }
}

/**
 * Shown while the File Manager's connection is anything but up. The folder underneath
 * stays on screen: a dropped connection is not a reason to blank what the user was
 * looking at.
 */
@Composable
fun FileConnectionBanner(state: SshSessionState, onReconnect: () -> Unit) {
    if (state is SshSessionState.Connected) return

    val working = state.isBusy
    val message = when (state) {
        is SshSessionState.Connecting -> stringResource(R.string.files_state_connecting)
        is SshSessionState.Reconnecting -> stringResource(R.string.files_state_reconnecting, state.attempt, state.max)
        is SshSessionState.AwaitingHostKeyApproval -> stringResource(R.string.state_verifying)
        is SshSessionState.Failed -> stringResource(state.kind.stringRes)
        else -> stringResource(R.string.files_state_closed)
    }
    val canReconnect = state is SshSessionState.Failed ||
        state is SshSessionState.Closed ||
        state is SshSessionState.Idle

    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surface)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        if (working) {
            LinearProgressIndicator(
                modifier = Modifier.fillMaxWidth().height(2.dp),
                color = Cyan,
                trackColor = Stroke,
            )
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                message,
                style = MaterialTheme.typography.bodySmall,
                color = if (state is SshSessionState.Failed) MaterialTheme.colorScheme.error else TextSecondary,
                modifier = Modifier.weight(1f),
            )
            if (canReconnect) {
                TextButton(onClick = onReconnect) {
                    Text(stringResource(R.string.files_reconnect), color = Turquoise)
                }
            }
        }
    }
}

/** Host-key approval and refusal for the File Manager's own connection. */
@Composable
fun FileHostKeyDialogs(viewModel: AppViewModel, session: FileSession) {
    val state by session.state.collectAsStateWithLifecycle()
    var dismissedFailure by remember { mutableStateOf(false) }

    (state as? SshSessionState.AwaitingHostKeyApproval)?.let { pending ->
        AlertDialog(
            onDismissRequest = { session.disconnect() },
            title = { Text(stringResource(R.string.hostkey_title)) },
            text = {
                Column {
                    Text(stringResource(R.string.hostkey_body), style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(16.dp))
                    FingerprintText("${pending.host}:${pending.port}")
                    Spacer(Modifier.height(8.dp))
                    FingerprintText(pending.algorithm)
                    Spacer(Modifier.height(8.dp))
                    FingerprintText(pending.fingerprint)
                }
            },
            confirmButton = {
                TextButton(onClick = { viewModel.trustFileHostKey(session, pending) }) {
                    Text(stringResource(R.string.hostkey_trust), color = Amber)
                }
            },
            dismissButton = {
                TextButton(onClick = { session.disconnect() }) { Text(stringResource(R.string.cancel)) }
            },
            containerColor = MaterialTheme.colorScheme.surface,
        )
    }

    (state as? SshSessionState.Failed)?.takeIf { it.hostKeyChanged && !dismissedFailure }?.let { failure ->
        AlertDialog(
            onDismissRequest = { dismissedFailure = true },
            title = { Text(stringResource(R.string.hostkey_changed_title), color = Danger) },
            text = {
                Column {
                    Text(stringResource(R.string.hostkey_changed_body), style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(12.dp))
                    FingerprintText(failure.message)
                }
            },
            confirmButton = {
                TextButton(onClick = { dismissedFailure = true }) { Text(stringResource(R.string.cancel)) }
            },
            dismissButton = {
                TextButton(onClick = {
                    viewModel.forgetHostKey(session.profile.host, session.profile.port)
                    dismissedFailure = true
                }) { Text(stringResource(R.string.hostkey_forget), color = Danger) }
            },
            containerColor = MaterialTheme.colorScheme.surface,
        )
    }
}

@Composable
private fun FingerprintText(text: String) {
    Text(
        text,
        fontFamily = FontFamily.Monospace,
        style = MaterialTheme.typography.bodyMedium,
        color = TextSecondary,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(horizontal = 12.dp, vertical = 8.dp),
    )
}
