package app.terminalssh.secure.ui

import android.content.Context
import android.graphics.Typeface

/**
 * Typefaces behind the Terminal font setting: the two system monospace faces every Android
 * device ships, plus monospaced fonts bundled in assets/fonts (licences in assets/fonts/licenses).
 * Every one is genuinely monospaced, which the terminal grid depends on.
 */
object TerminalFonts {
    /** Stored id -> asset file for the bundled faces. */
    private val bundled = mapOf(
        "jetbrains_mono" to "jetbrains_mono.ttf",
        "ibm_plex_mono" to "ibm_plex_mono.ttf",
        "dejavu_sans_mono" to "dejavu_sans_mono.ttf",
        "liberation_mono" to "liberation_mono.ttf",
        "red_hat_mono" to "red_hat_mono.ttf",
        "geist_mono" to "geist_mono.ttf",
        "dm_mono" to "dm_mono.ttf",
    )

    /** Every id the setting offers, in display order. */
    val ids: List<String> = listOf("monospace", "serif_monospace") + bundled.keys

    private val cache = HashMap<String, Typeface>()

    @Synchronized
    fun typeface(context: Context, name: String): Typeface = cache.getOrPut(name) { load(context, name) }

    private fun load(context: Context, name: String): Typeface {
        if (name == "serif_monospace") {
            val created = Typeface.create("serif-monospace", Typeface.NORMAL)
            // A device without that family silently hands back its proportional default,
            // which would wreck the terminal grid; fall back to the plain monospace face.
            return if (created == Typeface.DEFAULT) Typeface.MONOSPACE else created
        }
        val asset = bundled[name] ?: return Typeface.MONOSPACE
        return runCatching { Typeface.createFromAsset(context.applicationContext.assets, "fonts/$asset") }
            .getOrDefault(Typeface.MONOSPACE)
    }
}
