package app.terminalssh.secure.ui

import android.graphics.Typeface

/** Typefaces behind the Terminal font setting. Only faces every Android device ships are offered. */
object TerminalFonts {
    fun typeface(name: String): Typeface = when (name) {
        "serif_monospace" -> {
            val created = Typeface.create("serif-monospace", Typeface.NORMAL)
            // A device without that family silently hands back its proportional default,
            // which would wreck the terminal grid; fall back to the plain monospace face.
            if (created == Typeface.DEFAULT) Typeface.MONOSPACE else created
        }
        else -> Typeface.MONOSPACE
    }
}
