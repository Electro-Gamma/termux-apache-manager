package app.terminalssh.secure.uart

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * A saved serial connection. Nothing in it is secret (a UART has no credentials), so it is kept
 * as plain JSON next to the host list rather than in the vault.
 */
data class UartProfile(
    val id: String,
    val label: String = "",
    val settings: SerialSettings = SerialSettings(),
    /** USB vendor/product id of the adapter this profile is for; -1 means "any adapter". */
    val vendorId: Int = ANY_DEVICE,
    val productId: Int = ANY_DEVICE,
    /** A remembered adapter name, for showing which one the ids above mean when it is unplugged. */
    val deviceName: String = "",
    val notes: String = "",
    val lastConnectedAt: Long = 0L,
) {
    val displayName: String get() = label.ifBlank { "UART" }
    val subtitle: String get() = settings.summary
    val anyDevice: Boolean get() = vendorId == ANY_DEVICE

    fun matches(vid: Int, pid: Int): Boolean = anyDevice || (vendorId == vid && productId == pid)

    companion object {
        const val ANY_DEVICE = -1
    }
}

class UartStore(context: Context) {
    private val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun profiles(): List<UartProfile> {
        val raw = prefs.getString(KEY, null) ?: return emptyList()
        val array = runCatching { JSONArray(raw) }.getOrNull() ?: return emptyList()
        return (0 until array.length())
            .mapNotNull { i -> array.optJSONObject(i)?.let { runCatching { it.toProfile() }.getOrNull() } }
            .sortedByDescending { it.lastConnectedAt }
    }

    fun upsert(profile: UartProfile) = write(profiles().filterNot { it.id == profile.id } + profile)

    fun delete(id: String) = write(profiles().filterNot { it.id == id })

    fun touch(id: String) {
        profiles().firstOrNull { it.id == id }?.let { upsert(it.copy(lastConnectedAt = System.currentTimeMillis())) }
    }

    private fun write(list: List<UartProfile>) {
        prefs.edit().putString(KEY, JSONArray(list.map { it.toJson() }).toString()).apply()
    }

    private fun UartProfile.toJson() = JSONObject()
        .put("id", id).put("label", label)
        .put("baud", settings.baudRate)
        .put("dataBits", settings.dataBits.name).put("stopBits", settings.stopBits.name)
        .put("parity", settings.parity.name).put("flow", settings.flowControl.name)
        .put("dtr", settings.dtrEnabled).put("rts", settings.rtsEnabled)
        .put("vid", vendorId).put("pid", productId).put("device", deviceName)
        .put("notes", notes).put("last", lastConnectedAt)

    private fun JSONObject.toProfile() = UartProfile(
        id = getString("id"),
        label = optString("label"),
        settings = SerialSettings(
            baudRate = optInt("baud", 115200).coerceIn(SerialSettings.MIN_BAUD, SerialSettings.MAX_BAUD),
            dataBits = enumOr(optString("dataBits"), DataBits.EIGHT),
            stopBits = enumOr(optString("stopBits"), StopBits.ONE),
            parity = enumOr(optString("parity"), Parity.NONE),
            flowControl = enumOr(optString("flow"), FlowControl.NONE),
            dtrEnabled = optBoolean("dtr", true),
            rtsEnabled = optBoolean("rts", true),
        ),
        vendorId = optInt("vid", UartProfile.ANY_DEVICE),
        productId = optInt("pid", UartProfile.ANY_DEVICE),
        deviceName = optString("device"),
        notes = optString("notes"),
        lastConnectedAt = optLong("last", 0L),
    )

    private inline fun <reified E : Enum<E>> enumOr(name: String, default: E): E =
        enumValues<E>().firstOrNull { it.name == name } ?: default

    private companion object {
        const val PREFS = "uart_profiles_v1"
        const val KEY = "profiles"
    }
}
