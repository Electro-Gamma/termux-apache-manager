package app.terminalssh.secure.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import app.terminalssh.secure.R
import app.terminalssh.secure.ssh.SshSessionState
import app.terminalssh.secure.ui.theme.Danger
import app.terminalssh.secure.ui.theme.Size
import app.terminalssh.secure.ui.theme.Space
import app.terminalssh.secure.ui.theme.Stroke
import app.terminalssh.secure.ui.theme.TextSecondary
import app.terminalssh.secure.uart.DataBits
import app.terminalssh.secure.uart.FlowControl
import app.terminalssh.secure.uart.Parity
import app.terminalssh.secure.uart.SerialSettings
import app.terminalssh.secure.uart.StopBits
import app.terminalssh.secure.uart.UartProfile
import app.terminalssh.secure.vm.UsbAdapter
import java.util.UUID

/** The saved UART connections, under their own heading on the host list. */
fun LazyListScope.uartRows(
    profiles: List<UartProfile>,
    hostStates: Map<String, SshSessionState>,
    onOpen: (UartProfile) -> Unit,
    onEdit: (UartProfile) -> Unit,
) {
    if (profiles.isEmpty()) return
    item(key = "uart-header") { SectionHeader(stringResource(R.string.uart_section_title)) }
    items(profiles, key = { "uart-" + it.id }) { profile ->
        UartRow(profile, hostStates[profile.id], onOpen = { onOpen(profile) }, onEdit = { onEdit(profile) })
    }
}

@Composable
private fun UartRow(profile: UartProfile, state: SshSessionState?, onOpen: () -> Unit, onEdit: () -> Unit) {
    val status = state.status()
    val outline = if (status == ConnectionStatus.IDLE) Stroke.copy(alpha = 0.55f) else status.color.copy(alpha = 0.5f)
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 72.dp)
            .clip(MaterialTheme.shapes.medium)
            .background(MaterialTheme.colorScheme.surface)
            .border(Size.hairline, outline, MaterialTheme.shapes.medium)
            .clickable(onClick = onOpen)
            .padding(horizontal = Space.md, vertical = Space.md),
    ) {
        Avatar(initial = "U", status = status)
        Spacer(Modifier.width(Space.md))
        Column(Modifier.weight(1f)) {
            Text(ltr(profile.displayName), style = MaterialTheme.typography.titleMedium, maxLines = 1)
            Text(
                ltr(profile.subtitle),
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
                maxLines = 1,
            )
            val device = if (profile.anyDevice) stringResource(R.string.uart_any_device) else profile.deviceName
            Text(device, style = MaterialTheme.typography.labelSmall, color = TextSecondary, maxLines = 1)
        }
        TextButton(onClick = onEdit) { Text(stringResource(R.string.uart_edit)) }
    }
}

/** What a new connection is: SSH to a server, or a serial console over a USB-to-UART adapter. */
@Composable
fun NewConnectionDialog(onSsh: () -> Unit, onUart: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.new_connection_title)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(Space.sm)) {
                ChoiceRow(R.string.new_connection_ssh, R.string.new_connection_ssh_desc, onSsh)
                ChoiceRow(R.string.new_connection_uart, R.string.new_connection_uart_desc, onUart)
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
        containerColor = MaterialTheme.colorScheme.surface,
    )
}

@Composable
private fun ChoiceRow(title: Int, body: Int, onClick: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.medium)
            .border(Size.hairline, Stroke, MaterialTheme.shapes.medium)
            .clickable(onClick = onClick)
            .padding(Space.md),
    ) {
        Text(stringResource(title), style = MaterialTheme.typography.titleMedium)
        Text(stringResource(body), style = MaterialTheme.typography.bodySmall, color = TextSecondary)
    }
}

/** Creates or edits a UART connection: port settings, handshake lines and which adapter it is for. */
@Composable
fun UartEditSheet(
    initial: UartProfile?,
    adapters: List<UsbAdapter>,
    usbSupported: Boolean,
    onDismiss: () -> Unit,
    onSave: (UartProfile) -> Unit,
    onDelete: (UartProfile) -> Unit,
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val start = initial ?: UartProfile(id = UUID.randomUUID().toString())
    var label by remember { mutableStateOf(start.label) }
    var baudText by remember { mutableStateOf(start.settings.baudRate.toString()) }
    var dataBits by remember { mutableStateOf(start.settings.dataBits) }
    var parity by remember { mutableStateOf(start.settings.parity) }
    var stopBits by remember { mutableStateOf(start.settings.stopBits) }
    var flow by remember { mutableStateOf(start.settings.flowControl) }
    var dtr by remember { mutableStateOf(start.settings.dtrEnabled) }
    var rts by remember { mutableStateOf(start.settings.rtsEnabled) }
    var vendorId by remember { mutableStateOf(start.vendorId) }
    var productId by remember { mutableStateOf(start.productId) }
    var deviceName by remember { mutableStateOf(start.deviceName) }

    val baud = baudText.toIntOrNull()
    val baudValid = baud != null && baud in SerialSettings.MIN_BAUD..SerialSettings.MAX_BAUD

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(
            Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = Space.xl)
                .padding(bottom = Space.xxl),
            verticalArrangement = Arrangement.spacedBy(Space.lg),
        ) {
            Text(
                stringResource(if (initial == null) R.string.uart_new_title else R.string.uart_edit_title),
                style = MaterialTheme.typography.titleLarge,
            )
            if (!usbSupported) {
                Text(stringResource(R.string.err_usb_unsupported), color = Danger, style = MaterialTheme.typography.bodyMedium)
            }
            OutlinedTextField(
                value = label,
                onValueChange = { label = it.take(60) },
                label = { Text(stringResource(R.string.uart_name_label)) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )

            Column(verticalArrangement = Arrangement.spacedBy(Space.xs)) {
                Text(stringResource(R.string.uart_baud), style = MaterialTheme.typography.labelLarge)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(Space.sm)) {
                    SerialSettings.COMMON_BAUD_RATES.forEach { rate ->
                        FilterChip(selected = baud == rate, onClick = { baudText = rate.toString() }, label = { Text(rate.toString()) })
                    }
                }
                OutlinedTextField(
                    value = baudText,
                    onValueChange = { baudText = it.filter(Char::isDigit).take(8) },
                    label = { Text(stringResource(R.string.uart_baud_custom)) },
                    isError = !baudValid,
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            Chips(R.string.uart_data_bits, DataBits.entries, dataBits, { it.label }) { dataBits = it }
            Chips(R.string.uart_parity, Parity.entries, parity, { it.label }) { parity = it }
            Chips(R.string.uart_stop_bits, StopBits.entries, stopBits, { it.label }) { stopBits = it }
            Chips(R.string.uart_flow, FlowControl.entries, flow, { it.label }) { flow = it }

            Column {
                Text(stringResource(R.string.uart_handshake), style = MaterialTheme.typography.labelLarge)
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("DTR", Modifier.weight(1f))
                    Switch(checked = dtr, onCheckedChange = { dtr = it })
                }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("RTS", Modifier.weight(1f))
                    Switch(checked = rts, onCheckedChange = { rts = it })
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(Space.xs)) {
                Text(stringResource(R.string.uart_device), style = MaterialTheme.typography.labelLarge)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(Space.sm)) {
                    FilterChip(
                        selected = vendorId == UartProfile.ANY_DEVICE,
                        onClick = { vendorId = UartProfile.ANY_DEVICE; productId = UartProfile.ANY_DEVICE; deviceName = "" },
                        label = { Text(stringResource(R.string.uart_any_device)) },
                    )
                    adapters.forEach { a ->
                        FilterChip(
                            selected = vendorId == a.vendorId && productId == a.productId,
                            onClick = { vendorId = a.vendorId; productId = a.productId; deviceName = a.name },
                            label = { Text(a.name) },
                        )
                    }
                    // A remembered adapter that is not plugged in right now stays selectable.
                    if (vendorId != UartProfile.ANY_DEVICE && adapters.none { it.vendorId == vendorId && it.productId == productId }) {
                        FilterChip(
                            selected = true,
                            onClick = {},
                            label = { Text(stringResource(R.string.uart_device_missing, deviceName.ifBlank { "%04X:%04X".format(vendorId, productId) })) },
                        )
                    }
                }
                if (adapters.isEmpty()) {
                    Text(stringResource(R.string.uart_no_adapter_hint), style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                }
            }

            Text(stringResource(R.string.uart_ttl_warning), style = MaterialTheme.typography.bodySmall, color = TextSecondary)

            Button(
                onClick = {
                    onSave(
                        start.copy(
                            label = label.trim(),
                            settings = SerialSettings(
                                baudRate = baud ?: 115200,
                                dataBits = dataBits,
                                stopBits = stopBits,
                                parity = parity,
                                flowControl = flow,
                                dtrEnabled = dtr,
                                rtsEnabled = rts,
                            ),
                            vendorId = vendorId,
                            productId = productId,
                            deviceName = deviceName,
                        ),
                    )
                },
                enabled = baudValid,
                modifier = Modifier.fillMaxWidth(),
            ) { Text(stringResource(R.string.uart_save)) }
            if (initial != null) {
                OutlinedButton(
                    onClick = { onDelete(initial) },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Danger),
                    modifier = Modifier.fillMaxWidth(),
                ) { Text(stringResource(R.string.uart_delete)) }
            }
            Spacer(Modifier.height(Space.sm))
        }
    }
}

@Composable
private fun <T> Chips(title: Int, options: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(Space.xs)) {
        Text(stringResource(title), style = MaterialTheme.typography.labelLarge)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(Space.sm)) {
            options.forEach { option ->
                FilterChip(selected = option == selected, onClick = { onSelect(option) }, label = { Text(label(option)) })
            }
        }
    }
}
