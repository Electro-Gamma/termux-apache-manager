package app.terminalssh.secure.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import android.os.Bundle
import android.os.SystemClock
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.text.Spanned
import android.text.TextWatcher
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.OverScroller
import androidx.compose.ui.graphics.toArgb
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.roundToInt

// Editor colours (One Dark).
internal const val EDITOR_BG = 0xFF282C34.toInt()
private const val EDITOR_FG = 0xFFABB2BF.toInt()
private const val MATCH_BG = 0xFF5A4A1F.toInt()
private const val MATCH_CUR_BG = 0xFF9A6A14.toInt()

/** One recorded change: [old] was replaced by [new] at [start]. */
internal class EditHistory {
    class Edit(var start: Int, var old: String, var new: String, var time: Long)

    private val undoSt = ArrayList<Edit>()
    private val redoSt = ArrayList<Edit>()
    private var chars = 0L

    // Size of the undo stack when the text was last saved; null when that state is gone.
    private var savedPos: Int? = 0

    val canUndo: Boolean get() = undoSt.isNotEmpty()
    val canRedo: Boolean get() = redoSt.isNotEmpty()

    /** True when the text may differ from the saved text. Never says "clean" for changed text. */
    val modified: Boolean
        get() {
            val p = savedPos
            return p == null || p != undoSt.size
        }

    fun reset() {
        undoSt.clear()
        redoSt.clear()
        chars = 0L
        savedPos = 0
    }

    fun markSaved() {
        savedPos = undoSt.size
    }

    fun record(start: Int, old: String, new: String, now: Long) {
        if (old == new) return // nothing changed (also covers empty -> empty)
        if (redoSt.isNotEmpty()) {
            redoSt.clear()
            val p = savedPos
            if (p != null && p > undoSt.size) savedPos = null
        }
        val last = undoSt.lastOrNull()
        // Typing, backspacing and keyboard composition fold into one undo step, but never
        // into the step that was current when the file was saved.
        if (last != null && savedPos != undoSt.size && now - last.time < COALESCE_MS) {
            if (old.isEmpty() && last.old.isEmpty() && start == last.start + last.new.length &&
                last.new.length < 400 && !new.contains('\n')
            ) {
                last.new += new
                chars += new.length
                last.time = now
                return
            }
            if (new.isEmpty() && last.new.isEmpty() && start + old.length == last.start) {
                last.start = start
                last.old = old + last.old
                chars += old.length
                last.time = now
                return
            }
            if (new.isEmpty() && last.new.isEmpty() && start == last.start) {
                last.old += old
                chars += old.length
                last.time = now
                return
            }
            if (start == last.start && old == last.new) {
                chars += new.length - last.new.length
                last.new = new
                last.time = now
                return
            }
        }
        undoSt.add(Edit(start, old, new, now))
        chars += old.length + new.length
        while (undoSt.size > MAX_ENTRIES || (undoSt.size > 1 && chars > MAX_CHARS)) {
            val e = undoSt.removeAt(0)
            chars -= e.old.length + e.new.length
            val p = savedPos
            savedPos = if (p == null || p - 1 < 0) null else p - 1
        }
    }

    fun undo(): Edit? {
        if (undoSt.isEmpty()) return null
        val e = undoSt.removeAt(undoSt.lastIndex)
        chars -= e.old.length + e.new.length
        redoSt.add(e)
        return e
    }

    fun redo(): Edit? {
        if (redoSt.isEmpty()) return null
        val e = redoSt.removeAt(redoSt.lastIndex)
        undoSt.add(e)
        chars += e.old.length + e.new.length
        return e
    }

    private companion object {
        const val COALESCE_MS = 900L
        const val MAX_ENTRIES = 400
        const val MAX_CHARS = 6_000_000L
    }
}

/** The character window and data version the on-screen spans of one kind were built for. */
private class AppliedWindow {
    var start = -1
    var end = -1
    var version = -1
    var edit = -1

    fun reset() {
        start = -1
        end = -1
        version = -1
        edit = -1
    }

    fun covers(version: Int, edit: Int, from: Int, to: Int): Boolean =
        start >= 0 && this.version == version && this.edit == edit && from >= start && to <= end

    fun set(start: Int, end: Int, version: Int, edit: Int) {
        this.start = start
        this.end = end
        this.version = version
        this.edit = edit
    }
}

private class HlColorSpan(color: Int) : ForegroundColorSpan(color)
private class MatchSpan(color: Int) : BackgroundColorSpan(color)

/**
 * The editor surface: a real [EditText] that is exactly the size of the screen area and does
 * its own scrolling, so only the visible lines are ever laid out, drawn or coloured. That is
 * what keeps typing, scrolling and searching quick on files of hundreds of kilobytes.
 *
 * Scroll ownership: this view is the ONLY thing that decides where the viewport is. A stock
 * [EditText] also scrolls itself, to keep the caret visible, from several places (its
 * pre-draw hook, deferred layout scrolls, every batch edit an IME sends, the movement
 * method's touch handling, ...). Left alone that machinery runs next to our own scrolling and
 * snaps the view back to the caret - i.e. to wherever the person last tapped - the next time
 * anything makes it fire. So the framework's self-scrolling is switched off in [scrollTo],
 * [bringPointIntoView] and [requestRectangleOnScreen], and the viewport changes only when
 *  - the person drags or flings,
 *  - we explicitly reveal something (find match, undo/redo, zoom/layout restore), or
 *  - the caret itself moved or the text was edited by the person (see [armFollow]).
 *
 * It also owns the things that must happen inside the touch stream: fling scrolling, the
 * two-finger pinch (which cancels the gesture for the text view so it can never raise the
 * keyboard or touch the selection), keeping the caret above the keyboard, the line-number
 * gutter, and undo/redo as small edits rather than whole-text copies.
 */
internal class CodeEditText(context: Context) : EditText(context) {

    // ---- callbacks to the Compose screen ----
    var onEdited: (() -> Unit)? = null
    var onCaret: ((line: Int, col: Int) -> Unit)? = null
    var onPinch: ((Float) -> Unit)? = null
    var onPinchEnd: (() -> Unit)? = null

    // ---- state ----
    private val density = resources.displayMetrics.density
    private val history = EditHistory()
    private var applying = false
    private var readOnlyMode = true
    private var ready = false
    var editCount = 0
        private set

    val canUndo: Boolean get() = history.canUndo
    val canRedo: Boolean get() = history.canRedo
    fun isModified(): Boolean = history.modified
    fun markSaved() = history.markSaved()

    private var pendStart = 0
    private var pendOld = ""
    private val watcher = object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            if (applying) return
            pendStart = start
            pendOld = if (count > 0) s.subSequence(start, start + count).toString() else ""
        }

        override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
            if (applying) return
            val new = if (count > 0) s.subSequence(start, start + count).toString() else ""
            history.record(start, pendOld, new, SystemClock.uptimeMillis())
        }

        override fun afterTextChanged(s: Editable) {
            editCount++
            onEdited?.invoke()
            if (ready) {
                // Typing (or a key, or an IME) moves the caret: let the view follow it. Edits
                // made by the app itself (find/replace, undo, load) decide for themselves.
                if (!applying && !programmaticEdit && !readOnlyMode) armFollow()
                removeCallbacks(caretRunnable)
                post(caretRunnable)
            }
        }
    }

    // ---- gutter ----
    private val gutterPad = 6f * density
    private var gutterDigits = 3
    private var gutterWidth = 0f
    private val gutterPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = GUTTER_COLOR
        textAlign = Paint.Align.RIGHT
        typeface = Typeface.MONOSPACE
    }
    private val gutterBg = Paint().apply { color = EDITOR_BG }
    private val sepPaint = Paint().apply { color = SEPARATOR_COLOR }

    // ---- scrolling ----
    private val scroller = OverScroller(context)
    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop
    private val maxFling = ViewConfiguration.get(context).scaledMaximumFlingVelocity
    private var velocity: VelocityTracker? = null
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var dragging = false
    private var blockScroll = false
    private val longPressRunnable = Runnable { blockScroll = true }

    // ---- who may move the viewport (see class doc) ----
    private var internalScroll = 0
    private var followUntil = 0L
    private var touching = false
    private var programmaticEdit = false
    private var programmaticSelect = false

    // ---- pinch ----
    private var multiTouch = false
    private var zooming = false
    private val scaleDetector = ScaleGestureDetector(
        context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
                zooming = true
                return true
            }

            override fun onScale(detector: ScaleGestureDetector): Boolean {
                onPinch?.invoke(detector.scaleFactor)
                return true
            }
        },
    )
    private var currentSp = 0f
    private var pendingScrollX = -1
    private var pendingScrollY = -1

    // Scroll position and text size as they were before the first zoom step that has not been
    // laid out yet. Every step is computed from these, so several steps between two layouts
    // (a fast pinch) compound correctly instead of each one starting from a stale scroll.
    private var zoomBasisPx = -1f
    private var zoomBasisX = 0
    private var zoomBasisY = 0

    // ---- colours and find matches, applied only around the visible lines ----
    private var hlSpans: List<HlSpan> = emptyList()
    private var hlText: String? = null
    private var hlEdit = -1
    private var matchStarts = IntArray(0)
    private var matchLen = 0
    private var matchCur = -1
    private var matchEdit = -1
    private var hlVersion = 0
    private var matchVersion = 0
    private val hlApplied = AppliedWindow()
    private val matchApplied = AppliedWindow()
    private val appliedHl = ArrayList<Any>()
    private val appliedMatch = ArrayList<Any>()
    private var decorPending = false
    private val decorRunnable = Runnable { applyDecor() }
    private val caretRunnable = Runnable { notifyCaret() }

    init {
        isSaveEnabled = false // never put a whole file into saved instance state
        background = null
        typeface = Typeface.MONOSPACE
        setTextColor(EDITOR_FG)
        highlightColor = 0x6640E0D0
        gravity = Gravity.TOP or Gravity.START
        // inputType first: it resets horizontal scrolling, which must stay on (no wrapping).
        inputType = InputType.TYPE_CLASS_TEXT or
            InputType.TYPE_TEXT_FLAG_MULTI_LINE or
            InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        setHorizontallyScrolling(true)
        includeFontPadding = false
        imeOptions = EditorInfo.IME_FLAG_NO_EXTRACT_UI or EditorInfo.IME_FLAG_NO_FULLSCREEN
        textDirection = View.TEXT_DIRECTION_LTR
        layoutDirection = View.LAYOUT_DIRECTION_LTR
        isVerticalScrollBarEnabled = true
        overScrollMode = View.OVER_SCROLL_NEVER
        filters = arrayOf(
            InputFilter { _, _, _, dest, dstart, dend ->
                if (!readOnlyMode || applying) null else dest.subSequence(dstart, dend)
            },
        )
        setShowSoftInputOnFocus(false)
        setTextSizeSp(13f)
        addTextChangedListener(watcher)
        ready = true
    }

    // =====================================================================================
    // Content
    // =====================================================================================

    fun textString(): String = text.toString()

    fun textLength(): Int = text.length

    fun firstLine(): String {
        val ed = text
        val n = minOf(ed.length, 200)
        val sb = StringBuilder()
        for (i in 0 until n) {
            val c = ed[i]
            if (c == '\n') break
            sb.append(c)
        }
        return sb.toString()
    }

    fun setContent(content: String) {
        applying = true
        try {
            setText(content, android.widget.TextView.BufferType.EDITABLE)
        } finally {
            applying = false
        }
        history.reset()
        hlSpans = emptyList()
        hlText = null
        hlEdit = -1
        matchStarts = IntArray(0)
        matchLen = 0
        matchCur = -1
        matchEdit = -1
        appliedHl.clear()
        appliedMatch.clear()
        hlApplied.reset()
        matchApplied.reset()
        hlVersion++
        matchVersion++
        // A different document: start at its top, and drop anything still queued for the old one.
        scroller.forceFinished(true)
        pendingScrollX = -1
        pendingScrollY = -1
        zoomBasisPx = -1f
        followUntil = 0L
        selectQuietly(0, 0)
        scrollInternal(0, 0)
        onEdited?.invoke()
        scheduleDecor(0L)
    }

    fun setReadOnlyMode(readOnly: Boolean) {
        if (readOnlyMode == readOnly) return
        readOnlyMode = readOnly
        setShowSoftInputOnFocus(!readOnly)
        if (readOnly) {
            val imm = context.getSystemService(InputMethodManager::class.java)
            imm?.hideSoftInputFromWindow(windowToken, 0)
        }
    }

    // ---- undo / redo ----

    fun undo() {
        val e = history.undo() ?: return
        replaceSilently(e.start, e.new.length, e.old)
    }

    fun redo() {
        val e = history.redo() ?: return
        replaceSilently(e.start, e.old.length, e.new)
    }

    private fun replaceSilently(start: Int, removeLen: Int, insert: String) {
        val ed = text
        val s = start.coerceIn(0, ed.length)
        val e = (start + removeLen).coerceIn(s, ed.length)
        applying = true
        try {
            ed.replace(s, e, insert)
        } finally {
            applying = false
        }
        selectQuietly((s + insert.length).coerceAtMost(text.length))
        followCaret() // undo/redo should show what it changed
    }

    // ---- editing from the find/replace bar ----

    fun replaceRange(start: Int, length: Int, replacement: String) {
        val ed = text
        val s = start.coerceIn(0, ed.length)
        val e = (start + length).coerceIn(s, ed.length)
        programmaticEdit = true
        try {
            ed.replace(s, e, replacement)
        } finally {
            programmaticEdit = false
        }
        selectQuietly((s + replacement.length).coerceAtMost(text.length))
        followCaret() // "Replace" steps to the next spot; keep it on screen
    }

    fun replaceAllText(newText: String) {
        val ed = text
        val caret = selectionEnd.coerceAtLeast(0)
        // Remember which line is at the top of the screen, and how far into it we are, so the
        // same line stays there however many lines the replacement adds or removes above it.
        val old = layout
        var anchorLine = -1
        var anchorDelta = 0
        if (old != null && old.lineCount > 0) {
            anchorLine = old.getLineForVertical((scrollY - totalPaddingTop).coerceAtLeast(0))
            anchorDelta = scrollY - (old.getLineTop(anchorLine) + totalPaddingTop)
        }
        programmaticEdit = true
        try {
            ed.replace(0, ed.length, newText)
        } finally {
            programmaticEdit = false
        }
        selectQuietly(caret.coerceAtMost(text.length))
        val l = layout
        if (anchorLine >= 0 && l != null && l.lineCount > 0) {
            val line = anchorLine.coerceAtMost(l.lineCount - 1)
            val y = (l.getLineTop(line) + totalPaddingTop + anchorDelta).coerceIn(0, maxScrollY())
            scrollInternal(scrollX, y)
        }
    }

    // =====================================================================================
    // Colours and matches
    // =====================================================================================

    /**
     * [atEdit] is [editCount] when the text handed to the highlighter was taken. A result for
     * text that has since changed is dropped; the colours already on screen keep following the
     * text (Android shifts spans as the text is edited) until a fresh pass replaces them.
     */
    fun setHighlight(result: HlResult?, atEdit: Int) {
        if (result == null) {
            hlSpans = emptyList()
            hlText = null
            hlEdit = -1
            hlVersion++
            hlApplied.reset()
            removeApplied(appliedHl)
            return
        }
        if (atEdit != editCount) return
        // Outer ranges first, so an inner token's colour is applied after (and wins over) its parent's.
        hlSpans = result.spans.sortedWith(compareBy<HlSpan>({ it.start }, { -it.end }))
        hlText = result.text
        hlEdit = atEdit
        hlVersion++
        scheduleDecor(0L)
    }

    val hasHighlight: Boolean get() = hlText != null

    /** Match positions found in the text as it was at [atEdit]; stale results are dropped. */
    fun setMatches(starts: IntArray, length: Int, current: Int, atEdit: Int) {
        if (atEdit != editCount) return
        matchStarts = starts
        matchLen = length
        matchCur = current
        matchEdit = atEdit
        matchVersion++
        scheduleDecor(0L)
    }

    private fun removeApplied(list: ArrayList<Any>) {
        val ed = text
        for (sp in list) ed.removeSpan(sp)
        list.clear()
    }

    /** Selects a match and scrolls it into view, even when this view is not focused. */
    fun revealRange(start: Int, end: Int) {
        val len = text.length
        val s = start.coerceIn(0, len)
        selectQuietly(s, end.coerceIn(s, len))
        revealOffset(s)
    }

    private fun revealOffset(offset: Int) {
        val l = layout ?: return
        if (l.lineCount == 0) return
        val line = l.getLineForOffset(offset.coerceIn(0, text.length))
        val y = (l.getLineTop(line) + totalPaddingTop - height / 3).coerceIn(0, maxScrollY())
        val x = l.getPrimaryHorizontal(offset.coerceIn(0, text.length)).toInt() + totalPaddingLeft
        var sx = scrollX
        if (x - sx < gutterWidth + 24 * density || x - sx > width - 40 * density) {
            sx = x - width / 3
        }
        scrollInternal(0, y)
        scrollInternal(sx.coerceIn(0, maxScrollX()), y)
    }

    private fun scheduleDecor(delay: Long) {
        if (!ready || decorPending) return
        decorPending = true
        postDelayed(decorRunnable, delay)
    }

    private fun applyDecor() {
        decorPending = false
        val l = layout ?: return
        if (l.lineCount == 0) return
        val ed = text
        val off = totalPaddingTop
        val vFirst = l.getLineForVertical((scrollY - off).coerceAtLeast(0))
        val vLast = l.getLineForVertical((scrollY + height - off).coerceAtLeast(0)).coerceAtMost(l.lineCount - 1)
        val first = (vFirst - WINDOW_LINES).coerceAtLeast(0)
        val last = (vLast + WINDOW_LINES).coerceAtMost(l.lineCount - 1)
        val ws = l.getLineStart(first)
        val we = l.getLineEnd(last)
        val visStart = l.getLineStart(vFirst)
        val visEnd = l.getLineEnd(vLast)
        val len = ed.length

        // Colours and matches are laid down for the visible lines plus a margin. While the
        // visible lines stay inside what is already applied (ordinary scrolling) and the data
        // has not changed, nothing is touched at all: no span churn, no invalidation.
        //
        // Only replace what is on screen when the data is current; otherwise the old spans
        // stay and keep moving with the text until the fresh result arrives.
        if (hlEdit == editCount && hlText?.length == len &&
            !hlApplied.covers(hlVersion, editCount, visStart, visEnd)
        ) {
            removeApplied(appliedHl)
            for (sp in hlSpans) {
                if (sp.end > ws && sp.start < we && sp.end <= len && sp.start < sp.end) {
                    val span = HlColorSpan(sp.style.color.toArgb())
                    ed.setSpan(span, sp.start, sp.end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    appliedHl.add(span)
                }
            }
            hlApplied.set(ws, we, hlVersion, editCount)
        }
        if (matchEdit == editCount && !matchApplied.covers(matchVersion, editCount, visStart, visEnd)) {
            removeApplied(appliedMatch)
            if (matchLen > 0 && matchStarts.isNotEmpty()) {
                var i = lowerBound(matchStarts, ws - matchLen + 1)
                var n = 0
                while (i < matchStarts.size && matchStarts[i] < we && n < MAX_MATCH_SPANS) {
                    val st = matchStarts[i]
                    val en = st + matchLen
                    if (st >= 0 && en <= len) {
                        val span = MatchSpan(if (i == matchCur) MATCH_CUR_BG else MATCH_BG)
                        ed.setSpan(span, st, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                        appliedMatch.add(span)
                    }
                    i++
                    n++
                }
            }
            matchApplied.set(ws, we, matchVersion, editCount)
        }
    }

    private fun lowerBound(a: IntArray, value: Int): Int {
        var lo = 0
        var hi = a.size
        while (lo < hi) {
            val mid = (lo + hi) ushr 1
            if (a[mid] < value) lo = mid + 1 else hi = mid
        }
        return lo
    }

    // =====================================================================================
    // Zoom
    // =====================================================================================

    /** Sets the text size in sp, keeping the same part of the text on screen. */
    fun setTextSizeSp(sp: Float) {
        if (abs(sp - currentSp) < 0.01f) return
        // The first step after a layout remembers where we were; later steps before the next
        // layout keep using that, because scrollX/scrollY have not moved yet.
        if (ready && pendingScrollY < 0 && textSize > 0f) {
            zoomBasisPx = textSize
            zoomBasisX = scrollX
            zoomBasisY = scrollY
        }
        currentSp = sp
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        applyPadding()
        if (ready && zoomBasisPx > 0f) {
            val ratio = textSize / zoomBasisPx
            // Only the text scales; the top padding does not.
            val pad = paddingTop
            pendingScrollY = (((zoomBasisY - pad) * ratio) + pad).roundToInt().coerceAtLeast(0)
            pendingScrollX = (zoomBasisX * ratio).roundToInt().coerceAtLeast(0)
        }
    }

    private fun applyPadding() {
        gutterPaint.textSize = textSize
        gutterWidth = gutterPaint.measureText("0") * gutterDigits + gutterPad * 2f
        setPadding(
            (gutterWidth + gutterPad).toInt(),
            (8 * density).toInt(),
            (16 * density).toInt(),
            (56 * density).toInt(), // room to scroll the last line above the keyboard
        )
    }

    // =====================================================================================
    // Layout, drawing, caret
    // =====================================================================================

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (!ready) return
        // The keyboard rising resizes this view. If the caret was on screen a moment ago, keep
        // it on screen (it may now be under the keyboard). If the person had scrolled away from
        // it, the viewport is theirs: a resize alone never pulls it back to the caret.
        if (h < oldh && hasFocus() && !readOnlyMode && caretWithin(oldh)) {
            post { followCaret() }
        }
        scheduleDecor(0L)
    }

    override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
        super.onLayout(changed, left, top, right, bottom)
        if (!ready) return
        if (pendingScrollY >= 0) {
            val sy = pendingScrollY.coerceIn(0, maxScrollY())
            val sx = pendingScrollX.coerceIn(0, maxScrollX())
            pendingScrollX = -1
            pendingScrollY = -1
            zoomBasisPx = -1f
            scrollInternal(sx, sy)
        } else {
            // Content may have become shorter (delete, replace): never stay scrolled past the end.
            val sy = scrollY.coerceIn(0, maxScrollY())
            if (sy != scrollY) scrollInternal(scrollX, sy)
        }
        scheduleDecor(0L)
        notifyCaret()
    }

    override fun onScrollChanged(horiz: Int, vert: Int, oldHoriz: Int, oldVert: Int) {
        super.onScrollChanged(horiz, vert, oldHoriz, oldVert)
        if (ready && vert != oldVert) scheduleDecor(60L)
    }

    override fun onSelectionChanged(selStart: Int, selEnd: Int) {
        super.onSelectionChanged(selStart, selEnd)
        if (!ready) return
        notifyCaret()
        // A caret move that did not come from a finger on the text (keyboard keys, IME cursor
        // control, selection handles, a long-press drag) is followed. Taps and drags that
        // scroll never are: the finger is already where it wants the view to be.
        if (!applying && !programmaticSelect && !(touching && !blockScroll)) armFollow()
    }

    private fun notifyCaret() {
        val l = layout ?: return
        val cb = onCaret ?: return
        val off = selectionEnd
        if (off < 0 || off > text.length || l.lineCount == 0) return
        val line = l.getLineForOffset(off)
        cb(line + 1, off - l.getLineStart(line) + 1)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (!ready) return
        val l = layout ?: return
        val digits = maxOf(2, l.lineCount.toString().length)
        if (digits != gutterDigits) {
            gutterDigits = digits
            post { applyPadding() }
        }
        val left = scrollX.toFloat()
        val top = scrollY.toFloat()
        val bottom = top + height
        // Pinned to the left edge however far the text is scrolled sideways.
        canvas.drawRect(left, top, left + gutterWidth, bottom, gutterBg)
        canvas.drawRect(left + gutterWidth - 1f, top, left + gutterWidth, bottom, sepPaint)
        if (l.lineCount == 0) return
        val off = totalPaddingTop
        val first = l.getLineForVertical((scrollY - off).coerceAtLeast(0))
        val last = l.getLineForVertical((scrollY + height - off).coerceAtLeast(0))
        val x = left + gutterWidth - gutterPad
        for (i in first..last) {
            canvas.drawText((i + 1).toString(), x, (l.getLineBaseline(i) + off).toFloat(), gutterPaint)
        }
        // The pre-draw pass that may follow the caret has run by now; close the window.
        followUntil = 0L
    }

    // =====================================================================================
    // Scroll ownership
    // =====================================================================================

    /** Moves the viewport on our own authority (drag, fling, reveal, restore). */
    private fun scrollInternal(x: Int, y: Int) {
        internalScroll++
        try {
            scrollTo(x, y)
        } finally {
            internalScroll--
        }
    }

    private fun followActive(): Boolean = SystemClock.uptimeMillis() < followUntil

    /**
     * Lets the text view's own caret-following run for the next frame. Called when the caret
     * moved, or the person edited, and nothing else - never for a plain scroll gesture.
     */
    private fun armFollow() {
        followUntil = SystemClock.uptimeMillis() + FOLLOW_WINDOW_MS
        invalidate() // guarantees a frame, whose draw closes the window again
    }

    /** Scrolls the minimum needed to show the caret. */
    private fun followCaret() {
        if (!ready || layout == null) return
        armFollow()
        bringPointIntoView(selectionEnd)
    }

    private fun selectQuietly(start: Int, end: Int = start) {
        programmaticSelect = true
        try {
            val len = text.length
            setSelection(start.coerceIn(0, len), end.coerceIn(0, len))
        } finally {
            programmaticSelect = false
        }
    }

    /** True when the caret's line intersects a viewport of [viewHeight] at the current scroll. */
    private fun caretWithin(viewHeight: Int): Boolean {
        val l = layout ?: return false
        val off = selectionEnd
        if (off < 0 || off > text.length || l.lineCount == 0) return false
        val line = l.getLineForOffset(off)
        val top = l.getLineTop(line) + totalPaddingTop
        val bottom = l.getLineBottom(line) + totalPaddingTop
        return bottom > scrollY && top < scrollY + viewHeight
    }

    /** The only door through which the framework's self-scrolling (Touch, bringPointIntoView, ...) passes. */
    override fun scrollTo(x: Int, y: Int) {
        if (internalScroll > 0 || followActive()) super.scrollTo(x, y)
    }

    override fun bringPointIntoView(offset: Int): Boolean {
        if (!followActive()) return false
        return super.bringPointIntoView(offset)
    }

    // The caret-follow ends by asking ancestors to scroll the caret into view as well; nobody
    // above this view scrolls, and that request is how focus changes used to nudge things.
    override fun requestRectangleOnScreen(rectangle: Rect, immediate: Boolean): Boolean {
        if (!followActive() && internalScroll == 0) return false
        return super.requestRectangleOnScreen(rectangle, immediate)
    }

    // Accessibility scroll actions are explicit requests to move the viewport.
    override fun performAccessibilityAction(action: Int, arguments: Bundle?): Boolean {
        internalScroll++
        try {
            return super.performAccessibilityAction(action, arguments)
        } finally {
            internalScroll--
        }
    }

    // Pasting keeps only the characters: copied text can carry colour spans from elsewhere that
    // this view would never clean up.
    override fun onTextContextMenuItem(id: Int): Boolean {
        val mapped = if (id == android.R.id.paste) android.R.id.pasteAsPlainText else id
        return super.onTextContextMenuItem(mapped)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(decorRunnable)
        removeCallbacks(caretRunnable)
        removeCallbacks(longPressRunnable)
        scroller.forceFinished(true)
        followUntil = 0L
        super.onDetachedFromWindow()
    }

    // =====================================================================================
    // Touch: scroll + fling, pinch, and everything else left to the text view
    // =====================================================================================

    private fun maxScrollY(): Int {
        val l = layout ?: return 0
        return (l.height + totalPaddingTop + totalPaddingBottom - height).coerceAtLeast(0)
    }

    private fun maxScrollX(): Int {
        val l = layout ?: return 0
        if (l.lineCount == 0) return 0
        val top = (scrollY - totalPaddingTop).coerceAtLeast(0)
        val first = l.getLineForVertical(top)
        val last = l.getLineForVertical(top + height)
        var right = 0f
        for (i in first..last) right = maxOf(right, l.getLineRight(i))
        return (ceil(right.toDouble()).toInt() + totalPaddingLeft + totalPaddingRight - width).coerceAtLeast(0)
    }

    override fun computeScroll() {
        super.computeScroll()
        if (scroller.computeScrollOffset()) {
            scrollInternal(scroller.currX, scroller.currY)
            postInvalidateOnAnimation()
        }
    }

    private fun cancelForTextView(ev: MotionEvent) {
        val c = MotionEvent.obtain(ev)
        c.action = MotionEvent.ACTION_CANCEL
        super.onTouchEvent(c)
        c.recycle()
    }

    private fun endDrag() {
        removeCallbacks(longPressRunnable)
        dragging = false
        velocity?.recycle()
        velocity = null
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        val action = ev.actionMasked
        if (action == MotionEvent.ACTION_DOWN) touching = true
        try {
            return handleTouch(ev)
        } finally {
            // After the handler: a tap places the caret inside ACTION_UP and must still count as touch.
            if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) touching = false
        }
    }

    private fun handleTouch(ev: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(ev)
        val action = ev.actionMasked
        if (action == MotionEvent.ACTION_DOWN) multiTouch = false

        // Two fingers: this is a pinch. The text view gets a cancel and then never hears of
        // the gesture again, so it cannot raise the keyboard or move the selection.
        if (ev.pointerCount > 1 || scaleDetector.isInProgress || multiTouch) {
            if (!multiTouch) {
                multiTouch = true
                endDrag()
                scroller.forceFinished(true)
                cancelForTextView(ev)
            }
            if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                multiTouch = false
                if (zooming) {
                    zooming = false
                    onPinchEnd?.invoke()
                }
            }
            return true
        }

        when (action) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                scroller.forceFinished(true)
                dragging = false
                blockScroll = false
                downX = ev.x
                downY = ev.y
                lastX = ev.x
                lastY = ev.y
                velocity?.recycle()
                velocity = VelocityTracker.obtain().also { it.addMovement(ev) }
                removeCallbacks(longPressRunnable)
                postDelayed(longPressRunnable, ViewConfiguration.getLongPressTimeout().toLong())
                return super.onTouchEvent(ev)
            }

            MotionEvent.ACTION_MOVE -> {
                velocity?.addMovement(ev)
                if (!dragging && !blockScroll &&
                    (abs(ev.x - downX) > touchSlop || abs(ev.y - downY) > touchSlop)
                ) {
                    dragging = true
                    removeCallbacks(longPressRunnable)
                    cancelForTextView(ev) // a drag is scrolling, not placing the caret
                }
                if (dragging) {
                    val dx = (lastX - ev.x).roundToInt()
                    val dy = (lastY - ev.y).roundToInt()
                    lastX -= dx
                    lastY -= dy
                    if (dx != 0 || dy != 0) {
                        val ny = (scrollY + dy).coerceIn(0, maxScrollY())
                        scrollInternal(scrollX, ny)
                        scrollInternal((scrollX + dx).coerceIn(0, maxScrollX()), ny)
                    }
                    return true
                }
                // Still inside the touch slop. The text view only needs to hear about this
                // when a long-press selection drag is under way; otherwise its movement method
                // would start scrolling by itself, in parallel with ours, and fight it.
                return if (blockScroll) super.onTouchEvent(ev) else true
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(longPressRunnable)
                if (dragging) {
                    val vt = velocity
                    if (vt != null && action == MotionEvent.ACTION_UP) {
                        vt.computeCurrentVelocity(1000, maxFling.toFloat())
                        val vx = -vt.xVelocity.toInt()
                        val vy = -vt.yVelocity.toInt()
                        scroller.fling(scrollX, scrollY, vx, vy, 0, maxScrollX(), 0, maxScrollY())
                        postInvalidateOnAnimation()
                    }
                    endDrag()
                    return true
                }
                endDrag()
                return super.onTouchEvent(ev)
            }
        }
        return super.onTouchEvent(ev)
    }

    private companion object {
        const val WINDOW_LINES = 60
        const val FOLLOW_WINDOW_MS = 300L
        const val MAX_MATCH_SPANS = 1500
        const val GUTTER_COLOR = 0xFF636D83.toInt()
        const val SEPARATOR_COLOR = 0xFF3A3F4B.toInt()
    }
}
