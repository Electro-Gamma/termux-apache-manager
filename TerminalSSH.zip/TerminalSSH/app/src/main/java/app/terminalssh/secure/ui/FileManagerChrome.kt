package app.terminalssh.secure.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Dns
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import app.terminalssh.secure.R
import app.terminalssh.secure.sftp.Selection
import app.terminalssh.secure.ui.theme.TextSecondary
import app.terminalssh.secure.ui.theme.Turquoise

/**
 * Top bar of the Files tab.
 *
 * Normal mode: parent-folder arrow, the "File Manager" title and a three-dot menu with
 * the folder-level options. Selection mode: a close button, "N selected" and the same
 * three-dot slot, now holding the actions for the selection. Either way every command
 * lives in that one menu rather than in a toolbar.
 */
@Composable
fun FileManagerTopBar(
    selection: Selection,
    currentPath: String,
    canGoUp: Boolean,
    onGoUp: () -> Unit,
    onExitSelection: () -> Unit,
    menuContent: @Composable ColumnScope.(closeMenu: () -> Unit) -> Unit,
) {
    var menuOpen by remember { mutableStateOf(false) }
    // The menu changes meaning when the mode flips, so a menu left open is closed with it.
    LaunchedEffect(selection.isActive) { menuOpen = false }

    Row(
        Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (selection.isActive) {
            IconButton(onClick = onExitSelection) {
                Icon(
                    Icons.Outlined.Close,
                    stringResource(R.string.sftp_selection_exit),
                    tint = MaterialTheme.colorScheme.onSurface,
                )
            }
        } else {
            IconButton(onClick = onGoUp, enabled = canGoUp) {
                Icon(
                    Icons.AutoMirrored.Outlined.ArrowBack,
                    stringResource(R.string.sftp_go_up),
                    tint = if (canGoUp) {
                        MaterialTheme.colorScheme.onSurface
                    } else {
                        TextSecondary.copy(alpha = 0.38f)
                    },
                )
            }
        }

        Column(Modifier.weight(1f).padding(horizontal = 8.dp)) {
            if (selection.isActive) {
                Text(
                    stringResource(R.string.sftp_selected_count, selection.count),
                    style = MaterialTheme.typography.titleLarge,
                    maxLines = 1,
                )
                val elsewhere = selection.countOutside(currentPath)
                if (elsewhere > 0) {
                    Text(
                        stringResource(R.string.sftp_selected_elsewhere, elsewhere),
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary,
                        maxLines = 1,
                    )
                }
            } else {
                Text(
                    stringResource(R.string.sftp_title),
                    style = MaterialTheme.typography.titleLarge,
                    maxLines = 1,
                )
            }
        }

        Box {
            IconButton(onClick = { menuOpen = true }) {
                Icon(
                    Icons.Outlined.MoreVert,
                    stringResource(R.string.sftp_menu_more),
                    tint = MaterialTheme.colorScheme.onSurface,
                )
            }
            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                menuContent { menuOpen = false }
            }
        }
    }
}

/** One row of the three-dot menu. Closes the menu, then runs [onClick]. */
@Composable
fun MenuEntry(
    icon: ImageVector,
    label: String,
    closeMenu: () -> Unit,
    enabled: Boolean = true,
    tint: Color? = null,
    checked: Boolean = false,
    onClick: () -> Unit,
) {
    val iconTint = tint ?: MaterialTheme.colorScheme.onSurfaceVariant
    val trailing: (@Composable () -> Unit)? = if (checked) {
        { Icon(Icons.Outlined.Check, contentDescription = null, tint = Turquoise) }
    } else {
        null
    }
    DropdownMenuItem(
        text = {
            Text(
                label,
                color = tint ?: MaterialTheme.colorScheme.onSurface,
            )
        },
        onClick = {
            closeMenu()
            onClick()
        },
        enabled = enabled,
        leadingIcon = { Icon(icon, contentDescription = null, tint = iconTint) },
        trailingIcon = trailing,
    )
}
