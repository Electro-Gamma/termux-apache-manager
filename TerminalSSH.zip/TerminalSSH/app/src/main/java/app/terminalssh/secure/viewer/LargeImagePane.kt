package app.terminalssh.secure.viewer

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import app.terminalssh.secure.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Images up to this size go through the WebView (animated GIFs included); bigger ones are decoded natively. */
private const val WEBVIEW_IMAGE_BYTES = 4L * 1024 * 1024
private const val WEBVIEW_GIF_BYTES = 10L * 1024 * 1024

/** Whether [file] is small enough for the WebView viewer (it must be embedded in the page as base64). */
internal fun imageFitsWebView(file: File): Boolean {
    val head = ByteArray(16)
    val n = file.inputStream().use { it.read(head).coerceAtLeast(0) }
    val mime = sniffImageMime(head.copyOf(n))
    val limit = if (mime == "image/gif") WEBVIEW_GIF_BYTES else WEBVIEW_IMAGE_BYTES
    return file.length() <= limit
}

// A decoded bitmap costs 4 bytes per pixel whatever the file size, so large images are
// decoded at a reduced size: at most this many pixels, and at most this long a side.
private const val MAX_PIXELS = 8_000_000L
private const val MAX_SIDE = 4096
private const val MAX_ZOOM = 8f

private fun decodeScaled(file: File): Bitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(file.path, bounds)
    val w = bounds.outWidth
    val h = bounds.outHeight
    if (w <= 0 || h <= 0) return null
    var sample = 1
    while (w / sample > MAX_SIDE || h / sample > MAX_SIDE || (w / sample).toLong() * (h / sample) > MAX_PIXELS) sample *= 2
    val options = BitmapFactory.Options().apply { inSampleSize = sample }
    val bitmap = try {
        BitmapFactory.decodeFile(file.path, options)
    } catch (e: OutOfMemoryError) {
        return null
    } ?: return null
    return applyOrientation(file, bitmap)
}

/** BitmapFactory ignores EXIF rotation (a phone photo would lie on its side); the WebView path honours it. */
private fun applyOrientation(file: File, bitmap: Bitmap): Bitmap {
    val orientation = runCatching {
        ExifInterface(file.path).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
    }.getOrDefault(ExifInterface.ORIENTATION_NORMAL)
    val m = Matrix()
    when (orientation) {
        ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
        ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
        ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
        ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
        ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
        ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
        ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(270f); m.postScale(-1f, 1f) }
        else -> return bitmap
    }
    return try {
        Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, m, true).also { if (it !== bitmap) bitmap.recycle() }
    } catch (e: OutOfMemoryError) {
        bitmap
    }
}

/**
 * A large image from its downloaded file, decoded at a bounded size so memory stays flat however
 * big the file is. Pinch to zoom, drag to pan, double-tap to toggle. (An animated GIF this big
 * shows its first frame.)
 */
@Composable
internal fun LargeImagePane(file: File?, dark: Boolean, modifier: Modifier = Modifier) {
    val backdrop = if (dark) Color(0xFF0D1117) else Color.White
    // (finished, bitmap): a null bitmap after "finished" means the file could not be decoded.
    val decoded by produceState(false to (null as Bitmap?), file) {
        val result = if (file == null) null else withContext(Dispatchers.IO) { runCatching { decodeScaled(file) }.getOrNull() }
        value = true to result
        awaitDispose { result?.let { if (!it.isRecycled) it.recycle() } }
    }
    val failed = decoded.first
    val bmp = decoded.second
    Box(modifier.fillMaxSize().background(backdrop), contentAlignment = Alignment.Center) {
        if (bmp == null) {
            Text(
                stringResource(if (failed) R.string.viewer_cannot_display else R.string.editor_loading),
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.padding(24.dp),
            )
            return@Box
        }
        var scale by remember(bmp) { mutableFloatStateOf(1f) }
        var offset by remember(bmp) { mutableStateOf(Offset.Zero) }
        var box by remember { mutableStateOf(androidx.compose.ui.unit.IntSize.Zero) }
        fun clamp(o: Offset, s: Float): Offset {
            val maxX = box.width * (s - 1f) / 2f
            val maxY = box.height * (s - 1f) / 2f
            return Offset(o.x.coerceIn(-maxX, maxX), o.y.coerceIn(-maxY, maxY))
        }
        Image(
            bitmap = bmp.asImageBitmap(),
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .fillMaxSize()
                .onSizeChanged { box = it }
                .pointerInput(bmp) {
                    detectTapGestures(onDoubleTap = {
                        if (scale > 1f) { scale = 1f; offset = Offset.Zero } else scale = 3f
                    })
                }
                .pointerInput(bmp) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        scale = (scale * zoom).coerceIn(1f, MAX_ZOOM)
                        offset = clamp(offset + pan * scale, scale)
                    }
                }
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                    translationX = offset.x
                    translationY = offset.y
                },
        )
    }
}
