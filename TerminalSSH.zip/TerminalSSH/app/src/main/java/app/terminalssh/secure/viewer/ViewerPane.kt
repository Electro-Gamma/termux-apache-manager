package app.terminalssh.secure.viewer

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.view.View
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.UUID

/**
 * The rendered view of a file. The WebView stays alive while the person looks at the source,
 * so coming back to the Viewer keeps the scroll position (the page is only rebuilt when the
 * text actually changed). While [visible] is false it is hidden and does no rendering work.
 *
 * Locked down on purpose: it runs on remote file content. No network loads, no file or
 * content access, no storage; links open in the system browser only when tapped.
 */
@Composable
internal fun ViewerPane(
    kind: ViewerKind,
    text: String?,
    bytes: ByteArray?,
    visible: Boolean,
    dark: Boolean,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    // One nonce per pane keeps the page string identical for identical content, so an
    // unchanged document is never reloaded (which would reset its scroll position).
    val nonce = remember { UUID.randomUUID().toString().replace("-", "") }
    val page by produceState<String?>(initialValue = null, kind, text, bytes, dark, visible) {
        if (!visible) return@produceState // keep what is there; render when it is shown again
        value = withContext(Dispatchers.Default) {
            ViewerRenderer.page(ViewerRenderer.body(kind, text, bytes), dark, ViewerRenderer.assets(context), nonce)
        }
    }
    val bg = if (dark) 0xFF0D1117.toInt() else 0xFFFFFFFF.toInt()

    AndroidView(
        modifier = modifier.fillMaxSize(),
        factory = { ctx ->
            WebView(ctx).apply {
                settings.javaScriptEnabled = true // highlighting only; page scripts are blocked by the CSP
                settings.allowFileAccess = false
                settings.allowContentAccess = false
                settings.domStorageEnabled = false
                settings.blockNetworkLoads = true
                settings.setSupportMultipleWindows(false)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) settings.safeBrowsingEnabled = false
                // Two-finger pinch zoom, no on-screen buttons.
                settings.useWideViewPort = true
                settings.setSupportZoom(true)
                settings.builtInZoomControls = true
                settings.displayZoomControls = false
                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                        val url: Uri = request.url
                        if (url.scheme.orEmpty() in setOf("http", "https", "mailto") && request.hasGesture()) {
                            try {
                                ctx.startActivity(Intent(Intent.ACTION_VIEW, url).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            } catch (_: Exception) {
                            }
                        }
                        return true // never navigate inside the viewer
                    }
                }
            }
        },
        update = { web ->
            web.setBackgroundColor(bg)
            web.visibility = if (visible) View.VISIBLE else View.INVISIBLE
            val p = page
            if (p != null && web.tag != p) {
                web.tag = p
                web.loadDataWithBaseURL("https://viewer.invalid/", p, "text/html", "utf-8", null)
            }
        },
        onRelease = { it.destroy() },
    )
}
