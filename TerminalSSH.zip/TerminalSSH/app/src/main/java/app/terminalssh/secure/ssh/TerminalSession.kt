package app.terminalssh.secure.ssh

import app.terminalssh.secure.ui.theme.TerminalPalette
import kotlinx.coroutines.flow.StateFlow
import org.connectbot.terminal.TerminalEmulator

/**
 * What a terminal tab needs from whatever is behind it. An SSH shell and a UART serial port
 * both show up as a tab with a screen, a status and a keyboard, so the Terminal screen is
 * written against this and never needs to know which one it is talking to.
 */
interface TerminalSession {
    val id: String

    /** The saved connection this session belongs to (host id, or UART profile id). */
    val hostId: String
    val title: String

    /** The short line at the right of the status bar: `user@host:port`, or `115200 8N1`. */
    val subtitle: String
    val state: StateFlow<SshSessionState>
    val emulator: TerminalEmulator
    val ctrlLatched: StateFlow<Boolean>
    val altLatched: StateFlow<Boolean>

    /** When anything last moved in either direction; the idle-disconnect timer measures from here. */
    val lastActivityAt: Long

    /** Whether "reopen last sessions" at launch can bring this one back. */
    val restorable: Boolean

    fun toggleCtrl()
    fun toggleAlt()
    fun send(bytes: ByteArray)
    fun send(text: String)
    fun sendKey(bytes: ByteArray)
    fun sendKey(text: String)
    fun requestPaste()
    fun applyPalette(palette: TerminalPalette)
    fun applyCursorStyle(style: String, blink: Boolean)
    fun clearScreen()
    fun disconnect()
    fun destroy()
}
