package app.terminalssh.secure.ssh

import android.content.ContentResolver
import app.terminalssh.secure.sftp.SftpController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * One server's File Manager: its connection plus everything the user has going on in it
 * (current folder, selection, clipboard, transfers, batch operations).
 *
 * It lives in the Application, not in a screen. Leaving the Files tab, minimising the
 * app or recreating the Activity changes nothing here; the folder, the queue and any
 * running transfer carry on, and the screen simply reattaches to them. It ends only
 * through [destroy], which the user triggers by disconnecting.
 */
class FileWorkspace(
    val session: FileSession,
    contentResolver: ContentResolver,
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    val controller = SftpController(session, contentResolver, scope)

    val id: String get() = session.id
    val profile get() = session.profile

    init {
        scope.launch {
            var loadedOnce = false
            session.state.collect { state ->
                if (state is SshSessionState.Connected) {
                    if (!loadedOnce) {
                        loadedOnce = true
                        controller.openHome()
                    } else {
                        // Back after a drop: stay in the same folder and refresh it.
                        controller.refresh()
                    }
                }
            }
        }
    }

    fun destroy() {
        controller.close()
        session.destroy()
        scope.cancel()
    }
}
