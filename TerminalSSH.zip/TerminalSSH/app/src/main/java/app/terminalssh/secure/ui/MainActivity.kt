package app.terminalssh.secure.ui

import android.os.Bundle
import androidx.activity.OnBackPressedCallback
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.terminalssh.secure.settings.SettingsRegistry
import app.terminalssh.secure.R
import android.content.Intent
import app.terminalssh.secure.TerminalApp
import app.terminalssh.secure.service.HostShortcuts
import app.terminalssh.secure.ui.theme.TerminalTheme
import app.terminalssh.secure.vm.AppViewModel
import java.util.Locale

/**
 * [FragmentActivity] rather than ComponentActivity because BiometricPrompt hosts itself
 * in a fragment; it is still a ComponentActivity, so Compose and `by viewModels()` work
 * exactly as before.
 */
class MainActivity : FragmentActivity() {

    private val viewModel: AppViewModel by viewModels()

    /**
     * Held on the Activity rather than created inside the composable: state created
     * during composition is rebuilt on every recomposition, which would snap the app
     * straight back to locked the moment anything above it recomposed.
     */
    private var locked by mutableStateOf(false)

    /** Guards against re-prompting while a prompt is already on screen. */
    private var prompting = false

    /** Host id from a launcher shortcut, if the app was opened through one. */
    private var launchHostId by mutableStateOf<String?>(null)

    private val lockEnabled: Boolean
        get() = (application as TerminalApp).settings.biometricLock &&
            AppLock.availability(this) == LockAvailability.AVAILABLE

    override fun onCreate(savedInstanceState: Bundle?) {
        // Must run before super.onCreate: it swaps SplashTheme for AppTheme, and after
        // super it would be too late for the system to apply the post-splash theme.
        installSplashScreen()
        super.onCreate(savedInstanceState)
        // Keep the terminal out of screenshots, recents previews and screen recordings,
        // unless the user has allowed screenshots in Settings.
        applyScreenshotPolicy()
        // The app is dark-only, so the bars must always use light icons. The default "auto"
        // style follows the phone's light/dark mode and would draw dark clock, signal and
        // battery icons on the black UI when the phone is in light mode.
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )

        // Back from the top level must not finish the Activity while a terminal or File
        // Manager is connected: finishing is how a session used to be lost by accident. The
        // app moves to the background instead and everything keeps running. With nothing
        // connected, Back behaves as it always did. Compose's own BackHandlers (leaving a
        // tab, leaving selection mode) are registered later and so still take precedence.
        onBackPressedDispatcher.addCallback(
            this,
            object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    if ((application as TerminalApp).hasBackgroundWork()) {
                        moveTaskToBack(true)
                    } else {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            },
        )

        // A rotation re-runs onCreate; only lock on a genuinely fresh start.
        if (savedInstanceState == null) locked = lockEnabled
        launchHostId = intent?.getStringExtra(HostShortcuts.EXTRA_HOST_ID)

        val rtl = Locale.getDefault().language == "fa"
        setContent {
            // Follows the setting live, so the switch takes effect the moment it is flipped
            // rather than the next time the app is opened.
            val settingsRevision by (application as TerminalApp).settingsStore.revision
                .collectAsStateWithLifecycle()
            LaunchedEffect(settingsRevision) { applyScreenshotPolicy() }

            TerminalTheme {
                CompositionLocalProvider(
                    LocalLayoutDirection provides if (rtl) LayoutDirection.Rtl else LayoutDirection.Ltr,
                ) {
                    if (locked) {
                        // The prompt itself is raised from onResume, never from here: a
                        // composition effect can run while the app is still in the
                        // background, where the system drops the prompt and leaves only
                        // this screen. The button is the way back after a cancel, and
                        // always starts a fresh prompt.
                        LockScreen(onUnlock = { authenticate(force = true) })
                    } else {
                        RootScreen(viewModel, launchHostId = launchHostId)
                    }
                }
            }
        }
    }

    /**
     * Re-arm the lock whenever the app leaves the foreground. Locking only at cold start
     * would leave the content readable to anyone who picks the phone up mid-session,
     * which is the case the lock exists for.
     */
    /**
     * FLAG_SECURE is what makes Android refuse screenshots and screen recording and blank
     * the app in the recent-apps list. It is on unless "Allow screenshots" is enabled.
     */
    private fun applyScreenshotPolicy() {
        val allowed = (application as TerminalApp).settingsStore.get(SettingsRegistry.allowScreenshots)
        if (allowed) {
            window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        } else {
            window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }
    }

    override fun onStart() {
        super.onStart()
        // Every time the app opens (or comes back to the front), ask each configured
        // server whether it answers. Rate-limited so a quick app switch doesn't repeat it.
        viewModel.refreshReachability()
    }

    override fun onStop() {
        super.onStop()
        if (lockEnabled && !isChangingConfigurations) locked = true
    }

    /**
     * Every time the app is in front and locked, the configured method (fingerprint, PIN,
     * pattern or password, whichever the device has) is raised right away. onResume rather
     * than onCreate or a composable: it runs on cold start and on every return from the
     * background, at a moment the prompt can actually be shown.
     */
    override fun onResume() {
        super.onResume()
        if (locked) authenticate()
    }

    /** singleTask means a second shortcut tap arrives here, not through onCreate. */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        launchHostId = intent.getStringExtra(HostShortcuts.EXTRA_HOST_ID)
    }

    /** Identifies the current prompt, so a late result from a replaced one is ignored. */
    private var promptToken = 0
    private var activePrompt: androidx.biometric.BiometricPrompt? = null

    /**
     * @param force the user tapped Unlock: drop whatever prompt state is left over and ask
     *   again, so a prompt the system dismissed without telling us can never leave the
     *   button doing nothing.
     */
    private fun authenticate(force: Boolean = false) {
        if (prompting && !force) return
        if (force) {
            runCatching { activePrompt?.cancelAuthentication() }
            activePrompt = null
        }
        prompting = true
        val token = ++promptToken
        activePrompt = AppLock.prompt(
            activity = this,
            title = getString(R.string.lock_title),
            subtitle = getString(R.string.lock_subtitle),
        ) { ok ->
            if (token != promptToken) return@prompt
            prompting = false
            activePrompt = null
            if (ok) locked = false
        }
    }

    override fun onDestroy() {
        // Sessions intentionally outlive the Activity, even when it is finishing (the user
        // swiped the app away, the system reclaimed the screen): they belong to the
        // Application and its foreground service, and a connection ending because a window
        // closed is exactly what must not happen. They end only through an explicit
        // disconnect or close, or "Disconnect all" in the notification.
        super.onDestroy()
    }
}
