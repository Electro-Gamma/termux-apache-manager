package app.terminalssh.secure.uart

import com.hoho.android.usbserial.driver.UsbSerialPort

enum class DataBits(val value: Int, val label: String) {
    FIVE(5, "5"),
    SIX(6, "6"),
    SEVEN(7, "7"),
    EIGHT(8, "8"),
}

enum class StopBits(val libValue: Int, val label: String) {
    ONE(UsbSerialPort.STOPBITS_1, "1"),
    ONE_POINT_FIVE(UsbSerialPort.STOPBITS_1_5, "1.5"),
    TWO(UsbSerialPort.STOPBITS_2, "2"),
}

enum class Parity(val libValue: Int, val label: String, val letter: Char) {
    NONE(UsbSerialPort.PARITY_NONE, "None", 'N'),
    ODD(UsbSerialPort.PARITY_ODD, "Odd", 'O'),
    EVEN(UsbSerialPort.PARITY_EVEN, "Even", 'E'),
}

enum class FlowControl(val label: String) {
    NONE("None"),
    XON_XOFF("XON/XOFF"),
    RTS_CTS("RTS/CTS"),
}

/**
 * Everything needed to configure a serial port, plus the two handshaking lines (DTR/RTS)
 * some adapters and boards rely on. Defaults are 115200 8N1 without flow control, the usual
 * Linux serial-console configuration on embedded boards.
 */
data class SerialSettings(
    val baudRate: Int = 115200,
    val dataBits: DataBits = DataBits.EIGHT,
    val stopBits: StopBits = StopBits.ONE,
    val parity: Parity = Parity.NONE,
    val flowControl: FlowControl = FlowControl.NONE,
    val dtrEnabled: Boolean = true,
    val rtsEnabled: Boolean = true,
) {
    /** The conventional short form: `115200 8N1`, with the flow control appended when there is one. */
    val summary: String
        get() = "$baudRate ${dataBits.value}${parity.letter}${stopBits.label}" +
            if (flowControl == FlowControl.NONE) "" else " ${flowControl.label}"

    companion object {
        val COMMON_BAUD_RATES = listOf(9600, 19200, 38400, 57600, 115200, 230400, 460800, 921600)
        const val MIN_BAUD = 50
        const val MAX_BAUD = 4_000_000
    }
}
