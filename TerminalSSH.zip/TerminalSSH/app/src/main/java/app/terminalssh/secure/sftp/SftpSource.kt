package app.terminalssh.secure.sftp

/**
 * Anything that can hand out SFTP clients: a terminal session riding its shell
 * connection, or a File Manager session that owns a connection of its own.
 *
 * The browser, the transfer queue and the batch runner only ever need this, which is
 * what lets the File Manager work with no terminal open.
 */
interface SftpSource {
    /**
     * A new client on the current connection, or null while there is no connection.
     * The caller owns the returned client and must close it.
     */
    fun openSftp(): SftpClient?
}
