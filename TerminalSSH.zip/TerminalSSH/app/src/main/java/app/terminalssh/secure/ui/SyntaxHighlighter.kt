package app.terminalssh.secure.ui

import android.annotation.SuppressLint
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.font.FontStyle
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import org.json.JSONTokener
import java.io.ByteArrayInputStream
import java.io.IOException
import kotlin.coroutines.resume

/** One coloured range of the highlighted text. */
internal class HlSpan(val start: Int, val end: Int, val style: SpanStyle)

/** The text that was highlighted plus its colour ranges. */
internal class HlResult(val text: String, val spans: List<HlSpan>)

/**
 * Syntax colouring with Highlight.js running in a hidden WebView.
 *
 * The WebView is never attached to a window and never drawn: it only runs
 * `highlightCode()` from assets/editor/bridge.html and hands back HTML, which
 * [parseHljsHtml] turns into native colour ranges. The editor itself is plain
 * Compose, so a highlighter problem can only ever cost colours, never the text.
 */
internal class SyntaxHighlighter(context: Context) {
    private val appContext = context.applicationContext
    private val mutex = Mutex()
    private var webView: WebView? = null
    private var started = false
    private var ready = CompletableDeferred<Boolean>()

    /** Why the last highlight did not work, or null. Shown in the editor status bar. */
    @Volatile
    var lastError: String? = null
        private set

    @SuppressLint("SetJavaScriptEnabled")
    private fun createOnMain() {
        if (webView != null) return
        val deferred = ready
        try {
            val view = WebView(appContext)
            view.settings.apply {
                javaScriptEnabled = true
                allowFileAccess = false
                allowContentAccess = false
                blockNetworkLoads = true
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) safeBrowsingEnabled = false
            }
            view.webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = true

                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                    val url = request.url
                    val path = url.path.orEmpty()
                    if (url.scheme == "https" && url.host == HOST && path.startsWith("/assets/")) {
                        val name = path.removePrefix("/assets/")
                        return try {
                            WebResourceResponse(mimeOf(name), "utf-8", appContext.assets.open(name))
                        } catch (e: IOException) {
                            blocked(404, "Not Found")
                        }
                    }
                    return blocked(403, "Forbidden")
                }

                override fun onPageFinished(view: WebView, url: String?) {
                    if (!deferred.isCompleted) deferred.complete(true)
                }

                override fun onReceivedError(
                    view: WebView,
                    request: WebResourceRequest,
                    error: android.webkit.WebResourceError,
                ) {
                    if (request.isForMainFrame) {
                        lastError = "page load failed"
                        if (!deferred.isCompleted) deferred.complete(false)
                    }
                }

                // A dead renderer must not crash the app; colours simply stop until restarted.
                override fun onRenderProcessGone(
                    view: WebView,
                    detail: android.webkit.RenderProcessGoneDetail,
                ): Boolean {
                    lastError = "highlighter stopped"
                    webView = null
                    started = false
                    if (!deferred.isCompleted) deferred.complete(false)
                    ready = CompletableDeferred()
                    return true
                }
            }
            webView = view
            view.loadUrl("https://$HOST/assets/editor/bridge.html")
        } catch (t: Throwable) {
            lastError = "WebView unavailable"
            if (!deferred.isCompleted) deferred.complete(false)
        }
    }

    private suspend fun ensureReady(): WebView? {
        if (!started) {
            started = true
            withContext(Dispatchers.Main) { createOnMain() }
        }
        val ok = withTimeoutOrNull(15_000) { ready.await() }
        if (ok != true) {
            if (ok == null && lastError == null) lastError = "highlighter timed out"
            return null
        }
        return webView
    }

    /** Colours [text] as [language]. Null means "show it plain"; [lastError] says why. */
    suspend fun highlight(text: String, language: String): HlResult? = mutex.withLock {
        val wv = ensureReady() ?: return null
        val js = "highlightCode(${jsQuote(text)},${jsQuote(language)})"
        val raw = withContext(Dispatchers.Main) {
            suspendCancellableCoroutine<String?> { cont -> wv.evaluateJavascript(js) { cont.resume(it) } }
        }
        withContext(Dispatchers.Default) {
            try {
                val value = if (raw == null || raw == "null") null else JSONTokener(raw).nextValue()
                val obj = (value as? String)?.let { JSONObject(it) }
                when {
                    obj == null -> { lastError = "no result"; null }
                    obj.optBoolean("error") -> { lastError = obj.optString("message", "error"); null }
                    obj.optBoolean("unsupported") -> { lastError = null; HlResult(text, emptyList()) }
                    else -> {
                        val parsed = parseHljsHtml(obj.getString("html"))
                        if (parsed.text == text) { lastError = null; parsed } else { lastError = "text mismatch"; null }
                    }
                }
            } catch (t: Throwable) {
                lastError = t.message ?: "parse error"
                null
            }
        }
    }

    fun destroy() {
        val wv = webView ?: return
        webView = null
        started = false
        if (!ready.isCompleted) ready.complete(false)
        ready = CompletableDeferred()
        Handler(Looper.getMainLooper()).post { wv.destroy() }
    }

    private companion object {
        const val HOST = "appassets.androidplatform.net"

        fun blocked(code: Int, reason: String) =
            WebResourceResponse("text/plain", "utf-8", code, reason, emptyMap(), ByteArrayInputStream(ByteArray(0)))

        fun mimeOf(name: String): String = when (name.substringAfterLast('.', "").lowercase()) {
            "html" -> "text/html"
            "js" -> "application/javascript"
            "css" -> "text/css"
            else -> "application/octet-stream"
        }

        /** A JavaScript string literal for any text. */
        fun jsQuote(s: String): String =
            JSONObject.quote(s).replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")
    }
}

// ---- Highlight.js HTML -> colour ranges ----

private val HlPurple = SpanStyle(color = Color(0xFFC678DD))
private val HlBlue = SpanStyle(color = Color(0xFF61AFEF))
private val HlYellow = SpanStyle(color = Color(0xFFE5C07B))
private val HlGreen = SpanStyle(color = Color(0xFF98C379))
private val HlOrange = SpanStyle(color = Color(0xFFD19A66))
private val HlRed = SpanStyle(color = Color(0xFFE06C75))
private val HlCyan = SpanStyle(color = Color(0xFF56B6C2))
private val HlGrey = SpanStyle(color = Color(0xFF7F848E), fontStyle = FontStyle.Italic)

private fun styleFor(classAttr: String): SpanStyle? {
    if (classAttr.isEmpty()) return null
    val tokens = classAttr.split(' ')
    val scope = tokens.firstOrNull { it.startsWith("hljs-") }?.removePrefix("hljs-") ?: return null
    return when (scope) {
        "keyword", "selector-tag", "doctag", "meta-keyword", "formula" -> HlPurple
        "title" -> if (tokens.contains("class_") || tokens.contains("language_")) HlYellow else HlBlue
        "built_in", "section", "meta" -> HlBlue
        "type", "class" -> HlYellow
        "string", "addition", "meta-string" -> HlGreen
        "number", "literal", "attr", "attribute", "variable", "template-variable",
        "selector-attr", "selector-class", "selector-id", "selector-pseudo" -> HlOrange
        "symbol", "bullet", "link", "regexp", "operator" -> HlCyan
        "name", "property", "deletion", "tag" -> HlRed
        "comment", "quote" -> HlGrey
        else -> null
    }
}

private fun decodeEntity(name: String): String? = when (name) {
    "amp" -> "&"
    "lt" -> "<"
    "gt" -> ">"
    "quot" -> "\""
    "apos" -> "'"
    else -> if (name.length > 1 && name[0] == '#') {
        val code = if (name[1] == 'x' || name[1] == 'X') name.substring(2).toIntOrNull(16) else name.substring(1).toIntOrNull()
        if (code != null && code in 0..0x10FFFF) String(Character.toChars(code)) else null
    } else null
}

/**
 * Turns Highlight.js output (nested `<span class="hljs-...">`, escaped text) into the plain
 * text it was made from plus colour ranges. Single pass, no DOM.
 */
internal fun parseHljsHtml(html: String): HlResult {
    val out = StringBuilder(html.length)
    val spans = ArrayList<HlSpan>()
    val starts = ArrayList<Int>()
    val styles = ArrayList<SpanStyle?>()
    var i = 0
    val n = html.length
    while (i < n) {
        val c = html[i]
        if (c == '<') {
            val end = html.indexOf('>', i)
            if (end < 0) break
            if (i + 1 < n && html[i + 1] == '/') {
                if (starts.isNotEmpty()) {
                    val s = starts.removeAt(starts.lastIndex)
                    val st = styles.removeAt(styles.lastIndex)
                    if (st != null && out.length > s) spans.add(HlSpan(s, out.length, st))
                }
            } else if (html.startsWith("<span", i)) {
                var cls = ""
                val k = html.indexOf("class=\"", i)
                if (k in i until end) {
                    val q = html.indexOf('"', k + 7)
                    if (q in (k + 7)..end) cls = html.substring(k + 7, q)
                }
                starts.add(out.length)
                styles.add(styleFor(cls))
            }
            i = end + 1
        } else if (c == '&') {
            val semi = html.indexOf(';', i)
            val decoded = if (semi in (i + 2)..(i + 10)) decodeEntity(html.substring(i + 1, semi)) else null
            if (decoded != null) {
                out.append(decoded)
                i = semi + 1
            } else {
                out.append('&')
                i++
            }
        } else {
            out.append(c)
            i++
        }
    }
    return HlResult(out.toString(), spans)
}

/**
 * Colour ranges for [current] taken from an older [snap]. While the user types, the unchanged
 * start and end of the text keep their colours; only the edited stretch is left plain until
 * the fresh highlight arrives.
 */
internal fun spansFor(snap: HlResult, current: String): List<HlSpan> {
    val old = snap.text
    if (old == current) return snap.spans
    var prefix = 0
    val minLen = minOf(old.length, current.length)
    while (prefix < minLen && old[prefix] == current[prefix]) prefix++
    var suffix = 0
    while (suffix < old.length - prefix && suffix < current.length - prefix &&
        old[old.length - 1 - suffix] == current[current.length - 1 - suffix]
    ) suffix++
    val oldChangedEnd = old.length - suffix
    val delta = current.length - old.length
    val out = ArrayList<HlSpan>(snap.spans.size)
    for (sp in snap.spans) {
        when {
            sp.end <= prefix -> out.add(sp)
            sp.start >= oldChangedEnd -> {
                val s = sp.start + delta
                val e = minOf(sp.end + delta, current.length)
                if (s in 0 until e) out.add(HlSpan(s, e, sp.style))
            }
            sp.start < prefix && sp.end > oldChangedEnd -> {
                out.add(HlSpan(sp.start, prefix, sp.style))
                val s = oldChangedEnd + delta
                val e = minOf(sp.end + delta, current.length)
                if (s in 0 until e) out.add(HlSpan(s, e, sp.style))
            }
            sp.start < prefix -> out.add(HlSpan(sp.start, prefix, sp.style))
        }
    }
    return out
}

/** The Highlight.js language for a file, or null to show it uncoloured. */
internal fun editorLanguage(fileName: String, firstLine: String): String? {
    val lower = fileName.lowercase()
    val ext = lower.substringAfterLast('.', "")
    when (lower) {
        "dockerfile" -> return "dockerfile"
        "makefile", "gnumakefile" -> return "makefile"
        "cmakelists.txt" -> return "cmake"
        ".bashrc", ".profile", ".zshrc", ".bash_profile", ".bash_aliases" -> return "bash"
        "nginx.conf" -> return "nginx"
    }
    val byExt = when (ext) {
        "ino", "pde" -> "arduino"
        "c", "h" -> "c"
        "cpp", "cc", "cxx", "hpp", "hh", "hxx", "ipp" -> "cpp"
        "py", "pyw" -> "python"
        "js", "mjs", "cjs", "jsx" -> "javascript"
        "ts", "tsx" -> "typescript"
        "json", "jsonc", "geojson" -> "json"
        "sh", "bash", "zsh", "ksh", "env" -> "bash"
        "html", "htm", "xml", "svg", "xhtml", "plist", "xsd", "xsl", "rss", "kml", "gpx" -> "xml"
        "css" -> "css"
        "scss" -> "scss"
        "md", "markdown" -> "markdown"
        "yml", "yaml" -> "yaml"
        "java" -> "java"
        "kt", "kts" -> "kotlin"
        "go" -> "go"
        "rs" -> "rust"
        "php" -> "php"
        "rb" -> "ruby"
        "sql" -> "sql"
        "ini", "cfg", "conf", "cnf" -> "ini"
        "toml" -> "ini"
        "properties" -> "properties"
        "lua" -> "lua"
        "pl", "pm" -> "perl"
        "diff", "patch" -> "diff"
        "cs" -> "csharp"
        "swift" -> "swift"
        "gradle", "groovy" -> "groovy"
        "r" -> "r"
        "bat", "cmd" -> "dos"
        "ps1" -> "powershell"
        "gcode", "nc", "ngc" -> "gcode"
        "tex" -> "latex"
        "vue", "svelte" -> "xml"
        else -> ""
    }
    if (byExt.isNotEmpty()) return byExt
    if (firstLine.startsWith("#!")) {
        val l = firstLine.lowercase()
        return when {
            "python" in l -> "python"
            "node" in l -> "javascript"
            "perl" in l -> "perl"
            "ruby" in l -> "ruby"
            "php" in l -> "php"
            "lua" in l -> "lua"
            "sh" in l -> "bash"
            else -> null
        }
    }
    return null
}
