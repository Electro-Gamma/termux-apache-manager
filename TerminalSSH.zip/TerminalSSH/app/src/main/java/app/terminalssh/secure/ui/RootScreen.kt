package app.terminalssh.secure.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.platform.LocalDensity
import kotlin.math.max
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Dns
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Terminal
import androidx.compose.material.icons.outlined.VpnKey
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.terminalssh.secure.R
import app.terminalssh.secure.model.HostProfile
import app.terminalssh.secure.ui.theme.Cyan
import app.terminalssh.secure.ui.theme.Ink
import app.terminalssh.secure.ui.theme.Turquoise
import app.terminalssh.secure.vm.AppViewModel
import app.terminalssh.secure.vm.OpenMode

enum class Tab { HOSTS, TERMINAL, FILES, KEYS, SETTINGS }

@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
fun RootScreen(viewModel: AppViewModel, launchHostId: String? = null) {
    var tab by viewModel::currentTab
    val sessions by viewModel.sessions.sessions.collectAsStateWithLifecycle()
    val toast by viewModel.toast.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    val hosts by viewModel.hosts.collectAsStateWithLifecycle()
    // Survives recomposition so a shortcut cannot re-open the session on every recompose.
    var consumedLaunchId by rememberSaveable { mutableStateOf<String?>(null) }

    BackHandler(enabled = tab != Tab.HOSTS) {
        tab = Tab.HOSTS
    }

    LaunchedEffect(toast) {
        toast?.let {
            snackbar.showSnackbar(it)
            viewModel.consumeToast()
        }
    }

    val openHost: (HostProfile, OpenMode, CharArray?) -> Unit = { profile, mode, password ->
        viewModel.openHost(profile, mode, password)
        // Terminal and Both land on the terminal; File Manager lands on the files.
        tab = if (mode == OpenMode.FILES) Tab.FILES else Tab.TERMINAL
    }

    // A launcher shortcut names a host by id. Only hosts with a stored credential can
    // connect unattended; anything else just lands the user on the host list, where the
    // normal password prompt happens.
    LaunchedEffect(launchHostId, hosts) {
        val id = launchHostId ?: return@LaunchedEffect
        if (consumedLaunchId == id) return@LaunchedEffect
        val profile = hosts.firstOrNull { it.id == id } ?: return@LaunchedEffect
        consumedLaunchId = id
        if (viewModel.hasStoredSecret(profile)) openHost(profile, OpenMode.TERMINAL, null)
    }

    Scaffold(
        containerColor = Ink,
        snackbarHost = { SnackbarHost(snackbar) },
        // The keyboard inset is handled once, by ImeAwareDock below; the Scaffold must
        // not consume it as well or it would be counted twice.
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            // The dock reserves max(its own height, the keyboard height) at the bottom, as a
            // pure function of the live IME inset. The old AnimatedVisibility kept its full
            // height in the layout for the whole exit animation while the terminal also
            // applied the IME inset, so the two were added together and a tall empty strip
            // showed under the toolbar until the animation finished.
            ImeAwareDock {
                Box(Modifier.navigationBarsPadding().padding(horizontal = 12.dp, vertical = 12.dp)) {
                    Surface(
                        shape = RoundedCornerShape(24.dp),
                        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f),
                        tonalElevation = 0.dp,
                        shadowElevation = 12.dp,
                    ) {
                        NavigationBar(
                            containerColor = androidx.compose.ui.graphics.Color.Transparent,
                            tonalElevation = 0.dp,
                        ) {
                            TabItem(tab, Tab.HOSTS, Icons.Outlined.Dns, stringResource(R.string.tab_hosts)) { tab = it }
                            TabItem(
                                tab,
                                Tab.TERMINAL,
                                Icons.Outlined.Terminal,
                                stringResource(R.string.tab_terminal),
                                sessions.size,
                            ) { tab = it }
                            TabItem(tab, Tab.FILES, Icons.Outlined.Folder, stringResource(R.string.tab_files)) { tab = it }
                            TabItem(tab, Tab.KEYS, Icons.Outlined.VpnKey, stringResource(R.string.tab_keys)) { tab = it }
                            TabItem(tab, Tab.SETTINGS, Icons.Outlined.Settings, stringResource(R.string.tab_settings)) { tab = it }
                        }
                    }
                }
            }
        },
    ) { padding ->
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            Turquoise.copy(alpha = 0.055f),
                            Cyan.copy(alpha = 0.018f),
                            Ink,
                            Ink,
                        )
                    )
                )
                .padding(padding)
                // Edge-to-edge draws under the status bar; without this the screen headers
                // sat behind the clock, signal and battery icons. Side insets cover the
                // camera cutout and a side navigation bar in landscape.
                .windowInsetsPadding(
                    WindowInsets.systemBars
                        .union(WindowInsets.displayCutout)
                        .only(WindowInsetsSides.Top + WindowInsetsSides.Horizontal),
                )
        ) {
            Crossfade(targetState = tab, label = "root-tab") { target ->
                when (target) {
                    Tab.HOSTS -> HostsScreen(viewModel, onConnect = openHost)
                    Tab.TERMINAL -> TerminalScreen(viewModel, onGoToHosts = { tab = Tab.HOSTS })
                    Tab.FILES -> FilesScreen(viewModel, onGoToHosts = { tab = Tab.HOSTS })
                    Tab.KEYS -> KeysScreen(viewModel)
                    Tab.SETTINGS -> SettingsScreen(viewModel)
                }
            }
        }
    }
}

/**
 * Bottom dock whose layout height is max(dock height, keyboard height).
 *
 * With the keyboard closed it is exactly the dock. As the keyboard rises the content above
 * it is pushed up in step with the keyboard animation and the dock slides underneath the
 * keyboard (and fades), so nothing is measured twice and nothing jumps at the end. The
 * screens therefore need no IME padding of their own.
 */
@Composable
private fun ImeAwareDock(content: @Composable () -> Unit) {
    val ime = WindowInsets.ime
    val fadeDistancePx = with(LocalDensity.current) { 72.dp.toPx() }
    Layout(
        content = {
            Box(
                Modifier.graphicsLayer {
                    alpha = 1f - (ime.getBottom(this) / fadeDistancePx).coerceIn(0f, 1f)
                },
            ) { content() }
        },
    ) { measurables, constraints ->
        val dock = measurables.first().measure(constraints.copy(minHeight = 0))
        val height = max(dock.height, ime.getBottom(this))
        layout(dock.width, height) { dock.place(0, height - dock.height) }
    }
}

@Composable
private fun RowScope.TabItem(
    current: Tab,
    target: Tab,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    badge: Int = 0,
    onSelect: (Tab) -> Unit,
) {
    NavigationBarItem(
        selected = current == target,
        onClick = { onSelect(target) },
        icon = {
            if (badge > 0) {
                BadgedBox(badge = { Badge { Text("$badge") } }) {
                    Icon(icon, contentDescription = null)
                }
            } else {
                Icon(icon, contentDescription = null)
            }
        },
        label = { Text(label, style = MaterialTheme.typography.labelSmall) },
        colors = NavigationBarItemDefaults.colors(
            selectedIconColor = Turquoise,
            selectedTextColor = Turquoise,
            indicatorColor = Turquoise.copy(alpha = 0.12f),
        ),
    )
}
