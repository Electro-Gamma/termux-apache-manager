package app.terminalssh.secure.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Link
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.automirrored.outlined.KeyboardArrowRight
import androidx.compose.material3.HorizontalDivider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import app.terminalssh.secure.R
import app.terminalssh.secure.sftp.RemoteEntry
import app.terminalssh.secure.sftp.Selection
import app.terminalssh.secure.sftp.SftpController
import app.terminalssh.secure.ui.theme.Ink
import app.terminalssh.secure.ui.theme.Stroke
import app.terminalssh.secure.ui.theme.TextSecondary
import app.terminalssh.secure.ui.theme.Turquoise

/**
 * Remote file browser.
 *
 * Layout is intentionally list-first rather than a grid: on a phone, filenames are the
 * information that matters and truncating them into a grid cell defeats the point.
 */
@Composable
fun SftpBrowser(
    state: SftpController.BrowserState,
    onNavigate: (String) -> Unit,
    onDownload: (RemoteEntry) -> Unit,
    selection: Selection = Selection(),
    onToggleSelect: (RemoteEntry) -> Unit = {},
    /** Entries the view options are hiding, so an empty-looking folder can say why. */
    hiddenCount: Int = 0,
    modifier: Modifier = Modifier.fillMaxSize(),
) {
    Column(modifier) {
        PathBar(state.path, onNavigate = onNavigate)

        // Reserves its own height so the list below never jumps when loading starts.
        Box(Modifier.fillMaxWidth().height(2.dp)) {
            androidx.compose.animation.AnimatedVisibility(
                visible = state.loading,
                enter = fadeIn(),
                exit = fadeOut(),
            ) {
                LinearProgressIndicator(
                    Modifier.fillMaxWidth(),
                    color = Turquoise,
                    trackColor = Stroke,
                )
            }
        }

        AnimatedVisibility(
            visible = state.errorKind != null,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically(),
        ) {
            state.errorKind?.let { kind ->
                Text(
                    stringResource(kind.stringRes),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 12.dp),
                )
            }
        }

        if (state.entries.isEmpty() && !state.loading) {
            EmptyDirectory(hiddenOnly = hiddenCount > 0)
        } else {
            LazyColumn(
                // Bottom padding keeps the last row clear of the floating "+" button.
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 96.dp),
            ) {
                items(state.entries, key = { it.path }) { entry ->
                    Column {
                        EntryRow(
                            entry = entry,
                            isSelected = selection.contains(entry.path),
                            selectionMode = selection.isActive,
                            onClick = {
                                when {
                                    // While selecting, a tap ticks the row; navigation stays on the
                                    // breadcrumbs and the arrow in the top bar.
                                    selection.isActive -> onToggleSelect(entry)
                                    entry.isDirectory -> onNavigate(entry.path)
                                    else -> onDownload(entry)
                                }
                            },
                            onLongClick = { onToggleSelect(entry) },
                        )
                        HorizontalDivider(
                            modifier = Modifier.padding(horizontal = 12.dp),
                            color = MaterialTheme.colorScheme.outlineVariant,
                        )
                    }
                }
            }
        }
    }
}

/**
 * Breadcrumbs that scroll horizontally, with chevrons between the segments. A deep path
 * on a narrow phone would otherwise either truncate the part the user needs or wrap into
 * several lines; it opens scrolled to the end so the current folder is always in view.
 */
@Composable
private fun PathBar(
    path: String,
    onNavigate: (String) -> Unit,
) {
    val crumbs = app.terminalssh.secure.sftp.RemotePath.breadcrumbs(path)
    val listState = rememberLazyListState()
    LaunchedEffect(path) { listState.scrollToItem((crumbs.size - 1).coerceAtLeast(0)) }

    LazyRow(
        state = listState,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
            .background(MaterialTheme.colorScheme.surface),
        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        itemsIndexed(crumbs, key = { _, crumb -> crumb.second }) { index, crumb ->
            val name = crumb.first
            val target = crumb.second
            val isCurrent = target == path
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = name,
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = if (isCurrent) FontWeight.SemiBold else FontWeight.Normal,
                    color = if (isCurrent) MaterialTheme.colorScheme.onSurface else TextSecondary,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable(enabled = !isCurrent) { onNavigate(target) }
                        .padding(horizontal = 8.dp, vertical = 10.dp),
                )
                if (index < crumbs.lastIndex) {
                    Icon(
                        Icons.AutoMirrored.Outlined.KeyboardArrowRight,
                        contentDescription = null,
                        tint = TextSecondary,
                        modifier = Modifier.size(18.dp),
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun EntryRow(
    entry: RemoteEntry,
    isSelected: Boolean,
    selectionMode: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
) {
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (pressed) 0.985f else 1f, Motion.press(), label = "row-press")
    val background by animateColorAsState(
        when {
            isSelected -> Turquoise.copy(alpha = 0.14f)
            pressed -> Turquoise.copy(alpha = 0.08f)
            else -> Color.Transparent
        },
        Motion.quick(),
        label = "row-bg",
    )
    val haptics = LocalHapticFeedback.current

    Row(
        Modifier
            .fillMaxWidth()
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(RoundedCornerShape(12.dp))
            .background(background)
            .semantics { selected = isSelected }
            .combinedClickable(
                onClick = {
                    pressed = false
                    onClick()
                },
                onLongClick = {
                    pressed = false
                    haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                    onLongClick()
                },
            )
            // A 56dp row clears the 48dp minimum touch target with room for a mis-tap.
            .padding(horizontal = 12.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        // The checkbox is display-only: the whole row is the touch target.
        AnimatedVisibility(
            visible = selectionMode,
            enter = fadeIn() + expandHorizontally(),
            exit = fadeOut() + shrinkHorizontally(),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(
                    checked = isSelected,
                    onCheckedChange = null,
                    colors = CheckboxDefaults.colors(
                        checkedColor = Turquoise,
                        uncheckedColor = TextSecondary,
                        checkmarkColor = Ink,
                    ),
                )
                Spacer(Modifier.width(12.dp))
            }
        }
        Icon(
            imageVector = when {
                entry.isSymlink -> Icons.Outlined.Link
                entry.isDirectory -> Icons.Outlined.Folder
                else -> Icons.Outlined.Description
            },
            contentDescription = null,
            tint = if (entry.isDirectory) Turquoise else TextSecondary,
            modifier = Modifier.size(24.dp),
        )
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(
                ltr(entry.name),
                style = MaterialTheme.typography.bodyLarge,
                maxLines = 1,
            )
            Text(
                if (entry.isDirectory) entry.permissions else "${FileSize.format(entry.sizeBytes)} · ${entry.permissions}",
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary,
                maxLines = 1,
            )
        }
    }
}

@Composable
private fun EmptyDirectory(hiddenOnly: Boolean) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                Icons.Outlined.Folder,
                null,
                tint = TextSecondary.copy(alpha = 0.4f),
                modifier = Modifier.size(48.dp),
            )
            Spacer(Modifier.height(12.dp))
            Text(
                stringResource(if (hiddenOnly) R.string.sftp_all_hidden else R.string.sftp_empty),
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
                textAlign = TextAlign.Center,
            )
        }
    }
}
