package app.terminalssh.secure.serial

import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.os.Handler
import android.os.Looper
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import app.terminalssh.secure.ssh.ConnectionErrorKind
import app.terminalssh.secure.ssh.SecretMask
import app.terminalssh.secure.ssh.SshSessionState
import app.terminalssh.secure.ssh.TerminalSession
import app.terminalssh.secure.ui.theme.TerminalPalette
import com.hoho.android.usbserial.driver.UsbSerialDriver
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.connectbot.terminal.TerminalEmulator
import org.connectbot.terminal.TerminalEmulatorFactory
import java.io.IOException
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * One open USB serial port plus its terminal emulator: the UART counterpart of
 * [app.terminalssh.secure.ssh.SshSession], on the same terminal component.
 *
 * Threading follows the SSH session's contract:
 *  - every port operation (open, write, close) runs on [io];
 *  - every emulator mutation is posted to the main thread;
 *  - the port's read thread only forwards bytes, and never touches the emulator directly.
 *
 * There is deliberately no reconnect loop. A serial link does not drop and come back by
 * itself: it ends when the adapter is unplugged or fails, and the user decides when to open
 * it again from the host list.
 */
class SerialSession(
    override val id: String,
    private val driver: UsbSerialDriver,
    private val usb: UsbSerialManager,
    initialSettings: SerialSettings,
    private val onClipboardCopy: (String) -> Unit,
    private val onPasteRequest: () -> Unit,
    private val onBell: () -> Unit = {},
    /** Read at each chunk of output, so toggling the setting takes effect immediately. */
    private val maskSecrets: () -> Boolean = { false },
    defaultForeground: Color = Color.White,
    defaultBackground: Color = Color.Black,
) : TerminalSession {

    private val device: UsbDevice = driver.device
    private val io = Executors.newSingleThreadExecutor { r -> Thread(r, "serial-io-$id") }
    private val main = Handler(Looper.getMainLooper())
    private val controller = SerialPortController()
    private val latch = ControlKeyLatch()

    /** Set once the session has ended, whichever way; stops late bytes and duplicate failures. */
    private val ended = AtomicBoolean(false)

    private val _state = MutableStateFlow<SshSessionState>(SshSessionState.Idle)
    override val state: StateFlow<SshSessionState> = _state.asStateFlow()

    private val _settings = MutableStateFlow(initialSettings)

    /** The settings in force. The status line shows them and the settings dialog edits them. */
    val settings: StateFlow<SerialSettings> = _settings.asStateFlow()

    override val hostId: String = hostIdFor(device)
    override val title: String = usb.displayName(device)
    override val subtitle: String get() = _settings.value.summary

    override val ctrlLatched: StateFlow<Boolean> get() = latch.ctrl
    override val altLatched: StateFlow<Boolean> get() = latch.alt

    override val emulator: TerminalEmulator = TerminalEmulatorFactory.create(
        initialRows = INITIAL_ROWS,
        initialCols = INITIAL_COLS,
        defaultForeground = defaultForeground,
        defaultBackground = defaultBackground,
        onKeyboardInput = { bytes -> sendKey(bytes) },
        onBell = { onBell() },
        // A plain UART has no side channel to tell the far end the window size (an SSH pty
        // does). `stty rows R cols C` on the board is the way to do it by hand.
        onResize = { },
        onClipboardCopy = onClipboardCopy,
    )

    /** Opens the port. Safe to call once; to connect again, open a new session. */
    fun connect() {
        _state.value = SshSessionState.Connecting
        controller.onDataReceived = ::onData
        controller.onError = { e -> fail(ConnectionErrorKind.SERIAL_DEVICE_LOST, e.message) }
        io.execute {
            var connection: UsbDeviceConnection? = null
            try {
                connection = usb.openConnection(device)
                    ?: throw IOException("Android refused to open the USB device")
                controller.open(driver, connection, _settings.value)
                if (ended.get()) {
                    // Closed or unplugged while the port was opening.
                    controller.close()
                    return@execute
                }
                _state.value = SshSessionState.Connected
            } catch (t: Throwable) {
                runCatching { connection?.close() }
                fail(ConnectionErrorKind.SERIAL_OPEN_FAILED, t.message ?: t.javaClass.simpleName)
            }
        }
    }

    /** Applies new settings to the open port, e.g. a different baud rate when the output is garbled. */
    fun updateSettings(newSettings: SerialSettings) {
        _settings.value = newSettings
        if (ended.get()) return
        io.execute {
            try {
                controller.updateSettings(newSettings)
            } catch (t: Throwable) {
                fail(ConnectionErrorKind.SERIAL_OPEN_FAILED, t.message ?: t.javaClass.simpleName)
            }
        }
    }

    /** Called when Android reports any USB device unplugged; ends this session if it was ours. */
    fun onDeviceDetached(detached: UsbDevice) {
        if (detached.deviceName == device.deviceName) {
            fail(ConnectionErrorKind.SERIAL_DEVICE_LOST, "USB adapter unplugged")
        }
    }

    private fun onData(data: ByteArray) {
        if (ended.get()) return
        val chunk = data.copyOf()
        if (maskSecrets()) SecretMask.maskInPlace(chunk, chunk.size)
        main.post {
            try {
                if (!ended.get()) emulator.writeInput(chunk, 0, chunk.size)
            } finally {
                chunk.fill(0)
            }
        }
    }

    private fun fail(kind: ConnectionErrorKind, message: String?) {
        if (!ended.compareAndSet(false, true)) return
        _state.value = SshSessionState.Failed(message = message ?: kind.name, kind = kind)
        io.execute { runCatching { controller.close() } }
    }

    // ---- input ----

    override fun send(bytes: ByteArray) {
        if (ended.get() || !_state.value.isLive) return
        val copy = bytes.copyOf()
        // Not zeroed afterwards: with XON/XOFF the controller may still be holding it.
        io.execute { controller.write(copy) }
    }

    override fun send(text: String) = send(text.encodeToByteArray())

    override fun toggleCtrl() = latch.toggleCtrl()
    override fun toggleAlt() = latch.toggleAlt()

    override fun sendKey(bytes: ByteArray) = send(latch.apply(bytes))
    override fun sendKey(text: String) = sendKey(text.encodeToByteArray())

    override fun requestPaste() = onPasteRequest()

    // ---- appearance (same contract as the SSH session) ----

    override fun applyPalette(palette: TerminalPalette) {
        val ansi = IntArray(16) { palette.ansi[it].toArgb() }
        val fg = palette.foreground.toArgb()
        val bg = palette.background.toArgb()
        main.post {
            runCatching {
                val method = emulator.javaClass.methods.firstOrNull {
                    it.name == "applyColorScheme" && it.parameterTypes.size == 3 &&
                        it.parameterTypes[0] == IntArray::class.java
                } ?: return@runCatching
                method.invoke(emulator, ansi, fg, bg)
            }
        }
    }

    override fun applyCursorStyle(style: String, blink: Boolean) {
        val code = when (style) {
            "bar" -> if (blink) 5 else 6
            "underline" -> if (blink) 3 else 4
            else -> if (blink) 1 else 2
        }
        val bytes = "\u001b[$code q".encodeToByteArray()
        main.post { emulator.writeInput(bytes, 0, bytes.size) }
    }

    override fun clearScreen() {
        main.post { runCatching { emulator.clearScreen() } }
    }

    // ---- lifecycle ----

    override fun disconnect() {
        if (!ended.compareAndSet(false, true)) return
        _state.value = SshSessionState.Closed
        io.execute { runCatching { controller.close() } }
    }

    override fun destroy() {
        disconnect()
        io.shutdown()
    }

    companion object {
        private const val INITIAL_ROWS = 24
        private const val INITIAL_COLS = 80

        /** One id per plugged-in adapter: it changes when the adapter is replugged, as it should. */
        fun hostIdFor(device: UsbDevice): String = "serial:${device.deviceName}"
    }
}
