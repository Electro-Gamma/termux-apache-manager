package app.terminalssh.secure.storage

import android.content.Context

/**
 * Which servers had a terminal open when the app was last used, for "Reopen the last
 * session on launch". Only host ids are kept (never credentials): reopening goes through
 * the normal connect path and so only works for hosts whose secret is saved.
 */
class LastSessions(context: Context) {
    private val prefs = context.getSharedPreferences("session_state", Context.MODE_PRIVATE)

    fun get(): List<String> =
        prefs.getString(KEY, "").orEmpty().split(SEPARATOR).filter { it.isNotBlank() }

    fun set(hostIds: List<String>) {
        prefs.edit().putString(KEY, hostIds.distinct().joinToString(SEPARATOR)).apply()
    }

    private companion object {
        const val KEY = "last_terminal_hosts"
        const val SEPARATOR = ","
    }
}
