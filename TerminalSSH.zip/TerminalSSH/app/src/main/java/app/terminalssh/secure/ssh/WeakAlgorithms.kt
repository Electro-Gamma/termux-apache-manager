package app.terminalssh.secure.ssh

/**
 * Judges whether a server's host key is weak enough to deserve a warning when the user is
 * asked to trust it for the first time ("Warn about weak encryption").
 *
 * DSA host keys are fixed at 1024 bits and long considered broken; RSA keys below 2048 bits
 * are within reach of well-resourced attackers. Anything this cannot parse is treated as
 * fine rather than flagged, so a format surprise never produces a false alarm.
 */
object WeakAlgorithms {
    private const val MIN_RSA_BITS = 2048

    fun isWeakHostKey(algorithm: String, key: ByteArray): Boolean = when {
        algorithm.equals("ssh-dss", ignoreCase = true) -> true
        algorithm.equals("ssh-rsa", ignoreCase = true) -> rsaBits(key)?.let { it < MIN_RSA_BITS } ?: false
        else -> false
    }

    /** Modulus size of an SSH-wire-format RSA public key (type, e, n), or null if it is not one. */
    internal fun rsaBits(blob: ByteArray): Int? {
        var offset = 0

        fun readField(): ByteArray? {
            if (offset + 4 > blob.size) return null
            val length = ((blob[offset].toInt() and 0xFF) shl 24) or
                ((blob[offset + 1].toInt() and 0xFF) shl 16) or
                ((blob[offset + 2].toInt() and 0xFF) shl 8) or
                (blob[offset + 3].toInt() and 0xFF)
            offset += 4
            if (length < 0 || offset + length > blob.size) return null
            val field = blob.copyOfRange(offset, offset + length)
            offset += length
            return field
        }

        readField() ?: return null // key type
        readField() ?: return null // public exponent
        val modulus = readField() ?: return null
        // A leading zero byte only keeps the integer positive; it is not part of its size.
        val significant = if (modulus.isNotEmpty() && modulus[0] == 0.toByte()) modulus.size - 1 else modulus.size
        return significant * 8
    }
}
