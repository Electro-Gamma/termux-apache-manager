package app.terminalssh.secure.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.Redo
import androidx.compose.material.icons.automirrored.outlined.Undo
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.FindReplace
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.KeyboardArrowUp
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.Save
import androidx.compose.material.icons.outlined.SaveAs
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.terminalssh.secure.R
import app.terminalssh.secure.sftp.FileTooLarge
import app.terminalssh.secure.sftp.RemotePath
import app.terminalssh.secure.sftp.SftpClient
import app.terminalssh.secure.sftp.SftpController
import app.terminalssh.secure.ui.theme.Danger
import app.terminalssh.secure.ui.theme.TextSecondary
import app.terminalssh.secure.ui.theme.Turquoise
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction

private val EditorBg = Color(0xFF282C34)
private val EditorFg = Color(0xFFABB2BF)
private val GutterFg = Color(0xFF636D83)
private val MatchBg = Color(0xFF5A4A1F)
private val MatchCurBg = Color(0xFF9A6A14)
private val EditorTextStyle = TextStyle(
    color = EditorFg,
    fontFamily = FontFamily.Monospace,
    fontSize = 13.sp,
    lineHeight = 19.sp,
)

/** Paints find matches behind the text. The text itself is untouched, so offsets map 1:1. */
private class MatchHighlighter(
    private val starts: List<Int>,
    private val length: Int,
    private val current: Int,
) : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        if (starts.isEmpty() || length <= 0) return TransformedText(text, OffsetMapping.Identity)
        val b = AnnotatedString.Builder(text)
        val limit = minOf(starts.size, 3000)
        for (i in 0 until limit) {
            val s = starts[i]
            val e = s + length
            if (e <= text.length) {
                b.addStyle(SpanStyle(background = if (i == current) MatchCurBg else MatchBg), s, e)
            }
        }
        return TransformedText(b.toAnnotatedString(), OffsetMapping.Identity)
    }
}

/**
 * The File Manager's built-in editor for a remote file.
 *
 * A plain native text editor (no WebView, no syntax colouring): open, edit, undo/redo,
 * find/replace, Save and Save As. The session (file, unsaved text) is kept in
 * [SftpController.editor], so switching tabs and coming back reopens the same file with
 * any unsaved edits.
 */
@Composable
fun FileEditorScreen(controller: SftpController) {
    val scope = rememberCoroutineScope()
    val initial = remember { controller.editor.value } ?: return

    var path by remember { mutableStateOf(initial.entry.path) }
    val fileName = RemotePath.name(path)

    var eol by remember { mutableStateOf(initial.eol) }
    var charsetName by remember { mutableStateOf(initial.charsetName) }
    var bom by remember { mutableStateOf(initial.bom) }
    var loadError by remember { mutableStateOf<Int?>(null) }

    // The text and everything derived from it.
    var tfv by remember { mutableStateOf(TextFieldValue("")) }
    var savedText by remember { mutableStateOf("") }
    var unknownBase by remember { mutableStateOf(false) }
    var pageLoaded by remember { mutableStateOf(false) }
    var readOnly by remember { mutableStateOf(initial.readOnly) }
    var saving by remember { mutableStateOf(false) }
    var notice by remember { mutableStateOf<Pair<Int, Boolean>?>(null) }
    val dirty = pageLoaded && (unknownBase || tfv.text != savedText)

    // Undo / redo.
    val undoSt = remember { ArrayList<TextFieldValue>() }
    val redoSt = remember { ArrayList<TextFieldValue>() }
    var lastPush by remember { mutableStateOf(0L) }
    var canUndo by remember { mutableStateOf(false) }
    var canRedo by remember { mutableStateOf(false) }

    // Find / replace.
    var findOpen by remember { mutableStateOf(false) }
    var showReplace by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var replacement by remember { mutableStateOf("") }
    var cur by remember { mutableStateOf(0) }

    var menuOpen by remember { mutableStateOf(false) }
    var showSaveAs by remember { mutableStateOf(false) }
    var overwriteTarget by remember { mutableStateOf<String?>(null) }
    var confirmClose by remember { mutableStateOf(false) }

    val vScroll = rememberScrollState()
    val hScroll = rememberScrollState()
    val lineHeightPx = with(LocalDensity.current) { 19.sp.toPx() }

    LaunchedEffect(notice) {
        if (notice != null) {
            delay(2500)
            notice = null
        }
    }

    fun refreshHistoryFlags() {
        canUndo = undoSt.isNotEmpty()
        canRedo = redoSt.isNotEmpty()
    }

    fun pushUndo(prev: TextFieldValue, coalesce: Boolean) {
        val now = System.currentTimeMillis()
        if (!(coalesce && undoSt.isNotEmpty() && now - lastPush < 900 && redoSt.isEmpty())) {
            undoSt.add(prev)
            while (undoSt.size > 60 || (undoSt.size > 1 && undoSt.sumOf { it.text.length } > 8_000_000)) {
                undoSt.removeAt(0)
            }
            redoSt.clear()
        }
        lastPush = now
        refreshHistoryFlags()
    }

    /** An edit that is undoable as one step. */
    fun applyEdit(nv: TextFieldValue, coalesce: Boolean) {
        if (nv.text != tfv.text) pushUndo(tfv, coalesce)
        tfv = nv
    }

    fun undo() {
        if (undoSt.isEmpty()) return
        redoSt.add(tfv)
        tfv = undoSt.removeAt(undoSt.lastIndex)
        refreshHistoryFlags()
    }

    fun redo() {
        if (redoSt.isEmpty()) return
        undoSt.add(tfv)
        tfv = redoSt.removeAt(redoSt.lastIndex)
        refreshHistoryFlags()
    }

    // ---- load the file (or restore the unsaved text of an earlier visit) ----
    LaunchedEffect(Unit) {
        val draft = initial.draft
        if (draft != null) {
            tfv = TextFieldValue(draft)
            unknownBase = true
            pageLoaded = true
            return@LaunchedEffect
        }
        try {
            val decoded = decode(controller.readFile(initial.entry.path))
            if (decoded == null) {
                loadError = R.string.editor_binary
            } else {
                eol = decoded.eol
                charsetName = decoded.charsetName
                bom = decoded.bom
                controller.updateEditor { it.copy(eol = decoded.eol, charsetName = decoded.charsetName, bom = decoded.bom) }
                savedText = decoded.text
                tfv = TextFieldValue(decoded.text)
                pageLoaded = true
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: FileTooLarge) {
            loadError = R.string.editor_too_large
        } catch (t: Throwable) {
            loadError = SftpClient.classify(t).stringRes
        }
    }

    // Keep the unsaved text in the session so leaving the tab does not lose it.
    LaunchedEffect(tfv.text, dirty) {
        if (!pageLoaded) return@LaunchedEffect
        if (dirty) {
            delay(600)
            controller.updateEditor { it.copy(draft = tfv.text) }
        } else {
            controller.updateEditor { it.copy(draft = null) }
        }
    }

    /** Writes the current text to [target]. True when it was saved. */
    suspend fun saveNow(target: String): Boolean {
        if (saving || !pageLoaded) return false
        saving = true
        return try {
            val text = tfv.text
            val bytes = encode(text, eol, charsetName, bom)
            controller.writeFile(target, bytes)
            path = target
            savedText = text
            unknownBase = false
            controller.updateEditor {
                it.copy(entry = it.entry.copy(path = target, name = RemotePath.name(target)), draft = null)
            }
            notice = R.string.editor_saved to false
            controller.refresh()
            true
        } catch (e: CancellationException) {
            throw e
        } catch (t: Throwable) {
            notice = SftpClient.classify(t).stringRes to true
            false
        } finally {
            saving = false
        }
    }

    fun save(target: String) { scope.launch { saveNow(target) } }

    fun requestSaveAs(input: String) {
        val trimmed = input.trim()
        if (trimmed.isEmpty() || trimmed.endsWith("/")) return
        val target = RemotePath.join(RemotePath.parent(path), trimmed)
        showSaveAs = false
        if (target == path) {
            save(target)
            return
        }
        scope.launch {
            if (controller.fileExists(target)) overwriteTarget = target else save(target)
        }
    }

    fun setEditing(editing: Boolean) {
        readOnly = !editing
        controller.updateEditor { it.copy(readOnly = !editing) }
    }

    // ---- find / replace ----
    val matchStarts: List<Int> = remember(query, tfv.text, findOpen) {
        if (!findOpen || query.isEmpty()) emptyList() else {
            val out = ArrayList<Int>()
            val t = tfv.text
            var i = t.indexOf(query, 0, ignoreCase = true)
            while (i >= 0 && out.size < 20000) {
                out.add(i)
                i = t.indexOf(query, i + query.length, ignoreCase = true)
            }
            out
        }
    }
    val curIndex = if (matchStarts.isEmpty()) -1 else cur.coerceIn(0, matchStarts.size - 1)
    val highlighter = remember(matchStarts, query, curIndex) {
        MatchHighlighter(matchStarts, query.length, curIndex)
    }

    fun goToMatch(i: Int) {
        if (matchStarts.isEmpty()) return
        val idx = ((i % matchStarts.size) + matchStarts.size) % matchStarts.size
        cur = idx
        val s = matchStarts[idx]
        tfv = tfv.copy(selection = TextRange(s, s + query.length))
        val text = tfv.text
        var line = 0
        for (k in 0 until s) if (text[k] == '\n') line++
        scope.launch { vScroll.animateScrollTo(maxOf(0, (line * lineHeightPx - 4 * lineHeightPx).toInt())) }
    }

    fun replaceCurrent() {
        if (readOnly) setEditing(true)
        if (curIndex < 0) return
        val s = matchStarts[curIndex]
        val t = tfv.text
        val nt = t.substring(0, s) + replacement + t.substring(s + query.length)
        val caret = s + replacement.length
        applyEdit(TextFieldValue(nt, TextRange(caret)), false)
    }

    fun replaceAll() {
        if (readOnly) setEditing(true)
        if (query.isEmpty()) return
        val nt = Regex(Regex.escape(query), RegexOption.IGNORE_CASE)
            .replace(tfv.text, Regex.escapeReplacement(replacement))
        applyEdit(TextFieldValue(nt, TextRange(minOf(tfv.selection.start, nt.length))), false)
    }

    // Back closes the find bar first, then offers to save, then leaves the editor.
    BackHandler(enabled = true) {
        when {
            menuOpen -> menuOpen = false
            findOpen -> findOpen = false
            dirty -> confirmClose = true
            else -> controller.closeEditor()
        }
    }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surface)) {
        // ---- title row ----
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(
                onClick = { if (dirty) confirmClose = true else controller.closeEditor() },
                modifier = Modifier.size(44.dp),
            ) {
                Icon(Icons.AutoMirrored.Outlined.ArrowBack, stringResource(R.string.editor_close))
            }
            Column(Modifier.weight(1f).padding(horizontal = 4.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        ltr(fileName),
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false),
                    )
                    if (dirty) {
                        Text(" ●", color = Turquoise, style = MaterialTheme.typography.titleMedium)
                    }
                }
                val note = notice
                if (note != null) {
                    Text(
                        stringResource(note.first),
                        style = MaterialTheme.typography.labelSmall,
                        color = if (note.second) MaterialTheme.colorScheme.error else Turquoise,
                        maxLines = 1,
                    )
                } else {
                    Text(
                        ltr(path),
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
            Box {
                IconButton(onClick = { menuOpen = true }, modifier = Modifier.size(44.dp)) {
                    Icon(Icons.Outlined.MoreVert, stringResource(R.string.editor_more))
                }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    MenuEntry(
                        Icons.Outlined.Save,
                        stringResource(R.string.editor_save),
                        { menuOpen = false },
                        enabled = dirty && !saving && pageLoaded,
                    ) { save(path) }
                    MenuEntry(
                        Icons.Outlined.SaveAs,
                        stringResource(R.string.editor_save_as),
                        { menuOpen = false },
                        enabled = !saving && pageLoaded,
                    ) { showSaveAs = true }
                }
            }
        }

        // ---- tool row: Edit, Undo, Redo, Find, Replace, Save ----
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            val on = pageLoaded
            ToolButton(
                if (readOnly) Icons.Outlined.Edit else Icons.Outlined.Visibility,
                stringResource(if (readOnly) R.string.editor_edit else R.string.editor_view_only),
                enabled = on,
                highlighted = !readOnly,
            ) { setEditing(readOnly) }
            ToolButton(
                Icons.AutoMirrored.Outlined.Undo,
                stringResource(R.string.editor_undo),
                enabled = on && canUndo && !readOnly,
            ) { undo() }
            ToolButton(
                Icons.AutoMirrored.Outlined.Redo,
                stringResource(R.string.editor_redo),
                enabled = on && canRedo && !readOnly,
            ) { redo() }
            ToolButton(
                Icons.Outlined.Search,
                stringResource(R.string.editor_find),
                enabled = on,
                highlighted = findOpen && !showReplace,
            ) { findOpen = true; showReplace = false }
            ToolButton(
                Icons.Outlined.FindReplace,
                stringResource(R.string.editor_replace),
                enabled = on,
                highlighted = findOpen && showReplace,
            ) { findOpen = true; showReplace = true }
            ToolButton(
                Icons.Outlined.Save,
                stringResource(R.string.editor_save),
                enabled = on && dirty && !saving,
                highlighted = dirty,
            ) { save(path) }
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

        // ---- find / replace bar ----
        if (findOpen) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it; cur = 0 },
                        label = { Text(stringResource(R.string.editor_find)) },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                    )
                    Text(
                        if (matchStarts.isEmpty()) "0/0" else "${curIndex + 1}/${matchStarts.size}",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary,
                        modifier = Modifier.padding(horizontal = 6.dp),
                    )
                    IconButton(onClick = { goToMatch(curIndex - 1) }, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Outlined.KeyboardArrowUp, null)
                    }
                    IconButton(onClick = { goToMatch(curIndex + 1) }, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Outlined.KeyboardArrowDown, null)
                    }
                    IconButton(onClick = { findOpen = false }, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Outlined.Close, null)
                    }
                }
                if (showReplace) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = replacement,
                            onValueChange = { replacement = it },
                            label = { Text(stringResource(R.string.editor_replace)) },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                        )
                        TextButton(onClick = { replaceCurrent() }, enabled = curIndex >= 0) {
                            Text(stringResource(R.string.editor_replace))
                        }
                        TextButton(onClick = { replaceAll() }, enabled = matchStarts.isNotEmpty()) { Text("All") }
                    }
                }
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
        }

        // ---- the editing surface ----
        Box(Modifier.weight(1f).fillMaxWidth().background(EditorBg)) {
            val error = loadError
            if (error != null) {
                Text(
                    stringResource(error),
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    modifier = Modifier.align(Alignment.Center).padding(32.dp),
                )
            } else if (!pageLoaded) {
                Text(
                    stringResource(R.string.editor_loading),
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    modifier = Modifier.align(Alignment.Center),
                )
            } else {
                val lineCount = remember(tfv.text) { tfv.text.count { it == '\n' } + 1 }
                val gutterText = remember(lineCount) { (1..lineCount).joinToString("\n") }
                Row(Modifier.fillMaxSize().verticalScroll(vScroll)) {
                    Text(
                        gutterText,
                        style = EditorTextStyle.copy(color = GutterFg, textAlign = TextAlign.End),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 8.dp),
                    )
                    Box(Modifier.weight(1f).horizontalScroll(hScroll)) {
                        BasicTextField(
                            value = tfv,
                            onValueChange = { applyEdit(it, true) },
                            readOnly = readOnly,
                            textStyle = EditorTextStyle,
                            cursorBrush = SolidColor(Color.White),
                            softWrap = false,
                            visualTransformation = highlighter,
                            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.None),
                            modifier = Modifier.heightIn(min = 300.dp).padding(horizontal = 8.dp, vertical = 8.dp),
                        )
                    }
                }
            }
        }
        // ---- status ----
        if (pageLoaded && loadError == null) {
            val pos = remember(tfv.selection.start, tfv.text) {
                val p = tfv.selection.start.coerceIn(0, tfv.text.length)
                var line = 1
                var lastNl = -1
                for (k in 0 until p) if (tfv.text[k] == '\n') { line++; lastNl = k }
                "Ln $line, Col ${p - lastNl}"
            }
            Row(
                Modifier.fillMaxWidth().background(Color(0xFF21252B)).padding(horizontal = 10.dp, vertical = 3.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text(pos, style = MaterialTheme.typography.labelSmall, color = GutterFg)
                Text(if (eol == "\r\n") "CRLF" else "LF", style = MaterialTheme.typography.labelSmall, color = GutterFg)
                Text(
                    if (readOnly) "VIEW" else "EDIT",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (readOnly) Color(0xFFE5C07B) else Color(0xFF98C379),
                )
            }
        }
    }

    // ---- dialogs ----
    if (showSaveAs) {
        var input by remember { mutableStateOf(fileName) }
        AlertDialog(
            onDismissRequest = { showSaveAs = false },
            title = { Text(stringResource(R.string.editor_save_as_title)) },
            text = {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    label = { Text(stringResource(R.string.editor_save_as_label)) },
                    singleLine = true,
                )
            },
            confirmButton = {
                TextButton(
                    onClick = { requestSaveAs(input) },
                    enabled = input.isNotBlank() && !input.trim().endsWith("/"),
                ) { Text(stringResource(R.string.editor_save)) }
            },
            dismissButton = {
                TextButton(onClick = { showSaveAs = false }) { Text(stringResource(R.string.cancel)) }
            },
            containerColor = MaterialTheme.colorScheme.surface,
        )
    }

    overwriteTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { overwriteTarget = null },
            title = { Text(stringResource(R.string.editor_overwrite_title)) },
            text = { Text(stringResource(R.string.editor_overwrite_body, RemotePath.name(target))) },
            confirmButton = {
                TextButton(onClick = {
                    overwriteTarget = null
                    save(target)
                }) { Text(stringResource(R.string.editor_overwrite_confirm), color = Danger) }
            },
            dismissButton = {
                TextButton(onClick = { overwriteTarget = null }) { Text(stringResource(R.string.cancel)) }
            },
            containerColor = MaterialTheme.colorScheme.surface,
        )
    }

    if (confirmClose) {
        AlertDialog(
            onDismissRequest = { confirmClose = false },
            title = { Text(stringResource(R.string.editor_unsaved_title)) },
            text = { Text(stringResource(R.string.editor_unsaved_body, fileName)) },
            confirmButton = {
                TextButton(onClick = {
                    confirmClose = false
                    // Close only once the save really went through.
                    scope.launch { if (saveNow(path)) controller.closeEditor() }
                }) { Text(stringResource(R.string.editor_save)) }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { confirmClose = false }) { Text(stringResource(R.string.cancel)) }
                    TextButton(onClick = {
                        confirmClose = false
                        controller.closeEditor()
                    }) { Text(stringResource(R.string.editor_discard), color = Danger) }
                }
            },
            containerColor = MaterialTheme.colorScheme.surface,
        )
    }
}

@Composable
private fun ToolButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String,
    enabled: Boolean = true,
    highlighted: Boolean = false,
    onClick: () -> Unit,
) {
    IconButton(onClick = onClick, enabled = enabled, modifier = Modifier.size(40.dp)) {
        Icon(
            icon,
            description,
            tint = when {
                !enabled -> TextSecondary.copy(alpha = 0.38f)
                highlighted -> Turquoise
                else -> MaterialTheme.colorScheme.onSurface
            },
        )
    }
}

// ---- text <-> bytes ----

private class Decoded(val text: String, val eol: String, val charsetName: String, val bom: Boolean)

/** Bytes to editable text, or null for a binary file. Line endings are normalised and restored on save. */
private fun decode(bytes: ByteArray): Decoded? {
    val probe = minOf(bytes.size, 8192)
    for (i in 0 until probe) if (bytes[i] == 0.toByte()) return null
    val bom = bytes.size >= 3 &&
        bytes[0] == 0xEF.toByte() && bytes[1] == 0xBB.toByte() && bytes[2] == 0xBF.toByte()
    val body = if (bom) bytes.copyOfRange(3, bytes.size) else bytes
    var charset = "UTF-8"
    val text = try {
        Charsets.UTF_8.newDecoder()
            .onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT)
            .decode(ByteBuffer.wrap(body))
            .toString()
    } catch (e: CharacterCodingException) {
        // Not UTF-8: keep the bytes round-trippable as Latin-1 rather than refusing the file.
        charset = "ISO-8859-1"
        String(body, Charsets.ISO_8859_1)
    }
    val crlf = text.contains("\r\n")
    return Decoded(if (crlf) text.replace("\r\n", "\n") else text, if (crlf) "\r\n" else "\n", charset, bom)
}

private fun encode(text: String, eol: String, charsetName: String, bom: Boolean): ByteArray {
    val withEol = if (eol == "\r\n") text.replace("\n", "\r\n") else text
    val body = withEol.toByteArray(Charset.forName(charsetName))
    return if (bom) byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()) + body else body
}

