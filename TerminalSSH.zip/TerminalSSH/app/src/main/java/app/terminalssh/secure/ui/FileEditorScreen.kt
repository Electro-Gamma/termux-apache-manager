package app.terminalssh.secure.ui

import androidx.activity.compose.BackHandler
import android.view.View
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.Redo
import androidx.compose.material.icons.automirrored.outlined.Undo
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.FindReplace
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.KeyboardArrowUp
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.Save
import androidx.compose.material.icons.outlined.SaveAs
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import app.terminalssh.secure.R
import app.terminalssh.secure.sftp.FileTooLarge
import app.terminalssh.secure.sftp.RemotePath
import app.terminalssh.secure.sftp.SftpClient
import app.terminalssh.secure.sftp.SftpController
import app.terminalssh.secure.storage.Settings
import app.terminalssh.secure.viewer.PdfPane
import app.terminalssh.secure.viewer.ViewerKind
import app.terminalssh.secure.viewer.ViewerPane
import app.terminalssh.secure.viewer.viewerKindFor
import app.terminalssh.secure.ui.theme.Danger
import app.terminalssh.secure.ui.theme.TextSecondary
import app.terminalssh.secure.ui.theme.Turquoise
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction

private val EditorSurface = Color(EDITOR_BG)
private val StatusFg = Color(0xFF636D83)

/** Text size at 100% zoom, in sp. The pinch and the A-/A+ buttons scale this. */
private const val EDITOR_BASE_SP = 13f
private const val EDITOR_ZOOM_HUD_MS = 2_200L

/** Above this many characters the file is shown without colours, to stay quick. */
private const val MAX_COLOUR_CHARS = 400_000

/** Match positions found in the text as it was at edit number [gen]. */
private class MatchSet(val starts: IntArray, val length: Int, val gen: Int)

private fun findAll(text: String, query: String): IntArray {
    val out = ArrayList<Int>()
    var i = text.indexOf(query, 0, ignoreCase = true)
    while (i >= 0 && out.size < 50_000) {
        out.add(i)
        i = text.indexOf(query, i + query.length, ignoreCase = true)
    }
    return out.toIntArray()
}

/**
 * The File Manager's built-in editor for a remote file.
 *
 * The text lives in a native [CodeEditText] that draws only what is on screen, so large files
 * stay quick; this screen holds the toolbar, find/replace, save and the dialogs. Syntax colours
 * come from Highlight.js in a hidden WebView (see [SyntaxHighlighter]) and are applied only
 * around the visible lines. Pinch with two fingers to zoom, as in the terminal.
 *
 * The session (file, unsaved text) is kept in [SftpController.editor], so switching tabs and
 * coming back reopens the same file with any unsaved edits.
 */
@Composable
fun FileEditorScreen(controller: SftpController, settings: Settings) {
    val scope = rememberCoroutineScope()
    val initial = remember { controller.editor.value } ?: return

    var path by remember { mutableStateOf(initial.entry.path) }
    val fileName = RemotePath.name(path)

    var eol by remember { mutableStateOf(initial.eol) }
    var charsetName by remember { mutableStateOf(initial.charsetName) }
    var bom by remember { mutableStateOf(initial.bom) }
    var loadError by remember { mutableStateOf<Int?>(null) }

    // The editor view, and what the screen needs to know about it.
    var editorView by remember { mutableStateOf<CodeEditText?>(null) }
    var changeTick by remember { mutableIntStateOf(0) }
    var canUndo by remember { mutableStateOf(false) }
    var canRedo by remember { mutableStateOf(false) }
    var caretLine by remember { mutableIntStateOf(1) }
    var caretCol by remember { mutableIntStateOf(1) }
    var unknownBase by remember { mutableStateOf(false) }
    var pageLoaded by remember { mutableStateOf(false) }
    var readOnly by remember { mutableStateOf(initial.readOnly) }

    // .md / .ipynb / .svg / .pbm open in the rendered Viewer; the pencil shows their source.
    // Binary kinds (.pbm, images, .pdf): viewer only, never decoded into the text editor.
    val kind = remember(path) { viewerKindFor(RemotePath.name(path)) }
    val isBinary = kind?.binary == true
    var viewing by remember { mutableStateOf(initial.rendered) }
    var viewerText by remember { mutableStateOf<String?>(null) }
    var viewerBytes by remember { mutableStateOf<ByteArray?>(null) }
    val showViewer = kind != null && (viewing || isBinary)
    val dark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
    var saving by remember { mutableStateOf(false) }
    var notice by remember { mutableStateOf<Pair<Int, Boolean>?>(null) }

    @Suppress("UNUSED_VARIABLE")
    val subscribeToEdits = changeTick // re-evaluate "unsaved" after every edit
    val dirty = pageLoaded && (unknownBase || editorView?.isModified() == true)

    // Zoom: one value, remembered across launches. Pinch and the A-/A+ keys both go through
    // applyZoom, so they cannot disagree.
    var zoom by remember { mutableFloatStateOf(settings.editorZoom) }
    var pendingPinch by remember { mutableFloatStateOf(1f) }
    var zoomHudTick by remember { mutableIntStateOf(0) }
    var zoomHudVisible by remember { mutableStateOf(false) }
    val applyZoom: (Float) -> Unit = { target ->
        val next = TerminalZoom.clamp(target)
        if (next != zoom) {
            zoom = next
            zoomHudTick++
        }
    }
    LaunchedEffect(zoomHudTick) {
        if (zoomHudTick > 0) {
            zoomHudVisible = true
            delay(EDITOR_ZOOM_HUD_MS)
            zoomHudVisible = false
        }
    }

    // Find / replace.
    var findOpen by remember { mutableStateOf(false) }
    var showReplace by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var replacement by remember { mutableStateOf("") }
    var cur by remember { mutableIntStateOf(0) }
    var jumpPending by remember { mutableStateOf(false) }
    var matches by remember { mutableStateOf(MatchSet(IntArray(0), 0, -1)) }

    var menuOpen by remember { mutableStateOf(false) }
    var showSaveAs by remember { mutableStateOf(false) }
    var overwriteTarget by remember { mutableStateOf<String?>(null) }
    var confirmClose by remember { mutableStateOf(false) }

    LaunchedEffect(notice) {
        if (notice != null) {
            delay(2500)
            notice = null
        }
    }

    // ---- syntax colours ----
    val appContext = LocalContext.current.applicationContext
    val highlighter = remember { SyntaxHighlighter(appContext) }
    DisposableEffect(highlighter) { onDispose { highlighter.destroy() } }
    val language = remember(fileName, pageLoaded, editorView, isBinary) {
        val v = editorView
        if (!pageLoaded || v == null || isBinary) null else editorLanguage(fileName, v.firstLine())
    }
    var hlNote by remember { mutableStateOf("") }
    LaunchedEffect(pageLoaded, language, changeTick, editorView) {
        val v = editorView
        val lang = language
        if (!pageLoaded || v == null || lang == null) {
            v?.setHighlight(null, 0)
            hlNote = ""
            return@LaunchedEffect
        }
        if (v.textLength() > MAX_COLOUR_CHARS) {
            v.setHighlight(null, 0)
            hlNote = "too large to colour"
            return@LaunchedEffect
        }
        if (v.hasHighlight) delay(300) // while typing, wait for a pause
        val gen = v.editCount
        val r = highlighter.highlight(v.textString(), lang)
        if (r != null) {
            v.setHighlight(r, gen)
            hlNote = ""
        } else {
            hlNote = "colours off: " + (highlighter.lastError ?: "failed").take(40)
        }
    }

    // ---- find matches: searched off the main thread, painted only near the visible lines ----
    LaunchedEffect(findOpen, query, changeTick, editorView) {
        val v = editorView ?: return@LaunchedEffect
        if (!findOpen || query.isEmpty()) {
            if (matches.starts.isNotEmpty()) matches = MatchSet(IntArray(0), 0, v.editCount)
            return@LaunchedEffect
        }
        delay(150) // typing in the box, or editing: search once things settle
        val gen = v.editCount
        val snapshot = v.textString()
        val q = query
        val found = withContext(Dispatchers.Default) { findAll(snapshot, q) }
        matches = MatchSet(found, q.length, gen)
        if (jumpPending && found.isNotEmpty()) {
            jumpPending = false
            cur = 0
            v.revealRange(found[0], found[0] + q.length)
        }
    }
    val curIndex = if (matches.starts.isEmpty()) -1 else cur.coerceIn(0, matches.starts.size - 1)
    LaunchedEffect(matches, curIndex, editorView) {
        editorView?.setMatches(matches.starts, matches.length, curIndex, matches.gen)
    }

    // ---- load the file (or restore the unsaved text of an earlier visit) ----
    LaunchedEffect(Unit) {
        val v = snapshotFlow { editorView }.filterNotNull().first()
        val draft = initial.draft
        if (draft != null) {
            v.setContent(draft)
            viewerText = draft
            unknownBase = true
            pageLoaded = true
            return@LaunchedEffect
        }
        try {
            // readFile enforces the editor's 2 MB limit for every type, viewer files included.
            val bytes = controller.readFile(initial.entry.path)
            if (isBinary) {
                // Binary (bitmap, image, PDF): handed to the viewer as bytes only, never to the text editor.
                viewerBytes = bytes
                pageLoaded = true
                return@LaunchedEffect
            }
            val decoded = decode(bytes)
            if (decoded == null) {
                loadError = R.string.editor_binary
            } else {
                eol = decoded.eol
                charsetName = decoded.charsetName
                bom = decoded.bom
                controller.updateEditor { it.copy(eol = decoded.eol, charsetName = decoded.charsetName, bom = decoded.bom) }
                v.setContent(decoded.text)
                viewerText = decoded.text
                pageLoaded = true
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: FileTooLarge) {
            loadError = R.string.editor_too_large
        } catch (t: Throwable) {
            loadError = SftpClient.classify(t).stringRes
        }
    }

    // Keep the unsaved text in the session so leaving the tab does not lose it.
    LaunchedEffect(changeTick, dirty) {
        if (!pageLoaded) return@LaunchedEffect
        if (dirty) {
            delay(600)
            val t = editorView?.textString() ?: return@LaunchedEffect
            controller.updateEditor { it.copy(draft = t) }
        } else {
            controller.updateEditor { it.copy(draft = null) }
        }
    }
    val latestDirty by rememberUpdatedState(dirty)
    DisposableEffect(Unit) {
        onDispose {
            // Leaving right after a keystroke: store what is there now, not what was 600 ms ago.
            val v = editorView
            if (latestDirty && v != null) {
                val t = v.textString()
                controller.updateEditor { it.copy(draft = t) }
            }
        }
    }

    /** Writes the current text to [target]. True when it was saved. */
    suspend fun saveNow(target: String): Boolean {
        val v = editorView
        if (saving || !pageLoaded || v == null || isBinary) return false
        saving = true
        return try {
            val text = v.textString()
            val bytes = withContext(Dispatchers.Default) { encode(text, eol, charsetName, bom) }
            controller.writeFile(target, bytes)
            // Saved under a name of another type: show it as plain source, not suddenly rendered.
            if (viewerKindFor(RemotePath.name(target)) != kind) viewing = false
            path = target
            v.markSaved()
            unknownBase = false
            changeTick++
            controller.updateEditor {
                it.copy(entry = it.entry.copy(path = target, name = RemotePath.name(target)), draft = null)
            }
            notice = R.string.editor_saved to false
            controller.refresh()
            true
        } catch (e: CancellationException) {
            throw e
        } catch (t: Throwable) {
            notice = SftpClient.classify(t).stringRes to true
            false
        } finally {
            saving = false
        }
    }

    fun save(target: String) { scope.launch { saveNow(target) } }

    fun requestSaveAs(input: String) {
        val trimmed = input.trim()
        if (trimmed.isEmpty() || trimmed.endsWith("/")) return
        val target = RemotePath.join(RemotePath.parent(path), trimmed)
        showSaveAs = false
        if (target == path) {
            save(target)
            return
        }
        scope.launch {
            if (controller.fileExists(target)) overwriteTarget = target else save(target)
        }
    }

    fun setEditing(editing: Boolean) {
        readOnly = !editing
        editorView?.setReadOnlyMode(!editing)
        controller.updateEditor { it.copy(readOnly = !editing) }
    }

    /** Pencil: from the rendered Viewer to the source, ready to edit. Never for a binary bitmap. */
    fun enterSource() {
        if (kind == null || isBinary) return
        viewing = false
        setEditing(true)
        controller.updateEditor { it.copy(rendered = false) }
    }

    /** Eye: back to the rendered Viewer, showing the text as it is now (unsaved edits included). */
    fun enterViewer() {
        val v = editorView ?: return
        if (kind == null) return
        if (!isBinary) viewerText = v.textString()
        findOpen = false
        viewing = true
        setEditing(false) // also drops the keyboard
        controller.updateEditor { it.copy(rendered = true) }
    }

    fun goToMatch(i: Int) {
        val ms = matches.starts
        if (ms.isEmpty()) return
        val idx = ((i % ms.size) + ms.size) % ms.size
        cur = idx
        editorView?.revealRange(ms[idx], ms[idx] + matches.length)
    }

    fun replaceCurrent() {
        val v = editorView ?: return
        val idx = curIndex
        if (idx < 0 || matches.gen != v.editCount) return // positions are out of date; try again
        if (readOnly) setEditing(true)
        v.replaceRange(matches.starts[idx], matches.length, replacement)
    }

    fun replaceAll() {
        val v = editorView ?: return
        if (query.isEmpty()) return
        if (readOnly) setEditing(true)
        val q = query
        val rep = replacement
        scope.launch {
            val gen = v.editCount
            val src = v.textString()
            val replaced = withContext(Dispatchers.Default) {
                Regex(Regex.escape(q), RegexOption.IGNORE_CASE).replace(src, Regex.escapeReplacement(rep))
            }
            if (v.editCount == gen && replaced != src) v.replaceAllText(replaced)
        }
    }

    // Back closes the find bar first, then offers to save, then leaves the editor.
    BackHandler(enabled = true) {
        when {
            menuOpen -> menuOpen = false
            findOpen -> findOpen = false
            dirty -> confirmClose = true
            else -> controller.closeEditor()
        }
    }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surface)) {
        // ---- title row ----
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(
                onClick = { if (dirty) confirmClose = true else controller.closeEditor() },
                modifier = Modifier.size(44.dp),
            ) {
                Icon(Icons.AutoMirrored.Outlined.ArrowBack, stringResource(R.string.editor_close))
            }
            Column(Modifier.weight(1f).padding(horizontal = 4.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        ltr(fileName),
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false),
                    )
                    if (dirty) {
                        Text(" ●", color = Turquoise, style = MaterialTheme.typography.titleMedium)
                    }
                }
                val note = notice
                if (note != null) {
                    Text(
                        stringResource(note.first),
                        style = MaterialTheme.typography.labelSmall,
                        color = if (note.second) MaterialTheme.colorScheme.error else Turquoise,
                        maxLines = 1,
                    )
                } else {
                    Text(
                        ltr(path),
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
            Box {
                IconButton(onClick = { menuOpen = true }, modifier = Modifier.size(44.dp)) {
                    Icon(Icons.Outlined.MoreVert, stringResource(R.string.editor_more))
                }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    MenuEntry(
                        Icons.Outlined.Save,
                        stringResource(R.string.editor_save),
                        { menuOpen = false },
                        enabled = dirty && !saving && pageLoaded,
                    ) { save(path) }
                    MenuEntry(
                        Icons.Outlined.SaveAs,
                        stringResource(R.string.editor_save_as),
                        { menuOpen = false },
                        enabled = !saving && pageLoaded && !isBinary,
                    ) { showSaveAs = true }
                }
            }
        }

        // ---- tool row: Edit, Undo, Redo, Find, Replace, Save ----
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            val on = pageLoaded
            if (kind != null) {
                if (showViewer) {
                    ToolButton(
                        Icons.Outlined.Edit,
                        stringResource(if (isBinary) R.string.editor_viewer_only else R.string.editor_edit),
                        enabled = on && !isBinary,
                    ) { enterSource() }
                } else {
                    ToolButton(
                        Icons.Outlined.Visibility,
                        stringResource(R.string.editor_viewer),
                        enabled = on,
                        highlighted = true,
                    ) { enterViewer() }
                }
            } else {
                ToolButton(
                    if (readOnly) Icons.Outlined.Edit else Icons.Outlined.Visibility,
                    stringResource(if (readOnly) R.string.editor_edit else R.string.editor_view_only),
                    enabled = on,
                    highlighted = !readOnly,
                ) { setEditing(readOnly) }
            }
            ToolButton(
                Icons.AutoMirrored.Outlined.Undo,
                stringResource(R.string.editor_undo),
                enabled = on && canUndo && !readOnly && !showViewer,
            ) { editorView?.undo() }
            ToolButton(
                Icons.AutoMirrored.Outlined.Redo,
                stringResource(R.string.editor_redo),
                enabled = on && canRedo && !readOnly && !showViewer,
            ) { editorView?.redo() }
            ToolButton(
                Icons.Outlined.Search,
                stringResource(R.string.editor_find),
                enabled = on && !showViewer,
                highlighted = findOpen && !showReplace,
            ) { findOpen = true; showReplace = false }
            ToolButton(
                Icons.Outlined.FindReplace,
                stringResource(R.string.editor_replace),
                enabled = on && !showViewer,
                highlighted = findOpen && showReplace,
            ) { findOpen = true; showReplace = true }
            ToolButton(
                Icons.Outlined.Save,
                stringResource(R.string.editor_save),
                enabled = on && dirty && !saving,
                highlighted = dirty,
            ) { save(path) }
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

        // ---- find / replace bar ----
        if (findOpen) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it; cur = 0; jumpPending = true },
                        label = { Text(stringResource(R.string.editor_find)) },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                    )
                    Text(
                        if (matches.starts.isEmpty()) "0/0" else "${curIndex + 1}/${matches.starts.size}",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary,
                        modifier = Modifier.padding(horizontal = 6.dp),
                    )
                    IconButton(onClick = { goToMatch(curIndex - 1) }, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Outlined.KeyboardArrowUp, null)
                    }
                    IconButton(onClick = { goToMatch(curIndex + 1) }, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Outlined.KeyboardArrowDown, null)
                    }
                    IconButton(onClick = { findOpen = false }, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Outlined.Close, null)
                    }
                }
                if (showReplace) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = replacement,
                            onValueChange = { replacement = it },
                            label = { Text(stringResource(R.string.editor_replace)) },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                        )
                        TextButton(onClick = { replaceCurrent() }, enabled = curIndex >= 0) {
                            Text(stringResource(R.string.editor_replace))
                        }
                        TextButton(onClick = { replaceAll() }, enabled = matches.starts.isNotEmpty()) { Text("All") }
                    }
                }
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
        }

        // ---- the editing surface ----
        // No keyboard padding here: RootScreen's dock already reserves max(tab bar, keyboard)
        // below this screen, so this area shrinks as the keyboard rises and the editor view
        // scrolls the caret into the part that is left.
        Box(Modifier.weight(1f).fillMaxWidth().background(EditorSurface).clipToBounds()) {
            val error = loadError
            if (error != null) {
                Text(
                    stringResource(error),
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    modifier = Modifier.align(Alignment.Center).padding(32.dp),
                )
            } else {
                AndroidView(
                    factory = { ctx -> CodeEditText(ctx) },
                    modifier = Modifier.fillMaxSize(),
                    update = { v ->
                        if (editorView !== v) editorView = v
                        v.onEdited = {
                            changeTick++
                            canUndo = v.canUndo
                            canRedo = v.canRedo
                        }
                        v.onCaret = { line, col ->
                            if (caretLine != line) caretLine = line
                            if (caretCol != col) caretCol = col
                        }
                        v.onPinch = { factor ->
                            val (nextZoom, remainder) = TerminalZoom.applyPinch(zoom, pendingPinch, factor)
                            pendingPinch = remainder
                            applyZoom(nextZoom)
                        }
                        v.onPinchEnd = {
                            pendingPinch = 1f
                            settings.editorZoom = zoom
                        }
                        v.setReadOnlyMode(readOnly)
                        v.setTextSizeSp(EDITOR_BASE_SP * zoom)
                        v.importantForAccessibility = if (showViewer) {
                            View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
                        } else {
                            View.IMPORTANT_FOR_ACCESSIBILITY_AUTO
                        }
                    },
                )
                // The rendered view sits over the editor, which keeps its text and scroll
                // position underneath. Hidden (not destroyed) while the source is showing.
                if (kind == ViewerKind.PDF) {
                    if (pageLoaded && showViewer) PdfPane(bytes = viewerBytes, dark = dark, modifier = Modifier.fillMaxSize())
                } else if (kind != null && pageLoaded) {
                    ViewerPane(
                        kind = kind,
                        text = viewerText,
                        bytes = viewerBytes,
                        visible = showViewer,
                        dark = dark,
                        modifier = Modifier.fillMaxSize(),
                    )
                }
                if (!pageLoaded) {
                    Text(
                        stringResource(R.string.editor_loading),
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary,
                        modifier = Modifier.align(Alignment.Center),
                    )
                }
                val zoomHudAlpha by animateFloatAsState(
                    if (zoomHudVisible) 1f else 0f,
                    Motion.normal(),
                    label = "editor-zoom-hud",
                )
                if (zoomHudAlpha > 0f) {
                    Box(
                        Modifier
                            .align(Alignment.TopEnd)
                            .padding(12.dp)
                            .graphicsLayer { alpha = zoomHudAlpha },
                    ) {
                        ZoomHud(
                            zoom = zoom,
                            onZoomOut = { applyZoom(TerminalZoom.step(zoom, -1)); settings.editorZoom = zoom },
                            onZoomIn = { applyZoom(TerminalZoom.step(zoom, +1)); settings.editorZoom = zoom },
                            onReset = { applyZoom(TerminalZoom.DEFAULT); settings.editorZoom = zoom },
                        )
                    }
                }
            }
        }

        // ---- status ----
        if (pageLoaded && loadError == null) {
            Row(
                Modifier.fillMaxWidth().background(Color(0xFF21252B)).padding(horizontal = 10.dp, vertical = 3.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                if (showViewer) {
                    Text(kind?.label.orEmpty(), style = MaterialTheme.typography.labelSmall, color = StatusFg)
                } else {
                    Text("Ln $caretLine, Col $caretCol", style = MaterialTheme.typography.labelSmall, color = StatusFg)
                    Text(if (eol == "\r\n") "CRLF" else "LF", style = MaterialTheme.typography.labelSmall, color = StatusFg)
                    Text(language ?: "plain text", style = MaterialTheme.typography.labelSmall, color = StatusFg)
                }
                if (hlNote.isNotEmpty()) {
                    Text(hlNote, style = MaterialTheme.typography.labelSmall, color = Color(0xFFE5C07B), maxLines = 1)
                }
                Text(
                    if (showViewer) "VIEWER" else if (readOnly) "VIEW" else "EDIT",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (showViewer || readOnly) Color(0xFFE5C07B) else Color(0xFF98C379),
                )
            }
        }
    }

    // ---- dialogs ----
    if (showSaveAs) {
        var input by remember { mutableStateOf(fileName) }
        AlertDialog(
            onDismissRequest = { showSaveAs = false },
            title = { Text(stringResource(R.string.editor_save_as_title)) },
            text = {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    label = { Text(stringResource(R.string.editor_save_as_label)) },
                    singleLine = true,
                )
            },
            confirmButton = {
                TextButton(
                    onClick = { requestSaveAs(input) },
                    enabled = input.isNotBlank() && !input.trim().endsWith("/"),
                ) { Text(stringResource(R.string.editor_save)) }
            },
            dismissButton = {
                TextButton(onClick = { showSaveAs = false }) { Text(stringResource(R.string.cancel)) }
            },
            containerColor = MaterialTheme.colorScheme.surface,
        )
    }

    overwriteTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { overwriteTarget = null },
            title = { Text(stringResource(R.string.editor_overwrite_title)) },
            text = { Text(stringResource(R.string.editor_overwrite_body, RemotePath.name(target))) },
            confirmButton = {
                TextButton(onClick = {
                    overwriteTarget = null
                    save(target)
                }) { Text(stringResource(R.string.editor_overwrite_confirm), color = Danger) }
            },
            dismissButton = {
                TextButton(onClick = { overwriteTarget = null }) { Text(stringResource(R.string.cancel)) }
            },
            containerColor = MaterialTheme.colorScheme.surface,
        )
    }

    if (confirmClose) {
        AlertDialog(
            onDismissRequest = { confirmClose = false },
            title = { Text(stringResource(R.string.editor_unsaved_title)) },
            text = { Text(stringResource(R.string.editor_unsaved_body, fileName)) },
            confirmButton = {
                TextButton(onClick = {
                    confirmClose = false
                    // Close only once the save really went through.
                    scope.launch { if (saveNow(path)) controller.closeEditor() }
                }) { Text(stringResource(R.string.editor_save)) }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { confirmClose = false }) { Text(stringResource(R.string.cancel)) }
                    TextButton(onClick = {
                        confirmClose = false
                        controller.closeEditor()
                    }) { Text(stringResource(R.string.editor_discard), color = Danger) }
                }
            },
            containerColor = MaterialTheme.colorScheme.surface,
        )
    }
}

@Composable
private fun ToolButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String,
    enabled: Boolean = true,
    highlighted: Boolean = false,
    onClick: () -> Unit,
) {
    IconButton(onClick = onClick, enabled = enabled, modifier = Modifier.size(40.dp)) {
        Icon(
            icon,
            description,
            tint = when {
                !enabled -> TextSecondary.copy(alpha = 0.38f)
                highlighted -> Turquoise
                else -> MaterialTheme.colorScheme.onSurface
            },
        )
    }
}

// ---- text <-> bytes ----

private class Decoded(val text: String, val eol: String, val charsetName: String, val bom: Boolean)

/** Bytes to editable text, or null for a binary file. Line endings are normalised and restored on save. */
private fun decode(bytes: ByteArray): Decoded? {
    val probe = minOf(bytes.size, 8192)
    for (i in 0 until probe) if (bytes[i] == 0.toByte()) return null
    val bom = bytes.size >= 3 &&
        bytes[0] == 0xEF.toByte() && bytes[1] == 0xBB.toByte() && bytes[2] == 0xBF.toByte()
    val body = if (bom) bytes.copyOfRange(3, bytes.size) else bytes
    var charset = "UTF-8"
    val text = try {
        Charsets.UTF_8.newDecoder()
            .onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT)
            .decode(ByteBuffer.wrap(body))
            .toString()
    } catch (e: CharacterCodingException) {
        // Not UTF-8: keep the bytes round-trippable as Latin-1 rather than refusing the file.
        charset = "ISO-8859-1"
        String(body, Charsets.ISO_8859_1)
    }
    val crlf = text.contains("\r\n")
    return Decoded(if (crlf) text.replace("\r\n", "\n") else text, if (crlf) "\r\n" else "\n", charset, bom)
}

private fun encode(text: String, eol: String, charsetName: String, bom: Boolean): ByteArray {
    val withEol = if (eol == "\r\n") text.replace("\n", "\r\n") else text
    val body = withEol.toByteArray(Charset.forName(charsetName))
    return if (bom) byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()) + body else body
}

