package app.terminalssh.secure.ui

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color as AndroidColor
import android.os.Handler
import android.os.Looper
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.Redo
import androidx.compose.material.icons.automirrored.outlined.Undo
import androidx.compose.material.icons.outlined.Code
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.FindReplace
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.Save
import androidx.compose.material.icons.outlined.SaveAs
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import app.terminalssh.secure.R
import app.terminalssh.secure.sftp.FileTooLarge
import app.terminalssh.secure.sftp.RemotePath
import app.terminalssh.secure.sftp.SftpClient
import app.terminalssh.secure.sftp.SftpController
import app.terminalssh.secure.ui.theme.Danger
import app.terminalssh.secure.ui.theme.TextSecondary
import app.terminalssh.secure.ui.theme.Turquoise
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import org.json.JSONObject
import org.json.JSONTokener
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction
import kotlin.coroutines.resume

/**
 * The File Manager's built-in editor for a remote file.
 *
 * The text surface is a small WebView page (assets/editor) that uses Highlight.js for
 * syntax colouring, with its own undo history and find/replace. This composable owns
 * everything that touches the server: opening, decoding, Save and Save As.
 *
 * Clicking a file in the browser opens it here instead of downloading it. The session
 * (file, unsaved text) is kept in [SftpController.editor], so switching tabs and coming
 * back reopens the same file with any unsaved edits.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun FileEditorScreen(controller: SftpController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val initial = remember { controller.editor.value } ?: return

    var path by remember { mutableStateOf(initial.entry.path) }
    val fileName = RemotePath.name(path)

    // What the page is asked to show once it is ready.
    var content by remember { mutableStateOf<String?>(null) }
    var startDirty by remember { mutableStateOf(false) }
    var eol by remember { mutableStateOf(initial.eol) }
    var charsetName by remember { mutableStateOf(initial.charsetName) }
    var bom by remember { mutableStateOf(initial.bom) }
    var loadError by remember { mutableStateOf<Int?>(null) }

    var pageReady by remember { mutableStateOf(false) }
    var pageLoaded by remember { mutableStateOf(false) }
    var dirty by remember { mutableStateOf(false) }
    var canUndo by remember { mutableStateOf(false) }
    var canRedo by remember { mutableStateOf(false) }
    var findOpen by remember { mutableStateOf(false) }
    var readOnly by remember { mutableStateOf(initial.readOnly) }
    var saving by remember { mutableStateOf(false) }
    var notice by remember { mutableStateOf<Pair<Int, Boolean>?>(null) }

    var menuOpen by remember { mutableStateOf(false) }
    var showSaveAs by remember { mutableStateOf(false) }
    var overwriteTarget by remember { mutableStateOf<String?>(null) }
    var confirmClose by remember { mutableStateOf(false) }
    var showLanguages by remember { mutableStateOf(false) }

    var webView by remember { mutableStateOf<WebView?>(null) }
    fun js(code: String) { webView?.evaluateJavascript(code, null) }

    LaunchedEffect(notice) {
        if (notice != null) {
            delay(2500)
            notice = null
        }
    }

    // ---- load the file (or restore the unsaved text of an earlier visit) ----
    LaunchedEffect(Unit) {
        val draft = initial.draft
        if (draft != null) {
            content = draft
            startDirty = true
            return@LaunchedEffect
        }
        try {
            val decoded = decode(controller.readFile(initial.entry.path))
            if (decoded == null) {
                loadError = R.string.editor_binary
            } else {
                eol = decoded.eol
                charsetName = decoded.charsetName
                bom = decoded.bom
                controller.updateEditor { it.copy(eol = decoded.eol, charsetName = decoded.charsetName, bom = decoded.bom) }
                content = decoded.text
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: FileTooLarge) {
            loadError = R.string.editor_too_large
        } catch (t: Throwable) {
            loadError = SftpClient.classify(t).stringRes
        }
    }

    LaunchedEffect(pageReady, content) {
        val text = content ?: return@LaunchedEffect
        if (pageReady && !pageLoaded) {
            pageLoaded = true
            js("Ed.load(${jsString(text)},${jsString(fileName)},${jsString(eol)},$startDirty,$readOnly)")
            // A WebView that first draws inside the tab Crossfade's alpha layer can stay blank until
            // something invalidates it. Nudge it once the text is in and again after the colour pass.
            repaintWebView(webView)
            delay(120)
            repaintWebView(webView)
            delay(500)
            repaintWebView(webView)
        }
    }

    // Null when the page cannot answer. A save must then fail, never write an empty file.
    suspend fun fetchText(): String? = suspendCancellableCoroutine { cont ->
        val wv = webView
        if (wv == null) {
            cont.resume(null)
        } else {
            wv.evaluateJavascript("Ed.getText()") { raw ->
                cont.resume(runCatching { JSONTokener(raw).nextValue() }.getOrNull() as? String)
            }
        }
    }

    /** Writes the current text to [target]. True when it was saved. */
    suspend fun saveNow(target: String): Boolean {
        if (saving || !pageLoaded) return false
        saving = true
        return try {
            val text = fetchText() ?: throw IllegalStateException("editor is not available")
            val bytes = encode(text, eol, charsetName, bom)
            controller.writeFile(target, bytes)
            path = target
            js("Ed.markSaved();Ed.setName(${jsString(RemotePath.name(target))})")
            controller.updateEditor {
                it.copy(entry = it.entry.copy(path = target, name = RemotePath.name(target)), draft = null)
            }
            dirty = false
            notice = R.string.editor_saved to false
            controller.refresh()
            true
        } catch (e: CancellationException) {
            throw e
        } catch (t: Throwable) {
            notice = SftpClient.classify(t).stringRes to true
            false
        } finally {
            saving = false
        }
    }

    fun save(target: String) { scope.launch { saveNow(target) } }

    fun requestSaveAs(input: String) {
        val trimmed = input.trim()
        if (trimmed.isEmpty() || trimmed.endsWith("/")) return
        val target = RemotePath.join(RemotePath.parent(path), trimmed)
        showSaveAs = false
        if (target == path) {
            save(target)
            return
        }
        scope.launch {
            if (controller.fileExists(target)) overwriteTarget = target else save(target)
        }
    }

    fun setEditing(editing: Boolean) {
        readOnly = !editing
        controller.updateEditor { it.copy(readOnly = !editing) }
        js("Ed.setReadOnly(${!editing})")
    }

    // Back closes the find bar first, then offers to save, then leaves the editor.
    BackHandler(enabled = true) {
        when {
            menuOpen -> menuOpen = false
            findOpen -> js("Ed.closeFind()")
            dirty -> confirmClose = true
            else -> controller.closeEditor()
        }
    }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surface)) {
        // ---- title row ----
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(
                onClick = { if (dirty) confirmClose = true else controller.closeEditor() },
                modifier = Modifier.size(44.dp),
            ) {
                Icon(Icons.AutoMirrored.Outlined.ArrowBack, stringResource(R.string.editor_close))
            }
            Column(Modifier.weight(1f).padding(horizontal = 4.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        ltr(fileName),
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false),
                    )
                    if (dirty) {
                        Text(" ●", color = Turquoise, style = MaterialTheme.typography.titleMedium)
                    }
                }
                val note = notice
                if (note != null) {
                    Text(
                        stringResource(note.first),
                        style = MaterialTheme.typography.labelSmall,
                        color = if (note.second) MaterialTheme.colorScheme.error else Turquoise,
                        maxLines = 1,
                    )
                } else {
                    Text(
                        ltr(path),
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
            Box {
                IconButton(onClick = { menuOpen = true }, modifier = Modifier.size(44.dp)) {
                    Icon(Icons.Outlined.MoreVert, stringResource(R.string.editor_more))
                }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    MenuEntry(
                        Icons.Outlined.Save,
                        stringResource(R.string.editor_save),
                        { menuOpen = false },
                        enabled = dirty && !saving && pageLoaded,
                    ) { save(path) }
                    MenuEntry(
                        Icons.Outlined.SaveAs,
                        stringResource(R.string.editor_save_as),
                        { menuOpen = false },
                        enabled = !saving && pageLoaded,
                    ) { showSaveAs = true }
                    HorizontalDivider()
                    MenuEntry(
                        Icons.Outlined.Code,
                        stringResource(R.string.editor_language),
                        { menuOpen = false },
                        enabled = pageLoaded,
                    ) { showLanguages = true }
                }
            }
        }

        // ---- tool row: Edit, Undo, Redo, Find, Replace, Save ----
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            val on = pageLoaded
            ToolButton(
                if (readOnly) Icons.Outlined.Edit else Icons.Outlined.Visibility,
                stringResource(if (readOnly) R.string.editor_edit else R.string.editor_view_only),
                enabled = on,
                highlighted = !readOnly,
            ) { setEditing(readOnly) }
            ToolButton(
                Icons.AutoMirrored.Outlined.Undo,
                stringResource(R.string.editor_undo),
                enabled = on && canUndo && !readOnly,
            ) { js("Ed.undo()") }
            ToolButton(
                Icons.AutoMirrored.Outlined.Redo,
                stringResource(R.string.editor_redo),
                enabled = on && canRedo && !readOnly,
            ) { js("Ed.redo()") }
            ToolButton(
                Icons.Outlined.Search,
                stringResource(R.string.editor_find),
                enabled = on,
                highlighted = findOpen,
            ) { js("Ed.find(false)") }
            ToolButton(
                Icons.Outlined.FindReplace,
                stringResource(R.string.editor_replace),
                enabled = on,
            ) { js("Ed.find(true)") }
            ToolButton(
                Icons.Outlined.Save,
                stringResource(R.string.editor_save),
                enabled = on && dirty && !saving,
                highlighted = dirty,
            ) { save(path) }
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

        // ---- the editing surface ----
        Box(Modifier.weight(1f).fillMaxWidth()) {
            val error = loadError
            if (error != null) {
                Text(
                    stringResource(error),
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    modifier = Modifier.align(Alignment.Center).padding(32.dp),
                )
            } else {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        val main = Handler(Looper.getMainLooper())
                        WebView(ctx).apply {
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = false
                            settings.allowFileAccess = false
                            settings.allowContentAccess = false
                            settings.blockNetworkLoads = true
                            settings.cacheMode = WebSettings.LOAD_NO_CACHE
                            settings.setSupportZoom(false)
                            settings.builtInZoomControls = false
                            setBackgroundColor(AndroidColor.parseColor("#282C34"))
                            overScrollMode = View.OVER_SCROLL_NEVER
                            setLayerType(View.LAYER_TYPE_HARDWARE, null)
                            webViewClient = object : WebViewClient() {
                                override fun onPageFinished(view: WebView?, url: String?) {
                                    repaintWebView(view)
                                }

                                // A dead renderer must not take the app down; the editor just closes.
                                override fun onRenderProcessGone(
                                    view: WebView?,
                                    detail: android.webkit.RenderProcessGoneDetail?,
                                ): Boolean {
                                    main.post { controller.closeEditor() }
                                    return true
                                }

                                // The page never navigates anywhere.
                                override fun shouldOverrideUrlLoading(
                                    view: WebView?,
                                    request: android.webkit.WebResourceRequest?,
                                ) = true
                            }
                            addJavascriptInterface(
                                EditorBridge(main) { event ->
                                    when (event) {
                                        is EditorEvent.PageReady -> pageReady = true
                                        is EditorEvent.Dirty -> {
                                            dirty = event.value
                                            if (!event.value) controller.updateEditor { it.copy(draft = null) }
                                        }
                                        is EditorEvent.History -> { canUndo = event.undo; canRedo = event.redo }
                                        is EditorEvent.Find -> findOpen = event.open
                                        is EditorEvent.Draft -> controller.updateEditor { it.copy(draft = event.text) }
                                        is EditorEvent.SaveRequested -> save(path)
                                        is EditorEvent.EditEnabled -> {
                                            readOnly = false
                                            controller.updateEditor { it.copy(readOnly = false) }
                                        }
                                    }
                                },
                                "Android",
                            )
                            loadDataWithBaseURL("about:blank", EditorAssets.html(ctx), "text/html", "utf-8", null)
                            val created = this
                            main.post { webView = created }
                        }
                    },
                    onRelease = { view ->
                        view.removeJavascriptInterface("Android")
                        view.destroy()
                    },
                )
                if (content == null) {
                    Text(
                        stringResource(R.string.editor_loading),
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary,
                        modifier = Modifier.align(Alignment.Center),
                    )
                }
            }
        }
    }

    // ---- dialogs ----
    if (showSaveAs) {
        var input by remember { mutableStateOf(fileName) }
        AlertDialog(
            onDismissRequest = { showSaveAs = false },
            title = { Text(stringResource(R.string.editor_save_as_title)) },
            text = {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    label = { Text(stringResource(R.string.editor_save_as_label)) },
                    singleLine = true,
                )
            },
            confirmButton = {
                TextButton(
                    onClick = { requestSaveAs(input) },
                    enabled = input.isNotBlank() && !input.trim().endsWith("/"),
                ) { Text(stringResource(R.string.editor_save)) }
            },
            dismissButton = {
                TextButton(onClick = { showSaveAs = false }) { Text(stringResource(R.string.cancel)) }
            },
            containerColor = MaterialTheme.colorScheme.surface,
        )
    }

    overwriteTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { overwriteTarget = null },
            title = { Text(stringResource(R.string.editor_overwrite_title)) },
            text = { Text(stringResource(R.string.editor_overwrite_body, RemotePath.name(target))) },
            confirmButton = {
                TextButton(onClick = {
                    overwriteTarget = null
                    save(target)
                }) { Text(stringResource(R.string.editor_overwrite_confirm), color = Danger) }
            },
            dismissButton = {
                TextButton(onClick = { overwriteTarget = null }) { Text(stringResource(R.string.cancel)) }
            },
            containerColor = MaterialTheme.colorScheme.surface,
        )
    }

    if (confirmClose) {
        AlertDialog(
            onDismissRequest = { confirmClose = false },
            title = { Text(stringResource(R.string.editor_unsaved_title)) },
            text = { Text(stringResource(R.string.editor_unsaved_body, fileName)) },
            confirmButton = {
                TextButton(onClick = {
                    confirmClose = false
                    // Close only once the save really went through.
                    scope.launch { if (saveNow(path)) controller.closeEditor() }
                }) { Text(stringResource(R.string.editor_save)) }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { confirmClose = false }) { Text(stringResource(R.string.cancel)) }
                    TextButton(onClick = {
                        confirmClose = false
                        controller.closeEditor()
                    }) { Text(stringResource(R.string.editor_discard), color = Danger) }
                }
            },
            containerColor = MaterialTheme.colorScheme.surface,
        )
    }

    if (showLanguages) {
        AlertDialog(
            onDismissRequest = { showLanguages = false },
            title = { Text(stringResource(R.string.editor_language)) },
            text = {
                LazyColumn(Modifier.heightIn(max = 380.dp)) {
                    item {
                        LanguageRow(stringResource(R.string.editor_language_auto)) {
                            showLanguages = false
                            js("Ed.setLanguage('auto')")
                        }
                    }
                    items(LANGUAGES) { (label, id) ->
                        LanguageRow(label) {
                            showLanguages = false
                            js("Ed.setLanguage(${jsString(id)})")
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showLanguages = false }) { Text(stringResource(R.string.cancel)) }
            },
            containerColor = MaterialTheme.colorScheme.surface,
        )
    }
}

@Composable
private fun LanguageRow(label: String, onClick: () -> Unit) {
    Text(
        label,
        style = MaterialTheme.typography.bodyLarge,
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 12.dp, horizontal = 8.dp),
    )
}

@Composable
private fun ToolButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String,
    enabled: Boolean = true,
    highlighted: Boolean = false,
    onClick: () -> Unit,
) {
    IconButton(onClick = onClick, enabled = enabled, modifier = Modifier.size(40.dp)) {
        Icon(
            icon,
            description,
            tint = when {
                !enabled -> TextSecondary.copy(alpha = 0.38f)
                highlighted -> Turquoise
                else -> MaterialTheme.colorScheme.onSurface
            },
        )
    }
}

// ---- WebView bridge ----

private sealed interface EditorEvent {
    data object PageReady : EditorEvent
    data class Dirty(val value: Boolean) : EditorEvent
    data class History(val undo: Boolean, val redo: Boolean) : EditorEvent
    data class Find(val open: Boolean) : EditorEvent
    data class Draft(val text: String) : EditorEvent
    data object SaveRequested : EditorEvent
    data object EditEnabled : EditorEvent
}

/** The only object the page can call. Every call is handed to the main thread before it touches UI state. */
private class EditorBridge(
    private val main: Handler,
    private val onEvent: (EditorEvent) -> Unit,
) {
    private fun post(event: EditorEvent) { main.post { onEvent(event) } }

    @JavascriptInterface fun onPageReady() = post(EditorEvent.PageReady)
    @JavascriptInterface fun onReady() = Unit
    @JavascriptInterface fun onDirty(value: Boolean) = post(EditorEvent.Dirty(value))
    @JavascriptInterface fun onHistory(undo: Boolean, redo: Boolean) = post(EditorEvent.History(undo, redo))
    @JavascriptInterface fun onFind(open: Boolean) = post(EditorEvent.Find(open))
    @JavascriptInterface fun onDraft(text: String) = post(EditorEvent.Draft(text))
    @JavascriptInterface fun onSaveRequested() = post(EditorEvent.SaveRequested)
    @JavascriptInterface fun onEditEnabled() = post(EditorEvent.EditEnabled)
}

/** The editor page with Highlight.js inlined, read from assets once. */
private object EditorAssets {
    @Volatile private var cached: String? = null

    fun html(context: Context): String = cached ?: synchronized(this) {
        cached ?: run {
            val assets = context.applicationContext.assets
            val page = assets.open("editor/editor.html").bufferedReader().use { it.readText() }
            val hljs = assets.open("editor/highlight.js").bufferedReader().use { it.readText() }
            page.replace("/*HLJS*/", hljs).also { cached = it }
        }
    }
}

/** Forces the WebView to redraw; harmless when it is already showing the page. */
private fun repaintWebView(view: WebView?) {
    view ?: return
    view.requestLayout()
    view.invalidate()
    view.postInvalidateOnAnimation()
}

/** A string as a JavaScript literal, safe for any file content. */
private fun jsString(value: String): String =
    JSONObject.quote(value).replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")

// ---- text <-> bytes ----

private class Decoded(val text: String, val eol: String, val charsetName: String, val bom: Boolean)

/** Bytes to editable text, or null for a binary file. Line endings are normalised and restored on save. */
private fun decode(bytes: ByteArray): Decoded? {
    val probe = minOf(bytes.size, 8192)
    for (i in 0 until probe) if (bytes[i] == 0.toByte()) return null
    val bom = bytes.size >= 3 &&
        bytes[0] == 0xEF.toByte() && bytes[1] == 0xBB.toByte() && bytes[2] == 0xBF.toByte()
    val body = if (bom) bytes.copyOfRange(3, bytes.size) else bytes
    var charset = "UTF-8"
    val text = try {
        Charsets.UTF_8.newDecoder()
            .onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT)
            .decode(ByteBuffer.wrap(body))
            .toString()
    } catch (e: CharacterCodingException) {
        // Not UTF-8: keep the bytes round-trippable as Latin-1 rather than refusing the file.
        charset = "ISO-8859-1"
        String(body, Charsets.ISO_8859_1)
    }
    val crlf = text.contains("\r\n")
    return Decoded(if (crlf) text.replace("\r\n", "\n") else text, if (crlf) "\r\n" else "\n", charset, bom)
}

private fun encode(text: String, eol: String, charsetName: String, bom: Boolean): ByteArray {
    val withEol = if (eol == "\r\n") text.replace("\n", "\r\n") else text
    val body = withEol.toByteArray(Charset.forName(charsetName))
    return if (bom) byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()) + body else body
}

/** Languages offered in the picker; the ids are the Highlight.js names bundled in assets. */
private val LANGUAGES = listOf(
    "Plain text" to "plaintext",
    "Bash / Shell" to "bash",
    "C" to "c",
    "C++" to "cpp",
    "Arduino (.ino)" to "arduino",
    "Python" to "python",
    "Kotlin" to "kotlin",
    "Java" to "java",
    "JavaScript" to "javascript",
    "TypeScript" to "typescript",
    "JSON" to "json",
    "YAML" to "yaml",
    "XML / HTML" to "xml",
    "INI / Config" to "ini",
    "Markdown" to "markdown",
    "CSS" to "css",
    "SQL" to "sql",
    "Go" to "go",
    "Rust" to "rust",
    "PHP" to "php",
    "Ruby" to "ruby",
    "Perl" to "perl",
    "Lua" to "lua",
    "Makefile" to "makefile",
    "Dockerfile" to "dockerfile",
    "Diff" to "diff",
    "Nginx" to "nginx",
    "PowerShell" to "powershell",
    "Gradle" to "gradle",
    "C#" to "csharp",
    "Swift" to "swift",
)
