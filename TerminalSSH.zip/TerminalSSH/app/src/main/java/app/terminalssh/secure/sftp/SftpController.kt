package app.terminalssh.secure.sftp

import android.content.ContentResolver
import android.net.Uri
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

/**
 * Drives the browser and the transfer queue against one SSH session.
 *
 * The scheduling rules live in [TransferQueue], which is pure and unit-tested; this
 * class is the thin layer that does the actual I/O and feeds results back into it.
 */
class SftpController(
    private val session: SftpSource,
    private val contentResolver: ContentResolver,
    private val scope: CoroutineScope,
) {
    data class BrowserState(
        val path: String = RemotePath.ROOT,
        val entries: List<RemoteEntry> = emptyList(),
        val loading: Boolean = false,
        val errorKind: TransferErrorKind? = null,
    )

    private val _browser = MutableStateFlow(BrowserState())
    val browser: StateFlow<BrowserState> = _browser.asStateFlow()

    val queue = TransferQueue()

    // ---- selection, clipboard and multi-item operations ----

    private val _selection = MutableStateFlow(Selection())

    /** Ticked entries; survives navigation so items from different folders can be combined. */
    val selection: StateFlow<Selection> = _selection.asStateFlow()

    private val _clipboard = MutableStateFlow<Clipboard?>(null)

    /** Entries copied or cut, waiting for "Paste here". */
    val clipboard: StateFlow<Clipboard?> = _clipboard.asStateFlow()

    private val batchRunner = BatchRunner(session, contentResolver, scope) { kind ->
        // A download changes nothing on the server; everything else changes the listing.
        if (kind != BatchKind.DOWNLOAD) {
            // Other folders' remembered listings may now be stale (moved, deleted, pasted into).
            synchronized(this) { listingCache.clear() }
            refresh()
        }
    }

    /** The running or just-finished multi-item operation, or null. */
    val batch: StateFlow<BatchState?> = batchRunner.state

    private val propertiesRunner = PropertiesRunner(session, scope)
    val properties: StateFlow<PropertiesState?> = propertiesRunner.state

    private var client: SftpClient? = null
    private var pumpJob: Job? = null

    /** Cancellation flags keyed by transfer id, read by the copy loops. */
    private val cancelled = mutableSetOf<String>()

    private suspend fun client(): SftpClient = withContext(Dispatchers.IO) {
        // A client left over from before a reconnect points at a dead connection: replace it.
        client?.takeIf { it.isAlive }?.let { return@withContext it }
        runCatching { client?.close() }
        val opened = session.openSftp() ?: throw java.io.IOException("connection is not available")
        client = opened
        opened
    }

    // ---- remembered scroll positions and listings ----

    /** Where a folder's list was scrolled to: the first visible row (by path, then index) and its offset. */
    data class ListScroll(val anchorPath: String?, val index: Int, val offset: Int)

    private val scrollByPath = object : LinkedHashMap<String, ListScroll>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, ListScroll>?) = size > MAX_REMEMBERED_FOLDERS
    }

    /**
     * Folders already listed, newest use last. Going back to one shows it at once, exactly as it
     * was, while a fresh listing is fetched quietly behind it.
     */
    private val listingCache = object : LinkedHashMap<String, List<RemoteEntry>>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, List<RemoteEntry>>?) = size > MAX_CACHED_LISTINGS
    }

    /** The saved scroll of [path], or null (start at the top). */
    @Synchronized
    fun savedScroll(path: String): ListScroll? = scrollByPath[RemotePath.normalize(path)]

    @Synchronized
    fun saveScroll(path: String, scroll: ListScroll) {
        scrollByPath[RemotePath.normalize(path)] = scroll
    }

    /** Bumped by every navigation; a listing that arrives for an older one is dropped. */
    private var navToken = 0

    fun openHome() = scope.launch {
        val start = runCatching { withContext(Dispatchers.IO) { client().home() } }
            .getOrDefault(RemotePath.ROOT)
        navigate(start)
    }

    // ---- back navigation ----
    // Folders the user has been through, most recent last. System Back pops this, so it
    // steps back through where the user actually was (not merely the parent folder) and
    // only leaves the File Manager once it is empty.
    private val history = ArrayDeque<String>()
    private var hasListing = false
    private val _canGoBack = MutableStateFlow(false)

    /** True while there is a previous folder to return to. */
    val canGoBack: StateFlow<Boolean> = _canGoBack.asStateFlow()

    /** Returns to the previous folder. False (and nothing happens) when there is none. */
    fun goBack(): Boolean {
        val previous = history.removeLastOrNull() ?: return false
        _canGoBack.value = history.isNotEmpty()
        navigate(previous, record = false, backward = true)
        return true
    }

    /**
     * Opens [path]. Going to a folder that contains the current one (the arrow, a breadcrumb) is
     * a return, so its list comes back exactly as it was left; opening any other folder starts
     * at its first row.
     */
    fun navigate(path: String) {
        val target = RemotePath.normalize(path)
        val current = _browser.value.path
        val backward = target != current && (target == RemotePath.ROOT || current.startsWith("$target/"))
        navigate(target, record = true, backward = backward)
    }

    private fun navigate(path: String, record: Boolean, backward: Boolean = false, useCache: Boolean = true) {
        val token = ++navToken
        scope.launch {
            val normalized = RemotePath.normalize(path)
            val cached = if (useCache) synchronized(this@SftpController) { listingCache[normalized] } else null
            if (cached != null) {
                // Show the folder immediately; the fresh listing below replaces it only if it differs.
                applyListing(normalized, cached, record, backward, loading = true, fresh = false)
            } else {
                _browser.value = _browser.value.copy(loading = true, errorKind = null)
            }
            val result = runCatching {
                withContext(Dispatchers.IO) { client().list(path) }
            }
            if (token != navToken) return@launch // a newer navigation owns the screen now
            result.fold(
                onSuccess = { entries ->
                    synchronized(this@SftpController) { listingCache[normalized] = entries }
                    val shown = _browser.value
                    if (shown.path == normalized && shown.entries == entries) {
                        // Nothing changed: keep the very same list so nothing is rebuilt or scrolled.
                        _browser.value = shown.copy(loading = false, errorKind = null)
                        _selection.update { it.pruned(normalized, entries) }
                    } else {
                        applyListing(normalized, entries, record, backward, loading = false, fresh = true)
                    }
                },
                onFailure = { failure ->
                    // Keep the previous listing on screen rather than blanking it; an
                    // error banner over stale content beats an empty directory.
                    _browser.value = _browser.value.copy(loading = false, errorKind = SftpClient.classify(failure))
                },
            )
        }
    }

    private fun applyListing(
        normalized: String,
        entries: List<RemoteEntry>,
        record: Boolean,
        backward: Boolean,
        loading: Boolean,
        fresh: Boolean,
    ) {
        // Only a real move to a different folder is a step in the history: a refresh, a
        // failed listing and the very first load are not.
        val before = _browser.value.path
        if (normalized != before) {
            if (record && hasListing) {
                history.addLast(before)
                while (history.size > MAX_HISTORY) history.removeFirst()
                _canGoBack.value = true
            }
            // Coming back keeps the saved position; opening a folder starts at its first row.
            if (!backward) synchronized(this) { scrollByPath.remove(normalized) }
        }
        hasListing = true
        // Entries that vanished from this folder (deleted, renamed) leave the selection.
        if (fresh) _selection.update { it.pruned(normalized, entries) }
        _browser.value = BrowserState(path = normalized, entries = entries, loading = loading)
    }

    fun navigateUp() = navigate(RemotePath.parent(_browser.value.path))

    fun refresh() = navigate(_browser.value.path, record = false, useCache = false)

    // ---- file editor ----

    /**
     * What the editor is showing. It lives here, not in the screen, so leaving the Files
     * tab and coming back reopens the same file with any unsaved text still in it.
     */
    data class EditorSession(
        val entry: RemoteEntry,
        /** Unsaved text the page last reported, or null when the file is unmodified. */
        val draft: String? = null,
        val eol: String = "\n",
        val charsetName: String = "UTF-8",
        val bom: Boolean = false,
        val readOnly: Boolean = true,
        /** For .md/.ipynb/.svg/.pbm: true while the rendered Viewer is showing (false = source). */
        val rendered: Boolean = true,
    )

    private val _editor = MutableStateFlow<EditorSession?>(null)
    val editor: StateFlow<EditorSession?> = _editor.asStateFlow()

    fun openEditor(entry: RemoteEntry) { _editor.value = EditorSession(entry) }

    fun updateEditor(transform: (EditorSession) -> EditorSession) { _editor.update { it?.let(transform) } }

    fun closeEditor() {
        _editor.value = null
        releaseViewerFile()
    }

    // ---- large viewable files (images, PDF) ----

    private class ViewerFile(val key: String, val file: java.io.File)

    private var viewerFile: ViewerFile? = null

    /** Frees the downloaded copy of the file that was being viewed. */
    @Synchronized
    fun releaseViewerFile() {
        viewerFile?.file?.delete()
        viewerFile = null
    }

    /**
     * Downloads [entry] to a private cache file for the viewer, streaming, so even a very large
     * image or PDF never sits in memory. The copy is kept while the same file stays open (leaving
     * the tab and coming back does not download it again) and is deleted when the viewer closes.
     */
    suspend fun fetchForViewer(
        entry: RemoteEntry,
        cacheDir: java.io.File,
        maxBytes: Long,
        onProgress: (Long) -> Unit,
    ): java.io.File {
        val key = "${entry.path}|${entry.sizeBytes}|${entry.modifiedEpochSeconds}"
        synchronized(this) {
            val held = viewerFile
            if (held != null && held.key == key && held.file.isFile) return held.file
        }
        releaseViewerFile()
        val dir = java.io.File(cacheDir, "viewer").apply { mkdirs() }
        // Leftovers of a crashed session: nothing in here is ever needed for long.
        dir.listFiles()?.forEach { if (System.currentTimeMillis() - it.lastModified() > STALE_VIEWER_FILE_MS) it.delete() }
        if (entry.sizeBytes > 0 && dir.usableSpace < entry.sizeBytes + MIN_FREE_BYTES) {
            throw java.io.IOException("not enough free storage to open this file")
        }
        val target = java.io.File.createTempFile("view", ".tmp", dir)
        try {
            withContext(Dispatchers.IO) {
                val ctx = kotlin.coroutines.coroutineContext
                var reported = 0L
                client().readToFile(entry.path, target, maxBytes) { total ->
                    ctx.ensureActive() // leaving the screen stops the download
                    if (total - reported >= PROGRESS_STEP_BYTES) {
                        reported = total
                        onProgress(total)
                    }
                }
            }
        } catch (t: Throwable) {
            target.delete()
            throw t
        }
        synchronized(this) { viewerFile = ViewerFile(key, target) }
        return target
    }

    /** Whether [path], after following links, is a folder. Used so a link to a folder opens as one. */
    suspend fun isFolder(path: String): Boolean = withContext(Dispatchers.IO) {
        runCatching { client().isDirectoryFollowingLinks(path) }.getOrDefault(false)
    }

    /** Reads a whole file into memory; [maxBytes] defaults to the editor's 2 MB limit. */
    suspend fun readFile(path: String, maxBytes: Int = MAX_EDIT_BYTES): ByteArray = withContext(Dispatchers.IO) {
        client().readBytes(path, maxBytes)
    }

    suspend fun writeFile(path: String, data: ByteArray) = withContext(Dispatchers.IO) {
        client().writeBytes(path, data)
    }

    suspend fun fileExists(path: String): Boolean = withContext(Dispatchers.IO) {
        runCatching { client().exists(path) }.getOrDefault(false)
    }

    // ---- selection ----

    fun toggleSelection(entry: RemoteEntry) {
        _selection.update { it.toggle(entry) }
    }

    /** Adds every entry of the folder being viewed to the selection. */
    fun selectAllHere() {
        _selection.update { it.addAll(_browser.value.entries) }
    }

    /** Adds exactly [entries] (what the user can see, e.g. without hidden files) to the selection. */
    fun selectAll(entries: List<RemoteEntry>) {
        _selection.update { it.addAll(entries) }
    }

    fun clearSelection() {
        _selection.value = Selection()
    }

    // ---- clipboard ----

    fun copySelection() = fillClipboard(ClipboardMode.COPY)

    fun cutSelection() = fillClipboard(ClipboardMode.CUT)

    private fun fillClipboard(mode: ClipboardMode) {
        val items = _selection.value.entries
        if (items.isEmpty()) return
        _clipboard.value = Clipboard(mode, items)
        clearSelection()
    }

    fun clearClipboard() {
        _clipboard.value = null
    }

    /** Pastes the clipboard into the folder being viewed. Returns false if busy or empty. */
    fun pasteHere(): Boolean {
        val clip = _clipboard.value ?: return false
        val destination = _browser.value.path
        return when (clip.mode) {
            ClipboardMode.COPY -> batchRunner.copy(clip.items, destination)
            ClipboardMode.CUT -> batchRunner.move(clip.items, destination).also { started ->
                // A cut can only land once; a copy can be pasted into several folders.
                if (started) _clipboard.value = null
            }
        }
    }

    // ---- multi-item operations ----

    val isBatchBusy: Boolean get() = batchRunner.isBusy

    fun deleteSelection(): Boolean {
        val items = _selection.value.entries
        if (items.isEmpty()) return false
        val started = batchRunner.delete(items)
        if (started) clearSelection()
        return started
    }

    fun renameSelected(newName: String): Boolean {
        val entry = _selection.value.single ?: return false
        val started = batchRunner.rename(entry, newName.trim())
        if (started) clearSelection()
        return started
    }

    /** Downloads the whole selection, folders recursively, into the folder the user picked. */
    fun downloadSelectionTo(treeUri: Uri): Boolean {
        val items = _selection.value.entries
        if (items.isEmpty()) return false
        val started = batchRunner.download(items, treeUri)
        if (started) clearSelection()
        return started
    }

    /** Creates a folder named [name] inside the folder being viewed. */
    fun createFolder(name: String): Boolean = batchRunner.createFolder(_browser.value.path, name)

    fun createFile(name: String): Boolean = batchRunner.createFile(_browser.value.path, name)

    fun cancelBatch() = batchRunner.cancel()

    fun dismissBatch() = batchRunner.dismiss()

    // ---- properties ----

    fun showProperties() {
        val items = _selection.value.entries
        if (items.isNotEmpty()) propertiesRunner.show(items)
    }

    fun dismissProperties() = propertiesRunner.dismiss()

    // ---- transfers ----

    fun enqueueDownload(entry: RemoteEntry, destination: Uri) {
        queue.enqueue(
            Transfer(
                id = UUID.randomUUID().toString(),
                direction = TransferDirection.DOWNLOAD,
                remotePath = entry.path,
                localUri = destination.toString(),
                displayName = entry.name,
                totalBytes = entry.sizeBytes,
            ),
        )
        pump()
    }

    fun enqueueUpload(source: Uri, displayName: String, remoteDirectory: String) {
        queue.enqueue(
            Transfer(
                id = UUID.randomUUID().toString(),
                direction = TransferDirection.UPLOAD,
                remotePath = RemotePath.join(remoteDirectory, RemotePath.sanitizeDownloadName(displayName)),
                localUri = source.toString(),
                displayName = displayName,
            ),
        )
        pump()
    }

    fun pause(id: String) {
        cancelled += id
        queue.pause(id)
    }

    fun resume(id: String) {
        cancelled -= id
        queue.resume(id)
        pump()
    }

    fun cancel(id: String) {
        cancelled += id
        queue.cancel(id)
    }

    fun clearFinished() = queue.clearFinished()

    /** Starts the next transfer if the queue allows one; re-entrant and cheap. */
    private fun pump() {
        if (pumpJob?.isActive == true) return
        pumpJob = scope.launch {
            while (isActive) {
                val next = queue.nextToStart() ?: break
                queue.markRunning(next.id)
                cancelled -= next.id
                runTransfer(queue.transfers.value.first { it.id == next.id })
            }
        }
    }

    private suspend fun runTransfer(transfer: Transfer) {
        val result = runCatching {
            // Resolve the client here rather than reaching for a field that is only
            // populated once a listing has succeeded: a transfer queued before the first
            // successful navigate would otherwise dereference null.
            val sftp = client()
            withContext(Dispatchers.IO) {
                when (transfer.direction) {
                    TransferDirection.DOWNLOAD -> download(sftp, transfer)
                    TransferDirection.UPLOAD -> upload(sftp, transfer)
                }
            }
        }
        when {
            transfer.id in cancelled -> Unit // pause()/cancel() already set the state.
            result.isSuccess -> queue.markCompleted(transfer.id)
            else -> queue.fail(transfer.id, SftpClient.classify(result.exceptionOrNull()!!))
        }
    }

    private fun download(sftp: SftpClient, transfer: Transfer) {
        val uri = Uri.parse(transfer.localUri)
        // "wt" truncates: a resumed download re-fetches from zero rather than appending
        // to a partial file, because SAF gives no reliable way to learn how many bytes
        // actually reached storage.
        val sink = contentResolver.openOutputStream(uri, "wt")
            ?: throw IllegalStateException("cannot open destination")
        sink.use {
            sftp.download(transfer.remotePath, it, resumeFrom = 0L) { total ->
                if (transfer.id in cancelled) throw InterruptedTransfer()
                queue.markProgress(transfer.id, total)
            }
        }
    }

    private fun upload(sftp: SftpClient, transfer: Transfer) {
        val uri = Uri.parse(transfer.localUri)
        val source = contentResolver.openInputStream(uri)
            ?: throw IllegalStateException("cannot open source")
        source.use {
            sftp.upload(it, transfer.remotePath, resumeFrom = 0L) { total ->
                if (transfer.id in cancelled) throw InterruptedTransfer()
                queue.markProgress(transfer.id, total)
            }
        }
    }

    /** Signals a user-requested stop, distinguishing it from a real transfer failure. */
    private class InterruptedTransfer : RuntimeException("transfer interrupted by the user")

    fun onSessionLost() {
        queue.onConnectionLost()
        close()
    }

    fun close() {
        releaseViewerFile()
        batchRunner.close()
        propertiesRunner.dismiss()
        pumpJob?.cancel()
        runCatching { client?.close() }
        client = null
    }

    companion object {
        /** Largest file the editor opens; bigger files are downloaded instead. */
        const val MAX_EDIT_BYTES = 2 * 1024 * 1024

        /** Largest image or PDF the viewer will download (it is streamed to disk, never held in memory). */
        const val MAX_VIEW_BYTES = 256L * 1024 * 1024

        /** Largest SVG or PBM: these are read into memory to be drawn, so they stay modest. */
        const val MAX_VIEW_IN_MEMORY_BYTES = 10 * 1024 * 1024

        private const val MAX_HISTORY = 100
        private const val MAX_REMEMBERED_FOLDERS = 500
        private const val MAX_CACHED_LISTINGS = 32
        private const val STALE_VIEWER_FILE_MS = 6L * 60 * 60 * 1000
        private const val MIN_FREE_BYTES = 32L * 1024 * 1024
        private const val PROGRESS_STEP_BYTES = 256L * 1024
    }
}
