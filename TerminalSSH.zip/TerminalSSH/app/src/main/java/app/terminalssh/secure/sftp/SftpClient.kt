package app.terminalssh.secure.sftp

import com.jcraft.jsch.ChannelSftp
import com.jcraft.jsch.Session
import com.jcraft.jsch.SftpATTRS
import com.jcraft.jsch.SftpException
import com.jcraft.jsch.SftpProgressMonitor
import java.io.InputStream
import java.io.OutputStream

/**
 * SFTP over an SSH [Session] that is already connected and host-key verified.
 *
 * Reusing the terminal's session is the point: opening a second connection would mean a
 * second authentication, a second host-key check, and a second password prompt for the
 * same server the user is already sitting in.
 *
 * Every method here performs blocking network I/O and must never run on the main thread.
 */
/** Thrown by [SftpClient.readBytes] when a file is bigger than the editor will open. */
class FileTooLarge(val sizeBytes: Long) : java.io.IOException("file too large for the editor: $sizeBytes bytes")

class SftpClient(private val session: Session) : AutoCloseable {

    private var channel: ChannelSftp? = null

    /** False once the underlying connection has gone away (dropped, or replaced by a reconnect). */
    val isAlive: Boolean get() = session.isConnected

    private fun channel(): ChannelSftp {
        channel?.takeIf { it.isConnected }?.let { return it }
        val opened = session.openChannel("sftp") as ChannelSftp
        opened.connect(CONNECT_TIMEOUT_MS)
        channel = opened
        return opened
    }

    /** The server's idea of where the user starts, usually their home directory. */
    fun home(): String = runCatching { channel().home }.getOrDefault(RemotePath.ROOT)

    @Suppress("UNCHECKED_CAST")
    fun list(path: String): List<RemoteEntry> {
        val normalized = RemotePath.normalize(path)
        val raw = channel().ls(normalized) as? java.util.Vector<ChannelSftp.LsEntry> ?: return emptyList()
        return raw.asSequence()
            .map { entry -> entry.toRemoteEntry(normalized) }
            .filterNot { it.isNavigational }
            // Directories first, then case-insensitive by name: the ordering people
            // expect from every other file browser they have used.
            .sortedWith(compareByDescending<RemoteEntry> { it.isDirectory }.thenBy { it.name.lowercase() })
            .toList()
    }

    /**
     * @param resumeFrom byte offset to continue from; 0 starts fresh. This is what makes
     *   a download survive a dropped connection on mobile data.
     */
    fun download(remotePath: String, sink: OutputStream, resumeFrom: Long = 0L, onProgress: (Long) -> Unit) {
        val monitor = ProgressMonitor(resumeFrom, onProgress)
        channel().get(RemotePath.normalize(remotePath), sink, monitor, ChannelSftp.RESUME, resumeFrom)
    }

    fun upload(source: InputStream, remotePath: String, resumeFrom: Long = 0L, onProgress: (Long) -> Unit) {
        val monitor = ProgressMonitor(resumeFrom, onProgress)
        val mode = if (resumeFrom > 0L) ChannelSftp.RESUME else ChannelSftp.OVERWRITE
        channel().put(source, RemotePath.normalize(remotePath), monitor, mode)
    }

    /**
     * Reads a whole file into memory for the editor, refusing anything over [maxBytes]
     * (the caller shows "too large" rather than loading it). Uses its own channel so an
     * open editor never interleaves with a running transfer on the shared one.
     */
    fun readBytes(remotePath: String, maxBytes: Int): ByteArray {
        val reader = session.openChannel("sftp") as ChannelSftp
        reader.connect(CONNECT_TIMEOUT_MS)
        try {
            val path = RemotePath.normalize(remotePath)
            val declared = runCatching { reader.stat(path).size }.getOrDefault(-1L)
            if (declared > maxBytes) throw FileTooLarge(declared)
            reader.get(path).use { input ->
                val out = java.io.ByteArrayOutputStream(if (declared in 1..maxBytes.toLong()) declared.toInt() else 8192)
                val buffer = ByteArray(COPY_BUFFER_BYTES)
                while (true) {
                    val read = input.read(buffer)
                    if (read < 0) break
                    out.write(buffer, 0, read)
                    if (out.size() > maxBytes) throw FileTooLarge(out.size().toLong())
                }
                return out.toByteArray()
            }
        } finally {
            runCatching { reader.disconnect() }
        }
    }

    /**
     * Replaces the contents of a file with [data]. Overwriting an existing file in place
     * keeps its owner and permissions (a script stays executable); a new file gets the
     * server's default mode.
     */
    fun writeBytes(remotePath: String, data: ByteArray) {
        val writer = session.openChannel("sftp") as ChannelSftp
        writer.connect(CONNECT_TIMEOUT_MS)
        try {
            writer.put(java.io.ByteArrayInputStream(data), RemotePath.normalize(remotePath), ChannelSftp.OVERWRITE)
        } finally {
            runCatching { writer.disconnect() }
        }
    }

    /** Whether anything (file, folder or link) exists at [remotePath]. */
    fun exists(remotePath: String): Boolean =
        runCatching { channel().lstat(RemotePath.normalize(remotePath)); true }.getOrDefault(false)

    /** Size in bytes, or [Transfer.UNKNOWN_SIZE] when the server will not say. */
    fun size(remotePath: String): Long =
        runCatching { channel().stat(RemotePath.normalize(remotePath)).size }
            .getOrDefault(Transfer.UNKNOWN_SIZE)

    fun delete(remotePath: String, isDirectory: Boolean) {
        val normalized = RemotePath.normalize(remotePath)
        if (isDirectory) channel().rmdir(normalized) else channel().rm(normalized)
    }

    fun makeDirectory(remotePath: String) = channel().mkdir(RemotePath.normalize(remotePath))

    /**
     * Creates a new empty file. Refuses to touch anything that already exists (the batch
     * runner has checked the listing, this closes the gap between that and the write).
     */
    fun createEmptyFile(remotePath: String) {
        if (exists(remotePath)) throw java.io.IOException("already exists")
        writeBytes(remotePath, ByteArray(0))
    }

    fun rename(from: String, to: String) =
        channel().rename(RemotePath.normalize(from), RemotePath.normalize(to))

    /**
     * Full attributes of one entry. Uses `lstat`, so a symbolic link reports itself rather
     * than whatever it points at; [RemoteStat.linkTarget] says where it points.
     */
    fun statDetailed(remotePath: String): RemoteStat {
        val normalized = RemotePath.normalize(remotePath)
        val attributes: SftpATTRS = channel().lstat(normalized)
        val target = if (attributes.isLink) {
            runCatching { channel().readlink(normalized) }.getOrNull()
        } else {
            null
        }
        return RemoteStat(
            sizeBytes = attributes.size,
            isDirectory = attributes.isDir,
            isSymlink = attributes.isLink,
            permissionsString = attributes.permissionsString ?: "",
            permissionsOctal = String.format("%04o", attributes.permissions and 0xFFF),
            uid = attributes.getUId(),
            gid = attributes.getGId(),
            accessedEpochSeconds = attributes.getATime().toLong(),
            modifiedEpochSeconds = attributes.getMTime().toLong(),
            linkTarget = target,
        )
    }

    /** Whether [remotePath], after following links, is a directory. False when it cannot be told. */
    fun isDirectoryFollowingLinks(remotePath: String): Boolean =
        runCatching { channel().stat(RemotePath.normalize(remotePath)).isDir }.getOrDefault(false)

    /**
     * Copies a file on the server by streaming it through this device.
     *
     * SFTP has no copy command, so the bytes make a round trip. Two channels are needed
     * because one SFTP channel cannot read and write at the same time. Nothing is held on
     * disk or in memory beyond one buffer. An existing [to] is overwritten, so the caller
     * must have picked a free name.
     */
    fun copyFile(from: String, to: String, onCopied: (Long) -> Unit) {
        val source = RemotePath.normalize(from)
        val target = RemotePath.normalize(to)
        val writer = session.openChannel("sftp") as ChannelSftp
        writer.connect(CONNECT_TIMEOUT_MS)
        try {
            channel().get(source).use { input ->
                writer.put(target, ChannelSftp.OVERWRITE).use { output ->
                    val buffer = ByteArray(COPY_BUFFER_BYTES)
                    var copied = 0L
                    while (true) {
                        val read = input.read(buffer)
                        if (read < 0) break
                        output.write(buffer, 0, read)
                        copied += read
                        onCopied(copied)
                    }
                }
            }
        } finally {
            runCatching { writer.disconnect() }
        }
    }

    override fun close() {
        runCatching { channel?.disconnect() }
        channel = null
    }

    private fun ChannelSftp.LsEntry.toRemoteEntry(parent: String): RemoteEntry {
        val attributes: SftpATTRS = attrs
        return RemoteEntry(
            name = filename,
            path = RemotePath.join(parent, filename),
            isDirectory = attributes.isDir,
            isSymlink = attributes.isLink,
            sizeBytes = attributes.size,
            modifiedEpochSeconds = attributes.mTime.toLong(),
            permissions = attributes.permissionsString ?: "",
        )
    }

    /**
     * JSch reports each chunk's size; the UI wants a running total, and a resumed
     * transfer has to start counting from where it left off rather than zero.
     */
    private class ProgressMonitor(
        startedAt: Long,
        private val onProgress: (Long) -> Unit,
    ) : SftpProgressMonitor {
        private var total = startedAt

        override fun init(op: Int, src: String?, dest: String?, max: Long) = Unit

        override fun count(count: Long): Boolean {
            total += count
            onProgress(total)
            return true
        }

        override fun end() = Unit
    }

    companion object {
        private const val CONNECT_TIMEOUT_MS = 15_000
        private const val COPY_BUFFER_BYTES = 32 * 1024

        /** Maps an SFTP failure onto something the transfer list can explain. */
        fun classify(t: Throwable): TransferErrorKind = when {
            t is SftpException -> when (t.id) {
                ChannelSftp.SSH_FX_NO_SUCH_FILE -> TransferErrorKind.NOT_FOUND
                ChannelSftp.SSH_FX_PERMISSION_DENIED -> TransferErrorKind.PERMISSION_DENIED
                else -> classifyMessage(t.message)
            }
            else -> classifyMessage(t.message)
        }

        private fun classifyMessage(message: String?): TransferErrorKind {
            val text = (message ?: "").lowercase()
            return when {
                "no space" in text || "quota" in text || "disk full" in text -> TransferErrorKind.OUT_OF_SPACE
                "permission" in text || "denied" in text -> TransferErrorKind.PERMISSION_DENIED
                "no such file" in text || "not found" in text -> TransferErrorKind.NOT_FOUND
                "connection" in text || "broken pipe" in text || "session is down" in text ->
                    TransferErrorKind.CONNECTION_LOST
                else -> TransferErrorKind.UNKNOWN
            }
        }
    }
}
