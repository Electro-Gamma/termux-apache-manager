package app.terminalssh.secure.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Terminal
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import app.terminalssh.secure.R
import app.terminalssh.secure.model.HostProfile
import app.terminalssh.secure.ui.theme.TextSecondary
import app.terminalssh.secure.ui.theme.Turquoise
import app.terminalssh.secure.vm.OpenMode

/**
 * What to open for a tapped server. Always the same three choices, whether or not
 * anything for that server is already running: the Terminal and the File Manager are
 * independent, so neither is a prerequisite of the other.
 */
@Composable
fun OpenHostDialog(
    profile: HostProfile,
    terminalRunning: Boolean,
    filesRunning: Boolean,
    onPick: (OpenMode) -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(ltr(profile.displayName), maxLines = 1) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                ChoiceRow(
                    icon = Icons.Outlined.Terminal,
                    title = stringResource(R.string.open_terminal),
                    subtitle = stringResource(if (terminalRunning) R.string.open_resume else R.string.open_terminal_hint),
                    onClick = { onPick(OpenMode.TERMINAL) },
                )
                ChoiceRow(
                    icon = Icons.Outlined.Folder,
                    title = stringResource(R.string.open_files),
                    subtitle = stringResource(if (filesRunning) R.string.open_resume else R.string.open_files_hint),
                    onClick = { onPick(OpenMode.FILES) },
                )
                ChoiceRow(
                    icon = Icons.Outlined.Dashboard,
                    title = stringResource(R.string.open_both),
                    subtitle = stringResource(R.string.open_both_hint),
                    onClick = { onPick(OpenMode.BOTH) },
                )
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
        },
        containerColor = MaterialTheme.colorScheme.surface,
    )
}

@Composable
private fun ChoiceRow(icon: ImageVector, title: String, subtitle: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, contentDescription = null, tint = Turquoise, modifier = Modifier.size(28.dp))
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
        }
    }
}
