package app.terminalssh.secure.sftp

import app.terminalssh.secure.ssh.SshSession
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Loads the Properties sheet: full attributes for each selected entry straight away, then
 * a background recursive count and size of any selected folders. Dismissing the sheet
 * stops the measuring.
 */
class PropertiesRunner(
    private val session: SshSession,
    private val scope: CoroutineScope,
) {
    private val _state = MutableStateFlow<PropertiesState?>(null)
    val state: StateFlow<PropertiesState?> = _state.asStateFlow()

    private var job: Job? = null

    /** Identifies the current sheet so a stale background run cannot overwrite a newer one. */
    private var token = Any()

    fun show(entries: List<RemoteEntry>) {
        job?.cancel()
        val mine = Any()
        token = mine
        _state.value = PropertiesState(
            items = entries.map { PropertyItem(it, null) },
            locations = entries.map { RemotePath.parent(it.path) }.distinct(),
        )
        job = scope.launch {
            withContext(Dispatchers.IO) {
                val active = { isActive }
                measure(entries, mine, active)
            }
        }
    }

    fun dismiss() {
        job?.cancel()
        token = Any()
        _state.value = null
    }

    private fun publish(mine: Any, change: (PropertiesState) -> PropertiesState) {
        _state.update { s -> if (s != null && token === mine) change(s) else s }
    }

    private class Tally {
        var files = 0
        var folders = 0
        var bytes = 0L
        var unreadable = 0
    }

    private fun measure(entries: List<RemoteEntry>, mine: Any, active: () -> Boolean) {
        val sftp = session.openSftp()
        if (sftp == null) {
            publish(mine) { it.copy(loadingDetails = false, measuring = false) }
            return
        }
        try {
            val detailed = entries.map { entry ->
                PropertyItem(entry, runCatching { sftp.statDetailed(entry.path) }.getOrNull())
            }
            publish(mine) { it.copy(items = detailed, loadingDetails = false) }

            val tally = Tally()
            var lastPublishedAt = 0L
            val report = {
                val now = System.nanoTime() / 1_000_000L
                if (now - lastPublishedAt >= PUBLISH_INTERVAL_MS) {
                    lastPublishedAt = now
                    publish(mine) {
                        it.copy(
                            fileCount = tally.files,
                            folderCount = tally.folders,
                            totalBytes = tally.bytes,
                            unreadableFolders = tally.unreadable,
                        )
                    }
                }
            }
            for (entry in entries) {
                if (!active()) return
                walk(sftp, entry, 0, tally, active, report)
            }
            publish(mine) {
                it.copy(
                    fileCount = tally.files,
                    folderCount = tally.folders,
                    totalBytes = tally.bytes,
                    unreadableFolders = tally.unreadable,
                    measuring = false,
                )
            }
        } finally {
            sftp.close()
        }
    }

    private fun walk(
        sftp: SftpClient,
        entry: RemoteEntry,
        depth: Int,
        tally: Tally,
        active: () -> Boolean,
        report: () -> Unit,
    ) {
        if (!active()) return
        if (entry.isDirectory) {
            tally.folders++
            if (depth >= MAX_DEPTH) {
                tally.unreadable++
                return
            }
            val children = try {
                sftp.list(entry.path)
            } catch (e: Exception) {
                tally.unreadable++
                report()
                return
            }
            for (child in children) walk(sftp, child, depth + 1, tally, active, report)
        } else {
            // Symbolic links count as the small entries they are; they are never followed.
            tally.files++
            if (entry.sizeBytes > 0L) tally.bytes += entry.sizeBytes
        }
        report()
    }

    private companion object {
        const val PUBLISH_INTERVAL_MS = 200L
        const val MAX_DEPTH = 64
    }
}
