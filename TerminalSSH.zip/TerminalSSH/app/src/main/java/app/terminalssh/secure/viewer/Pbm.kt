package app.terminalssh.secure.viewer

import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.util.zip.CRC32
import java.util.zip.DeflaterOutputStream

/** [whiteBits]: rows padded to whole bytes, bit 1 = white pixel (PNG 1-bit grayscale layout). */
internal class PbmImage(val width: Int, val height: Int, val whiteBits: ByteArray)

/** Portable Bitmap: ASCII (P1) and binary (P4). */
internal object Pbm {
    // A 1-bit PNG still costs 4 bytes per pixel once the WebView decodes it, so cap the size.
    // 16M pixels is also the most a 2 MB binary (P4) file can actually contain.
    const val MAX_PIXELS = 16_777_216L

    fun decode(b: ByteArray): PbmImage {
        var pos = 0
        fun skip() {
            while (pos < b.size) {
                val c = (b[pos].toInt() and 0xFF).toChar()
                if (c == '#') { while (pos < b.size && b[pos].toInt() != '\n'.code) pos++ }
                else if (c.isWhitespace()) pos++
                else break
            }
        }
        fun token(): String {
            skip()
            val start = pos
            while (pos < b.size) {
                val c = (b[pos].toInt() and 0xFF).toChar()
                if (c.isWhitespace() || c == '#') break
                pos++
            }
            return String(b, start, pos - start, Charsets.US_ASCII)
        }

        val magic = token()
        require(magic == "P1" || magic == "P4") { "not a PBM (P1/P4) file" }
        val w = token().toIntOrNull() ?: throw IllegalArgumentException("bad width")
        val h = token().toIntOrNull() ?: throw IllegalArgumentException("bad height")
        require(w > 0 && h > 0 && w.toLong() * h <= MAX_PIXELS) { "unsupported image size ${w}x$h" }
        val rowBytes = (w + 7) / 8
        val out = ByteArray(rowBytes * h)
        out.fill(0xFF.toByte())

        if (magic == "P4") {
            pos++ // exactly one whitespace byte separates the header from the pixel data
            for (i in out.indices) {
                if (pos + i >= b.size) break
                out[i] = b[pos + i].toInt().inv().toByte() // PBM 1 = black, PNG 1 = white
            }
        } else {
            var x = 0
            var y = 0
            while (pos < b.size && y < h) {
                val c = b[pos++].toInt().toChar()
                if (c == '#') { while (pos < b.size && b[pos].toInt() != '\n'.code) pos++; continue }
                if (c != '0' && c != '1') continue
                if (c == '1') {
                    val idx = y * rowBytes + (x shr 3)
                    out[idx] = (out[idx].toInt() and (0x80 shr (x and 7)).inv()).toByte()
                }
                if (++x == w) { x = 0; y++ }
            }
        }
        return PbmImage(w, h, out)
    }

    /** Minimal 1-bit grayscale PNG so the WebView can show the bitmap. */
    fun toPng(img: PbmImage): ByteArray {
        val rowBytes = (img.width + 7) / 8
        val idat = ByteArrayOutputStream()
        DeflaterOutputStream(idat).use { z ->
            for (y in 0 until img.height) {
                z.write(0) // filter: none
                z.write(img.whiteBits, y * rowBytes, rowBytes)
            }
        }
        val png = ByteArrayOutputStream()
        val d = DataOutputStream(png)
        d.write(byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A))
        fun chunk(type: String, data: ByteArray) {
            val t = type.toByteArray(Charsets.US_ASCII)
            d.writeInt(data.size)
            d.write(t)
            d.write(data)
            val crc = CRC32()
            crc.update(t)
            crc.update(data)
            d.writeInt(crc.value.toInt())
        }
        val ihdr = ByteArrayOutputStream()
        DataOutputStream(ihdr).apply {
            writeInt(img.width); writeInt(img.height)
            write(1); write(0); write(0); write(0); write(0) // 1-bit, grayscale, deflate, filter 0, no interlace
        }
        chunk("IHDR", ihdr.toByteArray())
        chunk("IDAT", idat.toByteArray())
        chunk("IEND", ByteArray(0))
        return png.toByteArray()
    }
}
