(function () {
  'use strict';
  var root = document.querySelector('.markdown-body');
  if (!root) return;

  /* ---------- helpers ---------- */
  function esc(s) { return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
  function words(s) { return '\\b(?:' + s.split(' ').join('|') + ')\\b'; }

  /* ---------- syntax highlighting (offline, regex based) ---------- */
  var R = {
    dq: /"(?:\\.|[^"\\\n])*"/, sq: /'(?:\\.|[^'\\\n])*'/, bt: /`(?:\\[\s\S]|[^`\\])*`/,
    tdq: /"""[\s\S]*?"""/, tsq: /'''[\s\S]*?'''/,
    cline: /\/\/[^\n]*/, cblock: /\/\*[\s\S]*?\*\//, hash: /#[^\n]*/, dash: /--[^\n]*/,
    num: /\b(?:0[xX][0-9a-fA-F_]+|\d[\d_]*(?:\.\d+)?(?:[eE][+-]?\d+)?[fFlLuU]*)\b/,
    fn: /\b[A-Za-z_$][\w$]*(?=\s*\()/, ty: /\b[A-Z][A-Za-z0-9_]*\b/
  };
  function S(re) { return re.source; }

  function run(code, rules, flags) {
    var re = new RegExp(rules.map(function (r) { return '(' + r[1] + ')'; }).join('|'), (flags || '') + 'g');
    var out = '', last = 0, m, i;
    while ((m = re.exec(code))) {
      if (m[0].length === 0) { re.lastIndex++; continue; }
      i = 1; while (i < m.length && m[i] === undefined) i++;
      var rule = rules[i - 1];
      out += esc(code.slice(last, m.index));
      out += rule[2] ? rule[2](m[0]) : '<span class="tok-' + rule[0] + '">' + esc(m[0]) + '</span>';
      last = m.index + m[0].length;
    }
    return out + esc(code.slice(last));
  }

  var CKW = 'abstract as async await break case catch class const constructor continue data debugger default defer delete do else enum export extends extern final finally fn for fun func function get goto if impl implements import in inline instanceof interface internal is lateinit let match mod mut namespace new object of open operator out override package private protected pub public readonly ref return sealed self set static struct super suspend switch this throw throws trait try type typealias typeof union unsafe use using val var virtual void volatile when where while with yield';
  var CLIT = 'true false null nil undefined NaN Infinity';
  var clikeRules = [
    ['c', S(R.cblock)], ['c', S(R.cline)], ['s', S(R.bt)], ['s', S(R.dq)], ['s', S(R.sq)],
    ['t', '@[A-Za-z_]\\w*'], ['k', words(CKW)], ['n', words(CLIT)], ['n', S(R.num)], ['f', S(R.fn)], ['t', S(R.ty)]
  ];
  var cppRules = [['k', '^[ \\t]*#[ \\t]*[a-z]+']].concat(clikeRules);

  var PYKW = 'and as assert async await break class continue def del elif else except finally for from global if import in is lambda nonlocal not or pass raise return try while with yield match case';
  var pyRules = [
    ['c', S(R.hash)], ['s', S(R.tdq)], ['s', S(R.tsq)], ['s', S(R.dq)], ['s', S(R.sq)],
    ['t', '@[\\w.]+'], ['k', words(PYKW)], ['n', words('True False None')], ['n', S(R.num)], ['f', S(R.fn)], ['t', S(R.ty)]
  ];
  var RBKW = 'alias and begin break case class def do else elsif end ensure for if in module next not or redo rescue retry return self super then undef unless until when while yield';
  var rbRules = [
    ['c', S(R.hash)], ['s', S(R.dq)], ['s', S(R.sq)], ['k', words(RBKW)], ['n', words('true false nil')],
    ['n', S(R.num)], ['f', S(R.fn)], ['t', S(R.ty)]
  ];
  var SHKW = 'if then else elif fi for while until do done case esac in function select return exit export local readonly declare echo cd source alias unset set shift break continue';
  var shRules = [
    ['a', '\\$(?:\\{[^}\\n]*\\}|\\w+|[@#?*$!-])'], ['c', S(R.hash)], ['s', S(R.dq)], ['s', S(R.sq)],
    ['k', words(SHKW)], ['n', S(R.num)]
  ];
  var SQLKW = 'select from where insert into values update set delete create table alter drop index view join inner left right outer full cross on as and or not null is in like between group by order having limit offset union all distinct case when then else end primary key foreign references default unique check constraint database schema if exists begin commit rollback grant revoke with returning asc desc count sum avg min max int integer varchar text boolean date timestamp serial';
  var sqlRules = [
    ['c', S(R.dash)], ['c', S(R.cblock)], ['s', S(R.sq)], ['s', S(R.dq)], ['k', words(SQLKW)], ['n', S(R.num)], ['f', S(R.fn)]
  ];
  var jsonRules = [
    ['a', '"(?:\\\\.|[^"\\\\\\n])*"(?=\\s*:)'], ['c', S(R.cline)], ['c', S(R.cblock)], ['s', S(R.dq)],
    ['n', words('true false null')], ['n', '-?\\b\\d+(?:\\.\\d+)?(?:[eE][+-]?\\d+)?\\b']
  ];
  var yamlRules = [
    ['c', S(R.hash)], ['s', S(R.dq)], ['s', S(R.sq)], ['a', '[\\w.\\-]+(?=:(?:\\s|$))'],
    ['t', '[&*][\\w-]+'], ['n', words('true false null')], ['n', S(R.num)]
  ];
  var tomlRules = [
    ['c', S(R.hash)], ['t', '^[ \\t]*\\[[^\\]\\n]+\\]'], ['s', S(R.tdq)], ['s', S(R.dq)], ['s', S(R.sq)],
    ['a', '[\\w.\\-]+(?=\\s*=)'], ['n', words('true false')], ['n', S(R.num)]
  ];
  var tagInner = [
    ['k', '^<\\/?[\\w:.-]+'], ['k', '\\/?>$'], ['a', '[\\w:.-]+(?=\\s*=)'], ['s', S(R.dq)], ['s', S(R.sq)]
  ];
  var htmlRules = [
    ['c', '<!--[\\s\\S]*?-->'], ['c', '<![A-Za-z][^>]*>'],
    ['x', '<\\/?[A-Za-z](?:"[^"]*"|\'[^\']*\'|[^>"\'])*>', function (t) { return run(t, tagInner); }]
  ];
  var cssRules = [
    ['c', S(R.cblock)], ['s', S(R.dq)], ['s', S(R.sq)], ['n', '#[0-9a-fA-F]{3,8}\\b'], ['k', '@[\\w-]+'],
    ['k', '!important'], ['a', '-?[a-zA-Z][\\w-]*(?=\\s*:\\s)'], ['f', '[.#][A-Za-z_-][\\w-]*'],
    ['n', '\\b\\d+(?:\\.\\d+)?(?:px|r?em|vh|vw|pt|ms|s|deg|fr)?\\b|\\b\\d+(?:\\.\\d+)?%']
  ];
  var diffRules = [['add', '^\\+[^\\n]*'], ['del', '^-[^\\n]*'], ['c', '^@@[^\\n]*']];

  var L = {};
  function reg(names, rules, flags) { names.split(' ').forEach(function (n) { L[n] = { rules: rules, flags: flags || '' }; }); }
  reg('js javascript jsx mjs ts typescript tsx java kt kotlin kts cs csharp go golang rust rs swift php dart scala groovy gradle objc zig', clikeRules);
  reg('c h cpp cc cxx hpp c++', cppRules, 'm');
  reg('python py python3', pyRules);
  reg('ruby rb', rbRules);
  reg('sh bash zsh shell', shRules);
  reg('sql', sqlRules, 'i');
  reg('json jsonc json5', jsonRules);
  reg('yaml yml', yamlRules);
  reg('toml ini', tomlRules, 'm');
  reg('html xml svg xhtml', htmlRules);
  reg('css scss less', cssRules);
  reg('diff patch', diffRules, 'm');

  root.querySelectorAll('pre > code').forEach(function (code) {
    var cls = Array.prototype.slice.call(code.classList).filter(function (c) { return c.indexOf('language-') === 0; })[0];
    if (!cls) return;
    var def = L[cls.slice(9).toLowerCase()];
    if (!def) return;
    try { code.innerHTML = run(code.textContent, def.rules, def.flags); } catch (e) { /* leave plain */ }
  });

  /* ---------- heading ids (GitHub-style slugs) ---------- */
  var seen = {};
  root.querySelectorAll('h1,h2,h3,h4,h5,h6').forEach(function (h) {
    if (h.id) return;
    var base = h.textContent.trim().toLowerCase().replace(/[^\p{L}\p{N}\p{M}\s_-]/gu, '').replace(/\s/g, '-');
    var n = seen[base], id;
    if (n === undefined) { seen[base] = 1; id = base; } else { id = base + '-' + n; seen[base] = n + 1; }
    h.id = id;
  });

  /* ---------- task lists ---------- */
  root.querySelectorAll('input[type=checkbox]').forEach(function (cb) {
    cb.disabled = true;
    var li = cb.closest('li');
    if (li) li.classList.add('task-list-item');
  });

  /* ---------- GitHub alerts ---------- */
  var ALERTS = {
    NOTE: ['note', '\u24D8', 'Note'], TIP: ['tip', '\uD83D\uDCA1', 'Tip'], IMPORTANT: ['important', '\u2757', 'Important'],
    WARNING: ['warning', '\u26A0\uFE0F', 'Warning'], CAUTION: ['caution', '\uD83D\uDED1', 'Caution']
  };
  root.querySelectorAll('blockquote').forEach(function (bq) {
    var p = bq.firstElementChild;
    if (!p || p.tagName !== 'P') return;
    var m = /^\s*\[!(NOTE|TIP|IMPORTANT|WARNING|CAUTION)\][ \t]*(?:\r?\n|<br\s*\/?>\s*|$)/i.exec(p.innerHTML);
    if (!m) return;
    var a = ALERTS[m[1].toUpperCase()];
    p.innerHTML = p.innerHTML.slice(m[0].length);
    if (!p.textContent.trim() && !p.children.length) bq.removeChild(p);
    var title = document.createElement('p');
    title.className = 'markdown-alert-title';
    title.textContent = a[1] + ' ' + a[2];
    bq.insertBefore(title, bq.firstChild);
    bq.classList.add('markdown-alert', 'markdown-alert-' + a[0]);
  });

  /* ---------- small bitmaps: crisp pixels; large ones: smooth downscale ---------- */
  root.querySelectorAll('.pbm img').forEach(function (img) {
    function fit() { img.style.imageRendering = img.naturalWidth > root.clientWidth ? 'auto' : 'pixelated'; }
    if (img.complete) fit(); else img.addEventListener('load', fit);
  });

  /* ---------- in-page anchors ---------- */
  root.addEventListener('click', function (e) {
    var a = e.target.closest ? e.target.closest('a') : null;
    if (!a) return;
    var h = a.getAttribute('href');
    if (!h || h.charAt(0) !== '#') return;
    e.preventDefault();
    var id = h.slice(1);
    try { id = decodeURIComponent(id); } catch (err) { /* keep raw */ }
    var t = document.getElementById(id) || document.getElementById(id.toLowerCase()) || document.getElementsByName(id)[0];
    if (t) t.scrollIntoView();
  });
})();
