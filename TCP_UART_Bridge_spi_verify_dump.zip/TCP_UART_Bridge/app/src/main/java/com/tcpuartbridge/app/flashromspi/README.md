# `flashromspi` — the real flashrom binary, for SPI (CH341A) only

Unlike `isp/` (a from-scratch Kotlin reimplementation of the SPI NOR command set and an
alternative serprog/UART programmer path), this package runs the **actual, real flashrom CLI
binary** as a native subprocess against the CH341A — the same binary, the same patched `libusb`,
and the same USB-file-descriptor-handoff trick the Diamon "Flash EEPROM Tool" project
(`com.diamon.curso`) uses — trimmed down to only the `ch341a_spi` programmer path. No PCI, no
FTDI/JTAG programmers, no serprog/Arduino/PTY bridging, no MiniPro, no UI, no ads/billing — just:
open the CH341A, hand its file descriptor to a real flashrom process, run it.

## Why a real binary instead of reimplementing the protocol (see `isp/`)

flashrom's SPI NOR support is extremely mature — chip quirks, block-protect handling, 4-byte
addressing, progress reporting, layout files, all of it — built up over many chips and years.
Reimplementing that in Kotlin (`isp/IspFlash.kt`, `eeprom/SpiFlash.kt`) only ever covers the
common cases. Running flashrom itself gets the real thing, at the cost of shipping native
binaries and a small JNI shim instead of pure Kotlin.

## How it actually talks to the CH341A without root

flashrom's `ch341a_spi` programmer uses **libusb**, and libusb on stock Android normally needs
root to open a raw USB device. The Flash-EEPROM-Tool project works around that with two pieces,
both reused here as-is:

1. **A patched libusb** (`libusb_1_0.so`, shipped as `libusb-1.0.so` at runtime). Built from
   upstream libusb with a small patch (`patch_libusb.py`, part of that project, not reproduced
   here — only its *compiled output* was reused) that checks for an `ANDROID_USB_FD` environment
   variable: if set, `libusb_open()` calls `libusb_wrap_sys_device()` on that fd instead of
   scanning `/dev/bus/usb` (which needs root), and the device descriptor is read with a direct
   `ioctl(fd, USBDEVFS_CONTROL, ...)` instead of the normal enumeration path. flashrom's own code
   is completely unaware of any of this — it just calls ordinary libusb functions.
2. **A tiny JNI shim** (`native-lib.cpp`, adapted here) that does its own `fork()`+`exec()` of the
   flashrom binary, because Android's `ProcessBuilder` marks every file descriptor above
   stdin/stdout/stderr close-on-exec, which would silently close the USB connection's fd (from
   `UsbDeviceConnection.getFileDescriptor()`) before flashrom ever saw it. The shim clears that
   flag on a duplicate of the fd first, sets `ANDROID_USB_FD` in the child's environment, and
   execs flashrom.

## What's bundled, and why each file is here

All of it is arm64-v8a only (`app/src/main/jniLibs/arm64-v8a/`), copied byte-for-byte from
Flash-EEPROM-Tool's own `app/src/main/jniLibs/arm64-v8a/` — nothing here was recompiled, only
selected and copied:

| File (as shipped) | Runtime name | Why it's needed |
|---|---|---|
| `libflashrom_bin.so` | `usr/sbin/flashrom` | The actual flashrom CLI — an ELF *executable*, packaged with a `.so` name purely so Android's APK packaging accepts it into `jniLibs` and extracts it to a real, executable file path (`nativeLibraryDir`) instead of leaving it compressed/mmap'd inside the APK. |
| `libusb_1_0.so` | `libusb-1.0.so` | The patched libusb described above — what actually talks to the CH341A. |
| `libcrypto_3.so` | `libcrypto.so.3` | Directly linked by the flashrom binary itself (OpenSSL's libcrypto — flashrom links this unconditionally regardless of which programmer is used). |
| `libpci_3_15_0.so` | `libpci.so.3` | Directly linked by the flashrom binary. Its actual PCI-scanning code is never reached by `ch341a_spi` — this is here purely because the dynamic linker requires *every* declared dependency of a binary to resolve before it will run at all, whether or not that dependency's code ever executes. It further needs `libz.so.1`. |
| `libftdi1_2_6_0.so` | `libftdi1.so.2` | Same story as libpci — flashrom was built with the FTDI-based programmer backends compiled in too. Unused by `ch341a_spi`, but required to load. |
| `libjaylink.so` | `libjaylink.so` | Same story again — SEGGER J-Link backend. Unused by `ch341a_spi`, required to load. |
| `libz_1.so` | `libz.so.1` | Transitively required by `libpci.so.3`. |

Left out entirely (present in Flash-EEPROM-Tool, not needed for `ch341a_spi`): `libpyftdi1.so` and
the whole Python/pyftdi stack, `liblspci.so`/`libsetpci.so`/`libpcilmr.so` (PCI command-line
tools), `libftdi_eeprom.so`, `libftdipp1*.so` (the FTDI C++ wrapper), `libconfuse.so` and
`libc++_shared.so` (neither is a dependency of anything in the table above), and the entire
`assets/data/data/com.diamon.curso/...` bundled root filesystem (docs, `pci.ids`, Python — none of
it is needed to run `flashrom -p ch341a_spi`).

## What's here, on the Kotlin/native side

| File | What it does |
|---|---|
| `app/src/main/cpp/native-lib.cpp` + `CMakeLists.txt` | The JNI shim — adapted from Flash-EEPROM-Tool's own `native-lib.cpp`, keeping only the `fork()`/`exec()`/wait/kill functions the `ch341a_spi` path needs and dropping its PTY-bridging functions (those exist only for the serprog/Arduino path, which needs none of this). |
| `NativeProcess.kt` | The Kotlin side of that JNI boundary. |
| `FlashromRuntime.kt` | Creates the classically-named symlinks (`libusb-1.0.so`, `libpci.so.3`, ...) flashrom's dynamic linker expects, pointing at the underscored names Android's jniLibs packaging requires (`libusb_1_0.so`, `libpci_3_15_0.so`, ...) — same technique as Flash-EEPROM-Tool's `AssetHelper.ensureNativeToolLinks()`, trimmed to the seven files in the table above. |
| `FlashromProcess.kt` | Runs the binary via `NativeProcess`, streams its combined stdout+stderr back as it runs (matches Flash-EEPROM-Tool's `FlashromExecutor`). |
| `Ch341SpiUsbConnection.kt` | Finds/opens the CH341A (VID `0x1A86` / PID `0x5512`) and gets its connection's fd — deliberately separate from `ch341/Ch341UsbDevice.kt`, since this package hands the fd to libusb instead of issuing USB transfers directly. |
| `FlashromSpiController.kt` | Ties the above together: connect, probe, read, write, verify, erase — one suspend function each, same shape as `programmer/ProgrammerController.kt`. |

## Status

**Wired into the SPI Flash (25xx) page** - `MainActivity.kt`'s Connect/Detect Chip/Read/Erase/
Write/Write Random/Verify/Dump buttons on that page all call `FlashromSpiController` now (via a small
line-buffered logger, `MainActivity.FlashromLineLogger`, that streams flashrom's own stdout+stderr
into the app's log view). This replaced that page's original hand-rolled driver
(`eeprom/SpiFlash.kt` + `ch341/Ch341Spi.kt`, both now unused dead code) outright, using a
completely separate USB connection from the rest of the app (see `Ch341SpiUsbConnection.kt`'s doc
comment) - the I2C EEPROM and SSD1306 Display pages are untouched and still use the original
driver via `ProgrammerController`.

**This one needs an actual NDK-equipped build to even compile**, unlike the rest of this repo:
`native-lib.cpp` has to be compiled into `libflashromjni.so` by Gradle/CMake, which needs the
Android NDK installed (see the root `README.md`'s "Building" section). Like the rest of this
delivery, everything here is logically reviewed — the native library set was checked file-by-file
with `readelf` against the actual binaries to confirm this exact list resolves every dynamic
dependency (see the table above), and `MainActivity`'s new code paths were re-read end to end
against `FlashromSpiController`'s actual signatures — but not built or run against real hardware.
Confirm a clean Gradle build with NDK installed, and test the USB-fd handoff against a real
CH341A, before relying on it.
