# TCP UART Bridge — CH341A EEPROM & Flash Programmer

Turns an Android phone into a **CH341A USB EEPROM/SPI programmer** -
plug in one of the common black/green CH341A programmer boards (VID
`1A86` / PID `5512`, running in its EEPROM/SPI *programmer* mode - not a
plain CH340 UART adapter), pick a mode, hit **Connect**, and read,
write, or erase I2C EEPROMs and SPI NOR flash chips, drive a small
SSD1306 I2C OLED display, or bridge I2C/SPI over the network to another
device - all from the phone, no PC required.

**Note on this delivery:** this is a complete, ready-to-build Android
Studio project (Gradle config, manifest, Kotlin sources, resources). It
was put together in an environment with no Android SDK and no network
access, so no `.apk` binary is included - build it with the steps
below. It has been through real Gradle build/install cycles during
development (catching and fixing several real bugs along the way -
see `NOTICE.md` for the technical ones with license implications) but
has **not** been exercised against real CH341A hardware, so treat the
actual USB/I2C/SPI behavior as logically reviewed and cross-checked
against known-working reference implementations, not hardware-verified.

## The four modes

The **Mode** picker (repeated in a small row at the top of every
screen, always in sync) switches between:

| Mode | What it's for |
|---|---|
| **I2C EEPROM (24Cxx)** | Read/write/erase 24-series I2C EEPROMs |
| **SPI Flash (25xx)** | Read/write/erase 25-series SPI NOR flash |
| **SSD1306 Display** | Drive a small I2C OLED panel |
| **TCP Server** | Bridge I2C/SPI over the network to another device |

Only one mode's screen is shown at a time, and the **Mode** picker is
disabled while connected - disconnect first to switch. **TCP Server**
doesn't need its own USB connection type: under the hood it connects
exactly the way **I2C EEPROM** does, since that's all I2C-over-TCP
actually needs (see `ProgrammerController.connect()` and the `UiPage`
enum in `MainActivity.kt`).

## I2C EEPROM (24Cxx)

Pick a chip from the **Chip** picker - 13 presets from 24C01 (128 B)
through 24C1024 (128 KB), plus the two oddball-addressing 24LC515/
24LC1025 (64 KB/128 KB) variants - or enter a custom size manually.
Then:

- **Read** - dumps the whole chip into the hex editor below.
- **Write** - prompts for a `.bin` file (via Android's file picker) and
  writes it, page-by-page.
- **Erase** - fills the chip with `0xFF`.
- **Write Random** - fills the hex editor with random bytes and writes
  them - a quick way to get *something* different on the chip to
  verify a Read afterward actually reads it back.
- **Detect** - probes to figure out the chip's actual size, for when
  you don't know which 24Cxx you're holding.
- **Verify** / **Dump** - **UI only, not wired up yet** - present in
  the layout (per the reference design this screen is styled after)
  but tapping them does nothing. See "Not yet implemented" below.

The hex editor (16 bytes/row, offset | hex | ASCII, tap any byte or
ASCII character to edit it in place) is always showing *something* -
256 bytes of `0xFF` on first launch, then whatever the last Read/Write
Random/Load File put there - and **Load File**/**Save File** let you
pull that buffer from or push it to a file independent of the actual
chip.

## SPI Flash (25xx)

**Runs the real flashrom binary** (`flashromspi/`, `-p ch341a_spi`) rather than a hand-rolled SPI
NOR command set - see that package's `README.md` for how it talks to the CH341A without root. This
page's **Connect** button opens its own connection (separate from the EEPROM/Display pages') and
prepares flashrom's bundled native libraries; everything below only works once that's connected.

- **Detect Chip** runs flashrom's own probe (no read/write/erase - just chip identification) and
  parses its output line (`Found <Vendor> flash chip "<Name>" (<size> kB, SPI) on ch341a_spi.`) to
  fill in the name/size and, where the name matches one of `SpiFlashDatabase.kt`'s 31 known parts,
  the chip spinner - falling back to "Custom" with the decoded size otherwise. flashrom's own chip
  database is far larger than that list, so an unmatched name is normal, not a failure.
- **Read** / **Write** / **Erase** run `flashrom -r` / `-w` / `--erase` against a temp file under
  the app's cache dir, loading the result into (or saving the hex editor's current bytes to) that
  file - `Write` and `Write Random` both get flashrom's own erase-what's-needed-then-write-then-
  verify behavior for free, rather than the fixed page-size loop the old driver used (the page
  size field is no longer read - flashrom picks its own strategy per chip).
- **Verify** runs `flashrom -v` against the hex editor's current bytes - confirms the chip actually
  matches what you just wrote (or loaded), without a manual Read + compare.
- **Dump** is Read followed immediately by the Save File picker - a one-tap backup, versus Read's
  "load it for viewing/editing."
- Every operation streams flashrom's real progress/status text into the log below, instead of a
  byte-count progress percentage.

Same always-populated 16-byte-row hex editor and Load File/Save File as the EEPROM panel - every
button above goes through it exactly as before.

## SSD1306 Display

Set the I2C address (`3C` is the near-universal default; some boards
use `3D`) and panel size (128x64, 128x32, 96x16, or 64x32 - each with
its own correct contrast/COM-pin configuration), tap **Init Display**
once, then:

- **Test Pattern** / **Clear**
- **Draw Text** - draws whatever's in the text box, in the built-in 5x7
  pixel font (upper/lowercase, digits, punctuation) or a loaded custom
  font (see below)
- **Load Image** - any picture via the file picker, scaled to the
  panel and dithered to 1-bit automatically

**Custom Font** - pick one of the two bundled pixel fonts (Alagard,
PixelOperator) or any `.ttf`/`.otf` from the phone; once loaded, **Draw
Text** and the **Clock**'s time/date use it instead of the built-in font.

**Clock** - an analog clock face plus digital time/date, redrawn once a
second, until you hit Stop.

**Device Stats** - battery level, battery temperature, RAM, storage,
and the phone's IP address, redrawn once a second.

**Animate Images** - pick 2+ images (any order, any format) and they
loop on the panel at whatever delay you set, each frame scaled/dithered
the same way Load Image does.

Only one of Clock/Stats/Animate runs at a time - starting one stops
whichever of the other two was running.

## TCP Server

**I2C-over-TCP** - tap **Start** and any device on the network can run
I2C transactions against whatever's wired to the CH341A, not just this
app - see `I2cTcpServer.kt`'s doc comment for the exact length-prefixed
wire protocol. Needs a live connection (which, per the Mode note above,
this page opens the same way I2C EEPROM mode does).

**SPI-over-TCP** - **UI only, not wired up yet** - see "Not yet
implemented" below.

## In-System Programming (ISP) - external serprog programmer

A second way to talk to a SPI NOR flash chip, alongside the CH341A path above: driving an
**external serprog-speaking programmer** - typically a small microcontroller board (an Arduino,
an FTDI-based adapter with the right firmware, etc.) wired to the chip's SPI pins - over UART,
using flashrom's own **serprog** wire protocol. Useful when the CH341A clip can't get a clean
direct connection to a chip that's still soldered into a board.

**Backend only - no UI for this yet.** `isp/` has a complete, self-contained implementation
(protocol client, SPI NOR read/write/erase, a write-protection status decoder, and a field
checklist of in-circuit-programming gotchas) built the same way the rest of this app is - see
`isp/README.md` for what's in it and where the protocol/knowledge came from, and `NOTICE.md` for
provenance. It isn't wired into `MainActivity` or any layout - see "Not yet implemented" below for
the app's general approach to backend-ahead-of-UI features - but `IspController.kt` is built to
the same connect/action shape as `ProgrammerController.kt` specifically so a future screen can
reuse that existing pattern.

## SPI flashing via the real flashrom binary (`flashromspi`)

A third, different way to talk to the CH341A's SPI Flash mode: instead of a Kotlin
reimplementation of the SPI NOR command set (the two paths above), `flashromspi/` runs the actual,
real **flashrom CLI binary** as a native subprocess - the same binary and patched `libusb` the
Diamon "Flash EEPROM Tool" project uses, reused directly and restricted to just the `ch341a_spi`
programmer path (no PCI, FTDI/JTAG, serprog, or PTY bridging - see that package's `README.md` for
the full explanation, including how it talks to the CH341A over libusb without root).

**This is what the SPI Flash (25xx) page's Connect/Detect/Read/Write/Erase/Write Random/Verify/Dump
buttons actually run** - see the "SPI Flash (25xx)" section above. It replaced that page's original
hand-rolled driver outright rather than sitting alongside it; `eeprom/SpiFlash.kt` and
`ch341/Ch341Spi.kt` are unused dead code now (the I2C EEPROM page's I2C driver is untouched - this
only affects the SPI Flash page). **Needs an NDK build**, unlike the rest of this repo:
`app/src/main/cpp/native-lib.cpp` (a small JNI shim needed to hand the CH341A's USB file
descriptor to the flashrom process) has to be compiled by Gradle/CMake, which needs the Android
NDK installed - see "Building" below. `FlashromSpiController.kt` exposes the same
connect/probe/read/write/erase shape `ProgrammerController.kt` uses for its own modes.

## Not yet implemented

Two controls exist in the layout - styled and positioned to match the
reference design this app's UI follows - but have no code behind them:

- **Verify** and **Dump** on the **EEPROM** panel specifically (the
  SPI Flash panel's versions are wired - see "SPI Flash (25xx)"
  above) - no `onClickListener` at all; tapping them does nothing.
  There's no I2C equivalent of flashrom to lean on the way SPI now
  does, so these would need genuine new logic in `I2cEeprom.kt`
  rather than another wiring pass.
- **SPI-over-TCP** (TCP Server page) - a status line, port field, and
  Start/Stop button that don't yet do anything. A real implementation
  would need its own server class arbitrating the SPI bus between
  this app's own UI and a remote client, analogous to
  `I2cTcpServer.kt` but for SPI.

If you pick either of these up, `MainActivity.kt`'s existing
`onEepromDetectClicked`/`onSpiVerifyClicked`/`onI2cTcpToggleClicked`
and `ProgrammerController`'s corresponding suspend functions are the
pattern to follow.

## Project structure

```
app/src/main/java/com/tcpuartbridge/app/
├── MainActivity.kt          UI wiring: buttons, spinners, the hex editor, mode switching
├── ch341/                   Raw CH341A USB transport + its SPI/I2C stream protocols
├── eeprom/                  I2C EEPROM (24Cxx) and SPI NOR flash (25xx) logic + chip databases
├── display/                 SSD1306 driver, and the clock/stats/text-rendering compositor
├── programmer/              ProgrammerController (ties USB+EEPROM+SPI+display+TCP together),
│                             I2cTcpServer
├── isp/                     In-System Programming via an external serprog programmer (UART) -
│                             backend only, not yet wired into the UI - see isp/README.md
├── flashromspi/             Real flashrom binary + patched libusb, ch341a_spi only - wired into
│                             the SPI Flash page; needs an NDK build - see flashromspi/README.md
└── ui/                      HexEditorAdapter (the 16-bytes/row hex+ASCII grid)
```

```
app/src/main/cpp/            native-lib.cpp + CMakeLists.txt - the flashromspi/ JNI shim
app/src/main/jniLibs/arm64-v8a/  Prebuilt flashrom/libusb/etc. binaries for flashromspi/ -
                              see flashromspi/README.md for the full file list
```

## Permissions

| Permission | Why |
|---|---|
| USB host feature | Talk to the CH341A over USB |
| `INTERNET` | Run the I2C-over-TCP server |
| `ACCESS_NETWORK_STATE` / `ACCESS_WIFI_STATE` | Show the phone's IP address (TCP Server page, Device Stats) |

EEPROM/SPI flash dump load/save and OLED image/font/animation-frame
picking all go through Android's Storage Access Framework file picker,
so none of it needs a storage permission.

## Building

Standard Android Studio project - open the folder, let Gradle sync,
build/run on a phone with USB host support. `minSdk` 26, `targetSdk`/
`compileSdk` 35.

**One exception:** `flashromspi/` includes a small native component
(`app/src/main/cpp/native-lib.cpp`), so a build needs the **Android
NDK and CMake installed** (Android Studio's SDK Manager, "SDK Tools"
tab) - without them, Gradle will fail to configure the
`externalNativeBuild` task. If you don't need that package, its native
sources and the `app/src/main/jniLibs/arm64-v8a/` binaries can simply
be deleted along with the `externalNativeBuild`/`ndk.abiFilters` block
in `app/build.gradle`; nothing else in the app depends on them.

## License / attribution

Most of this app is original code written from public/standard
specifications (the SPI NOR JEDEC command set, the SSD1306 datasheet,
etc). The parts that aren't - protocol logic ported from two
GPL-licensed C projects (flashrom, IMSProg), some BSD-licensed code and
data from Adafruit's SSD1306/GFX libraries, two bundled third-party
font files, and (`flashromspi/` only) actual prebuilt GPL/LGPL/Apache/
zlib-licensed binaries reused as-is rather than ported - are documented
file-by-file in `NOTICE.md`.
