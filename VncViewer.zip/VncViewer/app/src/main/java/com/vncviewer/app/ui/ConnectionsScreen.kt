package com.vncviewer.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.vncviewer.app.data.Engine
import com.vncviewer.app.data.TargetParser
import com.vncviewer.app.data.VncProfile
import com.vncviewer.app.realvnc.RealVncCore
import com.vncviewer.app.session.Phase

@Composable
fun ConnectionsScreen(vm: VncViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .padding(horizontal = 16.dp)
    ) {
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text("VncViewer", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text(
                    "VNC remote desktop client",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            TextButton(onClick = { vm.openSettings() }) { Text("Settings") }
            Button(onClick = { vm.startNewProfile() }) { Text("+ New") }
        }

        Spacer(Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = vm.quickText,
                onValueChange = { vm.quickText = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                label = { Text("Quick connect") },
                placeholder = { Text("192.168.1.10:1  or  host:5901") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { vm.quickConnect() })
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = { vm.quickConnect() }) { Text("Connect") }
        }
        Spacer(Modifier.height(8.dp))
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Engine", style = MaterialTheme.typography.labelLarge)
            for (e in Engine.values()) {
                ToolChip(e.label, vm.quickEngine == e, compact = true) { vm.quickEngine = e }
            }
        }
        val message = vm.listMessage
        if (message != null) {
            Text(message, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }

        if (vm.sessions.isNotEmpty()) {
            Spacer(Modifier.height(14.dp))
            Text("Open sessions", style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(6.dp))
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                for (s in vm.sessions) {
                    val state = when (s.phase) {
                        Phase.CONNECTED -> ""
                        Phase.CONNECTING -> " (connecting)"
                        Phase.AUTH_REQUIRED -> " (password)"
                        Phase.FAILED -> " (disconnected)"
                    }
                    ToolChip(s.title + state, vm.activeSessionId == s.id) { vm.selectSession(s.id) }
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        Text("Saved connections", style = MaterialTheme.typography.titleSmall)
        Spacer(Modifier.height(6.dp))

        if (vm.profiles.isEmpty()) {
            Text(
                "Nothing saved yet. Tap \"+ New\" to add a computer, or type an address above and press Connect.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 8.dp)
            )
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(vm.profiles, key = { it.id }) { profile ->
                    ProfileCard(vm, profile)
                }
                item { Spacer(Modifier.height(16.dp)) }
            }
        }
    }

    val editing = vm.editorProfile
    if (editing != null) {
        ProfileEditorDialog(
            initial = editing,
            isNew = vm.editorIsNew,
            onSave = { saved ->
                vm.saveProfile(saved)
                vm.editorProfile = null
            },
            onDismiss = { vm.editorProfile = null }
        )
    }

    val toDelete = vm.deleteCandidate
    if (toDelete != null) {
        AlertDialog(
            onDismissRequest = { vm.deleteCandidate = null },
            title = { Text("Delete connection?") },
            text = { Text("\"" + toDelete.name.ifBlank { toDelete.address } + "\" will be removed from this device.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.deleteProfile(toDelete)
                    vm.deleteCandidate = null
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { vm.deleteCandidate = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun ProfileCard(vm: VncViewModel, profile: VncProfile) {
    Card(modifier = Modifier
        .fillMaxWidth()
        .clickable { vm.connect(profile) }
    ) {
        Row(
            modifier = Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = profile.name.ifBlank { profile.host },
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                val extras = (if (profile.engine == Engine.REALVNC) " \u00B7 RealVNC" else "") +
                    (if (profile.viewOnly) " \u00B7 view only" else "") +
                    (if (profile.password.isNotEmpty()) " \u00B7 password saved" else "")
                Text(
                    text = profile.address + extras,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            TextButton(onClick = { vm.toggleFavorite(profile) }) {
                Text(if (profile.favorite) "\u2605" else "\u2606")
            }
            TextButton(onClick = { vm.startEditProfile(profile) }) { Text("Edit") }
            TextButton(onClick = { vm.deleteCandidate = profile }) { Text("Delete") }
        }
    }
}

@Composable
private fun ProfileEditorDialog(
    initial: VncProfile,
    isNew: Boolean,
    onSave: (VncProfile) -> Unit,
    onDismiss: () -> Unit
) {
    var name by remember(initial.id) { mutableStateOf(initial.name) }
    var server by remember(initial.id) { mutableStateOf(if (initial.host.isEmpty()) "" else initial.address) }
    var password by remember(initial.id) { mutableStateOf(initial.password) }
    var savePassword by remember(initial.id) { mutableStateOf(isNew || initial.password.isNotEmpty()) }
    var viewOnly by remember(initial.id) { mutableStateOf(initial.viewOnly) }
    var errorText by remember(initial.id) { mutableStateOf<String?>(null) }
    var engine by remember(initial.id) { mutableStateOf(initial.engine) }
    var userName by remember(initial.id) { mutableStateOf(initial.userName) }
    var quality by remember(initial.id) { mutableStateOf(initial.quality) }
    val engineProblem: String? = if (engine == Engine.REALVNC) RealVncCore.unavailableReason() else null

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (isNew) "New connection" else "Edit connection") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    singleLine = true,
                    label = { Text("Name (optional)") }
                )
                Text("Engine", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (e in Engine.values()) {
                        ToolChip(e.label, engine == e, compact = true) { engine = e }
                    }
                }
                if (engine == Engine.BUILTIN) {
                    Text(
                        "Plain VNC client built into the app. Works with most servers; the connection is not encrypted.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    Text(
                        "RealVNC's own viewer core: encrypted connections, UDP, ZRLE2 and RealVNC authentication. Best with RealVNC Server.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (engineProblem != null) {
                        Text(engineProblem, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    }
                }
                OutlinedTextField(
                    value = server,
                    onValueChange = {
                        server = it
                        errorText = null
                    },
                    singleLine = true,
                    label = { Text("Server") },
                    placeholder = { Text("192.168.1.10:1  or  host:5901") },
                    supportingText = { Text("host, host:display (e.g. :1 = port 5901) or host:port") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri)
                )
                if (engine == Engine.REALVNC) {
                    OutlinedTextField(
                        value = userName,
                        onValueChange = { userName = it },
                        singleLine = true,
                        label = { Text("User name (optional)") },
                        supportingText = { Text("Only for servers that sign in with user name + password") }
                    )
                    Text("Picture quality", style = MaterialTheme.typography.labelLarge)
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        for (q in listOf("Auto", "High", "Medium", "Low")) {
                            ToolChip(q, quality == q, compact = true) { quality = q }
                        }
                    }
                }
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    singleLine = true,
                    label = { Text(if (engine == Engine.REALVNC) "Password" else "VNC password") },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Save password (encrypted)", modifier = Modifier.weight(1f))
                    Switch(checked = savePassword, onCheckedChange = { savePassword = it })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("View only", modifier = Modifier.weight(1f))
                    Switch(checked = viewOnly, onCheckedChange = { viewOnly = it })
                }
                val err = errorText
                if (err != null) {
                    Text(err, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val target = TargetParser.parse(server)
                if (target == null) {
                    errorText = "Enter a valid server address."
                } else {
                    onSave(
                        initial.copy(
                            name = name.trim().ifEmpty { target.host },
                            host = target.host,
                            port = target.port,
                            password = if (savePassword) password else "",
                            viewOnly = viewOnly,
                            engine = engine,
                            userName = userName.trim(),
                            quality = quality
                        )
                    )
                }
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
