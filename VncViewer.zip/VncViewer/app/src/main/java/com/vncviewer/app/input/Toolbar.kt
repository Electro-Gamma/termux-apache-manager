// SPDX-License-Identifier: MIT
//
// Kotlin port of Vento's Toolbar.java (https://github.com/pgaskin/vento, control/ module,
// (C) 2026 Patrick Gaskin, MIT): the draggable column of session buttons.
package com.vncviewer.app.input

/** A thin vertical toolbar of square buttons with a grip underneath that drags it up and down. */
class Toolbar(private val cfg: Config) : TouchRouter.Claim {

    class Item(val name: String)

    interface Listener {
        fun toolbarChanged()
        fun toolbarAction(name: String)
        fun toolbarMoved(fraction: Float) {
        }
    }

    class Bounds(val item: Item?, val left: Float, val top: Float, val right: Float, val bottom: Float) {
        fun contains(x: Float, y: Float): Boolean = x >= left && x < right && y >= top && y < bottom
        fun width(): Float = right - left
        fun height(): Float = bottom - top
        fun centreX(): Float = (left + right) / 2.0f
        fun centreY(): Float = (top + bottom) / 2.0f
    }

    private var listener: Listener? = null
    private var defs: List<Item> = emptyList()
    private val items = ArrayList<Bounds>()
    private val active = LinkedHashSet<String>()
    private var grip: Bounds? = null
    private var viewW = 0
    private var viewH = 0
    private var insetLeft = 0f
    private var insetTop = 0f
    private var insetBottom = 0f
    private var visible = false
    private var fraction = 0.35f
    private var activeId = NONE
    private var activeItem: Item? = null
    private var dragging = false
    private var pressY = 0f
    private var pressTop = 0f
    private var spare = 0L

    fun setListener(l: Listener?) {
        listener = l
    }

    /** Replace the buttons; an identical list is ignored so a press under the finger survives. */
    fun setItems(names: List<String>) {
        val same = defs.size == names.size && defs.indices.all { defs[it].name == names[it] }
        if (same) return
        defs = names.map { Item(it) }
        release()
        layout()
        changed()
    }

    fun setViewSize(w: Int, h: Int) {
        if (w == viewW && h == viewH) return
        viewW = w
        viewH = h
        layout()
        changed()
    }

    fun setInsets(left: Float, top: Float, bottom: Float) {
        if (left == insetLeft && top == insetTop && bottom == insetBottom) return
        insetLeft = left
        insetTop = top
        insetBottom = bottom
        layout()
        changed()
    }

    fun visible(): Boolean = visible

    fun setVisible(v: Boolean) {
        if (visible == v) return
        visible = v
        if (!visible) release()
        changed()
    }

    fun setActive(name: String, on: Boolean) {
        val changedSet = if (on) active.add(name) else active.remove(name)
        if (changedSet) changed()
    }

    fun isActive(item: Item?): Boolean = item != null && active.contains(item.name)
    fun position(): Float = fraction

    fun setPosition(f: Float) {
        fraction = clamp(f, 0f, 1f)
        layout()
        changed()
    }

    fun items(): List<Bounds> = items
    fun grip(): Bounds? = grip
    fun pressedItem(): Item? = if (dragging) null else activeItem
    fun touched(): Boolean = activeId != NONE
    fun dragging(): Boolean = dragging
    fun left(): Float = insetLeft
    fun right(): Float = insetLeft + cfg.toolbarButtonPx
    fun top(): Float = insetTop + fraction * band()
    fun bottom(): Float = top() + height()
    fun height(): Float = if (defs.isEmpty()) 0f else defs.size * cfg.toolbarButtonPx + cfg.toolbarGripPx

    private fun band(): Float = Math.max(0f, viewH - insetTop - insetBottom - height())

    private fun layout() {
        items.clear()
        grip = null
        if (viewW <= 0 || viewH <= 0 || defs.isEmpty()) return
        val l = left()
        val r = right()
        var y = top()
        for (d in defs) {
            items.add(Bounds(d, l, y, r, y + cfg.toolbarButtonPx))
            y += cfg.toolbarButtonPx
        }
        grip = Bounds(null, l, y, r, y + cfg.toolbarGripPx)
    }

    override fun claimTouch(id: Int, x: Float, y: Float, t: Long): Boolean {
        if (!visible || defs.isEmpty() || x < left() || x >= right() || y < top() || y >= bottom()) return false
        if (activeId != NONE) {
            spare = spare or bit(id)
            return true
        }
        activeId = id
        activeItem = itemAt(x, y)
        dragging = activeItem == null
        pressY = y
        pressTop = top()
        changed()
        return true
    }

    override fun claimMoved(id: Int, x: Float, y: Float, t: Long) {
        if (id != activeId) return
        if (!dragging && Math.abs(y - pressY) > cfg.toolbarDragSlopPx) {
            dragging = true
            activeItem = null
        }
        if (dragging) {
            val b = band()
            fraction = if (b <= 0) 0f else clamp((pressTop + (y - pressY) - insetTop) / b, 0f, 1f)
            layout()
            changed()
        }
    }

    override fun claimEnded(id: Int, x: Float, y: Float, t: Long) {
        if (spare != 0L && (spare and bit(id)) != 0L) {
            spare = spare and bit(id).inv()
            return
        }
        if (id != activeId) return
        val item = activeItem
        val wasDragging = dragging
        activeId = NONE
        activeItem = null
        dragging = false
        if (wasDragging) {
            listener?.toolbarMoved(fraction)
        } else if (item != null && item === itemAt(x, y)) {
            listener?.toolbarAction(item.name)
        }
        changed()
    }

    override fun claimCancelled(t: Long) {
        release()
        changed()
    }

    private fun release() {
        activeId = NONE
        activeItem = null
        dragging = false
        spare = 0
    }

    private fun itemAt(x: Float, y: Float): Item? {
        for (b in items) if (b.contains(x, y)) return b.item
        return null
    }

    private fun bit(id: Int): Long = if (id in 0..62) 1L shl id else 0L

    private fun changed() {
        listener?.toolbarChanged()
    }

    private fun clamp(v: Float, lo: Float, hi: Float): Float = if (v < lo) lo else if (v > hi) hi else v

    private companion object {
        const val NONE = Int.MIN_VALUE
    }
}
