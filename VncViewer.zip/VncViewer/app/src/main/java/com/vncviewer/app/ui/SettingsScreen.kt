// SPDX-License-Identifier: GPL-3.0-or-later
//
// The settings tree of Vento (https://github.com/pgaskin/vento, (C) 2026 Patrick Gaskin):
// Sessions > General, Sessions > Touch and cursor, and Restore defaults - same rows, same
// wording, same defaults, drawn the way Vento draws them: rows grouped onto a container with
// large outer corners (16 dp) and small inner ones (4 dp), 2 dp between rows, 20 dp between
// groups, headings inset 24 dp, radio-style choice dialogs and OK/Cancel number dialogs.
package com.vncviewer.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.vncviewer.app.input.AppSettings
import com.vncviewer.app.input.InputSettings

private enum class Page { ROOT, GENERAL, INPUT }

@Composable
fun SettingsScreen(vm: VncViewModel) {
    var page by remember { mutableStateOf(Page.ROOT) }
    val ctx = LocalContext.current

    BackHandler {
        if (page != Page.ROOT) page = Page.ROOT else vm.closeSettings()
    }

    // Subscribing: any preference change redraws the rows below.
    AppSettings.changeTick.intValue

    Column(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        Row(
            modifier = Modifier.padding(start = 4.dp, end = 16.dp, top = 8.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = { if (page != Page.ROOT) page = Page.ROOT else vm.closeSettings() }) {
                Text("\u2039 Back")
            }
            Text(
                text = when (page) {
                    Page.ROOT -> "Settings"
                    Page.GENERAL -> "General"
                    Page.INPUT -> "Touch and cursor"
                },
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        }
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
        ) {
            when (page) {
                Page.ROOT -> RootPage(ctx, onOpen = { page = it })
                Page.GENERAL -> GeneralPage()
                Page.INPUT -> InputPage()
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

// ---- the root ------------------------------------------------------------------------------

@Composable
private fun RootPage(ctx: android.content.Context, onOpen: (Page) -> Unit) {
    var confirm by remember { mutableStateOf(false) }
    var done by remember { mutableStateOf(false) }

    Heading("Sessions")
    Group(
        { m -> LinkRow(m, "General", "Keyboard, clipboard, and controls.") { onOpen(Page.GENERAL) } },
        { m -> LinkRow(m, "Touch and cursor", "Acceleration, momentum, and scrolling.") { onOpen(Page.INPUT) } }
    )
    Heading("App")
    Group(
        { m ->
            LinkRow(
                m, "Restore defaults",
                "Reset all session, backend, and app settings. Saved connections are not touched."
            ) { confirm = true }
        }
    )
    if (done) {
        Text(
            "Settings cleared",
            color = MaterialTheme.colorScheme.secondary,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp)
        )
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Reset all settings?") },
            text = { Text("Reset all session, backend, and app settings. Saved connections are not touched.") },
            confirmButton = {
                TextButton(onClick = {
                    AppSettings.resetAll(ctx)
                    confirm = false
                    done = true
                }) { Text("Reset") }
            },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } }
        )
    }
}

// ---- General --------------------------------------------------------------------------------

@Composable
private fun GeneralPage() {
    val ctx = LocalContext.current

    Group(
        { m ->
            ChoiceRow(
                m,
                title = "Session timeout",
                summary = "Automatically disconnect inactive sessions.",
                valueLabel = AppSettings.timeoutLabel(AppSettings.sessionTimeout(ctx)),
                choices = AppSettings.SESSION_TIMEOUTS.map { it.toString() to AppSettings.timeoutLabel(it) },
                current = AppSettings.sessionTimeout(ctx).toString()
            ) { AppSettings.setText(ctx, AppSettings.KEY_SESSION_TIMEOUT, it) }
        },
        { m ->
            Switches(
                m, AppSettings.KEY_HUD, "Debug overlay",
                "Show cursor, viewport, gesture, and rendering debug information."
            )
        },
        { m ->
            Switches(
                m, AppSettings.KEY_KEEP_AWAKE, "Keep screen on",
                "Disable the screen timeout while connected."
            )
        },
        { m ->
            Switches(
                m, AppSettings.KEY_IMMERSIVE, "Full screen",
                "Hide the system bars while connected."
            )
        },
        { m ->
            Switches(
                m, AppSettings.KEY_PRIVATE_IME, "Treat the desktop as a password field",
                "Disable IME suggestions, auto-correction, and learning."
            )
        },
        { m ->
            Switches(
                m, AppSettings.KEY_MODIFIER_RESETS_IME, "Reset IME state when pressing modifiers",
                "Return to the main IME view when pressing Ctrl, Alt or Shift on the extension keyboard."
            )
        },
        { m ->
            Switches(
                m, AppSettings.KEY_TWO_LINE_KEYS, "Use two-row extension keyboard",
                "Reduces the amount of horizontal scrolling for the extension keyboard."
            )
        },
        { m ->
            Switches(
                m, AppSettings.KEY_MAC_KEYS, "Show additional modifiers",
                "Show the Option and Command keys in the extension keyboard."
            )
        },
        { m ->
            ChoiceRow(
                m,
                title = "Session controls",
                summary = "Change how the disconnect, connection info, keyboard, and mouse actions are displayed.",
                valueLabel = AppSettings.controlsLabel(AppSettings.controls(ctx)),
                choices = listOf(
                    AppSettings.CONTROLS_TOOLBAR to AppSettings.controlsLabel(AppSettings.CONTROLS_TOOLBAR),
                    AppSettings.CONTROLS_REGIONS to AppSettings.controlsLabel(AppSettings.CONTROLS_REGIONS),
                    AppSettings.CONTROLS_BOTH to AppSettings.controlsLabel(AppSettings.CONTROLS_BOTH)
                ),
                current = AppSettings.controls(ctx)
            ) { AppSettings.setText(ctx, AppSettings.KEY_CONTROLS, it) }
        },
        { m ->
            Switches(
                m, AppSettings.KEY_REGION_HINTS, "Ask about controls when connecting",
                "Explain the session controls and offer the choice between them on the first frame."
            )
        },
        { m ->
            Switches(
                m, AppSettings.KEY_CLIPBOARD_OUT, "Send clipboard",
                "Send locally copied text to the remote machine."
            )
        },
        { m ->
            Switches(
                m, AppSettings.KEY_CLIPBOARD_IN, "Receive clipboard",
                "Update the local clipboard with copied text."
            )
        },
        { m ->
            Switches(
                m, AppSettings.KEY_RELEASE_KEYS, "Release keys when losing focus",
                "Release all locally held keys when switching apps."
            )
        },
        { m ->
            Switches(
                m, AppSettings.KEY_CURSOR_DOT, "Dot for an invisible cursor",
                "Show a small dot where the pointer is when the server hides its cursor."
            )
        }
    )
}

@Composable
private fun Switches(modifier: Modifier, key: String, title: String, summary: String) {
    val ctx = LocalContext.current
    SwitchRow(modifier, title, summary, AppSettings.bool(ctx, key)) { AppSettings.setBool(ctx, key, it) }
}

// ---- Touch and cursor -----------------------------------------------------------------------------

@Composable
private fun InputPage() {
    val ctx = LocalContext.current
    val density = ctx.resources.displayMetrics.density
    val defaults = remember { InputSettings.defaults(density) }
    val prefs = InputSettings.prefs(ctx)
    AppSettings.changeTick.intValue

    val rows = InputSettings.TUNABLES.map { t ->
        val def = t.read(defaults)
        val stored = prefs.getString(t.key, null)
        val value = if (stored != null && stored.isNotEmpty()) stored else def
        val row: @Composable (Modifier) -> Unit = { m ->
            when (t.kind) {
                InputSettings.Kind.BOOL -> SwitchRow(m, t.label, t.summary, value.toBoolean()) { on ->
                    store(ctx, t.key, on.toString(), def)
                }
                InputSettings.Kind.NUMBER -> NumberRow(m, t.label, t.summary, value) { text ->
                    store(ctx, t.key, text, def)
                }
            }
        }
        row
    }
    Group(rows)

    // On a break of its own: an action among the values it acts on reads as one more of them.
    Spacer(Modifier.height(GROUP_SPACING))
    Group(
        { m ->
            LinkRow(m, "Reset", "Set all values above back to their defaults.") {
                InputSettings.clearOverrides(ctx)
            }
        }
    )
}

/** A value equal to the default is stored as nothing, so the default keeps answering for it. */
private fun store(ctx: android.content.Context, key: String, value: String, def: String) {
    val e = InputSettings.prefs(ctx).edit()
    if (value.trim() == def) e.remove(key) else e.putString(key, value.trim())
    e.apply()
    AppSettings.changeTick.intValue = AppSettings.changeTick.intValue + 1
}

// ---- groups and rows ----------------------------------------------------------------------------------

private val GROUP_INSET = 16.dp
private val GROUP_GAP = 2.dp
private val GROUP_SPACING = 20.dp
private val GROUP_RADIUS = 16.dp
private val GROUP_RADIUS_INNER = 4.dp
private val ROW_PADDING = 16.dp
private val ROW_MIN_HEIGHT = 56.dp

/** Large corners where a group starts or ends, small ones where the next row is. */
private fun groupShape(index: Int, count: Int): Shape {
    val first = index == 0
    val last = index == count - 1
    val outer = GROUP_RADIUS
    val inner = GROUP_RADIUS_INNER
    return RoundedCornerShape(
        topStart = if (first) outer else inner,
        topEnd = if (first) outer else inner,
        bottomStart = if (last) outer else inner,
        bottomEnd = if (last) outer else inner
    )
}

/** Contiguous rows on a container with large corners. Each row gets the background it is handed. */
@Composable
private fun Group(vararg rows: @Composable (Modifier) -> Unit) = Group(rows.toList())

@Composable
private fun Group(rows: List<@Composable (Modifier) -> Unit>) {
    val color = MaterialTheme.colorScheme.surfaceVariant
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = GROUP_INSET),
        verticalArrangement = Arrangement.spacedBy(GROUP_GAP)
    ) {
        rows.forEachIndexed { i, row ->
            row(
                Modifier
                    .fillMaxWidth()
                    .clip(groupShape(i, rows.size))
                    .background(color)
            )
        }
    }
}

/** A heading over the group that follows. */
@Composable
private fun Heading(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 24.dp, end = 24.dp, top = 24.dp, bottom = 12.dp)
    )
}

@Composable
private fun RowText(title: String, summary: String, modifier: Modifier = Modifier) {
    Column(modifier = modifier) {
        Text(title, style = MaterialTheme.typography.bodyLarge)
        if (summary.isNotEmpty()) {
            Text(
                summary,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun LinkRow(modifier: Modifier, title: String, summary: String, onClick: () -> Unit) {
    Row(
        modifier = modifier
            .clickable(onClick = onClick)
            .heightIn(min = ROW_MIN_HEIGHT)
            .padding(horizontal = ROW_PADDING, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RowText(title, summary, Modifier.weight(1f))
    }
}

@Composable
private fun SwitchRow(
    modifier: Modifier,
    title: String,
    summary: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit
) {
    Row(
        modifier = modifier
            .clickable { onChange(!checked) }
            .heightIn(min = ROW_MIN_HEIGHT)
            .padding(horizontal = ROW_PADDING, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        RowText(title, summary, Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

/** A list row: its value, then the explanation under it; the choices are radio buttons in a dialog. */
@Composable
private fun ChoiceRow(
    modifier: Modifier,
    title: String,
    summary: String,
    valueLabel: String,
    choices: List<Pair<String, String>>,
    current: String,
    onSelect: (String) -> Unit
) {
    var open by remember { mutableStateOf(false) }
    LinkRow(modifier, title, valueLabel + "\n" + summary) { open = true }
    if (open) {
        AlertDialog(
            onDismissRequest = { open = false },
            title = { Text(title) },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    for ((value, label) in choices) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onSelect(value)
                                    open = false
                                }
                                .heightIn(min = 48.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = current == value, onClick = null)
                            Text(label, modifier = Modifier.padding(start = 16.dp))
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { open = false }) { Text("Cancel") } }
        )
    }
}

/** A number row: the value, then the explanation; edited in a decimal text box with OK and Cancel. */
@Composable
private fun NumberRow(
    modifier: Modifier,
    title: String,
    summary: String,
    value: String,
    onChange: (String) -> Unit
) {
    var open by remember { mutableStateOf(false) }
    LinkRow(modifier, title, "$value\n$summary") { open = true }
    if (open) {
        var text by remember { mutableStateOf(value) }
        AlertDialog(
            onDismissRequest = { open = false },
            title = { Text(title) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(summary, style = MaterialTheme.typography.bodyMedium)
                    OutlinedTextField(
                        value = text,
                        onValueChange = { text = it },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (text.trim().toFloatOrNull() != null) onChange(text)
                    open = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { open = false }) { Text("Cancel") } }
        )
    }
}
