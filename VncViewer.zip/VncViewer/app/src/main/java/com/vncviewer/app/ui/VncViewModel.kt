package com.vncviewer.app.ui

import android.app.Application
import android.view.KeyEvent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import com.vncviewer.app.data.ProfileStore
import com.vncviewer.app.data.Engine
import com.vncviewer.app.data.TargetParser
import com.vncviewer.app.data.VncProfile
import com.vncviewer.app.session.VncSession
import java.util.UUID

enum class Screen { LIST, SESSION }

class VncViewModel(application: Application) : AndroidViewModel(application) {

    private val store = ProfileStore(application)

    val profiles = mutableStateListOf<VncProfile>()
    val sessions = mutableStateListOf<VncSession>()

    var screen by mutableStateOf(Screen.LIST)
    var activeSessionId by mutableStateOf<String?>(null)
    var fullscreen by mutableStateOf(false)

    // Connections screen state
    var quickText by mutableStateOf("")
    var quickEngine by mutableStateOf(Engine.BUILTIN)
    var listMessage by mutableStateOf<String?>(null)
    var editorProfile by mutableStateOf<VncProfile?>(null)
    var editorIsNew by mutableStateOf(false)
    var deleteCandidate by mutableStateOf<VncProfile?>(null)

    val activeSession: VncSession?
        get() = sessions.firstOrNull { it.id == activeSessionId }

    init {
        profiles.addAll(sorted(store.load()))
    }

    // ---- saved profiles ----------------------------------------------------------------

    private fun sorted(list: List<VncProfile>): List<VncProfile> {
        return list.sortedWith(
            compareByDescending<VncProfile> { it.favorite }
                .thenByDescending { it.lastUsed }
                .thenBy { it.name.lowercase() }
        )
    }

    private fun persist() {
        store.save(profiles.toList())
    }

    fun isSaved(id: String): Boolean = profiles.any { it.id == id }

    fun saveProfile(profile: VncProfile) {
        val i = profiles.indexOfFirst { it.id == profile.id }
        if (i >= 0) profiles[i] = profile else profiles.add(profile)
        val ordered = sorted(profiles.toList())
        profiles.clear()
        profiles.addAll(ordered)
        persist()
    }

    fun deleteProfile(profile: VncProfile) {
        profiles.removeAll { it.id == profile.id }
        persist()
    }

    fun toggleFavorite(profile: VncProfile) {
        saveProfile(profile.copy(favorite = !profile.favorite))
    }

    fun startNewProfile() {
        editorIsNew = true
        editorProfile = VncProfile(id = UUID.randomUUID().toString(), name = "", host = "")
    }

    fun startEditProfile(profile: VncProfile) {
        editorIsNew = false
        editorProfile = profile
    }

    // ---- connecting ---------------------------------------------------------------------

    fun connect(profile: VncProfile) {
        var p = profile
        if (isSaved(profile.id)) {
            p = profile.copy(lastUsed = System.currentTimeMillis())
            saveProfile(p)
        }
        val session = VncSession(getApplication<Application>(), UUID.randomUUID().toString(), p)
        sessions.add(session)
        activeSessionId = session.id
        screen = Screen.SESSION
        session.connect(p.password)
    }

    fun quickConnect() {
        val target = TargetParser.parse(quickText)
        if (target == null) {
            listMessage = "Enter a server such as 192.168.1.10:1 or myhost:5901"
            return
        }
        listMessage = null
        connect(
            VncProfile(
                id = "quick-" + UUID.randomUUID().toString(),
                name = target.host,
                host = target.host,
                port = target.port,
                engine = quickEngine
            )
        )
    }

    fun submitPassword(session: VncSession, password: String, remember: Boolean) {
        if (remember && isSaved(session.profile.id)) {
            val updated = session.profile.copy(password = password)
            saveProfile(updated)
            session.profile = updated
        }
        session.submitPassword(password)
    }

    /** The RealVNC engine's sign-in prompt was answered with "remember". */
    fun rememberCredentials(session: VncSession, userName: String, password: String) {
        if (!isSaved(session.profile.id)) return
        val updated = session.profile.copy(
            password = password,
            userName = if (userName.isNotEmpty()) userName else session.profile.userName
        )
        saveProfile(updated)
        session.profile = updated
    }

    fun saveSessionAsProfile(session: VncSession) {
        if (isSaved(session.profile.id)) return
        val saved = session.profile.copy(id = UUID.randomUUID().toString())
        saveProfile(saved)
        session.profile = saved
        session.showNotice("Saved to your connections")
    }

    // ---- sessions -----------------------------------------------------------------------

    fun selectSession(id: String) {
        activeSessionId = id
        screen = Screen.SESSION
    }

    fun closeSession(id: String) {
        val s = sessions.firstOrNull { it.id == id } ?: return
        s.close()
        sessions.remove(s)
        if (activeSessionId == id) {
            activeSessionId = sessions.lastOrNull()?.id
        }
        if (sessions.isEmpty()) {
            screen = Screen.LIST
            fullscreen = false
        }
    }

    /** Called from MainActivity.dispatchKeyEvent. Returns true if the key went to the remote. */
    fun handleKeyEvent(event: KeyEvent): Boolean {
        if (screen != Screen.SESSION) return false
        val s = activeSession ?: return false
        return s.onKeyEvent(event)
    }

    fun onAppStopped() {
        for (s in sessions) {
            s.releaseAllKeys()
            s.setFocused(false)
        }
    }

    fun onAppStarted() {
        for (s in sessions) s.setFocused(true)
    }

    override fun onCleared() {
        for (s in sessions) s.close()
        sessions.clear()
        super.onCleared()
    }
}
