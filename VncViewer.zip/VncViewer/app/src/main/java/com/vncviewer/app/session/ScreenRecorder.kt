package com.vncviewer.app.session

import android.content.ClipData
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.provider.MediaStore
import android.util.Log
import android.view.Surface
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** The pointer at one instant: its shape, hot spot, and where it is on the desktop (desktop pixels). */
class CursorFrame(val bitmap: Bitmap, val hotX: Int, val hotY: Int, val x: Float, val y: Float)

/**
 * Records the remote desktop to an MP4, the video counterpart of [Screenshot].
 *
 * What is filmed is the desktop itself (the framebuffer, at the size the far end has it, capped at
 * 1080p), not the phone's screen, so no screen-capture permission or dialog is involved and
 * nothing of the phone's own UI ends up in the video. Frames are drawn onto a hardware encoder's
 * input surface at a steady rate, so a desktop that is not changing still produces a video of the
 * right length. The pointer is drawn onto every frame, at the remote cursor's shape and position,
 * at twice its desktop size so it stays easy to follow at video scale.
 *
 * Android 10+: the file goes into the shared Movies/VncViewer folder (it shows up in the gallery).
 * Older versions: it is written to the cache and handed to the share sheet when it ends.
 */
class ScreenRecorder(
    context: Context,
    private val source: () -> Bitmap?,
    private val cursor: () -> CursorFrame?,
    private val title: String
) {
    private val app = context.applicationContext
    private val main = Handler(Looper.getMainLooper())

    @Volatile
    private var running = false
    private var worker: Thread? = null

    val isRecording: Boolean get() = running

    /** Begin recording; false if there is no picture yet or the device has no usable encoder. */
    fun start(): Boolean {
        if (running) return true
        val first = source() ?: return false
        if (first.isRecycled || first.width <= 0 || first.height <= 0) return false

        // Even sides, and no bigger than 1920 on the long edge: what every AVC encoder takes.
        val k = Math.min(1f, MAX_SIDE.toFloat() / Math.max(first.width, first.height))
        val w = Math.max(2, (first.width * k).toInt() and 1.inv())
        val h = Math.max(2, (first.height * k).toInt() and 1.inv())

        val out = try {
            Output.open(app, fileName())
        } catch (e: Exception) {
            Log.w(TAG, "opening the output", e)
            return false
        }

        val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            // A desktop is mostly flat colour and text: modest bits go a long way.
            setInteger(MediaFormat.KEY_BIT_RATE, (w * h * FPS * 0.12f).toInt().coerceIn(1_000_000, 10_000_000))
            setInteger(MediaFormat.KEY_FRAME_RATE, FPS)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
        }
        val codec: MediaCodec
        val surface: Surface
        try {
            codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            surface = codec.createInputSurface()
            codec.start()
        } catch (e: Exception) {
            Log.w(TAG, "starting the encoder", e)
            out.discard()
            return false
        }

        running = true
        worker = Thread({ run(codec, surface, out, w, h) }, "screen-recorder").also {
            it.isDaemon = true
            it.start()
        }
        return true
    }

    /** Stop and finish the file; it is saved on the recorder's own thread. */
    fun stop() {
        running = false
    }

    private fun run(codec: MediaCodec, surface: Surface, out: Output, w: Int, h: Int) {
        val info = MediaCodec.BufferInfo()
        val sink = Sink(codec, out, info)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG)
        val src = Rect()
        val dst = Rect(0, 0, w, h)
        val cursorDst = RectF()
        var failed = false
        try {
            val step = 1000L / FPS
            var next = SystemClock.elapsedRealtime()
            while (running) {
                val bmp = source()
                if (bmp != null && !bmp.isRecycled) {
                    src.set(0, 0, bmp.width, bmp.height)
                    val canvas = surface.lockHardwareCanvas()
                    try {
                        canvas.drawBitmap(bmp, src, dst, paint)
                        val cur = cursor()
                        if (cur != null && !cur.bitmap.isRecycled) {
                            // Desktop pixels to video pixels, then the pointer a little larger.
                            val sx = w.toFloat() / bmp.width
                            val sy = h.toFloat() / bmp.height
                            val longest = Math.max(cur.bitmap.width, cur.bitmap.height)
                            val cs = Math.min(sx * 2f, 64f / longest)
                            val px = cur.x * sx - cur.hotX * cs
                            val py = cur.y * sy - cur.hotY * cs
                            cursorDst.set(px, py, px + cur.bitmap.width * cs, py + cur.bitmap.height * cs)
                            canvas.drawBitmap(cur.bitmap, null, cursorDst, paint)
                        }
                    } finally {
                        surface.unlockCanvasAndPost(canvas)
                    }
                }
                sink.drain(false)
                next += step
                val wait = next - SystemClock.elapsedRealtime()
                if (wait > 0) SystemClock.sleep(wait) else next = SystemClock.elapsedRealtime()
            }
            codec.signalEndOfInputStream()
            sink.drain(true)
        } catch (e: Exception) {
            Log.w(TAG, "recording", e)
            failed = true
        } finally {
            running = false
            try { codec.stop() } catch (_: Exception) {}
            codec.release()
            surface.release()
            sink.finish()
        }
        val saved = if (failed && !sink.wrote) null else out.finish(sink.wrote)
        main.post { announce(saved, sink.wrote) }
    }

    private fun announce(saved: Saved?, wrote: Boolean) {
        if (!wrote || saved == null) {
            Toast.makeText(app, "Nothing was recorded.", Toast.LENGTH_SHORT).show()
            return
        }
        if (saved.shareUri != null) {
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "video/mp4"
                putExtra(Intent.EXTRA_STREAM, saved.shareUri)
                clipData = ClipData.newUri(app.contentResolver, "recording", saved.shareUri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            app.startActivity(Intent.createChooser(send, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } else {
            Toast.makeText(app, "Recording saved to Movies/VncViewer", Toast.LENGTH_LONG).show()
        }
    }

    private fun fileName(): String {
        val b = StringBuilder()
        for (c in title) {
            if (b.length >= 40) break
            if (c in 'a'..'z' || c in 'A'..'Z' || c in '0'..'9') b.append(c)
            else if (b.isNotEmpty() && b.last() != '-') b.append('-')
        }
        while (b.isNotEmpty() && b.last() == '-') b.setLength(b.length - 1)
        if (b.isEmpty()) b.append("desktop")
        val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
        return "$b-$stamp.mp4"
    }

    /** Encoder output to muxer, with the clock started at the first frame. */
    private class Sink(val codec: MediaCodec, val out: Output, val info: MediaCodec.BufferInfo) {
        private var track = -1
        private var baseUs = -1L
        var wrote = false
        private var muxerStarted = false

        fun drain(end: Boolean) {
            var idle = 0
            while (true) {
                val i = codec.dequeueOutputBuffer(info, if (end) 10_000L else 0L)
                when {
                    i == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                        if (!end || ++idle > 300) return
                    }
                    i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        track = out.muxer.addTrack(codec.outputFormat)
                        out.muxer.start()
                        muxerStarted = true
                    }
                    i >= 0 -> {
                        val buf = codec.getOutputBuffer(i)
                        if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                        if (buf != null && info.size > 0 && muxerStarted) {
                            if (baseUs < 0) baseUs = info.presentationTimeUs
                            info.presentationTimeUs = Math.max(0L, info.presentationTimeUs - baseUs)
                            buf.position(info.offset)
                            buf.limit(info.offset + info.size)
                            out.muxer.writeSampleData(track, buf, info)
                            wrote = true
                        }
                        val eos = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                        codec.releaseOutputBuffer(i, false)
                        if (eos) return
                    }
                }
            }
        }

        fun finish() {
            if (muxerStarted) {
                try { out.muxer.stop() } catch (e: Exception) { Log.w(TAG, "closing the file", e) }
            }
            try { out.muxer.release() } catch (_: Exception) {}
        }
    }

    private class Saved(val shareUri: Uri?)

    /** Where the video goes: the gallery on Android 10+, the cache (then the share sheet) before. */
    private class Output private constructor(
        val muxer: MediaMuxer,
        private val app: Context,
        private val pfd: ParcelFileDescriptor?,
        private val uri: Uri?,
        private val file: File?
    ) {
        fun discard() {
            try { muxer.release() } catch (_: Exception) {}
            close()
            if (uri != null) app.contentResolver.delete(uri, null, null)
            file?.delete()
        }

        /** Called after the muxer is finished; null shareUri means it is already in the gallery. */
        fun finish(wrote: Boolean): Saved? {
            close()
            if (!wrote) {
                if (uri != null) app.contentResolver.delete(uri, null, null)
                file?.delete()
                return null
            }
            if (uri != null) {
                val v = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                app.contentResolver.update(uri, v, null, null)
                return Saved(null)
            }
            val f = file ?: return null
            return Saved(FileProvider.getUriForFile(app, app.packageName + ".files", f))
        }

        private fun close() {
            try { pfd?.close() } catch (_: Exception) {}
        }

        companion object {
            fun open(app: Context, name: String): Output {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val v = ContentValues().apply {
                        put(MediaStore.Video.Media.DISPLAY_NAME, name)
                        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                        put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/VncViewer")
                        put(MediaStore.Video.Media.IS_PENDING, 1)
                    }
                    val uri = app.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)
                        ?: throw IllegalStateException("no MediaStore entry")
                    val pfd = app.contentResolver.openFileDescriptor(uri, "rw")
                        ?: throw IllegalStateException("no file descriptor")
                    return Output(MediaMuxer(pfd.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4), app, pfd, uri, null)
                }
                val dir = File(app.cacheDir, "recordings")
                dir.listFiles()?.forEach { it.delete() }
                if (!dir.isDirectory && !dir.mkdirs()) throw IllegalStateException("no cache folder")
                val f = File(dir, name)
                return Output(MediaMuxer(f.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4), app, null, null, f)
            }
        }
    }

    companion object {
        private const val TAG = "ScreenRecorder"
        private const val FPS = 15
        private const val MAX_SIDE = 1920
    }
}
