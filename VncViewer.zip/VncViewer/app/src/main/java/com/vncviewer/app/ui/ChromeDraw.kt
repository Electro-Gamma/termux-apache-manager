// SPDX-License-Identifier: GPL-3.0-or-later
//
// Drawing for the on-screen session controls (mouse overlay, toolbar, tap-region hints,
// debug overlay), modelled on Vento's control/ui/Chrome.java (https://github.com/pgaskin/vento,
// (C) 2026 Patrick Gaskin, MIT).
package com.vncviewer.app.ui

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import com.vncviewer.app.input.MouseOverlay
import com.vncviewer.app.input.TapRegions
import com.vncviewer.app.input.Toolbar

class ChromeDraw(private val density: Float) {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    init {
        stroke.style = Paint.Style.STROKE
        stroke.strokeCap = Paint.Cap.ROUND
        text.textAlign = Paint.Align.CENTER
    }

    private fun dp(v: Float) = v * density

    // ---- mouse overlay -------------------------------------------------------------------

    fun drawOverlay(c: Canvas, o: MouseOverlay) {
        for (b in o.parts()) {
            when (b.part) {
                MouseOverlay.Part.SCROLL -> drawStrip(c, o, b)
                MouseOverlay.Part.DISMISS -> drawDismiss(c, b, o.pressed(b.part))
                else -> drawButton(c, b, o.pressed(b.part))
            }
        }
    }

    private fun drawButton(c: Canvas, b: MouseOverlay.Bounds, pressed: Boolean) {
        fill.color = if (pressed) 0xE60F3A57.toInt() else 0xD9161B22.toInt()
        c.drawRect(b.left, b.top, b.right, b.bottom, fill)
        stroke.color = 0xFF3A4452.toInt()
        stroke.strokeWidth = dp(1f)
        c.drawRect(b.left, b.top, b.right, b.bottom, stroke)
        text.color = 0xFFE6EDF3.toInt()
        text.textSize = dp(15f)
        text.typeface = Typeface.DEFAULT_BOLD
        val label = when (b.part) {
            MouseOverlay.Part.LEFT -> "Left"
            MouseOverlay.Part.MIDDLE -> "Middle"
            else -> "Right"
        }
        c.drawText(label, (b.left + b.right) / 2f, b.centreY() + dp(5f), text)
    }

    private fun drawDismiss(c: Canvas, b: MouseOverlay.Bounds, pressed: Boolean) {
        fill.color = if (pressed) 0xE60F3A57.toInt() else 0xD9161B22.toInt()
        rect.set(b.left, b.top, b.right, b.bottom)
        c.drawRoundRect(rect, dp(6f), dp(6f), fill)
        stroke.color = 0xFFE6EDF3.toInt()
        stroke.strokeWidth = dp(2f)
        val cx = (b.left + b.right) / 2f
        val cy = b.centreY()
        val r = dp(8f)
        c.drawLine(cx - r, cy - r, cx + r, cy + r, stroke)
        c.drawLine(cx - r, cy + r, cx + r, cy - r, stroke)
    }

    private fun drawStrip(c: Canvas, o: MouseOverlay, b: MouseOverlay.Bounds) {
        fill.color = 0x99161B22.toInt()
        c.drawRect(b.left, b.top, b.right, b.bottom, fill)
        // The handle: where the finger is, and so which way and how fast the wheel turns.
        val active = o.scrollRate() != 0f
        fill.color = if (active) 0xE67CC4FF.toInt() else 0xCC39424E.toInt()
        rect.set(b.left + dp(8f), o.handleTop(), b.right - dp(8f), o.handleBottom())
        c.drawRoundRect(rect, dp(10f), dp(10f), fill)
        stroke.color = 0xFFE6EDF3.toInt()
        stroke.strokeWidth = dp(2f)
        val cx = (b.left + b.right) / 2f
        val y = (o.handleTop() + o.handleBottom()) / 2f
        val a = dp(6f)
        c.drawLine(cx - a, y - dp(10f), cx, y - dp(16f), stroke)
        c.drawLine(cx + a, y - dp(10f), cx, y - dp(16f), stroke)
        c.drawLine(cx - a, y + dp(10f), cx, y + dp(16f), stroke)
        c.drawLine(cx + a, y + dp(10f), cx, y + dp(16f), stroke)
    }

    // ---- toolbar ---------------------------------------------------------------------------

    fun drawToolbar(c: Canvas, t: Toolbar) {
        if (!t.visible() || t.items().isEmpty()) return
        val dim = !t.touched()
        val alpha = if (dim) 0xB3 else 0xF2
        fill.color = (alpha shl 24) or 0x161B22
        rect.set(t.left(), t.top(), t.right(), t.bottom())
        c.drawRoundRect(rect, dp(10f), dp(10f), fill)
        stroke.color = 0xFF3A4452.toInt()
        stroke.strokeWidth = dp(1f)
        c.drawRoundRect(rect, dp(10f), dp(10f), stroke)
        for (b in t.items()) {
            val item = b.item ?: continue
            val pressed = t.pressedItem() === item
            val on = t.isActive(item)
            if (pressed || on) {
                fill.color = if (pressed) 0xE60F3A57.toInt() else 0x990F3A57.toInt()
                rect.set(b.left + dp(3f), b.top + dp(3f), b.right - dp(3f), b.bottom - dp(3f))
                c.drawRoundRect(rect, dp(8f), dp(8f), fill)
            }
            icon(c, item.name, b.centreX(), b.centreY(), if (on) 0xFF7CC4FF.toInt() else 0xFFE6EDF3.toInt())
        }
        val g = t.grip()
        if (g != null) {
            stroke.color = if (t.dragging()) 0xFF7CC4FF.toInt() else 0xFF9DA7B3.toInt()
            stroke.strokeWidth = dp(2f)
            val cx = g.centreX()
            val cy = g.centreY()
            c.drawLine(cx - dp(9f), cy - dp(3f), cx + dp(9f), cy - dp(3f), stroke)
            c.drawLine(cx - dp(9f), cy + dp(3f), cx + dp(9f), cy + dp(3f), stroke)
        }
    }

    private fun icon(c: Canvas, name: String, cx: Float, cy: Float, color: Int) {
        stroke.color = color
        stroke.strokeWidth = dp(2f)
        fill.color = color
        val r = dp(8f)
        when (name) {
            TapRegions.DISCONNECT -> {
                c.drawLine(cx - r, cy - r, cx + r, cy + r, stroke)
                c.drawLine(cx - r, cy + r, cx + r, cy - r, stroke)
            }
            TapRegions.INFORMATION -> {
                c.drawCircle(cx, cy, r + dp(2f), stroke)
                c.drawCircle(cx, cy - dp(5f), dp(1.3f), fill)
                c.drawLine(cx, cy - dp(1.5f), cx, cy + dp(6f), stroke)
            }
            TapRegions.KEYBOARD -> {
                rect.set(cx - dp(11f), cy - dp(7f), cx + dp(11f), cy + dp(7f))
                c.drawRoundRect(rect, dp(2f), dp(2f), stroke)
                for (i in -2..2) c.drawCircle(cx + i * dp(4f), cy - dp(2.5f), dp(1f), fill)
                for (i in -1..1) c.drawCircle(cx + i * dp(4f), cy + dp(2.5f), dp(1f), fill)
            }
            TapRegions.MOUSE -> {
                rect.set(cx - dp(7f), cy - dp(10f), cx + dp(7f), cy + dp(10f))
                c.drawRoundRect(rect, dp(7f), dp(7f), stroke)
                c.drawLine(cx, cy - dp(10f), cx, cy - dp(1f), stroke)
                c.drawLine(cx - dp(7f), cy - dp(1f), cx + dp(7f), cy - dp(1f), stroke)
            }
        }
    }

    // ---- tap-region hints ------------------------------------------------------------------------

    fun drawRegionHints(c: Canvas, regions: TapRegions, w: Int, h: Int, label: (String) -> String) {
        for (r in regions.regions) {
            rect.set(r.left * w, r.top * h, r.right * w, r.bottom * h)
            fill.color = 0x4D7CC4FF
            c.drawRect(rect, fill)
            stroke.color = 0xB37CC4FF.toInt()
            stroke.strokeWidth = dp(1.5f)
            c.drawRect(rect, stroke)
            text.color = 0xFFFFFFFF.toInt()
            text.textSize = dp(14f)
            text.typeface = Typeface.DEFAULT_BOLD
            c.drawText(label(r.name), rect.centerX(), rect.centerY() + dp(5f), text)
        }
    }

    // ---- debug overlay ---------------------------------------------------------------------------

    fun drawHud(c: Canvas, lines: List<String>, top: Float) {
        text.textAlign = Paint.Align.LEFT
        text.typeface = Typeface.MONOSPACE
        text.textSize = dp(10.5f)
        val lh = dp(13f)
        fill.color = 0xA6000000.toInt()
        var widest = 0f
        for (l in lines) widest = Math.max(widest, text.measureText(l))
        rect.set(dp(4f), top, dp(4f) + widest + dp(10f), top + lines.size * lh + dp(8f))
        c.drawRoundRect(rect, dp(6f), dp(6f), fill)
        text.color = 0xFF9BE9A8.toInt()
        var y = top + dp(4f) + lh - dp(3f)
        for (l in lines) {
            c.drawText(l, dp(9f), y, text)
            y += lh
        }
        text.textAlign = Paint.Align.CENTER
    }
}
