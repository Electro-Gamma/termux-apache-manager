// SPDX-License-Identifier: GPL-3.0-or-later
//
// Kotlin port of the input glue of Vento's SessionView.java (https://github.com/pgaskin/vento,
// (C) 2026 Patrick Gaskin): wires the input stack to one session.
package com.vncviewer.app.input

import android.content.Context
import android.os.SystemClock
import com.vncviewer.app.ui.KeyboardChrome
import kotlin.math.roundToInt

/**
 * Everything between "a finger touched the screen" and "a pointer event goes to the server":
 * viewport, cursor, gesture recognition, the mouse overlay, the toolbar, tap regions and a
 * physical mouse - all configured from [Config].
 */
class SessionInput(
    private val appContext: Context,
    private val host: Host
) : ZoomSink, CursorController.Listener, CursorController.PointerSink, RegionSink,
    MouseOverlay.Listener, Toolbar.Listener, PhysicalMouse.Listener,
    ExtensionKeyboard.Listener, KeySink {

    interface Host {
        fun sendPointer(x: Int, y: Int, buttons: Int)

        /** disconnect / information / keyboard / mouse; true if it was handled. */
        fun controlAction(name: String): Boolean

        fun invalidate()
        fun viewOnly(): Boolean
        fun keyboardVisible(): Boolean

        /** The desktop is being recorded to a video. */
        fun recording(): Boolean

        /** A key edge from the extension keyboard; the release is tied to its press by the caller. */
        fun sendKey(keysym: Int, down: Boolean)

        /** The extension keyboard's Paste key: type the phone's clipboard out. */
        fun pasteClipboard()

        /** Send the soft keyboard back to its letters (after a modifier was pressed). */
        fun restartIme()
    }

    val cfg: Config = InputSettings.config(appContext, appContext.resources.displayMetrics.density)
    val scheduler = AndroidScheduler()
    val viewport = Viewport(cfg.density)
    val cursor = CursorController(cfg, viewport, this, scheduler)
    val gestures = GestureRecognizer(cfg, cursor, this, scheduler)
    private val router = TouchRouter(gestures)
    val overlay = MouseOverlay(cfg, cursor.newButtonSource(), scheduler)
    val toolbar = Toolbar(cfg)

    /** Vento's extension keyboard (the Keys button), and the ink for it. */
    val keyboard = ExtensionKeyboard(cfg, this, scheduler, keyList(appContext))
    val keyboardChrome = KeyboardChrome(cfg)

    /** Haptics need a View, which the canvas has: it plugs itself in here. */
    var feedbackSink: ((ExtensionKeyboard.Feedback) -> Unit)? = null
    val mouse = PhysicalMouse(cfg, cursor.newButtonSource())
    val tapRegions = TapRegions.standard()

    /** Clicks from menus and keys run through a button source of their own. */
    val clickSource: MouseSink = cursor.newButtonSource()

    var lastRegion = "-"
    private var baseScale = 1.0f
    private var placed = false
    private var desktopKnown = false
    private val edges = IntArray(4)
    private var overlayWasVisible = false
    private var keyboardShown = false
    private val heldKeyIds = HashMap<Int, Int>()
    private val frame = Runnable { host.invalidate() }

    init {
        cursor.setListener(this)
        gestures.setRegions(tapRegions, this)
        router.addClaim(overlay)
        // The toolbar is a bar in the header's place and takes its own touches; the keyboard,
        // like the overlay, floats over the picture and claims its touches here.
        router.addClaim(keyboard)
        overlay.setListener(this)
        toolbar.setListener(this)
        mouse.setListener(this)
        // Before listening: measuring the row counts as a change to it.
        keyboardChrome.attach(keyboard)
        keyboard.setListener(this)
        applyControls()
    }

    // ---- settings ----------------------------------------------------------------------

    /** Pick up changed preferences; safe on a running session. */
    fun applySettings() {
        cfg.copyFrom(InputSettings.config(appContext, cfg.density))
        applyKeyList()
        applyControls()
        applyInsets()
        host.invalidate()
    }

    fun applyControls() {
        gestures.setRegions(if (AppSettings.regionsShown(appContext)) tapRegions else null, this)
        toolbar.setVisible(AppSettings.toolbarShown(appContext))
        syncToolbarState()
    }

    /** The soft keyboard opened or closed: the top-align condition may have changed. */
    fun imeVisibilityChanged() {
        applyInsets()
        syncToolbarState()
        host.invalidate()
    }

    fun syncToolbarState() {
        toolbar.setItems(
            if (host.viewOnly()) listOf(Toolbar.SCREENSHOT, Toolbar.RECORD, TapRegions.INFORMATION, TapRegions.DISCONNECT)
            else listOf(
                TapRegions.MOUSE, TapRegions.KEYBOARD, Toolbar.KEYS,
                Toolbar.CLIPBOARD, Toolbar.SCREENSHOT, Toolbar.RECORD, TapRegions.INFORMATION, TapRegions.DISCONNECT
            )
        )
        toolbar.setActive(TapRegions.MOUSE, overlay.visible())
        toolbar.setActive(TapRegions.KEYBOARD, host.keyboardVisible())
        toolbar.setActive(Toolbar.KEYS, keyboard.visible())
        toolbar.setActive(Toolbar.RECORD, host.recording())
    }

    /**
     * Which keys the extension row offers, from this phone's preferences: the one scrolling line,
     * or the two-line grouping, and either of them without the two modifiers that are only for a Mac.
     */
    private fun keyList(ctx: Context): List<ExtensionKeyboard.Key> {
        val keys = ArrayList(
            if (AppSettings.twoLineKeys(ctx)) ExtensionKeyboard.twoLineKeys()
            else ExtensionKeyboard.standardKeys()
        )
        if (!AppSettings.macKeys(ctx)) {
            keys.removeAll { "Option" == it.label() || "CMD" == it.label() }
        }
        return keys
    }

    /** Only when it differs: a swap lets go of every modifier held at the far end. */
    private fun applyKeyList() {
        val want = keyList(appContext)
        if (want == keyboard.allKeys()) return
        keyboard.setKeys(want)
    }

    // ---- geometry ----------------------------------------------------------------------

    fun setDesktopSize(w: Int, h: Int) {
        if (desktopKnown && viewport.desktopWidth() == w && viewport.desktopHeight() == h) return
        viewport.setDesktopSize(w, h)
        desktopKnown = true
        placed = false
        place()
    }

    fun onViewSize(w: Int, h: Int) {
        viewport.setViewSize(w, h)
        gestures.setViewSize(w, h)
        overlay.setViewSize(w, h)
        keyboard.setViewSize(w, h)
        place()
    }

    /** System bars, camera cutout: how far in from each window edge the desktop should be able to sit. */
    fun setWindowEdges(left: Int, top: Int, right: Int, bottom: Int) {
        if (edges[0] == left && edges[1] == top && edges[2] == right && edges[3] == bottom) return
        edges[0] = left; edges[1] = top; edges[2] = right; edges[3] = bottom
        applyInsets()
        host.invalidate()
    }

    private fun place() {
        if (viewport.viewWidth() == 0 || !desktopKnown) return
        if (!placed) {
            placed = true
            val w = viewport.desktopWidth().toFloat()
            val h = viewport.desktopHeight().toFloat()
            viewport.setFocus(w / 2, h / 2)
            viewport.centreOn(w / 2, h / 2, viewport.snapScale(1.0f))
            cursor.setPosition(w / 2, h / 2)
        } else {
            viewport.centreOn(cursor.x(), cursor.y(), viewport.snapScale(viewport.getScale()))
        }
        baseScale = viewport.getScale()
        host.invalidate()
    }

    private fun panMargin(edge: Int, inset: Int): Int =
        (if (cfg.panMarginInsets) Math.max(edge - inset, 0) else 0) + cfg.panMarginPx.toInt()

    private fun applyInsets() {
        // Only the Keys row insets the picture. The mouse controls are drawn over it and take
        // nothing from it, so opening or using them can never move, resize or zoom the desktop.
        val bottom = keyboard.insetBottomPx().toInt()
        viewport.setPanMargins(
            panMargin(edges[0], 0), panMargin(edges[1], 0),
            panMargin(edges[2], 0), panMargin(edges[3], bottom)
        )
        // Only when the soft keyboard is up together with the Keys row and/or the mouse buttons:
        // a desktop shorter than the view then sits at the top, in the black area, so those
        // controls never cover it. Any other combination leaves the desktop centred.
        viewport.setTopAlign(host.keyboardVisible() && (keyboard.visible() || overlay.visible()))
        cursor.setInsets(0, 0, 0, bottom)
        baseScale = viewport.getScale()
    }

    // ---- touch and mouse input ------------------------------------------------------------

    fun touchDown(id: Int, x: Float, y: Float, t: Long) = router.down(id, x, y, t)
    fun touchMove(id: Int, x: Float, y: Float, t: Long) = router.move(id, x, y, t)
    fun touchUp(id: Int, x: Float, y: Float, t: Long) = router.up(id, x, y, t)
    fun touchClaim(id: Int, x: Float, y: Float, t: Long): Boolean = router.claimDown(id, x, y, t)

    /** Abandon everything in flight (session hidden, app stopped). */
    fun suspendInput() {
        val now = SystemClock.uptimeMillis()
        router.cancel(now)
        gestures.cancelAll(now)
        keyboard.clearModifiers()
        mouse.cancel()
    }

    fun remoteCursorChanged() {
        gestures.remoteCursorChanged(SystemClock.uptimeMillis())
    }

    fun toggleOverlay() {
        overlay.toggle()
        syncToolbarState()
    }

    fun toggleKeys() {
        setKeyboardVisible(!keyboard.visible())
    }

    private fun setKeyboardVisible(show: Boolean) {
        if (show == keyboard.visible()) return
        // Everything else follows from the model changing, in keyboardChanged(): the model can
        // also hide itself, from its own close button.
        keyboard.setVisible(show)
    }

    /** Ask for another frame (a key's ripple is mid-flight). */
    fun requestFrame() {
        scheduler.postFrame(frame)
    }

    // ---- KeySink: the extension keyboard's keys go straight to the far end --------------------

    override fun keyDown(keysym: Int, keyId: Int) {
        heldKeyIds[keyId] = keysym
        host.sendKey(keysym, true)
    }

    override fun keyUp(keyId: Int) {
        val sym = heldKeyIds.remove(keyId) ?: return
        host.sendKey(sym, false)
    }

    /** A key from somewhere else (the soft keyboard, a real one): consumes one-shot modifiers. */
    fun externalKey(keysym: Int) {
        keyboard.externalKey(keysym)
    }

    // ---- ExtensionKeyboard.Listener ----------------------------------------------------------

    override fun keyboardChanged() {
        keyboardChrome.keyboardChanged(keyboard)
        if (keyboardShown != keyboard.visible()) {
            keyboardShown = keyboard.visible()
            applyInsets()
            syncToolbarState()
        }
        // The mouse controls stand on top of the Keys row when both are open.
        overlay.setBottomOffset(keyboard.heightPx())
        host.invalidate()
    }

    override fun keyFeedback(what: ExtensionKeyboard.Feedback) {
        feedbackSink?.invoke(what)
    }

    override fun keyAction(name: String) {
        if (ExtensionKeyboard.ACTION_PASTE == name) host.pasteClipboard()
    }

    override fun modifierPressed(key: ExtensionKeyboard.Key) {
        if (AppSettings.modifierResetsIme(appContext)) host.restartIme()
    }

    // ---- direct touch (absolute) --------------------------------------------------------------

    fun directMoveTo(sx: Float, sy: Float) {
        cursor.setPositionHere(viewport.toDesktopX(sx), viewport.toDesktopY(sy))
    }

    fun directZoom(factor: Float, cx: Float, cy: Float, panDx: Float, panDy: Float) {
        viewport.zoomAt(viewport.getScale() * factor, cx, cy)
        if (panDx != 0f || panDy != 0f) viewport.panBy(panDx, panDy)
        baseScale = viewport.getScale()
        host.invalidate()
    }

    // ---- ZoomSink ---------------------------------------------------------------------------

    override fun zoomBegan() {
        baseScale = viewport.getScale()
    }

    override fun zoomChanged(factor: Float) {
        viewport.setScale(baseScale * factor)
        if (cfg.recentreCursorOnZoom) cursor.centreCursor(true)
        host.invalidate()
    }

    override fun zoomPanned(screenDx: Float, screenDy: Float) {
        // The cursor owns the viewport position here; only a far-end-owned cursor pans freely.
    }

    override fun zoomEnded() {
        baseScale = viewport.getScale()
    }

    override fun scaleCentre(screenX: Float, screenY: Float) {
        viewport.setFocus(viewport.toDesktopX(screenX), viewport.toDesktopY(screenY))
    }

    // ---- CursorController.PointerSink / Listener ----------------------------------------------

    override fun pointerEvent(x: Float, y: Float, buttons: Int) {
        host.sendPointer(x.roundToInt(), y.roundToInt(), buttons)
    }

    override fun onCursorChanged() {
        host.invalidate()
    }

    /** A click is a key as far as the extension row is concerned: Ctrl+click is a chord too. */
    override fun onButtonsReleased() {
        keyboard.externalClick()
    }

    // ---- RegionSink / Toolbar / MouseOverlay / PhysicalMouse listeners -----------------------

    override fun regionTapped(region: TapRegions.Region, x: Float, y: Float): Boolean {
        lastRegion = region.name
        return host.controlAction(region.name)
    }

    override fun toolbarChanged() {
        host.invalidate()
    }

    override fun toolbarAction(name: String) {
        lastRegion = name
        host.controlAction(name)
    }

    override fun overlayChanged() {
        gestures.setExternalButtonHeld((overlay.heldMask() and Button.DRAG_MASK) != 0)
        if (overlay.visible() != overlayWasVisible) {
            overlayWasVisible = overlay.visible()
            applyInsets()
            syncToolbarState()
        }
        host.invalidate()
    }

    override fun mouseActivity() {
        host.invalidate()
    }

    // ---- debug overlay -------------------------------------------------------------------------

    fun hudLines(): List<String> {
        val now = SystemClock.uptimeMillis()
        val v = viewport
        val g = gestures
        return listOf(
            "cursor " + cursor.x().roundToInt() + "," + cursor.y().roundToInt() +
                "  buttons " + Button.maskName(cursor.buttons()),
            "sent " + cursor.eventCount() + "  dropped " + cursor.suppressedCount(),
            "view " + v.viewWidth() + "x" + v.viewHeight() + "  desktop " + v.desktopWidth() + "x" + v.desktopHeight(),
            "scale " + fmt(v.getScale()) + "  origin " + v.originX().roundToInt() + "," + v.originY().roundToInt(),
            "fingers " + g.downCount() + "  gesture " + g.mode().label + "  held " + (g.heldButton()?.name ?: "-"),
            "accel x" + fmt(g.accelFactor()) + "  speed " + fmt(g.accelSpeed()) + " px/ms  axis " + g.axisLock().label,
            "turn " + fmt(g.turnDegrees()) + " deg  glide " + fmt(g.glideSpeed().toFloat()),
            "hover x" + fmt(g.hoverGain()) + "  lag " + fmt(g.hoverLagMs()) + " ms" +
                (if (g.hoverLockedOut(now)) "  LOCKED" else ""),
            "overlay " + (if (overlay.visible()) "on" else "off") + "  scroll rate " + fmt(overlay.scrollRate()) +
                "  keys " + (if (keyboard.visible()) "on" else "off"),
            "mouse " + (if (mouse.seen()) "seen" else "none") + " held " + Button.maskName(mouse.heldMask()) +
                "  region " + lastRegion
        )
    }

    private fun fmt(f: Float): String = String.format(java.util.Locale.US, "%.2f", f)
}
