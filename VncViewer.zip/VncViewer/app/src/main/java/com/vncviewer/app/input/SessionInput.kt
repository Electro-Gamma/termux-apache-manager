// SPDX-License-Identifier: GPL-3.0-or-later
//
// Kotlin port of the input glue of Vento's SessionView.java (https://github.com/pgaskin/vento,
// (C) 2026 Patrick Gaskin): wires the input stack to one session.
package com.vncviewer.app.input

import android.content.Context
import android.os.SystemClock
import kotlin.math.roundToInt

/**
 * Everything between "a finger touched the screen" and "a pointer event goes to the server":
 * viewport, cursor, gesture recognition, the mouse overlay, the toolbar, tap regions and a
 * physical mouse - all configured from [Config].
 */
class SessionInput(
    private val appContext: Context,
    private val host: Host
) : ZoomSink, CursorController.Listener, CursorController.PointerSink, RegionSink,
    MouseOverlay.Listener, Toolbar.Listener, PhysicalMouse.Listener {

    interface Host {
        fun sendPointer(x: Int, y: Int, buttons: Int)

        /** disconnect / information / keyboard / mouse; true if it was handled. */
        fun controlAction(name: String): Boolean

        fun invalidate()
        fun viewOnly(): Boolean
        fun keyboardVisible(): Boolean
    }

    val cfg: Config = InputSettings.config(appContext, appContext.resources.displayMetrics.density)
    val scheduler = AndroidScheduler()
    val viewport = Viewport(cfg.density)
    val cursor = CursorController(cfg, viewport, this, scheduler)
    val gestures = GestureRecognizer(cfg, cursor, this, scheduler)
    private val router = TouchRouter(gestures)
    val overlay = MouseOverlay(cfg, cursor.newButtonSource(), scheduler)
    val toolbar = Toolbar(cfg)
    val mouse = PhysicalMouse(cfg, cursor.newButtonSource())
    val tapRegions = TapRegions.standard()

    /** Clicks from menus and keys run through a button source of their own. */
    val clickSource: MouseSink = cursor.newButtonSource()

    var lastRegion = "-"
    private var baseScale = 1.0f
    private var placed = false
    private var desktopKnown = false
    private val edges = IntArray(4)
    private var overlayWasVisible = false

    init {
        cursor.setListener(this)
        gestures.setRegions(tapRegions, this)
        router.addClaim(overlay)
        router.addClaim(toolbar)
        overlay.setListener(this)
        toolbar.setListener(this)
        mouse.setListener(this)
        toolbar.setPosition(AppSettings.toolbarPosition(appContext))
        applyControls()
    }

    // ---- settings ----------------------------------------------------------------------

    /** Pick up changed preferences; safe on a running session. */
    fun applySettings() {
        cfg.copyFrom(InputSettings.config(appContext, cfg.density))
        applyControls()
        applyInsets()
        host.invalidate()
    }

    fun applyControls() {
        gestures.setRegions(if (AppSettings.regionsShown(appContext)) tapRegions else null, this)
        toolbar.setVisible(AppSettings.toolbarShown(appContext))
        syncToolbarState()
    }

    fun syncToolbarState() {
        toolbar.setItems(
            if (host.viewOnly()) listOf(TapRegions.DISCONNECT, TapRegions.INFORMATION)
            else listOf(TapRegions.DISCONNECT, TapRegions.INFORMATION, TapRegions.KEYBOARD, TapRegions.MOUSE)
        )
        toolbar.setActive(TapRegions.MOUSE, overlay.visible())
        toolbar.setActive(TapRegions.KEYBOARD, host.keyboardVisible())
    }

    // ---- geometry ----------------------------------------------------------------------

    fun setDesktopSize(w: Int, h: Int) {
        if (desktopKnown && viewport.desktopWidth() == w && viewport.desktopHeight() == h) return
        viewport.setDesktopSize(w, h)
        desktopKnown = true
        placed = false
        place()
    }

    fun onViewSize(w: Int, h: Int) {
        viewport.setViewSize(w, h)
        gestures.setViewSize(w, h)
        overlay.setViewSize(w, h)
        toolbar.setViewSize(w, h)
        place()
    }

    /** System bars, camera cutout: how far in from each window edge the desktop should be able to sit. */
    fun setWindowEdges(left: Int, top: Int, right: Int, bottom: Int) {
        if (edges[0] == left && edges[1] == top && edges[2] == right && edges[3] == bottom) return
        edges[0] = left; edges[1] = top; edges[2] = right; edges[3] = bottom
        applyInsets()
        host.invalidate()
    }

    private fun place() {
        if (viewport.viewWidth() == 0 || !desktopKnown) return
        if (!placed) {
            placed = true
            val w = viewport.desktopWidth().toFloat()
            val h = viewport.desktopHeight().toFloat()
            viewport.setFocus(w / 2, h / 2)
            viewport.centreOn(w / 2, h / 2, viewport.snapScale(1.0f))
            cursor.setPosition(w / 2, h / 2)
        } else {
            viewport.centreOn(cursor.x(), cursor.y(), viewport.snapScale(viewport.getScale()))
        }
        baseScale = viewport.getScale()
        host.invalidate()
    }

    private fun panMargin(edge: Int, inset: Int): Int =
        (if (cfg.panMarginInsets) Math.max(edge - inset, 0) else 0) + cfg.panMarginPx.toInt()

    private fun applyInsets() {
        val right = overlay.insetRightPx().toInt()
        val bottom = overlay.insetBottomPx().toInt()
        viewport.setPanMargins(
            panMargin(edges[0], 0), panMargin(edges[1], 0),
            panMargin(edges[2], right), panMargin(edges[3], bottom)
        )
        cursor.setInsets(0, 0, right, bottom)
        toolbar.setInsets(0f, edges[1].toFloat(), edges[3].toFloat())
        baseScale = viewport.getScale()
    }

    // ---- touch and mouse input ------------------------------------------------------------

    fun touchDown(id: Int, x: Float, y: Float, t: Long) = router.down(id, x, y, t)
    fun touchMove(id: Int, x: Float, y: Float, t: Long) = router.move(id, x, y, t)
    fun touchUp(id: Int, x: Float, y: Float, t: Long) = router.up(id, x, y, t)

    /** Abandon everything in flight (session hidden, app stopped). */
    fun suspendInput() {
        val now = SystemClock.uptimeMillis()
        router.cancel(now)
        gestures.cancelAll(now)
        mouse.cancel()
    }

    fun remoteCursorChanged() {
        gestures.remoteCursorChanged(SystemClock.uptimeMillis())
    }

    fun toggleOverlay() {
        overlay.toggle()
        syncToolbarState()
    }

    // ---- direct touch (absolute) --------------------------------------------------------------

    fun directMoveTo(sx: Float, sy: Float) {
        cursor.setPositionHere(viewport.toDesktopX(sx), viewport.toDesktopY(sy))
    }

    fun directZoom(factor: Float, cx: Float, cy: Float, panDx: Float, panDy: Float) {
        viewport.zoomAt(viewport.getScale() * factor, cx, cy)
        if (panDx != 0f || panDy != 0f) viewport.panBy(panDx, panDy)
        baseScale = viewport.getScale()
        host.invalidate()
    }

    // ---- ZoomSink ---------------------------------------------------------------------------

    override fun zoomBegan() {
        baseScale = viewport.getScale()
    }

    override fun zoomChanged(factor: Float) {
        viewport.setScale(baseScale * factor)
        if (cfg.recentreCursorOnZoom) cursor.centreCursor(true)
        host.invalidate()
    }

    override fun zoomPanned(screenDx: Float, screenDy: Float) {
        // The cursor owns the viewport position here; only a far-end-owned cursor pans freely.
    }

    override fun zoomEnded() {
        baseScale = viewport.getScale()
    }

    override fun scaleCentre(screenX: Float, screenY: Float) {
        viewport.setFocus(viewport.toDesktopX(screenX), viewport.toDesktopY(screenY))
    }

    // ---- CursorController.PointerSink / Listener ----------------------------------------------

    override fun pointerEvent(x: Float, y: Float, buttons: Int) {
        host.sendPointer(x.roundToInt(), y.roundToInt(), buttons)
    }

    override fun onCursorChanged() {
        host.invalidate()
    }

    // ---- RegionSink / Toolbar / MouseOverlay / PhysicalMouse listeners -----------------------

    override fun regionTapped(region: TapRegions.Region, x: Float, y: Float): Boolean {
        lastRegion = region.name
        return host.controlAction(region.name)
    }

    override fun toolbarChanged() {
        host.invalidate()
    }

    override fun toolbarAction(name: String) {
        lastRegion = name
        host.controlAction(name)
    }

    override fun toolbarMoved(fraction: Float) {
        AppSettings.setToolbarPosition(appContext, fraction)
    }

    override fun overlayChanged() {
        gestures.setExternalButtonHeld((overlay.heldMask() and Button.DRAG_MASK) != 0)
        if (overlay.visible() != overlayWasVisible) {
            overlayWasVisible = overlay.visible()
            applyInsets()
            syncToolbarState()
        }
        host.invalidate()
    }

    override fun mouseActivity() {
        host.invalidate()
    }

    // ---- debug overlay -------------------------------------------------------------------------

    fun hudLines(): List<String> {
        val now = SystemClock.uptimeMillis()
        val v = viewport
        val g = gestures
        return listOf(
            "cursor " + cursor.x().roundToInt() + "," + cursor.y().roundToInt() +
                "  buttons " + Button.maskName(cursor.buttons()),
            "sent " + cursor.eventCount() + "  dropped " + cursor.suppressedCount(),
            "view " + v.viewWidth() + "x" + v.viewHeight() + "  desktop " + v.desktopWidth() + "x" + v.desktopHeight(),
            "scale " + fmt(v.getScale()) + "  origin " + v.originX().roundToInt() + "," + v.originY().roundToInt(),
            "fingers " + g.downCount() + "  gesture " + g.mode().label + "  held " + (g.heldButton()?.name ?: "-"),
            "accel x" + fmt(g.accelFactor()) + "  speed " + fmt(g.accelSpeed()) + " px/ms  axis " + g.axisLock().label,
            "turn " + fmt(g.turnDegrees()) + " deg  glide " + fmt(g.glideSpeed().toFloat()),
            "hover x" + fmt(g.hoverGain()) + "  lag " + fmt(g.hoverLagMs()) + " ms" +
                (if (g.hoverLockedOut(now)) "  LOCKED" else ""),
            "overlay " + (if (overlay.visible()) "on" else "off") + "  scroll rate " + fmt(overlay.scrollRate()) +
                "  toolbar " + fmt(toolbar.position()),
            "mouse " + (if (mouse.seen()) "seen" else "none") + " held " + Button.maskName(mouse.heldMask()) +
                "  region " + lastRegion
        )
    }

    private fun fmt(f: Float): String = String.format(java.util.Locale.US, "%.2f", f)
}
