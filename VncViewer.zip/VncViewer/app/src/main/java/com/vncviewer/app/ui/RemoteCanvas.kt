package com.vncviewer.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.layout.fillMaxSize
import android.os.Build
import android.view.HapticFeedbackConstants
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.PointerInputScope
import androidx.compose.ui.input.pointer.PointerType
import androidx.compose.ui.input.pointer.isBackPressed
import androidx.compose.ui.input.pointer.isForwardPressed
import androidx.compose.ui.input.pointer.isPrimaryPressed
import androidx.compose.ui.input.pointer.isSecondaryPressed
import androidx.compose.ui.input.pointer.isTertiaryPressed
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.vncviewer.app.input.AppSettings
import com.vncviewer.app.input.Button
import com.vncviewer.app.input.ExtensionKeyboard
import com.vncviewer.app.input.TapRegions
import com.vncviewer.app.session.MouseMode
import com.vncviewer.app.session.VncSession
import kotlin.math.abs
import kotlin.math.ln

private const val OUT_LONG = 0
private const val OUT_MOVED = 1
private const val OUT_RELEASED = 2
private const val OUT_MULTI = 3

/**
 * Draws the remote desktop through the session's viewport and feeds touches / a physical mouse
 * to the input stack.
 *
 * Touchpad mode (Vento's): one finger moves the cursor (acceleration, axis lock, momentum, edge
 * scrolling), a tap clicks (tap-then-drag drags), two/three-finger taps right/middle-click, two
 * fingers scroll or pinch-zoom. Direct touch mode: the finger is the pointer.
 */
@Composable
fun RemoteCanvas(session: VncSession, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val haptics = LocalHapticFeedback.current
    val density = ctx.resources.displayMetrics.density
    val paint = remember { android.graphics.Paint() }
    val srcRect = remember { android.graphics.Rect() }
    val dstRect = remember { android.graphics.RectF() }
    val cursorRect = remember { android.graphics.RectF() }
    val cursorPaint = remember { android.graphics.Paint() }
    val slots = remember { PointerSlots() }
    val chrome = remember { ChromeDraw(density) }

    // The extension keyboard's haptics, which need this view.
    DisposableEffect(session) {
        session.input.feedbackSink = { what ->
            val kind = when (what) {
                ExtensionKeyboard.Feedback.LOCK -> HapticFeedbackConstants.LONG_PRESS
                ExtensionKeyboard.Feedback.PRESS -> HapticFeedbackConstants.KEYBOARD_TAP
                else -> if (Build.VERSION.SDK_INT >= 34) HapticFeedbackConstants.SEGMENT_FREQUENT_TICK else -1
            }
            if (kind >= 0) view.performHapticFeedback(kind)
        }
        onDispose { session.input.feedbackSink = null }
    }

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
            .onSizeChanged { size -> session.onViewSize(size.width, size.height) }
            .onGloballyPositioned { coords ->
                // How far the desktop view sits in from each window edge matters only for the
                // "pan margin (display)" setting: system bars and the camera cutout.
                val ins = ViewCompat.getRootWindowInsets(view)?.getInsetsIgnoringVisibility(
                    WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
                )
                if (ins != null) {
                    val r = coords.boundsInWindow()
                    val l = Math.max(0, ins.left - r.left.toInt())
                    val t = Math.max(0, ins.top - r.top.toInt())
                    val rr = Math.max(0, ins.right - (view.width - r.right.toInt()))
                    val b = Math.max(0, ins.bottom - (view.height - r.bottom.toInt()))
                    session.input.setWindowEdges(l, t, rr, b)
                }
                val imeNow = ViewCompat.getRootWindowInsets(view)
                    ?.isVisible(WindowInsetsCompat.Type.ime()) == true
                if (session.imeVisible != imeNow) {
                    session.imeVisible = imeNow
                    session.input.syncToolbarState()
                }
            }
            .pointerInput(session, session.mouseMode) {
                if (session.mouseMode == MouseMode.TOUCHPAD) {
                    stackTouch(session, slots)
                } else {
                    directGestures(session, slots) {
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                    }
                }
            }
            .pointerInput(session) {
                mouseGestures(session)
            }
    ) {
        // Reading the ticks subscribes this draw block to new frames and to input changes.
        val tick = session.frameTick
        val itick = session.inputTick
        val input = session.input
        val bmp = session.bitmap
        if (bmp != null && session.fbWidth > 0 && tick >= 0 && itick >= 0) {
            val v = input.viewport
            val sc = v.getScale()
            val left = v.originX()
            val top = v.originY()
            drawIntoCanvas { canvas ->
                srcRect.set(0, 0, bmp.width, bmp.height)
                dstRect.set(left, top, left + bmp.width * sc, top + bmp.height * sc)
                paint.isFilterBitmap = sc < 3f
                canvas.nativeCanvas.drawBitmap(bmp, srcRect, dstRect, paint)
            }

            val d = 1.dp.toPx()
            val cx = input.cursor.screenX()
            val cy = input.cursor.screenY()
            val cursor = session.remoteCursor
            val held = input.cursor.buttons()
            if (cursor != null && !session.viewOnly) {
                // The server's cursor shape, drawn at the pointer exactly as Vento does: scaled by
                // the screen density (not by the desktop zoom) and capped at 32 logical pixels.
                val longest = Math.max(cursor.width, cursor.height)
                val base = if (density < 1f) 1f else density
                val cs = if (longest > 32) base * 32f / longest else base
                val hx = session.cursorHotX * cs
                val hy = session.cursorHotY * cs
                drawIntoCanvas { canvas ->
                    cursorRect.set(cx - hx, cy - hy, cx - hx + cursor.width * cs, cy - hy + cursor.height * cs)
                    cursorPaint.isFilterBitmap = true
                    canvas.nativeCanvas.drawBitmap(cursor, null, cursorRect, cursorPaint)
                }
            } else if (session.mouseMode == MouseMode.TOUCHPAD && !session.viewOnly) {
                val path = Path()
                path.moveTo(0f, 0f)
                path.lineTo(0f, 17f * d)
                path.lineTo(4.2f * d, 13.4f * d)
                path.lineTo(7.4f * d, 20.5f * d)
                path.lineTo(10.2f * d, 19.2f * d)
                path.lineTo(7f * d, 12.4f * d)
                path.lineTo(12f * d, 12.4f * d)
                path.close()
                val fill = if ((held and Button.LEFT.mask) != 0) Color(0xFF7CC4FF) else Color.White
                translate(left = cx, top = cy) {
                    drawPath(path, Color.Black, style = Stroke(width = 2.4f * d))
                    drawPath(path, fill)
                }
            } else if (held != 0 && !session.viewOnly) {
                drawCircle(color = Color(0x887CC4FF), radius = 18f * d, center = Offset(cx, cy))
            }

            drawIntoCanvas { canvas ->
                val nc = canvas.nativeCanvas
                if (input.overlay.visible()) chrome.drawOverlay(nc, input.overlay)
                if (input.keyboard.visible() &&
                    input.keyboardChrome.drawKeyboard(nc, input.keyboard, size.width.toInt(), input.cursor.screenY())
                ) {
                    input.requestFrame()
                }
                if (session.showHints && AppSettings.regionsShown(ctx)) {
                    chrome.drawRegionHints(nc, input.tapRegions, size.width.toInt(), size.height.toInt()) { name ->
                        when (name) {
                            TapRegions.DISCONNECT -> "Disconnect"
                            TapRegions.INFORMATION -> "Connection info"
                            TapRegions.KEYBOARD -> "Keyboard"
                            else -> "Mouse"
                        }
                    }
                }
                if (AppSettings.hud(ctx)) chrome.drawHud(nc, input.hudLines(), 4f * d)
            }
        }
    }
}

/** Touchpad mode: every finger goes to the input stack (on-screen controls get first pick). */
private suspend fun PointerInputScope.stackTouch(session: VncSession, slots: PointerSlots) {
    val input = session.input
    awaitPointerEventScope {
        try {
            while (true) {
                val ev = awaitPointerEvent()
                for (ch in ev.changes) {
                    if (ch.type == PointerType.Mouse) continue
                    val t = ch.uptimeMillis
                    if (ch.pressed && !ch.previousPressed) {
                        val id = slots.acquire(ch.id.value)
                        input.touchDown(id, ch.position.x, ch.position.y, t)
                        ch.consume()
                    } else if (!ch.pressed && ch.previousPressed) {
                        val id = slots.release(ch.id.value)
                        if (id >= 0) input.touchUp(id, ch.position.x, ch.position.y, t)
                        ch.consume()
                    } else if (ch.pressed && ch.position != ch.previousPosition) {
                        val id = slots.find(ch.id.value)
                        if (id >= 0) input.touchMove(id, ch.position.x, ch.position.y, t)
                        ch.consume()
                    }
                }
            }
        } finally {
            slots.clear()
            input.suspendInput()
        }
    }
}

/**
 * Compose numbers pointers with an ever-growing counter, but the ported input stack (like Vento's,
 * which got Android's small dense ids) only tracks ids 0..63 - so after ~64 touches the toolbar and
 * the mouse overlay stopped receiving anything. This maps each live finger to a small free slot.
 */
internal class PointerSlots {
    private val live = LongArray(16) { -1L }

    fun acquire(composeId: Long): Int {
        val have = find(composeId)
        if (have >= 0) return have
        for (i in live.indices) if (live[i] < 0) { live[i] = composeId; return i }
        live[live.size - 1] = composeId
        return live.size - 1
    }

    fun find(composeId: Long): Int {
        for (i in live.indices) if (live[i] == composeId) return i
        return -1
    }

    fun release(composeId: Long): Int {
        val i = find(composeId)
        if (i >= 0) live[i] = -1L
        return i
    }

    fun clear() = live.fill(-1L)
}

private fun countPressed(changes: List<androidx.compose.ui.input.pointer.PointerInputChange>): Int {
    var n = 0
    for (c in changes) if (c.pressed) n++
    return n
}

/** Direct touch mode: tap = click there, long-press = right click, drag = left drag. */
private suspend fun PointerInputScope.directGestures(session: VncSession, slots: PointerSlots, haptic: () -> Unit) {
    val slop = viewConfiguration.touchSlop
    val longPressMs = viewConfiguration.longPressTimeoutMillis
    val cfg = session.input.cfg

    awaitEachGesture {
        val down = awaitFirstDown(requireUnconsumed = false)
        if (down.type == PointerType.Mouse) return@awaitEachGesture

        // The toolbar and the mouse buttons/wheel strip get first pick here too, as in touchpad mode.
        val slot = slots.acquire(down.id.value)
        if (session.input.touchClaim(slot, down.position.x, down.position.y, down.uptimeMillis)) {
            down.consume()
            try {
                while (true) {
                    val ev = awaitPointerEvent()
                    val c = ev.changes.firstOrNull { it.id == down.id } ?: break
                    if (!c.pressed) {
                        session.input.touchUp(slot, c.position.x, c.position.y, c.uptimeMillis)
                        c.consume()
                        break
                    }
                    if (c.position != c.previousPosition) {
                        session.input.touchMove(slot, c.position.x, c.position.y, c.uptimeMillis)
                    }
                    c.consume()
                }
            } finally {
                slots.release(down.id.value)
            }
            return@awaitEachGesture
        }
        slots.release(down.id.value)

        val startPos = down.position
        val primaryId = down.id
        val panOnly = session.viewOnly || session.panDragMode

        val waited: Int? = withTimeoutOrNull(longPressMs) {
            var res = OUT_LONG
            while (true) {
                val ev = awaitPointerEvent()
                if (countPressed(ev.changes) >= 2) {
                    res = OUT_MULTI
                    break
                }
                val c = ev.changes.firstOrNull { it.id == primaryId }
                if (c == null || !c.pressed) {
                    res = OUT_RELEASED
                    break
                }
                if ((c.position - startPos).getDistance() > slop) {
                    res = OUT_MOVED
                    break
                }
            }
            res
        }
        val outcome = waited ?: OUT_LONG
        var goMulti = outcome == OUT_MULTI

        if (outcome == OUT_RELEASED) {
            if (!panOnly) {
                session.pointerToScreen(startPos.x, startPos.y)
                session.click(1)
            }
            return@awaitEachGesture
        }

        if (outcome == OUT_LONG) {
            if (!panOnly) {
                haptic()
                session.pointerToScreen(startPos.x, startPos.y)
                session.click(4)
            }
            while (true) {
                val ev = awaitPointerEvent()
                if (countPressed(ev.changes) == 0) break
                ev.changes.forEach { it.consume() }
            }
            return@awaitEachGesture
        }

        if (outcome == OUT_MOVED) {
            var last = startPos
            var dragging = false
            try {
                if (!panOnly) {
                    session.pointerToScreen(startPos.x, startPos.y)
                    session.buttonDown(1)
                    dragging = true
                }
                while (true) {
                    val ev = awaitPointerEvent()
                    val pressed = countPressed(ev.changes)
                    if (pressed == 0) break
                    if (pressed >= 2) {
                        goMulti = true
                        break
                    }
                    val c = ev.changes.firstOrNull { it.id == primaryId } ?: break
                    if (!c.pressed) break
                    val dx = c.position.x - last.x
                    val dy = c.position.y - last.y
                    last = c.position
                    if (panOnly) session.panBy(dx, dy) else session.pointerToScreen(c.position.x, c.position.y)
                    c.consume()
                }
            } finally {
                if (dragging) session.buttonUp(1)
            }
            if (!goMulti) return@awaitEachGesture
        }

        // Two or more fingers: pinch-zoom, scroll, or (a quick tap) right-click.
        val multiStart = System.currentTimeMillis()
        var totalZoom = 1f
        var totalPan = Offset.Zero
        var mode = 0
        var wheelAcc = 0f
        var firstCentroid: Offset? = null
        val sign = if (cfg.naturalScrolling) -1f else 1f
        while (true) {
            val ev = awaitPointerEvent()
            val pressed = countPressed(ev.changes)
            if (pressed == 0) break
            if (pressed >= 2) {
                val centroid = ev.calculateCentroid(useCurrent = true)
                if (firstCentroid == null) firstCentroid = centroid
                val z = ev.calculateZoom()
                val p = ev.calculatePan()
                totalZoom *= z
                totalPan += p
                if (mode == 0) {
                    if (abs(ln(totalZoom)) > 0.07f) {
                        mode = 1
                    } else if (totalPan.getDistance() > slop * 1.5f) {
                        mode = 2
                        if (!panOnly) session.pointerToScreen(centroid.x, centroid.y)
                    }
                }
                if (mode == 1) {
                    session.zoomBy(z, centroid.x, centroid.y, p.x, p.y)
                } else if (mode == 2) {
                    if (panOnly) {
                        session.panBy(p.x, p.y)
                    } else {
                        wheelAcc += p.y * sign
                        while (wheelAcc >= cfg.wheelStepPx) {
                            session.wheel(true)
                            wheelAcc -= cfg.wheelStepPx
                        }
                        while (wheelAcc <= -cfg.wheelStepPx) {
                            session.wheel(false)
                            wheelAcc += cfg.wheelStepPx
                        }
                    }
                }
                ev.changes.forEach { it.consume() }
            }
        }
        if (mode == 0 && !panOnly) {
            val elapsed = System.currentTimeMillis() - multiStart
            if (elapsed < 450 && totalPan.getDistance() < slop * 2f) {
                val c = firstCentroid
                if (c != null) session.pointerToScreen(c.x, c.y)
                session.click(4)
            }
        }
    }
}

/**
 * A physical mouse (USB / Bluetooth / DeX) while its pointer is not captured: motion derived
 * from the local pointer, three buttons plus back/forward, and the wheel. (When the pointer is
 * captured, relative events arrive through [KeyCaptureView] instead.)
 */
private suspend fun PointerInputScope.mouseGestures(session: VncSession) {
    val mouse = session.input.mouse
    awaitPointerEventScope {
        try {
            while (true) {
                val ev = awaitPointerEvent()
                val ch = ev.changes.firstOrNull { it.type == PointerType.Mouse } ?: continue
                when (ev.type) {
                    PointerEventType.Scroll -> {
                        mouse.scroll(ch.scrollDelta.x, -ch.scrollDelta.y)
                        ch.consume()
                    }
                    PointerEventType.Exit -> mouse.leave()
                    else -> {
                        mouse.moveTo(ch.position.x, ch.position.y)
                        val b = ev.buttons
                        var mask = 0
                        if (b.isPrimaryPressed) mask = mask or 1
                        if (b.isSecondaryPressed) mask = mask or 2
                        if (b.isTertiaryPressed) mask = mask or 4
                        if (b.isBackPressed) mask = mask or 8
                        if (b.isForwardPressed) mask = mask or 16
                        mouse.buttonState(mask)
                    }
                }
            }
        } finally {
            mouse.cancel()
        }
    }
}
