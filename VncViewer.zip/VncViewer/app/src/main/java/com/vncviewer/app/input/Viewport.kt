// SPDX-License-Identifier: MIT
//
// Kotlin port of Vento's Viewport.java (https://github.com/pgaskin/vento, control/ module,
// (C) 2026 Patrick Gaskin, MIT). The zoom ladder is omitted; zoomAt() is this app's addition
// for pinching about the fingers in direct-touch mode.
package com.vncviewer.app.input

/** Where the desktop is on screen: a scale, an origin, and a focus kept inside sensible bounds. */
class Viewport(density: Float) {
    private val density: Float = Math.max(density, 1.0f)
    private var fbW = 1
    private var fbH = 1
    private var viewW = 0
    private var viewH = 0
    private var insetL = 0
    private var insetT = 0
    private var insetR = 0
    private var insetB = 0
    private var marginL = 0
    private var marginT = 0
    private var marginR = 0
    private var marginB = 0
    private var scale = 1.0f
    private var originX = 0f
    private var originY = 0f
    private var focusX = 0f
    private var focusY = 0f
    private var topAlign = false

    /**
     * Rest a desktop that is shorter than the view against the top edge instead of centring it,
     * so controls drawn over the bottom (Keys row, mouse buttons) have the black space below.
     */
    fun setTopAlign(on: Boolean) {
        if (on == topAlign) return
        topAlign = on
        centreOn(focusX, focusY)
    }

    fun setDesktopSize(w: Int, h: Int) {
        fbW = Math.max(w, 1)
        fbH = Math.max(h, 1)
    }

    fun setViewSize(w: Int, h: Int) {
        viewW = w
        viewH = h
    }

    fun setInsets(left: Int, top: Int, right: Int, bottom: Int) {
        insetL = Math.max(left, 0)
        insetT = Math.max(top, 0)
        insetR = Math.max(right, 0)
        insetB = Math.max(bottom, 0)
    }

    /** Let a pan carry each edge of the desktop in by this much (rounded corners, cutouts, bars). */
    fun setPanMargins(left: Int, top: Int, right: Int, bottom: Int) {
        val l = Math.max(left, 0)
        val t = Math.max(top, 0)
        val r = Math.max(right, 0)
        val b = Math.max(bottom, 0)
        if (l == marginL && t == marginT && r == marginR && b == marginB) return
        marginL = l; marginT = t; marginR = r; marginB = b
        centreOn(focusX, focusY)
    }

    fun contentWidth(): Int = Math.max(viewW - insetL - insetR, 0)
    fun contentHeight(): Int = Math.max(viewH - insetT - insetB, 0)
    fun centreScreenX(): Float = insetL + contentWidth() / 2.0f
    fun centreScreenY(): Float = insetT + contentHeight() / 2.0f
    fun desktopWidth(): Int = fbW
    fun desktopHeight(): Int = fbH
    fun viewWidth(): Int = viewW
    fun viewHeight(): Int = viewH
    fun getScale(): Float = scale
    fun originX(): Float = originX
    fun originY(): Float = originY
    fun focusX(): Float = focusX
    fun focusY(): Float = focusY

    fun toScreenX(dx: Float): Float = dx * scale + originX
    fun toScreenY(dy: Float): Float = dy * scale + originY
    fun toDesktopX(sx: Float): Float = (sx - originX) / scale
    fun toDesktopY(sy: Float): Float = (sy - originY) / scale

    fun setFocus(dx: Float, dy: Float) {
        focusX = dx
        focusY = dy
    }

    /** The scale at which the whole desktop is visible. */
    fun minScale(): Float {
        if (contentWidth() == 0 || contentHeight() == 0) return 1.0f
        return Math.min(contentWidth().toFloat() / fbW, contentHeight().toFloat() / fbH)
    }

    fun fillScale(): Float {
        if (contentWidth() == 0 || contentHeight() == 0) return 1.0f
        return Math.max(contentWidth().toFloat() / fbW, contentHeight().toFloat() / fbH)
    }

    fun maxScale(): Float = 2.0f * Math.floor(density.toDouble()).toFloat()

    /** Quantise, and snap to the natural sizes (1:1, 2:1.., fit width, fit height) when near. */
    fun snapScale(s: Float): Float {
        var q = (s * 128.0f).toInt() / 128.0f
        val w = fbW * q
        val steps = Math.floor(density.toDouble()).toInt()
        for (k in 1..steps) q = snapTo(q, w, (fbW * k).toFloat())
        if (contentWidth() > 0 && contentHeight() > 0) {
            q = snapTo(q, w, contentWidth().toFloat())
            q = snapTo(q, w, fbW * (contentHeight().toFloat() / fbH))
        }
        return clamp(q, minScale(), maxScale())
    }

    private fun snapTo(q: Float, w: Float, candidateW: Float): Float {
        if (candidateW > 0 && Math.abs(w - candidateW) <= 0.04f * candidateW) return candidateW / fbW
        return q
    }

    fun setScale(s: Float) {
        centreOn(focusX, focusY, snapScale(s))
    }

    fun centreOn(dx: Float, dy: Float) {
        centreOn(dx, dy, scale)
    }

    fun centreOn(dx: Float, dy: Float, s: Float) {
        val cw = contentWidth()
        val ch = contentHeight()
        if (cw == 0 || ch == 0) {
            scale = s
            return
        }
        scale = s
        val ox = centreScreenX() - dx * s
        val oy = centreScreenY() - dy * s
        place(ox, oy)
        focusX = toDesktopX(centreScreenX())
        focusY = toDesktopY(centreScreenY())
    }

    private fun place(ox: Float, oy: Float) {
        val dw = fbW * scale
        val dh = fbH * scale
        originX = clampAxis(ox, insetL, contentWidth(), dw, (viewW - dw) / 2.0f, marginL, marginR)
        originY = clampAxis(
            oy, insetT, contentHeight(), dh,
            if (topAlign) insetT.toFloat() else (viewH - dh) / 2.0f, marginT, marginB
        )
    }

    private fun clampAxis(
        o: Float, inset: Int, content: Int, desktop: Float, centred: Float, marginLo: Int, marginHi: Int
    ): Float {
        val mLo = Math.min(marginLo.toFloat(), content / 2.0f)
        val mHi = Math.min(marginHi.toFloat(), content / 2.0f)
        val lo: Float
        val hi: Float
        if (desktop < content) {
            // Smaller than the window: it rests centred, and a margin lets it be pushed
            // towards either edge by what that edge costs.
            val rest = clamp(centred, inset.toFloat(), inset + content - desktop)
            val blankLo = rest - inset
            val blankHi = inset + content - desktop - rest
            lo = rest - Math.max(mHi - blankHi, 0.0f)
            hi = rest + Math.max(mLo - blankLo, 0.0f)
        } else {
            lo = inset + content - desktop - mHi
            hi = inset + mLo
        }
        return clamp(o, lo, hi)
    }

    fun panBy(screenDx: Float, screenDy: Float) {
        centreOn(focusX - screenDx / scale, focusY - screenDy / scale)
    }

    /** Zoom so the desktop point under (sx, sy) stays under it (direct-touch pinch). */
    fun zoomAt(newScale: Float, sx: Float, sy: Float) {
        if (contentWidth() == 0 || contentHeight() == 0) {
            scale = newScale
            return
        }
        val dx = toDesktopX(sx)
        val dy = toDesktopY(sy)
        scale = clamp(newScale, minScale(), maxScale())
        place(sx - dx * scale, sy - dy * scale)
        focusX = toDesktopX(centreScreenX())
        focusY = toDesktopY(centreScreenY())
    }

    fun zoomToFit() {
        setScale(minScale())
    }

    fun zoomToFill() {
        setScale(Math.min(fillScale(), Math.floor(density.toDouble()).toFloat()))
    }

    companion object {
        fun clamp(v: Float, lo: Float, hi: Float): Float = if (v < lo) lo else if (v > hi) hi else v
    }
}
