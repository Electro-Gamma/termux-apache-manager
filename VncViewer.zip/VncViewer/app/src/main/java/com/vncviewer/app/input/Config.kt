// SPDX-License-Identifier: MIT
//
// Kotlin port of Vento's input stack (https://github.com/pgaskin/vento, control/ module,
// (C) 2026 Patrick Gaskin, MIT): Config.java. Defaults are the values reverse-engineered
// from RealVNC Viewer 4.9.1.60165, plus Vento's deliberate improvements ("improved").
package com.vncviewer.app.input

import java.lang.reflect.Modifier

/** Every tunable of the input stack, in one place. */
class Config(@JvmField val density: Float) {

    fun dp(v: Float): Float = v * density

    // ---- tap vs. drag ----
    @JvmField var moveThresholdPx: Float = dp(12f)
    @JvmField var tapPathThresholdPx: Float = 0f
    @JvmField var moveCountTest: Boolean = false
    @JvmField var moveCountLimit: Int = 10
    @JvmField var tapMaxDurationMs: Long = 0

    // ---- clicks ----
    @JvmField var clickHoldMs: Long = 250
    @JvmField var flickMinDistPx: Float = 2.0f

    // ---- bump scroll (edge auto-repeat during a tap-then-drag) ----
    @JvmField var bumpScrollEnabled: Boolean = true
    @JvmField var bumpBorderPx: Float = dp(24f)
    @JvmField var bumpDeltaPx: Float = dp(12f)
    @JvmField var bumpPeriodMs: Long = 100
    @JvmField var bumpStopOutsideBorder: Boolean = true

    // ---- two-finger ----
    @JvmField var zoomRatio: Float = 0.7f
    @JvmField var scrollRatio: Float = 0.2f
    @JvmField var wheelStepPx: Float = 8.0f
    @JvmField var naturalScrolling: Boolean = false

    // ---- acceleration ----
    @JvmField var accelEnabled: Boolean = true
    @JvmField var accelDrainHistory: Boolean = true
    @JvmField var accelResetOnDown: Boolean = true
    @JvmField var accelBase: Float = Math.sqrt(1.1).toFloat()
    @JvmField var accelExponent: Float = 2.5999999f
    @JvmField var accelMin: Float = 1.1f
    @JvmField var accelMax: Float = 5.0f

    // ---- adaptive acceleration / axis lock ----
    @JvmField var accelAdaptive: Boolean = false
    @JvmField var accelSlowSpeedPx: Float = dp(0.15f)
    @JvmField var accelFullSpeedPx: Float = dp(0.60f)
    @JvmField var axisLockEnabled: Boolean = false
    @JvmField var axisLockMaxSpeedPx: Float = dp(0.25f)
    @JvmField var axisLockEnterRatio: Float = 0.30f
    @JvmField var axisLockExitRatio: Float = 0.55f
    @JvmField var axisLockTurnSpanPx: Float = dp(36f)
    @JvmField var axisLockMaxTurnDeg: Float = 10.0f
    @JvmField var axisLockCornerDeg: Float = 45.0f

    // ---- hover assist ----
    @JvmField var hoverAssistEnabled: Boolean = false
    @JvmField var hoverAssistSpanPx: Float = dp(12f)
    @JvmField var hoverAssistGain: Float = 0.25f
    @JvmField var hoverAssistMaxSpeedPx: Float = dp(0.35f)
    @JvmField var hoverAssistIdleMs: Long = 120
    @JvmField var hoverAssistMinTravelPx: Float = dp(6f)
    @JvmField var hoverAssistBurstCount: Int = 4
    @JvmField var hoverAssistBurstMs: Long = 600
    @JvmField var hoverAssistLockoutMs: Long = 2000
    @JvmField var hoverAssistMaxLagMs: Long = 60

    /** Send a finger's motion unshaped where the far end owns the cursor. */
    @JvmField var rawMotionWhenRelative: Boolean = true

    // ---- mouse button overlay ----
    @JvmField var overlayStripWidthPx: Float = dp(60f)
    @JvmField var overlayRowHeightPx: Float = dp(72f)
    @JvmField var overlayDismissPx: Float = dp(40f)
    @JvmField var overlayDismissMarginPx: Float = dp(17.5f)
    @JvmField var overlayMiddleMinPx: Float = dp(100f)
    @JvmField var overlayWheelTickMs: Long = 40
    @JvmField var overlayWheelMaxRate: Float = 4.0f
    @JvmField var overlayWheelTicksPerClick: Float = 3.0f
    @JvmField var overlayWheelStartDelayTicks: Int = 8

    // ---- extension keyboard ----
    @JvmField var keyboardHaptics: Boolean = true
    @JvmField var keyboardInfoSolid: Boolean = false
    @JvmField var keyboardInfoMaxChars: Int = 256
    @JvmField var keyDoubleTapMs: Long = 300
    @JvmField var keyLongPressMs: Long = 500
    @JvmField var keyRepeatMs: Long = 75
    @JvmField var keyboardKeyHeightPx: Float = dp(46f)
    @JvmField var keyboardKeyHeightMultiPx: Float = dp(40f)
    @JvmField var keyboardInfoHeightPx: Float = dp(30f)
    @JvmField var keyboardKeyPadPx: Float = dp(8f)
    @JvmField var keyboardKeyPadWidePx: Float = dp(12f)
    @JvmField var keyboardGroupGapPx: Float = dp(22f)
    @JvmField var keyboardIconWidthPx: Float = dp(18f)
    @JvmField var keyboardMinKeyWidthPx: Float = dp(32f)
    @JvmField var keyboardScrollSlopPx: Float = dp(8f)
    @JvmField var keyboardFlingTickMs: Long = 16
    @JvmField var keyboardFlingDecay: Float = 0.94f
    @JvmField var keyboardFlingMinPx: Float = dp(0.3f)
    @JvmField var keyboardFlingStopPx: Float = dp(0.02f)

    // ---- toolbar ----
    @JvmField var toolbarButtonPx: Float = dp(44f)
    @JvmField var toolbarGripPx: Float = dp(24f)
    @JvmField var toolbarDragSlopPx: Float = dp(8f)

    // ---- momentum ----
    @JvmField var inertiaEnabled: Boolean = true
    @JvmField var inertiaStartDelayMs: Long = 50
    @JvmField var inertiaTickMs: Long = 10
    @JvmField var inertiaSpeedScale: Double = 25.0
    @JvmField var inertiaSpeedMax: Double = 200.0
    @JvmField var inertiaDecay: Double = 0.85
    @JvmField var inertiaStopSpeed: Double = 3.0
    @JvmField var inertiaCancelOnDown: Boolean = true
    @JvmField var inertiaResetOnDown: Boolean = true

    // ---- cursor / viewport ----
    @JvmField var recentreCursorOnZoom: Boolean = true
    @JvmField var coalescePointerEvents: Boolean = true
    @JvmField var dedupePointerEvents: Boolean = true
    @JvmField var panMarginInsets: Boolean = false
    @JvmField var panMarginPx: Float = 0f

    // ---- physical mouse ----
    @JvmField var mouseCapture: Boolean = true
    @JvmField var mouseSpeed: Float = 1.0f
    @JvmField var mouseWheelStep: Float = 1.0f

    /** Adopt every setting of [o], so new preferences reach a stack that is already running. */
    fun copyFrom(o: Config) {
        for (f in Config::class.java.fields) {
            val m = f.modifiers
            if (Modifier.isStatic(m) || Modifier.isFinal(m)) continue
            f.set(this, f.get(o))
        }
    }

    companion object {
        /** The version Vento ships: the original's feel plus its deliberate improvements. */
        fun improved(density: Float): Config {
            val c = Config(density)
            c.tapPathThresholdPx = c.dp(24f)
            c.accelAdaptive = true
            c.axisLockEnabled = true
            c.hoverAssistEnabled = true
            return c
        }
    }
}
