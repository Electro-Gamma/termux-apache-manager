// SPDX-License-Identifier: GPL-3.0-or-later
//
// Kotlin port of Vento's AppSettings.java (https://github.com/pgaskin/vento,
// (C) 2026 Patrick Gaskin): app-level session preferences.
package com.vncviewer.app.input

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableIntStateOf

/**
 * App-level preferences: the ones about this program rather than about a connection or
 * about the feel of the input stack (which has its own file, [InputSettings]).
 * A preference that has never been touched is absent, and [DEFAULTS] answers for it.
 */
object AppSettings {
    const val FILE = "settings_app"

    const val KEY_HUD = "hud"
    const val KEY_KEEP_AWAKE = "keepAwake"
    const val KEY_IMMERSIVE = "immersive"
    const val KEY_PRIVATE_IME = "privateIme"
    const val KEY_MODIFIER_RESETS_IME = "modifierResetsIme"
    const val KEY_TWO_LINE_KEYS = "twoLineKeys"
    const val KEY_MAC_KEYS = "macKeys"
    const val KEY_CONTROLS = "controls"
    const val KEY_TOOLBAR_POS = "toolbarPos"
    const val KEY_CLIPBOARD_OUT = "clipboardOut"
    const val KEY_CLIPBOARD_IN = "clipboardIn"
    const val KEY_REGION_HINTS = "regionHints"
    const val KEY_RELEASE_KEYS = "releaseKeys"
    const val KEY_SESSION_TIMEOUT = "sessionTimeout"
    const val KEY_CURSOR_DOT = "cursorDot"
    const val KEY_LIST_VIEW = "listView"
    const val KEY_PREVIEWS = "previews"

    const val CONTROLS_TOOLBAR = "toolbar"
    const val CONTROLS_REGIONS = "regions"
    const val CONTROLS_BOTH = "both"

    /** Every key with the answer it gives when nothing is stored; the class says how it is stored. */
    val DEFAULTS: Map<String, Any> = linkedMapOf(
        KEY_HUD to false,
        KEY_KEEP_AWAKE to true,
        KEY_IMMERSIVE to true,
        KEY_PRIVATE_IME to true,
        KEY_MODIFIER_RESETS_IME to true,
        KEY_TWO_LINE_KEYS to false,
        KEY_MAC_KEYS to true,
        KEY_CONTROLS to CONTROLS_REGIONS,
        KEY_TOOLBAR_POS to "35",
        KEY_CLIPBOARD_OUT to true,
        KEY_CLIPBOARD_IN to true,
        KEY_REGION_HINTS to true,
        KEY_RELEASE_KEYS to true,
        KEY_SESSION_TIMEOUT to "0",
        KEY_CURSOR_DOT to true,
        KEY_LIST_VIEW to false,
        KEY_PREVIEWS to true
    )

    /** What the session timeout row offers, in minutes, in order. */
    val SESSION_TIMEOUTS: List<Int> = listOf(0, 1, 5, 15, 30, 45, 60, 120, 240, 480, 720, 1440)

    /** Bumped on every change so Compose screens that read a preference redraw. */
    val changeTick = mutableIntStateOf(0)

    fun prefs(ctx: Context): SharedPreferences =
        ctx.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun bool(ctx: Context, key: String): Boolean {
        changeTick.intValue
        return prefs(ctx).getBoolean(key, DEFAULTS[key] as Boolean)
    }

    fun text(ctx: Context, key: String): String {
        changeTick.intValue
        return prefs(ctx).getString(key, DEFAULTS[key] as String) ?: (DEFAULTS[key] as String)
    }

    fun setBool(ctx: Context, key: String, value: Boolean) {
        prefs(ctx).edit().putBoolean(key, value).apply()
        changeTick.intValue = changeTick.intValue + 1
    }

    fun setText(ctx: Context, key: String, value: String) {
        prefs(ctx).edit().putString(key, value).apply()
        changeTick.intValue = changeTick.intValue + 1
    }

    fun hud(ctx: Context) = bool(ctx, KEY_HUD)
    fun keepAwake(ctx: Context) = bool(ctx, KEY_KEEP_AWAKE)
    fun immersive(ctx: Context) = bool(ctx, KEY_IMMERSIVE)
    fun privateIme(ctx: Context) = bool(ctx, KEY_PRIVATE_IME)
    fun modifierResetsIme(ctx: Context) = bool(ctx, KEY_MODIFIER_RESETS_IME)
    fun twoLineKeys(ctx: Context) = bool(ctx, KEY_TWO_LINE_KEYS)
    fun macKeys(ctx: Context) = bool(ctx, KEY_MAC_KEYS)
    fun clipboardOut(ctx: Context) = bool(ctx, KEY_CLIPBOARD_OUT)
    fun clipboardIn(ctx: Context) = bool(ctx, KEY_CLIPBOARD_IN)
    fun regionHints(ctx: Context) = bool(ctx, KEY_REGION_HINTS)
    fun releaseKeys(ctx: Context) = bool(ctx, KEY_RELEASE_KEYS)
    fun cursorDot(ctx: Context) = bool(ctx, KEY_CURSOR_DOT)

    /** Home screen: connections as rows rather than cards. */
    fun listView(ctx: Context) = bool(ctx, KEY_LIST_VIEW)
    fun setListView(ctx: Context, value: Boolean) = setBool(ctx, KEY_LIST_VIEW, value)

    /** Whether the last screenful of a desktop is kept as the preview on its home card. */
    fun previews(ctx: Context) = bool(ctx, KEY_PREVIEWS)

    /** Which affordance a session offers: the toolbar, the tap regions, or both. */
    fun controls(ctx: Context): String {
        val v = text(ctx, KEY_CONTROLS)
        return if (v == CONTROLS_TOOLBAR || v == CONTROLS_BOTH) v else CONTROLS_REGIONS
    }

    fun toolbarShown(ctx: Context): Boolean = controls(ctx) != CONTROLS_REGIONS
    fun regionsShown(ctx: Context): Boolean = controls(ctx) != CONTROLS_TOOLBAR

    /** Where the toolbar sits, as a fraction of the band it may be dragged in. */
    fun toolbarPosition(ctx: Context): Float {
        val pc = text(ctx, KEY_TOOLBAR_POS).toIntOrNull() ?: return 0.35f
        return Math.min(100, Math.max(0, pc)) / 100f
    }

    fun setToolbarPosition(ctx: Context, fraction: Float) {
        val f = Math.min(1f, Math.max(0f, fraction))
        // Not through setText: dragging the toolbar must not redraw the settings screens.
        prefs(ctx).edit().putString(KEY_TOOLBAR_POS, Math.round(f * 100).toString()).apply()
    }

    /** Minutes a session may stay connected with nothing looking at it, or 0 for never. */
    fun sessionTimeout(ctx: Context): Int {
        val v = text(ctx, KEY_SESSION_TIMEOUT).toIntOrNull() ?: return 0
        return Math.max(0, v)
    }

    fun timeoutLabel(minutes: Int): String {
        if (minutes <= 0) return "Never"
        if (minutes % 60 == 0) {
            val h = minutes / 60
            return if (h == 1) "1 hour" else "$h hours"
        }
        return if (minutes == 1) "1 minute" else "$minutes minutes"
    }

    fun controlsLabel(value: String): String = when (value) {
        CONTROLS_TOOLBAR -> "Toolbar"
        CONTROLS_BOTH -> "Toolbar and touch regions"
        else -> "Touch regions"
    }

    /** "Restore defaults": every session setting back to what a fresh install has. */
    fun resetAll(ctx: Context) {
        prefs(ctx).edit().clear().apply()
        InputSettings.prefs(ctx).edit().clear().apply()
        changeTick.intValue = changeTick.intValue + 1
    }
}
