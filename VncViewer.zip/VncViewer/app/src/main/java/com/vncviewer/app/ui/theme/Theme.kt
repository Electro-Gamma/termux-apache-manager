package com.vncviewer.app.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.LineHeightStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Deep graphite (dark) or cool paper (light), with four accents that each mean one thing.
// Turquoise is the brand and marks what succeeded; cyan means work in progress; amber
// means the app has stopped and is waiting on the user; red means it failed. See
// ConnectionStatus, which is where that mapping is actually enforced.
//
// The names below are what the rest of the app imports. They used to be fixed dark values;
// they are now read from the active palette, so every screen follows the light/dark choice
// without being touched. The accents are deepened in light mode so they keep their contrast
// on a white surface (the dark-mode turquoise would be unreadable as text there).
class AppColors(
    val ink: Color,
    val surface1: Color,
    val surface2: Color,
    val surface3: Color,
    val stroke: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val turquoise: Color,
    val cyan: Color,
    val amber: Color,
    val danger: Color,
)

private val DarkAppColors = AppColors(
    ink = Color(0xFF07090C),
    surface1 = Color(0xFF101317),
    surface2 = Color(0xFF171B20),
    surface3 = Color(0xFF20262D),
    stroke = Color(0xFF2A3037),
    textPrimary = Color(0xFFF4F7F8),
    textSecondary = Color(0xFF9AA4AC),
    turquoise = Color(0xFF35D7AE),
    cyan = Color(0xFF5AC8FA),
    amber = Color(0xFFFFC66D),
    danger = Color(0xFFFF7082),
)

private val LightAppColors = AppColors(
    ink = Color(0xFFF5F7F9),
    surface1 = Color(0xFFFFFFFF),
    surface2 = Color(0xFFEEF1F4),
    surface3 = Color(0xFFE3E8ED),
    stroke = Color(0xFFD3DAE0),
    textPrimary = Color(0xFF10151A),
    textSecondary = Color(0xFF55606A),
    turquoise = Color(0xFF00856A),
    cyan = Color(0xFF0A6FA8),
    amber = Color(0xFF9A5B00),
    danger = Color(0xFFC62339),
)

/**
 * The active palette. Backed by snapshot state, so anything that reads a colour (a
 * composable, or a draw block) is invalidated when the mode flips. [TerminalTheme] is the
 * only writer.
 */
object AppPalette {
    var dark: Boolean by mutableStateOf(true)

    internal val colors: AppColors get() = if (dark) DarkAppColors else LightAppColors
}

val Ink: Color get() = AppPalette.colors.ink
val Surface1: Color get() = AppPalette.colors.surface1
val Surface2: Color get() = AppPalette.colors.surface2
val Surface3: Color get() = AppPalette.colors.surface3
val Stroke: Color get() = AppPalette.colors.stroke
val TextPrimary: Color get() = AppPalette.colors.textPrimary
val TextSecondary: Color get() = AppPalette.colors.textSecondary
val Turquoise: Color get() = AppPalette.colors.turquoise
val Cyan: Color get() = AppPalette.colors.cyan
val Amber: Color get() = AppPalette.colors.amber
val Danger: Color get() = AppPalette.colors.danger

private val DarkScheme = darkColorScheme(
    primary = DarkAppColors.turquoise,
    onPrimary = DarkAppColors.ink,
    primaryContainer = Color(0xFF0C3A31),
    onPrimaryContainer = Color(0xFFC7FFF0),
    secondary = DarkAppColors.cyan,
    onSecondary = DarkAppColors.ink,
    secondaryContainer = Color(0xFF12323B),
    onSecondaryContainer = Color(0xFFD4F8FF),
    tertiary = DarkAppColors.cyan,
    onTertiary = DarkAppColors.ink,
    background = DarkAppColors.ink,
    onBackground = DarkAppColors.textPrimary,
    surface = DarkAppColors.surface1,
    onSurface = DarkAppColors.textPrimary,
    surfaceVariant = DarkAppColors.surface2,
    onSurfaceVariant = DarkAppColors.textSecondary,
    outline = DarkAppColors.stroke,
    error = DarkAppColors.danger,
    onError = DarkAppColors.ink,
)

private val LightScheme = lightColorScheme(
    primary = LightAppColors.turquoise,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFC6F2E5),
    onPrimaryContainer = Color(0xFF00382C),
    secondary = LightAppColors.cyan,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFD2EAF7),
    onSecondaryContainer = Color(0xFF042F47),
    tertiary = LightAppColors.cyan,
    onTertiary = Color.White,
    background = LightAppColors.ink,
    onBackground = LightAppColors.textPrimary,
    surface = LightAppColors.surface1,
    onSurface = LightAppColors.textPrimary,
    surfaceVariant = LightAppColors.surface2,
    onSurfaceVariant = LightAppColors.textSecondary,
    surfaceTint = LightAppColors.turquoise,
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFF8FAFB),
    surfaceContainer = LightAppColors.surface2,
    surfaceContainerHigh = Color(0xFFE9EDF1),
    surfaceContainerHighest = LightAppColors.surface3,
    outline = Color(0xFF8A949D),
    outlineVariant = LightAppColors.stroke,
    error = LightAppColors.danger,
    onError = Color.White,
)

/**
 * Corner radii on a 4dp grid like everything else. The previous 9/13/18/24/30 were close
 * to these but off the grid, which is invisible on any one component and reads as
 * carelessness once several sit next to each other.
 */
private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp),
)

/**
 * Line height is centred in the text box, and letterSpacing stays at zero for every style so
 * all text keeps its natural width.
 */
private val AppLineHeight = LineHeightStyle(
    alignment = LineHeightStyle.Alignment.Center,
    trim = LineHeightStyle.Trim.None,
)

private fun appStyle(
    size: Int,
    line: Int,
    weight: FontWeight = FontWeight.Normal,
    color: Color = Color.Unspecified,
) = TextStyle(
    fontFamily = FontFamily.Default,
    fontSize = size.sp,
    lineHeight = line.sp,
    fontWeight = weight,
    letterSpacing = 0.sp,
    color = color,
    lineHeightStyle = AppLineHeight,
    platformStyle = PlatformTextStyle(includeFontPadding = false),
)

/**
 * Built per mode, not once: labelSmall carries the secondary text colour, which differs
 * between dark and light.
 *
 * Every Material 3 style is defined, not just the ones in use today.
 *
 * An undefined style silently falls back to the Material default, which is a Latin-first
 * face with non-zero letterSpacing — the exact thing the note above rules out. Two styles were previously left undefined and were rendering in the
 * fallback font, letter-spaced. Filling the whole scale means the next screen that
 * reaches for titleSmall cannot reintroduce that.
 */
private fun appTypography() = Typography(
    displayLarge = appStyle(45, 56, FontWeight.Bold),
    displayMedium = appStyle(36, 46, FontWeight.Bold),
    displaySmall = appStyle(32, 41, FontWeight.Bold),

    headlineLarge = appStyle(34, 45, FontWeight.Bold),
    headlineMedium = appStyle(29, 42, FontWeight.Bold),
    headlineSmall = appStyle(24, 34, FontWeight.SemiBold),

    titleLarge = appStyle(20, 31, FontWeight.SemiBold),
    titleMedium = appStyle(16, 26, FontWeight.Medium),
    titleSmall = appStyle(14, 22, FontWeight.SemiBold),

    bodyLarge = appStyle(16, 27),
    bodyMedium = appStyle(14, 24),
    bodySmall = appStyle(12, 20),

    labelLarge = appStyle(14, 21, FontWeight.Medium),
    labelMedium = appStyle(12, 18, FontWeight.Medium),
    labelSmall = appStyle(12, 19, color = TextSecondary),
)

val MonoStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp)

/**
 * [dark] picks the whole app's look. The palette is written before any child composes, so
 * the first frame already has the right colours.
 */
@Composable
fun TerminalTheme(dark: Boolean = true, content: @Composable () -> Unit) {
    AppPalette.dark = dark
    val typography = remember(dark) { appTypography() }
    MaterialTheme(
        colorScheme = if (dark) DarkScheme else LightScheme,
        shapes = AppShapes,
        typography = typography,
        content = content,
    )
}

data class TerminalPalette(
    val id: String,
    val label: String,
    val background: Color,
    val foreground: Color,
    val accent: Color,
    /** The 16 ANSI colours: 0-7 normal (black..white), 8-15 bright. */
    val ansi: List<Color> = DefaultAnsi,
)

private fun ansi(vararg rgb: Long): List<Color> = rgb.map { Color(0xFF000000 or it) }

/** A neutral set (the VS Code terminal defaults) for themes that do not define their own. */
private val DefaultAnsi = ansi(
    0x000000, 0xCD3131, 0x0DBC79, 0xE5E510, 0x2472C8, 0xBC3FBC, 0x11A8CD, 0xE5E5E5,
    0x666666, 0xF14C4C, 0x23D18B, 0xF5F543, 0x3B8EEA, 0xD670D6, 0x29B8DB, 0xFFFFFF,
)

/**
 * A readable 16-colour set for light backgrounds. [DefaultAnsi] has a pale "white" and
 * "bright white" that would disappear on a white terminal, so light themes that do not
 * ship their own colours use this instead.
 */
private val LightAnsi = ansi(
    0x1F2328, 0xC62828, 0x2E7D32, 0x9A6700, 0x1565C0, 0x8E24AA, 0x00838F, 0x6E7781,
    0x57606A, 0xE53935, 0x43A047, 0xB8860B, 0x1E88E5, 0xAB47BC, 0x00ACC1, 0x8C959F,
)

val TerminalPalettes = listOf(
    TerminalPalette("neon", "Neon turquoise", Color(0xFF05080B), Color(0xFFF0F6F8), Turquoise),
    TerminalPalette("oled", "OLED black", Color(0xFF000000), Color(0xFFD6DEE6), Cyan),
    TerminalPalette("midnight", "Midnight", Color(0xFF09121E), Color(0xFFDCE8F2), Color(0xFF79A7FF)),
    TerminalPalette("solarized", "Solarized", Color(0xFF002B36), Color(0xFF93A1A1), Color(0xFFB58900),
        ansi(0x073642, 0xDC322F, 0x859900, 0xB58900, 0x268BD2, 0xD33682, 0x2AA198, 0xEEE8D5,
            0x002B36, 0xCB4B16, 0x586E75, 0x657B83, 0x839496, 0x6C71C4, 0x93A1A1, 0xFDF6E3)),
    TerminalPalette("classic", "Classic green", Color(0xFF031008), Color(0xFF58F58A), Color(0xFF58F58A)),
    TerminalPalette("amber", "Amber", Color(0xFF100B04), Color(0xFFFFC66D), Amber),
    // Community palettes, using each project's published background, foreground and a
    // representative accent rather than an approximation.
    TerminalPalette("dracula", "Dracula", Color(0xFF282A36), Color(0xFFF8F8F2), Color(0xFFBD93F9),
        ansi(0x21222C, 0xFF5555, 0x50FA7B, 0xF1FA8C, 0xBD93F9, 0xFF79C6, 0x8BE9FD, 0xF8F8F2,
            0x6272A4, 0xFF6E6E, 0x69FF94, 0xFFFFA5, 0xD6ACFF, 0xFF92DF, 0xA4FFFF, 0xFFFFFF)),
    TerminalPalette("nord", "Nord", Color(0xFF2E3440), Color(0xFFD8DEE9), Color(0xFF88C0D0),
        ansi(0x3B4252, 0xBF616A, 0xA3BE8C, 0xEBCB8B, 0x81A1C1, 0xB48EAD, 0x88C0D0, 0xE5E9F0,
            0x4C566A, 0xBF616A, 0xA3BE8C, 0xEBCB8B, 0x81A1C1, 0xB48EAD, 0x8FBCBB, 0xECEFF4)),
    TerminalPalette("gruvbox", "Gruvbox", Color(0xFF282828), Color(0xFFEBDBB2), Color(0xFFFABD2F),
        ansi(0x282828, 0xCC241D, 0x98971A, 0xD79921, 0x458588, 0xB16286, 0x689D6A, 0xA89984,
            0x928374, 0xFB4934, 0xB8BB26, 0xFABD2F, 0x83A598, 0xD3869B, 0x8EC07C, 0xEBDBB2)),
    TerminalPalette("catppuccin", "Catppuccin", Color(0xFF1E1E2E), Color(0xFFCDD6F4), Color(0xFFF5C2E7),
        ansi(0x45475A, 0xF38BA8, 0xA6E3A1, 0xF9E2AF, 0x89B4FA, 0xF5C2E7, 0x94E2D5, 0xBAC2DE,
            0x585B70, 0xF38BA8, 0xA6E3A1, 0xF9E2AF, 0x89B4FA, 0xF5C2E7, 0x94E2D5, 0xA6ADC8)),
    TerminalPalette("tokyo_night", "Tokyo Night", Color(0xFF1A1B26), Color(0xFFC0CAF5), Color(0xFF7AA2F7),
        ansi(0x15161E, 0xF7768E, 0x9ECE6A, 0xE0AF68, 0x7AA2F7, 0xBB9AF7, 0x7DCFFF, 0xA9B1D6,
            0x414868, 0xF7768E, 0x9ECE6A, 0xE0AF68, 0x7AA2F7, 0xBB9AF7, 0x7DCFFF, 0xC0CAF5)),
    // Light themes. Each pairs a pale background with a dark foreground and ANSI colours
    // chosen to stay legible on it (nothing near-white, nothing that needs a dark ground).
    TerminalPalette("paper", "Paper", Color(0xFFFFFFFF), Color(0xFF1F2328), Color(0xFF00856A), LightAnsi),
    TerminalPalette("github_light", "GitHub Light", Color(0xFFFFFFFF), Color(0xFF24292F), Color(0xFF0969DA),
        ansi(0x24292F, 0xCF222E, 0x116329, 0x4D2D00, 0x0969DA, 0x8250DF, 0x1B7C83, 0x6E7781,
            0x57606A, 0xA40E26, 0x1A7F37, 0x633C01, 0x218BFF, 0xA475F9, 0x3192AA, 0x8C959F)),
    TerminalPalette("solarized_light", "Solarized Light", Color(0xFFFDF6E3), Color(0xFF657B83), Color(0xFFB58900),
        ansi(0x073642, 0xDC322F, 0x859900, 0xB58900, 0x268BD2, 0xD33682, 0x2AA198, 0xEEE8D5,
            0x002B36, 0xCB4B16, 0x586E75, 0x657B83, 0x839496, 0x6C71C4, 0x93A1A1, 0xFDF6E3)),
    TerminalPalette("one_light", "One Light", Color(0xFFFAFAFA), Color(0xFF383A42), Color(0xFF4078F2),
        ansi(0x383A42, 0xE45649, 0x50A14F, 0xC18401, 0x4078F2, 0xA626A4, 0x0184BC, 0xA0A1A7,
            0x4F525E, 0xEF6A5E, 0x62B25F, 0xD19A0A, 0x5C8EF7, 0xB93FB7, 0x1B9BCF, 0x7F848E)),
    TerminalPalette("gruvbox_light", "Gruvbox Light", Color(0xFFFBF1C7), Color(0xFF3C3836), Color(0xFFD79921),
        ansi(0x3C3836, 0xCC241D, 0x98971A, 0xD79921, 0x458588, 0xB16286, 0x689D6A, 0x7C6F64,
            0x928374, 0x9D0006, 0x79740E, 0xB57614, 0x076678, 0x8F3F71, 0x427B58, 0x282828)),
    TerminalPalette("catppuccin_latte", "Catppuccin Latte", Color(0xFFEFF1F5), Color(0xFF4C4F69), Color(0xFF8839EF),
        ansi(0x5C5F77, 0xD20F39, 0x40A02B, 0xDF8E1D, 0x1E66F5, 0xEA76CB, 0x179299, 0xACB0BE,
            0x6C6F85, 0xD20F39, 0x40A02B, 0xDF8E1D, 0x1E66F5, 0xEA76CB, 0x179299, 0xBCC0CC)),
)

/** The palette for a stored theme id; an unknown id (an old or imported value) gets the default. */
fun terminalPalette(id: String): TerminalPalette =
    TerminalPalettes.firstOrNull { it.id == id } ?: TerminalPalettes.first()
