package com.vncviewer.app.ui

import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.foundation.layout.fillMaxSize
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.vncviewer.app.input.AppSettings
import com.vncviewer.app.session.Phase

@Composable
fun VncViewerApp(vm: VncViewModel) {
    val view = LocalView.current
    val context = LocalContext.current

    val inSession = vm.screen == Screen.SESSION
    val connected = vm.activeSession?.phase == Phase.CONNECTED
    // "Full screen" hides the system bars while connected; the Fullscreen chip also hides our own chrome.
    val immersive = inSession && (vm.fullscreen || (AppSettings.immersive(context) && connected))
    val keepAwake = inSession && connected && AppSettings.keepAwake(context)

    BackHandler(enabled = inSession) {
        if (vm.fullscreen) {
            vm.fullscreen = false
        } else {
            vm.screen = Screen.LIST
        }
    }

    LaunchedEffect(immersive) {
        val window = (context as? Activity)?.window ?: return@LaunchedEffect
        val controller = WindowCompat.getInsetsController(window, view)
        if (immersive) {
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            controller.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    // Sessions are always dark; the home and settings screens follow the system.
    val homeStyle = vm.screen != Screen.SESSION
    val lightBars = homeStyle && !isSystemInDarkTheme()
    SideEffect {
        view.keepScreenOn = keepAwake
        val window = (context as? Activity)?.window ?: return@SideEffect
        val controller = WindowCompat.getInsetsController(window, view)
        controller.isAppearanceLightStatusBars = lightBars
        controller.isAppearanceLightNavigationBars = lightBars
    }

    val body: @Composable () -> Unit = {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = if (homeStyle) MaterialTheme.colorScheme.surfaceContainer else MaterialTheme.colorScheme.background
        ) {
            when (vm.screen) {
                Screen.SESSION -> {
                    val session = vm.activeSession
                    // Leaving a session, by any road, keeps its last screenful for the home card.
                    DisposableEffect(session?.id) {
                        onDispose { if (session != null && vm.sessions.contains(session)) vm.captureThumbnail(session) }
                    }
                    SessionScreen(vm)
                }
                Screen.SETTINGS -> SettingsScreen(vm)
                Screen.LIST -> ConnectionsScreen(vm)
            }
        }
    }
    if (homeStyle) VncHomeTheme(body) else body()
}
