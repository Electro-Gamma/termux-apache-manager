package com.vncviewer.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import com.vncviewer.app.input.AppSettings
import com.vncviewer.app.ui.theme.TerminalTheme

/**
 * Light, dark, or follow the phone: the same three choices as TerminalSSH's "appearance"
 * setting, and dark by default like it. The look itself (palette, type, shapes, spacing) is
 * TerminalSSH's, copied unchanged into ui/theme so the two apps can be merged later.
 */
@Composable
fun appIsDark(): Boolean {
    val ctx = LocalContext.current
    val system = isSystemInDarkTheme()
    return when (AppSettings.text(ctx, AppSettings.KEY_APPEARANCE)) {
        AppSettings.APPEARANCE_LIGHT -> false
        AppSettings.APPEARANCE_SYSTEM -> system
        else -> true
    }
}

@Composable
fun VncViewerTheme(content: @Composable () -> Unit) {
    TerminalTheme(dark = appIsDark(), content = content)
}

/** Kept for callers: the home and settings screens now share the one app theme. */
@Composable
fun VncHomeTheme(content: @Composable () -> Unit) = content()
