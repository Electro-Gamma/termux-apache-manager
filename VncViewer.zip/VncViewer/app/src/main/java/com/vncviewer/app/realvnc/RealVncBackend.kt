// SPDX-License-Identifier: GPL-3.0-or-later
//
// Kotlin port of the RealVNC backend of Vento (https://github.com/pgaskin/vento,
// (C) 2026 Patrick Gaskin, GPL-3.0-or-later): RealVncBackend.java, adapted to this app's
// RemoteBackend / VncListener seam and to a simpler pixel pipeline.
package com.vncviewer.app.realvnc

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.realvnc.vncviewer.jni.ConnectionInfoBindings
import com.realvnc.vncviewer.jni.SessionBindings
import com.vncviewer.app.vnc.RemoteBackend
import com.vncviewer.app.vnc.RemotePrompt
import com.vncviewer.app.vnc.VncListener
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean

/**
 * A [RemoteBackend] on RealVNC's own viewer core (libvncviewer.so, supplied separately).
 *
 * Thread discipline, which the library imposes:
 *  - The core thread ([RealVncCore]) owns every call into the library AND receives every
 *    callback. Long work posted to it delays the protocol itself.
 *  - Pixels are read on that same thread when an update ends, in 256x256 tiles through a
 *    small native scratch buffer, and painted into one desktop-sized Bitmap which the UI
 *    draws. Because everything that touches the native buffer is on one thread, no extra
 *    locking is needed (Vento reads on the renderer thread and needs a lock for that).
 *  - Never call destroySession: closing an already-closed session is a SIGSEGV inside the
 *    core, and the original viewer never calls it either.
 */
class RealVncBackend(
    context: Context,
    private val address: String,
    userName: String,
    passwordText: String,
    quality: String,
    viewOnly: Boolean,
    private val listener: VncListener
) : RemoteBackend, SessionBindings.DesktopCallback, SessionBindings.SessionCallback {

    private enum class State { IDLE, CONNECTING, CONNECTED, CLOSED }

    private val appContext: Context = context.applicationContext
    private val mainHandler = Handler(Looper.getMainLooper())

    /** Empty is not a password: the core would authenticate with "" instead of asking. */
    private val passwordArg: String? = if (passwordText.isEmpty()) null else passwordText

    private val options = LinkedHashMap<String, String>()

    @Volatile
    private var session: SessionBindings.Session? = null

    @Volatile
    private var state = State.IDLE

    @Volatile
    private var dead = false

    // ---- pixels (core thread only) -----------------------------------------------------
    private var desktopW = 0
    private var desktopH = 0
    private var desktop: Bitmap? = null
    private var desktopCanvas: Canvas? = null
    private var tileBitmap: Bitmap? = null
    private var tileBuffer: ByteBuffer? = null
    private var dirty = BooleanArray(0)
    private var cellsX = 0
    private var cellsY = 0
    private var anyDirty = false
    private var flushScheduled = false
    private val srcRect = Rect()
    private val dstRect = Rect()
    private val copyPaint = Paint()

    // ---- misc ----------------------------------------------------------------------------
    private val held = LinkedHashSet<Int>()

    @Volatile
    private var pendingClipboardText: String? = null

    @Volatile
    private var pendingPointer = -1L
    private val moveScheduled = AtomicBoolean(false)

    /**
     * Prompts on screen. The connect timeout is about a session that has gone silent, and a
     * session waiting for a password has not. Core thread only.
     */
    private var outstandingPrompts = 0
    private val connectTimeout = Runnable { onConnectTimeout() }
    private val flushRunnable = Runnable {
        flushScheduled = false
        flushDirty()
        listener.onFrameUpdated()
    }

    init {
        copyPaint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC)

        // Every offered parameter at its default, then this connection's choices on top.
        options["Quality"] = "Auto"
        options["PreferredEncoding"] = "ZRLE2"
        options["ColorLevel"] = "full"
        options["ViewOnly"] = "false"
        options["Shared"] = "true"
        options["AutoReconnect"] = "true"
        options["EnableUdpRfb"] = "true"
        options["Encryption"] = "PreferOn"
        options["WarnUnencrypted"] = "true"
        options["DotWhenNoCursor"] = "true"
        options["AcceptBell"] = "true"
        options["KeepAliveInterval"] = "30"
        options["KeepAliveResponseTimeout"] = "30"

        if (userName.isNotEmpty()) options["UserName"] = userName
        options["Quality"] = quality
        options["ColorLevel"] = colorLevelFor(quality)
        options["ViewOnly"] = viewOnly.toString()

        // What this server was last accepted as: the core's security prompt is silent for an
        // identity it recognises.
        val identity = identities(appContext).getString(address, null)
        if (identity != null) options["Identity"] = identity
    }

    internal fun addressText(): String = address

    // =====================================================================================
    // Lifecycle
    // =====================================================================================

    override fun start() {
        if (state != State.IDLE) return
        state = State.CONNECTING
        try {
            RealVncCore.start(appContext)
        } catch (t: Throwable) {
            Log.e(TAG, "core start failed", t)
            state = State.CLOSED
            listener.onDisconnected(
                "The RealVNC engine could not start: " + (t.message ?: t.javaClass.simpleName)
            )
            return
        }
        RealVncCore.postDelayed(connectTimeout, CONNECT_TIMEOUT_MS)
        listener.onStatus("Connecting to $address\u2026")
        RealVncCore.post { createOnCoreThread() }
    }

    private fun createOnCoreThread() {
        if (dead) return
        val snapshot = HashMap<String, String>()
        synchronized(options) { snapshot.putAll(options) }

        RealVncPrompts.connecting(this)
        var s: SessionBindings.Session? = null
        try {
            s = SessionBindings.createSession(this, this, address, passwordArg, snapshot)
        } catch (t: Throwable) {
            Log.e(TAG, "createSession failed", t)
        } finally {
            RealVncPrompts.connected(this)
        }
        if (s == null) {
            closed("Could not start the connection")
            return
        }
        session = s
        RealVncPrompts.attach(s, this)

        // The scratch buffer the core scales regions into, and the bitmap it is copied to.
        try {
            tileBuffer = SessionBindings.setScaleBufferSize(s, TILE, TILE)
            tileBitmap = Bitmap.createBitmap(TILE, TILE, Bitmap.Config.ARGB_8888)
        } catch (t: Throwable) {
            Log.e(TAG, "scale buffer", t)
        }
        SessionBindings.focusEvent(s, true)
    }

    /**
     * A connect that fails reports nothing at all (a refused port logs internally and the
     * session just sits there), so a mistyped address would be a spinner that never stops.
     */
    private fun onConnectTimeout() {
        if (state == State.CONNECTING) {
            Log.w(TAG, "no connSuccess within $CONNECT_TIMEOUT_MS ms")
            reap(true)
            closed("Could not connect to $address")
        }
    }

    override fun close() {
        dead = true
        reap(true)
    }

    /**
     * Close the session and retire the handle (which is what stops it being closed twice).
     * Nothing is ever freed: see the class comment about destroySession.
     */
    private fun reap(close: Boolean) {
        RealVncCore.cancel(connectTimeout)
        RealVncCore.cancel(flushRunnable)
        val s = session ?: return
        session = null
        RealVncPrompts.detach(s)
        RealVncCore.post {
            tileBuffer = null
            val tile = tileBitmap
            tileBitmap = null
            tile?.recycle()
            try {
                if (close && state != State.CLOSED) {
                    SessionBindings.closeSession(s)
                }
            } catch (t: Throwable) {
                Log.w(TAG, "closing session", t)
            }
        }
    }

    private fun closed(detail: String?) {
        if (state == State.CLOSED) return
        state = State.CLOSED
        listener.onDisconnected(detail ?: "Disconnected")
    }

    /** Run something on the core thread with the live handle, if there is one. */
    private fun onSession(what: (SessionBindings.Session) -> Unit): Boolean {
        val s = session
        if (s == null || dead) return false
        RealVncCore.post {
            if (session === s) what(s)
        }
        return true
    }

    // =====================================================================================
    // RemoteBackend: input
    // =====================================================================================

    override fun sendPointer(x: Int, y: Int, buttonMask: Int) {
        onSession { s -> SessionBindings.pointerEvent(s, x, y, buttonMask) }
    }

    override fun sendPointerMove(x: Int, y: Int, buttonMask: Int) {
        pendingPointer = (buttonMask.toLong() shl 40) or (x.toLong() shl 20) or y.toLong()
        if (moveScheduled.compareAndSet(false, true)) {
            RealVncCore.post {
                moveScheduled.set(false)
                val s = session
                val v = pendingPointer
                if (s != null && !dead && v >= 0) {
                    val mask = ((v shr 40) and 0x1FF).toInt()
                    val px = ((v shr 20) and 0xFFFFF).toInt()
                    val py = (v and 0xFFFFF).toInt()
                    SessionBindings.pointerEvent(s, px, py, mask)
                }
            }
        }
    }

    /**
     * The core wants a client-side identity that ties a release to its press; the keysym
     * itself is unique per key, so it doubles as that identity.
     */
    override fun sendKey(keySym: Int, down: Boolean) {
        onSession { s ->
            if (down) {
                held.add(keySym)
                SessionBindings.keyDownEvent(s, keySym.toLong(), keySym)
            } else {
                held.remove(keySym)
                SessionBindings.keyUpEvent(s, keySym)
            }
        }
    }

    /**
     * The core pulls our clipboard through getClipboard() when it decides to, rather than
     * being pushed to: remember the text and answer when asked. The focus toggle nudges the
     * core to look. ("Type phone clipboard" in the menu works regardless.)
     */
    override fun sendClipboard(text: String) {
        pendingClipboardText = text
        onSession { s ->
            SessionBindings.focusEvent(s, false)
            SessionBindings.focusEvent(s, true)
        }
    }

    override fun setFocused(focused: Boolean) {
        onSession { s -> SessionBindings.focusEvent(s, focused) }
    }

    /** Redraw everything from the core's own framebuffer. */
    override fun refresh() {
        RealVncCore.post {
            markDirty(0, 0, desktopW, desktopH)
            flushDirty()
            listener.onFrameUpdated()
        }
    }

    /**
     * Quality is a group: the core acts on a quality that has CHANGED and carries the rest
     * with it, so colour depth, encoding and quality go over together (quality last), then
     * applyOptions.
     */
    override fun setQuality(quality: String) {
        val color = colorLevelFor(quality)
        val encoding: String
        synchronized(options) {
            options["Quality"] = quality
            options["ColorLevel"] = color
            encoding = options["PreferredEncoding"] ?: "ZRLE2"
        }
        onSession { s ->
            SessionBindings.setOption(s, "ColorLevel", color)
            SessionBindings.setOption(s, "PreferredEncoding", encoding)
            SessionBindings.setOption(s, "Quality", quality)
            SessionBindings.applyOptions(s)
        }
    }

    override fun connectionInfo(callback: (List<Pair<String, String>>) -> Unit) {
        val s = session
        if (s == null || dead || state != State.CONNECTED) {
            mainHandler.post { callback(emptyList()) }
            return
        }
        RealVncCore.post {
            val rows = ArrayList<Pair<String, String>>()
            if (!dead && session === s) {
                rows.add(Pair("Engine", "RealVNC viewer core"))
                fun add(label: String, read: () -> String?) {
                    try {
                        val text = read()
                        if (!text.isNullOrEmpty()) rows.add(Pair(label, text))
                    } catch (_: Throwable) {
                    }
                }
                add("Desktop") { ConnectionInfoBindings.getDesktopName(s) }
                add("Protocol") { ConnectionInfoBindings.getProtoVersion(s) }
                add("Connection") { ConnectionInfoBindings.getConnectionType(s) }
                add("Security") { ConnectionInfoBindings.getSecurityDesc(s) }
                add("Encoding") { ConnectionInfoBindings.getLastUsedEncoding(s) }
                add("Line speed") { ConnectionInfoBindings.getLineSpeed(s) }
                add("Server pixels") { ConnectionInfoBindings.getServerPixelFormat(s) }
                add("Viewer pixels") { ConnectionInfoBindings.getViewerPixelFormat(s) }
            }
            mainHandler.post { callback(rows) }
        }
    }

    // =====================================================================================
    // Pixels
    // =====================================================================================

    private fun markDirty(x: Int, y: Int, w: Int, h: Int) {
        if (desktopW <= 0 || desktopH <= 0 || w <= 0 || h <= 0) return
        val x0 = if (x < 0) 0 else x
        val y0 = if (y < 0) 0 else y
        val x1 = if (x + w > desktopW) desktopW else x + w
        val y1 = if (y + h > desktopH) desktopH else y + h
        if (x1 <= x0 || y1 <= y0) return
        val cx0 = x0 / TILE
        val cx1 = (x1 - 1) / TILE
        val cy0 = y0 / TILE
        val cy1 = (y1 - 1) / TILE
        for (cy in cy0..cy1) {
            for (cx in cx0..cx1) {
                dirty[cy * cellsX + cx] = true
            }
        }
        anyDirty = true
    }

    private fun scheduleFlush() {
        if (!flushScheduled) {
            flushScheduled = true
            RealVncCore.postDelayed(flushRunnable, FLUSH_FALLBACK_MS)
        }
    }

    /** Read every dirty 256x256 cell out of the core and paint it into the desktop bitmap. */
    private fun flushDirty() {
        if (!anyDirty) return
        anyDirty = false
        val s = session
        val buf = tileBuffer
        val tile = tileBitmap
        val canvas = desktopCanvas
        if (s == null || dead || buf == null || tile == null || canvas == null) {
            java.util.Arrays.fill(dirty, false)
            return
        }
        for (cy in 0 until cellsY) {
            for (cx in 0 until cellsX) {
                val idx = cy * cellsX + cx
                if (!dirty[idx]) continue
                dirty[idx] = false
                val x = cx * TILE
                val y = cy * TILE
                val w = if (desktopW - x < TILE) desktopW - x else TILE
                val h = if (desktopH - y < TILE) desktopH - y else TILE
                try {
                    // Writes the region to the FRONT of the scratch buffer at the buffer's stride.
                    SessionBindings.copyScaledRegion(s, x, y, w, h, 1f)
                    buf.rewind()
                    tile.copyPixelsFromBuffer(buf)
                    srcRect.set(0, 0, w, h)
                    dstRect.set(x, y, x + w, y + h)
                    canvas.drawBitmap(tile, srcRect, dstRect, copyPaint)
                } catch (t: Throwable) {
                    Log.w(TAG, "copyScaledRegion", t)
                }
            }
        }
    }

    // =====================================================================================
    // DesktopCallback (core thread)
    // =====================================================================================

    override fun connSuccess() {
        Log.i(TAG, "connSuccess")
        RealVncCore.cancel(connectTimeout)
        state = State.CONNECTED
        listener.onStatus("Connected")
    }

    override fun setDesktopSize(width: Int, height: Int) {
        Log.i(TAG, "setDesktopSize ${width}x$height")
        if (width <= 0 || height <= 0) return
        if (width.toLong() * height.toLong() > 80_000_000L) {
            reap(true)
            closed("The remote screen is too large (${width}x$height)")
            return
        }
        val bmp: Bitmap
        try {
            bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        } catch (e: OutOfMemoryError) {
            reap(true)
            closed("Out of memory: the remote screen is too large for this device.")
            return
        }
        // Pixels from the core may carry alpha 0 in the unused byte: treat the bitmap as opaque.
        bmp.setHasAlpha(false)
        bmp.eraseColor(Color.BLACK)
        desktop = bmp
        desktopCanvas = Canvas(bmp)
        desktopW = width
        desktopH = height
        cellsX = (width + TILE - 1) / TILE
        cellsY = (height + TILE - 1) / TILE
        dirty = BooleanArray(cellsX * cellsY)
        anyDirty = false

        var name = ""
        val s = session
        if (s != null) {
            try {
                name = ConnectionInfoBindings.getDesktopName(s) ?: ""
            } catch (_: Throwable) {
            }
        }
        listener.onFramebufferReady(bmp, if (name.isEmpty()) address else name)
        markDirty(0, 0, width, height)
        scheduleFlush()
    }

    override fun drawRegion(x: Int, y: Int, width: Int, height: Int) {
        markDirty(x, y, width, height)
        scheduleFlush()
    }

    override fun framebufferUpdateEnd() {
        RealVncCore.cancel(flushRunnable)
        flushScheduled = false
        flushDirty()
        listener.onFrameUpdated()
    }

    /** The two ints are the NEGATED hotspot (the core rewrites the cursor rect to -hot). */
    override fun setCursor(bitmap: Any?, negHotX: Int, negHotY: Int) {
        val shape = bitmap as? Bitmap
        val copy: Bitmap? = try {
            shape?.copy(Bitmap.Config.ARGB_8888, false)
        } catch (_: Throwable) {
            null
        }
        listener.onCursor(copy, -negHotX, -negHotY)
    }

    override fun bell() {
        listener.onBell()
    }

    override fun getClipboard(): String? = pendingClipboardText

    override fun setClipboard(text: String?) {
        if (!text.isNullOrEmpty()) listener.onServerCutText(text)
    }

    // =====================================================================================
    // SessionCallback (core thread)
    // =====================================================================================

    override fun sessionClosed(ended: SessionBindings.Session?) {
        Log.i(TAG, "sessionClosed")
        val current = session
        if (ended != null && current != null && ended !== current) return
        // Already closed by definition, so do not close it again.
        reap(false)
        closed(null)
    }

    // =====================================================================================
    // Called by RealVncPrompts
    // =====================================================================================

    internal fun ask(prompt: RemotePrompt) {
        RealVncCore.post {
            outstandingPrompts++
            RealVncCore.cancel(connectTimeout)
        }
        listener.onPrompt(prompt)
    }

    internal fun promptAnswered() {
        RealVncCore.post {
            outstandingPrompts = if (outstandingPrompts > 0) outstandingPrompts - 1 else 0
            if (outstandingPrompts == 0 && state == State.CONNECTING && !dead) {
                RealVncCore.postDelayed(connectTimeout, CONNECT_TIMEOUT_MS)
            }
        }
    }

    internal fun status(text: String) {
        Log.i(TAG, "status: $text")
        listener.onStatus(text)
    }

    internal fun reconnecting(message: String) {
        listener.onBanner(message)
    }

    internal fun reconnected() {
        listener.onBanner(null)
    }

    /** Answering the prompt with "remember" is what makes the core send this. */
    internal fun saveIdentity(identity: String) {
        identities(appContext).edit().putString(address, identity).apply()
    }

    // =====================================================================================

    private fun identities(context: Context): SharedPreferences =
        context.getSharedPreferences("realvnc_identities", Context.MODE_PRIVATE)

    private companion object {
        const val TAG = RealVncCore.TAG
        const val TILE = 256
        const val CONNECT_TIMEOUT_MS = 20_000L
        const val FLUSH_FALLBACK_MS = 80L

        /** Low and Custom are the qualities that consult the colour depth. */
        fun colorLevelFor(quality: String): String = if (quality == "Low") "rgb111" else "full"
    }
}
