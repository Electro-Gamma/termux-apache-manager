package com.vncviewer.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vncviewer.app.R
import com.vncviewer.app.data.Engine
import com.vncviewer.app.session.Phase
import com.vncviewer.app.session.Screenshot
import com.vncviewer.app.session.VncSession
import kotlinx.coroutines.delay

private val RowColor get() = com.vncviewer.app.ui.theme.Surface2
private val GapColor get() = com.vncviewer.app.ui.theme.Stroke

private val QUALITIES = listOf("Auto" to "Automatic", "High" to "High", "Medium" to "Medium", "Low" to "Low")

/**
 * What the Information toolbar button / tap region opens: the controls first (picture quality,
 * view only, reconnect), then the live facts, then the pixel formats, then the footer
 * (screenshot, log, disconnect). Same order and look as Vento's connection panel.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConnectionSheet(session: VncSession) {
    val context = LocalContext.current
    var showLog by remember { mutableStateOf(false) }
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    // The line speed and the encoding move on their own while this is open.
    LaunchedEffect(session) {
        while (true) {
            delay(1000)
            session.refreshConnectionInfo()
        }
    }

    run {
        ModalBottomSheet(
            onDismissRequest = { session.closeConnectionInfo() },
            sheetState = state,
            containerColor = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
        ) {
            val facts = remember(session.infoRows) { (session.infoRows ?: emptyList()).toMap() }
            val connected = session.phase == Phase.CONNECTED
            val protocol = if (session.isRealVnc) "VNC (RealVNC)" else "VNC"
            val title = session.desktopName.ifEmpty { facts["Desktop"].orEmpty() }
                .ifEmpty { session.profile.host.ifEmpty { "Remote desktop" } }
            val subtitle = if (connected) {
                buildString {
                    append("Connected \u00B7 ").append(protocol)
                    if (session.fbWidth > 0 && session.fbHeight > 0) {
                        append(" \u00B7 ").append(session.fbWidth).append(" \u00D7 ").append(session.fbHeight)
                    }
                }
            } else {
                session.error ?: session.status
            }

            Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 8.dp)) {
                // Header: the desktop's name, its state and size, and the close button.
                Row(
                    Modifier.fillMaxWidth().heightIn(min = 64.dp)
                        .padding(start = 24.dp, end = 12.dp, top = 8.dp, bottom = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            title, fontSize = 28.sp, lineHeight = 34.sp,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            subtitle, fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                    IconButton(
                        onClick = { session.closeConnectionInfo() },
                        modifier = Modifier.size(48.dp).background(MaterialTheme.colorScheme.surfaceVariant, CircleShape)
                    ) {
                        Icon(
                            painterResource(R.drawable.ic_close_sheet), "Close",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                // Controls.
                Group {
                    if (session.isRealVnc) {
                        ControlRow("Picture quality") {
                            QualityDropdown(session)
                        }
                    }
                    ControlRow("View only") {
                        Switch(checked = session.viewOnly, onCheckedChange = { session.viewOnly = it })
                    }
                    if (session.isRealVnc) {
                        ControlRow("Reconnect automatically") {
                            Switch(
                                checked = session.autoReconnect,
                                onCheckedChange = { session.updateAutoReconnect(it) }
                            )
                        }
                    }
                }

                // Facts.
                val factKeys = listOf("Protocol", "Connection", "Security", "Encoding", "Line speed")
                val factRows = factKeys.filter { !facts[it].isNullOrEmpty() }
                if (factRows.isNotEmpty()) {
                    Spacer(Modifier.size(16.dp))
                    Group {
                        for (k in factRows) FactRow(k, facts[k].orEmpty())
                    }
                }

                // Diagnostics: how a quality change is checked.
                val diag = listOf("Server pixels", "Viewer pixels").filter { !facts[it].isNullOrEmpty() }
                if (diag.isNotEmpty()) {
                    Spacer(Modifier.size(16.dp))
                    Group {
                        for (k in diag) FactRow(k, facts[k].orEmpty(), labelWidth = 120.dp)
                    }
                }

                // Footer: screenshot at the start; log and disconnect/reconnect at the end.
                Row(
                    Modifier.fillMaxWidth().padding(start = 12.dp, end = 16.dp, top = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { Screenshot.share(context, session) }) {
                        Icon(
                            painterResource(R.drawable.ic_screenshot_region), "Screenshot the desktop",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { showLog = true }) { Text("View log", fontSize = 15.sp) }
                    Spacer(Modifier.width(8.dp))
                    FilledTonalButton(onClick = {
                        if (session.phase == Phase.FAILED) {
                            session.closeConnectionInfo()
                            session.reconnect()
                        } else {
                            session.closeConnectionInfo()
                            session.onDisconnectRequest?.invoke()
                        }
                    }) {
                        Text(if (session.phase == Phase.FAILED) "Reconnect" else "Disconnect", fontSize = 15.sp)
                    }
                }
            }
        }

        if (showLog) LogDialog(session) { showLog = false }
    }
}

/** A group of rows held apart by a 2dp gap, with large outer corners. */
@Composable
private fun Group(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.padding(horizontal = 16.dp).fillMaxWidth()
            .clip(RoundedCornerShape(24.dp)).background(GapColor),
        verticalArrangement = Arrangement.spacedBy(2.dp),
        content = content
    )
}

@Composable
private fun ControlRow(label: String, control: @Composable () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(RowColor).heightIn(min = 52.dp)
            .padding(start = 16.dp, end = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label, Modifier.weight(1f), fontSize = 17.sp,
            color = MaterialTheme.colorScheme.onSurface
        )
        control()
    }
}

@Composable
private fun FactRow(label: String, value: String, labelWidth: androidx.compose.ui.unit.Dp = 140.dp) {
    Row(
        Modifier.fillMaxWidth().background(RowColor).heightIn(min = 33.dp)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label, Modifier.width(labelWidth), fontSize = 15.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            value, Modifier.weight(1f), fontSize = 15.sp, textAlign = TextAlign.End,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
private fun QualityDropdown(session: VncSession) {
    var open by remember { mutableStateOf(false) }
    val current = QUALITIES.firstOrNull { it.first == session.quality }?.second ?: session.quality
    Box {
        Row(
            Modifier.clip(RoundedCornerShape(8.dp)).clickable { open = true }.padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(current, fontSize = 17.sp, color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(8.dp))
            val tint = MaterialTheme.colorScheme.primary
            Canvas(Modifier.size(width = 14.dp, height = 8.dp)) {
                val p = Path().apply {
                    moveTo(0f, 0f); lineTo(size.width, 0f); lineTo(size.width / 2f, size.height); close()
                }
                drawPath(p, tint)
            }
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }, containerColor = MaterialTheme.colorScheme.surface) {
            for ((value, label) in QUALITIES) {
                DropdownMenuItem(
                    text = { Text(label) },
                    onClick = {
                        open = false
                        if (value != session.quality) session.setPictureQuality(value)
                    }
                )
            }
        }
    }
}

@Composable
private fun LogDialog(session: VncSession, onClose: () -> Unit) {
    AlertDialog(
        containerColor = androidx.compose.material3.MaterialTheme.colorScheme.surface,
        onDismissRequest = onClose,
        title = { Text("Log") },
        text = {
            Column(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState())) {
                if (session.logLines.isEmpty()) Text("Nothing logged yet.")
                for (line in session.logLines) {
                    Text(line, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Close") } }
    )
}
