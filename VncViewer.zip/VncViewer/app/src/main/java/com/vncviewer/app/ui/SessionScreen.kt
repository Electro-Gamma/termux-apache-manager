package com.vncviewer.app.ui

import android.content.Context
import android.view.inputmethod.InputMethodManager
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.vncviewer.app.session.MouseMode
import com.vncviewer.app.session.Phase
import com.vncviewer.app.session.VncSession
import com.vncviewer.app.vnc.CredentialsPrompt
import com.vncviewer.app.vnc.Keysyms
import com.vncviewer.app.vnc.MessagePrompt
import com.vncviewer.app.vnc.MessageSeverity
import com.vncviewer.app.vnc.RemotePrompt
import com.vncviewer.app.vnc.TrustEncryption
import com.vncviewer.app.vnc.TrustIdentity
import com.vncviewer.app.vnc.TrustPrompt
import kotlinx.coroutines.delay

@Composable
fun SessionScreen(vm: VncViewModel) {
    val session = vm.activeSession
    if (session == null) {
        LaunchedEffect(Unit) { vm.screen = Screen.LIST }
        return
    }
    val fullscreen = vm.fullscreen
    val connected = session.phase == Phase.CONNECTED

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        if (!fullscreen) {
            SessionTabs(vm)
            SessionToolbar(vm, session)
        }
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            key(session.id) {
                RemoteCanvas(session)
                KeyCaptureHost(session)
            }

            when (session.phase) {
                Phase.CONNECTING -> ConnectingOverlay(vm, session)
                Phase.FAILED -> FailedOverlay(vm, session)
                Phase.AUTH_REQUIRED -> PasswordDialog(vm, session)
                Phase.CONNECTED -> {}
            }

            val banner = session.banner
            if (banner != null) {
                Surface(
                    color = Color(0xE6E3B341),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(12.dp)
                ) {
                    Text(
                        text = banner,
                        color = Color.Black,
                        style = MaterialTheme.typography.labelLarge,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                    )
                }
            }

            val prompt = session.prompts.firstOrNull()
            if (prompt != null) {
                PromptDialog(vm, session, prompt)
            }
            if (session.infoRows != null) {
                InfoDialog(session)
            }

            if (fullscreen) {
                FullscreenControls(vm, session, Modifier.align(Alignment.TopEnd))
            }

            val notice = session.notice
            if (notice != null) {
                LaunchedEffect(notice) {
                    delay(2400)
                    if (session.notice == notice) session.notice = null
                }
                Surface(
                    color = Color(0xE6212833),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(16.dp)
                ) {
                    Text(
                        text = notice,
                        color = Color.White,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }
            }
        }
        if (session.showDock && connected) {
            KeyDock(session)
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Chips / small building blocks
// ---------------------------------------------------------------------------------------------

@Composable
fun ToolChip(label: String, selected: Boolean = false, compact: Boolean = false, onClick: () -> Unit) {
    Surface(
        color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
        contentColor = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            maxLines = 1,
            modifier = Modifier.padding(
                horizontal = if (compact) 10.dp else 12.dp,
                vertical = if (compact) 6.dp else 8.dp
            )
        )
    }
}

@Composable
private fun SessionTabs(vm: VncViewModel) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .horizontalScroll(rememberScrollState())
            .padding(6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ToolChip("\u2039 Connections") { vm.screen = Screen.LIST }
        for (s in vm.sessions) {
            val selected = s.id == vm.activeSessionId
            Surface(
                color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.clickable { vm.activeSessionId = s.id }
            ) {
                Row(
                    modifier = Modifier.padding(start = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val dot = when (s.phase) {
                        Phase.CONNECTED -> Color(0xFF6FD6A0)
                        Phase.CONNECTING -> Color(0xFFE3B341)
                        else -> Color(0xFFFF7B72)
                    }
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(dot, RoundedCornerShape(4.dp))
                    )
                    Text(
                        text = (if (s.isRealVnc) "RV \u00B7 " else "") + s.title,
                        style = MaterialTheme.typography.labelLarge,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(start = 8.dp)
                    )
                    Text(
                        text = "\u00D7",
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier
                            .clickable { vm.closeSession(s.id) }
                            .padding(horizontal = 12.dp, vertical = 4.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun SessionToolbar(vm: VncViewModel, session: VncSession) {
    val view = LocalView.current
    var clickMenu by remember { mutableStateOf(false) }
    var moreMenu by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .horizontalScroll(rememberScrollState())
            .padding(start = 6.dp, end = 6.dp, bottom = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ToolChip("Keyboard") {
            val visible = ViewCompat.getRootWindowInsets(view)
                ?.isVisible(WindowInsetsCompat.Type.ime()) == true
            session.requestIme(!visible)
        }
        ToolChip("Keys", session.showDock) { session.showDock = !session.showDock }
        ToolChip("Mouse: " + session.mouseMode.label) {
            session.mouseMode = if (session.mouseMode == MouseMode.TOUCH) MouseMode.TRACKPAD else MouseMode.TOUCH
        }
        ToolChip("View: " + session.scaleMode.label) { session.cycleScaleMode() }
        ToolChip("Pan", session.panDragMode) { session.panDragMode = !session.panDragMode }

        Box {
            ToolChip("Click\u2026") { clickMenu = true }
            DropdownMenu(expanded = clickMenu, onDismissRequest = { clickMenu = false }) {
                DropdownMenuItem(text = { Text("Left click") }, onClick = { clickMenu = false; session.click(1) })
                DropdownMenuItem(text = { Text("Double click") }, onClick = { clickMenu = false; session.doubleClick() })
                DropdownMenuItem(text = { Text("Right click") }, onClick = { clickMenu = false; session.click(4) })
                DropdownMenuItem(text = { Text("Middle click") }, onClick = { clickMenu = false; session.click(2) })
            }
        }

        ToolChip("Fullscreen") { vm.fullscreen = true }

        Box {
            ToolChip("More\u2026") { moreMenu = true }
            DropdownMenu(expanded = moreMenu, onDismissRequest = { moreMenu = false }) {
                DropdownMenuItem(
                    text = { Text("Send Ctrl+Alt+Del") },
                    onClick = {
                        moreMenu = false
                        session.keyCombo(Keysyms.CONTROL_L, Keysyms.ALT_L, Keysyms.DELETE)
                    }
                )
                DropdownMenuItem(text = { Text("Refresh screen") }, onClick = { moreMenu = false; session.refresh() })
                DropdownMenuItem(
                    text = { Text("Connection info") },
                    onClick = { moreMenu = false; session.showConnectionInfo() }
                )
                if (session.isRealVnc) {
                    DropdownMenuItem(
                        text = { Text("Picture quality: " + session.quality + " (tap to change)") },
                        onClick = { session.cycleQuality() }
                    )
                }
                DropdownMenuItem(text = { Text("Reset zoom") }, onClick = { moreMenu = false; session.resetViewport() })
                DropdownMenuItem(
                    text = { Text("Send phone clipboard to remote") },
                    onClick = { moreMenu = false; session.sendClipboardToRemote() }
                )
                DropdownMenuItem(
                    text = { Text("Type phone clipboard") },
                    onClick = { moreMenu = false; session.typeClipboard() }
                )
                DropdownMenuItem(
                    text = { Text(if (session.viewOnly) "View only: ON (tap to allow input)" else "View only: off") },
                    onClick = { moreMenu = false; session.viewOnly = !session.viewOnly }
                )
                if (!vm.isSaved(session.profile.id)) {
                    DropdownMenuItem(
                        text = { Text("Save connection") },
                        onClick = { moreMenu = false; vm.saveSessionAsProfile(session) }
                    )
                }
                DropdownMenuItem(
                    text = { Text("Disconnect") },
                    onClick = { moreMenu = false; vm.closeSession(session.id) }
                )
            }
        }
    }
}

@Composable
private fun KeyDock(session: VncSession) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .horizontalScroll(rememberScrollState())
            .padding(6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ToolChip("Esc", compact = true) { session.tapKey(Keysyms.ESCAPE) }
        ToolChip("Tab", compact = true) { session.tapKey(Keysyms.TAB) }
        ToolChip("Ctrl", session.ctrl, compact = true) { session.toggleCtrl() }
        ToolChip("Alt", session.alt, compact = true) { session.toggleAlt() }
        ToolChip("Shift", session.shift, compact = true) { session.toggleShift() }
        ToolChip("Win", session.meta, compact = true) { session.toggleMeta() }
        ToolChip("\u2190", compact = true) { session.tapKey(Keysyms.LEFT) }
        ToolChip("\u2191", compact = true) { session.tapKey(Keysyms.UP) }
        ToolChip("\u2193", compact = true) { session.tapKey(Keysyms.DOWN) }
        ToolChip("\u2192", compact = true) { session.tapKey(Keysyms.RIGHT) }
        ToolChip("Home", compact = true) { session.tapKey(Keysyms.HOME) }
        ToolChip("End", compact = true) { session.tapKey(Keysyms.END) }
        ToolChip("PgUp", compact = true) { session.tapKey(Keysyms.PAGE_UP) }
        ToolChip("PgDn", compact = true) { session.tapKey(Keysyms.PAGE_DOWN) }
        ToolChip("Del", compact = true) { session.tapKey(Keysyms.DELETE) }
        ToolChip("Ins", compact = true) { session.tapKey(Keysyms.INSERT) }
        ToolChip("Ctrl+Alt+Del", compact = true) {
            session.keyCombo(Keysyms.CONTROL_L, Keysyms.ALT_L, Keysyms.DELETE)
        }
        for (n in 1..12) {
            ToolChip("F$n", compact = true) { session.tapKey(Keysyms.functionKey(n)) }
        }
    }
}

@Composable
private fun FullscreenControls(vm: VncViewModel, session: VncSession, modifier: Modifier) {
    var expanded by remember { mutableStateOf(false) }
    Row(
        modifier = modifier.padding(8.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (expanded) {
            val view = LocalView.current
            ToolChip("Keyboard", compact = true) {
                val visible = ViewCompat.getRootWindowInsets(view)
                    ?.isVisible(WindowInsetsCompat.Type.ime()) == true
                session.requestIme(!visible)
            }
            ToolChip("Keys", session.showDock, compact = true) { session.showDock = !session.showDock }
            ToolChip("Exit fullscreen", compact = true) { vm.fullscreen = false }
        }
        Surface(
            color = Color(0x99212833),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.clickable { expanded = !expanded }
        ) {
            Text(
                text = if (expanded) "Hide" else "Menu",
                color = Color.White,
                style = MaterialTheme.typography.labelMedium,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
            )
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Overlays and dialogs
// ---------------------------------------------------------------------------------------------

@Composable
private fun ConnectingOverlay(vm: VncViewModel, session: VncSession) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xCC000000)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.padding(24.dp)
        ) {
            CircularProgressIndicator()
            Text(session.title, style = MaterialTheme.typography.titleMedium, color = Color.White)
            Text(session.status, style = MaterialTheme.typography.bodyMedium, color = Color(0xFF9DA7B3))
            TextButton(onClick = { vm.closeSession(session.id) }) { Text("Cancel") }
        }
    }
}

@Composable
private fun FailedOverlay(vm: VncViewModel, session: VncSession) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xCC000000)),
        contentAlignment = Alignment.Center
    ) {
        Card(modifier = Modifier.padding(24.dp)) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Disconnected", style = MaterialTheme.typography.titleMedium)
                Text(
                    session.error ?: "The connection ended.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = { session.reconnect() }) { Text("Reconnect") }
                    TextButton(onClick = { vm.closeSession(session.id) }) { Text("Close") }
                }
            }
        }
    }
}

@Composable
private fun PasswordDialog(vm: VncViewModel, session: VncSession) {
    var password by remember { mutableStateOf("") }
    var save by remember { mutableStateOf(true) }
    AlertDialog(
        onDismissRequest = { vm.closeSession(session.id) },
        title = { Text("VNC password") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = if (session.passwordRejected) {
                        "That password was rejected. Try again."
                    } else {
                        session.title + " requires a password."
                    },
                    color = if (session.passwordRejected) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                )
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    singleLine = true,
                    label = { Text("Password") },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                )
                if (vm.isSaved(session.profile.id)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = save, onCheckedChange = { save = it })
                        Text("Remember password")
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { vm.submitPassword(session, password, save) }) { Text("Connect") }
        },
        dismissButton = {
            TextButton(onClick = { vm.closeSession(session.id) }) { Text("Cancel") }
        }
    )
}

// ---------------------------------------------------------------------------------------------
// Soft keyboard host
// ---------------------------------------------------------------------------------------------

@Composable
private fun KeyCaptureHost(session: VncSession) {
    val context = LocalContext.current
    val holder = remember { arrayOfNulls<KeyCaptureView>(1) }

    AndroidView(
        factory = { ctx ->
            val v = KeyCaptureView(ctx)
            holder[0] = v
            v
        },
        update = { v ->
            v.textSink = { text -> session.imeText(text) }
            v.keySink = { event -> session.onKeyEvent(event) }
        },
        modifier = Modifier.size(1.dp)
    )

    LaunchedEffect(session.imeCommandTick) {
        if (session.imeCommandTick == 0) return@LaunchedEffect
        delay(60)
        val v = holder[0] ?: return@LaunchedEffect
        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        if (session.imeCommandShow) {
            v.requestFocus()
            imm.restartInput(v)
            imm.showSoftInput(v, InputMethodManager.SHOW_IMPLICIT)
        } else {
            imm.hideSoftInputFromWindow(v.windowToken, 0)
        }
    }
}


// ---------------------------------------------------------------------------------------------
// RealVNC engine prompts and connection info
// ---------------------------------------------------------------------------------------------

@Composable
private fun PromptDialog(vm: VncViewModel, session: VncSession, prompt: RemotePrompt) {
    when (prompt) {
        is CredentialsPrompt -> CredentialsDialog(vm, session, prompt)
        is TrustPrompt -> TrustDialog(session, prompt)
        is MessagePrompt -> MessageDialog(session, prompt)
    }
}

@Composable
private fun CredentialsDialog(vm: VncViewModel, session: VncSession, p: CredentialsPrompt) {
    var user by remember(p) { mutableStateOf(p.userName.ifEmpty { session.profile.userName }) }
    var pass by remember(p) { mutableStateOf("") }
    var save by remember(p) { mutableStateOf(true) }
    AlertDialog(
        onDismissRequest = {
            p.cancel()
            session.dismissPrompt(p)
        },
        title = { Text("Sign in") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (p.serverName.isNotEmpty()) Text(p.serverName, style = MaterialTheme.typography.titleSmall)
                if (p.instructions.isNotEmpty()) Text(p.instructions, style = MaterialTheme.typography.bodyMedium)
                if (p.askUserName) {
                    OutlinedTextField(
                        value = user,
                        onValueChange = { user = it },
                        singleLine = true,
                        label = { Text("User name") }
                    )
                }
                if (p.askPassword) {
                    OutlinedTextField(
                        value = pass,
                        onValueChange = { pass = it },
                        singleLine = true,
                        label = { Text("Password") },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                    )
                }
                if (p.catchphrase.isNotEmpty()) {
                    Text(
                        "Catchphrase: " + p.catchphrase,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (vm.isSaved(session.profile.id)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = save, onCheckedChange = { save = it })
                        Text("Remember")
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (save) vm.rememberCredentials(session, user, pass)
                p.answer(true, if (p.askUserName) user else null, if (p.askPassword) pass else null)
                session.dismissPrompt(p)
            }) { Text("Sign in") }
        },
        dismissButton = {
            TextButton(onClick = {
                p.cancel()
                session.dismissPrompt(p)
            }) { Text("Cancel") }
        }
    )
}

@Composable
private fun TrustDialog(session: VncSession, p: TrustPrompt) {
    var rememberServer by remember(p) { mutableStateOf(p.identity == TrustIdentity.NEW) }
    val identityText = when (p.identity) {
        TrustIdentity.OK -> "This server's identity matches one you accepted before."
        TrustIdentity.NEW ->
            "You have not connected to this server before. Check that the catchphrase below matches the one the server shows."
        TrustIdentity.MATCHES_ANOTHER -> "This identity is already known as \"" + p.matchingName + "\"."
        TrustIdentity.CHANGED ->
            "WARNING: this server's identity has CHANGED since you last connected. Someone may be impersonating it. Only continue if you expected this."
        TrustIdentity.MISSING -> "The server did not provide an identity, so it cannot be verified."
        TrustIdentity.PRESHARED -> "Authenticated with a pre-shared key."
        TrustIdentity.ARD -> "Apple Remote Desktop authentication."
    }
    val encryptionText = when (p.encryption) {
        TrustEncryption.ENCRYPTED -> "The connection is encrypted."
        TrustEncryption.UNENCRYPTED_WARN ->
            "WARNING: the connection is NOT encrypted. Anyone on the network could read your screen and password."
        TrustEncryption.UNENCRYPTED_QUIET -> "The connection is not encrypted."
    }
    val danger = p.identity == TrustIdentity.CHANGED || p.encryption == TrustEncryption.UNENCRYPTED_WARN
    AlertDialog(
        onDismissRequest = {
            p.cancel()
            session.dismissPrompt(p)
        },
        title = { Text("Verify server") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (p.serverName.isNotEmpty()) Text(p.serverName, style = MaterialTheme.typography.titleSmall)
                Text(
                    identityText,
                    color = if (p.identity == TrustIdentity.CHANGED) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                )
                Text(
                    encryptionText,
                    color = if (p.encryption == TrustEncryption.UNENCRYPTED_WARN) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                )
                if (p.catchphrase.isNotEmpty()) Text("Catchphrase: " + p.catchphrase, style = MaterialTheme.typography.bodyMedium)
                if (p.signature.isNotEmpty()) {
                    Text(
                        "Signature: " + p.signature,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = rememberServer, onCheckedChange = { rememberServer = it })
                    Text("Remember this server")
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                p.answer(true, rememberServer)
                session.dismissPrompt(p)
            }) { Text(if (danger) "Continue anyway" else "Continue") }
        },
        dismissButton = {
            TextButton(onClick = {
                p.cancel()
                session.dismissPrompt(p)
            }) { Text("Cancel") }
        }
    )
}

@Composable
private fun MessageDialog(session: VncSession, p: MessagePrompt) {
    val title = when (p.severity) {
        MessageSeverity.ERROR -> "Error"
        MessageSeverity.WARNING -> "Warning"
        MessageSeverity.QUESTION -> "Question"
        MessageSeverity.INFORMATION -> "Message"
    }
    val positive = p.customButton ?: if (p.yesNo) "Yes" else "OK"
    AlertDialog(
        onDismissRequest = {
            p.cancel()
            session.dismissPrompt(p)
        },
        title = { Text(title) },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                if (p.serverName.isNotEmpty()) {
                    Text(p.serverName, style = MaterialTheme.typography.titleSmall)
                }
                Text(p.message)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                p.answer(true)
                session.dismissPrompt(p)
            }) { Text(positive) }
        },
        dismissButton = {
            if (p.isQuestion) {
                TextButton(onClick = {
                    p.answer(false)
                    session.dismissPrompt(p)
                }) { Text(if (p.yesNo) "No" else "Cancel") }
            }
        }
    )
}

@Composable
private fun InfoDialog(session: VncSession) {
    val rows = session.infoRows ?: return
    AlertDialog(
        onDismissRequest = { session.infoRows = null },
        title = { Text("Connection info") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (rows.isEmpty()) {
                    Text("Not connected.")
                }
                for (row in rows) {
                    Column {
                        Text(
                            row.first,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(row.second, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { session.infoRows = null }) { Text("Close") } }
    )
}
