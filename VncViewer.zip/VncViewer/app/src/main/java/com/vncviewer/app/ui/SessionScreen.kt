package com.vncviewer.app.ui

import android.content.Context
import android.view.HapticFeedbackConstants
import android.view.inputmethod.InputMethodManager
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.vncviewer.app.input.AppSettings
import com.vncviewer.app.input.InputSettings
import com.vncviewer.app.session.MouseMode
import com.vncviewer.app.session.Phase
import com.vncviewer.app.session.VncSession
import com.vncviewer.app.vnc.CredentialsPrompt
import com.vncviewer.app.vnc.Keysyms
import com.vncviewer.app.vnc.MessagePrompt
import com.vncviewer.app.vnc.MessageSeverity
import com.vncviewer.app.vnc.RemotePrompt
import com.vncviewer.app.vnc.TrustEncryption
import com.vncviewer.app.vnc.TrustIdentity
import com.vncviewer.app.vnc.TrustPrompt
import kotlinx.coroutines.delay

@Composable
fun SessionScreen(vm: VncViewModel) {
    val session = vm.activeSession
    if (session == null) {
        LaunchedEffect(Unit) { vm.screen = Screen.LIST }
        return
    }
    val fullscreen = vm.fullscreen
    val connected = session.phase == Phase.CONNECTED
    val ctx = LocalContext.current
    val solidInfo = InputSettings.solidInfo(ctx)

    // Preferences changed in Settings reach a session that is already running.
    LaunchedEffect(AppSettings.changeTick.intValue) {
        session.input.applySettings()
    }
    // The first frame explains the session controls (and offers the choice), unless told not to.
    LaunchedEffect(session.firstFrame) {
        if (session.firstFrame && !session.hintsHandled) {
            session.hintsHandled = true
            if (AppSettings.regionHints(ctx)) session.showHints = true
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        if (!fullscreen) {
            SessionTabs(vm)
            SessionToolbar(vm, session)
        }
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            key(session.id) {
                RemoteCanvas(session)
                KeyCaptureHost(session)
            }

            when (session.phase) {
                Phase.CONNECTING -> ConnectingOverlay(vm, session)
                Phase.FAILED -> FailedOverlay(vm, session)
                Phase.AUTH_REQUIRED -> PasswordDialog(vm, session)
                Phase.CONNECTED -> {}
            }

            val banner = session.banner
            if (banner != null) {
                Surface(
                    color = Color(0xE6E3B341),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(12.dp)
                ) {
                    Text(
                        text = banner,
                        color = Color.Black,
                        style = MaterialTheme.typography.labelLarge,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                    )
                }
            }

            if (session.showDock && connected && !solidInfo) {
                InfoBar(session, Modifier.align(Alignment.BottomCenter))
            }
            if (session.showHints) {
                ControlsDialog(session)
            }

            val prompt = session.prompts.firstOrNull()
            if (prompt != null) {
                PromptDialog(vm, session, prompt)
            }
            if (session.infoOpen) {
                ConnectionSheet(session)
            }

            if (fullscreen) {
                FullscreenControls(vm, session, Modifier.align(Alignment.TopEnd))
            }

            val notice = session.notice
            if (notice != null) {
                LaunchedEffect(notice) {
                    delay(2400)
                    if (session.notice == notice) session.notice = null
                }
                Surface(
                    color = Color(0xE6212833),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(16.dp)
                ) {
                    Text(
                        text = notice,
                        color = Color.White,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }
            }
        }
        if (session.showDock && connected) {
            if (solidInfo) InfoBar(session)
            KeyDock(session)
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Chips / small building blocks
// ---------------------------------------------------------------------------------------------

@Composable
fun ToolChip(label: String, selected: Boolean = false, compact: Boolean = false, onClick: () -> Unit) {
    Surface(
        color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
        contentColor = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            maxLines = 1,
            modifier = Modifier.padding(
                horizontal = if (compact) 10.dp else 12.dp,
                vertical = if (compact) 6.dp else 8.dp
            )
        )
    }
}

@Composable
private fun SessionTabs(vm: VncViewModel) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .horizontalScroll(rememberScrollState())
            .padding(6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ToolChip("\u2039 Connections") { vm.screen = Screen.LIST }
        for (s in vm.sessions) {
            val selected = s.id == vm.activeSessionId
            Surface(
                color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.clickable { vm.activeSessionId = s.id }
            ) {
                Row(
                    modifier = Modifier.padding(start = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val dot = when (s.phase) {
                        Phase.CONNECTED -> Color(0xFF6FD6A0)
                        Phase.CONNECTING -> Color(0xFFE3B341)
                        else -> Color(0xFFFF7B72)
                    }
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(dot, RoundedCornerShape(4.dp))
                    )
                    Text(
                        text = (if (s.isRealVnc) "RV \u00B7 " else "") + s.title,
                        style = MaterialTheme.typography.labelLarge,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(start = 8.dp)
                    )
                    Text(
                        text = "\u00D7",
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier
                            .clickable { vm.closeSession(s.id) }
                            .padding(horizontal = 12.dp, vertical = 4.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun SessionToolbar(vm: VncViewModel, session: VncSession) {
    val view = LocalView.current
    var clickMenu by remember { mutableStateOf(false) }
    var moreMenu by remember { mutableStateOf(false) }
    // Reading the tick keeps the "Buttons" chip in step with the overlay.
    val overlayOn = session.inputTick >= 0 && session.input.overlay.visible()

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .horizontalScroll(rememberScrollState())
            .padding(start = 6.dp, end = 6.dp, bottom = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ToolChip("Keyboard") {
            val visible = ViewCompat.getRootWindowInsets(view)
                ?.isVisible(WindowInsetsCompat.Type.ime()) == true
            session.requestIme(!visible)
        }
        ToolChip("Keys", session.showDock) { session.showDock = !session.showDock }
        ToolChip("Mouse: " + session.mouseMode.label) {
            session.input.suspendInput()
            session.mouseMode = if (session.mouseMode == MouseMode.TOUCHPAD) MouseMode.DIRECT else MouseMode.TOUCHPAD
        }
        ToolChip("Buttons", overlayOn) { session.input.toggleOverlay() }
        ToolChip("View: " + session.scaleMode.label) { session.cycleScaleMode() }
        if (session.mouseMode == MouseMode.DIRECT) {
            ToolChip("Pan", session.panDragMode) { session.panDragMode = !session.panDragMode }
        }

        Box {
            ToolChip("Click\u2026") { clickMenu = true }
            DropdownMenu(expanded = clickMenu, onDismissRequest = { clickMenu = false }) {
                DropdownMenuItem(text = { Text("Left click") }, onClick = { clickMenu = false; session.click(1) })
                DropdownMenuItem(text = { Text("Double click") }, onClick = { clickMenu = false; session.doubleClick() })
                DropdownMenuItem(text = { Text("Right click") }, onClick = { clickMenu = false; session.click(4) })
                DropdownMenuItem(text = { Text("Middle click") }, onClick = { clickMenu = false; session.click(2) })
            }
        }

        ToolChip("Fullscreen") { vm.fullscreen = true }

        Box {
            ToolChip("More\u2026") { moreMenu = true }
            DropdownMenu(expanded = moreMenu, onDismissRequest = { moreMenu = false }) {
                DropdownMenuItem(
                    text = { Text("Send Ctrl+Alt+Del") },
                    onClick = {
                        moreMenu = false
                        session.keyCombo(Keysyms.CONTROL_L, Keysyms.ALT_L, Keysyms.DELETE)
                    }
                )
                DropdownMenuItem(text = { Text("Refresh screen") }, onClick = { moreMenu = false; session.refresh() })
                DropdownMenuItem(
                    text = { Text("Connection info") },
                    onClick = { moreMenu = false; session.showConnectionInfo() }
                )
                if (session.isRealVnc) {
                    DropdownMenuItem(
                        text = { Text("Picture quality: " + session.quality + " (tap to change)") },
                        onClick = { session.cycleQuality() }
                    )
                }
                DropdownMenuItem(text = { Text("Reset zoom") }, onClick = { moreMenu = false; session.resetViewport() })
                DropdownMenuItem(
                    text = { Text("Send phone clipboard to remote") },
                    onClick = { moreMenu = false; session.sendClipboardToRemote() }
                )
                DropdownMenuItem(
                    text = { Text("Type phone clipboard") },
                    onClick = { moreMenu = false; session.typeClipboard() }
                )
                DropdownMenuItem(
                    text = { Text(if (session.viewOnly) "View only: ON (tap to allow input)" else "View only: off") },
                    onClick = { moreMenu = false; session.viewOnly = !session.viewOnly }
                )
                if (!vm.isSaved(session.profile.id)) {
                    DropdownMenuItem(
                        text = { Text("Save connection") },
                        onClick = { moreMenu = false; vm.saveSessionAsProfile(session) }
                    )
                }
                DropdownMenuItem(
                    text = { Text("Settings") },
                    onClick = { moreMenu = false; vm.openSettings() }
                )
                DropdownMenuItem(
                    text = { Text("Disconnect") },
                    onClick = { moreMenu = false; vm.closeSession(session.id) }
                )
            }
        }
    }
}

private class DockKey(
    val label: String,
    val group: Int,
    val row: Int,
    val modifier: Boolean = false,
    val isOn: (VncSession) -> Boolean = { false },
    val action: (VncSession) -> Unit
)

/** Vento's extension keyboard keys, key for key (labels and grouping are RealVNC's). */
private fun dockKeys(twoLine: Boolean, mac: Boolean): List<DockKey> {
    val k = ArrayList<DockKey>()
    fun tap(sym: Int): (VncSession) -> Unit = { s -> s.tapKey(sym) }
    val modRow = if (twoLine) 1 else 0
    k.add(DockKey("Shift", 0, modRow, true, { s -> s.shift }, { s -> s.toggleShift() }))
    k.add(DockKey("Ctrl", 0, modRow, true, { s -> s.ctrl }, { s -> s.toggleCtrl() }))
    k.add(DockKey("Alt", 0, modRow, true, { s -> s.alt }, { s -> s.toggleAlt() }))
    k.add(DockKey("Windows", 0, modRow, true, { s -> s.meta }, { s -> s.toggleMeta() }))
    if (mac) {
        k.add(DockKey("Option", 0, modRow, true, { s -> s.option }, { s -> s.toggleOption() }))
        k.add(DockKey("CMD", 0, modRow, true, { s -> s.cmd }, { s -> s.toggleCmd() }))
    }
    if (!twoLine) {
        k.add(DockKey("Backspace", 1, 0, action = tap(Keysyms.BACKSPACE)))
        k.add(DockKey("Del", 1, 0, action = tap(Keysyms.DELETE)))
        k.add(DockKey("Esc", 1, 0, action = tap(Keysyms.ESCAPE)))
        k.add(DockKey("Tab", 1, 0, action = tap(Keysyms.TAB)))
        k.add(DockKey("Ins", 1, 0, action = tap(Keysyms.INSERT)))
        k.add(DockKey("Enter", 2, 0, action = tap(Keysyms.RETURN)))
        k.add(DockKey("\u2191", 3, 0, action = tap(Keysyms.UP)))
        k.add(DockKey("\u2193", 3, 0, action = tap(Keysyms.DOWN)))
        k.add(DockKey("\u2190", 3, 0, action = tap(Keysyms.LEFT)))
        k.add(DockKey("\u2192", 3, 0, action = tap(Keysyms.RIGHT)))
        k.add(DockKey("Paste", 4, 0, action = { s -> s.typeClipboard() }))
        k.add(DockKey("Home", 5, 0, action = tap(Keysyms.HOME)))
        k.add(DockKey("End", 5, 0, action = tap(Keysyms.END)))
        k.add(DockKey("Page Up", 5, 0, action = tap(Keysyms.PAGE_UP)))
        k.add(DockKey("Page Down", 5, 0, action = tap(Keysyms.PAGE_DOWN)))
        for (n in 1..12) k.add(DockKey("F$n", 6, 0, action = tap(Keysyms.functionKey(n))))
    } else {
        k.add(DockKey("Backspace", 1, 0, action = tap(Keysyms.BACKSPACE)))
        k.add(DockKey("Del", 1, 0, action = tap(Keysyms.DELETE)))
        k.add(DockKey("Esc", 1, 0, action = tap(Keysyms.ESCAPE)))
        k.add(DockKey("Tab", 1, 0, action = tap(Keysyms.TAB)))
        k.add(DockKey("Ins", 1, 0, action = tap(Keysyms.INSERT)))
        k.add(DockKey("Home", 2, 0, action = tap(Keysyms.HOME)))
        k.add(DockKey("\u2191", 2, 0, action = tap(Keysyms.UP)))
        k.add(DockKey("End", 2, 0, action = tap(Keysyms.END)))
        k.add(DockKey("\u2190", 2, 1, action = tap(Keysyms.LEFT)))
        k.add(DockKey("\u2193", 2, 1, action = tap(Keysyms.DOWN)))
        k.add(DockKey("\u2192", 2, 1, action = tap(Keysyms.RIGHT)))
        k.add(DockKey("PgUp", 3, 0, action = tap(Keysyms.PAGE_UP)))
        k.add(DockKey("PgDn", 3, 1, action = tap(Keysyms.PAGE_DOWN)))
        k.add(DockKey("Paste", 4, 0, action = { s -> s.typeClipboard() }))
        k.add(DockKey("Enter", 4, 1, action = tap(Keysyms.RETURN)))
        for (n in 1..12) k.add(DockKey("F$n", 5, if (n <= 6) 0 else 1, action = tap(Keysyms.functionKey(n))))
    }
    return k
}

@Composable
private fun KeyDock(session: VncSession) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val twoLine = AppSettings.twoLineKeys(ctx)
    val mac = AppSettings.macKeys(ctx)
    val resets = AppSettings.modifierResetsIme(ctx)
    val keys = remember(twoLine, mac) { dockKeys(twoLine, mac) }
    val rows = if (twoLine) 2 else 1

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .horizontalScroll(rememberScrollState())
            .padding(6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        for (r in 0 until rows) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                var lastGroup = -1
                for (k in keys) {
                    if (k.row != r) continue
                    if (lastGroup != -1 && k.group != lastGroup) Spacer(Modifier.width(14.dp))
                    lastGroup = k.group
                    ToolChip(k.label, k.isOn(session), compact = true) {
                        if (session.input.cfg.keyboardHaptics) {
                            view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                        }
                        k.action(session)
                        // RealVNC's viewer: pressing a modifier sends the soft keyboard back to its letters.
                        if (k.modifier && resets) session.imeRestartTick = session.imeRestartTick + 1
                    }
                }
            }
        }
    }
}

/** The extension keyboard's info bar: armed modifiers and the line being typed. */
@Composable
private fun InfoBar(session: VncSession, modifier: Modifier = Modifier) {
    val mods = session.heldModifiersText()
    val line = session.typedLine
    Surface(
        color = MaterialTheme.colorScheme.surface,
        modifier = modifier.fillMaxWidth()
    ) {
        Text(
            text = (if (mods.isEmpty()) "" else "$mods  ") + (if (line.length > 60) "\u2026" + line.takeLast(60) else line),
            style = MaterialTheme.typography.bodySmall,
            maxLines = 1,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
        )
    }
}

@Composable
private fun FullscreenControls(vm: VncViewModel, session: VncSession, modifier: Modifier) {
    var expanded by remember { mutableStateOf(false) }
    Row(
        modifier = modifier.padding(8.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (expanded) {
            val view = LocalView.current
            ToolChip("Keyboard", compact = true) {
                val visible = ViewCompat.getRootWindowInsets(view)
                    ?.isVisible(WindowInsetsCompat.Type.ime()) == true
                session.requestIme(!visible)
            }
            ToolChip("Keys", session.showDock, compact = true) { session.showDock = !session.showDock }
            ToolChip("Exit fullscreen", compact = true) { vm.fullscreen = false }
        }
        Surface(
            color = Color(0x99212833),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.clickable { expanded = !expanded }
        ) {
            Text(
                text = if (expanded) "Hide" else "Menu",
                color = Color.White,
                style = MaterialTheme.typography.labelMedium,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
            )
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Overlays and dialogs
// ---------------------------------------------------------------------------------------------

@Composable
private fun ConnectingOverlay(vm: VncViewModel, session: VncSession) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xCC000000)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.padding(24.dp)
        ) {
            CircularProgressIndicator()
            Text(session.title, style = MaterialTheme.typography.titleMedium, color = Color.White)
            Text(session.status, style = MaterialTheme.typography.bodyMedium, color = Color(0xFF9DA7B3))
            TextButton(onClick = { vm.closeSession(session.id) }) { Text("Cancel") }
        }
    }
}

@Composable
private fun FailedOverlay(vm: VncViewModel, session: VncSession) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xCC000000)),
        contentAlignment = Alignment.Center
    ) {
        Card(modifier = Modifier.padding(24.dp)) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Disconnected", style = MaterialTheme.typography.titleMedium)
                Text(
                    session.error ?: "The connection ended.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = { session.reconnect() }) { Text("Reconnect") }
                    TextButton(onClick = { vm.closeSession(session.id) }) { Text("Close") }
                }
            }
        }
    }
}

@Composable
private fun PasswordDialog(vm: VncViewModel, session: VncSession) {
    var password by remember { mutableStateOf("") }
    var save by remember { mutableStateOf(true) }
    AlertDialog(
        onDismissRequest = { vm.closeSession(session.id) },
        title = { Text("VNC password") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = if (session.passwordRejected) {
                        "That password was rejected. Try again."
                    } else {
                        session.title + " requires a password."
                    },
                    color = if (session.passwordRejected) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                )
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    singleLine = true,
                    label = { Text("Password") },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                )
                if (vm.isSaved(session.profile.id)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = save, onCheckedChange = { save = it })
                        Text("Remember password")
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { vm.submitPassword(session, password, save) }) { Text("Connect") }
        },
        dismissButton = {
            TextButton(onClick = { vm.closeSession(session.id) }) { Text("Cancel") }
        }
    )
}

// ---------------------------------------------------------------------------------------------
// Soft keyboard host
// ---------------------------------------------------------------------------------------------

@Composable
private fun KeyCaptureHost(session: VncSession) {
    val context = LocalContext.current
    val holder = remember { arrayOfNulls<KeyCaptureView>(1) }

    AndroidView(
        factory = { ctx ->
            val v = KeyCaptureView(ctx)
            holder[0] = v
            v
        },
        update = { v ->
            v.textSink = { text -> session.imeText(text) }
            v.keySink = { event -> session.onKeyEvent(event) }
            v.capturedSink = { ev -> session.input.mouse.onCapturedPointerEvent(ev) }
            v.privateIme = AppSettings.privateIme(context)
            val capture = session.phase == Phase.CONNECTED && session.input.cfg.mouseCapture
            if (capture) v.requestFocus()
            v.wantCapture = capture
        },
        modifier = Modifier.size(1.dp)
    )

    LaunchedEffect(session.imeRestartTick) {
        if (session.imeRestartTick == 0) return@LaunchedEffect
        val v = holder[0] ?: return@LaunchedEffect
        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        if (imm.isActive(v)) imm.restartInput(v)
    }

    LaunchedEffect(session.imeCommandTick) {
        if (session.imeCommandTick == 0) return@LaunchedEffect
        delay(60)
        val v = holder[0] ?: return@LaunchedEffect
        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        if (session.imeCommandShow) {
            v.requestFocus()
            imm.restartInput(v)
            imm.showSoftInput(v, InputMethodManager.SHOW_IMPLICIT)
        } else {
            imm.hideSoftInputFromWindow(v.windowToken, 0)
        }
    }
}


// ---------------------------------------------------------------------------------------------
// RealVNC engine prompts and connection info
// ---------------------------------------------------------------------------------------------

@Composable
private fun PromptDialog(vm: VncViewModel, session: VncSession, prompt: RemotePrompt) {
    when (prompt) {
        is CredentialsPrompt -> CredentialsDialog(vm, session, prompt)
        is TrustPrompt -> TrustDialog(session, prompt)
        is MessagePrompt -> MessageDialog(session, prompt)
    }
}

@Composable
private fun CredentialsDialog(vm: VncViewModel, session: VncSession, p: CredentialsPrompt) {
    var user by remember(p) { mutableStateOf(p.userName.ifEmpty { session.profile.userName }) }
    var pass by remember(p) { mutableStateOf("") }
    var save by remember(p) { mutableStateOf(true) }
    AlertDialog(
        onDismissRequest = {
            p.cancel()
            session.dismissPrompt(p)
        },
        title = { Text("Sign in") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (p.serverName.isNotEmpty()) Text(p.serverName, style = MaterialTheme.typography.titleSmall)
                if (p.instructions.isNotEmpty()) Text(p.instructions, style = MaterialTheme.typography.bodyMedium)
                if (p.askUserName) {
                    OutlinedTextField(
                        value = user,
                        onValueChange = { user = it },
                        singleLine = true,
                        label = { Text("User name") }
                    )
                }
                if (p.askPassword) {
                    OutlinedTextField(
                        value = pass,
                        onValueChange = { pass = it },
                        singleLine = true,
                        label = { Text("Password") },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                    )
                }
                if (p.catchphrase.isNotEmpty()) {
                    Text(
                        "Catchphrase: " + p.catchphrase,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (vm.isSaved(session.profile.id)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = save, onCheckedChange = { save = it })
                        Text("Remember")
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (save) vm.rememberCredentials(session, user, pass)
                p.answer(true, if (p.askUserName) user else null, if (p.askPassword) pass else null)
                session.dismissPrompt(p)
            }) { Text("Sign in") }
        },
        dismissButton = {
            TextButton(onClick = {
                p.cancel()
                session.dismissPrompt(p)
            }) { Text("Cancel") }
        }
    )
}

@Composable
private fun TrustDialog(session: VncSession, p: TrustPrompt) {
    var rememberServer by remember(p) { mutableStateOf(p.identity == TrustIdentity.NEW) }
    val identityText = when (p.identity) {
        TrustIdentity.OK -> "This server's identity matches one you accepted before."
        TrustIdentity.NEW ->
            "You have not connected to this server before. Check that the catchphrase below matches the one the server shows."
        TrustIdentity.MATCHES_ANOTHER -> "This identity is already known as \"" + p.matchingName + "\"."
        TrustIdentity.CHANGED ->
            "WARNING: this server's identity has CHANGED since you last connected. Someone may be impersonating it. Only continue if you expected this."
        TrustIdentity.MISSING -> "The server did not provide an identity, so it cannot be verified."
        TrustIdentity.PRESHARED -> "Authenticated with a pre-shared key."
        TrustIdentity.ARD -> "Apple Remote Desktop authentication."
    }
    val encryptionText = when (p.encryption) {
        TrustEncryption.ENCRYPTED -> "The connection is encrypted."
        TrustEncryption.UNENCRYPTED_WARN ->
            "WARNING: the connection is NOT encrypted. Anyone on the network could read your screen and password."
        TrustEncryption.UNENCRYPTED_QUIET -> "The connection is not encrypted."
    }
    val danger = p.identity == TrustIdentity.CHANGED || p.encryption == TrustEncryption.UNENCRYPTED_WARN
    AlertDialog(
        onDismissRequest = {
            p.cancel()
            session.dismissPrompt(p)
        },
        title = { Text("Verify server") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (p.serverName.isNotEmpty()) Text(p.serverName, style = MaterialTheme.typography.titleSmall)
                Text(
                    identityText,
                    color = if (p.identity == TrustIdentity.CHANGED) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                )
                Text(
                    encryptionText,
                    color = if (p.encryption == TrustEncryption.UNENCRYPTED_WARN) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                )
                if (p.catchphrase.isNotEmpty()) Text("Catchphrase: " + p.catchphrase, style = MaterialTheme.typography.bodyMedium)
                if (p.signature.isNotEmpty()) {
                    Text(
                        "Signature: " + p.signature,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = rememberServer, onCheckedChange = { rememberServer = it })
                    Text("Remember this server")
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                p.answer(true, rememberServer)
                session.dismissPrompt(p)
            }) { Text(if (danger) "Continue anyway" else "Continue") }
        },
        dismissButton = {
            TextButton(onClick = {
                p.cancel()
                session.dismissPrompt(p)
            }) { Text("Cancel") }
        }
    )
}

@Composable
private fun MessageDialog(session: VncSession, p: MessagePrompt) {
    val title = when (p.severity) {
        MessageSeverity.ERROR -> "Error"
        MessageSeverity.WARNING -> "Warning"
        MessageSeverity.QUESTION -> "Question"
        MessageSeverity.INFORMATION -> "Message"
    }
    val positive = p.customButton ?: if (p.yesNo) "Yes" else "OK"
    AlertDialog(
        onDismissRequest = {
            p.cancel()
            session.dismissPrompt(p)
        },
        title = { Text(title) },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                if (p.serverName.isNotEmpty()) {
                    Text(p.serverName, style = MaterialTheme.typography.titleSmall)
                }
                Text(p.message)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                p.answer(true)
                session.dismissPrompt(p)
            }) { Text(positive) }
        },
        dismissButton = {
            if (p.isQuestion) {
                TextButton(onClick = {
                    p.answer(false)
                    session.dismissPrompt(p)
                }) { Text(if (p.yesNo) "No" else "Cancel") }
            }
        }
    )
}

/** The first-frame "Controls" explanation: pick toolbar, tap regions or both. */
@Composable
private fun ControlsDialog(session: VncSession) {
    val ctx = LocalContext.current
    var doNotAsk by remember { mutableStateOf(false) }
    val current = AppSettings.controls(ctx)
    AlertDialog(
        onDismissRequest = {
            session.showHints = false
            if (doNotAsk) AppSettings.setBool(ctx, AppSettings.KEY_REGION_HINTS, false)
        },
        title = { Text("Controls") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Choose how to reach disconnect, connection info, the keyboard and the mouse. The rest of the screen controls the desktop.")
                for (v in listOf(AppSettings.CONTROLS_TOOLBAR, AppSettings.CONTROLS_REGIONS, AppSettings.CONTROLS_BOTH)) {
                    ToolChip(AppSettings.controlsLabel(v), current == v) {
                        AppSettings.setText(ctx, AppSettings.KEY_CONTROLS, v)
                        session.input.applyControls()
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = doNotAsk, onCheckedChange = { doNotAsk = it })
                    Text("Do not ask again")
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                session.showHints = false
                if (doNotAsk) AppSettings.setBool(ctx, AppSettings.KEY_REGION_HINTS, false)
            }) { Text("OK") }
        }
    )
}
