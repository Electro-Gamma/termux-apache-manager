package com.vncviewer.app

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.LaunchedEffect
import androidx.core.content.ContextCompat
import androidx.activity.viewModels
import com.vncviewer.app.ui.VncViewModel
import com.vncviewer.app.ui.VncViewerApp
import com.vncviewer.app.ui.VncViewerTheme

class MainActivity : ComponentActivity() {

    private val vm: VncViewModel by viewModels()

    private var askedForNotifications = false
    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        setContent {
            // Android 13+: the "sessions are running" notification needs its permission. Asked once
            // a session exists, not at launch; sessions run in the background without it, the
            // notification just stays out of sight.
            LaunchedEffect(vm.sessions.size) {
                if (vm.sessions.isNotEmpty() && !askedForNotifications &&
                    Build.VERSION.SDK_INT >= 33 &&
                    ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.POST_NOTIFICATIONS) !=
                    PackageManager.PERMISSION_GRANTED
                ) {
                    askedForNotifications = true
                    notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }
            VncViewerTheme {
                VncViewerApp(vm)
            }
        }
    }

    /** Physical keyboards (and IME key events) go to the remote desktop while a session is on screen. */
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (vm.handleKeyEvent(event)) return true
        return super.dispatchKeyEvent(event)
    }

    override fun onStart() {
        super.onStart()
        vm.onAppStarted()
    }

    override fun onStop() {
        super.onStop()
        vm.onAppStopped()
    }
}
