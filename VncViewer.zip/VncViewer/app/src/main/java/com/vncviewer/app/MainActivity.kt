package com.vncviewer.app

import android.graphics.Color
import android.os.Bundle
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.vncviewer.app.ui.VncViewModel
import com.vncviewer.app.ui.VncViewerApp
import com.vncviewer.app.ui.VncViewerTheme

class MainActivity : ComponentActivity() {

    private val vm: VncViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        setContent {
            VncViewerTheme {
                VncViewerApp(vm)
            }
        }
    }

    /** Physical keyboards (and IME key events) go to the remote desktop while a session is on screen. */
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (vm.handleKeyEvent(event)) return true
        return super.dispatchKeyEvent(event)
    }

    override fun onStart() {
        super.onStart()
        vm.onAppStarted()
    }

    override fun onStop() {
        super.onStop()
        vm.onAppStopped()
    }
}
