package com.vncviewer.app

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.core.content.ContextCompat
import androidx.activity.viewModels
import com.vncviewer.app.ui.VncViewModel
import com.vncviewer.app.ui.VncViewerApp
import com.vncviewer.app.ui.VncViewerTheme
import com.vncviewer.app.ui.appIsDark

class MainActivity : ComponentActivity() {

    private val vm: VncViewModel by viewModels()

    private var askedForNotifications = false
    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        setContent {
            // Android 13+: the "sessions are running" notification needs its permission. Asked once
            // a session exists, not at launch; sessions run in the background without it, the
            // notification just stays out of sight.
            LaunchedEffect(vm.sessions.size) {
                if (vm.sessions.isNotEmpty() && !askedForNotifications &&
                    Build.VERSION.SDK_INT >= 33 &&
                    ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.POST_NOTIFICATIONS) !=
                    PackageManager.PERMISSION_GRANTED
                ) {
                    askedForNotifications = true
                    notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }
            val dark = appIsDark()
            // Bar icons contrast with the UI behind them, and the window behind the first frame
            // matches the theme so a light app does not flash black while it draws.
            DisposableEffect(dark) {
                val bars = if (dark) SystemBarStyle.dark(Color.TRANSPARENT)
                else SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT)
                enableEdgeToEdge(statusBarStyle = bars, navigationBarStyle = bars)
                window.setBackgroundDrawable(
                    ColorDrawable(if (dark) 0xFF000000.toInt() else 0xFFF5F7F9.toInt())
                )
                onDispose { }
            }
            VncViewerTheme {
                VncViewerApp(vm)
            }
        }
    }

    /** Physical keyboards (and IME key events) go to the remote desktop while a session is on screen. */
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (vm.handleKeyEvent(event)) return true
        return super.dispatchKeyEvent(event)
    }

    override fun onStart() {
        super.onStart()
        vm.onAppStarted()
    }

    override fun onStop() {
        super.onStop()
        vm.onAppStopped()
    }
}
