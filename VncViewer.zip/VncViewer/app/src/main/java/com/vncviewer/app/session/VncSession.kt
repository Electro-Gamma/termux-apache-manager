package com.vncviewer.app.session

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.view.KeyCharacterMap
import android.view.KeyEvent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.vncviewer.app.data.Engine
import com.vncviewer.app.data.VncProfile
import com.vncviewer.app.realvnc.RealVncBackend
import com.vncviewer.app.realvnc.RealVncCore
import com.vncviewer.app.vnc.Keysyms
import com.vncviewer.app.vnc.RemoteBackend
import com.vncviewer.app.vnc.RemotePrompt
import com.vncviewer.app.vnc.VncClient
import com.vncviewer.app.vnc.VncListener
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.roundToInt

enum class Phase { CONNECTING, AUTH_REQUIRED, CONNECTED, FAILED }

enum class MouseMode(val label: String) {
    TOUCH("Touch"),
    TRACKPAD("Trackpad")
}

enum class ScaleMode(val label: String) {
    FIT("Fit"),
    ORIGINAL("1:1"),
    STRETCH("Stretch")
}

/**
 * One open VNC connection: network client + everything the UI needs
 * (framebuffer, viewport, mouse/keyboard state). All state is Compose state,
 * all mutating methods must be called on the main thread.
 */
class VncSession(
    private val appContext: Context,
    val id: String,
    initialProfile: VncProfile
) {
    // ---- connection state ----------------------------------------------------------
    var profile by mutableStateOf(initialProfile)
    var phase by mutableStateOf(Phase.CONNECTING)
    var status by mutableStateOf("Connecting\u2026")
    var error by mutableStateOf<String?>(null)
    var passwordRejected by mutableStateOf(false)
    var desktopName by mutableStateOf("")
    var notice by mutableStateOf<String?>(null)

    /** Questions from the RealVNC engine (sign-in, server identity, messages); first one is shown. */
    val prompts = mutableStateListOf<RemotePrompt>()

    /** Temporary banner, e.g. "Reconnecting..." (RealVNC engine). */
    var banner by mutableStateOf<String?>(null)

    /** Rows for the connection-info dialog, or null when it is closed. */
    var infoRows by mutableStateOf<List<Pair<String, String>>?>(null)

    /** RealVNC engine: Auto, High, Medium, Low. */
    var quality by mutableStateOf(initialProfile.quality)

    /** Remote cursor shape (RealVNC engine); null until the server sends one. */
    var remoteCursor by mutableStateOf<Bitmap?>(null)
    var cursorHotX by mutableIntStateOf(0)
    var cursorHotY by mutableIntStateOf(0)

    // ---- framebuffer -----------------------------------------------------------------
    @Volatile
    var bitmap: Bitmap? = null
    var fbWidth by mutableIntStateOf(0)
    var fbHeight by mutableIntStateOf(0)
    var frameTick by mutableIntStateOf(0)

    // ---- viewport ----------------------------------------------------------------------
    var scaleMode by mutableStateOf(ScaleMode.FIT)
    var zoom by mutableFloatStateOf(1f)
    var panX by mutableFloatStateOf(0f)
    var panY by mutableFloatStateOf(0f)
    private var viewW = 1
    private var viewH = 1

    // ---- input state -------------------------------------------------------------------
    var mouseMode by mutableStateOf(MouseMode.TOUCH)
    var panDragMode by mutableStateOf(false)
    var viewOnly by mutableStateOf(initialProfile.viewOnly)
    var pointerX by mutableFloatStateOf(0f)
    var pointerY by mutableFloatStateOf(0f)
    var buttonMask by mutableIntStateOf(0)
    var ctrl by mutableStateOf(false)
    var alt by mutableStateOf(false)
    var shift by mutableStateOf(false)
    var meta by mutableStateOf(false)
    var showDock by mutableStateOf(false)
    var imeCommandTick by mutableIntStateOf(0)
    var imeCommandShow: Boolean = false

    // ---- internals -----------------------------------------------------------------------
    private val main = Handler(Looper.getMainLooper())
    private var client: RemoteBackend? = null

    @Volatile
    private var token = 0
    private var lastPassword = ""
    private val framePending = AtomicBoolean(false)
    private val downKeys = HashMap<Int, Int>()

    val title: String
        get() = profile.name.ifBlank { profile.address }

    // =====================================================================================
    // Connection lifecycle
    // =====================================================================================

    fun connect(password: String) {
        closeClient()
        token++
        val my = token
        lastPassword = password
        phase = Phase.CONNECTING
        status = "Connecting\u2026"
        error = null
        clearPrompts()
        banner = null
        remoteCursor = null

        val listener = object : VncListener {
            override fun onStatus(text: String) {
                runOnMain(my) { status = text }
            }

            override fun onPasswordRequired(wasRejected: Boolean) {
                runOnMain(my) {
                    passwordRejected = wasRejected
                    phase = Phase.AUTH_REQUIRED
                }
            }

            override fun onFramebufferReady(bitmap: Bitmap, desktopName: String) {
                runOnMain(my) { handleFramebuffer(bitmap, desktopName) }
            }

            override fun onFrameUpdated() {
                if (my == token && framePending.compareAndSet(false, true)) {
                    main.post {
                        framePending.set(false)
                        frameTick = frameTick + 1
                    }
                }
            }

            override fun onServerCutText(text: String) {
                runOnMain(my) { handleRemoteClipboard(text) }
            }

            override fun onBell() {
            }

            override fun onDisconnected(error: String?) {
                runOnMain(my) { handleDisconnected(error) }
            }

            override fun onCursor(bitmap: Bitmap?, hotX: Int, hotY: Int) {
                runOnMain(my) {
                    remoteCursor = bitmap
                    cursorHotX = hotX
                    cursorHotY = hotY
                }
            }

            override fun onPrompt(prompt: RemotePrompt) {
                runOnMain(my) { prompts.add(prompt) }
            }

            override fun onBanner(text: String?) {
                runOnMain(my) { banner = text }
            }
        }

        val c: RemoteBackend
        if (profile.engine == Engine.REALVNC) {
            val reason = RealVncCore.unavailableReason()
            if (reason != null) {
                handleDisconnected(reason)
                return
            }
            c = RealVncBackend(
                appContext,
                profile.realVncAddress,
                profile.userName,
                password,
                quality,
                viewOnly,
                listener
            )
        } else {
            c = VncClient(profile.host, profile.port, password, listener)
        }
        client = c
        c.start()
    }

    fun reconnect() {
        connect(lastPassword.ifEmpty { profile.password })
    }

    fun submitPassword(password: String) {
        connect(password)
    }

    fun close() {
        token++
        releaseAllKeys()
        clearPrompts()
        closeClient()
    }

    /** Answer "no" to every open question so the engine is not left waiting. */
    private fun clearPrompts() {
        val open = ArrayList<RemotePrompt>(prompts)
        prompts.clear()
        for (p in open) p.cancel()
    }

    fun dismissPrompt(prompt: RemotePrompt) {
        prompts.remove(prompt)
    }

    private fun closeClient() {
        val c = client
        client = null
        c?.close()
    }

    private fun runOnMain(t: Int, block: () -> Unit) {
        main.post {
            if (t == token) block()
        }
    }

    private fun handleFramebuffer(bmp: Bitmap, name: String) {
        val resized = bmp.width != fbWidth || bmp.height != fbHeight
        bitmap = bmp
        fbWidth = bmp.width
        fbHeight = bmp.height
        desktopName = name
        if (resized) {
            zoom = 1f
            panX = 0f
            panY = 0f
            pointerX = (bmp.width / 2).toFloat()
            pointerY = (bmp.height / 2).toFloat()
        }
        if (phase != Phase.CONNECTED) phase = Phase.CONNECTED
        frameTick = frameTick + 1
    }

    private fun handleDisconnected(err: String?) {
        if (phase == Phase.AUTH_REQUIRED) return
        error = err ?: "Disconnected"
        phase = Phase.FAILED
        buttonMask = 0
        downKeys.clear()
        clearPrompts()
        banner = null
    }

    private fun handleRemoteClipboard(text: String) {
        if (text.isEmpty()) return
        try {
            val cm = appContext.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("VNC", text))
            showNotice("Clipboard updated from remote")
        } catch (_: Exception) {
        }
    }

    fun showNotice(text: String) {
        notice = text
    }

    /** Ask the UI to show or hide the Android soft keyboard. */
    fun requestIme(show: Boolean) {
        imeCommandShow = show
        imeCommandTick = imeCommandTick + 1
    }

    fun refresh() {
        client?.refresh()
    }

    /** App moved to / from the background: stop or resume screen updates (RealVNC engine). */
    fun setFocused(focused: Boolean) {
        client?.setFocused(focused)
    }

    val isRealVnc: Boolean
        get() = profile.engine == Engine.REALVNC

    fun cycleQuality() {
        val all = listOf("Auto", "High", "Medium", "Low")
        val next = all[(all.indexOf(quality) + 1) % all.size]
        quality = next
        client?.setQuality(next)
        showNotice("Picture quality: $next")
    }

    fun showConnectionInfo() {
        val c = client
        if (c == null) {
            infoRows = emptyList()
        } else {
            c.connectionInfo { rows -> infoRows = rows }
        }
    }

    // =====================================================================================
    // Viewport geometry
    // =====================================================================================

    fun onViewSize(w: Int, h: Int) {
        viewW = if (w < 1) 1 else w
        viewH = if (h < 1) 1 else h
        clampPan()
    }

    private fun baseScaleX(): Float {
        if (fbWidth <= 0 || fbHeight <= 0) return 1f
        return when (scaleMode) {
            ScaleMode.FIT -> minOf(viewW.toFloat() / fbWidth, viewH.toFloat() / fbHeight)
            ScaleMode.STRETCH -> viewW.toFloat() / fbWidth
            ScaleMode.ORIGINAL -> 1f
        }
    }

    private fun baseScaleY(): Float {
        if (fbWidth <= 0 || fbHeight <= 0) return 1f
        return when (scaleMode) {
            ScaleMode.FIT -> minOf(viewW.toFloat() / fbWidth, viewH.toFloat() / fbHeight)
            ScaleMode.STRETCH -> viewH.toFloat() / fbHeight
            ScaleMode.ORIGINAL -> 1f
        }
    }

    /** Screen pixels per remote pixel, horizontally (includes zoom). */
    fun scaleX(): Float {
        val s = baseScaleX() * zoom
        return if (s > 0.0001f) s else 0.0001f
    }

    fun scaleY(): Float {
        val s = baseScaleY() * zoom
        return if (s > 0.0001f) s else 0.0001f
    }

    /** Screen X of the framebuffer's left edge. */
    fun contentLeft(): Float = viewW / 2f - fbWidth * scaleX() / 2f + panX

    fun contentTop(): Float = viewH / 2f - fbHeight * scaleY() / 2f + panY

    private fun remoteX(sx: Float): Float {
        val v = (sx - contentLeft()) / scaleX()
        val max = if (fbWidth > 0) (fbWidth - 1).toFloat() else 0f
        return v.coerceIn(0f, max)
    }

    private fun remoteY(sy: Float): Float {
        val v = (sy - contentTop()) / scaleY()
        val max = if (fbHeight > 0) (fbHeight - 1).toFloat() else 0f
        return v.coerceIn(0f, max)
    }

    private fun clampPan() {
        if (fbWidth <= 0 || fbHeight <= 0) return
        val dw = fbWidth * scaleX()
        val dh = fbHeight * scaleY()
        val maxX = if (dw > viewW) (dw - viewW) / 2f else 0f
        val maxY = if (dh > viewH) (dh - viewH) / 2f else 0f
        val nx = panX.coerceIn(-maxX, maxX)
        val ny = panY.coerceIn(-maxY, maxY)
        if (nx != panX) panX = nx
        if (ny != panY) panY = ny
    }

    fun zoomBy(factor: Float, cx: Float, cy: Float, panDx: Float, panDy: Float) {
        if (fbWidth <= 0 || fbHeight <= 0) return
        val rx = (cx - contentLeft()) / scaleX()
        val ry = (cy - contentTop()) / scaleY()
        val minZoom = if (scaleMode == ScaleMode.ORIGINAL) 0.25f else 1f
        zoom = (zoom * factor).coerceIn(minZoom, 8f)
        panX = panX + (cx - (contentLeft() + rx * scaleX())) + panDx
        panY = panY + (cy - (contentTop() + ry * scaleY())) + panDy
        clampPan()
    }

    fun panBy(dx: Float, dy: Float) {
        panX = panX + dx
        panY = panY + dy
        clampPan()
    }

    fun resetViewport() {
        zoom = 1f
        panX = 0f
        panY = 0f
    }

    fun cycleScaleMode() {
        val all = ScaleMode.values()
        scaleMode = all[(scaleMode.ordinal + 1) % all.size]
        resetViewport()
    }

    /** Screen position of the remote pointer (used to draw the trackpad cursor). */
    fun pointerScreenX(): Float = contentLeft() + pointerX * scaleX()

    fun pointerScreenY(): Float = contentTop() + pointerY * scaleY()

    private fun ensurePointerVisible() {
        if (zoom <= 1.001f && scaleMode != ScaleMode.ORIGINAL) return
        val sx = pointerScreenX()
        val sy = pointerScreenY()
        val margin = 48f
        var dx = 0f
        var dy = 0f
        if (sx < margin) dx = margin - sx else if (sx > viewW - margin) dx = viewW - margin - sx
        if (sy < margin) dy = margin - sy else if (sy > viewH - margin) dy = viewH - margin - sy
        if (dx != 0f || dy != 0f) {
            panX = panX + dx
            panY = panY + dy
            clampPan()
        }
    }

    // =====================================================================================
    // Mouse
    // =====================================================================================

    private fun canInteract(): Boolean = phase == Phase.CONNECTED && !viewOnly && client != null

    private fun sendMove() {
        client?.sendPointerMove(pointerX.roundToInt(), pointerY.roundToInt(), buttonMask)
    }

    private fun sendPointerNow(mask: Int) {
        client?.sendPointer(pointerX.roundToInt(), pointerY.roundToInt(), mask)
    }

    /** Touch mode: put the pointer exactly under a screen position. */
    fun pointerToScreen(sx: Float, sy: Float) {
        if (!canInteract()) return
        pointerX = remoteX(sx)
        pointerY = remoteY(sy)
        sendMove()
    }

    /** Trackpad mode: move the pointer relative to where it is. */
    fun movePointerBy(dxScreen: Float, dyScreen: Float) {
        if (!canInteract()) return
        val maxX = if (fbWidth > 0) (fbWidth - 1).toFloat() else 0f
        val maxY = if (fbHeight > 0) (fbHeight - 1).toFloat() else 0f
        pointerX = (pointerX + dxScreen / scaleX() * TRACKPAD_GAIN).coerceIn(0f, maxX)
        pointerY = (pointerY + dyScreen / scaleY() * TRACKPAD_GAIN).coerceIn(0f, maxY)
        sendMove()
        ensurePointerVisible()
    }

    fun buttonDown(mask: Int) {
        if (!canInteract()) return
        buttonMask = buttonMask or mask
        sendPointerNow(buttonMask)
    }

    fun buttonUp(mask: Int) {
        if (!canInteract()) return
        buttonMask = buttonMask and mask.inv()
        sendPointerNow(buttonMask)
    }

    /** Press and release [mask] (1 = left, 2 = middle, 4 = right) at the current pointer position. */
    fun click(mask: Int) {
        if (!canInteract()) return
        val c = client ?: return
        val x = pointerX.roundToInt()
        val y = pointerY.roundToInt()
        val mods = pressModifiers()
        c.sendPointer(x, y, buttonMask or mask)
        main.postDelayed({
            c.sendPointer(x, y, buttonMask and mask.inv())
            releaseModifiers(mods)
        }, 35)
    }

    fun doubleClick() {
        click(1)
        main.postDelayed({ click(1) }, 90)
    }

    fun wheel(down: Boolean, notches: Int = 1) {
        if (!canInteract()) return
        val c = client ?: return
        val x = pointerX.roundToInt()
        val y = pointerY.roundToInt()
        val bit = if (down) 16 else 8
        for (i in 0 until notches) {
            c.sendPointer(x, y, buttonMask or bit)
            c.sendPointer(x, y, buttonMask)
        }
    }

    /** Absolute event from a physical mouse: position plus the full button state. */
    fun mouseEvent(sx: Float, sy: Float, mask: Int) {
        if (!canInteract()) return
        pointerX = remoteX(sx)
        pointerY = remoteY(sy)
        val changed = mask != buttonMask
        buttonMask = mask
        if (changed) sendPointerNow(mask) else sendMove()
    }

    // =====================================================================================
    // Keyboard
    // =====================================================================================

    private fun pressModifiers(): List<Int> {
        val c = client ?: return emptyList()
        val list = ArrayList<Int>(4)
        if (ctrl) list.add(Keysyms.CONTROL_L)
        if (alt) list.add(Keysyms.ALT_L)
        if (shift) list.add(Keysyms.SHIFT_L)
        if (meta) list.add(Keysyms.SUPER_L)
        for (k in list) c.sendKey(k, true)
        ctrl = false
        alt = false
        shift = false
        meta = false
        return list
    }

    private fun releaseModifiers(list: List<Int>) {
        val c = client ?: return
        for (k in list.asReversed()) c.sendKey(k, false)
    }

    /** Press + release one key, wrapped in whichever on-screen modifiers are armed. */
    fun tapKey(keySym: Int) {
        if (!canInteract() || keySym == 0) return
        val c = client ?: return
        val mods = pressModifiers()
        c.sendKey(keySym, true)
        c.sendKey(keySym, false)
        releaseModifiers(mods)
    }

    /** Press all keys in order, then release them in reverse (e.g. Ctrl+Alt+Del). */
    fun keyCombo(vararg keys: Int) {
        if (!canInteract()) return
        val c = client ?: return
        for (k in keys) c.sendKey(k, true)
        for (i in keys.indices.reversed()) c.sendKey(keys[i], false)
    }

    /** Text from the soft keyboard / IME. */
    fun imeText(text: String) {
        typeText(text)
    }

    fun typeText(text: String) {
        if (!canInteract()) return
        var i = 0
        while (i < text.length) {
            val cp = Character.codePointAt(text, i)
            i += Character.charCount(cp)
            tapKey(Keysyms.fromCodePoint(cp))
        }
    }

    fun toggleCtrl() {
        ctrl = !ctrl
    }

    fun toggleAlt() {
        alt = !alt
    }

    fun toggleShift() {
        shift = !shift
    }

    fun toggleMeta() {
        meta = !meta
    }

    /** Hardware keyboard (or key events sent by an IME). Returns true when the event was consumed. */
    fun onKeyEvent(event: KeyEvent): Boolean {
        if (!canInteract()) return false
        val action = event.action
        if (action != KeyEvent.ACTION_DOWN && action != KeyEvent.ACTION_UP) return false
        val down = action == KeyEvent.ACTION_DOWN
        val code = event.keyCode

        var sym = Keysyms.fromAndroidKeyCode(code)
        if (sym == 0) {
            val modMask = KeyEvent.META_CTRL_MASK or KeyEvent.META_ALT_MASK or KeyEvent.META_META_MASK
            val uc = event.getUnicodeChar(event.metaState and modMask.inv())
            if (uc != 0 && (uc and KeyCharacterMap.COMBINING_ACCENT) == 0) {
                sym = Keysyms.fromCodePoint(uc)
            }
        }
        if (down) {
            if (sym == 0) return false
            if (event.repeatCount > 0 && isModifierSym(sym)) return true
            downKeys[code] = sym
        } else {
            val previous = downKeys.remove(code)
            if (previous != null) sym = previous
            if (sym == 0) return false
        }
        client?.sendKey(sym, down)
        return true
    }

    private fun isModifierSym(sym: Int): Boolean = sym in 0xFFE1..0xFFEE

    fun releaseAllKeys() {
        val c = client
        if (c != null) {
            for (sym in downKeys.values) c.sendKey(sym, false)
            if (buttonMask != 0) {
                c.sendPointer(pointerX.roundToInt(), pointerY.roundToInt(), 0)
            }
        }
        downKeys.clear()
        buttonMask = 0
    }

    // =====================================================================================
    // Clipboard
    // =====================================================================================

    private fun localClipboardText(): String? {
        return try {
            val cm = appContext.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = cm.primaryClip
            if (clip == null || clip.itemCount == 0) {
                null
            } else {
                clip.getItemAt(0).coerceToText(appContext)?.toString()
            }
        } catch (_: Exception) {
            null
        }
    }

    /** Copy the phone's clipboard to the remote clipboard (then paste there with Ctrl+V). */
    fun sendClipboardToRemote() {
        if (!canInteract()) return
        val text = localClipboardText()
        if (text.isNullOrEmpty()) {
            showNotice("Phone clipboard is empty")
        } else {
            client?.sendClipboard(text)
            showNotice("Clipboard sent. Paste on the remote with Ctrl+V")
        }
    }

    /** Type the phone's clipboard into the remote as key presses (works everywhere). */
    fun typeClipboard() {
        if (!canInteract()) return
        val text = localClipboardText()
        if (text.isNullOrEmpty()) {
            showNotice("Phone clipboard is empty")
        } else {
            typeText(if (text.length > 5000) text.substring(0, 5000) else text)
        }
    }

    private companion object {
        const val TRACKPAD_GAIN = 1.3f
    }
}
