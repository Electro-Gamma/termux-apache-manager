# Minification is disabled for this project, so no rules are needed.
