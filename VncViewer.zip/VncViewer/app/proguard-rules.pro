# Minification is disabled for this project. These rules only matter if you turn it on:
# the RealVNC native library resolves these classes and their members by name.
-keep class com.realvnc.vncviewer.jni.** { *; }
-keep class com.vncviewer.app.realvnc.** { *; }
