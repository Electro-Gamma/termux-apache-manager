plugins {
  alias(libs.plugins.android.application)
  alias(libs.plugins.kotlin.compose)
}

// Release signing is only attached when VNCVIEWER_KEYSTORE points at a real file
// (the Colab notebook generates one in step 7). Without it Android refuses to
// install a release APK, because it would be unsigned.
val releaseKeystorePath: String? = System.getenv("VNCVIEWER_KEYSTORE")
val releaseKeystoreFile: File? = releaseKeystorePath?.let { File(it) }
val hasReleaseKeystore: Boolean = releaseKeystoreFile != null && releaseKeystoreFile.exists()

android {
  namespace = "com.vncviewer.app"
  compileSdk { version = release(36) }

  defaultConfig {
    applicationId = "com.vncviewer.app"
    minSdk = 24
    targetSdk = 36
    versionCode = 1
    versionName = "1.0"
  }

  signingConfigs {
    if (hasReleaseKeystore) {
      create("release") {
        storeFile = releaseKeystoreFile
        storePassword = System.getenv("VNCVIEWER_KEYSTORE_PASSWORD")
        keyAlias = System.getenv("VNCVIEWER_KEY_ALIAS") ?: "vncviewer"
        keyPassword = System.getenv("VNCVIEWER_KEY_PASSWORD")
      }
    }
  }

  buildTypes {
    release {
      isMinifyEnabled = false
      proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
      if (hasReleaseKeystore) {
        signingConfig = signingConfigs.getByName("release")
      }
    }
  }

  compileOptions {
    sourceCompatibility = JavaVersion.VERSION_11
    targetCompatibility = JavaVersion.VERSION_11
  }

  buildFeatures {
    compose = true
  }

  lint {
    abortOnError = false
    checkReleaseBuilds = false
  }

  dependenciesInfo {
    includeInApk = false
    includeInBundle = false
  }
}

dependencies {
  implementation(platform(libs.androidx.compose.bom))
  implementation(libs.androidx.core.ktx)
  implementation(libs.androidx.activity.compose)
  implementation(libs.androidx.lifecycle.viewmodel.compose)
  implementation(libs.androidx.lifecycle.runtime.ktx)
  implementation(libs.androidx.compose.ui)
  implementation(libs.androidx.compose.ui.graphics)
  implementation(libs.androidx.compose.foundation)
  implementation(libs.androidx.compose.material3)
  implementation(libs.kotlinx.coroutines.android)
}
