# Notices

## VncViewer
The RealVNC engine of this app (`app/src/main/java/com/vncviewer/app/realvnc/`) is a Kotlin
port of the RealVNC backend of **Vento** (https://github.com/pgaskin/vento,
Copyright (C) 2026 Patrick Gaskin), which is licensed **GPL-3.0-or-later**. Because of that,
this project as a whole is distributed under the GNU General Public License v3 or later
(see `LICENSE`). If you give the built app to anyone, you must also provide the source.

## realvnc-jni (CC0-1.0)
`realvnc-jni/` holds the Java declarations of the JNI surface of RealVNC Viewer's
`libvncviewer.so`, copied from Vento's `realvnc/` module (CC0-1.0). One line was changed:
`AuthkeyStoreAndroid` uses `Collections.emptySet()` instead of `Set.of()` (Android < 11).

## RealVNC native library (NOT included)
`libvncviewer.so` and `libc++_shared.so` (RealVNC Viewer 4.9.3.60175, arm64-v8a) are
proprietary software of RealVNC Limited. They are **not** part of this project and are not
in the project zip. You supply them yourself (the Colab notebook asks for `arm64-v8a.zip`
and verifies their SHA-256 before building). An APK built with them contains RealVNC's
binary: use it for yourself and do not redistribute that APK.
