# VncViewer

A small, VNC-only remote desktop client for Android (Kotlin + Jetpack Compose).
Derived from RemMobile with RDP, SSH, SFTP, web console, SPICE, the credential vault,
sync/diagnostics and all unused dependencies removed.

## Features
- RFB 3.3 / 3.7 / 3.8; security: None and VNC password. Encodings: ZRLE, Hextile, CopyRect, RRE, Raw, DesktopSize.
- Several sessions at once (tabs); sessions stay alive while you browse the connection list.
- Saved connections (passwords encrypted with an Android Keystore AES-256-GCM key) and Quick connect
  (`host`, `host:1` = port 5901, `host:5901`, `host::5901`, `vnc://host:port`, `[ipv6]:port`).
- Mouse: Touch mode (tap/long-press/drag) and Trackpad mode, pinch-zoom, two-finger scroll,
  pan toggle, physical mouse support (3 buttons + wheel), click menu (left/double/right/middle).
- Keyboard: Android soft keyboard, physical keyboard, key bar (Esc, Tab, sticky Ctrl/Alt/Shift/Win,
  arrows, Home/End/PgUp/PgDn, Del, Ins, F1-F12, Ctrl+Alt+Del).
- Clipboard: remote -> phone automatic; phone -> remote as clipboard or as typed text.
- Fit / 1:1 / Stretch scaling, fullscreen, view-only mode, keeps the screen on while connected.

## RealVNC engine (optional)
Each connection can run on the **built-in** client or on **RealVNC's own viewer core**
(encrypted connections, UDP, ZRLE2, RealVNC authentication, remote cursor shape, picture-quality
presets, connection info). Pick the engine per connection (or next to Quick connect).

The RealVNC core is a proprietary native library that is *not* in this project. To enable it,
upload `arm64-v8a.zip` (containing `libvncviewer.so` and `libc++_shared.so` from RealVNC Viewer
4.9.3.60175) in the Colab notebook; they are verified against pinned SHA-256 hashes and bundled
as `app/src/main/jniLibs/arm64-v8a/`. Requirements: arm64 phone, Android 8.0+. Without the
libraries the app builds and works normally; choosing RealVNC then shows an explanation.

Not supported on the RealVNC engine: RealVNC cloud sign-in / address book, multi-factor sign-in
prompts, client-certificate identities.

## Layout
```
app/src/main/java/com/vncviewer/app/
  MainActivity.kt          activity, hardware-key hook
  vnc/VncClient.kt         built-in RFB protocol engine (sockets, decoders, input)
  vnc/RemoteBackend.kt     the interface both engines implement
  vnc/RemotePrompt.kt      sign-in / trust / message prompts from the RealVNC engine
  realvnc/                 RealVNC engine: core thread + init, prompt bridge, backend
realvnc-jni/               Java declarations of the RealVNC JNI surface (CC0, from Vento)
  vnc/Keysyms.kt           Android key codes / Unicode -> X11 keysyms
  session/VncSession.kt    one connection: viewport, mouse, keyboard, clipboard state
  data/                    profile model, encrypted JSON store, address parser
  ui/                      Compose screens, canvas + gestures, soft-keyboard capture view
```

## Build
Use the Colab notebook `VncViewer_APK_Release.ipynb`, or locally (JDK 17, Android SDK 36, Gradle 9.3.1):
```
gradle assembleDebug assembleRelease
```
