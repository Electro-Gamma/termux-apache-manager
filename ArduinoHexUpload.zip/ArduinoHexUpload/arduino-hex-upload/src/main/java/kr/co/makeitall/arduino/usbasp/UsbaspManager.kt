package kr.co.makeitall.arduino.usbasp

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import androidx.core.content.ContextCompat
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kr.co.makeitall.arduino.ArduinoUploader.Config.McuIdentifier
import kr.co.makeitall.arduino.LineReader
import IntelHexFormatReader.HexFileReader
import IntelHexFormatReader.Model.MemoryBlock
import java.io.InputStream
import java.io.InputStreamReader
import java.io.StringReader

/**
 * High-level USBasp support: finds a connected USBasp, handles its (Android 14+ safe)
 * permission request, and drives a full hex upload (verify signature -> chip erase -> write ->
 * read back and verify) via [UsbaspProgrammer]. Mirrors the percent/message/complete callback
 * shape used by [kr.co.makeitall.arduino.UsbSerialManager] so it plugs into the same UI code
 * paths, but is otherwise fully independent — USBasp is a raw-USB device, not a serial one, so
 * none of the felHR85 machinery is involved.
 */
class UsbaspManager(private val context: Context, lifecycle: Lifecycle) : DefaultLifecycleObserver {

    private val usbManager = context.getSystemService(Context.USB_SERVICE) as UsbManager

    var device: UsbDevice? = null
        private set

    private var onChangeListener: (() -> Unit)? = null

    fun addOnChangeListener(listener: () -> Unit): UsbaspManager {
        onChangeListener = listener
        return this
    }

    fun hasPermission(): Boolean = device?.let { usbManager.hasPermission(it) } ?: false

    fun requestPermission() {
        val target = device ?: return
        // Same Android 14+ requirement as UsbSerialManager: a mutable PendingIntent must wrap
        // an EXPLICIT intent (scoped to our own package), or the OS refuses to create it.
        val intent = Intent(ACTION_USBASP_PERMISSION).setPackage(context.packageName)
        val pendingIntent = PendingIntent.getBroadcast(context, 0, intent, PendingIntent.FLAG_MUTABLE)
        usbManager.requestPermission(target, pendingIntent)
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            when (intent.action) {
                ACTION_USBASP_PERMISSION, UsbManager.ACTION_USB_DEVICE_ATTACHED, UsbManager.ACTION_USB_DEVICE_DETACHED -> {
                    refresh()
                    onChangeListener?.invoke()
                }
            }
        }
    }

    init {
        lifecycle.addObserver(this)
    }

    override fun onCreate(owner: LifecycleOwner) {
        ContextCompat.registerReceiver(
            context,
            receiver,
            IntentFilter().apply {
                addAction(ACTION_USBASP_PERMISSION)
                addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
                addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
            },
            ContextCompat.RECEIVER_EXPORTED
        )
        refresh()
    }

    override fun onDestroy(owner: LifecycleOwner) {
        try {
            context.unregisterReceiver(receiver)
        } catch (_: IllegalArgumentException) {
            // Not registered — nothing to do.
        }
    }

    /** Re-scans connected USB devices for a USBasp match. */
    fun refresh() {
        device = usbManager.deviceList.values.firstOrNull { UsbaspProgrammer.isUsbasp(it) }
    }

    /**
     * Full hex upload over USBasp: parse -> open -> connect -> verify signature -> chip erase
     * -> write flash -> read back and verify -> close. Any failure is reported via
     * [messageCallback] before [completeCallback] fires with false, mirroring UsbSerialManager.
     */
    suspend fun uploadHex(
        hexCode: String? = null,
        firmware: InputStream? = null,
        mcu: McuIdentifier,
        sckOption: UsbaspSckOption,
        percentCallback: (percent: Int) -> Unit,
        messageCallback: (message: String) -> Unit,
        completeCallback: (complete: Boolean) -> Unit
    ) {
        val target = device
        if (target == null) {
            messageCallback("ERROR: No USBasp device found")
            completeCallback(false)
            return
        }

        val programmer = UsbaspProgrammer(context, target)

        try {
            withContext(Dispatchers.IO) {
                messageCallback("Starting USBasp uploader...")

                val info = UsbaspMcuTable[mcu]
                val lines = LineReader(
                    hexCode?.let { StringReader(it) } ?: firmware?.let { InputStreamReader(it) }
                        ?: throw UsbaspException("code and firmware is null")
                ).readLines()
                val block: MemoryBlock = HexFileReader(lines, info.flashSize).Parse()
                val usedLength = block.highestModifiedOffset + 1
                if (usedLength > info.flashSize) {
                    throw UsbaspException("Program is larger than the target's flash (${info.flashSize} bytes available)")
                }
                val image = ByteArray(usedLength) { i -> block.cells[i].value }

                if (!programmer.open()) {
                    throw UsbaspException("Could not open the USBasp — try reconnecting it")
                }

                try {
                    messageCallback("Connecting to USBasp...")
                    programmer.setSck(sckOption)
                    programmer.connect()
                    programmer.enableProgramming()

                    messageCallback("Checking device signature...")
                    val signature = programmer.readSignature()
                    val expected = info.signature
                    if (!signature.contentEquals(expected)) {
                        throw UsbaspException(
                            "Signature mismatch: expected ${expected.toHexString()}, got ${signature.toHexString()} " +
                                "— check the selected MCU and the wiring (MOSI/MISO/SCK/RESET/VCC/GND)"
                        )
                    }
                    messageCallback("Device signature checked: ${signature.toHexString()}")

                    messageCallback("Erasing chip...")
                    programmer.chipErase()

                    messageCallback("Writing $usedLength bytes to flash (page size ${info.pageSize})...")
                    programmer.writeFlash(image, info.pageSize) { percent ->
                        // Writing is the first half of the progress bar, verify is the second.
                        percentCallback(percent / 2)
                    }
                    messageCallback("$usedLength bytes written to flash!")

                    messageCallback("Verifying program...")
                    val readBack = programmer.readFlash(usedLength) { percent ->
                        percentCallback(50 + percent / 2)
                    }
                    if (!readBack.contentEquals(image)) {
                        val mismatchAt = readBack.indices.firstOrNull { readBack[it] != image[it] }
                        throw UsbaspException("Verification failed — mismatch at byte offset ${mismatchAt ?: -1}")
                    }
                    messageCallback("$usedLength bytes verified!")
                    messageCallback("Verified program!")
                } finally {
                    programmer.close()
                }
            }

            percentCallback(100)
            completeCallback(true)
        } catch (e: Exception) {
            e.printStackTrace()
            messageCallback("ERROR: ${e.message ?: e.javaClass.simpleName}")
            completeCallback(false)
        }
    }

    private fun IntArray.toHexString(): String = joinToString(" ") { "%02X".format(it) }

    companion object {
        const val ACTION_USBASP_PERMISSION = "kr.co.makeitall.arduino.usbasp.action.USB_PERMISSION_REQUEST"
    }
}
