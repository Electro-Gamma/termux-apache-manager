package kr.co.makeitall.arduino.usbasp

import kr.co.makeitall.arduino.ArduinoUploader.Config.McuIdentifier

/**
 * USBasp is a raw-USB (control-transfer) AVR ISP programmer — not a USB-serial device, so none
 * of [kr.co.makeitall.arduino.UsbSerialManager]'s felHR85-based machinery applies to it. Every
 * constant below is taken directly from avrdude 8.2's own USBasp driver source
 * (src/usbasp.c, src/usbasp.h, src/usbdevs.h) and its avrdude.conf part definitions, not
 * reconstructed from memory, so it matches real hardware/firmware exactly.
 */
object UsbaspIds {
    // src/usbdevs.h: USBASP_SHARED_VID / USBASP_SHARED_PID (modern firmware, VOTI shared ID)
    const val VENDOR_ID = 0x16C0
    const val PRODUCT_ID = 0x05DC

    // src/usbdevs.h: USBASP_OLD_VID / USBASP_OLD_PID (old/unofficial ATMEL-VID clones)
    const val OLD_VENDOR_ID = 0x03EB
    const val OLD_PRODUCT_ID = 0xC7B4

    fun matches(vendorId: Int, productId: Int): Boolean =
        (vendorId == VENDOR_ID && productId == PRODUCT_ID) ||
            (vendorId == OLD_VENDOR_ID && productId == OLD_PRODUCT_ID)
}

/** src/usbasp.h USB function call identifiers (the control transfer's bRequest field). */
object UsbaspFunction {
    const val CONNECT = 1
    const val DISCONNECT = 2
    const val TRANSMIT = 3
    const val READFLASH = 4
    const val ENABLEPROG = 5
    const val WRITEFLASH = 6
    const val READEEPROM = 7
    const val WRITEEEPROM = 8
    const val SETLONGADDRESS = 9
    const val SETISPSCK = 10
    const val GETCAPABILITIES = 127
}

/** src/usbasp.h block mode flags, used in the top nibble of WRITEFLASH's cmd[3]. */
object UsbaspBlockFlag {
    const val FIRST = 1
    const val LAST = 2
}

/** src/usbasp.c usbasp_transmit(): block sizes used per USB control-transfer chunk. */
object UsbaspBlockSize {
    const val READ = 200
    const val WRITE = 200
}

/**
 * src/usbasp.h ISP SCK speed identifiers, sent via SETISPSCK. Slower boards/breadboard wiring
 * benefit from a slower SCK; AUTO lets the firmware pick and auto-slow on no response.
 */
enum class UsbaspSckOption(val id: Int, val label: String) {
    AUTO(0, "Auto"),
    HZ_187_5(9, "187.5 kHz"),
    HZ_375(10, "375 kHz"),
    HZ_750(11, "750 kHz"),
    KHZ_1500(12, "1.5 MHz");

    override fun toString() = label
}

/**
 * Per-MCU flash geometry and signature, verified against avrdude.conf (not from memory):
 * ATmega168 -> 1E 94 06, 16384 B, 128 B/page
 * ATmega328P -> 1E 95 0F, 32768 B, 128 B/page
 * ATmega32U4 -> 1E 95 87, 32768 B, 128 B/page
 * ATmega2560 -> 1E 98 01, 262144 B, 256 B/page
 * ATmega1284 -> 1E 97 06, 131072 B, 256 B/page
 * ATmega1284P -> 1E 97 05, 131072 B, 256 B/page
 */
data class UsbaspMcuInfo(val signature: IntArray, val flashSize: Int, val pageSize: Int)

object UsbaspMcuTable {
    private val table = mapOf(
        McuIdentifier.AtMega168 to UsbaspMcuInfo(intArrayOf(0x1E, 0x94, 0x06), 16384, 128),
        McuIdentifier.AtMega328P to UsbaspMcuInfo(intArrayOf(0x1E, 0x95, 0x0F), 32768, 128),
        McuIdentifier.AtMega32U4 to UsbaspMcuInfo(intArrayOf(0x1E, 0x95, 0x87), 32768, 128),
        McuIdentifier.AtMega2560 to UsbaspMcuInfo(intArrayOf(0x1E, 0x98, 0x01), 262144, 256),
        McuIdentifier.AtMega1284 to UsbaspMcuInfo(intArrayOf(0x1E, 0x97, 0x06), 131072, 256),
        McuIdentifier.AtMega1284P to UsbaspMcuInfo(intArrayOf(0x1E, 0x97, 0x05), 131072, 256)
    )

    operator fun get(mcu: McuIdentifier): UsbaspMcuInfo =
        table[mcu] ?: error("No USBasp geometry table entry for $mcu")
}
