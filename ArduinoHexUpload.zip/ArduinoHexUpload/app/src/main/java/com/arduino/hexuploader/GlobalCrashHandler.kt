package com.arduino.hexuploader

import android.app.Application
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Process
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.system.exitProcess

/**
 * Installed as the default uncaught-exception handler for every thread. When anything crashes,
 * this builds a full text report, saves it to a file under internal storage, and launches
 * [CrashActivity] (which runs in its own process, see the manifest) with the report attached —
 * then kills the crashed process. This exists purely for diagnostics: it doesn't fix anything,
 * it just makes sure a crash produces a readable, copyable report instead of a silent
 * "app keeps stopping" with no detail.
 */
class GlobalCrashHandler private constructor(
    private val appContext: Context,
    private val previousHandler: Thread.UncaughtExceptionHandler?
) : Thread.UncaughtExceptionHandler {

    override fun uncaughtException(thread: Thread, throwable: Throwable) {
        try {
            val report = buildReport(thread, throwable)
            val savedPath = writeToFile(report)

            val intent = Intent(appContext, CrashActivity::class.java).apply {
                addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_CLEAR_TASK or
                        Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS
                )
                putExtra(CrashActivity.EXTRA_REPORT, report)
                putExtra(CrashActivity.EXTRA_FILE_PATH, savedPath)
            }
            appContext.startActivity(intent)
        } catch (handlerFailure: Throwable) {
            // The crash handler itself must never be the reason the device sees nothing at all.
            previousHandler?.uncaughtException(thread, throwable)
        } finally {
            Process.killProcess(Process.myPid())
            exitProcess(10)
        }
    }

    private fun buildReport(thread: Thread, throwable: Throwable): String {
        val sw = StringWriter()
        PrintWriter(sw).use { pw ->
            pw.println("AVR Programmer crash report")
            pw.println("Time: ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())}")
            pw.println("Thread: ${thread.name}")
            pw.println("App version: ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})")
            pw.println("Android: ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})")
            pw.println("Device: ${Build.MANUFACTURER} ${Build.MODEL}")
            pw.println()
            throwable.printStackTrace(pw)

            var cause = throwable.cause
            while (cause != null) {
                pw.println()
                pw.println("Caused by:")
                cause.printStackTrace(pw)
                cause = cause.cause
            }
        }
        return sw.toString()
    }

    private fun writeToFile(report: String): String? = try {
        val dir = File(appContext.filesDir, "crash_logs").apply { mkdirs() }
        val file = File(dir, "crash_${System.currentTimeMillis()}.txt")
        file.writeText(report)
        file.absolutePath
    } catch (e: Exception) {
        null
    }

    companion object {
        fun install(app: Application) {
            val previous = Thread.getDefaultUncaughtExceptionHandler()
            Thread.setDefaultUncaughtExceptionHandler(
                GlobalCrashHandler(app.applicationContext, previous)
            )
        }
    }
}
