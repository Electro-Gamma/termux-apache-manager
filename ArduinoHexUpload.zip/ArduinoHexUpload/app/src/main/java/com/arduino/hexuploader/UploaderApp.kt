package com.arduino.hexuploader

import android.app.Application
import timber.log.Timber

class UploaderApp : Application() {
    override fun onCreate() {
        super.onCreate()
        if (BuildConfig.DEBUG) {
            Timber.plant(Timber.DebugTree())
        }
    }
}
