package com.arduino.hexuploader

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate
import timber.log.Timber

class UploaderApp : Application() {
    override fun onCreate() {
        super.onCreate()
        GlobalCrashHandler.install(this)
        // Belt-and-suspenders on top of the light-only theme: force light mode app-wide
        // regardless of the system dark-mode setting.
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        if (BuildConfig.DEBUG) {
            Timber.plant(Timber.DebugTree())
        }
    }
}
