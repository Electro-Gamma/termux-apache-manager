package com.arduino.hexuploader

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.res.ColorStateList
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.widget.ArrayAdapter
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updateLayoutParams
import androidx.core.view.updatePadding
import androidx.lifecycle.lifecycleScope
import com.arduino.hexuploader.databinding.ActivityMainBinding
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kr.co.makeitall.arduino.ArduinoUploader.Config.Arduino
import kr.co.makeitall.arduino.ArduinoUploader.Config.McuIdentifier
import kr.co.makeitall.arduino.ArduinoUploader.Config.Protocol
import kr.co.makeitall.arduino.Boards
import kr.co.makeitall.arduino.LineReader
import kr.co.makeitall.arduino.UsbSerialManager
import IntelHexFormatReader.HexFileReader
import IntelHexFormatReader.Model.MemoryBlock
import java.io.InputStreamReader

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var usbSerialManager: UsbSerialManager

    private val boards = Boards.values()
    private val mcus = McuIdentifier.values()
    private val protocols = Protocol.values()

    private var selectedBoard: Boards = Boards.ARDUINO_UNO
    private var selectedMcu: McuIdentifier = McuIdentifier.AtMega328P
    private var selectedProtocol: Protocol = Protocol.Stk500v1

    private var selectedHexUri: Uri? = null
    private var hexValidated = false
    private var isUploading = false

    private val openHexFile =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            uri?.let { onHexFilePicked(it) }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        applyWindowInsets()
        // Belt-and-suspenders alongside the XML attribute: makes sure this small log box
        // properly claims scroll gestures instead of losing them to the outer page ScrollView.
        binding.logScrollView.isNestedScrollingEnabled = true

        usbSerialManager = UsbSerialManager(this, lifecycle)
        usbSerialManager
            .addOnStateListener { refreshDeviceStatus(); updateUploadEnabled() }
            .addOnPermissionListener { refreshDeviceStatus(); updateUploadEnabled() }
            .addOnErrorListener { refreshDeviceStatus(); updateUploadEnabled() }

        setupUploadTypeToggle()
        setupBoardDropdown()
        setupCustomFields()

        binding.browseButton.setOnClickListener { openHexFile.launch(arrayOf("*/*")) }
        binding.deviceStatusRow.setOnClickListener {
            if (usbSerialManager.usbDevice != null && !usbSerialManager.hasPermission()) {
                usbSerialManager.requestPermission()
            }
        }
        binding.uploadFab.setOnClickListener { startUpload() }
        binding.copyLogButton.setOnClickListener { copyLogToClipboard() }

        refreshDeviceStatus()
        updateUploadEnabled()
    }

    // region Setup

    private fun applyWindowInsets() {
        // Android 15 (targetSdk 35) draws edge-to-edge by default, so without this the FAB and
        // toolbar title can end up hidden behind the system status/navigation bars depending on
        // the device (3-button nav, gesture nav, etc.) — apply the real inset instead of a
        // fixed guess.
        val baseFabMargin = (binding.uploadFab.layoutParams as CoordinatorLayout.LayoutParams).bottomMargin
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())

            binding.appBarLayout.updatePadding(top = bars.top)
            binding.scrollContent.updatePadding(bottom = 96.dpToPx() + bars.bottom)
            binding.uploadFab.updateLayoutParams<CoordinatorLayout.LayoutParams> {
                bottomMargin = baseFabMargin + bars.bottom
            }

            insets
        }
    }

    private fun Int.dpToPx(): Int = (this * resources.displayMetrics.density).toInt()

    private fun setupUploadTypeToggle() {
        binding.uploadTypeGroup.setOnCheckedChangeListener { _, checkedId ->
            val standard = checkedId == binding.radioStandard.id
            binding.boardInputLayout.visibility = if (standard) View.VISIBLE else View.GONE
            binding.customFieldsContainer.visibility = if (standard) View.GONE else View.VISIBLE
            if (selectedHexUri != null) validateSelectedHex()
        }
    }

    private fun setupBoardDropdown() {
        val names = boards.map { it.boardName }
        binding.boardDropdown.setAdapter(
            ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, names)
        )
        binding.boardDropdown.setText(selectedBoard.boardName, false)
        binding.boardDropdown.setOnItemClickListener { _, _, position, _ ->
            selectedBoard = boards[position]
            if (selectedHexUri != null) validateSelectedHex()
        }
    }

    private fun setupCustomFields() {
        binding.mcuDropdown.setAdapter(
            ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, mcus.map { it.name })
        )
        binding.mcuDropdown.setText(selectedMcu.name, false)
        binding.mcuDropdown.setOnItemClickListener { _, _, position, _ ->
            selectedMcu = mcus[position]
            if (selectedHexUri != null) validateSelectedHex()
        }

        binding.protocolDropdown.setAdapter(
            ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, protocols.map { it.name })
        )
        binding.protocolDropdown.setText(selectedProtocol.name, false)
        binding.protocolDropdown.setOnItemClickListener { _, _, position, _ ->
            selectedProtocol = protocols[position]
            binding.customBaudRate.setText(defaultBaudRateFor(selectedProtocol).toString())
        }
    }

    // endregion

    // region Hex file picking + validation

    private fun onHexFilePicked(uri: Uri) {
        selectedHexUri = uri
        binding.hexFileName.text = queryDisplayName(uri) ?: uri.lastPathSegment ?: uri.toString()
        validateSelectedHex()
    }

    private fun queryDisplayName(uri: Uri): String? =
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && cursor.moveToFirst()) cursor.getString(idx) else null
        }

    private fun currentFlashSize(): Int {
        val mcu = if (binding.radioStandard.isChecked) selectedBoard.chipType else selectedMcu
        return flashSizeFor(mcu)
    }

    private fun flashSizeFor(mcu: McuIdentifier): Int = when (mcu) {
        McuIdentifier.AtMega168 -> 16 * 1024
        McuIdentifier.AtMega328P -> 32 * 1024
        McuIdentifier.AtMega32U4 -> 32 * 1024
        McuIdentifier.AtMega1284, McuIdentifier.AtMega1284P -> 128 * 1024
        McuIdentifier.AtMega2560 -> 256 * 1024
    }

    private fun validateSelectedHex() {
        val uri = selectedHexUri ?: return
        val flashSize = currentFlashSize()

        binding.verifyRow.visibility = View.VISIBLE
        binding.verifyIcon.setImageResource(R.drawable.ic_check_circle)
        binding.verifyText.setTextColor(ContextCompat.getColor(this, R.color.neutral_500))
        binding.verifyText.text = getString(R.string.verify_checking)
        hexValidated = false
        updateUploadEnabled()

        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val lines = contentResolver.openInputStream(uri)?.use { input ->
                        LineReader(InputStreamReader(input)).readLines()
                    } ?: throw IllegalStateException("Could not open the selected file")
                    HexFileReader(lines, flashSize).Parse() as MemoryBlock
                }
            }

            result.onSuccess { block ->
                val used = block.highestModifiedOffset + 1
                if (used > flashSize) {
                    showVerifyError(getString(R.string.verify_too_big_format, formatBytes(flashSize)))
                } else {
                    val pct = (used * 100 / flashSize).coerceIn(0, 100)
                    binding.verifyIcon.setImageResource(R.drawable.ic_check_circle)
                    binding.verifyText.setTextColor(ContextCompat.getColor(this@MainActivity, R.color.success_600))
                    binding.verifyText.text =
                        getString(R.string.verify_valid_format, formatBytes(used), formatBytes(flashSize), pct)
                    hexValidated = true
                }
                updateUploadEnabled()
            }.onFailure { e ->
                showVerifyError(e.message ?: e.toString())
            }
        }
    }

    private fun showVerifyError(message: String) {
        binding.verifyIcon.setImageResource(R.drawable.ic_error_circle)
        binding.verifyText.setTextColor(ContextCompat.getColor(this, R.color.error_600))
        binding.verifyText.text = getString(R.string.verify_invalid_format, message)
        hexValidated = false
        updateUploadEnabled()
    }

    private fun formatBytes(n: Int): String = "%,d".format(n)

    // endregion

    // region Device status

    private fun refreshDeviceStatus() {
        val device = usbSerialManager.usbDevice
        when {
            device == null -> {
                binding.deviceStatusText.text = getString(R.string.device_none)
                tintStatusIcon(R.color.neutral_500)
            }
            !usbSerialManager.hasPermission() -> {
                binding.deviceStatusText.text = getString(R.string.device_needs_permission)
                tintStatusIcon(R.color.warning_700)
            }
            else -> {
                binding.deviceStatusText.text =
                    getString(R.string.device_ready_format, UsbChipIdentifier.friendlyName(device))
                tintStatusIcon(R.color.success_600)
            }
        }
    }

    private fun tintStatusIcon(colorRes: Int) {
        binding.deviceStatusIcon.imageTintList = ColorStateList.valueOf(ContextCompat.getColor(this, colorRes))
    }

    // endregion

    // region Upload

    private fun defaultBaudRateFor(protocol: Protocol): Int = when (protocol) {
        Protocol.Stk500v1 -> 57600
        Protocol.Stk500v2 -> 115200
        Protocol.Avr109 -> 57600
    }

    private fun defaultResetBehaviorFor(protocol: Protocol): Pair<String?, String?> = when (protocol) {
        Protocol.Stk500v1 -> "DTR;true" to "DTR-RTS;250;50"
        Protocol.Stk500v2 -> "DTR-RTS;50;250;true" to "DTR-RTS;250;50;true"
        Protocol.Avr109 -> "1200bps" to null
    }

    private fun updateUploadEnabled() {
        val ready = !isUploading && hexValidated &&
            usbSerialManager.usbDevice != null && usbSerialManager.hasPermission()
        binding.uploadFab.isEnabled = ready
        binding.uploadFab.alpha = if (ready) 1f else 0.5f
    }

    private fun setUploading(active: Boolean) {
        isUploading = active
        binding.progressContainer.visibility = if (active) View.VISIBLE else View.GONE
        binding.browseButton.isEnabled = !active
        for (i in 0 until binding.uploadTypeGroup.childCount) {
            binding.uploadTypeGroup.getChildAt(i).isEnabled = !active
        }
        binding.boardDropdown.isEnabled = !active
        binding.mcuDropdown.isEnabled = !active
        binding.protocolDropdown.isEnabled = !active
        binding.customBaudRate.isEnabled = !active
        binding.customBoardName.isEnabled = !active
        if (!active) binding.progressBar.setProgressCompat(0, false)
        updateUploadEnabled()
    }

    private fun appendLog(message: String) {
        if (binding.logText.text.isNullOrBlank()) {
            binding.logText.text = message
        } else {
            binding.logText.append("\n$message")
        }
        binding.logText.post { binding.logScrollView.fullScroll(View.FOCUS_DOWN) }
    }

    private fun copyLogToClipboard() {
        val text = binding.logText.text?.toString().orEmpty()
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Upload log", text))
        Snackbar.make(binding.root, R.string.log_copied, Snackbar.LENGTH_SHORT).show()
    }

    private fun startUpload() {
        val uri = selectedHexUri
        if (uri == null) {
            Snackbar.make(binding.root, R.string.error_pick_hex_first, Snackbar.LENGTH_SHORT).show()
            return
        }
        if (usbSerialManager.usbDevice == null || !usbSerialManager.hasPermission()) {
            Snackbar.make(binding.root, R.string.error_device_first, Snackbar.LENGTH_SHORT).show()
            return
        }

        setUploading(true)
        binding.logText.text = ""

        lifecycleScope.launch {
            val stream = withContext(Dispatchers.IO) { contentResolver.openInputStream(uri) }
            if (stream == null) {
                appendLog("Could not open the selected file.")
                setUploading(false)
                return@launch
            }

            val percentCallback: (Int) -> Unit = { percent ->
                binding.progressBar.setProgressCompat(percent, true)
                binding.progressPercentText.text = "$percent%"
            }
            val messageCallback: (String) -> Unit = { message -> appendLog(message) }
            val completeCallback: (Boolean) -> Unit = { success ->
                setUploading(false)
                appendLog(if (success) "\u2713 Upload complete" else "\u2717 Upload failed — see the error above")
                Snackbar.make(
                    binding.root,
                    if (success) R.string.upload_success else R.string.upload_failed,
                    Snackbar.LENGTH_LONG
                ).show()
            }

            if (binding.radioStandard.isChecked) {
                usbSerialManager.uploadHex(
                    firmware = stream,
                    board = selectedBoard,
                    percentCallback = percentCallback,
                    messageCallback = messageCallback,
                    completeCallback = completeCallback
                )
            } else {
                val (preOpen, close) = defaultResetBehaviorFor(selectedProtocol)
                val arduino = Arduino(
                    model = binding.customBoardName.text?.toString()?.ifBlank { null } ?: "Custom board",
                    mcu = selectedMcu,
                    baudRate = binding.customBaudRate.text?.toString()?.toIntOrNull()
                        ?: defaultBaudRateFor(selectedProtocol),
                    protocol = selectedProtocol,
                    preOpenResetBehavior = preOpen,
                    closeResetBehavior = close
                )
                usbSerialManager.uploadHexCustom(
                    firmware = stream,
                    arduino = arduino,
                    percentCallback = percentCallback,
                    messageCallback = messageCallback,
                    completeCallback = completeCallback
                )
            }
        }
    }

    // endregion
}
