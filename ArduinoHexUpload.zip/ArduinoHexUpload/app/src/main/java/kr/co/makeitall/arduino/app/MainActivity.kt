package kr.co.makeitall.arduino.app

import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.launch
import kr.co.makeitall.arduino.Boards
import kr.co.makeitall.arduino.UsbSerialException
import kr.co.makeitall.arduino.UsbSerialManager
import kr.co.makeitall.arduino.ArduinoUploader.Config.Arduino
import kr.co.makeitall.arduino.ArduinoUploader.Config.McuIdentifier
import kr.co.makeitall.arduino.ArduinoUploader.Config.Protocol
import kr.co.makeitall.arduino.app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var usbSerialManager: UsbSerialManager

    private var selectedHexUri: Uri? = null
    private var isUploading = false

    /** Friendly reset-behavior presets exposed in Custom mode. */
    private data class ResetPreset(
        val label: String,
        val preOpen: String? = null,
        val postOpen: String? = null,
        val close: String? = null
    )

    private val resetPresets = listOf(
        ResetPreset(
            label = "Auto DTR toggle (most Arduino / CH340 boards)",
            preOpen = "DTR;true",
            close = "DTR-RTS;250;50"
        ),
        ResetPreset(
            label = "DTR-RTS pulse, inverted (some CP2102 / FTDI adapters)",
            postOpen = "DTR-RTS;50;250;true",
            close = "DTR-RTS;250;50;true"
        ),
        ResetPreset(
            label = "1200bps touch (Leonardo / Micro / native-USB 32U4)",
            preOpen = "1200bps"
        ),
        ResetPreset(
            label = "None (board resets itself / manual reset button)"
        )
    )

    private val openHexFile =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            uri ?: return@registerForActivityResult
            selectedHexUri = uri
            binding.tvHexFileName.text = queryFileName(uri) ?: uri.lastPathSegment ?: uri.toString()
            binding.tvHexFileName.setTextColor(getColor(R.color.text_primary))
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        usbSerialManager = UsbSerialManager(this, lifecycle)
        wireUsbListeners()

        setupHexFileRow()
        setupUploadTypeToggle()
        setupStandardBoardSpinner()
        setupCustomSpinners()
        setupFab()
    }

    // ---------------------------------------------------------------------
    // Setup
    // ---------------------------------------------------------------------

    private fun setupHexFileRow() {
        binding.btnBrowse.setOnClickListener {
            openHexFile.launch(arrayOf("*/*"))
        }
    }

    private fun setupUploadTypeToggle() {
        binding.rgUploadType.setOnCheckedChangeListener { _, checkedId ->
            val standard = checkedId == binding.rbStandard.id
            binding.containerStandard.visibility = if (standard) android.view.View.VISIBLE else android.view.View.GONE
            binding.containerCustom.visibility = if (standard) android.view.View.GONE else android.view.View.VISIBLE
        }
    }

    private fun setupStandardBoardSpinner() {
        binding.rowBoard.label.text = getString(R.string.board_label)
        val boardNames = Boards.values().map { it.boardName }
        binding.rowBoard.spinner.adapter = simpleAdapter(boardNames)
    }

    private fun setupCustomSpinners() {
        binding.rowMcu.label.text = getString(R.string.mcu_label)
        binding.rowMcu.spinner.adapter = simpleAdapter(McuIdentifier.values().map { it.name })

        binding.rowProtocol.label.text = getString(R.string.protocol_label)
        binding.rowProtocol.spinner.adapter = simpleAdapter(Protocol.values().map { it.name })

        binding.rowReset.label.text = getString(R.string.reset_label)
        binding.rowReset.spinner.adapter = simpleAdapter(resetPresets.map { it.label })
    }

    private fun simpleAdapter(items: List<String>) =
        ArrayAdapter(this, android.R.layout.simple_spinner_item, items).also {
            it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }

    private fun setupFab() {
        binding.fabUpload.setOnClickListener { startUpload() }
    }

    private fun wireUsbListeners() {
        usbSerialManager
            .addOnStateListener { state ->
                when (state) {
                    UsbSerialManager.USB_STATE_READY -> refreshConnectionStatus()
                    UsbSerialManager.USB_STATE_CONNECTED -> refreshConnectionStatus()
                    UsbSerialManager.USB_STATE_DISCONNECTED -> {
                        binding.tvConnectionStatus.text = getString(R.string.status_no_device)
                    }
                    else -> Unit
                }
            }
            .addOnPermissionListener { permission ->
                if (permission == UsbSerialManager.USB_PERMISSION_GRANTED) {
                    refreshConnectionStatus()
                } else {
                    binding.tvConnectionStatus.text = getString(R.string.status_permission_needed)
                }
            }
            .addOnErrorListener { error: UsbSerialException ->
                if (!isUploading) {
                    binding.tvConnectionStatus.text = getString(R.string.status_no_device)
                }
            }

        binding.tvConnectionStatus.setOnClickListener {
            usbSerialManager.requestPermission()
        }

        refreshConnectionStatus()
    }

    private fun refreshConnectionStatus() {
        val device = usbSerialManager.usbDevice
        binding.tvConnectionStatus.text = when {
            device == null -> getString(R.string.status_no_device)
            !usbSerialManager.hasPermission() -> getString(R.string.status_permission_needed)
            else -> getString(
                R.string.status_ready,
                device.productName ?: device.deviceName
            )
        }
    }

    // ---------------------------------------------------------------------
    // Upload
    // ---------------------------------------------------------------------

    private fun startUpload() {
        if (isUploading) return

        val uri = selectedHexUri
        if (uri == null) {
            Snackbar.make(binding.coordinator, R.string.error_no_hex_file, Snackbar.LENGTH_SHORT).show()
            return
        }
        if (usbSerialManager.usbDevice == null) {
            Snackbar.make(binding.coordinator, R.string.error_no_usb, Snackbar.LENGTH_SHORT).show()
            return
        }
        if (!usbSerialManager.hasPermission()) {
            Snackbar.make(binding.coordinator, R.string.error_no_permission, Snackbar.LENGTH_LONG).show()
            usbSerialManager.requestPermission()
            return
        }

        val useStandard = binding.rbStandard.isChecked

        beginUploadUi()

        lifecycleScope.launch {
            val stream = contentResolver.openInputStream(uri)
            if (stream == null) {
                endUploadUi(success = false, message = "Could not open the selected file")
                return@launch
            }

            val percentCallback: (Int) -> Unit = { percent ->
                binding.progressBar.progress = percent
                binding.tvStatus.text = getString(R.string.status_uploading, percent)
            }
            val messageCallback: (String) -> Unit = { message ->
                binding.tvStatus.text = message
            }
            val completeCallback: (Boolean) -> Unit = { success ->
                endUploadUi(
                    success = success,
                    message = getString(
                        if (success) R.string.status_success
                        else R.string.status_failure
                    )
                )
            }

            stream.use { hexStream ->
                if (useStandard) {
                    val boardName = binding.rowBoard.spinner.selectedItem as String
                    val board = Boards.values().first { it.boardName == boardName }
                    usbSerialManager.uploadHex(
                        firmware = hexStream,
                        board = board,
                        percentCallback = percentCallback,
                        messageCallback = messageCallback,
                        completeCallback = completeCallback
                    )
                } else {
                    val mcu = McuIdentifier.values()[binding.rowMcu.spinner.selectedItemPosition]
                    val protocol = Protocol.values()[binding.rowProtocol.spinner.selectedItemPosition]
                    val preset = resetPresets[binding.rowReset.spinner.selectedItemPosition]
                    val baudRate = binding.etBaudRate.text.toString().ifBlank { "57600" }.toIntOrNull() ?: 57600

                    val customArduino = Arduino(
                        model = "custom",
                        mcu = mcu,
                        baudRate = baudRate,
                        protocol = protocol,
                        preOpenResetBehavior = preset.preOpen,
                        postOpenResetBehavior = preset.postOpen,
                        closeResetBehavior = preset.close
                    )

                    usbSerialManager.uploadHex(
                        firmware = hexStream,
                        arduino = customArduino,
                        percentCallback = percentCallback,
                        messageCallback = messageCallback,
                        completeCallback = completeCallback
                    )
                }
            }
        }
    }

    private fun beginUploadUi() {
        isUploading = true
        binding.fabUpload.isEnabled = false
        binding.fabUpload.alpha = 0.5f
        binding.progressContainer.visibility = android.view.View.VISIBLE
        binding.progressBar.progress = 0
        binding.tvStatus.text = ""
    }

    private fun endUploadUi(success: Boolean, message: String) {
        isUploading = false
        binding.fabUpload.isEnabled = true
        binding.fabUpload.alpha = 1f
        binding.tvStatus.text = message
        Snackbar.make(binding.coordinator, message, Snackbar.LENGTH_LONG).show()
        refreshConnectionStatus()
    }

    // ---------------------------------------------------------------------
    // Helpers
    // ---------------------------------------------------------------------

    private fun queryFileName(uri: Uri): String? {
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (nameIndex >= 0 && cursor.moveToFirst()) {
                return cursor.getString(nameIndex)
            }
        }
        return null
    }
}
