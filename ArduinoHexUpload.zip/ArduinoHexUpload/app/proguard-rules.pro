# Add project specific ProGuard rules here.
# minifyEnabled is off for the debug build produced by the Colab notebook,
# so these rules only matter if you later turn on a minified release build.
