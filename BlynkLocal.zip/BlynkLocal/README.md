# Blynk Local (Android)

Independent client for a self-hosted Blynk Local Server (0.41.x). Java, framework-only, no native code, no third-party libraries.

- `app/src/main/java/app/blynklocal/core` – pure-Java protocol (framing, auth hash, JSON, models, client, session)
- `app/src/main/java/app/blynklocal/ui` – Activities and widget views
- `tools/ServerIT.java` – integration test against a real server
- `docs/ANALYSIS_AND_REPORT.md` – analysis, dependency inventory, size comparison, test status

Build: open in Android Studio (AGP 8.7.3, compileSdk 35, JDK 17) or use `BlynkLocal_Build_And_Test.ipynb` in Colab (also runs the server test and downloads the APK).
Connect: server address, app port (default 9443, TLS), your email/password. Create an account from the login screen if needed.
