package app.blynklocal.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.*;
import app.blynklocal.core.*;
import java.util.*;

/** Renders one project: widgets positioned on a 4-column grid like the original app; edit mode adds/deletes widgets. */
public class DashboardActivity extends Activity implements Session.PinListener {
    private static final int COLS = 4;
    private static final String[] ADD_TYPES = {"BUTTON", "SWITCH", "SLIDER", "LABELED_VALUE_DISPLAY", "GAUGE", "LEVEL_DISPLAY", "LED", "TERMINAL", "TEXT_INPUT", "NUMBER_INPUT", "STEP", "SEGMENTED_CONTROL", "MENU"};

    private int dashId;
    private Model.Dash dash;
    private FrameLayout grid;
    private LinearLayout tabBar;
    private TextView banner;
    private boolean editing;
    private int tabId;
    private final Map<Long, WidgetFactory.Holder> holders = new HashMap<Long, WidgetFactory.Holder>();

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        dashId = getIntent().getIntExtra("dash", 0);
        dash = Session.I.dash(dashId);
        if (dash == null) { finish(); return; }
        LinearLayout root = Ui.column(this);
        root.setBackgroundColor(Ui.BG);
        Button edit = Ui.button(this, "Edit", false), dev = Ui.button(this, "Devices", false);
        root.addView(Ui.toolbar(this, dash.name, edit, dev));
        banner = Ui.text(this, "", 13, Ui.DANGER);
        root.addView(banner);
        tabBar = new LinearLayout(this);
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.addView(tabBar);
        root.addView(hs);
        grid = new FrameLayout(this);
        ScrollView sv = new ScrollView(this);
        sv.addView(grid);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        edit.setOnClickListener(new View.OnClickListener() { public void onClick(View v) {
            editing = !editing; ((Button) v).setText(editing ? "Done" : "Edit"); buildGrid();
        } });
        dev.setOnClickListener(new View.OnClickListener() { public void onClick(View v) {
            Intent i = new Intent(DashboardActivity.this, DevicesActivity.class);
            i.putExtra("dash", dashId);
            startActivity(i);
        } });
    }

    @Override protected void onStart() {
        super.onStart();
        if (dash == null) return;
        Session.I.addListener(this);
        buildGrid();
        // make this project the live one and ask the server to push the current pin values
        Session.I.request(Proto.ACTIVATE_DASHBOARD, String.valueOf(dashId), new Session.Result() { public void result(String err, String body) {
            if (err != null) banner.setText(err);
            Session.I.request(Proto.APP_SYNC, String.valueOf(dashId), new Session.Result() { public void result(String e, String b) { } });
        } });
    }

    @Override protected void onStop() {
        super.onStop();
        Session.I.removeListener(this);
    }

    private void buildGrid() {
        grid.removeAllViews();
        holders.clear();
        buildTabs();
        DisplayMetrics dm = getResources().getDisplayMetrics();
        final int cell = dm.widthPixels / COLS;
        int bottom = 0;
        for (final Model.Widget w : dash.widgets) {
            if (w.type.equals("TABS") || w.tabId != tabId) continue;
            WidgetFactory.Holder h = WidgetFactory.create(this, dashId, w, editing);
            holders.put(w.id, h);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(cell * Math.min(w.width, COLS) - Ui.dp(this, 8), cell * w.height - Ui.dp(this, 8));
            lp.leftMargin = cell * w.x + Ui.dp(this, 4);
            lp.topMargin = cell * w.y + Ui.dp(this, 4);
            grid.addView(h.view, lp);
            bottom = Math.max(bottom, w.y + w.height);
            if (editing) {
                // transparent overlay catches taps; tap = delete
                View o = new View(this);
                o.setBackground(Ui.rounded(this, 0x33E5534B, 14));
                grid.addView(o, lp);
                o.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { confirmDelete(w); } });
            }
        }
        if (editing) {
            Button add = Ui.button(this, "+ Add widget", true);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-2, -2);
            lp.topMargin = cell * bottom + Ui.dp(this, 8);
            lp.leftMargin = Ui.dp(this, 12);
            grid.addView(add, lp);
            add.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { pickType(); } });
            bottom += 2;
        }
        grid.setMinimumHeight(cell * (bottom + 1));
    }

    private void buildTabs() {
        tabBar.removeAllViews();
        for (Model.Widget w : dash.widgets) {
            if (!"TABS".equals(w.type)) continue;
            for (final String[] t : w.tabs) {
                final int id = Integer.parseInt(t[0]);
                Button b = Ui.button(this, t[1], id == tabId);
                b.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { tabId = id; buildGrid(); } });
                tabBar.addView(b, Ui.lp(-2, -2, 6, 4, 0, 4, this));
            }
        }
    }

    private void confirmDelete(final Model.Widget w) {
        new AlertDialog.Builder(this).setTitle("Delete widget?").setMessage(w.type + " " + w.label)
            .setPositiveButton("Delete", new DialogInterface.OnClickListener() { public void onClick(DialogInterface x, int i) {
                Session.I.request(Proto.DELETE_WIDGET, Proto.join(String.valueOf(dashId), String.valueOf(w.id)), new Session.Result() { public void result(String err, String body) {
                    if (err != null) { banner.setText(err); return; }
                    dash.widgets.remove(w); buildGrid();
                } });
            } }).setNegativeButton("Cancel", null).show();
    }

    private void pickType() {
        new AlertDialog.Builder(this).setTitle("Add widget").setItems(ADD_TYPES, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int i) { configure(ADD_TYPES[i]); }
        }).show();
    }

    private void configure(final String type) {
        LinearLayout f = Ui.column(this);
        f.setPadding(Ui.dp(this, 20), Ui.dp(this, 8), Ui.dp(this, 20), 0);
        final EditText label = Ui.edit(this, "Label", ""), pin = Ui.edit(this, "Virtual pin number", "0"), min = Ui.edit(this, "Min", "0"), max = Ui.edit(this, "Max", "255");
        for (EditText e : new EditText[]{label, pin, min, max}) e.setTextColor(0xFF000000);
        pin.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        f.addView(label); f.addView(pin);
        final boolean ranged = type.equals("SLIDER") || type.equals("GAUGE") || type.equals("LEVEL_DISPLAY") || type.equals("STEP");
        if (ranged) { f.addView(min); f.addView(max); }
        final Spinner devs = new Spinner(this);
        final List<String> names = new ArrayList<String>();
        for (Model.Device d : dash.devices) names.add(d.name + " (#" + d.id + ")");
        devs.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, names));
        f.addView(devs);
        new AlertDialog.Builder(this).setTitle(type).setView(f)
            .setPositiveButton("Add", new DialogInterface.OnClickListener() { public void onClick(DialogInterface x, int i) {
                final Model.Widget w = new Model.Widget();
                w.id = dash.nextWidgetId();
                w.type = type;
                w.label = label.getText().toString();
                try { w.pin = Integer.parseInt(pin.getText().toString()); } catch (NumberFormatException e) { w.pin = 0; }
                w.pinType = "VIRTUAL";
                if (!dash.devices.isEmpty() && devs.getSelectedItemPosition() >= 0) w.deviceId = dash.devices.get(devs.getSelectedItemPosition()).id;
                if (ranged) { try { w.min = Double.parseDouble(min.getText().toString()); w.max = Double.parseDouble(max.getText().toString()); } catch (NumberFormatException e) { } }
                w.tabId = tabId;
                w.width = type.equals("TERMINAL") ? 4 : 2;
                w.height = type.equals("TERMINAL") ? 3 : (type.equals("LED") ? 1 : 2);
                int y = 0;
                for (Model.Widget o : dash.widgets) if (o.tabId == tabId) y = Math.max(y, o.y + o.height);
                w.y = y;
                Session.I.request(Proto.CREATE_WIDGET, Proto.join(String.valueOf(dashId), Json.write(w.toMap())), new Session.Result() { public void result(String err, String body) {
                    if (err != null) { banner.setText(err); return; }
                    dash.widgets.add(w); buildGrid();
                } });
            } }).setNegativeButton("Cancel", null).show();
    }

    public void onPin(Model.PinUpdate u) {
        if (u.dashId != dashId) return;
        for (Model.Widget w : dash.widgets) {
            if (!w.matches(u.deviceId, u.pinType, u.pin)) continue;
            WidgetFactory.Holder h = holders.get(w.id);
            if (h != null) h.onValue(u.value());
        }
    }

    public void onOffline(int deviceId) { }
    public void onConnectionLost(String why) { banner.setText("Connection lost: " + why); }
}
