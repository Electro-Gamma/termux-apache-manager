package app.blynklocal.ui;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Tiny view-building helpers (no XML layouts, no AndroidX => small APK). */
final class Ui {
    static final int BG = 0xFF0F1720, CARD = 0xFF1B2733, TEXT = 0xFFE8EEF4, MUTED = 0xFF8EA0B1, ACCENT = 0xFF23C48E, DANGER = 0xFFE5534B;

    private Ui() { }

    static int dp(Context c, float v) { return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, c.getResources().getDisplayMetrics()); }

    static GradientDrawable rounded(Context c, int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    static LinearLayout column(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    static TextView text(Context c, String s, float sp, int color) {
        TextView t = new TextView(c);
        t.setText(s); t.setTextSize(sp); t.setTextColor(color);
        return t;
    }

    static Button button(Context c, String s, boolean primary) {
        Button b = new Button(c);
        b.setText(s); b.setAllCaps(false);
        b.setTextColor(primary ? BG : TEXT);
        b.setBackground(rounded(c, primary ? ACCENT : CARD, 10));
        b.setPadding(dp(c, 16), dp(c, 10), dp(c, 16), dp(c, 10));
        return b;
    }

    static EditText edit(Context c, String hint, String value) {
        EditText e = new EditText(c);
        e.setHint(hint); e.setText(value);
        e.setTextColor(TEXT); e.setHintTextColor(MUTED);
        e.setSingleLine(true);
        return e;
    }

    static LinearLayout.LayoutParams lp(int w, int h, int l, int t, int r, int b, Context c) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(dp(c, l), dp(c, t), dp(c, r), dp(c, b));
        return p;
    }

    static View toolbar(Context c, String title, View... actions) {
        LinearLayout bar = new LinearLayout(c);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(CARD);
        bar.setPadding(dp(c, 16), dp(c, 8), dp(c, 8), dp(c, 8));
        TextView t = text(c, title, 20, TEXT);
        t.setSingleLine(true);
        bar.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        for (View a : actions) bar.addView(a);
        return bar;
    }

    static int parseColor(int blynkArgb, int fallback) {
        // Blynk stores colors as signed ARGB ints; 0 means "unset"
        return blynkArgb == 0 ? fallback : (blynkArgb | 0xFF000000);
    }

    static int safeColor(String hex, int fb) { try { return Color.parseColor(hex); } catch (Exception e) { return fb; } }
}
