package app.blynklocal.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import app.blynklocal.core.*;
import java.util.LinkedHashMap;
import java.util.Map;

public class ProjectsActivity extends Activity implements Session.PinListener {
    private LinearLayout list;
    private TextView banner;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = Ui.column(this);
        root.setBackgroundColor(Ui.BG);
        Button add = Ui.button(this, "+ New", true), out = Ui.button(this, "Log out", false);
        root.addView(Ui.toolbar(this, "Projects", add, out));
        banner = Ui.text(this, "", 13, Ui.DANGER);
        root.addView(banner);
        list = Ui.column(this);
        list.setPadding(Ui.dp(this, 12), Ui.dp(this, 8), Ui.dp(this, 12), Ui.dp(this, 8));
        ScrollView sv = new ScrollView(this);
        sv.addView(list);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        add.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { createDialog(); } });
        out.setOnClickListener(new View.OnClickListener() { public void onClick(View v) {
            Session.I.disconnect();
            startActivity(new Intent(ProjectsActivity.this, LoginActivity.class));
            finish();
        } });
    }

    @Override protected void onStart() { super.onStart(); Session.I.addListener(this); render(); }
    @Override protected void onStop() { super.onStop(); Session.I.removeListener(this); }

    private void render() {
        list.removeAllViews();
        if (Session.I.dashes.isEmpty()) list.addView(Ui.text(this, "No projects yet. Tap + New.", 14, Ui.MUTED));
        for (final Model.Dash d : Session.I.dashes) {
            LinearLayout card = Ui.column(this);
            card.setBackground(Ui.rounded(this, Ui.CARD, 14));
            card.setPadding(Ui.dp(this, 16), Ui.dp(this, 14), Ui.dp(this, 16), Ui.dp(this, 14));
            card.addView(Ui.text(this, d.name.length() > 0 ? d.name : "Project " + d.id, 18, Ui.TEXT));
            card.addView(Ui.text(this, d.widgets.size() + " widgets, " + d.devices.size() + " devices" + (d.isActive ? " - active" : ""), 12, Ui.MUTED));
            list.addView(card, Ui.lp(-1, -2, 0, 6, 0, 6, this));
            card.setOnClickListener(new View.OnClickListener() { public void onClick(View v) {
                Intent i = new Intent(ProjectsActivity.this, DashboardActivity.class);
                i.putExtra("dash", d.id);
                startActivity(i);
            } });
            card.setOnLongClickListener(new View.OnLongClickListener() { public boolean onLongClick(View v) { deleteDialog(d); return true; } });
        }
    }

    private void createDialog() {
        final EditText name = Ui.edit(this, "Project name", "");
        name.setTextColor(0xFF000000);
        new AlertDialog.Builder(this).setTitle("New project").setView(name)
            .setPositiveButton("Create", new DialogInterface.OnClickListener() { public void onClick(DialogInterface x, int w) {
                final int id = (int) (System.currentTimeMillis() & 0x3FFFFFFF);
                Map<String, Object> m = new LinkedHashMap<String, Object>();
                m.put("id", (long) id); m.put("name", name.getText().toString());
                Session.I.request(Proto.CREATE_DASH, Json.write(m), new Session.Result() { public void result(String err, String body) {
                    if (err != null) { banner.setText(err); return; }
                    Session.I.reloadProfile(new Session.Done() { public void done(String e) { if (e != null) banner.setText(e); else render(); } });
                } });
            } }).setNegativeButton("Cancel", null).show();
    }

    private void deleteDialog(final Model.Dash d) {
        new AlertDialog.Builder(this).setTitle("Delete \"" + d.name + "\"?").setMessage("This permanently removes the project from the server.")
            .setPositiveButton("Delete", new DialogInterface.OnClickListener() { public void onClick(DialogInterface x, int w) {
                Session.I.request(Proto.DELETE_DASH, String.valueOf(d.id), new Session.Result() { public void result(String err, String body) {
                    if (err != null) { banner.setText(err); return; }
                    Session.I.dashes.remove(d); render();
                } });
            } }).setNegativeButton("Cancel", null).show();
    }

    public void onPin(Model.PinUpdate u) { }
    public void onOffline(int deviceId) { }
    public void onConnectionLost(String why) { banner.setText("Connection lost: " + why); }
}
