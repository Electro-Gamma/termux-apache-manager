package app.blynklocal.core;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

/**
 * One connection to a Blynk Local Server (app protocol). Thread-safe sends, one reader thread.
 * Callbacks are invoked on the reader thread; the UI layer must hop to the main thread itself.
 */
public class BlynkClient {

    public interface Listener {
        /** Unsolicited message (hardware pin write, sync, device offline, ...). */
        void onMessage(Proto.Msg m);
        /** Connection ended; {@code error} is null for a normal close(). */
        void onClosed(Exception error);
    }

    public interface Reply {
        /** Reply to a request: either a RESPONSE frame (check {@code m.code}) or a data frame of the same command. */
        void onReply(Proto.Msg m);
        void onError(Exception e);
    }

    private final String host;
    private final int port;
    private final boolean tls;
    private final boolean trustSelfSigned;
    private Socket socket;
    private InputStream in;
    private OutputStream out;
    private volatile boolean closed;
    private int nextId = 1;
    private final Object writeLock = new Object();
    private final Map<Integer, Object[]> pending = new HashMap<Integer, Object[]>();   // id -> {cmd, Reply}
    private Listener listener;
    private Timer pinger;
    private Thread reader;

    public BlynkClient(String host, int port, boolean tls, boolean trustSelfSigned) {
        this.host = host; this.port = port; this.tls = tls; this.trustSelfSigned = trustSelfSigned;
    }

    public void setListener(Listener l) { this.listener = l; }

    /** Blocking connect (TCP + optional TLS handshake). Call from a worker thread. */
    public void connect() throws IOException {
        Socket raw = new Socket();
        raw.connect(new InetSocketAddress(host, port), 10000);
        raw.setTcpNoDelay(true);
        if (tls) {
            try {
                SSLContext ctx = SSLContext.getInstance("TLS");
                if (trustSelfSigned) {
                    ctx.init(null, new TrustManager[]{new TrustAll()}, new SecureRandom());
                } else {
                    ctx.init(null, null, null);   // system trust store
                }
                SSLSocket s = (SSLSocket) ctx.getSocketFactory().createSocket(raw, host, port, true);
                s.startHandshake();
                socket = s;
            } catch (IOException e) {
                try { raw.close(); } catch (IOException ignore) { }
                throw e;
            } catch (java.security.GeneralSecurityException e) {
                try { raw.close(); } catch (IOException ignore) { }
                throw new IOException("TLS setup failed: " + e.getMessage(), e);
            }
        } else {
            socket = raw;
        }
        in = socket.getInputStream();
        out = socket.getOutputStream();
        reader = new Thread(new Runnable() { public void run() { readLoop(); } }, "blynk-reader");
        reader.setDaemon(true);
        reader.start();
        pinger = new Timer("blynk-ping", true);
        pinger.schedule(new TimerTask() { public void run() { try { send(Proto.PING, ""); } catch (IOException ignore) { } } }, 8000, 8000);
    }

    public boolean isClosed() { return closed; }

    /** Fire-and-forget. Returns the message id used. */
    public int send(int cmd, String body) throws IOException {
        int id;
        synchronized (writeLock) {
            id = nextId();
            writeFrame(Proto.encode(cmd, id, body));
        }
        return id;
    }

    /** Request with reply callback. */
    public int request(int cmd, String body, Reply reply) {
        int id;
        try {
            synchronized (writeLock) {
                id = nextId();
                synchronized (pending) { pending.put(id, new Object[]{cmd, reply}); }
                writeFrame(Proto.encode(cmd, id, body));
            }
        } catch (IOException e) {
            reply.onError(e);
            return -1;
        }
        return id;
    }

    /** Replies to a message the server sent us (used by tests that play the server's role is not needed in the app). */
    public void sendRaw(byte[] frame) throws IOException {
        synchronized (writeLock) { writeFrame(frame); }
    }

    private int nextId() {
        int id = nextId;
        nextId = nextId >= 0xFFFF ? 1 : nextId + 1;
        return id;
    }

    private void writeFrame(byte[] f) throws IOException {
        if (closed || out == null) throw new IOException("Not connected");
        out.write(f);
        out.flush();
    }

    private void readLoop() {
        Exception err = null;
        try {
            while (!closed) {
                Proto.Msg m = Proto.read(in);
                Object[] p = null;
                synchronized (pending) {
                    Object[] cand = pending.get(m.id);
                    if (cand != null && (m.cmd == Proto.RESPONSE || m.cmd == (Integer) cand[0])) {
                        p = pending.remove(m.id);
                    }
                }
                if (p != null) {
                    ((Reply) p[1]).onReply(m);
                } else if (m.cmd != Proto.RESPONSE) {
                    Listener l = listener;
                    if (l != null) l.onMessage(m);
                }
            }
        } catch (Exception e) {
            if (!closed) err = e;
        } finally {
            shutdown(err);
        }
    }

    private void shutdown(Exception err) {
        boolean first;
        synchronized (this) { first = !closed || err != null; closed = true; }
        if (pinger != null) pinger.cancel();
        try { if (socket != null) socket.close(); } catch (IOException ignore) { }
        Map<Integer, Object[]> copy;
        synchronized (pending) { copy = new HashMap<Integer, Object[]>(pending); pending.clear(); }
        for (Object[] p : copy.values()) ((Reply) p[1]).onError(err != null ? err : new IOException("Closed"));
        Listener l = listener;
        if (l != null && first) l.onClosed(err);
    }

    public void close() { shutdown(null); }

    private static final class TrustAll implements X509TrustManager {
        public void checkClientTrusted(X509Certificate[] c, String a) { }
        public void checkServerTrusted(X509Certificate[] c, String a) { }
        public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
    }

    // ---------------- high level helpers (bodies as the server expects them) ----------------

    public void login(String email, String password, Reply r) {
        request(Proto.LOGIN, Proto.join(email, Proto.hashPassword(password, email), "Android", "1.0.0", "Blynk"), r);
    }

    public void register(String email, String password, Reply r) {
        request(Proto.REGISTER, Proto.join(email, Proto.hashPassword(password, email), "Blynk"), r);
    }

    public void loadProfile(Reply r) { request(Proto.LOAD_PROFILE_GZIPPED, "", r); }
    public void sync(int dashId, Reply r) { request(Proto.APP_SYNC, String.valueOf(dashId), r); }
    public void activate(int dashId, Reply r) { request(Proto.ACTIVATE_DASHBOARD, String.valueOf(dashId), r); }
    public void deactivate(int dashId, Reply r) { request(Proto.DEACTIVATE_DASHBOARD, String.valueOf(dashId), r); }

    /** Write a pin value to a device: "dashId-deviceId NUL vw NUL pin NUL value". */
    public void writePin(int dashId, int deviceId, char pinType, int pin, String value) throws IOException {
        send(Proto.HARDWARE, Proto.join(dashId + "-" + deviceId, pinType + "w", String.valueOf(pin), value));
    }
}
