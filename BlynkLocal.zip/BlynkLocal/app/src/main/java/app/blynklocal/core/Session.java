package app.blynklocal.core;

import android.os.Handler;
import android.os.Looper;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/** Process-wide connection + profile state. All public callbacks run on the main thread. */
public final class Session {
    public static final Session I = new Session();

    public interface Done { void done(String error); }
    public interface PinListener { void onPin(Model.PinUpdate u); void onOffline(int deviceId); void onConnectionLost(String why); }

    public BlynkClient client;
    public String email;
    public List<Model.Dash> dashes = new ArrayList<Model.Dash>();
    public final Handler main = new Handler(Looper.getMainLooper());
    private final List<PinListener> listeners = new CopyOnWriteArrayList<PinListener>();

    private Session() { }

    public void addListener(PinListener l) { listeners.add(l); }
    public void removeListener(PinListener l) { listeners.remove(l); }

    public boolean connected() { return client != null && !client.isClosed(); }

    public Model.Dash dash(int id) {
        for (Model.Dash d : dashes) if (d.id == id) return d;
        return null;
    }

    /** Connect, authenticate (or register first) and load the profile. */
    public void connect(final String host, final int port, final boolean tls, final boolean trustSelfSigned,
                        final String mail, final String password, final boolean register, final Done cb) {
        disconnect();
        new Thread(new Runnable() {
            public void run() {
                final BlynkClient c = new BlynkClient(host, port, tls, trustSelfSigned);
                try {
                    c.connect();
                } catch (final IOException e) {
                    post(cb, "Cannot connect to " + host + ":" + port + " - " + e.getMessage());
                    return;
                }
                c.setListener(new BlynkClient.Listener() {
                    public void onMessage(final Proto.Msg m) { handle(m); }
                    public void onClosed(final Exception e) {
                        main.post(new Runnable() { public void run() {
                            for (PinListener l : listeners) l.onConnectionLost(e == null ? "closed" : String.valueOf(e.getMessage()));
                        } });
                    }
                });
                client = c;
                email = mail;
                BlynkClient.Reply afterAuth = new BlynkClient.Reply() {
                    public void onReply(Proto.Msg m) {
                        if (m.code != Proto.OK) { c.close(); post(cb, Proto.responseName(m.code)); return; }
                        c.loadProfile(new BlynkClient.Reply() {
                            public void onReply(Proto.Msg p) {
                                try {
                                    if (p.cmd == Proto.RESPONSE) { post(cb, Proto.responseName(p.code)); return; }
                                    dashes = Model.parseProfile(new String(Proto.gunzip(p.body), Proto.UTF8));
                                    post(cb, null);
                                } catch (Exception e) { post(cb, "Bad profile: " + e); }
                            }
                            public void onError(Exception e) { post(cb, String.valueOf(e.getMessage())); }
                        });
                    }
                    public void onError(Exception e) { post(cb, String.valueOf(e.getMessage())); }
                };
                if (register) {
                    c.register(mail, password, new BlynkClient.Reply() {
                        public void onReply(Proto.Msg m) {
                            if (m.code != Proto.OK) { c.close(); post(cb, Proto.responseName(m.code)); return; }
                            c.login(mail, password, afterAuthRef(c, cb));
                        }
                        public void onError(Exception e) { post(cb, String.valueOf(e.getMessage())); }
                    });
                } else {
                    c.login(mail, password, afterAuth);
                }
            }
        }, "blynk-connect").start();
    }

    private BlynkClient.Reply afterAuthRef(final BlynkClient c, final Done cb) {
        return new BlynkClient.Reply() {
            public void onReply(Proto.Msg m) {
                if (m.code != Proto.OK) { c.close(); post(cb, Proto.responseName(m.code)); return; }
                c.loadProfile(new BlynkClient.Reply() {
                    public void onReply(Proto.Msg p) {
                        try {
                            dashes = Model.parseProfile(new String(Proto.gunzip(p.body), Proto.UTF8));
                            post(cb, null);
                        } catch (Exception e) { post(cb, "Bad profile: " + e); }
                    }
                    public void onError(Exception e) { post(cb, String.valueOf(e.getMessage())); }
                });
            }
            public void onError(Exception e) { post(cb, String.valueOf(e.getMessage())); }
        };
    }

    public void reloadProfile(final Done cb) {
        if (!connected()) { cb.done("Not connected"); return; }
        client.loadProfile(new BlynkClient.Reply() {
            public void onReply(Proto.Msg p) {
                try {
                    dashes = Model.parseProfile(new String(Proto.gunzip(p.body), Proto.UTF8));
                    post(cb, null);
                } catch (Exception e) { post(cb, "Bad profile: " + e); }
            }
            public void onError(Exception e) { post(cb, String.valueOf(e.getMessage())); }
        });
    }

    /** Generic request: cb gets null on RESPONSE OK / data frame, else an error text; second arg is the reply body text. */
    public interface Result { void result(String error, String body); }

    public void request(int cmd, String body, final Result r) {
        if (!connected()) { r.result("Not connected", null); return; }
        client.request(cmd, body, new BlynkClient.Reply() {
            public void onReply(final Proto.Msg m) {
                final String err = m.cmd == Proto.RESPONSE && m.code != Proto.OK ? Proto.responseName(m.code) : null;
                final String txt = m.cmd == Proto.RESPONSE ? "" : m.text();
                main.post(new Runnable() { public void run() { r.result(err, txt); } });
            }
            public void onError(final Exception e) { main.post(new Runnable() { public void run() { r.result(String.valueOf(e.getMessage()), null); } }); }
        });
    }

    public void writePin(int dashId, int deviceId, char type, int pin, String value) {
        try { if (connected()) client.writePin(dashId, deviceId, type, pin, value); } catch (IOException ignore) { }
    }

    private void handle(Proto.Msg m) {
        if (m.cmd == Proto.HARDWARE) {
            final Model.PinUpdate u = Model.PinUpdate.parse(m.fields());
            if (u == null) return;
            final Model.Dash d = dash(u.dashId);
            if (d != null) for (Model.Widget w : d.widgets) if (w.matches(u.deviceId, u.pinType, u.pin)) w.value = u.value();
            main.post(new Runnable() { public void run() { for (PinListener l : listeners) l.onPin(u); } });
        } else if (m.cmd == Proto.DEVICE_OFFLINE) {
            String[] f = m.fields();
            int id = 0;
            try { id = Integer.parseInt(f[f.length - 1].split("-")[f[f.length - 1].contains("-") ? 1 : 0]); } catch (Exception ignore) { }
            final int dev = id;
            main.post(new Runnable() { public void run() { for (PinListener l : listeners) l.onOffline(dev); } });
        }
    }

    private void post(final Done cb, final String err) {
        main.post(new Runnable() { public void run() { cb.done(err); } });
    }

    public void disconnect() {
        if (client != null) { client.close(); client = null; }
    }
}
