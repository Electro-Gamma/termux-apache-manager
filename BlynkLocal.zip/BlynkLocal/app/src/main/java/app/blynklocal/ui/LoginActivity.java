package app.blynklocal.ui;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import app.blynklocal.core.Session;

public class LoginActivity extends Activity {
    private EditText host, port, email, pass;
    private CheckBox tls, trust;
    private TextView status;
    private Button login, register;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        final SharedPreferences sp = getSharedPreferences("srv", MODE_PRIVATE);
        LinearLayout root = Ui.column(this);
        root.setBackgroundColor(Ui.BG);
        root.setPadding(Ui.dp(this, 24), Ui.dp(this, 48), Ui.dp(this, 24), Ui.dp(this, 24));
        root.addView(Ui.text(this, "Blynk Local", 30, Ui.ACCENT));
        root.addView(Ui.text(this, "Connect to your own Blynk server", 14, Ui.MUTED));
        host = Ui.edit(this, "Server address (e.g. 192.168.1.10)", sp.getString("host", ""));
        port = Ui.edit(this, "App port (default 9443 TLS)", sp.getString("port", "9443"));
        port.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        email = Ui.edit(this, "Email", sp.getString("email", ""));
        email.setInputType(android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        pass = Ui.edit(this, "Password", "");
        pass.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        tls = new CheckBox(this); tls.setText("Use TLS"); tls.setTextColor(Ui.TEXT); tls.setChecked(sp.getBoolean("tls", true));
        trust = new CheckBox(this); trust.setText("Trust self-signed certificate"); trust.setTextColor(Ui.TEXT); trust.setChecked(sp.getBoolean("trust", true));
        login = Ui.button(this, "Log in", true);
        register = Ui.button(this, "Create account", false);
        status = Ui.text(this, "", 13, Ui.DANGER);
        View[] vs = {host, port, email, pass, tls, trust, login, register, status};
        for (View v : vs) root.addView(v, Ui.lp(-1, -2, 0, 8, 0, 0, this));
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Ui.BG);
        sv.addView(root);
        setContentView(sv);
        login.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { go(false); } });
        register.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { go(true); } });
    }

    private void go(boolean reg) {
        final String h = host.getText().toString().trim(), e = email.getText().toString().trim(), p = pass.getText().toString();
        int pt;
        try { pt = Integer.parseInt(port.getText().toString().trim()); } catch (NumberFormatException ex) { status.setText("Invalid port"); return; }
        if (h.length() == 0 || e.length() == 0 || p.length() == 0) { status.setText("Fill in address, email and password"); return; }
        getSharedPreferences("srv", MODE_PRIVATE).edit().putString("host", h).putString("port", port.getText().toString().trim())
                .putString("email", e).putBoolean("tls", tls.isChecked()).putBoolean("trust", trust.isChecked()).apply();
        status.setTextColor(Ui.MUTED); status.setText("Connecting...");
        login.setEnabled(false); register.setEnabled(false);
        Session.I.connect(h, pt, tls.isChecked(), trust.isChecked(), e, p, reg, new Session.Done() {
            public void done(String error) {
                login.setEnabled(true); register.setEnabled(true);
                if (error != null) { status.setTextColor(Ui.DANGER); status.setText(error); return; }
                startActivity(new Intent(LoginActivity.this, ProjectsActivity.class));
                finish();
            }
        });
    }
}
