package app.blynklocal.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import app.blynklocal.core.*;
import java.util.Map;

/** Devices of one project: show/copy auth token, refresh token, add, rename, delete. */
public class DevicesActivity extends Activity {
    private int dashId;
    private LinearLayout list;
    private TextView banner;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        dashId = getIntent().getIntExtra("dash", 0);
        LinearLayout root = Ui.column(this);
        root.setBackgroundColor(Ui.BG);
        Button add = Ui.button(this, "+ Device", true);
        root.addView(Ui.toolbar(this, "Devices", add));
        banner = Ui.text(this, "", 13, Ui.DANGER);
        root.addView(banner);
        list = Ui.column(this);
        list.setPadding(Ui.dp(this, 12), Ui.dp(this, 8), Ui.dp(this, 12), Ui.dp(this, 8));
        ScrollView sv = new ScrollView(this);
        sv.addView(list);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        add.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { addDialog(); } });
        render();
    }

    private Model.Dash dash() { return Session.I.dash(dashId); }

    private void render() {
        list.removeAllViews();
        Model.Dash d = dash();
        if (d == null) return;
        for (final Model.Device dev : d.devices) {
            LinearLayout card = Ui.column(this);
            card.setBackground(Ui.rounded(this, Ui.CARD, 14));
            card.setPadding(Ui.dp(this, 16), Ui.dp(this, 12), Ui.dp(this, 16), Ui.dp(this, 12));
            card.addView(Ui.text(this, dev.name + "  (" + dev.boardType + ")", 16, Ui.TEXT));
            card.addView(Ui.text(this, "Status: " + dev.status, 12, "ONLINE".equals(dev.status) ? Ui.ACCENT : Ui.MUTED));
            TextView tok = Ui.text(this, dev.token == null ? "(no token)" : dev.token, 13, Ui.MUTED);
            tok.setTypeface(android.graphics.Typeface.MONOSPACE);
            card.addView(tok);
            LinearLayout row = new LinearLayout(this);
            Button copy = Ui.button(this, "Copy token", false), ref = Ui.button(this, "New token", false), del = Ui.button(this, "Delete", false);
            row.addView(copy); row.addView(ref); row.addView(del);
            card.addView(row);
            list.addView(card, Ui.lp(-1, -2, 0, 6, 0, 6, this));
            copy.setOnClickListener(new View.OnClickListener() { public void onClick(View v) {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("token", dev.token));
                Toast.makeText(DevicesActivity.this, "Token copied", Toast.LENGTH_SHORT).show();
            } });
            ref.setOnClickListener(new View.OnClickListener() { public void onClick(View v) {
                Session.I.request(Proto.REFRESH_TOKEN, Proto.join(String.valueOf(dashId), String.valueOf(dev.id)), new Session.Result() { public void result(String err, String body) {
                    if (err != null) { banner.setText(err); return; }
                    dev.token = body; render();
                } });
            } });
            del.setOnClickListener(new View.OnClickListener() { public void onClick(View v) {
                Session.I.request(Proto.DELETE_DEVICE, Proto.join(String.valueOf(dashId), String.valueOf(dev.id)), new Session.Result() { public void result(String err, String body) {
                    if (err != null) { banner.setText(err); return; }
                    dash().devices.remove(dev); render();
                } });
            } });
        }
    }

    private void addDialog() {
        final EditText name = Ui.edit(this, "Device name", "");
        name.setTextColor(0xFF000000);
        new AlertDialog.Builder(this).setTitle("New device").setView(name)
            .setPositiveButton("Create", new DialogInterface.OnClickListener() { public void onClick(DialogInterface x, int w) {
                Model.Device nd = new Model.Device();
                nd.id = dash().nextDeviceId() + (int) (System.currentTimeMillis() % 100000);
                nd.name = name.getText().toString();
                Session.I.request(Proto.CREATE_DEVICE, Proto.join(String.valueOf(dashId), Json.write(nd.toMap())), new Session.Result() { public void result(String err, String body) {
                    if (err != null) { banner.setText(err); return; }
                    try {
                        Model.Device created = Model.Device.from(Json.parseObject(body));
                        dash().devices.add(created); render();
                    } catch (Exception e) { banner.setText("Unexpected reply: " + e.getMessage()); }
                } });
            } }).setNegativeButton("Cancel", null).show();
    }
}
