package app.blynklocal.core;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Plain data classes for the profile JSON the server sends (field names from the server's model classes). */
public final class Model {
    private Model() { }

    public static String strOr(Map<String, Object> m, String k, String d) { return m == null ? d : Json.str(m, k, d); }
    public static double dblOr(Map<String, Object> m, String k, double d) { return m == null ? d : Json.dbl(m, k, d); }

    public static final class Device {
        public int id;
        public String name = "";
        public String boardType = "Generic Board";
        public String connectionType = "WI_FI";
        public String token;
        public String status = "OFFLINE";
        public Map<String, Object> raw;

        public static Device from(Map<String, Object> m) {
            Device d = new Device();
            d.raw = m;
            d.id = Json.num(m, "id", 0);
            d.name = Json.str(m, "name", "");
            d.boardType = Json.str(m, "boardType", "Generic Board");
            d.connectionType = Json.str(m, "connectionType", "WI_FI");
            d.token = Json.str(m, "token", null);
            d.status = Json.str(m, "status", "OFFLINE");
            return d;
        }

        public Map<String, Object> toMap() {
            Map<String, Object> m = raw != null ? new LinkedHashMap<String, Object>(raw) : new LinkedHashMap<String, Object>();
            m.put("id", (long) id);
            m.put("name", name);
            m.put("boardType", boardType);
            m.put("connectionType", connectionType);
            return m;
        }
    }

    public static final class Widget {
        public long id;
        public String type = "";
        public int x, y, width = 1, height = 1, tabId;
        public String label = "";
        public int color;
        public int deviceId;
        public String pinType = "VIRTUAL";
        public int pin = -1;
        public String value;
        public double min = 0, max = 255;
        public boolean pushMode;
        public String onLabel, offLabel;
        public List<String> labels = new ArrayList<String>();   // SEGMENTED_CONTROL / MENU
        public List<String[]> tabs = new ArrayList<String[]>(); // TABS: {id, label}
        public String url;                                      // VIDEO
        public boolean sendOnRelease;
        public boolean terminalInputOn = true;
        public Map<String, Object> raw;

        public static Widget from(Map<String, Object> m) {
            Widget w = new Widget();
            w.raw = m;
            w.id = Json.lng(m, "id", 0);
            w.type = Json.str(m, "type", "");
            w.x = Json.num(m, "x", 0); w.y = Json.num(m, "y", 0);
            w.width = Math.max(1, Json.num(m, "width", 1)); w.height = Math.max(1, Json.num(m, "height", 1));
            w.tabId = Json.num(m, "tabId", 0);
            w.label = Json.str(m, "label", "");
            w.color = Json.num(m, "color", 0);
            w.deviceId = Json.num(m, "deviceId", 0);
            w.pinType = Json.str(m, "pinType", "VIRTUAL");
            w.pin = Json.num(m, "pin", -1);
            w.value = Json.str(m, "value", null);
            w.min = Json.dbl(m, "min", 0); w.max = Json.dbl(m, "max", 255);
            w.pushMode = Json.bool(m, "pushMode", false);
            w.onLabel = Json.str(m, "onLabel", null); w.offLabel = Json.str(m, "offLabel", null);
            for (Object o : Json.arr(m.get("labels"))) w.labels.add(String.valueOf(o));
            for (Object o : Json.arr(m.get("tabs"))) {
                Map<String, Object> t = Json.obj(o);
                if (t != null) w.tabs.add(new String[]{String.valueOf(Json.num(t, "id", 0)), Json.str(t, "label", "")});
            }
            w.url = Json.str(m, "url", null);
            w.sendOnRelease = Json.bool(m, "sendOnReleaseOn", false);
            w.terminalInputOn = Json.bool(m, "terminalInputOn", true);
            return w;
        }

        /** Server-side pin type letter used on the wire: v, d or a. */
        public char pinChar() {
            return "DIGITAL".equals(pinType) ? 'd' : "ANALOG".equals(pinType) ? 'a' : 'v';
        }

        public boolean usesPin() { return pin >= 0; }

        public boolean matches(int dev, char pc, int p) {
            return usesPin() && deviceId == dev && pin == p && pc == pinChar();
        }

        public Map<String, Object> toMap() {
            Map<String, Object> m = raw != null ? new LinkedHashMap<String, Object>(raw) : new LinkedHashMap<String, Object>();
            m.put("id", id); m.put("type", type);
            m.put("x", (long) x); m.put("y", (long) y); m.put("width", (long) width); m.put("height", (long) height);
            m.put("tabId", (long) tabId); m.put("label", label); m.put("color", (long) color);
            m.put("deviceId", (long) deviceId); m.put("pinType", pinType); m.put("pin", (long) pin);
            m.put("min", min); m.put("max", max);
            if (value != null) m.put("value", value);
            return m;
        }
    }

    public static final class Dash {
        public int id;
        public String name = "";
        public boolean isActive;
        public boolean keepScreenOn;
        public List<Device> devices = new ArrayList<Device>();
        public List<Widget> widgets = new ArrayList<Widget>();
        public Map<String, Object> raw;

        public static Dash from(Map<String, Object> m) {
            Dash d = new Dash();
            d.raw = m;
            d.id = Json.num(m, "id", 0);
            d.name = Json.str(m, "name", "");
            d.isActive = Json.bool(m, "isActive", false);
            d.keepScreenOn = Json.bool(m, "keepScreenOn", false);
            for (Object o : Json.arr(m.get("devices"))) { Map<String, Object> dm = Json.obj(o); if (dm != null) d.devices.add(Device.from(dm)); }
            for (Object o : Json.arr(m.get("widgets"))) { Map<String, Object> wm = Json.obj(o); if (wm != null) d.widgets.add(Widget.from(wm)); }
            return d;
        }

        public Device device(int id) {
            for (Device d : devices) if (d.id == id) return d;
            return null;
        }

        public long nextWidgetId() {
            long max = 0;
            for (Widget w : widgets) if (w.id < 200000 && w.id > max) max = w.id;
            return max + 1;
        }

        public int nextDeviceId() {
            int max = -1;
            for (Device d : devices) if (d.id > max) max = d.id;
            return max + 1;
        }
    }

    /** The user's whole profile as returned by LOAD_PROFILE_GZIPPED with an empty body. */
    public static List<Dash> parseProfile(String json) {
        Map<String, Object> root = Json.parseObject(json);
        List<Dash> out = new ArrayList<Dash>();
        for (Object o : Json.arr(root.get("dashBoards"))) { Map<String, Object> m = Json.obj(o); if (m != null) out.add(Dash.from(m)); }
        return out;
    }

    /** A pin write that arrived from hardware (or another app): body "dashId-deviceId NUL v|d|a w NUL pin NUL value...". */
    public static final class PinUpdate {
        public int dashId, deviceId, pin;
        public char pinType;
        public String[] values;

        public String value() { return values.length > 0 ? values[0] : ""; }

        public static PinUpdate parse(String[] f) {
            // f[0] = "dashId[-deviceId]", f[1] = "vw"/"dw"/"aw", f[2] = pin, f[3..] = values
            if (f.length < 4 || f[1].length() != 2 || f[1].charAt(1) != 'w') return null;
            try {
                PinUpdate u = new PinUpdate();
                String[] ids = f[0].split("-");
                u.dashId = Integer.parseInt(ids[0]);
                u.deviceId = ids.length > 1 ? Integer.parseInt(ids[1]) : 0;
                u.pinType = f[1].charAt(0);
                u.pin = Integer.parseInt(f[2]);
                u.values = new String[f.length - 3];
                System.arraycopy(f, 3, u.values, 0, u.values.length);
                return u;
            } catch (NumberFormatException e) {
                return null;
            }
        }
    }
}
