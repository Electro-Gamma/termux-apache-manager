package app.blynklocal.ui;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import app.blynklocal.core.Model;
import app.blynklocal.core.Session;

/** Builds a native View per widget type. Types not listed show a labelled placeholder (see docs/FEATURES.md). */
final class WidgetFactory {

    /** A rendered widget; {@link #onValue} is called on the main thread when a pin value arrives. */
    abstract static class Holder {
        View view;
        abstract void onValue(String v);
        void onOffline() { }
    }

    private WidgetFactory() { }

    static boolean supported(String type) {
        switch (type) {
            case "BUTTON": case "STYLED_BUTTON": case "SWITCH": case "SLIDER": case "VERTICAL_SLIDER":
            case "LABELED_VALUE_DISPLAY": case "DIGIT4_DISPLAY": case "GAUGE": case "LEVEL_DISPLAY":
            case "VERTICAL_LEVEL_DISPLAY": case "LED": case "TERMINAL": case "TEXT_INPUT": case "NUMBER_INPUT":
            case "STEP": case "VERTICAL_STEP": case "SEGMENTED_CONTROL": case "MENU":
                return true;
            default: return false;
        }
    }

    static Holder create(final Context c, final int dashId, final Model.Widget w, final boolean editing) {
        final Holder h;
        switch (w.type) {
            case "BUTTON": case "STYLED_BUTTON": h = button(c, dashId, w); break;
            case "SWITCH": h = toggle(c, dashId, w); break;
            case "SLIDER": case "VERTICAL_SLIDER": h = slider(c, dashId, w); break;
            case "LABELED_VALUE_DISPLAY": case "DIGIT4_DISPLAY": h = display(c, w); break;
            case "GAUGE": case "LEVEL_DISPLAY": case "VERTICAL_LEVEL_DISPLAY": h = level(c, w); break;
            case "LED": h = led(c, w); break;
            case "TERMINAL": h = terminal(c, dashId, w); break;
            case "TEXT_INPUT": case "NUMBER_INPUT": h = input(c, dashId, w); break;
            case "STEP": case "VERTICAL_STEP": h = step(c, dashId, w); break;
            case "SEGMENTED_CONTROL": case "MENU": h = choice(c, dashId, w); break;
            default: h = placeholder(c, w);
        }
        if (w.value != null) h.onValue(w.value);
        if (editing) {   // block interaction while editing, overlay handled by the activity
            h.view.setEnabled(false);
        }
        return h;
    }

    private static LinearLayout card(Context c, String title) {
        LinearLayout l = Ui.column(c);
        l.setBackground(Ui.rounded(c, Ui.CARD, 14));
        l.setPadding(Ui.dp(c, 10), Ui.dp(c, 8), Ui.dp(c, 10), Ui.dp(c, 8));
        l.setGravity(Gravity.CENTER);
        if (title != null && title.length() > 0) {
            TextView t = Ui.text(c, title, 12, Ui.MUTED);
            t.setSingleLine(true);
            l.addView(t, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        return l;
    }

    private static int accent(Model.Widget w) { return Ui.parseColor(w.color, Ui.ACCENT); }

    private static String onVal(Model.Widget w) { String s = Model.strOr(w.raw, "onValue", "1"); return s; }
    private static String offVal(Model.Widget w) { return Model.strOr(w.raw, "offValue", "0"); }

    private static void send(Model.Widget w, int dashId, String v) {
        Session.I.writePin(dashId, w.deviceId, w.pinChar(), w.pin, v);
    }

    // ---- BUTTON / STYLED_BUTTON ----
    private static Holder button(final Context c, final int dashId, final Model.Widget w) {
        final LinearLayout card = card(c, null);
        final Button b = Ui.button(c, w.label.length() > 0 ? w.label : "Button", true);
        final boolean[] on = {false};
        final Runnable paint = new Runnable() { public void run() {
            b.setBackground(Ui.rounded(c, on[0] ? accent(w) : Ui.BG, 12));
            b.setTextColor(on[0] ? Ui.BG : Ui.TEXT);
            String t = on[0] ? w.onLabel : w.offLabel;
            b.setText(t != null && t.length() > 0 ? t : (w.label.length() > 0 ? w.label : "Button"));
        } };
        paint.run();
        b.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent e) {
                if (!v.isEnabled()) return false;
                if (w.pushMode) {
                    if (e.getAction() == MotionEvent.ACTION_DOWN) { on[0] = true; send(w, dashId, onVal(w)); paint.run(); return true; }
                    if (e.getAction() == MotionEvent.ACTION_UP || e.getAction() == MotionEvent.ACTION_CANCEL) { on[0] = false; send(w, dashId, offVal(w)); paint.run(); return true; }
                } else if (e.getAction() == MotionEvent.ACTION_UP) {
                    on[0] = !on[0]; send(w, dashId, on[0] ? onVal(w) : offVal(w)); paint.run();
                }
                return e.getAction() == MotionEvent.ACTION_DOWN || !w.pushMode;
            }
        });
        card.addView(b, new LinearLayout.LayoutParams(-1, -1));
        Holder h = new Holder() { void onValue(String v) { on[0] = v.equals(onVal(w)) || v.equals("1"); paint.run(); } };
        h.view = card; return h;
    }

    // ---- SWITCH ----
    private static Holder toggle(Context c, final int dashId, final Model.Widget w) {
        LinearLayout card = card(c, w.label);
        final Switch s = new Switch(c);
        card.addView(s);
        s.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton b, boolean on) { if (b.isPressed()) send(w, dashId, on ? onVal(w) : offVal(w)); }
        });
        Holder h = new Holder() { void onValue(String v) { s.setChecked(v.equals(onVal(w)) || v.equals("1")); } };
        h.view = card; return h;
    }

    // ---- SLIDER ----
    private static Holder slider(Context c, final int dashId, final Model.Widget w) {
        final LinearLayout card = card(c, w.label);
        final TextView val = Ui.text(c, "", 16, Ui.TEXT);
        final SeekBar sb = new SeekBar(c);
        final int min = (int) w.min, max = Math.max((int) w.max, min + 1);
        sb.setMax(max - min);
        sb.setProgress(0);
        card.addView(val);
        card.addView(sb, new LinearLayout.LayoutParams(-1, -2));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            long last;
            public void onProgressChanged(SeekBar s, int p, boolean user) {
                val.setText(String.valueOf(p + min));
                long now = System.currentTimeMillis();
                if (user && !w.sendOnRelease && now - last > 100) { last = now; send(w, dashId, String.valueOf(p + min)); }
            }
            public void onStartTrackingTouch(SeekBar s) { }
            public void onStopTrackingTouch(SeekBar s) { send(w, dashId, String.valueOf(s.getProgress() + min)); }
        });
        Holder h = new Holder() { void onValue(String v) { try { int p = (int) Double.parseDouble(v) - min; sb.setProgress(Math.max(0, Math.min(p, max - min))); val.setText(v); } catch (NumberFormatException ignore) { } } };
        h.view = card; return h;
    }

    // ---- value displays ----
    private static Holder display(Context c, final Model.Widget w) {
        LinearLayout card = card(c, w.label);
        final TextView t = Ui.text(c, "-", 26, accent(w));
        t.setGravity(Gravity.CENTER);
        card.addView(t);
        Holder h = new Holder() { void onValue(String v) { t.setText(v); } };
        h.view = card; return h;
    }

    private static Holder level(Context c, final Model.Widget w) {
        LinearLayout card = card(c, w.label);
        final TextView t = Ui.text(c, "-", 18, Ui.TEXT);
        final ProgressBar pb = new ProgressBar(c, null, android.R.attr.progressBarStyleHorizontal);
        final int min = (int) w.min, max = Math.max((int) w.max, min + 1);
        pb.setMax(max - min);
        card.addView(t);
        card.addView(pb, new LinearLayout.LayoutParams(-1, -2));
        Holder h = new Holder() { void onValue(String v) { try { pb.setProgress((int) Double.parseDouble(v) - min); } catch (NumberFormatException ignore) { } t.setText(v); } };
        h.view = card; return h;
    }

    // ---- LED ----
    private static Holder led(Context c, final Model.Widget w) {
        LinearLayout card = card(c, w.label);
        final View dot = new View(c);
        final GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(0xFF3A4856);
        dot.setBackground(g);
        card.addView(dot, new LinearLayout.LayoutParams(Ui.dp(c, 34), Ui.dp(c, 34)));
        Holder h = new Holder() { void onValue(String v) {
            boolean on;
            try { on = Double.parseDouble(v) > 0; } catch (NumberFormatException e) { on = false; }
            g.setColor(on ? accent(w) : 0xFF3A4856);
        } };
        h.view = card; return h;
    }

    // ---- TERMINAL ----
    private static Holder terminal(final Context c, final int dashId, final Model.Widget w) {
        LinearLayout card = card(c, w.label);
        final TextView log = Ui.text(c, "", 12, Ui.TEXT);
        log.setTypeface(android.graphics.Typeface.MONOSPACE);
        final ScrollView sv = new ScrollView(c);
        sv.addView(log);
        card.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));
        if (w.terminalInputOn) {
            LinearLayout row = new LinearLayout(c);
            final EditText in = Ui.edit(c, "Send", "");
            Button go = Ui.button(c, "Send", true);
            row.addView(in, new LinearLayout.LayoutParams(0, -2, 1));
            row.addView(go);
            card.addView(row);
            go.setOnClickListener(new View.OnClickListener() { public void onClick(View v) {
                String s = in.getText().toString();
                if (s.length() == 0) return;
                send(w, dashId, s);
                log.append("> " + s + "\n");
                in.setText("");
            } });
        }
        Holder h = new Holder() { void onValue(String v) { log.append(v + "\n"); sv.fullScroll(View.FOCUS_DOWN); } };
        h.view = card; return h;
    }

    // ---- TEXT_INPUT / NUMBER_INPUT ----
    private static Holder input(Context c, final int dashId, final Model.Widget w) {
        LinearLayout card = card(c, w.label);
        final EditText in = Ui.edit(c, "", "");
        if ("NUMBER_INPUT".equals(w.type)) in.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL | android.text.InputType.TYPE_NUMBER_FLAG_SIGNED);
        Button go = Ui.button(c, "Send", true);
        card.addView(in, new LinearLayout.LayoutParams(-1, -2));
        card.addView(go);
        go.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { send(w, dashId, in.getText().toString()); } });
        Holder h = new Holder() { void onValue(String v) { in.setText(v); } };
        h.view = card; return h;
    }

    // ---- STEP ----
    private static Holder step(Context c, final int dashId, final Model.Widget w) {
        LinearLayout card = card(c, w.label);
        final double stepSize = Model.dblOr(w.raw, "step", 1);
        final double[] cur = {w.min};
        LinearLayout row = new LinearLayout(c);
        row.setGravity(Gravity.CENTER);
        Button minus = Ui.button(c, "-", false), plus = Ui.button(c, "+", true);
        final TextView t = Ui.text(c, "", 20, Ui.TEXT);
        t.setPadding(Ui.dp(c, 14), 0, Ui.dp(c, 14), 0);
        row.addView(minus); row.addView(t); row.addView(plus);
        card.addView(row);
        final Runnable show = new Runnable() { public void run() { t.setText(fmt(cur[0])); } };
        show.run();
        minus.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { cur[0] = Math.max(w.min, cur[0] - stepSize); show.run(); send(w, dashId, fmt(cur[0])); } });
        plus.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { cur[0] = Math.min(w.max, cur[0] + stepSize); show.run(); send(w, dashId, fmt(cur[0])); } });
        Holder h = new Holder() { void onValue(String v) { try { cur[0] = Double.parseDouble(v); show.run(); } catch (NumberFormatException ignore) { } } };
        h.view = card; return h;
    }

    private static String fmt(double d) { return d == Math.rint(d) ? String.valueOf((long) d) : String.valueOf(d); }

    // ---- SEGMENTED_CONTROL / MENU ----
    private static Holder choice(Context c, final int dashId, final Model.Widget w) {
        LinearLayout card = card(c, w.label);
        final Spinner sp = new Spinner(c);
        sp.setAdapter(new ArrayAdapter<String>(c, android.R.layout.simple_spinner_dropdown_item, w.labels));
        card.addView(sp, new LinearLayout.LayoutParams(-1, -2));
        final boolean[] user = {false};
        sp.setOnTouchListener(new View.OnTouchListener() { public boolean onTouch(View v, MotionEvent e) { user[0] = true; return false; } });
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> p, View v, int pos, long id) { if (user[0]) { user[0] = false; send(w, dashId, String.valueOf(pos)); } }
            public void onNothingSelected(AdapterView<?> p) { }
        });
        Holder h = new Holder() { void onValue(String v) { try { int i = Integer.parseInt(v); if (i >= 0 && i < w.labels.size()) sp.setSelection(i); } catch (NumberFormatException ignore) { } } };
        h.view = card; return h;
    }

    private static Holder placeholder(Context c, Model.Widget w) {
        LinearLayout card = card(c, w.label);
        card.addView(Ui.text(c, w.type.toLowerCase().replace('_', ' '), 12, Ui.MUTED));
        card.addView(Ui.text(c, "not supported in this app", 11, Ui.MUTED));
        Holder h = new Holder() { void onValue(String v) { } };
        h.view = card; return h;
    }
}
