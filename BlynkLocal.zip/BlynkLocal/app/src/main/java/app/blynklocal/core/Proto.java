package app.blynklocal.core;

import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.security.MessageDigest;

/**
 * Blynk Local Server wire protocol, as implemented by server 0.41.x
 * (cc.blynk.server.core.protocol.* in the server source):
 *
 *   frame  = command:u8 | messageId:u16 (big endian) | lengthOrCode:u16 (big endian) | body
 *   command 0 (RESPONSE) frames carry a status code in place of the length and have no body.
 *   body   = UTF-8 text, fields separated by NUL (0x00); LOAD_PROFILE_GZIPPED carries gzip bytes.
 */
public final class Proto {
    private Proto() { }

    public static final Charset UTF8 = Charset.forName("UTF-8");
    public static final char SEP = '\0';

    // commands used by this client (values from Command.java of the server)
    public static final int RESPONSE = 0, REGISTER = 1, LOGIN = 2, HARDWARE_CONNECTED = 4, PING = 6,
            ACTIVATE_DASHBOARD = 7, DEACTIVATE_DASHBOARD = 8, REFRESH_TOKEN = 9, HARDWARE_SYNC = 16,
            BLYNK_INTERNAL = 17, SET_WIDGET_PROPERTY = 19, HARDWARE = 20, CREATE_DASH = 21, UPDATE_DASH = 22,
            DELETE_DASH = 23, LOAD_PROFILE_GZIPPED = 24, APP_SYNC = 25, HARDWARE_LOGIN = 29,
            CREATE_WIDGET = 33, UPDATE_WIDGET = 34, DELETE_WIDGET = 35, GET_ENERGY = 36, GET_SERVER = 40,
            CREATE_DEVICE = 42, UPDATE_DEVICE = 43, DELETE_DEVICE = 44, GET_DEVICES = 45, MOBILE_GET_DEVICE = 50,
            LOGOUT = 66, DEVICE_OFFLINE = 71, OUTDATED_APP_NOTIFICATION = 72, RESET_PASSWORD = 81;

    // response codes (Response.java)
    public static final int OK = 200, QUOTA_LIMIT = 1, ILLEGAL_COMMAND = 2, USER_NOT_REGISTERED = 3,
            USER_ALREADY_REGISTERED = 4, USER_NOT_AUTHENTICATED = 5, NOT_ALLOWED = 6, DEVICE_NOT_IN_NETWORK = 7,
            NO_ACTIVE_DASHBOARD = 8, INVALID_TOKEN = 9, ILLEGAL_COMMAND_BODY = 11, NO_DATA = 17,
            SERVER_ERROR = 19, ENERGY_LIMIT = 21;

    public static String responseName(int code) {
        switch (code) {
            case OK: return "OK";
            case QUOTA_LIMIT: return "Too many requests (quota limit)";
            case ILLEGAL_COMMAND: return "Illegal command";
            case USER_NOT_REGISTERED: return "User is not registered";
            case USER_ALREADY_REGISTERED: return "User is already registered";
            case USER_NOT_AUTHENTICATED: return "Wrong email or password";
            case NOT_ALLOWED: return "Not allowed";
            case DEVICE_NOT_IN_NETWORK: return "Device is not connected";
            case NO_ACTIVE_DASHBOARD: return "No active project";
            case INVALID_TOKEN: return "Invalid token";
            case ILLEGAL_COMMAND_BODY: return "Illegal command body";
            case NO_DATA: return "No data";
            case SERVER_ERROR: return "Server error";
            case ENERGY_LIMIT: return "Not enough energy";
            default: return "Response code " + code;
        }
    }

    /** One decoded frame. For RESPONSE frames {@code code} is set and body is empty. */
    public static final class Msg {
        public final int cmd;
        public final int id;
        public final int code;
        public final byte[] body;

        public Msg(int cmd, int id, int code, byte[] body) {
            this.cmd = cmd; this.id = id; this.code = code; this.body = body;
        }
        public String text() { return new String(body, UTF8); }
        public String[] fields() { return split(text()); }
        @Override public String toString() {
            return cmd == RESPONSE ? "Response(id=" + id + ", " + responseName(code) + ")"
                    : "Msg(cmd=" + cmd + ", id=" + id + ", " + body.length + " bytes)";
        }
    }

    public static byte[] encode(int cmd, int id, byte[] body) {
        int len = body == null ? 0 : body.length;
        if (len > 0xFFFF) throw new IllegalArgumentException("Body too large: " + len);
        byte[] out = new byte[5 + len];
        out[0] = (byte) cmd;
        out[1] = (byte) (id >> 8); out[2] = (byte) id;
        out[3] = (byte) (len >> 8); out[4] = (byte) len;
        if (len > 0) System.arraycopy(body, 0, out, 5, len);
        return out;
    }

    public static byte[] encodeResponse(int id, int code) {
        return new byte[]{0, (byte) (id >> 8), (byte) id, (byte) (code >> 8), (byte) code};
    }

    public static byte[] encode(int cmd, int id, String body) {
        return encode(cmd, id, body == null ? new byte[0] : body.getBytes(UTF8));
    }

    /** Blocks until one full frame is read. Throws EOFException when the peer closed the stream. */
    public static Msg read(InputStream in) throws IOException {
        byte[] h = new byte[5];
        readFully(in, h, 0, 5);
        int cmd = h[0] & 0xFF;
        int id = ((h[1] & 0xFF) << 8) | (h[2] & 0xFF);
        int lc = ((h[3] & 0xFF) << 8) | (h[4] & 0xFF);
        if (cmd == RESPONSE) return new Msg(cmd, id, lc, new byte[0]);
        byte[] body = new byte[lc];
        readFully(in, body, 0, lc);
        return new Msg(cmd, id, 0, body);
    }

    private static void readFully(InputStream in, byte[] b, int off, int len) throws IOException {
        while (len > 0) {
            int n = in.read(b, off, len);
            if (n < 0) throw new EOFException();
            off += n; len -= n;
        }
    }

    public static String[] split(String body) { return body.split("\0", -1); }

    public static String join(String... parts) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < parts.length; i++) { if (i > 0) b.append(SEP); b.append(parts[i]); }
        return b.toString();
    }

    /** Password hash used by the server: base64(SHA-256(password + SHA-256(lower-case email))). */
    public static String hashPassword(String password, String email) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] salt = md.digest(email.toLowerCase().getBytes(UTF8));
            md.reset();
            md.update(password.getBytes(UTF8));
            return base64(md.digest(salt));
        } catch (java.security.NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }

    private static final char[] B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".toCharArray();

    public static String base64(byte[] d) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < d.length; i += 3) {
            int n = (d[i] & 0xFF) << 16;
            if (i + 1 < d.length) n |= (d[i + 1] & 0xFF) << 8;
            if (i + 2 < d.length) n |= d[i + 2] & 0xFF;
            b.append(B64[(n >> 18) & 63]).append(B64[(n >> 12) & 63]);
            b.append(i + 1 < d.length ? B64[(n >> 6) & 63] : '=');
            b.append(i + 2 < d.length ? B64[n & 63] : '=');
        }
        return b.toString();
    }

    public static byte[] gunzip(byte[] data) throws IOException {
        java.util.zip.GZIPInputStream g = new java.util.zip.GZIPInputStream(new java.io.ByteArrayInputStream(data));
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = g.read(buf)) > 0) o.write(buf, 0, n);
        return o.toByteArray();
    }
}
