package app.blynklocal.core;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.zip.GZIPOutputStream;

/** Self-consistency test against an in-process MOCK server. Proves framing/codec only, NOT real-server compatibility. */
public class ProtocolTest {
    static int fails = 0;
    static void check(String n, boolean ok) { System.out.println((ok ? "PASS " : "FAIL ") + n); if (!ok) fails++; }

    public static void main(String[] a) throws Exception {
        // known-answer: hash = base64(sha256(pw || sha256(lower(email))))
        check("hash length 44", Proto.hashPassword("pass", "A@b.c").length() == 44);
        check("hash email case-insensitive", Proto.hashPassword("pass", "A@b.c").equals(Proto.hashPassword("pass", "a@b.c")));
        check("base64 rfc", Proto.base64("foobar".getBytes()).equals("Zm9vYmFy") && Proto.base64("fo".getBytes()).equals("Zm8="));
        byte[] f = Proto.encode(Proto.HARDWARE, 7, "1-0\u0000vw\u00005\u0000x");
        check("frame header", f[0] == 20 && f[1] == 0 && f[2] == 7 && f[4] == 10);
        Json.parse("{\"a\":[1,2.5,\"x\\n\",null,true],\"b\":{}}");
        check("json roundtrip", Json.write(Json.parse("{\"a\":[1,\"x\"]}")).equals("{\"a\":[1,\"x\"]}"));

        final ServerSocket ss = new ServerSocket(0);
        final BlockingQueue<String> serverGot = new LinkedBlockingQueue<String>();
        Thread srv = new Thread(() -> {
            try {
                Socket s = ss.accept();
                InputStream in = s.getInputStream(); OutputStream out = s.getOutputStream();
                while (true) {
                    Proto.Msg m = Proto.read(in);
                    if (m.cmd == Proto.LOGIN) { out.write(Proto.encodeResponse(m.id, Proto.OK)); }
                    else if (m.cmd == Proto.LOAD_PROFILE_GZIPPED) {
                        String js = "{\"dashBoards\":[{\"id\":1,\"name\":\"Home\",\"devices\":[{\"id\":0,\"name\":\"D\",\"token\":\"tok\"}],\"widgets\":[{\"id\":5,\"type\":\"BUTTON\",\"deviceId\":0,\"pinType\":\"VIRTUAL\",\"pin\":3,\"x\":0,\"y\":0,\"width\":2,\"height\":1}]}]}";
                        ByteArrayOutputStream bo = new ByteArrayOutputStream(); GZIPOutputStream g = new GZIPOutputStream(bo); g.write(js.getBytes("UTF-8")); g.close();
                        out.write(Proto.encode(Proto.LOAD_PROFILE_GZIPPED, m.id, bo.toByteArray()));
                    } else if (m.cmd == Proto.HARDWARE) {
                        serverGot.add(m.text().replace('\0', '|'));
                        out.write(Proto.encode(Proto.HARDWARE, 0, "1-0\u0000vw\u00003\u0000echo"));   // unsolicited push
                    }
                    out.flush();
                }
            } catch (Exception e) { }
        });
        srv.setDaemon(true); srv.start();

        BlynkClient c = new BlynkClient("127.0.0.1", ss.getLocalPort(), false, false);
        final BlockingQueue<String> events = new LinkedBlockingQueue<String>();
        c.setListener(new BlynkClient.Listener() {
            public void onMessage(Proto.Msg m) { events.add("push:" + m.text().replace('\0', '|')); }
            public void onClosed(Exception e) { }
        });
        c.connect();
        final BlockingQueue<Integer> codes = new LinkedBlockingQueue<Integer>();
        c.login("a@b.c", "pw", new BlynkClient.Reply() {
            public void onReply(Proto.Msg m) { codes.add(m.code); }
            public void onError(Exception e) { codes.add(-1); }
        });
        Integer code = codes.poll(3, TimeUnit.SECONDS);
        check("login response code 200", code != null && code == 200);
        final BlockingQueue<List<Model.Dash>> prof = new LinkedBlockingQueue<List<Model.Dash>>();
        c.loadProfile(new BlynkClient.Reply() {
            public void onReply(Proto.Msg m) { try { prof.add(Model.parseProfile(new String(Proto.gunzip(m.body), "UTF-8"))); } catch (Exception e) { prof.add(new ArrayList<Model.Dash>()); } }
            public void onError(Exception e) { }
        });
        List<Model.Dash> ds = prof.poll(3, TimeUnit.SECONDS);
        check("profile parsed", ds != null && ds.size() == 1 && ds.get(0).widgets.size() == 1 && ds.get(0).devices.get(0).token.equals("tok"));
        check("widget fields", ds != null && ds.get(0).widgets.get(0).matches(0, 'v', 3) && ds.get(0).widgets.get(0).width == 2);
        c.writePin(1, 0, 'v', 3, "1");
        check("server got pin write", "1-0|vw|3|1".equals(serverGot.poll(3, TimeUnit.SECONDS)));
        String ev = events.poll(3, TimeUnit.SECONDS);
        check("unsolicited push delivered", "push:1-0|vw|3|echo".equals(ev));
        Model.PinUpdate u = Model.PinUpdate.parse("1-0\u0000vw\u00003\u0000echo".split("\0"));
        check("pin update parse", u != null && u.pin == 3 && u.value().equals("echo") && u.deviceId == 0);
        c.close();
        System.out.println(fails == 0 ? "ALL PASS" : fails + " FAILED");
        System.exit(fails);
    }
}
