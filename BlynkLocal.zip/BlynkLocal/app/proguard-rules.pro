# Activities are referenced from the manifest and kept automatically by AAPT rules.
# Nothing uses reflection; Json/Proto/Model are plain classes.
