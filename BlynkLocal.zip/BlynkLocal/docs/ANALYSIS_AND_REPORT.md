# Blynk Local (Android) — analysis, dependency inventory, size comparison, compatibility & test report

Status legend used throughout: **VERIFIED** = observed by running it here; **NOT RUN** = written but not executed in this sandbox; **ASSUMPTION** = reasoned from the server source, unconfirmed.

## 1. What the supplied APKs are (VERIFIED by parsing the manifest/DEX/ELF files)
- Package `cc.blynk`, "Blynk Legacy" 2.27.34, minSdk 19, targetSdk 32. Base APK 11,054,383 B + arm64 split 4,901,427 B = **15,955,810 B (15.2 MiB)**.
- Native libraries actually present in the supplied arm64 split:

| Library | Size | What it is | Needed for a local-server client? |
|---|---|---|---|
| libbarhopper_v3.so | 3,805,328 | Google ML Kit barcode scanner (QR for sharing/importing projects) | No – QR import is optional |
| libc++_shared.so | 919,888 | C++ runtime used by the libs above | No |
| libvlcjni.so | 96,192 | JNI glue for the VLC media player (video widget). Its payload `libvlc.so` is **not in the supplied split** | No – only for the Video widget |
| libyylRecord.so | 34,760 | VLC recording glue | No |
| libimage_processing_util_jni.so | 27,672 | CameraX image conversion | No |

- **There is no `libvnc` / VNC code in either APK** (searched libs, DEX class/string tables, manifest). The "~30 MB library" in the brief is most likely `libvlc.so` (VLC core), which would normally ship in a separate split that was not supplied. I could not inspect it. No feature of a local-server client depends on VNC, so none was added.
- The original also bundles Firebase/Google Play Services, billing, ML Kit, CameraX, VLC and many other SDKs (cloud-account features: Google/Facebook login, energy purchases, push, analytics).

## 2. Protocol and server version (from the server source supplied earlier: Blynk Server 0.41.17)
- App protocol, not the Cloud API: binary frames `command u8 | messageId u16 | length-or-status u16 | body`, UTF-8 bodies with `\0` separators. Responses use command 0 and carry a status code (200 = OK).
- App connects to the server's **TLS port (default 9443)**, usually with a self-signed certificate (the app offers "trust self-signed"). Devices connect to the plain **8080** port with `HARDWARE_LOGIN <token>`.
- Login: `email \0 base64(SHA-256(password ‖ SHA-256(lowercase email))) \0 os \0 version \0 appName`.
- Profile: `LOAD_PROFILE_GZIPPED` returns gzipped JSON; pin traffic is `HARDWARE` with `dashId-deviceId \0 vw \0 pin \0 value`.
- Nothing contacts Blynk Cloud; the only network endpoint is the host/port the user types in.

## 3. Design decisions
- Java, **framework Views only**, no AndroidX/Kotlin stdlib/Firebase/ML Kit/CameraX/VLC → **zero third-party dependencies, zero native code** (so the APK is ABI-independent).
- Protocol core (`app.blynklocal.core`) has no Android imports, so it is unit-testable with plain `javac` and testable against the real server from the command line (`tools/ServerIT.java`).
- Native libs were not "removed blindly": each was identified (table above) and mapped to the feature that used it; the QR scanner, VLC video and camera features are **not reproduced** (see §7), everything else the local server needs is pure Java.

## 4. Dependency inventory
| | Original (observed) | This app |
|---|---|---|
| Third-party libraries | Firebase, Google Play Services, billing, ML Kit, CameraX, VLC, many AndroidX libs, etc. (see `apk/base/*.properties`) | **none** |
| Native `.so` | 5 libs, 4.9 MB compressed in the split | **none** |
| Permissions | many (camera, location, storage, billing, …) | `INTERNET` |
| minSdk / target | 19 / 32 | 21 / 34 |

## 5. APK size comparison
- Original: 15,955,810 B (both supplied APKs).
- New app: **NOT MEASURED in this sandbox** (no Android SDK here). The Colab notebook prints the real size after the Gradle build. Expectation (ASSUMPTION, not a result): well under 1 MB, because the source is ~80 KB of Java and there are no libraries or assets.

## 6. Test results
| Check | Result |
|---|---|
| Core compiles with `javac` (JDK 21 here) | **VERIFIED** |
| Unit tests vs in-process **mock** server (hash, base64, framing, JSON, login, gzipped profile, pin write, unsolicited push, pin-update parse): 11/11 | **VERIFIED** – proves self-consistency only, *not* server compatibility |
| `ServerIT` compiles | **VERIFIED** |
| `ServerIT` against the real Blynk Local Server (register, login, wrong password, profile, create project/device/widgets, activate, device↔app pin round-trip, token refresh, deletes) | **NOT RUN** – the sandbox cannot build the server (Maven blocked). Run Colab step 6 on `BlynkLocal_Build_And_Test.ipynb`; the console output is saved to `integration_results.txt`. Until then, compatibility with the real server is **unproven**. |
| Android UI source (Activities/widgets) compiles | **NOT RUN** – needs the Android SDK; Colab step 4 does this. Expect that first build may reveal compile errors. |
| App on a device/emulator | **NOT RUN** anywhere |

## 7. Feature matrix vs the original (observable behaviour, ASSUMPTIONS flagged)
Implemented (code written, UI untested): login/register to a user-supplied server (TLS toggle, self-signed trust), project list/create/delete, dashboard grid (4 columns, widget x/y/width/height, tabs), live pin updates, APP_SYNC on open, edit mode (add/delete widgets), device list with token display/copy/new token/add/delete.

Widgets rendered: BUTTON/STYLED_BUTTON (push & switch), SWITCH, SLIDER, VERTICAL_SLIDER (drawn horizontally), LABELED_VALUE_DISPLAY, DIGIT4_DISPLAY, GAUGE and LEVEL displays (as bars), LED, TERMINAL, TEXT_INPUT, NUMBER_INPUT, STEP, SEGMENTED_CONTROL and MENU (as dropdown; value sent as 0-based index — **ASSUMPTION**, the original may be 1-based for some).
Placeholder only ("not supported"): graphs/history, RGB/zeRGBa, joystick, timer, video, map, LCD, table, image, device tiles and the rest of the server's widget list.

Not implemented: drag-to-reposition/resize, widget property editor, QR scan/import, video/VLC, sensors/GPS/notification widgets, history graphs, push notifications, in-app purchase/energy, social login, OTA/reports, HTTP/MQTT admin features, polished animations/icons (visuals are my own design, intentionally not copying the original's assets).

## 8. Legal / method
No code or assets from the original APK were copied; protocol facts come from the open-source server code supplied by the user. No licence, access-control or authentication bypass is involved: the app logs in with the user's own credentials to the user's own server.
