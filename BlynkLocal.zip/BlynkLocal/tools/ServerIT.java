import app.blynklocal.core.*;
import java.util.*;
import java.util.concurrent.*;

/**
 * Integration test of the app's protocol core against a REAL Blynk Local Server.
 * usage: java ServerIT <host> <appTlsPort> <hardwarePlainPort>
 * Exit code = number of failed checks. Output lines "PASS|FAIL name".
 */
public class ServerIT {
    static int fails;
    static void check(String n, boolean ok, String info) { System.out.println((ok ? "PASS " : "FAIL ") + n + (info == null || info.isEmpty() ? "" : "  [" + info + "]")); if (!ok) fails++; }

    static final class Reply implements BlynkClient.Reply {
        final BlockingQueue<Proto.Msg> q = new LinkedBlockingQueue<Proto.Msg>();
        final BlockingQueue<String> err = new LinkedBlockingQueue<String>();
        public void onReply(Proto.Msg m) { q.add(m); }
        public void onError(Exception e) { err.add(String.valueOf(e)); }
        Proto.Msg get() throws Exception { Proto.Msg m = q.poll(8, TimeUnit.SECONDS); return m; }
    }

    static Proto.Msg ask(BlynkClient c, int cmd, String body) throws Exception {
        Reply r = new Reply();
        c.request(cmd, body, r);
        return r.get();
    }

    public static void main(String[] a) throws Exception {
        String host = a[0]; int appPort = Integer.parseInt(a[1]), hwPort = Integer.parseInt(a[2]);
        String email = "it" + System.currentTimeMillis() + "@test.local", pw = "secret123";

        BlynkClient app = new BlynkClient(host, appPort, true, true);
        final BlockingQueue<Proto.Msg> pushes = new LinkedBlockingQueue<Proto.Msg>();
        app.setListener(new BlynkClient.Listener() {
            public void onMessage(Proto.Msg m) { pushes.add(m); }
            public void onClosed(Exception e) { }
        });
        app.connect();
        check("TLS connect to app port (self-signed trusted)", true, host + ":" + appPort);

        Proto.Msg m = ask(app, Proto.REGISTER, Proto.join(email, Proto.hashPassword(pw, email), "Blynk"));
        check("register new user", m != null && m.cmd == 0 && m.code == Proto.OK, m == null ? "timeout" : "code " + m.code);
        m = ask(app, Proto.LOGIN, Proto.join(email, Proto.hashPassword("wrong", email), "Android", "1.0.0", "Blynk"));
        check("login with wrong password is rejected", m != null && m.code != Proto.OK, m == null ? "timeout" : "code " + m.code);
        // a failed login may close the connection; use a fresh one for the real login
        app.close();
        app = new BlynkClient(host, appPort, true, true);
        app.setListener(new BlynkClient.Listener() {
            public void onMessage(Proto.Msg m2) { pushes.add(m2); }
            public void onClosed(Exception e) { }
        });
        app.connect();
        m = ask(app, Proto.LOGIN, Proto.join(email, Proto.hashPassword(pw, email), "Android", "1.0.0", "Blynk"));
        check("login with correct password", m != null && m.code == Proto.OK, m == null ? "timeout" : "code " + m.code);

        m = ask(app, Proto.LOAD_PROFILE_GZIPPED, "");
        List<Model.Dash> ds = null; String perr = "";
        try { ds = Model.parseProfile(new String(Proto.gunzip(m.body), Proto.UTF8)); } catch (Exception e) { perr = e.toString(); }
        check("load profile (gzip JSON) parses", ds != null, perr);

        int dashId = (int) (System.currentTimeMillis() & 0x3FFFFFFF);
        Map<String, Object> dm = new LinkedHashMap<String, Object>();
        dm.put("id", (long) dashId); dm.put("name", "IT project");
        m = ask(app, Proto.CREATE_DASH, Json.write(dm));
        check("create project", m != null && m.code == Proto.OK, m == null ? "timeout" : "cmd " + m.cmd + " code " + m.code);

        Model.Device dev = new Model.Device(); dev.id = 0; dev.name = "IT device";
        m = ask(app, Proto.CREATE_DEVICE, Proto.join(String.valueOf(dashId), Json.write(dev.toMap())));
        String token = null;
        try { if (m != null && m.cmd == Proto.CREATE_DEVICE) token = Model.Device.from(Json.parseObject(m.text())).token; } catch (Exception e) { }
        check("create device returns auth token", token != null && token.length() >= 16, m == null ? "timeout" : "cmd " + m.cmd + " code " + m.code + " body " + (m.cmd == 0 ? "" : m.text()));

        Model.Widget w = new Model.Widget(); w.id = 1; w.type = "BUTTON"; w.label = "B"; w.pin = 1; w.deviceId = 0; w.width = 2; w.height = 2;
        m = ask(app, Proto.CREATE_WIDGET, Proto.join(String.valueOf(dashId), Json.write(w.toMap())));
        check("create BUTTON widget", m != null && m.code == Proto.OK, m == null ? "timeout" : "code " + m.code);
        Model.Widget w2 = new Model.Widget(); w2.id = 2; w2.type = "LABELED_VALUE_DISPLAY"; w2.label = "V"; w2.pin = 2; w2.deviceId = 0; w2.width = 2; w2.height = 1;
        m = ask(app, Proto.CREATE_WIDGET, Proto.join(String.valueOf(dashId), Json.write(w2.toMap())));
        check("create LABELED_VALUE_DISPLAY widget", m != null && m.code == Proto.OK, m == null ? "timeout" : "code " + m.code);

        m = ask(app, Proto.LOAD_PROFILE_GZIPPED, "");
        Model.Dash mine = null;
        try { for (Model.Dash d : Model.parseProfile(new String(Proto.gunzip(m.body), Proto.UTF8))) if (d.id == dashId) mine = d; } catch (Exception e) { }
        check("profile round-trip contains project, device and 2 widgets", mine != null && mine.devices.size() == 1 && mine.widgets.size() == 2,
                mine == null ? "project missing" : mine.devices.size() + " devices " + mine.widgets.size() + " widgets");

        m = ask(app, Proto.ACTIVATE_DASHBOARD, String.valueOf(dashId));
        check("activate project", m != null && m.code == Proto.OK, m == null ? "timeout" : "code " + m.code);

        // ---- hardware side (plain port) ----
        BlynkClient hw = new BlynkClient(host, hwPort, false, false);
        final BlockingQueue<Proto.Msg> hwGot = new LinkedBlockingQueue<Proto.Msg>();
        hw.setListener(new BlynkClient.Listener() {
            public void onMessage(Proto.Msg m3) { hwGot.add(m3); }
            public void onClosed(Exception e) { }
        });
        hw.connect();
        m = token == null ? null : ask(hw, Proto.HARDWARE_LOGIN, token);
        check("device logs in with its token (plain hardware port)", m != null && m.code == Proto.OK, m == null ? "no token / timeout" : "code " + m.code);

        // device -> app
        hw.send(Proto.HARDWARE, Proto.join("vw", "2", "42"));
        String pushed = null;
        long end = System.currentTimeMillis() + 6000;
        while (System.currentTimeMillis() < end && pushed == null) {
            Proto.Msg p = pushes.poll(500, TimeUnit.MILLISECONDS);
            if (p != null && p.cmd == Proto.HARDWARE) { Model.PinUpdate u = Model.PinUpdate.parse(p.fields()); if (u != null && u.pin == 2) pushed = u.dashId + "/" + u.deviceId + "/" + u.value(); }
        }
        check("device->app: virtual pin write reaches the app", (dashId + "/0/42").equals(pushed), String.valueOf(pushed));

        // app -> device
        app.writePin(dashId, 0, 'v', 1, "1");
        String got = null;
        end = System.currentTimeMillis() + 6000;
        while (System.currentTimeMillis() < end && got == null) {
            Proto.Msg p = hwGot.poll(500, TimeUnit.MILLISECONDS);
            if (p != null && p.cmd == Proto.HARDWARE) got = p.text().replace('\0', '|');
        }
        check("app->device: widget write reaches the device", "vw|1|1".equals(got), String.valueOf(got));

        // token refresh
        m = ask(app, Proto.REFRESH_TOKEN, Proto.join(String.valueOf(dashId), "0"));
        check("refresh device token returns a new token", m != null && m.cmd == Proto.REFRESH_TOKEN && !m.text().equals(token), m == null ? "timeout" : "cmd " + m.cmd + " code " + m.code);

        // cleanup paths
        m = ask(app, Proto.DELETE_WIDGET, dashId + "\0" + 2);
        check("delete widget", m != null && m.code == Proto.OK, m == null ? "timeout" : "code " + m.code);
        m = ask(app, Proto.DELETE_DEVICE, dashId + "\0" + 0);
        check("delete device", m != null && m.code == Proto.OK, m == null ? "timeout" : "code " + m.code);
        m = ask(app, Proto.DELETE_DASH, String.valueOf(dashId));
        check("delete project", m != null && m.code == Proto.OK, m == null ? "timeout" : "code " + m.code);

        app.close(); hw.close();
        System.out.println(fails == 0 ? "ALL PASS" : fails + " FAILED");
        System.exit(fails);
    }
}
