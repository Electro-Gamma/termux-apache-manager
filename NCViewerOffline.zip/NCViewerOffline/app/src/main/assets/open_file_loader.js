// Helper for the native "Open file" button (FileOpener.kt).
// It is injected into the page with WebView.evaluateJavascript and defines window.__ncvOpen:
//
//   state()                 -> 'noeditor' | 'empty' | 'has'
//                              'empty' also covers the built-in welcome/changelog text.
//   load(mode, name, url)   -> fetches the picked file from the app (url), puts it into the G-code
//                              editor ('replace' or 'append'), then presses the PLOT button.
//                              The result is reported back through NCVNative.onResult(ok, message).
//
// This file lives in assets/ (not assets/www/), so it is never served to the page as a normal URL.
(function () {
  'use strict';

  function report(ok, message) {
    try {
      window.NCVNative.onResult(ok, message);
    } catch (e) {
      console.log('NCV open file: ' + message);
    }
  }

  // Ace stores its environment on the container element: #editor.env.editor is the Ace Editor.
  function getEditor() {
    var el = document.getElementById('editor');
    return el && el.env && el.env.editor ? el.env.editor : null;
  }

  function getPlotButton() {
    var b = document.getElementById('plot-file-btn');
    if (b) return b;
    var all = document.querySelectorAll('#fixed-plot-btn button');
    for (var i = 0; i < all.length; i++) {
      if ((all[i].textContent || '').trim().toLowerCase() === 'plot') return all[i];
    }
    return null;
  }

  function state() {
    var ed = getEditor();
    if (!ed) return 'noeditor';
    var v = ed.getValue();
    if (!v.trim()) return 'empty';
    // the welcome text NC Viewer shows before any file is loaded
    if (v.indexOf('Ctrl-Enter: Plot current file') !== -1 && v.indexOf('CHANGELOG') !== -1) return 'empty';
    return 'has';
  }

  function put(ed, text, name, append) {
    if (append) {
      var s = ed.session;
      var last = s.getLength() - 1;
      var cur = ed.getValue();
      var sep = cur.length && cur.charAt(cur.length - 1) !== '\n' ? '\n' : '';
      s.insert({ row: last, column: s.getLine(last).length }, sep + text);
      return;
    }
    // same steps as the app's own "open file": fill the editor, forget undo history, show the file name
    ed.setValue(text, -1);
    try { ed.session.getUndoManager().reset(); } catch (e) { /* not fatal */ }
    try { window.$nuxt.$store.commit('SET_FILENAME', name); } catch (e) { /* not fatal */ }
    document.title = name + ' - NCViewer';
  }

  function load(mode, name, url) {
    var ed = getEditor();
    if (!ed) {
      report(false, 'The editor is not ready yet.');
      return;
    }
    var append = mode === 'append';
    fetch(url, { cache: 'no-store' })
      .then(function (r) {
        if (!r.ok) throw new Error('the file could not be read (' + r.status + ')');
        return r.text();
      })
      .then(function (text) {
        put(ed, text, name, append);
        // let the editor's change handler run first (it updates the text NC Viewer plots), then press PLOT
        setTimeout(function () {
          var b = getPlotButton();
          if (!b) {
            report(false, (append ? 'Appended ' : 'Loaded ') + name + ', but the PLOT button was not found.');
            return;
          }
          b.click();
          report(true, (append ? 'Appended ' : 'Loaded ') + name + ' and plotted');
        }, 50);
      })
      .catch(function (e) {
        report(false, 'Could not open ' + name + ': ' + (e && e.message ? e.message : e));
      });
  }

  window.__ncvOpen = { state: state, load: load };
})();
