package com.example.ncvieweroffline.crash

import android.app.Application
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Process
import com.example.ncvieweroffline.BuildConfig
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.system.exitProcess

/**
 * Drop-in global crash handler. Install it once from your Application class:
 *
 *     class MyApp : Application() {
 *         override fun onCreate() {
 *             super.onCreate()
 *             GlobalCrashHandler.install(this)
 *             ...
 *         }
 *     }
 *
 * On any uncaught exception on any thread, this:
 *   1. Builds a full text report (device info + full stack trace, including causes).
 *   2. Saves it to a file under the app's private storage (filesDir/crash_logs/).
 *   3. Launches CrashActivity (a separate process — see the manifest snippet) with the report
 *      attached.
 *   4. Kills the crashed process.
 *
 * It does not fix anything — it exists purely so a crash produces a readable, copyable report
 * instead of a silent "app keeps stopping" with zero detail and no adb required to read it.
 *
 * Requires: `buildFeatures { buildConfig true }` in your app module's build.gradle (this uses
 * BuildConfig.VERSION_NAME / VERSION_CODE — remove those two lines from buildReport() below if
 * you'd rather not enable that).
 */
class GlobalCrashHandler private constructor(
    private val appContext: Context,
    private val previousHandler: Thread.UncaughtExceptionHandler?
) : Thread.UncaughtExceptionHandler {

    override fun uncaughtException(thread: Thread, throwable: Throwable) {
        try {
            val report = buildReport(thread, throwable)
            val savedPath = writeToFile(report)

            val intent = Intent(appContext, CrashActivity::class.java).apply {
                addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_CLEAR_TASK or
                        Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS
                )
                putExtra(CrashActivity.EXTRA_REPORT, report)
                putExtra(CrashActivity.EXTRA_FILE_PATH, savedPath)
            }
            appContext.startActivity(intent)
        } catch (handlerFailure: Throwable) {
            // The crash handler itself must never be the reason the device sees nothing at all.
            previousHandler?.uncaughtException(thread, throwable)
        } finally {
            Process.killProcess(Process.myPid())
            exitProcess(10)
        }
    }

    private fun buildReport(thread: Thread, throwable: Throwable): String {
        val sw = StringWriter()
        PrintWriter(sw).use { pw ->
            pw.println("Crash report")
            pw.println("Time: ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())}")
            pw.println("Thread: ${thread.name}")
            pw.println("App version: ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})")
            pw.println("Android: ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})")
            pw.println("Device: ${Build.MANUFACTURER} ${Build.MODEL}")
            pw.println()
            throwable.printStackTrace(pw)

            var cause = throwable.cause
            while (cause != null) {
                pw.println()
                pw.println("Caused by:")
                cause.printStackTrace(pw)
                cause = cause.cause
            }
        }
        return sw.toString()
    }

    private fun writeToFile(report: String): String? = try {
        val dir = File(appContext.filesDir, "crash_logs").apply { mkdirs() }
        val file = File(dir, "crash_${System.currentTimeMillis()}.txt")
        file.writeText(report)
        file.absolutePath
    } catch (e: Exception) {
        null
    }

    companion object {
        fun install(app: Application) {
            val previous = Thread.getDefaultUncaughtExceptionHandler()
            Thread.setDefaultUncaughtExceptionHandler(
                GlobalCrashHandler(app.applicationContext, previous)
            )
        }
    }
}
