package com.example.ncvieweroffline

/*
 * Serve.kt — serve an extracted offline site over local HTTP.
 *
 * 100 % Kotlin port of serve.py (only the Kotlin stdlib + the JDK; no third-party libraries).
 *
 * Why you'd need this: some apps load their own JS/CSS/data via fetch() or `import`, which
 * browsers block when a page is opened straight from disk (file://). Serving the same folder
 * over http://localhost avoids that, while staying fully offline.
 *
 * USAGE
 *     java -jar serve.jar [folder] [port]
 *
 *     folder  defaults to the current directory
 *     port    defaults to 8000
 *
 * Stop the server with Ctrl+C.
 */

import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.nio.charset.StandardCharsets
import java.nio.file.Files
import java.time.Instant
import java.time.OffsetDateTime
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeParseException
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.system.exitProcess

// ---------------------------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------------------------

private const val MAX_LINE = 65536
private const val MAX_HEADERS = 100
private const val READ_TIMEOUT_MS = 30_000

private val SERVER_VERSION = "SimpleHTTP/0.6 Kotlin/${KotlinVersion.CURRENT}"
private val WHITESPACE = Regex("\\s+")
private val HTTP_VERSION = Regex("HTTP/(\\d+)\\.(\\d+)")
private val INDEX_PAGES = listOf("index.html", "index.htm")

private val HTTP_DATE: DateTimeFormatter =
    DateTimeFormatter.ofPattern("EEE, dd MMM yyyy HH:mm:ss 'GMT'", Locale.US).withZone(ZoneOffset.UTC)

private val PHRASES = mapOf(
    200 to "OK",
    301 to "Moved Permanently",
    304 to "Not Modified",
    400 to "Bad Request",
    404 to "Not Found",
    414 to "Request-URI Too Long",
    431 to "Request Header Fields Too Large",
    501 to "Not Implemented",
    505 to "HTTP Version Not Supported"
)

private val EXPLAIN = mapOf(
    400 to "Bad request syntax or unsupported method",
    404 to "Nothing matches the given URI",
    414 to "URI is too long",
    431 to "The line length or size of header fields is too large",
    501 to "Server does not support this operation",
    505 to "Cannot fulfill request."
)

private val MIME_TYPES = mapOf(
    "" to "application/octet-stream",
    ".html" to "text/html",
    ".htm" to "text/html",
    ".css" to "text/css",
    ".js" to "text/javascript",
    ".mjs" to "text/javascript",
    ".json" to "application/json",
    ".webmanifest" to "application/manifest+json",
    ".xml" to "application/xml",
    ".txt" to "text/plain",
    ".py" to "text/plain",
    ".c" to "text/plain",
    ".h" to "text/plain",
    ".csv" to "text/csv",
    ".md" to "text/markdown",
    ".png" to "image/png",
    ".jpg" to "image/jpeg",
    ".jpeg" to "image/jpeg",
    ".jpe" to "image/jpeg",
    ".gif" to "image/gif",
    ".bmp" to "image/bmp",
    ".svg" to "image/svg+xml",
    ".ico" to "image/vnd.microsoft.icon",
    ".webp" to "image/webp",
    ".avif" to "image/avif",
    ".woff" to "font/woff",
    ".woff2" to "font/woff2",
    ".ttf" to "font/ttf",
    ".otf" to "font/otf",
    ".wasm" to "application/wasm",
    ".pdf" to "application/pdf",
    ".zip" to "application/zip",
    ".nc" to "application/x-netcdf",
    ".mp3" to "audio/mpeg",
    ".wav" to "audio/x-wav",
    ".mp4" to "video/mp4",
    ".webm" to "video/webm"
)

// ---------------------------------------------------------------------------------------------
// Small helpers (logging, dates, URL/HTML escaping, MIME lookup, path mapping)
// ---------------------------------------------------------------------------------------------

private val logLock = Any()

/** Same format as serve.py's log_message override: "<client> - <text>" on stderr. */
private fun logMessage(client: String, text: String) {
    synchronized(logLock) {
        System.err.println("$client - $text")
    }
}

private fun httpDate(epochSeconds: Long): String = HTTP_DATE.format(Instant.ofEpochSecond(epochSeconds))

/** Parses an If-Modified-Since value; returns epoch seconds, or null if invalid / not in UTC. */
private fun parseHttpDate(value: String): Long? {
    return try {
        val parsed = OffsetDateTime.parse(value.trim(), DateTimeFormatter.RFC_1123_DATE_TIME)
        if (parsed.offset.totalSeconds == 0) parsed.toEpochSecond() else null
    } catch (e: DateTimeParseException) {
        null
    }
}

private fun escapeHtml(s: String): String = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

private fun hexValue(c: Char): Int = when (c) {
    in '0'..'9' -> c - '0'
    in 'a'..'f' -> c - 'a' + 10
    in 'A'..'F' -> c - 'A' + 10
    else -> -1
}

/** Equivalent of Python's urllib.parse.unquote (percent-decoding, UTF-8). */
private fun unquote(s: String): String {
    if (s.indexOf('%') < 0) return s
    val bytes = ByteArrayOutputStream(s.length)
    var i = 0
    while (i < s.length) {
        val c = s[i]
        if (c == '%' && i + 2 < s.length) {
            val hi = hexValue(s[i + 1])
            val lo = hexValue(s[i + 2])
            if (hi >= 0 && lo >= 0) {
                bytes.write(hi * 16 + lo)
                i += 3
                continue
            }
        }
        val cp = s.codePointAt(i)
        bytes.write(String(Character.toChars(cp)).toByteArray(StandardCharsets.UTF_8))
        i += Character.charCount(cp)
    }
    return String(bytes.toByteArray(), StandardCharsets.UTF_8)
}

/** Equivalent of Python's urllib.parse.quote (safe = "/"). */
private fun quote(s: String): String {
    val sb = StringBuilder()
    for (b in s.toByteArray(StandardCharsets.UTF_8)) {
        val v = b.toInt() and 0xFF
        val ch = v.toChar()
        val safe = ch in 'a'..'z' || ch in 'A'..'Z' || ch in '0'..'9' ||
            ch == '_' || ch == '.' || ch == '-' || ch == '~' || ch == '/'
        if (safe) sb.append(ch) else sb.append('%').append(String.format("%02X", v))
    }
    return sb.toString()
}

/** Extension lookup exactly like SimpleHTTPRequestHandler.guess_type (case-sensitive first, then lower-case). */
private fun guessType(fileName: String): String {
    val dot = fileName.lastIndexOf('.')
    val ext = if (dot > 0 && fileName.substring(0, dot).any { it != '.' }) fileName.substring(dot) else ""
    return MIME_TYPES[ext] ?: MIME_TYPES[ext.lowercase()] ?: "application/octet-stream"
}

private class Target(val file: File, val trailingSlash: Boolean)

/**
 * Equivalent of SimpleHTTPRequestHandler.translate_path: drops query/fragment, percent-decodes,
 * normalises "." / ".." lexically (so it can never climb out of the served folder).
 */
private fun translatePath(root: File, rawPath: String): Target {
    val noQuery = rawPath.substringBefore('#').substringBefore('?')
    val trailingSlash = noQuery.trimEnd().endsWith('/')
    val decoded = unquote(noQuery)

    val stack = ArrayList<String>()
    for (segment in decoded.split('/')) {
        if (segment.isEmpty() || segment == ".") {
            continue
        } else if (segment == "..") {
            if (stack.isNotEmpty()) stack.removeAt(stack.size - 1)
        } else {
            stack.add(segment)
        }
    }

    var file = root
    for (segment in stack) {
        // ignore components that are not a simple file/directory name
        if (segment.indexOf(File.separatorChar) >= 0 || segment.indexOf('\u0000') >= 0) continue
        file = File(file, segment)
    }
    return Target(file, trailingSlash)
}

/** Reads one line (including its terminator) of at most [limit] bytes. Returns null on EOF. */
private fun readLineBytes(input: InputStream, limit: Int): ByteArray? {
    val buf = ByteArrayOutputStream()
    while (buf.size() < limit) {
        val b = input.read()
        if (b < 0) break
        buf.write(b)
        if (b == '\n'.code) break
    }
    return if (buf.size() == 0) null else buf.toByteArray()
}

private fun errorPage(code: Int, message: String, explain: String): String =
    "<!DOCTYPE HTML>\n" +
        "<html lang=\"en\">\n" +
        "    <head>\n" +
        "        <meta charset=\"utf-8\">\n" +
        "        <title>Error response</title>\n" +
        "    </head>\n" +
        "    <body>\n" +
        "        <h1>Error response</h1>\n" +
        "        <p>Error code: $code</p>\n" +
        "        <p>Message: ${escapeHtml(message)}.</p>\n" +
        "        <p>Error code explanation: $code - ${escapeHtml(explain)}.</p>\n" +
        "    </body>\n" +
        "</html>\n"

// ---------------------------------------------------------------------------------------------
// One connection = one request (HTTP/1.0, connection closed afterwards — like serve.py)
// ---------------------------------------------------------------------------------------------

private class Handler(private val root: File, private val socket: Socket) : Runnable {

    private val client: String = socket.inetAddress?.hostAddress ?: "-"
    private var requestLine = ""
    private var isHead = false

    override fun run() {
        try {
            socket.use { s ->
                s.soTimeout = READ_TIMEOUT_MS
                val input = BufferedInputStream(s.getInputStream())
                val out = BufferedOutputStream(s.getOutputStream())
                try {
                    serve(input, out)
                } finally {
                    out.flush()
                }
            }
        } catch (e: IOException) {
            // client went away / timed out: nothing to do
        }
    }

    private fun serve(input: InputStream, out: OutputStream) {
        val rawLine = readLineBytes(input, MAX_LINE + 1) ?: return
        if (rawLine.size > MAX_LINE) {
            requestLine = ""
            sendError(out, 414)
            return
        }
        requestLine = String(rawLine, StandardCharsets.ISO_8859_1).trimEnd('\r', '\n')

        val words = requestLine.split(WHITESPACE).filter { it.isNotEmpty() }
        if (words.isEmpty()) return
        if (words.size != 3) {
            sendError(out, 400, "Bad request syntax ('$requestLine')")
            return
        }

        val version = words[2]
        val match = HTTP_VERSION.matchEntire(version)
        if (match == null) {
            sendError(out, 400, "Bad request version ('$version')")
            return
        }
        val major = match.groupValues[1].toIntOrNull() ?: Int.MAX_VALUE
        if (major >= 2) {
            sendError(out, 505, "Invalid HTTP version (${match.groupValues[1]}.${match.groupValues[2]})")
            return
        }

        var path = words[1]
        if (path.startsWith("//")) path = "/" + path.trimStart('/')

        // request headers
        val headers = HashMap<String, String>()
        var count = 0
        while (true) {
            val line = readLineBytes(input, MAX_LINE + 1) ?: break
            if (line.size > MAX_LINE) {
                sendError(out, 431, "Line too long")
                return
            }
            val text = String(line, StandardCharsets.ISO_8859_1).trimEnd('\r', '\n')
            if (text.isEmpty()) break
            count++
            if (count > MAX_HEADERS) {
                sendError(out, 431, "Too many headers")
                return
            }
            val idx = text.indexOf(':')
            if (idx > 0) {
                headers.putIfAbsent(text.substring(0, idx).trim().lowercase(), text.substring(idx + 1).trim())
            }
        }

        when (words[0]) {
            "GET" -> handleRequest(out, path, headers)
            "HEAD" -> {
                isHead = true
                handleRequest(out, path, headers)
            }
            else -> sendError(out, 501, "Unsupported method ('${words[0]}')")
        }
    }

    /** Port of SimpleHTTPRequestHandler.send_head (+ do_GET / do_HEAD). */
    private fun handleRequest(out: OutputStream, rawPath: String, headers: Map<String, String>) {
        val target = translatePath(root, rawPath)
        var file = target.file

        if (file.isDirectory) {
            val noFragment = rawPath.substringBefore('#')
            val fragment = if (rawPath.indexOf('#') >= 0) rawPath.substringAfter('#') else ""
            val pathOnly = noFragment.substringBefore('?')
            val query = if (noFragment.indexOf('?') >= 0) noFragment.substringAfter('?') else ""

            if (!pathOnly.endsWith("/")) {
                // redirect browser - doing basically what apache does
                val location = StringBuilder(pathOnly).append('/')
                if (query.isNotEmpty()) location.append('?').append(query)
                if (fragment.isNotEmpty()) location.append('#').append(fragment)
                sendHead(out, 301, listOf("Location" to location.toString(), "Content-Length" to "0"))
                return
            }

            val index = INDEX_PAGES.map { File(file, it) }.firstOrNull { it.isFile }
            if (index == null) {
                listDirectory(out, file, rawPath)
                return
            }
            file = index
        } else if (target.trailingSlash) {
            sendError(out, 404, "File not found")
            return
        }

        val stream = try {
            FileInputStream(file)
        } catch (e: IOException) {
            null
        }
        if (stream == null) {
            sendError(out, 404, "File not found")
            return
        }

        stream.use { fs ->
            val length = fs.channel.size()
            val lastModified = file.lastModified() / 1000

            // use browser cache if possible
            val ifModifiedSince = headers["if-modified-since"]
            if (ifModifiedSince != null && !headers.containsKey("if-none-match")) {
                val since = parseHttpDate(ifModifiedSince)
                if (since != null && lastModified <= since) {
                    sendHead(out, 304, emptyList())
                    return
                }
            }

            sendHead(
                out, 200,
                listOf(
                    "Content-type" to guessType(file.name),
                    "Content-Length" to length.toString(),
                    "Last-Modified" to httpDate(lastModified)
                )
            )
            if (isHead) return
            fs.copyTo(out, 64 * 1024)
        }
    }

    /** Port of SimpleHTTPRequestHandler.list_directory. */
    private fun listDirectory(out: OutputStream, dir: File, rawPath: String) {
        val names = dir.list()
        if (names == null) {
            sendError(out, 404, "No permission to list directory")
            return
        }
        val sorted = names.sortedBy { it.lowercase() }
        val title = "Directory listing for ${escapeHtml(unquote(rawPath))}"

        val r = ArrayList<String>()
        r.add("<!DOCTYPE HTML>")
        r.add("<html lang=\"en\">")
        r.add("<head>")
        r.add("<meta charset=\"utf-8\">")
        r.add("<title>$title</title>\n</head>")
        r.add("<body>\n<h1>$title</h1>")
        r.add("<hr>\n<ul>")
        for (name in sorted) {
            val full = File(dir, name)
            var displayName = name
            var linkName = name
            // append / for directories or @ for symbolic links
            if (full.isDirectory) {
                displayName = "$name/"
                linkName = "$name/"
            }
            if (Files.isSymbolicLink(full.toPath())) {
                displayName = "$name@"
            }
            r.add("<li><a href=\"${quote(linkName)}\">${escapeHtml(displayName)}</a></li>")
        }
        r.add("</ul>\n<hr>\n</body>\n</html>\n")

        val body = r.joinToString("\n").toByteArray(StandardCharsets.UTF_8)
        sendHead(
            out, 200,
            listOf("Content-type" to "text/html; charset=utf-8", "Content-Length" to body.size.toString())
        )
        if (!isHead) out.write(body)
    }

    /** send_response + send_header + end_headers (with the extra "Cache-Control: no-store"). */
    private fun sendHead(
        out: OutputStream,
        code: Int,
        headers: List<Pair<String, String>>,
        message: String? = null
    ) {
        logMessage(client, "\"$requestLine\" $code -")
        val sb = StringBuilder()
        sb.append("HTTP/1.0 ").append(code).append(' ').append(message ?: PHRASES[code] ?: "").append("\r\n")
        sb.append("Server: ").append(SERVER_VERSION).append("\r\n")
        sb.append("Date: ").append(httpDate(Instant.now().epochSecond)).append("\r\n")
        for ((name, value) in headers) {
            sb.append(name).append(": ").append(value).append("\r\n")
        }
        sb.append("Cache-Control: no-store\r\n")
        sb.append("\r\n")
        out.write(sb.toString().toByteArray(StandardCharsets.ISO_8859_1))
    }

    /** Port of BaseHTTPRequestHandler.send_error. */
    private fun sendError(out: OutputStream, code: Int, message: String? = null) {
        val text = message ?: PHRASES[code] ?: ""
        val explain = EXPLAIN[code] ?: ""
        logMessage(client, "code $code, message $text")
        val body = errorPage(code, text, explain).toByteArray(StandardCharsets.UTF_8)
        sendHead(
            out, code,
            listOf(
                "Connection" to "close",
                "Content-Type" to "text/html;charset=utf-8",
                "Content-Length" to body.size.toString()
            ),
            text
        )
        if (!isHead && code >= 200 && code != 204 && code != 205 && code != 304) out.write(body)
    }
}

// ---------------------------------------------------------------------------------------------
// main
// ---------------------------------------------------------------------------------------------

fun main(args: Array<String>) {
    val folder = if (args.isNotEmpty()) args[0] else "."
    var port = 8000
    if (args.size > 1) {
        port = args[1].toIntOrNull() ?: run {
            System.err.println("Invalid port: ${args[1]}")
            exitProcess(1)
        }
    }

    val dir = File(folder)
    if (!dir.isDirectory) {
        println("Not a folder: $folder")
        exitProcess(1)
    }
    val root = dir.absoluteFile.normalize()

    val server = ServerSocket()
    try {
        server.reuseAddress = true
        server.bind(InetSocketAddress("0.0.0.0", port), 50)
    } catch (e: IOException) {
        System.err.println("Cannot listen on port $port: ${e.message}")
        exitProcess(1)
    }

    println("Serving ${root.path}")
    println("  -> http://localhost:$port/")
    println("  (if serving from a PC for a phone on the same Wi-Fi, use the PC's LAN IP instead of localhost)")
    println("Press Ctrl+C to stop.")

    // Ctrl+C (SIGINT) or SIGTERM -> print "Stopped." and exit, like the KeyboardInterrupt branch in serve.py
    Runtime.getRuntime().addShutdownHook(Thread {
        println("\nStopped.")
        System.out.flush()
    })

    val pool = Executors.newCachedThreadPool { runnable ->
        Thread(runnable).apply { isDaemon = true }
    }
    while (true) {
        try {
            pool.execute(Handler(root, server.accept()))
        } catch (e: IOException) {
            Thread.sleep(50) // transient accept() failure; keep serving
        }
    }
}
