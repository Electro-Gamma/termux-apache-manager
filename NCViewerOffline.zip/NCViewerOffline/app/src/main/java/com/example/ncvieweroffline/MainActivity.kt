package com.example.ncvieweroffline

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.res.AssetManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowInsets
import android.webkit.ConsoleMessage
import android.webkit.ServiceWorkerClient
import android.webkit.ServiceWorkerController
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.math.abs

private const val TAG = "NCViewer"

/**
 * false (default): the site is served from the APK's assets by AppAssetHandler through the WebView itself.
 *                  No server, no socket, no port.
 * true:            old behaviour, Serve.kt listening on 127.0.0.1:8000 (kept only as a fallback).
 */
private const val USE_LOCAL_SERVER = false

private const val PREFS = "ncviewer_prefs"
private const val PREF_DESKTOP_MODE = "desktop_mode"

/** CSS-pixel layout width the page gets in desktop mode (what a ~1280px wide browser window would show). */
private const val DESKTOP_VIEWPORT_WIDTH = 1280

/**
 * The site declares <meta name="viewport" content="width=device-width">, and WebView honours that even
 * with a desktop user agent, so the layout would stay phone-sized. In desktop mode this rewrites that
 * tag to a fixed width (WebView then zooms out to fit it) and keeps it that way if the SPA touches <head>.
 * Safe to run repeatedly; the site's own scripts are not modified.
 */
private val DESKTOP_VIEWPORT_JS = """
    (function(){
      var want = 'width=$DESKTOP_VIEWPORT_WIDTH, user-scalable=yes';
      function enforce(){
        var head = document.head;
        if (!head) return;
        var m = head.querySelector('meta[name="viewport"]');
        if (!m) {
          m = document.createElement('meta');
          m.setAttribute('name', 'viewport');
          head.appendChild(m);
        }
        if (m.getAttribute('content') !== want) m.setAttribute('content', want);
      }
      enforce();
      if (!window.__ncDesktopObserver && document.head) {
        window.__ncDesktopObserver = new MutationObserver(enforce);
        window.__ncDesktopObserver.observe(document.head,
          {subtree: true, childList: true, attributes: true, attributeFilter: ['content']});
      }
    })();
""".trimIndent()

// The embedded server must be started once per process, not once per Activity instance.
private val serverLock = Any()
@Volatile private var serverPort = 0

class MainActivity : Activity() {

    private val port = 8000 // preferred port = the one in the tested Termux command (see choosePort)
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private val fileChooserRequestCode = 51426

    private lateinit var webView: WebView
    private lateinit var modeButton: TextView
    private lateinit var assetHandler: AppAssetHandler
    private var defaultUserAgent = ""
    private var desktopMode = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Lets a PC's Chrome (chrome://inspect/#devices) attach a full DevTools
        // console+network panel to this exact WebView over USB.
        WebView.setWebContentsDebuggingEnabled(true)

        // Serve.kt (unmodified) reads from a real filesystem directory via java.io.File,
        // same as it did under Termux — it has no idea it's inside an APK. So the only
        // job on this side is: get the bundled assets onto real disk once, then hand
        // Serve.kt's own main() the folder + port, exactly like the tested
        // `java -jar serve.jar assets/ncviewer-offline 8000` command did.
        val siteDir = File(filesDir, "ncviewer-offline")

        webView = WebView(this)
        assetHandler = AppAssetHandler(assets)
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        @Suppress("DEPRECATION")
        settings.databaseEnabled = true
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true
        settings.textZoom = 100
        settings.builtInZoomControls = true
        settings.displayZoomControls = false

        // Desktop / mobile mode: remember the last choice; the floating button below toggles it.
        defaultUserAgent = settings.userAgentString ?: ""
        desktopMode = getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(PREF_DESKTOP_MODE, false)
        applyUserAgent()

        webView.webViewClient = object : WebViewClient() {
            // Answers every request to https://appassets.androidplatform.net/ from the APK's assets
            // (runs on a WebView background thread). Any other host returns null = normal network.
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                if (USE_LOCAL_SERVER || request == null) return null
                return assetHandler.handle(request)
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                injectDesktopViewport(view)
            }

            override fun onPageCommitVisible(view: WebView?, url: String?) {
                super.onPageCommitVisible(view, url)
                injectDesktopViewport(view)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                injectDesktopViewport(view)
                val js = """
                    (function(){
                      var hamburger = document.querySelector('.hamburger,.menu-icon,.navbar-toggler,[class*="menu"]');
                      var social = document.querySelector('[class*="social"] svg, [class*="social"] img, header svg, header img');
                      function box(el){ if(!el) return 'not found'; var r = el.getBoundingClientRect(); return Math.round(r.width)+'x'+Math.round(r.height); }
                      return 'innerWidth: ' + window.innerWidth + '\n' +
                             'innerHeight: ' + window.innerHeight + '\n' +
                             'devicePixelRatio: ' + window.devicePixelRatio + '\n' +
                             'documentElement.clientWidth: ' + document.documentElement.clientWidth + '\n' +
                             'documentElement.clientHeight: ' + document.documentElement.clientHeight + '\n' +
                             'visualViewport.scale: ' + (window.visualViewport ? window.visualViewport.scale : 'n/a') + '\n' +
                             'fonts.status: ' + (document.fonts ? document.fonts.status : 'n/a') + '\n' +
                             'serviceWorker supported: ' + (!!navigator.serviceWorker) + '\n' +
                             'serviceWorker controller: ' + (navigator.serviceWorker && navigator.serviceWorker.controller ? navigator.serviceWorker.controller.scriptURL : 'none (not controlled yet)') + '\n' +
                             'hamburger element: ' + (hamburger ? box(hamburger) : 'not found') + '\n' +
                             'first header icon box: ' + box(social) + '\n' +
                             'userAgent: ' + navigator.userAgent;
                    })();
                """.trimIndent()
                view?.evaluateJavascript(js) { result ->
                    val decoded = result?.trim('"')?.replace("\\n", "\n")?.replace("\\\"", "\"") ?: "null"
                    Log.d(TAG, "diagnostics:\n$decoded")
                    runOnUiThread {
                        android.app.AlertDialog.Builder(this@MainActivity)
                            .setTitle("Diagnostics (also in Logcat, tag NCViewer)")
                            .setMessage(decoded)
                            .setPositiveButton("OK", null)
                            .show()
                    }
                }
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                Log.e(TAG, "onReceivedError url=${request?.url} error=${error?.description}")
            }

            @Suppress("DEPRECATION")
            override fun onReceivedError(
                view: WebView?,
                errorCode: Int,
                description: String?,
                failingUrl: String?
            ) {
                Log.e(TAG, "onReceivedError(legacy) url=$failingUrl code=$errorCode desc=$description")
            }

            override fun onReceivedHttpError(
                view: WebView?,
                request: WebResourceRequest?,
                errorResponse: WebResourceResponse?
            ) {
                Log.e(TAG, "onReceivedHttpError url=${request?.url} status=${errorResponse?.statusCode}")
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(message: ConsoleMessage?): Boolean {
                Log.d(TAG, "console: ${message?.message()} (${message?.sourceId()}:${message?.lineNumber()})")
                return true
            }

            override fun onShowFileChooser(
                view: WebView?,
                callback: ValueCallback<Array<Uri>>?,
                params: FileChooserParams?
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                return try {
                    @Suppress("DEPRECATION")
                    startActivityForResult(Intent.createChooser(intent, "Select a file"), fileChooserRequestCode)
                    true
                } catch (e: Exception) {
                    filePathCallback = null
                    false
                }
            }
        }

        if (!USE_LOCAL_SERVER) {
            // Requests made by a service worker do not pass through WebViewClient, so route them here too.
            try {
                ServiceWorkerController.getInstance().setServiceWorkerClient(object : ServiceWorkerClient() {
                    override fun shouldInterceptRequest(request: WebResourceRequest?): WebResourceResponse? =
                        if (request != null) assetHandler.handle(request) else null
                })
            } catch (e: Exception) {
                Log.w(TAG, "service worker interception unavailable: ${e.message}")
            }
        }

        modeButton = buildModeButton()

        webView.setOnApplyWindowInsetsListener { v, insets ->
            val (left, top, right, bottom) = if (Build.VERSION.SDK_INT >= 30) {
                val bars = insets.getInsets(WindowInsets.Type.systemBars())
                arrayOf(bars.left, bars.top, bars.right, bars.bottom)
            } else {
                @Suppress("DEPRECATION")
                arrayOf(
                    insets.systemWindowInsetLeft, insets.systemWindowInsetTop,
                    insets.systemWindowInsetRight, insets.systemWindowInsetBottom
                )
            }
            v.setPadding(left, top, right, bottom)
            // keep the floating button clear of the system bars as well
            (modeButton.layoutParams as FrameLayout.LayoutParams).setMargins(0, 0, dp(12) + right, dp(12) + bottom)
            modeButton.requestLayout()
            insets
        }

        val root = FrameLayout(this)
        root.addView(
            webView,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        root.addView(
            modeButton,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.END
            ).apply { setMargins(0, 0, dp(12), dp(12)) }
        )
        setContentView(root)

        if (USE_LOCAL_SERVER) {
            // Everything here touches disk or a socket, so it all runs off the main thread —
            // a raw Socket().connect() call in waitForPort(), even to 127.0.0.1, throws
            // NetworkOnMainThreadException if done directly from onCreate(). Only the final
            // loadUrl() needs to be back on the main thread, since WebView isn't thread-safe.
            Thread {
                // Started once per process. If the Activity is ever re-created (system-initiated), reuse the
                // running server instead of starting a second one on another port (which would also change
                // the page's origin and lose its localStorage).
                val servePort = synchronized(serverLock) {
                    if (serverPort == 0) {
                        extractAssetDir(assets, "www", siteDir)

                        // Serve.kt with NO folder argument serves the current directory, which is how it ends up
                        // returning a directory-listing page (HTML) while every /_nuxt/*.js is a 404. The app
                        // never does that — it always passes an explicit folder — but the folder itself must
                        // really be the site root, so check that before starting the server.
                        val problem = verifySite(siteDir)
                        if (problem != null) {
                            Log.e(TAG, problem)
                            runOnUiThread {
                                android.app.AlertDialog.Builder(this@MainActivity)
                                    .setTitle("Site files missing")
                                    .setMessage(problem)
                                    .setPositiveButton("OK", null)
                                    .show()
                            }
                        }

                        // Termux (or anything else) may already be listening on 8000. Serve.kt would then call
                        // exitProcess(1) inside our process, and waitForPort() would happily connect to the
                        // *other* server. So only use 8000 if it is really free.
                        val chosen = choosePort(port)
                        Log.d(TAG, "Serve.kt main(folder=${siteDir.absolutePath}, port=$chosen)")
                        Thread {
                            main(arrayOf(siteDir.absolutePath, chosen.toString()))
                        }.apply { isDaemon = true }.start()
                        // Serve.kt's main() binds the socket synchronously near the top before doing
                        // anything else, but there's no callback out of it (it's unmodified) — so wait
                        // for the port to actually accept a connection before loading the page, instead
                        // of guessing a fixed delay.
                        waitForPort(chosen)
                        serverPort = chosen
                    }
                    serverPort
                }
                runOnUiThread {
                    webView.loadUrl("http://127.0.0.1:$servePort/")
                }
            }.start()
        } else {
            // No server, no port: AppAssetHandler answers the WebView's requests from assets/www.
            val problem = verifyBundledSite()
            if (problem != null) {
                Log.e(TAG, problem)
                android.app.AlertDialog.Builder(this)
                    .setTitle("Site files missing")
                    .setMessage(problem)
                    .setPositiveButton("OK", null)
                    .show()
            }
            webView.loadUrl("${AppAssetHandler.ORIGIN}/")
        }
    }

    // ---------------------------------------------------------------- desktop / mobile mode

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun modeLabel(): String = if (desktopMode) "Desktop view" else "Mobile view"

    /** Desktop Chrome-on-Linux user agent, reusing the WebView's own Chrome version number. */
    private fun desktopUserAgent(mobileUa: String): String {
        val chrome = Regex("Chrome/([0-9.]+)").find(mobileUa)?.groupValues?.get(1) ?: "124.0.0.0"
        return "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/$chrome Safari/537.36"
    }

    /** Desktop mode = desktop user agent; mobile mode = WebView's default (null restores it). */
    private fun applyUserAgent() {
        webView.settings.userAgentString = if (desktopMode) desktopUserAgent(defaultUserAgent) else null
    }

    private fun injectDesktopViewport(view: WebView?) {
        if (desktopMode) view?.evaluateJavascript(DESKTOP_VIEWPORT_JS, null)
    }

    /**
     * Flips the mode, remembers it, and reloads: the user agent is only read when a page loads, and a
     * reload also drops the widened viewport again when going back to mobile.
     */
    private fun toggleMode() {
        desktopMode = !desktopMode
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(PREF_DESKTOP_MODE, desktopMode).apply()
        applyUserAgent()
        modeButton.text = modeLabel()
        Toast.makeText(this, modeLabel(), Toast.LENGTH_SHORT).show()
        webView.reload()
    }

    /** Small translucent pill: tap = switch mode, drag = move it out of the way. */
    private fun buildModeButton(): TextView = TextView(this).apply {
        text = modeLabel()
        textSize = 13f
        setTextColor(Color.WHITE)
        setPadding(dp(14), dp(8), dp(14), dp(8))
        background = GradientDrawable().apply {
            setColor(Color.argb(204, 32, 33, 36))
            cornerRadius = dp(20).toFloat()
        }
        alpha = 0.85f
        elevation = dp(6).toFloat()
        contentDescription = "Switch between desktop and mobile view"

        val slop = ViewConfiguration.get(this@MainActivity).scaledTouchSlop.toFloat()
        var downX = 0f
        var downY = 0f
        var startX = 0f
        var startY = 0f
        var dragging = false
        setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = v.translationX
                    startY = v.translationY
                    dragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!dragging && (abs(dx) > slop || abs(dy) > slop)) dragging = true
                    if (dragging) {
                        v.translationX = startX + dx
                        v.translationY = startY + dy
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!dragging) toggleMode()
                    true
                }
                else -> false
            }
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // after a rotation the dragged position may be off-screen, so snap the button back
        if (::modeButton.isInitialized) {
            modeButton.translationX = 0f
            modeButton.translationY = 0f
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == fileChooserRequestCode) {
            val callback = filePathCallback
            filePathCallback = null
            if (callback == null) return
            val results: Array<Uri>? = if (resultCode == RESULT_OK && data != null) {
                val clipData = data.clipData
                val dataUri = data.data
                when {
                    clipData != null -> Array(clipData.itemCount) { i -> clipData.getItemAt(i).uri }
                    dataUri != null -> arrayOf(dataUri)
                    else -> null
                }
            } else null
            callback.onReceiveValue(results)
        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    /**
     * Recursively copies assets/<assetPath> onto real disk at destDir, so Serve.kt's
     * plain java.io.File-based server can read it exactly as it did under Termux.
     * AssetManager.list() can't tell a file from an empty directory by itself, so this
     * tries open() first and falls back to treating it as a directory.
     */
    private fun extractAssetDir(assetManager: AssetManager, assetPath: String, destDir: File) {
        val children = assetManager.list(assetPath)
        if (children == null || children.isEmpty()) {
            try {
                assetManager.open(assetPath).use { input ->
                    destDir.parentFile?.mkdirs()
                    FileOutputStream(destDir).use { output -> input.copyTo(output) }
                }
            } catch (e: IOException) {
                destDir.mkdirs() // was actually an empty directory
            }
        } else {
            destDir.mkdirs()
            for (child in children) {
                extractAssetDir(assetManager, "$assetPath/$child", File(destDir, child))
            }
        }
    }

    /**
     * Returns null if siteDir looks like the real site root (index.html plus .js files under _nuxt), otherwise a
     * human-readable description of what is missing. Also logs the facts (tag NCViewer).
     */
    private fun verifySite(siteDir: File): String? {
        val hasIndex = File(siteDir, "index.html").isFile
        val jsCount = File(siteDir, "_nuxt").walkTopDown().count { it.isFile && it.extension == "js" }
        Log.d(TAG, "site root=${siteDir.absolutePath} index.html=$hasIndex _nuxt/*.js files=$jsCount " +
            "top-level=${siteDir.list()?.sorted()}")
        return when {
            !hasIndex -> "index.html is missing in ${siteDir.absolutePath}"
            jsCount == 0 -> "index.html is there but ${siteDir.absolutePath}/_nuxt contains no .js files. " +
                "The APK was built without www/_nuxt (check androidResources.ignoreAssetsPattern in app/build.gradle.kts)."
            else -> null
        }
    }

    /** Null if the APK really contains index.html and the site's .js files, otherwise what is missing. */
    private fun verifyBundledSite(): String? {
        val root = assets.list("www")?.toList() ?: emptyList()
        val hasNuxtJs = assets.list("www/_nuxt")?.any { it.endsWith(".js") } == true
        Log.d(TAG, "bundled site: www=$root _nuxt has .js=$hasNuxtJs")
        return when {
            "index.html" !in root -> "index.html is missing from the APK's assets/www."
            !hasNuxtJs -> "index.html is there but assets/www/_nuxt has no .js files. " +
                "The APK was built without www/_nuxt (check androidResources.ignoreAssetsPattern in app/build.gradle.kts)."
            else -> null
        }
    }

    /** [preferred] if it can be bound right now, otherwise any free port. */
    private fun choosePort(preferred: Int): Int = try {
        java.net.ServerSocket().use { s ->
            s.reuseAddress = true
            s.bind(InetSocketAddress("0.0.0.0", preferred))
        }
        preferred
    } catch (e: IOException) {
        val free = java.net.ServerSocket(0).use { it.localPort }
        Log.w(TAG, "port $preferred is busy (${e.message}); using $free instead")
        free
    }

    /** Polls 127.0.0.1:port until a TCP connection succeeds, so loadUrl() never races main(). */
    private fun waitForPort(port: Int, timeoutMs: Long = 5000) {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            try {
                Socket().use { it.connect(InetSocketAddress("127.0.0.1", port), 200) }
                return
            } catch (e: IOException) {
                Thread.sleep(20)
            }
        }
        Log.e(TAG, "waitForPort: server did not come up on port $port within ${timeoutMs}ms")
    }
}
