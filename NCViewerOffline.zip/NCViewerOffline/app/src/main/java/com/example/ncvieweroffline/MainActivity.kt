package com.example.ncvieweroffline

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.res.AssetManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.WindowInsets
import android.webkit.ConsoleMessage
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import java.io.BufferedOutputStream
import java.io.IOException
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.CountDownLatch

private const val TAG = "NCViewer"

class MainActivity : Activity() {

    private val port = 8090
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private val fileChooserRequestCode = 51426

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Lets a PC's Chrome (chrome://inspect/#devices) attach a full DevTools
        // console+network panel to this exact WebView over USB.
        WebView.setWebContentsDebuggingEnabled(true)

        // 1. server up and confirmed listening BEFORE touching the WebView at all.
        val server = LocalAssetServer(assets, port)
        server.start()
        server.awaitReady()

        // 2/3. configure the WebView to behave like a normal mobile browser.
        val webView = WebView(this)
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        @Suppress("DEPRECATION")
        settings.databaseEnabled = true
        // Without these two, WebView can ignore the page's own <meta viewport>
        // tag and fall back to legacy desktop-width emulation — the likely
        // actual cause of icons/text rendering at different proportions than
        // Chrome, even with byte-identical CSS/JS being served.
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true
        settings.textZoom = 100 // ignore the device's system font-size accessibility setting
        settings.builtInZoomControls = true
        settings.displayZoomControls = false

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                val js = """
                    (function(){
                      var hamburger = document.querySelector('.hamburger,.menu-icon,.navbar-toggler,[class*="menu"]');
                      var social = document.querySelector('[class*="social"] svg, [class*="social"] img, header svg, header img');
                      function box(el){ if(!el) return 'not found'; var r = el.getBoundingClientRect(); return Math.round(r.width)+'x'+Math.round(r.height); }
                      return 'innerWidth: ' + window.innerWidth + '\n' +
                             'innerHeight: ' + window.innerHeight + '\n' +
                             'devicePixelRatio: ' + window.devicePixelRatio + '\n' +
                             'documentElement.clientWidth: ' + document.documentElement.clientWidth + '\n' +
                             'documentElement.clientHeight: ' + document.documentElement.clientHeight + '\n' +
                             'visualViewport.scale: ' + (window.visualViewport ? window.visualViewport.scale : 'n/a') + '\n' +
                             'fonts.status: ' + (document.fonts ? document.fonts.status : 'n/a') + '\n' +
                             'serviceWorker supported: ' + (!!navigator.serviceWorker) + '\n' +
                             'serviceWorker controller: ' + (navigator.serviceWorker && navigator.serviceWorker.controller ? navigator.serviceWorker.controller.scriptURL : 'none (not controlled yet)') + '\n' +
                             'hamburger element: ' + (hamburger ? box(hamburger) : 'not found') + '\n' +
                             'first header icon box: ' + box(social) + '\n' +
                             'userAgent: ' + navigator.userAgent;
                    })();
                """.trimIndent()
                view?.evaluateJavascript(js) { result ->
                    val decoded = result?.trim('"')?.replace("\\n", "\n")?.replace("\\\"", "\"") ?: "null"
                    Log.d(TAG, "diagnostics:\n$decoded")
                    runOnUiThread {
                        android.app.AlertDialog.Builder(this@MainActivity)
                            .setTitle("Diagnostics (also in Logcat, tag NCViewer)")
                            .setMessage(decoded)
                            .setPositiveButton("OK", null)
                            .show()
                    }
                }
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                Log.e(TAG, "onReceivedError url=${request?.url} error=${error?.description}")
            }

            @Suppress("DEPRECATION")
            override fun onReceivedError(
                view: WebView?,
                errorCode: Int,
                description: String?,
                failingUrl: String?
            ) {
                Log.e(TAG, "onReceivedError(legacy) url=$failingUrl code=$errorCode desc=$description")
            }

            override fun onReceivedHttpError(
                view: WebView?,
                request: WebResourceRequest?,
                errorResponse: WebResourceResponse?
            ) {
                Log.e(TAG, "onReceivedHttpError url=${request?.url} status=${errorResponse?.statusCode}")
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(message: ConsoleMessage?): Boolean {
                Log.d(TAG, "console: ${message?.message()} (${message?.sourceId()}:${message?.lineNumber()})")
                return true
            }

            override fun onShowFileChooser(
                view: WebView?,
                callback: ValueCallback<Array<Uri>>?,
                params: FileChooserParams?
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                return try {
                    @Suppress("DEPRECATION")
                    startActivityForResult(Intent.createChooser(intent, "Select a file"), fileChooserRequestCode)
                    true
                } catch (e: Exception) {
                    filePathCallback = null
                    false
                }
            }
        }

        // Belt-and-suspenders alongside the theme's edge-to-edge opt-out: if a given
        // OEM/OS build still dispatches non-zero insets anyway, pad correctly for them
        // using the modern Type-based API (the old systemWindowInset* fields this used
        // previously are unreliable under Android 15's forced edge-to-edge).
        webView.setOnApplyWindowInsetsListener { v, insets ->
            val (left, top, right, bottom) = if (Build.VERSION.SDK_INT >= 30) {
                val bars = insets.getInsets(WindowInsets.Type.systemBars())
                arrayOf(bars.left, bars.top, bars.right, bars.bottom)
            } else {
                @Suppress("DEPRECATION")
                arrayOf(
                    insets.systemWindowInsetLeft, insets.systemWindowInsetTop,
                    insets.systemWindowInsetRight, insets.systemWindowInsetBottom
                )
            }
            v.setPadding(left, top, right, bottom)
            insets
        }

        setContentView(webView)
        // 4/5. load the site only now that everything above is configured.
        webView.loadUrl("http://127.0.0.1:$port/index.html")
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == fileChooserRequestCode) {
            val callback = filePathCallback
            filePathCallback = null
            if (callback == null) return
            val results: Array<Uri>? = if (resultCode == RESULT_OK && data != null) {
                val clipData = data.clipData
                val dataUri = data.data
                when {
                    clipData != null -> Array(clipData.itemCount) { i -> clipData.getItemAt(i).uri }
                    dataUri != null -> arrayOf(dataUri)
                    else -> null
                }
            } else null
            callback.onReceiveValue(results)
        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }
}

/**
 * Minimal static file server. Serves files out of assets/www/ as the web root —
 * no third-party libraries, thread-per-connection, mirrors `python3 -m http.server`.
 * Every request and response now gets logged to Logcat under tag "NCViewer" so a
 * real 404 vs. a network failure vs. a WebView-side error can be told apart.
 */
class LocalAssetServer(
    private val assetManager: AssetManager,
    private val port: Int
) : Thread() {

    private val ready = CountDownLatch(1)
    private var serverSocket: ServerSocket? = null

    fun awaitReady() = ready.await()

    private val mimeTypes = mapOf(
        "html" to "text/html; charset=utf-8",
        "htm" to "text/html; charset=utf-8",
        "js" to "text/javascript; charset=utf-8",
        "mjs" to "text/javascript; charset=utf-8",
        "css" to "text/css; charset=utf-8",
        "json" to "application/json; charset=utf-8",
        "png" to "image/png",
        "jpg" to "image/jpeg",
        "jpeg" to "image/jpeg",
        "gif" to "image/gif",
        "svg" to "image/svg+xml",
        "ico" to "image/x-icon",
        "woff" to "font/woff",
        "woff2" to "font/woff2",
        "ttf" to "font/ttf",
        "otf" to "font/otf",
        "wasm" to "application/wasm",
        "txt" to "text/plain; charset=utf-8",
        "xml" to "application/xml; charset=utf-8"
    )

    override fun run() {
        try {
            serverSocket = ServerSocket(port, 50, InetAddress.getByName("127.0.0.1"))
            Log.d(TAG, "LocalAssetServer listening on 127.0.0.1:$port")
        } catch (e: IOException) {
            Log.e(TAG, "LocalAssetServer failed to bind port $port", e)
            ready.countDown()
            return
        }
        ready.countDown()
        while (!isInterrupted) {
            try {
                val client = serverSocket!!.accept()
                Thread { handle(client) }.start()
            } catch (e: IOException) {
                break
            }
        }
    }

    private fun handle(client: Socket) {
        try {
            client.soTimeout = 10000
            val input = client.getInputStream().bufferedReader(Charsets.ISO_8859_1)
            val requestLine = input.readLine() ?: return
            var line: String?
            do { line = input.readLine() } while (!line.isNullOrEmpty()) // discard headers

            val parts = requestLine.split(" ")
            if (parts.size < 2) { client.close(); return }
            var path = parts[1].substringBefore('?')
            if (path == "/") path = "/index.html"
            if (path.contains("..")) { // reject path traversal; never serve outside www/
                client.close()
                return
            }
            val assetPath = "www$path" // "/" -> "www/index.html", "/_nuxt/x.js" -> "www/_nuxt/x.js"

            val output = BufferedOutputStream(client.getOutputStream())
            try {
                val stream = assetManager.open(assetPath)
                val bytes = stream.readBytes()
                stream.close()
                val ext = path.substringAfterLast('.', "")
                val mime = mimeTypes[ext] ?: "application/octet-stream"
                val header = "HTTP/1.1 200 OK\r\n" +
                        "Content-Type: $mime\r\n" +
                        "Content-Length: ${bytes.size}\r\n" +
                        "Cache-Control: no-store\r\n" +
                        "Connection: close\r\n\r\n"
                output.write(header.toByteArray(Charsets.ISO_8859_1))
                output.write(bytes)
                Log.d(TAG, "200 $path -> $assetPath ($mime, ${bytes.size}B)")
            } catch (e: IOException) {
                val body = "404 Not Found: $path".toByteArray()
                val header = "HTTP/1.1 404 Not Found\r\n" +
                        "Content-Type: text/plain; charset=utf-8\r\n" +
                        "Content-Length: ${body.size}\r\n" +
                        "Connection: close\r\n\r\n"
                output.write(header.toByteArray(Charsets.ISO_8859_1))
                output.write(body)
                Log.w(TAG, "404 $path -> $assetPath")
            }
            output.flush()
        } catch (e: IOException) {
            Log.w(TAG, "handle() IOException: ${e.message}")
        } finally {
            try { client.close() } catch (e: IOException) {}
        }
    }
}
