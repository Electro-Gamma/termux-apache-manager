package com.example.ncvieweroffline

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.res.AssetManager
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.webkit.ConsoleMessage
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import java.io.BufferedOutputStream
import java.io.IOException
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.CountDownLatch

private const val TAG = "NCViewer"

class MainActivity : Activity() {

    private val port = 8090
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private val fileChooserRequestCode = 51426

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Lets a PC's Chrome (chrome://inspect/#devices) attach a full DevTools
        // console+network panel to this exact WebView over USB.
        WebView.setWebContentsDebuggingEnabled(true)

        val server = LocalAssetServer(assets, port)
        server.start()
        server.awaitReady()

        val webView = WebView(this)

        // Wipe any cached responses left over from earlier test installs — an APK
        // update keeps app data (including WebView's HTTP cache) unless you uninstall,
        // so a stale cached failure can otherwise look identical to a live bug.
        webView.clearCache(true)
        webView.settings.cacheMode = WebSettings.LOAD_NO_CACHE
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true

        webView.webViewClient = object : WebViewClient() {
            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                Log.e(TAG, "onReceivedError url=${request?.url} error=${error?.description}")
            }

            @Suppress("DEPRECATION")
            override fun onReceivedError(
                view: WebView?,
                errorCode: Int,
                description: String?,
                failingUrl: String?
            ) {
                Log.e(TAG, "onReceivedError(legacy) url=$failingUrl code=$errorCode desc=$description")
            }

            override fun onReceivedHttpError(
                view: WebView?,
                request: WebResourceRequest?,
                errorResponse: WebResourceResponse?
            ) {
                Log.e(TAG, "onReceivedHttpError url=${request?.url} status=${errorResponse?.statusCode}")
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(message: ConsoleMessage?): Boolean {
                Log.d(TAG, "console: ${message?.message()} (${message?.sourceId()}:${message?.lineNumber()})")
                return true
            }

            override fun onShowFileChooser(
                view: WebView?,
                callback: ValueCallback<Array<Uri>>?,
                params: FileChooserParams?
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                return try {
                    @Suppress("DEPRECATION")
                    startActivityForResult(Intent.createChooser(intent, "Select a file"), fileChooserRequestCode)
                    true
                } catch (e: Exception) {
                    filePathCallback = null
                    false
                }
            }
        }

        // Android 15+ (targetSdk 35) forces edge-to-edge by default; pad by the real
        // system bar insets so the app's own header/footer aren't hidden under them.
        webView.setOnApplyWindowInsetsListener { v, insets ->
            v.setPadding(
                insets.systemWindowInsetLeft,
                insets.systemWindowInsetTop,
                insets.systemWindowInsetRight,
                insets.systemWindowInsetBottom
            )
            insets
        }

        setContentView(webView)
        webView.loadUrl("http://127.0.0.1:$port/index.html")
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == fileChooserRequestCode) {
            val callback = filePathCallback
            filePathCallback = null
            if (callback == null) return
            val results: Array<Uri>? = if (resultCode == RESULT_OK && data != null) {
                val clipData = data.clipData
                val dataUri = data.data
                when {
                    clipData != null -> Array(clipData.itemCount) { i -> clipData.getItemAt(i).uri }
                    dataUri != null -> arrayOf(dataUri)
                    else -> null
                }
            } else null
            callback.onReceiveValue(results)
        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }
}

/**
 * Minimal static file server. Serves files out of assets/www/ as the web root —
 * no third-party libraries, thread-per-connection, mirrors `python3 -m http.server`.
 * Every request and response now gets logged to Logcat under tag "NCViewer" so a
 * real 404 vs. a network failure vs. a WebView-side error can be told apart.
 */
class LocalAssetServer(
    private val assetManager: AssetManager,
    private val port: Int
) : Thread() {

    private val ready = CountDownLatch(1)
    private var serverSocket: ServerSocket? = null

    fun awaitReady() = ready.await()

    private val mimeTypes = mapOf(
        "html" to "text/html; charset=utf-8",
        "htm" to "text/html; charset=utf-8",
        "js" to "text/javascript; charset=utf-8",
        "mjs" to "text/javascript; charset=utf-8",
        "css" to "text/css; charset=utf-8",
        "json" to "application/json; charset=utf-8",
        "png" to "image/png",
        "jpg" to "image/jpeg",
        "jpeg" to "image/jpeg",
        "gif" to "image/gif",
        "svg" to "image/svg+xml",
        "ico" to "image/x-icon",
        "woff" to "font/woff",
        "woff2" to "font/woff2",
        "ttf" to "font/ttf",
        "otf" to "font/otf",
        "wasm" to "application/wasm",
        "txt" to "text/plain; charset=utf-8",
        "xml" to "application/xml; charset=utf-8"
    )

    override fun run() {
        try {
            serverSocket = ServerSocket(port, 50, InetAddress.getByName("127.0.0.1"))
            Log.d(TAG, "LocalAssetServer listening on 127.0.0.1:$port")
        } catch (e: IOException) {
            Log.e(TAG, "LocalAssetServer failed to bind port $port", e)
            ready.countDown()
            return
        }
        ready.countDown()
        while (!isInterrupted) {
            try {
                val client = serverSocket!!.accept()
                Thread { handle(client) }.start()
            } catch (e: IOException) {
                break
            }
        }
    }

    private fun handle(client: Socket) {
        try {
            client.soTimeout = 10000
            val input = client.getInputStream().bufferedReader(Charsets.ISO_8859_1)
            val requestLine = input.readLine() ?: return
            var line: String?
            do { line = input.readLine() } while (!line.isNullOrEmpty()) // discard headers

            val parts = requestLine.split(" ")
            if (parts.size < 2) { client.close(); return }
            var path = parts[1].substringBefore('?')
            if (path == "/") path = "/index.html"
            val assetPath = "www$path" // "/" -> "www/index.html", "/_nuxt/x.js" -> "www/_nuxt/x.js"

            val output = BufferedOutputStream(client.getOutputStream())
            try {
                val stream = assetManager.open(assetPath)
                val bytes = stream.readBytes()
                stream.close()
                val ext = path.substringAfterLast('.', "")
                val mime = mimeTypes[ext] ?: "application/octet-stream"
                val header = "HTTP/1.1 200 OK\r\n" +
                        "Content-Type: $mime\r\n" +
                        "Content-Length: ${bytes.size}\r\n" +
                        "Cache-Control: no-store\r\n" +
                        "Connection: close\r\n\r\n"
                output.write(header.toByteArray(Charsets.ISO_8859_1))
                output.write(bytes)
                Log.d(TAG, "200 $path -> $assetPath ($mime, ${bytes.size}B)")
            } catch (e: IOException) {
                val body = "404 Not Found: $path".toByteArray()
                val header = "HTTP/1.1 404 Not Found\r\n" +
                        "Content-Type: text/plain; charset=utf-8\r\n" +
                        "Content-Length: ${body.size}\r\n" +
                        "Connection: close\r\n\r\n"
                output.write(header.toByteArray(Charsets.ISO_8859_1))
                output.write(body)
                Log.w(TAG, "404 $path -> $assetPath")
            }
            output.flush()
        } catch (e: IOException) {
            Log.w(TAG, "handle() IOException: ${e.message}")
        } finally {
            try { client.close() } catch (e: IOException) {}
        }
    }
}
