package com.example.ncvieweroffline

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.res.AssetManager
import android.net.Uri
import android.os.Bundle
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import java.io.BufferedOutputStream
import java.io.IOException
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.CountDownLatch

class MainActivity : Activity() {

    private val port = 8090
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private val fileChooserRequestCode = 51426

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Start the local static-file server — serves app/src/main/assets/www/ as the
        // web root, exactly like `python3 serve.py` did, so absolute paths like
        // /_nuxt/app.js resolve correctly. awaitReady() blocks (briefly — binding a
        // loopback socket is near-instant) so the WebView never races the server.
        val server = LocalAssetServer(assets, port)
        server.start()
        server.awaitReady()

        val webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webViewClient = WebViewClient()

        // Without this, tapping any <input type="file"> in the page (e.g. "GCode File")
        // silently does nothing — WebView has no built-in file picker.
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView?,
                callback: ValueCallback<Array<Uri>>?,
                params: FileChooserParams?
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                return try {
                    @Suppress("DEPRECATION")
                    startActivityForResult(Intent.createChooser(intent, "Select a file"), fileChooserRequestCode)
                    true
                } catch (e: Exception) {
                    filePathCallback = null
                    false
                }
            }
        }

        // Android 15+ (targetSdk 35) forces edge-to-edge by default, which otherwise
        // draws the page under the status bar / nav bar. Pad the WebView by the actual
        // system bar insets so the app's own header and bottom panel aren't hidden.
        webView.setOnApplyWindowInsetsListener { v, insets ->
            v.setPadding(
                insets.systemWindowInsetLeft,
                insets.systemWindowInsetTop,
                insets.systemWindowInsetRight,
                insets.systemWindowInsetBottom
            )
            insets
        }

        setContentView(webView)
        webView.loadUrl("http://127.0.0.1:$port/index.html")
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == fileChooserRequestCode) {
            val callback = filePathCallback
            filePathCallback = null
            if (callback == null) return
            val results: Array<Uri>? = if (resultCode == RESULT_OK && data != null) {
                val clipData = data.clipData
                val dataUri = data.data
                when {
                    clipData != null -> Array(clipData.itemCount) { i -> clipData.getItemAt(i).uri }
                    dataUri != null -> arrayOf(dataUri)
                    else -> null
                }
            } else null
            callback.onReceiveValue(results)
        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }
}

/**
 * Minimal static file server. Serves files out of assets/www/ as the web root —
 * no third-party libraries, thread-per-connection, mirrors `python3 -m http.server`.
 * Reusable as-is for any extracted offline site: just swap the assets/www folder.
 */
class LocalAssetServer(
    private val assetManager: AssetManager,
    private val port: Int
) : Thread() {

    private val ready = CountDownLatch(1)
    private var serverSocket: ServerSocket? = null

    fun awaitReady() = ready.await()

    private val mimeTypes = mapOf(
        "html" to "text/html; charset=utf-8",
        "htm" to "text/html; charset=utf-8",
        "js" to "application/javascript; charset=utf-8",
        "mjs" to "application/javascript; charset=utf-8",
        "css" to "text/css; charset=utf-8",
        "json" to "application/json; charset=utf-8",
        "png" to "image/png",
        "jpg" to "image/jpeg",
        "jpeg" to "image/jpeg",
        "gif" to "image/gif",
        "svg" to "image/svg+xml",
        "ico" to "image/x-icon",
        "woff" to "font/woff",
        "woff2" to "font/woff2",
        "ttf" to "font/ttf",
        "otf" to "font/otf",
        "wasm" to "application/wasm",
        "txt" to "text/plain; charset=utf-8",
        "xml" to "application/xml; charset=utf-8"
    )

    override fun run() {
        try {
            serverSocket = ServerSocket(port, 50, InetAddress.getByName("127.0.0.1"))
        } catch (e: IOException) {
            ready.countDown()
            return
        }
        ready.countDown()
        while (!isInterrupted) {
            try {
                val client = serverSocket!!.accept()
                Thread { handle(client) }.start()
            } catch (e: IOException) {
                break
            }
        }
    }

    private fun handle(client: Socket) {
        try {
            client.soTimeout = 10000
            val input = client.getInputStream().bufferedReader(Charsets.ISO_8859_1)
            val requestLine = input.readLine() ?: return
            var line: String?
            do { line = input.readLine() } while (!line.isNullOrEmpty()) // discard headers

            val parts = requestLine.split(" ")
            if (parts.size < 2) { client.close(); return }
            var path = parts[1].substringBefore('?')
            if (path == "/") path = "/index.html"
            val assetPath = "www$path" // "/" -> "www/index.html", "/_nuxt/x.js" -> "www/_nuxt/x.js"

            val output = BufferedOutputStream(client.getOutputStream())
            try {
                val stream = assetManager.open(assetPath)
                val bytes = stream.readBytes()
                stream.close()
                val ext = path.substringAfterLast('.', "")
                val mime = mimeTypes[ext] ?: "application/octet-stream"
                val header = "HTTP/1.1 200 OK\r\n" +
                        "Content-Type: $mime\r\n" +
                        "Content-Length: ${bytes.size}\r\n" +
                        "Cache-Control: no-store\r\n" +
                        "Connection: close\r\n\r\n"
                output.write(header.toByteArray(Charsets.ISO_8859_1))
                output.write(bytes)
            } catch (e: IOException) {
                val body = "404 Not Found: $path".toByteArray()
                val header = "HTTP/1.1 404 Not Found\r\n" +
                        "Content-Type: text/plain; charset=utf-8\r\n" +
                        "Content-Length: ${body.size}\r\n" +
                        "Connection: close\r\n\r\n"
                output.write(header.toByteArray(Charsets.ISO_8859_1))
                output.write(body)
            }
            output.flush()
        } catch (e: IOException) {
            // client disconnected mid-request; nothing to do
        } finally {
            try { client.close() } catch (e: IOException) {}
        }
    }
}
