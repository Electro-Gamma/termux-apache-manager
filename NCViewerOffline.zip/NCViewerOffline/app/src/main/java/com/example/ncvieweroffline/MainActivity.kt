package com.example.ncvieweroffline

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.res.AssetManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.WindowInsets
import android.webkit.ConsoleMessage
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Socket

private const val TAG = "NCViewer"

class MainActivity : Activity() {

    private val port = 8000 // preferred port = the one in the tested Termux command (see choosePort)
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private val fileChooserRequestCode = 51426

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Lets a PC's Chrome (chrome://inspect/#devices) attach a full DevTools
        // console+network panel to this exact WebView over USB.
        WebView.setWebContentsDebuggingEnabled(true)

        // Serve.kt (unmodified) reads from a real filesystem directory via java.io.File,
        // same as it did under Termux — it has no idea it's inside an APK. So the only
        // job on this side is: get the bundled assets onto real disk once, then hand
        // Serve.kt's own main() the folder + port, exactly like the tested
        // `java -jar serve.jar assets/ncviewer-offline 8000` command did.
        val siteDir = File(filesDir, "ncviewer-offline")

        val webView = WebView(this)
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        @Suppress("DEPRECATION")
        settings.databaseEnabled = true
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true
        settings.textZoom = 100
        settings.builtInZoomControls = true
        settings.displayZoomControls = false

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                val js = """
                    (function(){
                      var hamburger = document.querySelector('.hamburger,.menu-icon,.navbar-toggler,[class*="menu"]');
                      var social = document.querySelector('[class*="social"] svg, [class*="social"] img, header svg, header img');
                      function box(el){ if(!el) return 'not found'; var r = el.getBoundingClientRect(); return Math.round(r.width)+'x'+Math.round(r.height); }
                      return 'innerWidth: ' + window.innerWidth + '\n' +
                             'innerHeight: ' + window.innerHeight + '\n' +
                             'devicePixelRatio: ' + window.devicePixelRatio + '\n' +
                             'documentElement.clientWidth: ' + document.documentElement.clientWidth + '\n' +
                             'documentElement.clientHeight: ' + document.documentElement.clientHeight + '\n' +
                             'visualViewport.scale: ' + (window.visualViewport ? window.visualViewport.scale : 'n/a') + '\n' +
                             'fonts.status: ' + (document.fonts ? document.fonts.status : 'n/a') + '\n' +
                             'serviceWorker supported: ' + (!!navigator.serviceWorker) + '\n' +
                             'serviceWorker controller: ' + (navigator.serviceWorker && navigator.serviceWorker.controller ? navigator.serviceWorker.controller.scriptURL : 'none (not controlled yet)') + '\n' +
                             'hamburger element: ' + (hamburger ? box(hamburger) : 'not found') + '\n' +
                             'first header icon box: ' + box(social) + '\n' +
                             'userAgent: ' + navigator.userAgent;
                    })();
                """.trimIndent()
                view?.evaluateJavascript(js) { result ->
                    val decoded = result?.trim('"')?.replace("\\n", "\n")?.replace("\\\"", "\"") ?: "null"
                    Log.d(TAG, "diagnostics:\n$decoded")
                    runOnUiThread {
                        android.app.AlertDialog.Builder(this@MainActivity)
                            .setTitle("Diagnostics (also in Logcat, tag NCViewer)")
                            .setMessage(decoded)
                            .setPositiveButton("OK", null)
                            .show()
                    }
                }
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                Log.e(TAG, "onReceivedError url=${request?.url} error=${error?.description}")
            }

            @Suppress("DEPRECATION")
            override fun onReceivedError(
                view: WebView?,
                errorCode: Int,
                description: String?,
                failingUrl: String?
            ) {
                Log.e(TAG, "onReceivedError(legacy) url=$failingUrl code=$errorCode desc=$description")
            }

            override fun onReceivedHttpError(
                view: WebView?,
                request: WebResourceRequest?,
                errorResponse: WebResourceResponse?
            ) {
                Log.e(TAG, "onReceivedHttpError url=${request?.url} status=${errorResponse?.statusCode}")
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(message: ConsoleMessage?): Boolean {
                Log.d(TAG, "console: ${message?.message()} (${message?.sourceId()}:${message?.lineNumber()})")
                return true
            }

            override fun onShowFileChooser(
                view: WebView?,
                callback: ValueCallback<Array<Uri>>?,
                params: FileChooserParams?
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                return try {
                    @Suppress("DEPRECATION")
                    startActivityForResult(Intent.createChooser(intent, "Select a file"), fileChooserRequestCode)
                    true
                } catch (e: Exception) {
                    filePathCallback = null
                    false
                }
            }
        }

        webView.setOnApplyWindowInsetsListener { v, insets ->
            val (left, top, right, bottom) = if (Build.VERSION.SDK_INT >= 30) {
                val bars = insets.getInsets(WindowInsets.Type.systemBars())
                arrayOf(bars.left, bars.top, bars.right, bars.bottom)
            } else {
                @Suppress("DEPRECATION")
                arrayOf(
                    insets.systemWindowInsetLeft, insets.systemWindowInsetTop,
                    insets.systemWindowInsetRight, insets.systemWindowInsetBottom
                )
            }
            v.setPadding(left, top, right, bottom)
            insets
        }

        setContentView(webView)

        // Everything here touches disk or a socket, so it all runs off the main thread —
        // a raw Socket().connect() call in waitForPort(), even to 127.0.0.1, throws
        // NetworkOnMainThreadException if done directly from onCreate(). Only the final
        // loadUrl() needs to be back on the main thread, since WebView isn't thread-safe.
        Thread {
            extractAssetDir(assets, "www", siteDir)

            // Serve.kt with NO folder argument serves the current directory, which is how it ends up
            // returning a directory-listing page (HTML) while every /_nuxt/*.js is a 404. The app
            // never does that — it always passes an explicit folder — but the folder itself must
            // really be the site root, so check that before starting the server.
            val problem = verifySite(siteDir)
            if (problem != null) {
                Log.e(TAG, problem)
                runOnUiThread {
                    android.app.AlertDialog.Builder(this@MainActivity)
                        .setTitle("Site files missing")
                        .setMessage(problem)
                        .setPositiveButton("OK", null)
                        .show()
                }
            }

            // Termux (or anything else) may already be listening on 8000. Serve.kt would then call
            // exitProcess(1) inside our process, and waitForPort() would happily connect to the
            // *other* server. So only use 8000 if it is really free.
            val servePort = choosePort(port)
            Log.d(TAG, "Serve.kt main(folder=${siteDir.absolutePath}, port=$servePort)")
            Thread {
                main(arrayOf(siteDir.absolutePath, servePort.toString()))
            }.apply { isDaemon = true }.start()
            // Serve.kt's main() binds the socket synchronously near the top before doing
            // anything else, but there's no callback out of it (it's unmodified) — so wait
            // for the port to actually accept a connection before loading the page, instead
            // of guessing a fixed delay.
            waitForPort(servePort)
            runOnUiThread {
                webView.loadUrl("http://127.0.0.1:$servePort/")
            }
        }.start()
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == fileChooserRequestCode) {
            val callback = filePathCallback
            filePathCallback = null
            if (callback == null) return
            val results: Array<Uri>? = if (resultCode == RESULT_OK && data != null) {
                val clipData = data.clipData
                val dataUri = data.data
                when {
                    clipData != null -> Array(clipData.itemCount) { i -> clipData.getItemAt(i).uri }
                    dataUri != null -> arrayOf(dataUri)
                    else -> null
                }
            } else null
            callback.onReceiveValue(results)
        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    /**
     * Recursively copies assets/<assetPath> onto real disk at destDir, so Serve.kt's
     * plain java.io.File-based server can read it exactly as it did under Termux.
     * AssetManager.list() can't tell a file from an empty directory by itself, so this
     * tries open() first and falls back to treating it as a directory.
     */
    private fun extractAssetDir(assetManager: AssetManager, assetPath: String, destDir: File) {
        val children = assetManager.list(assetPath)
        if (children == null || children.isEmpty()) {
            try {
                assetManager.open(assetPath).use { input ->
                    destDir.parentFile?.mkdirs()
                    FileOutputStream(destDir).use { output -> input.copyTo(output) }
                }
            } catch (e: IOException) {
                destDir.mkdirs() // was actually an empty directory
            }
        } else {
            destDir.mkdirs()
            for (child in children) {
                extractAssetDir(assetManager, "$assetPath/$child", File(destDir, child))
            }
        }
    }

    /**
     * Returns null if siteDir looks like the real site root (index.html plus .js files under _nuxt), otherwise a
     * human-readable description of what is missing. Also logs the facts (tag NCViewer).
     */
    private fun verifySite(siteDir: File): String? {
        val hasIndex = File(siteDir, "index.html").isFile
        val jsCount = File(siteDir, "_nuxt").walkTopDown().count { it.isFile && it.extension == "js" }
        Log.d(TAG, "site root=${siteDir.absolutePath} index.html=$hasIndex _nuxt/*.js files=$jsCount " +
            "top-level=${siteDir.list()?.sorted()}")
        return when {
            !hasIndex -> "index.html is missing in ${siteDir.absolutePath}"
            jsCount == 0 -> "index.html is there but ${siteDir.absolutePath}/_nuxt contains no .js files. " +
                "The APK was built without www/_nuxt (check androidResources.ignoreAssetsPattern in app/build.gradle.kts)."
            else -> null
        }
    }

    /** [preferred] if it can be bound right now, otherwise any free port. */
    private fun choosePort(preferred: Int): Int = try {
        java.net.ServerSocket().use { s ->
            s.reuseAddress = true
            s.bind(InetSocketAddress("0.0.0.0", preferred))
        }
        preferred
    } catch (e: IOException) {
        val free = java.net.ServerSocket(0).use { it.localPort }
        Log.w(TAG, "port $preferred is busy (${e.message}); using $free instead")
        free
    }

    /** Polls 127.0.0.1:port until a TCP connection succeeds, so loadUrl() never races main(). */
    private fun waitForPort(port: Int, timeoutMs: Long = 5000) {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            try {
                Socket().use { it.connect(InetSocketAddress("127.0.0.1", port), 200) }
                return
            } catch (e: IOException) {
                Thread.sleep(20)
            }
        }
        Log.e(TAG, "waitForPort: server did not come up on port $port within ${timeoutMs}ms")
    }
}
