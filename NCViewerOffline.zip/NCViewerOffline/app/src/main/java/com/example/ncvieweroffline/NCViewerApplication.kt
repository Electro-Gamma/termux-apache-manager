package com.example.ncvieweroffline

import android.app.Application
import com.example.ncvieweroffline.crash.GlobalCrashHandler

class NCViewerApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        GlobalCrashHandler.install(this)
    }
}
