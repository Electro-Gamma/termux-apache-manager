plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.ncvieweroffline"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.ncvieweroffline"
        minSdk = 26 // Serve.kt uses java.time + java.nio.file, both API 26+ on Android
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // deliberately no third-party libraries — WebView + java.net only
}
