plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.ncvieweroffline"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.ncvieweroffline"
        minSdk = 26 // Serve.kt uses java.time + java.nio.file, both API 26+ on Android
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    buildFeatures {
        buildConfig = true
    }

    // ROOT CAUSE FIX. AGP/aapt2's default ignoreAssetsPattern is
    //   !.svn:!.git:!.ds_store:!*.scc:.*:<dir>_*:!CVS:!thumbs.db:!picasa.ini:!*~
    // and its "<dir>_*" entry silently drops every assets directory whose name starts with "_".
    // That removes www/_nuxt/ (all the site's JavaScript + CSS) from the APK while index.html,
    // imgs/ and s/ survive -> the server serves the HTML fine and every /_nuxt/*.js is a 404.
    // Same pattern with only "<dir>_*" removed:
    androidResources {
        ignoreAssetsPattern = "!.svn:!.git:!.ds_store:!*.scc:.*:!CVS:!thumbs.db:!picasa.ini:!*~"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // deliberately no third-party libraries — WebView + java.net only
}
