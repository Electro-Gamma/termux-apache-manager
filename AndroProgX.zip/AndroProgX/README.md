# AndroProgX — CH341A EEPROM & Flash Programmer

Turns an Android phone into a **CH341A USB EEPROM/SPI programmer** -
plug in one of the common black/green CH341A programmer boards (VID
`1A86` / PID `5512`, running in its EEPROM/SPI *programmer* mode - not a
plain CH340 UART adapter), pick a mode, hit **Connect**, and read,
write, or erase I2C EEPROMs and SPI NOR flash chips, drive a small
SSD1306 I2C OLED display, or bridge I2C/SPI over the network to another
device - all from the phone, no PC required.

**Note on this delivery:** this is a complete, ready-to-build Android
Studio project (Gradle config, manifest, Kotlin sources, resources). It
was put together in an environment with no Android SDK and no network
access, so no `.apk` binary is included - build it with the steps
below. It has been through real Gradle build/install cycles during
development (catching and fixing several real bugs along the way -
see `NOTICE.md` for the technical ones with license implications) but
has **not** been exercised against real CH341A hardware, so treat the
actual USB/I2C/SPI behavior as logically reviewed and cross-checked
against known-working reference implementations, not hardware-verified.

## The four modes

The **Mode** picker (repeated in a small row at the top of every
screen, always in sync) switches between:

| Mode | What it's for |
|---|---|
| **I2C EEPROM (24Cxx)** | Read/write/erase 24-series I2C EEPROMs |
| **SPI Flash (25xx)** | Read/write/erase 25-series SPI NOR flash |
| **SSD1306 Display** | Drive a small I2C OLED panel |
| **TCP Server** | Bridge I2C/SPI over the network to another device |

Only one mode's screen is shown at a time, and the **Mode** picker is
disabled while connected - disconnect first to switch. **TCP Server**
doesn't need its own USB connection type: under the hood it connects
exactly the way **I2C EEPROM** does, since that's all I2C-over-TCP
actually needs (see `ProgrammerController.connect()` and the `UiPage`
enum in `MainActivity.kt`).

## I2C EEPROM (24Cxx)

Pick a chip from the **Chip** picker - 13 presets from 24C01 (128 B)
through 24C1024 (128 KB), plus the two oddball-addressing 24LC515/
24LC1025 (64 KB/128 KB) variants - or enter a custom size manually.
Then:

- **Read** - dumps the whole chip into the hex editor below.
- **Write** - prompts for a `.bin` file (via Android's file picker) and
  writes it, page-by-page.
- **Erase** - fills the chip with `0xFF`.
- **Write Random** - fills the hex editor with random bytes and writes
  them - a quick way to get *something* different on the chip to
  verify a Read afterward actually reads it back.
- **Detect** - probes to figure out the chip's actual size, for when
  you don't know which 24Cxx you're holding.
- **Verify** / **Dump** - **UI only, not wired up yet** - present in
  the layout (per the reference design this screen is styled after)
  but tapping them does nothing. See "Not yet implemented" below.

The hex editor (16 bytes/row, offset | hex | ASCII, tap any byte or
ASCII character to edit it in place) is always showing *something* -
256 bytes of `0xFF` on first launch, then whatever the last Read/Write
Random/Load File put there - and **Load File**/**Save File** let you
pull that buffer from or push it to a file independent of the actual
chip.

## SPI Flash (25xx)

**Detect Chip (JEDEC ID)** reads the chip's manufacturer/type/capacity
bytes and looks them up (9 manufacturers, 31 exact part-name matches,
falling back to "Manufacturer SPI NOR (generic)" otherwise - see
`SpiFlashDatabase.kt`) to fill in size and show a friendly name; or set
size/page size manually if you'd rather skip detection. Then:

- **Read** / **Write** / **Erase** - same idea as the EEPROM panel,
  using the standard SPI NOR command set (page program, sector/chip
  erase, status polling) that's identical across virtually every
  25xx-family chip regardless of manufacturer.
- **Write Random** - same as the EEPROM panel's.
- **Verify** / **Dump** - **UI only, not wired up yet** - see "Not yet
  implemented" below.

Same always-populated 16-byte-row hex editor and Load File/Save File
as the EEPROM panel.

## SSD1306 Display

Set the I2C address (`3C` is the near-universal default; some boards
use `3D`) and panel size (128x64, 128x32, 96x16, or 64x32 - each with
its own correct contrast/COM-pin configuration), tap **Init Display**
once, then:

- **Test Pattern** / **Clear**
- **Draw Text** - draws whatever's in the text box, in the built-in 5x7
  pixel font (upper/lowercase, digits, punctuation) or a loaded custom
  font (see below)
- **Load Image** - any picture via the file picker, scaled to the
  panel and dithered to 1-bit automatically

**Custom Font** - pick one of the two bundled pixel fonts (Alagard,
PixelOperator) or any `.ttf`/`.otf` from the phone; once loaded, **Draw
Text** and the **Clock**'s time/date use it instead of the built-in font.

**Clock** - an analog clock face plus digital time/date, redrawn once a
second, until you hit Stop.

**Device Stats** - battery level, battery temperature, RAM, storage,
and the phone's IP address, redrawn once a second.

**Animate Images** - pick 2+ images (any order, any format) and they
loop on the panel at whatever delay you set, each frame scaled/dithered
the same way Load Image does.

Only one of Clock/Stats/Animate runs at a time - starting one stops
whichever of the other two was running.

## TCP Server

**I2C-over-TCP** - tap **Start** and any device on the network can run
I2C transactions against whatever's wired to the CH341A, not just this
app - see `I2cTcpServer.kt`'s doc comment for the exact length-prefixed
wire protocol. Needs a live connection (which, per the Mode note above,
this page opens the same way I2C EEPROM mode does).

**SPI-over-TCP** - **UI only, not wired up yet** - see "Not yet
implemented" below.

## Not yet implemented

Three controls exist in the layout - styled and positioned to match
the reference design this app's UI follows - but have no code behind
them, by explicit request while reorganizing the UI rather than adding
new backend features:

- **Verify** and **Dump** (both the EEPROM and SPI Flash panels) - no
  `onClickListener` at all; tapping them does nothing.
- **SPI-over-TCP** (TCP Server page) - same: a status line, port
  field, and Start/Stop button that don't yet do anything. A real
  implementation would need its own server class arbitrating the SPI
  bus between this app's own UI and a remote client, analogous to
  `I2cTcpServer.kt` but for SPI.

If you pick any of these up, `MainActivity.kt`'s existing
`onEepromDetectClicked`/`onSpiDetectClicked`/`onI2cTcpToggleClicked`
and `ProgrammerController`'s corresponding suspend functions are the
pattern to follow.

## Project structure

```
app/src/main/java/com/androprogx/app/
├── MainActivity.kt          UI wiring: buttons, spinners, the hex editor, mode switching
├── ch341/                   Raw CH341A USB transport + its SPI/I2C stream protocols
├── eeprom/                  I2C EEPROM (24Cxx) and SPI NOR flash (25xx) logic + chip databases
├── display/                 SSD1306 driver, and the clock/stats/text-rendering compositor
├── programmer/              ProgrammerController (ties USB+EEPROM+SPI+display+TCP together),
│                             I2cTcpServer
└── ui/                      HexEditorAdapter (the 16-bytes/row hex+ASCII grid)
```

## Permissions

| Permission | Why |
|---|---|
| USB host feature | Talk to the CH341A over USB |
| `INTERNET` | Run the I2C-over-TCP server |
| `ACCESS_NETWORK_STATE` / `ACCESS_WIFI_STATE` | Show the phone's IP address (TCP Server page, Device Stats) |

EEPROM/SPI flash dump load/save and OLED image/font/animation-frame
picking all go through Android's Storage Access Framework file picker,
so none of it needs a storage permission.

## Building

Standard Android Studio project - open the folder, let Gradle sync,
build/run on a phone with USB host support. `minSdk` 26, `targetSdk`/
`compileSdk` 35.

## License / attribution

Most of this app is original code written from public/standard
specifications (the SPI NOR JEDEC command set, the SSD1306 datasheet,
etc). The parts that aren't - protocol logic ported from two
GPL-licensed C projects (flashrom, IMSProg), some BSD-licensed code and
data from Adafruit's SSD1306/GFX libraries, and two bundled third-party
font files - are documented file-by-file in `NOTICE.md`.
