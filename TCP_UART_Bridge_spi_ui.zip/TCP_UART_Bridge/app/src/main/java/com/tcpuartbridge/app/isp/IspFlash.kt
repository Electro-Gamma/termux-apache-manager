package com.tcpuartbridge.app.isp

import com.tcpuartbridge.app.eeprom.SpiFlashDatabase

/**
 * The same SPI NOR flash ("25xx" family) command set as
 * [com.tcpuartbridge.app.eeprom.SpiFlash] - JEDEC ID, READ, WREN, page program, sector/chip
 * erase, status-register read/write/unprotect - built on top of a [SerprogClient] instead of
 * [com.tcpuartbridge.app.ch341.Ch341Spi]. Kept as its own small class rather than reusing
 * [com.tcpuartbridge.app.eeprom.SpiFlash] directly so this package stays fully self-contained
 * (its only dependency on the rest of the app is a read-only one: chip name/size lookup via
 * [SpiFlashDatabase]) - see this package's `README` note. The command set itself is the same
 * industry-standard SPI NOR instruction set [SpiFlash]'s own doc comment describes - de facto
 * identical across manufacturers, not specific to any one tool.
 *
 * Chunk sizes for read/write are bounded by [SerprogClient.maxReadLen]/[SerprogClient.maxWriteLen]
 * rather than a fixed constant: on a small microcontroller-based serprog programmer these can be
 * very small (64/32 bytes on the reference Arduino sketch this was cross-checked against, to stay
 * inside its USB-serial chip's tiny internal buffer - see that sketch's own comments about UART
 * overrun), so every operation here re-issues a fresh opcode+address each chunk rather than
 * assuming one large transfer will work - the same pattern [SpiFlash.read]/[SpiFlash.write] use,
 * just with a device-reported chunk size instead of a size picked purely for USB efficiency.
 */
class IspFlash(private val client: SerprogClient) {

    data class JedecId(val manufacturer: Int, val memoryType: Int, val capacityCode: Int) {
        /** Standard JEDEC convention: capacity in bytes = 2^capacityCode (valid for most parts). */
        val sizeBytes: Long get() = if (capacityCode in 8..30) 1L shl capacityCode else 0L
    }

    /** Set by [configureAddressing] - chips over 16MB need a 4th address byte and an explicit mode switch. */
    private var use4ByteAddr = false

    fun readJedecId(): JedecId? {
        val r = client.transfer(byteArrayOf(CMD_JEDEC_ID.toByte()), 3) ?: return null
        return JedecId(r[0].toInt() and 0xFF, r[1].toInt() and 0xFF, r[2].toInt() and 0xFF)
    }

    /** Reads the JEDEC ID and looks it up in [SpiFlashDatabase]. Returns null on a transport failure. */
    fun detectChip(): SpiFlashDatabase.ChipPreset? {
        val id = readJedecId() ?: return null
        return SpiFlashDatabase.identify(id.manufacturer, id.memoryType, id.capacityCode)
    }

    fun readStatus(): Int? {
        val r = client.transfer(byteArrayOf(CMD_RDSR.toByte()), 1) ?: return null
        return r[0].toInt() and 0xFF
    }

    /** Convenience wrapper around [readStatus] + [WriteProtection.decode]. */
    fun writeProtectionStatus(): WriteProtection.Status? = readStatus()?.let { WriteProtection.decode(it) }

    private fun writeEnable(): Boolean = client.transfer(byteArrayOf(CMD_WREN.toByte()), 0) != null

    private fun waitWhileBusy(timeoutMs: Long): Boolean {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            val sr = readStatus() ?: return false
            if (sr and SR_WIP == 0) return true
            Thread.sleep(2)
        }
        return false
    }

    /**
     * Call once after picking/detecting a chip, before any read/write/erase, with the chip's
     * total size - same 16MB threshold and 0xB7/0xE9 command pair as
     * [com.tcpuartbridge.app.eeprom.SpiFlash.configureAddressing]; see that doc comment for the
     * handful of Spansion/Cypress parts this generic approach doesn't cover.
     */
    fun configureAddressing(sizeBytes: Long): Boolean {
        val need4Byte = sizeBytes > 0x1000000L
        if (need4Byte == use4ByteAddr) return true
        use4ByteAddr = need4Byte
        return client.transfer(byteArrayOf((if (need4Byte) CMD_EN4B else CMD_EX4B).toByte()), 0) != null
    }

    private fun addr(address: Int): ByteArray = if (use4ByteAddr) {
        byteArrayOf(
            ((address shr 24) and 0xFF).toByte(), ((address shr 16) and 0xFF).toByte(),
            ((address shr 8) and 0xFF).toByte(), (address and 0xFF).toByte()
        )
    } else {
        byteArrayOf(((address shr 16) and 0xFF).toByte(), ((address shr 8) and 0xFF).toByte(), (address and 0xFF).toByte())
    }

    /**
     * Clears the status register's block-protect bits (BP0-BP3), same bit math as
     * [com.tcpuartbridge.app.eeprom.SpiFlash.unprotect] - see [WriteProtection] for a decoded,
     * human-readable view of what this is clearing and why it's usually needed before a chip
     * that's never been touched (or was left protected by a previous tool) will actually erase.
     */
    fun unprotect(): Boolean {
        val sr = readStatus() ?: return false
        val cleared = sr and 0xC3 // keep WIP/WEL (bits 0-1) and bits 6-7, clear BP0-BP3 (bits 2-5)
        if (cleared == sr) return true
        if (!writeEnable()) return false
        return client.transfer(byteArrayOf(CMD_WRSR.toByte(), cleared.toByte()), 0) != null
    }

    /**
     * Sets or clears SRP0 (status register protect enable, bit 7) - flashrom's `--wp-enable` /
     * `--wp-disable` equivalent. See [WriteProtection] for what this bit does.
     */
    fun setStatusRegisterProtect(enabled: Boolean): Boolean {
        val sr = readStatus() ?: return false
        val newSr = if (enabled) (sr or 0x80) else (sr and 0x7F)
        if (newSr == sr) return true
        if (!writeEnable()) return false
        return client.transfer(byteArrayOf(CMD_WRSR.toByte(), newSr.toByte()), 0) != null
    }

    /** Reads [length] bytes starting at [address]. Returns null on the first transport failure. */
    fun read(address: Int, length: Int, onProgress: ((Int, Int) -> Unit)? = null): ByteArray? {
        val out = ByteArray(length)
        var offset = 0
        val chunk = maxOf(1, minOf(client.maxReadLen, READ_CHUNK_CEILING))
        while (offset < length) {
            val n = minOf(chunk, length - offset)
            val cmd = byteArrayOf(CMD_READ.toByte()) + addr(address + offset)
            val r = client.transfer(cmd, n) ?: return null
            System.arraycopy(r, 0, out, offset, n)
            offset += n
            onProgress?.invoke(offset, length)
        }
        return out
    }

    /** Erases the whole chip. Can take tens of seconds to minutes on larger parts. */
    fun eraseChip(timeoutMs: Long = 200_000): Boolean {
        if (!unprotect()) return false
        if (!writeEnable()) return false
        if (client.transfer(byteArrayOf(CMD_CHIP_ERASE.toByte()), 0) == null) return false
        return waitWhileBusy(timeoutMs)
    }

    /** Erases one 4KB sector containing [address]. */
    fun eraseSector4k(address: Int): Boolean {
        if (!writeEnable()) return false
        val cmd = byteArrayOf(CMD_SECTOR_ERASE_4K.toByte()) + addr(address and 0xFFF000.toInt())
        if (client.transfer(cmd, 0) == null) return false
        return waitWhileBusy(10_000)
    }

    /**
     * Erases every 4KB sector covering [address] until [address]+[length], then writes [data]
     * page-by-page (respecting [pageSize], default 256B which covers virtually all SPI NOR
     * parts) in chunks no larger than the connected device's advertised max write length. Pass
     * [eraseFirst] = false to skip erasing (e.g. writing to already-erased space).
     */
    fun write(
        address: Int,
        data: ByteArray,
        pageSize: Int = 256,
        eraseFirst: Boolean = true,
        onProgress: ((Int, Int) -> Unit)? = null
    ): Boolean {
        if (eraseFirst) {
            if (!unprotect()) return false
            var sectorAddr = address - (address % 4096)
            val endAddr = address + data.size
            while (sectorAddr < endAddr) {
                if (!eraseSector4k(sectorAddr)) return false
                sectorAddr += 4096
            }
        }
        val addrLen = if (use4ByteAddr) 4 else 3
        val maxDataPerCall = maxOf(1, client.maxWriteLen - 1 - addrLen) // -1 for the opcode byte
        var offset = 0
        while (offset < data.size) {
            val addrNow = address + offset
            val bytesLeftInPage = pageSize - (addrNow % pageSize)
            val n = minOf(bytesLeftInPage, data.size - offset, maxDataPerCall)
            if (!writeEnable()) return false
            val cmd = byteArrayOf(CMD_PAGE_PROGRAM.toByte()) + addr(addrNow) + data.copyOfRange(offset, offset + n)
            if (client.transfer(cmd, 0) == null) return false
            if (!waitWhileBusy(3_000)) return false
            offset += n
            onProgress?.invoke(offset, data.size)
        }
        return true
    }

    companion object {
        private const val CMD_WREN = 0x06
        private const val CMD_RDSR = 0x05
        private const val CMD_WRSR = 0x01
        private const val CMD_READ = 0x03
        private const val CMD_PAGE_PROGRAM = 0x02
        private const val CMD_SECTOR_ERASE_4K = 0x20
        private const val CMD_CHIP_ERASE = 0xC7
        private const val CMD_JEDEC_ID = 0x9F
        private const val CMD_EN4B = 0xB7 // enter 4-byte address mode
        private const val CMD_EX4B = 0xE9 // exit 4-byte address mode
        private const val SR_WIP = 0x01 // write-in-progress bit

        /** Upper bound on a read chunk regardless of what the device reports - keeps memory/IO sane. */
        private const val READ_CHUNK_CEILING = 4096
    }
}
