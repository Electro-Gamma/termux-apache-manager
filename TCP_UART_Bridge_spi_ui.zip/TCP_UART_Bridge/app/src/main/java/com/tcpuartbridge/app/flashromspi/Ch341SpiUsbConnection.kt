package com.tcpuartbridge.app.flashromspi

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbManager
import android.os.Build

/**
 * Finds and opens the CH341A (VID `0x1A86` / PID `0x5512`, the same "programmer mode" personality
 * [com.tcpuartbridge.app.ch341.Ch341UsbDevice] already targets for this app's own hand-rolled SPI
 * driver) for the flashrom-binary path in this package, which needs a raw
 * [UsbDeviceConnection] and nothing more: unlike the existing Kotlin SPI driver, flashrom's
 * (patched, bundled) libusb wraps the connection's file descriptor itself and does its own
 * interface claiming through it - see this package's `README.md`.
 *
 * Deliberately self-contained rather than reusing `Ch341UsbDevice` - this package talks to the
 * device in a completely different way (hand the fd to a native process vs. issue USB control/bulk
 * transfers directly), and duplicating the ~20 lines of permission/open boilerplate keeps that
 * distinction clear and keeps this package independent of the rest of the app's USB code.
 */
class Ch341SpiUsbConnection(private val context: Context) {

    private val usbManager: UsbManager = context.getSystemService(Context.USB_SERVICE) as UsbManager

    fun findDevice(): UsbDevice? =
        usbManager.deviceList.values.firstOrNull { it.vendorId == VENDOR_ID && it.productId == PRODUCT_ID }

    fun hasPermission(device: UsbDevice): Boolean = usbManager.hasPermission(device)

    fun requestPermission(device: UsbDevice, callback: (Boolean) -> Unit) {
        val action = "com.tcpuartbridge.app.flashromspi.USB_PERMISSION"
        val mutabilityFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0
        val permissionIntent = PendingIntent.getBroadcast(
            context, 0, Intent(action).setPackage(context.packageName), mutabilityFlag
        )
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context, intent: Intent) {
                if (intent.action == action) {
                    context.unregisterReceiver(this)
                    callback(intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false))
                }
            }
        }
        val filter = IntentFilter(action)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            context.registerReceiver(receiver, filter)
        }
        usbManager.requestPermission(device, permissionIntent)
    }

    /**
     * Opens [device]. Deliberately does *not* call `claimInterface()` - flashrom's bundled,
     * patched libusb does its own interface claiming once it wraps this connection's fd (see
     * `libusb_wrap_sys_device()` in this package's `README.md`), the same way the reference
     * Diamon "Flash EEPROM Tool" project's own `UsbController.connectToDevice()` leaves it to
     * libusb rather than claiming it at the Android API level first.
     */
    fun open(device: UsbDevice): UsbDeviceConnection? = usbManager.openDevice(device)

    companion object {
        const val VENDOR_ID = 0x1A86
        const val PRODUCT_ID = 0x5512
    }
}
