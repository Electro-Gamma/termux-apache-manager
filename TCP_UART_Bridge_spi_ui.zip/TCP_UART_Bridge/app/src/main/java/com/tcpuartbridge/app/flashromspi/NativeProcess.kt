package com.tcpuartbridge.app.flashromspi

/**
 * The JNI surface implemented by `app/src/main/cpp/native-lib.cpp` (built into `libflashromjni.so`
 * by `app/src/main/cpp/CMakeLists.txt`). Kept as a tiny standalone object - just the four native
 * declarations plus the `System.loadLibrary` call - so nothing else in this package needs to know
 * these are JNI calls at all; see [FlashromProcess] for the actual process-lifecycle logic built
 * on top of them.
 *
 * Why any native code is needed here at all: Android's `ProcessBuilder`/`Runtime.exec()` always
 * marks every file descriptor above stdin/stdout/stderr as close-on-exec before starting a child
 * process, so the CH341A's already-open USB connection fd
 * ([android.hardware.usb.UsbDeviceConnection.getFileDescriptor]) would be silently closed before
 * flashrom ever saw it. Only a real `fork()`+`exec()` done in C - clearing `FD_CLOEXEC` on that
 * one fd first - can hand it to flashrom still open, which is all `native-lib.cpp` does.
 */
object NativeProcess {
    init {
        System.loadLibrary("flashromjni")
    }

    /** Duplicates [fd] into a new, inheritable-across-exec fd. Returns -1 on failure. */
    @JvmStatic
    external fun dupFdForChild(fd: Int): Int

    /** Closes a fd previously returned by [dupFdForChild], once the child process has exited. */
    @JvmStatic
    external fun closeDupedFd(fd: Int)

    /**
     * fork()+exec()'s [executable] with [args] (argv[0] is set to [executable] itself - don't
     * include it in [args]), exporting [usbFd] to the child as `ANDROID_USB_FD` (skipped if
     * [usbFd] is negative) and setting `LD_LIBRARY_PATH` to [ldLibraryPath] and the working
     * directory to [workingDir]. The child's stdout+stderr are merged into a pipe.
     *
     * @return `[pid, pipeReadFd]` on success, or null if the pipe/fork itself failed (as opposed
     *   to the exec'd program failing to start, which instead shows up as the child exiting 127 -
     *   see [FlashromProcess]).
     */
    @JvmStatic
    external fun startNativeProcess(
        executable: String,
        args: Array<String>,
        usbFd: Int,
        ldLibraryPath: String,
        workingDir: String
    ): IntArray?

    /** Blocks until [pid] exits, returning its exit code (or -1 if it didn't exit normally). */
    @JvmStatic
    external fun waitForNativeProcess(pid: Int): Int

    /** SIGKILLs [pid] - used to abort an in-progress flashrom run. */
    @JvmStatic
    external fun terminateNativeProcess(pid: Int)
}
