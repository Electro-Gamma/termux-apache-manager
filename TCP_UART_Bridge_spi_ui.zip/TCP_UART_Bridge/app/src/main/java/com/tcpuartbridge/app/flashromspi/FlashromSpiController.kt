package com.tcpuartbridge.app.flashromspi

import android.content.Context
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Ties [Ch341SpiUsbConnection] + [FlashromRuntime] + [FlashromProcess] together into the same
 * one-suspend-function-per-action shape [com.tcpuartbridge.app.programmer.ProgrammerController]
 * uses for the app's existing (hand-rolled) SPI/I2C driver, so wiring this into a future UI screen
 * is a drop-in job. This is the real flashrom CLI binary doing the actual chip talking - see this
 * package's `README.md` for what's bundled and where it came from - not a reimplementation of the
 * SPI NOR command set the way `eeprom/SpiFlash.kt` is.
 *
 * Backend only, like the rest of this package - see the repo root `README.md`.
 */
class FlashromSpiController(private val context: Context) {

    private val usbConnection = Ch341SpiUsbConnection(context)
    private val process = FlashromProcess()

    private var deviceConnection: UsbDeviceConnection? = null
    private var flashromBin: File? = null

    val isConnected: Boolean get() = deviceConnection != null
    val isRunning: Boolean get() = process.isRunning

    fun findDevice(): UsbDevice? = usbConnection.findDevice()
    fun hasPermission(device: UsbDevice): Boolean = usbConnection.hasPermission(device)
    fun requestPermission(device: UsbDevice, callback: (Boolean) -> Unit) =
        usbConnection.requestPermission(device, callback)

    /**
     * Opens the CH341A and prepares the runtime library symlinks (see [FlashromRuntime]). Returns
     * false if the device couldn't be opened or the bundled native libraries are incomplete
     * (that second case means an incomplete build - see the package README's file list).
     */
    suspend fun connect(device: UsbDevice): Boolean = withContext(Dispatchers.IO) {
        val bin = FlashromRuntime.ensureReady(context) ?: return@withContext false
        val conn = usbConnection.open(device) ?: return@withContext false
        deviceConnection = conn
        flashromBin = bin
        true
    }

    suspend fun disconnect() = withContext(Dispatchers.IO) {
        process.abort()
        deviceConnection?.close()
        deviceConnection = null
        flashromBin = null
    }

    fun abort() = process.abort()

    /** Runs `flashrom -p ch341a_spi` with no other arguments - a probe-only chip identification. */
    suspend fun probe(onOutput: (String) -> Unit): Int = runFlashrom(listOf("-p", PROGRAMMER), onOutput)

    /** `flashrom -p ch341a_spi -r <file>` - dumps the whole chip to [outputFile]. */
    suspend fun read(outputFile: File, onOutput: (String) -> Unit): Int =
        runFlashrom(listOf("-p", PROGRAMMER, "-r", outputFile.absolutePath), onOutput)

    /** `flashrom -p ch341a_spi -w <file>` - writes [inputFile]'s contents to the chip. */
    suspend fun write(inputFile: File, onOutput: (String) -> Unit): Int =
        runFlashrom(listOf("-p", PROGRAMMER, "-w", inputFile.absolutePath), onOutput)

    /** `flashrom -p ch341a_spi -v <file>` - verifies the chip's contents against [expected]. */
    suspend fun verify(expected: File, onOutput: (String) -> Unit): Int =
        runFlashrom(listOf("-p", PROGRAMMER, "-v", expected.absolutePath), onOutput)

    /** `flashrom -p ch341a_spi --erase` - erases the whole chip. */
    suspend fun erase(onOutput: (String) -> Unit): Int =
        runFlashrom(listOf("-p", PROGRAMMER, "--erase"), onOutput)

    private suspend fun runFlashrom(args: List<String>, onOutput: (String) -> Unit): Int =
        withContext(Dispatchers.IO) {
            val bin = flashromBin
            val conn = deviceConnection
            if (bin == null || conn == null) {
                onOutput("[ERROR] Not connected.\n")
                return@withContext -1
            }
            process.run(
                flashromBin = bin,
                args = args,
                usbFd = conn.fileDescriptor,
                ldLibraryPath = FlashromRuntime.ldLibraryPath(context),
                workingDir = context.filesDir,
                onOutput = FlashromProcess.OutputListener { chunk -> onOutput(chunk) }
            )
        }

    companion object {
        private const val PROGRAMMER = "ch341a_spi"
    }
}
