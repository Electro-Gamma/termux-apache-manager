package com.tcpuartbridge.app.flashromspi

import android.os.ParcelFileDescriptor
import java.io.File
import java.io.FileInputStream
import java.io.InputStreamReader

/**
 * Runs the bundled `flashrom` binary as a real child process - via [NativeProcess], not
 * `ProcessBuilder`, so the CH341A's USB connection fd survives into it (see [NativeProcess]'s doc
 * comment) - and streams its combined stdout+stderr back one chunk at a time as it runs, the way
 * flashrom's own progress percentage output expects to be consumed rather than captured only once
 * the process exits.
 *
 * Mirrors the shape of the Diamon "Flash EEPROM Tool" project's `FlashromExecutor` (see this
 * package's `README.md`), trimmed to the one thing this package needs it for: `ch341a_spi`,
 * which - unlike that project's serial-programmer paths - needs no PTY, just the USB fd.
 */
class FlashromProcess {

    fun interface OutputListener {
        fun onOutput(chunk: String)
    }

    @Volatile
    private var currentPid: Int = -1

    val isRunning: Boolean get() = currentPid > 0

    /** SIGKILLs the in-progress run, if any. */
    fun abort() {
        val pid = currentPid
        if (pid > 0) {
            NativeProcess.terminateNativeProcess(pid)
            currentPid = -1
        }
    }

    /**
     * Runs [flashromBin] with [args], passing [usbFd] through as `ANDROID_USB_FD` and
     * [ldLibraryPath] as `LD_LIBRARY_PATH` (see [FlashromRuntime]), from working directory
     * [workingDir]. Calls [onOutput] with each chunk of combined stdout+stderr as it arrives, then
     * blocks (on the calling thread - call this from a background dispatcher) until the process
     * exits.
     *
     * @return the process's exit code, or -1 if it couldn't even be started.
     */
    fun run(
        flashromBin: File,
        args: List<String>,
        usbFd: Int,
        ldLibraryPath: String,
        workingDir: File,
        onOutput: OutputListener
    ): Int {
        if (!flashromBin.exists()) {
            onOutput.onOutput("[ERROR] flashrom binary not found at ${flashromBin.absolutePath}\n")
            return -1
        }

        var inheritableFd = -1
        try {
            if (usbFd >= 0) {
                inheritableFd = NativeProcess.dupFdForChild(usbFd)
            }
            val fdToPass = if (inheritableFd >= 0) inheritableFd else usbFd

            val processInfo = NativeProcess.startNativeProcess(
                flashromBin.absolutePath,
                args.toTypedArray(),
                fdToPass,
                ldLibraryPath,
                workingDir.absolutePath
            )
            if (processInfo == null || processInfo[0] <= 0) {
                onOutput.onOutput("[ERROR] Could not start the native flashrom process.\n")
                return -1
            }

            val pid = processInfo[0]
            val readFd = processInfo[1]
            currentPid = pid

            try {
                ParcelFileDescriptor.adoptFd(readFd).use { pfd ->
                    FileInputStream(pfd.fileDescriptor).use { fis ->
                        InputStreamReader(fis, Charsets.UTF_8).use { reader ->
                            val buffer = CharArray(512)
                            while (true) {
                                val n = reader.read(buffer)
                                if (n == -1) break
                                onOutput.onOutput(String(buffer, 0, n))
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                onOutput.onOutput("[ERROR] Reading flashrom output failed: ${e.message}\n")
            }

            return NativeProcess.waitForNativeProcess(pid)
        } catch (e: Exception) {
            onOutput.onOutput("[ERROR] flashrom process failed: ${e.message}\n")
            return -1
        } finally {
            currentPid = -1
            if (inheritableFd >= 0) {
                NativeProcess.closeDupedFd(inheritableFd)
            }
        }
    }
}
