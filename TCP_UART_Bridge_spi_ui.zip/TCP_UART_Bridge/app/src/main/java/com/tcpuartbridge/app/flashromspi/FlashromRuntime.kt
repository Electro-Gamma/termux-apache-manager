package com.tcpuartbridge.app.flashromspi

import android.content.Context
import android.system.Os
import android.util.Log
import java.io.File

/**
 * Prepares a small writable directory (under [Context.getFilesDir]) full of symlinks pointing
 * back into [android.content.pm.ApplicationInfo.nativeLibraryDir], named the way flashrom's own
 * dynamic loading actually expects (`libusb-1.0.so`, `libpci.so.3`, ...) rather than the
 * underscored names Android's jniLibs packaging requires (`libusb_1_0.so`, `libpci_3_15_0.so`,
 * ...) - `nativeLibraryDir` itself is read-only and can't hold those names directly, since AGP's
 * jniLibs packaging only accepts filenames of the literal form `lib<name>.so`.
 *
 * This is the same technique the Diamon "Flash EEPROM Tool" project's `AssetHelper` class uses
 * (`ensureNativeToolLinks()`) - see this package's `README.md` for the full provenance - trimmed
 * to only the seven files the `ch341a_spi` programmer path actually needs (see that README for
 * why flashrom's own dynamic-linking requirements pull in a few libraries - `libpci`, `libftdi1`,
 * `libjaylink` - that ch341a_spi itself never calls into: the binary was built with every
 * programmer backend compiled in, and the dynamic loader insists on resolving every one of a
 * binary's declared dependencies before it will run at all, whether or not a given run ever
 * exercises that code path).
 */
object FlashromRuntime {
    private const val TAG = "FlashromRuntime"

    /** Runtime soname flashrom/libusb look for, to the underscored filename it's shipped as in jniLibs. */
    private val SONAME_TO_JNILIB = linkedMapOf(
        "libusb-1.0.so" to "libusb_1_0.so",
        "libcrypto.so.3" to "libcrypto_3.so",
        "libpci.so.3" to "libpci_3_15_0.so",
        "libftdi1.so.2" to "libftdi1_2_6_0.so",
        "libjaylink.so" to "libjaylink.so",
        "libz.so.1" to "libz_1.so"
    )

    /**
     * Creates (or repairs) `<filesDir>/usr/lib/<soname>` symlinks and `<filesDir>/usr/sbin/flashrom`
     * for every entry in [SONAME_TO_JNILIB], all pointing into [nativeLibraryDir]. Safe to call on
     * every launch - existing correct symlinks are left alone (a stale one, e.g. after an APK
     * update moves `nativeLibraryDir`, is replaced).
     *
     * @return the `flashrom` executable's path once this returns successfully, or null if any
     *   required native library is missing from [nativeLibraryDir] (which would mean an
     *   incomplete build - see the package README's file list).
     */
    fun ensureReady(context: Context): File? {
        val nativeLibDir = File(context.applicationInfo.nativeLibraryDir)
        val usrLib = File(context.filesDir, "usr/lib")
        val usrSbin = File(context.filesDir, "usr/sbin")
        if (!usrLib.exists() && !usrLib.mkdirs()) {
            Log.e(TAG, "Could not create ${usrLib.absolutePath}")
            return null
        }
        if (!usrSbin.exists() && !usrSbin.mkdirs()) {
            Log.e(TAG, "Could not create ${usrSbin.absolutePath}")
            return null
        }

        var ok = true
        for ((soname, jniLibName) in SONAME_TO_JNILIB) {
            ok = link(File(usrLib, soname), File(nativeLibDir, jniLibName)) && ok
        }
        val flashromBin = File(usrSbin, "flashrom")
        ok = link(flashromBin, File(nativeLibDir, "libflashrom_bin.so")) && ok

        return if (ok) flashromBin else null
    }

    /** `nativeLibraryDir` first (the raw jniLibs files), then the symlink directory built above. */
    fun ldLibraryPath(context: Context): String {
        val nativeLibDir = context.applicationInfo.nativeLibraryDir
        val usrLib = File(context.filesDir, "usr/lib").absolutePath
        return "$nativeLibDir:$usrLib"
    }

    private fun link(linkPath: File, target: File): Boolean {
        if (!target.exists()) {
            Log.e(TAG, "Missing native library, can't link ${linkPath.name} -> ${target.absolutePath}")
            return false
        }
        return try {
            if (linkPath.exists() && linkPath.canonicalPath == target.canonicalPath) {
                return true // already correct
            }
            linkPath.delete() // clear a stale/broken link, if any
            Os.symlink(target.absolutePath, linkPath.absolutePath)
            true
        } catch (e: Exception) {
            Log.w(TAG, "symlink failed for ${linkPath.name}, falling back to a copy: ${e.message}")
            copy(target, linkPath)
        }
    }

    private fun copy(source: File, dest: File): Boolean = try {
        dest.parentFile?.let { if (!it.exists()) it.mkdirs() }
        source.copyTo(dest, overwrite = true)
        if (dest.parentFile?.name == "sbin" || dest.parentFile?.name == "bin") {
            dest.setExecutable(true, true)
        }
        true
    } catch (e: Exception) {
        Log.e(TAG, "Fallback copy failed for ${dest.name}: ${e.message}")
        false
    }
}
