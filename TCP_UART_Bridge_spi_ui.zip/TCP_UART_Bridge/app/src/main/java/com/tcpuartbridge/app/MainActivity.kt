package com.tcpuartbridge.app

import android.content.res.ColorStateList
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.hardware.usb.UsbDevice
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.InputFilter
import android.text.InputType
import android.text.Spannable
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.tcpuartbridge.app.databinding.ActivityMainBinding
import com.tcpuartbridge.app.display.OledCompositor
import com.tcpuartbridge.app.eeprom.I2cEeprom
import com.tcpuartbridge.app.eeprom.SpiFlashDatabase
import com.tcpuartbridge.app.flashromspi.FlashromSpiController
import com.tcpuartbridge.app.programmer.ProgrammerController
import com.tcpuartbridge.app.programmer.ProgrammerMode
import com.tcpuartbridge.app.ui.HexEditorAdapter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.random.Random
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * CH341A programmer app - I2C EEPROM (24Cxx) read/write, SPI NOR flash (25xx) read/erase/write,
 * and a small SSD1306 I2C OLED display driver (including a clock, a phone-stats dashboard, a
 * custom TTF/OTF font, and a multi-image animation loop), all over the CH341A's USB
 * "parallel/EPP" (programmer) mode. Also exposes an I2C-over-TCP server so another device on the
 * network can run I2C transactions against whatever's wired to the CH341A.
 *
 * This talks to the CH341A's programmer-mode USB personality via [Ch341UsbDevice] - see that
 * class's doc for why it needs its own connect/open/claim-interface flow rather than a standard
 * serial port.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val progBinding get() = binding.includeProgrammer

    private val programmerController by lazy { ProgrammerController(applicationContext) }
    /** The SPI Flash (25xx) page's connection - see the doc comment on [onSpiDetectClicked] and
     *  friends for why this page uses the real flashrom binary instead of [programmerController]'s
     *  hand-rolled SPI driver, and why that means its own, separate USB connection. */
    private val flashromSpiController by lazy { FlashromSpiController(applicationContext) }
    private var currentProgMode = ProgrammerMode.I2C_EEPROM
    private var progConnectedDevice: UsbDevice? = null

    /** The four pages the "Mode" selector (repeated - always in sync - at the top of whichever
     *  page is currently showing) switches between. TCP Server has no [ProgrammerMode] of its
     *  own: I2C-over-TCP and (once implemented) SPI-over-TCP both need a live connection, and the
     *  I2C one specifically just needs the I2C bus opened - exactly what [ProgrammerMode.I2C_EEPROM]
     *  already does in [ProgrammerController.connect] - so this page reuses that connection
     *  rather than inventing a fifth thing for the controller to know how to open. */
    private enum class UiPage(val progMode: ProgrammerMode) {
        EEPROM(ProgrammerMode.I2C_EEPROM),
        SPI(ProgrammerMode.SPI_FLASH),
        DISPLAY(ProgrammerMode.SSD1306_DISPLAY),
        TCP_SERVER(ProgrammerMode.I2C_EEPROM)
    }

    private val uiPageLabels = arrayOf("I2C EEPROM (24Cxx)", "SPI Flash (25xx)", "SSD1306 OLED Display", "TCP Server")
    private val uiPageValues = arrayOf(UiPage.EEPROM, UiPage.SPI, UiPage.DISPLAY, UiPage.TCP_SERVER)
    private var currentUiPage = UiPage.EEPROM

    private val eepromChipLabels = I2cEeprom.COMMON_CHIPS.map { it.name } + "Custom (enter size below)"
    private var selectedEepromChip: I2cEeprom.Chip = I2cEeprom.COMMON_CHIPS.first()

    private val spiChipLabels = SpiFlashDatabase.COMMON_CHIPS.map { it.name } + "Custom (enter size below)"
    /** Null = "Custom" is selected, so the size comes from [ActivityMainBinding]'s etSpiSizeKb field instead. */
    private var selectedSpiChipSize: Long? = SpiFlashDatabase.COMMON_CHIPS.firstOrNull()?.sizeBytes

    private val oledSizeLabels = arrayOf("128 x 64", "128 x 32", "96 x 16", "64 x 32")
    private val oledSizeValues = arrayOf(128 to 64, 128 to 32, 96 to 16, 64 to 32)
    private var selectedOledSize = oledSizeValues.first()

    /** Which of the clock/stats/animation continuous-redraw loops (if any) is currently running -
     *  mirrors [ProgrammerController.isContinuousRunning] but also tracks *which one*, so the
     *  right button gets put back to its "Start" label when another one supersedes it. */
    private enum class ContinuousMode { CLOCK, STATS, ANIMATION }
    private var activeContinuousMode: ContinuousMode? = null
    private var animFrameUris: List<Uri> = emptyList()

    /** Live, editable buffers backing each panel's embedded hex editor - populated by Read, Load
     *  File, Erase, or Write Random, edited in place by tapping a byte or ASCII character, and
     *  what Write/Save File act on. Seeded with [PLACEHOLDER_HEX_BYTES] bytes of 0xFF (erased/
     *  uninitialized-memory convention) so the grid is never blank on first launch, before any
     *  real Read has happened - matching the reference CH341A Programmer design, which always
     *  shows a populated hex dump. */
    private val eepromHexAdapter = HexEditorAdapter(defaultHexPlaceholder(), HexEditorAdapter.BYTES_PER_ROW,
        onByteTapped = { offset -> onEepromByteTapped(offset) },
        onAsciiTapped = { offset -> onEepromAsciiTapped(offset) })
    private val spiHexAdapter = HexEditorAdapter(defaultHexPlaceholder(), HexEditorAdapter.BYTES_PER_ROW,
        onByteTapped = { offset -> onSpiByteTapped(offset) },
        onAsciiTapped = { offset -> onSpiAsciiTapped(offset) })

    // ---- Storage Access Framework pickers for dump files --------------------

    private val eepromSaveLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
            if (uri != null) writeBytesToUri(uri, eepromHexAdapter.currentData(), "EEPROM dump")
        }

    private val eepromOpenLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) readBytesFromUri(uri) { bytes -> onEepromFileLoaded(bytes) }
        }

    private val spiSaveLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
            if (uri != null) writeBytesToUri(uri, spiHexAdapter.currentData(), "SPI flash dump")
        }

    private val spiOpenLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) readBytesFromUri(uri) { bytes -> onSpiFileLoaded(bytes) }
        }

    private val oledImageLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) onOledImageChosen(uri)
        }

    private val fontPickerLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) onFontChosen(uri)
        }

    private val animFramesLauncher =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            if (uris.isNotEmpty()) onAnimFramesChosen(uris)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setUpEdgeToEdgeInsets()
        setupProgrammerUi()
    }

    /** minSdk 26 through targetSdk 35 all draw edge-to-edge by default (mandatory from API 35 on,
     *  opt-in before that) - meaning our own content, not the OS, is responsible for keeping the
     *  header's title/subtitle text out from behind the status bar's clock/icons, and the log
     *  panel's content out from behind the gesture/3-button nav bar. The header/log *backgrounds*
     *  still deliberately extend up/down behind those system bars for a seamless look - only
     *  their content gets pushed in by the matching inset, via padding (not margin, so a tap near
     *  the very top of the header still lands inside it). */
    private fun setUpEdgeToEdgeInsets() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, binding.root).isAppearanceLightStatusBars = false

        val header = binding.headerBar
        val headerBaseTop = header.paddingTop
        val log = progBinding.scrollProgLog
        val logBaseBottom = log.paddingBottom
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            header.setPadding(header.paddingLeft, headerBaseTop + bars.top, header.paddingRight, header.paddingBottom)
            log.setPadding(log.paddingLeft, log.paddingTop, log.paddingRight, logBaseBottom + bars.bottom)
            insets
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        // Plain synchronous close (not the suspend disconnect()) - the activity is on its way
        // out, so there's no coroutine scope left to safely launch into.
        programmerController.stopI2cTcpServer()
        programmerController.usbDevice.close()
    }

    // ==================== CH341A: I2C EEPROM / SPI flash / SSD1306 ====================

    private fun setupProgrammerUi() {
        val p = progBinding

        val modeBoxes = listOf(p.spinnerEepromMode, p.spinnerSpiMode, p.spinnerDisplayMode, p.spinnerTcpServerMode)
        modeBoxes.forEach { box -> box.setOnClickListener { showModePicker(box) } }
        syncModeSpinners()

        p.spinnerEepromChip.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, eepromChipLabels)
        p.spinnerEepromChip.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val isCustom = position !in I2cEeprom.COMMON_CHIPS.indices
                p.etEepromCustomSize.visibility = if (isCustom) View.VISIBLE else View.GONE
                if (isCustom) {
                    p.tvEepromInfo.text = "Enter the size in bytes above - a 2-byte-address, 32-byte-page chip is assumed."
                    p.tvEepromInfoChipValue.text = eepromChipLabels[position]
                } else {
                    selectedEepromChip = I2cEeprom.COMMON_CHIPS[position]
                    p.tvEepromInfo.text = "${selectedEepromChip.totalBytes} bytes total, ${selectedEepromChip.pageSize}-byte write pages."
                    p.tvEepromInfoChipValue.text = selectedEepromChip.name
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        p.spinnerOledSize.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, oledSizeLabels)
        p.spinnerOledSize.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedOledSize = oledSizeValues[position]
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        p.spinnerSpiChip.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, spiChipLabels)
        p.spinnerSpiChip.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val isCustom = position !in SpiFlashDatabase.COMMON_CHIPS.indices
                if (isCustom) {
                    selectedSpiChipSize = null
                } else {
                    val chip = SpiFlashDatabase.COMMON_CHIPS[position]
                    selectedSpiChipSize = chip.sizeBytes
                    p.etSpiSizeKb.setText((chip.sizeBytes / 1024).toString())
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        p.btnProgConnect.setOnClickListener { onProgConnectClicked() }
        p.btnEepromRead.setOnClickListener { onEepromReadClicked() }
        p.btnEepromWrite.setOnClickListener { onEepromWriteClicked() }
        p.btnEepromErase.setOnClickListener { onEepromEraseClicked() }
        p.btnEepromRandom.setOnClickListener { onEepromRandomClicked() }
        p.btnEepromWriteText.setOnClickListener { onEepromWriteTextClicked() }
        p.btnEepromLoadFile.setOnClickListener { onEepromLoadFileClicked() }
        p.btnEepromSaveFile.setOnClickListener { onEepromSaveFileClicked() }
        p.btnSpiRead.setOnClickListener { onSpiReadClicked() }
        p.btnSpiErase.setOnClickListener { onSpiEraseClicked() }
        p.btnSpiWrite.setOnClickListener { onSpiWriteClicked() }
        p.btnSpiRandom.setOnClickListener { onSpiRandomClicked() }
        p.btnSpiWriteText.setOnClickListener { onSpiWriteTextClicked() }
        p.btnSpiLoadFile.setOnClickListener { onSpiLoadFileClicked() }
        p.btnSpiSaveFile.setOnClickListener { onSpiSaveFileClicked() }
        p.btnOledInit.setOnClickListener { onOledInitClicked() }
        p.btnOledTest.setOnClickListener { onOledTestClicked() }
        p.btnOledClear.setOnClickListener { onOledClearClicked() }
        p.btnOledDrawText.setOnClickListener { onOledDrawTextClicked() }
        p.btnOledLoadImage.setOnClickListener { onOledLoadImageClicked() }

        val fontLabels = listOf(getString(R.string.prog_font_builtin)) +
            ProgrammerController.BUNDLED_FONTS.map { it.displayName } +
            getString(R.string.prog_font_choose_phone)
        p.spinnerFont.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, fontLabels)
        p.spinnerFont.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                when (position) {
                    0 -> {
                        programmerController.clearCustomFont()
                        updateFontStatus()
                        progLog("Reverted to the built-in pixel font")
                    }
                    in 1..ProgrammerController.BUNDLED_FONTS.size -> {
                        val font = ProgrammerController.BUNDLED_FONTS[position - 1]
                        val ok = programmerController.loadBundledFont(this@MainActivity, font.assetPath, font.displayName)
                        updateFontStatus()
                        if (ok) progLog("Font loaded: ${font.displayName}") else progLog("Failed to load ${font.displayName} from assets", LogLevel.WARN)
                    }
                    else -> fontPickerLauncher.launch(arrayOf("*/*"))
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        p.btnClockToggle.setOnClickListener { onClockToggleClicked() }
        p.btnStatsToggle.setOnClickListener { onStatsToggleClicked() }
        p.btnAnimChoose.setOnClickListener { onAnimChooseClicked() }
        p.btnAnimToggle.setOnClickListener { onAnimToggleClicked() }

        p.btnI2cTcpToggle.setOnClickListener { onI2cTcpToggleClicked() }

        p.rvEepromHex.layoutManager = LinearLayoutManager(this)
        p.rvEepromHex.adapter = eepromHexAdapter
        p.rvEepromHex.setHasFixedSize(true)

        p.rvSpiHex.layoutManager = LinearLayoutManager(this)
        p.rvSpiHex.adapter = spiHexAdapter
        p.rvSpiHex.setHasFixedSize(true)

        p.btnSpiChipDetectBox.setOnClickListener { onSpiDetectClicked() }

        p.tvEepromInfo.text = "${selectedEepromChip.totalBytes} bytes total, ${selectedEepromChip.pageSize}-byte write pages."
        p.tvEepromInfoChipValue.text = selectedEepromChip.name
        refreshEepromHexInfo("placeholder")
        refreshSpiHexInfo("placeholder")
        updateProgConnectionUi(false)
    }

    /** Shows [page]'s panel and hides the other three (including the just-relocated TCP Server
     *  one), and updates [currentProgMode] to whatever connection [page] actually needs - see
     *  [UiPage]'s doc for why TCP Server reuses I2C EEPROM's. Called from whichever of the four
     *  Mode rows the person just picked from; [syncModeSpinners] then reflects the new page's
     *  label on the other three, so every page's Mode row always shows the same current value. */
    private fun switchToPage(page: UiPage) {
        if (currentUiPage == page) return
        currentUiPage = page
        currentProgMode = page.progMode
        progBinding.llI2cPanel.visibility = if (page == UiPage.EEPROM) View.VISIBLE else View.GONE
        progBinding.llSpiPanel.visibility = if (page == UiPage.SPI) View.VISIBLE else View.GONE
        progBinding.llDisplayPanel.visibility = if (page == UiPage.DISPLAY) View.VISIBLE else View.GONE
        progBinding.llTcpServerPanel.visibility = if (page == UiPage.TCP_SERVER) View.VISIBLE else View.GONE
        syncModeSpinners()
    }

    private fun syncModeSpinners() {
        val label = uiPageLabels[uiPageValues.indexOf(currentUiPage)]
        progBinding.tvEepromModeValue.text = label
        progBinding.tvSpiModeValue.text = label
        progBinding.tvDisplayModeValue.text = label
        progBinding.tvTcpServerModeValue.text = label
    }

    /** The Mode row (deliberately a plain clickable row rather than a real [android.widget.Spinner]
     *  - a Spinner's own text rendering can't be restyled down to match the compact Chip Detect
     *  row it sits next to) opens this small popup of the same four pages listed in [uiPageLabels]. */
    private fun showModePicker(anchor: View) {
        val popup = PopupMenu(this, anchor)
        uiPageLabels.forEachIndexed { index, label -> popup.menu.add(0, index, index, label) }
        popup.setOnMenuItemClickListener { item ->
            switchToPage(uiPageValues[item.itemId])
            true
        }
        popup.show()
    }

    // ---- connect / disconnect ----------------------------------------------

    private fun updateProgConnectionUi(connected: Boolean, deviceLabel: String? = null) {
        progBinding.tvProgStatus.text = if (connected) {
            "Connected: ${deviceLabel ?: programmerController.usbDevice.deviceLabel()}"
        } else {
            getString(R.string.prog_not_connected)
        }
        val statusColor = getColor(if (connected) R.color.status_ok else R.color.status_error)
        progBinding.tvProgStatus.setTextColor(statusColor)
        progBinding.vProgStatusDot.backgroundTintList = ColorStateList.valueOf(statusColor)
        progBinding.btnProgConnect.text = getString(if (connected) R.string.prog_disconnect else R.string.prog_connect)
        listOf(progBinding.spinnerEepromMode, progBinding.spinnerSpiMode, progBinding.spinnerDisplayMode, progBinding.spinnerTcpServerMode).forEach { box ->
            box.isEnabled = !connected
            box.alpha = if (connected) 0.55f else 1f
        }
        if (!connected) {
            // disconnect() always stops the I2C-over-TCP server too - reflect that here.
            progBinding.tvI2cTcpStatus.text = getString(R.string.prog_i2ctcp_not_running)
            progBinding.tvI2cTcpToggleLabel.text = getString(R.string.prog_i2ctcp_start)
            // ...and any running clock/stats/animation loop - reset that UI state too.
            activeContinuousMode = null
            resetContinuousButtons()
        }
    }

    private fun onProgConnectClicked() {
        if (currentProgMode == ProgrammerMode.SPI_FLASH) {
            onSpiConnectClicked()
            return
        }
        if (programmerController.isConnected) {
            lifecycleScope.launch {
                programmerController.disconnect(currentProgMode)
                progConnectedDevice = null
                updateProgConnectionUi(false)
                progLog("Disconnected")
            }
            return
        }

        val dev = programmerController.findDevice()
        if (dev == null) {
            progLog("No CH341A programmer found - plug it in (VID 1A86 / PID 5512) and tap Connect again", LogLevel.ERROR)
            return
        }

        if (programmerController.hasPermission(dev)) {
            connectToProgrammerDevice(dev)
        } else {
            programmerController.requestPermission(dev) { granted ->
                if (granted) connectToProgrammerDevice(dev) else progLog("USB permission denied", LogLevel.ERROR)
            }
        }
    }

    private fun connectToProgrammerDevice(dev: UsbDevice) {
        lifecycleScope.launch {
            val ok = programmerController.connect(dev, currentProgMode)
            if (ok) {
                progConnectedDevice = dev
                updateProgConnectionUi(true, programmerController.usbDevice.deviceLabel())
                progLog("Connected: ${programmerController.usbDevice.deviceLabel()}")
            } else {
                progLog("Failed to open/initialize the CH341A", LogLevel.ERROR)
            }
        }
    }

    /** Same shape as [onProgConnectClicked]/[connectToProgrammerDevice], but against
     *  [flashromSpiController]'s own, separate connection - see [onSpiDetectClicked]'s doc
     *  comment for why the SPI Flash page needs a different one than every other page. */
    private fun onSpiConnectClicked() {
        if (flashromSpiController.isConnected) {
            lifecycleScope.launch {
                flashromSpiController.disconnect()
                progConnectedDevice = null
                updateProgConnectionUi(false)
                progLog("Disconnected")
            }
            return
        }

        val dev = flashromSpiController.findDevice()
        if (dev == null) {
            progLog("No CH341A programmer found - plug it in (VID 1A86 / PID 5512) and tap Connect again", LogLevel.ERROR)
            return
        }

        if (flashromSpiController.hasPermission(dev)) {
            connectToFlashromSpiDevice(dev)
        } else {
            flashromSpiController.requestPermission(dev) { granted ->
                if (granted) connectToFlashromSpiDevice(dev) else progLog("USB permission denied", LogLevel.ERROR)
            }
        }
    }

    private fun connectToFlashromSpiDevice(dev: UsbDevice) {
        val label = "CH341A programmer (VID:${dev.vendorId} PID:${dev.productId}) - flashrom"
        lifecycleScope.launch {
            val ok = flashromSpiController.connect(dev)
            if (ok) {
                progConnectedDevice = dev
                updateProgConnectionUi(true, label)
                progLog("Connected: $label")
            } else {
                progLog(
                    "Failed to open the CH341A or prepare flashrom's native libraries - see Logcat for details",
                    LogLevel.ERROR
                )
            }
        }
    }

    // ---- I2C EEPROM ---------------------------------------------------------

    /** Reads the chip spinner, or builds a Chip from the custom-size field. Logs and returns null if invalid. */
    private fun currentEepromChip(): I2cEeprom.Chip? {
        val pos = progBinding.spinnerEepromChip.selectedItemPosition
        if (pos in I2cEeprom.COMMON_CHIPS.indices) return I2cEeprom.COMMON_CHIPS[pos]
        val size = progBinding.etEepromCustomSize.text.toString().toIntOrNull()
        if (size == null || size <= 0) {
            progLog("Enter a valid custom EEPROM size in bytes first", LogLevel.WARN)
            return null
        }
        progLog(
            "Custom chip: assuming 2-byte word addressing / 32-byte pages (typical for 32Kbit+ " +
                "EEPROMs) - pick the matching preset instead if your chip is smaller than that"
        )
        return I2cEeprom.Chip("Custom ($size B)", size, pageSize = 32, algorithm = 0x02)
    }

    private fun onEepromReadClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first", LogLevel.WARN)
            return
        }
        val chip = currentEepromChip() ?: return
        lifecycleScope.launch {
            setProgProgress(0)
            progLog("Reading ${chip.name}...")
            val data = programmerController.readEeprom(chip) { done, total ->
                runOnUiThread { setProgProgress(if (total > 0) done * 100 / total else 100) }
            }
            setProgProgress(null)
            if (data != null) {
                eepromHexAdapter.replaceData(data)
                refreshEepromHexInfo("from chip")
                progLog("Read ${data.size} bytes")
            } else {
                progLog("EEPROM read failed - check wiring and that a chip is present", LogLevel.ERROR)
            }
        }
    }

    private fun onEepromWriteClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first", LogLevel.WARN)
            return
        }
        val chip = currentEepromChip() ?: return
        val live = eepromHexAdapter.currentData()
        if (live.isEmpty()) {
            progLog("Nothing to write - tap Read or Load File first", LogLevel.WARN)
            return
        }
        // Snapshot rather than write the adapter's live array directly - it stays editable by the
        // user (tapping a byte) while this write is streaming, and the two shouldn't race.
        val data = if (live.size > chip.totalBytes) {
            progLog("Hex editor has ${live.size} B, larger than ${chip.name} (${chip.totalBytes} B) - truncating", LogLevel.WARN)
            live.copyOf(chip.totalBytes).also { eepromHexAdapter.replaceData(it) }
        } else {
            live.copyOf()
        }
        lifecycleScope.launch {
            setProgProgress(0)
            progLog("Writing ${data.size} bytes to ${chip.name}...")
            val ok = programmerController.writeEeprom(chip, data) { done, total ->
                runOnUiThread { setProgProgress(if (total > 0) done * 100 / total else 100) }
            }
            setProgProgress(null)
            if (ok) progLog("EEPROM write complete") else progLog("EEPROM write failed", LogLevel.ERROR)
        }
    }

    private fun onEepromLoadFileClicked() {
        progLog("Choose a file to load into the hex editor...")
        eepromOpenLauncher.launch(arrayOf("*/*"))
    }

    private fun onEepromFileLoaded(bytes: ByteArray) {
        eepromHexAdapter.replaceData(bytes)
        refreshEepromHexInfo("from file")
        progLog("Loaded ${bytes.size} bytes into the hex editor")
    }

    private fun onEepromSaveFileClicked() {
        val data = eepromHexAdapter.currentData()
        if (data.isEmpty()) {
            progLog("Nothing to save - tap Read or Load File first", LogLevel.WARN)
            return
        }
        eepromSaveLauncher.launch(suggestedFileName("eeprom_dump", data.size))
    }

    private fun onEepromEraseClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first", LogLevel.WARN)
            return
        }
        val chip = currentEepromChip() ?: return
        MaterialAlertDialogBuilder(this, R.style.ThemeOverlay_Prog_AlertDialog)
            .setTitle("Erase ${chip.name}?")
            .setMessage("Fills all ${chip.totalBytes} bytes with 0xFF. This cannot be undone. Continue?")
            .setPositiveButton("Erase") { _, _ ->
                lifecycleScope.launch {
                    setProgProgress(0)
                    progLog("Erasing ${chip.name}...")
                    val ok = programmerController.eraseEeprom(chip) { done, total ->
                        runOnUiThread { setProgProgress(if (total > 0) done * 100 / total else 100) }
                    }
                    setProgProgress(null)
                    if (ok) progLog("Erase complete") else progLog("Erase failed", LogLevel.ERROR)
                    if (ok) {
                        eepromHexAdapter.replaceData(ByteArray(chip.totalBytes) { 0xFF.toByte() })
                        refreshEepromHexInfo("from chip")
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun onEepromRandomClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first", LogLevel.WARN)
            return
        }
        val chip = currentEepromChip() ?: return
        MaterialAlertDialogBuilder(this, R.style.ThemeOverlay_Prog_AlertDialog)
            .setTitle("Write random data to ${chip.name}?")
            .setMessage("Overwrites all ${chip.totalBytes} bytes with random data. This cannot be undone. Continue?")
            .setPositiveButton("Write Random") { _, _ ->
                val randomData = ByteArray(chip.totalBytes)
                Random.nextBytes(randomData)
                lifecycleScope.launch {
                    setProgProgress(0)
                    progLog("Writing random data to ${chip.name}...")
                    val ok = programmerController.writeEeprom(chip, randomData) { done, total ->
                        runOnUiThread { setProgProgress(if (total > 0) done * 100 / total else 100) }
                    }
                    setProgProgress(null)
                    if (ok) progLog("Random write complete") else progLog("Random write failed", LogLevel.ERROR)
                    if (ok) {
                        eepromHexAdapter.replaceData(randomData)
                        refreshEepromHexInfo("from chip")
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun onEepromByteTapped(offset: Int) {
        showByteEditDialog(eepromHexAdapter, offset) { refreshEepromHexInfo("edited, not written yet") }
    }

    private fun onEepromAsciiTapped(offset: Int) {
        showAsciiEditDialog(eepromHexAdapter, offset) { refreshEepromHexInfo("edited, not written yet") }
    }

    private fun onEepromWriteTextClicked() {
        showWriteTextDialog(eepromHexAdapter) { refreshEepromHexInfo("text written, not written to chip yet") }
    }

    /** Opens a multi-line plain-text entry dialog and writes its ASCII bytes (newlines included,
     *  as 0x0A) into [adapter]'s buffer starting at offset 0 - a quick way to get readable text
     *  into the buffer without editing byte-by-byte, the same idea as the OLED panel's Draw Text
     *  but targeting a hex editor instead of the display. Only edits the in-memory buffer - Write
     *  still has to be tapped separately to actually send it to the chip, same as any other hex
     *  editor edit. [onCommitted] runs after a successful write, to refresh that panel's info line. */
    private fun showWriteTextDialog(adapter: HexEditorAdapter, onCommitted: () -> Unit) {
        val input = EditText(this).apply {
            hint = "Text to write"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            setSingleLine(false)
            minLines = 3
            maxLines = 8
            gravity = Gravity.TOP or Gravity.START
            val pad = (20 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad / 2, pad, pad / 2)
        }
        MaterialAlertDialogBuilder(this, R.style.ThemeOverlay_Prog_AlertDialog)
            .setTitle("Write text into hex editor")
            .setMessage("Writes the text below as ASCII bytes starting at offset 0, overwriting whatever's currently there.")
            .setView(input)
            .setPositiveButton("Add") { _, _ ->
                val text = input.text.toString()
                if (text.isEmpty()) {
                    progLog("Enter some text first", LogLevel.WARN)
                    return@setPositiveButton
                }
                val bufferSize = adapter.currentData().size
                val toWrite = if (text.length > bufferSize) text.substring(0, bufferSize) else text
                toWrite.forEachIndexed { i, ch -> adapter.setByte(i, (ch.code and 0xFF).toByte()) }
                onCommitted()
                if (text.length > bufferSize) {
                    progLog("Wrote the first $bufferSize of ${text.length} characters - the rest didn't fit the buffer", LogLevel.WARN)
                } else {
                    progLog("Wrote ${toWrite.length} character(s) into the hex editor")
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun refreshEepromHexInfo(source: String) {
        val n = eepromHexAdapter.currentData().size
        progBinding.tvEepromHexInfo.text = if (n == 0) getString(R.string.prog_hex_no_data) else "$n bytes - $source"
    }

    // ---- SPI flash ------------------------------------------------------------

    /** Size in bytes implied by the chip spinner, or the manual KB field when "Custom" is selected. */
    private fun currentSpiSizeBytes(): Long {
        selectedSpiChipSize?.let { return it }
        val kb = progBinding.etSpiSizeKb.text.toString().toIntOrNull() ?: 0
        return kb.toLong() * 1024
    }

    /*
     * Detect/Read/Erase/Write below all run the real flashrom binary (flashromspi/) rather than
     * this app's own hand-rolled SPI NOR command set (eeprom/SpiFlash.kt, still used by the isp/
     * package's alternative external-programmer path) - see flashromspi/README.md for why. That
     * means:
     *  - a separate connection ([flashromSpiController], not [programmerController] - see
     *    [onSpiConnectClicked]) since flashrom's bundled libusb wraps the USB fd itself instead of
     *    this app issuing transfers directly;
     *  - Read/Write/Random go through a temp file under [cacheDir], since flashrom's CLI reads
     *    and writes real files, not in-memory buffers - loaded into / saved from [spiHexAdapter]
     *    same as every other source (a real Read, Load File, ...) already was;
     *  - flashrom's own progress text streams into the log ([FlashromLineLogger]) instead of the
     *    numeric progress bar the old byte-by-byte [ProgrammerController] callbacks drove, since
     *    flashrom doesn't hand back a byte-count as it goes the way that code did - just an
     *    indeterminate "running" state (see [setProgProgress]) plus flashrom's own status lines.
     */

    private fun onSpiDetectClicked() {
        if (!flashromSpiController.isConnected) {
            progLog("Connect to the CH341A first", LogLevel.WARN)
            return
        }
        val logger = FlashromLineLogger()
        lifecycleScope.launch {
            setProgProgress(0)
            progLog("Probing SPI flash chip (flashrom)...")
            val output = StringBuilder()
            val exitCode = flashromSpiController.probe { chunk ->
                output.append(chunk)
                logger.onOutput(chunk)
            }
            logger.flush()
            setProgProgress(null)
            val match = FLASHROM_PROBE_REGEX.find(output)
            if (exitCode != 0 || match == null) {
                progBinding.tvSpiId.text = ""
                progLog("No chip detected - check wiring/chip", LogLevel.ERROR)
                return@launch
            }
            val chipName = match.groupValues[1]
            val sizeBytes = (match.groupValues[2].toLongOrNull() ?: 0L) * 1024
            progBinding.tvSpiId.text = "$chipName  (${formatSize(sizeBytes)})"
            progBinding.tvSpiInfoChipValue.text = chipName
            progBinding.tvSpiInfoCapacityValue.text = formatSize(sizeBytes)
            val index = SpiFlashDatabase.COMMON_CHIPS.indexOfFirst { it.name == chipName }
            if (index >= 0) {
                progBinding.spinnerSpiChip.setSelection(index)
            } else {
                // Not one of the exact-named parts - fall back to "Custom" and fill in the decoded size.
                progBinding.spinnerSpiChip.setSelection(spiChipLabels.size - 1)
                selectedSpiChipSize = null
                progBinding.etSpiSizeKb.setText((sizeBytes / 1024).toString())
            }
            progLog("Detected: $chipName")
        }
    }

    private fun onSpiRandomClicked() {
        if (!flashromSpiController.isConnected) {
            progLog("Connect to the CH341A first", LogLevel.WARN)
            return
        }
        val sizeBytes = currentSpiSizeBytes()
        if (sizeBytes <= 0) {
            progLog("Pick a chip or enter a valid size in KB", LogLevel.WARN)
            return
        }
        MaterialAlertDialogBuilder(this, R.style.ThemeOverlay_Prog_AlertDialog)
            .setTitle("Write random data?")
            .setMessage("Erases and overwrites ${formatSize(sizeBytes)} with random data. This cannot be undone. Continue?")
            .setPositiveButton("Write Random") { _, _ ->
                val randomData = ByteArray(sizeBytes.toInt())
                Random.nextBytes(randomData)
                val logger = FlashromLineLogger()
                lifecycleScope.launch {
                    val tempFile = newSpiTempFile("random")
                    if (!writeTempFile(tempFile, randomData)) {
                        progLog("Could not prepare the write image", LogLevel.ERROR)
                        return@launch
                    }
                    setProgProgress(0)
                    progLog("Writing random data to SPI flash (flashrom)...")
                    val exitCode = flashromSpiController.write(tempFile, logger::onOutput)
                    logger.flush()
                    tempFile.delete()
                    setProgProgress(null)
                    if (exitCode == 0) {
                        progLog("Random write complete")
                        spiHexAdapter.replaceData(randomData)
                        refreshSpiHexInfo("from chip")
                    } else {
                        progLog("Random write failed", LogLevel.ERROR)
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun onSpiReadClicked() {
        if (!flashromSpiController.isConnected) {
            progLog("Connect to the CH341A first", LogLevel.WARN)
            return
        }
        val logger = FlashromLineLogger()
        lifecycleScope.launch {
            val tempFile = newSpiTempFile("read")
            setProgProgress(0)
            progLog("Reading SPI flash (flashrom)...")
            val exitCode = flashromSpiController.read(tempFile, logger::onOutput)
            logger.flush()
            setProgProgress(null)
            val data = if (exitCode == 0 && tempFile.exists()) {
                try {
                    tempFile.readBytes()
                } catch (e: Exception) {
                    null
                }
            } else {
                null
            }
            tempFile.delete()
            if (data != null && data.isNotEmpty()) {
                spiHexAdapter.replaceData(data)
                refreshSpiHexInfo("from chip")
                progLog("Read ${data.size} bytes")
            } else {
                progLog("SPI flash read failed - check wiring and that a chip is present", LogLevel.ERROR)
            }
        }
    }

    private fun onSpiEraseClicked() {
        if (!flashromSpiController.isConnected) {
            progLog("Connect to the CH341A first", LogLevel.WARN)
            return
        }
        val sizeBytes = currentSpiSizeBytes()
        MaterialAlertDialogBuilder(this, R.style.ThemeOverlay_Prog_AlertDialog)
            .setTitle("Erase entire SPI flash chip?")
            .setMessage("This wipes the whole chip and cannot be undone. Continue?")
            .setPositiveButton("Erase") { _, _ ->
                val logger = FlashromLineLogger()
                lifecycleScope.launch {
                    setProgProgress(0)
                    progLog("Erasing SPI flash chip (flashrom) - this can take a while...")
                    val exitCode = flashromSpiController.erase(logger::onOutput)
                    logger.flush()
                    setProgProgress(null)
                    if (exitCode == 0) {
                        progLog("Chip erase complete")
                        if (sizeBytes > 0) {
                            spiHexAdapter.replaceData(ByteArray(sizeBytes.toInt()) { 0xFF.toByte() })
                            refreshSpiHexInfo("from chip")
                        }
                    } else {
                        progLog("Chip erase failed", LogLevel.ERROR)
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun onSpiWriteClicked() {
        if (!flashromSpiController.isConnected) {
            progLog("Connect to the CH341A first", LogLevel.WARN)
            return
        }
        val live = spiHexAdapter.currentData()
        if (live.isEmpty()) {
            progLog("Nothing to write - tap Read or Load File first", LogLevel.WARN)
            return
        }
        val data = live.copyOf() // snapshot - the adapter's live array stays editable during the write
        val logger = FlashromLineLogger()
        lifecycleScope.launch {
            val tempFile = newSpiTempFile("write")
            if (!writeTempFile(tempFile, data)) {
                progLog("Could not prepare the write image", LogLevel.ERROR)
                return@launch
            }
            setProgProgress(0)
            progLog("Erasing + writing ${data.size} bytes to SPI flash (flashrom)...")
            val exitCode = flashromSpiController.write(tempFile, logger::onOutput)
            logger.flush()
            tempFile.delete()
            setProgProgress(null)
            if (exitCode == 0) progLog("SPI flash write complete") else progLog("SPI flash write failed", LogLevel.ERROR)
        }
    }

    private fun newSpiTempFile(tag: String): File = File(cacheDir, "flashromspi_${tag}_${System.currentTimeMillis()}.bin")

    private fun writeTempFile(file: File, data: ByteArray): Boolean = try {
        file.writeBytes(data)
        true
    } catch (e: Exception) {
        false
    }

    private fun onSpiLoadFileClicked() {
        progLog("Choose a file to load into the hex editor...")
        spiOpenLauncher.launch(arrayOf("*/*"))
    }

    private fun onSpiFileLoaded(bytes: ByteArray) {
        spiHexAdapter.replaceData(bytes)
        refreshSpiHexInfo("from file")
        progLog("Loaded ${bytes.size} bytes into the hex editor")
    }

    private fun onSpiSaveFileClicked() {
        val data = spiHexAdapter.currentData()
        if (data.isEmpty()) {
            progLog("Nothing to save - tap Read or Load File first", LogLevel.WARN)
            return
        }
        spiSaveLauncher.launch(suggestedFileName("spi_flash_dump", data.size))
    }

    private fun onSpiByteTapped(offset: Int) {
        showByteEditDialog(spiHexAdapter, offset) { refreshSpiHexInfo("edited, not written yet") }
    }

    private fun onSpiAsciiTapped(offset: Int) {
        showAsciiEditDialog(spiHexAdapter, offset) { refreshSpiHexInfo("edited, not written yet") }
    }

    private fun onSpiWriteTextClicked() {
        showWriteTextDialog(spiHexAdapter) { refreshSpiHexInfo("text written, not written to chip yet") }
    }

    private fun refreshSpiHexInfo(source: String) {
        val n = spiHexAdapter.currentData().size
        progBinding.tvSpiHexInfo.text = if (n == 0) getString(R.string.prog_hex_no_data) else "$n bytes - $source"
    }

    // ---- SSD1306 OLED -----------------------------------------------------------

    private fun parseOledAddress(): Int =
        progBinding.etOledAddress.text.toString().trim()
            .removePrefix("0x").removePrefix("0X")
            .toIntOrNull(16) ?: 0x3C

    private fun onOledInitClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first", LogLevel.WARN)
            return
        }
        val (w, h) = selectedOledSize
        val addr = parseOledAddress()
        lifecycleScope.launch {
            val ok = programmerController.initDisplay(addr, w, h)
            if (ok) {
                progLog("SSD1306 initialized (${w}x$h @ 0x${addr.toString(16)})")
            } else {
                progLog("SSD1306 init failed - check address/wiring", LogLevel.ERROR)
            }
        }
    }

    private fun onOledTestClicked() {
        lifecycleScope.launch {
            val ok = programmerController.displayTestPattern()
            if (ok) progLog("Test pattern sent") else progLog("Init the display first", LogLevel.WARN)
        }
    }

    private fun onOledClearClicked() {
        lifecycleScope.launch {
            val ok = programmerController.displayClear()
            if (ok) progLog("Display cleared") else progLog("Init the display first", LogLevel.WARN)
        }
    }

    private fun onOledDrawTextClicked() {
        val text = progBinding.etOledText.text.toString()
        lifecycleScope.launch {
            val ok = if (programmerController.customFontTypeface != null) {
                programmerController.displayCustomText(text)
            } else {
                programmerController.displayText(text)
            }
            if (ok) progLog("Text drawn") else progLog("Init the display first", LogLevel.WARN)
        }
    }

    private fun onOledLoadImageClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first", LogLevel.WARN)
            return
        }
        progLog("Choose an image to display...")
        oledImageLauncher.launch(arrayOf("image/*"))
    }

    private fun onOledImageChosen(uri: Uri) {
        lifecycleScope.launch {
            val bitmap = try {
                withContext(Dispatchers.IO) {
                    contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                }
            } catch (e: Exception) {
                null
            }
            if (bitmap == null) {
                progLog("Failed to decode the selected image", LogLevel.ERROR)
                return@launch
            }
            val ok = programmerController.displayBitmap(bitmap)
            bitmap.recycle()
            if (ok) progLog("Image drawn (scaled + thresholded to 1-bit)") else progLog("Init the display first", LogLevel.WARN)
        }
    }

    // ---- Custom font (Draw Text / the Clock's date can use a loaded TTF/OTF) ----

    private fun updateFontStatus() {
        progBinding.tvFontStatus.text = programmerController.customFontName?.let { "Using: $it" }
            ?: getString(R.string.prog_font_none)
    }

    private fun onFontChosen(uri: Uri) {
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) { programmerController.loadCustomFont(this@MainActivity, uri) }
            updateFontStatus()
            if (ok) {
                progLog("Font loaded: ${programmerController.customFontName} - Draw Text and the Clock will use it")
            } else {
                progLog("That file doesn't look like a valid font", LogLevel.WARN)
            }
        }
    }

    // ---- Clock / Stats / Animate - continuous redraw loops -----------------------

    private fun resetContinuousButtons() {
        progBinding.btnClockToggle.text = getString(R.string.prog_clock_start)
        progBinding.btnStatsToggle.text = getString(R.string.prog_stats_start)
        progBinding.btnAnimToggle.text = getString(R.string.prog_anim_start)
    }

    private fun onClockToggleClicked() {
        if (activeContinuousMode == ContinuousMode.CLOCK) {
            programmerController.stopContinuous()
            activeContinuousMode = null
            progBinding.btnClockToggle.text = getString(R.string.prog_clock_start)
            progLog("Clock stopped")
            return
        }
        if (!programmerController.isConnected) {
            progLog("Connect in SSD1306 Display mode first", LogLevel.WARN)
            return
        }
        resetContinuousButtons()
        activeContinuousMode = ContinuousMode.CLOCK
        progBinding.btnClockToggle.text = getString(R.string.prog_clock_stop)
        progLog("Clock started")
        programmerController.startClock(intervalMs = 1000L) { error ->
            runOnUiThread {
                progBinding.btnClockToggle.text = getString(R.string.prog_clock_start)
                if (activeContinuousMode == ContinuousMode.CLOCK) activeContinuousMode = null
                if (error != null) progLog(error, LogLevel.ERROR)
            }
        }
    }

    private fun onStatsToggleClicked() {
        if (activeContinuousMode == ContinuousMode.STATS) {
            programmerController.stopContinuous()
            activeContinuousMode = null
            progBinding.btnStatsToggle.text = getString(R.string.prog_stats_start)
            progLog("Stats stopped")
            return
        }
        if (!programmerController.isConnected) {
            progLog("Connect in SSD1306 Display mode first", LogLevel.WARN)
            return
        }
        resetContinuousButtons()
        activeContinuousMode = ContinuousMode.STATS
        progBinding.btnStatsToggle.text = getString(R.string.prog_stats_stop)
        progLog("Stats started")
        programmerController.startStats(applicationContext, intervalMs = 1000L) { error ->
            runOnUiThread {
                progBinding.btnStatsToggle.text = getString(R.string.prog_stats_start)
                if (activeContinuousMode == ContinuousMode.STATS) activeContinuousMode = null
                if (error != null) progLog(error, LogLevel.ERROR)
            }
        }
    }

    private fun onAnimChooseClicked() {
        animFramesLauncher.launch(arrayOf("image/*"))
    }

    private fun onAnimFramesChosen(uris: List<Uri>) {
        animFrameUris = sortUrisByDisplayName(uris)
        progBinding.tvAnimStatus.text = "${uris.size} frame(s) selected"
        progLog("${uris.size} animation frame(s) selected")
    }

    private fun sortUrisByDisplayName(uris: List<Uri>): List<Uri> = uris.sortedBy { uri ->
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0) else uri.toString()
            } ?: uri.toString()
        } catch (e: Exception) {
            uri.toString()
        }
    }

    private fun onAnimToggleClicked() {
        if (activeContinuousMode == ContinuousMode.ANIMATION) {
            programmerController.stopContinuous()
            activeContinuousMode = null
            progBinding.btnAnimToggle.text = getString(R.string.prog_anim_start)
            progLog("Animation stopped")
            return
        }
        if (!programmerController.isConnected) {
            progLog("Connect in SSD1306 Display mode first", LogLevel.WARN)
            return
        }
        if (animFrameUris.isEmpty()) {
            progLog("Choose frames first", LogLevel.WARN)
            return
        }
        val delayMs = progBinding.etAnimDelay.text.toString().toLongOrNull()
        if (delayMs == null || delayMs <= 0) {
            progLog("Enter a valid frame delay in ms", LogLevel.WARN)
            return
        }
        resetContinuousButtons()
        activeContinuousMode = ContinuousMode.ANIMATION
        progBinding.btnAnimToggle.text = getString(R.string.prog_anim_stop)
        progLog("Loading ${animFrameUris.size} frame(s)...")
        lifecycleScope.launch {
            val frames = withContext(Dispatchers.IO) {
                animFrameUris.mapNotNull { uri ->
                    try {
                        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                    } catch (e: Exception) {
                        null
                    }
                }
            }
            if (frames.isEmpty() || activeContinuousMode != ContinuousMode.ANIMATION) {
                if (frames.isEmpty()) {
                    progLog("Couldn't decode any of the selected frames", LogLevel.ERROR)
                } else {
                    frames.forEach { it.recycle() } // superseded by another mode while decoding
                }
                if (activeContinuousMode == ContinuousMode.ANIMATION) {
                    activeContinuousMode = null
                    progBinding.btnAnimToggle.text = getString(R.string.prog_anim_start)
                }
                return@launch
            }
            progLog("Animating ${frames.size} frame(s) every ${delayMs}ms")
            programmerController.startAnimation(frames, delayMs) { error ->
                runOnUiThread {
                    progBinding.btnAnimToggle.text = getString(R.string.prog_anim_start)
                    if (activeContinuousMode == ContinuousMode.ANIMATION) activeContinuousMode = null
                    if (error != null) progLog(error, LogLevel.ERROR)
                    frames.forEach { it.recycle() }
                }
            }
        }
    }

    // ---- I2C-over-TCP -----------------------------------------------------------

    private fun onI2cTcpToggleClicked() {
        if (programmerController.isI2cTcpServerRunning) {
            programmerController.stopI2cTcpServer()
            progBinding.tvI2cTcpStatus.text = getString(R.string.prog_i2ctcp_not_running)
            progBinding.tvI2cTcpToggleLabel.text = getString(R.string.prog_i2ctcp_start)
            progLog("I2C-over-TCP server stopped")
            return
        }
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first", LogLevel.WARN)
            return
        }
        val port = progBinding.etI2cTcpPort.text.toString().toIntOrNull()
        if (port == null || port !in 1..65535) {
            progLog("Enter a valid port number (1-65535)", LogLevel.WARN)
            return
        }
        try {
            programmerController.startI2cTcpServer(
                port = port,
                onClientConnected = { addr -> runOnUiThread { progLog("I2C-over-TCP client connected: $addr") } },
                onClientDisconnected = { addr -> runOnUiThread { progLog("I2C-over-TCP client disconnected: $addr") } },
                onError = { e -> runOnUiThread { progLog("I2C-over-TCP error: ${e.message}", LogLevel.ERROR) } }
            )
            progBinding.tvI2cTcpStatus.text = "Listening on ${OledCompositor.wifiOrCellularIpAddress(this)}:$port"
            progBinding.tvI2cTcpToggleLabel.text = getString(R.string.prog_i2ctcp_stop)
            progLog("I2C-over-TCP server started on port $port")
        } catch (e: Exception) {
            progLog("Failed to start I2C-over-TCP server: ${e.message}", LogLevel.ERROR)
        }
    }

    // ---- file I/O (Storage Access Framework) -----------------------------------

    private fun suggestedFileName(prefix: String, sizeBytes: Int): String {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        return "${prefix}_${sizeBytes}B_$stamp.bin"
    }

    private fun writeBytesToUri(uri: Uri, data: ByteArray, label: String) {
        lifecycleScope.launch {
            val ok = try {
                withContext(Dispatchers.IO) {
                    contentResolver.openOutputStream(uri)?.use { it.write(data) }
                    true
                }
            } catch (e: Exception) {
                false
            }
            if (ok) progLog("$label saved (${data.size} bytes)") else progLog("Failed to save $label", LogLevel.ERROR)
        }
    }

    private fun readBytesFromUri(uri: Uri, onLoaded: (ByteArray) -> Unit) {
        lifecycleScope.launch {
            val bytes = try {
                withContext(Dispatchers.IO) { contentResolver.openInputStream(uri)?.use { it.readBytes() } }
            } catch (e: Exception) {
                null
            }
            if (bytes != null) onLoaded(bytes) else progLog("Failed to read the selected file", LogLevel.ERROR)
        }
    }

    private fun formatSize(bytes: Long): String = when {
        bytes <= 0 -> "unknown size"
        bytes >= 1024 * 1024 -> "%.0f MB".format(bytes / (1024.0 * 1024.0))
        else -> "%.0f KB".format(bytes / 1024.0)
    }

    // ---- hex editor byte-edit dialogs -------------------------------------------

    /** Shows a tiny "enter a new hex byte" dialog for [offset], committing via [adapter] on Save. */
    private fun showByteEditDialog(adapter: HexEditorAdapter, offset: Int, onCommitted: () -> Unit) {
        val current = adapter.byteAt(offset) ?: return
        val input = EditText(this).apply {
            setText(String.format("%02X", current.toInt() and 0xFF))
            filters = arrayOf(InputFilter.LengthFilter(2))
            inputType = InputType.TYPE_CLASS_TEXT
            setSelectAllOnFocus(true)
            val pad = (20 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad / 2, pad, 0)
        }
        MaterialAlertDialogBuilder(this, R.style.ThemeOverlay_Prog_AlertDialog)
            .setTitle("Edit byte at offset 0x%X".format(offset))
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val value = input.text.toString().trim().toIntOrNull(16)
                if (value == null || value !in 0..255) {
                    progLog("Enter a valid 2-digit hex value (00-FF)", LogLevel.WARN)
                } else {
                    adapter.setByte(offset, value.toByte())
                    onCommitted()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    /** Shows a tiny "enter a new character" dialog for [offset] - the ASCII-column counterpart
     *  of [showByteEditDialog], setting the byte to that character's code instead of a hex value. */
    private fun showAsciiEditDialog(adapter: HexEditorAdapter, offset: Int, onCommitted: () -> Unit) {
        val current = adapter.byteAt(offset) ?: return
        val currentChar = (current.toInt() and 0xFF).let { if (it in 0x20..0x7E) it.toChar().toString() else "" }
        val input = EditText(this).apply {
            setText(currentChar)
            filters = arrayOf(InputFilter.LengthFilter(1))
            inputType = InputType.TYPE_CLASS_TEXT
            setSelectAllOnFocus(true)
            val pad = (20 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad / 2, pad, 0)
        }
        MaterialAlertDialogBuilder(this, R.style.ThemeOverlay_Prog_AlertDialog)
            .setTitle("Edit character at offset 0x%X".format(offset))
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val text = input.text.toString()
                if (text.isEmpty()) {
                    progLog("Enter a single character", LogLevel.WARN)
                } else {
                    adapter.setByte(offset, (text[0].code and 0xFF).toByte())
                    onCommitted()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---- shared progress/log helpers -------------------------------------------

    private fun setProgProgress(percent: Int?) {
        val bar = progBinding.progressProgrammer
        if (percent == null) {
            bar.visibility = View.INVISIBLE
        } else {
            bar.visibility = View.VISIBLE
            bar.progress = percent.coerceIn(0, 100)
        }
    }

    private enum class LogLevel(val tag: String) { INFO("INFO"), WARN("WARN"), ERROR("ERROR") }

    /** Appends one colored log line - `[HH:mm:ss] LEVEL message` - matching the reference design's
     *  INFO (accent blue) / WARN (amber) / ERROR (red) log style. [level] defaults to INFO so
     *  every already-written call site keeps compiling/behaving as a plain status line; only the
     *  call sites that are genuinely a warning or a failure pass [LogLevel.WARN]/[LogLevel.ERROR]
     *  explicitly. */
    private fun progLog(message: String, level: LogLevel = LogLevel.INFO) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        val color = when (level) {
            LogLevel.INFO -> getColor(R.color.bridge_accent)
            LogLevel.WARN -> getColor(R.color.status_warn)
            LogLevel.ERROR -> getColor(R.color.status_error)
        }
        val prefix = "[$time] "
        val tag = "${level.tag} "
        val line = SpannableString(prefix + tag + message + "\n")
        line.setSpan(ForegroundColorSpan(getColor(R.color.log_timestamp)), 0, prefix.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        val tagStart = prefix.length
        val tagEnd = tagStart + tag.length
        line.setSpan(ForegroundColorSpan(color), tagStart, tagEnd, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        line.setSpan(StyleSpan(Typeface.BOLD), tagStart, tagEnd, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        progBinding.tvProgLog.append(line)
        progBinding.scrollProgLog.post { progBinding.scrollProgLog.fullScroll(View.FOCUS_DOWN) }
    }

    /** Wraps flashromspi's raw, arbitrarily-chunked stdout+stderr (see
     *  [com.tcpuartbridge.app.flashromspi.FlashromProcess]) into complete lines logged via
     *  [progLog] as they arrive - flashrom prints its own real progress/status text rather than a
     *  byte count, so this is what stands in for the numeric progress bar the old SPI 25xx
     *  driver's callbacks drove. One instance per run (Detect/Read/Write/Erase each make their
     *  own); call [flush] once the run's finished to emit any trailing partial line. */
    private inner class FlashromLineLogger {
        private val buffer = StringBuilder()

        fun onOutput(chunk: String) {
            buffer.append(chunk)
            var idx = buffer.indexOf("\n")
            while (idx >= 0) {
                emitLine(buffer.substring(0, idx))
                buffer.delete(0, idx + 1)
                idx = buffer.indexOf("\n")
            }
        }

        fun flush() {
            if (buffer.isNotEmpty()) {
                emitLine(buffer.toString())
                buffer.clear()
            }
        }

        private fun emitLine(raw: String) {
            val line = raw.trimEnd('\r')
            if (line.isNotEmpty()) runOnUiThread { progLog(line) }
        }
    }

    companion object {
        /** Rows' worth of 0xFF ("erased flash") shown in each hex viewer before any real Read -
         *  just enough to look populated (matching the reference design) without pretending a
         *  multi-megabyte chip has actually been read; Read/Erase/Load File/Write Random all
         *  replace this via [HexEditorAdapter.replaceData] same as always. */
        private const val PLACEHOLDER_HEX_BYTES = 256

        private fun defaultHexPlaceholder(): ByteArray = ByteArray(PLACEHOLDER_HEX_BYTES) { 0xFF.toByte() }

        /** Matches flashrom's standard successful-probe line, e.g.:
         *  `Found Winbond flash chip "W25Q64.V" (8192 kB, SPI) on ch341a_spi.`
         *  Group 1 = chip name, group 2 = size in KB. This has been flashrom's stable output
         *  format for its `-p <programmer>`-with-no-other-arguments probe-only invocation for
         *  many years; if a future flashrom version phrases it differently, [onSpiDetectClicked]
         *  falls back to just logging the raw output so nothing silently goes blank. */
        private val FLASHROM_PROBE_REGEX = Regex("""Found\s+\S+\s+flash chip\s+"([^"]+)"\s+\((\d+)\s*kB""")
    }
}
