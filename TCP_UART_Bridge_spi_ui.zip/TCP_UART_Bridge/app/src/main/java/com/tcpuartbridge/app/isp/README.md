# `isp` — In-System Programming (external serprog programmer)

Adds a second way to get bytes into/out of a SPI NOR flash chip, alongside the app's existing
direct CH341A path (`ch341/` + `eeprom/SpiFlash.kt`): talking to an **external serprog-speaking
programmer** — typically a small microcontroller board (an Arduino, an FTDI-based adapter, etc.)
wired to the flash chip's SPI pins over UART — using flashrom's own **serprog** wire protocol.

## Why this exists

The CH341A clip is the easy path when you can get it directly onto the chip. It's not always the
right tool, though:

- The chip might be soldered into a board where a CH341A clip doesn't reach cleanly, but a
  breadboard/jumper-wire connection to a separate microcontroller does.
- The 5V/3.3V mismatch, timing sensitivity, or general "gets a marginal connection working
  reliably at a lower clock" tinkering that in-circuit programming often needs (see
  `InSystemProgrammingNotes.kt`) is easier with a general-purpose microcontroller you can
  customize than with the CH341A's fixed protocol/voltage.
- Someone already has a serprog-compatible programmer (the reference hardware in flashrom's own
  `arduino_flasher` documentation, for instance) and would rather reuse it than buy a CH341A board.

## What's here

| File | What it does |
|---|---|
| `InSystemProgrammingNotes.kt` | Knowledge, not code — a field checklist for programming a chip in-circuit, paraphrased from flashrom's own bundled user docs (see that file's doc comment for exact sources). |
| `SerprogTransport.kt` | The byte-level transport interface, plus `UsbSerialTransport` — a real implementation over `usb-serial-for-android` (already a project dependency, previously unused). |
| `SerprogClient.kt` | flashrom's serprog wire protocol itself — sync handshake, capability queries, and the one SPI transaction primitive (`O_SPIOP`) everything else is built on. |
| `IspFlash.kt` | The same SPI NOR command set as `eeprom/SpiFlash.kt` (JEDEC ID, read, write, erase, status register), built on `SerprogClient` instead of `Ch341Spi`. |
| `WriteProtection.kt` | A status-register decoder — flashrom's `--wp-status`/`--wp-enable`/`--wp-disable` equivalent. |
| `IspController.kt` | Ties the above together with the same one-suspend-function-per-action shape `programmer/ProgrammerController.kt` uses, ready to be wired into a UI screen. |

## Provenance

- **Knowledge** (`InSystemProgrammingNotes.kt`, this file's own background): paraphrased from
  flashrom's bundled HTML documentation (`in_system.html`, `misc_notes.html`,
  `management_engine.html`, `arduino_flasher.html`) — part of the Diamon "Flash EEPROM Tool"
  project this was extracted from. Docs only; no flashrom code was available in that project to
  port from (only its prebuilt binaries/libraries), so nothing here is a GPL port.
- **Protocol** (`SerprogClient.kt`): an original implementation of flashrom's own published
  serprog protocol specification (also bundled as documentation in that same project),
  cross-checked command-by-command against a real, working reference implementation — that
  project's bundled `serprog_arduino_uno_ch340g.ino` (GPLv3) — for chunk-size and timing
  assumptions, without copying its code.
- **SPI NOR command set** (`IspFlash.kt`, `WriteProtection.kt`): the same industry-standard,
  de-facto-universal SPI NOR instruction set and status-register convention `eeprom/SpiFlash.kt`
  already documents itself as using — not specific to either GPL source in this app's `NOTICE.md`.

## Status

Backend only — nothing here is called from `MainActivity` or any layout yet, the same posture the
app's own "Verify"/"Dump" buttons and "SPI-over-TCP" toggle already have (see the repo root
`README.md`'s "Not yet implemented" section). Like the rest of this delivery, it's logically
reviewed and cross-checked against a known-working reference implementation, but not exercised
against real hardware — confirm `usb-serial-for-android`'s exact API surface for whatever version
Gradle resolves, and test the serprog handshake against a real serial programmer, before relying
on it.

If you pick this up to wire into the UI, `IspController` is the intended entry point — it mirrors
`ProgrammerController`'s connect/action shape closely enough that the existing screens' button-
handler pattern in `MainActivity.kt` should transfer directly.
