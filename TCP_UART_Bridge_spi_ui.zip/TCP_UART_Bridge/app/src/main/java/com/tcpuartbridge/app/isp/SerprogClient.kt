package com.tcpuartbridge.app.isp

/**
 * Host-side client for flashrom's **serprog** wire protocol ("Serial Flasher Protocol") - the
 * protocol flashrom itself speaks to small serial-attached SPI programmers, most commonly an
 * Arduino (or similar microcontroller board) running a serprog sketch, such as the one bundled
 * with the Diamon "Flash EEPROM Tool" project this package's knowledge/protocol details were
 * extracted from (`serprog_arduino_uno_ch340g.ino`, GPLv3) - see this package's `README` note.
 *
 * Nothing here is ported from flashrom's own `serprog.c`: this project only ever had flashrom's
 * prebuilt binaries and documentation available (no source), not the driver code. This is a
 * fresh implementation of the wire protocol, written from flashrom's own **published protocol
 * specification** (bundled as documentation in that same "Flash EEPROM Tool" project, under
 * `usr/share/doc/flashrom/html/supported_hw/supported_prog/serprog/serprog-protocol.html` -
 * command numbers, ACK/NAK framing, and the mandatory/recommended-command notes below all come
 * from that document) and cross-checked command-by-command against that bundled Arduino sketch's
 * actual (GPLv3) command handling to make sure the exact chunk-size/timeout assumptions line up
 * with a real, working reference implementation.
 *
 * Only the commands a *pure-SPI* serprog device needs are implemented: NOP, Q_IFACE, Q_PGMNAME,
 * Q_BUSTYPE, Q_WRNMAXLEN, Q_RDNMAXLEN, SYNCNOP, S_BUSTYPE, and O_SPIOP. The protocol's
 * operation-buffer commands (O_INIT/O_WRITEB/O_WRITEN/O_DELAY/O_EXEC, plus Q_CMDMAP/Q_SERBUF)
 * exist mainly for parallel/LPC/FWH programmers or flow-control bookkeeping this client doesn't
 * need: O_SPIOP alone - one immediate "send these bytes, then clock in this many more" SPI
 * transaction - is sufficient to build every operation a SPI NOR flash chip needs (JEDEC ID,
 * READ, WREN, page program, sector/chip erase, status register read/write), the same way
 * [com.tcpuartbridge.app.eeprom.SpiFlash] builds them on top of the CH341A's own single-
 * transaction [com.tcpuartbridge.app.ch341.Ch341Spi.transfer] - see [IspFlash], which does that
 * here.
 */
class SerprogClient(private val transport: SerprogTransport) {

    /** The device's self-reported name (Q_PGMNAME) - e.g. "arduino" for the reference sketch. */
    var programmerName: String = ""
        private set

    /** Max bytes this device accepts as the write phase of one O_SPIOP call (from Q_WRNMAXLEN). */
    var maxWriteLen: Int = DEFAULT_CHUNK
        private set

    /** Max bytes this device will hand back from one O_SPIOP call (from Q_RDNMAXLEN). */
    var maxReadLen: Int = DEFAULT_CHUNK
        private set

    /**
     * Synchronizes with the device, then queries interface version, name, SPI bus support, and
     * the max write/read chunk sizes. Returns false if the device never syncs, doesn't speak
     * protocol version 1, or doesn't support SPI.
     */
    fun open(): Boolean {
        // The reference Arduino sketch sends an extra "ready" beacon of its own once its startup
        // delay finishes, before it starts answering serprog commands at all - not part of the
        // serprog spec itself, just that particular firmware's own convention. Draining whatever
        // is sitting in the input buffer before the sync handshake harmlessly discards it (and
        // anything else stale left over from a previous session) without needing to know about it.
        drain(DRAIN_MS)

        if (!sync()) return false

        val iface = sendCommand(CMD_Q_IFACE, ByteArray(0), 2) ?: return false
        val ifaceVersion = (iface[0].toInt() and 0xFF) or ((iface[1].toInt() and 0xFF) shl 8)
        if (ifaceVersion != 1) return false

        sendCommand(CMD_Q_PGMNAME, ByteArray(0), 16)?.let { name ->
            programmerName = String(name, Charsets.US_ASCII).substringBefore('\u0000').trim()
        }

        val bustypes = sendCommand(CMD_Q_BUSTYPE, ByteArray(0), 1) ?: return false
        if (bustypes[0].toInt() and BUS_SPI == 0) return false // this client only ever asks for SPI

        // Tell the programmer to use SPI exclusively, in case it supports more than one bus type.
        if (!sendCommandOk(CMD_S_BUSTYPE, byteArrayOf(BUS_SPI.toByte()))) return false

        // Both of these are only "recommended", not mandatory, per the spec - a device that
        // doesn't answer just keeps the conservative DEFAULT_CHUNK default rather than the
        // spec's own fallback-to-unlimited-if-unsupported reading, which is fine for programmers
        // with big buffers but risky for exactly the small microcontroller-class programmers this
        // client is mainly meant for (see the reference sketch's own comments about UART overrun
        // at anything much bigger than the chunk sizes it advertises).
        sendCommand(CMD_Q_WRNMAXLEN, ByteArray(0), 3)?.let { r ->
            val len = le24(r)
            maxWriteLen = if (len == 0) DEFAULT_CHUNK else minOf(len, DEFAULT_CHUNK)
        }
        sendCommand(CMD_Q_RDNMAXLEN, ByteArray(0), 3)?.let { r ->
            val len = le24(r)
            maxReadLen = if (len == 0) DEFAULT_CHUNK else minOf(len, DEFAULT_CHUNK)
        }
        return true
    }

    fun close() = transport.close()

    /**
     * One SPI transaction - matches [com.tcpuartbridge.app.ch341.Ch341Spi.transfer]'s shape
     * (send [writeData], then clock in [readCount] more bytes, all inside one CS-low..CS-high
     * cycle) so the same style of calling code - JEDEC ID, READ, WREN, page program, etc., see
     * [IspFlash] - reads the same regardless of which transport is underneath. Returns null
     * (rather than silently chunking) if either size exceeds what the device told us it can
     * handle in one call - callers that need more than that must issue several transfers, each
     * with its own opcode/address, the same way [IspFlash.read]/[IspFlash.write] already do.
     */
    fun transfer(writeData: ByteArray, readCount: Int): ByteArray? {
        if (writeData.size > maxWriteLen || readCount > maxReadLen) return null
        return spiOp(writeData, readCount)
    }

    /** Command 0x13 (O_SPIOP): 24-bit slen + 24-bit rlen + slen bytes -> ACK + rlen bytes. */
    private fun spiOp(writeData: ByteArray, readCount: Int): ByteArray? {
        val slen = writeData.size
        val header = byteArrayOf(
            CMD_O_SPIOP.toByte(),
            (slen and 0xFF).toByte(), ((slen shr 8) and 0xFF).toByte(), ((slen shr 16) and 0xFF).toByte(),
            (readCount and 0xFF).toByte(), ((readCount shr 8) and 0xFF).toByte(), ((readCount shr 16) and 0xFF).toByte()
        )
        if (!transport.write(header)) return null
        if (slen > 0 && !transport.write(writeData)) return null

        val ack = readExactly(1, IO_TIMEOUT_MS) ?: return null
        if (ack[0] != ACK) return null
        if (readCount == 0) return ByteArray(0)
        return readExactly(readCount, IO_TIMEOUT_MS)
    }

    /** One simple "opcode (+params) -> ACK (+returnLen bytes)" query/set command. */
    private fun sendCommand(cmd: Int, params: ByteArray, returnLen: Int): ByteArray? {
        if (!transport.write(byteArrayOf(cmd.toByte()) + params)) return null
        val ack = readExactly(1, IO_TIMEOUT_MS) ?: return null
        if (ack[0] != ACK) return null
        if (returnLen == 0) return ByteArray(0)
        return readExactly(returnLen, IO_TIMEOUT_MS)
    }

    private fun sendCommandOk(cmd: Int, params: ByteArray): Boolean = sendCommand(cmd, params, 0) != null

    /**
     * Command 0x10 (SYNCNOP) always answers NAK immediately followed by ACK - the one command
     * with a fixed, state-independent reply, which is exactly what makes it useful for
     * (re)synchronizing with a device that might have stale bytes queued or be mid-command from a
     * previous session. Tries a handful of times, as flashrom's own serprog client does.
     */
    private fun sync(): Boolean {
        repeat(SYNC_ATTEMPTS) {
            if (!transport.write(byteArrayOf(CMD_SYNCNOP.toByte()))) return false
            val first = readExactly(1, SYNC_TIMEOUT_MS)
            if (first != null && first[0] == NAK) {
                val second = readExactly(1, SYNC_TIMEOUT_MS)
                if (second != null && second[0] == ACK) return true
            }
        }
        return false
    }

    private fun drain(timeoutMs: Int) {
        val buf = ByteArray(64)
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            val n = transport.read(buf, 20)
            if (n <= 0) break
        }
    }

    /** Loops over [SerprogTransport.read] until exactly [length] bytes have arrived or the deadline passes. */
    private fun readExactly(length: Int, timeoutMs: Int): ByteArray? {
        if (length == 0) return ByteArray(0)
        val out = ByteArray(length)
        var got = 0
        val deadline = System.currentTimeMillis() + timeoutMs
        while (got < length) {
            val remaining = (deadline - System.currentTimeMillis()).toInt()
            if (remaining <= 0) return null
            val buf = ByteArray(length - got)
            val n = transport.read(buf, remaining)
            if (n < 0) return null
            if (n > 0) {
                System.arraycopy(buf, 0, out, got, n)
                got += n
            }
        }
        return out
    }

    private fun le24(b: ByteArray): Int =
        (b[0].toInt() and 0xFF) or ((b[1].toInt() and 0xFF) shl 8) or ((b[2].toInt() and 0xFF) shl 16)

    companion object {
        private const val ACK: Byte = 0x06
        private const val NAK: Byte = 0x15

        private const val CMD_Q_IFACE = 0x01
        private const val CMD_Q_PGMNAME = 0x03
        private const val CMD_Q_BUSTYPE = 0x05
        private const val CMD_Q_WRNMAXLEN = 0x08
        private const val CMD_SYNCNOP = 0x10
        private const val CMD_Q_RDNMAXLEN = 0x11
        private const val CMD_S_BUSTYPE = 0x12
        private const val CMD_O_SPIOP = 0x13

        /** Q_BUSTYPE/S_BUSTYPE bit layout: bit0 PARALLEL, bit1 LPC, bit2 FWH, bit3 SPI. */
        private const val BUS_SPI = 0x08

        private const val IO_TIMEOUT_MS = 3000
        private const val SYNC_TIMEOUT_MS = 200
        private const val SYNC_ATTEMPTS = 8
        private const val DRAIN_MS = 300

        /**
         * Fallback/ceiling chunk size: used if a device doesn't answer Q_WRNMAXLEN/Q_RDNMAXLEN at
         * all, and as a cap on whatever a device *does* report, so one O_SPIOP call never gets
         * bigger than this regardless of what the device claims to support. 128 comfortably covers
         * a SPI NOR opcode+4-byte-address+small-payload, while staying well under the kind of size
         * that overran the reference Arduino sketch's UART buffer at its default 64-byte read /
         * 32-byte write limits - see [IspFlash]'s doc comment for how chunking above this is
         * handled by re-issuing a fresh command per chunk rather than asking for it here.
         */
        const val DEFAULT_CHUNK = 128
    }
}
