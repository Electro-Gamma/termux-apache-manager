package com.tcpuartbridge.app.isp

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import com.hoho.android.usbserial.driver.UsbSerialDriver
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.driver.UsbSerialProber
import java.io.IOException

/**
 * Byte-level transport a [SerprogClient] talks over. Deliberately just two blocking primitives
 * (write-all, read-some-with-timeout) so the serprog protocol logic in [SerprogClient] doesn't
 * need to know whether it's really talking to a serial port, and could be pointed at a fake
 * transport for testing without any USB hardware involved.
 */
interface SerprogTransport {

    /** Writes every byte of [data]. Returns false if the transport can't guarantee it all went out. */
    fun write(data: ByteArray): Boolean

    /**
     * One non-looping read attempt: copies up to `buf.size` bytes into [buf] and returns how many
     * arrived (0 if none showed up within [timeoutMs] - that's a normal "nothing yet", not an
     * error). Returns -1 on a real I/O failure (port closed, device unplugged, etc.).
     */
    fun read(buf: ByteArray, timeoutMs: Int): Int

    fun close()
}

/**
 * [SerprogTransport] over a real serial port, via the `usb-serial-for-android` library this
 * project already depends on (see `app/build.gradle` - CH340/CP210x/FTDI/PL2303/CDC-ACM support)
 * but, before this package, had no code actually exercising it - [SerprogClient]'s doc comment
 * and this package's `README` note explain why that library was sitting unused.
 *
 * This talks to a *serprog-speaking external programmer* - most commonly a small microcontroller
 * board (an Arduino, an FTDI-based adapter with the right firmware, etc.) wired to a flash chip's
 * SPI pins and running firmware that answers flashrom's serprog protocol - which is a completely
 * different device from the CH341A "programmer mode" USB personality
 * [com.tcpuartbridge.app.ch341.Ch341UsbDevice] talks to for the app's existing SPI Flash panel.
 * The two are independent connection paths to the same *kind* of end goal (get bytes into/out of
 * a SPI NOR flash chip) - see this package's `README` note for when you'd reach for one over the
 * other.
 *
 * IMPORTANT: This class is logically reviewed against `usb-serial-for-android`'s long-stable
 * public API and against the serprog reference firmware this package's protocol client was
 * cross-checked with, but - like the rest of this delivery, see the repo root `README.md` - has
 * not been exercised against a real device. Confirm the exact `UsbSerialPort` method signatures
 * against whatever `usb-serial-for-android` version Gradle actually resolves before relying on it.
 */
class UsbSerialTransport(private val context: Context) : SerprogTransport {

    private val usbManager: UsbManager = context.getSystemService(Context.USB_SERVICE) as UsbManager

    private var port: UsbSerialPort? = null

    /** The first attached device `usb-serial-for-android`'s default prober recognizes as a serial adapter. */
    fun findDriver(): UsbSerialDriver? =
        UsbSerialProber.getDefaultProber().findAllDrivers(usbManager).firstOrNull()

    fun device(driver: UsbSerialDriver): UsbDevice = driver.device

    fun hasPermission(driver: UsbSerialDriver): Boolean = usbManager.hasPermission(driver.device)

    /**
     * Same broadcast-receiver permission dance as
     * [com.tcpuartbridge.app.ch341.Ch341UsbDevice.requestPermission], against its own distinct
     * action string so the CH341A path's permission requests and this one can never be confused
     * for each other if both happen to be in flight at once.
     */
    fun requestPermission(driver: UsbSerialDriver, callback: (Boolean) -> Unit) {
        val action = "com.tcpuartbridge.app.isp.SERPROG_USB_PERMISSION"
        val mutabilityFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0
        val permissionIntent = PendingIntent.getBroadcast(
            context, 0, Intent(action).setPackage(context.packageName), mutabilityFlag
        )
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context, intent: Intent) {
                if (intent.action == action) {
                    context.unregisterReceiver(this)
                    callback(intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false))
                }
            }
        }
        val filter = IntentFilter(action)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            context.registerReceiver(receiver, filter)
        }
        usbManager.requestPermission(driver.device, permissionIntent)
    }

    /**
     * Opens [driver]'s first port at [baudRate] - 115200 by default, matching both the reference
     * serprog Arduino sketch this package was cross-checked against and flashrom's own
     * `arduino_flasher` documentation for 8u2/16u2-based Unos (`Serial.begin(115200)` on the
     * device side; an FTDI-based external programmer can usually go much faster - see that
     * documentation if wiring one of those up instead).
     */
    fun open(driver: UsbSerialDriver, baudRate: Int = DEFAULT_BAUD_RATE): Boolean {
        return try {
            val connection = usbManager.openDevice(driver.device) ?: return false
            val p = driver.ports.firstOrNull() ?: run { connection.close(); return false }
            p.open(connection)
            p.setParameters(baudRate, UsbSerialPort.DATABITS_8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)
            port = p
            true
        } catch (e: IOException) {
            false
        }
    }

    override fun write(data: ByteArray): Boolean {
        val p = port ?: return false
        return try {
            p.write(data, WRITE_TIMEOUT_MS)
            true
        } catch (e: IOException) {
            false
        }
    }

    override fun read(buf: ByteArray, timeoutMs: Int): Int {
        val p = port ?: return -1
        return try {
            p.read(buf, timeoutMs)
        } catch (e: IOException) {
            -1
        }
    }

    override fun close() {
        try {
            port?.close()
        } catch (_: Exception) {
        }
        port = null
    }

    companion object {
        const val DEFAULT_BAUD_RATE = 115200
        private const val WRITE_TIMEOUT_MS = 2000
    }
}
