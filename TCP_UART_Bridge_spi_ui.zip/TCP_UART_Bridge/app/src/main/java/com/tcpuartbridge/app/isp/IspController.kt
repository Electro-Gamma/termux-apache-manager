package com.tcpuartbridge.app.isp

import android.content.Context
import com.hoho.android.usbserial.driver.UsbSerialDriver
import com.tcpuartbridge.app.eeprom.SpiFlashDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Owns an external serprog-speaking programmer's connection ([UsbSerialTransport] +
 * [SerprogClient] + [IspFlash]) and exposes the same shape of one-suspend-function-per-action API
 * as [com.tcpuartbridge.app.programmer.ProgrammerController] does for the CH341A path, so wiring
 * this into a future UI screen - an "External Programmer (ISP)" panel, alongside the existing
 * four described in the repo root `README.md` - is a drop-in job rather than a redesign.
 *
 * Nothing in this file is called from anywhere yet: per this package's own `README` note, this is
 * a backend addition only, deliberately not wired into `MainActivity`/the layouts - the same
 * posture the existing "Verify"/"Dump" buttons and the "SPI-over-TCP" toggle already have (see
 * the root `README.md`'s "Not yet implemented" section) for features whose UI exists (or, here,
 * doesn't need to yet) before their backend does.
 */
class IspController(context: Context) {

    private val transport = UsbSerialTransport(context)
    private var client: SerprogClient? = null
    private var flash: IspFlash? = null

    val isConnected: Boolean get() = client != null

    /** The device's self-reported programmer name (Q_PGMNAME) once connected, e.g. "arduino". */
    val programmerName: String get() = client?.programmerName ?: ""

    fun findDriver(): UsbSerialDriver? = transport.findDriver()
    fun hasPermission(driver: UsbSerialDriver): Boolean = transport.hasPermission(driver)
    fun requestPermission(driver: UsbSerialDriver, callback: (Boolean) -> Unit) =
        transport.requestPermission(driver, callback)

    /** Opens the serial port and runs the serprog handshake (sync, Q_IFACE, Q_BUSTYPE, chunk-size queries). */
    suspend fun connect(driver: UsbSerialDriver, baudRate: Int = UsbSerialTransport.DEFAULT_BAUD_RATE): Boolean =
        withContext(Dispatchers.IO) {
            if (!transport.open(driver, baudRate)) return@withContext false
            val c = SerprogClient(transport)
            if (!c.open()) {
                transport.close()
                return@withContext false
            }
            client = c
            flash = IspFlash(c)
            true
        }

    suspend fun disconnect() = withContext(Dispatchers.IO) {
        client?.close()
        client = null
        flash = null
    }

    // ---- SPI NOR flash (25xx), via the external serprog programmer ------------------------

    suspend fun readJedecId(): IspFlash.JedecId? = withContext(Dispatchers.IO) {
        flash?.readJedecId()
    }

    /** Reads the JEDEC ID and looks it up in [SpiFlashDatabase] - see [IspFlash.detectChip]. */
    suspend fun detectChip(): SpiFlashDatabase.ChipPreset? = withContext(Dispatchers.IO) {
        flash?.detectChip()
    }

    /** Call once after picking/detecting a chip, before read/write/erase - see [IspFlash.configureAddressing]. */
    suspend fun configureAddressing(sizeBytes: Long): Boolean = withContext(Dispatchers.IO) {
        flash?.configureAddressing(sizeBytes) ?: false
    }

    /** flashrom's `--wp-status` equivalent - see [WriteProtection]. */
    suspend fun writeProtectionStatus(): WriteProtection.Status? = withContext(Dispatchers.IO) {
        flash?.writeProtectionStatus()
    }

    /** flashrom's `--wp-enable` / `--wp-disable` equivalent - see [IspFlash.setStatusRegisterProtect]. */
    suspend fun setStatusRegisterProtect(enabled: Boolean): Boolean = withContext(Dispatchers.IO) {
        flash?.setStatusRegisterProtect(enabled) ?: false
    }

    suspend fun read(length: Int, onProgress: (done: Int, total: Int) -> Unit): ByteArray? =
        withContext(Dispatchers.IO) {
            flash?.read(0, length, onProgress = onProgress)
        }

    suspend fun write(
        data: ByteArray,
        eraseFirst: Boolean = true,
        onProgress: (done: Int, total: Int) -> Unit
    ): Boolean = withContext(Dispatchers.IO) {
        flash?.write(0, data, eraseFirst = eraseFirst, onProgress = onProgress) ?: false
    }

    suspend fun eraseChip(): Boolean = withContext(Dispatchers.IO) {
        flash?.eraseChip() ?: false
    }
}
