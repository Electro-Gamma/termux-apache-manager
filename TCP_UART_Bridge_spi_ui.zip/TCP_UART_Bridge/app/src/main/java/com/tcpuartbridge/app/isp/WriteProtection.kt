package com.tcpuartbridge.app.isp

/**
 * SPI NOR status-register write-protection helpers - roughly what flashrom's `--wp-status` /
 * `--wp-enable` / `--wp-disable` give you on the command line (see flashrom's classic CLI manual,
 * bundled with the Diamon "Flash EEPROM Tool" project this package's knowledge was extracted
 * from), built from the generic single-status-register scheme almost every 25xx-family chip
 * implements - the same generic posture [com.tcpuartbridge.app.eeprom.SpiFlash]'s own
 * `unprotect()` already takes (see its doc comment and `NOTICE.md`). No source or binary data was
 * copied for this file - just the general SPI NOR status-register convention, which is public,
 * industry-standard knowledge, not specific to any one vendor or tool.
 *
 * Status Register 1, bit layout used near-universally across Winbond W25Q / GigaDevice GD25Q /
 * Macronix MX25L / EON-XMC 25QH parts:
 * ```
 * bit 0   WIP   write-in-progress / busy
 * bit 1   WEL   write-enable latch
 * bits 2-5 BP0-BP3  block-protect level - how much of the chip is currently protected
 * bit 6   vendor-specific - commonly TB ("top/bottom") or SEC ("sector/block") select
 * bit 7   SRP0  status-register-protect enable - locks the BP bits while the #WP pin is low
 * ```
 * What bit 6 means, and exactly which address range a given BP level protects, both vary by chip
 * density and vendor - a real flashrom resolves that from a per-chip table, not anything generic,
 * and this class deliberately doesn't guess at it. What it *does* give: whether any block
 * protection is currently active, whether the hardware protect pin is locking it, and a decoded
 * [Status] to act on - which covers the actual common failure mode this exists for: a
 * program/erase silently no-op'ing because a previous tool (or the chip's factory default) left
 * some BP bits set. [IspFlash.unprotect] is the piece that actually clears them.
 */
object WriteProtection {

    data class Status(
        val raw: Int,
        val busy: Boolean,
        val writeEnabled: Boolean,
        /** BP0-BP3, bits 2-5 of the status register - 0 means no block protection. */
        val blockProtectLevel: Int,
        /** SRP0, bit 7 - status register (and therefore the BP bits) is hardware-locked. */
        val statusRegisterProtected: Boolean
    ) {
        val anyBlockProtected: Boolean get() = blockProtectLevel != 0

        /** A short, human-readable summary - safe to show directly in a future UI. */
        fun describe(): String = buildString {
            append(
                if (anyBlockProtected)
                    "Block protect level $blockProtectLevel/15 - part of the chip is likely write-protected."
                else
                    "Block protect level 0 - no block protection active."
            )
            if (statusRegisterProtected) {
                append(
                    " Status register is hardware-locked (SRP0 set) - the #WP pin must be held " +
                        "high to change protection."
                )
            }
        }
    }

    /** Pure decode, no I/O - pass it whatever [IspFlash.readStatus] (or SpiFlash's) returned. */
    fun decode(statusRegister1: Int): Status = Status(
        raw = statusRegister1,
        busy = statusRegister1 and 0x01 != 0,
        writeEnabled = statusRegister1 and 0x02 != 0,
        blockProtectLevel = (statusRegister1 shr 2) and 0x0F,
        statusRegisterProtected = statusRegister1 and 0x80 != 0
    )
}
