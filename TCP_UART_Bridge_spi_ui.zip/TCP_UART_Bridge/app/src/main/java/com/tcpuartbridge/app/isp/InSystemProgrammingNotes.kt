package com.tcpuartbridge.app.isp

/**
 * Practical guidance for programming a SPI flash chip while it's still attached to its board
 * ("In-System Programming" / ISP / in-circuit programming), rather than desoldering it and
 * clipping it onto a programmer on its own - flashrom's own docs use exactly this term and this
 * package's name is a direct nod to it. This is the scenario both this package's serprog/
 * external-programmer path and the app's existing SPI Flash panel (direct via the CH341A) exist
 * for whenever the chip can't be pulled off the board.
 *
 * Paraphrased (not reproduced) from flashrom's own bundled user documentation - part of the
 * Diamon "Flash EEPROM Tool" project this was extracted from, GPL-licensed docs, no code copied:
 *   - `usr/share/doc/flashrom/html/user_docs/in_system.html` ("In-System Programming")
 *   - `usr/share/doc/flashrom/html/user_docs/misc_notes.html` ("Misc notes and advice" -
 *     the "Connections" / "Common problems" sections)
 *   - `usr/share/doc/flashrom/html/user_docs/management_engine.html` ("ME (Management Engine)")
 *   - `usr/share/doc/flashrom/html/supported_hw/supported_prog/serprog/arduino_flasher.html`
 *     (the voltage-matching warning specific to using an Arduino as the external programmer)
 * condensed into a short field checklist rather than the original prose.
 */
object InSystemProgrammingNotes {

    data class Tip(val title: String, val detail: String)

    /** What "ISP" means here - for a future UI that wants to explain the concept before showing the checklist. */
    const val SUMMARY: String =
        "In-System Programming (ISP) means writing a flash chip while it's still soldered to its " +
            "board, using an external programmer clipped or wired onto the chip's SPI pins, instead " +
            "of desoldering it. It's usually only practical for SPI chips."

    val CHECKLIST: List<Tip> = listOf(
        Tip(
            "Rule out board-level protection first",
            "Check for a BIOS-flash-protect jumper on the board and a write-protect option in " +
                "the BIOS/UEFI menu before assuming the connection itself is the problem."
        ),
        Tip(
            "Attach without soldering when possible",
            "An SOIC clip (Pomona, 3M, and similar - widely available from electronics " +
                "distributors) or, in a pinch, a DIP socket used as a makeshift clip, lets you " +
                "attach to the chip's pins without desoldering it. Use a board header labeled " +
                "ISP/ISP1/SPI if the board has one - there should be no connection problems as " +
                "long as the wires from it stay short."
        ),
        Tip(
            "Isolate the programmer's Vcc",
            "Chipset logic is often partially powered through the flash chip's own Vcc pin. " +
                "Power the board from its own PSU and disconnect the programmer's Vcc line " +
                "rather than letting the programmer supply power to a live board."
        ),
        Tip(
            "Hold the board in reset",
            "A jumper in place of the reset button usually works. Chipsets with an " +
                "edge-triggered reset (Intel ICH/PCH, because of the Management Engine - see " +
                "below) won't stay reset from a held-low line; pulsing reset periodically - e.g. " +
                "tied to the SPI chip-select line or a dedicated clock signal - instead of " +
                "holding it low is the usual workaround, with a pulse duration long enough for " +
                "the reset line to actually register."
        ),
        Tip(
            "Intel ME can block a region even with a perfect connection",
            "On Intel chipsets the flash is split into regions by a descriptor; the chipset's " +
                "own SPI controller enforces read/write access rights per region, and the ME " +
                "(Management Engine) region is normally locked to the host CPU entirely - a " +
                "restriction the chipset enforces, not something a clean physical connection can " +
                "get around. Vendor firmware-update tools, or writing only the BIOS region " +
                "specifically (not the whole chip), are the usual workarounds; see flashrom's own " +
                "management-engine documentation for the full picture."
        ),
        Tip(
            "Quiet the bus if reads/probes are inconsistent",
            "Try disconnecting the ATX12V header, or pulling the CPU/RAM, so nothing else on the " +
                "board is driving the SPI lines while you work."
        ),
        Tip(
            "Keep wires short and clean",
            "A few cm, not tens. Long or badly-terminated wires cause exactly the kind of " +
                "intermittent reads/probing failures that look like a bad chip or a bad " +
                "programmer. Lowering the SPI clock (this package's serprog path and the CH341A " +
                "SPI Flash panel both talk to hardware that supports this) often masks a marginal " +
                "connection; small series resistors (well under 100 ohm) or parallel capacitors " +
                "(well under 20pF) near the input pins - MISO especially - and a small (0.1-1 uF) " +
                "decoupling capacitor across the flash chip's Vcc/GND can help with longer runs."
        ),
        Tip(
            "Match voltages if the external programmer isn't natively 3.3V",
            "Most SPI NOR flash chips run at 3.3V; a 5V microcontroller board (a stock Arduino " +
                "Uno, for instance) needs level translation on every SPI line - a resistor " +
                "divider or a small buffer chip - before it touches a 3.3V chip's pins. Skipping " +
                "this on a 5V board is a real way to damage the chip, not just fail to talk to it."
        )
    )
}
