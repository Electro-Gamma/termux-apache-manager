// Adapted from the Diamon "Flash EEPROM Tool" project's `native-lib.cpp` (GPLv3) - see this
// package's README.md and the repo root NOTICE.md for exact provenance. Trimmed to only the
// process-spawning functions the `ch341a_spi` path needs: that path talks to the CH341A over
// libusb (via the ANDROID_USB_FD convention the bundled, prebuilt `libusb_1_0.so` understands -
// see FlashromRuntime.kt's doc comment), not a serial port, so the original's PTY-bridging
// functions (for flashrom's `serprog`/Arduino path) aren't needed here and were left out.
//
// Why this needs to be native code at all, not just a Kotlin ProcessBuilder call: Android's
// ProcessBuilder/Runtime.exec() marks every file descriptor above stdin/stdout/stderr as
// close-on-exec before starting the child process, so the already-open USB connection's fd
// (UsbDeviceConnection.getFileDescriptor()) would simply be closed by the time flashrom's exec()
// call ran. Only a real fork()+exec() - done here in C, with fcntl() clearing FD_CLOEXEC on that
// one fd first - can hand it to the child process still open.

#include <jni.h>
#include <string>
#include <vector>
#include <unistd.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <signal.h>
#include <errno.h>
#include <android/log.h>

#define LOG_TAG "FlashromSpiJNI"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

/**
 * Duplicates the USB file descriptor so the copy is inheritable across fork()+exec(). dup()
 * creates the new fd without O_CLOEXEC, letting it survive into the child process that will
 * become flashrom.
 *
 * @param fd  The original fd from UsbDeviceConnection.getFileDescriptor().
 * @return    A new, inheritable fd (>= 0), or -1 on error.
 */
extern "C" JNIEXPORT jint JNICALL
Java_com_tcpuartbridge_app_flashromspi_NativeProcess_dupFdForChild(JNIEnv *env, jclass clazz, jint fd) {
    if (fd < 0) {
        LOGE("dupFdForChild: invalid fd (%d)", (int) fd);
        return -1;
    }
    int newFd = dup((int) fd);
    if (newFd < 0) {
        LOGE("dupFdForChild: dup(%d) failed, errno=%d", (int) fd, errno);
        return -1;
    }
    int flags = fcntl(newFd, F_GETFD);
    if (flags >= 0 && (flags & FD_CLOEXEC)) {
        fcntl(newFd, F_SETFD, flags & ~FD_CLOEXEC);
    }
    LOGI("dupFdForChild: fd %d -> %d (inheritable)", (int) fd, newFd);
    return (jint) newFd;
}

/** Closes a fd previously returned by dupFdForChild(), once the child process has exited. */
extern "C" JNIEXPORT void JNICALL
Java_com_tcpuartbridge_app_flashromspi_NativeProcess_closeDupedFd(JNIEnv *env, jclass clazz, jint fd) {
    if (fd >= 0) {
        close((int) fd);
    }
}

/**
 * fork()+exec()'s [executable] with [args], bypassing ProcessBuilder so [usbFd] survives into the
 * child with FD_CLOEXEC cleared, exported as ANDROID_USB_FD - the environment variable this
 * package's bundled, prebuilt libusb (see FlashromRuntime.kt) checks for instead of scanning the
 * USB bus (which would need root on Android). The child's stdout+stderr are redirected to a pipe
 * whose read end is returned to the caller for streaming output back.
 *
 * @return [pid, pipeReadFd], or null if the pipe/fork itself failed.
 */
extern "C" JNIEXPORT jintArray JNICALL
Java_com_tcpuartbridge_app_flashromspi_NativeProcess_startNativeProcess(
        JNIEnv *env, jclass clazz,
        jstring jExecutable,
        jobjectArray jArgs,
        jint usbFd,
        jstring jLdLibraryPath,
        jstring jWorkingDir) {

    const char *execPath = env->GetStringUTFChars(jExecutable, nullptr);
    const char *ldLibPath = env->GetStringUTFChars(jLdLibraryPath, nullptr);
    const char *workingDir = env->GetStringUTFChars(jWorkingDir, nullptr);

    int argc = env->GetArrayLength(jArgs);
    std::vector<char *> argv;
    std::vector<const char *> stringsToRelease;
    argv.push_back(const_cast<char *>(execPath)); // argv[0] is the executable itself
    for (int i = 0; i < argc; i++) {
        jstring argStr = (jstring) env->GetObjectArrayElement(jArgs, i);
        const char *arg = env->GetStringUTFChars(argStr, nullptr);
        argv.push_back(const_cast<char *>(arg));
        stringsToRelease.push_back(arg);
    }
    argv.push_back(nullptr);

    int pipefds[2];
    if (pipe(pipefds) < 0) {
        LOGE("startNativeProcess: pipe() failed, errno=%d", errno);
        env->ReleaseStringUTFChars(jExecutable, execPath);
        env->ReleaseStringUTFChars(jLdLibraryPath, ldLibPath);
        env->ReleaseStringUTFChars(jWorkingDir, workingDir);
        for (int i = 0; i < argc; i++) {
            jstring argStr = (jstring) env->GetObjectArrayElement(jArgs, i);
            env->ReleaseStringUTFChars(argStr, stringsToRelease[i]);
        }
        return nullptr;
    }

    pid_t pid = fork();
    if (pid == 0) {
        // --- child ---
        dup2(pipefds[1], STDOUT_FILENO);
        dup2(pipefds[1], STDERR_FILENO);
        close(pipefds[0]);
        close(pipefds[1]);

        if (workingDir && workingDir[0] != '\0') {
            chdir(workingDir);
        }

        if (usbFd >= 0) {
            char fdStr[16];
            snprintf(fdStr, sizeof(fdStr), "%d", usbFd);
            setenv("ANDROID_USB_FD", fdStr, 1);
            int flags = fcntl(usbFd, F_GETFD);
            if (flags >= 0 && (flags & FD_CLOEXEC)) {
                fcntl(usbFd, F_SETFD, flags & ~FD_CLOEXEC);
            }
        }
        setenv("LD_LIBRARY_PATH", ldLibPath, 1);

        execv(execPath, argv.data());
        _exit(127); // only reached if execv() itself failed
    }

    // --- parent ---
    close(pipefds[1]);

    env->ReleaseStringUTFChars(jExecutable, execPath);
    env->ReleaseStringUTFChars(jLdLibraryPath, ldLibPath);
    env->ReleaseStringUTFChars(jWorkingDir, workingDir);
    for (int i = 0; i < argc; i++) {
        jstring argStr = (jstring) env->GetObjectArrayElement(jArgs, i);
        env->ReleaseStringUTFChars(argStr, stringsToRelease[i]);
    }

    if (pid < 0) {
        LOGE("startNativeProcess: fork() failed, errno=%d", errno);
        close(pipefds[0]);
        return nullptr;
    }

    jintArray result = env->NewIntArray(2);
    if (result != nullptr) {
        jint arr[2] = {(jint) pid, (jint) pipefds[0]};
        env->SetIntArrayRegion(result, 0, 2, arr);
    }
    return result;
}

/** Blocks until [pid] exits, returning its exit status (or -1 if it didn't exit normally). */
extern "C" JNIEXPORT jint JNICALL
Java_com_tcpuartbridge_app_flashromspi_NativeProcess_waitForNativeProcess(
        JNIEnv *env, jclass clazz, jint pid) {
    int status;
    if (waitpid((pid_t) pid, &status, 0) < 0) {
        return -1;
    }
    if (WIFEXITED(status)) {
        return WEXITSTATUS(status);
    }
    return -1;
}

/** SIGKILLs [pid] - used to abort an in-progress flashrom run. */
extern "C" JNIEXPORT void JNICALL
Java_com_tcpuartbridge_app_flashromspi_NativeProcess_terminateNativeProcess(
        JNIEnv *env, jclass clazz, jint pid) {
    if (pid > 0) {
        kill((pid_t) pid, SIGKILL);
    }
}
