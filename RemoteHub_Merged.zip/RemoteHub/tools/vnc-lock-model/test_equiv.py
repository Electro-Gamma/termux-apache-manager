"""(1) with the lock never switched on, the new code behaves exactly like the original; (2) lock invariants under random input."""
import random
from vp import *

class OldCursor:   # the ORIGINAL CursorController movement code, verbatim
    def __init__(s, vp): s.vp=vp; s.x=s.y=0.0; s.sent=[]
    def post(s): s.sent.append((round(s.x),round(s.y)))
    def setPosition(s,dx,dy): s.x=clamp(dx,0.0,s.vp.fbW-1.0); s.y=clamp(dy,0.0,s.vp.fbH-1.0); s.vp.centreOn(s.x,s.y)
    def setPositionHere(s,dx,dy): s.x=clamp(dx,0.0,s.vp.fbW-1.0); s.y=clamp(dy,0.0,s.vp.fbH-1.0); s.post()
    def mouseMove(s,dx,dy):
        sc=s.vp.scale; s.x=clamp(s.x+dx/sc,0.0,s.vp.fbW-1.0); s.y=clamp(s.y+dy/sc,0.0,s.vp.fbH-1.0); s.post(); s.vp.centreOn(s.x,s.y)
    def centreCursor(s):
        s.x=clamp(s.vp.toDesktopX(s.vp.centreScreenX()),0.0,s.vp.fbW-1.0); s.y=clamp(s.vp.toDesktopY(s.vp.centreScreenY()),0.0,s.vp.fbH-1.0); s.post(); s.vp.centreOn(s.x,s.y)
    def setInsets(s,l,t,r,b):
        vp=s.vp; cX=abs(vp.toScreenX(s.x)-vp.centreScreenX())<=0.5; cY=abs(vp.toScreenY(s.y)-vp.centreScreenY())<=0.5
        vp.setInsets(l,t,r,b)
        if vp.scale<vp.minScale(): vp.centreOn(s.x,s.y,vp.minScale())
        nx=vp.toDesktopX(vp.centreScreenX()) if cX else s.x; ny=vp.toDesktopY(vp.centreScreenY()) if cY else s.y
        if nx!=s.x or ny!=s.y: s.x=clamp(nx,0.0,vp.fbW-1.0); s.y=clamp(ny,0.0,vp.fbH-1.0); s.post()
        vp.centreOn(s.x,s.y)
def ops(rng,i,old=None):
    c=old if old is not None else i.cursor
    for _ in range(rng.randint(5,40)):
        k=rng.choice(["move","move","move","here","zoomT","zoomD","pan","inset","pos"])
        if k=="move": c.mouseMove(rng.uniform(-3000,3000)*rng.choice([0.01,1]),rng.uniform(-3000,3000)*rng.choice([0.01,1]))
        elif k=="here": c.setPositionHere(rng.uniform(-300,2300),rng.uniform(-300,1400))
        elif k=="zoomT":
            i.baseScale=i.vp.scale
            f=rng.uniform(0.3,3.0); i.vp.setScale(i.baseScale*f); c.centreCursor()
        elif k=="zoomD": i.vp.zoomAt(i.vp.scale*rng.uniform(0.5,2.0),rng.uniform(0,1080),rng.uniform(0,1800))
        elif k=="pan": i.vp.panBy(rng.uniform(-400,400),rng.uniform(-400,400))
        elif k=="inset": c.setInsets(0,0,0,rng.choice([0,0,300,600]))
        elif k=="pos": c.setPosition(rng.uniform(0,1920),rng.uniform(0,1080))
ok=True
print("== (1) lock never used: new code == original code, 300 random sessions")
bad=0
for seed in range(300):
    r1=random.Random(seed); r2=random.Random(seed)
    a=Input(); b=Input(); old=OldCursor(b.vp); old.x,old.y=b.cursor.x,b.cursor.y
    ops(r1,a); ops(r2,b,old)
    A=(a.vp.scale,a.vp.originX,a.vp.originY,a.cursor.x,a.cursor.y,tuple(a.cursor.sent)); B=(b.vp.scale,b.vp.originX,b.vp.originY,old.x,old.y,tuple(old.sent))
    if A!=B: bad+=1
print(("[ok]   " if bad==0 else "[FAIL] ")+f"{300-bad}/300 identical (scale, origin, cursor and every pointer event sent)"); ok&=bad==0
print("== (2) locked: random input never moves the picture and never leaves the pointer off screen")
bad=0
for seed in range(300):
    rng=random.Random(1000+seed); i=Input(); i.baseScale=i.vp.scale
    ops(rng,i); i.setScreenLocked(True); frozen=(i.vp.scale,i.vp.originX,i.vp.originY)
    for _ in range(80):
        ops(rng,i)
        v=i.vp; cx,cy=i.cursor.screenX(),i.cursor.screenY()
        if (v.scale,v.originX,v.originY)!=frozen: bad+=1; break
        if not (v.insetL-1e-6<=cx<=v.insetL+v.contentWidth()-1+1e-6 and v.insetT-1e-6<=cy<=v.insetT+v.contentHeight()-1+1e-6): bad+=1; break
        if not (0<=round(i.cursor.x)<=1919 and 0<=round(i.cursor.y)<=1079): bad+=1; break
print(("[ok]   " if bad==0 else "[FAIL] ")+f"{300-bad}/300 sessions: viewport frozen, pointer always inside the visible area"); ok&=bad==0
print("ALL PASSED" if ok else "FAILED")
