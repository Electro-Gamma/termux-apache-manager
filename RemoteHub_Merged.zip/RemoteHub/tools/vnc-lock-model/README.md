# VNC screen lock: logic model and tests

Not part of the app build. `vp.py` is a Python port of the parts of `Viewport.kt`, `CursorController.kt` and `SessionInput.kt` that the
screen lock touches. `python3 test_lock.py` checks the behaviour (zoom, lock, pointer pushed in every direction, pinch ignored,
keyboard inset, unlock, remote resolution change); `python3 test_equiv.py` fuzzes (1) that with the lock never used the code behaves
exactly like the original (300 sessions) and (2) that with it on the picture never moves and the pointer never leaves the screen (300 sessions).
The Kotlin that ships is in `app/src/main/java/com/vncviewer/app/input/`; unit tests for it are in `app/src/test/.../ScreenLockTest.kt`.
