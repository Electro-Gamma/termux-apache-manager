"""Port of Viewport.kt + CursorController.kt (+ the SessionInput lock gates). `lock_enabled=False` => the ORIGINAL code paths."""
import math
def clamp(v, lo, hi): return lo if v < lo else hi if v > hi else v

class Viewport:
    def __init__(s, density=3.0):
        s.density=max(density,1.0); s.fbW=s.fbH=1; s.viewW=s.viewH=0
        s.insetL=s.insetT=s.insetR=s.insetB=0; s.marginL=s.marginT=s.marginR=s.marginB=0
        s.scale=1.0; s.originX=s.originY=0.0; s.focusX=s.focusY=0.0; s.topAlign=False; s.restCentreY=float('nan'); s.frozen=False
    # --- lock
    def isFrozen(s): return s.frozen
    def setFrozen(s, on):
        if s.frozen==on: return
        s.frozen=on
        if (not on) and s.contentWidth()>0 and s.contentHeight()>0:
            s.focusX=s.toDesktopX(s.centreScreenX()); s.focusY=s.toDesktopY(s.centreScreenY())
    def visibleLeft(s): return max(s.toDesktopX(float(s.insetL)),0.0)
    def visibleTop(s): return max(s.toDesktopY(float(s.insetT)),0.0)
    def visibleRight(s): return min(s.toDesktopX(s.insetL+s.contentWidth()-1.0), s.fbW-1.0)
    def visibleBottom(s): return min(s.toDesktopY(s.insetT+s.contentHeight()-1.0), s.fbH-1.0)
    # --- geometry
    def setDesktopSize(s,w,h): s.fbW=max(w,1); s.fbH=max(h,1)
    def setViewSize(s,w,h): s.viewW=w; s.viewH=h
    def setInsets(s,l,t,r,b): s.insetL=max(l,0); s.insetT=max(t,0); s.insetR=max(r,0); s.insetB=max(b,0)
    def contentWidth(s): return max(s.viewW-s.insetL-s.insetR,0)
    def contentHeight(s): return max(s.viewH-s.insetT-s.insetB,0)
    def centreScreenX(s): return s.insetL+s.contentWidth()/2.0
    def centreScreenY(s): return s.insetT+s.contentHeight()/2.0
    def toScreenX(s,dx): return dx*s.scale+s.originX
    def toScreenY(s,dy): return dy*s.scale+s.originY
    def toDesktopX(s,sx): return (sx-s.originX)/s.scale
    def toDesktopY(s,sy): return (sy-s.originY)/s.scale
    def minScale(s):
        if s.contentWidth()==0 or s.contentHeight()==0: return 1.0
        return min(s.contentWidth()/s.fbW, s.contentHeight()/s.fbH)
    def maxScale(s): return 2.0*math.floor(s.density)
    def snapScale(s,v): return clamp(int(v*128.0)/128.0, s.minScale(), s.maxScale())   # snapping to natural sizes omitted
    def setScale(s,v): s.centreOn(s.focusX,s.focusY,s.snapScale(v))
    def centreOn(s,dx,dy,sc=None):
        if s.frozen: return
        sc=s.scale if sc is None else sc
        cw,ch=s.contentWidth(),s.contentHeight()
        if cw==0 or ch==0: s.scale=sc; return
        s.scale=sc
        s.place(s.centreScreenX()-dx*sc, s.centreScreenY()-dy*sc)
        s.focusX=s.toDesktopX(s.centreScreenX()); s.focusY=s.toDesktopY(s.centreScreenY())

def _clampAxis(s,o,inset,content,desktop,centred,mlo,mhi):
    mLo=min(float(mlo),content/2.0); mHi=min(float(mhi),content/2.0)
    if desktop<content:
        rest=clamp(centred,float(inset),inset+content-desktop)
        blankLo=rest-inset; blankHi=inset+content-desktop-rest
        lo=rest-max(mHi-blankHi,0.0); hi=rest+max(mLo-blankLo,0.0)
    else:
        lo=inset+content-desktop-mHi; hi=inset+mLo
    return clamp(o,lo,hi)
def _place(s,ox,oy):
    dw,dh=s.fbW*s.scale,s.fbH*s.scale
    s.originX=_clampAxis(s,ox,s.insetL,s.contentWidth(),dw,(s.viewW-dw)/2.0,s.marginL,s.marginR)
    cen=(float(s.insetT) if s.topAlign else (s.restCentreY-dh/2.0 if not math.isnan(s.restCentreY) else (s.viewH-dh)/2.0))
    s.originY=_clampAxis(s,oy,s.insetT,s.contentHeight(),dh,cen,s.marginT,s.marginB)
Viewport.place=_place
def _panBy(s,dx,dy): s.centreOn(s.focusX-dx/s.scale, s.focusY-dy/s.scale)
def _zoomAt(s,newScale,sx,sy):
    if s.frozen: return
    if s.contentWidth()==0 or s.contentHeight()==0: s.scale=newScale; return
    dx,dy=s.toDesktopX(sx),s.toDesktopY(sy)
    s.scale=clamp(newScale,s.minScale(),s.maxScale()); s.place(sx-dx*s.scale, sy-dy*s.scale)
    s.focusX=s.toDesktopX(s.centreScreenX()); s.focusY=s.toDesktopY(s.centreScreenY())
Viewport.panBy=_panBy; Viewport.zoomAt=_zoomAt

class Cursor:
    def __init__(s, vp, lock_enabled=True): s.vp=vp; s.x=s.y=0.0; s.sent=[]; s.lock_enabled=lock_enabled
    def limitX(s,v):
        vp=s.vp
        if s.lock_enabled and vp.isFrozen():
            lo=vp.visibleLeft(); return clamp(v,lo,max(lo,vp.visibleRight()))
        return clamp(v,0.0,vp.fbW-1.0)
    def limitY(s,v):
        vp=s.vp
        if s.lock_enabled and vp.isFrozen():
            lo=vp.visibleTop(); return clamp(v,lo,max(lo,vp.visibleBottom()))
        return clamp(v,0.0,vp.fbH-1.0)
    def post(s): s.sent.append((round(s.x),round(s.y)))
    def keepInView(s):
        nx,ny=s.limitX(s.x),s.limitY(s.y)
        if nx!=s.x or ny!=s.y: s.x,s.y=nx,ny; s.post()
    def setPosition(s,dx,dy): s.x=s.limitX(dx); s.y=s.limitY(dy); s.vp.centreOn(s.x,s.y)
    def setPositionHere(s,dx,dy): s.x=s.limitX(dx); s.y=s.limitY(dy); s.post()
    def mouseMove(s,dx,dy):
        sc=s.vp.scale; s.x=s.limitX(s.x+dx/sc); s.y=s.limitY(s.y+dy/sc); s.post(); s.vp.centreOn(s.x,s.y)
    def centreCursor(s):
        s.x=s.limitX(s.vp.toDesktopX(s.vp.centreScreenX())); s.y=s.limitY(s.vp.toDesktopY(s.vp.centreScreenY())); s.post(); s.vp.centreOn(s.x,s.y)
    def setInsets(s,l,t,r,b):
        vp=s.vp
        if vp.isFrozen():
            vp.setInsets(l,t,r,b); s.keepInView(); return
        cX=abs(vp.toScreenX(s.x)-vp.centreScreenX())<=0.5; cY=abs(vp.toScreenY(s.y)-vp.centreScreenY())<=0.5
        vp.setInsets(l,t,r,b)
        if vp.scale<vp.minScale(): vp.centreOn(s.x,s.y,vp.minScale())
        nx=vp.toDesktopX(vp.centreScreenX()) if cX else s.x; ny=vp.toDesktopY(vp.centreScreenY()) if cY else s.y
        if nx!=s.x or ny!=s.y:
            s.x=clamp(nx,0.0,vp.fbW-1.0); s.y=clamp(ny,0.0,vp.fbH-1.0); s.post()
        vp.centreOn(s.x,s.y)
    def screenX(s): return s.vp.toScreenX(s.x)
    def screenY(s): return s.vp.toScreenY(s.y)

class Input:   # the SessionInput pieces involved
    def __init__(s, viewW=1080, viewH=1800, fbW=1920, fbH=1080, density=3.0):
        s.vp=Viewport(density); s.vp.setDesktopSize(fbW,fbH); s.vp.setViewSize(viewW,viewH)
        s.cursor=Cursor(s.vp); s.baseScale=1.0; s.desktopKnown=True; s.placed=True; s.toolbarLock=False
        s.vp.setFocus=lambda dx,dy: (setattr(s.vp,'focusX',dx), setattr(s.vp,'focusY',dy))
        s.vp.centreOn(fbW/2,fbH/2,s.vp.snapScale(1.0)); s.cursor.setPosition(fbW/2,fbH/2)
    def setScreenLocked(s,on):
        if on==s.vp.isFrozen(): return
        s.vp.setFrozen(on)
        if on: s.cursor.keepInView()
        s.baseScale=s.vp.scale; s.toolbarLock=s.vp.isFrozen()
    def directZoom(s,factor,cx,cy,pdx=0,pdy=0):
        if s.vp.isFrozen(): return
        s.vp.zoomAt(s.vp.scale*factor,cx,cy)
        if pdx or pdy: s.vp.panBy(pdx,pdy)
    def zoomChanged(s,factor):
        if s.vp.isFrozen(): return
        s.vp.setScale(s.baseScale*factor); s.cursor.centreCursor()
    def setDesktopSize(s,w,h):
        if s.vp.fbW==w and s.vp.fbH==h: return
        if s.vp.isFrozen(): s.vp.setFrozen(False); s.toolbarLock=False
        s.vp.setDesktopSize(w,h); s.vp.centreOn(w/2,h/2,s.vp.snapScale(s.vp.scale)); s.cursor.setPosition(w/2,h/2)
