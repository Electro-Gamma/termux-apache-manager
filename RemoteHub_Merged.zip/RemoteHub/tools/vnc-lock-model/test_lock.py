import random
from vp import *
ok=True
def check(c,name,extra=""):
    global ok; print(("[ok]   " if c else "[FAIL] ")+name+(("   "+str(extra)) if (extra and not c) else "")); ok&=bool(c)
def screen_ok(i):
    v=i.vp; cx,cy=i.cursor.screenX(),i.cursor.screenY()
    return v.insetL<=cx<=v.insetL+v.contentWidth()-1+1e-6 and v.insetT<=cy<=v.insetT+v.contentHeight()-1+1e-6
def zoomed_in():
    i=Input(); i.zoomChanged  # touchpad: pinch to 2.5x via the normal path, centred on the cursor
    i.baseScale=i.vp.scale; i.zoomChanged(2.5); i.baseScale=i.vp.scale
    i.cursor.mouseMove(-200,150)                     # work somewhere in the picture; the view follows the cursor as usual
    return i

print("== Touchpad mode: zoom in, lock, push the pointer everywhere")
i=zoomed_in(); sc0,ox0,oy0=i.vp.scale,i.vp.originX,i.vp.originY
check(sc0>1.0,"normal zoom works before locking",sc0)
i.setScreenLocked(True)
check(i.vp.isFrozen() and i.toolbarLock,"lock is on and the toolbar item reports it")
for (dx,dy) in [(5000,0),(-5000,0),(0,5000),(0,-5000),(4000,4000),(-4000,-4000),(3,0),(0,-2)]*3:
    i.cursor.mouseMove(dx,dy)
    assert (i.vp.scale,i.vp.originX,i.vp.originY)==(sc0,ox0,oy0), ("viewport moved",dx,dy)
check(True,"pushing far left/right/up/down never changes scale or origin (24 moves)")
for (dx,dy) in [(9000,0),(-9000,0),(0,9000),(0,-9000)]:
    i.cursor.mouseMove(dx,dy); 
    check(screen_ok(i),f"pointer stays inside the screen after a push of ({dx},{dy})",(i.cursor.screenX(),i.cursor.screenY()))
i.cursor.mouseMove(-9000,-9000); sx0,sy0=i.cursor.screenX(),i.cursor.screenY()
check(abs(sx0-i.vp.insetL)<1e-3 and abs(sy0-i.vp.insetT)<1e-3,"pointer stops exactly at the top-left corner of the screen",(sx0,sy0))
i.cursor.mouseMove(9000,9000)
check(abs(i.cursor.screenX()-(i.vp.viewW-1))<1e-3 and abs(i.cursor.screenY()-(i.vp.viewH-1))<1e-3,"...and at the bottom-right corner",(i.cursor.screenX(),i.cursor.screenY()))
check(all(0<=x<=1919 and 0<=y<=1079 for x,y in i.cursor.sent),"every pointer position sent to the server is on the desktop")
# precise motion inside the area: 1 screen pixel of finger movement = 1/scale desktop pixels
i.cursor.mouseMove(-9000,-9000); i.cursor.mouseMove(40,0); 
check(abs(i.cursor.screenX()-(i.vp.insetL+40))<1e-3,"precise movement inside the area is 1:1 on screen")

print("== Pinch / pan while locked")
before=(i.vp.scale,i.vp.originX,i.vp.originY); cur=(i.cursor.x,i.cursor.y)
i.baseScale=i.vp.scale; i.zoomChanged(0.5); i.zoomChanged(3.0); i.directZoom(0.4,500,500,30,30); i.directZoom(2.0,100,100); i.vp.panBy(80,-90)
check((i.vp.scale,i.vp.originX,i.vp.originY)==before,"pinch (touchpad and direct) and pan do nothing while locked")
check((i.cursor.x,i.cursor.y)==cur,"...and the pinch does not drag the pointer to the middle either")

print("== Direct-touch mode")
i.cursor.setPositionHere(-500,-500); check(screen_ok(i),"a touch outside the picture is held at the nearest visible point")
i.cursor.setPositionHere(1e6,1e6); check(screen_ok(i),"...on every side")

print("== Soft keyboard / Keys row while locked")
before=(i.vp.scale,i.vp.originX,i.vp.originY)
i.cursor.mouseMove(9000,9000); i.cursor.setInsets(0,0,0,500)
check((i.vp.scale,i.vp.originX,i.vp.originY)==before,"keyboard inset changes do not move the picture")
check(screen_ok(i) and i.cursor.screenY()<=i.vp.viewH-500,"the pointer is pulled back into the smaller visible area",(i.cursor.screenY(),i.vp.viewH-500))
i.cursor.mouseMove(0,9000); check(i.cursor.screenY()<=i.vp.viewH-500,"...and cannot go below it")
i.cursor.setInsets(0,0,0,0); check((i.vp.scale,i.vp.originX,i.vp.originY)==before,"closing it changes nothing")

print("== Unlock restores the original behaviour")
i.setScreenLocked(False)
check(not i.vp.isFrozen() and not i.toolbarLock,"lock off")
# Where the pointer is, the picture follows it exactly as the original code does (the desktop edge limits how far it can centre).
j=zoomed_in(); j.cursor.x,j.cursor.y=i.cursor.x,i.cursor.y; j.cursor.mouseMove(30,20)
i.cursor.mouseMove(30,20)
mid=zoomed_in(); mid.setScreenLocked(True); v=mid.vp; mid.cursor.setPositionHere((v.visibleLeft()+v.visibleRight())/2,(v.visibleTop()+v.visibleBottom())/2); mid.setScreenLocked(False); mid.cursor.mouseMove(30,20)
check(abs(mid.cursor.screenX()-mid.vp.centreScreenX())<1e-3 and abs(mid.cursor.screenY()-mid.vp.centreScreenY())<1e-3,"touchpad: unlocked, the picture follows the pointer again (pointer back at the centre)")
sc=i.vp.scale; i.baseScale=sc; i.zoomChanged(0.5); check(i.vp.scale!=sc,"zoom works again")
i.vp.panBy(50,0); check(True,"pan works again")
i.cursor.mouseMove(-99999,0); check(i.cursor.x==0.0,"the pointer can reach the desktop edge again")

print("== Lock only affects locked state; remote resolution change releases it")
i=zoomed_in(); i.setScreenLocked(True); i.setDesktopSize(1280,720)
check(not i.vp.isFrozen() and not i.toolbarLock,"a desktop size change releases the lock")
i=zoomed_in(); i.setScreenLocked(True); i.setScreenLocked(True); i.setScreenLocked(False); i.setScreenLocked(False); check(not i.vp.isFrozen(),"toggling twice / redundant calls are harmless")

print("== Pan anchor after unlock: first pan does not jump")
i=zoomed_in(); i.setScreenLocked(True); i.baseScale=i.vp.scale
i.vp.setFocus=None
i.vp.focusX+=123; i.vp.focusY-=77                  # a pinch while locked moves the anchor (scaleCentre)
i.setScreenLocked(False); o=(i.vp.originX,i.vp.originY); i.vp.panBy(0,0)
check(abs(i.vp.originX-o[0])<1e-3 and abs(i.vp.originY-o[1])<1e-3,"first pan after unlocking starts from the picture as it is")

print("ALL PASSED" if ok else "FAILED")
