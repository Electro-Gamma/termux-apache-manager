# File viewer: copy buttons on code blocks

Not part of the app build. `build_pages.py` assembles a viewer page the way `ViewerRenderer.page()` does (same CSS, script and CSP),
from Markdown and from a notebook body shaped like `NotebookRenderer`'s output. `python3 test_copy.py` (needs `playwright` with Chromium,
i.e. the same engine as Android's WebView) clicks the buttons and checks what is copied, the confirmation, the three copy paths
(native bridge, browser clipboard API, select-and-copy), the failure message, CSP violations, layout and scrolling.
