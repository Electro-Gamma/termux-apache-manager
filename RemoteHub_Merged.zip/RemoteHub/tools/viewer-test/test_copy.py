import time
from playwright.sync_api import sync_playwright
import build_pages as bp
ok=True
def check(c,name,extra=""):
    global ok; print(("[ok]   " if c else "[FAIL] ")+name+(("   "+str(extra)) if (extra and not c) else "")); ok&=bool(c)
URL="https://viewer.invalid/"
def load(ctx, html, init=None):
    pg=ctx.new_page(); msgs=[]
    pg.on("console", lambda m: msgs.append(m.text)); pg.on("pageerror", lambda e: msgs.append("PAGEERROR "+str(e)))
    if init: pg.add_init_script(init)
    pg.route(URL, lambda r: r.fulfill(status=200, content_type="text/html", body=html))
    pg.goto(URL); return pg, msgs

BRIDGE="window.__copied=[]; window.AppClipboard={copy:function(t){window.__copied.push(t); return true;}};"
NOBRIDGE_NOAPI="Object.defineProperty(navigator,'clipboard',{value:undefined,configurable:true}); window.__ec=[]; document.addEventListener('copy',function(){var a=document.activeElement;window.__ec.push(a && a.value!==undefined ? a.value.substring(a.selectionStart,a.selectionEnd):null)},true);"

with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={"width":390,"height":844}, device_scale_factor=2, is_mobile=True, has_touch=True)
    ctx.grant_permissions(["clipboard-read","clipboard-write"], origin=URL)

    print("== Markdown page, native bridge")
    pg,msgs=load(ctx, open("md_light.html").read(), BRIDGE)
    n_code=pg.evaluate("document.querySelectorAll('pre > code').length"); n_btn=pg.evaluate("document.querySelectorAll('.code-copy').length")
    check(n_code==5 and n_btn==5,"one button per code block (fenced, no-language, indented, in a quote, in a list) - none on inline code",(n_code,n_btn))
    check(pg.evaluate("document.querySelectorAll('p > code .code-copy').length")==0,"inline code has no button")
    check(pg.evaluate("document.querySelector('.code-wrap > pre > code.language-python').querySelectorAll('span[class^=tok-]').length")>3,"syntax highlighting still runs")
    btns=pg.query_selector_all(".code-copy")
    btns[0].click(); pg.wait_for_timeout(50)
    got=pg.evaluate("window.__copied")
    check(got==[bp.PY.rstrip('\n')],"copies exactly the code (tabs, <, &, quotes, unicode intact; highlighting spans not included; trailing newline dropped)",repr(got)[:120])
    check(pg.evaluate("document.querySelector('.code-copy.copied') !== null") and pg.inner_text(".code-copy.copied")=="Copied","button confirms with a check and 'Copied'")
    check(pg.evaluate("document.querySelector('.code-copy.copied svg path') !== null"),"icon switched to the check mark")
    pg.wait_for_timeout(1800)
    check(pg.evaluate("document.querySelector('.code-copy.copied')")is None and pg.inner_text(".code-copy")=="","...and goes back to the copy icon")
    for k in (1,2,3,4):
        btns[k].click()
    pg.wait_for_timeout(50); got=pg.evaluate("window.__copied")[1:]
    check(got==["plain block without a language\nsecond line","indented code block\nline two",bp.LONG.strip(),'{"a": 1, "b": [true, null]}'],"every other block copies its own text",[g[:30] for g in got])
    check(not [m for m in msgs if "Content Security Policy" in m or "PAGEERROR" in m],"no CSP violations or script errors",msgs)
    # button stays put while a long line scrolls under it
    bash_btn=btns[3]; r0=bash_btn.bounding_box()
    pg.evaluate("document.querySelectorAll('.code-wrap > pre')[3].scrollLeft=300")
    r1=bash_btn.bounding_box()
    check(pg.evaluate("document.querySelectorAll('.code-wrap > pre')[3].scrollLeft")>0 and r0==r1,"the button stays in the corner while the code scrolls sideways")
    pg.screenshot(path="md_light.png"); pg.close()

    print("== Notebook page")
    pg,msgs=load(ctx, open("nb_light.html").read(), BRIDGE)
    check(pg.evaluate("document.querySelectorAll('.nb-cell > .code-wrap').length")==2 and pg.evaluate("document.querySelectorAll('.code-copy').length")==3,"a button on every code cell with code (2) and on the fenced block in a markdown cell (1); none on the empty cell or on outputs")
    check(pg.evaluate("document.querySelectorAll('pre.nb-out .code-copy, .nb-out .code-copy').length")==0,"outputs have no button")
    pg.query_selector_all(".code-copy")[2].click(); pg.wait_for_timeout(50)
    check(pg.evaluate("window.__copied")==["import numpy as np\nnp.arange(10).reshape(2, 5)"],"copies the cell's source only (not its prompt or output)",pg.evaluate("window.__copied"))
    # layout: the wrapper must keep the original cell spacing (prompt, code, output stack)
    gap=pg.evaluate("(function(){var c=document.querySelectorAll('.nb-cell')[0];var w=c.querySelector('.code-wrap');var o=c.querySelector('.nb-out');return o.getBoundingClientRect().top-w.getBoundingClientRect().bottom})()")
    check(3<=gap<=5,"cell spacing unchanged (4px between code and output)",gap)
    check(not [m for m in msgs if "Content Security Policy" in m or "PAGEERROR" in m],"no CSP violations or script errors",msgs)
    pg.screenshot(path="nb_light.png"); pg.close()

    print("== Dark theme")
    open("md_dark.html","w").write(bp.page(bp.md.render(bp.MARKDOWN),True)); pg,_=load(ctx, open("md_dark.html").read(), BRIDGE); pg.screenshot(path="md_dark.png"); pg.close()

    print("== No native bridge: the browser clipboard API (secure context, as in the app)")
    pg,msgs=load(ctx, open("md_light.html").read(), None)
    pg.query_selector_all(".code-copy")[1].click(); pg.wait_for_timeout(200)
    txt=pg.evaluate("navigator.clipboard.readText()")
    check(txt=="plain block without a language\nsecond line","falls back to navigator.clipboard",repr(txt)[:80]); pg.close()

    print("== No bridge and no clipboard API: select-and-copy fallback")
    pg,msgs=load(ctx, open("md_light.html").read(), NOBRIDGE_NOAPI)
    pg.query_selector_all(".code-copy")[0].click(); pg.wait_for_timeout(200)
    ec=pg.evaluate("window.__ec")
    check(ec==[bp.PY.rstrip('\n')],"falls back to execCommand('copy') with the right text",repr(ec)[:80])
    check(pg.inner_text(".code-copy")=="Copied","...and reports success"); pg.close()

    print("== Everything refused: honest failure")
    pg,msgs=load(ctx, open("md_light.html").read(), "window.AppClipboard={copy:function(){return false}}; Object.defineProperty(navigator,'clipboard',{value:{writeText:function(){return Promise.reject(new Error('no'))}},configurable:true}); document.execCommand=function(){return false};")
    pg.query_selector_all(".code-copy")[0].click(); pg.wait_for_timeout(300)
    check(pg.inner_text(".code-copy.failed")=="Copy failed","shows 'Copy failed' instead of pretending","" ); pg.close()

    print("== Tapping the button does not trigger other page behaviour")
    pg,msgs=load(ctx, open("md_light.html").read(), BRIDGE)
    y0=pg.evaluate("window.scrollY"); pg.query_selector_all(".code-copy")[0].click(); check(pg.evaluate("window.scrollY")==y0,"no scroll or navigation on tap"); pg.close()
    b.close()
print("ALL PASSED" if ok else "FAILED")
