"""Assemble viewer pages the way ViewerRenderer.page() does."""
import html, json
from markdown_it import MarkdownIt
ASSETS="../../app/src/main/assets/viewer/"
CSS=open(ASSETS+"github.css").read(); JS=open(ASSETS+"viewer.js").read()
md=MarkdownIt("commonmark")
NONCE="n0nce123456789"
def page(body, dark=False):
    csp=f"default-src 'none'; img-src data:; style-src 'unsafe-inline'; script-src 'nonce-{NONCE}'; font-src data:; base-uri 'none'; form-action 'none'"
    return f'''<!DOCTYPE html>
<html data-theme="{'dark' if dark else 'light'}"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=0.5, maximum-scale=5, user-scalable=yes">
<meta http-equiv="Content-Security-Policy" content="{csp}">
<style>{CSS}</style></head>
<body><article class="markdown-body">{body}</article>
<script nonce="{NONCE}">{JS}</script></body></html>'''

PY = 'def greet(name: str) -> str:\n    """Say hi & <welcome>."""\n    if name == "world":\n\treturn \'tab-indented\'  # keep the tab\n    return f"Hello, {name}! ünïcode ✓"\n'
LONG = "echo " + "very-long-argument-" * 14 + "\n"
MARKDOWN = f"""# Title

Intro with `inline code` that must not get a button.

```python
{PY}```

```
plain block without a language
second line
```

{chr(10).join('    ' + l for l in ['indented code block', 'line two'])}

> quote with a block:
>
> ```bash
> {LONG.strip()}
> ```

- list item

  ```json
  {{"a": 1, "b": [true, null]}}
  ```

Last paragraph.
"""
def esc(s): return html.escape(s, quote=False)
def notebook():
    cells=[
      ("md", "## Notebook\n\nSome text and a fenced block:\n\n```sql\nSELECT * FROM t WHERE a < 3 AND b > 2;\n```\n"),
      ("code", 1, PY, "hello\n"),
      ("code", 2, "import numpy as np\nnp.arange(10).reshape(2, 5)\n", "array([[0, 1, 2, 3, 4],\n       [5, 6, 7, 8, 9]])"),
      ("code", None, "", ""),
    ]
    out=[]
    for c in cells:
        if c[0]=="md": out.append('<section class="nb-md">'+md.render(c[1])+'</section>')
        else:
            prompt = f"[{c[1]}]" if c[1] else "[ ]"
            out.append(f'<div class="nb-cell"><div class="nb-prompt">In {prompt}</div><pre><code class="language-python">{esc(c[2])}</code></pre>')
            if c[3]: out.append(f'<pre class="nb-out">{esc(c[3])}</pre>')
            out.append('</div>')
    return "".join(out)
if __name__=="__main__":
    open("md_light.html","w").write(page(md.render(MARKDOWN),False)); open("nb_light.html","w").write(page(notebook(),False))
    print("pages written;", len(md.render(MARKDOWN)), len(notebook()))
