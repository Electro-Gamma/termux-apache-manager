import random, model
from collections import Counter
from session_sim import *
def run(seed, ed3_works=True):
    random.seed(seed)
    if not ed3_works:
        orig=model.Term._csi
        def csi(self,p,f):
            if f=="J" and p.split(";")[0]=="3": 
                # engine ignores ESC[3J: only the screen part is erased by ESC[2J
                return
            return orig(self,p,f)
        model.Term._csi=csi
    s=Sim(random.choice([40,80,100]),random.choice([24,30,40])); N=0; bad=[]
    for step in range(60):
        r=random.random()
        if r<0.5:
            for _ in range(random.randint(1,12)):
                N+=1; w=random.randint(8,110)
                col=random.choice(["\x1b[31m","\x1b[1;32m","\x1b[0m","\x1b[38;5;208m",""])
                s.output(f"{col}L{N:04d}:"+"x"*(w-6)+"\x1b[0m\r\n")
        elif r<0.55:
            s.output("$ typing"); s.output("\b\b\b\x1b[K"); s.output("ing\r\n")      # prompt editing
        else:
            c=random.choice([22,28,31,36,40,45,55,64,80,90,120]); rr=random.choice([20,24,30,36])
            s.resize(c,rr); s.settle()
        lg=[l for l in s.term.logical() if l.startswith("L")]
        nums=[int(l[1:5]) for l in lg]
        for l in lg:
            if "x"*(len(l)-6)!=l[6:]: bad.append(("damaged",step,l[:20]))
        dups=[k for k,v in Counter(nums).items() if v>1]
        if dups: bad.append(("dup",step,dups[:3]))
        if nums!=sorted(nums): bad.append(("order",step))
        if nums and nums[-1]!=N: bad.append(("tail",step,nums[-1],N))
    return bad, N
fails=0
for seed in range(40):
    bad,N=run(seed)
    if bad: fails+=1; print("seed",seed,bad[:3])
print(f"ED3 honoured: {40-fails}/40 random sessions with no damaged/duplicated/missing lines")
import importlib; importlib.reload(model)
import session_sim; importlib.reload(session_sim)
from session_sim import Sim as _S
fails2=0; kinds=Counter()
for seed in range(40):
    bad,N=run(seed,ed3_works=False)
    for b in bad: kinds[b[0]]+=1
    fails2+= bool(bad)
print(f"ED3 ignored by the engine: {40-fails2}/40 clean; kinds of problem: {dict(kinds)}")
