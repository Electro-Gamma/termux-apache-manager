from transcript import *
def feed(t,s): return t.append(s.encode() if isinstance(s,str) else s)
ok=True
def check(c,name):
    global ok; print(("[ok]   " if c else "[FAIL] ")+name); ok &= bool(c)

# ---- the six existing Kotlin tests, unchanged
t=TranscriptBuffer(); [feed(t,f"line {i}\r\n") for i in range(500)]
L=t.text().split("\n"); check(len(L)==500 and L[0]=="line 0" and L[-1]=="line 499","existing: keeps more than one screen")
t=TranscriptBuffer(); feed(t,"\x1b]0;title\x07\x1b[1;32mok\x1b[0m done\r\n"); check(t.text()=="ok done","existing: strips colour and title sequences")
t=TranscriptBuffer(); feed(t,"ls -x\b\x1b[K\r\n"); check(t.text()=="ls -","existing: backspace editing")
t=TranscriptBuffer(); feed(t,"10%\r50%\r100%\r\n"); check(t.text()=="100%","existing: carriage return overwrites")
t=TranscriptBuffer(); b="é\r\n".encode(); t.append(b[0:1]); t.append(b[1:]); check(t.text()=="é","existing: multibyte split across chunks")
t=TranscriptBuffer(maxChars=50); [feed(t,f"row {i}\r\n") for i in range(100)]; check(t.text().split("\n")[-1]=="row 99" and len(t.text())<=60,"existing: drops oldest past the limit")

# ---- clear
CLR="\x1b[H\x1b[2J\x1b[3J"
t=TranscriptBuffer(); feed(t,"welcome\r\n$ ls\r\na b c\r\n$ clear\r\n"); fl=feed(t,CLR+"$ "); 
check(fl&FULL_CLEAR,"clear: reported as a full clear"); check(t.text()=="$","clear: copy buffer is only what came after")
feed(t,"echo hi\r\nhi\r\n$ "); check(t.text()=="$ echo hi\nhi\n$","clear: new output is captured from zero")
t=TranscriptBuffer(); feed(t,"old\r\n"); feed(t,"\x1b[H\x1b[2J"); check(t.text()=="","clear: ESC[H ESC[2J alone (older terminfo) empties it")
t=TranscriptBuffer(); feed(t,"old\r\n"); feed(t,"\x1b[H\x1b[J"); check(t.text()=="","clear: ESC[H ESC[J (linux terminfo) empties it")
t=TranscriptBuffer(); feed(t,"keep\r\nsome text"); feed(t,"\x1b[J"); check(t.text()=="keep\nsome text","erase-below alone does not wipe the record")
t=TranscriptBuffer(); feed(t,"old\r\n"); feed(t,"\x1b[H"); feed(t,"x"); feed(t,"\x1b[J"); check("old" in t.text(),"home then text then ESC[J is not a clear")
t=TranscriptBuffer(); feed(t,"old\r\n"); fl=feed(t,"\x1bc$ "); check(fl&FULL_CLEAR and t.text()=="$","RIS (ESC c / reset) empties it")
t=TranscriptBuffer(); feed(t,"old\r\n"); feed(t,"\x1b[H\x1b[2"); feed(t,"J\x1b[3"); feed(t,"Jnew\r\n"); check(t.text()=="new","clear sequence split across chunks")
# clear end offset for splitting the chunk fed to the emulator
t=TranscriptBuffer(); data=("before\r\n"+CLR+"after\r\n").encode(); fl=t.append(data); e=t.lastClearEnd()
check(data[:e].endswith(b"\x1b[3J") and data[e:]==b"after\r\n","clear: offset splits the chunk exactly after the clear")
t=TranscriptBuffer(); data=("é\r\n"+CLR+"é!").encode(); t.append(data); e=t.lastClearEnd(); check(data[e:]=="é!".encode(),"clear: offset is a byte offset (UTF-8 before it)")
# colours survive a clear
t=TranscriptBuffer(); feed(t,"\x1b[31m"); feed(t,CLR); feed(t,"red\r\n"); check(t.lines[0]=="\x1b[0;31mred\x1b[0m","clear keeps the active colour for what follows")

# ---- alternate screen
t=TranscriptBuffer(); feed(t,"$ vim\r\n"); feed(t,"\x1b[?1049h\x1b[H\x1b[2Jjunk\x1b[5;5Hmore junk\r\n"); check(t.isAltScreen() and t.text()=="$ vim","alt screen: not recorded, and its clear does not wipe the record")
fl=feed(t,"\x1b[?1049l$ "); check((fl&ALT_LEFT) and not t.isAltScreen() and t.text()=="$ vim\n$","alt screen: recording resumes on exit (reported)")
t=TranscriptBuffer(); feed(t,"x\r\n\x1b[?1049h"); t.newConnection(); check(not t.isAltScreen(),"new connection leaves the alt screen")
t=TranscriptBuffer(); feed(t,"a\r\n\x1b[?1049h"); feed(t,"\x1bc"); check(not t.isAltScreen() and t.text()=="","RIS also leaves the alt screen")
# programs that use ESC 7/8 in the alt screen must not spoil replay afterwards
t=TranscriptBuffer(); feed(t,"x\r\n\x1b[?1049h\x1b7\x1b8\x1bM\x1b[?1049l"); check(t.replayAll(40) is not None,"alt-screen ESC 7/8/M do not mark the record unfaithful")

# ---- faithful / unfaithful
t=TranscriptBuffer(); feed(t,"a\r\n\x1b[1;24r"); check(t.replayAll(40) is None,"scroll region on the normal screen: replay declines")
for i in range(301): feed(t,f"l{i}\r\n")
check(t.replayAll(40) is not None,"...and is allowed again after 300 more lines")
t=TranscriptBuffer(); feed(t,"a\r\n\x1b[1;24r"); feed(t,CLR); feed(t,"b"); check(t.replayAll(40) is not None,"a clear removes the disturbance")

# ---- colours
t=TranscriptBuffer(); feed(t,"\x1b[1;38;5;12mA\x1b[0m B \x1b[48;2;1;2;3mC\x1b[49m\r\n"); print(repr(t.lines[0])); check(t.lines[0]=="\x1b[0;1;38;5;12mA\x1b[0m B \x1b[0;48;2;1;2;3mC\x1b[0m" and t.text()=="A B C","colour runs are kept per character, plain text stays plain")
print("ALL PASSED" if ok else "FAILED")
