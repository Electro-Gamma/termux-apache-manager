"""A small reference terminal: fixed grid, deferred autowrap, scrollback, NO reflow (cuts lines on shrink)."""
import re
class Term:
    def __init__(s, cols, rows):
        s.cols, s.rows = cols, rows
        s.grid=[[" "]*cols for _ in range(rows)]; s.wrap=[False]*rows   # wrap[r]: row r continues on r+1
        s.r=s.c=0; s.pending=False; s.sb=[]; s.sbwrap=[]
        s.esc=None
    def _push_top(s):
        s.sb.append("".join(s.grid[0]).rstrip()); s.sbwrap.append(s.wrap[0])
        s.grid.pop(0); s.wrap.pop(0); s.grid.append([" "]*s.cols); s.wrap.append(False)
    def _lf(s):
        if s.r==s.rows-1: s._push_top()
        else: s.r+=1
    def feed(s, data):
        if isinstance(data,bytes): data=data.decode("utf-8","replace")
        for ch in data:
            if s.esc is not None:
                s.esc+=ch
                if s.esc.startswith("\x1b[") and len(s.esc)>2 and "@"<=ch<="~": s._csi(s.esc[2:-1], ch); s.esc=None
                elif not s.esc.startswith("\x1b[") and len(s.esc)>=2 and ch!="[": s.esc=None
                continue
            if ch=="\x1b": s.esc="\x1b"
            elif ch=="\r": s.c=0; s.pending=False
            elif ch=="\n": s._lf(); s.pending=False
            elif ch=="\b": s.c=max(0,s.c-1); s.pending=False
            elif ch>=" ":
                if s.pending:
                    s.wrap[s.r]=True; s._lf(); s.c=0; s.pending=False
                s.grid[s.r][s.c]=ch
                if s.c==s.cols-1: s.pending=True
                else: s.c+=1
    def _csi(s, p, f):
        n=int(p.split(";")[0]) if p.split(";")[0].isdigit() else None
        if f=="H": s.r=s.c=0; s.pending=False
        elif f=="J":
            k=n or 0
            if k in (2,3) or k==0:
                if k==0:
                    for c in range(s.c,s.cols): s.grid[s.r][c]=" "
                    for r in range(s.r+1,s.rows): s.grid[r]=[" "]*s.cols; s.wrap[r]=False
                else:
                    s.grid=[[" "]*s.cols for _ in range(s.rows)]; s.wrap=[False]*s.rows
                if k==3: s.sb=[]; s.sbwrap=[]
        elif f=="K":
            k=n or 0
            if k==0:
                for c in range(s.c,s.cols): s.grid[s.r][c]=" "
            elif k==2: s.grid[s.r]=[" "]*s.cols
        elif f=="C": s.c=min(s.cols-1,s.c+(n or 1)); s.pending=False
        elif f=="D": s.c=max(0,s.c-(n or 1)); s.pending=False
        # SGR and everything else: ignored by the model
    def resize(s, cols, rows):
        # columns: cut or pad every row (no reflow)
        for r in range(s.rows):
            row=s.grid[r]; s.grid[r]=(row[:cols] if cols<len(row) else row+[" "]*(cols-len(row)))
        s.cols=cols; s.c=min(s.c,cols-1); s.pending=False
        # rows: shrink pushes top rows to scrollback while the cursor would fall off; grow adds blank rows at the bottom
        while s.rows>rows and s.r>=rows: s._push_top(); s.r-=1; s.rows-=1; 
        while s.rows>rows: s.grid.pop(); s.wrap.pop(); s.rows-=1
        while s.rows<rows: s.grid.append([" "]*s.cols); s.wrap.append(False); s.rows+=1
    def screen(s): return ["".join(r).rstrip() for r in s.grid]
    def logical(s):
        """scrollback + screen as logical lines (rows joined where the model recorded a wrap)."""
        rows=[(t,w) for t,w in zip(s.sb,s.sbwrap)]+[("".join(g).rstrip() if not w else "".join(g), w) for g,w in zip(s.grid,s.wrap)]
        out=[]; cur=""; 
        for t,w in rows:
            cur+=t
            if not w: out.append(cur); cur=""
        if cur: out.append(cur)
        while out and out[-1]=="": out.pop()
        return out
