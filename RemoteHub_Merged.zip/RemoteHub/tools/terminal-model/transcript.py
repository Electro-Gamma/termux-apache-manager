"""Line-for-line port of TranscriptBuffer.kt (for testing the logic; the Kotlin is what ships)."""
import re
FULL_CLEAR, ALT_LEFT = 1, 2
TAB, MAX_LINE, MAX_STYLES, REPL, TAINT_LINES = 8, 65536, 4096, 0xFFFD, 300

class Sgr:
    def __init__(s): s.reset()
    def reset(s):
        s.bold=s.dim=s.italic=s.underline=s.blink=s.inverse=s.hidden=s.strike=False; s.fg=s.bg=None
    def code(s):
        p=[]
        for flag,c in ((s.bold,"1"),(s.dim,"2"),(s.italic,"3"),(s.underline,"4"),(s.blink,"5"),(s.inverse,"7"),(s.hidden,"8"),(s.strike,"9")):
            if flag: p.append(c)
        if s.fg: p.append(s.fg)
        if s.bg: p.append(s.bg)
        return ";".join(p)

class TranscriptBuffer:
    TEXT,ESC,CSI,STRING,STRING_ESC,SKIP_ONE = range(6)
    def __init__(s, maxChars=4_000_000):
        s.maxChars=maxChars; s.lines=[]; s.storedChars=0; s.lineCounter=0
        s.cc=[]; s.cs=[]; s.len=0; s.column=0
        s.mode=s.TEXT; s.params=""
        s.sgr=Sgr(); s.styleNow=0; s.styleIds={}; s.styleCodes=[""]
        s.utf8Need=0; s.utf8Code=0
        s.altScreen=False; s.homePending=False; s.taintedAtLine=-(1<<62)
        s.clearEnd=-1; s.chunkFlags=0; s.offsetAfterChar=0
    # --- api
    def append(s, data, length=None):
        length=len(data) if length is None else length
        if length<=0: return 0
        s.clearEnd=-1; s.chunkFlags=0; i=0
        while i<length:
            b=data[i]; s.offsetAfterChar=i+1
            if s.utf8Need>0:
                if (b&0xC0)==0x80:
                    s.utf8Code=(s.utf8Code<<6)|(b&0x3F); s.utf8Need-=1
                    if s.utf8Need==0: s.emit(s.utf8Code)
                    i+=1; continue
                s.utf8Need=0; s.emit(REPL)
            if b<0x80: s.emit(b)
            elif 0xC2<=b<=0xDF: s.utf8Need=1; s.utf8Code=b&0x1F
            elif 0xE0<=b<=0xEF: s.utf8Need=2; s.utf8Code=b&0x0F
            elif 0xF0<=b<=0xF4: s.utf8Need=3; s.utf8Code=b&0x07
            else: s.emit(REPL)
            i+=1
        return s.chunkFlags
    def lastClearEnd(s): return s.clearEnd
    def text(s):
        out="".join(s.plain(l)+"\n" for l in s.lines)+s.trimmedCurrent()
        return out.rstrip("\n ")
    def clear(s):
        s.clearAll(); s.mode=s.TEXT; s.params=""; s.utf8Need=0; s.altScreen=False; s.sgr.reset(); s.styleNow=0
    def newConnection(s):
        s.mode=s.TEXT; s.params=""; s.utf8Need=0; s.altScreen=False; s.homePending=False
    def isAltScreen(s): return s.altScreen
    def replayAll(s, columns, maxLines=5000):
        if s.altScreen or columns<2: return None
        if s.lineCounter-s.taintedAtLine<=TAINT_LINES: return None
        if not s.lines and s.len==0 and s.column==0: return None
        out="\x1b[0m\x1b[H\x1b[2J\x1b[3J"
        for k in range(max(0,len(s.lines)-maxLines),len(s.lines)): out+=s.lines[k]+"\r\n"
        out+=s.styledRange(0,s.len)
        if max(s.len,s.column)<columns:
            if s.column<s.len: out+="\x1b["+str(s.len-s.column)+"D"
            elif s.column>s.len: out+="\x1b["+str(s.column-s.len)+"C"
        out+=s.sgrSequence(s.styleCodes[s.styleNow])
        return out.encode("utf-8")
    # --- decoding
    def emit(s, code):
        cp=REPL if (code>0x10FFFF or 0xD800<=code<=0xDFFF) else code
        s.feed(chr(cp))
    def feed(s, c):
        m=s.mode
        if m==s.TEXT: s.text_(c)
        elif m==s.ESC:
            if c=='[': s.mode=s.CSI; s.params=""
            elif c in ']P^_X': s.mode=s.STRING
            elif c in "()*+#%": s.mode=s.SKIP_ONE
            elif c=='c': s.fullReset(); s.mode=s.TEXT
            elif c in '78DEM': s.taint(); s.mode=s.TEXT
            else: s.mode=s.TEXT
        elif m==s.SKIP_ONE: s.mode=s.TEXT
        elif m==s.CSI:
            if '\u0020'<=c<='\u003F':
                if len(s.params)<32: s.params+=c
            elif '\u0040'<=c<='\u007E': s.csi(c); s.mode=s.TEXT
            else: s.mode=s.TEXT
        elif m==s.STRING:
            if c=='\u0007': s.mode=s.TEXT
            elif c=='\u001b': s.mode=s.STRING_ESC
        elif m==s.STRING_ESC: s.mode=s.TEXT if c=='\\' else s.STRING
    def text_(s, c):
        if c=='\u001b': s.mode=s.ESC
        elif s.altScreen: pass
        elif c=='\n': s.homePending=False; s.commitLine()
        elif c=='\r': s.column=0
        elif c=='\b':
            if s.column>0: s.column-=1
        elif c=='\t':
            nxt=(s.column//TAB+1)*TAB
            while s.column<nxt: s.put(' ')
        elif c<' ' or c=='\u007f': pass
        else: s.homePending=False; s.put(c)
    def put(s, c):
        if s.column>=MAX_LINE: s.commitLine()
        while len(s.cc)<s.column+1: s.cc.append(' '); s.cs.append(0)
        while s.len<s.column: s.cc[s.len]=' '; s.cs[s.len]=0; s.len+=1
        if s.column<s.len: s.cc[s.column]=c; s.cs[s.column]=s.styleNow
        else: s.cc[s.len]=c; s.cs[s.len]=s.styleNow; s.len+=1
        s.column+=1
    # --- escape sequences
    def csi(s, final):
        p=s.params
        if p.startswith("?"):
            if final in "hl": s.privateMode(p, final=='h')
            return
        if p[:1] in (">","<","="): return
        if s.altScreen: return
        head=p.split(';')[0]; n=int(head) if head.isdigit() else None
        if final not in "HJ": s.homePending=False
        if final=='m': s.applySgr(p)
        elif final=='K':
            k=n or 0
            if k==0:
                if s.column<s.len: s.len=s.column
            elif k==1:
                for i in range(min(s.column+1,s.len)): s.cc[i]=' '; s.cs[i]=0
            elif k==2: s.len=0
        elif final=='C': s.column+=min(max(n if n is not None else 1,1),500)
        elif final=='D': s.column=max(s.column-min(max(n if n is not None else 1,1),500),0)
        elif final=='G': s.column=min(max((n if n is not None else 1)-1,0),500)
        elif final=='P':
            count=max(n if n is not None else 1,1)
            if s.column<s.len:
                gone=min(count,s.len-s.column)
                del s.cc[s.column:s.column+gone]; del s.cs[s.column:s.column+gone]
                s.cc+= [' ']*gone; s.cs+=[0]*gone; s.len-=gone
        elif final=='@':
            count=min(max(n if n is not None else 1,1),500)
            while s.len<s.column:
                if s.len>=len(s.cc): s.cc.append(' '); s.cs.append(0)
                s.cc[s.len]=' '; s.cs[s.len]=0; s.len+=1
            s.cc[s.column:s.column]=[' ']*count; s.cs[s.column:s.column]=[0]*count; s.len+=count
        elif final in "Hf":
            home = p in ("","1","1;1",";","1;")
            if home: s.homePending=True
            else: s.homePending=False; s.taint()
        elif final=='J':
            what=n or 0
            if what in (2,3) or (what==0 and s.homePending):
                s.clearAll(); s.clearEnd=s.offsetAfterChar; s.chunkFlags|=FULL_CLEAR
            s.homePending=False
        elif final in "rLMSTdEFsu": s.taint()
    def privateMode(s, p, st):
        for part in p[1:].split(';'):
            if part.isdigit() and int(part) in (47,1047,1049):
                if s.altScreen!=st:
                    s.altScreen=st
                    if st: s.homePending=False
                    else: s.chunkFlags|=ALT_LEFT
    def taint(s):
        if not s.altScreen: s.taintedAtLine=s.lineCounter
    def applySgr(s, p):
        lst=[0] if p=="" else [int(x) if x.isdigit() else 0 for x in p.replace(':',';').split(';')]
        g=s.sgr; i=0
        while i<len(lst):
            n=lst[i]
            if n==0: g.reset()
            elif n==1: g.bold=True
            elif n==2: g.dim=True
            elif n==3: g.italic=True
            elif n==4: g.underline=True
            elif n in (5,6): g.blink=True
            elif n==7: g.inverse=True
            elif n==8: g.hidden=True
            elif n==9: g.strike=True
            elif n==22: g.bold=False; g.dim=False
            elif n==23: g.italic=False
            elif n==24: g.underline=False
            elif n==25: g.blink=False
            elif n==27: g.inverse=False
            elif n==28: g.hidden=False
            elif n==29: g.strike=False
            elif 30<=n<=37 or 90<=n<=97: g.fg=str(n)
            elif n==39: g.fg=None
            elif 40<=n<=47 or 100<=n<=107: g.bg=str(n)
            elif n==49: g.bg=None
            elif n in (38,48):
                kind=lst[i+1] if i+1<len(lst) else None
                if kind==5 and i+2<len(lst):
                    code=f"{n};5;{lst[i+2]}"
                    if n==38: g.fg=code
                    else: g.bg=code
                    i+=2
                elif kind==2 and i+4<len(lst):
                    code=f"{n};2;{lst[i+2]};{lst[i+3]};{lst[i+4]}"
                    if n==38: g.fg=code
                    else: g.bg=code
                    i+=4
                else: i=len(lst)
            i+=1
        s.styleNow=s.idFor(g.code())
    def idFor(s, code):
        if code=="": return 0
        if code in s.styleIds: return s.styleIds[code]
        if len(s.styleCodes)>=MAX_STYLES: return 0
        s.styleCodes.append(code); s.styleIds[code]=len(s.styleCodes)-1; return len(s.styleCodes)-1
    # --- lines
    def commitLine(s):
        line=s.styledRange(0,s.currentEnd()); s.lines.append(line); s.lineCounter+=1
        s.storedChars+=len(line)+1; s.len=0; s.column=0
        while s.storedChars>s.maxChars and len(s.lines)>1:
            s.storedChars-=len(s.lines.pop(0))+1
    def currentEnd(s):
        e=s.len
        while e>0 and s.cc[e-1].isspace(): e-=1
        return e
    def trimmedCurrent(s): return "".join(s.cc[:s.currentEnd()])
    def styledRange(s, a, b):
        out=[]; last=0
        for k in range(a,b):
            if s.cs[k]!=last: last=s.cs[k]; out.append(s.sgrSequence(s.styleCodes[last]))
            out.append(s.cc[k])
        if last!=0: out.append("\x1b[0m")
        return "".join(out)
    def sgrSequence(s, code): return "\x1b[0m" if code=="" else "\x1b[0;"+code+"m"
    def plain(s, line):
        return re.sub(r"\x1b\[[0-9;]*m","",line) if "\x1b" in line else line
    def plainLength(s, line): return len(s.plain(line))
    def rowsFor(s, width, columns): return 1 if width<=columns else (width+columns-1)//columns
    def clearAll(s):
        s.lines=[]; s.storedChars=0; s.len=0; s.column=0; s.homePending=False; s.taintedAtLine=-(1<<62)
    def fullReset(s):
        s.clearAll(); s.altScreen=False; s.sgr.reset(); s.styleNow=0
        s.clearEnd=s.offsetAfterChar; s.chunkFlags|=FULL_CLEAR
