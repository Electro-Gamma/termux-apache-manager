import random
from session_sim import *
ok=True
def check(c,name,extra=""):
    global ok; print(("[ok]   " if c else "[FAIL] ")+name+(("   "+extra) if extra and not c else "")); ok&=bool(c)

MOTD=["Welcome to Termux!","","Docs:       https://termux.dev/docs","Donate:     https://termux.dev/donate","","Working with packages:","",
      " - Search:  pkg search <query>"," - Install: pkg install <package>"," - Upgrade: pkg upgrade","",
      "Subscribing to additional repositories:",""," - Root:    pkg install root-repo"," - X11:     pkg install x11-repo","",
      "For fixing any repository issues,","try 'termux-change-repo' command.","","Report issues at https://termux.dev/issues"]
def motd(sim):
    for l in MOTD: sim.output(l+"\r\n")
    sim.output("\x1b[32m┌──(user㉿host)-[~]\x1b[0m\r\n\x1b[32m└─$\x1b[0m ")

print("== Reproduce the report (model without the fix): 80-col output, then zoom in, then back out")
for fix in (False, True):
    s=Sim(80,24,fix=fix); motd(s)
    for (c,r) in [(31,24),(40,24)]:
        s.resize(c,r); s.settle()
    text="\n".join(s.term.screen())
    cut = "Subscribing to additional repositories:" not in text and "pkg install root-repo" not in text
    print(f"   fix={fix}: 'Subscribing to additional repositories:' visible whole = {'Subscribing to additional repositories:' in ''.join(l for l in s.term.logical())}")
    if not fix: check(cut or "Subscribing to additional repositories:" not in "\n".join(s.term.logical()),"without the fix the model loses text on a shrink (reproduces the report)")
    else:
        logical=s.term.logical()
        check(all(any(l.strip()==m.strip() for l in logical) for m in MOTD if m),"with the fix every MOTD line is intact after 80->31->40")
        check(logical.count("Welcome to Termux!")==1,"...and nothing is duplicated")

print("== Round trip: back at the original width the screen is the original")
s=Sim(80,24); motd(s); before=s.term.screen()
for c in (31,60,45,31,80): s.resize(c,24); s.settle()
check(s.term.screen()==before,"80 -> 31 -> 60 -> 45 -> 31 -> 80 gives the original screen back", "\n".join(s.term.screen()))

print("== Long session with scrolling, many zoom changes, interleaved output")
random.seed(7)
s=Sim(80,24); N=0
def lines(n):
    global N
    for _ in range(n):
        N+=1; w=random.randint(10,75); s.output(f"L{N:04d}:"+"x"*(w-6)+"\r\n")
expected=[]
def expect_all():
    return [f"L{i:04d}:"+"x" for i in range(1,N+1)]
lines(60)
widths=[80,31,40,55,31,80,45,36,80,28,64]
bad=0; maxrows=0
for k,w in enumerate(widths):
    s.resize(w,24 if k%3 else 30); s.settle()
    lines(random.randint(0,15))                      # output while zoomed
    logical=[l for l in s.term.logical() if l.startswith("L")]
    nums=[int(l[1:5]) for l in logical]
    if nums!=sorted(set(nums)): bad+=1; print("   order/dup problem at step",k,w,nums[-8:])
    # every line fully intact: length matches its original (we know the pattern)
    for l in logical:
        if not l.rstrip().endswith("x") or "x"*(len(l)-6)!=l[6:]: bad+=1; print("   damaged line",repr(l)); break
check(bad==0,"no damaged lines, no duplicates, no reordering across 11 width changes")
nums=[int(l[1:5]) for l in s.term.logical() if l.startswith("L")]
check(nums==list(range(nums[0],N+1)),"scrollback + screen is one contiguous run ending at the last line", f"{nums[:3]}..{nums[-3:]} N={N}")
check(nums[0]==1,"nothing from the beginning was lost")

print("== clear, then new commands")
s=Sim(40,24); motd(s)
s.output("clear\r\n"); s.output("\x1b[H\x1b[2J\x1b[3J"+"\x1b[32m└─$\x1b[0m ")
check(s.tr.text()=="└─$","after clear the copy buffer holds just the new prompt")
check(all(l=="" for l in s.term.screen()[1:]) and s.term.sb==[],"after clear the terminal's screen and scrollback are empty too")
s.output("echo hi\r\nhi\r\n└─$ "); check(s.tr.text()=="└─$ echo hi\nhi\n└─$","new output is recorded from zero")
s.resize(31,24); s.settle(); check(s.tr.text()=="└─$ echo hi\nhi\n└─$" and "echo hi" in "".join(s.term.screen()),"zoom after clear keeps only post-clear content")

print("== full-screen program and zoom")
s=Sim(80,24); motd(s); s.output("vim\r\n\x1b[?1049h\x1b[Hscreen of vim\x1b[?1049l")
s.output("")
check("screen of vim" not in s.tr.text(),"vim's screen is not in the copy buffer")
s=Sim(80,24); motd(s); s.output("\x1b[?1049h")
s.resize(40,24); s.settle(); s.output("\x1b[?1049l"); 
check(s.term.cols==40 and s.contentCols==40,"resize during a full-screen program is applied when it exits")

print("== PTY size follows the emulator")
s=Sim(80,24); 
for c,r in [(31,24),(40,24),(1,1),(40,30)]: s.resize(c,r)
check(s.ptyLog[-1]==(40,30) and (1,1) not in s.ptyLog,"last grid is the PTY size; a degenerate 1x1 is never sent")
print("ALL PASSED" if ok else "FAILED")
