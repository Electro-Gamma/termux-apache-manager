"""What SshSession does with output and resizes (mirrors the planned Kotlin), around the reference terminal."""
from transcript import *
from model import Term
class Sim:
    def __init__(s, cols=80, rows=24, fix=True):
        s.term=Term(cols,rows); s.tr=TranscriptBuffer(); s.fix=fix
        s.contentCols=cols; s.contentRows=rows; s.pty=(cols,rows); s.ptyLog=[cols and (cols,rows)]
    def output(s, data):
        b=data.encode() if isinstance(data,str) else data
        fl=s.tr.append(b)
        if fl&FULL_CLEAR and s.tr.lastClearEnd()>0 and s.fix:
            e=s.tr.lastClearEnd(); s.term.feed(b[:e]); s.term.feed("\x1b[H\x1b[2J\x1b[3J"); s.term.feed(b[e:])   # emulator.clearScreen()
        else: s.term.feed(b)
        if fl&ALT_LEFT and s.pendingAlt: s.pendingAlt=False; s.reflow()
    pendingAlt=False
    def resize(s, cols, rows):                       # the terminal component resized its grid
        s.term.resize(cols,rows)
        if (cols,rows)!=s.pty and cols>=2 and rows>=2: s.pty=(cols,rows); s.ptyLog.append((cols,rows))
        if not s.fix: return
        if cols==s.contentCols: s.contentRows=rows   # rows only: layout unchanged
    def settle(s):                                   # the debounce elapsed
        if s.fix: s.reflow()
    def reflow(s):
        cols,rows=s.term.cols,s.term.rows
        if cols==s.contentCols: s.contentRows=rows; return
        if s.tr.isAltScreen(): s.pendingAlt=True; return
        data=s.tr.replayAll(cols)
        if data is not None: s.term.feed(data)
        s.contentCols=cols; s.contentRows=rows
