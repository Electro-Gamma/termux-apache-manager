# Terminal logic: reference model and tests

Not part of the app build. These check the logic of `TranscriptBuffer.kt` and of the resize handling in `SshSession.kt` without a
phone or the terminal library:

- `transcript.py` is a line-for-line Python port of `TranscriptBuffer.kt` (the Kotlin is what ships; keep them in step).
- `model.py` is a small reference terminal: fixed grid, autowrap, scrollback, and **no reflow** - a line is cut when the grid gets
  narrower and does not come back when it widens (what the screenshots of the zoom problem show the real emulator doing).
- `session_sim.py` mirrors what `SshSession` does with output and resizes (split at a clear, PTY size, rebuild after a width change).
- `test_transcript.py` (copy buffer, clear, full-screen programs, colours), `test_zoom.py` (the reported scenario, round trips,
  long sessions, clear + new commands), `test_fuzz.py` (40 random sessions). Run with `python3 test_*.py`.

What this does **not** prove: the real emulator (termlib / libvterm) is a prebuilt library that was not available when this was
written. The rebuild after a width change relies on it erasing its scrollback when sent `ESC[3J` (or via `clearScreen()`). If it
does not, scrolling back after a zoom shows older lines twice (the screen itself is right); the setting
"Keep text when zooming or rotating" (Settings > Terminal, advanced) turns the rebuild off. `test_fuzz.py` also runs that
worst case and shows the duplication.
