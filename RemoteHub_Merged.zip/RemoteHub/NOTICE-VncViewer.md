# Notices

## VncViewer
The Kotlin side of the engine (`app/src/main/java/com/vncviewer/app/realvnc/`) descends from a port
of the RealVNC backend of **Vento** (https://github.com/pgaskin/vento,
Copyright (C) 2026 Patrick Gaskin), which is licensed **GPL-3.0-or-later**. Because of that,
this project as a whole is distributed under the GNU General Public License v3 or later
(see `LICENSE`). If you give the built app to anyone, you must also provide the source.

## Input stack and settings (MIT / GPL-3.0-or-later)
`app/src/main/java/com/vncviewer/app/input/` is a Kotlin port of Vento's `control/` input stack
(MIT, (C) 2026 Patrick Gaskin: Config, PointerAccel, PointerInertia, HoverAssist, GestureRecognizer,
TouchRouter, Viewport, CursorController, MouseOverlay, Toolbar, PhysicalMouse, TapRegions) and of its
settings tables (`AppSettings`, `InputSettings`, GPL-3.0-or-later). The settings screens in
`ui/SettingsScreen.kt` follow Vento's settings tree and wording.

## Native VNC engine (app/src/main/cpp)
The "RealVNC" engine is `libvncviewer.so`, built by the NDK from `app/src/main/cpp/vnc/`: an independent C++
re-implementation of the RFB client that the app's JNI bindings expect (None / VNC password / RSA-AES RA2 and RA2r /
Apple ARD, RA4 handshake, ZRLE, Hextile, RRE, CopyRect, Raw), with **Mbed TLS 3.6.2** (`app/src/main/cpp/mbedtls/`,
Apache-2.0 OR GPL-2.0-or-later, see its `LICENSE`) for the cryptography. The Java declarations of its JNI surface are in
`app/src/main/java/com/realvnc/vncviewer/jni/` (the package name is the one the library resolves). No RealVNC binary is
used or bundled: nothing is downloaded, the library is compiled from the sources in this repository.

Provenance: per `native-engine/native-docs/ANALYSIS.md`, the engine's interface and behaviour were worked out by analysing the
original library (decompilation) and then re-implemented; it is therefore **not** a clean-room implementation. The decompiler
output itself is not part of this project. Whether that provenance is acceptable for your distribution is your decision.
