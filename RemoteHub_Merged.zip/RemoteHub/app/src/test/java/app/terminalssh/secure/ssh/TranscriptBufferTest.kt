package app.terminalssh.secure.ssh

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TranscriptBufferTest {
    private fun TranscriptBuffer.feed(s: String) = append(s.encodeToByteArray())

    @Test fun keepsMoreThanOneScreen() {
        val t = TranscriptBuffer()
        repeat(500) { t.feed("line $it\r\n") }
        val lines = t.text().lines()
        assertEquals(500, lines.size)
        assertEquals("line 0", lines.first())
        assertEquals("line 499", lines.last())
    }

    @Test fun stripsColourAndTitleSequences() {
        val t = TranscriptBuffer()
        t.feed("\u001b]0;title\u0007\u001b[1;32mok\u001b[0m done\r\n")
        assertEquals("ok done", t.text())
    }

    @Test fun appliesBackspaceEditing() {
        val t = TranscriptBuffer()
        t.feed("ls -x\b\u001b[K\r\n")
        assertEquals("ls -", t.text())
    }

    @Test fun carriageReturnOverwrites() {
        val t = TranscriptBuffer()
        t.feed("10%\r50%\r100%\r\n")
        assertEquals("100%", t.text())
    }

    @Test fun joinsMultiByteCharactersSplitAcrossChunks() {
        val t = TranscriptBuffer()
        val bytes = "é\r\n".encodeToByteArray()
        t.append(bytes.copyOfRange(0, 1)); t.append(bytes.copyOfRange(1, bytes.size))
        assertEquals("é", t.text())
    }

    @Test fun dropsOldestLinesPastTheLimit() {
        val t = TranscriptBuffer(maxChars = 50)
        repeat(100) { t.feed("row $it\r\n") }
        assert(t.text().lines().last() == "row 99")
        assert(t.text().length <= 60)
    }

    // ---- clear: the record follows the screen -------------------------------------------------

    private val clear = "\u001b[H\u001b[2J\u001b[3J"

    @Test fun clearEmptiesTheCopyBufferAndNewOutputStartsFromZero() {
        val t = TranscriptBuffer()
        t.feed("welcome\r\n$ ls\r\na b c\r\n$ clear\r\n")
        val flags = t.feed("$clear$ ")
        assertTrue((flags and TranscriptBuffer.FULL_CLEAR) != 0)
        assertEquals("$", t.text())
        t.feed("echo hi\r\nhi\r\n$ ")
        assertEquals("$ echo hi\nhi\n$", t.text())
    }

    @Test fun olderClearSpellingsAlsoEmptyIt() {
        for (seq in listOf("\u001b[H\u001b[2J", "\u001b[H\u001b[J", "\u001bc")) {
            val t = TranscriptBuffer()
            t.feed("old\r\n")
            t.feed(seq)
            assertEquals(seq, "", t.text())
        }
    }

    @Test fun eraseBelowAloneIsNotAClear() {
        val t = TranscriptBuffer()
        t.feed("keep\r\nsome text")
        t.feed("\u001b[J")
        assertEquals("keep\nsome text", t.text())
    }

    @Test fun aClearSplitAcrossChunksIsStillRecognised() {
        val t = TranscriptBuffer()
        t.feed("old\r\n")
        t.feed("\u001b[H\u001b[2"); t.feed("J\u001b[3"); t.feed("Jnew\r\n")
        assertEquals("new", t.text())
    }

    @Test fun clearOffsetSplitsTheChunkExactly() {
        val t = TranscriptBuffer()
        val data = ("é\r\n" + clear + "after\r\n").encodeToByteArray()
        t.append(data)
        val end = t.lastClearEnd()
        assertEquals(clear, String(data, 0, end).substringAfter("\r\n"))
        assertEquals("after\r\n", String(data, end, data.size - end))
    }

    // ---- full-screen programs ---------------------------------------------------------------

    @Test fun fullScreenProgramsAreNotRecordedAndTheirClearsDoNotWipeTheRecord() {
        val t = TranscriptBuffer()
        t.feed("$ vim\r\n")
        t.feed("\u001b[?1049h\u001b[H\u001b[2Jjunk\u001b[5;5Hmore\r\n")
        assertTrue(t.isAltScreen())
        assertEquals("$ vim", t.text())
        val flags = t.feed("\u001b[?1049l$ ")
        assertTrue((flags and TranscriptBuffer.ALT_LEFT) != 0)
        assertFalse(t.isAltScreen())
        assertEquals("$ vim\n$", t.text())
    }

    @Test fun aNewConnectionStartsOnTheNormalScreen() {
        val t = TranscriptBuffer()
        t.feed("x\r\n\u001b[?1049h")
        t.newConnection()
        assertFalse(t.isAltScreen())
    }

    // ---- rebuilding the terminal after a width change ------------------------------------------

    @Test fun replayWritesEveryLineWholeWithItsColours() {
        val t = TranscriptBuffer()
        t.feed("\u001b[31mred line that is longer than forty columns wide, for sure\u001b[0m\r\nplain\r\n$ ")
        val out = String(t.replayAll(columns = 40)!!, Charsets.UTF_8)
        assertTrue(out.startsWith("\u001b[0m\u001b[H\u001b[2J\u001b[3J"))
        assertTrue(out.contains("\u001b[0;31mred line that is longer than forty columns wide, for sure\u001b[0m\r\nplain\r\n$ "))
    }

    @Test fun replayKeepsTheCursorWhereItWas() {
        val t = TranscriptBuffer()
        t.feed("$ abc\u001b[2D")
        val out = String(t.replayAll(columns = 40)!!, Charsets.UTF_8)
        assertTrue(out.contains("$ abc\u001b[2D"))
    }

    @Test fun replayDeclinesWhileAFullScreenProgramRunsOrWhenTheRecordIsDisturbed() {
        val t = TranscriptBuffer()
        t.feed("a\r\n\u001b[?1049h")
        assertNull(t.replayAll(columns = 40))
        val u = TranscriptBuffer()
        u.feed("a\r\n\u001b[1;24r")
        assertNull(u.replayAll(columns = 40))
        repeat(301) { u.feed("l$it\r\n") }
        assertNotNull(u.replayAll(columns = 40))
        u.feed("\u001b[1;24r$clear")
        u.feed("b")
        assertNotNull(u.replayAll(columns = 40))
    }

    @Test fun colourRunsStayOutOfThePlainText() {
        val t = TranscriptBuffer()
        t.feed("\u001b[1;38;5;12mA\u001b[0m B \u001b[48;2;1;2;3mC\u001b[49m\r\n")
        assertEquals("A B C", t.text())
    }
}
