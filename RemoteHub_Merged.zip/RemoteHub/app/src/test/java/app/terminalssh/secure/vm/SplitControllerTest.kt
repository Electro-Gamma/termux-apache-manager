package app.terminalssh.secure.vm

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class SplitControllerTest {

    @Test
    fun enableNeedsTwoDifferentSessions() {
        val split = SplitController()
        split.enable("a", "a")
        assertFalse(split.layout.value.enabled)
        split.enable("a", "b")
        assertTrue(split.layout.value.enabled)
        assertEquals("a", split.layout.value.topId)
        assertEquals("b", split.layout.value.bottomId)
    }

    @Test
    fun choosingTheOtherPanesSessionSwapsThem() {
        val split = SplitController()
        split.enable("a", "b")
        split.setTop("b")
        assertEquals("b", split.layout.value.topId)
        assertEquals("a", split.layout.value.bottomId)
    }

    @Test
    fun aPaneCanShowAnotherSessionOfTheSameServer() {
        val split = SplitController()
        split.enable("a", "b")
        split.setBottom("c")
        assertEquals("a", split.layout.value.topId)
        assertEquals("c", split.layout.value.bottomId)
    }

    @Test
    fun resizeStaysWithinBounds() {
        val split = SplitController()
        split.setFraction(0f)
        assertEquals(SplitController.MIN_FRACTION, split.layout.value.fraction)
        split.setFraction(5f)
        assertEquals(SplitController.MAX_FRACTION, split.layout.value.fraction)
    }

    @Test
    fun closingAPaneSessionGivesItAnotherOne() {
        val split = SplitController()
        split.enable("a", "b")
        split.reconcile(listOf("a", "c"))
        assertTrue(split.layout.value.enabled)
        assertEquals("a", split.layout.value.topId)
        assertEquals("c", split.layout.value.bottomId)
    }

    @Test
    fun splitEndsWhenFewerThanTwoSessionsRemain() {
        val split = SplitController()
        split.enable("a", "b")
        split.reconcile(listOf("a"))
        assertFalse(split.layout.value.enabled)
    }

    @Test
    fun focusFollowsThePaneTouched() {
        val split = SplitController()
        split.enable("a", "b")
        assertEquals("a", split.layout.value.focusedId)
        split.focus(true)
        assertEquals("b", split.layout.value.focusedId)
    }
}
