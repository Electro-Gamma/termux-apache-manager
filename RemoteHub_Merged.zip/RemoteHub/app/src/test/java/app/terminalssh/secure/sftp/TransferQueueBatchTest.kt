package app.terminalssh.secure.sftp

import kotlin.test.Test
import kotlin.test.assertEquals

class TransferQueueBatchTest {
    private fun upload(name: String) = Transfer(
        id = name,
        direction = TransferDirection.UPLOAD,
        remotePath = "/r/$name",
        localUri = "content://x/$name",
        displayName = name,
    )

    @Test
    fun aBatchIsQueuedInOrderInOneStep() {
        val queue = TransferQueue()
        queue.enqueueAll(listOf(upload("a"), upload("b"), upload("c")))
        assertEquals(listOf("a", "b", "c"), queue.transfers.value.map { it.id })
        assertEquals("a", queue.nextToStart()?.id)
    }

    @Test
    fun aFailedEntryOfABatchStaysFailed() {
        val queue = TransferQueue()
        queue.enqueueAll(listOf(upload("a").copy(state = TransferState.FAILED)))
        assertEquals(TransferState.FAILED, queue.transfers.value.single().state)
    }
}
