package com.vncviewer.app.input

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** The screen lock: a frozen viewport, and a pointer that cannot leave what is on screen. */
class ScreenLockTest {

    private class Events : CursorController.PointerSink {
        val sent = ArrayList<Pair<Float, Float>>()
        override fun pointerEvent(x: Float, y: Float, buttons: Int) {
            sent.add(Pair(x, y))
        }
    }

    private val noScheduler = object : Scheduler {
        override fun postDelayed(r: Runnable, delayMs: Long) {}
        override fun removeCallbacks(r: Runnable) {}
        override fun postFrame(r: Runnable) {}
        override fun removeFrame(r: Runnable) {}
    }

    /** A 1080x1800 phone view of a 1920x1080 desktop, zoomed in to 2.5x around the middle. */
    private fun zoomedIn(events: Events = Events()): Pair<Viewport, CursorController> {
        val cfg = Config(3f)
        cfg.coalescePointerEvents = false
        val viewport = Viewport(3f)
        viewport.setDesktopSize(1920, 1080)
        viewport.setViewSize(1080, 1800)
        val cursor = CursorController(cfg, viewport, events, noScheduler)
        viewport.setFocus(960f, 540f)
        viewport.centreOn(960f, 540f, 1f)
        cursor.setPosition(960f, 540f)
        viewport.setScale(2.5f)
        cursor.centreCursor(true)
        cursor.mouseMove(-200f, 150f)
        return Pair(viewport, cursor)
    }

    private fun assertOnScreen(v: Viewport, c: CursorController) {
        assertTrue(c.screenX() >= -1e-3f && c.screenX() <= v.viewWidth() - 1 + 1e-3f)
        assertTrue(c.screenY() >= -1e-3f && c.screenY() <= v.viewHeight() - 1 + 1e-3f)
    }

    @Test fun lockedPointerMovesNeverMoveThePicture() {
        val (v, c) = zoomedIn()
        val scale = v.getScale()
        val ox = v.originX()
        val oy = v.originY()
        v.setFrozen(true)
        c.keepInView()
        for ((dx, dy) in listOf(5000f to 0f, -5000f to 0f, 0f to 5000f, 0f to -5000f, 4000f to 4000f, -4000f to -4000f)) {
            c.mouseMove(dx, dy)
            assertEquals(scale, v.getScale(), 0f)
            assertEquals(ox, v.originX(), 0f)
            assertEquals(oy, v.originY(), 0f)
            assertOnScreen(v, c)
        }
    }

    @Test fun lockedPointerStopsAtTheEdgesOfTheScreen() {
        val (v, c) = zoomedIn()
        v.setFrozen(true)
        c.mouseMove(-9000f, -9000f)
        assertEquals(0f, c.screenX(), 1e-2f)
        assertEquals(0f, c.screenY(), 1e-2f)
        c.mouseMove(9000f, 9000f)
        assertEquals(1079f, c.screenX(), 1e-2f)
        assertEquals(1799f, c.screenY(), 1e-2f)
    }

    @Test fun lockedMovementInsideTheAreaIsStillOneToOne() {
        val (v, c) = zoomedIn()
        v.setFrozen(true)
        c.mouseMove(-9000f, -9000f)
        c.mouseMove(40f, 0f)
        assertEquals(40f, c.screenX(), 1e-2f)
    }

    @Test fun everyPointerEventSentIsOnTheDesktop() {
        val events = Events()
        val (v, c) = zoomedIn(events)
        v.setFrozen(true)
        c.mouseMove(-9000f, 0f); c.mouseMove(9000f, 9000f); c.mouseMove(0f, -9000f)
        for ((x, y) in events.sent) assertTrue(x in 0f..1919f && y in 0f..1079f)
    }

    @Test fun touchOutsideThePictureIsHeldAtTheNearestVisiblePoint() {
        val (v, c) = zoomedIn()
        v.setFrozen(true)
        c.setPositionHere(-500f, -500f)
        assertOnScreen(v, c)
        c.setPositionHere(1e6f, 1e6f)
        assertOnScreen(v, c)
    }

    @Test fun zoomAndPanDoNothingWhileLocked() {
        val (v, c) = zoomedIn()
        v.setFrozen(true)
        val scale = v.getScale()
        val ox = v.originX()
        val oy = v.originY()
        v.zoomAt(scale * 0.4f, 500f, 500f)
        v.panBy(80f, -90f)
        v.setScale(1f)
        v.centreOn(10f, 10f)
        assertEquals(scale, v.getScale(), 0f)
        assertEquals(ox, v.originX(), 0f)
        assertEquals(oy, v.originY(), 0f)
        assertTrue(v.isFrozen())
    }

    @Test fun keyboardInsetsKeepThePictureAndPullThePointerBackIn() {
        val (v, c) = zoomedIn()
        v.setFrozen(true)
        val ox = v.originX()
        val oy = v.originY()
        c.mouseMove(9000f, 9000f)
        c.setInsets(0, 0, 0, 500)
        assertEquals(ox, v.originX(), 0f)
        assertEquals(oy, v.originY(), 0f)
        assertTrue(c.screenY() <= v.viewHeight() - 500)
        c.mouseMove(0f, 9000f)
        assertTrue(c.screenY() <= v.viewHeight() - 500)
    }

    @Test fun unlockingRestoresTheNormalBehaviour() {
        val (v, c) = zoomedIn()
        v.setFrozen(true)
        c.mouseMove(-9000f, -9000f)
        v.setFrozen(false)
        assertFalse(v.isFrozen())
        val before = v.getScale()
        v.setScale(before * 0.5f)
        assertTrue(v.getScale() != before)
        c.mouseMove(-99999f, 0f)
        assertEquals(0f, c.x(), 0f)
    }

    @Test fun unlockedBehaviourIsUnchanged() {
        // Never locked: the picture follows the pointer to the desktop's edge as it always did.
        val (v, c) = zoomedIn()
        c.mouseMove(99999f, 99999f)
        assertEquals(1919f, c.x(), 0f)
        assertEquals(1079f, c.y(), 0f)
    }
}
