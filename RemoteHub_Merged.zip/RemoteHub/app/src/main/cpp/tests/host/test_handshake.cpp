// Host test for the version / security-type negotiation in Session::handshake (real session.cpp, JNI stubbed).
// Guards the behaviour that real RealVNC servers need:
//   * a server announcing "RFB 005.xxx" or "RFB 004.xxx" must be answered with "RFB 003.008" and continue with the
//     classic security-type list (RSA-AES etc.), exactly like the engine always did; the RA4 path is opt-in (Ra4=1);
//   * the preferred security type is the same one the engine chose before RA2r / ARD support was added.
#include <pthread.h>
#include <sys/socket.h>
#include <unistd.h>
#include <sys/time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "session.h"
using namespace vr;

struct Case {
  const char* name; const char* banner; const char* opts;     // opts: "Key=Value,Key=Value"
  int nTypes; unsigned char types[16];
  const char* wantReply;                                       // exact 12 bytes the client must answer with
  int wantType;                                                // security type byte the client must choose (0 = none expected)
};
static const Case cases[] = {
  {"RealVNC 005.000 banner -> classic 3.8, None",      "RFB 005.000\n", "",                 1, {1},                   "RFB 003.008\n", 1},
  {"RealVNC 004.001 banner -> classic 3.8, None",      "RFB 004.001\n", "",                 1, {1},                   "RFB 003.008\n", 1},
  {"005.000 with RSA-AES offered picks 6 (as before)", "RFB 005.000\n", "",                 4, {5, 6, 129, 130},      "RFB 003.008\n", 6},
  {"005.000 + PreferEncrypted picks 129 (as before)",  "RFB 005.000\n", "PreferEncrypted=1", 4, {5, 6, 129, 130},     "RFB 003.008\n", 129},
  {"two-step types offered too, default -> 6",         "RFB 004.001\n", "",                 6, {13, 133, 129, 5, 6, 130}, "RFB 003.008\n", 6},
  {"two-step types offered too, PreferEncrypted -> 129","RFB 004.001\n", "PreferEncrypted=1", 6, {13, 133, 129, 5, 6, 130}, "RFB 003.008\n", 129},
  {"only 133 and 13 offered -> two-step is the fallback","RFB 004.001\n", "PreferEncrypted=1", 2, {13, 133},          "RFB 003.008\n", 133},
  {"Ra4=1 still opts in to the RA4 path (005 only)",   "RFB 005.000\n", "Ra4=1",            1, {1},                   "RFB 005.000\n", 0},
  {"plain 3.8 server, VNC auth",                       "RFB 003.008\n", "",                 2, {2, 1},                "RFB 003.008\n", 2},
};

struct Srv { int fd; const Case* c; char reply[13]; int gotType; };
static void* serverBody(void* a) {
  Srv* s = (Srv*)a; const Case* c = s->c;
  struct timeval tv = {2, 0}; setsockopt(s->fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv); s->gotType = -1; memset(s->reply, 0, sizeof s->reply);
  if (write(s->fd, c->banner, 12) != 12) return nullptr;
  size_t got = 0; while (got < 12) { ssize_t r = read(s->fd, s->reply + got, 12 - got); if (r <= 0) return nullptr; got += (size_t)r; }
  if (strcmp(s->reply, "RFB 005.000\n") == 0 && strcmp(c->wantReply, "RFB 005.000\n") == 0) return nullptr;   // RA4 opt-in: only the reply matters
  unsigned char list[17]; list[0] = (unsigned char)c->nTypes; memcpy(list + 1, c->types, (size_t)c->nTypes);
  if (write(s->fd, list, 1 + (size_t)c->nTypes) < 0) return nullptr;
  unsigned char t; if (read(s->fd, &t, 1) == 1) s->gotType = t;
  return nullptr;
}
// Whatever happens, shut the socket down afterwards so a client that is still waiting wakes up and gives up.
static void* server(void* a) { serverBody(a); shutdown(((Srv*)a)->fd, SHUT_RDWR); return nullptr; }

int main() {
  int fails = 0;
  for (const Case& c : cases) {
    int sv[2]; socketpair(AF_UNIX, SOCK_STREAM, 0, sv);
    Session* s = new Session; s->fd = sv[0];
    char buf[256]; strncpy(buf, c.opts, sizeof buf - 1); buf[sizeof buf - 1] = 0;
    for (char* tok = strtok(buf, ","); tok; tok = strtok(nullptr, ",")) { char* eq = strchr(tok, '='); if (eq) { *eq = 0; s->setOpt(tok, eq + 1); } }
    Srv srv = {sv[1], &c, {0}, -1}; pthread_t th; pthread_create(&th, nullptr, server, &srv);
    Str err; bool retry = false; s->handshake(&err, &retry);
    close(sv[0]); pthread_join(th, nullptr); close(sv[1]);
    bool okReply = strcmp(srv.reply, c.wantReply) == 0, okType = c.wantType == 0 || srv.gotType == c.wantType;
    printf("%s  %s", okReply && okType ? "[ok]  " : "[FAIL]", c.name);
    if (!okReply) { char r[16]; strncpy(r, srv.reply, 12); for (char* p = r; *p; p++) if (*p == '\n') *p = '.'; printf("   (client answered \"%s\")", r); }
    if (!okType) printf("   (client chose type %d, wanted %d)", srv.gotType, c.wantType);
    printf("\n"); if (!(okReply && okType)) fails++;
  }
  printf(fails ? "HANDSHAKE TESTS FAILED (%d)\n" : "HANDSHAKE TESTS PASSED\n", fails);
  return fails ? 1 : 0;
}
