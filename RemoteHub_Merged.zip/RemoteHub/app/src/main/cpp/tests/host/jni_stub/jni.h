#pragma once
#include <stdint.h>
typedef int32_t jint; typedef int64_t jlong; typedef uint8_t jboolean; typedef int8_t jbyte; typedef float jfloat; typedef double jdouble; typedef int16_t jshort; typedef uint16_t jchar; typedef jint jsize;
class _jobject {}; typedef _jobject* jobject; typedef jobject jclass; typedef jobject jstring; typedef jobject jarray; typedef jobject jthrowable;
typedef jarray jbyteArray; typedef jarray jintArray; typedef jobject jobjectArray;
struct _jmethodID; typedef _jmethodID* jmethodID; struct _jfieldID; typedef _jfieldID* jfieldID;
#define JNI_OK 0
#define JNI_VERSION_1_6 0x00010006
#define JNIEXPORT
#define JNICALL
#define JNI_FALSE 0
#define JNI_TRUE 1
struct Any { template<class T> operator T() const { return T(); } };
struct JNIEnv { template<class... A> Any CallVoidMethod(A...){return {};} template<class... A> Any CallObjectMethod(A...){return {};} template<class... A> Any CallStaticObjectMethod(A...){return {};}
  template<class... A> Any CallBooleanMethod(A...){return {};} template<class... A> Any CallIntMethod(A...){return {};}
  template<class... A> Any ExceptionCheck(A...){return {};} template<class... A> Any ExceptionClear(A...){return {};} template<class... A> Any NewStringUTF(A...){return {};}
  template<class... A> Any DeleteLocalRef(A...){return {};} template<class... A> Any NewGlobalRef(A...){return {};} template<class... A> Any DeleteGlobalRef(A...){return {};}
  template<class... A> Any GetObjectClass(A...){return {};} template<class... A> Any GetMethodID(A...){return {};} template<class... A> Any GetStaticMethodID(A...){return {};}
  template<class... A> Any NewObject(A...){return {};} template<class... A> Any FindClass(A...){return {};} template<class... A> Any GetStringUTFChars(A...){return {};} template<class... A> Any ReleaseStringUTFChars(A...){return {};}
  template<class... A> Any GetFieldID(A...){return {};} template<class... A> Any GetStaticFieldID(A...){return {};} template<class... A> Any GetStaticObjectField(A...){return {};} template<class... A> Any GetLongField(A...){return {};}
  template<class... A> Any SetLongField(A...){return {};} template<class... A> Any NewDirectByteBuffer(A...){return {};} template<class... A> Any GetObjectField(A...){return {};}
  template<class... A> Any CallLongMethod(A...){return {};} template<class... A> Any GetArrayLength(A...){return {};} template<class... A> Any GetByteArrayRegion(A...){return {};} template<class... A> Any NewByteArray(A...){return {};} template<class... A> Any SetByteArrayRegion(A...){return {};}
  template<class... A> Any GetJavaVM(A...){return {};} template<class... A> Any ThrowNew(A...){return {};} template<class... A> Any GetStringLength(A...){return {};} template<class... A> Any GetStringUTFLength(A...){return {};} template<class... A> Any GetDirectBufferAddress(A...){return {};} };
struct JavaVM { template<class... A> Any AttachCurrentThread(A...){return {};} template<class... A> Any DetachCurrentThread(A...){return {};} template<class... A> Any GetEnv(A...){return {};} };
