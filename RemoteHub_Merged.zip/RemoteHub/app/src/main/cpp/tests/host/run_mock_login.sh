#!/bin/bash
# Full RSA-AES logins against the independent mock server, for the engine in vnc/ (needs python3 + the built objects of run.sh).
set -u
cd "$(dirname "$0")/../.."
OUT=${TMPDIR:-/tmp}/vnc_host_test; M=mbedtls
g++ -std=c++17 -O2 -fno-exceptions -fno-rtti -w -Itests/host/jni_stub -Ivnc -I$M/include -I$M/library -I$M -DMBEDTLS_CONFIG_FILE=\"vnc_mbedtls_config.h\" \
  vnc/util.cpp vnc/des.cpp vnc/ra2.cpp $( [ -f vnc/ra4.cpp ] && echo vnc/ra4.cpp vnc/ra4_client.cpp ) vnc/session.cpp tests/host/stubs.cpp tests/host/test_session_mock.cpp ${MBOBJ:-$OUT/mb_*.o} -lz -lpthread -o $OUT/test_session_mock || exit 1
W=$OUT/mock; mkdir -p $W; fail=0; port=${MOCK_PORT:-18300}
run() { # name banner offer prefer-encrypted
  port=$((port+1))
  python3 tests/host/mock_vnc.py --port $port --proto 3.8 --auth ra2 --user pi --password raspberry --offer "$3" --banner "$2" --enc zrle --log $W/$1.log --expected $W/$1.rgba >$W/$1.srv 2>&1 &
  local sp=$!; for i in $(seq 1 50); do (echo > /dev/tcp/127.0.0.1/$port) 2>/dev/null && break; sleep 0.1; done
  local r; r=$(timeout 30 $OUT/test_session_mock $port $W/$1.rgba $4 2>&1 | tail -1); local rc=$?
  kill $sp 2>/dev/null; wait $sp 2>/dev/null
  case "$r" in OK*) echo "[ok]   $1: $r";; *) echo "[FAIL] $1: $r"; fail=1;; esac
}
run banner005_type6_login          "RFB 005.000" 6             0
run banner005_type130_login        "RFB 005.000" 130           0
run banner005_type5_encrypted      "RFB 005.000" 5             0
run banner005_type129_encrypted    "RFB 005.000" 129           0
run banner005_prefer_encrypted     "RFB 005.000" 5,6,129,130   1
run banner004_prefer_encrypted     "RFB 004.001" 5,6,129,130   1
run banner005_twostep_listed_129   "RFB 005.000" 13,133,129,6  1
[ $fail -eq 0 ] && echo "MOCK LOGINS PASSED" || echo "MOCK LOGINS FAILED"; exit $fail
