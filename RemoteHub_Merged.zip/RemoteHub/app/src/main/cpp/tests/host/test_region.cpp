// Session::copyRegion (direct framebuffer-rectangle -> bitmap copy): exactness, bounds, equivalence with scaledCopy,
// and (with -DBENCH) a comparison with the old tile route. Real session.cpp, JNI stubbed.
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "session.h"
using namespace vr;
static int fails = 0;
static void check(bool ok, const char* name) { printf("%s  %s\n", ok ? "[ok]  " : "[FAIL]", name); if (!ok) fails++; }
static uint32_t rnd() { static uint32_t s = 777; s = s * 1664525u + 1013904223u; return s; }

static Session* makeSession(int W, int H) {
  Session* s = new Session; s->fb.resize((size_t)W * H * 4); s->fbW = W; s->fbH = H;
  for (size_t i = 0; i < (size_t)W * H; i++) { uint32_t v = rnd() & 0x00ffffffu; memcpy(s->fb.p + i * 4, &v, 4); }   // alpha 0 as the decoders leave it
  return s;
}
static uint32_t px(const u8* p, int stride, int x, int y) { uint32_t v; memcpy(&v, p + ((size_t)y * stride + x) * 4, 4); return v; }

#ifndef BENCH
int main() {
  const int W = 200, H = 150, SENT = 0x12345678;
  Session* s = makeSession(W, H);
  // 1. interior rectangle into a full-size image with padded rows (stride 224 px)
  { int stride = 224; u8* d = (u8*)malloc((size_t)stride * H * 4); for (size_t i = 0; i < (size_t)stride * H; i++) memcpy(d + i * 4, &(const int&)SENT, 4);
    s->copyRegion(d, stride, W, H, 37, 21, 90, 60);
    bool in = true, out = true;
    for (int y = 0; y < H; y++) for (int x = 0; x < stride; x++) {
      bool inside = x >= 37 && x < 127 && y >= 21 && y < 81; uint32_t v = px(d, stride, x, y);
      if (inside) { if (v != (px(s->fb.p, W, x, y) | 0xff000000u)) in = false; } else if (v != (uint32_t)SENT) out = false; }
    check(in, "interior rectangle: pixels equal the framebuffer, alpha forced to 0xFF");
    check(out, "everything outside the rectangle (and the row padding) untouched");
    free(d); }
  // 2. rectangle partly outside the framebuffer is clamped
  { u8* d = (u8*)malloc((size_t)W * H * 4); memset(d, 0x5a, (size_t)W * H * 4);
    s->copyRegion(d, W, W, H, -20, -10, 60, 40);                       // covers (0..39, 0..29)
    s->copyRegion(d, W, W, H, 180, 130, 100, 100);                     // covers (180..199, 130..149)
    bool ok = true;
    for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) {
      bool inside = (x < 40 && y < 30) || (x >= 180 && y >= 130); uint32_t v = px(d, W, x, y);
      if (inside ? v != (px(s->fb.p, W, x, y) | 0xff000000u) : v != 0x5a5a5a5au) ok = false; }
    check(ok, "rectangle partly outside the framebuffer is clamped"); free(d); }
  // 3. destination smaller than the framebuffer (e.g. a stale bitmap after a resize): nothing written past it
  { int dw = 120, dh = 90; u8* d = (u8*)malloc((size_t)(dw * dh + 64) * 4); memset(d, 0x77, (size_t)(dw * dh + 64) * 4);
    s->copyRegion(d, dw, dw, dh, 0, 0, W, H);
    bool ok = true; for (size_t i = (size_t)dw * dh * 4; i < (size_t)(dw * dh + 64) * 4; i++) if (d[i] != 0x77) ok = false;
    for (int y = 0; y < dh; y++) for (int x = 0; x < dw; x++) if (px(d, dw, x, y) != (px(s->fb.p, W, x, y) | 0xff000000u)) ok = false;
    check(ok, "destination smaller than the framebuffer: clamped, no write past its end"); free(d); }
  // 4. empty / negative sizes write nothing
  { u8* d = (u8*)malloc((size_t)W * H * 4); memset(d, 0x33, (size_t)W * H * 4);
    s->copyRegion(d, W, W, H, 10, 10, 0, 50); s->copyRegion(d, W, W, H, 10, 10, 50, -3); s->copyRegion(nullptr, W, W, H, 0, 0, 5, 5); s->copyRegion(d, 0, W, H, 0, 0, 5, 5);
    bool ok = true; for (size_t i = 0; i < (size_t)W * H * 4; i++) if (d[i] != 0x33) ok = false;
    check(ok, "empty, negative or invalid arguments write nothing"); free(d); }
  // 5. same pixels as the existing scaledCopy for the same region
  { int rw = 77, rh = 53, rx = 41, ry = 29; u8* a = (u8*)calloc((size_t)rw * rh, 4); u8* b = (u8*)calloc((size_t)W * H, 4);
    s->scaledCopy(1.0f, a, rw, rh, rx, ry, rw, rh); s->copyRegion(b, W, W, H, rx, ry, rw, rh);
    bool ok = true; for (int y = 0; y < rh; y++) for (int x = 0; x < rw; x++) if (px(a, rw, x, y) != px(b, W, rx + x, ry + y)) ok = false;
    check(ok, "identical to scaledCopy(1.0) for the same region"); free(a); free(b); }
  printf(fails ? "REGION TESTS FAILED (%d)\n" : "REGION TESTS PASSED\n", fails); return fails ? 1 : 0;
}
#else
static double now() { struct timespec t; clock_gettime(CLOCK_THREAD_CPUTIME_ID, &t); return t.tv_sec + t.tv_nsec * 1e-9; }
int main() {
  const int W = 1920, H = 1080, T = 256; Session* s = makeSession(W, H);
  u8* desktop = (u8*)calloc((size_t)W * H, 4); u8* scratch = (u8*)calloc((size_t)T * T, 4); u8* javaTile = (u8*)calloc((size_t)T * T, 4);
  struct R { const char* name; int w, h, reps; } rs[] = {{"64x64 (typing / cursor)", 64, 64, 4000}, {"400x300 (a window region)", 400, 300, 600}, {"1920x1080 (full screen)", 1920, 1080, 60}};
  printf("%-28s %14s %14s %8s\n", "dirty rectangle", "tile route", "direct copy", "ratio");
  for (R& r : rs) {
    double t0 = now();
    for (int k = 0; k < r.reps; k++) {                                    // old route, per dirty 256x256 cell: native copy + zero-fill,
      for (int cy = 0; cy * T < r.h; cy++) for (int cx = 0; cx * T < r.w; cx++) {    // Java copyPixelsFromBuffer (modelled as memcpy), canvas blit
        int x = cx * T, y = cy * T, w = r.w - x < T ? r.w - x : T, h = r.h - y < T ? r.h - y : T;
        s->scaledCopy(1.0f, scratch, T, T, x, y, w, h); memcpy(javaTile, scratch, (size_t)T * T * 4);
        for (int row = 0; row < h; row++) memcpy(desktop + ((size_t)(y + row) * W + x) * 4, javaTile + (size_t)row * T * 4, (size_t)w * 4); } }
    double tOld = (now() - t0) / r.reps;
    t0 = now(); for (int k = 0; k < r.reps; k++) s->copyRegion(desktop, W, W, H, 0, 0, r.w, r.h);
    double tNew = (now() - t0) / r.reps;
    printf("%-28s %11.3f ms %11.3f ms %7.1fx\n", r.name, tOld * 1000, tNew * 1000, tOld / tNew);
  }
  return 0;
}
#endif
