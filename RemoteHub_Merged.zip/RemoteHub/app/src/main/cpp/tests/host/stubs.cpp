// Stand-ins for the JNI plumbing (jni_core/jni_store) so session.cpp links on the host.
#include "jni_common.h"
namespace vr {
JniGlobals G;
JNIEnv* attachThread(bool* a) { if (a) *a = false; return nullptr; }
void detachThread() {}
u32 unicodeToKeysym(u32 cp) { return cp; }
u32 keysymToUnicode(u32 ks) { return ks; }
}
