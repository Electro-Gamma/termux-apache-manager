#pragma once
#include <stdint.h>
typedef struct { uint32_t width, height, stride; int32_t format; uint32_t flags; } AndroidBitmapInfo;
inline int AndroidBitmap_getInfo(void*, void*, AndroidBitmapInfo*) { return 0; }
inline int AndroidBitmap_lockPixels(void*, void*, void**) { return 0; }
inline int AndroidBitmap_unlockPixels(void*, void*) { return 0; }
