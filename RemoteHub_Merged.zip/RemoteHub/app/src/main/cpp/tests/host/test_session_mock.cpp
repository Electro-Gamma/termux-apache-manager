// Full login + first frames through Session::handshake / serverInitAndLoop against tests/host/mock_vnc.py (an independent
// RSA-AES implementation). Usage: test_session_mock PORT EXPECTED_RGBA PREFER_ENCRYPTED(0/1) [user pass]
// Prints OK only if the login succeeded and the decoded framebuffer equals the server's image.
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "session.h"
using namespace vr;
static void* watchdog(void* a) { Session* s = (Session*)a; for (int i = 0; i < 60 && s->fd >= 0; i++) { usleep(100000); if (s->connected && i > 15) break; } shutdown(s->fd, SHUT_RDWR); return nullptr; }
int main(int argc, char** argv) {
  if (argc < 4) return 2;
  int port = atoi(argv[1]); const char* user = argc > 4 ? argv[4] : "pi"; const char* pass = argc > 5 ? argv[5] : "raspberry";
  int fd = socket(AF_INET, SOCK_STREAM, 0); struct sockaddr_in a = {}; a.sin_family = AF_INET; a.sin_port = htons(port); inet_pton(AF_INET, "127.0.0.1", &a.sin_addr);
  if (connect(fd, (struct sockaddr*)&a, sizeof a)) { perror("connect"); return 2; }
  Session* s = new Session; s->fd = fd;
  s->setOpt("Username", user); s->setOpt("Password", pass); if (atoi(argv[3])) s->setOpt("PreferEncrypted", "1");
  Str err; bool retry = false;
  if (!s->handshake(&err, &retry)) { printf("FAIL handshake: %s\n", err.c()); return 1; }
  pthread_t th; pthread_create(&th, nullptr, watchdog, s);
  bool dummy = s->serverInitAndLoop(&err); (void)dummy;
  pthread_join(th, nullptr);
  FILE* f = fopen(argv[2], "rb"); if (!f) { printf("FAIL: no expected image\n"); return 1; }
  static unsigned char exp[1 << 22]; size_t n = fread(exp, 1, sizeof exp, f); fclose(f);
  if (s->fbW <= 0 || (size_t)s->fbW * s->fbH * 4 != n) { printf("FAIL: framebuffer %dx%d, expected %zu bytes (%s)\n", s->fbW, s->fbH, n, err.c()); return 1; }
  size_t bad = 0; for (size_t i = 0; i < n; i += 4) if (memcmp(s->fb.p + i, exp + i, 3)) bad++;
  if (bad) { printf("FAIL: %zu of %zu pixels differ\n", bad, n / 4); return 1; }
  printf("OK   security type %d (%s), %dx%d frame identical\n", s->secType, s->secDesc.c(), s->fbW, s->fbH);
  return 0;
}
