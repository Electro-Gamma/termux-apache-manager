#!/bin/sh
# Decoder benchmark on the host: pre-built 1920x1080 updates (Raw, ZRLE, CopyRect) pushed through the real
# session.cpp; prints the client's time. Run it in two source trees to compare versions.
set -e
cd "$(dirname "$0")/../.."
OUT=${TMPDIR:-/tmp}/vnc_host_bench; mkdir -p "$OUT"; M=mbedtls
for c in $M/library/*.c; do f=$(basename $c .c); [ -f $OUT/mb_$f.o ] || gcc -O2 -c -I$M/include -I$M/library -I$M -DMBEDTLS_CONFIG_FILE=\"vnc_mbedtls_config.h\" $c -o $OUT/mb_$f.o; done
g++ -std=c++17 -O2 -fno-exceptions -fno-rtti -Wno-unused-function -DBENCH -DBENCH_W=1920 -DBENCH_H=1080 -Itests/host/jni_stub -Ivnc -I$M/include -I$M/library -I$M \
  -DMBEDTLS_CONFIG_FILE=\"vnc_mbedtls_config.h\" vnc/util.cpp vnc/des.cpp vnc/ra2.cpp vnc/ra4.cpp vnc/ra4_client.cpp vnc/session.cpp tests/host/stubs.cpp tests/host/test_decoders.cpp $OUT/mb_*.o -lz -lpthread -o $OUT/bench
for a in "0 0 300" "0 30 0" "30 0 0"; do for i in 1 2 3; do $OUT/bench $a; done; done
