#!/bin/sh
# Builds session.cpp for the host with stub JNI headers (tests/host/jni_stub) and runs the decoder test.
set -e
cd "$(dirname "$0")/../.."
OUT=${TMPDIR:-/tmp}/vnc_host_test
mkdir -p "$OUT"
M=mbedtls
MB="aes asn1parse asn1write bignum bignum_core bignum_mod bignum_mod_raw constant_time md oid platform platform_util rsa rsa_alt_helpers sha1 sha256"
for f in $MB; do gcc -O1 -c -I$M/include -I$M/library -I$M -DMBEDTLS_CONFIG_FILE=\"vnc_mbedtls_config.h\" $M/library/$f.c -o $OUT/mb_$f.o; done
g++ -std=c++17 -O2 -g -fno-exceptions -fno-rtti -Wno-unused-function -Itests/host/jni_stub -Ivnc -I$M/include -I$M/library -I$M \
  -DMBEDTLS_CONFIG_FILE=\"vnc_mbedtls_config.h\" ${EXTRA:-} \
  vnc/util.cpp vnc/des.cpp vnc/ra2.cpp vnc/session.cpp tests/host/stubs.cpp tests/host/test_decoders.cpp $OUT/mb_*.o \
  -lz -lpthread -o $OUT/test_decoders
$OUT/test_decoders
