#!/bin/sh
# Builds session.cpp for the host with stub JNI headers (tests/host/jni_stub) and runs the decoder test.
set -e
cd "$(dirname "$0")/../.."
OUT=${TMPDIR:-/tmp}/vnc_host_test
mkdir -p "$OUT"
M=mbedtls
for c in $M/library/*.c; do f=$(basename $c .c); [ -f $OUT/mb_$f.o ] || gcc -O1 -c -I$M/include -I$M/library -I$M -DMBEDTLS_CONFIG_FILE=\"vnc_mbedtls_config.h\" $c -o $OUT/mb_$f.o; done
g++ -std=c++17 -O2 -g -fno-exceptions -fno-rtti -Wno-unused-function -Itests/host/jni_stub -Ivnc -I$M/include -I$M/library -I$M \
  -DMBEDTLS_CONFIG_FILE=\"vnc_mbedtls_config.h\" ${EXTRA:-} \
  vnc/util.cpp vnc/des.cpp vnc/ra2.cpp vnc/ra4.cpp vnc/ra4_client.cpp vnc/session.cpp tests/host/stubs.cpp tests/host/test_decoders.cpp $OUT/mb_*.o \
  -lz -lpthread -o $OUT/test_decoders
$OUT/test_decoders
