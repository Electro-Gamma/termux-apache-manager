// Host test for the RFB decoders and the update-request pipeline in vnc/session.cpp.
// Links the REAL session.cpp (JNI replaced by the stubs in stubs/), runs Session::serverInitAndLoop on a
// thread against a fake server on a socketpair, and compares the library's framebuffer with a model.
//   tests/host/run.sh
#include <pthread.h>
#include <poll.h>
#include <sys/socket.h>
#include <unistd.h>
#include <zlib.h>
#include <initializer_list>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "session.h"
using namespace vr;
// Minimal byte vector (the library replaces operator new, which clashes with <vector>).
struct V {
  uint8_t* p = nullptr; size_t n = 0, cap = 0;
  V() {} V(size_t k, uint8_t v = 0) { resize(k, v); } V(std::initializer_list<uint8_t> l) { for (uint8_t b : l) push_back(b); }
  V(const V& o) { insert(nullptr, o.p, o.p + o.n); } V& operator=(const V& o) { if (this != &o) { n = 0; insert(nullptr, o.p, o.p + o.n); } return *this; } ~V() { free(p); }
  void reserve(size_t k) { if (k > cap) { cap = k * 2; p = (uint8_t*)realloc(p, cap); } }
  void resize(size_t k, uint8_t v = 0) { reserve(k); if (k > n) memset(p + n, v, k - n); n = k; }
  void push_back(uint8_t b) { reserve(n + 1); p[n++] = b; }
  void insert(uint8_t*, const uint8_t* a, const uint8_t* b) { size_t k = b - a; reserve(n + k); memcpy(p + n, a, k); n += k; }
  uint8_t& operator[](size_t i) { return p[i]; } uint8_t* data() { return p; } size_t size() const { return n; } uint8_t* begin() { return p; } uint8_t* end() { return p + n; }
};

static void wr(int fd, const void* d, size_t n) { const uint8_t* p = (const uint8_t*)d; while (n) { ssize_t r = write(fd, p, n); if (r <= 0) exit(3); p += r; n -= r; } }
static void rdn(int fd, void* d, size_t n) { uint8_t* p = (uint8_t*)d; while (n) { ssize_t r = read(fd, p, n); if (r <= 0) exit(4); p += r; n -= r; } }
static void p16(V& v, int x) { v.push_back(x >> 8); v.push_back(x & 255); }
static void p32(V& v, uint32_t x) { for (int i = 3; i >= 0; i--) v.push_back((x >> (8 * i)) & 255); }
static uint32_t rnd() { static uint32_t s = 12345; s = s * 1664525u + 1013904223u; return s >> 8; }

#ifndef BENCH_W
#define BENCH_W 300
#define BENCH_H 200
#endif
static const int W = BENCH_W, H = BENCH_H;
static uint32_t model[W * H];
static inline uint32_t PX(int r, int g, int b) { uint8_t b4[4] = {(uint8_t)r, (uint8_t)g, (uint8_t)b, 255}; uint32_t v; memcpy(&v, b4, 4); return v; }

static void rectHdr(V& v, int x, int y, int w, int h, int enc) { p16(v, x); p16(v, y); p16(v, w); p16(v, h); p32(v, (uint32_t)enc); }

// ---- ZRLE rect: every tile kind, with the model updated alongside ----
static bool g_screenLike = false;
static V zrleRect(int x, int y, int w, int h, z_stream* zs) {
  V raw;
  int kind = 0;
  for (int ty = 0; ty < h; ty += 64) for (int tx = 0; tx < w; tx += 64, kind++) {
    int tw = w - tx < 64 ? w - tx : 64, th = h - ty < 64 ? h - ty : 64;
    auto put = [&](int c, int r, uint32_t v) { model[(y + ty + r) * W + x + tx + c] = v; };
    static const int screenMix[10] = {1, 1, 1, 1, 5, 5, 6, 2, 3, 0};   // mostly solid/RLE/palette, one raw tile in ten
    int k = g_screenLike ? screenMix[kind % 10] : kind % 7;
    if (k == 0) {                                   // raw
      raw.push_back(0);
      for (int r = 0; r < th; r++) for (int c = 0; c < tw; c++) { int a = rnd() & 255, b = rnd() & 255, d = rnd() & 255; raw.push_back(a); raw.push_back(b); raw.push_back(d); put(c, r, PX(a, b, d)); }
    } else if (k == 1) {                            // solid
      raw.push_back(1); int a = rnd() & 255, b = rnd() & 255, d = rnd() & 255; raw.push_back(a); raw.push_back(b); raw.push_back(d);
      for (int r = 0; r < th; r++) for (int c = 0; c < tw; c++) put(c, r, PX(a, b, d));
    } else if (k == 2 || k == 3 || k == 4) {        // packed palette: 2, 3..4, 5..16 colours
      int ps = k == 2 ? 2 : (k == 3 ? 4 : 13); int bits = ps <= 2 ? 1 : (ps <= 4 ? 2 : 4);
      raw.push_back(ps); uint32_t pal[16];
      for (int i = 0; i < ps; i++) { int a = rnd() & 255, b = rnd() & 255, d = rnd() & 255; raw.push_back(a); raw.push_back(b); raw.push_back(d); pal[i] = PX(a, b, d); }
      for (int r = 0; r < th; r++) {
        int nb = (tw * bits + 7) / 8; V row(nb, 0);
        for (int c = 0; c < tw; c++) { int idx = rnd() % ps; int pos = c * bits; row[pos >> 3] |= idx << (8 - bits - (pos & 7)); put(c, r, pal[idx]); }
        raw.insert(nullptr, row.begin(), row.end());
      }
    } else if (k == 5) {                            // plain RLE
      raw.push_back(128); int total = tw * th, pos = 0;
      while (pos < total) {
        int a = rnd() & 255, b = rnd() & 255, d = rnd() & 255; int run = 1 + (rnd() % 300); if (run > total - pos) run = total - pos;
        raw.push_back(a); raw.push_back(b); raw.push_back(d);
        int rem = run - 1; while (rem >= 255) { raw.push_back(255); rem -= 255; } raw.push_back(rem);
        for (int i = 0; i < run; i++, pos++) put(pos % tw, pos / tw, PX(a, b, d));
      }
    } else {                                        // palette RLE
      int ps = 5; raw.push_back(128 | ps); uint32_t pal[16];
      for (int i = 0; i < ps; i++) { int a = rnd() & 255, b = rnd() & 255, d = rnd() & 255; raw.push_back(a); raw.push_back(b); raw.push_back(d); pal[i] = PX(a, b, d); }
      int total = tw * th, pos = 0;
      while (pos < total) {
        int idx = rnd() % ps; int run = 1 + (rnd() % 400); if (run > total - pos) run = total - pos;
        if (run == 1) raw.push_back(idx); else { raw.push_back(idx | 128); int rem = run - 1; while (rem >= 255) { raw.push_back(255); rem -= 255; } raw.push_back(rem); }
        for (int i = 0; i < run; i++, pos++) put(pos % tw, pos / tw, pal[idx]);
      }
    }
  }
  V comp(raw.size() + raw.size() / 10 + 1024);
  zs->next_in = raw.data(); zs->avail_in = raw.size(); zs->next_out = comp.data(); zs->avail_out = comp.size();
  if (deflate(zs, Z_SYNC_FLUSH) != Z_OK) exit(5);
  comp.resize(comp.size() - zs->avail_out);
  V out; rectHdr(out, x, y, w, h, 16); p32(out, comp.size()); out.insert(nullptr, comp.begin(), comp.end()); return out;
}

static V rawRect(int x, int y, int w, int h) {
  V out; rectHdr(out, x, y, w, h, 0);
  for (int r = 0; r < h; r++) for (int c = 0; c < w; c++) { int a = rnd() & 255, b = rnd() & 255, d = rnd() & 255; out.push_back(a); out.push_back(b); out.push_back(d); out.push_back(0); model[(y + r) * W + x + c] = PX(a, b, d); }
  return out;
}
static V copyRect(int dx, int dy, int w, int h, int sx, int sy) {
  V out; rectHdr(out, dx, dy, w, h, 1); p16(out, sx); p16(out, sy);
  uint32_t* tmp = (uint32_t*)malloc((size_t)w * h * 4);
  for (int r = 0; r < h; r++) for (int c = 0; c < w; c++) tmp[r * w + c] = model[(sy + r) * W + sx + c];
  for (int r = 0; r < h; r++) for (int c = 0; c < w; c++) model[(dy + r) * W + dx + c] = tmp[r * w + c];
  free(tmp); return out;
}

static int g_pipeline = 1, g_requestsEarly = 0, g_requests = 0, g_updates = 0;
static void readClientMsg(int fd, int* type) {
  uint8_t t; rdn(fd, &t, 1); *type = t; uint8_t b[64];
  if (t == 0) rdn(fd, b, 19); else if (t == 2) { rdn(fd, b, 3); int n = (b[1] << 8) | b[2]; V x(n * 4); if (n) rdn(fd, x.data(), n * 4); }
  else if (t == 3) rdn(fd, b, 9); else if (t == 4) rdn(fd, b, 7); else if (t == 5) rdn(fd, b, 5); else exit(6);
}
static bool readable(int fd, int ms) { struct pollfd p = {fd, POLLIN, 0}; return poll(&p, 1, ms) > 0 && (p.revents & POLLIN); }

static void* serverThread(void* arg) {
  int fd = *(int*)arg; uint8_t sh; rdn(fd, &sh, 1);
  V init; p16(init, W); p16(init, H);
  uint8_t pf[16] = {32, 24, 0, 1, 0, 255, 0, 255, 0, 255, 0, 8, 16, 0, 0, 0}; init.insert(nullptr, pf, pf + 16);
  p32(init, 4); init.push_back('t'); init.push_back('e'); init.push_back('s'); init.push_back('t'); wr(fd, init.data(), init.size());
  int t = 0; do readClientMsg(fd, &t); while (t != 3);            // SetPixelFormat, SetEncodings, first request
  z_stream zs; memset(&zs, 0, sizeof zs); deflateInit(&zs, 6);
  for (int u = 0; u < 6; u++) {
    V rects;
    if (u == 0) { V a = rawRect(0, 0, W, H); rects = a; }                               // whole screen, raw, full width
    else if (u == 1) { V a = zrleRect(10, 7, 250, 130, &zs); rects = a; }               // ZRLE, all tile kinds, partial tiles
    else if (u == 2) { V a = copyRect(40, 30, 100, 80, 30, 20); rects = a; }            // down-right, overlapping (src above dst)
    else if (u == 3) { V a = copyRect(20, 10, 120, 90, 50, 40); rects = a; }            // up-left, overlapping (src below dst)
    else if (u == 4) { V a = copyRect(100, 60, 100, 70, 90, 60); rects = a; }           // same rows, shifted sideways (in-row overlap)
    else { V a = rawRect(5, 5, 50, 50); V b = zrleRect(0, 0, 64, 64, &zs); rects = a; rects.insert(nullptr, b.begin(), b.end()); }
    int n = (u == 5) ? 2 : 1;
    V hdr = {0, 0, (uint8_t)(n >> 8), (uint8_t)n};
    wr(fd, hdr.data(), hdr.size());
    // Pipelining check: the next request must arrive while the update is still incomplete.
    bool early = readable(fd, g_pipeline ? 2000 : 300);
    if (early) { readClientMsg(fd, &t); if (t == 3) { g_requestsEarly++; g_requests++; } }
    wr(fd, rects.data(), rects.size()); g_updates++;
    if (!early) { do readClientMsg(fd, &t); while (t != 3); g_requests++; }
  }
  usleep(200000); close(fd); return nullptr;
}

static int runCase(int pipeline) {
  g_pipeline = pipeline; g_requestsEarly = g_requests = g_updates = 0; memset(model, 0, sizeof model); (void)rnd;
  int sv[2]; if (socketpair(AF_UNIX, SOCK_STREAM, 0, sv)) return 1;
  pthread_t th; pthread_create(&th, nullptr, serverThread, &sv[1]);
  Session* s = new Session; s->fd = sv[0];
  if (!pipeline) s->setOpt("Pipeline", "0");
  Str err; s->serverInitAndLoop(&err);
  pthread_join(th, nullptr);
  int bad = 0;
  if (s->fbW != W || s->fbH != H) { printf("  size %dx%d\n", s->fbW, s->fbH); return 1; }
  const uint32_t* got = (const uint32_t*)s->fb.p;
  for (int i = 0; i < W * H; i++) if ((got[i] | 0xff000000u) != (model[i] | 0xff000000u)) { if (bad < 5) printf("  mismatch at (%d,%d): got %08x want %08x\n", i % W, i / W, got[i], model[i]); bad++; }
  printf("pipeline=%d: %d pixels wrong, %d updates, %d requests (%d arrived before the update finished)\n", pipeline, bad, g_updates, g_requests, g_requestsEarly);
  if (pipeline && g_requestsEarly != g_updates) { printf("  FAIL: expected every request early\n"); bad++; }
  if (!pipeline && g_requestsEarly != 0) { printf("  FAIL: requests should wait for the end of the update\n"); bad++; }
  if (g_requests != g_updates) { printf("  FAIL: one request per update expected\n"); bad++; }
  return bad ? 1 : 0;
}

#ifdef BENCH
#include <time.h>
static double now() { struct timespec t; clock_gettime(CLOCK_THREAD_CPUTIME_ID, &t); return t.tv_sec + t.tv_nsec * 1e-9; }
static V g_all; static V g_rawFrames, g_zrleFrames, g_copyFrames; static int g_nRaw = 6, g_nZrle = 12, g_nCopy = 60;
static V wrap(const V& rect) { V o = {0, 0, 0, 1}; o.insert(nullptr, rect.p, rect.p + rect.n); return o; }
static void* benchServer(void* arg) {
  int fd = *(int*)arg; uint8_t sh; rdn(fd, &sh, 1);
  V init; p16(init, W); p16(init, H);
  uint8_t pf[16] = {32, 24, 0, 1, 0, 255, 0, 255, 0, 255, 0, 8, 16, 0, 0, 0}; init.insert(nullptr, pf, pf + 16);
  p32(init, 1); init.push_back('x'); wr(fd, init.data(), init.size());
  int t = 0; do readClientMsg(fd, &t); while (t != 3);
  wr(fd, g_all.data(), g_all.size());
  for (int got = 0; got < g_updates; ) { readClientMsg(fd, &t); if (t == 3) got++; }
  close(fd); return nullptr;
}
int main(int argc, char** argv) {
  if (argc > 3) { g_nRaw = atoi(argv[1]); g_nZrle = atoi(argv[2]); g_nCopy = atoi(argv[3]); }
  {
  g_screenLike = true;
  z_stream zs; memset(&zs, 0, sizeof zs); deflateInit(&zs, 6);
  for (int i = 0; i < g_nRaw; i++) { V a = wrap(rawRect(0, 0, W, H)); g_all.insert(nullptr, a.p, a.p + a.n); }
  for (int i = 0; i < g_nZrle; i++) { V a = wrap(zrleRect(0, 0, W, H, &zs)); g_all.insert(nullptr, a.p, a.p + a.n); }
  for (int i = 0; i < g_nCopy; i++) { int d = (i & 1) ? 1 : -1; V a = (d > 0) ? wrap(copyRect(0, 8, W, H - 8, 0, 0)) : wrap(copyRect(0, 0, W, H - 8, 0, 8)); g_all.insert(nullptr, a.p, a.p + a.n); }
  g_updates = g_nRaw + g_nZrle + g_nCopy;
}
  int sv[2]; socketpair(AF_UNIX, SOCK_STREAM, 0, sv); pthread_t th; pthread_create(&th, nullptr, benchServer, &sv[1]);
  // Let the server finish building its data first so only the client's work is timed.
  Session* s = new Session; s->fd = sv[0]; Str err; double t0 = now(); s->serverInitAndLoop(&err); double dt = now() - t0;
  pthread_join(th, nullptr);
  printf("%dx%d: %d updates (%d raw, %d zrle, %d copyrect) client CPU %.0f ms  (exit: %s)\n", W, H, g_updates, g_nRaw, g_nZrle, g_nCopy, dt * 1000, err.c());
  return 0;
}
#else
int main() { int f = 0; f += runCase(1); f += runCase(0); printf(f ? "FAILED\n" : "ALL PASSED\n"); return f ? 1 : 0; }
#endif
