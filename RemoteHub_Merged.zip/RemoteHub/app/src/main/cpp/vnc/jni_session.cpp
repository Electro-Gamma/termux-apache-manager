// SessionBindings, ConnectionInfoBindings and the dialog / notifier registration exports.
#include "jni_common.h"
#include "session.h"
#ifdef __ANDROID__
#include <android/bitmap.h>
#else
extern "C" {
int AndroidBitmap_getInfo(JNIEnv*, jobject, void*);
int AndroidBitmap_lockPixels(JNIEnv*, jobject, void**);
int AndroidBitmap_unlockPixels(JNIEnv*, jobject);
}
struct AndroidBitmapInfo { uint32_t width, height, stride; int32_t format; uint32_t flags; };
#endif

#define JF(ret, name, ...) extern "C" __attribute__((visibility("default"))) ret Java_com_realvnc_vncviewer_jni_##name(JNIEnv* env, jobject, ##__VA_ARGS__)
#define UNUSED(x) (void)(x)
using namespace vr;

#define SESSION_CLS "com/realvnc/vncviewer/jni/SessionBindings$Session"
#define SESSION_SIG "Lcom/realvnc/vncviewer/jni/SessionBindings$Session;"

static bool ensureClasses(JNIEnv* env) {
  if (G.sessionCls) return true;
  jclass c = env->FindClass(SESSION_CLS);
  if (!c) return false;
  G.sessionInit = env->GetMethodID(c, "<init>", "(J)V");
  G.sessionGetToken = env->GetMethodID(c, "getToken", "()J");
  G.sessionSetToken = env->GetMethodID(c, "setToken", "(J)V");
  if (env->ExceptionCheck() || !G.sessionInit || !G.sessionGetToken) { env->ExceptionClear(); env->DeleteLocalRef(c); return false; }
  G.sessionCls = (jclass)env->NewGlobalRef(c); env->DeleteLocalRef(c);
  // Optional: android.graphics.Bitmap for cursor images.
  jclass b = env->FindClass("android/graphics/Bitmap");
  jclass cfg = env->FindClass("android/graphics/Bitmap$Config");
  if (env->ExceptionCheck()) env->ExceptionClear();
  if (b && cfg) {
    jmethodID cb = env->GetStaticMethodID(b, "createBitmap", "(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;");
    jmethodID vo = env->GetStaticMethodID(cfg, "valueOf", "(Ljava/lang/String;)Landroid/graphics/Bitmap$Config;");
    if (env->ExceptionCheck()) env->ExceptionClear();
    if (cb && vo) {
      jstring n = env->NewStringUTF("ARGB_8888");
      jobject v = env->CallStaticObjectMethod(cfg, vo, n);
      if (env->ExceptionCheck()) env->ExceptionClear();
      env->DeleteLocalRef(n);
      if (v) { G.argb8888 = env->NewGlobalRef(v); env->DeleteLocalRef(v); G.bitmapCls = (jclass)env->NewGlobalRef(b); G.bitmapCreate = cb; }
    }
  }
  if (b) env->DeleteLocalRef(b);
  if (cfg) env->DeleteLocalRef(cfg);
  return true;
}

static Session* S(JNIEnv* env, jobject o) { return sessionFromObject(env, o); }

static bool readMap(JNIEnv* env, jobject map, Vec<KV>* out) {
  if (!map) return true;
  jclass mc = env->FindClass("java/util/Map"), sc = env->FindClass("java/util/Set"), ic = env->FindClass("java/util/Iterator"),
         ec = env->FindClass("java/util/Map$Entry");
  if (!mc || !sc || !ic || !ec) { env->ExceptionClear(); return false; }
  jmethodID entrySet = env->GetMethodID(mc, "entrySet", "()Ljava/util/Set;");
  jmethodID iterator = env->GetMethodID(sc, "iterator", "()Ljava/util/Iterator;");
  jmethodID hasNext = env->GetMethodID(ic, "hasNext", "()Z"), next = env->GetMethodID(ic, "next", "()Ljava/lang/Object;");
  jmethodID getKey = env->GetMethodID(ec, "getKey", "()Ljava/lang/Object;"), getValue = env->GetMethodID(ec, "getValue", "()Ljava/lang/Object;");
  jclass strc = env->FindClass("java/lang/String");
  jobject set = env->CallObjectMethod(map, entrySet);
  jobject it = env->CallObjectMethod(set, iterator);
  while (env->CallBooleanMethod(it, hasNext)) {
    jobject e = env->CallObjectMethod(it, next);
    jobject k = env->CallObjectMethod(e, getKey), v = env->CallObjectMethod(e, getValue);
    if (k && v && env->IsInstanceOf(k, strc) && env->IsInstanceOf(v, strc)) {
      JStr ks(env, k), vs(env, v); KV kv; kv.k = ks.get(); kv.v = vs.get(); out->push(kv);
    }
    if (k) env->DeleteLocalRef(k); if (v) env->DeleteLocalRef(v); env->DeleteLocalRef(e);
  }
  env->DeleteLocalRef(it); env->DeleteLocalRef(set);
  bool ok = !env->ExceptionCheck(); env->ExceptionClear();
  return ok;
}

// ---------------------------------------------------------------- SessionBindings
JF(jobject, SessionBindings_createSession, jobject desktopCb, jobject sessionCb, jstring address, jstring uuid, jobject options) {
  if (!ensureClasses(env)) { throwRuntime(env, "SessionBindings$Session class not available"); return nullptr; }
  if (!address || !desktopCb || !sessionCb) { throwRuntime(env, "invalid createSession arguments"); return nullptr; }
  JStr a(env, address); if (!a.ok()) return nullptr;
  JStr u(env, uuid);
  Vec<KV> opts; readMap(env, options, &opts);
  jobject out = nullptr;
  Session* s = sessionCreate(env, desktopCb, sessionCb, a.get(), u.get(), opts, &out);
  if (!s) { if (!env->ExceptionCheck()) throwRuntime(env, "failed to create session"); return nullptr; }
  return out;
}
JF(void, SessionBindings_closeSession, jobject session) { Session* s = S(env, session); if (s) s->requestClose(); }
JF(void, SessionBindings_destroySession, jobject session) { Session* s = S(env, session); if (s) sessionDestroy(env, s); }
JF(void, SessionBindings_pointerEvent, jobject session, jint x, jint y, jint mask) { Session* s = S(env, session); if (s) s->pointer(x, y, mask); }
JF(void, SessionBindings_wheelEvent, jobject session, jint horiz, jint delta) { Session* s = S(env, session); if (s) s->wheel(horiz, delta); }
JF(void, SessionBindings_keyDownEvent, jobject session, jlong keysym, jint unicode) {
  UNUSED(unicode);
  if (keysym < 0 || keysym > 0x7fffffffLL) { throwRuntime(env, "keysym out of range"); return; }
  Session* s = S(env, session); if (s) s->keyEvent(true, (u32)keysym);
}
JF(void, SessionBindings_keyUpEvent, jobject session, jint keysym) { Session* s = S(env, session); if (s) s->keyEvent(false, (u32)keysym); }
JF(void, SessionBindings_focusEvent, jobject session, jboolean f) { Session* s = S(env, session); if (s) s->focusEvent(f == JNI_TRUE); }
JF(void, SessionBindings_applyOptions, jobject session) { Session* s = S(env, session); if (s) s->applyOptions(); }
JF(jint, SessionBindings_authRetriesAllowed, jobject session) { Session* s = S(env, session); return s ? s->authAllowed : 4; }
JF(jint, SessionBindings_authRetriesRemaining, jobject session) {
  Session* s = S(env, session); if (!s) return 0;
  int r = s->authAllowed - s->authFailures; return r < 0 ? 0 : r;
}
JF(void, SessionBindings_setOption, jobject session, jstring key, jstring val) {
  Session* s = S(env, session); if (!s) return;
  JStr k(env, key), v(env, val); if (k.ok()) s->setOpt(k.get(), v.get());
}
JF(jobject, SessionBindings_setScaleBufferSize, jobject session, jint w, jint h) {
  Session* s = S(env, session); if (!s) return nullptr;
  void* p = s->resizeScaleBuf(w, h);
  if (!p) { throwRuntime(env, "invalid scale buffer size"); return nullptr; }
  return env->NewDirectByteBuffer(p, (jlong)w * h * 4);
}
JF(void, SessionBindings_copyScaledRegion, jfloat scale, jobject session, jint x, jint y, jint w, jint h) {
  Session* s = S(env, session); if (!s) return;
  if (!s->scaleBuf) { logf(LOG_ERR, "copyScaledRegion: scale buffer not allocated"); return; }
  s->scaledCopy(scale, s->scaleBuf, s->scaleW, s->scaleH, x, y, w, h);
}
JF(void, SessionBindings_getScaledPixels, jfloat scale, jobject session, jobject buf) {
  Session* s = S(env, session); if (!s || !buf) return;
  u8* p = (u8*)env->GetDirectBufferAddress(buf); jlong cap = env->GetDirectBufferCapacity(buf);
  if (!p || cap <= 0) return;
  int stride = (int)(s->fbW * scale); if (stride <= 0) return;
  int rows = (int)(cap / 4 / stride); if (rows <= 0) return;
  s->scaledCopy(scale, p, stride, rows, 0, 0, s->fbW, s->fbH);
}
JF(void, SessionBindings_getScaledBitmap, jfloat scale, jobject session, jobject bmp) {
  Session* s = S(env, session); if (!s || !bmp) return;
  AndroidBitmapInfo info; void* addr = nullptr;
  if (AndroidBitmap_getInfo(env, bmp, &info) != 0 || AndroidBitmap_lockPixels(env, bmp, &addr) != 0 || !addr) return;
  if (info.stride == info.width * 4 && info.width && info.height) s->scaledCopy(scale, (u8*)addr, (int)info.width, (int)info.height, 0, 0, s->fbW, s->fbH);
  else logf(LOG_WARN, "getScaledBitmap: unsupported bitmap layout");
  AndroidBitmap_unlockPixels(env, bmp);
}
// Remote Hub addition (not in the original library): copy one rectangle of the framebuffer straight into an
// ARGB_8888 android.graphics.Bitmap of the desktop's size - one lock, no scratch buffer, nothing else touched.
JF(void, SessionBindings_copyRegionToBitmap, jobject session, jobject bmp, jint x, jint y, jint w, jint h) {
  Session* s = S(env, session); if (!s || !bmp) return;
  AndroidBitmapInfo info; void* addr = nullptr;
  if (AndroidBitmap_getInfo(env, bmp, &info) != 0) return;
  if (info.format != 1 /* ANDROID_BITMAP_FORMAT_RGBA_8888 */ || (info.stride & 3) || !info.width || !info.height) { logf(LOG_WARN, "copyRegionToBitmap: unsupported bitmap layout"); return; }
  if (AndroidBitmap_lockPixels(env, bmp, &addr) != 0 || !addr) return;
  s->copyRegion((u8*)addr, (int)(info.stride / 4), (int)info.width, (int)info.height, x, y, w, h);
  AndroidBitmap_unlockPixels(env, bmp);
}
JF(void, SessionBindings_saveScreenshotToServerRec, jobject session, jobject rec) { UNUSED(env); UNUSED(session); UNUSED(rec); }
JF(void, SessionBindings_setPerUserTeamIds, jobject ids) { UNUSED(env); UNUSED(ids); }

// ---------------------------------------------------------------- ConnectionInfoBindings
#define CI(name, expr) JF(jstring, ConnectionInfoBindings_##name, jobject session) { Session* s = S(env, session); if (!s || !s->connected) return newStr(env, ""); return newStr(env, (expr).c()); }
CI(getDesktopName, s->desktopName)
CI(getDesktopSize, s->desktopSizeStr())
CI(getProtoVersion, strf("%d.%d", s->verMajor, s->verMinor))
CI(getSecurityDesc, s->secDesc)
CI(getLastUsedEncoding, s->lastEncoding)
CI(getServerPixelFormat, s->pixelFormatDesc(s->serverPF))
CI(getViewerPixelFormat, s->pixelFormatDesc(s->viewerPF))
CI(getConnectionType, Str("Direct (TCP)"))
JF(jstring, ConnectionInfoBindings_getLineSpeed, jobject session) { UNUSED(session); return newStr(env, ""); }
JF(jstring, ConnectionInfoBindings_isServerARD, jobject session) {
  Session* s = S(env, session); if (!s) return newStr(env, ""); return newStr(env, s->connected ? "false" : "");
}

// ---------------------------------------------------------------- dialog factories & results
template <class F> static void setFactory(JNIEnv* env, jobject* slot, jmethodID* mid, jobject f, const char* name, const char* sig) {
  replaceGlobalRef(env, slot, f); *mid = nullptr;
  if (!f) return;
  jclass c = env->GetObjectClass(f);
  *mid = env->GetMethodID(c, name, sig);
  if (env->ExceptionCheck()) { env->ExceptionClear(); logf(LOG_WARN, "factory method %s%s not found", name, sig); }
  env->DeleteLocalRef(c);
}
#define PKG "Lcom/realvnc/vncviewer/jni/"
JF(void, PasswdDlgBindings_setPasswdDlgFactory, jobject f) {
  setFactory<int>(env, &G.passwdFactory, &G.createPasswdDlg, f, "createPasswdDlg", "(" SESSION_SIG "JLjava/lang/String;)" PKG "PasswdDlgBindings$PasswdDlg;");
}
JF(void, MsgBoxBindings_setMsgBoxFactory, jobject f) {
  setFactory<int>(env, &G.msgBoxFactory, &G.createMsgBox, f, "createMsgBox", "(" SESSION_SIG "JLjava/lang/String;ILjava/lang/String;)" PKG "MsgBoxBindings$MsgBox;");
}
JF(void, InteractiveTextDlgBindings_setInteractiveTextDlgFactory, jobject f) {
  setFactory<int>(env, &G.itextFactory, &G.createInteractiveTextDlg, f, "createInteractiveTextDlg", "(" SESSION_SIG "J)" PKG "InteractiveTextDlgBindings$InteractiveTextDlg;");
}
JF(void, SecurityDlgBindings_setSecurityDlgFactory, jobject f) {
  setFactory<int>(env, &G.securityFactory, &G.createSecurityDlg, f, "createSecurityDlg", "(" SESSION_SIG "J)" PKG "SecurityDlgBindings$SecurityDlg;");
}
JF(void, AuthkeyChoiceDlgBindings_setAuthkeyChoiceDlgFactory, jobject f) {
  setFactory<int>(env, &G.authkeyFactory, &G.createAuthkeyChoiceDlg, f, "createAuthkeyChoiceDlg", "(" SESSION_SIG "J)" PKG "AuthkeyChoiceDlgBindings$AuthkeyChoiceDlg;");
}
JF(void, ReconnectorBindings_setDlgFactory, jobject f) {
  setFactory<int>(env, &G.reconnectFactory, &G.createReconnectDlg, f, "createReconnectDlg", "(" SESSION_SIG ")" PKG "ReconnectorBindings$ReconnectDlg;");
}
JF(void, StatusNotificationBindings_setStatusNotifier, jobject f) { replaceGlobalRef(env, &G.statusNotifier, f); }
JF(void, SecurityNotificationBindings_setSecurityNotifier, jobject f) { replaceGlobalRef(env, &G.securityNotifier, f); }
JF(void, SaveCredentialsBindings_setCredentialsStore, jobject f) { replaceGlobalRef(env, &G.credentialsStore, f); }
JF(void, SaveIdentityBindings_setIdentityStore, jobject f) { replaceGlobalRef(env, &G.identityStore, f); }
JF(void, SaveConnMethodBindings_setConnMethodStore, jobject f) { replaceGlobalRef(env, &G.connMethodStore, f); }

JF(void, PasswdDlgBindings_passwdResult, jlong h, jboolean ok, jstring user, jstring pass) {
  JStr u(env, user), p(env, pass); promptAnswer((u64)h, ok == JNI_TRUE, u.get(), p.get(), false, false);
}
JF(void, MsgBoxBindings_msgBoxResult, jlong h, jboolean ok) { UNUSED(env); promptAnswer((u64)h, ok == JNI_TRUE, "", "", false, false); }
JF(void, SecurityDlgBindings_securityResult, jlong h, jboolean ok, jboolean a, jboolean b) { UNUSED(env); promptAnswer((u64)h, ok == JNI_TRUE, "", "", a == JNI_TRUE, b == JNI_TRUE); }
JF(void, AuthkeyChoiceDlgBindings_identityChosen, jlong h, jboolean ok, jstring identity) {
  JStr i(env, identity); promptAnswer((u64)h, ok == JNI_TRUE, i.get(), "", false, false);
}
JF(void, InteractiveTextDlgBindings_promptResult, jlong h, jboolean ok, jobject responses) { UNUSED(env); UNUSED(responses); promptAnswer((u64)h, ok == JNI_TRUE, "", "", false, false); }
JF(jlong, InteractiveTextDlgBindings_00024UiResponses_nativeInit, jobject responses) { UNUSED(env); UNUSED(responses); return 0; }
JF(void, InteractiveTextDlgBindings_00024UiResponses_nativeClose, jlong p) { UNUSED(env); UNUSED(p); }
JF(jstring, InteractiveTextDlgBindings_getUsername, jlong a, jlong b) { UNUSED(a); UNUSED(b); return newStr(env, ""); }
JF(jint, InteractiveTextDlgBindings_enableOk, jlong h, jobject b) { UNUSED(env); UNUSED(h); UNUSED(b); return 0; }
JF(jint, InteractiveTextDlgBindings_enableElement, jlong h, jobject a, jobject b) { UNUSED(env); UNUSED(h); UNUSED(a); UNUSED(b); return 0; }
JF(jint, InteractiveTextDlgBindings_showElement, jlong h, jobject a, jobject b) { UNUSED(env); UNUSED(h); UNUSED(a); UNUSED(b); return 0; }
