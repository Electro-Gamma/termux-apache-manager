// RA4 client handshake / record / rekey state machine. See ra4.h and docs/RA4_RECOVERY.md.
#include "ra4.h"
#include "ra2.h"
#include "mbedtls/sha256.h"

namespace vr { namespace ra4 {

enum { M_HELLO = 0x15, M_SECURITY = 0x16, M_KEX = 0x17 };
enum { NEED_MORE = 0, OK = 1, BAD = -1 };

static void put16(Bytes* b, u32 v) { u8 x[2] = {(u8)(v >> 8), (u8)v}; b->append(x, 2); }
static void put32(Bytes* b, u32 v) { u8 x[4] = {(u8)(v >> 24), (u8)(v >> 16), (u8)(v >> 8), (u8)v}; b->append(x, 4); }
static u32 get16(const u8* p) { return ((u32)p[0] << 8) | p[1]; }
static u32 get32(const u8* p) { return ((u32)p[0] << 24) | ((u32)p[1] << 16) | ((u32)p[2] << 8) | p[3]; }

bool Client::fail(Str* err, const char* m) { st = S_FAILED; if (err) *err = m; return false; }

// process-wide local RSA key (generation is slow); regenerated only if a larger size is requested
static Mutex gKeyMu; static RsaKey* gKey = nullptr;
static const RsaKey* localKeyFor(int bits) {
  Lock l(gKeyMu);
  if (!gKey || gKey->bits < bits) { RsaKey* k = new RsaKey(); if (!k->generate(bits)) { delete k; return nullptr; } delete gKey; gKey = k; }
  return gKey;
}

bool Client::start(const HelloParams& p, Bytes* out, Str* err) {
  if (st != S_NEW) return fail(err, "RA4 client already started");
  hp = p;
  if (hp.nOffered <= 0 || hp.nOffered > 16) return fail(err, "No RA4 cipher suites offered");     // [BIN] rfb_cprotov5_no_ciphers
  bool needPsk = false;
  for (int i = 0; i < hp.nOffered; i++) {
    const Suite* s = suiteById(hp.offered[i]);
    if (!s) return fail(err, strf("Unknown RA4 cipher suite 0x%04x", hp.offered[i]).c());
    if (s->status != ST_IMPLEMENTED) return fail(err, strf("RA4 cipher suite %s is not supported: %s", s->name, s->statusNote).c());
    if (s->cipher == C_NULL && !hp.allowNull) return fail(err, "The Null cipher suite must be enabled explicitly");
    if (s->psk) needPsk = true;
  }
  if (needPsk) {   // [BIN 0x36bf20] "PSK too short": both PSKs >= 16 bytes
    if (!hp.myPsk.n || !hp.peerPsk.n) return fail(err, "PSK not available for connection");
    if (hp.myPsk.n < 16 || hp.peerPsk.n < 16) return fail(err, "PSK too short");
  }
  if (!hp.authList.n) put16(&hp.authList, 0);
  if (!ra2::randomBytes(clientRandom, 32)) return fail(err, "Random number generation failed");
  helloTx.clear(); put16(&helloTx, M_HELLO); helloTx.append(clientRandom, 32);
  put16(&helloTx, (u32)hp.nOffered); for (int i = 0; i < hp.nOffered; i++) put16(&helloTx, hp.offered[i]);
  helloTx.append(&hp.flag, 1); helloTx.append(hp.authList.p, hp.authList.n);
  out->append(helloTx.p, helloTx.n);
  st = S_HELLO_SENT; return true;
}

bool Client::emit(const Bytes& plain, Bytes* out) {
  if (sendPlain) return out->append(plain.p, plain.n);
  return core.seal(plain.p, plain.n, out);
}
bool Client::emitDigestMsg(Bytes* out) {
  u8 d[32]; if (!core.digest(true, d)) return false;
  Bytes m; put16(&m, M_SECURITY); u8 sub = 2; m.append(&sub, 1); m.append(d, 32);
  return emit(m, out);
}

// ---------------------------------------------------------------- server hello
int Client::onHello(const u8* p, size_t n, size_t* used, Bytes* out, Str* err) {
  if (n < 2 + 32 + 2) return NEED_MORE;
  const u8* srv = p + 2; u16 chosen = (u16)get16(p + 34);
  bool offered = false; for (int i = 0; i < hp.nOffered; i++) if (hp.offered[i] == chosen) offered = true;
  if (!offered) { fail(err, strf("chosen cipher %d not offered", chosen).c()); return BAD; }           // [BIN 0x38e538] anti-downgrade
  const Suite* s = suiteById(chosen);
  if (!s || s->status != ST_IMPLEMENTED) { fail(err, "Server selected an unsupported cipher suite"); return BAD; }
  if (s->cipher == C_NULL && !hp.allowNull) { fail(err, "Server selected the Null cipher suite"); return BAD; }
  *used = 36;
  // hello transcript [BIN 0x385ab4]
  Bytes ht; put32(&ht, hp.verMajor); put32(&ht, hp.verMinor);
  put16(&ht, (u32)hp.nOffered); for (int i = 0; i < hp.nOffered; i++) put16(&ht, hp.offered[i]);
  ht.append(&hp.flag, 1); ht.append(hp.authList.p, hp.authList.n);
  put32(&ht, hp.extA); put32(&ht, hp.extB); put16(&ht, chosen);
  core.init(s, true, clientRandom, srv, ht);
  if (s->cipher == C_NULL) { st = S_ESTABLISHED; return OK; }
  // our key-exchange message 1: ECDH public | RSA public (or the empty marker)
  if (!ecdh.generate(s->curve)) { fail(err, "ECDH key generation failed"); return BAD; }
  if (s->rsa) {
    local = injected ? injected : localKeyFor(hp.rsaBits > s->rsaMinBits ? hp.rsaBits : s->rsaMinBits);
    if (!local) { fail(err, "RSA key generation failed"); return BAD; }
    if (local->bits < s->rsaMinBits) { fail(err, strf("RSA key size of %d bits does not meet the %d bits required for %s", local->bits, s->rsaMinBits, s->name).c()); return BAD; }
  }
  msg1Local.clear(); put16(&msg1Local, M_KEX); ecdh.pubWire(&msg1Local);
  if (s->rsa) local->wire(&msg1Local); else put32(&msg1Local, 0xffffffffu);
  out->append(msg1Local.p, msg1Local.n);
  st = S_KEX; return OK;
}

// ---------------------------------------------------------------- key exchange messages (type 0x17)
int Client::onKex(const u8* p, size_t n, size_t* used, Bytes* out, Str* err) {
  const Suite* s = core.suite;
  if (!gotMsg1) {
    // msg1: type | u8 len | ecdh | rsa wire
    const size_t el = s->curve == 0 ? 32 : 56;
    if (n < 2 + 1 + el + 4) return NEED_MORE;
    size_t pos = 2;
    size_t u = 0; Ecdh& e = ecdh;
    if (p[pos] != el) { fail(err, "Bad length"); return BAD; }                                     // [BIN 0x44049c]
    if (!e.setPeer(p + pos, n - pos, &u)) { fail(err, "Invalid public key"); return BAD; }
    ecdhPeerWire.clear(); ecdhPeerWire.append(p + pos, u); pos += u;
    u32 bits = get32(p + pos);
    size_t rsaLen = 4;
    if (bits != 0xffffffffu) {
      if (bits < 1024 || bits > 8192) { fail(err, "Unsupported RSA key length"); return BAD; }
      size_t k = (bits + 7) / 8;
      if (n < pos + 4 + k + 2) return NEED_MORE;
      size_t elen = get16(p + pos + 4 + k);
      if (elen == 0 || elen > k) { fail(err, "bigNumReadV overflow"); return BAD; }
      if (n < pos + 6 + k + elen) return NEED_MORE;
      rsaLen = 6 + k + elen;
    }
    size_t ru = 0;
    if (!peerKey.parse(p + pos, rsaLen, &ru)) { fail(err, "Invalid RSA public key"); return BAD; }
    rsaPeerWire.clear(); rsaPeerWire.append(p + pos, ru); pos += ru;
    *used = pos;
    if (s->rsa) {
      if (!peerKey.has) { fail(err, "Public key not yet sent"); return BAD; }
      if (peerKey.bits < s->rsaMinBits) { fail(err, strf("RSA key size of %d bits does not meet the %d bits required for %s", peerKey.bits, s->rsaMinBits, s->name).c()); return BAD; }
    } else if (peerKey.has) { fail(err, "Unexpected RSA key for a PSK-only cipher suite"); return BAD; }
    if (s->psk && s->rsa) {                                                                       // [BIN 0x36c41c] peer identity pin
      if (hp.peerRsaHash.n != 32) { fail(err, "PSK not available for connection"); return BAD; }
      Bytes canon; peerKey.canonical(&canon); u8 h[32]; mbedtls_sha256(canon.p, canon.n, h, 0);
      if (!ctEqual(h, hp.peerRsaHash.p, 32)) { fail(err, "Bad peer identity"); return BAD; }
    }
    if (!ecdh.shared(&ecdhShared)) { fail(err, "Error generating secret key"); return BAD; }
    gotMsg1 = true;
    if (s->rsa) {                                                                                 // msg2: OAEP-encrypted nonce
      rLocal.clear(); rLocal.resize(s->nonceBytes);
      if (!ra2::randomBytes(rLocal.p, rLocal.n)) { fail(err, "Random number generation failed"); return BAD; }
      Bytes ct; if (!peerKey.encrypt(s->hashBits, rLocal.p, rLocal.n, &ct)) { fail(err, "RSA encrypt error"); return BAD; }
      Bytes m; put16(&m, M_KEX); put16(&m, (u32)ct.n); m.append(ct.p, ct.n);
      out->append(m.p, m.n); sentMsg2 = true;
      return OK;                                                                                  // wait for the server's msg2
    }
    return finishKex(out, err) ? OK : BAD;
  }
  // msg2: type | BE16 len | ciphertext
  if (n < 4) return NEED_MORE;
  size_t cl = get16(p + 2); if (n < 4 + cl) return NEED_MORE;
  *used = 4 + cl;
  Bytes pt; if (!local->decrypt(s->hashBits, p + 4, cl, &pt)) { fail(err, "RSA decrypt error"); return BAD; }
  if (pt.n != (size_t)s->nonceBytes) { fail(err, "Remote nonce size incorrect"); return BAD; }        // [BIN 0x36bc58]
  rPeer.clear(); rPeer.append(pt.p, pt.n); memset(pt.p, 0, pt.n);
  return finishKex(out, err) ? OK : BAD;
}

bool Client::finishKex(Bytes* out, Str* err) {
  const Suite* s = core.suite;
  // shared secret [BIN 0x36b554, 0x36c1fc]: BE16(|ecdh|) | ecdh | R_server | R_client [| BE16|my| my | BE16|peer| peer]
  Bytes sec; put16(&sec, (u32)ecdhShared.n); sec.append(ecdhShared.p, ecdhShared.n);
  if (s->rsa) { sec.append(rPeer.p, rPeer.n); sec.append(rLocal.p, rLocal.n); }      // client: server half first
  else { Bytes z; z.resize(2 * s->nonceBytes); memset(z.p, 0, z.n); sec.append(z.p, z.n); }   // [BIN-inf] zero buffer when no RSA
  if (s->psk) { put16(&sec, (u32)hp.myPsk.n); sec.append(hp.myPsk.p, hp.myPsk.n); put16(&sec, (u32)hp.peerPsk.n); sec.append(hp.peerPsk.p, hp.peerPsk.n); }
  // key-exchange transcript [BIN 0x36b974]: only built when RSA is part of the suite
  Bytes kexT;
  if (s->rsa) { kexT.append(ecdhPeerWire.p, ecdhPeerWire.n); kexT.append(msg1Local.p + 2, 1 + (s->curve == 0 ? 32 : 56));
                kexT.append(rsaPeerWire.p, rsaPeerWire.n); local->wire(&kexT); }
  if (!core.establish(sec, kexT)) return fail(err, "Key derivation failed");
  memset(sec.p, 0, sec.n); memset(ecdhShared.p, 0, ecdhShared.n);
  // digest in the clear, then our outgoing direction switches to the new keys [BIN-inf, log text at 0x384900]
  if (!emitDigestMsg(out)) return fail(err, "Digest computation failed");
  if (!core.installOut()) return fail(err, "Key installation failed");
  sendPlain = false; pendingIn = true; st = S_AWAIT_DIGEST;
  return true;
}

// ---------------------------------------------------------------- security messages (type 0x16)
int Client::onSecurity(const u8* p, size_t n, size_t* used, Bytes* out, Str* err) {
  if (n < 3) return NEED_MORE;
  const u8 sub = p[2];
  if (sub == 2) {                                                                                  // digest
    if (n < 3 + 32) return NEED_MORE;
    if (!pendingIn) { fail(err, "unexpected digest message"); return BAD; }
    if (!core.verifyDigest(p + 3)) { fail(err, "security failure (digest mismatch)"); return BAD; }   // [BIN 0x3843c4]
    *used = 35; pendingIn = false;
    if (!core.installIn()) { fail(err, "Key installation failed"); return BAD; }
    recvPlain = core.nullIn; if (!core.nullIn) recvPlain = false;
    if (st == S_AWAIT_DIGEST) st = S_ESTABLISHED;
    return OK;
  }
  if (st != S_ESTABLISHED && st != S_AWAIT_DIGEST) { fail(err, "cipher not established"); return BAD; }
  if (sub == 1) {                                                                                  // encryption change / key refresh
    if (n < 4) return NEED_MORE;
    if (st != S_ESTABLISHED) { fail(err, "bad key exchange sequence"); return BAD; }
    int v = p[3]; *used = 4;
    if (v == core.phaseIn) { /* key refresh */ }
    else if (v == 2 && core.suite->cipher == C_NE && core.phaseIn == 1) core.phaseIn = 2;
    else { fail(err, "invalid encryption change notification"); return BAD; }
    if (!core.refreshIn()) { fail(err, "re-key needed"); return BAD; }
    pendingIn = true; return OK;
  }
  if (sub == 0) {                                                                                  // key renegotiation
    if (st != S_ESTABLISHED) { fail(err, "bad key exchange sequence"); return BAD; }
    if (n < 5) return NEED_MORE;
    bool hasNonce = p[3] != 0, isResp = p[4] != 0;
    size_t need = 5 + (hasNonce ? 32 : 0); if (n < need) return NEED_MORE;
    *used = need;
    if (hasNonce && !isResp && rekeyState == 0) {                                                  // request 1/2
      u8 resp[32]; if (!core.onRekeyRequest(p + 5, resp)) { fail(err, "Rekey failed"); return BAD; }
      Bytes m; put16(&m, M_SECURITY); u8 h[3] = {0, 1, 1}; m.append(h, 3); m.append(resp, 32);
      if (!emit(m, out) || !emitDigestMsg(out) || !core.installOut()) { fail(err, "Rekey failed"); return BAD; }
      rekeyState = 2; return OK;
    }
    if (hasNonce && !isResp && rekeyState == 1) { fail(err, "simultaneous key renegotiation is not supported"); return BAD; }
    if (hasNonce && isResp && rekeyState == 1) {                                                   // response
      if (!core.onRekeyResponse(p + 5)) { fail(err, "Rekey failed"); return BAD; }
      Bytes m; put16(&m, M_SECURITY); u8 h[3] = {0, 0, 1}; m.append(h, 3);
      if (!emit(m, out) || !emitDigestMsg(out) || !core.installOut()) { fail(err, "Rekey failed"); return BAD; }
      rekeyState = 0; pendingIn = true; return OK;
    }
    if (!hasNonce && isResp && rekeyState == 2) {                                                  // request 2/2
      if (!core.onRekeyRequest2()) { fail(err, "Rekey failed"); return BAD; }
      rekeyState = 0; pendingIn = true; return OK;
    }
    fail(err, "bad key exchange sequence"); return BAD;                                            // [BIN 0x3839b8]
  }
  fail(err, "invalid subtype"); return BAD;
}

// ---------------------------------------------------------------- receive pipeline
bool Client::pullRecords(Str* err) {
  while (!recvPlain) {
    if (rawIn.n < 2) return true;
    const size_t len = get16(rawIn.p), tl = core.phaseIn == 2 ? 20 : 16;
    if (rawIn.n < 2 + len + tl) return true;
    size_t o = decBuf.n; if (!decBuf.resize(o + len)) return fail(err, "out of memory");
    bool ok = core.phaseIn == 2 ? core.hIn.open(rawIn.p, rawIn.p + 2, len, rawIn.p + 2 + len)
                                : core.gIn.open(rawIn.p, rawIn.p + 2, len, rawIn.p + 2 + len, decBuf.p + o);
    if (core.phaseIn == 2 && ok && len) memcpy(decBuf.p + o, rawIn.p + 2, len);
    if (!ok) return fail(err, core.phaseIn == 2 ? "HMAC authentication failure" : "AES authentication failure");
    size_t used = 2 + len + tl; memmove(rawIn.p, rawIn.p + used, rawIn.n - used); rawIn.n -= used;
    return true;     // one record at a time, so a key switch between records takes effect immediately
  }
  return true;
}

bool Client::pump(Bytes* out, Bytes* app, Str* err) {
  for (;;) {
    if (st == S_FAILED) return false;
    Bytes& cur = recvPlain ? rawIn : decBuf;
    if (!recvPlain && cur.n == 0) {
      size_t before = rawIn.n; if (!pullRecords(err)) return false;
      if (rawIn.n == before && decBuf.n == 0) return true;
      continue;
    }
    if (cur.n < 2) { if (recvPlain) return true; if (!pullRecords(err)) return false; if (decBuf.n < 2) return true; continue; }
    const u32 type = get16(cur.p); size_t used = 0; int r = NEED_MORE;
    switch (st) {
      case S_HELLO_SENT: if (type != M_HELLO) return fail(err, "invalid hello message type"); r = onHello(cur.p, cur.n, &used, out, err); break;
      case S_KEX:        if (type != M_KEX) return fail(err, "invalid key exchange message type"); r = onKex(cur.p, cur.n, &used, out, err); break;
      case S_AWAIT_DIGEST: if (type != M_SECURITY) return fail(err, "digest message required"); r = onSecurity(cur.p, cur.n, &used, out, err); break;
      case S_ESTABLISHED:
        if (type == M_SECURITY) { r = onSecurity(cur.p, cur.n, &used, out, err); break; }
        if (core.suite->cipher == C_NULL || !recvPlain) { app->append(cur.p, cur.n); cur.clear(); continue; }
        app->append(cur.p, cur.n); cur.clear(); return true;
      default: return false;
    }
    if (r == BAD) return false;
    if (r == NEED_MORE) { if (recvPlain) return true; size_t b = rawIn.n; if (!pullRecords(err)) return false; if (rawIn.n == b) return true; continue; }
    Bytes& c2 = recvPlain ? rawIn : decBuf;
    // the key-switch may have flipped recvPlain; the consumed bytes belong to the buffer that was parsed
    Bytes& parsed = (&c2 == &cur) ? c2 : cur;
    memmove(parsed.p, parsed.p + used, parsed.n - used); parsed.n -= used;
  }
}

bool Client::feed(const u8* d, size_t n, Bytes* out, Bytes* app, Str* err) {
  if (st == S_FAILED) { if (err) *err = "RA4 session failed"; return false; }
  if (st == S_NEW) return fail(err, "RA4 session not started");
  if (!rawIn.append(d, n)) return fail(err, "out of memory");
  return pump(out, app, err);
}

bool Client::send(const u8* d, size_t n, Bytes* out, Str* err) {
  if (st != S_ESTABLISHED) return fail(err, "cipher not established");
  Bytes m; m.append(d, n); return emit(m, out) ? true : fail(err, "encryption failed");
}
bool Client::rekey(Bytes* out, Str* err) {
  if (st != S_ESTABLISHED || core.suite->cipher == C_NULL) return fail(err, "cipher not established");
  if (rekeyState != 0 || pendingIn) return fail(err, "re-key already in progress");
  u8 nonce[32]; if (!core.beginRekey(nonce)) return fail(err, "Rekey failed");
  Bytes m; put16(&m, M_SECURITY); u8 h[3] = {0, 1, 0}; m.append(h, 3); m.append(nonce, 32);
  if (!emit(m, out)) return fail(err, "Rekey failed");
  rekeyState = 1; return true;
}
bool Client::refreshKeys(Bytes* out, Str* err) {
  if (st != S_ESTABLISHED || core.suite->cipher == C_NULL) return fail(err, "cipher not established");
  if (rekeyState != 0) return fail(err, "re-key already in progress");
  if (!core.refreshOutChecked()) return fail(err, "re-key needed");                                   // [BIN 0x38508c]
  Bytes m; put16(&m, M_SECURITY); u8 h[2] = {1, (u8)core.phaseOut}; m.append(h, 2);
  if (!emit(m, out) || !emitDigestMsg(out) || !core.installOut()) return fail(err, "Key refresh failed");
  return true;
}
bool Client::switchToNullHmac(Bytes* out, Str* err) {
  if (st != S_ESTABLISHED || core.suite->cipher != C_NE || core.phaseOut != 1) return fail(err, "encryption change not allowed");
  if (rekeyState != 0) return fail(err, "re-key already in progress");
  if (!core.refreshOutChecked()) return fail(err, "re-key needed");
  Bytes m; put16(&m, M_SECURITY); u8 h[2] = {1, 2}; m.append(h, 2);
  // the notification and its digest are still sealed with the old (GCM) keys; only then does the outgoing side switch to NULL-HMAC
  bool ok = emit(m, out) && emitDigestMsg(out);
  core.phaseOut = 2;
  if (!ok || !core.installOut()) return fail(err, "Encryption change failed");
  return true;
}

}}  // namespace vr::ra4

namespace vr { namespace ra4 {
void Client::reset() { this->~Client(); new (this) Client(); }
}}
