#define MBEDTLS_ALLOW_PRIVATE_ACCESS
// RA4 implementation. See ra4.h and docs/RA4_RECOVERY.md.
#include "ra4.h"
#include "ra2.h"
#include "mbedtls/md.h"
#include "mbedtls/ecp.h"
#include "mbedtls/bignum.h"

namespace vr { namespace ra4 {

// ================================================================== suite registry
static const Suite kSuites[] = {
  // id,     name,                desc,                                                       ci keyB hash psk    rsa    rmin curve nb  status
  {0x0001, "Null",              "NULL key exchange, NULL encryption",                         1, 0,   256, false, false, 0,    -1, 0,  ST_IMPLEMENTED, "negotiation only; no keys, refused unless allowNull"},
  {0x0101, "SignOnly",          "RSA-PSS, SHA-256, NULL encryption",                          1, 0,   256, false, true,  1024, -1, 0,  ST_UNSUPPORTED, "[UNKNOWN] RSA-PSS exchange (CCipherSignOnly 0x369084) not recovered"},
  {0x0202, "RA4_128",           "RSA-OAEP, ECDHE-Curve25519, SHA-256, AES-GCM-128",           2, 128, 256, false, true,  1024, 0,  16, ST_IMPLEMENTED, ""},
  {0x0303, "RA4_256",           "RSA-OAEP, ECDHE-Curve25519, SHA-512, AES-GCM-256",           3, 256, 512, false, true,  2048, 0,  32, ST_IMPLEMENTED, ""},
  {0x0b03, "RA4b_256",          "RSA-OAEP, ECDHE-Curve448, SHA-512, AES-GCM-256",             3, 256, 512, false, true,  2048, 1,  32, ST_IMPLEMENTED, ""},
  {0x0204, "RA4ne_128",         "RSA-OAEP, ECDHE-Curve25519, SHA-256, AES-GCM-128/NULL-HMAC-SHA1", 4, 128, 256, false, true, 1024, 0, 16, ST_IMPLEMENTED, "AES-GCM during login, NULL-HMAC-SHA1 after (switch trigger BIN-inf)"},
  {0x0402, "RA4-PSK-Only_128",  "ECDHE-Curve25519, PSK, SHA-256, AES-GCM-128",                2, 128, 256, true,  false, 0,    0,  16, ST_IMPLEMENTED, ""},
  {0x0403, "RA4-PSK-Only_256",  "ECDHE-Curve25519, PSK, SHA-512, AES-GCM-256",                3, 256, 512, true,  false, 0,    0,  32, ST_IMPLEMENTED, ""},
  {0x0c03, "RA4b-PSK-Only_256", "ECDHE-Curve448, PSK, SHA-512, AES-GCM-256",                  3, 256, 512, true,  false, 0,    1,  32, ST_IMPLEMENTED, ""},
  {0x0602, "RA4-PSK_128",       "RSA-OAEP, ECDHE-Curve25519, PSK, SHA-256, AES-GCM-128",      2, 128, 256, true,  true,  1024, 0,  16, ST_IMPLEMENTED, ""},
  {0x0703, "RA4-PSK_256",       "RSA-OAEP, ECDHE-Curve25519, PSK, SHA-512, AES-GCM-256",      3, 256, 512, true,  true,  2048, 0,  32, ST_IMPLEMENTED, ""},
  {0x0f03, "RA4b-PSK_256",      "RSA-OAEP, ECDHE-Curve448, PSK, SHA-512, AES-GCM-256",        3, 256, 512, true,  true,  2048, 1,  32, ST_IMPLEMENTED, ""},
};
size_t suiteCount() { return sizeof kSuites / sizeof kSuites[0]; }
const Suite& suiteAt(size_t i) { return kSuites[i]; }
const Suite* suiteById(u16 id) { for (const Suite& s : kSuites) if (s.id == id) return &s; return nullptr; }
const Suite* suiteByName(const char* n) { for (const Suite& s : kSuites) if (strcasecmp(s.name, n) == 0) return &s; return nullptr; }

int defaultPreference(u16* out, int max, bool includeNull) {
  // strongest first; PSK suites are only sensible when a PSK is configured, so the caller filters them.
  static const u16 order[] = {0x0b03, 0x0303, 0x0703, 0x0f03, 0x0403, 0x0c03, 0x0202, 0x0602, 0x0402, 0x0204};
  int n = 0;
  for (u16 id : order) if (n < max) out[n++] = id;
  if (includeNull && n < max) out[n++] = 0x0001;
  return n;
}

int parsePreference(const char* s, u16* out, int max, Str* err) {
  if (!s || !*s) return defaultPreference(out, max, false);
  int n = 0; const char* p = s;
  while (*p) {
    while (*p == ',' || *p == ' ' || *p == ';' || *p == '\t') p++;
    if (!*p) break;
    char tok[48]; size_t k = 0;
    while (*p && *p != ',' && *p != ' ' && *p != ';' && *p != '\t' && k + 1 < sizeof tok) tok[k++] = *p++;
    tok[k] = 0;
    const Suite* su = nullptr;
    if (tok[0] == '0' && (tok[1] == 'x' || tok[1] == 'X')) { char* e; unsigned long v = strtoul(tok, &e, 16); if (*e == 0 && v <= 0xffff) su = suiteById((u16)v); }
    else su = suiteByName(tok);
    if (!su) { if (err) *err = strf("Unknown RA4 cipher suite '%s'", tok); return -1; }
    for (int i = 0; i < n; i++) if (out[i] == su->id) { if (err) *err = strf("Duplicate RA4 cipher suite '%s'", tok); return -1; }
    if (n >= max) { if (err) *err = "Too many RA4 cipher suites"; return -1; }
    out[n++] = su->id;
  }
  if (n == 0) { if (err) *err = "Empty RA4 cipher suite list"; return -1; }
  return n;
}

// ================================================================== primitives
bool randomBytes(void* out, size_t n) { return ra2::randomBytes(out, n); }
bool ctEqual(const u8* a, const u8* b, size_t n) { u8 d = 0; for (size_t i = 0; i < n; i++) d |= a[i] ^ b[i]; return d == 0; }

static mbedtls_md_type_t mdFor(int bits) {
  switch (bits) { case 160: return MBEDTLS_MD_SHA1; case 256: return MBEDTLS_MD_SHA256; case 512: return MBEDTLS_MD_SHA512; default: return MBEDTLS_MD_NONE; }
}
bool hmac(int hb, const u8* key, size_t kl, const u8* data, size_t dl, u8* out) {
  mbedtls_md_type_t t = mdFor(hb); if (t == MBEDTLS_MD_NONE) return false;
  const mbedtls_md_info_t* mi = mbedtls_md_info_from_type(t); if (!mi) return false;
  static const u8 z = 0;
  return mbedtls_md_hmac(mi, key ? key : &z, kl, data ? data : &z, dl, out) == 0;
}
bool kdf(int hb, const u8* key, size_t kl, const u8* data, size_t dl, const u8* info, size_t il, size_t outLen, u8* out) {
  if (hb != 256 && hb != 512) return false;
  const size_t hl = (size_t)hb / 8;
  u8 prk[64]; if (!hmac(hb, key, kl, data, dl, prk)) return false;
  Bytes buf; if (!buf.resize(hl + il + 1)) return false;
  u8 t[64]; size_t have = 0, done = 0; u8 ctr = 1;
  while (done < outLen) {
    size_t o = 0;
    if (have) { memcpy(buf.p, t, hl); o = 0; } else o = hl;       // T(0) is empty: skip the T slot on the first round
    if (il) memcpy(buf.p + hl, info, il);
    buf.p[hl + il] = ctr;
    if (!hmac(hb, prk, hl, buf.p + o, (have ? hl : 0) + il + 1, t)) return false;
    have = hl; size_t c = outLen - done < hl ? outLen - done : hl;
    memcpy(out + done, t, c); done += c;
    if (++ctr == 0 && done < outLen) return false;               // > 255 blocks: not representable
  }
  memset(prk, 0, sizeof prk); memset(t, 0, sizeof t);
  return true;
}

bool gcmSeal(const u8* key, size_t kl, const u8 iv[12], const u8* aad, size_t al, const u8* in, size_t n, u8* out) {
  if (kl != 16 && kl != 32) return false;
  mbedtls_gcm_context g; mbedtls_gcm_init(&g);
  bool ok = mbedtls_gcm_setkey(&g, MBEDTLS_CIPHER_ID_AES, key, (unsigned)kl * 8) == 0 &&
            mbedtls_gcm_crypt_and_tag(&g, MBEDTLS_GCM_ENCRYPT, n, iv, 12, aad, al, in, out, 16, out + n) == 0;
  mbedtls_gcm_free(&g); return ok;
}
bool gcmOpen(const u8* key, size_t kl, const u8 iv[12], const u8* aad, size_t al, const u8* in, size_t n, u8* out) {
  if (kl != 16 && kl != 32) return false;
  mbedtls_gcm_context g; mbedtls_gcm_init(&g);
  bool ok = mbedtls_gcm_setkey(&g, MBEDTLS_CIPHER_ID_AES, key, (unsigned)kl * 8) == 0 &&
            mbedtls_gcm_auth_decrypt(&g, n, iv, 12, aad, al, in + n, 16, in, out) == 0;
  mbedtls_gcm_free(&g); return ok;
}

// ================================================================== ECDHE
static int rngCb(void*, unsigned char* o, size_t n) { return ra2::randomBytes(o, n) ? 0 : -1; }

bool Ecdh::generate(int c) {
  if (c != 0 && c != 1) return false;
  mbedtls_ecdh_free(&ctx); mbedtls_ecdh_init(&ctx); ready = false;
  if (mbedtls_ecdh_setup(&ctx, c == 0 ? MBEDTLS_ECP_DP_CURVE25519 : MBEDTLS_ECP_DP_CURVE448) != 0) return false;
  unsigned char buf[80]; size_t ol = 0;
  if (mbedtls_ecdh_make_public(&ctx, &ol, buf, sizeof buf, rngCb, nullptr) != 0) return false;
  curve = c; pubRaw.clear(); pubRaw.append(buf, ol); ready = true;
  return ol == (c == 0 ? 33u : 57u);
}
bool Ecdh::generateWithPrivate(int c, const u8* priv, size_t n) {
  const size_t want = c == 0 ? 32 : 56; if ((c != 0 && c != 1) || n != want) return false;
  mbedtls_ecdh_free(&ctx); mbedtls_ecdh_init(&ctx); ready = false;
  if (mbedtls_ecdh_setup(&ctx, c == 0 ? MBEDTLS_ECP_DP_CURVE25519 : MBEDTLS_ECP_DP_CURVE448) != 0) return false;
  u8 k[56]; memcpy(k, priv, n);
  if (c == 0) { k[0] &= 248; k[31] &= 127; k[31] |= 64; } else { k[0] &= 252; k[55] |= 128; }     // RFC 7748 decodeScalar
  mbedtls_ecdh_context_mbed* m = &ctx.MBEDTLS_PRIVATE(ctx).MBEDTLS_PRIVATE(mbed_ecdh);
  if (mbedtls_mpi_read_binary_le(&m->d, k, n) != 0) return false;
  if (mbedtls_ecp_mul(&m->grp, &m->Q, &m->d, &m->grp.G, rngCb, nullptr) != 0) return false;
  u8 pt[57]; size_t ol = 0;
  if (mbedtls_ecp_point_write_binary(&m->grp, &m->Q, MBEDTLS_ECP_PF_UNCOMPRESSED, &ol, pt + 1, sizeof pt - 1) != 0) return false;
  pt[0] = (u8)ol; curve = c; pubRaw.clear(); pubRaw.append(pt, ol + 1); ready = true; return ol == n;
}
void Ecdh::pubWire(Bytes* out) const { out->append(pubRaw.p, pubRaw.n); }
bool Ecdh::setPeer(const u8* p, size_t n, size_t* used) {
  if (!ready) return false;
  const size_t want = curve == 0 ? 32 : 56;
  if (n < 1 + want || p[0] != want) return false;
  if (mbedtls_ecdh_read_public(&ctx, p, 1 + want) != 0) return false;
  peerRaw.clear(); peerRaw.append(p, 1 + want); *used = 1 + want; return true;
}
bool Ecdh::shared(Bytes* out) const {
  if (!ready || !peerRaw.n) return false;
  u8 buf[64]; size_t ol = 0;
  Ecdh* self = const_cast<Ecdh*>(this);
  if (mbedtls_ecdh_calc_secret(&self->ctx, &ol, buf, sizeof buf, rngCb, nullptr) != 0) return false;
  if (ol != (curve == 0 ? 32u : 56u)) return false;
  u8 acc = 0; for (size_t i = 0; i < ol; i++) acc |= buf[i];
  if (!acc) return false;                                     // low-order point: refuse an all-zero secret
  out->clear(); out->append(buf, ol); memset(buf, 0, sizeof buf); return true;
}

// ================================================================== RSA
bool RsaKey::generate(int b) {
  mbedtls_rsa_free(&rsa); mbedtls_rsa_init(&rsa); has = false;
  if (mbedtls_rsa_gen_key(&rsa, rngCb, nullptr, (unsigned)b, 65537) != 0) return false;
  has = true; bits = b; return true;
}
bool RsaKey::setPublic(const u8* n, size_t nl, const u8* e, size_t el) {
  mbedtls_rsa_free(&rsa); mbedtls_rsa_init(&rsa); has = false;
  if (mbedtls_rsa_import_raw(&rsa, n, nl, nullptr, 0, nullptr, 0, nullptr, 0, e, el) != 0 || mbedtls_rsa_complete(&rsa) != 0) return false;
  bits = (int)mbedtls_rsa_get_len(&rsa) * 8; has = true;
  // exact bit length of N
  mbedtls_mpi N; mbedtls_mpi_init(&N);
  if (mbedtls_rsa_export(&rsa, &N, nullptr, nullptr, nullptr, nullptr) == 0) bits = (int)mbedtls_mpi_bitlen(&N);
  mbedtls_mpi_free(&N); return true;
}
static void put32(Bytes* b, u32 v) { u8 x[4] = {(u8)(v >> 24), (u8)(v >> 16), (u8)(v >> 8), (u8)v}; b->append(x, 4); }
static void put16(Bytes* b, u32 v) { u8 x[2] = {(u8)(v >> 8), (u8)v}; b->append(x, 2); }
void RsaKey::wire(Bytes* out) const {
  if (!has) { put32(out, 0xffffffffu); return; }
  mbedtls_mpi N, E; mbedtls_mpi_init(&N); mbedtls_mpi_init(&E);
  mbedtls_rsa_export(&rsa, &N, nullptr, nullptr, nullptr, &E);
  size_t k = (size_t)(bits + 7) / 8, el = mbedtls_mpi_size(&E); if (!el) el = 1;
  put32(out, (u32)bits);
  size_t o = out->n; out->resize(o + k); mbedtls_mpi_write_binary(&N, out->p + o, k);
  put16(out, (u32)el); o = out->n; out->resize(o + el); mbedtls_mpi_write_binary(&E, out->p + o, el);
  mbedtls_mpi_free(&N); mbedtls_mpi_free(&E);
}
void RsaKey::canonical(Bytes* out) const {
  if (!has) { put32(out, 0xffffffffu); return; }
  mbedtls_mpi N, E; mbedtls_mpi_init(&N); mbedtls_mpi_init(&E);
  mbedtls_rsa_export(&rsa, &N, nullptr, nullptr, nullptr, &E);
  size_t k = (size_t)(bits + 7) / 8;
  put32(out, (u32)bits);
  size_t o = out->n; out->resize(o + 2 * k);
  mbedtls_mpi_write_binary(&N, out->p + o, k); mbedtls_mpi_write_binary(&E, out->p + o + k, k);
  mbedtls_mpi_free(&N); mbedtls_mpi_free(&E);
}
bool RsaKey::parse(const u8* p, size_t n, size_t* used) {
  if (n < 4) return false;
  u32 b = ((u32)p[0] << 24) | ((u32)p[1] << 16) | ((u32)p[2] << 8) | p[3];
  mbedtls_rsa_free(&rsa); mbedtls_rsa_init(&rsa); has = false;
  if (b == 0xffffffffu) { *used = 4; bits = 0; return true; }
  if (b < 1024 || b > 8192) return false;                       // [BIN 0x441f60] "Unsupported RSA key length"
  size_t k = (b + 7) / 8; if (n < 4 + k + 2) return false;
  size_t el = ((size_t)p[4 + k] << 8) | p[5 + k];
  if (el == 0 || el > k || n < 6 + k + el) return false;       // [BIN 0x442670] bigNumReadV overflow if > k
  if (!setPublic(p + 4, k, p + 6 + k, el)) return false;
  if ((u32)bits != b) { mbedtls_rsa_free(&rsa); mbedtls_rsa_init(&rsa); has = false; return false; }   // declared size must match N
  *used = 6 + k + el; return true;
}
bool RsaKey::encrypt(int hb, const u8* in, size_t n, Bytes* ct) const {
  mbedtls_md_type_t t = mdFor(hb); if (!has || (hb != 256 && hb != 512)) return false;
  mbedtls_rsa_context* r = const_cast<mbedtls_rsa_context*>(&rsa);
  if (mbedtls_rsa_set_padding(r, MBEDTLS_RSA_PKCS_V21, t) != 0) return false;
  size_t k = mbedtls_rsa_get_len(r); if (!ct->resize(k)) return false;
  return mbedtls_rsa_pkcs1_encrypt(r, rngCb, nullptr, n, in, ct->p) == 0;
}
bool RsaKey::decrypt(int hb, const u8* ct, size_t cl, Bytes* out) const {
  mbedtls_md_type_t t = mdFor(hb); if (!has || (hb != 256 && hb != 512)) return false;
  mbedtls_rsa_context* r = const_cast<mbedtls_rsa_context*>(&rsa);
  if (mbedtls_rsa_set_padding(r, MBEDTLS_RSA_PKCS_V21, t) != 0) return false;
  size_t k = mbedtls_rsa_get_len(r); if (cl != k) return false;     // [BIN 0x4422b8] bad length
  if (!out->resize(k)) return false;
  size_t ol = 0;
  if (mbedtls_rsa_pkcs1_decrypt(r, rngCb, nullptr, &ol, ct, out->p, k) != 0) return false;
  out->n = ol; return true;
}

// ================================================================== records
static void incLE(u8* c, size_t n) { for (size_t i = 0; i < n; i++) if (++c[i] != 0) break; }

bool GcmRecord::init(const u8* key, size_t kl, const u8 iv12[12]) {
  if (kl != 16 && kl != 32) return false;
  mbedtls_gcm_free(&g); mbedtls_gcm_init(&g);
  if (mbedtls_gcm_setkey(&g, MBEDTLS_CIPHER_ID_AES, key, (unsigned)kl * 8) != 0) return false;
  memcpy(iv, iv12, 12); ready = true; records = 0; return true;
}
bool GcmRecord::seal(const u8* in, size_t n, Bytes* out) {
  if (!ready || n > 0xffff) return false;
  size_t o = out->n; if (!out->resize(o + 2 + n + 16)) return false;
  out->p[o] = (u8)(n >> 8); out->p[o + 1] = (u8)n;
  if (mbedtls_gcm_crypt_and_tag(&g, MBEDTLS_GCM_ENCRYPT, n, iv, 12, out->p + o, 2, in, out->p + o + 2, 16, out->p + o + 2 + n) != 0) { out->n = o; return false; }
  incLE(iv, 12); records++; return true;
}
bool GcmRecord::open(const u8* hdr2, const u8* ct, size_t n, const u8* tag, u8* out) {
  if (!ready) return false;
  if (mbedtls_gcm_auth_decrypt(&g, n, iv, 12, hdr2, 2, tag, 16, ct, out) != 0) return false;
  incLE(iv, 12); records++; return true;
}
bool HmacRecord::init(const u8 k[64], const u8 c[16]) { memcpy(key, k, 64); memcpy(counter, c, 16); ready = true; return true; }
bool HmacRecord::seal(const u8* in, size_t n, Bytes* out) {
  if (!ready || n > 0xffff) return false;
  size_t o = out->n; if (!out->resize(o + 2 + n + 20)) return false;
  out->p[o] = (u8)(n >> 8); out->p[o + 1] = (u8)n; if (n) memcpy(out->p + o + 2, in, n);
  Bytes m; m.append(counter, 16); m.append(out->p + o, 2 + n);
  bool ok = hmac(160, key, 64, m.p, m.n, out->p + o + 2 + n);
  if (!ok) { out->n = o; return false; }
  incLE(counter, 16); return true;
}
bool HmacRecord::open(const u8* hdr2, const u8* pt, size_t n, const u8* mac) {
  if (!ready) return false;
  Bytes m; m.append(counter, 16); m.append(hdr2, 2); m.append(pt, n);
  u8 want[20]; if (!hmac(160, key, 64, m.p, m.n, want) || !ctEqual(want, mac, 20)) return false;
  incLE(counter, 16); return true;
}

// ================================================================== Core (key schedule)
static const char* kLabelMaster = "RfbMasterSecret";
static const char* kLabelSession = "RfbSessionId";

void Core::init(const Suite* s, bool client, const u8 local[32], const u8 peer[32], const Bytes& hello) {
  suite = s; isClient = client;
  memcpy(nonceA, local, 32); memcpy(nonceC, local, 32); memcpy(nonceB, peer, 32);
  transcript.clear(); transcript.append(hello.p, hello.n);
  masterOut.clear(); masterIn.clear(); sessionId.clear(); ctrIn = ctrOut = 0; phaseIn = phaseOut = 1; keyed = false;
  nullOut = nullIn = false;
}

// info = server nonce | client nonce [| session id]   [BIN 0x384d10]
bool Core::nonceInfo(bool outDir, u8 info[96], size_t* il, bool withSession) const {
  const u8* local = outDir ? nonceA : nonceC;
  memcpy(info, isClient ? nonceB : local, 32);
  memcpy(info + 32, isClient ? local : nonceB, 32);
  *il = 64;
  if (withSession) { if (sessionId.n != 32) return false; memcpy(info + 64, sessionId.p, 32); *il = 96; }
  return true;
}
bool Core::establish(const Bytes& secret, const Bytes& kexT) {
  if (!suite) return false;
  u8 info[96]; size_t il;
  if (!nonceInfo(true, info, &il, false)) return false;
  u8 m[48]; const size_t ll = strlen(kLabelMaster);
  if (!kdf(suite->hashBits, (const u8*)kLabelMaster, ll, secret.p, secret.n, info, il, 48, m)) return false;
  masterOut.clear(); masterOut.append(m, 48); masterIn.clear(); masterIn.append(m, 48);
  u8 sid[32];
  if (!kdf(suite->hashBits, (const u8*)kLabelSession, strlen(kLabelSession), m, 48, info, il, 32, sid)) return false;
  sessionId.clear(); sessionId.append(sid, 32);
  transcript.append(kexT.p, kexT.n);
  ctrIn = ctrOut = 0; keyed = true; memset(m, 0, 48); return true;
}
static void be32(u8* o, u32 v) { o[0] = (u8)(v >> 24); o[1] = (u8)(v >> 16); o[2] = (u8)(v >> 8); o[3] = (u8)v; }

bool Core::digest(bool forSend, u8 out[32]) const {
  if (!suite || !masterOut.n) return false;
  // sender uses the label of the receiving role  [BIN 0x384900 / 0x3843c4]
  const char* label = forSend ? (isClient ? "RfbServerDigest" : "RfbClientDigest") : (isClient ? "RfbClientDigest" : "RfbServerDigest");
  u8 key[40]; size_t ll = strlen(label); memcpy(key, label, ll); be32(key + ll, forSend ? ctrOut : ctrIn);
  u8 info96[96]; size_t il; if (!nonceInfo(forSend, info96, &il, false)) return false;
  Bytes info; info.append(info96, 64); info.append(transcript.p, transcript.n);
  const Bytes& m = forSend ? masterOut : masterIn;
  return kdf(suite->hashBits, key, ll + 4, m.p, m.n, info.p, info.n, 32, out);
}
bool Core::verifyDigest(const u8 d[32]) const { u8 w[32]; return digest(false, w) && ctEqual(w, d, 32); }

bool Core::keyingMaterial(bool out, size_t len, u8* buf) const {
  if (!suite || !masterOut.n) return false;
  // label is named after the receiving role: client's incoming == server's outgoing  [BIN 0x384f10]
  const bool clientLabel = (isClient == !out);
  const char* label = clientLabel ? "RfbClientKeyingMaterial" : "RfbServerKeyingMaterial";
  u8 key[40]; size_t ll = strlen(label); memcpy(key, label, ll); be32(key + ll, out ? ctrOut : ctrIn);
  u8 info[96]; size_t il; if (!nonceInfo(out, info, &il, true)) return false;
  const Bytes& m = out ? masterOut : masterIn;
  return kdf(suite->hashBits, key, ll + 4, m.p, m.n, info, il, len, buf);
}
bool Core::installOut() {
  if (suite->cipher == C_NULL) { nullOut = true; return true; }
  if (phaseOut == 2) { u8 b[0x50]; if (!keyingMaterial(true, 0x50, b)) return false; bool ok = hOut.init(b, b + 64); memset(b, 0, sizeof b); return ok; }
  size_t kl = suite->keyBits / 8; u8 b[44];
  if (!keyingMaterial(true, kl + 12, b)) return false;
  bool ok = gOut.init(b, kl, b + kl); memset(b, 0, sizeof b); return ok;
}
bool Core::installIn() {
  if (suite->cipher == C_NULL) { nullIn = true; return true; }
  if (phaseIn == 2) { u8 b[0x50]; if (!keyingMaterial(false, 0x50, b)) return false; bool ok = hIn.init(b, b + 64); memset(b, 0, sizeof b); return ok; }
  size_t kl = suite->keyBits / 8; u8 b[44];
  if (!keyingMaterial(false, kl + 12, b)) return false;
  bool ok = gIn.init(b, kl, b + kl); memset(b, 0, sizeof b); return ok;
}
bool Core::seal(const u8* in, size_t n, Bytes* out) {
  if (suite->cipher == C_NULL) return out->append(in, n);
  const size_t chunk = 0x2000;                                  // AesGcmOutStream buffer size [BIN 0x369e64]
  do {
    size_t c = n < chunk ? n : chunk;
    bool ok = phaseOut == 2 ? hOut.seal(in, c, out) : gOut.seal(in, c, out);
    if (!ok) return false;
    in += c; n -= c;
  } while (n);
  return true;
}

// master secret rekey derivation [BIN 0x3839b8 -> 0x384d10]: new = KDF("RfbMasterSecret", old, S|C)
bool Core::deriveMaster(Bytes* m, bool committed) {
  u8 info[96]; size_t il; if (!nonceInfo(!committed, info, &il, false)) return false;
  u8 nm[48];
  if (!kdf(suite->hashBits, (const u8*)kLabelMaster, strlen(kLabelMaster), m->p, m->n, info, il, 48, nm)) return false;
  m->clear(); m->append(nm, 48); memset(nm, 0, 48); return true;
}
bool Core::beginRekey(u8 nonce[32]) {
  if (!keyed) return false;
  if (!randomBytes(nonceA, 32)) return false;
  memcpy(nonce, nonceA, 32); return true;
}
bool Core::onRekeyRequest(const u8 peer[32], u8 resp[32]) {
  if (!keyed) return false;
  if (!randomBytes(nonceA, 32)) return false;
  memcpy(nonceB, peer, 32); memcpy(resp, nonceA, 32);
  if (!deriveMaster(&masterOut, false)) return false;
  ctrOut = 0; return true;
}
bool Core::onRekeyResponse(const u8 peer[32]) {
  if (!keyed) return false;
  memcpy(nonceB, peer, 32); memcpy(nonceC, nonceA, 32);
  if (!deriveMaster(&masterOut, false)) return false;  ctrOut = 0;
  if (!deriveMaster(&masterIn, true)) return false;    ctrIn = 0;
  return true;
}
bool Core::onRekeyRequest2() {
  if (!keyed) return false;
  memcpy(nonceC, nonceA, 32);
  if (!deriveMaster(&masterIn, true)) return false;
  ctrIn = 0; return true;
}

}}  // namespace vr::ra4
