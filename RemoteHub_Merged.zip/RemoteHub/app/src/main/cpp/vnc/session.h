#pragma once
#include "jni_common.h"
#include <zlib.h>
#include "ra2.h"

namespace vr {

struct PixelFormat {
  u8 bpp = 32, depth = 24, bigEndian = 0, trueColour = 1;
  u16 rMax = 255, gMax = 255, bMax = 255;
  u8 rShift = 0, gShift = 8, bShift = 16;
};

struct KV { Str k, v; };

struct Session {
  u64 id = 0;
  // Java side
  jobject desktopCb = nullptr, sessionCb = nullptr, sessionObj = nullptr;
  jmethodID mConnSuccess = nullptr, mBell = nullptr, mGetClip = nullptr, mSetClip = nullptr, mSetCursor = nullptr,
            mSetDesktopSize = nullptr, mDrawRegion = nullptr, mFbUpdateEnd = nullptr, mSessionClosed = nullptr;
  // config
  Str address, uuid;
  Vec<KV> opts;
  Mutex optMutex;
  // thread / io
  pthread_t th; bool threadStarted = false;
  volatile bool closing = false, finished = false, connected = false;
  int fd = -1, wake[2] = {-1, -1};
  Mutex sendMutex;
  u8 inbuf[32768]; size_t inPos = 0, inLen = 0;
  // RA2 encrypted message layer (types 5 / 129 after the handshake)
  bool raActive = false; ra2::Cipher raTx, raRx; Bytes raPlain;
  // protocol info
  int verMajor = 0, verMinor = 0;
  int secType = 0; Str secDesc;
  Str desktopName; PixelFormat serverPF, viewerPF;
  Str lastEncoding;
  Str closeReason;
  // framebuffer
  Mutex fbMutex;
  Bytes fb; int fbW = 0, fbH = 0;
  bool pipeline = true, earlySent = false;  // next update request sent while decoding (option Pipeline)
  Bytes scrA, scrB;                       // reusable decoder scratch buffers (no per-tile allocation)
  // scale buffer
  u8* scaleBuf = nullptr; int scaleW = 0, scaleH = 0;
  Vec<void*> retired;
  // input state
  int ptrX = 0, ptrY = 0, buttons = 0;
  bool focus = true;
  Str lastClip;
  Vec<u32> pressed;
  Mutex inputMutex;
  // auth
  int authAllowed = 4, authFailures = 0;
  // zlib for ZRLE
  z_stream zs; bool zInit = false;

  Session();
  ~Session();
  bool start();
  void requestClose();
  void join();
  // options
  Str getOpt(const char* key, const char* def = nullptr);
  void setOpt(const char* key, const char* val);
  // input api
  void pointer(int x, int y, int mask);
  void wheel(int horizontal, int delta);
  void keyEvent(bool down, u32 keysym);
  void focusEvent(bool f);
  void applyOptions();
  // scaled copy
  void* resizeScaleBuf(int w, int h);
  void scaledCopy(float scale, u8* dst, int dstStridePx, int dstRows, int x, int y, int w, int h);
  // info
  Str desktopSizeStr();
  Str pixelFormatDesc(const PixelFormat& pf);

  // internals
  void run();
  bool connectTcp(Str* err);
  bool handshake(Str* err, bool* retry);
  bool serverInitAndLoop(Str* err);
  bool readn(void* dst, size_t n);
  bool skip(size_t n);
  bool sendAll(const void* d, size_t n);
  bool waitFd(short ev);
  u32 rd32(); u16 rd16(); u8 rd8();
  bool ioFail = false;
  bool sendSetup();
  bool sendUpdateRequest(bool incremental);
  bool readUpdate();
  bool decodeRect(int x, int y, int w, int h, int enc);
  bool decRaw(int x, int y, int w, int h);
  bool decRRE(int x, int y, int w, int h, bool corre);
  bool decHextile(int x, int y, int w, int h);
  bool decZrle(int x, int y, int w, int h);
  bool decCopyRect(int x, int y, int w, int h);
  bool decCursor(int x, int y, int w, int h);
  bool decExtDesktopSize(int x, int y, int w, int h);
  bool resizeFb(int w, int h);
  void fillRect(int x, int y, int w, int h, const u8* px);
  bool serverCutText();
  void sendCutText(const char* utf8);
  void showError(const char* msg);
  bool askPassword(const char* msg, Str* out);
  bool askCredentials(const char* msg, bool needUser, Str* user, Str* pass);
  bool ra2Auth(int sec, Str* err, bool* retry);
  bool rawSend(const void* d, size_t n);
  bool rawRead(void* d, size_t n);
  bool raFill();
  // java callbacks (session thread env)
  JNIEnv* env = nullptr;
  void cbDesktopSize();
  void cbDraw(int x, int y, int w, int h);
};

void sessionInitGlobals();
Session* sessionCreate(JNIEnv* env, jobject desktopCb, jobject sessionCb, const char* address, const char* uuid,
                       const Vec<KV>& opts, jobject* sessionObjOut);
void sessionDestroy(JNIEnv* env, Session* s);

// password store (in-memory)
Str storeGetPassword(const char* key);
void storeSetPassword(const char* key, const char* pw);
void storeRemovePassword(const char* key);
void storeClearPasswords();

}  // namespace vr
