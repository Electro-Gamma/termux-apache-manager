// RA4 (RFB protocol v5 cipher suites): suite registry, key exchange, key schedule, record layers.
// Everything here is derived from behaviour recovered from the original library; see docs/RA4_RECOVERY.md
// for the evidence (tags [BIN] / [BIN-inf] / [UNKNOWN]). Nothing here is a copy of proprietary code.
// This layer is sans-IO: callers feed received bytes and send whatever lands in the output buffer.
#pragma once
#include "util.h"
#include "mbedtls/gcm.h"
#include "mbedtls/rsa.h"
#include "mbedtls/ecdh.h"

namespace vr { namespace ra4 {

// ---- suites -------------------------------------------------------------------------------------
enum Cipher { C_NULL = 1, C_GCM128 = 2, C_GCM256 = 3, C_NE = 4 };           // id & 7
enum Status { ST_IMPLEMENTED, ST_UNSUPPORTED };

struct Suite {
  u16 id; const char* name; const char* desc;
  int cipher;       // id & 7
  int keyBits;      // 0 / 128 / 256
  int hashBits;     // KDF / HMAC / OAEP hash: 256 or 512
  bool psk;         // id & 0x400
  bool rsa;         // id & 0x200
  int rsaMinBits;   // 1024 (id&0x300==0x200), 2048 (0x300), 0 if no RSA
  int curve;        // -1 none, 0 = X25519, 1 = X448  (id & 0x800)
  int nonceBytes;   // per-side RSA-transported nonce size (table at 0x1bbca8: 128/256/128 bits)
  Status status; const char* statusNote;
};
size_t suiteCount();
const Suite& suiteAt(size_t i);
const Suite* suiteById(u16 id);
const Suite* suiteByName(const char* name);                       // case-insensitive exact name
// Parses "RA4_256,0x0b03,RA4-PSK_128" (names or ids, comma/space separated) into out[]. Returns the count, or -1 (err set).
// Unknown names/ids and duplicates are errors (no silent drops). Empty string -> default preference.
int parsePreference(const char* s, u16* out, int max, Str* err);
int defaultPreference(u16* out, int max, bool includeNull = false);   // strongest first, only implemented suites

// ---- primitives ---------------------------------------------------------------------------------
bool hmac(int hashBits, const u8* key, size_t kl, const u8* data, size_t dl, u8* out /* hashBits/8; 160 = SHA-1 */);
// KDF(hashBits, outLen, key, data, info): PRK = HMAC(key, data); T(i) = HMAC(PRK, T(i-1) | info | i)   [BIN 0x436a94]
bool kdf(int hashBits, const u8* key, size_t kl, const u8* data, size_t dl, const u8* info, size_t il, size_t outLen, u8* out);
bool randomBytes(void* out, size_t n);
bool ctEqual(const u8* a, const u8* b, size_t n);

// AES-GCM single-shot (exposed for known-answer tests): out = ct | 16-byte tag
bool gcmSeal(const u8* key, size_t kl, const u8 iv[12], const u8* aad, size_t al, const u8* in, size_t n, u8* out);
bool gcmOpen(const u8* key, size_t kl, const u8 iv[12], const u8* aad, size_t al, const u8* in /* ct|tag */, size_t n, u8* out);

// ---- ECDHE (X25519 / X448) ------------------------------------------------------------------------
struct Ecdh {
  mbedtls_ecdh_context ctx; int curve = -1; bool ready = false;
  Ecdh() { mbedtls_ecdh_init(&ctx); }
  ~Ecdh() { mbedtls_ecdh_free(&ctx); }
  Ecdh(const Ecdh&) = delete; Ecdh& operator=(const Ecdh&) = delete;
  bool generate(int curve);                              // curve 0 = X25519, 1 = X448
  bool generateWithPrivate(int curve, const u8* priv, size_t n);   // for tests (RFC 7748 vectors)
  void pubWire(Bytes* out) const;                        // u8 len | raw public (RFC 7748 encoding)   [BIN 0x440980]
  // Parses a peer public value at p (wire form); *used = consumed bytes. Strict: length byte must be 32 / 56.
  bool setPeer(const u8* p, size_t n, size_t* used);
  bool shared(Bytes* out) const;                         // RFC 7748 shared secret; rejects the all-zero result
  Bytes pubRaw; Bytes peerRaw;
};

// ---- RSA (OAEP transport) ---------------------------------------------------------------------------
struct RsaKey {
  mbedtls_rsa_context rsa; bool has = false; int bits = 0;
  RsaKey() { mbedtls_rsa_init(&rsa); }
  ~RsaKey() { mbedtls_rsa_free(&rsa); }
  RsaKey(const RsaKey&) = delete; RsaKey& operator=(const RsaKey&) = delete;
  bool generate(int bits);
  bool setPublic(const u8* n, size_t nl, const u8* e, size_t el);
  // wire form  BE32(bits) | N | BE16(len e) | e   [BIN 0x442168 flag 1];  empty key = 0xffffffff
  void wire(Bytes* out) const;
  // canonical form for identity hashing  BE32(bits) | N | e padded to |N|   [BIN 0x442168 flag 0]
  void canonical(Bytes* out) const;
  // Parses a wire key; *used = consumed. Accepts the empty marker (has=false). Enforces 1024..8192 bits.
  bool parse(const u8* p, size_t n, size_t* used);
  bool encrypt(int hashBits, const u8* in, size_t n, Bytes* ct) const;      // RSAES-OAEP, hash = MGF hash = SHA-256/512, empty label
  bool decrypt(int hashBits, const u8* ct, size_t cl, Bytes* out) const;
};

// ---- record layers ------------------------------------------------------------------------------------
// AES-GCM stream records [BIN 0x43c9c8/0x43c200/0x44723c]: BE16(len) | ct[len] | tag[16]; AAD = the 2 length bytes;
// IV = 12 bytes from the key schedule, incremented as a little-endian counter after every record.
struct GcmRecord {
  mbedtls_gcm_context g; u8 iv[12]; bool ready = false; u64 records = 0;
  GcmRecord() { mbedtls_gcm_init(&g); memset(iv, 0, 12); }
  ~GcmRecord() { mbedtls_gcm_free(&g); }
  GcmRecord(const GcmRecord&) = delete; GcmRecord& operator=(const GcmRecord&) = delete;
  bool init(const u8* key, size_t kl, const u8 iv12[12]);
  bool seal(const u8* in, size_t n, Bytes* out);               // appends one record (n <= 0xffff)
  bool open(const u8* hdr2, const u8* ct, size_t n, const u8* tag, u8* out);
};
// NULL-HMAC-SHA1 records (RA4ne after login) [BIN 0x4383b0/0x437de0/0x437fc4, BIN-inf for key split]:
// BE16(len) | plaintext | HMAC-SHA1(key64, counter16 | BE16(len) | plaintext); counter = 16-byte LE, incremented after each record.
struct HmacRecord {
  u8 key[64]; u8 counter[16]; bool ready = false;
  HmacRecord() { memset(key, 0, 64); memset(counter, 0, 16); }
  bool init(const u8 key64[64], const u8 counter16[16]);
  bool seal(const u8* in, size_t n, Bytes* out);
  bool open(const u8* hdr2, const u8* pt, size_t n, const u8* mac20);
};

// ---- key schedule / session core ----------------------------------------------------------------------
struct Core {
  const Suite* suite = nullptr; bool isClient = true;
  u8 nonceA[32], nonceB[32], nonceC[32];     // local (latest), peer (latest), local committed for incoming keys
  Bytes masterOut, masterIn, sessionId;      // 48 | 48 | 32 bytes
  Bytes transcript;                          // hello transcript | key-exchange transcript
  u32 ctrIn = 0, ctrOut = 0;
  int phaseOut = 1, phaseIn = 1;             // 1 = main cipher, 2 = NULL-HMAC-SHA1 (RA4ne after login)
  bool keyed = false;
  GcmRecord gOut, gIn; HmacRecord hOut, hIn;
  bool nullOut = false, nullIn = false;

  Core() { memset(nonceA, 0, 32); memset(nonceB, 0, 32); memset(nonceC, 0, 32); }
  void init(const Suite* s, bool client, const u8 local[32], const u8 peer[32], const Bytes& helloTranscript);
  // Derives MasterSecret and SessionId from the key-exchange secret [BIN 0x384b4c]; appends kexTranscript to the transcript.
  bool establish(const Bytes& secret, const Bytes& kexTranscript);
  bool digest(bool forSend, u8 out[32]) const;            // [BIN 0x384900 / 0x3843c4]
  bool verifyDigest(const u8 d[32]) const;
  bool installOut();                                       // derives keys for the outgoing direction and starts using them
  bool installIn();
  // 3-message rekey [BIN 0x3839b8]. Initiator: beginRekey -> (peer response) onResponse; responder: onRequest -> onRequest2.
  bool beginRekey(u8 nonceOut[32]);
  bool onRekeyRequest(const u8 peerNonce[32], u8 respNonce[32]);   // responder: request 1/2
  bool onRekeyResponse(const u8 peerNonce[32]);                    // initiator: response
  bool onRekeyRequest2();                                          // responder: request 2/2
  void refreshOut() { ctrOut++; }                                  // key refresh notification, outgoing [BIN 0x38508c]
  bool refreshIn() { if (ctrIn == 0xffffffffu) return false; ctrIn++; return true; }
  bool refreshOutChecked() { if (ctrOut == 0xffffffffu) return false; ctrOut++; return true; }
  bool seal(const u8* in, size_t n, Bytes* out);           // one record with the active outgoing cipher
  bool keyingMaterial(bool out, size_t len, u8* buf) const;  // [BIN 0x384f10]
 private:
  bool nonceInfo(bool outDir, u8 info[96], size_t* il, bool withSession) const;
  bool deriveMaster(Bytes* m, bool useCommittedLocal);
};

// ---- handshake (client role) ----------------------------------------------------------------------------
struct HelloParams {
  u16 offered[16]; int nOffered = 0;
  u8 flag = 0;                       // [UNKNOWN meaning, 0x38dd6c]: byte after the suite list
  Bytes authList;                    // serialised auth-method list; default BE16(0) = empty
  u32 verMajor = 5, verMinor = 0;    // conn+0x14/+0x18 in the hello transcript [BIN-inf: negotiated protocol version]
  u32 extA = 0, extB = 0;            // conn+0x1c/+0x20 [UNKNOWN meaning]
  Bytes myPsk, peerPsk, peerRsaHash; // PSK suites
  int rsaBits = 2048;                // size of the generated local RSA key
  bool allowNull = false;            // accept the Null suite (no encryption). Off unless explicitly enabled.
};

class Client {
 public:
  enum State { S_NEW, S_HELLO_SENT, S_KEX, S_AWAIT_DIGEST, S_ESTABLISHED, S_FAILED };
  Client() { memset(clientRandom, 0, 32); }
  bool start(const HelloParams& p, Bytes* out, Str* err);
  // Feed bytes from the peer. Handshake/rekey output goes to out; decrypted payload (records that do not start with a
  // 0x0016 security message) to app. Returns false on a fatal error (state S_FAILED, err set). Partial input is buffered.
  bool feed(const u8* d, size_t n, Bytes* out, Bytes* app, Str* err);
  bool send(const u8* d, size_t n, Bytes* out, Str* err);     // encrypts application bytes (only once established)
  bool rekey(Bytes* out, Str* err);                            // starts the 3-message rekey (initiator)
  bool refreshKeys(Bytes* out, Str* err);                      // key-refresh notification + digest
  bool switchToNullHmac(Bytes* out, Str* err);                 // RA4ne only: AES-GCM -> NULL-HMAC-SHA1 after login
  // For tests: use this local RSA key instead of the process-wide generated one
  void setLocalKey(const RsaKey* k) { injected = k; }
  State state() const { return st; }
  void reset();                                                // back to a fresh state (new connection)
  bool established() const { return st == S_ESTABLISHED; }
  const Suite* suite() const { return core.suite; }
  const Core& coreRef() const { return core; }
 private:
  State st = S_NEW; Core core; HelloParams hp;
  u8 clientRandom[32];
  Bytes helloTx;                      // serialised ClientHello (kept for the hello transcript)
  Ecdh ecdh; RsaKey peerKey; const RsaKey* local = nullptr; const RsaKey* injected = nullptr;
  Bytes msg1Local, ecdhPeerWire, rsaPeerWire, ecdhShared, rLocal, rPeer;
  bool gotMsg1 = false, sentMsg2 = false;
  int rekeyState = 0;                 // 0 idle, 1 initiator sent request 1/2, 2 responder sent response
  bool pendingIn = false;             // next digest verified -> switch incoming keys
  bool recvPlain = true, sendPlain = true;
  Bytes rawIn, decBuf;
  bool fail(Str* err, const char* m);
  bool pump(Bytes* out, Bytes* app, Str* err);
  bool pullRecords(Str* err);
  int onHello(const u8* p, size_t n, size_t* used, Bytes* out, Str* err);
  int onKex(const u8* p, size_t n, size_t* used, Bytes* out, Str* err);
  int onSecurity(const u8* p, size_t n, size_t* used, Bytes* out, Str* err);
  bool finishKex(Bytes* out, Str* err);
  bool emit(const Bytes& plain, Bytes* out);
  bool emitDigestMsg(Bytes* out);
};

}}  // namespace vr::ra4
