#include "ra2.h"
#include <fcntl.h>
#include <unistd.h>
#include "mbedtls/sha1.h"
#include "mbedtls/sha256.h"
#include "mbedtls/bignum.h"

namespace vr { namespace ra2 {

bool randomBytes(void* out, size_t n) {
  int f = open("/dev/urandom", O_RDONLY | O_CLOEXEC); if (f < 0) return false;
  u8* p = (u8*)out; bool ok = true;
  while (n) { ssize_t r = read(f, p, n); if (r <= 0) { ok = false; break; } p += r; n -= (size_t)r; }
  close(f); return ok;
}
int rngCallback(void*, unsigned char* out, size_t n) { return randomBytes(out, n) ? 0 : -1; }

static void dbl(const u8 in[16], u8 out[16]) {            // GF(2^128) doubling (CMAC subkey derivation)
  u8 carry = in[0] >> 7;
  for (int i = 0; i < 15; i++) out[i] = (u8)((in[i] << 1) | (in[i + 1] >> 7));
  out[15] = (u8)(in[15] << 1); if (carry) out[15] ^= 0x87;
}

bool Cipher::init(const u8* key, int keyLen) {
  clear(); mbedtls_aes_init(&aes);
  if (mbedtls_aes_setkey_enc(&aes, key, keyLen * 8) != 0) return false;
  u8 z[16] = {0}, l[16];
  if (mbedtls_aes_crypt_ecb(&aes, MBEDTLS_AES_ENCRYPT, z, l) != 0) return false;
  dbl(l, k1); dbl(k1, k2); memset(counter, 0, 16); ready = true; return true;
}
void Cipher::clear() { if (ready) mbedtls_aes_free(&aes); ready = false; memset(k1, 0, 16); memset(k2, 0, 16); }

// OMAC^t(X) = CMAC_K( [t]_16 || X )
bool Cipher::omac(int t, const u8* data, size_t n, u8 out[16]) {
  size_t total = 16 + n; size_t blocks = (total + 15) / 16; if (!blocks) blocks = 1;
  bool full = (total % 16 == 0);
  u8 x[16] = {0}, blk[16];
  for (size_t b = 0; b < blocks; b++) {
    for (int i = 0; i < 16; i++) {
      size_t pos = b * 16 + i; u8 v;
      if (pos < 16) v = (pos == 15) ? (u8)t : 0; else if (pos - 16 < n) v = data[pos - 16]; else v = (pos == total) ? 0x80 : 0;
      blk[i] = v;
    }
    if (b == blocks - 1) { const u8* k = full ? k1 : k2; for (int i = 0; i < 16; i++) blk[i] ^= k[i]; }
    for (int i = 0; i < 16; i++) x[i] ^= blk[i];
    if (mbedtls_aes_crypt_ecb(&aes, MBEDTLS_AES_ENCRYPT, x, x) != 0) return false;
  }
  memcpy(out, x, 16); return true;
}

void Cipher::ctr(const u8 start[16], const u8* in, size_t n, u8* out) {
  u8 c[16], ks[16]; memcpy(c, start, 16);
  for (size_t off = 0; off < n; off += 16) {
    mbedtls_aes_crypt_ecb(&aes, MBEDTLS_AES_ENCRYPT, c, ks);
    size_t k = n - off < 16 ? n - off : 16;
    for (size_t i = 0; i < k; i++) out[off + i] = in[off + i] ^ ks[i];
    for (int i = 15; i >= 0; i--) if (++c[i]) break;        // big-endian increment
  }
}

bool Cipher::eaxSeal(const u8 nonce[16], const u8* ad, size_t adl, const u8* in, size_t n, u8* out) {
  u8 N[16], H[16], C[16];
  if (!omac(0, nonce, 16, N) || !omac(1, ad, adl, H)) return false;
  ctr(N, in, n, out);
  if (!omac(2, out, n, C)) return false;
  for (int i = 0; i < 16; i++) out[n + i] = N[i] ^ H[i] ^ C[i];
  return true;
}
bool Cipher::eaxOpen(const u8 nonce[16], const u8* ad, size_t adl, const u8* in, size_t n, u8* out) {
  u8 N[16], H[16], C[16];
  if (!omac(0, nonce, 16, N) || !omac(1, ad, adl, H) || !omac(2, in, n, C)) return false;
  u8 diff = 0; for (int i = 0; i < 16; i++) diff |= (u8)((N[i] ^ H[i] ^ C[i]) ^ in[n + i]);
  if (diff) return false;
  ctr(N, in, n, out); return true;
}

static void bump(u8 c[16]) { for (int i = 0; i < 16; i++) if (++c[i]) break; }   // 128-bit little-endian counter

bool Cipher::seal(const u8* msg, size_t n, u8* out) {
  if (!ready || n > 65535) return false;
  u8 ad[2] = {(u8)(n >> 8), (u8)n}; out[0] = ad[0]; out[1] = ad[1];
  bool ok = eaxSeal(counter, ad, 2, msg, n, out + 2); bump(counter); return ok;
}
bool Cipher::open(size_t n, const u8* enc, u8* out) {
  if (!ready) return false;
  u8 ad[2] = {(u8)(n >> 8), (u8)n};
  bool ok = eaxOpen(counter, ad, 2, enc, n, out); bump(counter); return ok;
}

void hash(bool sha256, const u8* a, size_t an, const u8* b, size_t bn, u8* out) {
  if (sha256) { mbedtls_sha256_context c; mbedtls_sha256_init(&c); mbedtls_sha256_starts(&c, 0); mbedtls_sha256_update(&c, a, an); mbedtls_sha256_update(&c, b, bn); mbedtls_sha256_finish(&c, out); mbedtls_sha256_free(&c); }
  else { mbedtls_sha1_context c; mbedtls_sha1_init(&c); mbedtls_sha1_starts(&c); mbedtls_sha1_update(&c, a, an); mbedtls_sha1_update(&c, b, bn); mbedtls_sha1_finish(&c, out); mbedtls_sha1_free(&c); }
}

namespace {
Mutex gKeyMutex; bool gKeyReady = false; mbedtls_rsa_context gRsa; Bytes gPub; int gBits = 0;
}
bool clientKey(mbedtls_rsa_context** rsa, Bytes* publicWire, int bits) {
  Lock l(gKeyMutex);
  if (!gKeyReady || gBits != bits) {
    if (gKeyReady) mbedtls_rsa_free(&gRsa);
    mbedtls_rsa_init(&gRsa);
    if (mbedtls_rsa_set_padding(&gRsa, MBEDTLS_RSA_PKCS_V15, MBEDTLS_MD_NONE) != 0) return false;
    if (mbedtls_rsa_gen_key(&gRsa, rngCallback, nullptr, (unsigned)bits, 65537) != 0) { mbedtls_rsa_free(&gRsa); return false; }
    size_t nb = (size_t)(bits + 7) / 8; gPub.clear(); if (!gPub.resize(4 + 2 * nb)) return false;
    gPub.p[0] = (u8)(bits >> 24); gPub.p[1] = (u8)(bits >> 16); gPub.p[2] = (u8)(bits >> 8); gPub.p[3] = (u8)bits;
    mbedtls_mpi N, E; mbedtls_mpi_init(&N); mbedtls_mpi_init(&E);
    bool ok = mbedtls_rsa_export(&gRsa, &N, nullptr, nullptr, nullptr, &E) == 0 &&
              mbedtls_mpi_write_binary(&N, gPub.p + 4, nb) == 0 && mbedtls_mpi_write_binary(&E, gPub.p + 4 + nb, nb) == 0;
    mbedtls_mpi_free(&N); mbedtls_mpi_free(&E);
    if (!ok) { mbedtls_rsa_free(&gRsa); return false; }
    gKeyReady = true; gBits = bits;
  }
  *rsa = &gRsa; *publicWire = gPub; return true;
}

bool rsaEncrypt(const u8* n, size_t nl, const u8* e, size_t el, const u8* in, size_t inl, u8* out) {
  mbedtls_rsa_context r; mbedtls_rsa_init(&r);
  bool ok = mbedtls_rsa_set_padding(&r, MBEDTLS_RSA_PKCS_V15, MBEDTLS_MD_NONE) == 0 &&
            mbedtls_rsa_import_raw(&r, n, nl, nullptr, 0, nullptr, 0, nullptr, 0, e, el) == 0 &&
            mbedtls_rsa_complete(&r) == 0 && mbedtls_rsa_get_len(&r) == nl &&
            mbedtls_rsa_pkcs1_encrypt(&r, rngCallback, nullptr, inl, in, out) == 0;
  mbedtls_rsa_free(&r); return ok;
}
bool clientDecrypt(const u8* in, size_t inl, u8* out, size_t* outl, size_t outMax) {
  Lock l(gKeyMutex);
  if (!gKeyReady || inl != mbedtls_rsa_get_len(&gRsa)) return false;
  return mbedtls_rsa_pkcs1_decrypt(&gRsa, rngCallback, nullptr, outl, in, out, outMax) == 0;
}

}}  // namespace vr::ra2
