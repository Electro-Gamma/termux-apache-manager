#include "ra2.h"
#include <fcntl.h>
#include <unistd.h>
#include "mbedtls/sha1.h"
#include "mbedtls/sha256.h"
#include "mbedtls/bignum.h"

namespace vr { namespace ra2 {

bool randomBytes(void* out, size_t n) {
  int f = open("/dev/urandom", O_RDONLY | O_CLOEXEC); if (f < 0) return false;
  u8* p = (u8*)out; bool ok = true;
  while (n) { ssize_t r = read(f, p, n); if (r <= 0) { ok = false; break; } p += r; n -= (size_t)r; }
  close(f); return ok;
}
int rngCallback(void*, unsigned char* out, size_t n) { return randomBytes(out, n) ? 0 : -1; }

static void dbl(const u8 in[16], u8 out[16]) {            // GF(2^128) doubling (CMAC subkey derivation)
  u8 carry = in[0] >> 7;
  for (int i = 0; i < 15; i++) out[i] = (u8)((in[i] << 1) | (in[i + 1] >> 7));
  out[15] = (u8)(in[15] << 1); if (carry) out[15] ^= 0x87;
}

bool Cipher::init(const u8* key, int keyLen) {
  clear(); mbedtls_aes_init(&aes);
  if (mbedtls_aes_setkey_enc(&aes, key, keyLen * 8) != 0) return false;
  u8 z[16] = {0}, l[16];
  if (mbedtls_aes_crypt_ecb(&aes, MBEDTLS_AES_ENCRYPT, z, l) != 0) return false;
  dbl(l, k1); dbl(k1, k2); memset(counter, 0, 16); ready = true; return true;
}
void Cipher::clear() { if (ready) mbedtls_aes_free(&aes); ready = false; memset(k1, 0, 16); memset(k2, 0, 16); }

// OMAC^t(X) = CMAC_K( [t]_16 || X )
bool Cipher::omac(int t, const u8* data, size_t n, u8 out[16]) {
  size_t total = 16 + n; size_t blocks = (total + 15) / 16; if (!blocks) blocks = 1;
  bool full = (total % 16 == 0);
  u8 x[16] = {0}, blk[16];
  for (size_t b = 0; b < blocks; b++) {
    for (int i = 0; i < 16; i++) {
      size_t pos = b * 16 + i; u8 v;
      if (pos < 16) v = (pos == 15) ? (u8)t : 0; else if (pos - 16 < n) v = data[pos - 16]; else v = (pos == total) ? 0x80 : 0;
      blk[i] = v;
    }
    if (b == blocks - 1) { const u8* k = full ? k1 : k2; for (int i = 0; i < 16; i++) blk[i] ^= k[i]; }
    for (int i = 0; i < 16; i++) x[i] ^= blk[i];
    if (mbedtls_aes_crypt_ecb(&aes, MBEDTLS_AES_ENCRYPT, x, x) != 0) return false;
  }
  memcpy(out, x, 16); return true;
}

void Cipher::ctr(const u8 start[16], const u8* in, size_t n, u8* out) {
  u8 c[16], ks[16]; memcpy(c, start, 16);
  for (size_t off = 0; off < n; off += 16) {
    mbedtls_aes_crypt_ecb(&aes, MBEDTLS_AES_ENCRYPT, c, ks);
    size_t k = n - off < 16 ? n - off : 16;
    for (size_t i = 0; i < k; i++) out[off + i] = in[off + i] ^ ks[i];
    for (int i = 15; i >= 0; i--) if (++c[i]) break;        // big-endian increment
  }
}

bool Cipher::eaxSeal(const u8 nonce[16], const u8* ad, size_t adl, const u8* in, size_t n, u8* out) {
  u8 N[16], H[16], C[16];
  if (!omac(0, nonce, 16, N) || !omac(1, ad, adl, H)) return false;
  ctr(N, in, n, out);
  if (!omac(2, out, n, C)) return false;
  for (int i = 0; i < 16; i++) out[n + i] = N[i] ^ H[i] ^ C[i];
  return true;
}
bool Cipher::eaxOpen(const u8 nonce[16], const u8* ad, size_t adl, const u8* in, size_t n, u8* out) {
  u8 N[16], H[16], C[16];
  if (!omac(0, nonce, 16, N) || !omac(1, ad, adl, H) || !omac(2, in, n, C)) return false;
  u8 diff = 0; for (int i = 0; i < 16; i++) diff |= (u8)((N[i] ^ H[i] ^ C[i]) ^ in[n + i]);
  if (diff) return false;
  ctr(N, in, n, out); return true;
}

static void bump(u8 c[16]) { for (int i = 0; i < 16; i++) if (++c[i]) break; }   // 128-bit little-endian counter

bool Cipher::seal(const u8* msg, size_t n, u8* out) {
  if (!ready || n > 65535) return false;
  u8 ad[2] = {(u8)(n >> 8), (u8)n}; out[0] = ad[0]; out[1] = ad[1];
  bool ok = eaxSeal(counter, ad, 2, msg, n, out + 2); bump(counter); return ok;
}
bool Cipher::open(size_t n, const u8* enc, u8* out) {
  if (!ready) return false;
  u8 ad[2] = {(u8)(n >> 8), (u8)n};
  bool ok = eaxOpen(counter, ad, 2, enc, n, out); bump(counter); return ok;
}

void hash(bool sha256, const u8* a, size_t an, const u8* b, size_t bn, u8* out) {
  if (sha256) { mbedtls_sha256_context c; mbedtls_sha256_init(&c); mbedtls_sha256_starts(&c, 0); mbedtls_sha256_update(&c, a, an); mbedtls_sha256_update(&c, b, bn); mbedtls_sha256_finish(&c, out); mbedtls_sha256_free(&c); }
  else { mbedtls_sha1_context c; mbedtls_sha1_init(&c); mbedtls_sha1_starts(&c); mbedtls_sha1_update(&c, a, an); mbedtls_sha1_update(&c, b, bn); mbedtls_sha1_finish(&c, out); mbedtls_sha1_free(&c); }
}

void deriveKeys(bool sha256, int keyLen, const u8* cr, const u8* sr, u8* c2s, u8* s2c) {
  u8 d[32]; const size_t kl = (size_t)keyLen;
  hash(sha256, sr, kl, cr, kl, d); memcpy(c2s, d, kl);
  hash(sha256, cr, kl, sr, kl, d); memcpy(s2c, d, kl);
}

namespace {
Mutex gKeyMutex; bool gKeyReady = false; mbedtls_rsa_context gRsa; Bytes gPub; int gBits = 0;
}
bool clientKey(mbedtls_rsa_context** rsa, Bytes* publicWire, int bits) {
  Lock l(gKeyMutex);
  if (!gKeyReady || gBits != bits) {
    if (gKeyReady) mbedtls_rsa_free(&gRsa);
    mbedtls_rsa_init(&gRsa);
    if (mbedtls_rsa_set_padding(&gRsa, MBEDTLS_RSA_PKCS_V15, MBEDTLS_MD_NONE) != 0) return false;
    if (mbedtls_rsa_gen_key(&gRsa, rngCallback, nullptr, (unsigned)bits, 65537) != 0) { mbedtls_rsa_free(&gRsa); return false; }
    size_t nb = (size_t)(bits + 7) / 8; gPub.clear(); if (!gPub.resize(4 + 2 * nb)) return false;
    gPub.p[0] = (u8)(bits >> 24); gPub.p[1] = (u8)(bits >> 16); gPub.p[2] = (u8)(bits >> 8); gPub.p[3] = (u8)bits;
    mbedtls_mpi N, E; mbedtls_mpi_init(&N); mbedtls_mpi_init(&E);
    bool ok = mbedtls_rsa_export(&gRsa, &N, nullptr, nullptr, nullptr, &E) == 0 &&
              mbedtls_mpi_write_binary(&N, gPub.p + 4, nb) == 0 && mbedtls_mpi_write_binary(&E, gPub.p + 4 + nb, nb) == 0;
    mbedtls_mpi_free(&N); mbedtls_mpi_free(&E);
    if (!ok) { mbedtls_rsa_free(&gRsa); return false; }
    gKeyReady = true; gBits = bits;
  }
  *rsa = &gRsa; *publicWire = gPub; return true;
}

bool rsaEncrypt(const u8* n, size_t nl, const u8* e, size_t el, const u8* in, size_t inl, u8* out) {
  mbedtls_rsa_context r; mbedtls_rsa_init(&r);
  bool ok = mbedtls_rsa_set_padding(&r, MBEDTLS_RSA_PKCS_V15, MBEDTLS_MD_NONE) == 0 &&
            mbedtls_rsa_import_raw(&r, n, nl, nullptr, 0, nullptr, 0, nullptr, 0, e, el) == 0 &&
            mbedtls_rsa_complete(&r) == 0 && mbedtls_rsa_get_len(&r) == nl &&
            mbedtls_rsa_pkcs1_encrypt(&r, rngCallback, nullptr, inl, in, out) == 0;
  mbedtls_rsa_free(&r); return ok;
}
bool clientDecrypt(const u8* in, size_t inl, u8* out, size_t* outl, size_t outMax) {
  Lock l(gKeyMutex);
  if (!gKeyReady || inl != mbedtls_rsa_get_len(&gRsa)) return false;
  return mbedtls_rsa_pkcs1_decrypt(&gRsa, rngCallback, nullptr, outl, in, out, outMax) == 0;
}

}}  // namespace vr::ra2

// ---------------------------------------------------------------- ARD
namespace vr { namespace ard {

static inline u32 rol(u32 x, int c) { return (x << c) | (x >> (32 - c)); }
void md5(const u8* in, size_t n, u8 out[16]) {
  static const u32 K[64] = {
    0xd76aa478,0xe8c7b756,0x242070db,0xc1bdceee,0xf57c0faf,0x4787c62a,0xa8304613,0xfd469501,0x698098d8,0x8b44f7af,0xffff5bb1,0x895cd7be,0x6b901122,0xfd987193,0xa679438e,0x49b40821,
    0xf61e2562,0xc040b340,0x265e5a51,0xe9b6c7aa,0xd62f105d,0x02441453,0xd8a1e681,0xe7d3fbc8,0x21e1cde6,0xc33707d6,0xf4d50d87,0x455a14ed,0xa9e3e905,0xfcefa3f8,0x676f02d9,0x8d2a4c8a,
    0xfffa3942,0x8771f681,0x6d9d6122,0xfde5380c,0xa4beea44,0x4bdecfa9,0xf6bb4b60,0xbebfbc70,0x289b7ec6,0xeaa127fa,0xd4ef3085,0x04881d05,0xd9d4d039,0xe6db99e5,0x1fa27cf8,0xc4ac5665,
    0xf4292244,0x432aff97,0xab9423a7,0xfc93a039,0x655b59c3,0x8f0ccc92,0xffeff47d,0x85845dd1,0x6fa87e4f,0xfe2ce6e0,0xa3014314,0x4e0811a1,0xf7537e82,0xbd3af235,0x2ad7d2bb,0xeb86d391};
  static const int S[64] = {7,12,17,22,7,12,17,22,7,12,17,22,7,12,17,22,5,9,14,20,5,9,14,20,5,9,14,20,5,9,14,20,
                            4,11,16,23,4,11,16,23,4,11,16,23,4,11,16,23,6,10,15,21,6,10,15,21,6,10,15,21,6,10,15,21};
  u32 a0 = 0x67452301, b0 = 0xefcdab89, c0 = 0x98badcfe, d0 = 0x10325476;
  size_t total = ((n + 8) / 64 + 1) * 64; Bytes m; m.resize(total); memset(m.p, 0, total); if (n) memcpy(m.p, in, n); m.p[n] = 0x80;
  u64 bits = (u64)n * 8; for (int i = 0; i < 8; i++) m.p[total - 8 + i] = (u8)(bits >> (8 * i));
  for (size_t off = 0; off < total; off += 64) {
    u32 M[16]; for (int i = 0; i < 16; i++) M[i] = (u32)m.p[off + 4*i] | (u32)m.p[off + 4*i + 1] << 8 | (u32)m.p[off + 4*i + 2] << 16 | (u32)m.p[off + 4*i + 3] << 24;
    u32 A = a0, B = b0, C = c0, D = d0;
    for (int i = 0; i < 64; i++) {
      u32 F; int g;
      if (i < 16) { F = (B & C) | (~B & D); g = i; } else if (i < 32) { F = (D & B) | (~D & C); g = (5 * i + 1) % 16; }
      else if (i < 48) { F = B ^ C ^ D; g = (3 * i + 5) % 16; } else { F = C ^ (B | ~D); g = (7 * i) % 16; }
      F = F + A + K[i] + M[g]; A = D; D = C; C = B; B = B + rol(F, S[i]);
    }
    a0 += A; b0 += B; c0 += C; d0 += D;
  }
  u32 r[4] = {a0, b0, c0, d0}; for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) out[4*i + j] = (u8)(r[i] >> (8 * j));
}

bool dhAgreeWithPriv(unsigned gen, const u8* prime, const u8* peerPub, size_t kl, const u8* priv, u8* outPub, u8 key[16]) {
  mbedtls_mpi G, P, X, Y, R; mbedtls_mpi_init(&G); mbedtls_mpi_init(&P); mbedtls_mpi_init(&X); mbedtls_mpi_init(&Y); mbedtls_mpi_init(&R);
  bool ok = mbedtls_mpi_lset(&G, gen) == 0 && mbedtls_mpi_read_binary(&P, prime, kl) == 0 && mbedtls_mpi_read_binary(&X, priv, kl) == 0 &&
            mbedtls_mpi_read_binary(&Y, peerPub, kl) == 0 && mbedtls_mpi_cmp_int(&P, 2) > 0 && mbedtls_mpi_cmp_mpi(&Y, &P) < 0 &&
            mbedtls_mpi_cmp_int(&Y, 1) > 0 &&                                  // reject degenerate peer values 0 and 1
            mbedtls_mpi_exp_mod(&R, &G, &X, &P, nullptr) == 0 && mbedtls_mpi_write_binary(&R, outPub, kl) == 0;
  if (ok) {
    Bytes sh; ok = sh.resize(kl) && mbedtls_mpi_exp_mod(&R, &Y, &X, &P, nullptr) == 0 && mbedtls_mpi_write_binary(&R, sh.p, kl) == 0;
    if (ok) md5(sh.p, kl, key);
    if (sh.p) memset(sh.p, 0, sh.n);
  }
  mbedtls_mpi_free(&G); mbedtls_mpi_free(&P); mbedtls_mpi_free(&X); mbedtls_mpi_free(&Y); mbedtls_mpi_free(&R); return ok;
}
bool dhAgree(unsigned gen, const u8* prime, const u8* peerPub, size_t kl, u8* outPub, u8 key[16]) {
  Bytes priv; if (!priv.resize(kl) || !ra2::randomBytes(priv.p, kl)) return false;
  priv.p[0] &= 0x7f;                                                     // keep below the (>= 2^(8kl-1)) prime
  bool ok = dhAgreeWithPriv(gen, prime, peerPub, kl, priv.p, outPub, key); memset(priv.p, 0, kl); return ok;
}
bool sealCredentials(const u8 key[16], const char* user, const char* pass, u8 out[128]) {
  u8 pt[128]; memset(pt, 0, sizeof pt);
  size_t ul = strlen(user), pl = strlen(pass); if (ul > 63) ul = 63; if (pl > 63) pl = 63;    // keep a terminating NUL
  memcpy(pt, user, ul); memcpy(pt + 64, pass, pl);
  mbedtls_aes_context a; mbedtls_aes_init(&a); bool ok = mbedtls_aes_setkey_enc(&a, key, 128) == 0;
  for (int i = 0; ok && i < 8; i++) ok = mbedtls_aes_crypt_ecb(&a, MBEDTLS_AES_ENCRYPT, pt + 16 * i, out + 16 * i) == 0;
  mbedtls_aes_free(&a); memset(pt, 0, sizeof pt); return ok;
}
}}  // namespace vr::ard
