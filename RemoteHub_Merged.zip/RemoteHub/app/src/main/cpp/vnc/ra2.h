// RFB "RSA-AES" (RA2) support: AES-EAX message cipher, RSA key handling, hashing, randomness.
// Spec: https://github.com/rfbproto/rfbproto (RSA-AES Security Type). Crypto primitives come from Mbed TLS (third_party/mbedtls).
#pragma once
#include "util.h"
#include "mbedtls/aes.h"
#include "mbedtls/rsa.h"

namespace vr { namespace ra2 {

bool randomBytes(void* out, size_t n);                                  // /dev/urandom
int rngCallback(void* ctx, unsigned char* out, size_t n);                // mbedtls f_rng

struct Cipher {                                                          // one direction of the RA2 message layer
  mbedtls_aes_context aes; u8 k1[16], k2[16]; u8 counter[16]; bool ready = false;
  Cipher() { memset(&aes, 0, sizeof aes); memset(k1, 0, 16); memset(k2, 0, 16); memset(counter, 0, 16); }
  ~Cipher() { clear(); }
  bool init(const u8* key, int keyLen);                                  // keyLen 16 or 32; resets the 128-bit LE message counter
  void clear();
  // out must hold 2 + n + 16 bytes: U16 length | ciphertext | 16-byte MAC. n <= 65535
  bool seal(const u8* msg, size_t n, u8* out);
  // enc holds n ciphertext bytes followed by the 16-byte MAC; out receives n plaintext bytes
  bool open(size_t n, const u8* enc, u8* out);
  // raw EAX (exposed for known-answer tests)
  bool eaxSeal(const u8 nonce[16], const u8* ad, size_t adl, const u8* in, size_t n, u8* out /* n + 16 */);
  bool eaxOpen(const u8 nonce[16], const u8* ad, size_t adl, const u8* in /* n + 16 */, size_t n, u8* out);
 private:
  bool omac(int t, const u8* data, size_t n, u8 out[16]);
  void ctr(const u8 start[16], const u8* in, size_t n, u8* out);
};

// Session keys for one key-exchange round (both RA2 round 1 and the RA2r second round).
// clientRand/serverRand are keyLen bytes (16 or 32). Outputs keyLen bytes each:
//   clientToServer = H(serverRand || clientRand)[:keyLen], serverToClient = H(clientRand || serverRand)[:keyLen]
void deriveKeys(bool sha256, int keyLen, const u8* clientRand, const u8* serverRand, u8* clientToServer, u8* serverToClient);

void hash(bool sha256, const u8* a, size_t an, const u8* b, size_t bn, u8* out /* 20 or 32 */);

// Process-wide cached client RSA key (generated on first use; thread-safe). Returns false on failure.
// Writes the public key in RFB wire form: U32 bits | N (ceil(bits/8)) | E (ceil(bits/8)).
bool clientKey(mbedtls_rsa_context** rsa, Bytes* publicWire, int bits = 2048);

// RSA helpers (PKCS#1 v1.5). Encrypt with the server's public key / decrypt with the cached client key.
bool rsaEncrypt(const u8* n, size_t nl, const u8* e, size_t el, const u8* in, size_t inl, u8* out /* nl bytes */);
bool clientDecrypt(const u8* in, size_t inl, u8* out, size_t* outl, size_t outMax);

}}  // namespace vr::ra2

// Apple Remote Desktop (security type 30) primitives.
namespace vr { namespace ard {
void md5(const u8* in, size_t n, u8 out[16]);                            // RFC 1321
// DH with explicit private value (big-endian, kl bytes): outPub = g^priv mod p, key = MD5(peerPub^priv mod p, padded to kl bytes)
bool dhAgreeWithPriv(unsigned gen, const u8* prime, const u8* peerPub, size_t kl, const u8* priv, u8* outPub, u8 key[16]);
bool dhAgree(unsigned gen, const u8* prime, const u8* peerPub, size_t kl, u8* outPub, u8 key[16]);   // random private value
// 128 bytes: username[64] | password[64], zero padded, AES-128-ECB (confirmed: binary zero-pads; libvncclient pads randomly)
bool sealCredentials(const u8 key[16], const char* user, const char* pass, u8 out[128]);
}}
