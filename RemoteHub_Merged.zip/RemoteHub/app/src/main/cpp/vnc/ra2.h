// RFB "RSA-AES" (RA2) support: AES-EAX message cipher, RSA key handling, hashing, randomness.
// Spec: https://github.com/rfbproto/rfbproto (RSA-AES Security Type). Crypto primitives come from Mbed TLS (third_party/mbedtls).
#pragma once
#include "util.h"
#include "mbedtls/aes.h"
#include "mbedtls/rsa.h"

namespace vr { namespace ra2 {

bool randomBytes(void* out, size_t n);                                  // /dev/urandom
int rngCallback(void* ctx, unsigned char* out, size_t n);                // mbedtls f_rng

struct Cipher {                                                          // one direction of the RA2 message layer
  mbedtls_aes_context aes; u8 k1[16], k2[16]; u8 counter[16]; bool ready = false;
  Cipher() { memset(&aes, 0, sizeof aes); memset(k1, 0, 16); memset(k2, 0, 16); memset(counter, 0, 16); }
  ~Cipher() { clear(); }
  bool init(const u8* key, int keyLen);                                  // keyLen 16 or 32; resets the 128-bit LE message counter
  void clear();
  // out must hold 2 + n + 16 bytes: U16 length | ciphertext | 16-byte MAC. n <= 65535
  bool seal(const u8* msg, size_t n, u8* out);
  // enc holds n ciphertext bytes followed by the 16-byte MAC; out receives n plaintext bytes
  bool open(size_t n, const u8* enc, u8* out);
  // raw EAX (exposed for known-answer tests)
  bool eaxSeal(const u8 nonce[16], const u8* ad, size_t adl, const u8* in, size_t n, u8* out /* n + 16 */);
  bool eaxOpen(const u8 nonce[16], const u8* ad, size_t adl, const u8* in /* n + 16 */, size_t n, u8* out);
 private:
  bool omac(int t, const u8* data, size_t n, u8 out[16]);
  void ctr(const u8 start[16], const u8* in, size_t n, u8* out);
};

void hash(bool sha256, const u8* a, size_t an, const u8* b, size_t bn, u8* out /* 20 or 32 */);

// Process-wide cached client RSA key (generated on first use; thread-safe). Returns false on failure.
// Writes the public key in RFB wire form: U32 bits | N (ceil(bits/8)) | E (ceil(bits/8)).
bool clientKey(mbedtls_rsa_context** rsa, Bytes* publicWire, int bits = 2048);

// RSA helpers (PKCS#1 v1.5). Encrypt with the server's public key / decrypt with the cached client key.
bool rsaEncrypt(const u8* n, size_t nl, const u8* e, size_t el, const u8* in, size_t inl, u8* out /* nl bytes */);
bool clientDecrypt(const u8* in, size_t inl, u8* out, size_t* outl, size_t outMax);

}}  // namespace vr::ra2
