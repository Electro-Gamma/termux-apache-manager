// RFB client session: connection thread, protocol, decoders, input, scaled framebuffer copies.
#include "session.h"
#include "des.h"
#include <errno.h>
#include <fcntl.h>
#include <netdb.h>
#include <poll.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <unistd.h>
#ifdef __ANDROID__
#include <android/bitmap.h>
#else
extern "C" {  // provided by the host test shim
int AndroidBitmap_getInfo(JNIEnv*, jobject, void*);
int AndroidBitmap_lockPixels(JNIEnv*, jobject, void**);
int AndroidBitmap_unlockPixels(JNIEnv*, jobject);
}
struct AndroidBitmapInfo { uint32_t width, height, stride; int32_t format; uint32_t flags; };
#endif

namespace vr {

static const int kMaxDim = 16384;
static const size_t kMaxFbPixels = 64u * 1024 * 1024;

// ---------------------------------------------------------------- registries
struct Registry { Mutex m; Vec<Session*> sessions; u64 next = 1; Vec<Prompt*> prompts; Cond cv; u64 nextPrompt = 1;
                  Vec<KV> passwords; };
static Registry& reg() { static Registry* r = new Registry; return *r; }

void sessionInitGlobals() { (void)reg(); }

Session* sessionFind(u64 id) {
  Lock l(reg().m);
  for (size_t i = 0; i < reg().sessions.n; i++) if (reg().sessions[i]->id == id) return reg().sessions[i];
  return nullptr;
}
Session* sessionFromObject(JNIEnv* env, jobject obj) {
  if (!obj || !G.sessionGetToken) return nullptr;
  jlong t = env->CallLongMethod(obj, G.sessionGetToken);
  if (env->ExceptionCheck()) { env->ExceptionClear(); return nullptr; }
  return sessionFind((u64)t);
}

u64 promptCreate(Session* s) {
  Lock l(reg().m);
  Prompt* p = new Prompt; p->handle = reg().nextPrompt++; p->session = s;
  reg().prompts.push(p); return p->handle;
}
Prompt* promptWait(u64 handle, Session* s) {
  Lock l(reg().m);
  for (;;) {
    Prompt* f = nullptr;
    for (size_t i = 0; i < reg().prompts.n; i++) if (reg().prompts[i]->handle == handle) f = reg().prompts[i];
    if (!f) return nullptr;
    if (f->done) return f;
    if (s->closing) return nullptr;
    reg().cv.wait(reg().m);
  }
}
void promptRelease(u64 handle) {
  Lock l(reg().m);
  for (size_t i = 0; i < reg().prompts.n; i++) if (reg().prompts[i]->handle == handle) { delete reg().prompts[i]; reg().prompts.erase(i); return; }
}
void promptAnswer(u64 handle, bool ok, const char* user, const char* pass, bool f2, bool f3) {
  Lock l(reg().m);
  for (size_t i = 0; i < reg().prompts.n; i++) {
    Prompt* p = reg().prompts[i];
    if (p->handle == handle) { p->ok = ok; p->user = user; p->pass = pass; p->flag2 = f2; p->flag3 = f3; p->done = true; }
  }
  reg().cv.signal();
}
void promptAbortSession(Session*) { Lock l(reg().m); reg().cv.signal(); }

Str storeGetPassword(const char* key) {
  Lock l(reg().m);
  for (size_t i = 0; i < reg().passwords.n; i++) if (reg().passwords[i].k.eq(key)) return reg().passwords[i].v;
  return Str();
}
void storeSetPassword(const char* key, const char* pw) {
  Lock l(reg().m);
  for (size_t i = 0; i < reg().passwords.n; i++) if (reg().passwords[i].k.eq(key)) { reg().passwords[i].v = pw; return; }
  KV kv; kv.k = key; kv.v = pw; reg().passwords.push(kv);
}
void storeRemovePassword(const char* key) {
  Lock l(reg().m);
  for (size_t i = 0; i < reg().passwords.n; i++) if (reg().passwords[i].k.eq(key)) { reg().passwords.erase(i); return; }
}
void storeClearPasswords() { Lock l(reg().m); reg().passwords.clear(); }

// ---------------------------------------------------------------- Session basics
Session::Session() { memset(&zs, 0, sizeof zs); }
Session::~Session() {
  if (zInit) inflateEnd(&zs);
  free(scaleBuf);
  for (size_t i = 0; i < retired.n; i++) free(retired[i]);
  if (fd >= 0) close(fd);
  if (wake[0] >= 0) close(wake[0]);
  if (wake[1] >= 0) close(wake[1]);
}

Str Session::getOpt(const char* key, const char* def) {
  Lock l(optMutex);
  for (size_t i = 0; i < opts.n; i++) if (opts[i].k.eqi(key)) return opts[i].v;
  return Str(def);
}
void Session::setOpt(const char* key, const char* val) {
  Lock l(optMutex);
  for (size_t i = 0; i < opts.n; i++) if (opts[i].k.eqi(key)) { opts[i].v = val; return; }
  KV kv; kv.k = key; kv.v = val; opts.push(kv);
}

// ---------------------------------------------------------------- I/O
bool Session::waitFd(short ev) {
  for (;;) {
    struct pollfd p[2] = {{fd, ev, 0}, {wake[0], POLLIN, 0}};
    int r = poll(p, 2, -1);
    if (r < 0) { if (errno == EINTR) continue; return false; }
    if (p[1].revents) return false;                 // close requested
    if (p[0].revents & (ev | POLLERR | POLLHUP)) return true;
  }
}
bool Session::rawRead(void* dst, size_t n) {
  u8* d = (u8*)dst;
  while (n) {
    if (closing) { ioFail = true; return false; }
    ssize_t r = recv(fd, d, n, 0);
    if (r > 0) { d += r; n -= (size_t)r; continue; }
    if (r == 0) { ioFail = true; if (closeReason.empty()) closeReason = "The connection was closed by the remote computer."; return false; }
    if (errno == EINTR) continue;
    if (errno == EAGAIN || errno == EWOULDBLOCK) { if (!waitFd(POLLIN)) { ioFail = true; return false; } continue; }
    ioFail = true; if (closeReason.empty()) closeReason = strf("Network error: %s", strerror(errno)); return false;
  }
  return true;
}
// Read and decrypt one RA2 message into raPlain.
bool Session::raFill() {
  u8 h[2]; if (!rawRead(h, 2)) return false;
  size_t len = ((size_t)h[0] << 8) | h[1];
  Bytes enc; if (!enc.resize(len + 16) || !raPlain.resize(len ? len : 1)) { ioFail = true; closeReason = "Out of memory"; return false; }
  if (!rawRead(enc.p, len + 16)) return false;
  if (!raRx.open(len, enc.p, raPlain.p)) { ioFail = true; closeReason = "Encrypted message failed authentication"; return false; }
  inPos = 0; inLen = len; return true;
}
bool Session::readn(void* dst, size_t n) {
  u8* d = (u8*)dst;
  while (n) {
    if (inPos < inLen) {
      size_t k = inLen - inPos; if (k > n) k = n;
      memcpy(d, (raActive ? raPlain.p : inbuf) + inPos, k); inPos += k; d += k; n -= k; continue;
    }
    if (closing) { ioFail = true; return false; }
    if (raActive) { if (!raFill()) return false; continue; }
    // A read at least as big as the buffer goes straight to its destination (no second copy).
    bool direct = n >= sizeof inbuf;
    ssize_t r = direct ? recv(fd, d, n, 0) : recv(fd, inbuf, sizeof inbuf, 0);
    if (r > 0) { if (direct) { d += r; n -= (size_t)r; } else { inPos = 0; inLen = (size_t)r; } continue; }
    if (r == 0) { ioFail = true; if (closeReason.empty()) closeReason = "The connection was closed by the remote computer."; return false; }
    if (errno == EINTR) continue;
    if (errno == EAGAIN || errno == EWOULDBLOCK) { if (!waitFd(POLLIN)) { ioFail = true; return false; } continue; }
    ioFail = true; if (closeReason.empty()) closeReason = strf("Network error: %s", strerror(errno)); return false;
  }
  return true;
}
bool Session::skip(size_t n) {
  u8 tmp[1024];
  while (n) { size_t k = n > sizeof tmp ? sizeof tmp : n; if (!readn(tmp, k)) return false; n -= k; }
  return true;
}
u8 Session::rd8() { if (inPos < inLen) return (raActive ? raPlain.p : inbuf)[inPos++]; u8 v = 0; readn(&v, 1); return v; }
u16 Session::rd16() { u8 b[2] = {0, 0}; readn(b, 2); return (u16)((b[0] << 8) | b[1]); }
u32 Session::rd32() { u8 b[4] = {0, 0, 0, 0}; readn(b, 4); return ((u32)b[0] << 24) | (b[1] << 16) | (b[2] << 8) | b[3]; }

bool Session::rawSend(const void* d, size_t n) {
  const u8* p = (const u8*)d;
  while (n) {
    if (fd < 0) return false;
    ssize_t r = send(fd, p, n, MSG_NOSIGNAL);
    if (r > 0) { p += r; n -= r; continue; }
    if (r < 0 && errno == EINTR) continue;
    if (r < 0 && (errno == EAGAIN || errno == EWOULDBLOCK)) { if (!waitFd(POLLOUT)) return false; continue; }
    return false;
  }
  return true;
}
bool Session::sendAll(const void* d, size_t n) {
  Lock l(sendMutex);
  if (!raActive) return rawSend(d, n);
  const u8* p = (const u8*)d;
  while (n) {                                           // RA2: chunk into encrypted messages
    size_t k = n > 8192 ? 8192 : n;
    Bytes out; if (!out.resize(2 + k + 16)) return false;
    if (!raTx.seal(p, k, out.p)) return false;
    if (!rawSend(out.p, out.n)) return false;
    p += k; n -= k;
  }
  return true;
}

// ---------------------------------------------------------------- connect
bool Session::connectTcp(Str* err) {
  // Address forms: host, host:port, host::port (absolute port), [v6]:port; port < 100 means display number.
  char host[256]; int port = 5900;
  const char* a = address.c();
  if (*a == '[') {
    const char* e = strchr(a, ']'); if (!e || (size_t)(e - a) >= sizeof host) { *err = "Invalid address"; return false; }
    size_t n = e - a - 1; memcpy(host, a + 1, n); host[n] = 0;
    if (e[1] == ':') { const char* q = e + 2; bool abs = false; if (*q == ':') { abs = true; q++; } long v = atol(q); port = (abs || v >= 100) ? (int)v : 5900 + (int)v; }
  } else {
    const char* c = strchr(a, ':');
    size_t n = c ? (size_t)(c - a) : strlen(a);
    if (n == 0 || n >= sizeof host) { *err = "Invalid address"; return false; }
    memcpy(host, a, n); host[n] = 0;
    if (c) {
      if (strchr(c + 1, ':') && c[1] != ':') {   // bare IPv6 literal
        snprintf(host, sizeof host, "%s", a);
      } else { const char* q = c + 1; bool abs = false; if (*q == ':') { abs = true; q++; } long v = atol(q); port = (abs || v >= 100) ? (int)v : 5900 + (int)v; }
    }
  }
  if (port <= 0 || port > 65535) { *err = "Invalid port"; return false; }
  char ps[16]; snprintf(ps, sizeof ps, "%d", port);
  struct addrinfo hints; memset(&hints, 0, sizeof hints); hints.ai_socktype = SOCK_STREAM;
  struct addrinfo* res = nullptr;
  int gr = getaddrinfo(host, ps, &hints, &res);
  if (gr != 0) { *err = strf("Cannot resolve host '%s': %s", host, gai_strerror(gr)); return false; }
  Str last = "Connection failed";
  for (struct addrinfo* ai = res; ai; ai = ai->ai_next) {
    int s = socket(ai->ai_family, ai->ai_socktype, ai->ai_protocol);
    if (s < 0) continue;
    fcntl(s, F_SETFL, fcntl(s, F_GETFL) | O_NONBLOCK);
    int one = 1; setsockopt(s, IPPROTO_TCP, TCP_NODELAY, &one, sizeof one);
    int r = connect(s, ai->ai_addr, ai->ai_addrlen);
    if (r < 0 && errno == EINPROGRESS) {
      long tmo = parseInt(getOpt("ConnectTimeout", "15").c(), 15) * 1000;
      struct pollfd p[2] = {{s, POLLOUT, 0}, {wake[0], POLLIN, 0}};
      int pr;
      do { pr = poll(p, 2, (int)tmo); } while (pr < 0 && errno == EINTR);
      if (pr > 0 && p[1].revents) { close(s); freeaddrinfo(res); *err = "Cancelled"; return false; }
      if (pr <= 0) { close(s); last = "Connection timed out"; continue; }
      int soerr = 0; socklen_t sl = sizeof soerr; getsockopt(s, SOL_SOCKET, SO_ERROR, &soerr, &sl);
      if (soerr) { close(s); last = strf("Connection failed: %s", strerror(soerr)); continue; }
    } else if (r < 0) { last = strf("Connection failed: %s", strerror(errno)); close(s); continue; }
    fd = s; inPos = inLen = 0; ioFail = false; raActive = false; raTx.clear(); raRx.clear();
    freeaddrinfo(res); return true;
  }
  freeaddrinfo(res); *err = last; return false;
}

// ---------------------------------------------------------------- dialogs
void Session::showError(const char* msg) {
  logf(LOG_WARN, "session %llu error: %s", (unsigned long long)id, msg);
  if (!env || !G.msgBoxFactory || !G.createMsgBox || closing) return;
  u64 h = promptCreate(this);
  jstring m = newStr(env, msg), t = newStr(env, "VNC Viewer");
  jobject dlg = env->CallObjectMethod(G.msgBoxFactory, G.createMsgBox, sessionObj, (jlong)h, m, (jint)0, t);
  if (env->ExceptionCheck()) { env->ExceptionClear(); }
  env->DeleteLocalRef(m); env->DeleteLocalRef(t);
  if (dlg) { promptWait(h, this); env->DeleteLocalRef(dlg); }
  promptRelease(h);
}

bool Session::askCredentials(const char* msg, bool needUser, Str* user, Str* pass) {
  if (!env || !G.passwdFactory || !G.createPasswdDlg) return false;
  u64 h = promptCreate(this);
  Str full = needUser ? strf("@user@%s", msg) : Str(msg);       // marker tells the UI to show a username field
  jstring m = newStr(env, full.c());
  jobject dlg = env->CallObjectMethod(G.passwdFactory, G.createPasswdDlg, sessionObj, (jlong)h, m);
  if (env->ExceptionCheck()) { env->ExceptionClear(); }
  env->DeleteLocalRef(m);
  bool ok = false;
  if (dlg) {
    Prompt* p = promptWait(h, this);
    if (p && p->ok) { *user = p->user.c(); *pass = p->pass.c(); ok = true; }
    env->DeleteLocalRef(dlg);
  }
  promptRelease(h);
  return ok;
}

bool Session::askPassword(const char* msg, Str* out) {
  if (!env || !G.passwdFactory || !G.createPasswdDlg) return false;
  u64 h = promptCreate(this);
  jstring m = newStr(env, msg);
  jobject dlg = env->CallObjectMethod(G.passwdFactory, G.createPasswdDlg, sessionObj, (jlong)h, m);
  if (env->ExceptionCheck()) { env->ExceptionClear(); }
  env->DeleteLocalRef(m);
  bool ok = false;
  if (dlg) {
    Prompt* p = promptWait(h, this);
    if (p && p->ok) { *out = p->pass.c(); ok = true; }
    env->DeleteLocalRef(dlg);
  }
  promptRelease(h);
  return ok;
}

// ---------------------------------------------------------------- handshake
bool Session::handshake(Str* err, bool* retry) {
  *retry = false;
  char ver[13] = {0};
  if (!readn(ver, 12)) { *err = closeReason.empty() ? "No response from server" : closeReason.c(); return false; }
  int maj = 0, min = 0;
  if (strncmp(ver, "RFB ", 4) || sscanf(ver + 4, "%d.%d", &maj, &min) != 2) { *err = "The remote computer is not an RFB (VNC) server."; return false; }
  // RealVNC servers announce e.g. RFB 004.001 (any version newer than 3.8): answer 3.8 as the RFB spec requires.
  if (maj < 3) { *err = "Unsupported RFB protocol version"; return false; }
  bool newer = maj > 3 || min >= 8;
  int cmaj = 3, cmin = newer ? 8 : (min == 7 ? 7 : 3);
  Str pv = getOpt("ProtocolVersion", "");
  if (pv.eq("3.3")) cmin = 3; else if (pv.eq("3.7") && (newer || min >= 7)) cmin = 7; else if (pv.eq("3.8") && newer) cmin = 8;
  verMajor = cmaj; verMinor = cmin;
  char cv[13]; snprintf(cv, sizeof cv, "RFB 003.%03d\n", cmin);
  if (!sendAll(cv, 12)) { *err = "Network error"; return false; }

  int sec = 0;
  if (cmin == 3) {
    u32 t = rd32(); if (ioFail) { *err = closeReason.c(); return false; }
    if (t == 0) { u32 n = rd32(); Bytes b; if (n < 4096 && b.resize(n + 1) && readn(b.p, n)) { b.p[n] = 0; *err = (const char*)b.p; } else *err = "Connection refused"; return false; }
    sec = (int)t;
  } else {
    u8 n = rd8(); if (ioFail) { *err = closeReason.c(); return false; }
    if (n == 0) { u32 l = rd32(); Bytes b; if (l < 4096 && b.resize(l + 1) && readn(b.p, l)) { b.p[l] = 0; *err = (const char*)b.p; } else *err = "Connection refused"; return false; }
    u8 types[256]; if (!readn(types, n)) { *err = closeReason.c(); return false; }
    bool has[256] = {false};
    for (int i = 0; i < n; i++) has[types[i]] = true;
    // RA2 (RSA-AES) variants first, since they protect the credentials; then VNC password; then None.
    // 5/129 also encrypt the whole session, 6/130 ("ne") only the login. The "ne" pair is tried first by default
    // because it is the variant verified against real servers by other open-source viewers; PreferEncrypted=1 flips that.
    bool prefEnc = parseBool(getOpt("PreferEncrypted", "0").c(), false);
    static const int orderPlain[] = {6, 130, 5, 129}, orderEnc[] = {129, 5, 130, 6};
    const int* order = prefEnc ? orderEnc : orderPlain;
    sec = 0;
    for (int i = 0; i < 4 && !sec; i++) if (has[order[i]]) sec = order[i];
    if (!sec && has[2]) sec = 2;
    if (!sec && has[1]) sec = 1;
    if (!sec) { *err = "No configured security type is supported by this viewer (server offers RSA-AES, VNC password or none only if enabled)."; return false; }
    u8 c = (u8)sec; if (!sendAll(&c, 1)) { *err = "Network error"; return false; }
  }
  secType = sec;
  if (sec == 1) {
    secDesc = "None (connection is not encrypted)";
    if (cmin >= 8) { u32 r = rd32(); if (ioFail) { *err = closeReason.c(); return false; } if (r != 0) { *err = "Security negotiation failed"; return false; } }
  } else if (sec == 2) {
    secDesc = "VNC password authentication (connection is not encrypted)";
    u8 ch[16]; if (!readn(ch, 16)) { *err = closeReason.c(); return false; }
    Str pw;
    bool have = false;
    if (authFailures == 0) { Str o = getOpt("Password", ""); if (!o.empty()) { pw = o; have = true; } }
    if (!have && authFailures == 0 && !uuid.empty()) { Str sp = storeGetPassword(uuid.c()); if (!sp.empty()) { pw = sp; have = true; } }
    if (!have) {
      if (!askPassword(authFailures ? "Password incorrect" : "", &pw)) { *err = closing ? "Cancelled" : "Password not provided"; return false; }
    }
    u8 resp[16]; vncAuthResponse(pw.c(), ch, resp);
    if (!sendAll(resp, 16)) { *err = "Network error"; return false; }
    u32 r = rd32(); if (ioFail) { *err = closeReason.c(); return false; }
    if (r != 0) {
      authFailures++;
      Str why = "Password incorrect";
      if (cmin >= 8) { u32 l = rd32(); Bytes b; if (l < 4096 && b.resize(l + 1) && readn(b.p, l)) { b.p[l] = 0; if (l) why = (const char*)b.p; } }
      if (authFailures < authAllowed) { *retry = true; }
      *err = why; return false;
    }
    if (!uuid.empty() && !pw.empty()) storeSetPassword(uuid.c(), pw.c());
  } else if (sec == 5 || sec == 6 || sec == 129 || sec == 130) {
    bool okAuth = ra2Auth(sec, err, retry);
    if (!okAuth) return false;
    u32 r = rd32(); if (ioFail) { *err = closeReason.c(); return false; }
    if (r != 0) {
      authFailures++;
      Str why = "Authentication failed";
      if (cmin >= 8) { u32 l = rd32(); Bytes b; if (l < 4096 && b.resize(l + 1) && readn(b.p, l)) { b.p[l] = 0; if (l) why = (const char*)b.p; } }
      if (authFailures < authAllowed) { *retry = true; }
      *err = why; return false;
    }
  } else { *err = "Unsupported security type"; return false; }
  return true;
}

// RSA-AES security types (RFB "RA2"): RSA key exchange, AES-EAX protected login with username/password.
bool Session::ra2Auth(int sec, Str* err, bool* retry) {
  (void)retry;
  const bool sha256 = (sec == 129 || sec == 130), encrypted = (sec == 5 || sec == 129);
  const int keyLen = sha256 ? 32 : 16; const size_t hl = sha256 ? 32 : 20;
  const char* names[] = {"RSA-AES", "RSA-AES, login only encrypted", "RSA-AES-256", "RSA-AES-256, login only encrypted"};
  const char* nm = names[sec == 5 ? 0 : sec == 6 ? 1 : sec == 129 ? 2 : 3];
  auto fail = [&](const char* m) { *err = ioFail && !closeReason.empty() ? closeReason.c() : m; return false; };

  u32 sbits = rd32(); if (ioFail) return fail("Network error");
  if (sbits < 1024 || sbits > 8192) return fail("RSA-AES: the server's public key has an unacceptable size");
  size_t sb = (sbits + 7) / 8; Bytes spub; if (!spub.resize(4 + 2 * sb)) return fail("Out of memory");
  spub.p[0] = (u8)(sbits >> 24); spub.p[1] = (u8)(sbits >> 16); spub.p[2] = (u8)(sbits >> 8); spub.p[3] = (u8)sbits;
  if (!readn(spub.p + 4, 2 * sb)) return fail("Network error");

  mbedtls_rsa_context* crsa = nullptr; Bytes cpub;
  if (!ra2::clientKey(&crsa, &cpub, 2048)) return fail("RSA-AES: could not generate a client key");
  const size_t cb = (cpub.n - 4) / 2;
  if (!sendAll(cpub.p, cpub.n)) return fail("Network error");

  u8 crand[16]; if (!ra2::randomBytes(crand, 16)) return fail("No random source available");
  Bytes encr; if (!encr.resize(2 + sb)) return fail("Out of memory");
  encr.p[0] = (u8)(sb >> 8); encr.p[1] = (u8)sb;
  if (!ra2::rsaEncrypt(spub.p + 4, sb, spub.p + 4 + sb, sb, crand, 16, encr.p + 2)) return fail("RSA-AES: invalid server public key");
  if (!sendAll(encr.p, encr.n)) return fail("Network error");

  u16 rl = rd16(); if (ioFail) return fail("Network error");
  if (rl != cb) return fail("RSA-AES: unexpected encrypted random length");
  Bytes er; if (!er.resize(rl) || !readn(er.p, rl)) return fail("Network error");
  u8 srand_[64]; size_t srl = 0;
  if (!ra2::clientDecrypt(er.p, rl, srand_, &srl, sizeof srand_) || srl != 16) return fail("RSA-AES: corrupted random from server");

  u8 kin[32], ck[32], sk[32];
  memcpy(kin, srand_, 16); memcpy(kin + 16, crand, 16); ra2::hash(sha256, kin, 32, nullptr, 0, ck);        // client -> server key
  memcpy(kin, crand, 16); memcpy(kin + 16, srand_, 16); ra2::hash(sha256, kin, 32, nullptr, 0, sk);        // server -> client key
  if (!raTx.init(ck, keyLen) || !raRx.init(sk, keyLen)) return fail("RSA-AES: cipher setup failed");

  u8 chash[32], shash[32];
  ra2::hash(sha256, cpub.p, cpub.n, spub.p, spub.n, chash);
  ra2::hash(sha256, spub.p, spub.n, cpub.p, cpub.n, shash);
  { Bytes m; if (!m.resize(2 + hl + 16) || !raTx.seal(chash, hl, m.p) || !sendAll(m.p, m.n)) return fail("Network error"); }
  { u16 l = rd16(); if (ioFail) return fail("Network error"); if (l != hl) return fail("RSA-AES: wrong server hash length");
    u8 enc[32 + 16], pl[32]; if (!readn(enc, hl + 16)) return fail("Network error");
    if (!raRx.open(hl, enc, pl)) return fail("RSA-AES: server hash failed authentication");
    u8 diff = 0; for (size_t i = 0; i < hl; i++) diff |= (u8)(pl[i] ^ shash[i]);
    if (diff) return fail("RSA-AES: server hash mismatch (possible man-in-the-middle)"); }

  int subtype = 0;
  { u16 l = rd16(); if (ioFail) return fail("Network error"); if (l != 1) return fail("RSA-AES: wrong subtype message");
    u8 enc[17], pl[1]; if (!readn(enc, 17)) return fail("Network error");
    if (!raRx.open(1, enc, pl)) return fail("RSA-AES: subtype failed authentication");
    subtype = pl[0]; if (subtype != 1 && subtype != 2) return fail("RSA-AES: unknown credentials subtype"); }

  Str user, pass; bool have = false;
  if (authFailures == 0) {
    Str o = getOpt("Password", "");
    if (!o.empty()) { pass = o; user = getOpt("Username", ""); have = subtype == 2 || !user.empty(); }
  }
  if (!have && authFailures == 0 && !uuid.empty() && subtype == 2) { Str sp = storeGetPassword(uuid.c()); if (!sp.empty()) { pass = sp; have = true; } }
  if (!have) {
    if (!askCredentials(authFailures ? "Authentication failed" : "", subtype == 1, &user, &pass)) { *err = closing ? "Cancelled" : "Credentials not provided"; return false; }
  }
  size_t ul = subtype == 1 ? strlen(user.c()) : 0, pl2 = strlen(pass.c());
  if (ul > 255) ul = 255; if (pl2 > 255) pl2 = 255;
  { Bytes cred; if (!cred.resize(2 + ul + pl2)) return fail("Out of memory");
    cred.p[0] = (u8)ul; if (ul) memcpy(cred.p + 1, user.c(), ul);
    cred.p[1 + ul] = (u8)pl2; if (pl2) memcpy(cred.p + 2 + ul, pass.c(), pl2);
    Bytes m; if (!m.resize(2 + cred.n + 16) || !raTx.seal(cred.p, cred.n, m.p) || !sendAll(m.p, m.n)) return fail("Network error");
    memset(cred.p, 0, cred.n); }
  if (!uuid.empty() && subtype == 2 && !pass.empty()) storeSetPassword(uuid.c(), pass.c());

  u8 fp[20]; ra2::hash(false, spub.p, spub.n, nullptr, 0, fp);
  secDesc = strf("%s (server key SHA-1 %02x%02x:%02x%02x:%02x%02x:%02x%02x)%s", nm, fp[0], fp[1], fp[2], fp[3], fp[4], fp[5], fp[6], fp[7],
                 encrypted ? ", session encrypted" : "");
  if (encrypted) { inPos = inLen = 0; raActive = true; }          // everything after this point is AES-EAX framed
  else { raTx.clear(); raRx.clear(); }
  return true;
}

// ---------------------------------------------------------------- setup messages
static void put16(u8* p, int v) { p[0] = (u8)(v >> 8); p[1] = (u8)v; }
static void put32(u8* p, u32 v) { p[0] = (u8)(v >> 24); p[1] = (u8)(v >> 16); p[2] = (u8)(v >> 8); p[3] = (u8)v; }

bool Session::sendSetup() {
  u8 m[20] = {0};
  m[0] = 0; m[4] = 32; m[5] = 24; m[6] = 0; m[7] = 1;
  put16(m + 8, 255); put16(m + 10, 255); put16(m + 12, 255);
  m[14] = 0; m[15] = 8; m[16] = 16;
  if (!sendAll(m, 20)) return false;
  viewerPF = PixelFormat();
  return true;
}

static void encodingList(const char* pref, int* out, int* n) {
  int k = 0;
  int pe = -1;
  if (!strcasecmp(pref, "ZRLE")) pe = 16; else if (!strcasecmp(pref, "Hextile")) pe = 5;
  else if (!strcasecmp(pref, "RRE")) pe = 2; else if (!strcasecmp(pref, "Raw")) pe = 0;
  if (pe >= 0) out[k++] = pe;
  static const int base[] = {16, 5, 1, 2, 0};
  for (int b : base) if (b != pe) out[k++] = b;
  out[k++] = -239; out[k++] = -223; out[k++] = -308; out[k++] = -224;
  *n = k;
}

void Session::applyOptions() {
  if (!connected) return;
  int enc[16], n; Str pref = getOpt("PreferredEncoding", "ZRLE");
  encodingList(pref.c(), enc, &n);
  u8 buf[4 + 16 * 4]; buf[0] = 2; buf[1] = 0; put16(buf + 2, n);
  for (int i = 0; i < n; i++) put32(buf + 4 + 4 * i, (u32)enc[i]);
  sendAll(buf, 4 + 4 * n);
}

bool Session::sendUpdateRequest(bool incremental) {
  u8 m[10]; m[0] = 3; m[1] = incremental ? 1 : 0;
  put16(m + 2, 0); put16(m + 4, 0); put16(m + 6, fbW); put16(m + 8, fbH);
  return sendAll(m, 10);
}

// ---------------------------------------------------------------- Java callbacks
void Session::cbDesktopSize() {
  if (!env || !desktopCb || !mSetDesktopSize) return;
  env->CallVoidMethod(desktopCb, mSetDesktopSize, (jint)fbW, (jint)fbH);
  if (env->ExceptionCheck()) env->ExceptionClear();
}
void Session::cbDraw(int x, int y, int w, int h) {
  if (!env || !desktopCb || !mDrawRegion) return;
  env->CallVoidMethod(desktopCb, mDrawRegion, (jint)x, (jint)y, (jint)w, (jint)h);
  if (env->ExceptionCheck()) env->ExceptionClear();
}

// ---------------------------------------------------------------- framebuffer
bool Session::resizeFb(int w, int h) {
  if (w <= 0 || h <= 0 || w > kMaxDim || h > kMaxDim || (size_t)w * h > kMaxFbPixels) { closeReason = "Unsupported desktop size"; return false; }
  {
    Lock l(fbMutex);
    if (!fb.resize((size_t)w * h * 4)) { closeReason = "Out of memory"; return false; }
    memset(fb.p, 0, fb.n); fbW = w; fbH = h;
  }
  return true;
}

// One 3-byte ZRLE pixel as the framebuffer's R,G,B,0xFF bytes, built as a single 32-bit value.
static inline u32 px3(const u8* p) { u8 b[4] = {p[0], p[1], p[2], 0xff}; u32 v; memcpy(&v, b, 4); return v; }
static inline void fill32(u8* d, u32 v, int n) { u32* q = (u32*)d; for (int i = 0; i < n; i++) q[i] = v; }
void Session::fillRect(int x, int y, int w, int h, const u8* px) {
  u32 v; memcpy(&v, px, 4);
  for (int r = 0; r < h; r++) fill32(fb.p + ((size_t)(y + r) * fbW + x) * 4, v, w);
}

bool Session::decRaw(int x, int y, int w, int h) {
  size_t rowBytes = (size_t)w * 4; int chunk = (int)(262144 / (rowBytes ? rowBytes : 1)); if (chunk < 16) chunk = 16;
  for (int r = 0; r < h; r += chunk) {
    int rows = h - r < chunk ? h - r : chunk;
    if (!scrA.resize((size_t)rows * rowBytes)) { closeReason = "Out of memory"; return false; }
    if (!readn(scrA.p, scrA.n)) return false;
    Lock l(fbMutex);
    if (x == 0 && w == fbW) memcpy(fb.p + (size_t)(y + r) * fbW * 4, scrA.p, scrA.n);
    else for (int i = 0; i < rows; i++) memcpy(fb.p + ((size_t)(y + r + i) * fbW + x) * 4, scrA.p + (size_t)i * rowBytes, rowBytes);
  }
  return true;
}

bool Session::decCopyRect(int x, int y, int w, int h) {
  int sx = rd16(), sy = rd16(); if (ioFail) return false;
  if (sx + w > fbW || sy + h > fbH) { closeReason = "Invalid CopyRect source"; return false; }
  Lock l(fbMutex);
  // In place, one row at a time: rows are visited in the direction that never overwrites a source
  // row before it is read, and memmove covers overlap inside a row. No temporary copy.
  size_t rb = (size_t)w * 4;
  if (sy >= y) for (int r = 0; r < h; r++) memmove(fb.p + ((size_t)(y + r) * fbW + x) * 4, fb.p + ((size_t)(sy + r) * fbW + sx) * 4, rb);
  else for (int r = h - 1; r >= 0; r--) memmove(fb.p + ((size_t)(y + r) * fbW + x) * 4, fb.p + ((size_t)(sy + r) * fbW + sx) * 4, rb);
  return true;
}

bool Session::decRRE(int x, int y, int w, int h, bool corre) {
  u32 n = rd32(); u8 bg[4]; if (!readn(bg, 4)) return false;
  size_t per = corre ? 8 : 12;
  if ((size_t)n > (size_t)w * h) { closeReason = "Invalid RRE data"; return false; }
  Bytes tmp; if (!tmp.resize(n * per)) return false;
  if (n && !readn(tmp.p, tmp.n)) return false;
  Lock l(fbMutex);
  fillRect(x, y, w, h, bg);
  for (u32 i = 0; i < n; i++) {
    const u8* p = tmp.p + i * per; int sx, sy, sw, sh;
    if (corre) { sx = p[4]; sy = p[5]; sw = p[6]; sh = p[7]; }
    else { sx = (p[4] << 8) | p[5]; sy = (p[6] << 8) | p[7]; sw = (p[8] << 8) | p[9]; sh = (p[10] << 8) | p[11]; }
    if (sx + sw > w || sy + sh > h) { closeReason = "Invalid RRE subrectangle"; return false; }
    fillRect(x + sx, y + sy, sw, sh, p);
  }
  return true;
}

bool Session::decHextile(int x, int y, int w, int h) {
  u8 bg[4] = {0, 0, 0, 0}, fg[4] = {0, 0, 0, 0};
  for (int ty = 0; ty < h; ty += 16) for (int tx = 0; tx < w; tx += 16) {
    int tw = w - tx < 16 ? w - tx : 16, th = h - ty < 16 ? h - ty : 16;
    u8 sub = rd8(); if (ioFail) return false;
    if (sub & 1) {
      u8 rawTile[16 * 16 * 4]; if (!readn(rawTile, (size_t)tw * th * 4)) return false;
      Lock l(fbMutex);
      for (int r = 0; r < th; r++) memcpy(fb.p + ((size_t)(y + ty + r) * fbW + x + tx) * 4, rawTile + (size_t)r * tw * 4, (size_t)tw * 4);
      continue;
    }
    if (sub & 2) if (!readn(bg, 4)) return false;
    if (sub & 4) if (!readn(fg, 4)) return false;
    int ns = 0; if (sub & 8) ns = rd8();
    size_t per = (sub & 16) ? 6 : 2;
    u8 subBuf[255 * 6]; if (ns && !readn(subBuf, (size_t)ns * per)) return false;
    if (ioFail) return false;
    Lock l(fbMutex);
    fillRect(x + tx, y + ty, tw, th, bg);
    for (int i = 0; i < ns; i++) {
      const u8* p = subBuf + (size_t)i * per; const u8* col = fg; const u8* g = p;
      if (sub & 16) { col = p; g = p + 4; }
      int sx = g[0] >> 4, sy = g[0] & 15, sw = (g[1] >> 4) + 1, sh = (g[1] & 15) + 1;
      if (sx + sw > tw || sy + sh > th) { closeReason = "Invalid Hextile subrectangle"; return false; }
      fillRect(x + tx + sx, y + ty + sy, sw, sh, col);
    }
  }
  return true;
}

bool Session::decZrle(int x, int y, int w, int h) {
  u32 len = rd32(); if (ioFail) return false;
  if (len > (64u << 20)) { closeReason = "ZRLE data too large"; return false; }
  Bytes& comp = scrA; if (!comp.resize(len) || !readn(comp.p, len)) return false;
  if (!zInit) { memset(&zs, 0, sizeof zs); if (inflateInit(&zs) != Z_OK) { closeReason = "zlib init failed"; return false; } zInit = true; }
  Bytes& out = scrB; out.clear(); size_t maxOut = (size_t)w * h * 4 + (size_t)((w + 63) / 64) * ((h + 63) / 64) * 4096 + 65536;
  if (!out.reserve((size_t)w * h * 3 + (size_t)((w + 63) / 64) * ((h + 63) / 64) * 130 + 65536)) { closeReason = "Out of memory"; return false; }
  zs.next_in = comp.p; zs.avail_in = len;
  while (zs.avail_in) {
    if (!out.reserve(out.n + 65536)) return false;
    zs.next_out = out.p + out.n; zs.avail_out = (uInt)(out.cap - out.n);
    int r = inflate(&zs, Z_SYNC_FLUSH);
    out.n = out.cap - zs.avail_out;
    if (r != Z_OK && r != Z_BUF_ERROR && r != Z_STREAM_END) { closeReason = "ZRLE decompression error"; return false; }
    if (out.n > maxOut) { closeReason = "ZRLE output too large"; return false; }
    if (r == Z_BUF_ERROR && zs.avail_in == 0) break;
  }
  const u8* p = out.p; const u8* end = out.p + out.n;
  Lock l(fbMutex);
  for (int ty = 0; ty < h; ty += 64) for (int tx = 0; tx < w; tx += 64) {
    int tw = w - tx < 64 ? w - tx : 64, th = h - ty < 64 ? h - ty : 64;
    if (p >= end) goto bad;
    {
      u8 st = *p++; bool rle = st & 128; int ps = st & 127;
      u32 pal[128];
      u8* base = fb.p + ((size_t)(y + ty) * fbW + x + tx) * 4;
      size_t rs = (size_t)fbW * 4;
      if (!rle && ps == 0) {
        if ((size_t)(end - p) < (size_t)tw * th * 3) goto bad;
        for (int r = 0; r < th; r++) {
          u8* o = base + r * rs;
          for (int c = 0; c < tw; c++) { u32 v = px3(p); memcpy(o + c * 4, &v, 4); p += 3; }
        }
      } else if (!rle && ps == 1) {
        if (end - p < 3) goto bad; u32 v = px3(p); p += 3;
        u8 px[4]; memcpy(px, &v, 4);
        fillRect(x + tx, y + ty, tw, th, px);
      } else if (!rle && ps >= 2 && ps <= 16) {
        if ((end - p) < ps * 3) goto bad;
        for (int i = 0; i < ps; i++) { pal[i] = px3(p); p += 3; }
        int bits = ps <= 2 ? 1 : (ps <= 4 ? 2 : 4);
        int mask = (1 << bits) - 1;
        int need = (tw * bits + 7) / 8;
        for (int r = 0; r < th; r++) {
          if (end - p < need) goto bad;
          u8* o = base + r * rs;
          int bitpos = 0;
          for (int c = 0; c < tw; c++) {
            int sh = 8 - bits - (bitpos & 7);
            int idx = (p[bitpos >> 3] >> sh) & mask; bitpos += bits;
            if (idx >= ps) goto bad;
            memcpy(o + c * 4, &pal[idx], 4);
          }
          p += need;
        }
      } else if (rle && ps == 0) {
        int pos = 0, total = tw * th, cx = 0, cy = 0;
        while (pos < total) {
          if (end - p < 3) goto bad; u32 pv = px3(p); p += 3;
          int run = 1; for (;;) { if (p >= end) goto bad; int b = *p++; run += b; if (b != 255) break; }
          if (run > total - pos) goto bad;
          pos += run;
          while (run > 0) { int n = tw - cx < run ? tw - cx : run; fill32(base + cy * rs + cx * 4, pv, n); cx += n; run -= n; if (cx == tw) { cx = 0; cy++; } }
        }
      } else if (rle && ps >= 2) {
        if (ps > 127 || (end - p) < ps * 3) goto bad;
        for (int i = 0; i < ps; i++) { pal[i] = px3(p); p += 3; }
        int pos = 0, total = tw * th, cx = 0, cy = 0;
        while (pos < total) {
          if (p >= end) goto bad; int idx = *p++; int run = 1;
          if (idx & 128) { idx &= 127; for (;;) { if (p >= end) goto bad; int b = *p++; run += b; if (b != 255) break; } }
          if (idx >= ps || run > total - pos) goto bad;
          u32 pv = pal[idx]; pos += run;
          while (run > 0) { int n = tw - cx < run ? tw - cx : run; fill32(base + cy * rs + cx * 4, pv, n); cx += n; run -= n; if (cx == tw) { cx = 0; cy++; } }
        }
      } else goto bad;
    }
  }
  return true;
bad:
  closeReason = "Invalid ZRLE data"; return false;
}

bool Session::decCursor(int hx, int hy, int w, int h) {
  if (w < 0 || h < 0 || w > 512 || h > 512) { closeReason = "Invalid cursor size"; return false; }
  size_t pix = (size_t)w * h * 4, mask = (size_t)((w + 7) / 8) * h;
  Bytes d; if (!d.resize(pix + mask)) return false;
  if (d.n && !readn(d.p, d.n)) return false;
  if (!env || !desktopCb || !mSetCursor) return true;
  if (w == 0 || h == 0 || !G.bitmapCls || !G.bitmapCreate || !G.argb8888) {
    env->CallVoidMethod(desktopCb, mSetCursor, (jobject) nullptr, (jint)hx, (jint)hy);
    if (env->ExceptionCheck()) env->ExceptionClear();
    return true;
  }
  jobject bmp = env->CallStaticObjectMethod(G.bitmapCls, G.bitmapCreate, (jint)w, (jint)h, G.argb8888);
  if (env->ExceptionCheck()) { env->ExceptionClear(); return true; }
  if (!bmp) return true;
  AndroidBitmapInfo info; void* addr = nullptr;
  if (AndroidBitmap_getInfo(env, bmp, &info) == 0 && AndroidBitmap_lockPixels(env, bmp, &addr) == 0 && addr) {
    for (int r = 0; r < h; r++) {
      u8* o = (u8*)addr + (size_t)r * info.stride;
      for (int c = 0; c < w; c++) {
        bool on = d.p[pix + (size_t)r * ((w + 7) / 8) + (c >> 3)] & (0x80 >> (c & 7));
        const u8* s = d.p + ((size_t)r * w + c) * 4;
        if (c * 4 + 3 >= (int)info.stride) break;
        o[c * 4] = on ? s[0] : 0; o[c * 4 + 1] = on ? s[1] : 0; o[c * 4 + 2] = on ? s[2] : 0; o[c * 4 + 3] = on ? 0xff : 0;
      }
    }
    AndroidBitmap_unlockPixels(env, bmp);
    env->CallVoidMethod(desktopCb, mSetCursor, bmp, (jint)hx, (jint)hy);
    if (env->ExceptionCheck()) env->ExceptionClear();
  }
  env->DeleteLocalRef(bmp);
  return true;
}

bool Session::decExtDesktopSize(int reason, int status, int w, int h) {
  u8 hdr[4]; if (!readn(hdr, 4)) return false;
  if (!skip((size_t)hdr[0] * 16)) return false;
  if (status != 0 && reason != 0) return true;   // failed client-initiated change
  if (w != fbW || h != fbH) { if (!resizeFb(w, h)) return false; cbDesktopSize(); }
  return true;
}

bool Session::decodeRect(int x, int y, int w, int h, int enc) {
  switch (enc) {
    case -223: if (w != fbW || h != fbH) { if (!resizeFb(w, h)) return false; cbDesktopSize(); } return true;
    case -308: return decExtDesktopSize(x, y, w, h);
    case -239: return decCursor(x, y, w, h);
    case -224: return true;
  }
  if (x < 0 || y < 0 || w < 0 || h < 0 || x + w > fbW || y + h > fbH) { closeReason = "Rectangle outside framebuffer"; return false; }
  bool ok;
  switch (enc) {
    case 0: lastEncoding = "Raw"; ok = decRaw(x, y, w, h); break;
    case 1: lastEncoding = "CopyRect"; ok = decCopyRect(x, y, w, h); break;
    case 2: lastEncoding = "RRE"; ok = decRRE(x, y, w, h, false); break;
    case 4: lastEncoding = "CoRRE"; ok = decRRE(x, y, w, h, true); break;
    case 5: lastEncoding = "Hextile"; ok = decHextile(x, y, w, h); break;
    case 16: lastEncoding = "ZRLE"; ok = decZrle(x, y, w, h); break;
    default: closeReason = strf("Unsupported encoding %d", enc); return false;
  }
  if (ok && w && h) cbDraw(x, y, w, h);
  return ok;
}

bool Session::readUpdate() {
  rd8(); int n = rd16(); if (ioFail) return false;
  // Ask for the next update NOW, before decoding this one: the server encodes it, and the request
  // and reply cross the network, while we decode. (Still one request per update, so they never pile up.)
  if (pipeline) { if (!sendUpdateRequest(true)) { closeReason = "Network error"; return false; } earlySent = true; }
  for (int i = 0; i < n; i++) {
    int x = rd16(), y = rd16(), w = rd16(), h = rd16(); int enc = (int)rd32();
    if (ioFail) return false;
    if (enc == -224) break;
    if (!decodeRect(x, y, w, h, enc)) return false;
  }
  if (env && desktopCb && mFbUpdateEnd) { env->CallVoidMethod(desktopCb, mFbUpdateEnd); if (env->ExceptionCheck()) env->ExceptionClear(); }
  return true;
}

bool Session::serverCutText() {
  u8 pad[3]; if (!readn(pad, 3)) return false;
  u32 n = rd32(); if (ioFail) return false;
  if (n > (1u << 20)) { return skip(n); }
  Bytes b; if (!b.resize(n) || (n && !readn(b.p, n))) return false;
  Str u = latin1ToUtf8(b.p, n);
  if (env && desktopCb && mSetClip) {
    lastClip = u.c();
    jstring js = env->NewStringUTF(u.c());
    env->CallVoidMethod(desktopCb, mSetClip, js);
    if (env->ExceptionCheck()) env->ExceptionClear();
    env->DeleteLocalRef(js);
  }
  return true;
}

void Session::sendCutText(const char* utf8) {
  if (!connected || !utf8) return;
  size_t cap = strlen(utf8); if (cap > (1u << 18)) cap = (1u << 18);
  Bytes m; if (!m.resize(8 + cap)) return;
  m.p[0] = 6; m.p[1] = m.p[2] = m.p[3] = 0;
  size_t n = utf8ToLatin1(utf8, m.p + 8, cap);
  put32(m.p + 4, (u32)n);
  sendAll(m.p, 8 + n);
}

bool Session::serverInitAndLoop(Str* err) {
  u8 init = parseBool(getOpt("Shared", "1").c(), true) ? 1 : 0;
  if (!sendAll(&init, 1)) { *err = "Network error"; return false; }
  int w = rd16(), h = rd16();
  u8 pf[16]; if (!readn(pf, 16)) { *err = closeReason.c(); return false; }
  u32 nl = rd32(); if (ioFail) { *err = closeReason.c(); return false; }
  if (nl > 65536) { *err = "Invalid desktop name"; return false; }
  Bytes nm; if (!nm.resize(nl + 1) || !readn(nm.p, nl)) { *err = closeReason.c(); return false; }
  nm.p[nl] = 0; desktopName = latin1ToUtf8(nm.p, nl);
  serverPF.bpp = pf[0]; serverPF.depth = pf[1]; serverPF.bigEndian = pf[2]; serverPF.trueColour = pf[3];
  serverPF.rMax = (pf[4] << 8) | pf[5]; serverPF.gMax = (pf[6] << 8) | pf[7]; serverPF.bMax = (pf[8] << 8) | pf[9];
  serverPF.rShift = pf[10]; serverPF.gShift = pf[11]; serverPF.bShift = pf[12];
  if (!resizeFb(w, h)) { *err = closeReason.empty() ? "Invalid desktop size" : closeReason.c(); return false; }
  if (!sendSetup()) { *err = "Network error"; return false; }
  connected = true;
  applyOptions();
  pipeline = parseBool(getOpt("Pipeline", "1").c(), true);
  if (!sendUpdateRequest(false)) { *err = "Network error"; return false; }
  cbDesktopSize();
  if (env && desktopCb && mConnSuccess) { env->CallVoidMethod(desktopCb, mConnSuccess); if (env->ExceptionCheck()) env->ExceptionClear(); }
  for (;;) {
    u8 t; if (!readn(&t, 1)) { *err = closing ? "" : closeReason.c(); return closing; }
    switch (t) {
      case 0: { int ow = fbW, oh = fbH; earlySent = false;
              if (!readUpdate()) { *err = closeReason.empty() ? "Protocol error" : closeReason.c(); return false; }
              // Normally the request already went out. After a resize it named the old size: repeat it.
              if (!earlySent || fbW != ow || fbH != oh) { if (!sendUpdateRequest(true)) { *err = "Network error"; return false; } }
              break; }
      case 1: { rd8(); int first = rd16(); (void)first; int cnt = rd16(); if (!skip((size_t)cnt * 6)) { *err = closeReason.c(); return false; } break; }
      case 2: if (env && desktopCb && mBell) { env->CallVoidMethod(desktopCb, mBell); if (env->ExceptionCheck()) env->ExceptionClear(); } break;
      case 3: if (!serverCutText()) { *err = closeReason.c(); return false; } break;
      default: *err = strf("Unknown server message type %d", t); return false;
    }
  }
}

// ---------------------------------------------------------------- thread
void Session::run() {
  bool att = false; env = attachThread(&att);
  Str err;
  bool ok = false;
  for (;;) {
    if (closing) break;
    if (!connectTcp(&err)) break;
    bool retry = false;
    if (handshake(&err, &retry)) { ok = serverInitAndLoop(&err); break; }
    close(fd); fd = -1; connected = false;
    if (!retry || closing) break;
    logf(LOG_INFO, "authentication failed (%d/%d), retrying", authFailures, authAllowed);
  }
  connected = false;
  if (!ok && !closing && !err.empty()) showError(err.c());
  if (fd >= 0) { shutdown(fd, SHUT_RDWR); }
  if (env && sessionCb && mSessionClosed) {
    env->CallVoidMethod(sessionCb, mSessionClosed, sessionObj);
    if (env->ExceptionCheck()) env->ExceptionClear();
  }
  finished = true;
  env = nullptr;
  if (att) detachThread();
}

static void* threadMain(void* p) { ((Session*)p)->run(); return nullptr; }

bool Session::start() {
  if (socketpair(AF_UNIX, SOCK_STREAM, 0, wake) != 0) return false;
  fcntl(wake[0], F_SETFL, fcntl(wake[0], F_GETFL) | O_NONBLOCK);
  if (pthread_create(&th, nullptr, threadMain, this) != 0) return false;
  threadStarted = true; return true;
}
void Session::requestClose() {
  closing = true;
  if (wake[1] >= 0) { char c = 1; ssize_t r = write(wake[1], &c, 1); (void)r; }
  promptAbortSession(this);
}
void Session::join() { if (threadStarted) { pthread_join(th, nullptr); threadStarted = false; } }

// ---------------------------------------------------------------- input
void Session::pointer(int x, int y, int mask) {
  int w = fbW, h = fbH;
  if (x > w - 1) x = w - 1; if (y > h - 1) y = h - 1; if (x < 0) x = 0; if (y < 0) y = 0;
  Lock l(inputMutex);
  ptrX = x; ptrY = y; buttons = mask;
  if (!connected || parseBool(getOpt("ViewOnly", "0").c(), false)) return;
  u8 m[6] = {5, (u8)mask}; put16(m + 2, x); put16(m + 4, y);
  sendAll(m, 6);
}
void Session::wheel(int horizontal, int delta) {
  if (!delta) return;
  static const int tbl[4] = {5, 4, 7, 6};
  int idx = ((delta > 0) ^ (horizontal ? 1 : 0)) + (horizontal ? 2 : 0);
  int bit = 1 << (tbl[idx] - 1);
  int n = delta < 0 ? -delta : delta; if (n > 100) n = 100;
  Lock l(inputMutex);
  if (!connected || parseBool(getOpt("ViewOnly", "0").c(), false)) return;
  for (int i = 0; i < n; i++) {
    u8 m[6] = {5, (u8)(buttons | bit)}; put16(m + 2, ptrX); put16(m + 4, ptrY); sendAll(m, 6);
    m[1] = (u8)buttons; sendAll(m, 6);
  }
}
void Session::keyEvent(bool down, u32 ks) {
  Lock l(inputMutex);
  if (down) { bool f = false; for (size_t i = 0; i < pressed.n; i++) if (pressed[i] == ks) f = true; if (!f) pressed.push(ks); }
  else for (size_t i = 0; i < pressed.n; i++) if (pressed[i] == ks) { pressed.erase(i); break; }
  if (!connected || parseBool(getOpt("ViewOnly", "0").c(), false)) return;
  u8 m[8] = {4, (u8)(down ? 1 : 0), 0, 0}; put32(m + 4, ks); sendAll(m, 8);
}
void Session::focusEvent(bool f) {
  if (f == focus) return;
  focus = f;
  if (!f) {
    Vec<u32> keys; { Lock l(inputMutex); keys = pressed; }
    for (size_t i = 0; i < keys.n; i++) keyEvent(false, keys[i]);
    return;
  }
  // Gained focus: forward the local clipboard to the server if it changed.
  JNIEnv* e = nullptr; bool att = false; e = attachThread(&att);
  if (e && desktopCb && mGetClip) {
    jstring js = (jstring)e->CallObjectMethod(desktopCb, mGetClip);
    if (e->ExceptionCheck()) e->ExceptionClear();
    else if (js) {
      const char* c = e->GetStringUTFChars(js, nullptr);
      if (c) { if (!lastClip.eq(c)) { lastClip = c; sendCutText(c); } e->ReleaseStringUTFChars(js, c); }
      e->DeleteLocalRef(js);
    }
  }
  if (att) detachThread();
}

// ---------------------------------------------------------------- scaled copy
void* Session::resizeScaleBuf(int w, int h) {
  if (w <= 0 || h <= 0 || (size_t)w * h > kMaxFbPixels) return nullptr;
  Lock l(fbMutex);
  u8* nb = (u8*)calloc((size_t)w * h, 4); if (!nb) return nullptr;
  if (scaleBuf) { retired.push(scaleBuf); if (retired.n > 4) { free(retired[0]); retired.erase(0); } }
  scaleBuf = nb; scaleW = w; scaleH = h; return nb;
}

void Session::scaledCopy(float scale, u8* dst, int stridepx, int rows, int x, int y, int w, int h) {
  if (!dst || stridepx <= 0 || rows <= 0) return;
  Lock l(fbMutex);
  int step = (scale > 0.f) ? (int)(1.0f / scale) : 1; if (step < 1) step = 1;
  int x0 = x < 0 ? 0 : x, y0 = y < 0 ? 0 : y;
  int x1 = (x + w < fbW) ? x + w : fbW, y1 = (y + h < fbH) ? y + h : fbH;
  if (!fb.p || x1 <= x0 || y1 <= y0) { memset(dst, 0, (size_t)stridepx * rows * 4); return; }
  int cols = (x1 - x0 + step - 1) / step; if (cols > stridepx) cols = stridepx;
  int nrows = (y1 - y0 + step - 1) / step; if (nrows > rows) nrows = rows;
  const u32 kAlpha = 0xff000000u;
  for (int dy = 0; dy < nrows; dy++) {
    const u8* srow = fb.p + ((size_t)(y0 + dy * step) * fbW + x0) * 4;
    u8* o = dst + (size_t)dy * stridepx * 4;
    if (step == 1) {                       // opaque copy, auto-vectorised (NEON on arm64)
      for (int i = 0; i < cols; i++) { u32 v; memcpy(&v, srow + (size_t)i * 4, 4); v |= kAlpha; memcpy(o + (size_t)i * 4, &v, 4); }
    } else {
      for (int i = 0; i < cols; i++) { u32 v; memcpy(&v, srow + (size_t)i * step * 4, 4); v |= kAlpha; memcpy(o + (size_t)i * 4, &v, 4); }
    }
    if (cols < stridepx) memset(o + (size_t)cols * 4, 0, (size_t)(stridepx - cols) * 4);
  }
  if (nrows < rows) memset(dst + (size_t)nrows * stridepx * 4, 0, (size_t)(rows - nrows) * stridepx * 4);
}

// ---------------------------------------------------------------- info strings
Str Session::desktopSizeStr() { Lock l(fbMutex); return strf("%d x %d", fbW, fbH); }

static int bitsOf(u32 max) { int b = 0; while (max) { b++; max >>= 1; } return b; }
Str Session::pixelFormatDesc(const PixelFormat& pf) {
  char b[160]; int n = snprintf(b, sizeof b, "depth %d (%d bpp)", pf.depth, pf.bpp);
  if (pf.bpp != 8) n += snprintf(b + n, sizeof b - n, " %s-endian", pf.bigEndian ? "big" : "little");
  if (!pf.trueColour) { snprintf(b + n, sizeof b - n, " colour-map"); return Str(b); }
  int rb = bitsOf(pf.rMax), gb = bitsOf(pf.gMax), bb = bitsOf(pf.bMax);
  bool p2 = (pf.rMax & (pf.rMax + 1)) == 0 && (pf.gMax & (pf.gMax + 1)) == 0 && (pf.bMax & (pf.bMax + 1)) == 0;
  if (p2 && pf.bShift == 0 && pf.gShift == bb && pf.rShift == bb + gb) snprintf(b + n, sizeof b - n, " rgb%d%d%d", rb, gb, bb);
  else if (p2 && pf.rShift == 0 && pf.gShift == rb && pf.bShift == rb + gb) snprintf(b + n, sizeof b - n, " bgr%d%d%d", bb, gb, rb);
  else snprintf(b + n, sizeof b - n, " rgb max %d,%d,%d shift %d,%d,%d", pf.rMax, pf.gMax, pf.bMax, pf.rShift, pf.gShift, pf.bShift);
  return Str(b);
}

// ---------------------------------------------------------------- create / destroy
Session* sessionCreate(JNIEnv* env, jobject desktopCb, jobject sessionCb, const char* address, const char* uuid,
                       const Vec<KV>& opts, jobject* sessionObjOut) {
  Session* s = new Session;
  s->address = address; s->uuid = uuid; s->opts = opts;
  s->desktopCb = env->NewGlobalRef(desktopCb); s->sessionCb = env->NewGlobalRef(sessionCb);
  jclass dc = env->GetObjectClass(desktopCb), sc = env->GetObjectClass(sessionCb);
  s->mConnSuccess = env->GetMethodID(dc, "connSuccess", "()V");
  s->mBell = env->GetMethodID(dc, "bell", "()V");
  s->mGetClip = env->GetMethodID(dc, "getClipboard", "()Ljava/lang/String;");
  s->mSetClip = env->GetMethodID(dc, "setClipboard", "(Ljava/lang/String;)V");
  s->mSetCursor = env->GetMethodID(dc, "setCursor", "(Ljava/lang/Object;II)V");
  s->mSetDesktopSize = env->GetMethodID(dc, "setDesktopSize", "(II)V");
  s->mDrawRegion = env->GetMethodID(dc, "drawRegion", "(IIII)V");
  s->mFbUpdateEnd = env->GetMethodID(dc, "framebufferUpdateEnd", "()V");
  s->mSessionClosed = env->GetMethodID(sc, "sessionClosed", "(Lcom/realvnc/vncviewer/jni/SessionBindings$Session;)V");
  if (env->ExceptionCheck()) { env->ExceptionClear(); logf(LOG_WARN, "some callback methods not found"); }
  env->DeleteLocalRef(dc); env->DeleteLocalRef(sc);
  { Lock l(reg().m); s->id = reg().next++; reg().sessions.push(s); }
  jobject local = env->NewObject(G.sessionCls, G.sessionInit, (jlong)s->id);
  if (!local || env->ExceptionCheck()) { sessionDestroy(env, s); return nullptr; }
  s->sessionObj = env->NewGlobalRef(local);
  *sessionObjOut = local;
  if (!s->start()) { sessionDestroy(env, s); *sessionObjOut = nullptr; return nullptr; }
  return s;
}

void sessionDestroy(JNIEnv* env, Session* s) {
  { Lock l(reg().m); for (size_t i = 0; i < reg().sessions.n; i++) if (reg().sessions[i] == s) { reg().sessions.erase(i); break; } }
  s->requestClose();
  if (s->threadStarted && pthread_equal(pthread_self(), s->th)) {
    // Called from the session's own callback: it cannot join itself. Leak-free deferral is not worth the
    // complexity; detach the thread and let the OS reclaim it, freeing everything after the callback returns.
    pthread_detach(s->th); s->threadStarted = false;
    return;   // Session memory is reclaimed at process exit in this (rare) path.
  }
  s->join();
  if (env) {
    if (s->desktopCb) env->DeleteGlobalRef(s->desktopCb);
    if (s->sessionCb) env->DeleteGlobalRef(s->sessionCb);
    if (s->sessionObj) env->DeleteGlobalRef(s->sessionObj);
  }
  delete s;
}

}  // namespace vr
