/* Minimal Mbed TLS 3.6.2 configuration: RSA PKCS#1 v1.5 + v2.1 (OAEP/PSS), AES (ECB/GCM), SHA-1/256/512, ECDH on Curve25519/Curve448.
 * RA2 uses the first group; RA4 (see docs/RA4_RECOVERY.md) additionally uses OAEP, GCM, SHA-512 and X25519/X448. */
#ifndef VNC_MBEDTLS_CONFIG_H
#define VNC_MBEDTLS_CONFIG_H
#define MBEDTLS_PLATFORM_C
#define MBEDTLS_BIGNUM_C
#define MBEDTLS_GENPRIME
#define MBEDTLS_RSA_C
#define MBEDTLS_PKCS1_V15
#define MBEDTLS_PKCS1_V21
#define MBEDTLS_AES_C
#define MBEDTLS_SHA1_C
#define MBEDTLS_SHA256_C
#define MBEDTLS_SHA512_C
#define MBEDTLS_GCM_C
#define MBEDTLS_CIPHER_C
#define MBEDTLS_CIPHER_MODE_CTR
#define MBEDTLS_ECP_C
#define MBEDTLS_ECDH_C
#define MBEDTLS_ECP_DP_CURVE25519_ENABLED
#define MBEDTLS_ECP_DP_CURVE448_ENABLED
#define MBEDTLS_MD_C
#define MBEDTLS_OID_C
#define MBEDTLS_ASN1_PARSE_C
#define MBEDTLS_ASN1_WRITE_C
#define MBEDTLS_CIPHER_MODE_CBC
#define MBEDTLS_NO_UDBL_DIVISION   /* avoid __udivti3 (compiler-rt), which bionic does not export */
#endif
