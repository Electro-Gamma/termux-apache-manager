/* Minimal Mbed TLS 3.6.2 configuration: RSA-PKCS#1 v1.5, AES-ECB, SHA-1, SHA-256 only (used for RFB RSA-AES / RA2). */
#ifndef VNC_MBEDTLS_CONFIG_H
#define VNC_MBEDTLS_CONFIG_H
#define MBEDTLS_PLATFORM_C
#define MBEDTLS_BIGNUM_C
#define MBEDTLS_GENPRIME
#define MBEDTLS_RSA_C
#define MBEDTLS_PKCS1_V15
#define MBEDTLS_AES_C
#define MBEDTLS_SHA1_C
#define MBEDTLS_SHA256_C
#define MBEDTLS_MD_C
#define MBEDTLS_OID_C
#define MBEDTLS_ASN1_PARSE_C
#define MBEDTLS_ASN1_WRITE_C
#define MBEDTLS_CIPHER_MODE_CBC
#define MBEDTLS_NO_UDBL_DIVISION   /* avoid __udivti3 (compiler-rt), which bionic does not export */
#endif
