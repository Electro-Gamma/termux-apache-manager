# Performance changes in this version of the `libvncviewer.so` replacement

Scope: what was changed to make the C++ library faster, how it was measured, and what is not known. Sources: `vncreplace/src/session.cpp`, `session.h`; benchmark in `vncreplace/tests/bench/`.

## 1. Honest summary
- Measured on a **desktop x86-64 build** of the same sources, against a Python test server, with 1920x1080 frames. Not measured on a phone. Not compared with the original library (neither could be run on a device here).
- So this README shows that the replacement got faster than its own previous version. It does not show that it matches the original's speed.

## 2. Results (before -> after, same machine, same benchmark)
| Measure | Before | After |
|---|---|---|
| Full-frame copy to the app bitmap (`getScaledPixels/getScaledBitmap`, scale 1.0) | 5.7-6.9 ms | about 0.9 ms |
| Same copy at scale 0.5 | 1.9-3.4 ms | about 0.8 ms |
| Client CPU per ZRLE frame | 8.3 ms | 6.8 ms |
| Client CPU per Raw frame | 3.8 ms | 2.8 ms |

Frames-per-second numbers from the benchmark are limited by the Python server and vary between runs, so use the CPU-per-frame and copy times above.

## 3. What was changed
1. **Frame copy (`Session::scaledCopy`) - the biggest cost.** The app calls it on every redraw. It used to zero the whole destination, then copy pixel by pixel with four byte stores each. Now:
   - each output row is written once (copy, then zero only the unused tail; rows past the region are zeroed once);
   - 32-bit loads/stores with the alpha byte forced to 0xFF, which the compiler vectorises (NEON instructions are present in the arm64 build);
   - same output as before (tests compare the bytes).
2. **No per-tile allocation.** Hextile used heap buffers per tile; it now uses stack buffers (max 1024 bytes for a raw tile, 1530 for subrects). ZRLE and Raw use two reusable scratch buffers kept in the session (`scrA`, `scrB`), so memory is allocated once and reused.
3. **Faster fills.** Solid fills (`fillRect`) write 32-bit words instead of a 4-byte `memcpy` per pixel.
4. **ZRLE run-length tiles.** Runs are filled row by row with row/column counters instead of a division and modulo per pixel.
5. **Raw rectangles.** Chunks are about 256 KB instead of 16 rows, and a full-width rectangle is a single `memcpy`.
6. **Byte reads.** `rd8()` reads straight from the receive buffer when data is already there.

What was not changed: protocol behaviour, exports (still the same 130), dependencies, the security code.

## 4. What is left
- ZRLE time is now mostly zlib inflate (the system zlib on Android).
- The app (`VncView.kt`) redraws the whole frame on each update. Redrawing only the changed region would be faster, but would need the replacement's JNI behaviour to differ from the original's, so it was not done.
- Network and server settings (colour depth, compression) matter more than the decoder for slow links.

## 5. How to reproduce
```bash
cd vncreplace
HOST_OPT="-O2" ./build_host.sh          # host build with optimisation (default is -O1 -g)
FRAMES=40 tests/bench/run_bench.sh zrle raw    # hextile also works but its test server takes ~1 minute to prepare
tests/host/run_tests.sh                 # functional tests: 27 passed after the changes (takes about 75 s; run it in the background)
./build.sh                              # arm64 library; also runs the import check
```
The benchmark prints client CPU per frame and the time for a full-frame copy at scale 1.0 and 0.5. To compare with the earlier version, build the older sources in another folder and run the same script there.

## 6. Verification status
- Functional tests: 27 of 27 passed (none/VNC/RSA-AES logins, Raw/Hextile/RRE/ZRLE, error paths, export check).
- arm64 build: imports checked, exports unchanged; never executed on a device.
- Measured on a phone: no.

---

# Additional changes made when integrating into Remote Hub

Scope: `vnc/session.cpp`, `vnc/session.h` (JNI surface, exports, CMake and the Java bindings are unchanged).
Everything below was checked by `tests/host/run.sh`, which links the real `session.cpp` (JNI replaced by stubs)
and drives it over a socketpair with a fake RFB server. It compares the framebuffer pixel by pixel after Raw,
ZRLE (every tile kind: raw, solid, packed palette 2/4/16 colours, plain RLE, palette RLE, partial edge tiles) and
CopyRect (down-right, up-left and sideways overlap), and checks the update-request behaviour.

1. **Pipelined update requests.** The next `FramebufferUpdateRequest` is sent as soon as an update's header has
   been read, not after it has been decoded, so the server's encoding time and the network round trip overlap with
   our decoding. Still exactly one request per update (the test asserts this), so requests never pile up; after a
   desktop resize the request is repeated with the new size. Option `Pipeline` (default `1`; `0` restores the old
   timing). Effect: per-frame time on a slow link goes from decode + round trip to roughly max(decode, round trip).
   *Verified:* with it on, 6 of 6 requests arrive before their update finishes; off, 0 of 6. *Not measured:* the
   latency gain itself (the test has no network delay), and no real VNC server has been tried.
2. **CopyRect without a temporary buffer.** Row-by-row `memmove` in the direction that never overwrites a source
   row before it is read (previously: allocate, copy out, copy back). Window drags and scrolling use this.
3. **Large socket reads go straight to the destination** instead of through the 32 KB input buffer and a second
   copy. Helps Raw and big ZRLE payloads.
4. **ZRLE pixel stores**: raw, palette and run tiles write whole 32-bit pixels (palettes are kept as `u32`).

Host measurements (x86-64, thread CPU time, 1920x1080, same machine, previous vs now; `tests/host/bench.sh`):

| Workload | Before | After |
|---|---|---|
| 300 full-frame CopyRects | 366-406 ms | 96-100 ms (about 3.9x less) |
| 30 full-frame Raw updates | 34-40 ms | 30-32 ms (about 15% less) |
| 30 full-frame ZRLE updates (screen-like tile mix) | 146-164 ms | 143-180 ms (no measurable change; zlib inflate dominates) |

These are desktop numbers, not phone numbers, and the pixel output is identical to the previous version.
The tile code in ZRLE is a small part of its cost; the remaining time is zlib.

---

# Engine upgrade with RA2r / ARD / RA4 (current sources)

The sources are the upgraded engine package (adds RA2 fixes, RA2r, Apple ARD, the RA4 cipher-suite layer, a larger Mbed TLS
set, `-O3`, no NEON requirement on armeabi-v7a). That package was developed from an older base and **does not contain any of
the optimisations described above** (its CopyRect still allocates and copies twice, no scratch buffers, no pipelining), so on its
own it is *slower* than the previous version. The optimisations were therefore merged onto it (a three-way merge: original
sources as base, the upgrade's authentication changes, and the optimised session). Everything else in `vnc/`, `mbedtls/` and
`CMakeLists.txt` is the upgrade's, unchanged. One bug fix on top: `Session::rd8()` read the wrong buffer in RA4 mode.

Host comparison (x86-64, 1920x1080, thread CPU time unless noted; min of 5 runs; `tests/host/bench.sh`, `tests/host/run.sh`):

| Workload | Upgrade as supplied (-O3) | Previous version (-O2) | Now (-O3) |
|---|---|---|---|
| 300 full-frame CopyRects | 379 ms | 106 ms | 104 ms |
| 30 full-frame ZRLE, screen-like tiles | 144 ms | 116 ms | 114 ms |
| 30 full-frame Raw | 32 ms | 25 ms | 25 ms |
| Full-screen ZRLE frames, 30 ms simulated round trip | 36.4 ms/frame | 30.9 ms/frame | 30.6 ms/frame |
| Same, 60 ms round trip | 68.2 ms/frame | 61.7 ms/frame | 61.0 ms/frame |

So the current engine has every feature of the upgrade and the speed of the previous optimised version; it is not faster than the
previous version (`-O3` instead of `-O2` made no measurable difference here). Against the upgrade as supplied it needs about 6 ms less per frame
at a 30 ms round trip (about 16 % more frames per second), from the pipelined requests and the faster decoders.
These are desktop numbers and a simulated network, not a phone.

Checks run: decoder/pipeline test (`tests/host/run.sh`) passes, also under AddressSanitizer + UBSan; the upgrade's own RA2 and RA4
known-answer and mock-server tests (`native-engine/native-tests`) pass when built from these sources at `-O3` (the JVM-based
session tests need a JDK and were not run). Not checked: an NDK build of either ABI, a 32-bit compile, any device, a real RealVNC server.
