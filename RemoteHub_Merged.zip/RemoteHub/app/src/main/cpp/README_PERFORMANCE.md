# Performance changes in this version of the `libvncviewer.so` replacement

Scope: what was changed to make the C++ library faster, how it was measured, and what is not known. Sources: `vncreplace/src/session.cpp`, `session.h`; benchmark in `vncreplace/tests/bench/`.

## 1. Honest summary
- Measured on a **desktop x86-64 build** of the same sources, against a Python test server, with 1920x1080 frames. Not measured on a phone. Not compared with the original library (neither could be run on a device here).
- So this README shows that the replacement got faster than its own previous version. It does not show that it matches the original's speed.

## 2. Results (before -> after, same machine, same benchmark)
| Measure | Before | After |
|---|---|---|
| Full-frame copy to the app bitmap (`getScaledPixels/getScaledBitmap`, scale 1.0) | 5.7-6.9 ms | about 0.9 ms |
| Same copy at scale 0.5 | 1.9-3.4 ms | about 0.8 ms |
| Client CPU per ZRLE frame | 8.3 ms | 6.8 ms |
| Client CPU per Raw frame | 3.8 ms | 2.8 ms |

Frames-per-second numbers from the benchmark are limited by the Python server and vary between runs, so use the CPU-per-frame and copy times above.

## 3. What was changed
1. **Frame copy (`Session::scaledCopy`) - the biggest cost.** The app calls it on every redraw. It used to zero the whole destination, then copy pixel by pixel with four byte stores each. Now:
   - each output row is written once (copy, then zero only the unused tail; rows past the region are zeroed once);
   - 32-bit loads/stores with the alpha byte forced to 0xFF, which the compiler vectorises (NEON instructions are present in the arm64 build);
   - same output as before (tests compare the bytes).
2. **No per-tile allocation.** Hextile used heap buffers per tile; it now uses stack buffers (max 1024 bytes for a raw tile, 1530 for subrects). ZRLE and Raw use two reusable scratch buffers kept in the session (`scrA`, `scrB`), so memory is allocated once and reused.
3. **Faster fills.** Solid fills (`fillRect`) write 32-bit words instead of a 4-byte `memcpy` per pixel.
4. **ZRLE run-length tiles.** Runs are filled row by row with row/column counters instead of a division and modulo per pixel.
5. **Raw rectangles.** Chunks are about 256 KB instead of 16 rows, and a full-width rectangle is a single `memcpy`.
6. **Byte reads.** `rd8()` reads straight from the receive buffer when data is already there.

What was not changed: protocol behaviour, exports (still the same 130), dependencies, the security code.

## 4. What is left
- ZRLE time is now mostly zlib inflate (the system zlib on Android).
- The app (`VncView.kt`) redraws the whole frame on each update. Redrawing only the changed region would be faster, but would need the replacement's JNI behaviour to differ from the original's, so it was not done.
- Network and server settings (colour depth, compression) matter more than the decoder for slow links.

## 5. How to reproduce
```bash
cd vncreplace
HOST_OPT="-O2" ./build_host.sh          # host build with optimisation (default is -O1 -g)
FRAMES=40 tests/bench/run_bench.sh zrle raw    # hextile also works but its test server takes ~1 minute to prepare
tests/host/run_tests.sh                 # functional tests: 27 passed after the changes (takes about 75 s; run it in the background)
./build.sh                              # arm64 library; also runs the import check
```
The benchmark prints client CPU per frame and the time for a full-frame copy at scale 1.0 and 0.5. To compare with the earlier version, build the older sources in another folder and run the same script there.

## 6. Verification status
- Functional tests: 27 of 27 passed (none/VNC/RSA-AES logins, Raw/Hextile/RRE/ZRLE, error paths, export check).
- arm64 build: imports checked, exports unchanged; never executed on a device.
- Measured on a phone: no.

---

# Additional changes made when integrating into Remote Hub

Scope: `vnc/session.cpp`, `vnc/session.h` (JNI surface, exports, CMake and the Java bindings are unchanged).
Everything below was checked by `tests/host/run.sh`, which links the real `session.cpp` (JNI replaced by stubs)
and drives it over a socketpair with a fake RFB server. It compares the framebuffer pixel by pixel after Raw,
ZRLE (every tile kind: raw, solid, packed palette 2/4/16 colours, plain RLE, palette RLE, partial edge tiles) and
CopyRect (down-right, up-left and sideways overlap), and checks the update-request behaviour.

1. **Pipelined update requests.** The next `FramebufferUpdateRequest` is sent as soon as an update's header has
   been read, not after it has been decoded, so the server's encoding time and the network round trip overlap with
   our decoding. Still exactly one request per update (the test asserts this), so requests never pile up; after a
   desktop resize the request is repeated with the new size. Option `Pipeline` (default `1`; `0` restores the old
   timing). Effect: per-frame time on a slow link goes from decode + round trip to roughly max(decode, round trip).
   *Verified:* with it on, 6 of 6 requests arrive before their update finishes; off, 0 of 6. *Not measured:* the
   latency gain itself (the test has no network delay), and no real VNC server has been tried.
2. **CopyRect without a temporary buffer.** Row-by-row `memmove` in the direction that never overwrites a source
   row before it is read (previously: allocate, copy out, copy back). Window drags and scrolling use this.
3. **Large socket reads go straight to the destination** instead of through the 32 KB input buffer and a second
   copy. Helps Raw and big ZRLE payloads.
4. **ZRLE pixel stores**: raw, palette and run tiles write whole 32-bit pixels (palettes are kept as `u32`).

Host measurements (x86-64, thread CPU time, 1920x1080, same machine, previous vs now; `tests/host/bench.sh`):

| Workload | Before | After |
|---|---|---|
| 300 full-frame CopyRects | 366-406 ms | 96-100 ms (about 3.9x less) |
| 30 full-frame Raw updates | 34-40 ms | 30-32 ms (about 15% less) |
| 30 full-frame ZRLE updates (screen-like tile mix) | 146-164 ms | 143-180 ms (no measurable change; zlib inflate dominates) |

These are desktop numbers, not phone numbers, and the pixel output is identical to the previous version.
The tile code in ZRLE is a small part of its cost; the remaining time is zlib.

---

# Current sources: fixed upgrade + Remote Hub changes

**Base:** the engine package with RA2 fixes, RA2r, Apple ARD, the RA4 layer, `-O3`, and its RealVNC-2022 regression fix (RA4 is opt-in via
option `Ra4=1`; security-type order 6,130,5,129 first, then ARD, VNC password, None, two-step 13/133 last). That package does not contain the
optimisations described above, so they are merged onto it (three-way merge; everything outside `session.cpp`/`session.h` is the package's,
unchanged, apart from the additions below).

**Changes on top of the package** (all in `app/src/main/cpp/vnc/` unless noted):
1. Decoder / request optimisations of the sections above (frame copy, scratch buffers, ZRLE pixel stores, CopyRect in place, direct large reads,
   pipelined update requests; `Pipeline=0` turns the last one off).
2. `Session::rd8()` read the wrong buffer in RA4 mode (one-line fix).
3. Security-type order with `PreferEncrypted=1` (which Remote Hub sets): 129, 5, 130, 6 first, as before the two-step types existed; the package
   ranks 133/13 first there, but they are the least verified against real servers. Also a clearer "server offered: ..." error.
4. **New JNI function `copyRegionToBitmap(session, bitmap, x, y, w, h)`** (`Session::copyRegion`, `jni_session.cpp`, `exports.map`, `SessionBindings.java`):
   copies one framebuffer rectangle straight into the app's desktop-sized `Bitmap` (one pixel lock, alpha forced opaque, nothing else written,
   clamped to both images). Remote Hub's backend now uses it for every update instead of the old route (native copy of each dirty 256x256 tile
   into a scratch buffer with zero-fill, Java `copyPixelsFromBuffer`, canvas blit into the bitmap), and merges updates arriving less than 8 ms apart.
   This is the 131st export; the original library has 130.

**Measured on the host** (x86-64, thread CPU time; not a phone):

| Stage | Before | After |
|---|---|---|
| Getting a 64x64 change into the bitmap | 0.011 ms | 0.002 ms (6x) |
| ... a 400x300 change | 0.11-0.15 ms | 0.034 ms (3.5-4.5x) |
| ... a full 1920x1080 frame | 2.9-3.1 ms | 0.92-0.95 ms (3.2x) |

The "before" figures model the Java copy and canvas blit as the memcpy work they do; their real cost on a phone is not included, so the real gain is
probably larger, but that is not measured. Decoder and simulated-network benchmarks did not change in this round
(CopyRect 300 frames 83 ms, ZRLE 30 frames 113 ms, Raw 30 frames 26 ms, 30.5 ms/frame at a 30 ms round trip; the upload as supplied: 377, 152, 26,
35.4), because the decoders are near memory-bandwidth limits on the host and nothing in them changed.

**Checks run:** `tests/host/run.sh` (decoders + pipeline, handshake negotiation, copyRegion), also under AddressSanitizer + UBSan;
`tests/host/run_mock_login.sh` (full RSA-AES logins, types 5/6/129/130, `RFB 005.000` and `004.001` banners, encrypted sessions, decoded frame
identical, against the independent mock server in `tests/host/`); the package's own RA2/RA4 known-answer and mock tests (`native-engine/native-tests`).
**Not checked:** an NDK build of either ABI, a 32-bit compile, any device, a real RealVNC server (incl. the 2022 one this fix is for).
