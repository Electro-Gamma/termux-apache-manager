package app.terminalssh.secure.ui

import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.SelectAll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.terminalssh.secure.R
import app.terminalssh.secure.ssh.TerminalSession
import app.terminalssh.secure.ui.theme.TextSecondary
import app.terminalssh.secure.ui.theme.Turquoise
import app.terminalssh.secure.vm.AppViewModel

/** Two small actions beside the status line: copy the whole terminal, or open it as selectable text. */
@Composable
internal fun TranscriptActions(onCopyAll: () -> Unit, onSelectText: () -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
        TranscriptAction(Icons.Outlined.ContentCopy, stringResource(R.string.terminal_copy_all), onCopyAll)
        TranscriptAction(Icons.Outlined.SelectAll, stringResource(R.string.terminal_select_text), onSelectText)
    }
}

@Composable
private fun TranscriptAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String,
    onClick: () -> Unit,
) {
    Icon(
        icon,
        contentDescription = description,
        tint = TextSecondary,
        modifier = Modifier
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 6.dp)
            .size(16.dp),
    )
}

/** Copies the entire session output, then confirms with a short toast. */
internal fun copyWholeTerminal(
    context: android.content.Context,
    viewModel: AppViewModel,
    session: TerminalSession,
) {
    val text = session.transcriptText()
    if (text.isEmpty()) {
        // After a clear there is nothing to copy. Say so: staying silent would leave the
        // previous clipboard in place, which looks like the old output was copied again.
        Toast.makeText(context, R.string.terminal_copy_nothing, Toast.LENGTH_SHORT).show()
        return
    }
    viewModel.copyTerminalText(text)
    Toast.makeText(context, R.string.terminal_copied_all, Toast.LENGTH_SHORT).show()
}

/**
 * The whole session output as selectable text. A very long transcript is shown from its
 * latest part so the dialog stays responsive; "Copy all" always copies everything.
 */
@Composable
internal fun TerminalTextDialog(
    viewModel: AppViewModel,
    session: TerminalSession,
    onDismiss: () -> Unit,
) {
    val context = LocalContext.current
    val full = remember(session) { session.transcriptText() }
    val shown = if (full.length > SHOWN_CHARS) full.takeLast(SHOWN_CHARS).substringAfter('\n') else full
    val scroll = rememberScrollState()
    LaunchedEffect(shown) { scroll.scrollTo(scroll.maxValue) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.terminal_text_title)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (shown.length < full.length) {
                    Text(
                        stringResource(R.string.terminal_text_truncated),
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary,
                    )
                }
                SelectionContainer(Modifier.heightIn(max = 420.dp).verticalScroll(scroll)) {
                    Text(
                        shown.ifEmpty { stringResource(R.string.terminal_text_empty) },
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        lineHeight = 15.sp,
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { copyWholeTerminal(context, viewModel, session) }) {
                Text(stringResource(R.string.terminal_copy_all), color = Turquoise)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.close)) }
        },
        containerColor = MaterialTheme.colorScheme.surface,
    )
}

private const val SHOWN_CHARS = 200_000
