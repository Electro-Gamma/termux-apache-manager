package app.terminalssh.secure.audio

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** What the terminal header shows. There is one audio connection for the whole app, owned by one saved server. */
data class AudioUi(
    val owner: String? = null,
    val mic: Boolean = false,
    val speaker: Boolean = false,
    val state: AudioBridge.State = AudioBridge.State.IDLE,
    val message: String = "",
    val muted: Boolean = false,
) {
    val active: Boolean
        get() = state == AudioBridge.State.CONNECTING || state == AudioBridge.State.CONNECTED ||
            state == AudioBridge.State.RECONNECTING

    fun activeFor(hostId: String): Boolean = active && owner == hostId
    fun failedFor(hostId: String): Boolean = state == AudioBridge.State.FAILED && owner == hostId
}

/** Bridges [AudioService] (which runs without any screen) to Compose state. */
object AudioController {
    private val _ui = MutableStateFlow(AudioUi())
    val ui: StateFlow<AudioUi> = _ui.asStateFlow()

    @Volatile private var owner: String? = null

    private var failureTold = false

    /** The message of a failure that has not been shown yet, so it is announced once and not on every visit. */
    @Synchronized
    fun takeFailure(): String? {
        val current = _ui.value
        if (current.state != AudioBridge.State.FAILED || failureTold) return null
        failureTold = true
        return current.message
    }

    private val observer = AudioService.Observer { publish() }

    init {
        AudioService.addObserver(observer)
    }

    @Synchronized
    private fun publish() {
        val config = AudioService.current()?.config()
        _ui.value = AudioUi(
            owner = owner,
            mic = config?.mic == true,
            speaker = config?.playback == true,
            state = AudioService.state(),
            message = AudioService.message(),
            muted = AudioService.isMuted(),
        )
    }

    /** Starts or reconfigures audio. Call only while the app is visible, with RECORD_AUDIO granted if [mic]. */
    fun start(context: Context, hostId: String, target: AudioTarget, passphrase: String, mic: Boolean, speaker: Boolean) {
        if (!mic && !speaker) {
            stop(context)
            return
        }
        val config = AudioBridge.Config().also {
            it.host = target.host
            it.port = target.port
            it.passphrase = passphrase
            it.mic = mic
            it.playback = speaker
            it.micRate = target.micRate
            it.micChannels = target.micChannels
            it.playRate = target.playRate
            it.playChannels = target.playChannels
            it.voiceProcessing = target.voiceProcessing
        }
        owner = hostId
        failureTold = false
        // Shown at once; the service reports the real state as soon as it runs.
        _ui.value = AudioUi(owner = hostId, mic = mic, speaker = speaker, state = AudioBridge.State.CONNECTING)
        try {
            AudioService.start(context.applicationContext, config)
        } catch (e: RuntimeException) {
            _ui.value = AudioUi(owner = hostId, state = AudioBridge.State.FAILED, message = "Audio: ${e.message}")
        }
    }

    fun stop(context: Context) {
        AudioService.stop(context.applicationContext)
    }

    fun setMuted(muted: Boolean) = AudioService.setMuted(muted)

    fun level(): Int = AudioService.current()?.level() ?: 0

    /** Closing the last terminal of the server that has the audio also ends the audio: no hidden live microphone. */
    fun onOpenTerminals(context: Context, hostIds: Collection<String>) {
        val current = _ui.value
        val id = current.owner ?: return
        if (current.active && id !in hostIds) stop(context)
    }
}
