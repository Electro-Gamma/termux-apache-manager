package app.terminalssh.secure.audio;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;
import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/** Client side of the VNC Audio Bridge protocol (docs/AUDIO_PROTOCOL.md). No Android dependencies, so it is testable on a JVM.
 *  One encrypted TCP connection: computer -> phone playback PCM, phone -> computer microphone PCM (signed 16-bit little-endian). */
public final class AudioLink implements Closeable {
    public static final int T_HELLO = 1, T_PLAY = 2, T_MIC = 3, T_BYE = 5, MAX_PAYLOAD = 16000, ITERATIONS = 120000;
    public static final int MODE_PLAY = 1, MODE_MIC = 2, MODE_MIC_STEREO = 4;
    public static final int CAP_STEREO_MIC = 1, CAP_BYE_REASON = 2;
    public static final int BYE_NONE = 0, BYE_REPLACED = 1, BYE_SHUTDOWN = 2;
    public static final int ST_BAD_FORMAT = 1, ST_NO_AUDIO = 2;
    public interface Listener { void onPlayback(byte[] pcm, int len); void onClosed(String reason); }

    /** The server closed the connection in answer to our hello: almost always a wrong passphrase. */
    public static final class AuthException extends IOException { AuthException(String m, Throwable c) { super(m, c); } }
    /** The server authenticated us but refused the session; {@link #status} is ST_BAD_FORMAT or ST_NO_AUDIO. */
    public static final class RefusedException extends IOException {
        public final int status;
        RefusedException(int status) {
            super(status == ST_NO_AUDIO ? "The computer could not create its audio device (run diagnose.sh there)"
                                        : "Audio bridge refused the requested audio format");
            this.status = status;
        }
    }

    private final Socket sock; private final DataInputStream in; private final OutputStream out;
    private final SecretKeySpec sendKey, recvKey; private long sendCtr, recvCtr;
    private final ReentrantLock wlock = new ReentrantLock(); private volatile boolean closed;
    private volatile long sendStartedNanos; private volatile int byeReason = BYE_NONE; private int serverCaps;
    public final int playRate, playChannels, micRate;

    private AudioLink(Socket s, SecretKeySpec sk, SecretKeySpec rk, int pr, int pc, int mr) throws IOException {
        sock = s; in = new DataInputStream(new BufferedInputStream(s.getInputStream())); out = s.getOutputStream();
        sendKey = sk; recvKey = rk; playRate = pr; playChannels = pc; micRate = mr;
    }

    // ---- crypto helpers (HMAC-SHA256 based; javax.crypto only, works from API 24) ----
    static byte[] hmac(byte[] key, byte[]... parts) throws GeneralSecurityException {
        Mac m = Mac.getInstance("HmacSHA256"); m.init(new SecretKeySpec(key, "HmacSHA256"));
        for (byte[] p : parts) m.update(p); return m.doFinal();
    }
    static byte[] pbkdf2(byte[] pass, byte[] salt, int iters) throws GeneralSecurityException {   // one 32-byte block
        Mac m = Mac.getInstance("HmacSHA256"); m.init(new SecretKeySpec(pass, "HmacSHA256"));
        m.update(salt); m.update(new byte[]{0, 0, 0, 1}); byte[] u = m.doFinal(), t = u.clone();
        for (int i = 1; i < iters; i++) { u = m.doFinal(u); for (int j = 0; j < 32; j++) t[j] ^= u[j]; }
        return t;
    }
    static byte[] hkdf(byte[] key, byte[] salt, String info) throws GeneralSecurityException, UnsupportedEncodingException {
        byte[] prk = hmac(salt, key); byte[] inf = info.getBytes("US-ASCII"); byte[] x = new byte[inf.length + 1];
        System.arraycopy(inf, 0, x, 0, inf.length); x[inf.length] = 1; return hmac(prk, x);
    }
    private static byte[] nonce(long ctr) { return ByteBuffer.allocate(12).putInt(0).putLong(ctr).array(); }

    /** 1.x signature: mono or stereo microphone is chosen by MODE_MIC_STEREO in {@code mode}. */
    public static AudioLink connect(String host, int port, String passphrase, int mode, int playRate, int playChannels, int micRate) throws IOException {
        Socket s = new Socket(); boolean ok = false, helloSent = false;
        try {
            s.setTcpNoDelay(true); s.setKeepAlive(true); s.connect(new InetSocketAddress(host, port), 8000); s.setSoTimeout(15000);
            byte[] nc = new byte[16]; new SecureRandom().nextBytes(nc);
            byte[] master = pbkdf2(passphrase.getBytes("UTF-8"), "VAB1-pbkdf2-salt".getBytes("US-ASCII"), ITERATIONS);
            OutputStream o = s.getOutputStream(); o.write("VAB1".getBytes("US-ASCII")); o.write(nc); o.flush();
            DataInputStream di = new DataInputStream(s.getInputStream());   // unbuffered: the server sends nothing else before our hello
            byte[] ns = new byte[16]; di.readFully(ns);
            byte[] salt = new byte[32]; System.arraycopy(nc, 0, salt, 0, 16); System.arraycopy(ns, 0, salt, 16, 16);
            AudioLink l = new AudioLink(s, new SecretKeySpec(hkdf(master, salt, "c2s"), "AES"), new SecretKeySpec(hkdf(master, salt, "s2c"), "AES"), playRate, playChannels, micRate);
            byte[] hello = ByteBuffer.allocate(10).put((byte) mode).putInt(playRate).put((byte) playChannels).putInt(micRate).array();
            l.sendFrame(T_HELLO, hello, 0, hello.length);
            helloSent = true;
            byte[][] r = l.readFrame();
            if (r[0][0] != T_HELLO || r[1].length < 1) throw new IOException("Unexpected reply from the audio bridge");
            if (r[1][0] != 0) throw new RefusedException(r[1][0]);
            l.serverCaps = r[1].length > 11 ? r[1][11] & 255 : 0;          // 1.x servers send no capability byte
            ok = true; return l;
        } catch (EOFException | java.net.SocketException e) {
            if (helloSent) throw new AuthException("Audio bridge closed the connection (wrong passphrase?)", e);
            throw new IOException("Cannot reach the audio bridge: " + e.getMessage(), e);
        } catch (GeneralSecurityException e) { throw new IOException("Crypto error: " + e.getMessage(), e);
        } finally { if (!ok) try { s.close(); } catch (IOException ignored) { } }
    }

    /** Capability bits announced by the server; 0 for a 1.x server. */
    public int serverCaps() { return serverCaps; }
    /** Why the server said goodbye (BYE_*). */
    public int byeReason() { return byeReason; }
    /** How long the write in progress has been blocked, in milliseconds; 0 when idle. A large value means a dead link. */
    public long sendStalledMillis() { long s = sendStartedNanos; return s == 0 ? 0 : (System.nanoTime() - s) / 1000000L; }

    private void sendFrame(int type, byte[] p, int off, int len) throws IOException {
        wlock.lock();
        try {
            byte[] pt = new byte[len + 1]; pt[0] = (byte) type; System.arraycopy(p, off, pt, 1, len);
            byte[] aad = new byte[]{(byte) ((pt.length + 16) >> 8), (byte) (pt.length + 16)};
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.ENCRYPT_MODE, sendKey, new GCMParameterSpec(128, nonce(sendCtr++)));
            c.updateAAD(aad); byte[] ct = c.doFinal(pt);
            byte[] f = new byte[2 + ct.length]; System.arraycopy(aad, 0, f, 0, 2); System.arraycopy(ct, 0, f, 2, ct.length);
            sendStartedNanos = System.nanoTime();
            try { out.write(f); out.flush(); } finally { sendStartedNanos = 0; }
        } catch (GeneralSecurityException e) { throw new IOException(e);
        } finally { wlock.unlock(); }
    }
    private byte[][] readFrame() throws IOException {
        byte[] aad = new byte[2]; in.readFully(aad); int n = ((aad[0] & 255) << 8) | (aad[1] & 255);
        if (n < 17 || n > MAX_PAYLOAD + 17) throw new IOException("bad frame"); byte[] ct = new byte[n]; in.readFully(ct);
        try {
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.DECRYPT_MODE, recvKey, new GCMParameterSpec(128, nonce(recvCtr++)));
            c.updateAAD(aad); byte[] pt = c.doFinal(ct);
            byte[] p = new byte[pt.length - 1]; System.arraycopy(pt, 1, p, 0, p.length); return new byte[][]{{pt[0]}, p};
        } catch (GeneralSecurityException e) { throw new IOException("authentication failure", e); }
    }

    /** Sends microphone PCM (any length; split into frames). Thread-safe. */
    public void sendMic(byte[] pcm, int off, int len) throws IOException {
        if (closed) throw new IOException("closed");
        while (len > 0) { int k = Math.min(len, MAX_PAYLOAD); sendFrame(T_MIC, pcm, off, k); off += k; len -= k; }
    }

    /** Starts the receive thread; playback PCM is delivered to the listener. */
    public Thread startReceiving(final Listener l) {
        Thread t = new Thread(() -> {
            String why = "closed";
            try { sock.setSoTimeout(0);
                while (!closed) {
                    byte[][] f = readFrame();
                    if (f[0][0] == T_PLAY) l.onPlayback(f[1], f[1].length);
                    else if (f[0][0] == T_BYE) { byeReason = f[1].length > 0 ? f[1][0] & 255 : BYE_NONE; break; }
                }
            } catch (IOException e) { why = closed ? "closed" : String.valueOf(e.getMessage()); }
            l.onClosed(why);
        }, "audio-link-rx");
        t.setDaemon(true); t.start(); return t;
    }

    /** Safe on any thread, the Android UI thread included: all socket work happens on a helper thread, and the socket is
     *  closed even if the goodbye cannot be delivered. */
    @Override public void close() {
        if (closed) return; closed = true;
        Thread closer = new Thread(() -> {
            Thread bye = new Thread(() -> {
                try {
                    if (wlock.tryLock(200, TimeUnit.MILLISECONDS)) {
                        try { sendFrame(T_BYE, new byte[0], 0, 0); } finally { wlock.unlock(); }
                    }
                } catch (IOException | InterruptedException ignored) { }
            }, "audio-link-bye");
            bye.setDaemon(true); bye.start();
            try { bye.join(500); } catch (InterruptedException ignored) { }
            closeSocket();
        }, "audio-link-close");
        closer.setDaemon(true); closer.start();
    }

    /** Drops the connection at once (dead link): no goodbye, unblocks readers and writers. Safe on any thread. */
    public void abort() {
        closed = true;
        Thread t = new Thread(this::closeSocket, "audio-link-abort"); t.setDaemon(true); t.start();
    }

    private void closeSocket() { try { sock.close(); } catch (IOException ignored) { } }
}
