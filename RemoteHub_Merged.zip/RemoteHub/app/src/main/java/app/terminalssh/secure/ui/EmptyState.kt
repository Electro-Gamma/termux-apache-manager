package app.terminalssh.secure.ui

import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

/** Where the icon's top edge sits, as a fraction of the tab's height. Same on every tab. */
private const val ICON_TOP_FRACTION = 0.34f

/**
 * The empty state shared by the Hosts, Terminal, Files and VNC tabs: a 56dp icon, a title and a
 * one-line hint pointing at the + button.
 *
 * The icon is anchored at a fixed height instead of centring the whole block. Centring moved the
 * icon whenever a hint wrapped to a different number of lines, so the icons did not stay on one
 * line when switching tabs.
 */
@Composable
fun TabEmptyState(icon: ImageVector, title: String, hint: String, modifier: Modifier = Modifier) {
    TabEmptyState(rememberVectorPainter(icon), title, hint, modifier)
}

@Composable
fun TabEmptyState(icon: Painter, title: String, hint: String, modifier: Modifier = Modifier) {
    BoxWithConstraints(modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = maxHeight * ICON_TOP_FRACTION)
                .fillMaxWidth()
                .padding(horizontal = 48.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Icon(
                icon,
                contentDescription = null,
                modifier = Modifier.size(56.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                title,
                style = MaterialTheme.typography.titleLarge,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 16.dp),
            )
            Text(
                hint,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 8.dp),
            )
        }
    }
}
