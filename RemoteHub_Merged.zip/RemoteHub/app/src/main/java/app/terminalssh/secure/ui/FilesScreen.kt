package app.terminalssh.secure.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.outlined.OpenInNew
import androidx.compose.material.icons.outlined.Terminal
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.TextButton
import androidx.compose.ui.text.font.FontFamily
import app.terminalssh.secure.ui.theme.Stroke
import app.terminalssh.secure.viewer.ViewerKind
import app.terminalssh.secure.viewer.viewerKindFor
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Archive
import androidx.compose.material.icons.outlined.Unarchive
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.ContentCut
import androidx.compose.material.icons.outlined.CreateNewFolder
import androidx.compose.material.icons.outlined.NoteAdd
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Deselect
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.DriveFileRenameOutline
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.SelectAll
import androidx.compose.material.icons.outlined.SortByAlpha
import androidx.compose.material.icons.outlined.Storage
import androidx.compose.material.icons.outlined.SwapVert
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import app.terminalssh.secure.sftp.ListingView
import app.terminalssh.secure.sftp.RemotePath
import app.terminalssh.secure.sftp.SortKey
import app.terminalssh.secure.ui.theme.Danger
import app.terminalssh.secure.ui.theme.Turquoise
import androidx.compose.runtime.key
import app.terminalssh.secure.ssh.FileWorkspace
import app.terminalssh.secure.ssh.SshSessionState
import app.terminalssh.secure.R
import app.terminalssh.secure.archive.ArchiveFormat
import app.terminalssh.secure.sftp.RemoteEntry
import app.terminalssh.secure.sftp.SftpController
import app.terminalssh.secure.ui.theme.TextSecondary
import app.terminalssh.secure.vm.AppViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * File Manager tab.
 *
 * Each server's File Manager owns its connection and all its state (folder, selection,
 * transfers) in the Application, so this screen is only a window onto it: leaving the tab
 * or the app and coming back reattaches to exactly what was there, running tasks
 * included. It needs no terminal, and it ends only when the user disconnects it.
 */
@Composable
fun FilesScreen(viewModel: AppViewModel, onGoToHosts: () -> Unit, active: Boolean = true) {
    val workspaces by viewModel.files.workspaces.collectAsStateWithLifecycle()
    val activeId by viewModel.files.activeId.collectAsStateWithLifecycle()
    val split by viewModel.filesSplit.layout.collectAsStateWithLifecycle()
    val workspace = workspaces.firstOrNull { it.id == activeId } ?: workspaces.firstOrNull()

    // A pane whose File Manager was closed is given another; with fewer than two left the split ends.
    LaunchedEffect(workspaces) { viewModel.filesSplit.reconcile(workspaces.map { it.id }) }

    if (workspace == null) {
        NoSession(onGoToHosts)
        return
    }

    val topWs = if (split.enabled) workspaces.firstOrNull { it.id == split.topId } else null
    val bottomWs = if (split.enabled) workspaces.firstOrNull { it.id == split.bottomId } else null
    val panes: Pair<FileWorkspace, FileWorkspace>? =
        if (topWs != null && bottomWs != null) topWs to bottomWs else null

    // Keep "the selected File Manager" in step with the focused pane, so ending the split lands on it.
    LaunchedEffect(split.focusedId, panes != null) {
        val focusedId = split.focusedId
        if (panes != null && focusedId != null && focusedId != activeId) viewModel.files.select(focusedId)
    }

    val labels = remember(workspaces) {
        val list = numberedLabels(workspaces, { it.profile.id }, { it.profile.displayName })
        workspaces.indices.associate { workspaces[it].id to list[it] }
    }

    if (panes == null) {
        // key(): switching servers swaps the screen's own state (dialogs, pending picks) too.
        key(workspace.id) {
            FileManagerContent(
                viewModel = viewModel,
                workspace = workspace,
                workspaces = workspaces,
                labels = labels,
                onGoToHosts = onGoToHosts,
                active = active,
                onSelectWorkspace = viewModel.files::select,
                splitOn = false,
                onToggleSplit = {
                    val other = workspaces.firstOrNull { it.id != workspace.id }
                    if (other != null) {
                        viewModel.filesSplit.enable(workspace.id, other.id)
                    } else {
                        // Only one File Manager exists: open a second one on the same server and split with it.
                        val created = viewModel.openFileSessionAt(
                            workspace,
                            workspace.controller.browser.value.path,
                        )
                        viewModel.currentTab = app.terminalssh.secure.ui.Tab.FILES
                        viewModel.filesSplit.enable(workspace.id, created.id)
                    }
                },
                compact = false,
                focusRing = false,
                onFocus = {},
            )
        }
    } else {
        SplitPanes(
            fraction = split.fraction,
            onFractionChange = viewModel.filesSplit::setFraction,
            modifier = Modifier.fillMaxSize(),
            top = {
                key(panes.first.id) {
                    FileManagerContent(
                        viewModel = viewModel,
                        workspace = panes.first,
                        workspaces = workspaces,
                        labels = labels,
                        onGoToHosts = onGoToHosts,
                        active = active && !split.bottomFocused,
                        onSelectWorkspace = viewModel.filesSplit::setTop,
                        splitOn = true,
                        onToggleSplit = viewModel.filesSplit::disable,
                        compact = true,
                        focusRing = true,
                        paneFocused = !split.bottomFocused,
                        onFocus = { viewModel.filesSplit.focus(false) },
                    )
                }
            },
            bottom = {
                key(panes.second.id) {
                    FileManagerContent(
                        viewModel = viewModel,
                        workspace = panes.second,
                        workspaces = workspaces,
                        labels = labels,
                        onGoToHosts = onGoToHosts,
                        active = active && split.bottomFocused,
                        onSelectWorkspace = viewModel.filesSplit::setBottom,
                        splitOn = true,
                        onToggleSplit = viewModel.filesSplit::disable,
                        compact = true,
                        focusRing = true,
                        paneFocused = split.bottomFocused,
                        onFocus = { viewModel.filesSplit.focus(true) },
                    )
                }
            },
        )
    }
}

@Composable
private fun FileManagerContent(
    viewModel: AppViewModel,
    workspace: FileWorkspace,
    workspaces: List<FileWorkspace>,
    labels: Map<String, String>,
    onGoToHosts: () -> Unit,
    /** False while another tab is showing: this screen stays alive but must not take Back or focus. */
    active: Boolean,
    onSelectWorkspace: (String) -> Unit,
    splitOn: Boolean,
    onToggleSplit: () -> Unit,
    /** True in a split: the server pill and the paddings are tighter so two panes fit. */
    compact: Boolean,
    focusRing: Boolean,
    onFocus: () -> Unit,
    paneFocused: Boolean = true,
) {
    val sftp = workspace.controller
    val connection by workspace.session.state.collectAsStateWithLifecycle()
    var askReconnectPassword by remember { mutableStateOf(false) }

    // Shared by the banner's Reconnect button and by pulling down while disconnected.
    val reconnectNow: () -> Unit = {
        if (viewModel.hasStoredSecret(workspace.profile)) {
            viewModel.reconnectFileSession(workspace)
        } else {
            askReconnectPassword = true
        }
    }

    val browser by sftp.browser.collectAsStateWithLifecycle()
    val transfers by sftp.queue.transfers.collectAsStateWithLifecycle()
    val selection by sftp.selection.collectAsStateWithLifecycle()
    val clipboard by sftp.clipboard.collectAsStateWithLifecycle()
    val batch by sftp.batch.collectAsStateWithLifecycle()
    val properties by sftp.properties.collectAsStateWithLifecycle()
    var pendingDownload by remember { mutableStateOf<RemoteEntry?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }
    var renaming by remember { mutableStateOf<RemoteEntry?>(null) }
    var showReport by remember { mutableStateOf(false) }
    var creatingFolder by remember { mutableStateOf(false) }
    var creatingFile by remember { mutableStateOf(false) }
    var compressing by remember { mutableStateOf(false) }
    val archiveState by sftp.archive.collectAsStateWithLifecycle()

    // What is on screen: hidden files and sort order are display choices, so everything
    // that acts on "all items here" works from this list, not from the raw listing.
    val viewOptions by viewModel.sftpViewOptions.collectAsStateWithLifecycle()
    val visibleEntries = remember(browser.entries, viewOptions) {
        ListingView.apply(browser.entries, viewOptions)
    }
    val hiddenCount = remember(browser.entries, viewOptions) {
        ListingView.hiddenCount(browser.entries, viewOptions)
    }
    // Pull-to-refresh spins only for the reload the user asked for, not for every folder
    // they open, so it tracks its own flag and clears when the listing finishes.
    var pullRefreshing by remember { mutableStateOf(false) }
    LaunchedEffect(browser.loading) { if (!browser.loading) pullRefreshing = false }

    val busy = batch?.isFinished == false
    val allHereSelected = selection.coversAll(visibleEntries)
    // Extract and Open archive only make sense when every ticked item is an archive file.
    val onlyArchives = selection.isActive &&
        selection.entries.all { !it.isDirectory && ArchiveFormat.isArchiveName(it.name) }

    // Back steps through the folders visited so far, and only when that history is empty
    // does it fall through to the app's own Back (which leaves the File Manager). Declared
    // before the selection handler on purpose: the later one wins, so leaving selection
    // mode still comes first. While the editor is open it has its own Back handling.
    val canGoBack by sftp.canGoBack.collectAsStateWithLifecycle()
    val editorSession by sftp.editor.collectAsStateWithLifecycle()
    BackHandler(enabled = active && canGoBack && editorSession == null && archiveState == null) { sftp.goBack() }
    BackHandler(enabled = active && selection.isActive) { sftp.clearSelection() }
    val openScope = rememberCoroutineScope()

    val saveLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream"),
    ) { uri ->
        val entry = pendingDownload
        pendingDownload = null
        if (uri != null && entry != null) {
            sftp.enqueueDownload(entry, uri)
            // Only once the file is really queued: cancelling the picker keeps the selection.
            sftp.clearSelection()
        }
    }

    // Several items, or any folder: pick one destination folder and recreate the structure in it.
    val treeLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree(),
    ) { uri ->
        if (uri != null) sftp.downloadSelectionTo(uri)
    }

    var uploadOpen by remember { mutableStateOf(false) }
    // Where "Open in Terminal" was asked for, while the choice of terminal is showing.
    var terminalDir by remember { mutableStateOf<String?>(null) }
    val uploadScan by sftp.uploadScan.collectAsStateWithLifecycle()
    val images = remember(visibleEntries) {
        visibleEntries.filter { !it.isDirectory && viewerKindFor(it.name) == ViewerKind.IMAGE }
    }

    // One pane's outline and focus: a split marks the pane the user last touched.
    val paneModifier = if (focusRing) {
        Modifier
            .fillMaxSize()
            .border(1.dp, if (paneFocused) Turquoise.copy(alpha = 0.7f) else Stroke)
            .onAnyTouch(onFocus)
    } else {
        Modifier.fillMaxSize()
    }

    /** Opens [entry] (or the folder it is in) in a File Manager of its own, leaving this one as it is. */
    fun openInNewTab(entry: RemoteEntry?) {
        openScope.launch {
            if (entry == null) {
                viewModel.openFileSessionAt(workspace, browser.path)
            } else {
                val isFolder = entry.isDirectory || (entry.isSymlink && sftp.isFolder(entry.path))
                if (isFolder) {
                    viewModel.openFileSessionAt(workspace, entry.path)
                } else {
                    viewModel.openFileSessionAt(workspace, RemotePath.parent(entry.path), entry)
                }
            }
            sftp.clearSelection()
        }
    }

    /** "Open in Terminal": a folder is the working directory itself, a file's is its folder. */
    fun openInTerminal(entry: RemoteEntry?) {
        openScope.launch {
            val directory = when {
                entry == null -> browser.path
                entry.isDirectory || (entry.isSymlink && sftp.isFolder(entry.path)) -> entry.path
                else -> RemotePath.parent(entry.path)
            }
            sftp.clearSelection()
            if (viewModel.liveTerminalsFor(workspace.profile.id).isEmpty()) {
                viewModel.openTerminalAt(workspace, directory, null)
            } else {
                terminalDir = directory
            }
        }
    }

    // A tapped file is edited in place; the editor replaces the browser until it is closed.
    val editing = editorSession
    if (editing != null) {
        Box(paneModifier) {
            if (!editing.inArchive && viewerKindFor(editing.entry.name) == ViewerKind.IMAGE) {
                // Several images of the folder: swipe between them.
                val pages = if (images.any { it.path == editing.entry.path }) images else listOf(editing.entry) + images
                ImageGalleryScreen(sftp, pages, editing.entry, active)
            } else {
                FileEditorScreen(sftp, viewModel.settings, active)
            }
        }
        return
    }

    // An open archive replaces the folder view until it is closed (the editor, above, still wins).
    archiveState?.let { opened ->
        Box(paneModifier) { ArchiveScreen(sftp, viewModel, opened, active) }
        return
    }

    // No navigation-bar padding: the tab bar under this screen already clears the system
    // bar, and padding for it twice left a black strip between the content and the tabs.
    Column(paneModifier) {
        FileManagerTopBar(
            selection = selection,
            currentPath = browser.path,
            canGoUp = browser.path != RemotePath.ROOT,
            onGoUp = sftp::navigateUp,
            onExitSelection = sftp::clearSelection,
        ) { closeMenu ->
            if (selection.isActive) {
                // Selection actions live here, not in a toolbar.
                MenuEntry(
                    Icons.Outlined.Download,
                    stringResource(R.string.sftp_action_download),
                    closeMenu,
                    enabled = !busy,
                ) {
                    val only = selection.single
                    if (only != null && !only.isDirectory) {
                        // A lone file keeps the original save-as flow exactly as it was.
                        pendingDownload = only
                        saveLauncher.launch(RemotePath.sanitizeDownloadName(only.name))
                    } else {
                        treeLauncher.launch(null)
                    }
                }
                MenuEntry(Icons.Outlined.ContentCopy, stringResource(R.string.sftp_action_copy), closeMenu) {
                    sftp.copySelection()
                }
                MenuEntry(Icons.Outlined.ContentCut, stringResource(R.string.sftp_action_cut), closeMenu) {
                    sftp.cutSelection()
                }
                // Renaming several items to one name makes no sense, so it needs a single item.
                MenuEntry(
                    Icons.Outlined.DriveFileRenameOutline,
                    stringResource(R.string.sftp_action_rename),
                    closeMenu,
                    enabled = !busy && selection.count == 1,
                ) {
                    renaming = selection.single
                }
                MenuEntry(
                    Icons.Outlined.Archive,
                    stringResource(R.string.sftp_action_compress),
                    closeMenu,
                    enabled = !busy,
                ) {
                    compressing = true
                }
                if (onlyArchives) {
                    val archive = selection.single
                    if (archive != null) {
                        MenuEntry(
                            Icons.Outlined.Unarchive,
                            stringResource(R.string.sftp_action_open_archive),
                            closeMenu,
                        ) {
                            sftp.clearSelection()
                            sftp.openArchive(archive)
                        }
                    }
                    MenuEntry(
                        Icons.Outlined.Unarchive,
                        stringResource(R.string.sftp_action_extract_here),
                        closeMenu,
                        enabled = !busy,
                    ) {
                        sftp.extractSelection(intoFolder = false)
                    }
                    MenuEntry(
                        Icons.Outlined.Unarchive,
                        stringResource(R.string.sftp_action_extract_folder),
                        closeMenu,
                        enabled = !busy,
                    ) {
                        sftp.extractSelection(intoFolder = true)
                    }
                }
                MenuEntry(
                    Icons.Outlined.Delete,
                    stringResource(R.string.sftp_action_delete),
                    closeMenu,
                    enabled = !busy,
                    tint = Danger,
                ) {
                    confirmDelete = true
                }
                MenuEntry(Icons.Outlined.Info, stringResource(R.string.sftp_action_properties), closeMenu) {
                    sftp.showProperties()
                }
                // These two act on one item: a folder itself, or a file's folder.
                MenuEntry(
                    Icons.Outlined.OpenInNew,
                    stringResource(R.string.sftp_action_open_new_tab),
                    closeMenu,
                    enabled = selection.count == 1,
                ) {
                    openInNewTab(selection.single)
                }
                MenuEntry(
                    Icons.Outlined.Terminal,
                    stringResource(R.string.sftp_action_open_terminal),
                    closeMenu,
                    enabled = selection.count == 1,
                ) {
                    openInTerminal(selection.single)
                }
                HorizontalDivider()
                MenuEntry(
                    if (allHereSelected) Icons.Outlined.Deselect else Icons.Outlined.SelectAll,
                    stringResource(if (allHereSelected) R.string.sftp_deselect_all else R.string.sftp_select_all),
                    closeMenu,
                ) {
                    // "Deselect all" empties the whole selection, other folders included.
                    if (allHereSelected) sftp.clearSelection() else sftp.selectAll(visibleEntries)
                }
            } else {
                MenuEntry(Icons.Outlined.Refresh, stringResource(R.string.sftp_refresh), closeMenu) {
                    sftp.refresh()
                }
                MenuEntry(
                    if (viewOptions.showHidden) Icons.Outlined.VisibilityOff else Icons.Outlined.Visibility,
                    stringResource(
                        if (viewOptions.showHidden) R.string.sftp_menu_hide_hidden else R.string.sftp_menu_show_hidden,
                    ),
                    closeMenu,
                ) {
                    viewModel.updateSftpViewOptions { it.copy(showHidden = !it.showHidden) }
                }
                MenuEntry(
                    Icons.Outlined.CreateNewFolder,
                    stringResource(R.string.sftp_menu_new_folder),
                    closeMenu,
                    enabled = !busy,
                ) {
                    creatingFolder = true
                }
                MenuEntry(
                    Icons.Outlined.NoteAdd,
                    stringResource(R.string.sftp_menu_new_file),
                    closeMenu,
                    enabled = !busy,
                ) {
                    creatingFile = true
                }
                MenuEntry(
                    Icons.Outlined.SelectAll,
                    stringResource(R.string.sftp_select_all),
                    closeMenu,
                    enabled = visibleEntries.isNotEmpty(),
                ) {
                    sftp.selectAll(visibleEntries)
                }
                MenuEntry(Icons.Outlined.OpenInNew, stringResource(R.string.sftp_action_open_new_tab), closeMenu) {
                    openInNewTab(null)
                }
                MenuEntry(Icons.Outlined.Terminal, stringResource(R.string.sftp_action_open_terminal), closeMenu) {
                    openInTerminal(null)
                }
                HorizontalDivider()
                MenuEntry(
                    Icons.Outlined.SortByAlpha,
                    stringResource(R.string.sftp_menu_sort_name),
                    closeMenu,
                    checked = viewOptions.sortKey == SortKey.NAME,
                ) {
                    viewModel.updateSftpViewOptions { it.copy(sortKey = SortKey.NAME) }
                }
                MenuEntry(
                    Icons.Outlined.Storage,
                    stringResource(R.string.sftp_menu_sort_size),
                    closeMenu,
                    checked = viewOptions.sortKey == SortKey.SIZE,
                ) {
                    viewModel.updateSftpViewOptions { it.copy(sortKey = SortKey.SIZE) }
                }
                MenuEntry(
                    Icons.Outlined.Schedule,
                    stringResource(R.string.sftp_menu_sort_date),
                    closeMenu,
                    checked = viewOptions.sortKey == SortKey.MODIFIED,
                ) {
                    viewModel.updateSftpViewOptions { it.copy(sortKey = SortKey.MODIFIED) }
                }
                MenuEntry(
                    Icons.Outlined.SwapVert,
                    stringResource(R.string.sftp_menu_sort_reverse),
                    closeMenu,
                    checked = viewOptions.descending,
                ) {
                    viewModel.updateSftpViewOptions { it.copy(descending = !it.descending) }
                }
            }
        }
        FileServerChip(
            active = workspace,
            all = workspaces,
            labels = labels,
            onSelect = onSelectWorkspace,
            onDisconnect = viewModel::closeFileSession,
            compact = compact,
            splitOn = splitOn,
            onToggleSplit = onToggleSplit,
        )
        FileConnectionBanner(
            state = connection,
            onReconnect = reconnectNow,
        )
        batch?.let { current ->
            BatchCard(
                state = current,
                onCancel = sftp::cancelBatch,
                onDismiss = sftp::dismissBatch,
                onDetails = { showReport = true },
            )
        }
        uploadScan?.let { name ->
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)) {
                LinearProgressIndicator(Modifier.fillMaxWidth().height(2.dp), color = Turquoise, trackColor = Stroke)
                Text(
                    stringResource(R.string.upload_reading_folder, name),
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary,
                    maxLines = 1,
                )
            }
        }
        TransferStrip(
            transfers = transfers,
            onPause = sftp::pause,
            onResume = sftp::resume,
            onCancel = sftp::cancel,
            onClearFinished = sftp::clearFinished,
        )
        Box(Modifier.weight(1f)) {
            AppPullToRefresh(
                isRefreshing = pullRefreshing && browser.loading,
                onRefresh = {
                    when {
                        connection is SshSessionState.Connected -> {
                            pullRefreshing = true
                            sftp.refresh()
                        }
                        // Already reconnecting; the listing refreshes by itself when it is back.
                        connection.isBusy -> Unit
                        // Dropped: pulling down is the natural "try again".
                        else -> reconnectNow()
                    }
                },
                modifier = Modifier.fillMaxSize(),
            ) {
            SftpBrowser(
                state = browser.copy(entries = visibleEntries),
                onNavigate = sftp::navigate,
                onOpenFile = { entry ->
                    // An archive opens as a folder of its contents; any other file in the editor.
                    val openIt = {
                        if (ArchiveFormat.isArchiveName(entry.name)) sftp.openArchive(entry) else sftp.openEditor(entry)
                    }
                    if (entry.isSymlink) {
                        // A link may point at a folder; open it as one, otherwise open the file.
                        openScope.launch {
                            if (sftp.isFolder(entry.path)) sftp.navigate(entry.path) else openIt()
                        }
                    } else {
                        openIt()
                    }
                },
                selection = selection,
                onToggleSelect = sftp::toggleSelection,
                hiddenCount = hiddenCount,
                savedScroll = sftp::savedScroll,
                onScrollChanged = sftp::saveScroll,
                modifier = Modifier.fillMaxSize(),
            )
            }
            // Upload is the one primary action of this screen, so it is the floating button.
            if (!selection.isActive) {
                FloatingActionButton(
                    onClick = { uploadOpen = true },
                    containerColor = Turquoise,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
                ) {
                    Icon(Icons.Outlined.Add, stringResource(R.string.sftp_upload))
                }
            }
        }
        clipboard?.let { clip ->
            PasteBar(
                clipboard = clip,
                busy = busy,
                onPaste = { sftp.pasteHere() },
                onClear = sftp::clearClipboard,
                fromHost = if (clip.archive != null || sftp.isOwnClipboard(clip)) null else clip.sourceName,
                fromArchive = clip.archive?.name,
            )
        }
    }

    if (confirmDelete && selection.isActive) {
        DeleteConfirmDialog(
            selection = selection,
            onConfirm = {
                confirmDelete = false
                sftp.deleteSelection()
            },
            onDismiss = { confirmDelete = false },
        )
    }

    if (compressing && selection.isActive) {
        CompressDialog(
            defaultName = defaultArchiveName(selection.entries, browser.path),
            onConfirm = { name, format, level ->
                compressing = false
                sftp.compressSelection(name, format, level)
            },
            onDismiss = { compressing = false },
        )
    }

    if (creatingFolder) {
        NewFolderDialog(
            onConfirm = { name ->
                creatingFolder = false
                sftp.createFolder(name)
            },
            onDismiss = { creatingFolder = false },
        )
    }

    if (creatingFile) {
        NewFileDialog(
            onConfirm = { name ->
                creatingFile = false
                sftp.createFile(name)
            },
            onDismiss = { creatingFile = false },
        )
    }

    renaming?.let { target ->
        RenameDialog(
            entry = target,
            onConfirm = { newName ->
                renaming = null
                sftp.renameSelected(newName)
            },
            onDismiss = { renaming = null },
        )
    }

    properties?.let { state ->
        PropertiesDialog(state = state, onDismiss = sftp::dismissProperties)
    }

    if (uploadOpen) {
        UploadSheet(
            destination = browser.path,
            displayNameFor = viewModel::displayNameFor,
            onDismiss = { uploadOpen = false },
            onUpload = { items -> sftp.enqueueUploadBatch(items, browser.path) },
            onNewFolder = { creatingFolder = true },
            onNewFile = { creatingFile = true },
        )
    }

    terminalDir?.let { directory ->
        OpenInTerminalDialog(viewModel, workspace, directory) { terminalDir = null }
    }

    FileHostKeyDialogs(viewModel, workspace.session)

    if (askReconnectPassword) {
        PasswordPrompt(
            profile = workspace.profile,
            onDismiss = { askReconnectPassword = false },
            onSubmit = { password ->
                askReconnectPassword = false
                viewModel.reconnectFileSession(workspace, password)
            },
        )
    }

    // A report belongs to one operation: a new or dismissed batch closes it.
    LaunchedEffect(batch?.id) { showReport = false }
    val finished = batch
    if (showReport && finished != null && finished.failureCount > 0) {
        BatchReportDialog(state = finished, onDismiss = { showReport = false })
    }
}

@Composable
private fun NoSession(onGoToHosts: () -> Unit) {
    Box(Modifier.fillMaxSize()) {
      TabEmptyState(
          icon = Icons.Outlined.Folder,
          title = stringResource(R.string.files_empty_title),
          hint = stringResource(R.string.files_empty_hint),
      )
      // Same "+" button as the VNC tab; it still just takes you to the Hosts tab.
      androidx.compose.material3.FloatingActionButton(
            onClick = onGoToHosts,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 16.dp, bottom = 16.dp),
        ) {
            Icon(
                androidx.compose.ui.res.painterResource(R.drawable.hm_ic_add),
                contentDescription = stringResource(R.string.tab_hosts),
            )
        }
    }
}

/**
 * The name offered for a new archive: the item's own name without its extension for a single
 * item, otherwise the folder being viewed (or "archive" at the top).
 */
private fun defaultArchiveName(items: List<RemoteEntry>, currentPath: String): String {
    val single = items.singleOrNull()
    if (single != null) {
        val dot = single.name.lastIndexOf('.')
        return if (!single.isDirectory && dot > 0) single.name.substring(0, dot) else single.name
    }
    val folder = RemotePath.name(currentPath)
    return if (folder == RemotePath.ROOT) "archive" else folder
}

/**
 * Where "Open in Terminal" goes when terminals of this server are already open: a new one, or
 * one of the running ones (which is sent a `cd` to the folder).
 */
@Composable
private fun OpenInTerminalDialog(
    viewModel: AppViewModel,
    workspace: FileWorkspace,
    directory: String,
    onDismiss: () -> Unit,
) {
    val running = remember { viewModel.liveTerminalsFor(workspace.profile.id) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.sftp_open_terminal_title)) },
        text = {
            Column {
                Text(
                    ltr(directory),
                    style = MaterialTheme.typography.bodySmall,
                    fontFamily = FontFamily.Monospace,
                    color = TextSecondary,
                )
                Spacer(Modifier.height(12.dp))
                TerminalChoice(stringResource(R.string.sftp_open_terminal_new), highlighted = true) {
                    viewModel.openTerminalAt(workspace, directory, null)
                    onDismiss()
                }
                running.forEach { session ->
                    TerminalChoice(
                        stringResource(R.string.sftp_open_terminal_existing, session.title),
                        highlighted = false,
                    ) {
                        viewModel.openTerminalAt(workspace, directory, session)
                        onDismiss()
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
        containerColor = MaterialTheme.colorScheme.surface,
    )
}

@Composable
private fun TerminalChoice(label: String, highlighted: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            Icons.Outlined.Terminal,
            contentDescription = null,
            tint = if (highlighted) Turquoise else TextSecondary,
        )
        Spacer(Modifier.width(12.dp))
        Text(label, style = MaterialTheme.typography.bodyLarge)
    }
}
