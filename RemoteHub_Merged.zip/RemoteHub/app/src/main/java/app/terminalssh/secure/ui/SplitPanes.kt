package app.terminalssh.secure.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.ui.composed
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowDropDown
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.terminalssh.secure.R
import app.terminalssh.secure.ssh.SshSessionState
import app.terminalssh.secure.ui.theme.TextSecondary
import app.terminalssh.secure.ui.theme.Turquoise
import kotlinx.coroutines.flow.StateFlow

/** Height of the draggable divider between the two panes. */
private val DividerHeight = 22.dp

/**
 * Two panes stacked, with a divider the user drags to give one of them more room.
 *
 * The panes are plain slots: each one is composed once, in its own box, and is never moved or
 * recreated while the divider is dragged (only its size changes), so a terminal or a File
 * Manager keeps running exactly as it was. [fraction] is the share of the height (less the
 * divider) given to [top].
 */
@Composable
fun SplitPanes(
    fraction: Float,
    onFractionChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
    top: @Composable () -> Unit,
    bottom: @Composable () -> Unit,
) {
    BoxWithConstraints(modifier.fillMaxSize()) {
        val density = LocalDensity.current
        val availablePx = with(density) { (maxHeight - DividerHeight).toPx() }.coerceAtLeast(1f)
        val latestFraction by rememberUpdatedState(fraction)
        val latestChange by rememberUpdatedState(onFractionChange)
        val topHeight = with(density) { (availablePx * fraction).toDp() }

        Column(Modifier.fillMaxSize()) {
            Box(Modifier.fillMaxWidth().height(topHeight).clipToBounds()) { top() }
            val dividerDescription = stringResource(R.string.split_resize)
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(DividerHeight)
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .semantics { contentDescription = dividerDescription }
                    .pointerInput(availablePx) {
                        detectVerticalDragGestures { change, dragAmount ->
                            change.consume()
                            latestChange(latestFraction + dragAmount / availablePx)
                        }
                    },
                contentAlignment = Alignment.Center,
            ) {
                Box(
                    Modifier
                        .width(44.dp)
                        .height(4.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(TextSecondary.copy(alpha = 0.6f)),
                )
            }
            Box(Modifier.fillMaxWidth().weight(1f).clipToBounds()) { bottom() }
        }
    }
}

/** One thing a pane can show: a terminal or a File Manager, with its live connection state. */
class PaneChoice(
    val id: String,
    val label: String,
    val state: StateFlow<SshSessionState>,
)

/**
 * The pill at the top of a pane that says which session it shows and lets the user pick another,
 * from the same server or a different one. Choosing the session the other pane shows swaps them.
 */
@Composable
fun PanePicker(
    choices: List<PaneChoice>,
    selectedId: String,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    var expanded by remember { mutableStateOf(false) }
    val selected = choices.firstOrNull { it.id == selectedId }
    Box(modifier) {
        Row(
            Modifier
                .clip(RoundedCornerShape(14.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .clickable { expanded = true }
                .padding(start = 10.dp, end = 4.dp, top = 3.dp, bottom = 3.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (selected != null) PickerDot(selected.state)
            Spacer(Modifier.width(6.dp))
            Text(
                ltr(selected?.label.orEmpty()),
                style = MaterialTheme.typography.labelMedium,
                maxLines = 1,
                modifier = Modifier.weight(1f, fill = false),
            )
            Icon(
                Icons.Outlined.ArrowDropDown,
                contentDescription = stringResource(R.string.split_pick_session),
                tint = TextSecondary,
                modifier = Modifier.size(20.dp),
            )
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            choices.forEach { choice ->
                DropdownMenuItem(
                    text = { Text(ltr(choice.label)) },
                    onClick = {
                        expanded = false
                        onSelect(choice.id)
                    },
                    leadingIcon = { PickerDot(choice.state) },
                    trailingIcon = if (choice.id == selectedId) {
                        { Icon(Icons.Outlined.Check, contentDescription = null, tint = Turquoise) }
                    } else {
                        null
                    },
                )
            }
        }
    }
}

@Composable
private fun PickerDot(state: StateFlow<SshSessionState>) {
    val current by state.collectAsStateWithLifecycle()
    Box(Modifier.size(10.dp).clip(CircleShape).background(current.status().color))
}

/**
 * Tab labels for a list of sessions that may repeat a server: the first keeps the server's
 * name, later ones get "(2)", "(3)" ... in the order they were opened.
 */
fun <T> numberedLabels(items: List<T>, hostIdOf: (T) -> String, nameOf: (T) -> String): List<String> {
    val seen = HashMap<String, Int>()
    return items.map { item ->
        val n = (seen[hostIdOf(item)] ?: 0) + 1
        seen[hostIdOf(item)] = n
        if (n == 1) nameOf(item) else "${nameOf(item)} ($n)"
    }
}

/**
 * Calls [onTouch] when a finger goes down anywhere on this pane. It watches in the Initial pass
 * and consumes nothing, so the pane underneath behaves exactly as without it; it is only how a
 * split learns which pane the user is working in.
 */
fun Modifier.onAnyTouch(onTouch: () -> Unit): Modifier = composed {
    val latest = rememberUpdatedState(onTouch)
    pointerInput(Unit) {
        awaitEachGesture {
            awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
            latest.value()
        }
    }
}
