package app.terminalssh.secure.ssh

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import app.terminalssh.secure.model.AuthMethod
import app.terminalssh.secure.model.HostProfile
import androidx.compose.ui.graphics.Color
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import androidx.compose.ui.graphics.toArgb
import org.connectbot.terminal.TerminalEmulator
import org.connectbot.terminal.TerminalEmulatorFactory
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicLong

/**
 * One live SSH shell plus its terminal emulator.
 *
 * Threading contract — the previous version crashed because it was ignored:
 *  - every socket operation (connect, write, resize, close) runs on [io];
 *  - every emulator mutation is posted to the main thread;
 *  - the reader loop owns its own thread and never touches the emulator directly.
 */
class SshSession(
    override val id: String,
    @Volatile var profile: HostProfile,
    private val client: JschSshClient,
    private val keepAlive: Boolean,
    private val onClipboardCopy: (String) -> Unit,
    private val onPasteRequest: () -> Unit,
    /** What the server is told in the pty request (the Terminal type setting). */
    private val terminalType: String = "xterm-256color",
    private val onBell: () -> Unit = {},
    /**
     * Called on the main thread when the remote shell ended on purpose (`exit`, Ctrl+D,
     * logout). The owner closes the tab; the session never reconnects after this.
     */
    private val onShellExited: () -> Unit = {},
    /** Read at each chunk of output, so toggling the setting takes effect immediately. */
    private val maskSecrets: () -> Boolean = { false },
    /**
     * Read when the terminal's width changes: whether to rebuild the screen from the session
     * text so no line stays cut off (the Terminal setting "Keep text when zooming or rotating").
     */
    private val reflowOnResize: () -> Boolean = { true },
    defaultForeground: Color = Color.White,
    defaultBackground: Color = Color.Black,
) : TerminalSession, app.terminalssh.secure.sftp.SftpSource {
    private val io = Executors.newSingleThreadExecutor { r -> Thread(r, "ssh-io-$id") }
    private val main = Handler(Looper.getMainLooper())
    private val generation = AtomicLong(0)

    private val _state = MutableStateFlow<SshSessionState>(SshSessionState.Idle)
    override val state: StateFlow<SshSessionState> = _state.asStateFlow()

    @Volatile private var shell: JschSshClient.Shell? = null
    @Volatile private var reader: Thread? = null
    @Volatile private var pendingPassword: ByteArray? = null
    @Volatile private var autoReconnect = true

    private val transcript = TranscriptBuffer()

    override val emulator: TerminalEmulator = TerminalEmulatorFactory.create(
        initialRows = INITIAL_ROWS,
        initialCols = INITIAL_COLS,
        defaultForeground = defaultForeground,
        defaultBackground = defaultBackground,
        onKeyboardInput = { bytes -> sendKey(bytes) },
        onBell = { onBell() },
        onResize = { dimensions ->
            pushPtySize(dimensions.columns, dimensions.rows)
            main.post { onGridChanged() }
        },
        onClipboardCopy = onClipboardCopy,
    )

    // ---- keeping the shell, the screen and the record of the output in step ------------------
    //
    // The terminal component sizes its grid from the pixels it gets (so a zoom or a rotation
    // changes the number of columns) and reports each new size here. Two things follow from it.

    /** The size the shell was last told, so an unchanged size is not sent again. */
    @Volatile private var ptyCols = 0
    @Volatile private var ptyRows = 0

    /** Columns the screen's content is laid out for; only touched on the main thread. */
    private var contentCols = INITIAL_COLS
    private var reflowAfterAltScreen = false
    private val reflowTask = Runnable { reflowNow() }

    /**
     * Tells the shell the grid size, so it wraps and redraws for the width that is really shown.
     * A resize that arrives before the shell exists is not lost: [doConnect] sends the current
     * size once the shell is open. Degenerate sizes, which a terminal being rebuilt can report
     * for a moment, are ignored rather than sent as a window change.
     */
    private fun pushPtySize(columns: Int, rows: Int) {
        if (columns < 2 || rows < 2) return
        if (columns == ptyCols && rows == ptyRows) return
        val channel = shell?.channel ?: return
        ptyCols = columns
        ptyRows = rows
        io.execute { runCatching { channel.setPtySize(columns, rows, 0, 0) } }
    }

    /** Main thread: the terminal component resized the emulator's grid. */
    private fun onGridChanged() {
        val columns = emulator.dimensions.columns
        if (columns == contentCols) return // only the height changed (keyboard): no line was cut
        if (!reflowOnResize()) {
            contentCols = columns
            return
        }
        scheduleReflow()
    }

    private fun scheduleReflow() {
        main.removeCallbacks(reflowTask)
        main.postDelayed(reflowTask, REFLOW_DELAY_MS)
    }

    /**
     * The emulator cuts every line to a narrower grid and does not restore it when the grid
     * widens again, which is how zooming in and out used to lose words. Once the width has
     * settled, the screen and scrollback are written again from the record of the output, at
     * the new width, so every line is whole. Not done while a full-screen program has the
     * screen (it redraws itself on the window change; this runs when it ends), nor when the
     * record cannot be trusted (see [TranscriptBuffer.replayAll]): then the terminal keeps
     * what its own resize left.
     */
    private fun reflowNow() {
        val columns = emulator.dimensions.columns
        if (columns == contentCols || columns < 2) return
        if (transcript.isAltScreen()) {
            reflowAfterAltScreen = true
            return
        }
        val replay = transcript.replayAll(columns = columns)
        if (replay != null) {
            runCatching { emulator.clearScreen() }
            emulator.writeInput(replay, 0, replay.size)
        }
        contentCols = columns
    }

    /**
     * Feeds output to the emulator. A clear of the screen is the one thing split out: the
     * output up to it goes in, the emulator's screen and scrollback are emptied, then the rest
     * goes in. The record has already been emptied at the same point, so what is on screen
     * and what "copy all" returns agree.
     */
    private fun writeOutput(chunk: ByteArray, flags: Int) {
        val clearAt = if ((flags and TranscriptBuffer.FULL_CLEAR) != 0) transcript.lastClearEnd() else -1
        if (clearAt in 1..chunk.size) {
            emulator.writeInput(chunk, 0, clearAt)
            runCatching { emulator.clearScreen() }
            if (clearAt < chunk.size) emulator.writeInput(chunk, clearAt, chunk.size - clearAt)
        } else {
            emulator.writeInput(chunk, 0, chunk.size)
        }
        if ((flags and TranscriptBuffer.ALT_LEFT) != 0 && reflowAfterAltScreen) {
            reflowAfterAltScreen = false
            scheduleReflow()
        }
    }

    override val title: String get() = profile.displayName
    override val hostId: String get() = profile.id
    override val subtitle: String get() = profile.subtitle

    /**
     * Gives the live emulator a theme: the 16 ANSI colours and the default foreground and
     * background. Used when a session is created and again whenever the theme changes, so an
     * open session recolours at once instead of keeping the colours it started with.
     *
     * The emulator library's entry point for this is looked up by name: if a version does not
     * have it, the session simply keeps its colours (the Terminal view still paints the theme's
     * background and foreground).
     */
    override fun applyPalette(palette: app.terminalssh.secure.ui.theme.TerminalPalette) {
        val ansi = IntArray(16) { palette.ansi[it].toArgb() }
        val fg = palette.foreground.toArgb()
        val bg = palette.background.toArgb()
        main.post {
            runCatching {
                val method = emulator.javaClass.methods.firstOrNull {
                    it.name == "applyColorScheme" && it.parameterTypes.size == 3 &&
                        it.parameterTypes[0] == IntArray::class.java
                } ?: return@runCatching
                method.invoke(emulator, ansi, fg, bg)
            }
        }
    }

    /** When anything last moved in either direction; the idle-disconnect timer measures from here. */
    @Volatile var lastActivityAt: Long = SystemClock.elapsedRealtime()
        private set

    /**
     * Sets the cursor shape and blink with the standard DECSCUSR sequence, the same one a
     * program such as vim sends. It is fed to the terminal as if the server had sent it, so
     * it shows however far the terminal component honours it, and a program that sets its
     * own cursor shape later still wins.
     */
    override fun applyCursorStyle(style: String, blink: Boolean) {
        val code = when (style) {
            "bar" -> if (blink) 5 else 6
            "underline" -> if (blink) 3 else 4
            else -> if (blink) 1 else 2
        }
        val bytes = "\u001b[$code q".encodeToByteArray()
        main.post { emulator.writeInput(bytes, 0, bytes.size) }
    }

    /** @param password only for hosts without a stored secret; zeroed once used. */
    fun connect(password: ByteArray? = null) {
        pendingPassword?.fill(0)
        pendingPassword = password
        autoReconnect = true
        val gen = generation.incrementAndGet()
        _state.value = SshSessionState.Connecting
        io.execute { doConnect(gen, attempt = 0) }
    }

    private fun doConnect(gen: Long, attempt: Int) {
        if (gen != generation.get()) return
        try {
            val dimensions = emulator.dimensions
            val opened = client.connect(
                profile = profile,
                columns = dimensions.columns.coerceAtLeast(20),
                rows = dimensions.rows.coerceAtLeast(4),
                passwordOverride = pendingPassword?.copyOf(),
                keepAlive = keepAlive,
                terminalType = terminalType,
            )
            if (gen != generation.get()) {
                opened.close()
                return
            }
            shell = opened
            // The shell was opened with the size read above; the terminal may have been resized
            // since (its first layout usually lands while the connection is being made), and
            // that resize found no shell to tell. Send whatever the grid is now.
            ptyCols = dimensions.columns.coerceAtLeast(20)
            ptyRows = dimensions.rows.coerceAtLeast(4)
            transcript.newConnection()
            emulator.dimensions.let { pushPtySize(it.columns, it.rows) }
            _state.value = SshSessionState.Connected
            // A password only needs to stay decrypted in memory if reconnecting will
            // need it again; a saved host re-fetches it from the vault instead, so
            // wipe it as soon as it has served its purpose.
            if (hasStoredCredential()) clearPendingPassword()
            startReader(opened, gen)
        } catch (first: FirstUseRequired) {
            if (gen != generation.get()) {
                first.key.fill(0)
                return
            }
            _state.value = SshSessionState.AwaitingHostKeyApproval(
                host = first.host,
                port = first.port,
                algorithm = first.algorithm,
                fingerprint = first.fingerprint,
                key = first.key,
            )
        } catch (changed: HostKeyRejected) {
            if (gen != generation.get()) return
            clearPendingPassword()
            _state.value = SshSessionState.Failed(
                message = changed.message ?: "host key rejected",
                hostKeyChanged = true,
                kind = ConnectionErrorKind.HOST_KEY_CHANGED,
            )
        } catch (t: Throwable) {
            if (gen != generation.get()) return
            val maxAttempts = profile.maxReconnectAttempts
            if (autoReconnect && attempt < maxAttempts && ReconnectPolicy.isTransient(t)) {
                _state.value = SshSessionState.Reconnecting(attempt + 1, maxAttempts)
                Thread.sleep(ReconnectPolicy.delayMillis(attempt))
                doConnect(gen, attempt + 1)
            } else {
                clearPendingPassword()
                _state.value = SshSessionState.Failed(
                    message = t.message ?: t.javaClass.simpleName,
                    kind = ConnectionError.classify(t),
                )
            }
        }
    }

    /** Called after the user approves a first-use fingerprint; the caller stores the key. */
    fun retryAfterTrust() {
        clearPendingHostKey()
        val gen = generation.incrementAndGet()
        _state.value = SshSessionState.Connecting
        io.execute { doConnect(gen, attempt = 0) }
    }

    private fun startReader(open: JschSshClient.Shell, gen: Long) {
        val thread = Thread({
            val buffer = ByteArray(READ_BUFFER)
            try {
                while (gen == generation.get() && !open.channel.isClosed) {
                    val read = open.input.read(buffer)
                    if (read < 0) break
                    if (read > 0) {
                        if (gen != generation.get() || shell !== open) {
                            buffer.fill(0, 0, read)
                            break
                        }
                        lastActivityAt = SystemClock.elapsedRealtime()
                        if (maskSecrets()) SecretMask.maskInPlace(buffer, read)
                        val chunk = buffer.copyOf(read)
                        buffer.fill(0, 0, read)
                        main.post {
                            try {
                                if (gen == generation.get() && shell === open) {
                                    writeOutput(chunk, transcript.append(chunk))
                                }
                            } finally {
                                chunk.fill(0)
                            }
                        }
                    }
                }
            } catch (_: Throwable) {
                // Falls through to the disconnect handling below.
            } finally {
                buffer.fill(0)
                if (gen == generation.get()) {
                    shell = null
                    // Did the shell end on purpose (`exit`, Ctrl+D, logout), or did the
                    // connection drop? The exit-status message can arrive just after the
                    // stream's EOF, so reading it immediately raced and mistook `exit`
                    // for a dropped link, which reconnected and logged straight back in.
                    // Give it a moment; and if no status ever arrives but the transport
                    // is still up, only the channel ended, which is the shell exiting.
                    // A real network loss takes the transport down with it.
                    val remoteExitedCleanly = remoteShellExited(open)
                    if (autoReconnect && !remoteExitedCleanly && profile.maxReconnectAttempts > 0) {
                        _state.value = SshSessionState.Reconnecting(1, profile.maxReconnectAttempts)
                        io.execute { doConnect(gen, attempt = 0) }
                    } else {
                        // The end of the session, not a connection to keep warm: release
                        // the connection and worker thread, then ask the owner to close
                        // the tab, like a normal terminal window closing on `exit`.
                        destroy()
                        if (remoteExitedCleanly) main.post { onShellExited() }
                    }
                }
                runCatching { open.close() }
            }
        }, "ssh-reader-$id")
        thread.isDaemon = true
        reader = thread
        thread.start()
    }

    private fun remoteShellExited(open: JschSshClient.Shell): Boolean {
        val deadline = SystemClock.elapsedRealtime() + EXIT_STATUS_WAIT_MS
        while (true) {
            if (runCatching { open.channel.exitStatus }.getOrDefault(-1) >= 0) return true
            if (SystemClock.elapsedRealtime() >= deadline) break
            try { Thread.sleep(25) } catch (_: InterruptedException) { break }
        }
        return runCatching { open.session.isConnected }.getOrDefault(false)
    }

    override fun send(bytes: ByteArray) {
        val current = shell ?: return
        lastActivityAt = SystemClock.elapsedRealtime()
        val copy = bytes.copyOf()
        io.execute {
            try {
                current.output.write(copy)
                current.output.flush()
            } catch (_: Throwable) {
            } finally {
                copy.fill(0)
            }
        }
    }

    override fun send(text: String) = send(text.encodeToByteArray())

    // ---- Ctrl / Alt latches (the extra-keys bar) ----
    // Latched here, not in the toolbar, so they also apply to what is typed on the soft
    // keyboard, like Termux: tap CTRL, then press c on the keyboard to send ^C.

    private val _ctrlLatched = MutableStateFlow(false)
    override val ctrlLatched: StateFlow<Boolean> = _ctrlLatched.asStateFlow()
    private val _altLatched = MutableStateFlow(false)
    override val altLatched: StateFlow<Boolean> = _altLatched.asStateFlow()

    override fun toggleCtrl() { _ctrlLatched.value = !_ctrlLatched.value; _altLatched.value = false }
    override fun toggleAlt() { _altLatched.value = !_altLatched.value; _ctrlLatched.value = false }

    /** A key press from the keyboard or the bar: applies a latched Ctrl/Alt once, then releases it. */
    override fun sendKey(bytes: ByteArray) {
        val ctrl = _ctrlLatched.value
        val alt = _altLatched.value
        if (!ctrl && !alt) return send(bytes)
        _ctrlLatched.value = false
        _altLatched.value = false
        var out = bytes
        if (ctrl && bytes.size == 1) {
            val c = bytes[0].toInt().toChar()
            val code = when (c) {
                in 'a'..'z' -> c - 'a' + 1
                in 'A'..'Z' -> c - 'A' + 1
                '@', ' ' -> 0
                '[' -> 27
                '\\' -> 28
                ']' -> 29
                '^' -> 30
                '_', '/' -> 31
                '?' -> 127
                else -> -1
            }
            if (code >= 0) out = byteArrayOf(code.toByte())
        } else if (alt && bytes.isNotEmpty() && bytes[0] != 0x1B.toByte()) {
            out = byteArrayOf(0x1B) + bytes
        }
        send(out)
    }

    override fun sendKey(text: String) = sendKey(text.encodeToByteArray())

    override fun requestPaste() = onPasteRequest()

    /**
     * An SFTP client riding this session's existing connection, or null when the session
     * is not connected. Reusing the connection avoids a second authentication and a
     * second host-key check for a server the user is already inside.
     *
     * The caller owns the returned client and must close it.
     */
    override fun openSftp(): app.terminalssh.secure.sftp.SftpClient? =
        shell?.takeIf { it.alive }?.let { app.terminalssh.secure.sftp.SftpClient(it.session) }

    override fun clearScreen() { transcript.clear(); main.post { runCatching { emulator.clearScreen() } } }

    override fun transcriptText(): String = transcript.text()

    override fun disconnect() {
        autoReconnect = false
        generation.incrementAndGet()
        clearPendingHostKey()
        val open = shell
        shell = null
        clearPendingPassword()
        _state.value = SshSessionState.Closed
        if (open != null) io.execute { runCatching { open.close() } }
    }

    override fun destroy() {
        main.removeCallbacks(reflowTask)
        disconnect()
        io.shutdown()
    }

    private fun clearPendingHostKey() {
        (state.value as? SshSessionState.AwaitingHostKeyApproval)?.key?.fill(0)
    }

    private fun clearPendingPassword() {
        pendingPassword?.fill(0)
        pendingPassword = null
    }

    /** True when a reconnect can re-derive the credential from the vault, without [pendingPassword]. */
    private fun hasStoredCredential(): Boolean = when (val auth = profile.auth) {
        is AuthMethod.Password -> auth.vaultRef.isNotBlank()
        is AuthMethod.PrivateKey -> true
    }

    companion object {
        private const val INITIAL_ROWS = 24
        private const val INITIAL_COLS = 80

        /** How long the width must stay put before the screen is rebuilt for it (a zoom is a stream of sizes). */
        private const val REFLOW_DELAY_MS = 150L
        private const val READ_BUFFER = 16 * 1024
        private const val EXIT_STATUS_WAIT_MS = 400L
    }
}
