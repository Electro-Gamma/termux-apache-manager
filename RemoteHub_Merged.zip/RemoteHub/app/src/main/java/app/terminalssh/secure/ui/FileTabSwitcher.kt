package app.terminalssh.secure.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.InsertDriveFile
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.terminalssh.secure.R
import app.terminalssh.secure.sftp.RemotePath
import app.terminalssh.secure.ssh.FileWorkspace
import app.terminalssh.secure.ui.theme.Danger
import app.terminalssh.secure.ui.theme.Stroke
import app.terminalssh.secure.ui.theme.TextSecondary
import app.terminalssh.secure.ui.theme.Turquoise

/**
 * All the File Manager tabs at a glance, like a browser's tab switcher: one card per tab showing
 * which server it is on and what it is showing (a folder, or the file open in the editor or
 * viewer). Tapping a card brings that tab forward exactly as it was left; the tabs themselves
 * stay alive underneath, so nothing is reloaded, rescrolled or lost.
 */
@Composable
fun FileTabSwitcher(
    workspaces: List<FileWorkspace>,
    labels: Map<String, String>,
    shownIds: Set<String>,
    onSelect: (String) -> Unit,
    onClose: (String) -> Unit,
    onNewTab: () -> Unit,
    onDismiss: () -> Unit,
) {
    BackHandler(onBack = onDismiss)
    // A tab with unsaved text asks before it is closed.
    var confirmClose by remember { mutableStateOf<FileWorkspace?>(null) }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = onDismiss) {
                    Icon(Icons.AutoMirrored.Outlined.ArrowBack, stringResource(R.string.files_tabs_back))
                }
                Text(
                    stringResource(R.string.files_tabs_title, workspaces.size),
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                )
                IconButton(onClick = onNewTab) {
                    Icon(Icons.Outlined.Add, stringResource(R.string.files_tab_new))
                }
            }
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.fillMaxSize(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                items(workspaces, key = { it.id }) { workspace ->
                    TabCard(
                        workspace = workspace,
                        label = labels[workspace.id] ?: workspace.profile.displayName,
                        selected = workspace.id in shownIds,
                        onClick = { onSelect(workspace.id) },
                        onClose = {
                            if (workspace.controller.editor.value?.draft != null) {
                                confirmClose = workspace
                            } else {
                                onClose(workspace.id)
                            }
                        },
                    )
                }
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(MaterialTheme.colorScheme.surface)
                            .clickable(onClick = onNewTab)
                            .padding(vertical = 16.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(Icons.Outlined.Add, contentDescription = null, tint = Turquoise)
                        Spacer(Modifier.width(8.dp))
                        Text(stringResource(R.string.files_tab_new), color = Turquoise)
                    }
                }
            }
        }
    }

    confirmClose?.let { target ->
        AlertDialog(
            onDismissRequest = { confirmClose = null },
            title = { Text(stringResource(R.string.files_tab_close_title)) },
            text = { Text(stringResource(R.string.files_tab_close_body)) },
            confirmButton = {
                TextButton(onClick = {
                    confirmClose = null
                    onClose(target.id)
                }) { Text(stringResource(R.string.files_tab_close_action), color = Danger) }
            },
            dismissButton = {
                TextButton(onClick = { confirmClose = null }) { Text(stringResource(R.string.cancel)) }
            },
            containerColor = MaterialTheme.colorScheme.surface,
        )
    }
}

@Composable
private fun TabCard(
    workspace: FileWorkspace,
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    onClose: () -> Unit,
) {
    val state by workspace.session.state.collectAsStateWithLifecycle()
    val editor by workspace.controller.editor.collectAsStateWithLifecycle()
    val browser by workspace.controller.browser.collectAsStateWithLifecycle()

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(if (selected) 2.dp else 1.dp, if (selected) Turquoise else Stroke),
        modifier = Modifier.fillMaxWidth().height(150.dp).clickable(onClick = onClick),
    ) {
        Column(Modifier.padding(start = 12.dp, top = 4.dp, bottom = 10.dp, end = 2.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(9.dp).clip(CircleShape).background(state.status().color))
                Spacer(Modifier.width(8.dp))
                Text(
                    ltr(label),
                    style = MaterialTheme.typography.labelMedium,
                    color = TextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
                IconButton(onClick = onClose, modifier = Modifier.size(36.dp)) {
                    Icon(
                        Icons.Outlined.Close,
                        contentDescription = stringResource(R.string.files_tab_close),
                        tint = TextSecondary,
                        modifier = Modifier.size(18.dp),
                    )
                }
            }
            Column(
                Modifier.fillMaxWidth().weight(1f).padding(end = 10.dp),
                verticalArrangement = Arrangement.Center,
            ) {
                val file = editor
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        if (file != null) Icons.Outlined.InsertDriveFile else Icons.Outlined.Folder,
                        contentDescription = null,
                        tint = Turquoise,
                        modifier = Modifier.size(26.dp),
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(
                        ltr(
                            file?.entry?.name
                                ?: browser.path.let { if (it == RemotePath.ROOT) "/" else RemotePath.name(it) },
                        ),
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Spacer(Modifier.height(6.dp))
                if (file != null) {
                    Text(
                        stringResource(
                            when {
                                file.draft != null -> R.string.files_tab_unsaved
                                file.readOnly -> R.string.files_tab_viewing
                                else -> R.string.files_tab_editing
                            },
                        ),
                        style = MaterialTheme.typography.labelSmall,
                        color = if (file.draft != null) Danger else TextSecondary,
                    )
                    Text(
                        ltr(RemotePath.parent(file.entry.path)),
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary,
                        fontFamily = FontFamily.Monospace,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                } else {
                    Text(
                        ltr(browser.path),
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary,
                        fontFamily = FontFamily.Monospace,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
    }
}
