package app.terminalssh.secure.ui

import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.outlined.KeyboardArrowRight
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import app.terminalssh.secure.R
import app.terminalssh.secure.sftp.RemoteEntry
import app.terminalssh.secure.sftp.SftpClient
import app.terminalssh.secure.sftp.SftpController
import app.terminalssh.secure.ui.theme.TextSecondary
import app.terminalssh.secure.viewer.ViewerKind
import app.terminalssh.secure.viewer.ViewerPane
import app.terminalssh.secure.viewer.decodeScaled
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private const val MAX_IMAGE_ZOOM = 8f

/** Animated GIFs of this size or less go through the WebView so they keep moving. */
private const val ANIMATED_GIF_BYTES = 10L * 1024 * 1024

/**
 * The File Manager's image viewer. All the images of the folder are pages of one pager: swipe
 * left or right (or use the arrows) to move to the previous or next one. Only the page in view
 * and its neighbours are loaded, each downloaded as a stream and decoded at a bounded size, so
 * a folder of large photos stays light on memory.
 *
 * Pinch to zoom and drag to pan inside an image; a drag only turns the page once the image is at
 * its edge (or not zoomed), so panning a zoomed image never flips by accident.
 */
@Composable
fun ImageGalleryScreen(
    controller: SftpController,
    images: List<RemoteEntry>,
    current: RemoteEntry,
    active: Boolean = true,
) {
    val context = LocalContext.current
    val dark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
    val backdrop = if (dark) Color(0xFF0D1117) else Color.White
    val scope = rememberCoroutineScope()

    // The list can be refreshed or re-sorted while the viewer is open; the page shown is found by path.
    val startIndex = remember { images.indexOfFirst { it.path == current.path }.coerceAtLeast(0) }
    val pager = rememberPagerState(initialPage = startIndex) { images.size }

    // The editor session follows the page, so coming back to this tab shows the same image.
    LaunchedEffect(pager, images) {
        snapshotFlow { pager.currentPage }.collect { page ->
            images.getOrNull(page)?.let { entry ->
                if (entry.path != controller.editor.value?.entry?.path) {
                    controller.updateEditor { it.copy(entry = entry) }
                }
            }
        }
    }

    BackHandler(enabled = active) { controller.closeEditor() }

    val page = pager.currentPage
    val shown = images.getOrNull(page)

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surface)) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = { controller.closeEditor() }, modifier = Modifier.size(44.dp)) {
                Icon(Icons.AutoMirrored.Outlined.ArrowBack, stringResource(R.string.editor_close))
            }
            Column(Modifier.weight(1f).padding(horizontal = 4.dp)) {
                Text(
                    ltr(shown?.name.orEmpty()),
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    stringResource(R.string.gallery_position, page + 1, images.size),
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary,
                    maxLines = 1,
                )
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth().background(backdrop)) {
            HorizontalPager(
                state = pager,
                modifier = Modifier.fillMaxSize(),
                beyondViewportPageCount = 1,
                key = { index -> images.getOrNull(index)?.path ?: index },
            ) { index ->
                val entry = images.getOrNull(index)
                if (entry != null) {
                    GalleryPage(controller, entry, context.cacheDir, dark, backdrop)
                }
            }
            // Buttons as well as swiping: a GIF page keeps its own touch handling, and some people
            // simply prefer a tap.
            if (images.size > 1) {
                val atStart = page <= 0
                val atEnd = page >= images.size - 1
                NavArrow(
                    left = true,
                    enabled = !atStart,
                    modifier = Modifier.align(Alignment.CenterStart).padding(start = 6.dp),
                ) { scope.launch { pager.animateScrollToPage(page - 1) } }
                NavArrow(
                    left = false,
                    enabled = !atEnd,
                    modifier = Modifier.align(Alignment.CenterEnd).padding(end = 6.dp),
                ) { scope.launch { pager.animateScrollToPage(page + 1) } }
            }
        }
    }
}

@Composable
private fun NavArrow(left: Boolean, enabled: Boolean, modifier: Modifier, onClick: () -> Unit) {
    if (!enabled) return
    Box(
        modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(Color.Black.copy(alpha = 0.35f)),
        contentAlignment = Alignment.Center,
    ) {
        IconButton(onClick = onClick, modifier = Modifier.size(40.dp)) {
            Icon(
                if (left) Icons.AutoMirrored.Outlined.KeyboardArrowLeft else Icons.AutoMirrored.Outlined.KeyboardArrowRight,
                contentDescription = stringResource(if (left) R.string.gallery_previous else R.string.gallery_next),
                tint = Color.White,
            )
        }
    }
}

/** What one page found: still loading, or the image file, or a reason it cannot be shown. */
private sealed interface PageLoad {
    data object Loading : PageLoad
    class Ready(val file: File) : PageLoad
    class Failed(val messageRes: Int) : PageLoad
}

@Composable
private fun GalleryPage(
    controller: SftpController,
    entry: RemoteEntry,
    cacheDir: File,
    dark: Boolean,
    backdrop: Color,
) {
    var loaded by remember(entry.path) { mutableLongStateOf(0L) }
    val load by produceState<PageLoad>(PageLoad.Loading, entry.path, entry.sizeBytes) {
        value = PageLoad.Loading
        value = try {
            PageLoad.Ready(
                controller.fetchGalleryImage(entry, cacheDir, SftpController.MAX_VIEW_BYTES) { loaded = it },
            )
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: app.terminalssh.secure.sftp.FileTooLarge) {
            PageLoad.Failed(R.string.viewer_too_large)
        } catch (t: Throwable) {
            PageLoad.Failed(SftpClient.classify(t).stringRes)
        }
    }

    Box(Modifier.fillMaxSize().background(backdrop), contentAlignment = Alignment.Center) {
        when (val state = load) {
            PageLoad.Loading -> Text(
                stringResource(R.string.editor_loading) +
                    if (loaded > 0L) {
                        "  " + FileSize.format(loaded) +
                            if (entry.sizeBytes > 0L) " / " + FileSize.format(entry.sizeBytes) else ""
                    } else "",
                color = MaterialTheme.colorScheme.onSurface,
                style = MaterialTheme.typography.bodyMedium,
            )
            is PageLoad.Failed -> Text(
                stringResource(state.messageRes),
                color = MaterialTheme.colorScheme.onSurface,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(32.dp),
            )
            is PageLoad.Ready -> {
                val isGif = entry.name.endsWith(".gif", ignoreCase = true) && state.file.length() <= ANIMATED_GIF_BYTES
                if (isGif) {
                    val bytes by produceState<ByteArray?>(null, state.file) {
                        value = withContext(Dispatchers.IO) { runCatching { state.file.readBytes() }.getOrNull() }
                    }
                    bytes?.let {
                        ViewerPane(
                            kind = ViewerKind.IMAGE,
                            text = null,
                            bytes = it,
                            visible = true,
                            dark = dark,
                            modifier = Modifier.fillMaxSize(),
                        )
                    }
                } else {
                    ZoomableImage(state.file)
                }
            }
        }
    }
}

/**
 * A decoded image with pinch-zoom and pan that plays well inside a pager: a one-finger drag is
 * only taken (and consumed) while the image is zoomed in and can still move that way, so at
 * normal size, or once the zoomed image reaches its edge, the drag is left for the pager.
 */
@Composable
private fun ZoomableImage(file: File) {
    val decoded by produceState<Pair<Boolean, Bitmap?>>(false to null, file) {
        val result = withContext(Dispatchers.IO) { runCatching { decodeScaled(file) }.getOrNull() }
        value = true to result
        awaitDispose { result?.let { if (!it.isRecycled) it.recycle() } }
    }
    val bitmap = decoded.second
    if (bitmap == null) {
        Text(
            stringResource(if (decoded.first) R.string.viewer_cannot_display else R.string.editor_loading),
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(24.dp),
        )
        return
    }

    var scale by remember(bitmap) { mutableFloatStateOf(1f) }
    var offset by remember(bitmap) { mutableStateOf(Offset.Zero) }
    var box by remember { mutableStateOf(IntSize.Zero) }

    fun clamp(o: Offset, s: Float): Offset {
        val maxX = box.width * (s - 1f) / 2f
        val maxY = box.height * (s - 1f) / 2f
        return Offset(o.x.coerceIn(-maxX, maxX), o.y.coerceIn(-maxY, maxY))
    }

    Image(
        bitmap = bitmap.asImageBitmap(),
        contentDescription = null,
        contentScale = ContentScale.Fit,
        modifier = Modifier
            .fillMaxSize()
            .onSizeChanged { box = it }
            .pointerInput(bitmap) {
                detectTapGestures(onDoubleTap = {
                    if (scale > 1f) {
                        scale = 1f
                        offset = Offset.Zero
                    } else {
                        scale = 3f
                    }
                })
            }
            .pointerInput(bitmap) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    do {
                        val event = awaitPointerEvent()
                        val fingers = event.changes.count { it.pressed }
                        val zoom = event.calculateZoom()
                        val pan = event.calculatePan()
                        if (fingers > 1) {
                            scale = (scale * zoom).coerceIn(1f, MAX_IMAGE_ZOOM)
                            offset = clamp(offset + pan, scale)
                            event.changes.forEach { if (it.positionChanged()) it.consume() }
                        } else if (scale > 1f) {
                            val next = clamp(offset + pan, scale)
                            if (next != offset) {
                                offset = next
                                event.changes.forEach { if (it.positionChanged()) it.consume() }
                            }
                        }
                    } while (event.changes.any { it.pressed })
                }
            }
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
                translationX = offset.x
                translationY = offset.y
            },
    )
}
