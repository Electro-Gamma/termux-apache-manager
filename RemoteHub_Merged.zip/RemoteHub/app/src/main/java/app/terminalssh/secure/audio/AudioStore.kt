package app.terminalssh.secure.audio

import android.content.Context
import app.terminalssh.secure.security.AndroidKeyStoreVault
import app.terminalssh.secure.security.VaultAad

/** Where one saved server's audio goes, and in which format. The passphrase is not part of this: it lives in the vault. */
data class AudioTarget(
    val host: String,
    val port: Int = DEFAULT_PORT,
    val micRate: Int = 16000,
    val micChannels: Int = 1,
    val playRate: Int = 48000,
    val playChannels: Int = 2,
    /** Echo cancellation and noise suppression. Off gives dictation tools such as Whisper a less processed signal. */
    val voiceProcessing: Boolean = true,
) {
    companion object {
        const val DEFAULT_PORT = 5950
        const val MIN_PASSPHRASE = 12
        val MIC_RATES = listOf(8000, 16000, 24000, 44100, 48000)
        val PLAY_RATES = listOf(24000, 44100, 48000)
    }
}

/** Audio bridge settings per saved server (keyed by the session's host id). */
class AudioStore(context: Context, private val vault: AndroidKeyStoreVault) {
    private val prefs = context.getSharedPreferences("audio_bridge_v1", Context.MODE_PRIVATE)

    fun target(hostId: String): AudioTarget? {
        val host = prefs.getString("$hostId.host", null) ?: return null
        val defaults = AudioTarget(host)
        return AudioTarget(
            host = host,
            port = prefs.getInt("$hostId.port", defaults.port),
            micRate = prefs.getInt("$hostId.micRate", defaults.micRate),
            micChannels = prefs.getInt("$hostId.micChannels", defaults.micChannels),
            playRate = prefs.getInt("$hostId.playRate", defaults.playRate),
            playChannels = prefs.getInt("$hostId.playChannels", defaults.playChannels),
            voiceProcessing = prefs.getBoolean("$hostId.voice", defaults.voiceProcessing),
        )
    }

    /** null when none is saved, or when the saved one can no longer be decrypted. */
    fun passphrase(hostId: String): String? = runCatching {
        vault.get(ref(hostId), VaultAad.AUDIO_PASSPHRASE)?.let { bytes ->
            bytes.decodeToString().also { bytes.fill(0) }
        }
    }.getOrNull()

    /** [newPassphrase] null keeps the saved one. */
    fun save(hostId: String, target: AudioTarget, newPassphrase: String?) {
        if (newPassphrase != null) {
            val bytes = newPassphrase.encodeToByteArray()
            try {
                vault.put(ref(hostId), bytes, VaultAad.AUDIO_PASSPHRASE)
            } finally {
                bytes.fill(0)
            }
        }
        prefs.edit()
            .putString("$hostId.host", target.host)
            .putInt("$hostId.port", target.port)
            .putInt("$hostId.micRate", target.micRate)
            .putInt("$hostId.micChannels", target.micChannels)
            .putInt("$hostId.playRate", target.playRate)
            .putInt("$hostId.playChannels", target.playChannels)
            .putBoolean("$hostId.voice", target.voiceProcessing)
            .apply()
    }

    fun forget(hostId: String) {
        val edit = prefs.edit()
        listOf("host", "port", "micRate", "micChannels", "playRate", "playChannels", "voice")
            .forEach { edit.remove("$hostId.$it") }
        edit.apply()
        vault.delete(ref(hostId), VaultAad.AUDIO_PASSPHRASE)
    }

    private fun ref(hostId: String) = "audio:$hostId"
}
