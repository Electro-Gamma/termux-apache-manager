package app.terminalssh.secure.ssh

/**
 * A text record of what a terminal session has shown, with no limit of one screen.
 *
 * It does two jobs for the terminal tab:
 *
 *  1. "Copy all" / "Select text": the whole output as plain text. Control sequences are
 *     removed and carriage returns, backspaces and the common erase/cursor-move sequences
 *     are applied, so a shell prompt being edited reads as the user saw it.
 *
 *  2. Rebuilding the terminal when its width changes (zoom, rotation). The terminal component
 *     keeps its screen as a fixed grid and cuts every line to the new width when it gets
 *     narrower; widening it again does not bring the text back. The record keeps each line
 *     whole, with its colours, so [replayAll] can write the content again at the new width.
 *
 * The record follows the terminal's own idea of what is on screen:
 *  - A clear of the screen (`clear`, Ctrl+L in most shells, `tput reset`, ESC c) empties it,
 *    so "copy all" returns only what came after.
 *  - A full-screen program (vim, top, less: the "alternate screen") is not recorded, as in
 *    any terminal: its output does not belong to the shell's history, and the screen the
 *    shell had comes back when the program exits.
 *  - Output the line model cannot follow in the normal screen (scroll regions, cursor
 *    save/restore, absolute cursor addressing) marks the record as unfaithful for a while;
 *    [replayAll] then declines instead of drawing something wrong.
 *
 * Oldest lines are dropped once [maxChars] is exceeded.
 */
class TranscriptBuffer(private val maxChars: Int = DEFAULT_MAX_CHARS) {

    private enum class Mode { TEXT, ESC, CSI, STRING, STRING_ESC, SKIP_ONE }

    private val lock = Any()

    /** Finished lines. Each is self-contained: colour runs are `ESC [ 0 ; ... m`, reset at the end. */
    private val lines = ArrayDeque<String>()
    private var storedChars = 0L
    private var lineCounter = 0L

    // The line being written: characters and, parallel to them, a style id (0 = default).
    private var cc = CharArray(256)
    private var cs = IntArray(256)
    private var len = 0
    private var column = 0

    private var mode = Mode.TEXT
    private val params = StringBuilder()

    // Colours and attributes the output has switched on, as the terminal sees them.
    private val sgr = Sgr()
    private var styleNow = 0
    private val styleIds = HashMap<String, Int>()
    private val styleCodes = ArrayList<String>().apply { add("") }

    // UTF-8 decoding state, kept between chunks.
    private var utf8Need = 0
    private var utf8Code = 0

    // Screen state.
    private var altScreen = false
    private var homePending = false
    private var taintedAtLine = Long.MIN_VALUE / 2

    // What the last [append] saw; offsets are into that call's byte array.
    private var clearEnd = -1
    private var chunkFlags = 0
    private var offsetAfterChar = 0

    /**
     * Records output. Returns a set of [FULL_CLEAR] / [ALT_LEFT] flags for what this chunk did;
     * [lastClearEnd] then tells where in [bytes] the last full clear ended.
     */
    fun append(bytes: ByteArray, length: Int = bytes.size): Int {
        if (length <= 0) return 0
        synchronized(lock) {
            clearEnd = -1
            chunkFlags = 0
            var i = 0
            while (i < length) {
                val b = bytes[i].toInt() and 0xff
                offsetAfterChar = i + 1
                if (utf8Need > 0) {
                    if ((b and 0xC0) == 0x80) {
                        utf8Code = (utf8Code shl 6) or (b and 0x3F)
                        utf8Need--
                        if (utf8Need == 0) emit(utf8Code)
                        i++
                        continue
                    }
                    // Not a continuation byte: the sequence was broken. Report it, then read this byte afresh.
                    utf8Need = 0
                    emit(REPLACEMENT)
                }
                when {
                    b < 0x80 -> emit(b)
                    b in 0xC2..0xDF -> { utf8Need = 1; utf8Code = b and 0x1F }
                    b in 0xE0..0xEF -> { utf8Need = 2; utf8Code = b and 0x0F }
                    b in 0xF0..0xF4 -> { utf8Need = 3; utf8Code = b and 0x07 }
                    else -> emit(REPLACEMENT)
                }
                i++
            }
            return chunkFlags
        }
    }

    /** Byte offset in the array last given to [append] just after its last full clear, or -1. */
    fun lastClearEnd(): Int = synchronized(lock) { clearEnd }

    /** Everything recorded since the last clear, oldest first, as plain text. */
    fun text(): String = synchronized(lock) {
        val all = StringBuilder(storedChars.toInt() + len + 16)
        for (line in lines) all.append(plain(line)).append('\n')
        all.append(trimmedCurrent())
        all.toString().trimEnd('\n', ' ')
    }

    /** Forgets everything, including a half-read escape sequence and the alternate-screen state. */
    fun clear() = synchronized(lock) {
        clearAll()
        mode = Mode.TEXT
        params.setLength(0)
        utf8Need = 0
        altScreen = false
        sgr.reset()
        styleNow = 0
    }

    /** A new connection starts at the normal screen, whatever the old one was doing. */
    fun newConnection() = synchronized(lock) {
        mode = Mode.TEXT
        params.setLength(0)
        utf8Need = 0
        altScreen = false
        homePending = false
    }

    /** True while a full-screen program has the screen; nothing is recorded meanwhile. */
    fun isAltScreen(): Boolean = synchronized(lock) { altScreen }

    /**
     * The whole record written again as terminal output, to be fed to a terminal whose width
     * has changed: erase the screen and its scrollback, write the most recent [maxLines] lines
     * with their colours, then the line being typed with the cursor and colours as the output
     * left them. The terminal wraps the lines at its new width, so nothing the old width cut
     * off is missing and nothing is written twice; at the old width the old layout returns.
     *
     * Returns null when it would not be right: a full-screen program is running, the record
     * was recently disturbed by output it cannot follow, or there is nothing recorded.
     */
    fun replayAll(maxLines: Int = REPLAY_LINES, columns: Int): ByteArray? = synchronized(lock) {
        if (altScreen || columns < 2) return null
        if (lineCounter - taintedAtLine <= TAINT_LINES) return null
        if (lines.isEmpty() && len == 0 && column == 0) return null

        val out = StringBuilder()
        out.append("\u001b[0m\u001b[H\u001b[2J\u001b[3J")
        for (k in maxOf(0, lines.size - maxLines) until lines.size) out.append(lines[k]).append("\r\n")
        // The line being typed, whole: the blanks after a prompt matter, they are where the cursor is.
        out.append(styledRange(0, len))
        // Put the cursor where it was. Only for a line that fits on one row: moving across a wrap is not reliable.
        if (maxOf(len, column) < columns) {
            if (column < len) out.append("\u001b[").append(len - column).append('D')
            else if (column > len) out.append("\u001b[").append(column - len).append('C')
        }
        out.append(sgrSequence(styleCodes[styleNow]))
        out.toString().toByteArray(Charsets.UTF_8)
    }

    // ------------------------------------------------------------------ decoding

    private fun emit(code: Int) {
        val cp = if (code > 0x10FFFF || code in 0xD800..0xDFFF) REPLACEMENT else code
        if (cp > 0xFFFF) {
            feed(Character.highSurrogate(cp))
            feed(Character.lowSurrogate(cp))
        } else {
            feed(cp.toChar())
        }
    }

    private fun feed(c: Char) {
        when (mode) {
            Mode.TEXT -> text(c)
            Mode.ESC -> when (c) {
                '[' -> { mode = Mode.CSI; params.setLength(0) }
                ']', 'P', '^', '_', 'X' -> mode = Mode.STRING
                '(', ')', '*', '+', '#', '%' -> mode = Mode.SKIP_ONE
                'c' -> { fullReset(); mode = Mode.TEXT }
                '7', '8', 'D', 'E', 'M' -> { taint(); mode = Mode.TEXT }
                else -> mode = Mode.TEXT
            }
            Mode.SKIP_ONE -> mode = Mode.TEXT
            Mode.CSI -> when (c) {
                in '\u0020'..'\u003F' -> if (params.length < 32) params.append(c)
                in '\u0040'..'\u007E' -> { csi(c); mode = Mode.TEXT }
                else -> mode = Mode.TEXT
            }
            Mode.STRING -> when (c) {
                '\u0007' -> mode = Mode.TEXT
                '\u001b' -> mode = Mode.STRING_ESC
            }
            Mode.STRING_ESC -> mode = if (c == '\\') Mode.TEXT else Mode.STRING
        }
    }

    private fun text(c: Char) {
        when {
            c == '\u001b' -> mode = Mode.ESC
            altScreen -> Unit // a full-screen program is drawing; not part of the record
            c == '\n' -> { homePending = false; commitLine() }
            c == '\r' -> column = 0
            c == '\b' -> if (column > 0) column--
            c == '\t' -> {
                val next = (column / TAB + 1) * TAB
                while (column < next) put(' ')
            }
            c < ' ' || c == '\u007f' -> Unit
            else -> { homePending = false; put(c) }
        }
    }

    private fun put(c: Char) {
        if (column >= MAX_LINE) commitLine()
        ensure(column + 1)
        while (len < column) { cc[len] = ' '; cs[len] = 0; len++ }
        if (column < len) {
            cc[column] = c; cs[column] = styleNow
        } else {
            cc[len] = c; cs[len] = styleNow; len++
        }
        column++
    }

    private fun ensure(n: Int) {
        if (n > cc.size) {
            val size = maxOf(n, cc.size * 2)
            cc = cc.copyOf(size)
            cs = cs.copyOf(size)
        }
    }

    // ------------------------------------------------------------------ escape sequences

    private fun csi(final: Char) {
        val p = params.toString()
        if (p.startsWith("?")) {
            if (final == 'h' || final == 'l') privateMode(p, final == 'h')
            return
        }
        if (p.startsWith(">") || p.startsWith("<") || p.startsWith("=")) return
        if (altScreen) return // full-screen drawing: only the mode switches above matter
        val n = p.substringBefore(';').toIntOrNull()
        if (final != 'H' && final != 'J') homePending = false
        when (final) {
            'm' -> applySgr(p)
            'K' -> when (n ?: 0) {
                0 -> if (column < len) len = column
                1 -> for (i in 0 until minOf(column + 1, len)) { cc[i] = ' '; cs[i] = 0 }
                2 -> len = 0
            }
            'C' -> column += (n ?: 1).coerceIn(1, 500)
            'D' -> column = (column - (n ?: 1).coerceIn(1, 500)).coerceAtLeast(0)
            'G' -> column = ((n ?: 1) - 1).coerceIn(0, 500)
            'P' -> {
                val count = (n ?: 1).coerceAtLeast(1)
                if (column < len) {
                    val gone = minOf(count, len - column)
                    System.arraycopy(cc, column + gone, cc, column, len - column - gone)
                    System.arraycopy(cs, column + gone, cs, column, len - column - gone)
                    len -= gone
                }
            }
            '@' -> {
                val count = (n ?: 1).coerceIn(1, 500)
                ensure(maxOf(len, column) + count)
                while (len < column) { cc[len] = ' '; cs[len] = 0; len++ }
                System.arraycopy(cc, column, cc, column + count, len - column)
                System.arraycopy(cs, column, cs, column + count, len - column)
                for (k in 0 until count) { cc[column + k] = ' '; cs[column + k] = 0 }
                len += count
            }
            'H', 'f' -> {
                val home = p.isEmpty() || p == "1" || p == "1;1" || p == ";" || p == "1;"
                if (home) homePending = true else { homePending = false; taint() }
            }
            'J' -> {
                // 2 = whole screen, 3 = screen and scrollback; 0 right after a cursor-home is how
                // terminfo entries such as `linux` spell "clear".
                val what = n ?: 0
                if (what == 2 || what == 3 || (what == 0 && homePending)) {
                    clearAll()
                    clearEnd = offsetAfterChar
                    chunkFlags = chunkFlags or FULL_CLEAR
                }
                homePending = false
            }
            // Moves and edits that only a screen model could follow.
            'r', 'L', 'M', 'S', 'T', 'd', 'E', 'F', 's', 'u' -> taint()
        }
    }

    private fun privateMode(p: String, set: Boolean) {
        for (part in p.substring(1).split(';')) {
            when (part.toIntOrNull()) {
                47, 1047, 1049 -> {
                    if (altScreen != set) {
                        altScreen = set
                        if (set) homePending = false else chunkFlags = chunkFlags or ALT_LEFT
                    }
                }
            }
        }
    }

    /** Output the line model cannot follow on the normal screen (full-screen programs are not recorded at all). */
    private fun taint() {
        if (!altScreen) taintedAtLine = lineCounter
    }

    /** Colours and attributes: `ESC [ ... m`. */
    private fun applySgr(p: String) {
        val list = if (p.isEmpty()) listOf(0) else p.replace(':', ';').split(';').map { it.toIntOrNull() ?: 0 }
        var i = 0
        while (i < list.size) {
            val n = list[i]
            when (n) {
                0 -> sgr.reset()
                1 -> sgr.bold = true
                2 -> sgr.dim = true
                3 -> sgr.italic = true
                4 -> sgr.underline = true
                5, 6 -> sgr.blink = true
                7 -> sgr.inverse = true
                8 -> sgr.hidden = true
                9 -> sgr.strike = true
                22 -> { sgr.bold = false; sgr.dim = false }
                23 -> sgr.italic = false
                24 -> sgr.underline = false
                25 -> sgr.blink = false
                27 -> sgr.inverse = false
                28 -> sgr.hidden = false
                29 -> sgr.strike = false
                in 30..37, in 90..97 -> sgr.fg = n.toString()
                39 -> sgr.fg = null
                in 40..47, in 100..107 -> sgr.bg = n.toString()
                49 -> sgr.bg = null
                38, 48 -> {
                    val kind = list.getOrNull(i + 1)
                    if (kind == 5 && i + 2 < list.size) {
                        val code = "$n;5;${list[i + 2]}"
                        if (n == 38) sgr.fg = code else sgr.bg = code
                        i += 2
                    } else if (kind == 2 && i + 4 < list.size) {
                        val code = "$n;2;${list[i + 2]};${list[i + 3]};${list[i + 4]}"
                        if (n == 38) sgr.fg = code else sgr.bg = code
                        i += 4
                    } else {
                        i = list.size
                    }
                }
            }
            i++
        }
        styleNow = idFor(sgr.code())
    }

    private fun idFor(code: String): Int {
        if (code.isEmpty()) return 0
        styleIds[code]?.let { return it }
        if (styleCodes.size >= MAX_STYLES) return 0
        styleCodes.add(code)
        val id = styleCodes.size - 1
        styleIds[code] = id
        return id
    }

    // ------------------------------------------------------------------ lines

    private fun commitLine() {
        val line = styledRange(0, currentEnd())
        lines.addLast(line)
        lineCounter++
        storedChars += line.length + 1
        len = 0
        column = 0
        while (storedChars > maxChars && lines.size > 1) {
            storedChars -= lines.removeFirst().length + 1
        }
    }

    /** Length of the current line without trailing blanks. */
    private fun currentEnd(): Int {
        var end = len
        while (end > 0 && cc[end - 1].isWhitespace()) end--
        return end
    }

    private fun trimmedCurrent(): String = String(cc, 0, currentEnd())

    /** The current line's characters from [from] to [to) with their colours as `ESC [ ... m` runs. */
    private fun styledRange(from: Int, to: Int): String {
        val out = StringBuilder(to - from + 16)
        var last = 0
        for (k in from until to) {
            if (cs[k] != last) {
                last = cs[k]
                out.append(sgrSequence(styleCodes[last]))
            }
            out.append(cc[k])
        }
        if (last != 0) out.append("\u001b[0m")
        return out.toString()
    }

    private fun sgrSequence(code: String): String =
        if (code.isEmpty()) "\u001b[0m" else "\u001b[0;$code" + "m"

    /** A finished line without its colour runs. */
    private fun plain(line: String): String {
        if (line.indexOf('\u001b') < 0) return line
        val out = StringBuilder(line.length)
        var k = 0
        while (k < line.length) {
            val c = line[k]
            if (c == '\u001b') {
                while (k < line.length && line[k] != 'm') k++
            } else {
                out.append(c)
            }
            k++
        }
        return out.toString()
    }

    private fun plainLength(line: String): Int = if (line.indexOf('\u001b') < 0) line.length else plain(line).length

    private fun rowsFor(width: Int, columns: Int): Int = if (width <= columns) 1 else (width + columns - 1) / columns

    /** The screen was cleared: what was recorded is gone, what comes next starts from zero. */
    private fun clearAll() {
        lines.clear()
        storedChars = 0
        len = 0
        column = 0
        homePending = false
        taintedAtLine = Long.MIN_VALUE / 2
    }

    /** ESC c: the terminal returns to its power-on state. */
    private fun fullReset() {
        clearAll()
        altScreen = false
        sgr.reset()
        styleNow = 0
        clearEnd = offsetAfterChar
        chunkFlags = chunkFlags or FULL_CLEAR
    }

    private class Sgr {
        var bold = false
        var dim = false
        var italic = false
        var underline = false
        var blink = false
        var inverse = false
        var hidden = false
        var strike = false
        var fg: String? = null
        var bg: String? = null

        fun reset() {
            bold = false; dim = false; italic = false; underline = false
            blink = false; inverse = false; hidden = false; strike = false
            fg = null; bg = null
        }

        /** Parameters for `ESC [ 0 ; <this> m`, empty when everything is at its default. */
        fun code(): String {
            val parts = ArrayList<String>(6)
            if (bold) parts.add("1")
            if (dim) parts.add("2")
            if (italic) parts.add("3")
            if (underline) parts.add("4")
            if (blink) parts.add("5")
            if (inverse) parts.add("7")
            if (hidden) parts.add("8")
            if (strike) parts.add("9")
            fg?.let { parts.add(it) }
            bg?.let { parts.add(it) }
            return parts.joinToString(";")
        }
    }

    companion object {
        const val DEFAULT_MAX_CHARS = 4_000_000

        /** [append] result: the screen was cleared by this chunk (see [lastClearEnd]). */
        const val FULL_CLEAR = 1

        /** [append] result: a full-screen program ended in this chunk. */
        const val ALT_LEFT = 2

        private const val TAB = 8
        private const val MAX_LINE = 65_536
        private const val MAX_STYLES = 4096
        private const val REPLACEMENT = 0xFFFD

        /** Most recent lines [replayAll] writes by default (the terminal's own scrollback is of this order). */
        const val REPLAY_LINES = 5_000

        /** Lines after output the model cannot follow during which [replayAll] declines. */
        private const val TAINT_LINES = 300
    }
}
