package app.terminalssh.secure.viewer

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.UUID

/**
 * Search inside the rendered page, using the WebView's own find: every match is highlighted and
 * [step] scrolls to the next or previous one. The page's WebView attaches itself; this object
 * only holds the counts for the find bar.
 */
internal class ViewerFind {
    private var web: WebView? = null
    private var query: String = ""

    /** Matches found, and the 1-based number of the one in view (0 when there is none). */
    var total by mutableIntStateOf(0)
        private set
    var current by mutableIntStateOf(0)
        private set

    fun attach(view: WebView) {
        web = view
        view.setFindListener { active, count, _ ->
            total = count
            current = if (count == 0) 0 else active + 1
        }
    }

    fun detach(view: WebView) {
        if (web === view) {
            view.setFindListener(null)
            web = null
        }
    }

    fun search(text: String) {
        query = text
        val view = web ?: return
        if (text.isEmpty()) {
            view.clearMatches()
            total = 0
            current = 0
        } else {
            view.findAllAsync(text)
        }
    }

    /** Looks again after the page was rebuilt (switching view mode), keeping the same text. */
    fun rerun() {
        if (query.isNotEmpty()) web?.findAllAsync(query)
    }

    fun step(forward: Boolean) {
        web?.findNext(forward)
    }

    fun clear() {
        query = ""
        web?.clearMatches()
        total = 0
        current = 0
    }
}

/**
 * The rendered view of a file. The WebView stays alive while the person looks at the source,
 * so coming back to the Viewer keeps the scroll position (the page is only rebuilt when the
 * text actually changed). While [visible] is false it is hidden and does no rendering work.
 *
 * Locked down on purpose: it runs on remote file content. No network loads, no file or
 * content access, no storage; links open in the system browser only when tapped.
 */
@Composable
internal fun ViewerPane(
    kind: ViewerKind,
    text: String?,
    bytes: ByteArray?,
    visible: Boolean,
    dark: Boolean,
    modifier: Modifier = Modifier,
    desktop: Boolean = false,
    find: ViewerFind? = null,
) {
    val context = LocalContext.current
    // One nonce per pane keeps the page string identical for identical content, so an
    // unchanged document is never reloaded (which would reset its scroll position).
    val nonce = remember { UUID.randomUUID().toString().replace("-", "") }
    val page by produceState<String?>(initialValue = null, kind, text, bytes, dark, visible, desktop) {
        if (!visible) return@produceState // keep what is there; render when it is shown again
        value = withContext(Dispatchers.Default) {
            ViewerRenderer.page(ViewerRenderer.body(kind, text, bytes), dark, ViewerRenderer.assets(context), nonce, desktop)
        }
    }
    val bg = if (dark) 0xFF0D1117.toInt() else 0xFFFFFFFF.toInt()

    AndroidView(
        modifier = modifier.fillMaxSize(),
        factory = { ctx ->
            WebView(ctx).apply {
                settings.javaScriptEnabled = true // highlighting and the copy buttons; other scripts are blocked by the CSP
                addJavascriptInterface(CopyBridge(ctx.applicationContext), "AppClipboard")
                settings.allowFileAccess = false
                settings.allowContentAccess = false
                settings.domStorageEnabled = false
                settings.blockNetworkLoads = true
                settings.setSupportMultipleWindows(false)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) settings.safeBrowsingEnabled = false
                // Two-finger pinch zoom, no on-screen buttons.
                settings.useWideViewPort = true
                // Desktop View declares a wide viewport; open it scaled down to fit the screen.
                settings.loadWithOverviewMode = true
                settings.setSupportZoom(true)
                settings.builtInZoomControls = true
                settings.displayZoomControls = false
                find?.attach(this)
                webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView, url: String?) {
                        find?.rerun()
                    }

                    // A page that kills its renderer (a huge image) must not take the app with it.
                    override fun onRenderProcessGone(view: WebView, detail: android.webkit.RenderProcessGoneDetail): Boolean = true

                    override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                        val url: Uri = request.url
                        if (url.scheme.orEmpty() in setOf("http", "https", "mailto") && request.hasGesture()) {
                            try {
                                ctx.startActivity(Intent(Intent.ACTION_VIEW, url).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            } catch (_: Exception) {
                            }
                        }
                        return true // never navigate inside the viewer
                    }
                }
            }
        },
        update = { web ->
            web.setBackgroundColor(bg)
            web.visibility = if (visible) View.VISIBLE else View.INVISIBLE
            val p = page
            if (p != null && web.tag != p) {
                web.tag = p
                web.loadDataWithBaseURL("https://viewer.invalid/", p, "text/html", "utf-8", null)
            }
        },
        onRelease = {
            find?.detach(it)
            it.destroy()
        },
    )
}

/**
 * What the page's copy buttons call. It can only put text on the clipboard: nothing is read back,
 * and only the page's own (nonce'd) script can reach it - the CSP blocks every other script.
 */
private class CopyBridge(private val context: Context) {
    @JavascriptInterface
    fun copy(text: String?): Boolean {
        // The system clipboard refuses very large clips; say so and let the page try its own way.
        if (text.isNullOrEmpty() || text.length > MAX_COPY_CHARS) return false
        return runCatching {
            val manager = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            manager.setPrimaryClip(ClipData.newPlainText("code", text))
            true
        }.getOrDefault(false)
    }

    private companion object {
        const val MAX_COPY_CHARS = 400_000
    }
}
