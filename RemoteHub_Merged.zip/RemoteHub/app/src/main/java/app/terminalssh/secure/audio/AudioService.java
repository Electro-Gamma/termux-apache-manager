package app.terminalssh.secure.audio;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

import java.util.concurrent.CopyOnWriteArrayList;

/** Foreground service that owns the {@link AudioBridge}, so the microphone and speaker keep working while the app is in the
 *  background, with a notification that says so and offers Mute and Stop. Start it only while the app is visible: Android 14
 *  does not allow a microphone service to be started from the background. */
public final class AudioService extends Service {
    private static final String ACTION_START = "vab.audio.START", ACTION_MUTE = "vab.audio.MUTE", ACTION_STOP = "vab.audio.STOP";
    private static final String CHANNEL = "audio_bridge";
    private static final int NOTIFICATION_ID = 1002;

    public interface Observer { void onAudioChanged(); }

    private static final CopyOnWriteArrayList<Observer> observers = new CopyOnWriteArrayList<>();
    private static volatile AudioBridge bridge;
    private static volatile AudioBridge.State lastState = AudioBridge.State.IDLE;
    private static volatile String lastMessage = "";
    private static volatile boolean muted;

    private final Handler main = new Handler(Looper.getMainLooper());
    private PowerManager.WakeLock wakeLock;
    private WifiManager.WifiLock wifiLock;
    private ConnectivityManager.NetworkCallback networkCallback;
    private Network network;
    private int lastStartId;

    // ---- app-facing API ----

    /** Starts, or restarts with new settings. Call from a visible activity, after RECORD_AUDIO is granted if cfg.mic. */
    public static void start(Context context, AudioBridge.Config cfg) {
        Intent i = new Intent(context, AudioService.class).setAction(ACTION_START)
            .putExtra("host", cfg.host).putExtra("port", cfg.port).putExtra("pass", cfg.passphrase)
            .putExtra("playback", cfg.playback).putExtra("mic", cfg.mic)
            .putExtra("playRate", cfg.playRate).putExtra("playCh", cfg.playChannels)
            .putExtra("micRate", cfg.micRate).putExtra("micCh", cfg.micChannels)
            .putExtra("voice", cfg.voiceProcessing).putExtra("buffer", cfg.playBufferMs);
        if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i); else context.startService(i);
    }

    /** Delivered as a command so that it queues behind a start that has not run yet (stopping a service before it has
     *  called startForeground would crash the app). */
    public static void stop(Context context) {
        try { context.startService(new Intent(context, AudioService.class).setAction(ACTION_STOP)); }
        catch (RuntimeException e) { AudioBridge b = bridge; if (b != null) b.stop(); }
    }

    public static AudioBridge current() { return bridge; }
    public static AudioBridge.State state() { return lastState; }
    public static String message() { return lastMessage; }
    public static boolean isMuted() { return muted; }

    public static void setMuted(boolean value) {
        muted = value;
        AudioBridge b = bridge;
        if (b != null) b.setMicMuted(value);
        changed();
    }

    /** Observers are called on arbitrary threads. */
    public static void addObserver(Observer o) { observers.addIfAbsent(o); }
    public static void removeObserver(Observer o) { observers.remove(o); }
    private static void changed() { for (Observer o : observers) o.onAudioChanged(); }

    // ---- service ----

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        lastStartId = startId;
        String action = intent == null ? null : intent.getAction();
        if (ACTION_START.equals(action)) begin(intent);
        else if (ACTION_MUTE.equals(action)) { setMuted(!muted); refreshNotification(); }
        else { shutDown(AudioBridge.State.STOPPED, "Audio: off"); }
        return START_NOT_STICKY;                 // Android would not let a restarted process reopen the microphone
    }

    private void begin(Intent i) {
        AudioBridge.Config c = new AudioBridge.Config();
        c.host = i.getStringExtra("host"); c.port = i.getIntExtra("port", 5950); c.passphrase = i.getStringExtra("pass");
        c.playback = i.getBooleanExtra("playback", true); c.mic = i.getBooleanExtra("mic", true);
        c.playRate = i.getIntExtra("playRate", 48000); c.playChannels = i.getIntExtra("playCh", 2);
        c.micRate = i.getIntExtra("micRate", 16000); c.micChannels = i.getIntExtra("micCh", 1);
        c.voiceProcessing = i.getBooleanExtra("voice", true); c.playBufferMs = i.getIntExtra("buffer", 300);

        AudioBridge old = bridge;
        bridge = null;                           // its late callbacks are ignored from here on
        if (old != null) old.stop();
        if (!c.mic) muted = false;

        final AudioBridge[] self = new AudioBridge[1];
        self[0] = new AudioBridge(c, text -> main.post(() -> onBridgeState(self[0])));
        self[0].setMicMuted(muted);
        bridge = self[0];
        lastState = AudioBridge.State.CONNECTING; lastMessage = "Audio: connecting…";
        try {
            goForeground(c);                     // must happen even if there is nothing to do
        } catch (RuntimeException e) {           // SecurityException: permission missing or started from the background
            // The system still requires one successful startForeground after startForegroundService.
            try { if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, notification(c), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK); }
            catch (RuntimeException ignored) { }
            shutDown(AudioBridge.State.FAILED, "Audio: Android refused to start the audio service (" + e.getMessage() + ")");
            return;
        }
        if (!c.mic && !c.playback) { shutDown(AudioBridge.State.STOPPED, "Audio: off"); return; }
        acquireLocks();
        watchNetwork();
        self[0].start();
        changed();
    }

    private void onBridgeState(AudioBridge b) {
        if (b == null || b != bridge) return;
        AudioBridge.State s = b.state();
        lastState = s; lastMessage = b.message();
        if (s == AudioBridge.State.FAILED || s == AudioBridge.State.STOPPED) shutDown(s, b.message());
        else { refreshNotification(); changed(); }
    }

    private void shutDown(AudioBridge.State s, String text) {
        AudioBridge b = bridge;
        bridge = null;
        if (b != null) b.stop();
        muted = false;
        lastState = s; lastMessage = text;
        stopForeground(true);
        stopSelfResult(lastStartId);             // keeps the service if a newer start is already queued
        changed();
    }

    @Override public void onDestroy() {
        AudioBridge b = bridge;
        if (b != null) {                         // destroyed from outside (stopService, or the system)
            bridge = null; b.stop(); muted = false;
            lastState = AudioBridge.State.STOPPED; lastMessage = "Audio: off";
        }
        if (networkCallback != null) {
            try { getSystemService(ConnectivityManager.class).unregisterNetworkCallback(networkCallback); } catch (RuntimeException ignored) { }
            networkCallback = null;
        }
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        if (wifiLock != null && wifiLock.isHeld()) wifiLock.release();
        changed();
        super.onDestroy();
    }

    @SuppressWarnings({"deprecation", "WakelockTimeout"})
    private void acquireLocks() {
        if (wakeLock == null) {
            wakeLock = ((PowerManager) getSystemService(POWER_SERVICE)).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "vab:audio");
            wakeLock.setReferenceCounted(false);
        }
        wakeLock.acquire(12L * 60 * 60 * 1000);
        if (wifiLock == null) {
            WifiManager wifi = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
            if (wifi == null) return;
            int mode = Build.VERSION.SDK_INT >= 29 ? WifiManager.WIFI_MODE_FULL_LOW_LATENCY : WifiManager.WIFI_MODE_FULL_HIGH_PERF;
            wifiLock = wifi.createWifiLock(mode, "vab:audio");
            wifiLock.setReferenceCounted(false);
        }
        wifiLock.acquire();
    }

    private void watchNetwork() {
        if (networkCallback != null || Build.VERSION.SDK_INT < 24) return;
        networkCallback = new ConnectivityManager.NetworkCallback() {
            @Override public void onAvailable(Network n) {
                boolean switched = network != null && !network.equals(n);
                network = n;
                AudioBridge b = bridge;
                // The first report is just the current network; later ones are a switch or a return after loss.
                if (switched && b != null) b.reconnectNow();
            }
        };
        try { getSystemService(ConnectivityManager.class).registerDefaultNetworkCallback(networkCallback); }
        catch (RuntimeException e) { networkCallback = null; }
    }

    private void goForeground(AudioBridge.Config c) {
        Notification n = notification(c);
        int types = 0;
        if (Build.VERSION.SDK_INT >= 30 && c.mic) types |= ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE;
        if (Build.VERSION.SDK_INT >= 29 && c.playback) types |= ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK;
        if (types != 0) startForeground(NOTIFICATION_ID, n, types); else startForeground(NOTIFICATION_ID, n);
    }

    private void refreshNotification() {
        AudioBridge b = bridge;
        if (b != null) getSystemService(NotificationManager.class).notify(NOTIFICATION_ID, notification(b.config()));
    }

    @SuppressWarnings("deprecation")
    private Notification notification(AudioBridge.Config c) {
        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager m = getSystemService(NotificationManager.class);
            if (m.getNotificationChannel(CHANNEL) == null)
                m.createNotificationChannel(new NotificationChannel(CHANNEL, "Audio bridge", NotificationManager.IMPORTANCE_LOW));
            builder = new Notification.Builder(this, CHANNEL);
        } else {
            builder = new Notification.Builder(this);
        }
        String title = c.mic ? (muted ? "Microphone muted" : "Microphone is live") : "Playing computer sound";
        String text = (c.mic && c.playback ? "Microphone and speaker" : c.mic ? "Microphone" : "Speaker") + " · " + c.host
                + (lastState == AudioBridge.State.CONNECTED ? "" : " · " + (lastState == AudioBridge.State.RECONNECTING ? "reconnecting" : "connecting"));
        builder.setSmallIcon(app.terminalssh.secure.R.drawable.ic_stat_session).setContentTitle(title).setContentText(text)
               .setOngoing(true).setOnlyAlertOnce(true);
        Intent open = getPackageManager().getLaunchIntentForPackage(getPackageName());
        if (open != null) builder.setContentIntent(PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE));
        if (c.mic) builder.addAction(action(muted ? "Unmute" : "Mute", ACTION_MUTE, 1));
        builder.addAction(action("Stop audio", ACTION_STOP, 2));
        return builder.build();
    }

    @SuppressWarnings("deprecation")
    private Notification.Action action(String label, String what, int request) {
        PendingIntent p = PendingIntent.getService(this, request, new Intent(this, AudioService.class).setAction(what), PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Action.Builder(0, label, p).build();
    }
}
