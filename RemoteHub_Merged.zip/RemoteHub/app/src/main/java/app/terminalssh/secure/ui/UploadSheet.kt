package app.terminalssh.secure.ui

import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.CreateNewFolder
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material.icons.outlined.InsertDriveFile
import androidx.compose.material.icons.outlined.NoteAdd
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material.icons.outlined.UploadFile
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.terminalssh.secure.R
import app.terminalssh.secure.sftp.SftpController
import app.terminalssh.secure.ui.theme.TextSecondary
import app.terminalssh.secure.ui.theme.Turquoise

/**
 * What the "+" button opens: a row of icons for the ways to add things, instead of one file
 * picker. Files, whole folders and photos/videos can each be picked any number of times; what
 * was picked collects in a list below, and one button uploads it all together.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UploadSheet(
    destination: String,
    displayNameFor: (Uri) -> String,
    onDismiss: () -> Unit,
    onUpload: (List<SftpController.UploadItem>) -> Unit,
    onNewFolder: () -> Unit,
    onNewFile: () -> Unit,
) {
    val context = LocalContext.current
    val staged = remember { mutableStateListOf<SftpController.UploadItem>() }

    fun addFile(uri: Uri) {
        if (staged.none { !it.isFolder && it.uri == uri }) {
            staged.add(SftpController.UploadItem(uri, displayNameFor(uri), isFolder = false))
        }
    }

    fun keepAccess(uri: Uri) {
        // The upload outlives this sheet (and maybe the screen), so ask to keep reading it.
        runCatching {
            context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    val filesPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach { keepAccess(it); addFile(it) }
    }
    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null && staged.none { it.isFolder && it.uri == uri }) {
            keepAccess(uri)
            val id = runCatching { DocumentsContract.getTreeDocumentId(uri) }.getOrDefault("")
            val name = id.substringAfterLast('/').substringAfterLast(':').ifBlank { "folder" }
            staged.add(SftpController.UploadItem(uri, name, isFolder = true))
        }
    }
    val mediaPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia()) { uris ->
        uris.forEach { addFile(it) }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MaterialTheme.colorScheme.surface,
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 16.dp)
                .padding(bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(stringResource(R.string.upload_title), style = MaterialTheme.typography.titleMedium)
            Text(
                ltr(destination),
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )

            val tiles = listOf(
                Tile(Icons.Outlined.UploadFile, stringResource(R.string.upload_files)) {
                    filesPicker.launch(arrayOf("*/*"))
                },
                Tile(Icons.Outlined.FolderOpen, stringResource(R.string.upload_folder)) {
                    folderPicker.launch(null)
                },
                Tile(Icons.Outlined.PhotoLibrary, stringResource(R.string.upload_media)) {
                    mediaPicker.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo),
                    )
                },
                Tile(Icons.Outlined.CreateNewFolder, stringResource(R.string.sftp_menu_new_folder)) {
                    onDismiss()
                    onNewFolder()
                },
                Tile(Icons.Outlined.NoteAdd, stringResource(R.string.sftp_menu_new_file)) {
                    onDismiss()
                    onNewFile()
                },
            )
            tiles.chunked(3).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    row.forEach { tile -> TileButton(tile, Modifier.weight(1f)) }
                    // Keeps the last row's tiles the same width as the others.
                    repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }

            if (staged.isNotEmpty()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        stringResource(R.string.upload_selected, staged.size),
                        style = MaterialTheme.typography.labelLarge,
                        modifier = Modifier.weight(1f),
                    )
                    TextButton(onClick = { staged.clear() }) {
                        Text(stringResource(R.string.upload_clear), color = TextSecondary)
                    }
                }
                Column(
                    Modifier
                        .fillMaxWidth()
                        .heightIn(max = 220.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .verticalScroll(rememberScrollState()),
                ) {
                    staged.toList().forEach { item ->
                        Row(
                            Modifier.fillMaxWidth().padding(start = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(
                                if (item.isFolder) Icons.Outlined.Folder else Icons.Outlined.InsertDriveFile,
                                contentDescription = null,
                                tint = if (item.isFolder) Turquoise else TextSecondary,
                                modifier = Modifier.size(20.dp),
                            )
                            Spacer(Modifier.width(10.dp))
                            Text(
                                ltr(item.name),
                                style = MaterialTheme.typography.bodyMedium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f),
                            )
                            IconButton(onClick = { staged.remove(item) }, modifier = Modifier.size(40.dp)) {
                                Icon(
                                    Icons.Outlined.Close,
                                    contentDescription = stringResource(R.string.upload_remove),
                                    tint = TextSecondary,
                                    modifier = Modifier.size(18.dp),
                                )
                            }
                        }
                    }
                }
                Button(
                    onClick = {
                        onUpload(staged.toList())
                        onDismiss()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Turquoise,
                        contentColor = MaterialTheme.colorScheme.onPrimary,
                    ),
                ) {
                    Text(stringResource(R.string.upload_action, staged.size))
                }
            }
        }
    }
}

private class Tile(val icon: ImageVector, val label: String, val onClick: () -> Unit)

@Composable
private fun TileButton(tile: Tile, modifier: Modifier) {
    Column(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = tile.onClick)
            .padding(vertical = 14.dp, horizontal = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Box(
            Modifier.size(44.dp).clip(CircleShape).background(Turquoise.copy(alpha = 0.16f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(tile.icon, contentDescription = null, tint = Turquoise)
        }
        Text(
            tile.label,
            style = MaterialTheme.typography.labelMedium,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
    }
}
