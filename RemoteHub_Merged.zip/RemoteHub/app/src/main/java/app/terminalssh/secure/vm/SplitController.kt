package app.terminalssh.secure.vm

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * Which two sessions share the screen, and how tall the top one is.
 *
 * One controller exists for the Terminal tab and one for the Files tab. It only holds ids: the
 * sessions themselves stay in their registries, so splitting, resizing or un-splitting never
 * touches a connection. The two panes can never show the same session (a terminal view cannot
 * be drawn twice), which [setTop] and [setBottom] enforce by swapping.
 */
data class SplitLayout(
    val enabled: Boolean = false,
    val topId: String? = null,
    val bottomId: String? = null,
    /** Share of the height given to the top pane. */
    val fraction: Float = 0.5f,
    /** The pane that receives the key bar and Back; set by touching a pane. */
    val bottomFocused: Boolean = false,
) {
    val focusedId: String? get() = if (bottomFocused) bottomId else topId
}

class SplitController {
    private val _layout = MutableStateFlow(SplitLayout())
    val layout: StateFlow<SplitLayout> = _layout.asStateFlow()

    fun enable(topId: String, bottomId: String) {
        if (topId == bottomId) return
        _layout.update { it.copy(enabled = true, topId = topId, bottomId = bottomId, bottomFocused = false) }
    }

    fun disable() {
        _layout.update { it.copy(enabled = false) }
    }

    fun setTop(id: String) = _layout.update {
        if (id == it.topId) it
        else if (id == it.bottomId) it.copy(topId = id, bottomId = it.topId)
        else it.copy(topId = id)
    }

    fun setBottom(id: String) = _layout.update {
        if (id == it.bottomId) it
        else if (id == it.topId) it.copy(bottomId = id, topId = it.bottomId)
        else it.copy(bottomId = id)
    }

    fun swap() = _layout.update {
        it.copy(topId = it.bottomId, bottomId = it.topId, bottomFocused = !it.bottomFocused)
    }

    fun setFraction(value: Float) = _layout.update { it.copy(fraction = value.coerceIn(MIN_FRACTION, MAX_FRACTION)) }

    fun focus(bottom: Boolean) = _layout.update { if (it.bottomFocused == bottom) it else it.copy(bottomFocused = bottom) }

    /**
     * Called whenever the set of open sessions changes: a pane whose session was closed is
     * given another open one, and when fewer than two sessions remain the split ends.
     */
    fun reconcile(openIds: List<String>) = _layout.update { current ->
        if (!current.enabled) return@update current
        if (openIds.size < 2) return@update current.copy(enabled = false)
        var top = current.topId?.takeIf { it in openIds }
        var bottom = current.bottomId?.takeIf { it in openIds }
        if (top == null) top = openIds.firstOrNull { it != bottom }
        if (bottom == null) bottom = openIds.firstOrNull { it != top }
        if (top == null || bottom == null || top == bottom) current.copy(enabled = false)
        else current.copy(topId = top, bottomId = bottom)
    }

    companion object {
        const val MIN_FRACTION = 0.18f
        const val MAX_FRACTION = 0.82f
    }
}
