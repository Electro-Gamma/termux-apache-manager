package app.terminalssh.secure.ssh

import android.content.ContentResolver
import app.terminalssh.secure.sftp.ClipboardHub
import app.terminalssh.secure.sftp.SftpController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * One server's File Manager: its connection plus everything the user has going on in it
 * (current folder, selection, clipboard, transfers, batch operations).
 *
 * It lives in the Application, not in a screen. Leaving the Files tab, minimising the
 * app or recreating the Activity changes nothing here; the folder, the queue and any
 * running transfer carry on, and the screen simply reattaches to them. It ends only
 * through [destroy], which the user triggers by disconnecting.
 */
class FileWorkspace(
    val session: FileSession,
    contentResolver: ContentResolver,
    cacheDir: java.io.File,
    /**
     * Where a File Manager opened by "Open in new tab" starts: a folder, or a file (its parent
     * folder is shown and the file is opened). Null starts in the home folder, as always.
     */
    private val start: StartLocation? = null,
) {
    /** A folder to open, plus optionally a file inside it to open as well. */
    class StartLocation(val folder: String, val file: app.terminalssh.secure.sftp.RemoteEntry? = null)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    val controller = SftpController(session, contentResolver, scope, cacheDir, hostLabel = { session.title })

    val id: String get() = session.id
    val profile get() = session.profile

    init {
        scope.launch {
            var loadedOnce = false
            session.state.collect { state ->
                if (state is SshSessionState.Connected) {
                    if (!loadedOnce) {
                        loadedOnce = true
                        val where = start
                        if (where == null) {
                            controller.openHome()
                        } else {
                            controller.openStart(where.folder, where.file)
                        }
                    } else {
                        // Back after a drop: stay in the same folder and refresh it.
                        controller.refresh()
                    }
                }
            }
        }
    }

    fun destroy() {
        // Anything copied from this host can no longer be read once it is gone.
        ClipboardHub.dropSource(session)
        controller.close()
        session.destroy()
        scope.cancel()
    }
}
