package app.terminalssh.secure.ui

import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.PressInteraction
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Terminal
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Add
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import org.connectbot.terminal.SelectionController
import org.connectbot.terminal.SelectionMode
import androidx.compose.material.icons.outlined.HorizontalSplit
import androidx.compose.material3.IconButton
import androidx.compose.material3.HorizontalDivider
import app.terminalssh.secure.ssh.SshSession
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.onClick as semanticsOnClick
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.key
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.unit.sp
import app.terminalssh.secure.settings.SettingsRegistry
import app.terminalssh.secure.ui.theme.terminalPalette
import app.terminalssh.secure.ui.theme.Danger
import app.terminalssh.secure.R
import app.terminalssh.secure.serial.SerialSession
import app.terminalssh.secure.ssh.TerminalSession
import app.terminalssh.secure.ssh.SshSessionState
import app.terminalssh.secure.ui.theme.Stroke
import app.terminalssh.secure.ui.theme.TextSecondary
import app.terminalssh.secure.ui.theme.Turquoise
import app.terminalssh.secure.vm.AppViewModel
import kotlinx.coroutines.launch
import org.connectbot.terminal.Terminal

@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
fun TerminalScreen(viewModel: AppViewModel, onGoToHosts: () -> Unit) {
    val sessions by viewModel.sessions.sessions.collectAsStateWithLifecycle()
    val activeId by viewModel.sessions.activeId.collectAsStateWithLifecycle()
    val split by viewModel.terminalSplit.layout.collectAsStateWithLifecycle()
    val active = sessions.firstOrNull { it.id == activeId }

    // A pane whose terminal was closed is given another one; with fewer than two left the
    // split simply ends. Nothing here touches a connection.
    LaunchedEffect(sessions) { viewModel.terminalSplit.reconcile(sessions.map { it.id }) }

    if (active == null) {
        androidx.compose.foundation.layout.Box(Modifier.fillMaxSize()) {
        TabEmptyState(
            icon = Icons.Outlined.Terminal,
            title = stringResource(R.string.terminal_empty_title),
            hint = stringResource(R.string.terminal_empty_hint),
        )
        // Same "+" button as the VNC tab; it still just takes you to the Hosts tab.
        androidx.compose.material3.FloatingActionButton(
            onClick = onGoToHosts,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 16.dp, bottom = 16.dp),
        ) {
            Icon(
                androidx.compose.ui.res.painterResource(R.drawable.hm_ic_add),
                contentDescription = stringResource(R.string.tab_hosts),
            )
        }
        }
        return
    }

    // The two sessions of a split, when there is one.
    val topSession = if (split.enabled) sessions.firstOrNull { it.id == split.topId } else null
    val bottomSession = if (split.enabled) sessions.firstOrNull { it.id == split.bottomId } else null
    val panes: Pair<TerminalSession, TerminalSession>? =
        if (topSession != null && bottomSession != null) topSession to bottomSession else null

    // The session the key bar, snippets and "keep screen on" belong to: the focused pane of a
    // split, otherwise the selected tab.
    val focused: TerminalSession = when {
        panes == null -> active
        split.bottomFocused -> panes.second
        else -> panes.first
    }
    // Keep "the selected tab" in step with the focused pane, so ending the split lands on it.
    LaunchedEffect(focused.id, panes != null) {
        if (panes != null && focused.id != activeId) viewModel.sessions.select(focused.id)
    }

    var snippetsOpen by remember(focused.id) { mutableStateOf(false) }
    var confirmCloseId by remember { mutableStateOf<String?>(null) }

    // Everything the user chose in Settings that shapes this screen. Reading the store's
    // revision means a change made in Settings is picked up here without a restart.
    val store = viewModel.settingsStore
    val settingsRevision by store.revision.collectAsStateWithLifecycle()
    val keyHaptics = remember(settingsRevision) { store.get(SettingsRegistry.hapticKeys) }
    val keepScreenOn = remember(settingsRevision) { store.get(SettingsRegistry.keepScreenOn) }
    val confirmCloseRunning = remember(settingsRevision) { store.get(SettingsRegistry.confirmCloseRunning) }
    val appContext = androidx.compose.ui.platform.LocalContext.current
    val rootView = LocalView.current

    // "Keep the screen on", only while the focused session is actually connected.
    val focusedState by focused.state.collectAsStateWithLifecycle()
    DisposableEffect(keepScreenOn, focusedState.isLive) {
        rootView.keepScreenOn = keepScreenOn && focusedState.isLive
        onDispose { rootView.keepScreenOn = false }
    }

    // Each pane registers how to raise the keyboard for its own terminal, so the key bar's
    // keyboard key always reaches the pane that has the focus.
    val keyboardRaisers = remember { HashMap<String, () -> Unit>() }
    val registerKeyboard: (String, (() -> Unit)?) -> Unit = { id, raise ->
        if (raise == null) keyboardRaisers.remove(id) else keyboardRaisers[id] = raise
    }

    // Choosing a session (tab or pane picker) hands it the keyboard: the terminal that was just
    // chosen is built a moment later, so wait until it has registered how to raise its keyboard.
    var raiseFor by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(raiseFor) {
        val id = raiseFor ?: return@LaunchedEffect
        repeat(40) {
            keyboardRaisers[id]?.let { raise ->
                raise()
                raiseFor = null
                return@LaunchedEffect
            }
            delay(50)
        }
        raiseFor = null
    }

    val selectTab: (String) -> Unit = { id ->
        when {
            panes == null -> viewModel.sessions.select(id)
            split.bottomFocused -> viewModel.terminalSplit.setBottom(id)
            else -> viewModel.terminalSplit.setTop(id)
        }
        raiseFor = id
    }

    val toggleSplit: () -> Unit = {
        if (panes != null) {
            viewModel.terminalSplit.disable()
        } else {
            val other = sessions.firstOrNull { it.id != active.id }
            if (other != null) {
                viewModel.terminalSplit.enable(active.id, other.id)
            } else {
                // Only one terminal exists: open a second one to the same server and split with it.
                val created = viewModel.openAnotherSession(active)
                if (created != null) {
                    viewModel.terminalSplit.enable(active.id, created.id)
                } else {
                    viewModel.notify(appContext.getString(R.string.split_need_two))
                }
            }
        }
    }

    // A terminal's title already carries "(2)", "(3)" ... when its server has several.
    val choices = remember(sessions) {
        sessions.map { PaneChoice(it.id, it.title, it.state) }
    }

    // No imePadding here: RootScreen's dock already reserves max(tab bar, keyboard) below
    // this screen, so the toolbar sits flush on the tab bar or on the keyboard. Padding for
    // the keyboard here as well is what used to double-count it and leave a tall empty
    // strip for about a second after the terminal opened.
    Column(Modifier.fillMaxSize()) {
        SessionTabs(
            sessions = sessions,
            activeId = focused.id,
            onSelect = selectTab,
            onClose = { id ->
                val target = sessions.firstOrNull { it.id == id }
                // Closing ends whatever is running in it, so a live session asks first
                // (unless the user turned that off); a dead one just goes.
                if (confirmCloseRunning && target != null && target.state.value.isLive) {
                    confirmCloseId = id
                } else {
                    viewModel.closeSession(id)
                }
            },
            canOpenAnother = focused is SshSession,
            onOpenAnother = {
                if (viewModel.openAnotherSession(focused) == null) {
                    viewModel.notify(appContext.getString(R.string.terminal_new_session_unavailable))
                }
            },
            splitOn = panes != null,
            onToggleSplit = toggleSplit,
        )
        if (panes != null) {
            SplitPanes(
                fraction = split.fraction,
                onFractionChange = viewModel.terminalSplit::setFraction,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                top = {
                    key(panes.first.id) {
                        TerminalPane(
                            viewModel = viewModel,
                            active = panes.first,
                            focused = !split.bottomFocused,
                            showFocusRing = true,
                            onFocus = { viewModel.terminalSplit.focus(false) },
                            registerKeyboard = registerKeyboard,
                            picker = {
                                PanePicker(
                                    choices = choices,
                                    selectedId = panes.first.id,
                                    onSelect = { id ->
                                        viewModel.terminalSplit.setTop(id)
                                        viewModel.terminalSplit.focus(false)
                                        raiseFor = id
                                    },
                                )
                            },
                        )
                    }
                },
                bottom = {
                    key(panes.second.id) {
                        TerminalPane(
                            viewModel = viewModel,
                            active = panes.second,
                            focused = split.bottomFocused,
                            showFocusRing = true,
                            onFocus = { viewModel.terminalSplit.focus(true) },
                            registerKeyboard = registerKeyboard,
                            picker = {
                                PanePicker(
                                    choices = choices,
                                    selectedId = panes.second.id,
                                    onSelect = { id ->
                                        viewModel.terminalSplit.setBottom(id)
                                        viewModel.terminalSplit.focus(true)
                                        raiseFor = id
                                    },
                                )
                            },
                        )
                    }
                },
            )
        } else {
            // key(): every session gets its own terminal view. Reusing one view for whichever
            // session is selected left the previous session's screen bound to a view that was
            // no longer drawing it, which is what made the first terminal look frozen.
            key(active.id) {
                TerminalPane(
                    viewModel = viewModel,
                    active = active,
                    focused = true,
                    showFocusRing = false,
                    onFocus = {},
                    registerKeyboard = registerKeyboard,
                    modifier = Modifier.weight(1f),
                )
            }
        }
        CompositionLocalProvider(LocalKeyHaptics provides keyHaptics) {
        KeyToolbar(
            focused,
            onShowKeyboard = { keyboardRaisers[focused.id]?.invoke() },
            onSnippets = { snippetsOpen = true },
        )
        }
        confirmCloseId?.let { id ->
            AlertDialog(
                onDismissRequest = { confirmCloseId = null },
                title = { Text(stringResource(R.string.terminal_close_confirm_title)) },
                text = { Text(stringResource(R.string.terminal_close_confirm_body)) },
                confirmButton = {
                    TextButton(onClick = {
                        confirmCloseId = null
                        viewModel.closeSession(id)
                    }) { Text(stringResource(R.string.terminal_close_confirm_action), color = Danger) }
                },
                dismissButton = {
                    TextButton(onClick = { confirmCloseId = null }) { Text(stringResource(R.string.cancel)) }
                },
                containerColor = MaterialTheme.colorScheme.surface,
            )
        }
        if (snippetsOpen) {
            val snippets by viewModel.snippets.collectAsStateWithLifecycle()
            SnippetSheet(
                snippets = snippets,
                onDismiss = { snippetsOpen = false },
                onSave = viewModel::saveSnippet,
                onInsert = { entry ->
                    viewModel.insertSnippet(entry, focused)
                    snippetsOpen = false
                },
                onDelete = viewModel::deleteSnippet,
            )
        }
    }
}

/**
 * One terminal: its status line, its screen and its own zoom, keyboard focus, dialogs and
 * input. Everything here belongs to [active] alone, so two panes can show two sessions at once
 * (or the same server twice) without sharing a view, a focus or a pending dialog.
 */
@Composable
private fun TerminalPane(
    viewModel: AppViewModel,
    active: TerminalSession,
    focused: Boolean,
    showFocusRing: Boolean,
    onFocus: () -> Unit,
    registerKeyboard: (String, (() -> Unit)?) -> Unit,
    modifier: Modifier = Modifier,
    picker: (@Composable () -> Unit)? = null,
) {
    var serialSettingsOpen by remember(active.id) { mutableStateOf(false) }
    val terminalFocusRequester = remember(active.id) { FocusRequester() }

    val store = viewModel.settingsStore
    val settingsRevision by store.revision.collectAsStateWithLifecycle()
    val palette = remember(settingsRevision) { terminalPalette(store.get(SettingsRegistry.theme)) }
    val fontFamilyName = remember(settingsRevision) { store.get(SettingsRegistry.fontFamily) }
    val appContext = androidx.compose.ui.platform.LocalContext.current
    val typeface = remember(fontFamilyName) { TerminalFonts.typeface(appContext, fontFamilyName) }
    val baseFontSp = remember(settingsRevision) { store.get(SettingsRegistry.fontSize).toFloat() }
    val cursorStyle = remember(settingsRevision) { store.get(SettingsRegistry.cursorStyle) }
    val cursorBlink = remember(settingsRevision) { store.get(SettingsRegistry.cursorBlink) }
    var textDialogOpen by remember { mutableStateOf(false) }

    // One zoom per pane, starting from the remembered one. Pinch and the A-/A+ keys
    // both write through applyZoom, so they cannot disagree.
    var zoom by remember { mutableFloatStateOf(viewModel.settings.terminalZoom) }
    var pendingPinch by remember { mutableFloatStateOf(1f) }
    var zoomHudTick by remember { mutableIntStateOf(0) }
    var zoomHudVisible by remember { mutableStateOf(false) }
    val applyZoom: (Float) -> Unit = { target ->
        val next = TerminalZoom.clamp(target)
        if (next != zoom) {
            zoom = next
            zoomHudTick++
        }
    }
    // The size the user is asking for, and the size the terminal is actually built at. They
    // differ only for a moment while zooming: the terminal component takes its font size
    // when it is created, so a change is shown at once by scaling what is on screen, then
    // committed by rebuilding the terminal at the new size (see the commit effect below).
    val targetSp = baseFontSp * zoom
    var appliedSp by remember { mutableFloatStateOf(targetSp) }
    LaunchedEffect(zoomHudTick) {
        if (zoomHudTick > 0) {
            zoomHudVisible = true
            delay(ZOOM_HUD_MS)
            zoomHudVisible = false
        }
    }
    val keyboardController = LocalSoftwareKeyboardController.current
    val rootView = LocalView.current
    val keyboardScope = rememberCoroutineScope()
    // Where this pane is on screen. Several terminals can exist in the window at once (two
    // panes of a split, or one still fading out), each with its own input view; the pane's
    // position is how the right one is told apart.
    var paneBounds by remember(active.id) { mutableStateOf<androidx.compose.ui.geometry.Rect?>(null) }
    var selectionController by remember(active.id) { mutableStateOf<SelectionController?>(null) }

    val showKeyboard = {
        keyboardScope.launch {
            // A terminal that was only just chosen may not have attached its focus target yet;
            // asking too early throws, so try a few frames instead of failing.
            repeat(6) { attempt ->
                runCatching { terminalFocusRequester.requestFocus() }
                // Let focus publish the input connection before asking the IME to attach,
                // otherwise rapid dismiss/reopen taps can be ignored.
                withFrameNanos { }
                // The actual input connection belongs to termlib's embedded Android View, not
                // the surrounding Compose focus node. Target THIS pane's view directly.
                val imeView = rootView.findTerminalInputView(paneBounds)
                if (imeView != null) {
                    imeView.requestFocus()
                    val inputMethodManager = imeView.context
                        .getSystemService(InputMethodManager::class.java)
                    inputMethodManager.showSoftInput(imeView, InputMethodManager.SHOW_IMPLICIT)
                    return@launch
                }
                if (attempt < 5) delay(40)
            }
            keyboardController?.show()
        }
        Unit
    }
    val latestShowKeyboard by rememberUpdatedState(showKeyboard)
    val latestOnFocus by rememberUpdatedState(onFocus)
    DisposableEffect(active.id) {
        registerKeyboard(active.id) { latestShowKeyboard() }
        onDispose { registerKeyboard(active.id, null) }
    }

    // Commit a zoom change: after the fingers pause (or a button is tapped), rebuild the
    // terminal at the new size. The shell is told the new grid by the terminal itself, and
    // the emulator keeps the whole screen and scrollback, so nothing is lost. The keyboard
    // is deliberately NOT touched here: zooming must never raise it. It appears only on a
    // one-finger tap on the terminal or on the keyboard key in the bar.
    LaunchedEffect(targetSp) {
        if (targetSp == appliedSp) return@LaunchedEffect
        delay(ZOOM_COMMIT_MS)
        appliedSp = targetSp
    }

    // Termux behaviour: a long press selects the WORD under the finger (not one character), then
    // the two handles move per character. termlib starts a one-character selection on long
    // press and a word on double tap; here either becomes "word first, then character".
    LaunchedEffect(selectionController) {
        val controller = selectionController ?: return@LaunchedEffect
        snapshotFlow { controller.isSelectionActive }.collect { selecting ->
            if (selecting) {
                controller.setSelectionMode(SelectionMode.WORD)
                controller.setSelectionMode(SelectionMode.CHARACTER)
            }
        }
    }

    // The theme reaches the running emulator too: its default colours and the 16 ANSI colours
    // were fixed when the session was created, so a theme chosen later must be pushed into it.
    LaunchedEffect(active.id, palette) {
        active.applyPalette(palette)
    }

    // Cursor shape and blink, sent to the session whenever the setting or the session changes.
    LaunchedEffect(active.id, cursorStyle, cursorBlink) {
        active.applyCursorStyle(cursorStyle, cursorBlink)
    }

    val ring = if (showFocusRing) {
        Modifier.border(1.dp, if (focused) Turquoise.copy(alpha = 0.7f) else Stroke)
    } else {
        Modifier
    }
    Column(modifier.fillMaxWidth().then(ring)) {
        val activeSerial = active as? SerialSession
        StatusBar(
            active,
            onSettingsClick = activeSerial?.let { { serialSettingsOpen = true } },
            onCopyAll = { copyWholeTerminal(appContext, viewModel, active) },
            onSelectText = { textDialogOpen = true },
            picker = picker,
        )
        if (textDialogOpen) {
            TerminalTextDialog(viewModel, active, onDismiss = { textDialogOpen = false })
        }
        if (serialSettingsOpen && activeSerial != null) {
            SerialSettingsDialog(
                title = stringResource(R.string.serial_settings_title),
                initial = activeSerial.settings.value,
                confirmLabel = stringResource(R.string.serial_apply),
                onDismiss = { serialSettingsOpen = false },
                onConfirm = { updated -> viewModel.updateSerialSettings(activeSerial, updated) },
                onDisconnect = { activeSerial.disconnect() },
            )
        }
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(palette.background)
                .clipToBounds()
                .onGloballyPositioned { paneBounds = it.boundsInWindow() }
                .onSingleTap {
                    latestOnFocus()
                    latestShowKeyboard()
                }
                .pinchToZoom(
                    onZoomBy = { factor ->
                        val (nextZoom, remainder) = TerminalZoom.applyPinch(zoom, pendingPinch, factor)
                        pendingPinch = remainder
                        applyZoom(nextZoom)
                    },
                    onEnd = {
                        pendingPinch = 1f
                        viewModel.settings.terminalZoom = zoom
                    },
                ),
        ) {
            // While the size is catching up, what is already drawn is simply scaled, so the
            // text follows the fingers at once. key() then rebuilds the terminal at the
            // committed size, which is what makes the grid and the shell's idea of the
            // window size match the new text.
            Box(
                Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        val preview = targetSp / appliedSp
                        scaleX = preview
                        scaleY = preview
                        transformOrigin = TransformOrigin(0f, 0f)
                    },
            ) {
                key(active.id, appliedSp, fontFamilyName, palette) {
                    Terminal(
                        terminalEmulator = active.emulator,
                        typeface = typeface,
                        initialFontSize = appliedSp.sp,
                        minFontSize = MIN_FONT_SP.sp,
                        maxFontSize = MAX_FONT_SP.sp,
                        backgroundColor = palette.background,
                        foregroundColor = palette.foreground,
                        keyboardEnabled = true,
                        // The component would raise the keyboard every time it is rebuilt
                        // (each zoom step). Showing it is ours: see onSingleTap above.
                        showSoftKeyboard = false,
                        focusRequester = terminalFocusRequester,
                        onSelectionControllerAvailable = { selectionController = it },
                        selectionBackgroundColor = Color(0xFF3D7FD9),
                        selectionForegroundColor = Color.White,
                        onPasteRequest = {
                            // The paste dialog belongs to the pane the request came from.
                            latestOnFocus()
                            active.requestPaste()
                        },
                    )
                }
            }
            // Faded with a plain alpha rather than AnimatedVisibility: this Box sits inside a
            // Column, and the compiler will not let an AnimatedVisibility here borrow the
            // Column's scope.
            val zoomHudAlpha by animateFloatAsState(
                if (zoomHudVisible) 1f else 0f,
                Motion.normal(),
                label = "zoom-hud",
            )
            if (zoomHudAlpha > 0f) {
                Box(
                    Modifier
                        .align(Alignment.TopEnd)
                        .padding(12.dp)
                        .graphicsLayer { alpha = zoomHudAlpha },
                ) {
                    ZoomHud(
                        zoom = zoom,
                        onZoomOut = { applyZoom(TerminalZoom.step(zoom, -1)); viewModel.settings.terminalZoom = zoom },
                        onZoomIn = { applyZoom(TerminalZoom.step(zoom, +1)); viewModel.settings.terminalZoom = zoom },
                        onReset = { applyZoom(TerminalZoom.DEFAULT); viewModel.settings.terminalZoom = zoom },
                    )
                }
            }
        }
        PasteAndHostKeyDialogs(viewModel, active, handlesPaste = focused)
    }
}

private fun View.collectTerminalInputViews(out: MutableList<View>) {
    // ImeInputView is an internal Kotlin type in termlib, so identify the embedded text
    // editor without reflecting into its implementation.
    if (javaClass.name == TERMINAL_IME_VIEW_CLASS) {
        out += this
        return
    }
    if (this !is ViewGroup) return
    for (index in 0 until childCount) getChildAt(index).collectTerminalInputViews(out)
}

/**
 * The input view of the terminal drawn inside [bounds] (window coordinates). The first one found
 * is not necessarily the right one: a split shows two, and a terminal that is leaving the screen
 * can still be attached, which is how the keyboard used to end up typing into another session.
 */
private fun View.findTerminalInputView(bounds: androidx.compose.ui.geometry.Rect?): View? {
    val all = ArrayList<View>()
    collectTerminalInputViews(all)
    val visible = all.filter { it.isAttachedToWindow && it.isShown }
    val pool = if (visible.isNotEmpty()) visible else all
    if (bounds == null || pool.size <= 1) return pool.firstOrNull()
    val location = IntArray(2)
    return pool.minByOrNull { view ->
        view.getLocationInWindow(location)
        val x = location[0] + view.width / 2f
        val y = location[1] + view.height / 2f
        if (x >= bounds.left && x <= bounds.right && y >= bounds.top && y <= bounds.bottom) {
            0f
        } else {
            kotlin.math.hypot(x - bounds.center.x, y - bounds.center.y)
        }
    }
}

private const val TERMINAL_IME_VIEW_CLASS = "org.connectbot.terminal.ImeInputView"

@Composable
private fun SessionTabs(
    sessions: List<TerminalSession>,
    activeId: String?,
    onSelect: (String) -> Unit,
    onClose: (String) -> Unit,
    canOpenAnother: Boolean,
    onOpenAnother: () -> Unit,
    splitOn: Boolean,
    onToggleSplit: () -> Unit,
) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
    Row(
        Modifier
            .weight(1f)
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 8.dp, vertical = 3.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        sessions.forEach { session ->
            val selected = session.id == activeId
            val state by session.state.collectAsStateWithLifecycle()
            val closeDescription = stringResource(R.string.close_session, session.title)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(
                        if (selected) MaterialTheme.colorScheme.surfaceVariant
                        else MaterialTheme.colorScheme.surface,
                    )
                    .border(1.dp, if (selected) Turquoise.copy(alpha = 0.4f) else Stroke, RoundedCornerShape(10.dp))
                    .selectable(
                        selected = selected,
                        role = Role.Tab,
                        onClick = { onSelect(session.id) },
                    )
                    .padding(start = 8.dp, end = 0.dp),
            ) {
                StatusDot(state)
                Spacer(Modifier.width(5.dp))
                Text(session.title, style = MaterialTheme.typography.labelMedium, maxLines = 1)
                // 32dp square: the whole pill is 32dp tall, the same as the close target.
                Icon(
                    Icons.Outlined.Close,
                    contentDescription = closeDescription,
                    tint = TextSecondary,
                    modifier = Modifier
                        .size(32.dp)
                        .clickable { onClose(session.id) }
                        .padding(9.dp),
                )
            }
        }
    }
    IconButton(onClick = onOpenAnother, enabled = canOpenAnother, modifier = Modifier.size(34.dp)) {
        Icon(
            Icons.Outlined.Add,
            contentDescription = stringResource(R.string.terminal_new_session),
            tint = if (canOpenAnother) MaterialTheme.colorScheme.onSurface else TextSecondary.copy(alpha = 0.4f),
        )
    }
    IconButton(onClick = onToggleSplit, modifier = Modifier.size(34.dp)) {
        Icon(
            Icons.Outlined.HorizontalSplit,
            contentDescription = stringResource(if (splitOn) R.string.split_off else R.string.split_on),
            tint = if (splitOn) Turquoise else MaterialTheme.colorScheme.onSurface,
        )
    }
    }
}

@Composable
private fun StatusDot(state: SshSessionState) {
    // Shared with the host list rather than restated here: the two screens had already
    // drifted apart on what colour a connecting session is.
    val color by animateColorAsState(state.status().color, label = "status")

    // While a connection is being established the dot pulses, so "working" is readable
    // at a glance without occupying any more space than the idle indicator. Everything
    // else is a steady dot: motion here would mean nothing and cost battery.
    val busy = state.isBusy
    val transition = rememberInfiniteTransition(label = "status-pulse")
    val pulse by transition.animateFloat(
        initialValue = 1f,
        targetValue = if (busy) 1.55f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(760, easing = Motion.Standard),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "status-pulse-scale",
    )

    Box(Modifier.size(16.dp), contentAlignment = Alignment.Center) {
        if (busy) {
            Box(
                Modifier
                    .size(8.dp)
                    .graphicsLayer {
                        scaleX = pulse
                        scaleY = pulse
                        alpha = (1.6f - pulse).coerceIn(0f, 1f)
                    }
                    .clip(CircleShape)
                    .background(color),
            )
        }
        Box(Modifier.size(8.dp).clip(CircleShape).background(color))
    }
}

@Composable
private fun StatusBar(
    session: TerminalSession,
    onSettingsClick: (() -> Unit)? = null,
    onCopyAll: () -> Unit,
    onSelectText: () -> Unit,
    picker: (@Composable () -> Unit)? = null,
) {
    val state by session.state.collectAsStateWithLifecycle()
    val text = when (val s = state) {
        SshSessionState.Idle -> stringResource(R.string.state_idle)
        SshSessionState.Connecting -> stringResource(R.string.state_connecting)
        is SshSessionState.AwaitingHostKeyApproval -> stringResource(R.string.state_verifying)
        SshSessionState.Connected -> stringResource(R.string.state_connected)
        is SshSessionState.Reconnecting -> stringResource(R.string.state_reconnecting) + " ${s.attempt}/${s.max}"
        is SshSessionState.Failed -> stringResource(s.kind.stringRes)
        SshSessionState.Closed -> stringResource(R.string.state_disconnected)
    }
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 0.dp),
    ) {
        if (picker != null) {
            picker()
            Spacer(Modifier.width(8.dp))
        }
        StatusDot(state)
        Spacer(Modifier.width(5.dp))
        Text(text, style = MaterialTheme.typography.labelSmall, color = TextSecondary, maxLines = 1)
        Spacer(Modifier.weight(1f))
        TranscriptActions(onCopyAll = onCopyAll, onSelectText = onSelectText)
        Spacer(Modifier.width(6.dp))
        // For a serial port the line shows the live settings (they can change mid-session)
        // and is the way into the settings dialog; for SSH it is user@host:port.
        val serialSettings = (session as? SerialSession)?.settings?.collectAsStateWithLifecycle()?.value
        Text(
            ltr(serialSettings?.summary ?: session.subtitle),
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
            color = if (onSettingsClick != null) Turquoise else TextSecondary,
            fontFamily = FontFamily.Monospace,
            maxLines = 1,
            modifier = if (onSettingsClick != null) {
                Modifier.clickable(onClick = onSettingsClick).padding(vertical = 6.dp)
            } else {
                Modifier
            },
        )
    }
}

/**
 * Termux-style extra-keys bar: two compact rows of equal-width keys, no scrolling. It is
 * 64dp tall, exactly what the old single row took, so the terminal above keeps its size.
 *
 *   ⌨    ~   /    —   HOME  ↑   ESC  PGUP
 *  Snip TAB CTRL ALT   ←    ↓    →   PGDN
 *
 * CTRL and ALT latch for exactly one following key, whether it comes from this bar or from
 * the soft keyboard (the latch lives in the session's sendKey). Zoom is by pinch, with the
 * A−/A+ buttons on the zoom HUD that appears while pinching.
 */
@Composable
private fun KeyToolbar(
    session: TerminalSession,
    onShowKeyboard: () -> Unit,
    onSnippets: () -> Unit,
) {
    val ctrl by session.ctrlLatched.collectAsStateWithLifecycle()
    val alt by session.altLatched.collectAsStateWithLifecycle()

    Column(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface)) {
        // The bar's top edge is a 1dp hairline that belongs to the bar itself, so the bar
        // reads as one piece with the terminal above instead of a loose strip.
        HorizontalDivider(thickness = 1.dp, color = Stroke)
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 4.dp).padding(bottom = 1.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
        Row(Modifier.fillMaxWidth().height(BAR_ROW_HEIGHT)) {
            BarKey("⌨", contentDescription = stringResource(R.string.show_keyboard)) { onShowKeyboard() }
            BarKey("~") { session.sendKey("~") }
            BarKey("/") { session.sendKey("/") }
            BarKey("—", contentDescription = "-") { session.sendKey("-") }
            BarKey("HOME") { session.sendKey("\u001B[H") }
            BarKey("↑", contentDescription = stringResource(R.string.terminal_key_up), repeat = true) { session.sendKey("\u001B[A") }
            BarKey("ESC") { session.sendKey(byteArrayOf(0x1B)) }
            BarKey("PGUP") { session.sendKey("\u001B[5~") }
        }
        Row(Modifier.fillMaxWidth().height(BAR_ROW_HEIGHT)) {
            BarKey(stringResource(R.string.snippets_short)) { onSnippets() }
            BarKey("TAB") { session.sendKey(byteArrayOf(0x09)) }
            BarKey("CTRL", active = ctrl, toggle = true) { session.toggleCtrl() }
            BarKey("ALT", active = alt, toggle = true) { session.toggleAlt() }
            BarKey("←", contentDescription = stringResource(R.string.terminal_key_left), repeat = true) { session.sendKey("\u001B[D") }
            BarKey("↓", contentDescription = stringResource(R.string.terminal_key_down), repeat = true) { session.sendKey("\u001B[B") }
            BarKey("→", contentDescription = stringResource(R.string.terminal_key_right), repeat = true) { session.sendKey("\u001B[C") }
            BarKey("PGDN") { session.sendKey("\u001B[6~") }
        }
        }
    }
}

/** 1dp edge + 2 rows x 30dp + 2dp gap + 1dp padding = 64dp, the height of the old single-row bar. */
private val BAR_ROW_HEIGHT = 30.dp

@Composable
private fun RowScope.BarKey(
    label: String,
    active: Boolean = false,
    toggle: Boolean = false,
    contentDescription: String? = null,
    repeat: Boolean = false,
    onClick: () -> Unit,
) {
    val haptics = LocalHapticFeedback.current
    val hapticsEnabled = LocalKeyHaptics.current
    val interactions = remember { MutableInteractionSource() }
    val isPressed by interactions.collectIsPressedAsState()

    val press: () -> Unit = {
        if (hapticsEnabled) haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        onClick()
    }
    val currentOnClick by rememberUpdatedState(onClick)
    val currentPress by rememberUpdatedState(press)

    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .weight(1f)
            .fillMaxHeight()
            .padding(horizontal = 1.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(
                when {
                    active -> Turquoise
                    isPressed -> MaterialTheme.colorScheme.surfaceVariant
                    else -> androidx.compose.ui.graphics.Color.Transparent
                },
            )
            .then(
                if (contentDescription != null) Modifier.semantics {
                    this.contentDescription = contentDescription
                } else Modifier,
            )
            .then(
                if (repeat) Modifier
                    .semantics(mergeDescendants = true) {
                        role = Role.Button
                        semanticsOnClick { currentPress(); true }
                    }
                    // Like Termux: the key fires the moment it is touched, and if the finger
                    // stays down it repeats until released (or the touch is cancelled).
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onPress = { offset ->
                                val down = PressInteraction.Press(offset)
                                interactions.emit(down)
                                currentPress()
                                coroutineScope {
                                    val repeater = launch {
                                        delay(KEY_REPEAT_DELAY_MS)
                                        while (true) {
                                            currentOnClick()
                                            delay(KEY_REPEAT_INTERVAL_MS)
                                        }
                                    }
                                    val released = tryAwaitRelease()
                                    repeater.cancel()
                                    interactions.emit(
                                        if (released) PressInteraction.Release(down) else PressInteraction.Cancel(down),
                                    )
                                }
                            },
                        )
                    }
                else if (toggle) Modifier.toggleable(
                    value = active,
                    interactionSource = interactions,
                    indication = null,
                    role = Role.Button,
                    onValueChange = { press() },
                ) else Modifier.clickable(
                    interactionSource = interactions,
                    indication = null,
                    onClick = press,
                ),
            ),
    ) {
        Text(
            label,
            maxLines = 1,
            softWrap = false,
            fontSize = 11.sp,
            fontWeight = androidx.compose.ui.text.font.FontWeight.Medium,
            color = if (active) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
        )
    }
}

/** Held arrow keys: wait this long, then repeat at this interval (Termux's timing). */
private const val KEY_REPEAT_DELAY_MS = 400L
private const val KEY_REPEAT_INTERVAL_MS = 80L

private const val ZOOM_HUD_MS = 2_200L

/** How long the fingers must pause before the zoom is committed by rebuilding the terminal. */
private const val ZOOM_COMMIT_MS = 160L

/** Bounds handed to the terminal component; the zoom range and font setting stay well inside them. */
private const val MIN_FONT_SP = 4f
private const val MAX_FONT_SP = 96f

/** Whether the special-key bar gives haptic feedback (the Vibrate on key press setting). */
private val LocalKeyHaptics = compositionLocalOf { true }

/**
 * Appears while zooming: shows the current size and offers the same steps as the toolbar
 * keys, with the percentage doubling as "back to 100%". Fades on its own so it never sits
 * over the output.
 */
@Composable
internal fun ZoomHud(zoom: Float, onZoomOut: () -> Unit, onZoomIn: () -> Unit, onReset: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(RoundedCornerShape(24.dp))
            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.94f))
            .border(1.dp, Stroke, RoundedCornerShape(24.dp))
            .padding(horizontal = 4.dp),
    ) {
        val zoomOutDescription = stringResource(R.string.terminal_zoom_out)
        val zoomInDescription = stringResource(R.string.terminal_zoom_in)
        Text(
            "A−",
            style = MaterialTheme.typography.labelLarge,
            modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .semantics { contentDescription = zoomOutDescription }
                .clickable(onClick = onZoomOut)
                .defaultMinSize(minWidth = 48.dp, minHeight = 48.dp)
                .padding(horizontal = 12.dp, vertical = 12.dp),
        )
        val resetDescription = stringResource(R.string.terminal_zoom_reset)
        Text(
            "${TerminalZoom.percent(zoom)}%",
            style = MaterialTheme.typography.labelLarge,
            color = Turquoise,
            modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .semantics { contentDescription = resetDescription }
                .clickable(onClick = onReset)
                .defaultMinSize(minHeight = 48.dp)
                .padding(horizontal = 8.dp, vertical = 12.dp),
        )
        Text(
            "A+",
            style = MaterialTheme.typography.labelLarge,
            modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .semantics { contentDescription = zoomInDescription }
                .clickable(onClick = onZoomIn)
                .defaultMinSize(minWidth = 48.dp, minHeight = 48.dp)
                .padding(horizontal = 12.dp, vertical = 12.dp),
        )
    }
}
