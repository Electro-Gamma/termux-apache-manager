package app.terminalssh.secure.audio;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.media.audiofx.AcousticEchoCanceler;
import android.media.audiofx.NoiseSuppressor;
import android.os.Build;
import android.os.Process;

import java.io.IOException;
import java.util.ArrayDeque;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** Phone side of the audio bridge: plays the computer's sound with AudioTrack and sends the microphone (AudioRecord) to it.
 *  Keeps the connection up: it reconnects after network loss until {@link #stop()}. All network and audio work runs on its own
 *  threads. Each AudioRecord/AudioTrack is created, used and released by one thread. For use while the app is in the
 *  background, run it from {@link AudioService}. */
public final class AudioBridge {
    public interface Events { void onAudioState(String text); }

    public enum State { IDLE, CONNECTING, CONNECTED, RECONNECTING, STOPPED, FAILED }

    public static final int PLAY_RATE = 48000, PLAY_CH = 2, MIC_RATE = 16000;
    private static final long[] BACKOFF_MS = {1000, 2000, 4000, 8000, 15000};
    private static final long STALL_LIMIT_MS = 8000;

    /** Everything about one audio connection. */
    public static final class Config {
        public String host = ""; public int port = 5950; public String passphrase = "";
        public boolean playback = true, mic = true;
        public int playRate = PLAY_RATE, playChannels = PLAY_CH, micRate = MIC_RATE, micChannels = 1;
        /** true: VOICE_COMMUNICATION with echo cancellation and noise suppression (calls). false: the less processed
         *  VOICE_RECOGNITION source (dictation, Whisper, recording). */
        public boolean voiceProcessing = true;
        /** Playback queued in the app before the oldest is dropped. */
        public int playBufferMs = 300;

        public Config copy() {
            Config c = new Config(); c.host = host; c.port = port; c.passphrase = passphrase; c.playback = playback; c.mic = mic;
            c.playRate = playRate; c.playChannels = playChannels; c.micRate = micRate; c.micChannels = micChannels;
            c.voiceProcessing = voiceProcessing; c.playBufferMs = playBufferMs; return c;
        }
    }

    private final Config cfg; private final Events ev;
    private final Object wake = new Object();
    private volatile boolean stop, micMuted, retryNow;
    private volatile State state = State.IDLE;
    private volatile String message = "";
    private volatile int level;
    private volatile AudioLink link;
    private volatile String fatal;
    private Thread worker;

    public AudioBridge(String host, int port, String passphrase, boolean playback, boolean mic, Events ev) {
        this(simple(host, port, passphrase, playback, mic), ev);
    }
    public AudioBridge(Config config, Events ev) { this.cfg = config.copy(); this.ev = ev; }

    private static Config simple(String host, int port, String pass, boolean playback, boolean mic) {
        Config c = new Config(); c.host = host; c.port = port; c.passphrase = pass; c.playback = playback; c.mic = mic; return c;
    }

    public void setMicMuted(boolean m) { micMuted = m; if (m) level = 0; }
    public boolean isMicMuted() { return micMuted; }
    public State state() { return state; }
    public String message() { return message; }
    /** Microphone level 0..100 (-60 dBFS..0 dBFS) of the last 20 ms; 0 when muted or off. */
    public int level() { return level; }
    public Config config() { return cfg.copy(); }

    /** Connects in the background and starts audio. The caller must already hold RECORD_AUDIO when mic == true. */
    public synchronized void start() {
        if (worker != null || stop) return;
        worker = new Thread(this::run, "audio-session");
        worker.setDaemon(true); worker.start();
    }

    /** Safe on the UI thread. */
    public void stop() {
        if (stop) return; stop = true;
        AudioLink l = link; if (l != null) l.close();
        synchronized (wake) { wake.notifyAll(); }
    }

    /** The phone changed network: drop the old socket (it is bound to the old address) and reconnect at once. */
    public void reconnectNow() {
        retryNow = true;
        AudioLink l = link; if (l != null) l.abort();
        synchronized (wake) { wake.notifyAll(); }
    }

    private void report(State s, String text) {
        state = s; message = text;
        if (ev != null) ev.onAudioState(text);
    }

    private void run() {
        boolean everConnected = false; int attempt = 0, authFailures = 0;
        while (!stop && fatal == null) {
            report(everConnected ? State.RECONNECTING : State.CONNECTING, everConnected ? "Audio: reconnecting…" : "Audio: connecting…");
            String why; long connectedAt = 0;
            retryNow = false;
            try {
                int mode = (cfg.playback ? AudioLink.MODE_PLAY : 0) | (cfg.mic ? AudioLink.MODE_MIC : 0)
                        | (cfg.mic && cfg.micChannels == 2 ? AudioLink.MODE_MIC_STEREO : 0);
                AudioLink l = AudioLink.connect(cfg.host, cfg.port, cfg.passphrase, mode, cfg.playRate, cfg.playChannels, cfg.micRate);
                if (cfg.mic && cfg.micChannels == 2 && (l.serverCaps() & AudioLink.CAP_STEREO_MIC) == 0) {
                    l.close(); cfg.micChannels = 1;          // a 1.x server would play stereo data as mono
                    continue;
                }
                link = l;
                if (stop) { l.close(); break; }
                everConnected = true; authFailures = 0; connectedAt = System.nanoTime();
                why = session(l);
                if (l.byeReason() == AudioLink.BYE_REPLACED) fatal = "another phone or app connected to the computer";
            } catch (AudioLink.AuthException e) {
                why = e.getMessage();
                // Never connected: retrying a wrong passphrase only trips the server's failure limit.
                if (!everConnected || ++authFailures >= 3) fatal = why;
            } catch (AudioLink.RefusedException e) {
                why = e.getMessage();
                if (e.status != AudioLink.ST_NO_AUDIO) fatal = why;
            } catch (IOException e) {
                why = String.valueOf(e.getMessage());
            } catch (RuntimeException e) {
                why = String.valueOf(e.getMessage()); fatal = why;
            } finally {
                link = null; level = 0;
            }
            if (stop || fatal != null) break;
            if (connectedAt != 0 && System.nanoTime() - connectedAt > TimeUnit.SECONDS.toNanos(10)) attempt = 0;
            long delay = BACKOFF_MS[Math.min(attempt++, BACKOFF_MS.length - 1)];
            report(State.RECONNECTING, "Audio: " + why + " — retrying in " + delay / 1000 + " s");
            synchronized (wake) {
                if (!stop && !retryNow) try { wake.wait(delay); } catch (InterruptedException e) { break; }
            }
        }
        if (fatal != null && !stop) report(State.FAILED, "Audio: " + fatal);
        else report(State.STOPPED, "Audio: off");
    }

    /** Runs audio over one connection until it ends. Returns why it ended. */
    private String session(final AudioLink l) {
        final CountDownLatch ended = new CountDownLatch(1);
        final String[] reason = {"connection closed"};
        final Player player = cfg.playback ? new Player() : null;
        Thread micThread = null;
        try {
            if (player != null) player.start();
            l.startReceiving(new AudioLink.Listener() {
                @Override public void onPlayback(byte[] pcm, int len) { if (player != null) player.offer(pcm, len); }
                @Override public void onClosed(String r) { reason[0] = r; ended.countDown(); }
            });
            if (cfg.mic) { micThread = new Thread(() -> capture(l, ended), "audio-mic"); micThread.start(); }
            report(State.CONNECTED, "Audio: on" + (cfg.playback ? " ▶" : "") + (cfg.mic ? " 🎤" : ""));
            while (!stop && fatal == null && !ended.await(500, TimeUnit.MILLISECONDS)) {
                if (l.sendStalledMillis() > STALL_LIMIT_MS) { reason[0] = "network stalled"; break; }
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } finally {
            ended.countDown();
            if (stop) l.close(); else l.abort();
            if (player != null) player.finish();
            if (micThread != null) try { micThread.join(2000); } catch (InterruptedException ignored) { }
        }
        return reason[0];
    }

    @SuppressWarnings("MissingPermission")
    private void capture(AudioLink l, CountDownLatch ended) {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO);
        AudioRecord r = null; AcousticEchoCanceler aec = null; NoiseSuppressor ns = null;
        try {
            int ch = cfg.micChannels == 2 ? AudioFormat.CHANNEL_IN_STEREO : AudioFormat.CHANNEL_IN_MONO;
            int enc = AudioFormat.ENCODING_PCM_16BIT;
            int frame = cfg.micRate / 50 * 2 * cfg.micChannels;                     // 20 ms
            int min = AudioRecord.getMinBufferSize(cfg.micRate, ch, enc);
            if (min < 0) { fatal = "this phone cannot record " + cfg.micRate + " Hz with " + cfg.micChannels + " channel(s)"; return; }
            int source = cfg.voiceProcessing ? MediaRecorder.AudioSource.VOICE_COMMUNICATION : MediaRecorder.AudioSource.VOICE_RECOGNITION;
            r = new AudioRecord(source, cfg.micRate, ch, enc, Math.max(min, frame * 4));
            if (r.getState() != AudioRecord.STATE_INITIALIZED) { fatal = "microphone unavailable (permission?)"; return; }
            if (cfg.voiceProcessing) {
                try { if (AcousticEchoCanceler.isAvailable()) { aec = AcousticEchoCanceler.create(r.getAudioSessionId()); if (aec != null) aec.setEnabled(true); } } catch (RuntimeException ignored) { }
                try { if (NoiseSuppressor.isAvailable()) { ns = NoiseSuppressor.create(r.getAudioSessionId()); if (ns != null) ns.setEnabled(true); } } catch (RuntimeException ignored) { }
            }
            r.startRecording();
            byte[] b = new byte[frame], silence = new byte[frame];
            while (!stop && ended.getCount() > 0) {
                int n = 0;
                while (n < frame && !stop && ended.getCount() > 0) {
                    int k = r.read(b, n, frame - n);
                    if (k <= 0) { fatal = "the microphone stopped (taken by the system or another app?)"; return; }
                    n += k;
                }
                if (n == frame) {
                    boolean muted = micMuted;
                    level = muted ? 0 : levelOf(b, frame);
                    l.sendMic(muted ? silence : b, 0, frame);   // muted = digital silence: the link and the virtual mic stay alive
                }
            }
        } catch (IOException e) {
            l.abort();                                           // network: the session loop reconnects
        } catch (RuntimeException e) {
            fatal = "microphone: " + e.getMessage();
        } finally {
            level = 0;
            if (aec != null) try { aec.release(); } catch (RuntimeException ignored) { }
            if (ns != null) try { ns.release(); } catch (RuntimeException ignored) { }
            if (r != null) { try { r.stop(); } catch (RuntimeException ignored) { } r.release(); }
        }
    }

    static int levelOf(byte[] pcm, int len) {
        int peak = 1;
        for (int i = 0; i + 1 < len; i += 2) {
            int s = Math.abs((short) ((pcm[i] & 255) | (pcm[i + 1] << 8)));
            if (s > peak) peak = s;
        }
        double db = 20 * Math.log10(peak / 32768.0);
        return (int) Math.max(0, Math.min(100, (db + 60) * 100 / 60));
    }

    /** Plays queued PCM. The queue is bounded, so a slow phone clock or a network burst cannot build up delay. */
    private final class Player extends Thread {
        private final ArrayDeque<byte[]> queue = new ArrayDeque<>();
        private final int frameBytes = cfg.playChannels * 2;
        private final int maxBytes = cfg.playRate * frameBytes / 1000 * cfg.playBufferMs;
        private int queued; private volatile boolean done;
        private byte[] partial = new byte[0];
        private AudioTrack track;

        Player() { super("audio-play"); }

        synchronized void offer(byte[] pcm, int len) {
            byte[] all = new byte[partial.length + len];
            System.arraycopy(partial, 0, all, 0, partial.length); System.arraycopy(pcm, 0, all, partial.length, len);
            int cut = all.length - all.length % frameBytes;      // 1.x servers may split a sample frame
            partial = java.util.Arrays.copyOfRange(all, cut, all.length);
            if (cut == 0) return;
            queue.add(java.util.Arrays.copyOf(all, cut)); queued += cut;
            while (queued > maxBytes && queue.size() > 1) queued -= queue.remove().length;
            notifyAll();
        }

        private synchronized byte[] take() throws InterruptedException {
            if (queue.isEmpty() && !done) wait(200);
            byte[] b = queue.poll(); if (b != null) queued -= b.length; return b;
        }

        void finish() {
            done = true;
            synchronized (this) { notifyAll(); }
            synchronized (queue) { if (track != null) try { track.pause(); } catch (RuntimeException ignored) { } }  // unblocks write()
            try { join(2000); } catch (InterruptedException ignored) { }
        }

        @Override public void run() {
            AudioTrack t = null;
            try {
                int ch = cfg.playChannels == 2 ? AudioFormat.CHANNEL_OUT_STEREO : AudioFormat.CHANNEL_OUT_MONO;
                int enc = AudioFormat.ENCODING_PCM_16BIT;
                int min = AudioTrack.getMinBufferSize(cfg.playRate, ch, enc);
                int buf = Math.max(min, cfg.playRate * frameBytes / 10);          // about 100 ms
                AudioTrack.Builder b = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                    .setAudioFormat(new AudioFormat.Builder().setSampleRate(cfg.playRate).setChannelMask(ch).setEncoding(enc).build())
                    .setBufferSizeInBytes(buf).setTransferMode(AudioTrack.MODE_STREAM);
                if (Build.VERSION.SDK_INT >= 26) b.setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY);
                t = b.build();
                synchronized (queue) { track = t; }
                t.play();
                while (!done) {
                    byte[] pcm = take();
                    if (pcm == null) continue;
                    int off = 0;
                    while (off < pcm.length && !done) { int w = t.write(pcm, off, pcm.length - off); if (w <= 0) break; off += w; }
                }
            } catch (InterruptedException ignored) {
            } catch (RuntimeException e) {
                fatal = "playback: " + e.getMessage();
            } finally {
                synchronized (queue) { track = null; if (t != null) t.release(); }
            }
        }
    }
}
