package app.terminalssh.secure.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.VolumeOff
import androidx.compose.material.icons.automirrored.outlined.VolumeUp
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.MicOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.terminalssh.secure.R
import app.terminalssh.secure.TerminalApp
import app.terminalssh.secure.audio.AudioBridge
import app.terminalssh.secure.audio.AudioController
import app.terminalssh.secure.audio.AudioTarget
import app.terminalssh.secure.audio.AudioUi
import app.terminalssh.secure.ssh.SshSession
import app.terminalssh.secure.ui.theme.Amber
import app.terminalssh.secure.ui.theme.Cyan
import app.terminalssh.secure.ui.theme.Danger
import app.terminalssh.secure.ui.theme.TextSecondary
import app.terminalssh.secure.ui.theme.Turquoise
import kotlinx.coroutines.delay

/** Which of the two the user wants running. */
private data class Wanted(val mic: Boolean, val speaker: Boolean)

/**
 * The microphone and speaker buttons in a terminal's status line.
 *
 * Tap switches one of them on or off. The first time (and after a failure) a tap opens the
 * settings; a long press opens them at any time. Icon shape shows on and off, so colour is
 * never the only signal: a slashed icon is off or muted.
 */
@Composable
internal fun AudioActions(session: SshSession) {
    val context = LocalContext.current
    val app = context.applicationContext as TerminalApp
    val store = app.audioStore
    val ui by AudioController.ui.collectAsStateWithLifecycle()
    val hostId = session.hostId
    val mine = ui.activeFor(hostId)
    val micOn = mine && ui.mic
    val speakerOn = mine && ui.speaker

    var dialog by remember(hostId) { mutableStateOf<Wanted?>(null) }
    // Survives the activity being recreated while the permission prompt is up.
    var pendingSpeaker by rememberSaveable(hostId) { mutableStateOf(false) }

    fun startSaved(wanted: Wanted) {
        val target = store.target(hostId)
        val passphrase = store.passphrase(hostId)
        if (target == null || passphrase == null) {
            dialog = wanted
        } else {
            AudioController.start(context, hostId, target, passphrase, wanted.mic, wanted.speaker)
        }
    }

    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            startSaved(Wanted(mic = true, speaker = pendingSpeaker))
        } else {
            app.audioNotice(R.string.audio_permission_denied)
        }
    }

    fun switchTo(wanted: Wanted) {
        val configured = store.target(hostId) != null && store.passphrase(hostId) != null
        when {
            !wanted.mic && !wanted.speaker -> AudioController.stop(context)
            !configured -> dialog = wanted
            wanted.mic && ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) !=
                PackageManager.PERMISSION_GRANTED -> {
                pendingSpeaker = wanted.speaker
                permission.launch(Manifest.permission.RECORD_AUDIO)
            }
            else -> startSaved(wanted)
        }
    }

    var level by remember { mutableIntStateOf(0) }
    LaunchedEffect(micOn, ui.muted) {
        level = 0
        while (micOn && !ui.muted) {
            level = AudioController.level()
            delay(100)
        }
    }

    Row(horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.CenterVertically) {
        AudioButton(
            icon = if (micOn && !ui.muted) Icons.Outlined.Mic else Icons.Outlined.MicOff,
            description = stringResource(
                when {
                    micOn && ui.muted -> R.string.audio_mic_muted
                    micOn -> R.string.audio_mic_on
                    else -> R.string.audio_mic_off
                },
            ),
            tint = audioTint(ui, hostId, micOn, ui.muted),
            level = if (micOn && !ui.muted) level else null,
            onClick = {
                when {
                    ui.failedFor(hostId) -> dialog = Wanted(mic = true, speaker = false)
                    else -> switchTo(Wanted(mic = !micOn, speaker = speakerOn))
                }
            },
            onLongClick = { dialog = Wanted(mic = micOn || !mine, speaker = speakerOn) },
        )
        AudioButton(
            icon = if (speakerOn) Icons.AutoMirrored.Outlined.VolumeUp else Icons.AutoMirrored.Outlined.VolumeOff,
            description = stringResource(if (speakerOn) R.string.audio_speaker_on else R.string.audio_speaker_off),
            tint = audioTint(ui, hostId, speakerOn, muted = false),
            level = null,
            onClick = {
                when {
                    ui.failedFor(hostId) -> dialog = Wanted(mic = false, speaker = true)
                    else -> switchTo(Wanted(mic = micOn, speaker = !speakerOn))
                }
            },
            onLongClick = { dialog = Wanted(mic = micOn, speaker = speakerOn || !mine) },
        )
    }

    dialog?.let { initial ->
        AudioDialog(
            session = session,
            ui = ui,
            initialMic = initial.mic,
            initialSpeaker = initial.speaker,
            onDismiss = { dialog = null },
            onStop = {
                dialog = null
                AudioController.stop(context)
            },
            onApply = { target, newPassphrase, mic, speaker ->
                dialog = null
                val saved = runCatching { store.save(hostId, target, newPassphrase) }.isSuccess
                if (saved) switchTo(Wanted(mic, speaker)) else app.audioNotice(R.string.audio_save_failed)
            },
        )
    }
}

private fun audioTint(ui: AudioUi, hostId: String, on: Boolean, muted: Boolean): Color = when {
    ui.failedFor(hostId) -> Danger
    !on -> TextSecondary
    muted -> Amber
    ui.state == AudioBridge.State.CONNECTED -> Turquoise
    else -> Cyan
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AudioButton(
    icon: ImageVector,
    description: String,
    tint: Color,
    level: Int?,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .combinedClickable(
                role = Role.Button,
                onClick = onClick,
                onLongClickLabel = stringResource(R.string.audio_settings_action),
                onLongClick = onLongClick,
            )
            .padding(horizontal = 6.dp, vertical = 5.dp),
    ) {
        Icon(icon, contentDescription = description, tint = tint, modifier = Modifier.size(16.dp))
        // The input level, a 2dp line under the microphone. The space is always reserved so nothing jumps.
        Box(Modifier.width(16.dp).height(2.dp)) {
            if (level != null) {
                Box(Modifier.width((16 * level / 100f).dp).height(2.dp).background(Turquoise))
            }
        }
    }
}

@Composable
private fun AudioDialog(
    session: SshSession,
    ui: AudioUi,
    initialMic: Boolean,
    initialSpeaker: Boolean,
    onDismiss: () -> Unit,
    onStop: () -> Unit,
    onApply: (AudioTarget, String?, Boolean, Boolean) -> Unit,
) {
    val context = LocalContext.current
    val store = (context.applicationContext as TerminalApp).audioStore
    val hostId = session.hostId
    val saved = remember(hostId) { store.target(hostId) }
    val hasPassphrase = remember(hostId) { store.passphrase(hostId) != null }
    // The bridge usually runs on the machine this terminal is logged in to.
    val defaults = saved ?: AudioTarget(host = session.profile.host)

    var host by rememberSaveable(hostId) { mutableStateOf(defaults.host) }
    var port by rememberSaveable(hostId) { mutableStateOf(defaults.port.toString()) }
    // Deliberately not saveable: the passphrase never goes into the saved-state bundle.
    var passphrase by remember(hostId) { mutableStateOf("") }
    var mic by rememberSaveable(hostId) { mutableStateOf(initialMic) }
    var speaker by rememberSaveable(hostId) { mutableStateOf(initialSpeaker) }
    var micRate by rememberSaveable(hostId) { mutableIntStateOf(defaults.micRate) }
    var micStereo by rememberSaveable(hostId) { mutableStateOf(defaults.micChannels == 2) }
    var playRate by rememberSaveable(hostId) { mutableIntStateOf(defaults.playRate) }
    var playStereo by rememberSaveable(hostId) { mutableStateOf(defaults.playChannels == 2) }
    var voice by rememberSaveable(hostId) { mutableStateOf(defaults.voiceProcessing) }

    val portNumber = port.toIntOrNull()?.takeIf { it in 1..65535 }
    val passphraseOk = if (passphrase.isEmpty()) hasPassphrase else passphrase.length >= AudioTarget.MIN_PASSPHRASE
    val valid = host.isNotBlank() && portNumber != null && passphraseOk && (mic || speaker)
    val loopback = host.trim().let { it == "localhost" || it == "::1" || it.startsWith("127.") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.audio_title)) },
        text = {
            Column(
                Modifier.heightIn(max = 440.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                if (ui.owner == hostId && ui.message.isNotEmpty()) {
                    Text(
                        ui.message,
                        style = MaterialTheme.typography.labelMedium,
                        color = if (ui.failedFor(hostId)) Danger else Turquoise,
                    )
                } else if (ui.active) {
                    Hint(stringResource(R.string.audio_other_server))
                }
                if (ui.activeFor(hostId) && ui.mic) {
                    var level by remember { mutableIntStateOf(0) }
                    LaunchedEffect(Unit) {
                        while (true) {
                            level = AudioController.level()
                            delay(100)
                        }
                    }
                    LinearProgressIndicator(progress = { level / 100f }, modifier = Modifier.fillMaxWidth())
                    SwitchRow(stringResource(R.string.audio_mute), ui.muted) { AudioController.setMuted(it) }
                }
                Hint(stringResource(R.string.audio_help))
                OutlinedTextField(
                    value = host,
                    onValueChange = { host = it.trim() },
                    label = { Text(stringResource(R.string.audio_host)) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                    modifier = Modifier.fillMaxWidth(),
                )
                if (loopback) Hint(stringResource(R.string.audio_loopback_warning), Amber)
                OutlinedTextField(
                    value = port,
                    onValueChange = { port = it.filter(Char::isDigit).take(5) },
                    label = { Text(stringResource(R.string.audio_port)) },
                    singleLine = true,
                    isError = portNumber == null,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = passphrase,
                    onValueChange = { passphrase = it },
                    label = {
                        Text(stringResource(if (hasPassphrase) R.string.audio_passphrase_keep else R.string.audio_passphrase))
                    },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    isError = passphrase.isNotEmpty() && passphrase.length < AudioTarget.MIN_PASSPHRASE,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    modifier = Modifier.fillMaxWidth(),
                )
                SwitchRow(stringResource(R.string.audio_microphone), mic) { mic = it }
                if (mic) {
                    RateChips(AudioTarget.MIC_RATES, micRate) { micRate = it }
                    SwitchRow(stringResource(R.string.audio_stereo_mic), micStereo) { micStereo = it }
                    SwitchRow(stringResource(R.string.audio_voice_processing), voice) { voice = it }
                }
                SwitchRow(stringResource(R.string.audio_speaker), speaker) { speaker = it }
                if (speaker) {
                    RateChips(AudioTarget.PLAY_RATES, playRate) { playRate = it }
                    SwitchRow(stringResource(R.string.audio_stereo_speaker), playStereo) { playStereo = it }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = valid,
                onClick = {
                    val target = AudioTarget(
                        host = host.trim(),
                        port = portNumber ?: AudioTarget.DEFAULT_PORT,
                        micRate = micRate,
                        micChannels = if (micStereo) 2 else 1,
                        playRate = playRate,
                        playChannels = if (playStereo) 2 else 1,
                        voiceProcessing = voice,
                    )
                    onApply(target, passphrase.ifEmpty { null }, mic, speaker)
                },
            ) { Text(stringResource(R.string.audio_connect), color = if (valid) Turquoise else TextSecondary) }
        },
        dismissButton = {
            Row {
                if (ui.active) {
                    TextButton(onClick = onStop) { Text(stringResource(R.string.audio_stop), color = Danger) }
                }
                TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
            }
        },
        containerColor = MaterialTheme.colorScheme.surface,
    )
}

@Composable
private fun Hint(text: String, color: Color = TextSecondary) {
    Text(text, style = MaterialTheme.typography.labelSmall, color = color)
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun RateChips(rates: List<Int>, selected: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        rates.forEach { rate ->
            FilterChip(
                selected = rate == selected,
                onClick = { onSelect(rate) },
                label = { Text(if (rate % 1000 == 0) "${rate / 1000} kHz" else "${rate / 1000.0} kHz") },
            )
        }
    }
}
