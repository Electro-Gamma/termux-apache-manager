// SPDX-License-Identifier: GPL-3.0-or-later
package com.vncviewer.app.realvnc

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.realvnc.vncviewer.jni.ConnectionInfoBindings
import com.realvnc.vncviewer.jni.SessionBindings
import com.vncviewer.app.vnc.RemoteBackend
import com.vncviewer.app.vnc.RemotePrompt
import com.vncviewer.app.vnc.VncListener
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean

/**
 * A [RemoteBackend] on the native VNC engine (libvncviewer.so, built from app/src/main/cpp).
 *
 * Thread discipline:
 *  - The library runs each connection on a native thread of its own and delivers every
 *    callback there. Those callbacks do almost nothing: they hand the work to the worker thread
 *    ([RealVncCore]), which owns the bitmaps and every call back into the library.
 *  - Pixels are read on the worker thread when an update ends, in 256x256 tiles through a
 *    small native scratch buffer, and painted into one desktop-sized Bitmap which the UI draws.
 *  - A session is destroyed only after its sessionClosed callback, and never from inside a
 *    callback: destroying joins the native thread.
 *
 * What the engine does not do itself is done here: it has no automatic reconnect and no
 * picture-quality presets beyond the choice of encoding, so [setAutoReconnect] drives a retry
 * loop of new sessions and [setQuality] picks the encoding.
 */
class RealVncBackend(
    context: Context,
    private val address: String,
    private val userName: String,
    passwordText: String,
    quality: String,
    viewOnly: Boolean,
    private val listener: VncListener
) : RemoteBackend, SessionBindings.DesktopCallback, SessionBindings.SessionCallback {

    private enum class State { IDLE, CONNECTING, CONNECTED, RECONNECTING, CLOSED }

    private val appContext: Context = context.applicationContext
    private val mainHandler = Handler(Looper.getMainLooper())

    /** Empty is not a password: the engine would authenticate with "" instead of asking. */
    private val passwordArg: String? = if (passwordText.isEmpty()) null else passwordText

    private val options = LinkedHashMap<String, String>()

    @Volatile
    private var session: SessionBindings.Session? = null

    @Volatile
    private var state = State.IDLE

    @Volatile
    private var dead = false

    // ---- pixels (worker thread only, except the dirty union) -----------------------------
    private var desktopW = 0
    private var desktopH = 0
    private var desktop: Bitmap? = null
    private var desktopCanvas: Canvas? = null
    private var tileBitmap: Bitmap? = null
    private var tileBuffer: ByteBuffer? = null
    private var dirty = BooleanArray(0)
    private var cellsX = 0
    private var cellsY = 0
    private var anyDirty = false
    private val srcRect = Rect()
    private val dstRect = Rect()
    private val copyPaint = Paint()

    /** Rectangle of this update's drawRegion calls, filled on the native thread. */
    private val unionLock = Any()
    private var haveUnion = false
    private var ux0 = 0
    private var uy0 = 0
    private var ux1 = 0
    private var uy1 = 0

    // ---- misc ----------------------------------------------------------------------------
    private val held = LinkedHashSet<Int>()

    @Volatile
    private var pendingClipboardText: String? = null

    @Volatile
    private var pendingPointer = -1L
    private val moveScheduled = AtomicBoolean(false)

    @Volatile
    private var autoReconnect = true

    /** What the session said when it ended (the engine's message box), for the disconnected screen. */
    @Volatile
    private var lastError: String? = null

    /** The remote screen cannot be shown: do not try again. */
    @Volatile
    private var fatal = false
    private var everConnected = false
    private var attempts = 0

    /**
     * Prompts on screen. The connect timeout is about a session that has gone silent, and a
     * session waiting for a password has not. Worker thread only.
     */
    private var outstandingPrompts = 0
    private val connectTimeout = Runnable { onConnectTimeout() }
    private val updateEnd = Runnable { onUpdateEnd() }
    private val reconnectNow = Runnable { onReconnectDue() }

    init {
        copyPaint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC)

        options["ViewOnly"] = if (viewOnly) "1" else "0"
        options["Shared"] = "1"
        options["PreferredEncoding"] = encodingFor(quality)
        // RSA-AES sign-in: prefer the variants that encrypt the whole session, not just the login.
        options["PreferEncrypted"] = "1"
        options["ConnectTimeout"] = "15"
        if (userName.isNotEmpty()) options["Username"] = userName
        if (passwordArg != null) options["Password"] = passwordArg
    }

    internal fun addressText(): String = address

    internal fun userNameText(): String = userName

    // =====================================================================================
    // Lifecycle
    // =====================================================================================

    override fun start() {
        if (state != State.IDLE) return
        state = State.CONNECTING
        try {
            RealVncCore.start(appContext)
        } catch (t: Throwable) {
            Log.e(TAG, "engine start failed", t)
            state = State.CLOSED
            listener.onDisconnected(
                "The RealVNC engine could not start: " + (t.message ?: t.javaClass.simpleName)
            )
            return
        }
        listener.onStatus("Connecting to $address\u2026")
        RealVncCore.post { createOnCoreThread() }
    }

    private fun createOnCoreThread() {
        if (dead) return
        RealVncCore.cancel(connectTimeout)
        RealVncCore.postDelayed(connectTimeout, CONNECT_TIMEOUT_MS)
        val snapshot = HashMap<String, String>()
        synchronized(options) { snapshot.putAll(options) }

        lastError = null
        RealVncPrompts.connecting(this)
        var s: SessionBindings.Session? = null
        try {
            // No uuid: the library would remember the password under it for the whole process.
            s = SessionBindings.createSession(this, this, address, null, snapshot)
        } catch (t: Throwable) {
            Log.e(TAG, "createSession failed", t)
        } finally {
            RealVncPrompts.connected(this)
        }
        if (s == null) {
            RealVncCore.cancel(connectTimeout)
            closed("Could not start the connection")
            return
        }
        session = s
        RealVncPrompts.attach(s, this)

        // The scratch buffer the engine scales regions into, and the bitmap it is copied to.
        try {
            tileBuffer = SessionBindings.setScaleBufferSize(s, TILE, TILE)
            tileBitmap = Bitmap.createBitmap(TILE, TILE, Bitmap.Config.ARGB_8888)
        } catch (t: Throwable) {
            Log.e(TAG, "scale buffer", t)
        }
        SessionBindings.focusEvent(s, true)
    }

    /** The engine reports its own failures; this is the net under a server that just goes quiet. */
    private fun onConnectTimeout() {
        val s = session
        if (state == State.CONNECTING || state == State.RECONNECTING) {
            Log.w(TAG, "no connSuccess within $CONNECT_TIMEOUT_MS ms")
            if (lastError == null) lastError = "Could not connect to $address"
            if (s != null) SessionBindings.closeSession(s)
        }
    }

    override fun close() {
        dead = true
        RealVncCore.cancel(connectTimeout)
        RealVncCore.cancel(updateEnd)
        RealVncCore.cancel(reconnectNow)
        RealVncCore.post {
            val s = session
            if (s != null) {
                try {
                    SessionBindings.closeSession(s)
                } catch (t: Throwable) {
                    Log.w(TAG, "closing session", t)
                }
            } else {
                releaseTile()
            }
        }
    }

    private fun releaseTile() {
        tileBuffer = null
        val tile = tileBitmap
        tileBitmap = null
        tile?.recycle()
    }

    /** Worker thread. The session is over; free it and decide between reconnecting and ending. */
    private fun onNativeClosed(ended: SessionBindings.Session?) {
        if (ended != null) {
            RealVncPrompts.detach(ended)
            try {
                // Safe here: sessionClosed is the native thread's last act, so this join is brief.
                SessionBindings.destroySession(ended)
            } catch (t: Throwable) {
                Log.w(TAG, "destroySession", t)
            }
        }
        if (ended != null && session !== ended) return
        session = null
        RealVncCore.cancel(connectTimeout)
        releaseTile()
        if (dead || state == State.CLOSED) return

        val reason = lastError
        lastError = null
        if (shouldReconnect(reason)) {
            attempts++
            state = State.RECONNECTING
            listener.onBanner("Connection lost. Reconnecting ($attempts/$MAX_ATTEMPTS)\u2026")
            RealVncCore.postDelayed(reconnectNow, minOf(2_000L * attempts, 10_000L))
            return
        }
        closed(reason)
    }

    private fun shouldReconnect(reason: String?): Boolean {
        if (fatal || !autoReconnect || !everConnected || attempts >= MAX_ATTEMPTS) return false
        // A refused password will be refused again; asking over and over is not reconnecting.
        val r = reason?.lowercase() ?: return true
        return !(r.contains("password") || r.contains("authentication") || r.contains("credentials"))
    }

    private fun onReconnectDue() {
        if (dead || state != State.RECONNECTING) return
        if (!autoReconnect) {
            listener.onBanner(null)
            closed("Disconnected")
            return
        }
        createOnCoreThread()
    }

    private fun closed(detail: String?) {
        if (state == State.CLOSED) return
        state = State.CLOSED
        listener.onDisconnected(detail ?: "Disconnected")
    }

    /** Stop the session for a reason of ours; [onNativeClosed] then ends it without a retry. */
    private fun fail(detail: String) {
        fatal = true
        lastError = detail
        val s = session
        if (s != null) SessionBindings.closeSession(s) else closed(detail)
    }

    /** Run something on the worker thread with the live handle, if there is one. */
    private fun onSession(what: (SessionBindings.Session) -> Unit): Boolean {
        val s = session
        if (s == null || dead) return false
        RealVncCore.post {
            if (session === s) what(s)
        }
        return true
    }

    // =====================================================================================
    // RemoteBackend: input
    // =====================================================================================

    override fun sendPointer(x: Int, y: Int, buttonMask: Int) {
        onSession { s -> SessionBindings.pointerEvent(s, x, y, buttonMask) }
    }

    override fun sendPointerMove(x: Int, y: Int, buttonMask: Int) {
        pendingPointer = (buttonMask.toLong() shl 40) or (x.toLong() shl 20) or y.toLong()
        if (moveScheduled.compareAndSet(false, true)) {
            RealVncCore.post {
                moveScheduled.set(false)
                val s = session
                val v = pendingPointer
                if (s != null && !dead && v >= 0) {
                    val mask = ((v shr 40) and 0x1FF).toInt()
                    val px = ((v shr 20) and 0xFFFFF).toInt()
                    val py = (v and 0xFFFFF).toInt()
                    SessionBindings.pointerEvent(s, px, py, mask)
                }
            }
        }
    }

    /** The release is matched to its press by the keysym itself, which is unique per key. */
    override fun sendKey(keySym: Int, down: Boolean) {
        onSession { s ->
            if (down) {
                held.add(keySym)
                SessionBindings.keyDownEvent(s, keySym.toLong() and 0xFFFFFFFFL, keySym)
            } else {
                held.remove(keySym)
                SessionBindings.keyUpEvent(s, keySym)
            }
        }
    }

    /**
     * The engine sends our clipboard to the server when the viewer GAINS focus, asking us for
     * the text through getClipboard(). So: remember the text, then lose and regain focus.
     * Losing focus releases every key the engine saw pressed, so the ones still held (a sticky
     * Ctrl for Ctrl+V) are pressed again afterwards.
     */
    override fun sendClipboard(text: String) {
        pendingClipboardText = text
        onSession { s ->
            val keys = ArrayList(held)
            SessionBindings.focusEvent(s, false)
            SessionBindings.focusEvent(s, true)
            for (k in keys) SessionBindings.keyDownEvent(s, k.toLong() and 0xFFFFFFFFL, k)
        }
    }

    override fun setFocused(focused: Boolean) {
        onSession { s -> SessionBindings.focusEvent(s, focused) }
    }

    /** Redraw everything from the engine's own framebuffer. */
    override fun refresh() {
        RealVncCore.post {
            markDirty(0, 0, desktopW, desktopH)
            flushDirty()
            listener.onFrameUpdated()
        }
    }

    override fun setAutoReconnect(enabled: Boolean) {
        autoReconnect = enabled
    }

    /** The engine's picture-quality lever is the encoding; colour depth is always full. */
    override fun setQuality(quality: String) {
        val encoding = encodingFor(quality)
        synchronized(options) { options["PreferredEncoding"] = encoding }
        onSession { s ->
            SessionBindings.setOption(s, "PreferredEncoding", encoding)
            SessionBindings.applyOptions(s)
        }
    }

    override fun connectionInfo(callback: (List<Pair<String, String>>) -> Unit) {
        val s = session
        if (s == null || dead || state != State.CONNECTED) {
            mainHandler.post { callback(emptyList()) }
            return
        }
        RealVncCore.post {
            val rows = ArrayList<Pair<String, String>>()
            if (!dead && session === s) {
                rows.add(Pair("Engine", "Native VNC engine (libvncviewer)"))
                fun add(label: String, read: () -> String?) {
                    try {
                        val text = read()
                        if (!text.isNullOrEmpty()) rows.add(Pair(label, text))
                    } catch (_: Throwable) {
                    }
                }
                add("Desktop") { ConnectionInfoBindings.getDesktopName(s) }
                add("Protocol") { ConnectionInfoBindings.getProtoVersion(s) }
                add("Connection") { ConnectionInfoBindings.getConnectionType(s) }
                add("Security") { ConnectionInfoBindings.getSecurityDesc(s) }
                add("Encoding") { ConnectionInfoBindings.getLastUsedEncoding(s) }
                add("Server pixels") { ConnectionInfoBindings.getServerPixelFormat(s) }
                add("Viewer pixels") { ConnectionInfoBindings.getViewerPixelFormat(s) }
            }
            mainHandler.post { callback(rows) }
        }
    }

    // =====================================================================================
    // Pixels (worker thread)
    // =====================================================================================

    private fun markDirty(x: Int, y: Int, w: Int, h: Int) {
        if (desktopW <= 0 || desktopH <= 0 || w <= 0 || h <= 0) return
        val x0 = if (x < 0) 0 else x
        val y0 = if (y < 0) 0 else y
        val x1 = if (x + w > desktopW) desktopW else x + w
        val y1 = if (y + h > desktopH) desktopH else y + h
        if (x1 <= x0 || y1 <= y0) return
        val cx0 = x0 / TILE
        val cx1 = (x1 - 1) / TILE
        val cy0 = y0 / TILE
        val cy1 = (y1 - 1) / TILE
        for (cy in cy0..cy1) {
            for (cx in cx0..cx1) {
                dirty[cy * cellsX + cx] = true
            }
        }
        anyDirty = true
    }

    /** Read every dirty 256x256 cell out of the engine and paint it into the desktop bitmap. */
    private fun flushDirty() {
        if (!anyDirty) return
        anyDirty = false
        val s = session
        val buf = tileBuffer
        val tile = tileBitmap
        val canvas = desktopCanvas
        if (s == null || dead || buf == null || tile == null || canvas == null) {
            java.util.Arrays.fill(dirty, false)
            return
        }
        for (cy in 0 until cellsY) {
            for (cx in 0 until cellsX) {
                val idx = cy * cellsX + cx
                if (!dirty[idx]) continue
                dirty[idx] = false
                val x = cx * TILE
                val y = cy * TILE
                val w = if (desktopW - x < TILE) desktopW - x else TILE
                val h = if (desktopH - y < TILE) desktopH - y else TILE
                try {
                    // Writes the region to the FRONT of the scratch buffer at the buffer's stride.
                    SessionBindings.copyScaledRegion(1f, s, x, y, w, h)
                    buf.rewind()
                    tile.copyPixelsFromBuffer(buf)
                    srcRect.set(0, 0, w, h)
                    dstRect.set(x, y, x + w, y + h)
                    canvas.drawBitmap(tile, srcRect, dstRect, copyPaint)
                } catch (t: Throwable) {
                    Log.w(TAG, "copyScaledRegion", t)
                }
            }
        }
    }

    private fun onUpdateEnd() {
        var x0 = 0
        var y0 = 0
        var x1 = 0
        var y1 = 0
        var any: Boolean
        synchronized(unionLock) {
            any = haveUnion
            x0 = ux0
            y0 = uy0
            x1 = ux1
            y1 = uy1
            haveUnion = false
        }
        if (any) markDirty(x0, y0, x1 - x0, y1 - y0)
        flushDirty()
        listener.onFrameUpdated()
    }

    private fun applyDesktopSize(width: Int, height: Int) {
        if (width <= 0 || height <= 0 || dead) return
        if (width.toLong() * height.toLong() > 80_000_000L) {
            fail("The remote screen is too large (${width}x$height)")
            return
        }
        val bmp: Bitmap
        try {
            bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        } catch (e: OutOfMemoryError) {
            fail("Out of memory: the remote screen is too large for this device.")
            return
        }
        // Pixels from the engine carry alpha 0xFF, but treat the bitmap as opaque regardless.
        bmp.setHasAlpha(false)
        bmp.eraseColor(Color.BLACK)
        desktop = bmp
        desktopCanvas = Canvas(bmp)
        desktopW = width
        desktopH = height
        cellsX = (width + TILE - 1) / TILE
        cellsY = (height + TILE - 1) / TILE
        dirty = BooleanArray(cellsX * cellsY)
        anyDirty = false
        synchronized(unionLock) { haveUnion = false }

        var name = ""
        val s = session
        if (s != null) {
            try {
                name = ConnectionInfoBindings.getDesktopName(s) ?: ""
            } catch (_: Throwable) {
            }
        }
        listener.onFramebufferReady(bmp, if (name.isEmpty()) address else name)
        markDirty(0, 0, width, height)
        flushDirty()
        listener.onFrameUpdated()
    }

    // =====================================================================================
    // DesktopCallback / SessionCallback: native session thread. Hand off; never block.
    // =====================================================================================

    override fun connSuccess() {
        RealVncCore.post {
            Log.i(TAG, "connSuccess")
            RealVncCore.cancel(connectTimeout)
            val wasReconnecting = state == State.RECONNECTING
            state = State.CONNECTED
            everConnected = true
            attempts = 0
            if (wasReconnecting) listener.onBanner(null)
            listener.onStatus("Connected")
        }
    }

    override fun setDesktopSize(width: Int, height: Int) {
        Log.i(TAG, "setDesktopSize ${width}x$height")
        RealVncCore.enqueue(Runnable { applyDesktopSize(width, height) })
    }

    override fun drawRegion(x: Int, y: Int, width: Int, height: Int) {
        if (width <= 0 || height <= 0) return
        synchronized(unionLock) {
            if (!haveUnion) {
                ux0 = x
                uy0 = y
                ux1 = x + width
                uy1 = y + height
                haveUnion = true
            } else {
                if (x < ux0) ux0 = x
                if (y < uy0) uy0 = y
                if (x + width > ux1) ux1 = x + width
                if (y + height > uy1) uy1 = y + height
            }
        }
    }

    override fun framebufferUpdateEnd() {
        RealVncCore.enqueue(updateEnd)
    }

    /**
     * The two ints are the cursor's hotspot. (RealVNC's own core handed over the negated
     * hotspot; this engine passes the RFB rectangle's x/y straight through.)
     */
    override fun setCursor(bitmap: Any?, hotX: Int, hotY: Int) {
        listener.onCursor(bitmap as? Bitmap, hotX, hotY)
    }

    override fun bell() {
        listener.onBell()
    }

    /** Asked for by the engine, on whatever thread regained focus. */
    override fun getClipboard(): String? = pendingClipboardText

    override fun setClipboard(text: String?) {
        if (!text.isNullOrEmpty()) listener.onServerCutText(text)
    }

    override fun sessionClosed(ended: SessionBindings.Session?) {
        Log.i(TAG, "sessionClosed")
        RealVncCore.enqueue(Runnable { onNativeClosed(ended) })
    }

    // =====================================================================================
    // Called by RealVncPrompts
    // =====================================================================================

    internal fun ask(prompt: RemotePrompt) {
        RealVncCore.post {
            outstandingPrompts++
            RealVncCore.cancel(connectTimeout)
        }
        listener.onPrompt(prompt)
    }

    internal fun promptAnswered() {
        RealVncCore.post {
            outstandingPrompts = if (outstandingPrompts > 0) outstandingPrompts - 1 else 0
            if (outstandingPrompts == 0 &&
                (state == State.CONNECTING || state == State.RECONNECTING) && !dead
            ) {
                RealVncCore.postDelayed(connectTimeout, CONNECT_TIMEOUT_MS)
            }
        }
    }

    /** The engine's last words about why a session ended. */
    internal fun sessionMessage(text: String) {
        Log.i(TAG, "session message: $text")
        lastError = text
    }

    // =====================================================================================

    private companion object {
        const val TAG = RealVncCore.TAG
        const val TILE = 256
        const val CONNECT_TIMEOUT_MS = 30_000L
        const val MAX_ATTEMPTS = 10

        /** The engine offers encodings, not quality levels: Auto and High take the best, lower ones the lighter. */
        fun encodingFor(quality: String): String = when (quality) {
            "Medium" -> "Hextile"
            "Low" -> "Hextile"
            else -> "ZRLE"
        }
    }
}
