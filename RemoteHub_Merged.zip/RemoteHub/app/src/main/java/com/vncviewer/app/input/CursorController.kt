// SPDX-License-Identifier: MIT
//
// Kotlin port of Vento's CursorController.java (https://github.com/pgaskin/vento, control/
// module, (C) 2026 Patrick Gaskin, MIT). The "relative cursor" mode (far end owns the
// cursor) is not used by this app and is omitted.
package com.vncviewer.app.input

/** The one cursor: desktop position, the union of every source's buttons, and what is sent. */
class CursorController(
    private val cfg: Config,
    private val viewport: Viewport,
    private val out: PointerSink,
    private val scheduler: Scheduler
) : MouseSink {

    interface PointerSink {
        fun pointerEvent(x: Float, y: Float, buttons: Int)
    }

    interface Listener {
        fun onCursorChanged()
        fun onButtonsReleased() {
        }
    }

    private var listener: Listener? = null
    private var x = 0f
    private var y = 0f
    private var buttons = 0
    private var clicking = 0
    private val sources = ArrayList<IntArray>()
    private val own: IntArray = newSourceMask()
    private var framePending = false
    private val frameCallback = Runnable {
        framePending = false
        emit()
    }
    private var eventCount = 0
    private var suppressedCount = 0
    private var sentX = 0f
    private var sentY = 0f
    private var sentButtons = 0
    private var everSent = false

    fun setListener(l: Listener?) {
        listener = l
    }

    // Where the cursor may be: anywhere on the desktop, or - with the screen locked - only on the
    // part of it that is on screen, so it can never leave the picture the user is looking at.
    private fun limitX(v: Float): Float =
        if (viewport.isFrozen()) {
            val lo = viewport.visibleLeft()
            Viewport.clamp(v, lo, Math.max(lo, viewport.visibleRight()))
        } else {
            Viewport.clamp(v, 0f, (viewport.desktopWidth() - 1).toFloat())
        }

    private fun limitY(v: Float): Float =
        if (viewport.isFrozen()) {
            val lo = viewport.visibleTop()
            Viewport.clamp(v, lo, Math.max(lo, viewport.visibleBottom()))
        } else {
            Viewport.clamp(v, 0f, (viewport.desktopHeight() - 1).toFloat())
        }

    /** Bring the cursor inside the visible area (the screen was just locked, or its size changed). */
    fun keepInView() {
        val nx = limitX(x)
        val ny = limitY(y)
        if (nx != x || ny != y) {
            x = nx
            y = ny
            post()
        }
        changed()
    }

    fun x(): Float = x
    fun y(): Float = y
    fun buttons(): Int = buttons
    fun screenX(): Float = viewport.toScreenX(x)
    fun screenY(): Float = viewport.toScreenY(y)
    fun eventCount(): Int = eventCount
    fun suppressedCount(): Int = suppressedCount

    /** Put the cursor on a desktop point and bring the viewport to it. */
    fun setPosition(dx: Float, dy: Float) {
        x = limitX(dx)
        y = limitY(dy)
        viewport.centreOn(x, y)
        changed()
    }

    /** Direct touch: put the cursor under a finger and send it, leaving the viewport alone. */
    fun setPositionHere(dx: Float, dy: Float) {
        x = limitX(dx)
        y = limitY(dy)
        post()
        changed()
    }

    fun setInsets(left: Int, top: Int, right: Int, bottom: Int) {
        if (viewport.isFrozen()) {
            // Locked: the picture stays where it is; the keyboard row only changes how much of it
            // is visible, and the cursor is kept inside that.
            viewport.setInsets(left, top, right, bottom)
            keepInView()
            return
        }
        val centredX = Math.abs(screenX() - viewport.centreScreenX()) <= 0.5f
        val centredY = Math.abs(screenY() - viewport.centreScreenY()) <= 0.5f
        viewport.setInsets(left, top, right, bottom)
        if (viewport.getScale() < viewport.minScale()) {
            viewport.centreOn(x, y, viewport.minScale())
        }
        val nx = if (centredX) viewport.toDesktopX(viewport.centreScreenX()) else x
        val ny = if (centredY) viewport.toDesktopY(viewport.centreScreenY()) else y
        if (nx != x || ny != y) {
            x = Viewport.clamp(nx, 0f, (viewport.desktopWidth() - 1).toFloat())
            y = Viewport.clamp(ny, 0f, (viewport.desktopHeight() - 1).toFloat())
            post()
        }
        viewport.centreOn(x, y)
        changed()
    }

    /** Put the cursor at the middle of the view (after a zoom). */
    fun centreCursor(send: Boolean) {
        x = limitX(viewport.toDesktopX(viewport.centreScreenX()))
        y = limitY(viewport.toDesktopY(viewport.centreScreenY()))
        if (send) post()
        viewport.centreOn(x, y)
        changed()
    }

    override fun mouseMove(dx: Float, dy: Float) {
        val s = viewport.getScale()
        x = limitX(x + dx / s)
        y = limitY(y + dy / s)
        post()
        viewport.centreOn(x, y) // does nothing while the screen is locked
        changed()
    }

    override fun mouseDown(mask: Int) = press(own, mask)

    override fun mouseUp(mask: Int) = unpress(own, mask)

    /** A button source of its own, so one source letting go cannot release another's button. */
    fun newButtonSource(): MouseSink {
        val mask = newSourceMask()
        return object : MouseSink {
            override fun mouseMove(dx: Float, dy: Float) {
                this@CursorController.mouseMove(dx, dy)
            }

            override fun mouseDown(mask2: Int) {
                press(mask, mask2)
            }

            override fun mouseUp(mask2: Int) {
                unpress(mask, mask2)
            }
        }
    }

    private fun newSourceMask(): IntArray {
        val m = IntArray(1)
        sources.add(m)
        return m
    }

    private fun press(source: IntArray, mask: Int) {
        source[0] = source[0] or mask
        union()
        flush()
        clickEdge()
        changed()
    }

    private fun unpress(source: IntArray, mask: Int) {
        source[0] = source[0] and mask.inv()
        union()
        flush()
        clickEdge()
        changed()
    }

    private fun clickEdge() {
        val now = buttons and Button.CLICK_MASK
        val was = clicking
        clicking = now
        if (was != 0 && now == 0) listener?.onButtonsReleased()
    }

    private fun union() {
        var m = 0
        for (s in sources) m = m or s[0]
        buttons = m
    }

    private fun post() {
        if (!cfg.coalescePointerEvents) {
            emit()
            return
        }
        if (!framePending) {
            framePending = true
            scheduler.postFrame(frameCallback)
        }
    }

    private fun flush() {
        if (framePending) {
            framePending = false
            scheduler.removeFrame(frameCallback)
        }
        emit()
    }

    private fun emit() {
        if (cfg.dedupePointerEvents && everSent && x == sentX && y == sentY && buttons == sentButtons) {
            suppressedCount++
            return
        }
        everSent = true
        sentX = x
        sentY = y
        sentButtons = buttons
        eventCount++
        out.pointerEvent(x, y, buttons)
    }

    /** Forget what was last sent, so the next position is sent even if unchanged. */
    fun forgetSent() {
        everSent = false
    }

    private fun changed() {
        listener?.onCursorChanged()
    }
}
