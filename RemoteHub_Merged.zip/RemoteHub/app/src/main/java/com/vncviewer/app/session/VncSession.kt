package com.vncviewer.app.session

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.view.KeyCharacterMap
import android.view.KeyEvent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.vncviewer.app.data.Engine
import com.vncviewer.app.input.AppSettings
import com.vncviewer.app.input.Button
import com.vncviewer.app.input.SessionInput
import com.vncviewer.app.input.TapRegions
import com.vncviewer.app.input.Toolbar
import com.vncviewer.app.data.VncProfile
import com.vncviewer.app.realvnc.RealVncBackend
import com.vncviewer.app.realvnc.RealVncCore
import com.vncviewer.app.vnc.Keysyms
import com.vncviewer.app.vnc.RemoteBackend
import com.vncviewer.app.vnc.RemotePrompt
import com.vncviewer.app.vnc.VncClient
import com.vncviewer.app.vnc.VncListener
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.roundToInt

enum class Phase { CONNECTING, AUTH_REQUIRED, CONNECTED, FAILED }

enum class MouseMode(val label: String) {
    /** Vento's model: the finger moves a cursor (accelerated, with momentum); taps click. */
    TOUCHPAD("Touchpad"),

    /** The finger is the pointer: tap where you want to click. */
    DIRECT("Direct touch")
}

enum class ScaleMode(val label: String) {
    ORIGINAL("1:1"),
    FIT("Fit"),
    FILL("Fill")
}

/**
 * One open VNC connection: network client + everything the UI needs
 * (framebuffer, viewport, mouse/keyboard state). All state is Compose state,
 * all mutating methods must be called on the main thread.
 */
class VncSession(
    private val appContext: Context,
    val id: String,
    initialProfile: VncProfile
) {
    // ---- connection state ----------------------------------------------------------
    var profile by mutableStateOf(initialProfile)
    var phase by mutableStateOf(Phase.CONNECTING)
    var status by mutableStateOf("Connecting\u2026")
    var error by mutableStateOf<String?>(null)
    var passwordRejected by mutableStateOf(false)
    var desktopName by mutableStateOf("")
    var notice by mutableStateOf<String?>(null)

    /** True once the first frame has arrived; the UI uses it to show the controls hint. */
    var firstFrame by mutableStateOf(false)

    /** The "Controls" explanation is up: the tap regions are drawn over the desktop. */
    var showHints by mutableStateOf(false)
    var hintsHandled = false

    /** What was typed since the last Enter, for the extension keyboard's info bar. */
    var typedLine by mutableStateOf("")

    /** Two more armed modifiers of the extension keyboard (Mac layout names). */
    var option by mutableStateOf(false)
    var cmd by mutableStateOf(false)

    /** Bumped when a modifier key was pressed (the IME returns to its letters). */
    var imeRestartTick by mutableIntStateOf(0)

    /** Questions from the RealVNC engine (sign-in, server identity, messages); first one is shown. */
    val prompts = mutableStateListOf<RemotePrompt>()

    /** Temporary banner, e.g. "Reconnecting..." (RealVNC engine). */
    var banner by mutableStateOf<String?>(null)

    /** The connection sheet is open. */
    var infoOpen by mutableStateOf(false)

    /** The desktop is being recorded to a video (the toolbar's Record button). */
    var recording by mutableStateOf(false)
        private set
    private var recorder: ScreenRecorder? = null

    /** The "with or without microphone" question is showing. */
    var recordChoiceOpen by mutableStateOf(false)

    /** The Record button: stop if recording, otherwise ask how to record. */
    fun toggleRecording() {
        val r = recorder
        if (r != null && r.isRecording) {
            stopRecording()
            return
        }
        recordChoiceOpen = true
    }

    fun startRecording(withMic: Boolean) {
        recordChoiceOpen = false
        val fresh = ScreenRecorder(
            appContext, { bitmap },
            {
                // The same rule as the canvas: the server's pointer, except in a view-only session.
                val shape = remoteCursor
                if (viewOnly || shape == null) null
                else CursorFrame(shape, cursorHotX, cursorHotY, input.cursor.x(), input.cursor.y())
            },
            desktopName.ifEmpty { profile.host }
        )
        if (!fresh.start(withMic)) {
            showNotice(
                if (withMic) "Recording could not be started (is the microphone free?)"
                else "Recording could not be started"
            )
            return
        }
        recorder = fresh
        recording = true
        addLog(if (withMic) "Recording started, with microphone" else "Recording started")
        showNotice(if (withMic) "Recording the desktop with microphone" else "Recording the desktop")
        input.syncToolbarState()
    }

    fun stopRecording() {
        val r = recorder ?: return
        recorder = null
        r.stop()
        if (recording) addLog("Recording stopped")
        recording = false
        input.syncToolbarState()
    }

    /** Facts for the connection sheet, refreshed while it is open. */
    var infoRows by mutableStateOf<List<Pair<String, String>>?>(null)

    /** RealVNC engine: Auto, High, Medium, Low. */
    var quality by mutableStateOf(initialProfile.quality)

    /** RealVNC engine: reconnect on its own when the link drops (the sheet's switch). */
    var autoReconnect by mutableStateOf(true)

    /** What the session did, oldest first, for the sheet's "View log". */
    val logLines = mutableStateListOf<String>()

    fun addLog(message: String) {
        val stamp = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())
        logLines.add("$stamp  $message")
        while (logLines.size > 300) logLines.removeAt(0)
    }

    /** Remote cursor shape (RealVNC engine); null until the server sends one. */
    var remoteCursor by mutableStateOf<Bitmap?>(null)
    var cursorHotX by mutableIntStateOf(0)
    var cursorHotY by mutableIntStateOf(0)

    // ---- framebuffer -----------------------------------------------------------------
    @Volatile
    var bitmap: Bitmap? = null
    var fbWidth by mutableIntStateOf(0)
    var fbHeight by mutableIntStateOf(0)
    var frameTick by mutableIntStateOf(0)

    // ---- viewport ----------------------------------------------------------------------
    var scaleMode by mutableStateOf(ScaleMode.ORIGINAL)

    // ---- input state -------------------------------------------------------------------
    var mouseMode by mutableStateOf(MouseMode.TOUCHPAD)
    var panDragMode by mutableStateOf(false)
    var viewOnly by mutableStateOf(initialProfile.viewOnly)
    var imeVisible by mutableStateOf(false)

    /** Set by the owner: the user asked to leave (toolbar / tap region). */
    var onDisconnectRequest: (() -> Unit)? = null
    var ctrl by mutableStateOf(false)
    var alt by mutableStateOf(false)
    var shift by mutableStateOf(false)
    var meta by mutableStateOf(false)
    var showDock by mutableStateOf(false)
    var imeCommandTick by mutableIntStateOf(0)
    var imeCommandShow: Boolean = false

    // ---- internals -----------------------------------------------------------------------
    private val main = Handler(Looper.getMainLooper())
    private var client: RemoteBackend? = null

    @Volatile
    private var token = 0
    private var lastPassword = ""
    private val framePending = AtomicBoolean(false)
    private val downKeys = HashMap<Int, Int>()

    val title: String
        get() = profile.name.ifBlank { profile.address }

    // =====================================================================================
    // Connection lifecycle
    // =====================================================================================

    fun connect(password: String) {
        closeClient()
        token++
        val my = token
        lastPassword = password
        phase = Phase.CONNECTING
        status = "Connecting\u2026"
        addLog("Connecting to ${profile.host.ifEmpty { profile.realVncAddress }}")
        error = null
        clearPrompts()
        banner = null
        remoteCursor = null

        val listener = object : VncListener {
            override fun onStatus(text: String) {
                runOnMain(my) { status = text; addLog(text) }
            }

            override fun onPasswordRequired(wasRejected: Boolean) {
                runOnMain(my) {
                    passwordRejected = wasRejected
                    phase = Phase.AUTH_REQUIRED
                }
            }

            override fun onFramebufferReady(bitmap: Bitmap, desktopName: String) {
                runOnMain(my) { handleFramebuffer(bitmap, desktopName) }
            }

            override fun onFrameUpdated() {
                if (my == token && framePending.compareAndSet(false, true)) {
                    main.post {
                        framePending.set(false)
                        frameTick = frameTick + 1
                    }
                }
            }

            override fun onServerCutText(text: String) {
                runOnMain(my) { handleRemoteClipboard(text) }
            }

            override fun onBell() {
            }

            override fun onDisconnected(error: String?) {
                runOnMain(my) { handleDisconnected(error) }
            }

            override fun onCursor(bitmap: Bitmap?, hotX: Int, hotY: Int) {
                runOnMain(my) {
                    input.remoteCursorChanged()
                    remoteCursor = bitmap
                    cursorHotX = hotX
                    cursorHotY = hotY
                }
            }

            override fun onCursorHidden() {
                runOnMain(my) {
                    input.remoteCursorChanged()
                    // A dot (like RealVNC's DotWhenNoCursor) or, if switched off, a shape nobody can see.
                    val dot = AppSettings.cursorDot(appContext)
                    remoteCursor = hiddenCursorBitmap(dot)
                    cursorHotX = if (dot) DOT_SIZE / 2 else 0
                    cursorHotY = if (dot) DOT_SIZE / 2 else 0
                }
            }

            override fun onPrompt(prompt: RemotePrompt) {
                runOnMain(my) { prompts.add(prompt) }
            }

            override fun onBanner(text: String?) {
                runOnMain(my) { banner = text; addLog(text ?: "Reconnected") }
            }
        }

        val c: RemoteBackend
        if (profile.engine == Engine.REALVNC) {
            val reason = RealVncCore.unavailableReason()
            if (reason != null) {
                handleDisconnected(reason)
                return
            }
            c = RealVncBackend(
                appContext,
                profile.realVncAddress,
                profile.userName,
                password,
                quality,
                viewOnly,
                listener
            )
        } else {
            c = VncClient(profile.host, profile.port, password, listener)
        }
        client = c
        c.start()
    }

    fun reconnect() {
        connect(lastPassword.ifEmpty { profile.password })
    }

    fun submitPassword(password: String) {
        connect(password)
    }

    fun close() {
        token++
        stopRecording()
        releaseAllKeys()
        clearPrompts()
        closeClient()
    }

    /** Answer "no" to every open question so the engine is not left waiting. */
    private fun clearPrompts() {
        val open = ArrayList<RemotePrompt>(prompts)
        prompts.clear()
        for (p in open) p.cancel()
    }

    fun dismissPrompt(prompt: RemotePrompt) {
        prompts.remove(prompt)
    }

    private fun closeClient() {
        val c = client
        client = null
        c?.close()
    }

    private fun runOnMain(t: Int, block: () -> Unit) {
        main.post {
            if (t == token) block()
        }
    }

    private fun handleFramebuffer(bmp: Bitmap, name: String) {
        bitmap = bmp
        fbWidth = bmp.width
        fbHeight = bmp.height
        desktopName = name
        input.setDesktopSize(bmp.width, bmp.height)
        if (phase != Phase.CONNECTED) {
            phase = Phase.CONNECTED
            firstFrame = true
        }
        frameTick = frameTick + 1
    }

    private fun handleDisconnected(err: String?) {
        if (phase == Phase.AUTH_REQUIRED) return
        error = err ?: "Disconnected"
        addLog("Disconnected: ${error}")
        phase = Phase.FAILED
        stopRecording()
        input.suspendInput()
        downKeys.clear()
        clearPrompts()
        banner = null
    }

    /** Our own clipboard write must not bounce straight back to the remote. */
    private var suppressClipUntil = 0L

    private fun handleRemoteClipboard(text: String) {
        if (text.isEmpty() || !AppSettings.clipboardIn(appContext)) return
        suppressClipUntil = android.os.SystemClock.elapsedRealtime() + 1500
        try {
            val cm = appContext.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("VNC", text))
            showNotice("Clipboard updated from remote")
        } catch (_: Exception) {
        }
    }

    fun showNotice(text: String) {
        notice = text
    }

    /** Ask the UI to show or hide the Android soft keyboard. */
    fun requestIme(show: Boolean) {
        imeCommandShow = show
        imeCommandTick = imeCommandTick + 1
    }

    fun refresh() {
        client?.refresh()
    }

    /** App moved to / from the background: stop or resume screen updates (RealVNC engine). */
    fun setFocused(focused: Boolean) {
        client?.setFocused(focused)
    }

    val isRealVnc: Boolean
        get() = profile.engine == Engine.REALVNC

    fun setPictureQuality(next: String) {
        quality = next
        client?.setQuality(next)
        addLog("Picture quality: $next")
    }

    fun updateAutoReconnect(on: Boolean) {
        autoReconnect = on
        client?.setAutoReconnect(on)
        addLog("Reconnect automatically: ${if (on) "on" else "off"}")
    }

    /** The whole desktop at its own size (not the phone's viewport), or null if there is none yet. */
    fun desktopSnapshot(): Bitmap? {
        val src = bitmap ?: return null
        if (src.isRecycled || src.width <= 0 || src.height <= 0) return null
        return try {
            src.copy(Bitmap.Config.ARGB_8888, false)
        } catch (_: OutOfMemoryError) {
            null
        }
    }

    fun cycleQuality() {
        val all = listOf("Auto", "High", "Medium", "Low")
        val next = all[(all.indexOf(quality) + 1) % all.size]
        quality = next
        client?.setQuality(next)
        addLog("Picture quality: $next")
        showNotice("Picture quality: $next")
    }

    fun showConnectionInfo() {
        infoOpen = true
        refreshConnectionInfo()
    }

    fun refreshConnectionInfo() {
        val c = client
        if (c == null) {
            infoRows = emptyList()
        } else {
            c.connectionInfo { rows -> if (infoOpen) infoRows = rows }
        }
    }

    fun closeConnectionInfo() {
        infoOpen = false
        infoRows = null
    }

    // =====================================================================================
    // Viewport and mouse: the input stack (acceleration, momentum, gestures, overlay,
    // toolbar...) lives in SessionInput; this is the session-facing surface of it.
    // =====================================================================================

    /** Bumped whenever the cursor, viewport, overlay or toolbar changes; read by the canvas draw. */
    var inputTick by mutableIntStateOf(0)

    private val inputHost = object : SessionInput.Host {
        override fun sendPointer(x: Int, y: Int, buttons: Int) {
            if (canInteract()) client?.sendPointer(x, y, buttons)
        }

        override fun controlAction(name: String): Boolean = onControlAction(name)

        override fun invalidate() {
            inputTick = inputTick + 1
        }

        override fun viewOnly(): Boolean = this@VncSession.viewOnly

        override fun keyboardVisible(): Boolean = imeVisible

        override fun recording(): Boolean = this@VncSession.recording

        override fun sendKey(keysym: Int, down: Boolean) {
            // A press needs a live, interactive session; a release is always let through, or a
            // modifier armed before the session went view-only would stay down at the far end.
            if (down) {
                if (canInteract()) client?.sendKey(keysym, true)
            } else {
                client?.sendKey(keysym, false)
            }
        }

        override fun pasteClipboard() {
            typeClipboard()
        }

        override fun restartIme() {
            imeRestartTick = imeRestartTick + 1
        }
    }

    val input = SessionInput(appContext, inputHost)

    private fun canInteract(): Boolean = phase == Phase.CONNECTED && !viewOnly && client != null

    /** Toolbar buttons and tap regions: disconnect, connection info, keyboard, mouse overlay. */
    private fun onControlAction(name: String): Boolean {
        when (name) {
            TapRegions.DISCONNECT -> onDisconnectRequest?.invoke()
            TapRegions.INFORMATION -> showConnectionInfo()
            TapRegions.MOUSE -> {
                if (viewOnly) return false
                input.toggleOverlay()
            }
            TapRegions.KEYBOARD -> {
                if (viewOnly) return false
                requestIme(!imeVisible)
            }
            Toolbar.KEYS -> {
                if (viewOnly) return false
                input.toggleKeys()
            }
            Toolbar.SCREENSHOT -> Screenshot.save(appContext, this)
            Toolbar.RECORD -> toggleRecording()
            Toolbar.LOCK -> input.toggleScreenLock()
            Toolbar.CLIPBOARD -> {
                if (viewOnly) return false
                sendClipboardToRemote()
            }
            else -> return false
        }
        return true
    }

    fun onViewSize(w: Int, h: Int) {
        input.onViewSize(w, h)
    }

    fun cycleScaleMode() {
        if (input.screenLocked) return // the picture is frozen until the lock is switched off
        val all = ScaleMode.values()
        scaleMode = all[(scaleMode.ordinal + 1) % all.size]
        applyScaleMode()
    }

    private fun applyScaleMode() {
        val v = input.viewport
        v.setFocus(input.cursor.x(), input.cursor.y())
        when (scaleMode) {
            ScaleMode.FIT -> v.zoomToFit()
            ScaleMode.ORIGINAL -> v.setScale(1.0f)
            ScaleMode.FILL -> v.zoomToFill()
        }
        input.cursor.setPosition(input.cursor.x(), input.cursor.y())
    }

    fun resetViewport() {
        if (input.screenLocked) return
        scaleMode = ScaleMode.FIT
        applyScaleMode()
    }

    // ---- direct-touch helpers (absolute pointer, used by the Direct touch mode) ----

    fun pointerToScreen(sx: Float, sy: Float) {
        if (!canInteract()) return
        input.directMoveTo(sx, sy)
    }

    fun zoomBy(factor: Float, cx: Float, cy: Float, panDx: Float, panDy: Float) {
        input.directZoom(factor, cx, cy, panDx, panDy)
    }

    fun panBy(dx: Float, dy: Float) {
        input.viewport.panBy(dx, dy)
        inputTick = inputTick + 1
    }

    fun buttonDown(mask: Int) {
        if (canInteract()) input.clickSource.mouseDown(mask)
    }

    fun buttonUp(mask: Int) {
        if (canInteract()) input.clickSource.mouseUp(mask)
    }

    /** Press and release [mask] (1 = left, 2 = middle, 4 = right) where the cursor is, in any armed modifiers. */
    fun click(mask: Int) {
        if (!canInteract()) return
        val mods = pressModifiers()
        input.clickSource.mouseDown(mask)
        main.postDelayed({
            input.clickSource.mouseUp(mask)
            releaseModifiers(mods)
        }, 35)
    }

    fun doubleClick() {
        click(1)
        main.postDelayed({ click(1) }, 90)
    }

    fun wheel(down: Boolean, notches: Int = 1) {
        if (!canInteract()) return
        val b = if (down) Button.WHEEL_DOWN.mask else Button.WHEEL_UP.mask
        for (i in 0 until notches) {
            input.clickSource.mouseDown(b)
            input.clickSource.mouseUp(b)
        }
    }

    /** Local clipboard changed: send it when "Send clipboard" is on. */
    fun autoSendClipboard() {
        if (!canInteract() || !AppSettings.clipboardOut(appContext)) return
        if (android.os.SystemClock.elapsedRealtime() < suppressClipUntil) return
        val text = localClipboardText()
        if (!text.isNullOrEmpty()) client?.sendClipboard(text)
    }

    // =====================================================================================
    // Keyboard
    // =====================================================================================

    private fun pressModifiers(): List<Int> {
        val c = client ?: return emptyList()
        val list = ArrayList<Int>(4)
        if (ctrl) list.add(Keysyms.CONTROL_L)
        if (alt) list.add(Keysyms.ALT_L)
        if (shift) list.add(Keysyms.SHIFT_L)
        if (meta || cmd) list.add(Keysyms.SUPER_L)
        if (option) list.add(Keysyms.ISO_LEVEL3_SHIFT)
        for (k in list) c.sendKey(k, true)
        ctrl = false
        alt = false
        shift = false
        meta = false
        cmd = false
        option = false
        return list
    }

    private fun releaseModifiers(list: List<Int>) {
        val c = client ?: return
        for (k in list.asReversed()) c.sendKey(k, false)
    }

    /** Press + release one key, wrapped in whichever on-screen modifiers are armed. */
    fun tapKey(keySym: Int) {
        if (!canInteract() || keySym == 0) return
        val c = client ?: return
        val mods = pressModifiers()
        c.sendKey(keySym, true)
        c.sendKey(keySym, false)
        releaseModifiers(mods)
        input.externalKey(keySym)
        if (keySym == Keysyms.RETURN) typedLine = ""
        if (keySym == Keysyms.BACKSPACE && typedLine.isNotEmpty()) typedLine = typedLine.dropLast(1)
    }

    /** Press all keys in order, then release them in reverse (e.g. Ctrl+Alt+Del). */
    fun keyCombo(vararg keys: Int) {
        if (!canInteract()) return
        val c = client ?: return
        for (k in keys) c.sendKey(k, true)
        for (i in keys.indices.reversed()) c.sendKey(keys[i], false)
    }

    /** Text from the soft keyboard / IME. */
    fun imeText(text: String) {
        typeText(text)
    }

    fun typeText(text: String) {
        if (!canInteract()) return
        noteTyped(text)
        var i = 0
        while (i < text.length) {
            val cp = Character.codePointAt(text, i)
            i += Character.charCount(cp)
            tapKey(Keysyms.fromCodePoint(cp))
        }
    }

    fun toggleCtrl() {
        ctrl = !ctrl
    }

    fun toggleAlt() {
        alt = !alt
    }

    fun toggleShift() {
        shift = !shift
    }

    fun toggleMeta() {
        meta = !meta
    }

    fun toggleOption() {
        option = !option
    }

    fun toggleCmd() {
        cmd = !cmd
    }

    /** Armed modifiers as text, for the info bar. */
    fun heldModifiersText(): String {
        val parts = ArrayList<String>(4)
        if (ctrl) parts.add("Ctrl")
        if (alt) parts.add("Alt")
        if (shift) parts.add("Shift")
        if (meta) parts.add("Win")
        if (cmd) parts.add("CMD")
        if (option) parts.add("Option")
        return parts.joinToString("+")
    }

    private fun noteTyped(text: String) {
        val max = input.cfg.keyboardInfoMaxChars
        var t = typedLine
        for (ch in text) {
            if (ch == '\n') t = "" else t += ch
        }
        typedLine = if (t.length > max) t.substring(t.length - max) else t
    }

    /** Hardware keyboard (or key events sent by an IME). Returns true when the event was consumed. */
    fun onKeyEvent(event: KeyEvent): Boolean {
        if (!canInteract()) return false
        val action = event.action
        if (action != KeyEvent.ACTION_DOWN && action != KeyEvent.ACTION_UP) return false
        val down = action == KeyEvent.ACTION_DOWN
        val code = event.keyCode

        var sym = Keysyms.fromAndroidKeyCode(code)
        if (sym == 0) {
            val modMask = KeyEvent.META_CTRL_MASK or KeyEvent.META_ALT_MASK or KeyEvent.META_META_MASK
            val uc = event.getUnicodeChar(event.metaState and modMask.inv())
            if (uc != 0 && (uc and KeyCharacterMap.COMBINING_ACCENT) == 0) {
                sym = Keysyms.fromCodePoint(uc)
            }
        }
        if (down) {
            if (sym == 0) return false
            if (event.repeatCount > 0 && isModifierSym(sym)) return true
            downKeys[code] = sym
        } else {
            val previous = downKeys.remove(code)
            if (previous != null) sym = previous
            if (sym == 0) return false
        }
        client?.sendKey(sym, down)
        if (down && !isModifierSym(sym)) input.externalKey(sym)
        return true
    }

    private fun isModifierSym(sym: Int): Boolean = sym in 0xFFE1..0xFFEE

    fun releaseAllKeys() {
        val c = client
        if (c != null) {
            for (sym in downKeys.values) c.sendKey(sym, false)
        }
        downKeys.clear()
        input.suspendInput()
    }

    // =====================================================================================
    // Clipboard
    // =====================================================================================

    private fun localClipboardText(): String? {
        return try {
            val cm = appContext.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = cm.primaryClip
            if (clip == null || clip.itemCount == 0) {
                null
            } else {
                clip.getItemAt(0).coerceToText(appContext)?.toString()
            }
        } catch (_: Exception) {
            null
        }
    }

    /** Copy the phone's clipboard to the remote clipboard (then paste there with Ctrl+V). */
    fun sendClipboardToRemote() {
        if (!canInteract()) return
        val text = localClipboardText()
        if (text.isNullOrEmpty()) {
            showNotice("Phone clipboard is empty")
        } else {
            client?.sendClipboard(text)
            showNotice("Clipboard sent. Paste on the remote with Ctrl+V")
        }
    }

    /** Type the phone's clipboard into the remote as key presses (works everywhere). */
    fun typeClipboard() {
        if (!canInteract()) return
        val text = localClipboardText()
        if (text.isNullOrEmpty()) {
            showNotice("Phone clipboard is empty")
        } else {
            typeText(if (text.length > 5000) text.substring(0, 5000) else text)
        }
    }

    private companion object {
        const val TRACKPAD_GAIN = 1.3f
    }
}

private const val DOT_SIZE = 9

/** The stand-in for a cursor the server has hidden: a small outlined dot, or one transparent pixel. */
private fun hiddenCursorBitmap(dot: Boolean): Bitmap {
    if (!dot) return Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)
    val bmp = Bitmap.createBitmap(DOT_SIZE, DOT_SIZE, Bitmap.Config.ARGB_8888)
    val c = android.graphics.Canvas(bmp)
    val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    val m = DOT_SIZE / 2f
    paint.color = android.graphics.Color.BLACK
    c.drawCircle(m, m, m, paint)
    paint.color = android.graphics.Color.WHITE
    c.drawCircle(m, m, m - 1.5f, paint)
    return bmp
}
