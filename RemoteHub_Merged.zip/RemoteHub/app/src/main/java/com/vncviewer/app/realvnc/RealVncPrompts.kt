// SPDX-License-Identifier: GPL-3.0-or-later
package com.vncviewer.app.realvnc

import com.realvnc.vncviewer.jni.MsgBoxBindings
import com.realvnc.vncviewer.jni.PasswdDlgBindings
import com.realvnc.vncviewer.jni.SessionBindings
import com.vncviewer.app.vnc.CredentialsPrompt
import java.util.IdentityHashMap

/**
 * The two prompt families the engine has, bridged onto our own prompt types:
 *
 *  - credentials: the engine asks the factory for a dialog object and then waits, on its
 *    session thread, until [PasswdDlgBindings.passwdResult] arrives with the same cookie.
 *    The message is empty on the first try, an error text ("Password incorrect") on a retry,
 *    and starts with "@user@" when the server also wants a user name (RSA-AES sign-in).
 *  - message box: the last thing a failing session says. We keep the text for the
 *    disconnected screen and acknowledge at once, so the session can finish closing.
 *
 * The factories are process-wide, so this is where the Session a prompt carries is turned back
 * into the backend that owns it. A prompt can in principle arrive before createSession has
 * returned the handle it is keyed on; createSession calls are serialised on the worker thread,
 * so a single "pending" slot covers that window.
 */
internal object RealVncPrompts {

    private const val USER_MARKER = "@user@"

    private val owners = IdentityHashMap<SessionBindings.Session, RealVncBackend>()
    private val tokenOwners = HashMap<Long, RealVncBackend>()

    /** The backend whose createSession has not returned yet. */
    @Volatile
    private var pending: RealVncBackend? = null

    @Synchronized
    fun attach(session: SessionBindings.Session, backend: RealVncBackend) {
        owners[session] = backend
        val t = session.token
        if (t != 0L) tokenOwners[t] = backend
    }

    @Synchronized
    fun detach(session: SessionBindings.Session) {
        owners.remove(session)
        val t = session.token
        if (t != 0L) tokenOwners.remove(t)
    }

    fun connecting(backend: RealVncBackend) {
        pending = backend
    }

    fun connected(backend: RealVncBackend) {
        if (pending === backend) pending = null
    }

    @Synchronized
    private fun owner(session: SessionBindings.Session?): RealVncBackend? {
        if (session != null) {
            val byIdentity = owners[session]
            if (byIdentity != null) return byIdentity
            val t = session.token
            if (t != 0L) {
                val byToken = tokenOwners[t]
                if (byToken != null) return byToken
            }
        }
        return pending
    }

    fun registerFactories() {
        PasswdDlgBindings.setPasswdDlgFactory(object : PasswdDlgBindings.PasswdDlgFactory {
            override fun createPasswdDlg(
                session: SessionBindings.Session?,
                handle: Long,
                message: String?
            ): PasswdDlgBindings.PasswdDlg {
                askCredentials(session, handle, message ?: "")
                return object : PasswdDlgBindings.PasswdDlg {}
            }
        })

        MsgBoxBindings.setMsgBoxFactory(object : MsgBoxBindings.MsgBoxFactory {
            override fun createMsgBox(
                session: SessionBindings.Session?,
                handle: Long,
                message: String?,
                type: Int,
                title: String?
            ): MsgBoxBindings.MsgBox {
                owner(session)?.sessionMessage(message ?: "")
                // Nothing to wait for: the session is ending, and the reason goes to the
                // disconnected screen instead of a dialog on top of it.
                MsgBoxBindings.msgBoxResult(handle, true)
                return object : MsgBoxBindings.MsgBox {}
            }
        })
    }

    private fun askCredentials(session: SessionBindings.Session?, handle: Long, raw: String) {
        val backend = owner(session)
        if (backend == null) {
            PasswdDlgBindings.passwdResult(handle, false, "", "")
            return
        }
        val askUser = raw.startsWith(USER_MARKER)
        val text = if (askUser) raw.substring(USER_MARKER.length) else raw
        backend.ask(
            CredentialsPrompt(
                backend.addressText(),
                text,
                askUser,
                backend.userNameText(),
                true,
                "",
                ""
            ) { ok, user, pass ->
                backend.promptAnswered()
                // Any thread may answer, as long as the handle comes back with it.
                PasswdDlgBindings.passwdResult(handle, ok, user ?: "", pass ?: "")
            }
        )
    }
}
