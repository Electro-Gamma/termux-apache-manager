// SPDX-License-Identifier: GPL-3.0-or-later
package com.vncviewer.app.realvnc

import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import com.realvnc.vncviewer.jni.ConfigurationBindings
import java.util.concurrent.CountDownLatch

/**
 * The process-wide half of the VNC engine: load libvncviewer.so (built from app/src/main/cpp),
 * register the prompt factories, and own the one worker thread the backends run on.
 *
 * The library runs every connection on a native thread of its own and calls back on it. The
 * worker thread is where the backends do everything with that traffic - painting the
 * framebuffer into bitmaps and calling back into the library - so a slow bitmap copy never
 * holds up the protocol, and all the Kotlin-side state of a session stays on one thread.
 */
object RealVncCore {

    const val TAG = "RealVnc"

    @Volatile
    private var handler: Handler? = null
    private var initialised = false
    private var loaded = false
    private var loadError: String? = null

    /** Null when the engine can run on this phone, otherwise a human-readable reason. */
    fun unavailableReason(): String? {
        if (Build.VERSION.SDK_INT < 26) {
            return "The RealVNC engine needs Android 8.0 or newer."
        }
        var arm64 = false
        for (abi in Build.SUPPORTED_ABIS) {
            if (abi == "arm64-v8a") arm64 = true
        }
        if (!arm64) {
            return "The RealVNC engine only runs on 64-bit ARM (arm64-v8a) phones."
        }
        return ensureLoaded()
    }

    @Synchronized
    private fun ensureLoaded(): String? {
        if (loaded) return null
        val previous = loadError
        if (previous != null) return previous
        return try {
            System.loadLibrary("vncviewer")
            loaded = true
            null
        } catch (e: UnsatisfiedLinkError) {
            val msg = "The VNC engine library (libvncviewer.so) could not be loaded: ${e.message}"
            loadError = msg
            msg
        }
    }

    /** Idempotent. */
    @Synchronized
    fun start(@Suppress("UNUSED_PARAMETER") context: Context): Handler {
        val existing = handler
        if (initialised && existing != null) return existing

        val problem = ensureLoaded()
        if (problem != null) throw IllegalStateException(problem)

        val thread = HandlerThread("VncCore")
        thread.start()
        val h = Handler(thread.looper)
        handler = h
        try {
            RealVncPrompts.registerFactories()
            Log.i(TAG, "engine ready")
        } catch (t: Throwable) {
            thread.quitSafely()
            handler = null
            throw t
        }
        initialised = true
        return h
    }

    /** Run on the worker thread, whether or not we are already on it. */
    fun post(block: () -> Unit) {
        val h = handler ?: return
        if (Thread.currentThread() === h.looper.thread) {
            block()
        } else {
            h.post(Runnable { block() })
        }
    }

    /** Always queued, never run inline (callbacks from the library use this to keep their order). */
    fun enqueue(r: Runnable) {
        handler?.post(r)
    }

    fun postDelayed(r: Runnable, delayMs: Long) {
        handler?.postDelayed(r, delayMs)
    }

    fun cancel(r: Runnable) {
        handler?.removeCallbacks(r)
    }

    /** Run on the worker thread and wait; a throw comes back to the caller. */
    fun runBlocking(block: () -> Unit) {
        val h = handler ?: throw IllegalStateException("The VNC engine is not started")
        if (Thread.currentThread() === h.looper.thread) {
            block()
            return
        }
        val latch = CountDownLatch(1)
        var failure: Throwable? = null
        h.post(Runnable {
            try {
                block()
            } catch (t: Throwable) {
                failure = t
            } finally {
                latch.countDown()
            }
        })
        latch.await()
        val f = failure
        if (f != null) throw f
    }

    /** Set any parameter in the engine's registry. */
    fun setParameter(name: String, value: String) {
        post { ConfigurationBindings.set(name, value, 10, false) }
    }
}
