// SPDX-License-Identifier: GPL-3.0-or-later
//
// Drawing for the on-screen session controls (mouse overlay, toolbar, tap-region hints,
// debug overlay), modelled on Vento's control/ui/Chrome.java (https://github.com/pgaskin/vento,
// (C) 2026 Patrick Gaskin, MIT).
package com.vncviewer.app.ui

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import com.vncviewer.app.input.MouseOverlay
import com.vncviewer.app.input.TapRegions
import com.vncviewer.app.input.Toolbar

class ChromeDraw(private val density: Float) {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    init {
        stroke.style = Paint.Style.STROKE
        stroke.strokeCap = Paint.Cap.ROUND
        text.textAlign = Paint.Align.CENTER
    }

    private fun dp(v: Float) = v * density

    // ---- mouse overlay -------------------------------------------------------------------

    fun drawOverlay(c: Canvas, o: MouseOverlay) {
        for (b in o.parts()) {
            when (b.part) {
                MouseOverlay.Part.SCROLL -> drawStrip(c, o, b)
                MouseOverlay.Part.DISMISS -> drawDismiss(c, b, o.pressed(b.part))
                else -> drawButton(c, b, o.pressed(b.part))
            }
        }
    }

    // The mouse controls, as RealVNC draws them: no fill, no labels, thin grey outlines, and an
    // icon only where there is one (the wheel handle, the close button).

    private fun outline(): Float = Math.max(1f, dp(0.5f))

    private fun drawButton(c: Canvas, b: MouseOverlay.Bounds, pressed: Boolean) {
        if (pressed) {
            fill.color = 0x33FFFFFF
            c.drawRect(b.left, b.top, b.right, b.bottom, fill)
        }
        stroke.color = OUTLINE_GREY
        stroke.strokeWidth = outline()
        c.drawRect(b.left, b.top, b.right, b.bottom, stroke)
    }

    private fun drawDismiss(c: Canvas, b: MouseOverlay.Bounds, pressed: Boolean) {
        rect.set(b.left, b.top, b.right, b.bottom)
        if (pressed) {
            fill.color = 0x33FFFFFF
            c.drawRoundRect(rect, dp(3f), dp(3f), fill)
        }
        stroke.color = OUTLINE_GREY
        stroke.strokeWidth = outline()
        c.drawRoundRect(rect, dp(3f), dp(3f), stroke)
        stroke.color = 0xFFFFFFFF.toInt()
        stroke.strokeWidth = dp(2.5f)
        val cx = (b.left + b.right) / 2f
        val cy = b.centreY()
        val r = dp(9f)
        c.drawLine(cx - r, cy - r, cx + r, cy + r, stroke)
        c.drawLine(cx - r, cy + r, cx + r, cy - r, stroke)
    }

    private fun drawStrip(c: Canvas, o: MouseOverlay, b: MouseOverlay.Bounds) {
        stroke.color = OUTLINE_GREY
        stroke.strokeWidth = outline()
        c.drawRect(b.left, b.top, b.right, b.bottom, stroke)
        // The handle: an outlined box with three bars, where the finger is and so which way and
        // how fast the wheel turns.
        val active = o.scrollRate() != 0f
        val cx = (b.left + b.right) / 2f
        val y = (o.handleTop() + o.handleBottom()) / 2f
        rect.set(cx - o.handleWidth() / 2f, o.handleTop(), cx + o.handleWidth() / 2f, o.handleBottom())
        if (active) {
            fill.color = 0x33FFFFFF
            c.drawRoundRect(rect, dp(4f), dp(4f), fill)
        }
        stroke.color = if (active) 0xFFFFFFFF.toInt() else OUTLINE_GREY
        stroke.strokeWidth = outline()
        c.drawRoundRect(rect, dp(4f), dp(4f), stroke)
        stroke.color = 0xFFD8D8D8.toInt()
        stroke.strokeWidth = dp(1f)
        val half = dp(13f)
        for (i in -1..1) {
            c.drawLine(cx - half, y + i * dp(11.5f), cx + half, y + i * dp(11.5f), stroke)
        }
    }

    // ---- toolbar ---------------------------------------------------------------------------

    fun drawToolbar(c: Canvas, t: Toolbar) {
        if (!t.visible() || t.items().isEmpty()) return
        // A bar in the header's place rather than a panel over the picture: solid, with a
        // hairline underneath.
        fill.color = ChromeColors.surface1()
        rect.set(t.left(), t.top(), t.right(), t.bottom())
        c.drawRect(rect, fill)
        stroke.color = ChromeColors.stroke()
        stroke.strokeWidth = dp(1f)
        c.drawLine(t.left(), t.bottom() - dp(0.5f), t.right(), t.bottom() - dp(0.5f), stroke)
        for (b in t.items()) {
            val item = b.item ?: continue
            val pressed = t.pressedItem() === item
            val on = t.isActive(item)
            if (pressed || on) {
                fill.color = ChromeColors.withAlpha(ChromeColors.accent(), if (pressed) 0x4D else 0x2E)
                rect.set(b.left + dp(3f), b.top + dp(3f), b.right - dp(3f), b.bottom - dp(3f))
                c.drawRoundRect(rect, dp(8f), dp(8f), fill)
            }
            val lit = if (item.name == Toolbar.RECORD) ChromeColors.danger() else ChromeColors.accent()
            icon(c, item.name, b.centreX(), b.centreY(), if (on) lit else ChromeColors.textPrimary(), on)
        }
    }

    private fun icon(c: Canvas, name: String, cx: Float, cy: Float, color: Int, on: Boolean = false) {
        stroke.color = color
        stroke.strokeWidth = dp(2f)
        fill.color = color
        val r = dp(8f)
        when (name) {
            TapRegions.DISCONNECT -> {
                c.drawLine(cx - r, cy - r, cx + r, cy + r, stroke)
                c.drawLine(cx - r, cy + r, cx + r, cy - r, stroke)
            }
            TapRegions.INFORMATION -> {
                c.drawCircle(cx, cy, r + dp(2f), stroke)
                c.drawCircle(cx, cy - dp(5f), dp(1.3f), fill)
                c.drawLine(cx, cy - dp(1.5f), cx, cy + dp(6f), stroke)
            }
            TapRegions.KEYBOARD -> {
                rect.set(cx - dp(11f), cy - dp(7f), cx + dp(11f), cy + dp(7f))
                c.drawRoundRect(rect, dp(2f), dp(2f), stroke)
                for (i in -2..2) c.drawCircle(cx + i * dp(4f), cy - dp(2.5f), dp(1f), fill)
                for (i in -1..1) c.drawCircle(cx + i * dp(4f), cy + dp(2.5f), dp(1f), fill)
            }
            TapRegions.MOUSE -> {
                rect.set(cx - dp(7f), cy - dp(10f), cx + dp(7f), cy + dp(10f))
                c.drawRoundRect(rect, dp(7f), dp(7f), stroke)
                c.drawLine(cx, cy - dp(10f), cx, cy - dp(1f), stroke)
                c.drawLine(cx - dp(7f), cy - dp(1f), cx + dp(7f), cy - dp(1f), stroke)
            }
            Toolbar.KEYS -> {
                // Three key caps side by side: the extension row.
                for (i in -1..1) {
                    val kx = cx + i * dp(9.5f)
                    rect.set(kx - dp(3.5f), cy - dp(5f), kx + dp(3.5f), cy + dp(5f))
                    c.drawRoundRect(rect, dp(2f), dp(2f), stroke)
                }
            }
            Toolbar.RECORD -> {
                c.drawCircle(cx, cy, r + dp(2f), stroke)
                if (color == ChromeColors.danger()) {
                    // Recording: the stop square.
                    rect.set(cx - dp(4.5f), cy - dp(4.5f), cx + dp(4.5f), cy + dp(4.5f))
                    c.drawRoundRect(rect, dp(1.5f), dp(1.5f), fill)
                } else {
                    c.drawCircle(cx, cy, dp(4.5f), fill)
                }
            }
            Toolbar.SCREENSHOT -> {
                // Four corner brackets round a dot: "capture this area".
                val h = dp(10f)
                val a = dp(5f)
                for (sx in intArrayOf(-1, 1)) for (sy in intArrayOf(-1, 1)) {
                    val x = cx + sx * h
                    val y = cy + sy * h
                    c.drawLine(x, y, x - sx * a, y, stroke)
                    c.drawLine(x, y, x, y - sy * a, stroke)
                }
                c.drawCircle(cx, cy, dp(2.5f), fill)
            }
            Toolbar.LOCK -> {
                // A padlock: shut when the screen is locked, with the shackle lifted when it is not.
                rect.set(cx - dp(8f), cy - dp(1.5f), cx + dp(8f), cy + dp(9.5f))
                c.drawRoundRect(rect, dp(2.5f), dp(2.5f), stroke)
                c.drawCircle(cx, cy + dp(4f), dp(1.4f), fill)
                val lift = if (on) 0f else dp(4f)
                rect.set(cx - dp(5f), cy - dp(11f) - lift, cx + dp(5f), cy - dp(1f) - lift)
                c.drawArc(rect, 180f, 180f, false, stroke)
                c.drawLine(cx - dp(5f), cy - dp(6f) - lift, cx - dp(5f), cy - dp(1.5f), stroke)
                if (on) c.drawLine(cx + dp(5f), cy - dp(6f), cx + dp(5f), cy - dp(1.5f), stroke)
            }
            Toolbar.CLIPBOARD -> {
                rect.set(cx - dp(7f), cy - dp(8f), cx + dp(7f), cy + dp(10f))
                c.drawRoundRect(rect, dp(2f), dp(2f), stroke)
                rect.set(cx - dp(3.5f), cy - dp(11f), cx + dp(3.5f), cy - dp(6f))
                c.drawRoundRect(rect, dp(1.5f), dp(1.5f), fill)
                c.drawLine(cx - dp(3.5f), cy + dp(0f), cx + dp(3.5f), cy + dp(0f), stroke)
                c.drawLine(cx - dp(3.5f), cy + dp(4.5f), cx + dp(3.5f), cy + dp(4.5f), stroke)
            }
        }
    }

    // ---- tap-region hints ------------------------------------------------------------------------

    fun drawRegionHints(c: Canvas, regions: TapRegions, w: Int, h: Int, label: (String) -> String) {
        for (r in regions.regions) {
            rect.set(r.left * w, r.top * h, r.right * w, r.bottom * h)
            fill.color = ChromeColors.withAlpha(ChromeColors.accent(), 0x4D)
            c.drawRect(rect, fill)
            stroke.color = ChromeColors.withAlpha(ChromeColors.accent(), 0xB3)
            stroke.strokeWidth = dp(1.5f)
            c.drawRect(rect, stroke)
            text.color = 0xFFFFFFFF.toInt()
            text.textSize = dp(14f)
            text.typeface = Typeface.DEFAULT_BOLD
            c.drawText(label(r.name), rect.centerX(), rect.centerY() + dp(5f), text)
        }
    }

    // ---- debug overlay ---------------------------------------------------------------------------

    fun drawHud(c: Canvas, lines: List<String>, top: Float) {
        text.textAlign = Paint.Align.LEFT
        text.typeface = Typeface.MONOSPACE
        text.textSize = dp(10.5f)
        val lh = dp(13f)
        fill.color = 0xA6000000.toInt()
        var widest = 0f
        for (l in lines) widest = Math.max(widest, text.measureText(l))
        rect.set(dp(4f), top, dp(4f) + widest + dp(10f), top + lines.size * lh + dp(8f))
        c.drawRoundRect(rect, dp(6f), dp(6f), fill)
        text.color = ChromeColors.accent()
        var y = top + dp(4f) + lh - dp(3f)
        for (l in lines) {
            c.drawText(l, dp(9f), y, text)
            y += lh
        }
        text.textAlign = Paint.Align.CENTER
    }

    private companion object {
        /** The mouse controls' outlines. */
        val OUTLINE_GREY = 0xE6A8A8A8.toInt()
    }
}
