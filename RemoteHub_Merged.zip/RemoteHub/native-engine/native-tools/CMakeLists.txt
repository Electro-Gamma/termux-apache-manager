# Android NDK build:  cmake -DCMAKE_TOOLCHAIN_FILE=$ANDROID_NDK/build/cmake/android.toolchain.cmake \
#                           -DANDROID_ABI=arm64-v8a|armeabi-v7a -DANDROID_PLATFORM=android-24 -B out && cmake --build out
cmake_minimum_required(VERSION 3.18)
project(vncviewer C CXX)
set(CMAKE_CXX_STANDARD 17)
file(GLOB MBED third_party/mbedtls/library/*.c)
add_library(vncviewer SHARED ${MBED} src/ra2.cpp src/ra4.cpp src/ra4_client.cpp src/util.cpp src/des.cpp src/session.cpp src/jni_core.cpp src/jni_session.cpp src/jni_store.cpp)
target_include_directories(vncviewer PRIVATE src third_party/mbedtls/include third_party/mbedtls/library third_party/mbedtls)
target_compile_definitions(vncviewer PRIVATE MBEDTLS_CONFIG_FILE="vnc_mbedtls_config.h")
target_compile_options(vncviewer PRIVATE -O3 -fvisibility=hidden -fno-exceptions -fno-rtti -fno-threadsafe-statics -Wall -Wno-unused-function)
# Exports are restricted to the original library's JNI surface.
target_link_options(vncviewer PRIVATE -Wl,--version-script=${CMAKE_SOURCE_DIR}/src/exports.map -Wl,--gc-sections -Wl,-z,max-page-size=16384 -Wl,-z,noexecstack)
target_link_libraries(vncviewer log android jnigraphics z m dl)
