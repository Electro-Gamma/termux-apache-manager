LOCAL_PATH := $(call my-dir)
include $(CLEAR_VARS)
LOCAL_MODULE := vncviewer
LOCAL_SRC_FILES := $(addprefix third_party/mbedtls/library/,aes.c asn1parse.c asn1write.c bignum.c bignum_core.c bignum_mod.c bignum_mod_raw.c cipher.c cipher_wrap.c constant_time.c ecdh.c ecp.c ecp_curves.c gcm.c md.c oid.c platform.c platform_util.c rsa.c rsa_alt_helpers.c sha1.c sha256.c sha512.c) src/ra2.cpp src/ra4.cpp src/ra4_client.cpp src/util.cpp src/des.cpp src/session.cpp src/jni_core.cpp src/jni_session.cpp src/jni_store.cpp
LOCAL_C_INCLUDES := $(LOCAL_PATH)/src $(LOCAL_PATH)/third_party/mbedtls/include $(LOCAL_PATH)/third_party/mbedtls/library $(LOCAL_PATH)/third_party/mbedtls
LOCAL_CFLAGS := -DMBEDTLS_CONFIG_FILE=\"vnc_mbedtls_config.h\" -fvisibility=hidden
LOCAL_CPPFLAGS := -std=c++17 -fvisibility=hidden -fno-exceptions -fno-rtti -fno-threadsafe-statics
LOCAL_LDFLAGS := -Wl,--version-script=$(LOCAL_PATH)/src/exports.map -Wl,-z,max-page-size=16384
LOCAL_LDLIBS := -llog -landroid -ljnigraphics -lz
include $(BUILD_SHARED_LIBRARY)
