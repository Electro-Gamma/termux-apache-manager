#!/bin/bash
# Verifies the built Android libraries: ELF class/machine, SONAME, NEEDED, JNI exports vs the original, LOAD alignment, TEXTREL,
# bionic import resolution. usage: tools/verify_elf.sh [build-dir]   (exit 1 on any failure)
cd "$(dirname "$0")/.."; B=${1:-build}; fail=0
chk() { if eval "$2"; then echo "  [ok]   $1"; else echo "  [FAIL] $1"; fail=1; fi; }
for abi in arm64-v8a armeabi-v7a; do
  f=$B/$abi/libvncviewer.so; echo "== $abi ($f)"
  [ -f $f ] || { echo "  [FAIL] missing"; fail=1; continue; }
  if [ $abi = arm64-v8a ]; then cls="ELF64"; mach="AArch64"; else cls="ELF32"; mach="ARM"; fi
  chk "ELF class $cls" "readelf -h $f | grep -q 'Class:.*$cls\$'"
  chk "machine $mach" "readelf -h $f | grep -q 'Machine:.*$mach\$'"
  [ $abi = armeabi-v7a ] && { chk "EABI5" "readelf -h $f | grep -q 'Version5 EABI'"; chk "Tag_CPU_arch v7 (not v8-only)" "readelf -A $f | grep -q 'Tag_CPU_arch: v7'"; chk "no NEON/Advanced SIMD requirement" "! readelf -A $f | grep -q Advanced_SIMD"; }
  chk "SONAME libvncviewer.so" "readelf -d $f | grep -q 'SONAME.*\[libvncviewer.so\]'"
  chk "NEEDED = libc libm libdl liblog libandroid libjnigraphics libz" "[ \"\$(readelf -d $f | awk '/NEEDED/{gsub(/[\\[\\]]/,\"\",\$NF);print \$NF}' | sort | tr '\\n' ' ')\" = 'libandroid.so libc.so libdl.so libjnigraphics.so liblog.so libm.so libz.so ' ]"
  chk "JNI/native exports identical to the original (130)" "diff -q <(nm -D --defined-only $f | awk '{print \$3}' | sort) <(awk '{print \$NF}' docs/original_exports.txt | sort) >/dev/null"
  chk "all LOAD segments 16 KB aligned" "[ \"\$(readelf -lW $f | awk '/LOAD/{print \$NF}' | sort -u)\" = 0x4000 ]"
  chk "no text relocations" "! readelf -d $f | grep -q TEXTREL"
  chk "no executable stack" "! readelf -lW $f | grep GNU_STACK | grep -q RWE"
  chk "imports resolve against bionic export lists (API 24)" "python3 -I tools/check_imports.py $f third_party/bionic $abi 24 >/dev/null"
  echo "  size: $(stat -c %s $f) bytes"
done
[ $fail -eq 0 ] && echo "ELF verification: ALL OK" || echo "ELF verification: FAILURES"; exit $fail
