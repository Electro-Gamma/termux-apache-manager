#!/usr/bin/env python3
"""Fail if the library imports a symbol that Android's libc/libm/libdl (per the bionic *.map.txt version scripts), liblog,
libjnigraphics or zlib do not provide. Guards against compiler-runtime symbols (e.g. __udivti3) that a full NDK would link
statically but a bare toolchain leaves undefined -> dlopen failure on the device.
usage: check_imports.py <libvncviewer.so> <bionic dir>"""
import re, subprocess, sys
so, bionic = sys.argv[1], sys.argv[2]; abi = sys.argv[3] if len(sys.argv) > 3 else 'arm64-v8a'
TAG = 'arm' if abi == 'armeabi-v7a' else 'arm64'; BITS = 'lp32' if abi == 'armeabi-v7a' else 'lp64'
known = set()
API = int(sys.argv[4]) if len(sys.argv) > 4 else 24
def provided(tags):
    """tags = text after '#': architecture tags / introduced=N from the bionic version scripts"""
    t = tags.split()
    arch = [x for x in t if x in ('arm', 'arm64', 'x86', 'x86_64', 'riscv64', 'lp32', 'lp64')]
    if arch and not (TAG in arch or BITS in arch): return False
    for x in t:
        if x.startswith('introduced=') and x.split('=')[1].isdigit() and int(x.split('=')[1]) > API: return False
    return True
for m in ('libc/libc.map.txt', 'libm/libm.map.txt', 'libdl/libdl.map.txt', 'libdl/libdl_android.map.txt'):
    for line in open(f'{bionic}/{m}'):
        mm = re.match(r'\s*([A-Za-z_][A-Za-z0-9_]*)\s*;\s*(?:#(.*))?', line)
        if mm and provided(mm.group(2) or ''): known.add(mm.group(1))
extra = re.compile(r'^(__android_log_\w+|AndroidBitmap_\w+|inflate\w*|deflate\w*|zlibVersion|crc32|adler32)$')
und = subprocess.run(['llvm-nm', '-D', '--undefined-only', '--format=just-symbols', so], capture_output=True, text=True).stdout.split()
bad = [s for s in und if s not in known and not extra.match(s)]
print(f'{len(und)} imports checked against bionic export lists')
if bad: print('UNRESOLVED ON DEVICE:', ' '.join(bad)); sys.exit(1)
print('OK: all imports are provided by Android system libraries')
