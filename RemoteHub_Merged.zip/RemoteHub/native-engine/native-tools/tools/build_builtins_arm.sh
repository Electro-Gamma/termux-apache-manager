#!/bin/bash
# Builds libclang_rt.builtins-arm (compiler runtime: __aeabi_uldivmod, __udivdi3, ...) for armv7a-linux-androideabi from the
# LLVM compiler-rt sources (third_party/llvm-cr, sparse checkout of compiler-rt/lib/builtins). A full NDK ships the same library.
set -euo pipefail
cd "$(dirname "$0")/.."
SRC=third_party/llvm-cr/compiler-rt/lib/builtins; OUT=${1:-build/armeabi-v7a/builtins}; API=${API:-24}
BIONIC=${BIONIC:-$PWD/third_party/bionic}
mkdir -p $OUT; rm -f $OUT/*.o
CF="--target=armv7a-linux-androideabi$API -march=armv7-a -mfloat-abi=softfp -mfpu=vfpv3-d16 -O2 -fPIC -fvisibility=hidden -w -nostdinc -isystem $(clang -print-resource-dir)/include -isystem $BIONIC/libc/include -isystem $BIONIC/libc/kernel/uapi/asm-arm -isystem $BIONIC/libc/kernel/uapi -isystem $BIONIC/libc/kernel/android/uapi -I$SRC -DVISIBILITY_HIDDEN"
n=0
for f in $SRC/*.c $SRC/arm/*.c; do b=$(basename $f .c); case $b in atomic|emutls|eprintf|gcc_personality_v0|clear_cache|enable_execute_stack|cpu_model|os_version_check|trampoline_setup|int_util) continue;; esac
  clang $CF -c $f -o $OUT/$b.o 2>/dev/null && n=$((n+1)) || true; done
for f in $SRC/arm/*.S; do b=$(basename $f .S); clang $CF -c $f -o $OUT/s_$b.o 2>/dev/null && n=$((n+1)) || true; done
llvm-ar rcs $OUT/libclang_rt.builtins-arm.a $OUT/*.o; echo "builtins: $n objects -> $OUT/libclang_rt.builtins-arm.a"
