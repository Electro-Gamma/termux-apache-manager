#!/usr/bin/env python3
"""Generate link-time stub shared libraries (libc.so, libm.so, ...) exporting the given symbols.
They are used only so ld.lld can record DT_NEEDED entries; the real libs on the device are used at runtime."""
import os, subprocess, sys
import re
out = sys.argv[1]; triple = sys.argv[2]; syms = [x for x in sys.argv[3:] if re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', x)]
LIBLOG = {'__android_log_print', '__android_log_write'}
LIBBMP = {s for s in syms if s.startswith('AndroidBitmap_')}
LIBANDROID = {s for s in syms if s.startswith('ALooper_') or s.startswith('AAsset')}
LIBM = {'pow', 'exp', 'cos', 'sin', 'sqrt', 'floor', 'ceil', 'fabs', 'log', 'powf'}
LIBDL = {'dlopen', 'dlsym', 'dlclose', 'dlerror', 'dl_iterate_phdr'}
LIBZ = {s for s in syms if s in ('inflate', 'inflateEnd', 'inflateInit_', 'inflateInit2_', 'inflateReset', 'zlibVersion')}
groups = {'liblog.so': LIBLOG, 'libjnigraphics.so': LIBBMP, 'libandroid.so': LIBANDROID, 'libm.so': LIBM,
          'libdl.so': LIBDL, 'libz.so': LIBZ}
used = set().union(*groups.values())
groups['libc.so'] = {s for s in syms if s not in used and not s.startswith('_Z') and not s.startswith('__cxa') and s != '__dso_handle'}
for lib, ss in groups.items():
    src = os.path.join(out, lib + '.c')
    with open(src, 'w') as f:
        for s in sorted(ss):
            f.write('void %s(void) {}\n' % s)
    subprocess.check_call(['clang', '--target=' + triple, '-nostdlib', '-fno-builtin', '-w', '-shared', '-fuse-ld=lld',
                           '-Wl,-soname,' + lib, '-o', os.path.join(out, lib), src])
