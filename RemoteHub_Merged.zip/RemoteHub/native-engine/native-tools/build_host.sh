#!/bin/bash
# Builds the same sources for x86-64 Linux (glibc) so the exported JNI API can be exercised in a JVM.
set -euo pipefail
cd "$(dirname "$0")"
JDK_INC=${JDK_INC:-$(dirname "$(dirname "$(readlink -f "$(which javac)")")")/include}
OUT=${OUT:-$PWD/build/host}; mkdir -p $OUT
F="${OPT:--O1} -g -fPIC -fno-exceptions -fno-rtti -fno-threadsafe-statics -Isrc -I$JDK_INC -I$JDK_INC/linux"
clang -fPIC -shared -I$JDK_INC -I$JDK_INC/linux -o $OUT/libbitmapshim.so tests/host/bitmap_shim.c
MBINC="-Ithird_party/mbedtls/include -Ithird_party/mbedtls/library -Ithird_party/mbedtls -DMBEDTLS_CONFIG_FILE=\"vnc_mbedtls_config.h\""
MBO=""; for f in aes asn1parse asn1write bignum bignum_core bignum_mod bignum_mod_raw cipher cipher_wrap constant_time ecdh ecp ecp_curves gcm md oid platform platform_util rsa rsa_alt_helpers sha1 sha256 sha512; do clang -std=c11 ${OPT:--O1} -g -fPIC -w $MBINC -c third_party/mbedtls/library/$f.c -o $OUT/mb_$f.o; MBO="$MBO $OUT/mb_$f.o"; done
clang++ -std=c++17 $F $MBINC -fvisibility=default -shared -nostdlib++ -o $OUT/libvncviewer.so $MBO src/util.cpp src/des.cpp src/ra2.cpp src/ra4.cpp src/ra4_client.cpp src/session.cpp src/jni_core.cpp src/jni_session.cpp src/jni_store.cpp -L$OUT -lbitmapshim -Wl,-rpath,$OUT -lz -lpthread
clang++ -Isrc -nostdlib++ -o $OUT/desauth tests/host/desauth.cpp src/des.cpp -lc
clang++ -std=c++17 -fno-exceptions -fno-rtti -Isrc $MBINC -nostdlib++ -o $OUT/ra2_kat tests/host/ra2_kat.cpp src/ra2.cpp src/util.cpp $MBO -lc -lpthread
clang++ -std=c++17 -fno-exceptions -fno-rtti -Isrc -Itests/host $MBINC -nostdlib++ -o $OUT/ra4_kat tests/host/ra4_kat.cpp src/ra4.cpp src/ra2.cpp src/util.cpp $MBO -lc -lpthread
clang++ -std=c++17 -fno-exceptions -fno-rtti -Isrc $MBINC -nostdlib++ -o $OUT/ra4_driver tests/host/ra4_driver.cpp src/ra4.cpp src/ra4_client.cpp src/ra2.cpp src/util.cpp $MBO -lc -lpthread
echo "built $OUT"
