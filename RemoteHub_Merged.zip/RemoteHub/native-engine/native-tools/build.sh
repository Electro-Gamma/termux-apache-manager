#!/bin/bash
# Reproducible standalone build of libvncviewer.so for arm64-v8a (default) or armeabi-v7a:  ./build.sh [arm64-v8a|armeabi-v7a]
# This is a bare-toolchain cross build (clang + bionic headers [+ compiler-rt builtins for 32-bit ARM]), NOT the Android NDK.
# Needs: clang >= 17 with the AArch64 backend, ld.lld, and a bionic checkout (headers only).
#   BIONIC=<path to aosp platform/bionic checkout>  (default: ./third_party/bionic)
#   JNI_INC=<dir containing jni.h and linux/jni_md.h>  (default: JDK include dir)
# For a full NDK use CMakeLists.txt / Android.mk instead (see docs/BUILDING.md).
set -euo pipefail
cd "$(dirname "$0")"
BIONIC=${BIONIC:-$PWD/third_party/bionic}
JDK_INC=${JDK_INC:-$(dirname "$(dirname "$(readlink -f "$(which javac)")")")/include}
OUT=${OUT:-$PWD/build}
API=${API:-24}
ABI=${1:-${ABI:-arm64-v8a}}
case $ABI in
  arm64-v8a)   TRIPLE=aarch64-linux-android$API; ASM=asm-arm64; ARCHF="-mno-outline-atomics"; BUILTINS="";;
  armeabi-v7a) TRIPLE=armv7a-linux-androideabi$API; ASM=asm-arm; ARCHF="-march=armv7-a -mfloat-abi=softfp -mfpu=vfpv3-d16 -mthumb"; tools/build_builtins_arm.sh "$OUT/armeabi-v7a/builtins" >/dev/null; BUILTINS="$OUT/armeabi-v7a/builtins/libclang_rt.builtins-arm.a";;
  *) echo "unknown ABI $ABI"; exit 2;;
esac
OBJ="$OUT/obj-$ABI"; STUBS="$OUT/stubs-$ABI"; mkdir -p "$OBJ" "$STUBS" "$OUT/$ABI"; rm -f "$OBJ"/*.o
RES=$(clang -print-resource-dir)/include
SRCS="util des ra2 ra4 ra4_client keysym_unused session jni_core jni_session jni_store"
SRCS=${SRCS/keysym_unused /}
COMMON="${OPT:--O3} -g0 -fPIC -fvisibility=hidden -fno-exceptions -fno-rtti -fno-threadsafe-statics -fno-unwind-tables -fno-asynchronous-unwind-tables -Wall -Wno-unused-function -Isrc -Ithird_party/include"
ANDROID_FLAGS="--target=$TRIPLE -nostdinc -nostdinc++ -isystem $RES -isystem $BIONIC/libc/include -isystem $BIONIC/libc/kernel/uapi/$ASM -isystem $BIONIC/libc/kernel/uapi -isystem $BIONIC/libc/kernel/android/uapi -isystem $JDK_INC -isystem $JDK_INC/linux $ARCHF -fstack-protector-strong -DVNCR_DEFINE_DSO_HANDLE"
MBINC="-Ithird_party/mbedtls/include -Ithird_party/mbedtls/library -Ithird_party/mbedtls -DMBEDTLS_CONFIG_FILE=\"vnc_mbedtls_config.h\""
for f in $SRCS; do clang++ -std=c++17 $COMMON $MBINC $ANDROID_FLAGS -c src/$f.cpp -o $OBJ/$f.o; done
for f in aes asn1parse asn1write bignum bignum_core bignum_mod bignum_mod_raw cipher cipher_wrap constant_time ecdh ecp ecp_curves gcm md oid platform platform_util rsa rsa_alt_helpers sha1 sha256 sha512; do clang -std=c11 ${OPT:--O3} -g0 -fPIC -fvisibility=hidden -w $MBINC $ANDROID_FLAGS -c third_party/mbedtls/library/$f.c -o $OBJ/mb_$f.o; done
# Link stubs: the bionic/NDK shared libs are only needed at link time, so generate empty stubs
# exporting exactly the symbols we import.
UND=$(llvm-nm -u --format=just-symbols $OBJ/*.o | sort -u)
python3 -I tools/make_stubs.py "$STUBS" "$TRIPLE" $UND
LIBS="-lc -lm -ldl -llog -landroid -ljnigraphics -lz"
ld.lld -shared -soname libvncviewer.so -z noexecstack -z relro -z now -z max-page-size=16384 --build-id=sha1 --hash-style=gnu \
  --version-script=src/exports.map --gc-sections -o $OUT/$ABI/libvncviewer.so $OBJ/*.o $BUILTINS -L$STUBS $LIBS
python3 -I tools/check_imports.py $OUT/$ABI/libvncviewer.so $BIONIC $ABI
llvm-strip --strip-unneeded $OUT/$ABI/libvncviewer.so 2>/dev/null || true
echo "built $OUT/$ABI/libvncviewer.so ($ABI, $TRIPLE)"
