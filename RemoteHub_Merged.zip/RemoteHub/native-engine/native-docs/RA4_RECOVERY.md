# RA4 / RFB protocol v5 — recovered from `arm64/libvncviewer.so`

Tags: **[BIN]** read directly from decompilation of the original library · **[BIN-inf]** inferred from decompilation where the decompiler dropped or merged arguments · **[SPEC]** public spec · **[TEST]** only verified by our own tests · **[UNKNOWN]** not recovered, not implemented.
Addresses are Ghidra addresses (image base 0x100000). No proprietary code is reproduced; this file describes behaviour only.

## 0. Where RA4 lives
RA4 is **not an RFB security type**. It is the cipher-suite layer of RealVNC's protocol version 5+ (`CProtoV5Up`, factory keyed by the *major* version announced in the 12-byte `RFB MMM.mmm` greeting, `CConnection::readVersion` 0x381e08; `CProtoV4Down` handles ≤4, `CProtoV6` exists). [BIN] A server that announces `RFB 004.001` is served by the V4 code (security types: see SECURITY_TYPES.md) and never reaches RA4. The existing client answers 3.8 to such servers and is unaffected.

## 1. Suite id bit layout [BIN]
Table at 0x43c2f8 (id, name) and 0x43c3a8.. (id, description); helpers 0x38579c/0x38585c/0x38587c/0x3858a4/0x3858bc/0x3858c4.

| bits of id | meaning | evidence |
|---|---|---|
| `id & 7` | 1 = NULL cipher, 2 = AES-GCM-128, 3 = AES-GCM-256, 4 = "ne": AES-GCM-128 during login then NULL-HMAC-SHA1 | 0x38579c, 0x38585c |
| hash bits | 512 if `id&7==3` else 256 (HMAC/KDF hash **and** OAEP hash) | 0x3858a4 |
| per-half nonce bits (RSA-OAEP transport) | `id&7`: 2→128, 3→256, 4→128 (table 0x1bbca8 = {128,256,128}) | 0x38587c |
| bit 10 (0x400) | PSK mixed into the secret | 0x3858bc |
| bit 11 (0x800) | curve index: 0 = Curve25519, 1 = Curve448 (mbedtls group ids 9 / 13, table 0x1c06d4) | 0x3858c4 |
| `id & 0x300` | 0x200: RSA key exchange, peer/local RSA key ≥ 1024 bits; 0x300: ≥ 2048 bits (`cipherKeyExIdRsaOaep`) | 0x36b0c0, 0x36b61c, 0x36b8f0 |

Registry (id → name → description) [BIN]:
0x0001 Null · 0x0101 SignOnly (RSA-PSS, SHA-256, NULL enc) · 0x0202 RA4_128 (RSA-OAEP, ECDHE-25519, SHA-256, GCM-128) · 0x0303 RA4_256 (RSA-OAEP, ECDHE-25519, SHA-512, GCM-256) · 0x0b03 RA4b_256 (RSA-OAEP, ECDHE-448, SHA-512, GCM-256) · 0x0204 RA4ne_128 (RSA-OAEP, ECDHE-25519, SHA-256, GCM-128/NULL-HMAC-SHA1) · 0x0402 RA4-PSK-Only_128 · 0x0403 RA4-PSK-Only_256 · 0x0c03 RA4b-PSK-Only_256 (ECDHE-448) · 0x0602 RA4-PSK_128 · 0x0703 RA4-PSK_256 · 0x0f03 RA4b-PSK_256 (ECDHE-448; all PSK + RSA-OAEP).

## 2. Protocol messages [BIN]
Message type is a big-endian u16 at the start of every V5 message (0x38e1c0). Types: 0x10 Init, 0x11/0x12 init-ext variants (0x38e920), 0x13/0x14 (dispatch to cipher-independent handlers, [UNKNOWN] purpose), **0x15 hello**, **0x16 security digest / rekey / notification**, **0x17 key-exchange payload**. States (`secState`, +0x188 of CProtoV5Up): 0 hello, 1 exchange, 2 digest, 3 verifying digest, 4/5 authenticating/established, 6 init.

* **ClientHello (0x15)** (0x38dd6c): `random[32]` ‖ suite list (vector, serialiser 0x469f24 [BIN, layout of the vector not yet decoded]) ‖ `u8 flag` ‖ auth-method list (0x38599c: `u16 count`, each entry 0x50 bytes: string via 0x3f35f4, `u16 len`+data, vector 0x469f24). Empty suite list → error `rfb_cprotov5_no_ciphers`.
* **ServerHello (0x15)** (0x38e538): `random[32]` ‖ `u16 chosenSuite`. The client **must** find the choice in its own offered list (0x469ee0), otherwise error `chosen cipher %d not offered` — the anti-downgrade check. State → 1.
* **Hello transcript** (0x385ab4): `BE32(conn+0x14) BE32(conn+0x18)` (negotiated protocol major, minor) ‖ offered-suite vector ‖ `u8 flag` ‖ auth-method list ‖ `BE32(conn+0x1c) BE32(conn+0x20)` ‖ `BE16 chosenSuite`. Handed to the cipher together with both 32-byte randoms (0x38e538 → vtable+0x40 of the cipher). It is the initial value of the handshake transcript `T` (+0xa8).
* **0x16 sub-types** (0x3839b8 / 0x38405c / 0x38508c / 0x38422c): `u8 sub`.
  * `0` key renegotiation: `u8 hasNonce, u8 isResponse`, then `nonce[32]` if `hasNonce`. Sequence: request 1/2 (`hasNonce=1,isResponse=0`) → response (`hasNonce=1,isResponse=1`, receiver's own fresh nonce) → request 2/2 (`hasNonce=0,isResponse=1`). A simultaneous request (both sides send request 1/2) is resolved as described in 0x3839b8. Anything else → `bad key exchange sequence`. During the initial exchange `initialCookies` forbids this path (`!initialCookies || rekeyState == SENT_NF2_OR_LF`, CipherCore.cxx:0x55).
  * `1` encryption-change / key-refresh notification: `u8 value` (+ ...) — 0x38508c sends, 0x38405c receives. Same value as before = "key refresh", different = "encryption change (algorithm: NULL / AES-GCM-128 / AES-GCM-256 / NULL-HMAC-SHA1)". Counters at +0x98/+0xa4 (`rekeyCount`) saturate at 0xffffffff → error `re-key needed`. "cipher not established" if sent/received before keys exist.
  * `2` digest: 32-byte digest (0x384900 sends, 0x3843c4 verifies, constant-time compare 0x3e0674 → `security failure (digest mismatch)`; a non-2 sub-type → `digest message required`).
* **0x17 key exchange** — layout depends on the suite family, see §4.

## 3. Key schedule [BIN]
All derivations use one function `KDF(hashBits, outLen, key, data, info)` = 0x436a94:
```
PRK = HMAC_H(key = key, msg = data)               // H = SHA-256 if hashBits<=256 else SHA-512 (0x436e24/0x4370c0/0x4370cc)
T(0) = empty;  T(i) = HMAC_H(PRK, T(i-1) ‖ info ‖ u8(i))   i = 1,2,...
out  = first outLen bytes of T(1)‖T(2)‖...
```
(HKDF-Extract/Expand shape, but note the argument order: the *label* is the Extract key and the *secret* is the Extract message.) `H` is the suite hash (§1). `S`=server, `C`=client nonces; `[S‖C]` is the 64-byte string server-random ‖ client-random (0x384d10 fills offset 0 with the server's and offset 32 with the client's value). `ctr_in/ctr_out` are the u32 rekey counters (+0xa0 / +0xa4), written big-endian.

| value | key | data | info | len | evidence |
|---|---|---|---|---|---|
| MasterSecret | `"RfbMasterSecret"` | shared secret (§4) | `S‖C` | 48 | 0x384b4c |
| SessionId | `"RfbSessionId"` | MasterSecret | `S‖C` | 32 | 0x384b4c |
| next MasterSecret (rekey) | `"RfbMasterSecret"` | previous MasterSecret | `S‖C` with the new nonces | 48 | 0x3839b8 |
| KeyingMaterial (stream) | `"RfbClientKeyingMaterial" ‖ BE32(ctr)` if the key is the *client→server* direction, else `"RfbServerKeyingMaterial" ‖ BE32(ctr)` | MasterSecret | `S‖C‖SessionId` | keyLen+12 | 0x384f10 |
| KeyingMaterial (datagram) | same with `RfbClientDgramKeyingMaterial` / `RfbServerDgramKeyingMaterial` | | | | 0x384f10 |
| Digest | `"RfbClientDigest"` (sent by the server) / `"RfbServerDigest"` (sent by the client) `‖ BE32(ctr)` | MasterSecret | transcript (below) | 32 | 0x384900 / 0x3843c4 |

* The sender of a digest uses the label of the *receiving* role (client sends `RfbServerDigest`, server sends `RfbClientDigest`; receiver verifies the label of its own role) [BIN].
* Digest transcript = `S ‖ C ‖ T` where `T` is the accumulated handshake data: hello transcript (§2) ‖ the cipher-specific key-exchange transcript (§4) [BIN-inf for the exact concatenation order of the two parts: 0x384b4c appends `param_4` to the existing `+0xa8`].
* Key and IV: the keyLen+12 bytes of KeyingMaterial = `key[keyLen] ‖ iv[12]` (0x369804/0x369914) [BIN]. Direction of a key: `out` uses `ctr_out` and the master secret *to be sent with*, `in` uses `ctr_in` and the received one (0x384f10 selects +0x80 vs +0x68 and +0xa4 vs +0xa0).
* Rekey semantics: a request generates a fresh 32-byte nonce into slot A (local), stores the peer nonce in slot B; the incoming keys switch when the response arrives (slot C ← A) and the master secret is replaced with `KDF("RfbMasterSecret", oldMaster, S‖C)`; counters reset to 0 when the secret changes (+0xa0/+0xa4 ← 0, 0x3839b8) and increment on each key refresh notification.

## 4. Key exchange payloads (0x17) [BIN]
**ECDHE** (0x440980 write / 0x44049c read): X25519 → `u8 0x20 ‖ 32 bytes` (RFC 7748 u-coordinate, little-endian as in the RFC); X448 → `u8 0x38 ‖ 56 bytes`. Reader rejects any other length (`Bad length`) and bad points (`Invalid public key`). A third branch (4-byte magic 0xfffecd5a …, NIST curve) exists but no suite selects it. [UNKNOWN: not mapped to a suite → not implemented]
**RSA key** (0x442168 / 0x441f60): `BE32(bits)` ‖ `N` (⌈bits/8⌉ bytes, big-endian, fixed) ‖ `e` as `BE16(len) ‖ e` (variable form, flag 1, used on the wire). The fixed form for `e` (flag 0: `e` padded to ⌈bits/8⌉) is used for identity hashing. Accepted sizes: 1024–8192 bits (0x441f60: `Unsupported RSA key length`); RA4 floor 1024 (id&0x300==0x200) / 2048 (0x300).
**RSA-OAEP nonce transport** (0x36b974, 0x36bc58, 0x4441f0, 0x442cd0, 0x4434d0, 0x443624): each side generates `n = bits/8` random bytes (bits from §1 table), OAEP-encrypts them with the *peer's* RSA public key (hash = SHA-256 or SHA-512 per §1, MGF1 same hash, **empty label**) and sends `BE16(len) ‖ ciphertext` (len must equal the peer modulus size, else `RSA decrypt/check error: bad length`). The receiver decrypts and requires exactly `n` bytes (`Remote nonce size incorrect`). Shared RSA material = `R_server[n] ‖ R_client[n]`.
**Shared secret** (0x36b554): `BE16(len(ecdh)) ‖ ecdh_shared ‖ R_server ‖ R_client`.
**PSK suites** (0x36c1fc): secret = (above) ‖ `BE16(len(myPsk)) ‖ myPsk ‖ BE16(len(peerPsk)) ‖ peerPsk`; each PSK ≥ 16 bytes (`PSK too short`, 0x36bf20). `peerRsaHash`, if provisioned, must equal SHA-256 of the canonical (flag-0) serialisation of the peer's RSA key, constant-time compared (0x36c41c, `Bad peer identity`). PSK pair is supplied by the application as `myPsk=<hex>`, `peerPsk=<hex>`, `peerRsaHash=<hex>` (0x438f94). The PSK identity hash used for server-side lookup is `SHA-256(BE16(|my|) my BE16(|peer|) peer)`, method name `pskhash-sha256` (0x36ec9c, 0x36eddc). [UNKNOWN: whether the orientation of my/peer is swapped between client and server provisioning]
**Exchange transcript** `T_kex` (0x36b974 stores into +0x188): `ECDHpub_server ‖ ECDHpub_client ‖ RSApub_server ‖ RSApub_client` (wire encodings, RSA keys in the wire form with e variable), RSA parts only when the suite has RSA.

## 5. Record layer [BIN]
**AES-GCM** (`TaggedOutStream`/`TaggedInStream`, `AesGcmOut/InStream`; 0x43c9c8/0x43cbb8 write, 0x43c200 read, 0x44723c/0x447380/0x44745c): record = `BE16(plainLen) ‖ ciphertext[plainLen] ‖ tag[16]`; `AAD` = the two length bytes; 12-byte IV = the keying-material tail, **incremented as a little-endian counter after every record** (0x44723c); plainLen ≤ buffer size else `TaggedOutStream: plainLen exceeds bufSize`; tag mismatch → `AES authentication failure`; a zero-length record is allowed. Key length 16 or 32 (`id&7` 2/3). Setting a key is refused mid-record (`!inMsg`, `!plainLen()`).
**NULL / SignOnly / NULL-HMAC-SHA1**: see §6 (partly [UNKNOWN]).

## 6. Additional findings recorded while implementing (tags: [BIN] read from the decompilation, [BIN-inf] inferred from call sites because the decompiler dropped arguments, [TEST] only exercised against our own mock)
* Vector serialiser 0x469f24: BE16 count + elements (suite list: BE16 each; max 65535). String serialiser 0x3f35f4: u8 length + bytes. Auth-method list entry = string | BE16 len + data | vector<u16>. [BIN]
* Hello transcript 0x385ab4 = BE32(major) BE32(minor) | suite vector | flag byte | auth list | BE32(conn+0x1c) BE32(conn+0x20) | BE16(chosen). Major/minor = negotiated protocol version [BIN-inf]; the meaning of +0x1c/+0x20 is **[UNKNOWN]** (we send 0/0).
* NULL-HMAC-SHA1 (RA4ne after login): 0x50 bytes of keying material = 64-byte HMAC key | 16-byte little-endian counter; record = BE16(len) | plaintext | HMAC-SHA1(key, counter | BE16(len) | plaintext); counter incremented per record; failure text "HMAC authentication failure". [BIN] for record shape and text, [BIN-inf] for the key/counter split.
* Phase switch: notification (0x16 sub 1, value 2) on RA4ne; the notification and the digest after it are still sealed with the old keys. [BIN-inf]
* Every notification / rekey step is followed by a digest message (0x16 sub 2) that the receiver must verify before it installs the new incoming keys. [BIN]
* PSK-only suites: the RSA part of the shared secret is a zero buffer of 2 x nonce bytes. [BIN-inf]
* PSK+RSA suites: the peer's RSA key is pinned by SHA-256 of its canonical form and compared in constant time ("Bad peer identity"). [BIN] The application supplies the pin (`peerRsaHash`).
* Our extra safety (not from the binary): all-zero ECDH secret refused, RSA size ranges enforced before use, no Null suite unless explicitly enabled, simultaneous rekey requests rejected.

## 7. Implemented (src/ra4.cpp, src/ra4_client.cpp)
Suite registry (12 ids), preference parsing, KDF/HMAC, AES-GCM-128/256 record layer, NULL-HMAC-SHA1 record layer, X25519/X448, RSA-OAEP (SHA-256/512), PSK mixing, client hello / server-hello validation, key-exchange state machine, digests, 3-message rekey (initiator and responder), key refresh, RA4ne phase switch, error handling. Not implemented, on purpose, because the evidence is insufficient: SignOnly (0x0101) -- reported as "not supported" instead of faking it -- and the NIST-curve branch (magic 0xfffecd5a, unused by any suite).

## 8. V5 message dispatcher (Init 0x10-0x14), recovered in the integration round
Function 0x38caf4 (decompilation: `evidence/v5_message_handlers_decomp.c`, handlers at 0x392044, 0x392110, 0x3921e0, 0x392468, 0x388e94, 0x388ea0, 0x38a0e0, 0x38a0a8, 0x388524) is the **server -> client** message reader of the connection object, used after authentication. Every message starts with a BE16 type:
* 0x10 -- ServerInit (v4 style; vtable slot +0xe0, only when connection state 4) [BIN]
* 0x11 -- NUL-terminated/length string + u8 flag (calls 0x3867e8) [BIN]; 0x12 -- string (0x386908); 0x13 -- u8, u8 (or a second u8 if the vtable +0x30 says it is not implied), string, string -> object with flags `a | b<<1 | 0x10` (0x3869e0) [BIN]; 0x14 -- BE32 + u8 (0x386b60) [BIN]; types 4 and 5 carry no body; types with bit 15 set are rectangles (BE16 x, y, w, h; +BE32 encoding when negotiated protocol major is 3) [BIN]. Anything else: "invalid message type %d" (and "invalid init message type %d" in the init states).
* **Meaning of 0x11-0x14 and the client -> server direction (SetPixelFormat/SetEncodings/update requests/input in the v5 framing), `rvauth` (CAuthProtoImpl.cxx) and the transition into this dispatcher are NOT recovered.** They are server-to-client post-authentication messages, not part of the RA4 key exchange: the key exchange and digests (sections 2-5) are complete without them.
* Version handshake (0x381e08): the client reads the server's "RFB MMM.mmm", chooses min(server, client maximum) and answers with that version; major 5 selects CProtoV5Up (the RA4 layer), <5 CProtoV4Down. We answer with the server's own 005.xxx [BIN-inf: client maximum >= 5].
* SignOnly (0x0101): the key-exchange handler at 0x369084 (`evidence/signonly_kex_0x369084_decomp.c`) rejects a second packet ("unexpected packet"), requires a valid RSA key ("bad RSA key") and calls an RSA primitive at 0x444664 with a 0x100 selector and the serialised key hashing at 0x442168; the signature scheme/padding, hash and transcript coverage are **not established** -> SignOnly stays "not supported".

## 9. Integration into the RFB session (src/session.cpp)
* `Session::handshake`: a server announcing **RFB 005.xxx** (and `Ra4` not disabled, `ProtocolVersion` not forced to 3.8) is answered with the same version and handed to `Session::ra4Handshake`; every other version takes the pre-existing path unchanged (None, VncAuth, RA2 5/6/13/129/130/133, ARD).
* All I/O after the key exchange goes through `vr::ra4::Client` (`ra4Fill`/`sendAll`): records are decrypted/encrypted, security messages (digests, key refresh, rekey from the server) are answered transparently, only application bytes reach `readn`.
* Options (JNI `setOption`/createSession option map): `Ra4` (default 1), `Ra4Suites` (names or ids; default strongest first, PSK suites only when credentials are configured, Null never), `Ra4AllowNull`, `Ra4Psk` / `Ra4MyPsk` / `Ra4PeerPsk` (hex, >=16 bytes), `Ra4PeerRsaHash` (hex SHA-256 pin for PSK+RSA suites), `Ra4Rekey` (`refresh`|`rekey` right after establishment).
* After the digests the session stops with: "RA4 secure channel established (...), but the RFB v5 session protocol that follows it (Init messages, rvauth) is not recovered, so the connection cannot continue." Security description (`secType`/`secDesc`) is set to the suite. No v5 messages are invented.

## 10. rvauth (V5 authentication layer) -- recovered in the second integration round
Address space note: Ghidra addresses in this repository are ELF vaddr + 0x100000 (checked: the "bad RSA key" string is referenced at vaddr 0x269220 inside Ghidra's FUN_00369084). `tools/xref_str.py` (ADRP+ADD scan) finds code that uses a string; `gscripts/DecompForce.java` forces a function entry and decompiles it. Evidence: `evidence/rvauth_authrequest_0x3b6c18_decomp.c`.
* Class family `rvauth::{CAuthProto, CAuthProtoImpl, CAuthFactoryMgr, CAuthUserPasswd(+Factory), AuthFailure, AuthCancelled, NoMatchingAuthMethods}` [BIN: RTTI]. The state machine is FUN_003b6c18 (CAuthProtoImpl.cxx); `state == message type`, anything else throws "invalid auth msg type %d".
* **AuthRequest (server -> client)** [BIN]: `u8 required` | `BE16 count` | count x (`BE16 methodId` | `BE16 len` | `len` bytes of method data). Log text: "Server offered authentication method %s(%d) [required=%d]"; empty list -> "Server offered empty authentication list (auth completed)" and the connection's auth-completed hook is called (vtable +0x40).
* **Method choice (client -> server)** [BIN]: the client walks its own list in preference order ("Looking for auth method %s(%d)"), picks the first id the server offered ("Choosing authentication method %s(%d)"), then sends a message of kind **7** = `BE16 methodId`, ends it, and hands the method's data blob to the method object (vtable +0x20) before flushing. If no match: required=1 -> exception `rvauth_nomatchingauthmethods`; required=0 -> message kind 7 with `BE16 0` (no method). While a method runs the state is 0x18 and messages are forwarded to the method object.
* Method ids: 1..5 have names from a table at 0xbc52c (id->name, "[unknown authMethod %d]" otherwise); `UserPasswd` (CAuthUserPasswd, CModuleUserPasswd.cxx, "unexpected UserPasswd msg") is one of them. **The wire messages of the UserPasswd method (username/password framing, result), the numeric message type of AuthRequest, and which ids map to which names are not recovered.**
* The hello's auth-method list (Section 2) is the client-side advertisement; we still send an empty list ([UNKNOWN] what the real client advertises).
* Not implemented: our session cannot reach the AuthRequest because the numeric type of that message is unknown, so it is not parsed. Everything above is documentation of recovered facts, not code.

## 11. Still [UNKNOWN]
* SignOnly signature scheme; behaviour of the Null suite w.r.t. digests.
* PSK orientation on the server side ([TEST] mock uses the client's order).
* Whether the first digest is sent in the clear (our reading of the log text at 0x384900) -- unverified against a real server.
* The numeric type of AuthRequest, the UserPasswd method messages, meaning of server->client 0x11-0x14, and *all* client->server v5 messages after authentication (pixel format, encodings, update requests, input); transition from rvauth into the dispatcher; hello transcript fields conn+0x1c/+0x20.
* Application records starting with 0x00 0x16 are indistinguishable from security messages in our framing assumption.
* **Consequence:** nothing is implemented beyond the encrypted channel; a v5 session can not be completed, so no RFB v5 compatibility is claimed.
