# API
The replacement exports the same JNI symbols as `docs/original_exports.txt` (verify: `nm -D --defined-only libvncviewer.so`).
Classes live in package `com.realvnc.vncviewer.jni`. Implemented: SessionBindings (create/close/destroy, pointer/wheel/key/focus
events, setOption, copyScaledRegion/getScaledPixels/getScaledBitmap/setScaleBufferSize, auth retry counters), ConnectionInfoBindings,
SymbolBindings (keysym<->Unicode), ConfigurationBindings, ServerRecs/ServerRecBindings (in-memory), PasswordStoreBindings,
PasswdDlg/MsgBox factories. Reference Java stubs used by the tests: `tests/host/java/`.
