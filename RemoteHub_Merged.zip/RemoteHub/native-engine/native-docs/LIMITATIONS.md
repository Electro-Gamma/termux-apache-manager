# Limitations / not reproduced
- **Added (RealVNC server compatibility):** RSA-AES security types 5 (RA2), 6 (RA2ne), 129 (RA2_256), 130 (RA2ne_256) with
  username+password (or password-only) login, via vendored Mbed TLS 3.6.2 (RSA/AES/SHA only, `third_party/mbedtls`). Also fixes
  answering RealVNC's `RFB 004.xxx` banner with 3.8. Verified only against a mock server (independent `cryptography`-based
  implementation) and, for type 6, against noVNC's real RA2ne client code driving the same mock; **not yet verified against a real
  RealVNC Server**. Types 5/129 (encrypted session) follow the spec text only. Two-step types 13/133, server-key trust-on-first-use
  (the key's SHA-1 fingerprint is shown in the connection's security description but never checked) are not implemented.
- **Not implemented:** RealVNC cloud (sign-in, sync, hosted/cloud connections), ICE/STUN/TURN relay, UDP RFB,
  TLS/VeNCrypt, zeroconf discovery. (RA4 and ARD were added later, see the update below.)
- **Approximated:** translation catalog (`loc`/`loc1` return the key / simple `%s` substitution), Id/catchphrase
  functions (pass-through), `getLineSpeed` (empty), security-description and connection-type strings,
  wheel button mapping (5,4,7,6), `createMsgBox` int/title arguments, meaning of `createSession` arg 6.
- **Stubbed (inert):** natives whose Java signatures could not be established (see `src/jni_store.cpp`).
- **Unverified:** all Java-side signatures/callback names were recovered from decompilation, **without the APK**;
  compatibility with the real app is untested. Neither the arm64 nor the armeabi-v7a binary was ever executed; no Android NDK build was run (both ABIs were cross-compiled with clang + AOSP bionic headers; the 32-bit one also links compiler-rt builtins built from source). Minimum Android API is 24.
- **Deliberate deviations:** scaling `step` clamped to >=1; destination buffers bounds-checked; up to 4 retired scale
  buffers retained; destroying a session from inside a callback leaks it rather than deadlocking.
- **Dependencies:** adds libz.so; drops libc++_shared.so. Mbed TLS is linked statically (no new shared library).

## Update: security types
RA2r (13/133), RA2 username-only subtype and Apple ARD (30) are now implemented and the 256-bit RA2 nonce size was corrected. RA4 cipher suites (12 discovered, 11 implemented at the crypto/session-handshake layer, SignOnly unsupported) are implemented as a sans-IO layer and tested against an independent mock, and are reachable from the session for servers announcing RFB 005.xxx (handshake, encrypted channel, rekey/refresh), but the connection then ends with an explicit error because the v5 protocol after the digests (client->server messages, rvauth) is not recovered; unverified against a real server. SignOnly, SSO (cloud sign-in, not an RFB type here), S3, SSPI, Ticket and KvmMgmt are not implemented. See `SECURITY_TYPES.md`, `RA4_RECOVERY.md`, `COMPATIBILITY_REPORT.md`.

## Update: compatibility with older RealVNC servers (regression fix)
A build that failed against a 2022 RealVNC Server (which worked with the first version) was traced, by comparing against the first version's code, to two changes: (1) servers announcing RFB 005.xxx were routed to the RA4 layer, which cannot complete a v5 session; (2) the new RA2r types 13/133 and ARD (30) could be chosen ahead of the types that worked. Now: `Ra4` defaults to **0** (opt-in); the security-type order starts with the original 6,130,5,129, then ARD(30), VNC password(2), None(1), and RA2r (133,13) only as a last resort (`PreferEncrypted=1` restores the encrypted-first order). The log (tag/logcat) now prints the banner version, the security types offered and the one chosen. **Not verified against a real 2022 server (none available here)**; if it still fails, send the logcat lines "server banner ..." / "selected security type ...".
