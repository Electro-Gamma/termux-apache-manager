# Security types of libvncviewer.so: analysis, comparison, implementation status

Target: `arm64/libvncviewer.so` (SHA-256 `68e51b75…eaf13`, ELF64 AArch64, stripped), analysed with Ghidra 11.3.2 (image base 0x100000; Ghidra address = file vaddr + 0x100000).
Tags: **[BIN]** read in the binary · **[SPEC]** public spec / open-source client (rfbproto, TigerVNC `CSecurityRSAAES.cxx`, libvncclient `HandleARDAuth`) · **[TEST]** only verified by our own tests · **[UNKNOWN]**.
Helper scripts: `tools/reverse/` (`relocmap.py`, `dumpregion.py`, `vt.py`, `fn.py`, Ghidra `DecompAddr/RefsTo/DecompRange/VtableOf.java`).

## 1. Discovered security types [BIN]
Source: number→name `switch` at 0x3942cc and the name table at vaddr 0x43d958. Key size / session-encryption helpers at 0x394504 / 0x394528.

| No. | Name in binary | Key bits | Session encrypted | Client implementation found in binary | Ours before | Ours now |
|---|---|---|---|---|---|---|
| 1 | None | – | no | CSecTypeNone | yes | yes |
| 2 | VncAuth | – | no | CSecTypeVncAuth (DES, 16-byte challenge) | yes | yes |
| 3 / 4 | S3 / S3ne | 128 | yes / no | name only; no factory found | no | no (see 3.5) |
| 5 / 6 | RA2_128 / RA2ne_128 | 128 | yes / no | CSecTypeRA2 | yes | yes |
| 7 / 8 | SSPI / SSPIne | 128 | yes / no | name only; no factory found | no | no |
| 9 / 10 | Ticket / Ticketne | 128 | yes / no | name only | no | no |
| 11 / 12 / 14 | SSO_128 / SSOne_128 / SSOr_128 | 128 | yes / no / yes | registered in the RA2 factory table (SSO, SSOne, SSOr) | no | no (see 3.4) |
| 13 | RA2r_128 | 128 | yes (two-step) | CSecTypeRA2 | **no** | **yes** |
| 15 | KvmMgmt | 0 | – | name only | no | no |
| 30 | Ard | – | no | CSecTypeArd | **no** | **yes** |
| 129 / 130 | RA2_256 / RA2ne_256 | 256 | yes / no | CSecTypeRA2 | yes, **wrong nonce size** | yes, fixed |
| 131 / 132 / 134 | SSO_256 / SSOne_256 / SSOr_256 | 256 | yes / no / yes | RA2 factory table | no | no |
| 133 | RA2r_256 | 256 | yes (two-step) | CSecTypeRA2 | **no** | **yes** |

Not present in the binary (no strings, no RTTI): VeNCrypt (19), TLS (18), Tight (16), MSLogonII (113), SASL, xvp, DH (type 30 is Apple's ARD, not the TigerVNC "DH" scheme). The embedded Mbed TLS is used for HTTPS/cloud and RA2/RA4, not for RFB TLS security types. [BIN: string/RTTI absence]

Configuration names → type numbers (table at 0x53dac0, parser 0x394620): RA2 {5,129}, RA2r {13,133}, RA2ne {6,130}, SSO {11,131}, SSOr {14,134}, SSOne {12,132}.

### Second family: RA4 cipher suites (protocol v5, not an RFB security type) [BIN]
Table at vaddr 0x43c2f8; negotiated in `CProtoV5Up` (client hello builder 0x38dd6c, server choice 0x38e538).

| Suite id | Name | Description string in binary |
|---|---|---|
| 0x0001 | Null | NULL key exchange, NULL encryption |
| 0x0101 | SignOnly | RSA-PSS, SHA-256, NULL encryption |
| 0x0202 | RA4_128 | RSA-OAEP, ECDHE-Curve25519, SHA-256, AES-GCM-128 |
| 0x0303 | RA4_256 | RSA-OAEP, ECDHE-Curve25519, SHA-512, AES-GCM-256 |
| 0x0b03 | RA4b_256 | RSA-OAEP, ECDHE-Curve448, SHA-512, AES-GCM-256 |
| 0x0204 | RA4ne_128 | RSA-OAEP, ECDHE-Curve25519, SHA-256, AES-GCM-128 / NULL-HMAC-SHA1 |
| 0x0402 | RA4-PSK-Only_128 | ECDHE-Curve25519, PSK, SHA-256, AES-GCM-128 |
| 0x0403 | RA4-PSK-Only_256 | ECDHE-Curve25519, PSK, SHA-512, AES-GCM-256 |
| 0x0c03 | RA4b-PSK-Only_256 | ECDHE-Curve448, PSK, SHA-512, AES-GCM-256 |
| 0x0602 | RA4-PSK_128 | RSA-OAEP, ECDHE-Curve25519, PSK, SHA-256, AES-GCM-128 |
| 0x0703 | RA4-PSK_256 | RSA-OAEP, ECDHE-Curve25519, PSK, SHA-512, AES-GCM-256 |
| 0x0f03 | RA4b-PSK_256 | RSA-OAEP, ECDHE-Curve448, PSK, SHA-512, AES-GCM-256 |

Low 3 bits select the cipher (1 NULL, 2 AES-GCM-128, 3 AES-GCM-256, 4 AES-GCM-128 with NULL-HMAC-SHA1) (0x38579c). Minimum RSA size is 1024 bits for key-exchange id 0x200 and 2048 bits for 0x300 (0x36b61c).

## 2. Encryption comparison

| Type(s) | Key exchange | Key derivation | Session cipher / framing | Auth of peer | Credentials |
|---|---|---|---|---|---|
| 2 VncAuth | none | – | none; DES-ECB response to 16-byte challenge | shared password | password (max 8 chars) |
| 5/6/129/130 | RSA PKCS#1 v1.5, server key ≥1024 (binary: <512 rejected, `illegal key length`) | keys = H(srvRand‖cliRand), H(cliRand‖srvRand), truncated to key bytes; H = SHA-1 (128) / SHA-256 (256); nonce length = key bytes | AES-EAX, `U16 len ‖ ct ‖ 16-byte tag`, AD = length, nonce = 16-byte LE counter per direction; 5/129 whole session, 6/130 login only | public-key hash exchange (SHA-1/256 of both keys), user-visible fingerprint | username+password (subtype 1), password (2), username only (3) |
| 13/133 | as above | as above, then a second round of fresh nonces inside the EAX channel, same H and truncation, counters reset to 0 | whole session with the second-round keys | as above | as above |
| 30 Ard | Diffie-Hellman (generator u16, key length u16 ≤511, prime, server public) | key = MD5(shared secret, key-length bytes) | none after login; 128-byte `user[64]‖pass[64]` AES-128-ECB, then client public value | none (server identity not authenticated) | username+password |
| RA4 suites | ECDHE (X25519/X448) + RSA-OAEP and/or PSK | HKDF-Expand-like HMAC construction with labels (see 3.6) | AES-GCM (+ rekey messages) | digest of transcript (`RfbServerDigest`/`RfbClientDigest`) | via `rvauth` layer |

## 3. Technical analysis

### 3.1 RA2 family (5, 6, 13, 129, 130, 133)
**[BIN]** `SecTypeRA2.cxx` asserts `keyBits == 128 || keyBits == 256`; `remoteNonce.length() == keyBytes` (0x36f974); logs `using AES-%d`; session key = hash of (local‖remote) for the read direction and (remote‖local) for the write direction, truncated to `min(hashLen, keyBytes)` (0x36f6bc); hash is 160-bit for 16-byte keys, 256-bit otherwise; stream objects `AesEaxIn/OutStream` require 16/32-byte keys, optional 16-byte counter, **counter is zeroed when the key is set**, and re-keying is only allowed between messages. Peer-hash check failure message: `Session key mismatch`. Server key below 512 bits → `illegal key length`; the client's own key must be ≥ 1024 bits for RA4 (RA2: client sends 2048 bits).
**[BIN, extends spec]** the credentials stage reads a subtype byte; username is needed unless subtype is 2, password unless subtype is 3 (0x36e1f0), so **subtype 3 (username only) exists**.
**[BIN]** two-step flow (0x36de8c, 0x36df48, 0x36e028): types 13/133 (and 14/134) after credentials generate `keyBytes` fresh random bytes, write them through the already-encrypted stream, read `keyBytes` from the server, then re-key both directions as above. Non-"r" non-encrypted types restore the plain streams after login (0x36dfac).
**[SPEC]** RSA public-key wire form (`U32 bits ‖ N ‖ E`), PKCS#1 v1.5 padding, hash inputs `U32 len ‖ N ‖ E`, message framing, nonce = LE counter. TigerVNC confirms 32-byte randoms for 256-bit types.
**Correction to the earlier implementation:** it used 16-byte randoms for 129/130, which a real server (and the binary) rejects. Fixed and covered by KATs.

### 3.2 Apple Remote Desktop (30)
**[BIN]** (0x36c558…0x36cb2c, 0x36d000) reads generator (U16), key length (U16, rejects ≥512), prime and server public value; MD5 of the shared secret → 16-byte AES key; 128-byte zero-padded `username[64]‖password[64]`, eight ECB blocks; sends ciphertext then the client public value; then the normal SecurityResult. The viewer additionally disables low-colour and text clipboard for ARD servers and rejects incompatible ARD versions (`rfb_cprotov4down_ard_incompatible_version`). **[SPEC]** identical to libvncclient `HandleARDAuth` except padding (it pads randomly; the binary pads with zeros; both are accepted by servers).
Security note: ARD's DH group is chosen by the server (commonly 512-bit) and the server is not authenticated; the client rejects peer values 0 and 1.

### 3.3 VncAuth / None
Unchanged. [BIN] DES challenge-response with the password truncated/zero-padded to 8 bytes.

### 3.4 SSO types 11/12/14/131/132/134
**[BIN]** The id->name function at 0x3942cc maps 0xb "SSO_128", 0xc "SSOne_128", 0xe "SSOr_128", 0x83 "SSO_256", 0x84 "SSOne_256", 0x86 "SSOr_256" (a logging helper; ids 3/4/7/8/9/10/15 are mapped the same way). There is **no** CSecType/CModuleSecurity/factory class for any SSO type (RTTI lists only None, VncAuth, RA2, Ard, UserPasswd factories and the RA2/RA4/RA4ne/RA4Psk/SignOnly/Ard/None/VncAuth modules). "SSO" in this library is the RealVNC *cloud account* sign-in: `SignInMgr`, `HostedSso`, an OIDC identifier/IdP URL policy (`OidcOrgIdentifier`, `OidcIdentityProviderUrl`), a browser redirect to `<server>/sso_client_callback?sso_uri=<scheme>://localhost/login` and an `ssoAccessToken` obtained over HTTPS. It is not an RFB handshake in this binary. **Not implemented**: there is no recovered on-the-wire credential format and none will be invented.
### 3.5 S3 (3/4), SSPI (7/8), Ticket (9/10), KvmMgmt (15)
**[BIN]** name-table entries only (0x3942cc; strings "SSPI", "SSPIne", "Ticket", "Ticketne", "KvmMgmt"; ids 3/4 have unnamed entries). No factory, module, state machine or RTTI class exists for them in this build, so they are **reserved registrations, not implementations**. SSPI is a Windows API. Not implemented; if a server offers only these the client reports "no matching security type".
### 3.6 RA4 (cipher suites)
**Implemented** as a sans-IO layer (`src/ra4.*`, `src/ra4_client.cpp`) for 11 of the 12 suites; full evidence and open points are in `RA4_RECOVERY.md`. SignOnly (0x0101) is reported as unsupported ([UNKNOWN] exchange). RA4 is reachable from the session for servers announcing RFB 005.xxx (see RA4_RECOVERY.md sections 8-9); the connection ends after the encrypted channel is up because the v5 protocol above the digest (client->server messages, rvauth) is not recovered; RealVNC servers announcing 004.001 use the V4 path which never reaches RA4. Verified only by known-answer vectors and an independent mock server ([TEST]), **not** against a real RealVNC server.
Preference string: comma/space separated names or ids (`RA4b_256,0x0303,RA4-PSK_128`); empty = default (strongest first, Null excluded); unknown names, duplicates and unsupported suites are errors.

## 4. Missing / incorrect implementations (status)
| Item | Status |
|---|---|
| RA2_256 / RA2ne_256 nonce length (16 → 32) | **fixed** |
| RA2r 13 / 133 | **implemented** |
| RA2 subtype 3 | **implemented** |
| Ard 30 | **implemented** |
| Encrypted SecurityResult read-ahead lost when encryption starts (found by the new tests; intermittent failure) | **fixed** |
| SSO (11/12/14/131/132/134) | cloud sign-in, not an RFB type in this binary; not implemented (3.4) |
| S3, SSPI, Ticket, KvmMgmt | reserved names only; not implemented (3.5) |
| RA4 suites 0x0202 0x0303 0x0b03 0x0204 0x0402 0x0403 0x0c03 0x0602 0x0703 0x0f03 and Null 0x0001 | **implemented** as a sans-IO layer, mock-tested (3.6); not wired into the RFB session |
| RA4 SignOnly 0x0101 | not implemented ([UNKNOWN] RSA-PSS exchange) |

## 5. Tests (`tests/host/run_tests.sh`)
* KATs (`ra2_kat.cpp`): AES-EAX (paper vectors + AES-256), RA2 key derivation 128/256, MD5 (RFC 1321), ARD DH + credential blob, degenerate DH value rejected, counter restart on re-key. Expected values from Python hashlib/`cryptography`.
* Independent mock servers written separately in Python (`ra2_server.py`, `ard_server.py`): 5, 6, 129, 130, 13, 133, subtype 1/2/3, retry, failure, preference order; ARD with 512/1024-bit DH, retry, failure.
* Compatibility: noVNC's own RA2ne client against the mock (`novnc_check/check.mjs`, passes); TigerVNC source used as reference for nonce/hash sizes.
* The full suite was run 5 times with no failures after the read-ahead fix.
* RA4 (`ra4_kat.cpp`, `ra4_server.py`, `ra4_driver.cpp`, `run_ra4_tests.sh`): 58 known-answer checks (RFC 7748 X25519/X448, RFC 4231/2202 HMAC, NIST GCM, python-generated GCM/KDF/key-schedule/record/OAEP vectors) and ~50 TCP scenarios against an independent Python server: all 11 implemented suites (10 key-exchange + Null) with data, client- and server-initiated rekey, key refresh, RA4ne GCM->NULL-HMAC switch, 20 KB transfer; negotiation (unoffered/Null/unknown/duplicate suites); failures (wrong/short/missing PSK, wrong identity pin, tampered ciphertext/tag, replayed record, bad digest, bad OAEP, wrong nonce length, weak RSA key, zero ECDH value, garbage type, truncation); recovery after a failed connection.

## 6. Limitations
* No real RealVNC Server, TigerVNC server or Apple server was available: interoperability with real servers is **unverified** (only mock servers and noVNC for 128-bit ne).
* arm64 build was not rebuilt here (no bionic headers); sources are unchanged in structure and only use already-linked Mbed TLS modules.
* Server-key trust: the fingerprint is only shown, never persisted or compared across sessions.
* Default type order is unchanged for compatibility: `6,130,5,129,13,133` (login-only first); set `PreferEncrypted=1` for `133,129,13,5,130,6`. ARD ranks below RA2 and above VncAuth.
