# Compatibility report (RA4 work)

Legend: [BIN] read from libvncviewer.so, [BIN-inf] inferred from call sites, [SPEC] public specification, [TEST] verified only against our own tests, [UNKNOWN].

| Area | Result | Evidence |
|---|---|---|
| RFC 7748 X25519 / X448 | matches | [SPEC] vectors in `ra4_kat` |
| HMAC-SHA1/256/512, AES-GCM-128/256 | matches | [SPEC] RFC 4231/2202, NIST; python `cryptography` |
| RSA-OAEP SHA-256/512 (empty label) | matches python | [TEST] external ciphertexts decrypted by the C++ code |
| KDF, labels, nonce slots, digests, keying material, rekey | match an independent python implementation of the recovered construction | [BIN] construction, [TEST] check |
| GCM record framing + little-endian IV increment | python-produced stream decoded | [BIN] framing, [TEST] |
| NULL-HMAC-SHA1 record | python-produced record verified | [BIN-inf] key split, [TEST] |
| 11 of the 12 discovered suites (10 key-exchange + Null) end-to-end | pass against `ra4_server.py` | [TEST] (shares our interpretation) |
| Real RealVNC server | **not tested** | no authorised server available |
| Whole RFB session over RA4 | **not possible yet** | v5 client->server messages and UserPasswd method messages [UNKNOWN]; AuthRequest/AuthChoice structure recovered (RA4_RECOVERY.md section 10) but not implemented |
| SignOnly 0x0101 | refused with an explicit error | [UNKNOWN] |
| SSO / S3 / SSPI / Ticket / KvmMgmt | not RFB implementations in this binary | [BIN] no classes; name table only |

Existing behaviour (None, VncAuth, RA2 5/6/129/130, RA2r 13/133, ARD 30, JNI API) is unchanged: the full pre-existing test suite still passes. The arm64-v8a library builds with build.sh (bionic headers from the AOSP mirror): import check OK, exports identical to the original, 16 KB aligned; it was not executed on a device.

## Levels of verification (RA4)
| Level | Status |
|---|---|
| Implemented and tested on host (KAT + independent Python server over TCP) | yes: 11 of the 12 discovered suites (`tests/host/run_ra4_tests.sh`) |
| Integrated into the real session and tested through JNI (x86-64 host build of the same sources, JVM `ApiTest ra4` vs `ra4_server.py --rfb`) | yes, up to and including the encrypted channel, digests, server- and client-initiated rekey/refresh, failures, reconnection (`tests/host/run_ra4_session_tests.sh`, 28 cases). The session then stops with an explicit error because the v5 post-handshake protocol is not recovered |
| Built for Android arm64 | `build.sh arm64-v8a` (clang + AOSP bionic headers): ELF64 AArch64, imports OK at API 24, 130 exports identical to the original, SONAME libvncviewer.so, 16 KB aligned. **Not** built with the Android NDK, not run on a device |
| Built for Android ARMv7 | `build.sh armeabi-v7a`: genuine ELF32 ARM, EABI5, Tag_CPU_arch v7, no NEON requirement, same exports/SONAME/NEEDED/alignment checks (`tools/verify_elf.sh`). compiler-rt builtins built from source. **Not** an NDK build, **not executed** (no 32-bit runtime here) |
| Tested against a real compatible (RealVNC) server | **no** |
RA4 count: 12 discovered, 11 implemented at the crypto/session-handshake layer, SignOnly unsupported. Complete RA4 / RFB v5 compatibility is therefore **not** claimed: the full v5 session after authentication and every real-server behaviour assumed in section 10 of RA4_RECOVERY.md remain unverified.
