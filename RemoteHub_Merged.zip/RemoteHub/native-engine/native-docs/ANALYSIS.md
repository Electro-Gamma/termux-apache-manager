# Analysis summary
Original: ELF64 AArch64 shared object, soname libvncviewer.so, needs libdl, liblog, libandroid, libjnigraphics,
libc++_shared, libm, libc. 130 exports: `JNI_OnLoad` (JNI 1.4) and 129 `Java_com_realvnc_vncviewer_jni_<Class>Bindings_<method>`.
Statically contains mbedTLS, zstd tracing, RealVNC cloud/ICE/RA2/RA4 code and a UDP RFB transport.
Method: Ghidra headless decompilation of every JNI entry, string/xref review, then re-implementation of observable behaviour.
Recovered contracts: session-token + native `long impl` handle pattern; dialog/prompt factories answered via `*Result`
natives; viewer pixel format (32bpp, depth 24, little-endian, shifts r0 g8 b16); scaled copy algorithm; keysym tables
(`tools/extract_keysym_tables.py`, `src/keysym_tables.inc`); configuration defaults (`kParams`).
Full export list: `docs/original_exports.txt`. Ghidra scripts/decompiled output were kept outside this tree.
