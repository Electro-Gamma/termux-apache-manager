# Native VNC engine: upstream documentation, tests and tools

These folders come with the engine package (`vncviewer-app`) whose sources are built into the app from
`app/src/main/cpp/`. They are reference material and are **not** part of the Gradle build.

- `native-docs/` - what the library implements, its limits (`LIMITATIONS.md`), security types, RA4 notes, compatibility
  report, API notes.
- `native-tests/` - the engine's own tests (RA2/RA4 known-answer tests, mock RFB/RA2/RA4/ARD servers, a JVM API test). They
  expect the engine's original layout (`src/`, `third_party/mbedtls/`, `tests/host/`, `build/host/`); to run them, copy
  `app/src/main/cpp/vnc` to `src`, `app/src/main/cpp/mbedtls` to `third_party/mbedtls` and this folder to `tests/host`.
- `native-tools/` - standalone build scripts (clang + bionic headers), ELF/import checks.

Left out on purpose: `native-docs/evidence/` (decompiler output of the original proprietary library) and
`native-tools/tools/reverse/` (the Ghidra scripts that produced it). They are not needed to build or understand the app.

`app/src/main/cpp/tests/host/` is separate: the decoder/pipeline test and benchmarks written for Remote Hub.

Differences between `app/src/main/cpp/` and the engine package this folder came with (details in `app/src/main/cpp/README_PERFORMANCE.md`):
performance changes in `session.cpp`/`session.h`, one extra JNI export (`copyRegionToBitmap`, so 131 exports instead of the original 130),
a one-line `rd8()` fix for RA4 mode, and the `PreferEncrypted` security-type order. The package's own tests that check the export list against
`native-docs/original_exports.txt` will therefore report that one extra symbol.
