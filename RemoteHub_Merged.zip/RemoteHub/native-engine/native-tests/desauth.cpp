// CLI helper for the mock server: prints the VNC-auth response for <password> <32 hex chars challenge>.
#include "des.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(int c, char** v) {
  if (c == 2 && !strcmp(v[1], "selftest")) {   // DES: FIPS 81 / classic vector, key 133457799BBCDFF1, pt 0123456789ABCDEF -> 85E813540F0AB405
    // Reference: openssl des-ecb, key = bit-reversed "password", zero block -> ff97502e9422f089
    uint8_t ch[16] = {0}, out[16]; vr::vncAuthResponse("password", ch, out);
    static const uint8_t ref[8] = {0xff,0x97,0x50,0x2e,0x94,0x22,0xf0,0x89};
    bool ok = !memcmp(out, ref, 8) && !memcmp(out + 8, ref, 8);
    puts(ok ? "DES selftest ok (matches OpenSSL reference)" : "DES selftest FAILED"); return ok ? 0 : 1; }
  if (c < 3) return 1; uint8_t ch[16], out[16];
  for (int i = 0; i < 16; i++) { unsigned x; sscanf(v[2] + 2 * i, "%2x", &x); ch[i] = (uint8_t)x; }
  vr::vncAuthResponse(v[1], ch, out);
  for (int i = 0; i < 16; i++) printf("%02x", out[i]); puts(""); return 0;
}
