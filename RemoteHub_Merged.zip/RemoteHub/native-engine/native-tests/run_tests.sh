#!/bin/bash
# Functional tests: x86-64 host build of the same sources, driven from a JVM against a Python mock RFB server.
set -u
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"; B=$ROOT/build/host; T=$ROOT/tests/host; W=${TMPDIR:-/tmp}/vnctest.$$; mkdir -p $W
javac -nowarn -d $B/classes $(find $T/java -name "*.java") 2>&1 | grep -v JAVA_TOOL; LIB=$B/libvncviewer.so; fail=0; port=15900
run_case() { # name proto auth enc pws [opts] [expectfail]
  local n=$1 pr=$2 au=$3 en=$4 pw=$5 op=${6:-} ef=${7:-}; port=$((port+1))
  python3 $T/mock_vnc.py --port $port --proto $pr --auth $au --password ${PW:-secret} --enc $en ${EXTRA:-} --log $W/$n.log --expected $W/exp.rgba >$W/$n.srv 2>&1 &
  local sp=$!; sleep 0.7
  timeout 60 java -Dvnclib=$LIB -Djava.library.path=$B -cp $B/classes ApiTest session $port $W/exp.rgba "$pw" "$op" $ef >$W/$n.out 2>&1; local rc=$?
  kill $sp 2>/dev/null; wait $sp 2>/dev/null
  if [ $rc -eq 0 ] && [ -n "${EXPECT_SEC:-}" ] && ! grep -q "\"sectype\", \"t\": $EXPECT_SEC}" $W/$n.log; then echo "[FAIL] $n: server did not see security type $EXPECT_SEC"; grep sectype $W/$n.log; fail=1; return; fi
  if [ $rc -eq 0 ] && [ -n "${EXPECT_PROMPTS:-}" ] && ! grep -q "PROMPTS $EXPECT_PROMPTS\$" $W/$n.out; then echo "[FAIL] $n: expected $EXPECT_PROMPTS password prompt(s)"; grep -E "PROMPTS|prompt #" $W/$n.out; fail=1; return; fi
  if [ $rc -eq 0 ]; then echo "[ok]   $n"; else echo "[FAIL] $n (see $W/$n.out)"; grep -E '^FAIL|Exception|Error' $W/$n.out | head -5; fail=1; fi
}
echo "== DES FIPS vector"; $B/desauth selftest || fail=1
echo "== static API"; java -Dvnclib=$LIB -cp $B/classes ApiTest static 2>&1 | grep -E 'FAIL|PASSED|FAILED|Exception' ; [ ${PIPESTATUS[0]} -eq 0 ] || fail=1
for pr in 3.3 3.7 3.8; do for en in raw hextile rre zrle; do run_case "none_${pr}_$en" $pr none $en ""; done; done
run_case vnc_auth_3.8 3.8 vnc zrle "secret"
run_case vnc_auth_3.3 3.3 vnc raw "secret"
run_case vnc_retry 3.8 vnc zrle "wrong,secret"
run_case vnc_fail 3.8 vnc zrle "bad1,bad2,bad3,bad4" "" expectfail
echo "== RA2 (RSA-AES) security types, mock server with username/password pi/raspberry"
EXTRA="--user pi --offer 6" PW=raspberry EXPECT_SEC=6 EXPECT_PROMPTS=1 run_case ra2ne_6 3.8 ra2 zrle "pi:raspberry"
EXTRA="--user pi --offer 130" PW=raspberry EXPECT_SEC=130 EXPECT_PROMPTS=1 run_case ra2ne256_130 3.8 ra2 zrle "pi:raspberry"
EXTRA="--user pi --offer 5" PW=raspberry EXPECT_SEC=5 EXPECT_PROMPTS=1 run_case ra2_5_encrypted_session 3.8 ra2 zrle "pi:raspberry"
EXTRA="--user pi --offer 129" PW=raspberry EXPECT_SEC=129 EXPECT_PROMPTS=1 run_case ra2_129_encrypted_session 3.8 ra2 hextile "pi:raspberry"
EXTRA="--user pi --offer 5,6,129,130" PW=raspberry EXPECT_SEC=6 EXPECT_PROMPTS=1 run_case ra2_offer_all_default 3.8 ra2 zrle "pi:raspberry"
EXTRA="--user pi --offer 5,6,129,130" PW=raspberry EXPECT_SEC=129 EXPECT_PROMPTS=1 run_case ra2_offer_all_prefer_encrypted 3.8 ra2 zrle "pi:raspberry" "PreferEncrypted=1"
EXTRA="--user pi --offer 6" PW=raspberry EXPECT_SEC=6 EXPECT_PROMPTS=0 run_case ra2_credentials_from_options 3.8 ra2 raw "" "Username=pi,Password=raspberry"
EXTRA="--offer 5" PW=raspberry EXPECT_SEC=5 EXPECT_PROMPTS=1 run_case ra2_password_only_subtype2 3.8 ra2 rre "raspberry"
EXTRA="--user pi --offer 6" PW=raspberry EXPECT_PROMPTS=2 run_case ra2_retry_after_wrong_password 3.8 ra2 zrle "pi:wrong,pi:raspberry"
EXTRA="--user pi --offer 6" PW=raspberry run_case ra2_auth_failure 3.8 ra2 zrle "pi:x1,pi:x2,pi:x3,pi:x4" "" expectfail
echo "== RA2r two-step (13/133), 256-bit nonces, subtype 3, Apple ARD (30)"
EXTRA="--user pi --offer 13" PW=raspberry EXPECT_SEC=13 EXPECT_PROMPTS=1 run_case ra2r_13_two_step 3.8 ra2 zrle "pi:raspberry"
EXTRA="--user pi --offer 133" PW=raspberry EXPECT_SEC=133 EXPECT_PROMPTS=1 run_case ra2r_256_133_two_step 3.8 ra2 hextile "pi:raspberry"
EXTRA="--offer 133" PW=raspberry EXPECT_SEC=133 EXPECT_PROMPTS=1 run_case ra2r_256_password_only 3.8 ra2 raw "raspberry"
EXTRA="--user pi --offer 13,5,6" PW=raspberry EXPECT_SEC=6 run_case ra2_default_order_keeps_ne_first 3.8 ra2 raw "pi:raspberry"
EXTRA="--user pi --offer 13,5,6,129,130,133" PW=raspberry EXPECT_SEC=133 run_case ra2r_preferred_when_encrypted_first 3.8 ra2 raw "pi:raspberry" "PreferEncrypted=1"
EXTRA="--user pi --offer 13" PW=raspberry EXPECT_PROMPTS=2 run_case ra2r_retry_after_wrong_password 3.8 ra2 zrle "pi:bad,pi:raspberry"
EXTRA="--user pi --offer 133" PW=raspberry run_case ra2r_auth_failure 3.8 ra2 zrle "pi:x1,pi:x2,pi:x3,pi:x4" "" expectfail
EXTRA="--user pi --offer 129 --subtype 3" PW=raspberry EXPECT_SEC=129 EXPECT_PROMPTS=1 run_case ra2_subtype3_username_only 3.8 ra2 raw "pi:"
EXTRA="--user pi --dhbits 512" PW=raspberry EXPECT_SEC=30 EXPECT_PROMPTS=1 run_case ard_dh512 3.8 ard zrle "pi:raspberry"
EXTRA="--user pi --dhbits 1024" PW=raspberry EXPECT_SEC=30 EXPECT_PROMPTS=1 run_case ard_dh1024_hextile 3.8 ard hextile "pi:raspberry"
EXTRA="--user pi --dhbits 512" PW=raspberry EXPECT_PROMPTS=2 run_case ard_retry_after_wrong_password 3.8 ard raw "pi:bad,pi:raspberry"
EXTRA="--user pi --dhbits 512" PW=raspberry run_case ard_auth_failure 3.8 ard raw "pi:x1,pi:x2,pi:x3,pi:x4" "" expectfail
echo "== known-answer tests"; $B/ra2_kat || fail=1
echo "== RA4 (KAT + independent mock server)"; bash $T/run_ra4_tests.sh || fail=1
echo "== RA4 through the real session / JNI path"; bash $T/run_ra4_session_tests.sh || fail=1
echo "== Android ELF verification (arm64-v8a + armeabi-v7a)"; bash $ROOT/tools/verify_elf.sh $ROOT/build || fail=1
exit $fail
