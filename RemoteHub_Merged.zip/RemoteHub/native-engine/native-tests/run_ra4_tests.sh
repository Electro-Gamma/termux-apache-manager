#!/bin/bash
# RA4 tests: known-answer vectors + independent Python mock server vs the C++ client (real TCP).
# NOTE: the mock server shares our interpretation of the binary evidence ([TEST]); it is not a real RealVNC server.
set -u
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"; B=$ROOT/build/host; T=$ROOT/tests/host; W=${TMPDIR:-/tmp}/ra4test.$$; mkdir -p $W
fail=0; port=${RA4_PORT:-17100}
echo "== RA4 known-answer tests"; $B/ra4_kat | grep -vE '^PASS' ; [ ${PIPESTATUS[0]} -eq 0 ] || fail=1
PSK=000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f
# case NAME  SERVER_ARGS  DRIVER_ARGS  [expected error substring]   (SERVER_ARGS: --suite/--flags/--psk-*)
case_() {
  local n=$1 sa=$2 da=$3 ee=${4:-}; port=$((port+1)); local hf=$W/$n.hash; rm -f $hf
  python3 -I $T/ra4_server.py --port $port --hash-file $hf $sa >$W/$n.srv 2>&1 &
  local sp=$!; for i in $(seq 1 100); do grep -q READY $W/$n.srv 2>/dev/null && [ -f $hf ] && break; sleep 0.1; done
  local pin=""; [[ "$da" == *"@PIN@"* ]] && { pin=$(cat $hf); da=${da//@PIN@/$pin}; }
  local ex=""; [ -n "$ee" ] && ex="--expect-err $ee"
  timeout 60 $B/ra4_driver $port $da $ex >$W/$n.out 2>&1; local rc=$?
  kill $sp 2>/dev/null; wait $sp 2>/dev/null
  if [ $rc -eq 0 ]; then echo "[ok]   $n   $(tail -1 $W/$n.out)"; else echo "[FAIL] $n"; tail -3 $W/$n.out; echo "  server: $(tail -2 $W/$n.srv | tr '\n' ' ')"; fail=1; fi
}
SC="--script ping,rekey,ping,refresh,ping,srv-rekey,ping,srv-refresh,ping,big,ping"
echo "== every implemented suite: handshake + data + client/server rekey + key refresh"
for s in 0x0202 0x0303 0x0b03 0x0204; do case_ suite_$s "--suite $s" "$s $SC"; done
for s in 0x0402 0x0403 0x0c03; do case_ suite_$s "--suite $s --psk-my $PSK --psk-peer $PSK" "$s --my-psk $PSK --peer-psk $PSK $SC"; done
for s in 0x0602 0x0703 0x0f03; do case_ suite_$s "--suite $s --psk-my $PSK --psk-peer $PSK" "$s --my-psk $PSK --peer-psk $PSK --rsa-hash @PIN@ $SC"; done
case_ suite_0x0204_ne_switch_to_null_hmac "--suite 0x0204" "0x0204 --script ping,switch,ping,ping,big,srv-refresh,ping"
case_ suite_0x0001_null "--suite 0x0001" "0x0001 --allow-null --script ping"
echo "== negotiation"
case_ negotiate_strongest_first "--suite 0x0b03,0x0303,0x0202" "0x0b03,0x0303,0x0202 --script ping"
case_ negotiate_server_picks_other_offered "--suite 0x0202" "0x0303,0x0202 --script ping"
case_ negotiate_names "--suite 0x0303" "RA4_256 --script ping"
case_ reject_unoffered_choice "--suite 0x0303 --flags choose:0x0b03" "0x0303" "not offered"
case_ reject_null_downgrade "--suite 0x0303 --flags choose:0x0001" "0x0303" "not offered"
case_ reject_null_unless_enabled "--suite 0x0001" "0x0001" "Null cipher suite must be enabled"
case_ reject_null_selected_when_not_enabled "--suite 0x0001 --flags choose:0x0001" "0x0303,0x0001" "Null cipher suite must be enabled"
case_ reject_unknown_suite_id "--suite 0x0303" "0x0702" "nknown RA4"
case_ reject_signonly_unsupported "--suite 0x0303" "0x0101" "not supported"
case_ reject_duplicate_suite "--suite 0x0303" "0x0303,RA4_256" "uplicate RA4"
echo "== failure handling (no silent success)"
case_ psk_wrong_server_key "--suite 0x0403 --psk-my $PSK --psk-peer $PSK --flags wrong-psk" "0x0403 --my-psk $PSK --peer-psk $PSK" "digest mismatch"
case_ psk_wrong_client_key "--suite 0x0402 --psk-my $PSK --psk-peer $PSK" "0x0402 --my-psk 0f0e0d0c0b0a09080706050403020100ffffffffffffffff --peer-psk $PSK" "digest mismatch"
case_ psk_too_short "--suite 0x0402" "0x0402 --my-psk 0011 --peer-psk 0011" "PSK too short"
case_ psk_missing "--suite 0x0402" "0x0402" "PSK not available"
case_ psk_rsa_wrong_identity_pin "--suite 0x0703 --psk-my $PSK --psk-peer $PSK" "0x0703 --my-psk $PSK --peer-psk $PSK --rsa-hash 00112233445566778899aabbccddeeff00112233445566778899aabbccddeeff" "Bad peer identity"
case_ psk_rsa_no_pin "--suite 0x0703 --psk-my $PSK --psk-peer $PSK" "0x0703 --my-psk $PSK --peer-psk $PSK" "PSK not available"
case_ bad_tag_ciphertext "--suite 0x0303 --flags tamper-ct" "0x0303 --script ping" "AES authentication failure"
case_ bad_tag_tag "--suite 0x0b03 --flags tamper-tag" "0x0b03 --script ping" "AES authentication failure"
case_ bad_tag_128 "--suite 0x0202 --flags tamper-tag" "0x0202 --script ping" "AES authentication failure"
case_ replayed_record "--suite 0x0303 --flags replay" "0x0303 --script ping,ping,ping" "AES authentication failure"
case_ bad_server_digest "--suite 0x0303 --flags bad-digest" "0x0303" "digest mismatch"
case_ bad_oaep_ciphertext "--suite 0x0303 --flags bad-oaep" "0x0303" "RSA decrypt error"
case_ bad_nonce_length "--suite 0x0303 --flags bad-nonce-len" "0x0303" "nonce size incorrect"
case_ weak_server_rsa_key "--suite 0x0303 --flags short-rsa" "0x0303" "does not meet"
case_ zero_ecdh_public "--suite 0x0303 --flags zero-ecdh" "0x0303" "key"
case_ garbage_message_type "--suite 0x0303 --flags garbage-type" "0x0303" "invalid key exchange message type"
case_ truncated_key_exchange "--suite 0x0303 --flags truncate" "0x0303" "connection closed"
echo "== failure and recovery (same server, first connection fails, second succeeds)"
port=$((port+1)); python3 -I $T/ra4_server.py --port $port --max-conns 2 --flags "bad-digest;none" --suite 0x0303 >$W/rec.srv 2>&1 & sp=$!
for i in $(seq 1 100); do grep -q READY $W/rec.srv && break; sleep 0.1; done
$B/ra4_driver $port 0x0303 --expect-err "digest mismatch" >$W/rec1.out 2>&1; r1=$?
$B/ra4_driver $port 0x0303 --script ping,rekey,ping >$W/rec2.out 2>&1; r2=$?
kill $sp 2>/dev/null; wait $sp 2>/dev/null
if [ $r1 -eq 0 ] && [ $r2 -eq 0 ]; then echo "[ok]   recovery_after_failed_connection"; else echo "[FAIL] recovery (rc $r1 $r2)"; cat $W/rec1.out $W/rec2.out; fail=1; fi
echo; [ $fail -eq 0 ] && echo "RA4 tests: ALL PASSED" || echo "RA4 tests: FAILURES"
exit $fail
