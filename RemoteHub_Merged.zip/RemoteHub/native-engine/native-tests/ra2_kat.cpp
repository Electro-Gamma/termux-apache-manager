// Known-answer tests for the AES-EAX implementation (vectors from the EAX paper, Bellare/Rogaway/Wagner 2003, appendix G).
#include "ra2.h"
#include <stdio.h>
using namespace vr;
static size_t hex(const char* s, u8* o) { size_t n = 0; for (; s[0] && s[1]; s += 2) { unsigned v; sscanf(s, "%2x", &v); o[n++] = (u8)v; } return n; }
static int fails = 0;
static void kat(const char* key, const char* nonce, const char* hdr, const char* msg, const char* expect) {
  u8 k[32], n[16], h[64], m[64], e[96], out[96]; size_t kl = hex(key, k), nl = hex(nonce, n), hl = hex(hdr, h), ml = hex(msg, m), el = hex(expect, e);
  ra2::Cipher c; if (!c.init(k, (int)kl) || nl != 16) { puts("FAIL init"); fails++; return; }
  bool ok = c.eaxSeal(n, h, hl, m, ml, out) && el == ml + 16 && !memcmp(out, e, el);
  u8 back[64]; bool ok2 = c.eaxOpen(n, h, hl, e, ml, back) && !memcmp(back, m, ml);
  out[0] ^= 1; bool ok3 = !c.eaxOpen(n, h, hl, out, ml, back);   // tampered ciphertext/tag must be rejected
  printf("%s EAX KAT (msg %zu bytes): seal=%d open=%d tamper-rejected=%d\n", ok && ok2 && ok3 ? "PASS" : "FAIL", ml, ok, ok2, ok3);
  if (!(ok && ok2 && ok3)) fails++;
}

static void check(const char* name, bool ok) { printf("%s %s\n", ok ? "PASS" : "FAIL", name); if (!ok) fails++; }
static bool eqhex(const u8* d, size_t n, const char* h) { u8 e[512]; size_t el = hex(h, e); return el == n && !memcmp(d, e, n); }
static void moreTests() {
  // MD5 (RFC 1321 appendix A.5)
  u8 d[16]; ard::md5((const u8*)"", 0, d); check("MD5 \"\"", eqhex(d, 16, "d41d8cd98f00b204e9800998ecf8427e"));
  ard::md5((const u8*)"abc", 3, d); check("MD5 \"abc\"", eqhex(d, 16, "900150983cd24fb0d6963f7d28e17f72"));
  const char* m80 = "12345678901234567890123456789012345678901234567890123456789012345678901234567890";
  ard::md5((const u8*)m80, 80, d); check("MD5 80-digit (two blocks)", eqhex(d, 16, "57edf4a22be3c955ac49da2e2107b67a"));
  // RA2 session keys (expected values computed with Python hashlib)
  u8 cr[32], sr[32], c2s[32], s2c[32]; for (int i = 0; i < 32; i++) { cr[i] = (u8)i; sr[i] = (u8)(100 + i); }
  ra2::deriveKeys(false, 16, cr, sr, c2s, s2c);
  check("RA2 keys AES-128 (SHA-1 truncated to 16) c2s", eqhex(c2s, 16, "0e3ef812b14ca7b090de3f0ff9baf740"));
  check("RA2 keys AES-128 s2c", eqhex(s2c, 16, "785b67b01290c56cc7e93a5d58fbf46e"));
  ra2::deriveKeys(true, 32, cr, sr, c2s, s2c);
  check("RA2 keys AES-256 (32-byte nonces, SHA-256) c2s", eqhex(c2s, 32, "0eca610478174856c3416c0c57b8ca044cda1992c277999602be7b0ef6586619"));
  check("RA2 keys AES-256 s2c", eqhex(s2c, 32, "bd2a1f6a1c7be24cd4a6ddb5d2094bd7dd2e0f8ea1c7c069c33e4505f523b5dc"));
  // EAX with AES-256 (reference: independent CMAC+CTR implementation in tests/host/ra2_server.py)
  { u8 key[32], nonce[16], out[32]; for (int i = 0; i < 32; i++) key[i] = (u8)i; for (int i = 0; i < 16; i++) nonce[i] = (u8)i;
    ra2::Cipher c; c.init(key, 32); const u8 ad[2] = {0, 5}; bool ok = c.eaxSeal(nonce, ad, 2, (const u8*)"hello", 5, out);
    check("EAX AES-256 seal", ok && eqhex(out, 21, "1cf7ff70a65eaac195c169f4ebc3f69971b2bd32f1")); }
  // ARD: fixed DH vector (1024-bit... 768-bit Oakley group 1 prime, g=2) and credential blob
  const char* P = "ffffffffffffffffc90fdaa22168c234c4c6628b80dc1cd129024e088a67cc74020bbea63b139b22514a08798e3404ddef9519b3cd3a431b302b0a6df25f14374fe1356d6d51c245e485b576625e7ec6f44c42e9a63a3620ffffffffffffffff";
  const char* X = "0102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f202122232425262728292a2b2c2d2e2f303132333435363738393a3b3c3d3e3f404142434445464748494a4b4c4d4e4f505152535455565758595a5b5c5d5e5f61";
  const char* Y = "d2641d607de431ba4273fd45a978968e9ea0a0443596dfda714825565d531debd7c0950e69a106b8a4b907a6d2e718705fd66dc7f3ca3cbfcaf33afaaa02027f00daf05dae5e215cd8fcfd1a0fd82a3e3278bfa01dd4400bbff63f8432d65bc0";
  u8 p[128], x[128], y[128], pub[128], key[16]; size_t kl = hex(P, p); hex(X, x); hex(Y, y);
  bool ok = ard::dhAgreeWithPriv(2, p, y, kl, x, pub, key);
  check("ARD DH public value", ok && eqhex(pub, kl, "a4278a8423b8b90c42f20656289649bcabfcebc6d895b2ad3d5f3528fc060415fc3ebaacd579d07bad137fca3b2152c7581664abc8a80f66cdcdca7a8630421d8bc64b72ddfe9c6c2e4cf6cd4d7c3032af5b36a2221368727403be9f16e1ea58"));
  check("ARD DH shared key = MD5(shared secret)", ok && eqhex(key, 16, "d70d2b37ea1a9d1d67123b646056dc03"));
  u8 blob[128]; check("ARD credential blob AES-128-ECB", ard::sealCredentials(key, "alice", "wonderland", blob) &&
        eqhex(blob, 128, "7a98b67579566fda0038abcf3623fd92be71411c400e3b744d5662d4c20dd89bbe71411c400e3b744d5662d4c20dd89bbe71411c400e3b744d5662d4c20dd89bbef283659aa01ad836c7c2bbb4d05be6be71411c400e3b744d5662d4c20dd89bbe71411c400e3b744d5662d4c20dd89bbe71411c400e3b744d5662d4c20dd89b"));
  u8 one[128]; memset(one, 0, 128); one[kl - 1] = 1; u8 pb[128];
  check("ARD rejects degenerate peer value 1", !ard::dhAgreeWithPriv(2, p, one, kl, x, pb, key));
  // message layer: counter restarts after re-keying (RA2r second round)
  { u8 k1[16] = {1}, k2[16] = {2}; ra2::Cipher a, b; a.init(k1, 16); b.init(k1, 16); u8 m[5] = {1,2,3,4,5}, o1[23], o2[23], pl[5];
    a.seal(m, 5, o1); b.open(5, o1 + 2, pl); a.init(k2, 16); b.init(k2, 16); a.seal(m, 5, o2);
    ra2::Cipher fresh; fresh.init(k2, 16); u8 o3[23]; fresh.seal(m, 5, o3);
    check("re-key resets message counter to 0", !memcmp(o2, o3, 23) && b.open(5, o2 + 2, pl)); }
}
int main() {
  kat("233952DEE4D5ED5F9B9C6D6FF80FF478", "62EC67F9C3A4A407FCB2A8C49031A8B3", "6BFB914FD07EAE6B", "", "E037830E8389F27B025A2D6527E79D01");
  kat("91945D3F4DCBEE0BF45EF52255F095A4", "BECAF043B0A23D843194BA972C66DEBD", "FA3BFD4806EB53FA", "F7FB", "19DD5C4C9331049D0BDAB0277408F67967E5");
  // message-layer round trip with counters
  u8 key[16] = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16}; ra2::Cipher a, b; a.init(key, 16); b.init(key, 16);
  for (int i = 0; i < 3; i++) { u8 msg[5] = {'h','e','l','l',(u8)('0'+i)}, out[2+5+16], pl[5]; a.seal(msg, 5, out);
    bool ok = out[0] == 0 && out[1] == 5 && b.open(5, out + 2, pl) && !memcmp(pl, msg, 5); printf("%s message %d round trip (counter %d)\n", ok ? "PASS" : "FAIL", i, i); if (!ok) fails++; }
  moreTests();
  printf(fails ? "KAT FAILED\n" : "KAT ALL PASSED\n"); return fails ? 1 : 0;
}
