// Known-answer tests for RA4 primitives and key schedule. Vectors: tests/host/ra4_vectors.inc, produced by
// gen_ra4_vectors.py with python `cryptography`/hashlib (independent of this code); RFC 7748 / 4231 / 2202 / NIST GCM values
// are asserted inside the generator.
#include "ra4.h"
#include <stdio.h>
#include "ra4_vectors.inc"
using namespace vr; using namespace vr::ra4;
static int fails = 0, total = 0;
static Bytes H(const char* s) { Bytes b; for (; s[0] && s[1]; s += 2) { unsigned v; sscanf(s, "%2x", &v); u8 x = (u8)v; b.append(&x, 1); } return b; }
static void check(const char* name, bool ok) { total++; printf("%s %s\n", ok ? "PASS" : "FAIL", name); if (!ok) fails++; }
static bool eq(const Bytes& a, const char* hex) { Bytes e = H(hex); return a.n == e.n && !memcmp(a.p, e.p, e.n); }
static bool eqp(const u8* p, size_t n, const char* hex) { Bytes e = H(hex); return e.n == n && !memcmp(p, e.p, n); }

int main() {
  // ---- suite registry
  check("registry: 12 suites", suiteCount() == 12);
  { const u16 ids[] = {0x0001, 0x0101, 0x0202, 0x0303, 0x0b03, 0x0204, 0x0402, 0x0403, 0x0c03, 0x0602, 0x0703, 0x0f03}; bool ok = true;
    for (u16 i : ids) ok &= suiteById(i) != nullptr; check("registry: all 12 ids present", ok); }
  { const Suite* s = suiteById(0x0b03); check("0x0b03 = RA4b_256: gcm256, sha512, x448, rsa>=2048, no psk", s && s->cipher == C_GCM256 && s->hashBits == 512 && s->curve == 1 && s->rsaMinBits == 2048 && !s->psk && s->nonceBytes == 32); }
  { const Suite* s = suiteById(0x0602); check("0x0602 = RA4-PSK_128: gcm128, sha256, x25519, rsa>=1024, psk", s && s->cipher == C_GCM128 && s->hashBits == 256 && s->curve == 0 && s->rsaMinBits == 1024 && s->psk && s->nonceBytes == 16); }
  { const Suite* s = suiteById(0x0402); check("0x0402 = RA4-PSK-Only_128: psk, no rsa", s && s->psk && !s->rsa); }
  { const Suite* s = suiteById(0x0204); check("0x0204 = RA4ne_128: cipher 4, sha256", s && s->cipher == C_NE && s->hashBits == 256); }
  { const Suite* s = suiteById(0x0101); check("0x0101 SignOnly reported unsupported (not silently implemented)", s && s->status == ST_UNSUPPORTED); }
  { u16 o[16]; Str e; int n = parsePreference("RA4_256, 0x0b03x", o, 16, &e); check("pref: bad token rejected", n < 0);
    n = parsePreference("RA4_256,RA4_256", o, 16, &e); check("pref: duplicate rejected", n < 0);
    n = parsePreference("RA4b_256,0x0702", o, 16, &e); check("pref: unknown id rejected", n < 0);
    n = parsePreference("ra4b_256, 0x0303 RA4-PSK_128", o, 16, &e); check("pref: names+ids parsed in order", n == 3 && o[0] == 0x0b03 && o[1] == 0x0303 && o[2] == 0x0602);
    n = defaultPreference(o, 16); bool nonull = true; for (int i = 0; i < n; i++) nonull &= o[i] != 0x0001; check("default preference excludes Null", n > 0 && nonull); }

  // ---- primitives
  { u8 o[64]; const char* k = "Jefe"; const char* m = "what do ya want for nothing?";
    check("HMAC-SHA256 (RFC 4231 #2)", hmac(256, (const u8*)k, 4, (const u8*)m, 28, o) && eqp(o, 32, HMAC256_2));
    check("HMAC-SHA512 (RFC 4231 #2)", hmac(512, (const u8*)k, 4, (const u8*)m, 28, o) && eqp(o, 64, HMAC512_2));
    check("HMAC-SHA1 (RFC 2202 #2)", hmac(160, (const u8*)k, 4, (const u8*)m, 28, o) && eqp(o, 20, HMAC1_2)); }
  for (int bits = 128; bits <= 256; bits += 128) {
    Bytes key = H(bits == 128 ? GCM128_KEY : GCM256_KEY), iv = H(bits == 128 ? GCM128_IV : GCM256_IV), aad = H(bits == 128 ? GCM128_AAD : GCM256_AAD), pt = H(bits == 128 ? GCM128_PT : GCM256_PT);
    Bytes ct = H(bits == 128 ? GCM128_CT : GCM256_CT); Bytes o; o.resize(pt.n + 16), pt.n;
    bool s = gcmSeal(key.p, key.n, iv.p, aad.p, aad.n, pt.p, pt.n, o.p) && o.n == ct.n && !memcmp(o.p, ct.p, ct.n);
    Bytes back; back.resize(pt.n); bool op = gcmOpen(key.p, key.n, iv.p, aad.p, aad.n, ct.p, pt.n, back.p) && !memcmp(back.p, pt.p, pt.n);
    Bytes bad = ct; bad.p[3] ^= 1; bool t1 = !gcmOpen(key.p, key.n, iv.p, aad.p, aad.n, bad.p, pt.n, back.p);
    bad = ct; bad.p[ct.n - 1] ^= 1; bool t2 = !gcmOpen(key.p, key.n, iv.p, aad.p, aad.n, bad.p, pt.n, back.p);
    u8 aad2[2] = {0, 0x20}; bool t3 = !gcmOpen(key.p, key.n, iv.p, aad2, 2, ct.p, pt.n, back.p);
    char nm[64]; snprintf(nm, sizeof nm, "AES-GCM-%d seal/open vs python; tampered ct/tag/AAD rejected", bits); check(nm, s && op && t1 && t2 && t3);
  }
  { // NIST GCM test case 2 (AES-128, zero key/iv, 16 zero bytes)
    u8 key[16] = {0}, iv[12] = {0}, pt[16] = {0}, o[32]; check("AES-GCM NIST test case 2", gcmSeal(key, 16, iv, nullptr, 0, pt, 16, o) && eqp(o, 32, "0388dace60b6a392f328c2b971b2fe78ab6e47d42cec13bdf53a67b21257bddf")); }

  // ---- X25519 / X448 (RFC 7748)
  for (int c = 0; c < 2; c++) {
    Ecdh a, b; Bytes ap = H(c ? X448_A : X25519_A), bp = H(c ? X448_B : X25519_B);
    bool ok = a.generateWithPrivate(c, ap.p, ap.n) && b.generateWithPrivate(c, bp.p, bp.n);
    Bytes aw, bw; a.pubWire(&aw); b.pubWire(&bw);
    Bytes ea = H(c ? X448_APUB : X25519_APUB), eb = H(c ? X448_BPUB : X25519_BPUB);
    bool pubok = aw.n == ea.n + 1 && aw.p[0] == ea.n && !memcmp(aw.p + 1, ea.p, ea.n) && bw.p[0] == eb.n && !memcmp(bw.p + 1, eb.p, eb.n);
    size_t u; bool pe = a.setPeer(bw.p, bw.n, &u) && b.setPeer(aw.p, aw.n, &u);
    Bytes sa, sb; bool sh = a.shared(&sa) && b.shared(&sb);
    check(c ? "X448 RFC 7748 6.2 public keys + shared secret" : "X25519 RFC 7748 6.1 public keys + shared secret", ok && pubok && pe && sh && eq(sa, c ? X448_K : X25519_K) && eq(sb, c ? X448_K : X25519_K));
    Ecdh g1, g2; bool rnd = g1.generate(c) && g2.generate(c); Bytes w1, w2; g1.pubWire(&w1); g2.pubWire(&w2); size_t uu;
    Bytes s1, s2; bool r2 = g1.setPeer(w2.p, w2.n, &uu) && g2.setPeer(w1.p, w1.n, &uu) && g1.shared(&s1) && g2.shared(&s2) && s1.n == s2.n && !memcmp(s1.p, s2.p, s1.n);
    check(c ? "X448 random agreement" : "X25519 random agreement", rnd && r2);
    Bytes bl = bw; bl.p[0] = (u8)(bl.p[0] - 1); Ecdh t; t.generate(c); check("ECDH: wrong length byte rejected", !t.setPeer(bl.p, bl.n - 1, &uu));
    Bytes z; z.append(bw.p, 1); for (size_t i = 0; i < bw.n - 1; i++) { u8 zz = 0; z.append(&zz, 1); }
    Ecdh t2; t2.generate(c); bool zp = t2.setPeer(z.p, z.n, &uu); Bytes zs; check("ECDH: all-zero peer value gives no secret", !zp || !t2.shared(&zs));
  }

  // ---- KDF / key schedule vs python
  { Bytes S = H(NS_S), C = H(NS_C), secret = H(NS_SECRET), T = H(NS_T);
    struct { u16 id; const char* M; const char* SID; const char* C2S; const char* S2C; const char* C2S1; const char* DC; const char* DS; } v[2] = {
      {0x0202, S0202_MASTER, S0202_SID, S0202_KM_C2S, S0202_KM_S2C, S0202_KM_C2S_CTR1, S0202_DIG_FROM_CLIENT, S0202_DIG_FROM_SERVER},
      {0x0303, S0303_MASTER, S0303_SID, S0303_KM_C2S, S0303_KM_S2C, S0303_KM_C2S_CTR1, S0303_DIG_FROM_CLIENT, S0303_DIG_FROM_SERVER}};
    for (auto& x : v) {
      const Suite* s = suiteById(x.id); char nm[96]; Bytes hello, kex; hello.append(T.p, 40); kex.append(T.p + 40, T.n - 40);
      Core c, sv; c.init(s, true, C.p, S.p, hello); sv.init(s, false, S.p, C.p, hello);
      bool e = c.establish(secret, kex) && sv.establish(secret, kex);
      snprintf(nm, sizeof nm, "0x%04x MasterSecret/SessionId vs python (both roles)", x.id);
      check(nm, e && eq(c.masterOut, x.M) && eq(sv.masterOut, x.M) && eq(c.sessionId, x.SID) && eq(sv.sessionId, x.SID));
      size_t kl = s->keyBits / 8 + 12; u8 b[80];
      snprintf(nm, sizeof nm, "0x%04x keying material client->server (RfbClientKeyingMaterial)", x.id);
      check(nm, c.keyingMaterial(true, kl, b) && eqp(b, kl, x.C2S) && sv.keyingMaterial(false, kl, b) && eqp(b, kl, x.C2S));
      snprintf(nm, sizeof nm, "0x%04x keying material server->client (RfbServerKeyingMaterial)", x.id);
      check(nm, sv.keyingMaterial(true, kl, b) && eqp(b, kl, x.S2C) && c.keyingMaterial(false, kl, b) && eqp(b, kl, x.S2C));
      c.ctrOut = 1; snprintf(nm, sizeof nm, "0x%04x key refresh: counter 1 derives different keys", x.id);
      check(nm, c.keyingMaterial(true, kl, b) && eqp(b, kl, x.C2S1)); c.ctrOut = 0;
      u8 d[32]; snprintf(nm, sizeof nm, "0x%04x digests (RfbServerDigest from client / RfbClientDigest from server)", x.id);
      check(nm, c.digest(true, d) && eqp(d, 32, x.DC) && sv.verifyDigest(d) && sv.digest(true, d) && eqp(d, 32, x.DS) && c.verifyDigest(d));
      u8 bad[32]; memcpy(bad, d, 32); bad[5] ^= 1; check("digest mismatch detected", !c.verifyDigest(bad));
      // rekey: nonces random; expected = KDF(old master, S'|C') using the python-verified KDF
      Bytes oldM = c.masterOut; u8 cn[32], sn[32]; bool r = c.beginRekey(cn) && sv.onRekeyRequest(cn, sn) && c.onRekeyResponse(sn) && sv.onRekeyRequest2();
      u8 info[64]; memcpy(info, sn, 32); memcpy(info + 32, cn, 32); u8 nm2[48]; kdf(s->hashBits, (const u8*)"RfbMasterSecret", 15, oldM.p, oldM.n, info, 64, 48, nm2);
      snprintf(nm, sizeof nm, "0x%04x 3-message rekey: both directions agree and equal KDF(oldMaster, S'|C')", x.id);
      check(nm, r && c.masterOut.n == 48 && !memcmp(c.masterOut.p, nm2, 48) && !memcmp(c.masterIn.p, nm2, 48) && !memcmp(sv.masterOut.p, nm2, 48) && !memcmp(sv.masterIn.p, nm2, 48) && c.ctrOut == 0 && c.ctrIn == 0);
    }
  }

  // ---- records
  { Bytes km = H(S0202_KM_C2S); GcmRecord g; Bytes o; bool ok = g.init(km.p, 16, km.p + 16) ; (void)ok;
    Bytes key = H(REC_KEY), iv = H(REC_IV); GcmRecord w; w.init(key.p, 16, iv.p);
    w.seal((const u8*)"first record", 12, &o); w.seal((const u8*)"second", 6, &o);
    check("GCM record stream (LE IV increment with carry) vs python", eq(o, REC_STREAM));
    GcmRecord rd; rd.init(key.p, 16, iv.p); u8 pt[32]; size_t off = 0; bool a = true;
    for (int i = 0; i < 2; i++) { size_t n = ((size_t)o.p[off] << 8) | o.p[off + 1]; a &= rd.open(o.p + off, o.p + off + 2, n, o.p + off + 2 + n, pt); off += 2 + n + 16; }
    check("GCM record open", a);
    GcmRecord rd2; rd2.init(key.p, 16, iv.p); Bytes t = o; t.p[3] ^= 0x40; size_t n = ((size_t)t.p[0] << 8) | t.p[1];
    check("GCM record: flipped ciphertext bit rejected", !rd2.open(t.p, t.p + 2, n, t.p + 2 + n, pt));
    GcmRecord rd3; rd3.init(key.p, 16, iv.p); t = o; t.p[1] ^= 1; n = ((size_t)t.p[0] << 8) | t.p[1];
    check("GCM record: modified length header (AAD) rejected", !rd3.open(t.p, t.p + 2, 12, o.p + 2 + 12, pt));
    GcmRecord rd4; rd4.init(key.p, 16, iv.p); check("GCM record: replay/out-of-order rejected", !rd4.open(o.p + 2 + 12 + 16, o.p + 2 + 12 + 16 + 2, 6, o.p + 2 + 12 + 16 + 2 + 6, pt));
    Bytes nk = H(NE_KM); HmacRecord h; h.init(nk.p, nk.p + 64); Bytes ho; h.seal((const u8*)"hello ne", 8, &ho);
    check("NULL-HMAC-SHA1 record vs python", eq(ho, NE_REC1));
    HmacRecord hr; hr.init(nk.p, nk.p + 64); check("NULL-HMAC-SHA1 record verifies", hr.open(ho.p, ho.p + 2, 8, ho.p + 10));
    HmacRecord hr2; hr2.init(nk.p, nk.p + 64); ho.p[4] ^= 1; check("NULL-HMAC-SHA1 tampered record rejected", !hr2.open(ho.p, ho.p + 2, 8, ho.p + 10)); }

  // ---- RSA-OAEP (python-produced ciphertexts, private key imported only for the test)
  { Bytes n = H(RSA_N), e = H(RSA_E), d = H(RSA_D), p = H(RSA_P), q = H(RSA_Q); RsaKey k;
    bool imp = mbedtls_rsa_import_raw(&k.rsa, n.p, n.n, p.p, p.n, q.p, q.n, d.p, d.n, e.p, e.n) == 0 && mbedtls_rsa_complete(&k.rsa) == 0; k.has = true; k.bits = 2048;
    check("RSA test key imported", imp);
    Bytes o; check("RSA-OAEP-SHA256 decrypts python ciphertext", k.decrypt(256, H(OAEP256_CT).p, 256, &o) && eq(o, OAEP256_PT));
    check("RSA-OAEP-SHA512 decrypts python ciphertext", k.decrypt(512, H(OAEP512_CT).p, 256, &o) && eq(o, OAEP512_PT));
    check("RSA-OAEP: hash mismatch (SHA-512 data as SHA-256) rejected", !k.decrypt(256, H(OAEP512_CT).p, 256, &o));
    Bytes ct; check("RSA-OAEP encrypt/decrypt round trip", k.encrypt(256, (const u8*)"0123456789abcdef", 16, &ct) && ct.n == 256 && k.decrypt(256, ct.p, ct.n, &o) && o.n == 16 && !memcmp(o.p, "0123456789abcdef", 16));
    Bytes w; k.wire(&w); RsaKey k2; size_t used; check("RSA wire form round trip (BE32 bits | N | BE16 elen | e)", k2.parse(w.p, w.n, &used) && used == w.n && k2.bits == 2048 && w.n == 4 + 256 + 2 + 3);
    Bytes sh = w; sh.p[3] = 0; sh.p[2] = 0x07; sh.p[1] = 0; check("RSA parse: declared bits != modulus rejected", !k2.parse(sh.p, sh.n, &used));
    Bytes sm; u8 small[4] = {0, 0, 2, 0}; sm.append(small, 4); check("RSA parse: 512-bit key refused (min 1024)", !k2.parse(sm.p, sm.n, &used));
    check("RSA parse: truncated key refused", !k2.parse(w.p, w.n - 1, &used));
    u8 emp[4] = {0xff, 0xff, 0xff, 0xff}; RsaKey k3; check("RSA parse: empty marker accepted, no key", k3.parse(emp, 4, &used) && !k3.has && used == 4); }

  printf("\n%d checks, %d failed\n", total, fails);
  return fails ? 1 : 0;
}
