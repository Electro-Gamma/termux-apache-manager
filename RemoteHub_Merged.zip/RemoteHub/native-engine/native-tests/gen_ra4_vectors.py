#!/usr/bin/env python3
"""Generates ra4_vectors.inc: known-answer vectors for the RA4 primitives and key schedule.
Everything here is computed with python `cryptography` / hashlib / hmac, independently of the C++ code.
RFC 7748 and RFC 4231 / 2202 vectors are the published ones (asserted below)."""
import hmac, hashlib, struct, sys
from cryptography.hazmat.primitives.asymmetric import x25519, x448, rsa, padding
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

out = []
def emit(n, b): out.append('static const char* %s = "%s";' % (n, b.hex() if isinstance(b, (bytes, bytearray)) else b))
H = bytes.fromhex

# ---- RFC 7748 section 6.1 / 6.2 (published values, asserted against the library)
a = H("77076d0a7318a57d3c16c17251b26645df4c2f87ebc0992ab177fba51db92c2a")
b = H("5dab087e624a8a4b79e17f8b83800ee66f3bb1292618b6fd1c2f8b27ff88e0eb")
A = x25519.X25519PrivateKey.from_private_bytes(a); B = x25519.X25519PrivateKey.from_private_bytes(b)
assert A.public_key().public_bytes_raw().hex() == "8520f0098930a754748b7ddcb43ef75a0dbf3a0d26381af4eba4a98eaa9b4e6a"
k = A.exchange(B.public_key())
assert k.hex() == "4a5d9d5ba4ce2de1728e3bf480350f25e07e21c947d19e3376f09b3c1e161742"
emit("X25519_A", a); emit("X25519_B", b); emit("X25519_APUB", A.public_key().public_bytes_raw()); emit("X25519_BPUB", B.public_key().public_bytes_raw()); emit("X25519_K", k)
a4 = H("9a8f4925d1519f5775cf46b04b5800d4ee9ee8bae8bc5565d498c28dd9c9baf574a9419744897391006382a6f127ab1d9ac2d8c0a598726b")
b4 = H("1c306a7ac2a0e2e0990b294470cba339e6453772b075811d8fad0d1d6927c120bb5ee8972b0d3e21374c9c921b09d1b0366f10b65173992d")
A4 = x448.X448PrivateKey.from_private_bytes(a4); B4 = x448.X448PrivateKey.from_private_bytes(b4)
k4 = A4.exchange(B4.public_key())
assert k4.hex() == "07fff4181ac6cc95ec1c16a94a0f74d12da232ce40a77552281d282bb60c0b56fd2464c335543936521c24403085d59a449a5037514a879d"
emit("X448_A", a4); emit("X448_B", b4); emit("X448_APUB", A4.public_key().public_bytes_raw()); emit("X448_BPUB", B4.public_key().public_bytes_raw()); emit("X448_K", k4)

# ---- HMAC (RFC 4231 case 2, RFC 2202 case 2)
assert hmac.new(b"Jefe", b"what do ya want for nothing?", hashlib.sha256).hexdigest() == "5bdcc146bf60754e6a042426089575c75a003f089d2739839dec58b964ec3843"
assert hmac.new(b"Jefe", b"what do ya want for nothing?", hashlib.sha1).hexdigest() == "effcdf6ae5eb2fa2d27416d5f184df9c259a7c79"
emit("HMAC256_2", hmac.new(b"Jefe", b"what do ya want for nothing?", hashlib.sha256).digest())
emit("HMAC512_2", hmac.new(b"Jefe", b"what do ya want for nothing?", hashlib.sha512).digest())
emit("HMAC1_2", hmac.new(b"Jefe", b"what do ya want for nothing?", hashlib.sha1).digest())

# ---- AES-GCM: NIST GCM spec test case 2 (AES-128, zero key) asserted; AES-256 random-ish
g = AESGCM(bytes(16)).encrypt(bytes(12), bytes(16), b"")
assert g[:16].hex() == "0388dace60b6a392f328c2b971b2fe78" and g[16:].hex() == "ab6e47d42cec13bdf53a67b21257bddf"
for bits in (128, 256):
    key = bytes(range(bits // 8)); iv = bytes(range(0xa0, 0xac)); aad = b"\x00\x1f"; pt = bytes(range(31))
    emit("GCM%d_KEY" % bits, key); emit("GCM%d_IV" % bits, iv); emit("GCM%d_AAD" % bits, aad); emit("GCM%d_PT" % bits, pt)
    emit("GCM%d_CT" % bits, AESGCM(key).encrypt(iv, pt, aad))

# ---- KDF (python implementation of the recovered construction)
def kdf(hf, key, data, info, n):
    prk = hmac.new(key, data, hf).digest(); t = b""; o = b""; i = 1
    while len(o) < n:
        t = hmac.new(prk, t + info + bytes([i]), hf).digest(); o += t; i += 1
    return o[:n]
S = bytes((i * 7 + 1) & 255 for i in range(32)); C = bytes((i * 11 + 3) & 255 for i in range(32))
secret = bytes((i * 5 + 9) & 255 for i in range(70)); T = bytes((i * 3) & 255 for i in range(100))
emit("NS_S", S); emit("NS_C", C); emit("NS_SECRET", secret); emit("NS_T", T)
for sid, hf, kl in ((0x0202, hashlib.sha256, 16), (0x0303, hashlib.sha512, 32)):
    m = kdf(hf, b"RfbMasterSecret", secret, S + C, 48); s = kdf(hf, b"RfbSessionId", m, S + C, 32)
    p = "S%04x_" % sid
    emit(p + "MASTER", m); emit(p + "SID", s)
    emit(p + "KM_C2S", kdf(hf, b"RfbServerKeyingMaterial" + struct.pack(">I", 0), m, S + C + s, kl + 12))   # labels name the RECEIVING role (like the digests): client->server uses "Server..."
    emit(p + "KM_S2C", kdf(hf, b"RfbClientKeyingMaterial" + struct.pack(">I", 0), m, S + C + s, kl + 12))
    emit(p + "KM_C2S_CTR1", kdf(hf, b"RfbServerKeyingMaterial" + struct.pack(">I", 1), m, S + C + s, kl + 12))
    emit(p + "DIG_FROM_CLIENT", kdf(hf, b"RfbServerDigest" + struct.pack(">I", 0), m, S + C + T, 32))
    emit(p + "DIG_FROM_SERVER", kdf(hf, b"RfbClientDigest" + struct.pack(">I", 0), m, S + C + T, 32))
    m2 = kdf(hf, b"RfbMasterSecret", m, S[::-1] + C[::-1], 48)       # rekey: old master as the secret, new nonces
    emit(p + "REKEY_MASTER", m2)
# NULL-HMAC key material: 0x50 bytes from the same KDF
m = kdf(hashlib.sha256, b"RfbMasterSecret", secret, S + C, 48); s = kdf(hashlib.sha256, b"RfbSessionId", m, S + C, 32)
km = kdf(hashlib.sha256, b"RfbServerKeyingMaterial" + struct.pack(">I", 0), m, S + C + s, 0x50)
emit("NE_KM", km)
rec = b"hello ne"; ctr = bytearray(km[64:80])
frame = struct.pack(">H", len(rec)) + rec
emit("NE_REC1", frame + hmac.new(km[:64], bytes(ctr) + frame, hashlib.sha1).digest())
# GCM record stream: two records, IV incremented little-endian between them
key, iv = km[:16], bytearray(b"\xff\xff" + bytes(10))
r = b""
for pt in (b"first record", b"second"):
    h = struct.pack(">H", len(pt)); r += h + AESGCM(key).encrypt(bytes(iv), pt, h)
    i = 0
    while True:
        iv[i] = (iv[i] + 1) & 255
        if iv[i]: break
        i += 1
emit("REC_KEY", key); emit("REC_IV", b"\xff\xff" + bytes(10)); emit("REC_STREAM", r)

# ---- RSA-OAEP (SHA-256 and SHA-512, MGF1 same hash, empty label)
priv = rsa.generate_private_key(65537, 2048); pn = priv.private_numbers(); pub = pn.public_numbers
emit("RSA_N", pub.n.to_bytes(256, "big")); emit("RSA_E", pub.e.to_bytes(3, "big"))
emit("RSA_D", pn.d.to_bytes(256, "big")); emit("RSA_P", pn.p.to_bytes(128, "big")); emit("RSA_Q", pn.q.to_bytes(128, "big"))
for bits, hf in ((256, hashes.SHA256), (512, hashes.SHA512)):
    pt = bytes((i * 13 + bits) & 255 for i in range(16 if bits == 256 else 32))
    ct = priv.public_key().encrypt(pt, padding.OAEP(padding.MGF1(hf()), hf(), None))
    emit("OAEP%d_PT" % bits, pt); emit("OAEP%d_CT" % bits, ct)

open(sys.argv[1] if len(sys.argv) > 1 else "ra4_vectors.inc", "w").write("// generated by gen_ra4_vectors.py -- do not edit\n" + "\n".join(out) + "\n")
