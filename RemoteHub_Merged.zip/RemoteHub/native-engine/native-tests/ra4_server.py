#!/usr/bin/env python3
"""Independent RA4 mock server for the RFB v5 cipher-suite layer.

Written separately from the C++ client (python `cryptography` + hashlib/hmac, no shared code), from the message formats in
docs/RA4_RECOVERY.md.  IMPORTANT: it shares the *interpretation* of the binary evidence with the client ([TEST] only).
It proves the client matches the recovered format and handles errors; it does NOT prove interoperability with a real
RealVNC server.  Cryptographic primitives are checked against external vectors separately (ra4_kat.cpp).

Usage: ra4_server.py --port P [--suite 0x0303,...] [--flags a,b;c] [--psk-my HEX --psk-peer HEX] [--hash-file F] [--rsa-bits N]
Flags (per connection; ';' separates connections, last one repeats): wrong-psk, tamper-tag, tamper-ct, bad-digest, bad-oaep,
bad-nonce-len, short-rsa, choose:<id>, truncate, garbage-type, replay, zero-ecdh, bad-rsa-bits, none.
"""
import argparse, hashlib, hmac, os, socket, struct, sys, threading
from cryptography.hazmat.primitives.asymmetric import x25519, x448, rsa, padding
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

SUITES = {  # id: (cipher, hashbits, psk, rsa, rsa_min, curve, nonce_bytes)   cipher: 1 null, 2 gcm128, 3 gcm256, 4 ne
    0x0001: (1, 0, 0, 0, 0, None, 0),
    0x0202: (2, 256, 0, 1, 1024, 0, 16), 0x0303: (3, 512, 0, 1, 2048, 0, 32), 0x0b03: (3, 512, 0, 1, 2048, 1, 32),
    0x0204: (4, 256, 0, 1, 1024, 0, 16),
    0x0402: (2, 256, 1, 0, 0, 0, 16), 0x0403: (3, 512, 1, 0, 0, 0, 32), 0x0c03: (3, 512, 1, 0, 0, 1, 32),
    0x0602: (2, 256, 1, 1, 1024, 0, 16), 0x0703: (3, 512, 1, 1, 2048, 0, 32), 0x0f03: (3, 512, 1, 1, 2048, 1, 32),
}
HF = {256: hashlib.sha256, 512: hashlib.sha512}
CHF = {256: hashes.SHA256, 512: hashes.SHA512}

class Closed(Exception): pass
class Fatal(Exception): pass

def kdf(hf, key, data, info, n):
    prk = hmac.new(key, data, hf).digest(); t = b""; o = b""; i = 1
    while len(o) < n:
        t = hmac.new(prk, t + info + bytes([i]), hf).digest(); o += t; i += 1
    return o[:n]

def inc_le(b):
    b = bytearray(b)
    for i in range(len(b)):
        b[i] = (b[i] + 1) & 255
        if b[i]: break
    return bytes(b)

class Dir:  # one direction's record layer
    def __init__(self): self.mode = "plain"
    def set_gcm(self, key, iv): self.mode, self.key, self.iv = "gcm", key, iv
    def set_hmac(self, km): self.mode, self.hkey, self.ctr = "hmac", km[:64], km[64:80]

class Conn:
    def __init__(self, sock, flags, a, rsa_key):
        self.s, self.f, self.a, self.rsa = sock, flags, a, rsa_key
        self.buf = b""; self.outd, self.ind = Dir(), Dir(); self.plain_in = b""
        self.sent_enc = 0; self.last_rec = None
    # ---- raw IO
    def rd(self, n):
        while len(self.buf) < n:
            c = self.s.recv(4096)
            if not c: raise Closed()
            self.buf += c
        r, self.buf = self.buf[:n], self.buf[n:]; return r
    def wr(self, b): self.s.sendall(b)
    # ---- records
    def seal(self, pt):
        d = self.outd
        if d.mode == "plain": return pt
        out = b""
        for off in range(0, max(len(pt), 1), 0x2000):
            c = pt[off:off + 0x2000]; h = struct.pack(">H", len(c))
            if d.mode == "gcm":
                rec = h + AESGCM(d.key).encrypt(d.iv, c, h); d.iv = inc_le(d.iv)
            else:
                rec = h + c + hmac.new(d.hkey, d.ctr + h + c, hashlib.sha1).digest(); d.ctr = inc_le(d.ctr)
            if self.sent_enc == 0:
                if "tamper-tag" in self.f: rec = rec[:-1] + bytes([rec[-1] ^ 1])
                if "tamper-ct" in self.f: rec = rec[:2] + bytes([rec[2] ^ 0x80]) + rec[3:]
            self.sent_enc += 1; self.last_rec = rec; out += rec
        return out
    def send(self, pt):
        self.wr(self.seal(pt))
        if "replay" in self.f and self.sent_enc == 2 and self.outd.mode != "plain": self.wr(self.last_rec)
    def recv_plain_record(self):
        """returns the plaintext of one record (or, in the clear phase, None: caller reads raw)"""
        d = self.ind
        h = self.rd(2); n = struct.unpack(">H", h)[0]
        if d.mode == "gcm":
            body = self.rd(n + 16)
            try: pt = AESGCM(d.key).decrypt(d.iv, body, h)
            except Exception: raise Fatal("AES authentication failure")
            d.iv = inc_le(d.iv); return pt
        body = self.rd(n + 20); pt, mac = body[:n], body[n:]
        if not hmac.compare_digest(mac, hmac.new(d.hkey, d.ctr + h + pt, hashlib.sha1).digest()): raise Fatal("HMAC authentication failure")
        d.ctr = inc_le(d.ctr); return pt

class Session:
    """Server role of the RA4 key schedule, written from the spec in RA4_RECOVERY.md."""
    def __init__(self, c, sid, suite, S, C, transcript):
        self.c, self.id = c, sid
        self.cipher, self.hb, self.psk, self.rsa, self.rmin, self.curve, self.nb = suite
        self.hf = HF.get(self.hb); self.nA, self.nB, self.nC = S, C, S; self.T = transcript
        self.ctr_in = self.ctr_out = 0; self.phase_in = self.phase_out = 1
        self.rekey = 0; self.pending_in = False
    def info(self, out, sid=False):
        S = self.nA if out else self.nC
        return S + self.nB + (self.sid if sid else b"")
    def establish(self, secret, kexT):
        self.m_out = self.m_in = kdf(self.hf, b"RfbMasterSecret", secret, self.info(True), 48)
        self.sid = kdf(self.hf, b"RfbSessionId", self.m_out, self.info(True), 32); self.T += kexT
    def digest(self, send):
        label = b"RfbClientDigest" if send else b"RfbServerDigest"   # server sends the client-named digest
        ctr = self.ctr_out if send else self.ctr_in; m = self.m_out if send else self.m_in
        return kdf(self.hf, label + struct.pack(">I", ctr), m, self.info(send) + self.T, 32)
    def km(self, out, n):
        label = b"RfbClientKeyingMaterial" if out else b"RfbServerKeyingMaterial"
        ctr = self.ctr_out if out else self.ctr_in; m = self.m_out if out else self.m_in
        return kdf(self.hf, label + struct.pack(">I", ctr), m, self.info(out, True), n)
    def install(self, out):
        d = self.c.outd if out else self.c.ind; ph = self.phase_out if out else self.phase_in
        if ph == 2: d.set_hmac(self.km(out, 0x50))
        else:
            kl = 16 if self.cipher in (2, 4) else 32; k = self.km(out, kl + 12); d.set_gcm(k[:kl], k[kl:])
    def send_digest(self):
        d = self.digest(True)
        if "bad-digest" in self.c.f: d = bytes([d[0] ^ 1]) + d[1:]
        self.c.send(b"\x00\x16\x02" + d)

def hello_parse(c):
    head = c.rd(2 + 32 + 2); typ = struct.unpack(">H", head[:2])[0]
    if typ != 0x15: raise Fatal("bad hello type")
    rnd = head[2:34]; cnt = struct.unpack(">H", head[34:36])[0]
    suites = c.rd(2 * cnt); flag = c.rd(1)
    raw_auth = b""; ac = c.rd(2); raw_auth += ac
    for _ in range(struct.unpack(">H", ac)[0]):
        l = c.rd(1); raw_auth += l; raw_auth += c.rd(l[0]); l2 = c.rd(2); raw_auth += l2
        raw_auth += c.rd(struct.unpack(">H", l2)[0]); v = c.rd(2); raw_auth += v; raw_auth += c.rd(2 * struct.unpack(">H", v)[0])
    return rnd, [struct.unpack(">H", suites[i:i + 2])[0] for i in range(0, 2 * cnt, 2)], head[34:36] + suites, flag, raw_auth

def rsa_wire(key, bits_override=None):
    n = key.public_key().public_numbers(); bits = n.n.bit_length(); k = (bits + 7) // 8
    e = n.e.to_bytes((n.e.bit_length() + 7) // 8, "big")
    return struct.pack(">I", bits_override or bits) + n.n.to_bytes(k, "big") + struct.pack(">H", len(e)) + e

def rsa_pub_from_wire(w):
    bits = struct.unpack(">I", w[:4])[0]; k = (bits + 7) // 8
    n = int.from_bytes(w[4:4 + k], "big"); el = struct.unpack(">H", w[4 + k:6 + k])[0]; e = int.from_bytes(w[6 + k:6 + k + el], "big")
    return rsa.RSAPublicNumbers(e, n).public_key(), 6 + k + el

def rsa_identity_hash(key):
    n = key.public_key().public_numbers(); bits = n.n.bit_length(); k = (bits + 7) // 8
    return hashlib.sha256(struct.pack(">I", bits) + n.n.to_bytes(k, "big") + n.e.to_bytes(k, "big")).digest()

def handshake(c, a):
    if a.rfb:                                                   # RFB greeting: server announces v5, client must answer the same version
        c.wr(b"RFB 005.000\n"); v = c.rd(12)
        if v != b"RFB 005.000\n": raise Fatal("client answered RFB version %r" % v)
        print("VERSION-OK", flush=True)
    rnd, offered, suite_vec, flag, auth = hello_parse(c)
    supported = [s for s in a.suites if s in offered]
    choose = next((int(f.split(":")[1], 16) for f in c.f if f.startswith("choose:")), None)
    if choose is None:
        if not supported: raise Fatal("no common suite")
        choose = supported[0]
    sid = choose; suite = SUITES.get(sid)
    S = os.urandom(32)
    c.wr(b"\x00\x15" + S + struct.pack(">H", sid))
    T = struct.pack(">II", 5, 0) + suite_vec + flag + auth + struct.pack(">II", 0, 0) + struct.pack(">H", sid)
    if suite is None: raise Fatal("server chose an unknown suite")
    s = Session(c, sid, suite, S, rnd, T)
    if s.cipher == 1: return s                                   # Null: no key exchange, plaintext
    # ---- key exchange message 1
    if s.curve == 0: priv = x25519.X25519PrivateKey.generate(); elen = 32; Pub = x25519.X25519PublicKey
    else: priv = x448.X448PrivateKey.generate(); elen = 56; Pub = x448.X448PublicKey
    pub = priv.public_key().public_bytes_raw()
    if "zero-ecdh" in c.f: pub = bytes(elen)
    ew = bytes([elen]) + pub
    key = c.rsa
    rw = rsa_wire(key) if s.rsa else struct.pack(">I", 0xffffffff)
    if "short-rsa" in c.f and s.rsa: rw = rsa_wire(c.rsa_small)
    m1 = b"\x00\x17" + ew + rw
    if "truncate" in c.f: c.wr(m1[:len(m1) // 2]); raise Closed()
    if "garbage-type" in c.f: m1 = b"\x00\x99" + m1[2:]
    c.wr(m1)
    # ---- client message 1
    h = c.rd(3)
    if h[:2] != b"\x00\x17" or h[2] != elen: raise Fatal("bad client kex msg1")
    cpub = c.rd(elen); cew = bytes([elen]) + cpub
    head = c.rd(4); bits = struct.unpack(">I", head)[0]
    if bits == 0xffffffff:
        crw = head
        if s.rsa: raise Fatal("client sent no RSA key")
    else:
        if not s.rsa: raise Fatal("unexpected client RSA key")
        k = (bits + 7) // 8; body = c.rd(k + 2); el = struct.unpack(">H", body[k:])[0]; body += c.rd(el); crw = head + body
        if bits < s.rmin: raise Fatal("client RSA key too small")
    shared = priv.exchange(Pub.from_public_bytes(cpub))
    secret = struct.pack(">H", len(shared)) + shared
    if s.rsa:
        cpubkey, _ = rsa_pub_from_wire(crw)
        Rs = os.urandom(s.nb + (1 if "bad-nonce-len" in c.f else 0))
        ct = cpubkey.encrypt(Rs, padding.OAEP(padding.MGF1(CHF[s.hb]()), CHF[s.hb](), None))
        if "bad-oaep" in c.f: ct = ct[:5] + bytes([ct[5] ^ 1]) + ct[6:]
        c.wr(b"\x00\x17" + struct.pack(">H", len(ct)) + ct)
        h = c.rd(4)
        if h[:2] != b"\x00\x17": raise Fatal("bad client kex msg2")
        cl = struct.unpack(">H", h[2:])[0]; cct = c.rd(cl)
        Rc = c.rsa.decrypt(cct, padding.OAEP(padding.MGF1(CHF[s.hb]()), CHF[s.hb](), None))
        if len(Rc) != s.nb: raise Fatal("Remote nonce size incorrect")
        secret += Rs + Rc
    else: secret += bytes(2 * s.nb)
    if s.psk:
        pm, pp = a.psk_my, a.psk_peer
        if "wrong-psk" in c.f: pm = bytes(b ^ 0x55 for b in pm)
        secret += struct.pack(">H", len(pm)) + pm + struct.pack(">H", len(pp)) + pp
    kexT = (ew + cew + rw + crw) if s.rsa else b""
    s.establish(secret, kexT)
    # digest in the clear, then outgoing switches to the new keys; then verify the client's digest and switch incoming
    s.send_digest(); s.install(True)
    h = c.rd(3)
    if h != b"\x00\x16\x02": raise Fatal("digest message required")
    d = c.rd(32)
    if not hmac.compare_digest(d, s.digest(False)): raise Fatal("security failure (digest mismatch)")
    s.install(False)
    return s

def new_nonce(): return os.urandom(32)

def do_security(s, p):
    """process one security message (bytes starting with 0016); returns nothing; replies via s.c.send"""
    sub = p[2]; c = s.c; s.events = getattr(s, "events", 0) + 1
    if sub == 2:
        if not s.pending_in: raise Fatal("unexpected digest")
        if not hmac.compare_digest(p[3:35], s.digest(False)): raise Fatal("security failure (digest mismatch)")
        s.install(False); s.pending_in = False; return
    if sub == 1:
        v = p[3]
        if v == s.phase_in: pass
        elif v == 2 and s.cipher == 4 and s.phase_in == 1: s.phase_in = 2
        else: raise Fatal("invalid encryption change")
        s.ctr_in += 1; s.pending_in = True; return
    if sub == 0:
        has, resp = p[3], p[4]; n = p[5:37] if has else b""
        if has and not resp and s.rekey == 0:                      # peer's request 1/2: we are the responder
            s.nA = new_nonce(); s.nB = n
            s.m_out = kdf(s.hf, b"RfbMasterSecret", s.m_out, s.nA + s.nB, 48); s.ctr_out = 0
            c.send(b"\x00\x16\x00\x01\x01" + s.nA); s.send_digest(); s.install(True); s.rekey = 2
        elif has and resp and s.rekey == 1:                        # response to our request: we are the initiator
            s.nB = n; s.nC = s.nA
            s.m_out = kdf(s.hf, b"RfbMasterSecret", s.m_out, s.nA + s.nB, 48); s.ctr_out = 0
            s.m_in = kdf(s.hf, b"RfbMasterSecret", s.m_in, s.nC + s.nB, 48); s.ctr_in = 0
            c.send(b"\x00\x16\x00\x00\x01"); s.send_digest(); s.install(True); s.rekey = 0; s.pending_in = True
        elif not has and resp and s.rekey == 2:                    # request 2/2
            s.nC = s.nA; s.m_in = kdf(s.hf, b"RfbMasterSecret", s.m_in, s.nC + s.nB, 48); s.ctr_in = 0
            s.rekey = 0; s.pending_in = True
        else: raise Fatal("bad key exchange sequence")
        return
    raise Fatal("invalid subtype")

def next_event(s):
    """returns app bytes, or None after handling a security message"""
    c = s.c
    if s.ind_mode_plain(): pass
    pt = c.recv_plain_record()
    if pt[:2] == b"\x00\x16": do_security(s, pt); return None
    return pt
Session.ind_mode_plain = lambda self: self.c.ind.mode == "plain"

def serve_session(s):
    c = s.c
    if s.cipher != 1 and c.a.post:                                # session-test mode: actions, then a v5 application message
        for act in c.a.post.split(","):
            if act == "srv-rekey":
                s.nA = new_nonce(); s.rekey = 1; c.send(b"\x00\x16\x00\x01\x00" + s.nA)
                while s.rekey or s.pending_in:
                    if next_event(s) is not None: raise Fatal("app data during rekey")
                print("POST rekey-ok", flush=True)
            elif act == "srv-refresh":
                s.ctr_out += 1; c.send(b"\x00\x16\x01" + bytes([s.phase_out])); s.send_digest(); s.install(True); print("POST refresh-sent", flush=True)
            elif act == "client-event":                           # wait until the client has completed a rekey / refresh it started
                s.events = 0
                while s.events == 0 or s.rekey or s.pending_in:
                    if next_event(s) is not None: raise Fatal("app data while waiting for a client event")
                print("POST client-event-ok", flush=True)
            elif act == "app":
                c.send(b"\x00\x10" + b"v5-init-placeholder")
        try:
            while True: next_event(s)
        except Closed: print("POST session-end", flush=True); return
    if s.cipher == 1:                                              # Null suite: plaintext echo
        if c.a.post: c.wr(b"\x00\x10" + b"v5-init-placeholder")
        while True:
            d = c.s.recv(4096)
            if not d: return
            c.wr(b"PONG:" + d[5:] if d.startswith(b"PING:") else d)
    while True:
        pt = next_event(s)
        if pt is None: continue
        if pt.startswith(b"PING:"): c.send(b"PONG:" + pt[5:])
        elif pt == b"SERVER_REKEY":
            s.nA = new_nonce(); s.rekey = 1; c.send(b"\x00\x16\x00\x01\x00" + s.nA)
            while s.rekey or s.pending_in:
                r = next_event(s)
                if r is not None: raise Fatal("app data during rekey")
            c.send(b"DONE:rekey")
        elif pt == b"SERVER_REFRESH":
            s.ctr_out += 1; c.send(b"\x00\x16\x01" + bytes([s.phase_out])); s.send_digest(); s.install(True)
            c.send(b"DONE:refresh")
        elif pt == b"BIGDATA": c.send(bytes((i * 7) & 255 for i in range(20000)))
        elif pt == b"CLOSE": return
        else: c.send(b"ECHO:" + pt)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, required=True); ap.add_argument("--suite", default="0x0b03,0x0303,0x0703,0x0f03,0x0403,0x0c03,0x0202,0x0602,0x0402,0x0204,0x0001")
    ap.add_argument("--flags", default="none"); ap.add_argument("--psk-my", default=""); ap.add_argument("--psk-peer", default="")
    ap.add_argument("--hash-file"); ap.add_argument("--rsa-bits", type=int, default=2048); ap.add_argument("--max-conns", type=int, default=1); ap.add_argument("--rfb", action="store_true"); ap.add_argument("--post", default="")
    a = ap.parse_args(); a.suites = [int(x, 16) for x in a.suite.split(",")]
    a.psk_my, a.psk_peer = bytes.fromhex(a.psk_my), bytes.fromhex(a.psk_peer)
    key = rsa.generate_private_key(65537, a.rsa_bits); small = rsa.generate_private_key(65537, 1024)
    if a.hash_file: open(a.hash_file, "w").write(rsa_identity_hash(key).hex())
    ls = socket.socket(); ls.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1); ls.bind(("127.0.0.1", a.port)); ls.listen(4)
    print("READY", flush=True)
    flagsets = [set(x.split(",")) for x in a.flags.split(";")]
    for i in range(a.max_conns):
        sock, _ = ls.accept(); sock.settimeout(10)
        c = Conn(sock, flagsets[min(i, len(flagsets) - 1)], a, key); c.rsa_small = small
        try:
            s = handshake(c, a); print("ESTABLISHED 0x%04x" % s.id, flush=True); serve_session(s)
            print("CLOSED ok", flush=True)
        except Closed: print("PEER CLOSED", flush=True)
        except Fatal as e: print("FATAL", e, flush=True)
        except (socket.timeout, ConnectionError, OSError) as e: print("IO", e, flush=True)
        except Exception as e: print("EXC", repr(e), flush=True)
        finally:
            try: sock.close()
            except Exception: pass
if __name__ == "__main__": main()
