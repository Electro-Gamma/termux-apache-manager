import com.realvnc.vncviewer.jni.*;
import com.realvnc.vncviewer.jni.SessionBindings.Session;
import java.nio.*; import java.nio.file.*; import java.util.*; import java.util.concurrent.*;

/** Exercises the replacement library's JNI API. Usage: ApiTest static | ApiTest session <port> <expected.rgba> <pw1,pw2,..> [opts k=v,...] */
public class ApiTest {
  static int fails = 0;
  static void check(boolean ok, String what) { System.out.println((ok ? "PASS " : "FAIL ") + what); if (!ok) fails++; }

  public static void main(String[] a) throws Exception {
    System.load(System.getProperty("vnclib"));
    if (a[0].equals("static")) staticTests(); else if (a[0].equals("ra4")) ra4Test(a); else sessionTest(a);
    System.out.println(fails == 0 ? "ALL PASSED" : fails + " FAILED");
    System.exit(fails == 0 ? 0 : 1);
  }

  static void staticTests() {
    check(SymbolBindings.unicodeToKeysym(0x41) == 0x41, "unicodeToKeysym ASCII passthrough");
    check(SymbolBindings.unicodeToKeysym(0xe9) == 0xe9, "unicodeToKeysym Latin-1 passthrough");
    check(SymbolBindings.unicodeToKeysym(0x20ac) == 0x20ac, "unicodeToKeysym EuroSign table entry");
    check(SymbolBindings.unicodeToKeysym(0x4e2d) == 0x1004e2d, "unicodeToKeysym CJK -> 0x01000000|cp");
    check(SymbolBindings.unicodeToKeysym(0x7f) == 0xffff, "unicodeToKeysym DEL via table");
    check(SymbolBindings.unicodeToKeysym(0x110000) == 0, "unicodeToKeysym out of range -> 0");
    check(SymbolBindings.keysymToUnicode(0xff08) == 8, "keysymToUnicode BackSpace");
    check(SymbolBindings.keysymToUnicode(0x1004e2d) == 0x4e2d, "keysymToUnicode 0x01000000|cp");
    check(SymbolBindings.keysymToUnicode(0x41) == 0x41, "keysymToUnicode ASCII");
    check(SymbolBindings.keysymToUnicode(0x85) == 0, "keysymToUnicode C1 control rejected");
    check(SymbolBindings.keysymToUnicode(0xffe2) == SymbolBindings.keysymToUnicode(0xffe1), "keysymToUnicode right-shift canonicalised");
    check(SymbolBindings.keysymToUnicode(0xffb5) == 0x35, "keysymToUnicode KP_5 -> '5'");
    ConfigurationBindings.set("MyParam", "42", 0, false);
    check(ConfigurationBindings.getS64("MyParam") == 42, "Configuration set/getS64");
    check(ConfigurationBindings.getBoolean("Shared"), "Configuration default boolean");
    check(ConfigurationBindings.get("PreferredEncoding").equals("ZRLE"), "Configuration default string");
    ConfigurationBindings.set("ViewOnly", "1", 0, false); check(ConfigurationBindings.getBoolean("ViewOnly"), "Configuration set boolean");
    ConfigurationBindings.unset("ViewOnly", 0, false); check(!ConfigurationBindings.getBoolean("ViewOnly"), "Configuration unset restores default");
    try { ConfigurationBindings.get("NoSuchParam"); check(false, "unknown parameter throws"); }
    catch (RuntimeException e) { check(e.getMessage().equals("Parameter 'NoSuchParam' not found"), "unknown parameter throws: " + e.getMessage()); }
    PasswordStoreBindings.save("k1", "pw1"); check("pw1".equals(PasswordStoreBindings.load("k1")), "PasswordStore save/load");
    PasswordStoreBindings.remove("k1"); check(PasswordStoreBindings.load("k1") == null, "PasswordStore remove");
    ServerRecs recs = new ServerRecs(); ServerRecBindings r = new ServerRecBindings();
    r.setProperty("FriendlyName", "Home PC"); r.setProperty("Host", "10.0.0.5"); r.setProperty("ViewOnly", "true"); r.ensureUuid(); r.setLabels(new String[]{"a", "b"});
    recs.add(0, r); recs.add(1, r);
    check(recs.size() == 2, "ServerRecs add/size");
    ServerRecBindings g = recs.get(0);
    check(g.getProperty("FriendlyName").equals("Home PC") && g.getProperty("ViewOnly").equals("1") && g.getProperty("Uuid").length() == 36, "ServerRec properties round-trip");
    check(Arrays.equals(g.getLabels(), new String[]{"a", "b"}), "ServerRec labels round-trip");
    ServerRecBindings rm = recs.remove(0); check(recs.size() == 1 && rm.getProperty("Host").equals("10.0.0.5"), "ServerRecs remove");
    try { recs.get(5); check(false, "ServerRecs.get out of range throws"); } catch (IndexOutOfBoundsException e) { check(true, "ServerRecs.get out of range throws"); }
    try { SessionBindings.keyDownEvent(null, -1L, 0); } catch (Throwable t) { }
  }

  // ---------------------------------------------------------------------------------------------
  static volatile int updates = 0, draws = 0, bells = 0, cursors = 0, dw = 0, dh = 0; static volatile boolean connected = false, closed = false;
  static volatile String serverClip = null; static volatile String errorMsg = null; static volatile String localClip = "";
  static Session session;

  /** RA4 through the real session API: ApiTest ra4 <port> <opts k=v,...> <expected substring of the failure message>. The connection is
   *  expected to end with an error (the v5 post-handshake protocol is not recovered); the server log proves the handshake/rekey. */
  static void ra4Test(String[] a) throws Exception {
    int port = Integer.parseInt(a[1]); Map<String, String> opts = new HashMap<>();
    if (a.length > 2) for (String kv : a[2].split(",")) if (kv.contains("=")) opts.put(kv.substring(0, kv.indexOf('=')), kv.substring(kv.indexOf('=') + 1));
    opts.putIfAbsent("Ra4", "1");   // RA4 is opt-in in the library (default off); these tests exercise it
    String want = a.length > 3 ? a[3] : "";
    MsgBoxBindings.setMsgBoxFactory((MsgBoxBindings.MsgBoxFactory) (s, h, msg, type, title) -> { errorMsg = msg; System.out.println("msgbox: " + msg); MsgBoxBindings.msgBoxResult(h, true); return new MsgBoxBindings.MsgBox() {}; });
    CountDownLatch closedL = new CountDownLatch(1);
    session = SessionBindings.createSession(new SessionBindings.DesktopCallback() {
      public void connSuccess() { connected = true; } public void bell() {} public String getClipboard() { return ""; } public void setClipboard(String s) {}
      public void setCursor(Object b, int hx, int hy) {} public void setDesktopSize(int w, int h) {} public void drawRegion(int x, int y, int w, int h) {} public void framebufferUpdateEnd() {}
    }, s -> { closed = true; closedL.countDown(); }, "127.0.0.1::" + port, "uuid-test", opts);
    check(session != null && session.getToken() != 0, "createSession returns Session with token");
    check(closedL.await(20, TimeUnit.SECONDS), "sessionClosed callback");
    check(!connected, "no connSuccess (session cannot continue past RA4)");
    check(errorMsg != null && errorMsg.contains(want), "error through MsgBox factory contains '" + want + "': " + errorMsg);
    SessionBindings.destroySession(session);
  }

  static void sessionTest(String[] a) throws Exception {
    int port = Integer.parseInt(a[1]); byte[] expected = null;
    final Deque<String> pws = new ArrayDeque<>(); if (a.length > 3 && !a[3].isEmpty()) pws.addAll(Arrays.asList(a[3].split(",")));
    Map<String, String> opts = new HashMap<>(); if (a.length > 4) for (String kv : a[4].split(",")) if (kv.contains("=")) opts.put(kv.split("=")[0], kv.split("=")[1]);
    final boolean expectFail = a.length > 5 && a[5].equals("expectfail");
    final int[] prompts = {0};
    PasswdDlgBindings.setPasswdDlgFactory((PasswdDlgBindings.PasswdDlgFactory) (s, h, msg) -> {
      prompts[0]++; System.out.println("prompt #" + prompts[0] + " msg='" + msg + "'");
      new Thread(() -> { try { Thread.sleep(50); } catch (Exception e) {} String p = pws.poll();
        String user = "", pass = p == null ? "" : p;
        if (p != null && p.contains(":")) { user = p.substring(0, p.indexOf(':')); pass = p.substring(p.indexOf(':') + 1); }
        if (msg.startsWith("@user@") && user.isEmpty() && p != null) System.out.println("WARN username requested but none supplied");
        PasswdDlgBindings.passwdResult(h, p != null, user, pass); }).start();
      return new PasswdDlgBindings.PasswdDlg() {};
    });
    MsgBoxBindings.setMsgBoxFactory((MsgBoxBindings.MsgBoxFactory) (s, h, msg, type, title) -> {
      errorMsg = msg; System.out.println("msgbox: " + msg); MsgBoxBindings.msgBoxResult(h, true); return new MsgBoxBindings.MsgBox() {}; });
    CountDownLatch closedL = new CountDownLatch(1);
    session = SessionBindings.createSession(new SessionBindings.DesktopCallback() {
      public void connSuccess() { connected = true; }
      public void bell() { bells++; }
      public String getClipboard() { return localClip; }
      public void setClipboard(String s) { serverClip = s; }
      public void setCursor(Object b, int hx, int hy) { cursors++; System.out.println("cursor " + (b == null ? "null" : ((android.graphics.Bitmap) b).width + "x" + ((android.graphics.Bitmap) b).height) + " hot " + hx + "," + hy); lastCursor = b; }
      public void setDesktopSize(int w, int h) { dw = w; dh = h; }
      public void drawRegion(int x, int y, int w, int h) { draws++; }
      public void framebufferUpdateEnd() { updates++; }
    }, s -> { closed = true; closedL.countDown(); }, "127.0.0.1::" + port, "uuid-test", opts);
    check(session != null && session.getToken() != 0, "createSession returns Session with token");
    System.out.println("prompts so far: " + prompts[0]);
    if (expectFail) {
      check(closedL.await(15, TimeUnit.SECONDS), "sessionClosed callback after failed connection");
      check(!connected, "no connSuccess on failed authentication");
      check(errorMsg != null, "error shown through MsgBox factory: " + errorMsg);
      check(SessionBindings.authRetriesRemaining(session) == 0, "authRetriesRemaining == 0 (" + SessionBindings.authRetriesRemaining(session) + ")");
      SessionBindings.destroySession(session); return;
    }
    long end = System.currentTimeMillis() + 15000;
    while ((!connected || updates < 2) && System.currentTimeMillis() < end) Thread.sleep(20);
    expected = Files.readAllBytes(Paths.get(a[2]));
    check(connected, "connSuccess callback"); check(updates >= 2, "two framebuffer updates (" + updates + ")");
    check(dw == 160 && dh == 96, "setDesktopSize 160x96 (" + dw + "x" + dh + ")");
    check(draws > 0, "drawRegion callbacks (" + draws + ")"); check(bells == 1, "bell callback"); check("héllo from server".equals(serverClip), "setClipboard (Latin-1 -> UTF) '" + serverClip + "'");
    System.out.println("authRetriesAllowed=" + SessionBindings.authRetriesAllowed(session));
    // --- framebuffer comparison
    ByteBuffer sb = SessionBindings.setScaleBufferSize(session, 160, 96); sb.order(ByteOrder.nativeOrder());
    SessionBindings.copyScaledRegion(1.0f, session, 0, 0, 160, 96);
    byte[] got = new byte[160 * 96 * 4]; sb.get(got);
    check(Arrays.equals(got, expected), "copyScaledRegion(1.0) matches expected framebuffer" + diff(got, expected));
    ByteBuffer db = ByteBuffer.allocateDirect(160 * 96 * 4); SessionBindings.getScaledPixels(1.0f, session, db);
    byte[] got2 = new byte[160 * 96 * 4]; db.get(got2); check(Arrays.equals(got2, expected), "getScaledPixels(1.0) matches");
    android.graphics.Bitmap bmp = android.graphics.Bitmap.createBitmap(160, 96, android.graphics.Bitmap.Config.ARGB_8888);
    SessionBindings.getScaledBitmap(1.0f, session, bmp); byte[] got3 = new byte[160 * 96 * 4]; ((ByteBuffer) bmp.pixels.duplicate().rewind()).get(got3);
    check(Arrays.equals(got3, expected), "getScaledBitmap(1.0) matches");
    ByteBuffer half = ByteBuffer.allocateDirect(80 * 48 * 4); SessionBindings.getScaledPixels(0.5f, session, half);
    boolean hok = true; for (int y = 0; y < 48 && hok; y++) for (int x = 0; x < 80; x++) for (int c = 0; c < 4; c++) if (half.get((y * 80 + x) * 4 + c) != expected[((y * 2) * 160 + x * 2) * 4 + c]) { hok = false; break; }
    check(hok, "getScaledPixels(0.5) is 2x decimation of the framebuffer");
    SessionBindings.copyScaledRegion(1.0f, session, 40, 20, 30, 10); sb.rewind(); byte[] reg = new byte[160 * 96 * 4]; sb.get(reg);
    boolean rok = true; for (int y = 0; y < 10; y++) for (int x = 0; x < 30; x++) for (int c = 0; c < 4; c++) if (reg[(y * 160 + x) * 4 + c] != expected[((y + 20) * 160 + x + 40) * 4 + c]) rok = false;
    check(rok && reg[(10 * 160) * 4 + 3] == 0 && reg[30 * 4 + 3] == 0, "copyScaledRegion writes region at buffer origin and clears the rest");
    // --- connection info
    System.out.println("info: name=" + ConnectionInfoBindings.getDesktopName(session) + " size=" + ConnectionInfoBindings.getDesktopSize(session) + " proto=" + ConnectionInfoBindings.getProtoVersion(session)
      + " sec=" + ConnectionInfoBindings.getSecurityDesc(session) + " enc=" + ConnectionInfoBindings.getLastUsedEncoding(session) + " spf=[" + ConnectionInfoBindings.getServerPixelFormat(session)
      + "] vpf=[" + ConnectionInfoBindings.getViewerPixelFormat(session) + "] type=" + ConnectionInfoBindings.getConnectionType(session));
    check(ConnectionInfoBindings.getDesktopSize(session).equals("160 x 96"), "getDesktopSize format '160 x 96'");
    System.out.println("SECDESC " + ConnectionInfoBindings.getSecurityDesc(session) + " PROMPTS " + prompts[0]);
    check(ConnectionInfoBindings.getDesktopName(session).equals("mock desktop é"), "getDesktopName");
    check(ConnectionInfoBindings.getViewerPixelFormat(session).equals("depth 24 (32 bpp) little-endian bgr888"), "getViewerPixelFormat");
    check(ConnectionInfoBindings.getServerPixelFormat(session).contains("depth 24 (32 bpp)"), "getServerPixelFormat");
    // --- input
    SessionBindings.pointerEvent(session, 10, 20, 1); SessionBindings.pointerEvent(session, 500, -5, 0);
    SessionBindings.wheelEvent(session, 0, 2); SessionBindings.wheelEvent(session, 1, -1);
    SessionBindings.keyDownEvent(session, 0x61, 0x61); SessionBindings.keyUpEvent(session, 0x61);
    SessionBindings.keyDownEvent(session, 0xffe1, 0); SessionBindings.focusEvent(session, false);       // focus loss releases held keys
    localClip = "clip é€"; SessionBindings.focusEvent(session, true);                      // focus gain forwards clipboard (Latin-1, lossy)
    try { SessionBindings.keyDownEvent(session, 0x1_0000_0000L, 0); check(false, "keysym out of range throws"); } catch (RuntimeException e) { check(e.getMessage().equals("keysym out of range"), "keysym out of range throws"); }
    SessionBindings.setOption(session, "ViewOnly", "1"); SessionBindings.pointerEvent(session, 1, 1, 1);   // dropped (view only)
    SessionBindings.setOption(session, "ViewOnly", "0");
    Thread.sleep(300);
    check(cursors >= 1 || a.length > 4 && a[4].contains("nocursor"), "cursor image delivered as Bitmap");
    SessionBindings.closeSession(session);
    check(closedL.await(5, TimeUnit.SECONDS), "sessionClosed after closeSession");
    SessionBindings.destroySession(session);
    check(true, "destroySession completed");
  }
  static Object lastCursor;
  static String diff(byte[] g, byte[] e) { if (g.length != e.length) return " (len)"; for (int i = 0; i < g.length; i++) if (g[i] != e[i]) return " (first diff at px " + (i / 4 % 160) + "," + (i / 4 / 160) + ")"; return ""; }
}
