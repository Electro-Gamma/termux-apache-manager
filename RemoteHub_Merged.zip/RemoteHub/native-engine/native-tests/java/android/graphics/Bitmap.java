package android.graphics;
/** Test stand-in for android.graphics.Bitmap (fields are read by tests/host/bitmap_shim.c). */
public class Bitmap {
  public int width, height; public java.nio.ByteBuffer pixels;
  public enum Config { ARGB_8888 }
  public static Bitmap createBitmap(int w, int h, Config c) {
    Bitmap b = new Bitmap(); b.width = w; b.height = h; b.pixels = java.nio.ByteBuffer.allocateDirect(w * h * 4); return b; }
}
