package com.realvnc.vncviewer.jni;
public class ServerRecs { long impl; public ServerRecs() { init(); } public native void init(); public native int size(); public native ServerRecBindings get(int i);
  public native ServerRecBindings set(int i, ServerRecBindings r); public native void add(int i, ServerRecBindings r); public native ServerRecBindings remove(int i); public native void finalize2(); }
