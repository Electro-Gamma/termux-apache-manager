package com.realvnc.vncviewer.jni;
public class PasswordStoreBindings { public static native String load(String k); public static native void save(String k, String p); public static native void remove(String k); public static native void removeAll(boolean b); }
