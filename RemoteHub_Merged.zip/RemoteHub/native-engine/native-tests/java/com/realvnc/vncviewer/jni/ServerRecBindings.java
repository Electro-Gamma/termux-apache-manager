package com.realvnc.vncviewer.jni;
public class ServerRecBindings { long impl; public ServerRecBindings() { init(); } public ServerRecBindings(long p) { impl = p; }
  public native void init(); public native void ensureUuid(); public native String getProperty(String n); public native void setProperty(String n, String v);
  public native boolean getRememberPassword(); public native void setRememberPassword(boolean b); public native void setLabels(String[] l); public native String[] getLabels();
  public native void finalize2(); }
