"""Server side of Apple Remote Desktop security type 30 for the mock server, written with hashlib + `cryptography`
(independent of the C++ client). Message order from the public libvncclient HandleARDAuth: generator(2) keylen(2) prime(keylen) pub(keylen),
then the client answers AES-128-ECB(MD5(shared), username[64]|password[64]) followed by its DH public value."""
import hashlib, os, struct
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.asymmetric import dh

_PARAMS = {}
def params(bits):
    if bits not in _PARAMS: _PARAMS[bits] = dh.generate_parameters(generator=2, key_size=bits).parameter_numbers()
    return _PARAMS[bits]

def handshake(sock, user, password, recvn, ev, bits=512):
    pn = params(bits); p, g = pn.p, pn.g; kl = (p.bit_length() + 7) // 8
    x = int.from_bytes(os.urandom(kl), 'big') % (p - 2) + 1
    pub = pow(g, x, p)
    sock.sendall(struct.pack('>HH', g, kl) + p.to_bytes(kl, 'big') + pub.to_bytes(kl, 'big'))
    blob = recvn(sock, 128); cpub = int.from_bytes(recvn(sock, kl), 'big')
    key = hashlib.md5(pow(cpub, x, p).to_bytes(kl, 'big')).digest()
    dec = Cipher(algorithms.AES(key), modes.ECB()).decryptor(); pt = dec.update(blob) + dec.finalize()
    u = pt[:64].split(b'\0')[0].decode(); pw = pt[64:].split(b'\0')[0].decode()
    ok = (u == user and pw == password); ev(type='ard', user=u, ok=ok, keylen=kl)
    return ok
