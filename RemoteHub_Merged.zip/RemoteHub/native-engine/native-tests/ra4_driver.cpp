// Drives vr::ra4::Client against tests/host/ra4_server.py over a real TCP socket.
// usage: ra4_driver PORT SUITES [--my-psk HEX] [--peer-psk HEX] [--rsa-hash HEX] [--allow-null] [--script a,b,c] [--expect-err SUBSTR]
#include "ra4.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
using namespace vr; using namespace vr::ra4;
static Bytes H(const char* s) { Bytes b; for (; s[0] && s[1]; s += 2) { unsigned v; sscanf(s, "%2x", &v); u8 x = (u8)v; b.append(&x, 1); } return b; }
static int fd = -1; static Client cl; static Bytes app; static Str lastErr;
static ssize_t findApp(const char* s, size_t l) { void* r = app.n >= l ? memmem(app.p, app.n, s, l) : nullptr; return r ? (u8*)r - app.p : -1; }
static int done(int rc, const char* expect, const char* msg) {
  if (expect) {
    if (rc != 0 && strstr(msg, expect)) { printf("EXPECTED-ERR (%s)\n", msg); return 0; }
    printf("FAIL: wanted error containing '%s', got %s\n", expect, rc ? msg : "success"); return 1;
  }
  if (rc) printf("FAIL: %s\n", msg); else printf("OK %s\n", msg);
  return rc ? 1 : 0;
}
static bool sendAll(const Bytes& b) { size_t o = 0; while (o < b.n) { ssize_t w = send(fd, b.p + o, b.n - o, MSG_NOSIGNAL); if (w <= 0) return false; o += (size_t)w; } return true; }
// pump the socket until pred() holds. returns false (lastErr set) on protocol error / close / timeout
template <class F> static bool pumpUntil(F pred) {
  while (!pred()) {
    u8 buf[4096]; ssize_t n = recv(fd, buf, sizeof buf, 0);
    if (n < 0) { lastErr = Str("timeout"); return false; }
    if (n == 0) { lastErr = Str("connection closed"); return false; }
    Bytes out, a; Str err;
    bool ok = cl.feed(buf, (size_t)n, &out, &a, &err);
    if (out.n && !sendAll(out)) { lastErr = Str("send failed"); return false; }
    if (a.n) app.append(a.p, a.n);
    if (!ok) { lastErr = Str(err.c()); return false; }
  }
  return true;
}
static bool txBytes(const char* d, size_t n) { Bytes out; Str err; if (!cl.send((const u8*)d, n, &out, &err)) { lastErr = Str(err.c()); return false; } return sendAll(out); }
static bool expectApp(const char* s) {
  size_t l = strlen(s);
  if (!pumpUntil([&] { return findApp(s, l) >= 0; })) return false;
  size_t cut = (size_t)findApp(s, l) + l; memmove(app.p, app.p + cut, app.n - cut); app.n -= cut; return true;
}
int main(int argc, char** argv) {
  if (argc < 3) { puts("usage"); return 2; }
  HelloParams hp; const char* expect = nullptr; const char* script = "ping";
  for (int i = 3; i + 1 < argc; i++) if (!strcmp(argv[i], "--expect-err")) expect = argv[i + 1];
  Str perr; u16 pref[16]; int n = parsePreference(argv[2], pref, 16, &perr);
  if (n < 0) return done(1, expect, perr.c());
  for (int i = 0; i < n; i++) hp.offered[i] = pref[i]; hp.nOffered = n;
  for (int i = 3; i < argc; i++) {
    const char* a = argv[i];
    if (!strcmp(a, "--my-psk") && i + 1 < argc) { hp.myPsk = H(argv[++i]); }
    else if (!strcmp(a, "--peer-psk") && i + 1 < argc) { hp.peerPsk = H(argv[++i]); }
    else if (!strcmp(a, "--rsa-hash") && i + 1 < argc) { hp.peerRsaHash = H(argv[++i]); }
    else if (!strcmp(a, "--allow-null")) hp.allowNull = true;
    else if (!strcmp(a, "--script") && i + 1 < argc) script = argv[++i];
    else if (!strcmp(a, "--expect-err") && i + 1 < argc) expect = argv[++i];
  }
  fd = socket(AF_INET, SOCK_STREAM, 0); sockaddr_in sa{}; sa.sin_family = AF_INET; sa.sin_port = htons((u16)atoi(argv[1])); inet_pton(AF_INET, "127.0.0.1", &sa.sin_addr);
  timeval tv{10, 0}; setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv);
  Bytes out; Str err;
  if (!cl.start(hp, &out, &err)) return done(1, expect, err.c());       // local validation errors (unknown/unsupported suite, short PSK...)
  if (connect(fd, (sockaddr*)&sa, sizeof sa) != 0) return done(1, expect, "connect failed");
  if (!sendAll(out)) return done(1, expect, "send failed");
  if (!pumpUntil([&] { return cl.established(); })) return done(1, expect, lastErr.c());
  char info[64]; snprintf(info, sizeof info, "suite=0x%04x", cl.suite()->id);
  int cnt = 0; char* sc = strdup(script); char* sv = nullptr;
  for (char* cmdp = strtok_r(sc, ",", &sv); cmdp; cmdp = strtok_r(nullptr, ",", &sv)) {
    const char* cmd = cmdp; cnt++;
    bool ok = true; Bytes o; Str er;
    if (!strcmp(cmd, "ping")) { char m[40]; snprintf(m, sizeof m, "PING:%d", cnt); ok = txBytes(m, strlen(m)); snprintf(m, sizeof m, "PONG:%d", cnt); ok = ok && expectApp(m); }
    else if (!strcmp(cmd, "rekey")) { ok = cl.rekey(&o, &er) ? sendAll(o) : (lastErr = Str(er.c()), false); }
    else if (!strcmp(cmd, "refresh")) { ok = cl.refreshKeys(&o, &er) ? sendAll(o) : (lastErr = Str(er.c()), false); }
    else if (!strcmp(cmd, "switch")) { ok = cl.switchToNullHmac(&o, &er) ? sendAll(o) : (lastErr = Str(er.c()), false); }
    else if (!strcmp(cmd, "srv-rekey")) { ok = txBytes("SERVER_REKEY", 12) && expectApp("DONE:rekey"); }
    else if (!strcmp(cmd, "srv-refresh")) { ok = txBytes("SERVER_REFRESH", 14) && expectApp("DONE:refresh"); }
    else if (!strcmp(cmd, "big")) { ok = txBytes("BIGDATA", 7) && pumpUntil([&] { return app.n >= 20000; }); if (ok) { for (size_t i = 0; i < 20000; i++) if (app.p[i] != (u8)((i * 7) & 255)) { lastErr = Str("big data mismatch"); ok = false; break; } memmove(app.p, app.p + 20000, app.n - 20000); app.n -= 20000; } }
    else if (!strcmp(cmd, "echo-large")) { Bytes big; big.resize(30000); memset(big.p, 'x', 30000); ok = txBytes((const char*)big.p, big.n) && expectApp("ECHO:"); }
    else if (!strcmp(cmd, "close")) { txBytes("CLOSE", 5); break; }
    else if (!strcmp(cmd, "wait-err")) { ok = pumpUntil([] { return false; }); }
    else { lastErr = Str("unknown script command"); ok = false; }
    if (!ok) return done(1, expect, lastErr.c());
  }
  return done(0, expect, info);
}
