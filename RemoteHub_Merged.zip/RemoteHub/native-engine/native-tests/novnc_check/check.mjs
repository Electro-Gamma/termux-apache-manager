// Interop cross-check: drive the mock RA2 server with noVNC's own RA2ne client (core/ra2.js, MPL-2.0, from a noVNC clone).
// usage: node check.mjs <path-to-noVNC/core> <port>
import net from 'node:net';
import { pathToFileURL } from 'node:url';
const core = process.argv[2], port = +process.argv[3];
globalThis.window = globalThis;
const RSAAES = (await import(pathToFileURL(core + '/ra2.js').href)).default;
const s = net.connect(port, '127.0.0.1');
let buf = Buffer.alloc(0), state;
const sock = {
  rQwait: (_n, len) => buf.length < len,
  rQpeekBytes: n => new Uint8Array(buf.subarray(0, n)),
  rQshiftBytes: n => { const r = new Uint8Array(buf.subarray(0, n)); buf = buf.subarray(n); return r; },
  rQshift16: () => { const v = buf.readUInt16BE(0); buf = buf.subarray(2); return v; },
  rQshift32: () => { const v = buf.readUInt32BE(0); buf = buf.subarray(4); return v; },
  sQpushBytes: b => s.write(Buffer.from(b)), flush: () => {},
};
const creds = { username: 'pi', password: 'raspberry' };
state = new RSAAES(sock, () => creds);
state.addEventListener('serververification', () => state.approveServer());
let stage = 0;
s.on('data', d => {
  buf = Buffer.concat([buf, d]);
  if (stage === 0 && buf.length >= 12) { buf = buf.subarray(12); s.write('RFB 003.008\n'); stage = 1; }
  if (stage === 1 && buf.length >= 1 + 1) { const n = buf[0]; const types = [...buf.subarray(1, 1 + n)]; buf = buf.subarray(1 + n); s.write(Buffer.from([6])); stage = 2;
    state.negotiateRA2neAuthAsync().then(() => { console.log('noVNC RA2ne client: handshake completed, credentials sent'); setTimeout(() => process.exit(0), 300); })
         .catch(e => { console.log('noVNC RA2ne client FAILED:', e.message); process.exit(1); }); return; }
  state.checkInternalEvents();
});
s.on('error', e => { console.log('socket error', e.message); process.exit(2); });
setTimeout(() => { console.log('timeout'); process.exit(3); }, 20000);
