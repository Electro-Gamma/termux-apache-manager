#!/usr/bin/env python3
"""Mock RFB 3.x server used to test the replacement library. Not a general VNC server.
Serves one connection per accept (keeps accepting), logs client->server events as JSON lines."""
import argparse, json, socket, struct, subprocess, sys, threading, zlib, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

W, H = 160, 96

def make_image():
    img = [[(0, 0, 0)] * W for _ in range(H)]
    for y in range(H):
        for x in range(W):
            img[y][x] = ((x * 4) % 256, (y * 5) % 256, ((x + y) * 3) % 256)
    def box(x0, y0, w, h, c):
        for y in range(y0, y0 + h):
            for x in range(x0, x0 + w): img[y][x] = c
    box(64, 0, 64, 64, (200, 100, 50))                      # solid zrle tile
    for y in range(0, 64):                                  # 2-colour packed palette tile
        for x in range(128, 160): img[y][x] = (255, 255, 255) if (x // 4 + y // 4) % 2 else (0, 0, 128)
    for y in range(64, 96):                                 # plain RLE tile: horizontal runs
        for x in range(0, 64): img[y][x] = (10, 200, 30) if (x // 20) % 2 else (200, 10, 90)
    for y in range(64, 96):                                 # palette RLE (3 colours)
        for x in range(64, 128): img[y][x] = [(1, 2, 3), (250, 251, 252), (90, 80, 70)][((x - 64) // 7) % 3]
    for y in range(64, 96):                                 # 4-colour packed palette
        for x in range(128, 160): img[y][x] = [(9, 9, 9), (99, 9, 9), (9, 99, 9), (9, 9, 99)][(x + y) % 4]
    return img

def px(c): return bytes([c[0], c[1], c[2], 0])

def enc_raw(img, x, y, w, h):
    return b''.join(px(img[yy][xx]) for yy in range(y, y + h) for xx in range(x, x + w))

def enc_hextile(img, x, y, w, h):
    out = b''
    for ty in range(0, h, 16):
        for tx in range(0, w, 16):
            tw, th = min(16, w - tx), min(16, h - ty)
            tile = [[img[y + ty + r][x + tx + c] for c in range(tw)] for r in range(th)]
            flat = [p for row in tile for p in row]
            if len(set(flat)) == 1:
                out += bytes([2]) + px(flat[0])
            else:
                # bg + foreground subrects when exactly two colours present, else raw
                cols = sorted(set(flat), key=lambda c: -flat.count(c))
                if len(cols) == 2:
                    bg, fg = cols
                    subs = []
                    for r in range(th):          # one subrect per horizontal run of fg
                        c = 0
                        while c < tw:
                            if tile[r][c] == fg:
                                s = c
                                while c < tw and tile[r][c] == fg: c += 1
                                subs.append((s, r, c - s, 1))
                            else: c += 1
                    if len(subs) < 256:
                        out += bytes([2 | 4 | 8]) + px(bg) + px(fg) + bytes([len(subs)])
                        for sx, sy, sw, sh in subs: out += bytes([(sx << 4) | sy, ((sw - 1) << 4) | (sh - 1)])
                        continue
                out += bytes([1]) + b''.join(px(p) for p in flat)
    return out

def enc_rre(img, x, y, w, h):
    # bg = most common, subrects = per-row runs of non-bg
    flat = [img[yy][xx] for yy in range(y, y + h) for xx in range(x, x + w)]
    bg = max(set(flat), key=flat.count)
    subs = []
    for r in range(h):
        c = 0
        while c < w:
            if img[y + r][x + c] != bg:
                col = img[y + r][x + c]; s = c
                while c < w and img[y + r][x + c] == col: c += 1
                subs.append((col, s, r, c - s, 1))
            else: c += 1
    out = struct.pack('>I', len(subs)) + px(bg)
    for col, sx, sy, sw, sh in subs: out += px(col) + struct.pack('>HHHH', sx, sy, sw, sh)
    return out

def cp(c): return bytes([c[0], c[1], c[2]])

def enc_zrle_tiles(img, x, y, w, h):
    out = b''
    for ty in range(0, h, 64):
        for tx in range(0, w, 64):
            tw, th = min(64, w - tx), min(64, h - ty)
            tile = [img[y + ty + r][x + tx:x + tx + tw] for r in range(th)]
            flat = [p for row in tile for p in row]
            pal = list(dict.fromkeys(flat))
            if len(pal) == 1:
                out += bytes([1]) + cp(pal[0])
            elif len(pal) <= 16 and (ty, tx) in ((0, 128), (64, 128)):          # packed palette
                bits = 1 if len(pal) <= 2 else (2 if len(pal) <= 4 else 4)
                out += bytes([len(pal)]) + b''.join(cp(c) for c in pal)
                for row in tile:
                    acc = 0; nb = 0; rowb = b''
                    for p in row:
                        acc = (acc << bits) | pal.index(p); nb += bits
                        while nb >= 8: rowb += bytes([(acc >> (nb - 8)) & 255]); nb -= 8
                    if nb: rowb += bytes([(acc << (8 - nb)) & 255])
                    out += rowb
            elif (ty, tx) == (64, 0):                                           # plain RLE
                out += bytes([128]); i = 0
                while i < len(flat):
                    j = i
                    while j < len(flat) and flat[j] == flat[i]: j += 1
                    run = j - i; out += cp(flat[i]); r = run - 1
                    while r >= 255: out += b'\xff'; r -= 255
                    out += bytes([r]); i = j
            elif (ty, tx) == (64, 64):                                          # palette RLE
                out += bytes([128 + len(pal)]) + b''.join(cp(c) for c in pal); i = 0
                while i < len(flat):
                    j = i
                    while j < len(flat) and flat[j] == flat[i]: j += 1
                    run = j - i; idx = pal.index(flat[i])
                    if run == 1: out += bytes([idx])
                    else:
                        out += bytes([idx | 128]); r = run - 1
                        while r >= 255: out += b'\xff'; r -= 255
                        out += bytes([r])
                    i = j
            else:
                out += bytes([0]) + b''.join(cp(p) for p in flat)
    return out

def recvn(s, n):
    b = b''
    while len(b) < n:
        d = s.recv(n - len(b))
        if not d: raise EOFError
        b += d
    return b

def des_ok(password, challenge, resp):
    # DES core is validated separately against the FIPS 46-3 vector (tests/host/run_tests.sh).
    helper = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'build', 'host', 'desauth')
    out = subprocess.run([helper, password, challenge.hex()], capture_output=True, text=True).stdout.strip()
    return out == resp.hex()

def main_loop(conn, a, ev, dump, img):
    encs = []; step = 0; zc = zlib.compressobj()
    while True:
        t = recvn(conn, 1)[0]
        if t == 0:
            d = recvn(conn, 19); pf = d[3:]; ev(type='setpf', bpp=pf[0], depth=pf[1], big=pf[2], true=pf[3], shifts=list(pf[10:13]))
        elif t == 2:
            d = recvn(conn, 3); n = struct.unpack('>H', d[1:])[0]
            encs = list(struct.unpack('>%di' % n, recvn(conn, 4 * n))); ev(type='setenc', encs=encs)
        elif t == 3:
            d = recvn(conn, 9); inc, x, y, w, h = d[0], *struct.unpack('>HHHH', d[1:])
            ev(type='fbreq', inc=inc, rect=[x, y, w, h])
            if step == 0:
                dump()
                rects = []
                def rect(x, y, w, h, e, body): return struct.pack('>HHHHi', x, y, w, h, e) + body
                if a.enc == 'raw': rects.append(rect(0, 0, W, H, 0, enc_raw(img, 0, 0, W, H)))
                elif a.enc == 'hextile': rects.append(rect(0, 0, W, H, 5, enc_hextile(img, 0, 0, W, H)))
                elif a.enc == 'rre':
                    rects.append(rect(0, 0, 80, 48, 2, enc_rre(img, 0, 0, 80, 48)))
                    rects.append(rect(80, 0, 80, 48, 0, enc_raw(img, 80, 0, 80, 48)))
                    rects.append(rect(0, 48, W, 48, 0, enc_raw(img, 0, 48, W, 48)))
                elif a.enc == 'zrle':
                    raw = enc_zrle_tiles(img, 0, 0, W, H)
                    z = zc.compress(raw) + zc.flush(zlib.Z_SYNC_FLUSH)
                    rects.append(rect(0, 0, W, H, 16, struct.pack('>I', len(z)) + z))
                conn.sendall(bytes([0, 0]) + struct.pack('>H', len(rects)) + b''.join(rects))
                step = 1
            elif step == 1:
                # second update: CopyRect (20,10,40x30 <- 0,0), cursor, bell, clipboard
                src = [[img[yy][xx] for xx in range(40)] for yy in range(30)]
                for yy in range(30):
                    for xx in range(40): img[10 + yy][20 + xx] = src[yy][xx]
                dump()
                rects = [struct.pack('>HHHHi', 20, 10, 40, 30, 1) + struct.pack('>HH', 0, 0)]
                if -239 in encs:
                    cur = b''.join(px((255, 0, 0) if (x + y) % 2 else (0, 0, 255)) for y in range(4) for x in range(4)) + bytes([0xf0] * 4)
                    rects.append(struct.pack('>HHHHi', 1, 2, 4, 4, -239) + cur)
                conn.sendall(bytes([2]))   # bell
                txt = 'h\xe9llo from server'.encode('latin-1')
                conn.sendall(bytes([3, 0, 0, 0]) + struct.pack('>I', len(txt)) + txt)
                conn.sendall(bytes([0, 0]) + struct.pack('>H', len(rects)) + b''.join(rects))
                step = 2
        elif t == 4:
            d = recvn(conn, 7); ev(type='key', down=d[0], keysym=struct.unpack('>I', d[3:])[0])
        elif t == 5:
            d = recvn(conn, 5); ev(type='ptr', mask=d[0], x=struct.unpack('>H', d[1:3])[0], y=struct.unpack('>H', d[3:5])[0])
        elif t == 6:
            d = recvn(conn, 7); n = struct.unpack('>I', d[3:])[0]; ev(type='cuttext', text=recvn(conn, n).decode('latin-1'))
        else:
            ev(type='unknown', t=t); return

def serve(conn, a):
    log = open(a.log, 'a')
    def ev(**k): log.write(json.dumps(k) + '\n'); log.flush()
    img = make_image()
    def dump():
        open(a.expected, 'wb').write(b''.join(px(img[y][x])[:3] + b'\xff' for y in range(H) for x in range(W)))
    try:
        minor = {'3.3': 3, '3.7': 7, '3.8': 8}[a.proto]
        if a.auth == 'ard':
            import ard_server
            conn.sendall(b'RFB 003.889\n')
            cv = recvn(conn, 12); ev(type='version', v=cv.decode().strip())
            conn.sendall(bytes([2, 30, 2]))
            sel = recvn(conn, 1)[0]; ev(type='sectype', t=sel)
            if sel != 30: return
            ok = ard_server.handshake(conn, a.user, a.password, recvn, ev, a.dhbits)
            conn.sendall(struct.pack('>I', 0 if ok else 1))
            if not ok:
                m = b'Authentication failed'; conn.sendall(struct.pack('>I', len(m)) + m); return
            minor = 8
            shared = recvn(conn, 1)[0]; ev(type='clientinit', shared=shared)
            name = b'mock desktop \xe9'
            conn.sendall(struct.pack('>HH', W, H) + bytes([32, 24, 0, 1]) + struct.pack('>HHH', 255, 255, 255) + bytes([16, 8, 0, 0, 0, 0]) +
                         struct.pack('>I', len(name)) + name)
            main_loop(conn, a, ev, dump, img)
            return
        if a.auth == 'ra2':
            import ra2_server
            conn.sendall((a.banner or 'RFB 004.001').encode() + b'\n')
            cv = recvn(conn, 12); ev(type='version', v=cv.decode().strip())
            offered = [int(x) for x in a.offer.split(',')]
            conn.sendall(bytes([len(offered)]) + bytes(offered))
            sel = recvn(conn, 1)[0]; ev(type='sectype', t=sel)
            if sel not in offered or sel not in (5, 6, 13, 129, 130, 133): return
            try:
                nconn, ok = ra2_server.handshake(conn, sel, a.user, a.password, recvn, ev, a.subtype or None)
            except Exception as e:
                ev(type='ra2', step='error', msg=str(e)); return
            if not ok: return
            conn = nconn
            minor = 8
            shared = recvn(conn, 1)[0]; ev(type='clientinit', shared=shared)
            name = b'mock desktop \xe9'
            conn.sendall(struct.pack('>HH', W, H) + bytes([32, 24, 0, 1]) + struct.pack('>HHH', 255, 255, 255) + bytes([16, 8, 0, 0, 0, 0]) +
                         struct.pack('>I', len(name)) + name)
            main_loop(conn, a, ev, dump, img)
            return
        conn.sendall(b'RFB 003.%03d\n' % minor)
        cv = recvn(conn, 12); ev(type='version', v=cv.decode().strip())
        if minor == 3:
            conn.sendall(struct.pack('>I', 2 if a.auth == 'vnc' else 1))
        else:
            conn.sendall(bytes([1, 2 if a.auth == 'vnc' else 1]))
            ev(type='sectype', t=recvn(conn, 1)[0])
        if a.auth == 'vnc':
            ch = os.urandom(16); conn.sendall(ch); resp = recvn(conn, 16)
            ok = des_ok(a.password, ch, resp); ev(type='auth', ok=ok)
            if not ok:
                conn.sendall(struct.pack('>I', 1))
                if minor >= 8:
                    m = b'Authentication failed'; conn.sendall(struct.pack('>I', len(m)) + m)
                return
            conn.sendall(struct.pack('>I', 0))
        elif minor >= 8:
            conn.sendall(struct.pack('>I', 0))
        shared = recvn(conn, 1)[0]; ev(type='clientinit', shared=shared)
        name = b'mock desktop \xe9'
        conn.sendall(struct.pack('>HH', W, H) + bytes([32, 24, 0, 1]) + struct.pack('>HHH', 255, 255, 255) + bytes([16, 8, 0, 0, 0, 0]) +
                     struct.pack('>I', len(name)) + name)
        main_loop(conn, a, ev, dump, img)
    except EOFError:
        ev(type='eof')
    finally:
        conn.close()

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--port', type=int, required=True); p.add_argument('--proto', default='3.8')
    p.add_argument('--auth', default='none'); p.add_argument('--password', default='secret')
    p.add_argument('--enc', default='raw'); p.add_argument('--user', default=''); p.add_argument('--offer', default='6'); p.add_argument('--banner', default=''); p.add_argument('--subtype', type=int, default=0); p.add_argument('--dhbits', type=int, default=512); p.add_argument('--log', required=True); p.add_argument('--expected', required=True)
    a = p.parse_args()
    s = socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1); s.bind(('127.0.0.1', a.port)); s.listen(4)
    print('listening', flush=True)
    while True:
        c, _ = s.accept(); threading.Thread(target=serve, args=(c, a), daemon=True).start()
