/* Host-test stand-in for libjnigraphics: a "Bitmap" is any Java object with fields
   int width, height; java.nio.ByteBuffer pixels (direct). */
#include <jni.h>
#include <stdint.h>
typedef struct { uint32_t width, height, stride; int32_t format, flags; } Info;
static jfieldID fid(JNIEnv* e, jobject o, const char* n, const char* s) { jclass c = (*e)->GetObjectClass(e, o); jfieldID f = (*e)->GetFieldID(e, c, n, s); (*e)->DeleteLocalRef(e, c); return f; }
int AndroidBitmap_getInfo(JNIEnv* e, jobject b, void* out) {
  Info* i = out; i->width = (*e)->GetIntField(e, b, fid(e, b, "width", "I")); i->height = (*e)->GetIntField(e, b, fid(e, b, "height", "I"));
  i->stride = i->width * 4; i->format = 1; i->flags = 0; return 0; }
int AndroidBitmap_lockPixels(JNIEnv* e, jobject b, void** addr) {
  jobject bb = (*e)->GetObjectField(e, b, fid(e, b, "pixels", "Ljava/nio/ByteBuffer;")); *addr = (*e)->GetDirectBufferAddress(e, bb); return 0; }
int AndroidBitmap_unlockPixels(JNIEnv* e, jobject b) { (void)e; (void)b; return 0; }
