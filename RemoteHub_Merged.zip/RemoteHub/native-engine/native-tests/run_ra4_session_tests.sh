#!/bin/bash
# RA4 through the REAL session/JNI path: x86-64 host build of the same sources, driven from a JVM (ApiTest ra4) against
# the independent Python RA4 server (ra4_server.py --rfb). The v5 post-handshake protocol is not recovered, so every
# connection ends with an error; the checks are (a) what the server observed (version echo, key exchange, digests,
# server-initiated rekey/refresh answered correctly, client-initiated rekey/refresh accepted) and (b) the error the app sees.
# [TEST] only: the server shares our reading of the binary evidence; not a real RealVNC server.
set -u
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"; B=$ROOT/build/host; T=$ROOT/tests/host; W=${TMPDIR:-/tmp}/ra4sess.$$; mkdir -p $W
javac -nowarn -d $B/classes $(find $T/java -name "*.java") 2>&1 | grep -v JAVA_TOOL
LIB=$B/libvncviewer.so; fail=0; port=${RA4S_PORT:-17300}
PSK=000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f
start_srv() { # name args...
  local n=$1; shift; port=$((port+1)); rm -f $W/$n.hash
  python3 -I $T/ra4_server.py --port $port --rfb --hash-file $W/$n.hash "$@" >$W/$n.srv 2>&1 & SP=$!
  for i in $(seq 1 100); do grep -q READY $W/$n.srv 2>/dev/null && [ -f $W/$n.hash ] && break; sleep 0.1; done
}
run_java() { # name opts want
  local n=$1 o=${2//@PIN@/$(cat $W/$n.hash)}
  timeout 60 java -Dvnclib=$LIB -Djava.library.path=$B -cp $B/classes ApiTest ra4 $port "$o" "$3" >$W/$n.out 2>&1; return $?
}
case_() { # name server-args opts want [server-log-must-contain...]
  local n=$1 sa=$2 o=$3 want=$4; shift 4
  start_srv $n $sa; run_java $n "$o" "$want"; local rc=$?; sleep 0.3; kill $SP 2>/dev/null; wait $SP 2>/dev/null
  local bad=""; for m in "$@"; do grep -q -- "$m" $W/$n.srv || bad="$bad [server log lacks '$m']"; done
  if [ $rc -eq 0 ] && [ -z "$bad" ]; then echo "[ok]   $n"; else echo "[FAIL] $n$bad"; grep -E "^FAIL|msgbox" $W/$n.out | head -3; tail -3 $W/$n.srv | sed 's/^/  srv: /'; fail=1; fi
}
OKMSG="RA4 secure channel established"
echo "== RA4 through the session API: every suite, handshake + server rekey + server key refresh"
for s in 0x0202 0x0303 0x0b03 0x0204; do case_ sess_$s "--suite $s --post srv-rekey,srv-refresh,app" "Ra4Suites=$s" "$OKMSG" VERSION-OK "ESTABLISHED $s" "POST rekey-ok" "POST refresh-sent" "POST session-end"; done
for s in 0x0402 0x0403 0x0c03; do case_ sess_$s "--suite $s --psk-my $PSK --psk-peer $PSK --post srv-rekey,srv-refresh,app" "Ra4Suites=$s,Ra4Psk=$PSK" "$OKMSG" VERSION-OK "ESTABLISHED $s" "POST rekey-ok" "POST refresh-sent"; done
for s in 0x0602 0x0703 0x0f03; do case_ sess_$s "--suite $s --psk-my $PSK --psk-peer $PSK --post srv-rekey,srv-refresh,app" "Ra4Suites=$s,Ra4Psk=$PSK,Ra4PeerRsaHash=@PIN@" "$OKMSG" VERSION-OK "ESTABLISHED $s" "POST rekey-ok" "POST refresh-sent"; done
case_ sess_0x0001_null_opt_in "--suite 0x0001 --post app" "Ra4Suites=0x0001,Ra4AllowNull=1" "$OKMSG" VERSION-OK "ESTABLISHED 0x0001"
echo "== client-initiated rekey / key refresh (Ra4Rekey option) and preference/negotiation"
case_ sess_client_rekey "--suite 0x0b03 --post client-event,app" "Ra4Suites=0x0b03,Ra4Rekey=rekey" "$OKMSG" "POST client-event-ok"
case_ sess_client_refresh "--suite 0x0303 --post client-event,app" "Ra4Suites=0x0303,Ra4Rekey=refresh" "$OKMSG" "POST client-event-ok"
case_ sess_default_offer_negotiates_strongest "--suite 0x0b03,0x0303,0x0202 --post app" "" "$OKMSG" "ESTABLISHED 0x0b03"
case_ sess_restricted_offer_limits_server_choice "--suite 0x0b03,0x0303,0x0202 --post app" "Ra4Suites=0x0202 0x0303" "$OKMSG" "ESTABLISHED 0x0303"
case_ sess_names_in_preference "--suite 0x0303 --post app" "Ra4Suites=RA4_256" "$OKMSG" "ESTABLISHED 0x0303"
echo "== failures reach the application as errors (no silent success, no downgrade)"
case_ sess_reject_unoffered_choice "--suite 0x0b03 --flags choose:0x0b03" "Ra4Suites=0x0303" "not offered"
case_ sess_reject_null_downgrade "--suite 0x0303 --flags choose:0x0001" "Ra4Suites=0x0303" "not offered"
case_ sess_reject_null_without_opt_in "--suite 0x0001" "Ra4Suites=0x0001" "Null cipher suite must be enabled"
case_ sess_reject_signonly "--suite 0x0303" "Ra4Suites=0x0101" "not supported"
case_ sess_reject_bad_option "--suite 0x0303" "Ra4Suites=0x0702" "Invalid Ra4Suites"
case_ sess_bad_digest "--suite 0x0303 --flags bad-digest" "Ra4Suites=0x0303" "digest mismatch"
case_ sess_wrong_psk "--suite 0x0403 --psk-my $PSK --psk-peer $PSK --flags wrong-psk" "Ra4Suites=0x0403,Ra4Psk=$PSK" "digest mismatch"
case_ sess_psk_missing "--suite 0x0402" "Ra4Suites=0x0402" "PSK not available"
case_ sess_wrong_identity_pin "--suite 0x0703 --psk-my $PSK --psk-peer $PSK" "Ra4Suites=0x0703,Ra4Psk=$PSK,Ra4PeerRsaHash=00112233445566778899aabbccddeeff00112233445566778899aabbccddeeff" "Bad peer identity"
case_ sess_tampered_record "--suite 0x0303 --flags tamper-tag --post app" "Ra4Suites=0x0303" "authentication failure"
case_ sess_truncated_kex "--suite 0x0303 --flags truncate" "Ra4Suites=0x0303" "closed"
echo "== disconnect and reconnection (same server: first connection rejected, second succeeds)"
port=$((port+1)); rm -f $W/rc.hash; python3 -I $T/ra4_server.py --port $port --rfb --hash-file $W/rc.hash --max-conns 2 --suite 0x0303 --flags "bad-digest;none" --post app >$W/rc.srv 2>&1 & SP=$!
for i in $(seq 1 100); do grep -q READY $W/rc.srv 2>/dev/null && break; sleep 0.1; done
timeout 60 java -Dvnclib=$LIB -Djava.library.path=$B -cp $B/classes ApiTest ra4 $port "Ra4Suites=0x0303" "digest mismatch" >$W/rc1.out 2>&1; r1=$?
timeout 60 java -Dvnclib=$LIB -Djava.library.path=$B -cp $B/classes ApiTest ra4 $port "Ra4Suites=0x0303" "$OKMSG" >$W/rc2.out 2>&1; r2=$?
kill $SP 2>/dev/null; wait $SP 2>/dev/null
if [ $r1 -eq 0 ] && [ $r2 -eq 0 ] && grep -q "ESTABLISHED 0x0303" $W/rc.srv; then echo "[ok]   sess_reconnect_after_failed_connection"; else echo "[FAIL] sess_reconnect ($r1 $r2)"; fail=1; fi
echo; [ $fail -eq 0 ] && echo "RA4 session tests: ALL PASSED" || echo "RA4 session tests: FAILURES"; exit $fail
