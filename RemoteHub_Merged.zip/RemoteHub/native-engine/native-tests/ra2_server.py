"""Server side of the RFB RSA-AES (RA2) security types for the mock server, written with the `cryptography` package
(independent of the C++ implementation under test). Types: 5 RA2, 6 RA2ne, 13 RA2r, 129 RA2_256, 130 RA2ne_256, 133 RA2r_256.
Nonce length equals the AES key length (16 or 32 bytes), as in TigerVNC's CSecurityRSAAES and the original binary."""
import hashlib, os, struct
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import cmac

_KEY = None
def server_key():
    global _KEY
    if _KEY is None: _KEY = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    return _KEY

def pub_wire(pub):
    n = pub.public_numbers(); bits = pub.key_size; nb = (bits + 7) // 8
    return struct.pack('>I', bits) + n.n.to_bytes(nb, 'big') + n.e.to_bytes(nb, 'big')

def _omac(key, t, data):
    c = cmac.CMAC(algorithms.AES(key)); c.update(bytes(15) + bytes([t]) + data); return c.finalize()

def eax_seal(key, nonce, ad, msg):
    n = _omac(key, 0, nonce); h = _omac(key, 1, ad)
    enc = Cipher(algorithms.AES(key), modes.CTR(n)).encryptor(); ct = enc.update(msg) + enc.finalize()
    c = _omac(key, 2, ct); return ct + bytes(a ^ b ^ d for a, b, d in zip(n, h, c))

def eax_open(key, nonce, ad, blob):
    ct, tag = blob[:-16], blob[-16:]
    n = _omac(key, 0, nonce); h = _omac(key, 1, ad); c = _omac(key, 2, ct)
    if bytes(a ^ b ^ d for a, b, d in zip(n, h, c)) != tag: raise ValueError('EAX tag mismatch')
    dec = Cipher(algorithms.AES(key), modes.CTR(n)).decryptor(); return dec.update(ct) + dec.finalize()

class Dir:
    def __init__(self, key): self.key = key; self.ctr = 0
    def nonce(self): return self.ctr.to_bytes(16, 'little')
    def seal(self, msg):
        ad = struct.pack('>H', len(msg)); out = ad + eax_seal(self.key, self.nonce(), ad, msg); self.ctr += 1; return out
    def open(self, length, blob):
        m = eax_open(self.key, self.nonce(), struct.pack('>H', length), blob); self.ctr += 1; return m

class EncConn:
    """Socket-like wrapper: RA2-framed after the handshake (types 5/129)."""
    def __init__(self, sock, rx, tx): self.s = sock; self.rx = rx; self.tx = tx; self.buf = b''
    def _recvn(self, n):
        b = b''
        while len(b) < n:
            d = self.s.recv(n - len(b))
            if not d: raise EOFError
            b += d
        return b
    def recv(self, n):
        if not self.buf:
            ln = struct.unpack('>H', self._recvn(2))[0]; self.buf = self.rx.open(ln, self._recvn(ln + 16))
        d, self.buf = self.buf[:n], self.buf[n:]; return d
    def sendall(self, data):
        for i in range(0, len(data), 8192): self.s.sendall(self.tx.seal(data[i:i + 8192]))
    def close(self): self.s.close()

def handshake(sock, sectype, user, password, recvn, ev, subtype=None):
    """Runs the RA2 handshake on `sock` (already past type selection). Returns (conn_for_rest, ok)."""
    big = sectype in (129, 130, 133)
    sha = hashlib.sha256 if big else hashlib.sha1
    keylen = 32 if big else 16
    priv = server_key(); spub = pub_wire(priv.public_key()); sb = priv.key_size // 8
    sock.sendall(spub)
    cbits = struct.unpack('>I', recvn(sock, 4))[0]; cb = (cbits + 7) // 8
    cn = int.from_bytes(recvn(sock, cb), 'big'); ce = int.from_bytes(recvn(sock, cb), 'big')
    cpub_numbers = rsa.RSAPublicNumbers(ce, cn); cpub = cpub_numbers.public_key(); cpub_wire = struct.pack('>I', cbits) + cn.to_bytes(cb, 'big') + ce.to_bytes(cb, 'big')
    ev(type='ra2', step='clientkey', bits=cbits)
    ln = struct.unpack('>H', recvn(sock, 2))[0]
    if ln != sb: raise ValueError('bad client random length %d' % ln)
    crand = priv.decrypt(recvn(sock, ln), padding.PKCS1v15())
    if len(crand) != keylen: raise ValueError('client random has %d bytes, expected %d' % (len(crand), keylen))
    srand = os.urandom(keylen); enc = cpub.encrypt(srand, padding.PKCS1v15()); sock.sendall(struct.pack('>H', len(enc)) + enc)
    ck = sha(srand + crand).digest()[:keylen]; sk = sha(crand + srand).digest()[:keylen]
    rx, tx = Dir(ck), Dir(sk)                       # server receives with the client key, sends with the server key
    ln = struct.unpack('>H', recvn(sock, 2))[0]; chash = rx.open(ln, recvn(sock, ln + 16))
    if chash != sha(cpub_wire + spub).digest(): raise ValueError('client hash mismatch')
    sock.sendall(tx.seal(sha(spub + cpub_wire).digest()))
    if subtype is None: subtype = 1 if user else 2
    sock.sendall(tx.seal(bytes([subtype])))
    ln = struct.unpack('>H', recvn(sock, 2))[0]; cred = rx.open(ln, recvn(sock, ln + 16))
    ul = cred[0]; u = cred[1:1 + ul].decode(); pl = cred[1 + ul]; p = cred[2 + ul:2 + ul + pl].decode()
    ok = (p == (password if subtype != 3 else '')) and (u == (user or ''))
    ev(type='ra2', step='credentials', subtype=subtype, user=u, ok=ok)
    encrypted = sectype in (5, 129, 13, 133)
    if sectype in (13, 133):          # two-step: fresh randoms exchanged inside the AES-EAX channel, counters restart
        ln = struct.unpack('>H', recvn(sock, 2))[0]
        if ln != keylen: raise ValueError('bad round-2 client random length')
        crand2 = rx.open(ln, recvn(sock, ln + 16)); srand2 = os.urandom(keylen)
        sock.sendall(tx.seal(srand2))
        rx, tx = Dir(sha(srand2 + crand2).digest()[:keylen]), Dir(sha(crand2 + srand2).digest()[:keylen])
        ev(type='ra2', step='rekey')
    res = struct.pack('>I', 0 if ok else 1)
    if encrypted: sock.sendall(tx.seal(res))
    else: sock.sendall(res)
    if not ok:
        reason = b'Authentication failed'
        msg = struct.pack('>I', len(reason)) + reason
        sock.sendall(tx.seal(msg) if encrypted else msg)
        return None, False
    return (EncConn(sock, rx, tx) if encrypted else sock), True
