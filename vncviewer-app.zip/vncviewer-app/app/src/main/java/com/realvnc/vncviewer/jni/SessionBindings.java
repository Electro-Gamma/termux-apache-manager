package com.realvnc.vncviewer.jni;
import java.nio.ByteBuffer; import java.util.Map;
public class SessionBindings {
  public static class Session { private long token; public Session(long t) { token = t; } public long getToken() { return token; } public void setToken(long t) { token = t; } }
  public interface DesktopCallback { void connSuccess(); void bell(); String getClipboard(); void setClipboard(String s); void setCursor(Object bmp, int hx, int hy);
    void setDesktopSize(int w, int h); void drawRegion(int x, int y, int w, int h); void framebufferUpdateEnd(); }
  public interface SessionCallback { void sessionClosed(Session s); }
  public static native Session createSession(DesktopCallback d, SessionCallback c, String addr, String uuid, Map<String, String> opts);
  public static native void closeSession(Session s); public static native void destroySession(Session s);
  public static native void pointerEvent(Session s, int x, int y, int mask); public static native void wheelEvent(Session s, int horiz, int delta);
  public static native void keyDownEvent(Session s, long keysym, int uni); public static native void keyUpEvent(Session s, int keysym);
  public static native void focusEvent(Session s, boolean f); public static native void applyOptions(Session s);
  public static native int authRetriesAllowed(Session s); public static native int authRetriesRemaining(Session s);
  public static native void setOption(Session s, String k, String v);
  public static native ByteBuffer setScaleBufferSize(Session s, int w, int h);
  public static native void copyScaledRegion(float scale, Session s, int x, int y, int w, int h);
  public static native void getScaledPixels(float scale, Session s, ByteBuffer b);
  public static native void getScaledBitmap(float scale, Session s, Object bmp);
}
