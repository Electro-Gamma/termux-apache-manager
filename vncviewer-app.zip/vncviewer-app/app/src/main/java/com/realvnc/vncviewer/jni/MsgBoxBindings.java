package com.realvnc.vncviewer.jni;
public class MsgBoxBindings {
  public interface MsgBox {} public interface MsgBoxFactory { MsgBox createMsgBox(SessionBindings.Session s, long handle, String msg, int type, String title); }
  public static native void setMsgBoxFactory(Object f); public static native void msgBoxResult(long h, boolean ok);
}
