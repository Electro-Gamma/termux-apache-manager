package com.realvnc.vncviewer.jni;
public class SymbolBindings { public static native int unicodeToKeysym(int c); public static native int keysymToUnicode(int k); }
