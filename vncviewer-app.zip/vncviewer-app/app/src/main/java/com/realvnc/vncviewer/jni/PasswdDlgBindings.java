package com.realvnc.vncviewer.jni;
public class PasswdDlgBindings {
  public interface PasswdDlg {} public interface PasswdDlgFactory { PasswdDlg createPasswdDlg(SessionBindings.Session s, long handle, String msg); }
  public static native void setPasswdDlgFactory(Object f); public static native void passwdResult(long h, boolean ok, String user, String pass);
}
