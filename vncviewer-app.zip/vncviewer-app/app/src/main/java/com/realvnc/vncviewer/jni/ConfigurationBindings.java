package com.realvnc.vncviewer.jni;
public class ConfigurationBindings { public static native String get(String n); public static native boolean getBoolean(String n); public static native long getS64(String n);
  public static native void set(String n, String v, int p, boolean b); public static native void unset(String n, int p, boolean b); }
