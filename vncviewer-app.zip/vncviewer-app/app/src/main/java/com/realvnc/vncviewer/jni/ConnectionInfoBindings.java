package com.realvnc.vncviewer.jni;
public class ConnectionInfoBindings {
  public static native String getDesktopName(SessionBindings.Session s); public static native String getDesktopSize(SessionBindings.Session s);
  public static native String getProtoVersion(SessionBindings.Session s); public static native String getSecurityDesc(SessionBindings.Session s);
  public static native String getLastUsedEncoding(SessionBindings.Session s); public static native String getServerPixelFormat(SessionBindings.Session s);
  public static native String getViewerPixelFormat(SessionBindings.Session s); public static native String getConnectionType(SessionBindings.Session s);
}
