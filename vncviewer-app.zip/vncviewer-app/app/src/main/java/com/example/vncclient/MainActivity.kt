package com.example.vncclient

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val host = findViewById<EditText>(R.id.host); val port = findViewById<EditText>(R.id.port)
        val viewOnly = findViewById<CheckBox>(R.id.viewOnly); val status = findViewById<TextView>(R.id.status)
        val prefs = getSharedPreferences("vnc", MODE_PRIVATE)
        host.setText(prefs.getString("host", "")); port.setText(prefs.getString("port", "5900"))
        status.text = "Direct RFB (VNC) connections only. Cloud/RealVNC sign-in is not supported."
        findViewById<Button>(R.id.connect).setOnClickListener {
            val h = host.text.toString().trim(); val p = port.text.toString().trim().ifEmpty { "5900" }
            if (h.isEmpty()) { status.text = "Enter a host"; return@setOnClickListener }
            prefs.edit().putString("host", h).putString("port", p).apply()
            startActivity(Intent(this, ViewerActivity::class.java)
                .putExtra("host", h).putExtra("port", p.toIntOrNull() ?: 5900).putExtra("viewOnly", viewOnly.isChecked))
        }
    }
}
