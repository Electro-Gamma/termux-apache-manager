package com.example.vncclient

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.text.InputType
import android.view.KeyEvent
import android.view.Menu
import android.view.MenuItem
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class ViewerActivity : AppCompatActivity(), VncSession.Listener {
    private lateinit var view: VncView
    private lateinit var keys: EditText
    private var session: VncSession? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_viewer)
        view = findViewById(R.id.vnc); keys = findViewById(R.id.keys)
        val host = intent.getStringExtra("host") ?: return finish()
        val port = intent.getIntExtra("port", 5900)
        title = "Connecting to $host…"
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val s = VncSession("$host::$port", mapOf("ViewOnly" to if (intent.getBooleanExtra("viewOnly", false)) "1" else "0"), this)
        session = s; view.session = s
        s.localClipboard = cm.primaryClip?.getItemAt(0)?.text?.toString() ?: ""
        s.start()
        // Soft keyboard: typed characters -> keysyms; special keys via onKeyDown.
        keys.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(e: android.text.Editable?) {}
            override fun beforeTextChanged(t: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(t: CharSequence?, start: Int, before: Int, count: Int) {
                if (t == null) return
                repeat(before) { s.key(0xff08, true); s.key(0xff08, false) }                // BackSpace
                var i = start; while (i < start + count) { val cp = Character.codePointAt(t, i); s.typeChar(cp); i += Character.charCount(cp) }
                if (t.length > 64) keys.setText("")
            }
        })
        keys.setOnKeyListener { _, code, ev -> forwardKey(code, ev) }
    }

    private fun forwardKey(code: Int, ev: KeyEvent): Boolean {
        val ks = when (code) {
            KeyEvent.KEYCODE_ENTER -> 0xff0d; KeyEvent.KEYCODE_DEL -> return false /* handled by TextWatcher */
            KeyEvent.KEYCODE_TAB -> 0xff09; KeyEvent.KEYCODE_ESCAPE -> 0xff1b
            KeyEvent.KEYCODE_DPAD_LEFT -> 0xff51; KeyEvent.KEYCODE_DPAD_UP -> 0xff52
            KeyEvent.KEYCODE_DPAD_RIGHT -> 0xff53; KeyEvent.KEYCODE_DPAD_DOWN -> 0xff54
            else -> return false
        }
        session?.key(ks, ev.action == KeyEvent.ACTION_DOWN); return true
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menu.add(0, 1, 0, "Keyboard").setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM)
        menu.add(0, 2, 1, "Ctrl+Alt+Del"); menu.add(0, 3, 2, "Right-click mode"); menu.add(0, 4, 3, "Disconnect")
        return true
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            1 -> { keys.requestFocus(); (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(keys, InputMethodManager.SHOW_FORCED) }
            2 -> session?.let { s -> listOf(0xffe3, 0xffe9, 0xffff).forEach { s.key(it, true) }; listOf(0xffff, 0xffe9, 0xffe3).forEach { s.key(it, false) } }
            3 -> { view.rightClickNext = true; Toast.makeText(this, "Next tap is a right-click", Toast.LENGTH_SHORT).show() }
            4 -> finish()
        }
        return true
    }

    override fun onConnected() { title = session?.desktopName() ?: "Connected"; keys.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS; session?.focus(true) }
    override fun onDesktopSize(w: Int, h: Int) = view.onDesktopSize(w, h)
    override fun onFramebufferUpdated() = view.invalidateFramebuffer()
    override fun onBell() { Toast.makeText(this, "Bell", Toast.LENGTH_SHORT).show() }
    override fun onServerClipboard(text: String) {
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("VNC", text))
    }
    override fun onClosed() { Toast.makeText(this, "Disconnected", Toast.LENGTH_SHORT).show(); finish() }
    override fun onMessage(text: String) { Toast.makeText(this, text, Toast.LENGTH_LONG).show() }
    override fun onPasswordRequired(handle: Long, message: String) {
        val input = EditText(this).apply { inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }
        AlertDialog.Builder(this).setTitle(message.ifEmpty { "Password" }).setView(input).setCancelable(false)
            .setPositiveButton("OK") { _, _ -> session?.answerPassword(handle, true, input.text.toString()) }
            .setNegativeButton("Cancel") { _, _ -> session?.answerPassword(handle, false, "") }.show()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) { super.onWindowFocusChanged(hasFocus); session?.focus(hasFocus) }
    override fun onDestroy() { session?.close(); session = null; super.onDestroy() }
}
