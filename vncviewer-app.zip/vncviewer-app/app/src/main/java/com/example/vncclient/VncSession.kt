package com.example.vncclient

import android.os.Handler
import android.os.Looper
import com.realvnc.vncviewer.jni.*
import com.realvnc.vncviewer.jni.SessionBindings.Session

/** Thin Kotlin wrapper over the native libvncviewer JNI bindings. Callbacks arrive on native threads; they are marshalled to the UI thread. */
class VncSession(
    private val address: String,
    private val options: Map<String, String>,
    private val listener: Listener,
) {
    interface Listener {
        fun onConnected()
        fun onDesktopSize(w: Int, h: Int)
        fun onFramebufferUpdated()
        fun onBell()
        fun onServerClipboard(text: String)
        fun onClosed()
        fun onMessage(text: String)
        /** Called on the UI thread; call [answerPassword] with the result. */
        fun onPasswordRequired(handle: Long, message: String)
    }

    companion object {
        init { System.loadLibrary("vncviewer") }
        private val ui = Handler(Looper.getMainLooper())
    }

    @Volatile private var session: Session? = null
    @Volatile private var closed = false
    @Volatile var localClipboard: String = ""

    private val desktop = object : SessionBindings.DesktopCallback {
        override fun connSuccess() { ui.post { listener.onConnected() } }
        override fun bell() { ui.post { listener.onBell() } }
        override fun getClipboard(): String = localClipboard
        override fun setClipboard(s: String?) { if (s != null) ui.post { listener.onServerClipboard(s) } }
        override fun setCursor(bmp: Any?, hx: Int, hy: Int) { /* remote cursor not drawn; local touch pointer used */ }
        override fun setDesktopSize(w: Int, h: Int) { ui.post { listener.onDesktopSize(w, h) } }
        override fun drawRegion(x: Int, y: Int, w: Int, h: Int) {}
        override fun framebufferUpdateEnd() { ui.post { listener.onFramebufferUpdated() } }
    }
    private val callback = SessionBindings.SessionCallback { ui.post { if (!closed) { closed = true; listener.onClosed() } } }

    fun start() {
        PasswdDlgBindings.setPasswdDlgFactory(PasswdDlgBindings.PasswdDlgFactory { _, handle, msg ->
            ui.post { listener.onPasswordRequired(handle, msg ?: "") }
            object : PasswdDlgBindings.PasswdDlg {}
        })
        MsgBoxBindings.setMsgBoxFactory(MsgBoxBindings.MsgBoxFactory { _, handle, msg, _, _ ->
            ui.post { listener.onMessage(msg ?: "") }
            MsgBoxBindings.msgBoxResult(handle, true)
            object : MsgBoxBindings.MsgBox {}
        })
        session = SessionBindings.createSession(desktop, callback, address, java.util.UUID.randomUUID().toString(), HashMap(options))
    }

    fun answerPassword(handle: Long, ok: Boolean, password: String) = PasswdDlgBindings.passwdResult(handle, ok, "", password)

    // ---- display
    fun sizeString(): String? = session?.let { ConnectionInfoBindings.getDesktopSize(it) }
    fun desktopName(): String? = session?.let { ConnectionInfoBindings.getDesktopName(it) }
    fun drawInto(scale: Float, bmp: android.graphics.Bitmap) { session?.let { SessionBindings.getScaledBitmap(scale, it, bmp) } }

    // ---- input (desktop coordinates)
    fun pointer(x: Int, y: Int, mask: Int) { session?.let { SessionBindings.pointerEvent(it, x, y, mask) } }
    fun wheel(horizontal: Boolean, delta: Int) { session?.let { SessionBindings.wheelEvent(it, if (horizontal) 1 else 0, delta) } }
    fun key(keysym: Int, down: Boolean) {
        val s = session ?: return
        if (down) SessionBindings.keyDownEvent(s, keysym.toLong() and 0xffffffffL, 0) else SessionBindings.keyUpEvent(s, keysym)
    }
    fun typeChar(cp: Int) { val ks = SymbolBindings.unicodeToKeysym(cp); if (ks != 0) { key(ks, true); key(ks, false) } }
    fun focus(f: Boolean) { session?.let { SessionBindings.focusEvent(it, f) } }
    fun setViewOnly(v: Boolean) { session?.let { SessionBindings.setOption(it, "ViewOnly", if (v) "1" else "0") } }

    fun close() {
        val s = session ?: return
        closed = true
        SessionBindings.closeSession(s)
        // destroy off the UI thread; never from inside a native callback
        Thread { SessionBindings.destroySession(s) }.start()
        session = null
    }
}
