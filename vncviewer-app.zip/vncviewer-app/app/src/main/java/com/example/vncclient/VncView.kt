package com.example.vncclient

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import kotlin.math.max
import kotlin.math.min

/** Displays the remote framebuffer (fit-to-view with pinch zoom/pan) and turns touch gestures into RFB pointer events.
 *  Tap = left click, long-press+drag = left drag, two-finger drag = scroll wheel, pinch = zoom, tap after "right-click mode" = right click. */
class VncView @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : View(c, a) {
    var session: VncSession? = null
    @Volatile var rightClickNext = false
    private var dw = 0; private var dh = 0
    private var bmp: Bitmap? = null; private var bmpScale = 0f
    private var zoom = 1f; private var panX = 0f; private var panY = 0f     // extra zoom/pan on top of fit
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val m = Matrix()

    fun onDesktopSize(w: Int, h: Int) { dw = w; dh = h; bmp = null; invalidateFramebuffer() }
    fun invalidateFramebuffer() { invalidate() }

    private fun fit(): Float = if (dw == 0 || dh == 0 || width == 0) 1f else min(width.toFloat() / dw, height.toFloat() / dh)
    private fun viewScale(): Float = fit() * zoom
    // The native side scales down only; keep the bitmap at <= 1.0 and let the Canvas upscale.
    private fun nativeScale(): Float = min(1f, viewScale())

    override fun onDraw(canvas: Canvas) {
        val s = session ?: return
        if (dw == 0 || dh == 0) return
        val ns = nativeScale(); val bw = max(1, (dw * ns).toInt()); val bh = max(1, (dh * ns).toInt())
        var b = bmp
        if (b == null || b.width != bw || b.height != bh) { b = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888); bmp = b }
        s.drawInto(ns, b)
        val vs = viewScale(); val sx = vs * dw / bw; val sy = vs * dh / bh
        val ox = (width - vs * dw) / 2f + panX; val oy = (height - vs * dh) / 2f + panY
        m.reset(); m.postScale(sx, sy); m.postTranslate(ox, oy)
        canvas.drawBitmap(b, m, paint)
    }

    private fun toDesktopX(x: Float) = ((x - (width - viewScale() * dw) / 2f - panX) / viewScale()).toInt().coerceIn(0, max(0, dw - 1))
    private fun toDesktopY(y: Float) = ((y - (height - viewScale() * dh) / 2f - panY) / viewScale()).toInt().coerceIn(0, max(0, dh - 1))

    private var dragging = false; private var lastScrollY = 0f
    private val scale = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean { zoom = (zoom * d.scaleFactor).coerceIn(1f, 6f); if (zoom == 1f) { panX = 0f; panY = 0f }; invalidate(); return true }
    })
    private val gestures = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onSingleTapUp(e: MotionEvent): Boolean {
            val x = toDesktopX(e.x); val y = toDesktopY(e.y); val btn = if (rightClickNext) 4 else 1; rightClickNext = false
            session?.apply { pointer(x, y, btn); pointer(x, y, 0) }; return true
        }
        override fun onDoubleTap(e: MotionEvent): Boolean {
            val x = toDesktopX(e.x); val y = toDesktopY(e.y)
            session?.apply { pointer(x, y, 1); pointer(x, y, 0) }; return true      // 2nd click of the double-click
        }
        override fun onLongPress(e: MotionEvent) { dragging = true; session?.pointer(toDesktopX(e.x), toDesktopY(e.y), 1) }
    })

    override fun onTouchEvent(e: MotionEvent): Boolean {
        scale.onTouchEvent(e)
        if (scale.isInProgress) return true
        gestures.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_MOVE -> when {
                e.pointerCount >= 2 -> {
                    val y = (e.getY(0) + e.getY(1)) / 2f
                    if (zoom > 1f) { /* pan when zoomed */ }
                    else if (lastScrollY != 0f) { val d = y - lastScrollY; if (kotlin.math.abs(d) > 24f) { session?.wheel(false, if (d > 0) -1 else 1); lastScrollY = y } }
                    if (lastScrollY == 0f) lastScrollY = y
                }
                dragging -> session?.pointer(toDesktopX(e.x), toDesktopY(e.y), 1)
                zoom > 1f && e.historySize > 0 -> { panX += e.x - e.getHistoricalX(0); panY += e.y - e.getHistoricalY(0); invalidate() }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { if (dragging) { session?.pointer(toDesktopX(e.x), toDesktopY(e.y), 0); dragging = false }; lastScrollY = 0f }
        }
        return true
    }
}
