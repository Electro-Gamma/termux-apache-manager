#include "util.h"
#ifdef __ANDROID__
#include <android/log.h>
#endif

void* operator new(size_t n) { void* p = malloc(n ? n : 1); if (!p) abort(); return p; }
void* operator new[](size_t n) { void* p = malloc(n ? n : 1); if (!p) abort(); return p; }
void operator delete(void* p) noexcept { free(p); }
void operator delete[](void* p) noexcept { free(p); }
void operator delete(void* p, size_t) noexcept { free(p); }
void operator delete[](void* p, size_t) noexcept { free(p); }

#if defined(__ANDROID__) && defined(VNCR_DEFINE_DSO_HANDLE)
// Normally supplied by crtbegin_so.o of a full NDK; needed when building with a bare toolchain.
extern "C" __attribute__((visibility("hidden"))) void* __dso_handle = &__dso_handle;
#endif

namespace vr {

static volatile int g_logLevel = LOG_INFO;
void setLogLevel(int l) { g_logLevel = l; }
int logLevel() { return g_logLevel; }

void logf(int level, const char* fmt, ...) {
  if (level > g_logLevel) return;
  char buf[1024];
  va_list ap; va_start(ap, fmt); vsnprintf(buf, sizeof buf, fmt, ap); va_end(ap);
#ifdef __ANDROID__
  static const int prio[] = {ANDROID_LOG_INFO, ANDROID_LOG_ERROR, ANDROID_LOG_WARN, ANDROID_LOG_INFO, ANDROID_LOG_DEBUG};
  __android_log_write(prio[level > 4 ? 4 : level], "vncviewer", buf);
#else
  fprintf(stderr, "[vncviewer:%d] %s\n", level, buf);
#endif
}

Str strf(const char* fmt, ...) {
  char buf[1024];
  va_list ap; va_start(ap, fmt); vsnprintf(buf, sizeof buf, fmt, ap); va_end(ap);
  return Str(buf);
}

size_t utf8ToLatin1(const char* in, u8* out, size_t outMax) {
  size_t o = 0; const u8* s = (const u8*)in;
  while (*s && o < outMax) {
    u32 cp; int len;
    if (*s < 0x80) { cp = *s; len = 1; }
    else if ((*s & 0xe0) == 0xc0 && (s[1] & 0xc0) == 0x80) { cp = ((*s & 0x1f) << 6) | (s[1] & 0x3f); len = 2; }
    else if ((*s & 0xf0) == 0xe0 && (s[1] & 0xc0) == 0x80 && (s[2] & 0xc0) == 0x80) { cp = ((*s & 0x0f) << 12) | ((s[1] & 0x3f) << 6) | (s[2] & 0x3f); len = 3; }
    else if ((*s & 0xf8) == 0xf0 && (s[1] & 0xc0) == 0x80 && (s[2] & 0xc0) == 0x80 && (s[3] & 0xc0) == 0x80) { cp = 0x10000; len = 4; }
    else { cp = '?'; len = 1; }
    out[o++] = cp < 0x100 ? (u8)cp : '?';
    s += len;
  }
  return o;
}

Str latin1ToUtf8(const u8* in, size_t n) {
  char* out = (char*)malloc(n * 2 + 1); if (!out) abort();
  size_t o = 0;
  for (size_t i = 0; i < n; i++) {
    u8 c = in[i];
    if (c == 0) { out[o++] = ' '; continue; }
    if (c < 0x80) out[o++] = (char)c;
    else { out[o++] = (char)(0xc0 | (c >> 6)); out[o++] = (char)(0x80 | (c & 0x3f)); }
  }
  out[o] = 0;
  Str r; r.s = out; return r;
}

bool parseBool(const char* v, bool def) {
  if (!v || !*v) return def;
  if (!strcasecmp(v, "1") || !strcasecmp(v, "true") || !strcasecmp(v, "yes") || !strcasecmp(v, "on")) return true;
  if (!strcasecmp(v, "0") || !strcasecmp(v, "false") || !strcasecmp(v, "no") || !strcasecmp(v, "off")) return false;
  return def;
}
long parseInt(const char* v, long def) {
  if (!v || !*v) return def;
  char* e; long r = strtol(v, &e, 0);
  return (e == v) ? def : r;
}

}  // namespace vr
