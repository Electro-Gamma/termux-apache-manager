// RFB client session: connection thread, protocol, decoders, input, scaled framebuffer copies.
#include "session.h"
#include "des.h"
#include <errno.h>
#include <fcntl.h>
#include <netdb.h>
#include <poll.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <unistd.h>
#ifdef __ANDROID__
#include <android/bitmap.h>
#else
extern "C" {  // provided by the host test shim
int AndroidBitmap_getInfo(JNIEnv*, jobject, void*);
int AndroidBitmap_lockPixels(JNIEnv*, jobject, void**);
int AndroidBitmap_unlockPixels(JNIEnv*, jobject);
}
struct AndroidBitmapInfo { uint32_t width, height, stride; int32_t format; uint32_t flags; };
#endif

namespace vr {

static const int kMaxDim = 16384;
static const size_t kMaxFbPixels = 64u * 1024 * 1024;

// ---------------------------------------------------------------- registries
struct Registry { Mutex m; Vec<Session*> sessions; u64 next = 1; Vec<Prompt*> prompts; Cond cv; u64 nextPrompt = 1;
                  Vec<KV> passwords; };
static Registry& reg() { static Registry* r = new Registry; return *r; }

void sessionInitGlobals() { (void)reg(); }

Session* sessionFind(u64 id) {
  Lock l(reg().m);
  for (size_t i = 0; i < reg().sessions.n; i++) if (reg().sessions[i]->id == id) return reg().sessions[i];
  return nullptr;
}
Session* sessionFromObject(JNIEnv* env, jobject obj) {
  if (!obj || !G.sessionGetToken) return nullptr;
  jlong t = env->CallLongMethod(obj, G.sessionGetToken);
  if (env->ExceptionCheck()) { env->ExceptionClear(); return nullptr; }
  return sessionFind((u64)t);
}

u64 promptCreate(Session* s) {
  Lock l(reg().m);
  Prompt* p = new Prompt; p->handle = reg().nextPrompt++; p->session = s;
  reg().prompts.push(p); return p->handle;
}
Prompt* promptWait(u64 handle, Session* s) {
  Lock l(reg().m);
  for (;;) {
    Prompt* f = nullptr;
    for (size_t i = 0; i < reg().prompts.n; i++) if (reg().prompts[i]->handle == handle) f = reg().prompts[i];
    if (!f) return nullptr;
    if (f->done) return f;
    if (s->closing) return nullptr;
    reg().cv.wait(reg().m);
  }
}
void promptRelease(u64 handle) {
  Lock l(reg().m);
  for (size_t i = 0; i < reg().prompts.n; i++) if (reg().prompts[i]->handle == handle) { delete reg().prompts[i]; reg().prompts.erase(i); return; }
}
void promptAnswer(u64 handle, bool ok, const char* user, const char* pass, bool f2, bool f3) {
  Lock l(reg().m);
  for (size_t i = 0; i < reg().prompts.n; i++) {
    Prompt* p = reg().prompts[i];
    if (p->handle == handle) { p->ok = ok; p->user = user; p->pass = pass; p->flag2 = f2; p->flag3 = f3; p->done = true; }
  }
  reg().cv.signal();
}
void promptAbortSession(Session*) { Lock l(reg().m); reg().cv.signal(); }

Str storeGetPassword(const char* key) {
  Lock l(reg().m);
  for (size_t i = 0; i < reg().passwords.n; i++) if (reg().passwords[i].k.eq(key)) return reg().passwords[i].v;
  return Str();
}
void storeSetPassword(const char* key, const char* pw) {
  Lock l(reg().m);
  for (size_t i = 0; i < reg().passwords.n; i++) if (reg().passwords[i].k.eq(key)) { reg().passwords[i].v = pw; return; }
  KV kv; kv.k = key; kv.v = pw; reg().passwords.push(kv);
}
void storeRemovePassword(const char* key) {
  Lock l(reg().m);
  for (size_t i = 0; i < reg().passwords.n; i++) if (reg().passwords[i].k.eq(key)) { reg().passwords.erase(i); return; }
}
void storeClearPasswords() { Lock l(reg().m); reg().passwords.clear(); }

// ---------------------------------------------------------------- Session basics
Session::Session() { memset(&zs, 0, sizeof zs); }
Session::~Session() {
  if (zInit) inflateEnd(&zs);
  free(scaleBuf);
  for (size_t i = 0; i < retired.n; i++) free(retired[i]);
  if (fd >= 0) close(fd);
  if (wake[0] >= 0) close(wake[0]);
  if (wake[1] >= 0) close(wake[1]);
}

Str Session::getOpt(const char* key, const char* def) {
  Lock l(optMutex);
  for (size_t i = 0; i < opts.n; i++) if (opts[i].k.eqi(key)) return opts[i].v;
  return Str(def);
}
void Session::setOpt(const char* key, const char* val) {
  Lock l(optMutex);
  for (size_t i = 0; i < opts.n; i++) if (opts[i].k.eqi(key)) { opts[i].v = val; return; }
  KV kv; kv.k = key; kv.v = val; opts.push(kv);
}

// ---------------------------------------------------------------- I/O
bool Session::waitFd(short ev) {
  for (;;) {
    struct pollfd p[2] = {{fd, ev, 0}, {wake[0], POLLIN, 0}};
    int r = poll(p, 2, -1);
    if (r < 0) { if (errno == EINTR) continue; return false; }
    if (p[1].revents) return false;                 // close requested
    if (p[0].revents & (ev | POLLERR | POLLHUP)) return true;
  }
}
bool Session::readn(void* dst, size_t n) {
  u8* d = (u8*)dst;
  while (n) {
    if (inPos < inLen) {
      size_t k = inLen - inPos; if (k > n) k = n;
      memcpy(d, inbuf + inPos, k); inPos += k; d += k; n -= k; continue;
    }
    if (closing) { ioFail = true; return false; }
    ssize_t r = recv(fd, inbuf, sizeof inbuf, 0);
    if (r > 0) { inPos = 0; inLen = (size_t)r; continue; }
    if (r == 0) { ioFail = true; if (closeReason.empty()) closeReason = "The connection was closed by the remote computer."; return false; }
    if (errno == EINTR) continue;
    if (errno == EAGAIN || errno == EWOULDBLOCK) { if (!waitFd(POLLIN)) { ioFail = true; return false; } continue; }
    ioFail = true; if (closeReason.empty()) closeReason = strf("Network error: %s", strerror(errno)); return false;
  }
  return true;
}
bool Session::skip(size_t n) {
  u8 tmp[1024];
  while (n) { size_t k = n > sizeof tmp ? sizeof tmp : n; if (!readn(tmp, k)) return false; n -= k; }
  return true;
}
u8 Session::rd8() { u8 v = 0; readn(&v, 1); return v; }
u16 Session::rd16() { u8 b[2] = {0, 0}; readn(b, 2); return (u16)((b[0] << 8) | b[1]); }
u32 Session::rd32() { u8 b[4] = {0, 0, 0, 0}; readn(b, 4); return ((u32)b[0] << 24) | (b[1] << 16) | (b[2] << 8) | b[3]; }

bool Session::sendAll(const void* d, size_t n) {
  Lock l(sendMutex);
  const u8* p = (const u8*)d;
  while (n) {
    if (fd < 0) return false;
    ssize_t r = send(fd, p, n, MSG_NOSIGNAL);
    if (r > 0) { p += r; n -= r; continue; }
    if (r < 0 && errno == EINTR) continue;
    if (r < 0 && (errno == EAGAIN || errno == EWOULDBLOCK)) { if (!waitFd(POLLOUT)) return false; continue; }
    return false;
  }
  return true;
}

// ---------------------------------------------------------------- connect
bool Session::connectTcp(Str* err) {
  // Address forms: host, host:port, host::port (absolute port), [v6]:port; port < 100 means display number.
  char host[256]; int port = 5900;
  const char* a = address.c();
  if (*a == '[') {
    const char* e = strchr(a, ']'); if (!e || (size_t)(e - a) >= sizeof host) { *err = "Invalid address"; return false; }
    size_t n = e - a - 1; memcpy(host, a + 1, n); host[n] = 0;
    if (e[1] == ':') { const char* q = e + 2; bool abs = false; if (*q == ':') { abs = true; q++; } long v = atol(q); port = (abs || v >= 100) ? (int)v : 5900 + (int)v; }
  } else {
    const char* c = strchr(a, ':');
    size_t n = c ? (size_t)(c - a) : strlen(a);
    if (n == 0 || n >= sizeof host) { *err = "Invalid address"; return false; }
    memcpy(host, a, n); host[n] = 0;
    if (c) {
      if (strchr(c + 1, ':') && c[1] != ':') {   // bare IPv6 literal
        snprintf(host, sizeof host, "%s", a);
      } else { const char* q = c + 1; bool abs = false; if (*q == ':') { abs = true; q++; } long v = atol(q); port = (abs || v >= 100) ? (int)v : 5900 + (int)v; }
    }
  }
  if (port <= 0 || port > 65535) { *err = "Invalid port"; return false; }
  char ps[16]; snprintf(ps, sizeof ps, "%d", port);
  struct addrinfo hints; memset(&hints, 0, sizeof hints); hints.ai_socktype = SOCK_STREAM;
  struct addrinfo* res = nullptr;
  int gr = getaddrinfo(host, ps, &hints, &res);
  if (gr != 0) { *err = strf("Cannot resolve host '%s': %s", host, gai_strerror(gr)); return false; }
  Str last = "Connection failed";
  for (struct addrinfo* ai = res; ai; ai = ai->ai_next) {
    int s = socket(ai->ai_family, ai->ai_socktype, ai->ai_protocol);
    if (s < 0) continue;
    fcntl(s, F_SETFL, fcntl(s, F_GETFL) | O_NONBLOCK);
    int one = 1; setsockopt(s, IPPROTO_TCP, TCP_NODELAY, &one, sizeof one);
    int r = connect(s, ai->ai_addr, ai->ai_addrlen);
    if (r < 0 && errno == EINPROGRESS) {
      long tmo = parseInt(getOpt("ConnectTimeout", "15").c(), 15) * 1000;
      struct pollfd p[2] = {{s, POLLOUT, 0}, {wake[0], POLLIN, 0}};
      int pr;
      do { pr = poll(p, 2, (int)tmo); } while (pr < 0 && errno == EINTR);
      if (pr > 0 && p[1].revents) { close(s); freeaddrinfo(res); *err = "Cancelled"; return false; }
      if (pr <= 0) { close(s); last = "Connection timed out"; continue; }
      int soerr = 0; socklen_t sl = sizeof soerr; getsockopt(s, SOL_SOCKET, SO_ERROR, &soerr, &sl);
      if (soerr) { close(s); last = strf("Connection failed: %s", strerror(soerr)); continue; }
    } else if (r < 0) { last = strf("Connection failed: %s", strerror(errno)); close(s); continue; }
    fd = s; inPos = inLen = 0; ioFail = false;
    freeaddrinfo(res); return true;
  }
  freeaddrinfo(res); *err = last; return false;
}

// ---------------------------------------------------------------- dialogs
void Session::showError(const char* msg) {
  logf(LOG_WARN, "session %llu error: %s", (unsigned long long)id, msg);
  if (!env || !G.msgBoxFactory || !G.createMsgBox || closing) return;
  u64 h = promptCreate(this);
  jstring m = newStr(env, msg), t = newStr(env, "VNC Viewer");
  jobject dlg = env->CallObjectMethod(G.msgBoxFactory, G.createMsgBox, sessionObj, (jlong)h, m, (jint)0, t);
  if (env->ExceptionCheck()) { env->ExceptionClear(); }
  env->DeleteLocalRef(m); env->DeleteLocalRef(t);
  if (dlg) { promptWait(h, this); env->DeleteLocalRef(dlg); }
  promptRelease(h);
}

bool Session::askPassword(const char* msg, Str* out) {
  if (!env || !G.passwdFactory || !G.createPasswdDlg) return false;
  u64 h = promptCreate(this);
  jstring m = newStr(env, msg);
  jobject dlg = env->CallObjectMethod(G.passwdFactory, G.createPasswdDlg, sessionObj, (jlong)h, m);
  if (env->ExceptionCheck()) { env->ExceptionClear(); }
  env->DeleteLocalRef(m);
  bool ok = false;
  if (dlg) {
    Prompt* p = promptWait(h, this);
    if (p && p->ok) { *out = p->pass.c(); ok = true; }
    env->DeleteLocalRef(dlg);
  }
  promptRelease(h);
  return ok;
}

// ---------------------------------------------------------------- handshake
bool Session::handshake(Str* err, bool* retry) {
  *retry = false;
  char ver[13] = {0};
  if (!readn(ver, 12)) { *err = closeReason.empty() ? "No response from server" : closeReason.c(); return false; }
  int maj = 0, min = 0;
  if (strncmp(ver, "RFB ", 4) || sscanf(ver + 4, "%d.%d", &maj, &min) != 2) { *err = "The remote computer is not an RFB (VNC) server."; return false; }
  int cmaj = 3, cmin = min >= 8 ? 8 : (min == 7 ? 7 : 3);
  if (maj < 3) { *err = "Unsupported RFB protocol version"; return false; }
  Str pv = getOpt("ProtocolVersion", "");
  if (pv.eq("3.3")) cmin = 3; else if (pv.eq("3.7") && min >= 7) cmin = 7; else if (pv.eq("3.8") && min >= 8) cmin = 8;
  verMajor = cmaj; verMinor = cmin;
  char cv[13]; snprintf(cv, sizeof cv, "RFB 003.%03d\n", cmin);
  if (!sendAll(cv, 12)) { *err = "Network error"; return false; }

  int sec = 0;
  if (cmin == 3) {
    u32 t = rd32(); if (ioFail) { *err = closeReason.c(); return false; }
    if (t == 0) { u32 n = rd32(); Bytes b; if (n < 4096 && b.resize(n + 1) && readn(b.p, n)) { b.p[n] = 0; *err = (const char*)b.p; } else *err = "Connection refused"; return false; }
    sec = (int)t;
  } else {
    u8 n = rd8(); if (ioFail) { *err = closeReason.c(); return false; }
    if (n == 0) { u32 l = rd32(); Bytes b; if (l < 4096 && b.resize(l + 1) && readn(b.p, l)) { b.p[l] = 0; *err = (const char*)b.p; } else *err = "Connection refused"; return false; }
    u8 types[256]; if (!readn(types, n)) { *err = closeReason.c(); return false; }
    bool has1 = false, has2 = false;
    for (int i = 0; i < n; i++) { if (types[i] == 1) has1 = true; if (types[i] == 2) has2 = true; }
    sec = has2 ? 2 : (has1 ? 1 : 0);
    if (!sec) { *err = "The remote computer requires an authentication method this viewer does not support."; return false; }
    u8 c = (u8)sec; if (!sendAll(&c, 1)) { *err = "Network error"; return false; }
  }
  secType = sec;
  if (sec == 1) {
    secDesc = "None (connection is not encrypted)";
    if (cmin >= 8) { u32 r = rd32(); if (ioFail) { *err = closeReason.c(); return false; } if (r != 0) { *err = "Security negotiation failed"; return false; } }
  } else if (sec == 2) {
    secDesc = "VNC password authentication (connection is not encrypted)";
    u8 ch[16]; if (!readn(ch, 16)) { *err = closeReason.c(); return false; }
    Str pw;
    bool have = false;
    if (authFailures == 0) { Str o = getOpt("Password", ""); if (!o.empty()) { pw = o; have = true; } }
    if (!have && authFailures == 0 && !uuid.empty()) { Str sp = storeGetPassword(uuid.c()); if (!sp.empty()) { pw = sp; have = true; } }
    if (!have) {
      if (!askPassword(authFailures ? "Password incorrect" : "", &pw)) { *err = closing ? "Cancelled" : "Password not provided"; return false; }
    }
    u8 resp[16]; vncAuthResponse(pw.c(), ch, resp);
    if (!sendAll(resp, 16)) { *err = "Network error"; return false; }
    u32 r = rd32(); if (ioFail) { *err = closeReason.c(); return false; }
    if (r != 0) {
      authFailures++;
      Str why = "Password incorrect";
      if (cmin >= 8) { u32 l = rd32(); Bytes b; if (l < 4096 && b.resize(l + 1) && readn(b.p, l)) { b.p[l] = 0; if (l) why = (const char*)b.p; } }
      if (authFailures < authAllowed) { *retry = true; }
      *err = why; return false;
    }
    if (!uuid.empty() && !pw.empty()) storeSetPassword(uuid.c(), pw.c());
  } else { *err = "Unsupported security type"; return false; }
  return true;
}

// ---------------------------------------------------------------- setup messages
static void put16(u8* p, int v) { p[0] = (u8)(v >> 8); p[1] = (u8)v; }
static void put32(u8* p, u32 v) { p[0] = (u8)(v >> 24); p[1] = (u8)(v >> 16); p[2] = (u8)(v >> 8); p[3] = (u8)v; }

bool Session::sendSetup() {
  u8 m[20] = {0};
  m[0] = 0; m[4] = 32; m[5] = 24; m[6] = 0; m[7] = 1;
  put16(m + 8, 255); put16(m + 10, 255); put16(m + 12, 255);
  m[14] = 0; m[15] = 8; m[16] = 16;
  if (!sendAll(m, 20)) return false;
  viewerPF = PixelFormat();
  return true;
}

static void encodingList(const char* pref, int* out, int* n) {
  int k = 0;
  int pe = -1;
  if (!strcasecmp(pref, "ZRLE")) pe = 16; else if (!strcasecmp(pref, "Hextile")) pe = 5;
  else if (!strcasecmp(pref, "RRE")) pe = 2; else if (!strcasecmp(pref, "Raw")) pe = 0;
  if (pe >= 0) out[k++] = pe;
  static const int base[] = {16, 5, 1, 2, 0};
  for (int b : base) if (b != pe) out[k++] = b;
  out[k++] = -239; out[k++] = -223; out[k++] = -308; out[k++] = -224;
  *n = k;
}

void Session::applyOptions() {
  if (!connected) return;
  int enc[16], n; Str pref = getOpt("PreferredEncoding", "ZRLE");
  encodingList(pref.c(), enc, &n);
  u8 buf[4 + 16 * 4]; buf[0] = 2; buf[1] = 0; put16(buf + 2, n);
  for (int i = 0; i < n; i++) put32(buf + 4 + 4 * i, (u32)enc[i]);
  sendAll(buf, 4 + 4 * n);
}

bool Session::sendUpdateRequest(bool incremental) {
  u8 m[10]; m[0] = 3; m[1] = incremental ? 1 : 0;
  put16(m + 2, 0); put16(m + 4, 0); put16(m + 6, fbW); put16(m + 8, fbH);
  return sendAll(m, 10);
}

// ---------------------------------------------------------------- Java callbacks
void Session::cbDesktopSize() {
  if (!env || !desktopCb || !mSetDesktopSize) return;
  env->CallVoidMethod(desktopCb, mSetDesktopSize, (jint)fbW, (jint)fbH);
  if (env->ExceptionCheck()) env->ExceptionClear();
}
void Session::cbDraw(int x, int y, int w, int h) {
  if (!env || !desktopCb || !mDrawRegion) return;
  env->CallVoidMethod(desktopCb, mDrawRegion, (jint)x, (jint)y, (jint)w, (jint)h);
  if (env->ExceptionCheck()) env->ExceptionClear();
}

// ---------------------------------------------------------------- framebuffer
bool Session::resizeFb(int w, int h) {
  if (w <= 0 || h <= 0 || w > kMaxDim || h > kMaxDim || (size_t)w * h > kMaxFbPixels) { closeReason = "Unsupported desktop size"; return false; }
  {
    Lock l(fbMutex);
    if (!fb.resize((size_t)w * h * 4)) { closeReason = "Out of memory"; return false; }
    memset(fb.p, 0, fb.n); fbW = w; fbH = h;
  }
  return true;
}

void Session::fillRect(int x, int y, int w, int h, const u8* px) {
  for (int r = 0; r < h; r++) {
    u8* d = fb.p + ((size_t)(y + r) * fbW + x) * 4;
    for (int c = 0; c < w; c++) memcpy(d + c * 4, px, 4);
  }
}

bool Session::decRaw(int x, int y, int w, int h) {
  const int chunk = 16;
  for (int r = 0; r < h; r += chunk) {
    int rows = h - r < chunk ? h - r : chunk;
    Bytes tmp; if (!tmp.resize((size_t)rows * w * 4)) return false;
    if (!readn(tmp.p, tmp.n)) return false;
    Lock l(fbMutex);
    for (int i = 0; i < rows; i++) memcpy(fb.p + ((size_t)(y + r + i) * fbW + x) * 4, tmp.p + (size_t)i * w * 4, (size_t)w * 4);
  }
  return true;
}

bool Session::decCopyRect(int x, int y, int w, int h) {
  int sx = rd16(), sy = rd16(); if (ioFail) return false;
  if (sx + w > fbW || sy + h > fbH) { closeReason = "Invalid CopyRect source"; return false; }
  Lock l(fbMutex);
  Bytes tmp; if (!tmp.resize((size_t)w * h * 4)) return false;
  for (int r = 0; r < h; r++) memcpy(tmp.p + (size_t)r * w * 4, fb.p + ((size_t)(sy + r) * fbW + sx) * 4, (size_t)w * 4);
  for (int r = 0; r < h; r++) memcpy(fb.p + ((size_t)(y + r) * fbW + x) * 4, tmp.p + (size_t)r * w * 4, (size_t)w * 4);
  return true;
}

bool Session::decRRE(int x, int y, int w, int h, bool corre) {
  u32 n = rd32(); u8 bg[4]; if (!readn(bg, 4)) return false;
  size_t per = corre ? 8 : 12;
  if ((size_t)n > (size_t)w * h) { closeReason = "Invalid RRE data"; return false; }
  Bytes tmp; if (!tmp.resize(n * per)) return false;
  if (n && !readn(tmp.p, tmp.n)) return false;
  Lock l(fbMutex);
  fillRect(x, y, w, h, bg);
  for (u32 i = 0; i < n; i++) {
    const u8* p = tmp.p + i * per; int sx, sy, sw, sh;
    if (corre) { sx = p[4]; sy = p[5]; sw = p[6]; sh = p[7]; }
    else { sx = (p[4] << 8) | p[5]; sy = (p[6] << 8) | p[7]; sw = (p[8] << 8) | p[9]; sh = (p[10] << 8) | p[11]; }
    if (sx + sw > w || sy + sh > h) { closeReason = "Invalid RRE subrectangle"; return false; }
    fillRect(x + sx, y + sy, sw, sh, p);
  }
  return true;
}

bool Session::decHextile(int x, int y, int w, int h) {
  u8 bg[4] = {0, 0, 0, 0}, fg[4] = {0, 0, 0, 0};
  for (int ty = 0; ty < h; ty += 16) for (int tx = 0; tx < w; tx += 16) {
    int tw = w - tx < 16 ? w - tx : 16, th = h - ty < 16 ? h - ty : 16;
    u8 sub = rd8(); if (ioFail) return false;
    if (sub & 1) {
      Bytes tmp; if (!tmp.resize((size_t)tw * th * 4) || !readn(tmp.p, tmp.n)) return false;
      Lock l(fbMutex);
      for (int r = 0; r < th; r++) memcpy(fb.p + ((size_t)(y + ty + r) * fbW + x + tx) * 4, tmp.p + (size_t)r * tw * 4, (size_t)tw * 4);
      continue;
    }
    if (sub & 2) if (!readn(bg, 4)) return false;
    if (sub & 4) if (!readn(fg, 4)) return false;
    int ns = 0; if (sub & 8) ns = rd8();
    size_t per = (sub & 16) ? 6 : 2;
    Bytes tmp; if (!tmp.resize((size_t)ns * per)) return false;
    if (ns && !readn(tmp.p, tmp.n)) return false;
    if (ioFail) return false;
    Lock l(fbMutex);
    fillRect(x + tx, y + ty, tw, th, bg);
    for (int i = 0; i < ns; i++) {
      const u8* p = tmp.p + (size_t)i * per; const u8* col = fg; const u8* g = p;
      if (sub & 16) { col = p; g = p + 4; }
      int sx = g[0] >> 4, sy = g[0] & 15, sw = (g[1] >> 4) + 1, sh = (g[1] & 15) + 1;
      if (sx + sw > tw || sy + sh > th) { closeReason = "Invalid Hextile subrectangle"; return false; }
      fillRect(x + tx + sx, y + ty + sy, sw, sh, col);
    }
  }
  return true;
}

bool Session::decZrle(int x, int y, int w, int h) {
  u32 len = rd32(); if (ioFail) return false;
  if (len > (64u << 20)) { closeReason = "ZRLE data too large"; return false; }
  Bytes comp; if (!comp.resize(len) || !readn(comp.p, len)) return false;
  if (!zInit) { memset(&zs, 0, sizeof zs); if (inflateInit(&zs) != Z_OK) { closeReason = "zlib init failed"; return false; } zInit = true; }
  Bytes out; size_t maxOut = (size_t)w * h * 4 + (size_t)((w + 63) / 64) * ((h + 63) / 64) * 4096 + 65536;
  zs.next_in = comp.p; zs.avail_in = len;
  while (zs.avail_in) {
    if (!out.reserve(out.n + 65536)) return false;
    zs.next_out = out.p + out.n; zs.avail_out = (uInt)(out.cap - out.n);
    int r = inflate(&zs, Z_SYNC_FLUSH);
    out.n = out.cap - zs.avail_out;
    if (r != Z_OK && r != Z_BUF_ERROR && r != Z_STREAM_END) { closeReason = "ZRLE decompression error"; return false; }
    if (out.n > maxOut) { closeReason = "ZRLE output too large"; return false; }
    if (r == Z_BUF_ERROR && zs.avail_in == 0) break;
  }
  const u8* p = out.p; const u8* end = out.p + out.n;
  Lock l(fbMutex);
  for (int ty = 0; ty < h; ty += 64) for (int tx = 0; tx < w; tx += 64) {
    int tw = w - tx < 64 ? w - tx : 64, th = h - ty < 64 ? h - ty : 64;
    if (p >= end) goto bad;
    {
      u8 st = *p++; bool rle = st & 128; int ps = st & 127;
      u8 pal[128][4];
      #define CP(dst, src) do { (dst)[0] = (src)[0]; (dst)[1] = (src)[1]; (dst)[2] = (src)[2]; (dst)[3] = 0xff; } while (0)
      u8* base = fb.p + ((size_t)(y + ty) * fbW + x + tx) * 4;
      size_t rs = (size_t)fbW * 4;
      if (!rle && ps == 0) {
        if ((size_t)(end - p) < (size_t)tw * th * 3) goto bad;
        for (int r = 0; r < th; r++) for (int c = 0; c < tw; c++) { CP(base + r * rs + c * 4, p); p += 3; }
      } else if (!rle && ps == 1) {
        if (end - p < 3) goto bad; u8 px[4]; CP(px, p); p += 3;
        fillRect(x + tx, y + ty, tw, th, px);
      } else if (!rle && ps >= 2 && ps <= 16) {
        if ((end - p) < ps * 3) goto bad;
        for (int i = 0; i < ps; i++) { CP(pal[i], p); p += 3; }
        int bits = ps <= 2 ? 1 : (ps <= 4 ? 2 : 4);
        for (int r = 0; r < th; r++) {
          int need = (tw * bits + 7) / 8; if (end - p < need) goto bad;
          int bitpos = 0;
          for (int c = 0; c < tw; c++) {
            int byte = bitpos >> 3, sh = 8 - bits - (bitpos & 7);
            int idx = (p[byte] >> sh) & ((1 << bits) - 1); bitpos += bits;
            if (idx >= ps) goto bad;
            memcpy(base + r * rs + c * 4, pal[idx], 4);
          }
          p += need;
        }
      } else if (rle && ps == 0) {
        int pos = 0, total = tw * th;
        while (pos < total) {
          if (end - p < 3) goto bad; u8 px[4]; CP(px, p); p += 3;
          int run = 1; for (;;) { if (p >= end) goto bad; int b = *p++; run += b; if (b != 255) break; }
          if (run > total - pos) goto bad;
          while (run--) { memcpy(base + (pos / tw) * rs + (pos % tw) * 4, px, 4); pos++; }
        }
      } else if (rle && ps >= 2) {
        if (ps > 127 || (end - p) < ps * 3) goto bad;
        for (int i = 0; i < ps; i++) { CP(pal[i], p); p += 3; }
        int pos = 0, total = tw * th;
        while (pos < total) {
          if (p >= end) goto bad; int idx = *p++; int run = 1;
          if (idx & 128) { idx &= 127; for (;;) { if (p >= end) goto bad; int b = *p++; run += b; if (b != 255) break; } }
          if (idx >= ps || run > total - pos) goto bad;
          while (run--) { memcpy(base + (pos / tw) * rs + (pos % tw) * 4, pal[idx], 4); pos++; }
        }
      } else goto bad;
    }
  }
  return true;
bad:
  closeReason = "Invalid ZRLE data"; return false;
}

bool Session::decCursor(int hx, int hy, int w, int h) {
  if (w < 0 || h < 0 || w > 512 || h > 512) { closeReason = "Invalid cursor size"; return false; }
  size_t pix = (size_t)w * h * 4, mask = (size_t)((w + 7) / 8) * h;
  Bytes d; if (!d.resize(pix + mask)) return false;
  if (d.n && !readn(d.p, d.n)) return false;
  if (!env || !desktopCb || !mSetCursor) return true;
  if (w == 0 || h == 0 || !G.bitmapCls || !G.bitmapCreate || !G.argb8888) {
    env->CallVoidMethod(desktopCb, mSetCursor, (jobject) nullptr, (jint)hx, (jint)hy);
    if (env->ExceptionCheck()) env->ExceptionClear();
    return true;
  }
  jobject bmp = env->CallStaticObjectMethod(G.bitmapCls, G.bitmapCreate, (jint)w, (jint)h, G.argb8888);
  if (env->ExceptionCheck()) { env->ExceptionClear(); return true; }
  if (!bmp) return true;
  AndroidBitmapInfo info; void* addr = nullptr;
  if (AndroidBitmap_getInfo(env, bmp, &info) == 0 && AndroidBitmap_lockPixels(env, bmp, &addr) == 0 && addr) {
    for (int r = 0; r < h; r++) {
      u8* o = (u8*)addr + (size_t)r * info.stride;
      for (int c = 0; c < w; c++) {
        bool on = d.p[pix + (size_t)r * ((w + 7) / 8) + (c >> 3)] & (0x80 >> (c & 7));
        const u8* s = d.p + ((size_t)r * w + c) * 4;
        if (c * 4 + 3 >= (int)info.stride) break;
        o[c * 4] = on ? s[0] : 0; o[c * 4 + 1] = on ? s[1] : 0; o[c * 4 + 2] = on ? s[2] : 0; o[c * 4 + 3] = on ? 0xff : 0;
      }
    }
    AndroidBitmap_unlockPixels(env, bmp);
    env->CallVoidMethod(desktopCb, mSetCursor, bmp, (jint)hx, (jint)hy);
    if (env->ExceptionCheck()) env->ExceptionClear();
  }
  env->DeleteLocalRef(bmp);
  return true;
}

bool Session::decExtDesktopSize(int reason, int status, int w, int h) {
  u8 hdr[4]; if (!readn(hdr, 4)) return false;
  if (!skip((size_t)hdr[0] * 16)) return false;
  if (status != 0 && reason != 0) return true;   // failed client-initiated change
  if (w != fbW || h != fbH) { if (!resizeFb(w, h)) return false; cbDesktopSize(); }
  return true;
}

bool Session::decodeRect(int x, int y, int w, int h, int enc) {
  switch (enc) {
    case -223: if (w != fbW || h != fbH) { if (!resizeFb(w, h)) return false; cbDesktopSize(); } return true;
    case -308: return decExtDesktopSize(x, y, w, h);
    case -239: return decCursor(x, y, w, h);
    case -224: return true;
  }
  if (x < 0 || y < 0 || w < 0 || h < 0 || x + w > fbW || y + h > fbH) { closeReason = "Rectangle outside framebuffer"; return false; }
  bool ok;
  switch (enc) {
    case 0: lastEncoding = "Raw"; ok = decRaw(x, y, w, h); break;
    case 1: lastEncoding = "CopyRect"; ok = decCopyRect(x, y, w, h); break;
    case 2: lastEncoding = "RRE"; ok = decRRE(x, y, w, h, false); break;
    case 4: lastEncoding = "CoRRE"; ok = decRRE(x, y, w, h, true); break;
    case 5: lastEncoding = "Hextile"; ok = decHextile(x, y, w, h); break;
    case 16: lastEncoding = "ZRLE"; ok = decZrle(x, y, w, h); break;
    default: closeReason = strf("Unsupported encoding %d", enc); return false;
  }
  if (ok && w && h) cbDraw(x, y, w, h);
  return ok;
}

bool Session::readUpdate() {
  rd8(); int n = rd16(); if (ioFail) return false;
  for (int i = 0; i < n; i++) {
    int x = rd16(), y = rd16(), w = rd16(), h = rd16(); int enc = (int)rd32();
    if (ioFail) return false;
    if (enc == -224) break;
    if (!decodeRect(x, y, w, h, enc)) return false;
  }
  if (env && desktopCb && mFbUpdateEnd) { env->CallVoidMethod(desktopCb, mFbUpdateEnd); if (env->ExceptionCheck()) env->ExceptionClear(); }
  return true;
}

bool Session::serverCutText() {
  u8 pad[3]; if (!readn(pad, 3)) return false;
  u32 n = rd32(); if (ioFail) return false;
  if (n > (1u << 20)) { return skip(n); }
  Bytes b; if (!b.resize(n) || (n && !readn(b.p, n))) return false;
  Str u = latin1ToUtf8(b.p, n);
  if (env && desktopCb && mSetClip) {
    lastClip = u.c();
    jstring js = env->NewStringUTF(u.c());
    env->CallVoidMethod(desktopCb, mSetClip, js);
    if (env->ExceptionCheck()) env->ExceptionClear();
    env->DeleteLocalRef(js);
  }
  return true;
}

void Session::sendCutText(const char* utf8) {
  if (!connected || !utf8) return;
  size_t cap = strlen(utf8); if (cap > (1u << 18)) cap = (1u << 18);
  Bytes m; if (!m.resize(8 + cap)) return;
  m.p[0] = 6; m.p[1] = m.p[2] = m.p[3] = 0;
  size_t n = utf8ToLatin1(utf8, m.p + 8, cap);
  put32(m.p + 4, (u32)n);
  sendAll(m.p, 8 + n);
}

bool Session::serverInitAndLoop(Str* err) {
  u8 init = parseBool(getOpt("Shared", "1").c(), true) ? 1 : 0;
  if (!sendAll(&init, 1)) { *err = "Network error"; return false; }
  int w = rd16(), h = rd16();
  u8 pf[16]; if (!readn(pf, 16)) { *err = closeReason.c(); return false; }
  u32 nl = rd32(); if (ioFail) { *err = closeReason.c(); return false; }
  if (nl > 65536) { *err = "Invalid desktop name"; return false; }
  Bytes nm; if (!nm.resize(nl + 1) || !readn(nm.p, nl)) { *err = closeReason.c(); return false; }
  nm.p[nl] = 0; desktopName = latin1ToUtf8(nm.p, nl);
  serverPF.bpp = pf[0]; serverPF.depth = pf[1]; serverPF.bigEndian = pf[2]; serverPF.trueColour = pf[3];
  serverPF.rMax = (pf[4] << 8) | pf[5]; serverPF.gMax = (pf[6] << 8) | pf[7]; serverPF.bMax = (pf[8] << 8) | pf[9];
  serverPF.rShift = pf[10]; serverPF.gShift = pf[11]; serverPF.bShift = pf[12];
  if (!resizeFb(w, h)) { *err = closeReason.empty() ? "Invalid desktop size" : closeReason.c(); return false; }
  if (!sendSetup()) { *err = "Network error"; return false; }
  connected = true;
  applyOptions();
  if (!sendUpdateRequest(false)) { *err = "Network error"; return false; }
  cbDesktopSize();
  if (env && desktopCb && mConnSuccess) { env->CallVoidMethod(desktopCb, mConnSuccess); if (env->ExceptionCheck()) env->ExceptionClear(); }
  for (;;) {
    u8 t; if (!readn(&t, 1)) { *err = closing ? "" : closeReason.c(); return closing; }
    switch (t) {
      case 0: if (!readUpdate()) { *err = closeReason.empty() ? "Protocol error" : closeReason.c(); return false; }
              if (!sendUpdateRequest(true)) { *err = "Network error"; return false; } break;
      case 1: { rd8(); int first = rd16(); (void)first; int cnt = rd16(); if (!skip((size_t)cnt * 6)) { *err = closeReason.c(); return false; } break; }
      case 2: if (env && desktopCb && mBell) { env->CallVoidMethod(desktopCb, mBell); if (env->ExceptionCheck()) env->ExceptionClear(); } break;
      case 3: if (!serverCutText()) { *err = closeReason.c(); return false; } break;
      default: *err = strf("Unknown server message type %d", t); return false;
    }
  }
}

// ---------------------------------------------------------------- thread
void Session::run() {
  bool att = false; env = attachThread(&att);
  Str err;
  bool ok = false;
  for (;;) {
    if (closing) break;
    if (!connectTcp(&err)) break;
    bool retry = false;
    if (handshake(&err, &retry)) { ok = serverInitAndLoop(&err); break; }
    close(fd); fd = -1; connected = false;
    if (!retry || closing) break;
    logf(LOG_INFO, "authentication failed (%d/%d), retrying", authFailures, authAllowed);
  }
  connected = false;
  if (!ok && !closing && !err.empty()) showError(err.c());
  if (fd >= 0) { shutdown(fd, SHUT_RDWR); }
  if (env && sessionCb && mSessionClosed) {
    env->CallVoidMethod(sessionCb, mSessionClosed, sessionObj);
    if (env->ExceptionCheck()) env->ExceptionClear();
  }
  finished = true;
  env = nullptr;
  if (att) detachThread();
}

static void* threadMain(void* p) { ((Session*)p)->run(); return nullptr; }

bool Session::start() {
  if (socketpair(AF_UNIX, SOCK_STREAM, 0, wake) != 0) return false;
  fcntl(wake[0], F_SETFL, fcntl(wake[0], F_GETFL) | O_NONBLOCK);
  if (pthread_create(&th, nullptr, threadMain, this) != 0) return false;
  threadStarted = true; return true;
}
void Session::requestClose() {
  closing = true;
  if (wake[1] >= 0) { char c = 1; ssize_t r = write(wake[1], &c, 1); (void)r; }
  promptAbortSession(this);
}
void Session::join() { if (threadStarted) { pthread_join(th, nullptr); threadStarted = false; } }

// ---------------------------------------------------------------- input
void Session::pointer(int x, int y, int mask) {
  int w = fbW, h = fbH;
  if (x > w - 1) x = w - 1; if (y > h - 1) y = h - 1; if (x < 0) x = 0; if (y < 0) y = 0;
  Lock l(inputMutex);
  ptrX = x; ptrY = y; buttons = mask;
  if (!connected || parseBool(getOpt("ViewOnly", "0").c(), false)) return;
  u8 m[6] = {5, (u8)mask}; put16(m + 2, x); put16(m + 4, y);
  sendAll(m, 6);
}
void Session::wheel(int horizontal, int delta) {
  if (!delta) return;
  static const int tbl[4] = {5, 4, 7, 6};
  int idx = ((delta > 0) ^ (horizontal ? 1 : 0)) + (horizontal ? 2 : 0);
  int bit = 1 << (tbl[idx] - 1);
  int n = delta < 0 ? -delta : delta; if (n > 100) n = 100;
  Lock l(inputMutex);
  if (!connected || parseBool(getOpt("ViewOnly", "0").c(), false)) return;
  for (int i = 0; i < n; i++) {
    u8 m[6] = {5, (u8)(buttons | bit)}; put16(m + 2, ptrX); put16(m + 4, ptrY); sendAll(m, 6);
    m[1] = (u8)buttons; sendAll(m, 6);
  }
}
void Session::keyEvent(bool down, u32 ks) {
  Lock l(inputMutex);
  if (down) { bool f = false; for (size_t i = 0; i < pressed.n; i++) if (pressed[i] == ks) f = true; if (!f) pressed.push(ks); }
  else for (size_t i = 0; i < pressed.n; i++) if (pressed[i] == ks) { pressed.erase(i); break; }
  if (!connected || parseBool(getOpt("ViewOnly", "0").c(), false)) return;
  u8 m[8] = {4, (u8)(down ? 1 : 0), 0, 0}; put32(m + 4, ks); sendAll(m, 8);
}
void Session::focusEvent(bool f) {
  if (f == focus) return;
  focus = f;
  if (!f) {
    Vec<u32> keys; { Lock l(inputMutex); keys = pressed; }
    for (size_t i = 0; i < keys.n; i++) keyEvent(false, keys[i]);
    return;
  }
  // Gained focus: forward the local clipboard to the server if it changed.
  JNIEnv* e = nullptr; bool att = false; e = attachThread(&att);
  if (e && desktopCb && mGetClip) {
    jstring js = (jstring)e->CallObjectMethod(desktopCb, mGetClip);
    if (e->ExceptionCheck()) e->ExceptionClear();
    else if (js) {
      const char* c = e->GetStringUTFChars(js, nullptr);
      if (c) { if (!lastClip.eq(c)) { lastClip = c; sendCutText(c); } e->ReleaseStringUTFChars(js, c); }
      e->DeleteLocalRef(js);
    }
  }
  if (att) detachThread();
}

// ---------------------------------------------------------------- scaled copy
void* Session::resizeScaleBuf(int w, int h) {
  if (w <= 0 || h <= 0 || (size_t)w * h > kMaxFbPixels) return nullptr;
  Lock l(fbMutex);
  u8* nb = (u8*)calloc((size_t)w * h, 4); if (!nb) return nullptr;
  if (scaleBuf) { retired.push(scaleBuf); if (retired.n > 4) { free(retired[0]); retired.erase(0); } }
  scaleBuf = nb; scaleW = w; scaleH = h; return nb;
}

void Session::scaledCopy(float scale, u8* dst, int stridepx, int rows, int x, int y, int w, int h) {
  if (!dst || stridepx <= 0 || rows <= 0) return;
  Lock l(fbMutex);
  int step = (scale > 0.f) ? (int)(1.0f / scale) : 1; if (step < 1) step = 1;
  memset(dst, 0, (size_t)stridepx * rows * 4);
  int x0 = x < 0 ? 0 : x, y0 = y < 0 ? 0 : y;
  int x1 = (x + w < fbW) ? x + w : fbW, y1 = (y + h < fbH) ? y + h : fbH;
  if (!fb.p) return;
  int dy = 0;
  for (int sy = y0; sy < y1 && dy < rows; sy += step, dy++) {
    u8* o = dst + (size_t)dy * stridepx * 4; int dx = 0;
    for (int sx = x0; sx < x1 && dx < stridepx; sx += step, dx++) {
      const u8* s = fb.p + ((size_t)sy * fbW + sx) * 4;
      o[dx * 4] = s[0]; o[dx * 4 + 1] = s[1]; o[dx * 4 + 2] = s[2]; o[dx * 4 + 3] = 0xff;
    }
  }
}

// ---------------------------------------------------------------- info strings
Str Session::desktopSizeStr() { Lock l(fbMutex); return strf("%d x %d", fbW, fbH); }

static int bitsOf(u32 max) { int b = 0; while (max) { b++; max >>= 1; } return b; }
Str Session::pixelFormatDesc(const PixelFormat& pf) {
  char b[160]; int n = snprintf(b, sizeof b, "depth %d (%d bpp)", pf.depth, pf.bpp);
  if (pf.bpp != 8) n += snprintf(b + n, sizeof b - n, " %s-endian", pf.bigEndian ? "big" : "little");
  if (!pf.trueColour) { snprintf(b + n, sizeof b - n, " colour-map"); return Str(b); }
  int rb = bitsOf(pf.rMax), gb = bitsOf(pf.gMax), bb = bitsOf(pf.bMax);
  bool p2 = (pf.rMax & (pf.rMax + 1)) == 0 && (pf.gMax & (pf.gMax + 1)) == 0 && (pf.bMax & (pf.bMax + 1)) == 0;
  if (p2 && pf.bShift == 0 && pf.gShift == bb && pf.rShift == bb + gb) snprintf(b + n, sizeof b - n, " rgb%d%d%d", rb, gb, bb);
  else if (p2 && pf.rShift == 0 && pf.gShift == rb && pf.bShift == rb + gb) snprintf(b + n, sizeof b - n, " bgr%d%d%d", bb, gb, rb);
  else snprintf(b + n, sizeof b - n, " rgb max %d,%d,%d shift %d,%d,%d", pf.rMax, pf.gMax, pf.bMax, pf.rShift, pf.gShift, pf.bShift);
  return Str(b);
}

// ---------------------------------------------------------------- create / destroy
Session* sessionCreate(JNIEnv* env, jobject desktopCb, jobject sessionCb, const char* address, const char* uuid,
                       const Vec<KV>& opts, jobject* sessionObjOut) {
  Session* s = new Session;
  s->address = address; s->uuid = uuid; s->opts = opts;
  s->desktopCb = env->NewGlobalRef(desktopCb); s->sessionCb = env->NewGlobalRef(sessionCb);
  jclass dc = env->GetObjectClass(desktopCb), sc = env->GetObjectClass(sessionCb);
  s->mConnSuccess = env->GetMethodID(dc, "connSuccess", "()V");
  s->mBell = env->GetMethodID(dc, "bell", "()V");
  s->mGetClip = env->GetMethodID(dc, "getClipboard", "()Ljava/lang/String;");
  s->mSetClip = env->GetMethodID(dc, "setClipboard", "(Ljava/lang/String;)V");
  s->mSetCursor = env->GetMethodID(dc, "setCursor", "(Ljava/lang/Object;II)V");
  s->mSetDesktopSize = env->GetMethodID(dc, "setDesktopSize", "(II)V");
  s->mDrawRegion = env->GetMethodID(dc, "drawRegion", "(IIII)V");
  s->mFbUpdateEnd = env->GetMethodID(dc, "framebufferUpdateEnd", "()V");
  s->mSessionClosed = env->GetMethodID(sc, "sessionClosed", "(Lcom/realvnc/vncviewer/jni/SessionBindings$Session;)V");
  if (env->ExceptionCheck()) { env->ExceptionClear(); logf(LOG_WARN, "some callback methods not found"); }
  env->DeleteLocalRef(dc); env->DeleteLocalRef(sc);
  { Lock l(reg().m); s->id = reg().next++; reg().sessions.push(s); }
  jobject local = env->NewObject(G.sessionCls, G.sessionInit, (jlong)s->id);
  if (!local || env->ExceptionCheck()) { sessionDestroy(env, s); return nullptr; }
  s->sessionObj = env->NewGlobalRef(local);
  *sessionObjOut = local;
  if (!s->start()) { sessionDestroy(env, s); *sessionObjOut = nullptr; return nullptr; }
  return s;
}

void sessionDestroy(JNIEnv* env, Session* s) {
  { Lock l(reg().m); for (size_t i = 0; i < reg().sessions.n; i++) if (reg().sessions[i] == s) { reg().sessions.erase(i); break; } }
  s->requestClose();
  if (s->threadStarted && pthread_equal(pthread_self(), s->th)) {
    // Called from the session's own callback: it cannot join itself. Leak-free deferral is not worth the
    // complexity; detach the thread and let the OS reclaim it, freeing everything after the callback returns.
    pthread_detach(s->th); s->threadStarted = false;
    return;   // Session memory is reclaimed at process exit in this (rare) path.
  }
  s->join();
  if (env) {
    if (s->desktopCb) env->DeleteGlobalRef(s->desktopCb);
    if (s->sessionCb) env->DeleteGlobalRef(s->sessionCb);
    if (s->sessionObj) env->DeleteGlobalRef(s->sessionObj);
  }
  delete s;
}

}  // namespace vr
