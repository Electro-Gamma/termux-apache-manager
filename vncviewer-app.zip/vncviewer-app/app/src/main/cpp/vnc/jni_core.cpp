// JNI_OnLoad, thread attach, keysym mapping, Bindings / Configuration / Symbol / AppURL exports.
#include "jni_common.h"
#include "session.h"
#include <stdint.h>

#define JF(ret, name, ...) extern "C" __attribute__((visibility("default"))) ret Java_com_realvnc_vncviewer_jni_##name(JNIEnv* env, jobject, ##__VA_ARGS__)
#define UNUSED(x) (void)(x)

namespace vr {

JniGlobals G;

// AttachCurrentThread takes JNIEnv** in the Android NDK but void** in the JDK headers; accept both.
template <class V> static auto doAttach(V* vm, JNIEnv** e, int) -> decltype(vm->AttachCurrentThread(e, nullptr)) { return vm->AttachCurrentThread(e, nullptr); }
template <class V> static jint doAttach(V* vm, JNIEnv** e, long) { return vm->AttachCurrentThread((void**)e, nullptr); }

JNIEnv* attachThread(bool* attached) {
  *attached = false;
  if (!G.vm) return nullptr;
  JNIEnv* e = nullptr;
  jint r = G.vm->GetEnv((void**)&e, JNI_VERSION_1_4);
  if (r == JNI_OK) return e;
  if (r == JNI_EDETACHED && doAttach(G.vm, &e, 0) == JNI_OK) { *attached = true; return e; }
  return nullptr;
}
void detachThread() { if (G.vm) G.vm->DetachCurrentThread(); }

void throwJava(JNIEnv* env, const char* cls, const char* msg) {
  if (env->ExceptionCheck()) return;
  jclass c = env->FindClass(cls);
  if (c) { env->ThrowNew(c, msg); env->DeleteLocalRef(c); }
}
void replaceGlobalRef(JNIEnv* env, jobject* slot, jobject obj) {
  if (*slot) env->DeleteGlobalRef(*slot);
  *slot = obj ? env->NewGlobalRef(obj) : nullptr;
}

// ---------------------------------------------------------------- keysyms
#include "keysym_tables.inc"
static u32 lookup2(const uint32_t (*t)[2], size_t n, u32 key, int keyCol, u32* val) {
  // last entry wins (the original loads into a std::map with overwrite semantics)
  bool f = false;
  for (size_t i = 0; i < n; i++) if (t[i][keyCol] == key) { *val = t[i][1 - keyCol]; f = true; }
  return f;
}
u32 unicodeToKeysym(u32 cp) {
  if ((cp - 0x20) < 0x5f || (cp - 0xa0) < 0x60) return cp;
  u32 v;
  if (lookup2(kKeysymUnicode, sizeof kKeysymUnicode / sizeof *kKeysymUnicode, cp, 1, &v)) return v;
  if (cp - 0x100 > 0x10feff) return 0;
  return cp | 0x1000000;
}
static u32 canonKeysym(u32 ks) {
  u32 r = ks;
  if (((ks >> 21) & 0x7ff) == 8) r = unicodeToKeysym(ks & 0x1fffff);
  u32 v;
  if (lookup2(kKeysymCanon, sizeof kKeysymCanon / sizeof *kKeysymCanon, r, 0, &v)) r = v;
  return r;
}
u32 keysymToUnicode(u32 ks) {
  auto latin = [](u32 c) -> u32 { return ((c - 0x20) < 0x5f || (c - 0xa0) < 0x60) ? c : 0; };
  if (ks < 0x100) return latin(ks);
  ks = canonKeysym(ks);
  if (ks < 0x100) return latin(ks);
  if ((ks >> 21) == 8) return ks & 0x1fffff;
  u32 v;
  if (lookup2(kKeysymUnicode, sizeof kKeysymUnicode / sizeof *kKeysymUnicode, ks, 0, &v)) return v;
  return 0;
}

// ---------------------------------------------------------------- configuration store
struct Param { const char* name; const char* def; };
static const Param kParams[] = {
  {"ViewOnly", "0"}, {"Shared", "1"}, {"PreferredEncoding", "ZRLE"}, {"ColorLevel", "full"}, {"Quality", "auto"},
  {"Scaling", "fit"}, {"ProtocolVersion", "3.8"}, {"Locale", ""}, {"PointerEventInterval", "0"},
  {"WarnUnencrypted", "1"}, {"ProxyType", "none"}, {"ProxyServer", ""}, {"ProxyUserName", ""}, {"ProxyPassword", ""},
  {"AllowCloudRelay", "1"}, {"EnableUdpRfb", "0"}, {"EnableChat", "0"}, {"ServerClipboardGraceTime", "5"},
  {"SendInitialClipboard", "1"}, {"FullScreen", "0"}, {"PasswordMasterTimeout", "0"}, {"ConnectTimeout", "15"},
};
static Vec<KV>& cfg() { static Vec<KV>* v = nullptr; if (!v) { v = new Vec<KV>; for (const Param& p : kParams) { KV kv; kv.k = p.name; kv.v = p.def; v->push(kv); } } return *v; }
static Mutex& cfgMutex() { static Mutex* m = new Mutex; return *m; }
static KV* cfgFind(const char* k) { Vec<KV>& c = cfg(); for (size_t i = 0; i < c.n; i++) if (c[i].k.eq(k)) return &c[i]; return nullptr; }

}  // namespace vr
using namespace vr;

extern "C" __attribute__((visibility("default"))) jint JNI_OnLoad(JavaVM* vm, void*) {
  G.vm = vm;
  sessionInitGlobals(); { Lock l(cfgMutex()); (void)cfg(); }   // create lazily-built globals before threads exist
  JNIEnv* env = nullptr;
  if (vm->GetEnv((void**)&env, JNI_VERSION_1_4) != JNI_OK) return JNI_ERR;
  return JNI_VERSION_1_4;
}

// ---------------------------------------------------------------- Bindings
static Str g_appDir, g_dataDir, g_name;
static bool g_appInit = false, g_vwrInit = false;

JF(void, Bindings_initVwr, jobject, jobject, jobject, jobject) { UNUSED(env); g_vwrInit = true; logf(LOG_INFO, "viewer initialised"); }
JF(void, Bindings_initApp, jstring a, jstring b, jstring c, jobject, jobject, jobject, jobject, jobject, jboolean dbg, jobject) {
  JStr sa(env, a), sb(env, b), sc(env, c);
  if (!g_appInit) { g_name = sa.get(); g_appDir = sb.get(); g_dataDir = sc.get(); g_appInit = true; }
  if (dbg) setLogLevel(LOG_DEBUG);
  logf(LOG_INFO, "app initialised (replacement library)");
}
JF(void, Bindings_enableFileLogging, jboolean on) { UNUSED(env); UNUSED(on); /* file logging is not implemented; logcat only */ }
JF(jstring, Bindings_loc, jstring key) { JStr k(env, key); return newStr(env, k.get()); }
JF(jstring, Bindings_loc1, jstring key, jstring arg) {
  JStr k(env, key), a(env, arg);
  // No translation catalogue is available: substitute the first %s/%S/%1$S placeholder, else return the key.
  const char* t = k.get(); Str out = strf("%s", t);
  const char* pos = strstr(t, "%1$S"); size_t plen = 4;
  if (!pos) { pos = strstr(t, "%s"); plen = 2; }
  if (pos) { out = strf("%.*s%s%s", (int)(pos - t), t, a.get(), pos + plen); }
  return newStr(env, out.c());
}
JF(void, Bindings_log, jint level, jstring tag, jstring msg) {
  JStr t(env, tag), m(env, msg);
  int l = level <= 1 ? LOG_ERR : (level == 2 ? LOG_WARN : (level <= 4 ? LOG_INFO : LOG_DEBUG));
  logf(l, "%s: %s", t.get(), m.get());
}

// ---------------------------------------------------------------- Configuration
JF(jstring, ConfigurationBindings_get, jstring name) {
  JStr n(env, name); Lock l(cfgMutex()); KV* kv = cfgFind(n.get());
  if (!kv) { throwRuntime(env, strf("Parameter '%s' not found", n.get()).c()); return nullptr; }
  return newStr(env, kv->v.c());
}
JF(jboolean, ConfigurationBindings_getBoolean, jstring name) {
  JStr n(env, name); Lock l(cfgMutex()); KV* kv = cfgFind(n.get());
  if (!kv) { throwRuntime(env, strf("Parameter '%s' not found", n.get()).c()); return JNI_FALSE; }
  return parseBool(kv->v.c(), false) ? JNI_TRUE : JNI_FALSE;
}
JF(jlong, ConfigurationBindings_getS64, jstring name) {
  JStr n(env, name); Lock l(cfgMutex()); KV* kv = cfgFind(n.get());
  if (!kv) { throwRuntime(env, strf("Parameter '%s' not found", n.get()).c()); return 0; }
  return (jlong)strtoll(kv->v.c(), nullptr, 0);
}
JF(void, ConfigurationBindings_set, jstring name, jstring value, jint prio, jboolean persist) {
  UNUSED(prio); UNUSED(persist);
  JStr n(env, name), v(env, value); if (!n.ok()) return;
  Lock l(cfgMutex()); KV* kv = cfgFind(n.get());
  if (kv) kv->v = v.get(); else { KV x; x.k = n.get(); x.v = v.get(); cfg().push(x); }
}
JF(void, ConfigurationBindings_unset, jstring name, jint prio, jboolean persist) {
  UNUSED(prio); UNUSED(persist);
  JStr n(env, name); Lock l(cfgMutex());
  for (const Param& p : kParams) if (!strcmp(p.name, n.get())) { KV* kv = cfgFind(p.name); if (kv) kv->v = p.def; return; }
  Vec<KV>& c = cfg(); for (size_t i = 0; i < c.n; i++) if (c[i].k.eq(n.get())) { c.erase(i); return; }
}

// ---------------------------------------------------------------- Symbol / AppURL
JF(jint, SymbolBindings_unicodeToKeysym, jint cp) { UNUSED(env); return (jint)unicodeToKeysym((u32)cp); }
JF(jint, SymbolBindings_keysymToUnicode, jint ks) { UNUSED(env); return (jint)keysymToUnicode((u32)ks); }

JF(jstring, AppURLBindings_getAppURL, jstring key) {
  JStr k(env, key); const char* base = "https://www.realvnc.com";
  struct E { const char* k; const char* path; };
  static const E t[] = {{"VNC_URL_BASE", ""}, {"PRIVACY_URL", "/legal/#privacy"}, {"SIGNUP_URL", "/sign-up"},
    {"FIND_OUT_MORE_URL", "/sign-up#benefits"}, {"MANAGE_ACCOUNT_URL", "/profile"}, {"FORGOT_URL", "/forgot-password"},
    {"FORGOT_SERVER_PASSWORD_URL", "/doclink/forgot-server-password"}, {"TERMS_URL", "/legal/#eulas"},
    {"ABOUT_VNC_CONNECT_URL", "/connect"}, {"PUBKEY_LEARN_MORE_URL", "/docs/certificate-auth.html"},
    {"MANDATORY_2FA_HELP_URL", "/doclink/mfa-intro"}, {"STATUS_URL", "/status"},
    {"DEVICE_AUTH_PROBLEM_URL", "/device-auth-problem"}};
  for (const E& e : t) if (!strcmp(e.k, k.get())) return newStr(env, strf("%s%s", base, e.path).c());
  if (!strcmp(k.get(), "THIRD_PARTY_LEARN_MORE_URL")) return newStr(env, "https://help.realvnc.com/hc/en-us/articles/12585461044253");
  if (!strcmp(k.get(), "UNSUPPORTED_TEAM_LEARN_MORE_URL")) return newStr(env, strf("%s/home_info", base).c());
  return newStr(env, "");
}
