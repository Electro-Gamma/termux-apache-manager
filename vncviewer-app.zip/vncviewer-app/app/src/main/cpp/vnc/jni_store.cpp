// Local data-store and RealVNC-cloud related exports: ServerRecs, PasswordStore, Id, Label, SignInMgr, SyncMgr,
// SslCertificate, Zeroconf. Stores are in-memory; cloud/sign-in/sync/zeroconf are inert ("signed out") stubs.
#include "jni_common.h"
#include "session.h"
#include <time.h>

#define JF(ret, name, ...) extern "C" __attribute__((visibility("default"))) ret Java_com_realvnc_vncviewer_jni_##name(JNIEnv* env, jobject, ##__VA_ARGS__)
#define JT(ret, name, ...) extern "C" __attribute__((visibility("default"))) ret Java_com_realvnc_vncviewer_jni_##name(JNIEnv* env, jobject self, ##__VA_ARGS__)
#define UNUSED(x) (void)(x)
using namespace vr;

namespace {

struct ServerRec {
  Vec<KV> props; Vec<Str> labels; jobject thumb = nullptr; bool remember = false;
};
struct ServerRecList { Vec<ServerRec*> items; };

ServerRec* cloneRec(JNIEnv* env, const ServerRec* r) {
  ServerRec* n = new ServerRec; n->props = r->props; n->labels = r->labels; n->remember = r->remember;
  if (r->thumb) n->thumb = env->NewGlobalRef(r->thumb);
  return n;
}
void freeRec(JNIEnv* env, ServerRec* r) { if (!r) return; if (r->thumb) env->DeleteGlobalRef(r->thumb); delete r; }

jfieldID implField(JNIEnv* env, jobject o) {
  jclass c = env->GetObjectClass(o); jfieldID f = env->GetFieldID(c, "impl", "J"); env->DeleteLocalRef(c);
  if (env->ExceptionCheck()) env->ExceptionClear();
  return f;
}
void* getImpl(JNIEnv* env, jobject o) { jfieldID f = implField(env, o); return f ? (void*)env->GetLongField(o, f) : nullptr; }
void setImpl(JNIEnv* env, jobject o, void* p) { jfieldID f = implField(env, o); if (f) env->SetLongField(o, f, (jlong)p); }

const char* recGet(const ServerRec* r, const char* k) { for (size_t i = 0; i < r->props.n; i++) if (r->props[i].k.eq(k)) return r->props[i].v.c(); return ""; }
void recSet(ServerRec* r, const char* k, const char* v) {
  for (size_t i = 0; i < r->props.n; i++) if (r->props[i].k.eq(k)) { r->props[i].v = v; return; }
  KV kv; kv.k = k; kv.v = v; r->props.push(kv);
}

jobject wrapRec(JNIEnv* env, ServerRec* r) {
  jclass c = env->FindClass("com/realvnc/vncviewer/jni/ServerRecBindings");
  if (!c) return nullptr;
  jmethodID init = env->GetMethodID(c, "<init>", "(J)V");
  jobject o = init ? env->NewObject(c, init, (jlong)r) : nullptr;
  env->DeleteLocalRef(c); return o;
}

Str makeUuid() {
  static unsigned seed = 0; if (!seed) seed = (unsigned)time(nullptr) ^ (unsigned)(uintptr_t)&seed;
  u8 b[16]; for (int i = 0; i < 16; i++) { seed = seed * 1664525u + 1013904223u; b[i] = (u8)(seed >> 24); }
  b[6] = (b[6] & 0x0f) | 0x40; b[8] = (b[8] & 0x3f) | 0x80;
  char s[40]; snprintf(s, sizeof s, "%02x%02x%02x%02x-%02x%02x-%02x%02x-%02x%02x-%02x%02x%02x%02x%02x%02x", b[0], b[1], b[2], b[3], b[4], b[5], b[6], b[7], b[8], b[9], b[10], b[11], b[12], b[13], b[14], b[15]);
  return Str(s);
}
}  // namespace

// ---------------------------------------------------------------- ServerRecBindings (instance natives)
JT(void, ServerRecBindings_init) { setImpl(env, self, new ServerRec); }
JT(void, ServerRecBindings_finalize2) { ServerRec* r = (ServerRec*)getImpl(env, self); freeRec(env, r); setImpl(env, self, nullptr); }
JT(void, ServerRecBindings_ensureUuid) { ServerRec* r = (ServerRec*)getImpl(env, self); if (r && !*recGet(r, "Uuid")) recSet(r, "Uuid", makeUuid().c()); }
JT(jstring, ServerRecBindings_getProperty, jstring name) {
  ServerRec* r = (ServerRec*)getImpl(env, self); JStr n(env, name);
  if (!r || !n.ok()) return newStr(env, "");
  return newStr(env, recGet(r, n.get()));
}
JT(void, ServerRecBindings_setProperty, jstring name, jstring value) {
  ServerRec* r = (ServerRec*)getImpl(env, self); JStr n(env, name), v(env, value);
  if (!r || !n.ok()) return;
  if (!strcmp(n.get(), "ViewOnly")) { recSet(r, "ViewOnly", parseBool(v.get(), false) ? "1" : "0"); return; }
  recSet(r, n.get(), v.get());
}
JT(jobject, ServerRecBindings_getThumb) {
  ServerRec* r = (ServerRec*)getImpl(env, self); if (!r || !r->thumb) return nullptr;
  return env->NewLocalRef(r->thumb);
}
JT(void, ServerRecBindings_setThumb, jobject bmp) {
  ServerRec* r = (ServerRec*)getImpl(env, self); if (!r) return;
  if (r->thumb) env->DeleteGlobalRef(r->thumb);
  r->thumb = bmp ? env->NewGlobalRef(bmp) : nullptr;
}
JT(jboolean, ServerRecBindings_getRememberPassword) { ServerRec* r = (ServerRec*)getImpl(env, self); return r && r->remember; }
JT(void, ServerRecBindings_setRememberPassword, jboolean v) { ServerRec* r = (ServerRec*)getImpl(env, self); if (r) r->remember = v == JNI_TRUE; }
JT(void, ServerRecBindings_setLabels, jobjectArray arr) {
  ServerRec* r = (ServerRec*)getImpl(env, self); if (!r) return;
  r->labels.clear(); if (!arr) return;
  jsize n = env->GetArrayLength(arr);
  for (jsize i = 0; i < n; i++) { jstring s = (jstring)env->GetObjectArrayElement(arr, i); JStr js(env, s); r->labels.push(Str(js.get())); if (s) env->DeleteLocalRef(s); }
}
JT(jobjectArray, ServerRecBindings_getLabels) {
  ServerRec* r = (ServerRec*)getImpl(env, self);
  jclass sc = env->FindClass("java/lang/String"); size_t n = r ? r->labels.n : 0;
  jobjectArray a = env->NewObjectArray((jsize)n, sc, nullptr);
  for (size_t i = 0; i < n; i++) { jstring s = env->NewStringUTF(r->labels[i].c()); env->SetObjectArrayElement(a, (jsize)i, s); env->DeleteLocalRef(s); }
  env->DeleteLocalRef(sc); return a;
}

// ---------------------------------------------------------------- ServerRecs (list)
static ServerRecList* list(JNIEnv* env, jobject self) { return (ServerRecList*)getImpl(env, self); }
JT(void, ServerRecs_init) { setImpl(env, self, new ServerRecList); }
JT(void, ServerRecs_finalize2) {
  ServerRecList* l = list(env, self); if (!l) return;
  for (size_t i = 0; i < l->items.n; i++) freeRec(env, l->items[i]);
  delete l; setImpl(env, self, nullptr);
}
JT(jint, ServerRecs_size) { ServerRecList* l = list(env, self); return l ? (jint)l->items.n : 0; }
JT(jobject, ServerRecs_get, jint i) {
  ServerRecList* l = list(env, self);
  if (!l || i < 0 || (size_t)i >= l->items.n) { throwJava(env, "java/lang/IndexOutOfBoundsException", "index out of range"); return nullptr; }
  return wrapRec(env, cloneRec(env, l->items[i]));
}
JT(jobject, ServerRecs_set, jint i, jobject rec) {
  ServerRecList* l = list(env, self); ServerRec* src = rec ? (ServerRec*)getImpl(env, rec) : nullptr;
  if (!l || !src || i < 0 || (size_t)i >= l->items.n) { throwJava(env, "java/lang/IndexOutOfBoundsException", "index out of range"); return nullptr; }
  ServerRec* old = l->items[i]; l->items.p[i] = cloneRec(env, src);
  return wrapRec(env, old);   // ownership of the old record passes to the returned Java object
}
JT(void, ServerRecs_add, jint i, jobject rec) {
  ServerRecList* l = list(env, self); ServerRec* src = rec ? (ServerRec*)getImpl(env, rec) : nullptr;
  if (!l || !src || i < 0 || (size_t)i > l->items.n) { throwJava(env, "java/lang/IndexOutOfBoundsException", "index out of range"); return; }
  l->items.insert((size_t)i, cloneRec(env, src));
}
JT(jobject, ServerRecs_remove, jint i) {
  ServerRecList* l = list(env, self);
  if (!l || i < 0 || (size_t)i >= l->items.n) { throwJava(env, "java/lang/IndexOutOfBoundsException", "index out of range"); return nullptr; }
  ServerRec* r = l->items[i]; l->items.erase((size_t)i); return wrapRec(env, r);
}

// ---------------------------------------------------------------- Label
JF(jstring, LabelBindings_getFriendlyName, jobject l) { UNUSED(l); return newStr(env, ""); }
JF(jobjectArray, LabelBindings_getChildLabels, jobject l) {
  UNUSED(l); jclass sc = env->FindClass("java/lang/String"); jobjectArray a = env->NewObjectArray(0, sc, nullptr); env->DeleteLocalRef(sc); return a;
}

// ---------------------------------------------------------------- PasswordStore (in-memory)
JF(jstring, PasswordStoreBindings_load, jstring key) { JStr k(env, key); Str p = storeGetPassword(k.get()); return p.s ? newStr(env, p.c()) : nullptr; }
JF(void, PasswordStoreBindings_save, jstring key, jstring pw) { JStr k(env, key), p(env, pw); if (k.ok()) storeSetPassword(k.get(), p.get()); }
JF(void, PasswordStoreBindings_remove, jstring key) { JStr k(env, key); storeRemovePassword(k.get()); }
JF(void, PasswordStoreBindings_removeAll, jboolean all) { UNUSED(env); UNUSED(all); storeClearPasswords(); }

// ---------------------------------------------------------------- Id (identity helpers: pass-through, see docs/LIMITATIONS.md)
#define ID_PASS(name) JF(jstring, IdBindings_##name, jstring s) { JStr j(env, s); return newStr(env, j.get()); }
ID_PASS(getHexId) ID_PASS(getHexIdFromIdentity) ID_PASS(getFullIdentity) ID_PASS(getCatchphrase) ID_PASS(getCatchphraseFromIdentity)
ID_PASS(getCanonicalAddress)
JF(void, IdBindings_saveId, jstring a, jstring b) { UNUSED(env); UNUSED(a); UNUSED(b); }
JF(void, IdBindings_deleteId, jstring a) { UNUSED(env); UNUSED(a); }
JF(void, IdBindings_deleteExtraData, jstring a) { UNUSED(env); UNUSED(a); }

// ---------------------------------------------------------------- SignInMgr (always signed out)
JF(jstring, SignInMgrBindings_getAccountEmail) { return newStr(env, ""); }
JF(jstring, SignInMgrBindings_getAccountName) { return newStr(env, ""); }
JF(jboolean, SignInMgrBindings_isSignedIn) { UNUSED(env); return JNI_FALSE; }
JF(jint, SignInMgrBindings_getReauthenticateReason) { UNUSED(env); return 0; }
JF(jstring, SignInMgrBindings_getNetworkingError) { return newStr(env, ""); }
JF(jboolean, SignInMgrBindings_isSigningIn) { UNUSED(env); return JNI_FALSE; }
JF(void, SignInMgrBindings_beginSignIn, jstring a, jstring b) { UNUSED(env); UNUSED(a); UNUSED(b); logf(LOG_WARN, "RealVNC cloud sign-in is not supported by the replacement library"); }
JF(void, SignInMgrBindings_acceptSignInTerms) { UNUSED(env); }
JF(void, SignInMgrBindings_signOut, jboolean a) { UNUSED(env); UNUSED(a); }
JF(void, SignInMgrBindings_cancelSignIn) { UNUSED(env); }
JF(void, SignInMgrBindings_continueSignInFactor, jint a, jobject b, jobject c) { UNUSED(env); UNUSED(a); UNUSED(b); UNUSED(c); }
JF(void, SignInMgrBindings_continueSignInResendDa) { UNUSED(env); }
JF(void, SignInMgrBindings_beginSSO, jobject a) { UNUSED(env); UNUSED(a); }
JF(void, SignInMgrBindings_continueSSO, jobject a) { UNUSED(env); UNUSED(a); }
JF(jstring, SignInMgrBindings_getDsrId) { return newStr(env, ""); }
JF(jstring, SignInMgrBindings_getSsoSlug) { return newStr(env, ""); }
JF(void, SignInMgrBindings_clearSsoSlug) { UNUSED(env); }

// ---------------------------------------------------------------- SyncMgr (inert)
JF(void, SyncMgrBindings_enable, jint a) { UNUSED(env); UNUSED(a); }
JF(void, SyncMgrBindings_pause, jboolean a) { UNUSED(env); UNUSED(a); }
JF(void, SyncMgrBindings_signedIn) { UNUSED(env); }
JF(void, SyncMgrBindings_signedOut) { UNUSED(env); }
JF(jboolean, SyncMgrBindings_loadAll, jlong a, jobject b, jobject c, jobject d, jlong e, jboolean f) {
  UNUSED(env); UNUSED(a); UNUSED(b); UNUSED(c); UNUSED(d); UNUSED(e); UNUSED(f); return JNI_FALSE;
}
JF(void, SyncMgrBindings_save, jobject a) { UNUSED(env); UNUSED(a); }
JF(void, SyncMgrBindings_saveAll, jobject a) { UNUSED(env); UNUSED(a); }
JF(void, SyncMgrBindings_remove, jobject a) { UNUSED(env); UNUSED(a); }
JF(void, SyncMgrBindings_wipeThumbnail, jobject a) { UNUSED(env); UNUSED(a); }

// ---------------------------------------------------------------- SslCertificate / Zeroconf
JF(jstring, SslCertificateBindings_getSimpleSubjectName, jobject c) { UNUSED(c); return newStr(env, ""); }
JF(jstring, SslCertificateBindings_getSimpleIssuerName, jobject c) { UNUSED(c); return newStr(env, ""); }
JF(jstring, SslCertificateBindings_getUsername, jobject c) { UNUSED(c); return newStr(env, ""); }
JF(jboolean, SslCertificateBindings_hasClientAuth, jobject c) { UNUSED(env); UNUSED(c); return JNI_FALSE; }
JF(void, ZeroconfBindings_init, jobject a, jobject b) { UNUSED(env); UNUSED(a); UNUSED(b); }
JF(void, ZeroconfBindings_notifyNative, jlong a, jobject b, jobject c, jint d) { UNUSED(env); UNUSED(a); UNUSED(b); UNUSED(c); UNUSED(d); }
