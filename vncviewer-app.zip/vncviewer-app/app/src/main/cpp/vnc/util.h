// Small freestanding helpers (no libc++/STL dependency): containers, strings, locks, logging.
#pragma once
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <pthread.h>

inline void* operator new(size_t, void* p) noexcept { return p; }
void* operator new(size_t n);
void* operator new[](size_t n);
void operator delete(void* p) noexcept;
void operator delete[](void* p) noexcept;
void operator delete(void* p, size_t) noexcept;
void operator delete[](void* p, size_t) noexcept;

namespace vr {

typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;

// ---- logging -------------------------------------------------------------
enum { LOG_ERR = 1, LOG_WARN = 2, LOG_INFO = 3, LOG_DEBUG = 4 };
void logf(int level, const char* fmt, ...) __attribute__((format(printf, 2, 3)));
void setLogLevel(int level);
int logLevel();

// ---- Str: owning C string -------------------------------------------------
struct Str {
  char* s = nullptr;
  Str() {}
  Str(const char* x) { if (x) s = strdup(x); }
  Str(const Str& o) { if (o.s) s = strdup(o.s); }
  Str(Str&& o) noexcept { s = o.s; o.s = nullptr; }
  Str& operator=(const Str& o) { if (this != &o) { free(s); s = o.s ? strdup(o.s) : nullptr; } return *this; }
  Str& operator=(const char* x) { char* n = x ? strdup(x) : nullptr; free(s); s = n; return *this; }
  ~Str() { free(s); }
  const char* c() const { return s ? s : ""; }
  bool empty() const { return !s || !*s; }
  bool eq(const char* x) const { return strcmp(c(), x ? x : "") == 0; }
  bool eqi(const char* x) const { return strcasecmp(c(), x ? x : "") == 0; }
};

// ---- Vec: growable array for trivially relocatable types -------------------
template <class T> struct Vec {
  T* p = nullptr; size_t n = 0, cap = 0;
  Vec() {}
  Vec(const Vec& o) { for (size_t i = 0; i < o.n; i++) push(o.p[i]); }
  Vec& operator=(const Vec& o) { if (this != &o) { clear(); for (size_t i = 0; i < o.n; i++) push(o.p[i]); } return *this; }
  ~Vec() { clear(); free(p); }
  void reserve(size_t c) {
    if (c <= cap) return;
    size_t nc = cap ? cap * 2 : 8; if (nc < c) nc = c;
    T* np = (T*)malloc(nc * sizeof(T)); if (!np) abort();
    if (n) memcpy((void*)np, (void*)p, n * sizeof(T));
    free(p); p = np; cap = nc;
  }
  void push(const T& v) { reserve(n + 1); new (&p[n]) T(v); n++; }
  void clear() { for (size_t i = 0; i < n; i++) p[i].~T(); n = 0; }
  void erase(size_t i) { if (i >= n) return; p[i].~T(); if (i + 1 < n) memmove((void*)&p[i], (void*)&p[i + 1], (n - i - 1) * sizeof(T)); n--; }
  void insert(size_t i, const T& v) {
    if (i > n) i = n; reserve(n + 1);
    if (i < n) memmove((void*)&p[i + 1], (void*)&p[i], (n - i) * sizeof(T));
    new (&p[i]) T(v); n++;
  }
  T& operator[](size_t i) { return p[i]; }
  const T& operator[](size_t i) const { return p[i]; }
};

// ---- Bytes: raw byte buffer -------------------------------------------------
struct Bytes {
  u8* p = nullptr; size_t n = 0, cap = 0;
  Bytes() {}
  Bytes(const Bytes& o) { append(o.p, o.n); }
  Bytes& operator=(const Bytes& o) { if (this != &o) { n = 0; append(o.p, o.n); } return *this; }
  ~Bytes() { free(p); }
  bool reserve(size_t c) {
    if (c <= cap) return true;
    size_t nc = cap ? cap * 2 : 256; if (nc < c) nc = c;
    u8* np = (u8*)realloc(p, nc); if (!np) return false;
    p = np; cap = nc; return true;
  }
  bool append(const void* d, size_t k) { if (!reserve(n + k)) return false; if (k) memcpy(p + n, d, k); n += k; return true; }
  bool resize(size_t k) { if (!reserve(k)) return false; n = k; return true; }
  void clear() { n = 0; }
};

// ---- locking ----------------------------------------------------------------
struct Mutex {
  pthread_mutex_t m;
  Mutex() { pthread_mutexattr_t a; pthread_mutexattr_init(&a); pthread_mutexattr_settype(&a, PTHREAD_MUTEX_RECURSIVE); pthread_mutex_init(&m, &a); pthread_mutexattr_destroy(&a); }
  ~Mutex() { pthread_mutex_destroy(&m); }
  void lock() { pthread_mutex_lock(&m); }
  void unlock() { pthread_mutex_unlock(&m); }
  Mutex(const Mutex&) = delete; Mutex& operator=(const Mutex&) = delete;
};
struct Lock {
  Mutex& m; explicit Lock(Mutex& x) : m(x) { m.lock(); } ~Lock() { m.unlock(); }
};
struct Cond {
  pthread_cond_t c;
  Cond() { pthread_cond_init(&c, nullptr); }
  ~Cond() { pthread_cond_destroy(&c); }
  void signal() { pthread_cond_broadcast(&c); }
  void wait(Mutex& m) { pthread_cond_wait(&c, &m.m); }
  Cond(const Cond&) = delete; Cond& operator=(const Cond&) = delete;
};

// ---- misc ---------------------------------------------------------------------
Str strf(const char* fmt, ...) __attribute__((format(printf, 1, 2)));
size_t utf8ToLatin1(const char* in, u8* out, size_t outMax);   // lossy: non-Latin1 -> '?'
Str latin1ToUtf8(const u8* in, size_t n);
bool parseBool(const char* v, bool def);
long parseInt(const char* v, long def);

}  // namespace vr
