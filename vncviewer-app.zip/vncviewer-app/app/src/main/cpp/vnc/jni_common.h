// Shared JNI plumbing: VM handle, thread attach, cached class/method ids, dialog registry.
#pragma once
#include <jni.h>
#include "util.h"

namespace vr {

struct Session;

struct JniGlobals {
  JavaVM* vm = nullptr;
  // SessionBindings$Session
  jclass sessionCls = nullptr;
  jmethodID sessionInit = nullptr, sessionGetToken = nullptr, sessionSetToken = nullptr;
  // android.graphics.Bitmap (optional; used for cursor images)
  jclass bitmapCls = nullptr;
  jmethodID bitmapCreate = nullptr, bitmapSetHasAlpha = nullptr;
  jobject argb8888 = nullptr;
  // factories / notifiers registered by the app (global refs + resolved method ids)
  jobject passwdFactory = nullptr;      jmethodID createPasswdDlg = nullptr;
  jobject itextFactory = nullptr;       jmethodID createInteractiveTextDlg = nullptr;
  jobject msgBoxFactory = nullptr;      jmethodID createMsgBox = nullptr;
  jobject securityFactory = nullptr;    jmethodID createSecurityDlg = nullptr;
  jobject authkeyFactory = nullptr;     jmethodID createAuthkeyChoiceDlg = nullptr;
  jobject reconnectFactory = nullptr;   jmethodID createReconnectDlg = nullptr;
  jobject statusNotifier = nullptr;
  jobject securityNotifier = nullptr;
  jobject credentialsStore = nullptr;
  jobject identityStore = nullptr;
  jobject connMethodStore = nullptr;
};
extern JniGlobals G;

// Attach the calling thread (if needed) and return its env. *attached tells the caller to detach.
JNIEnv* attachThread(bool* attached);
void detachThread();
void throwJava(JNIEnv* env, const char* cls, const char* msg);
inline void throwRuntime(JNIEnv* env, const char* msg) { throwJava(env, "java/lang/RuntimeException", msg); }
void replaceGlobalRef(JNIEnv* env, jobject* slot, jobject obj);

// RAII for GetStringUTFChars (null-safe).
struct JStr {
  JNIEnv* e; jstring js; const char* c;
  JStr(JNIEnv* env, jobject s) : e(env), js((jstring)s), c(nullptr) { if (s) c = env->GetStringUTFChars((jstring)s, nullptr); }
  ~JStr() { if (c) e->ReleaseStringUTFChars(js, c); }
  const char* get() const { return c ? c : ""; }
  bool ok() const { return c != nullptr; }
};
inline jstring newStr(JNIEnv* e, const char* s) { return e->NewStringUTF(s ? s : ""); }

// ---- prompts (dialog round trips) -------------------------------------------------
struct Prompt {
  u64 handle = 0; Session* session = nullptr;
  bool done = false, ok = false; bool flag2 = false, flag3 = false;
  Str user, pass;
};
u64 promptCreate(Session* s);
Prompt* promptWait(u64 handle, Session* s);   // blocks until answered or session closing; returns null if aborted
void promptRelease(u64 handle);
void promptAnswer(u64 handle, bool ok, const char* user, const char* pass, bool f2, bool f3);
void promptAbortSession(Session* s);

// ---- sessions ---------------------------------------------------------------------
Session* sessionFind(u64 id);
Session* sessionFromObject(JNIEnv* env, jobject sessionObj);

// ---- key helpers --------------------------------------------------------------------
u32 unicodeToKeysym(u32 cp);
u32 keysymToUnicode(u32 ks);

}  // namespace vr
