#pragma once
#include <stdint.h>
namespace vr {
// VNC authentication response: DES-ECB encrypt 16-byte challenge with password (bit-reversed key bytes).
void vncAuthResponse(const char* password, const uint8_t challenge[16], uint8_t out[16]);
// Raw DES block encrypt (key given in standard DES byte order, parity ignored). Exposed for tests.
void desEncryptBlock(const uint8_t key[8], const uint8_t in[8], uint8_t out[8]);
}
