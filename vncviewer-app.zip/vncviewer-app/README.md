# VNC Client (Kotlin + C++)
Android app built on the replacement `libvncviewer.so` sources (`app/src/main/cpp/vnc`, built by the NDK through CMake).
- `com.realvnc.vncviewer.jni.*` (Java): the binding classes whose `native` methods the C++ library implements. They must keep this package/name.
- `VncSession.kt`: Kotlin wrapper, `VncView.kt`: framebuffer view + touch input, `ViewerActivity.kt` / `MainActivity.kt`: UI.

Build: open in Android Studio (Koala+, NDK installed) or `gradle assembleDebug` with ANDROID_HOME set. ABI: arm64-v8a, minSdk 24.
Scope: direct RFB connections (None / VNC password auth). RealVNC cloud/sign-in, TLS/RA2 are not implemented.
Usage: enter host/port; tap = click, long-press+drag = drag, two-finger swipe = scroll, pinch = zoom, menu: keyboard / Ctrl+Alt+Del / right-click / disconnect.
