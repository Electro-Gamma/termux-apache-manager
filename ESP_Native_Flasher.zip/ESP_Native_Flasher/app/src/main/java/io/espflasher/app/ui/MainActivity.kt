package io.espflasher.app.ui

import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import io.espflasher.app.R
import io.espflasher.app.databinding.ActivityMainBinding
import io.espflasher.app.databinding.ItemFileSlotBinding
import io.espflasher.app.flashing.FlashOptions
import io.espflasher.app.flashing.ImageSlot
import io.espflasher.app.usb.DataBits
import io.espflasher.app.usb.FlowControl
import io.espflasher.app.usb.Parity
import io.espflasher.app.usb.SerialConfig
import io.espflasher.app.usb.StopBits
import io.espflasher.app.usb.UsbDeviceInfo
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: MainViewModel by viewModels()

    private val logAdapter = LogAdapter()
    private val slotViews = mutableMapOf<ImageSlot, ItemFileSlotBinding>()
    private val customEntryViews = mutableMapOf<String, io.espflasher.app.databinding.ItemCustomEntryBinding>()
    private var pendingSlot: ImageSlot? = null
    private var pendingCustomAdd = false
    private var suppressOffsetWatchers = false

    private val slotOrder = listOf(
        ImageSlot.BOOTLOADER, ImageSlot.PARTITION_TABLE, ImageSlot.APPLICATION, ImageSlot.OTA_DATA,
        ImageSlot.SPIFFS, ImageSlot.FIRMWARE
    )

    private val openDocumentLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val slot = pendingSlot
        val wasCustomAdd = pendingCustomAdd
        pendingSlot = null
        pendingCustomAdd = false
        if (uri == null) return@registerForActivityResult
        contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        val name = queryFileName(uri) ?: uri.lastPathSegment.orEmpty()
        if (wasCustomAdd) {
            viewModel.addCustomEntry(uri, name)
        } else if (slot != null) {
            val size = queryFileSize(uri) ?: 0L
            viewModel.fileSelected(slot, uri, name, size)
        }
    }

    private val createDumpFileLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) viewModel.readFlashToFile(uri)
    }

    private val createLogFileLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) viewModel.saveLog(uri)
    }

    private val openSpiffsFolderLauncher = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { treeUri ->
        if (treeUri == null) return@registerForActivityResult
        contentResolver.takePersistableUriPermission(treeUri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        viewModel.generateSpiffsImage(treeUri, fallbackSizeBytes = 0L)
    }

    private val usbAttachReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            viewModel.refreshDevices()
        }
    }

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* no-op either way - the service still works without it */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupFileSlots()
        setupDropdowns()
        setupConsole()
        setupListeners()
        observeState()
        requestNotificationPermissionIfNeeded()
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS)
                != android.content.pm.PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter().apply {
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        }
        ContextCompat.registerReceiver(this, usbAttachReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        viewModel.refreshDevices()
    }

    override fun onStop() {
        super.onStop()
        runCatching { unregisterReceiver(usbAttachReceiver) }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.action_settings) {
            startActivity(Intent(this, SettingsActivity::class.java))
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    // -----------------------------------------------------------------
    // Setup
    // -----------------------------------------------------------------

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
    }

    private fun setupFileSlots() {
        for (slot in slotOrder) {
            val rowBinding = ItemFileSlotBinding.inflate(LayoutInflater.from(this), binding.fileSlotsContainer, false)
            rowBinding.slotLabel.text = slot.label
            rowBinding.slotEnabledCheck.setOnCheckedChangeListener { _, checked ->
                viewModel.setSlotEnabled(slot, checked)
            }
            rowBinding.slotBrowseButton.setOnClickListener {
                pendingSlot = slot
                openDocumentLauncher.launch(arrayOf("*/*"))
            }
            rowBinding.slotDeleteButton.setOnClickListener { viewModel.clearFile(slot) }
            rowBinding.slotOffsetInput.afterTextChangedListener({ text ->
                if (!suppressOffsetWatchers) viewModel.offsetTextChanged(slot, text?.toString().orEmpty())
            })
            if (slot == ImageSlot.SPIFFS) {
                rowBinding.slotDetectButton.setOnClickListener { viewModel.detectSpiffs() }
                rowBinding.slotGenerateButton.setOnClickListener { openSpiffsFolderLauncher.launch(null) }
                rowBinding.slotEraseButton.setOnClickListener { confirmThenEraseSpiffs() }
            }
            binding.fileSlotsContainer.addView(rowBinding.root)
            slotViews[slot] = rowBinding
        }
        binding.addCustomEntryButton.setOnClickListener {
            pendingCustomAdd = true
            openDocumentLauncher.launch(arrayOf("*/*"))
        }
    }

    private fun setupDropdowns() {
        setupExposedDropdown(binding.baudRateDropdown, SerialConfig.COMMON_BAUD_RATES.map { it.toString() })
        setupExposedDropdown(binding.dataBitsDropdown, DataBits.entries.map { it.value.toString() })
        setupExposedDropdown(binding.stopBitsDropdown, StopBits.entries.map { it.label })
        setupExposedDropdown(binding.parityDropdown, Parity.entries.map { it.label })
        setupExposedDropdown(binding.flowControlDropdown, FlowControl.entries.map { it.label })
        setupExposedDropdown(binding.uploadBaudRateDropdown, SerialConfig.COMMON_BAUD_RATES.map { it.toString() })

        binding.baudRateDropdown.setText(SerialConfig().baudRate.toString(), false)
        binding.dataBitsDropdown.setText(SerialConfig().dataBits.value.toString(), false)
        binding.stopBitsDropdown.setText(SerialConfig().stopBits.label, false)
        binding.parityDropdown.setText(SerialConfig().parity.label, false)
        binding.flowControlDropdown.setText(SerialConfig().flowControl.label, false)
        binding.uploadBaudRateDropdown.setText(viewModel.uiState.value.uploadBaudRate.toString(), false)

        val onConfigChanged = { _: Any? ->
            val config = SerialConfig(
                baudRate = binding.baudRateDropdown.text.toString().toIntOrNull() ?: 115200,
                dataBits = DataBits.entries.firstOrNull { it.value.toString() == binding.dataBitsDropdown.text.toString() } ?: DataBits.EIGHT,
                stopBits = StopBits.entries.firstOrNull { it.label == binding.stopBitsDropdown.text.toString() } ?: StopBits.ONE,
                parity = Parity.entries.firstOrNull { it.label == binding.parityDropdown.text.toString() } ?: Parity.NONE,
                flowControl = FlowControl.entries.firstOrNull { it.label == binding.flowControlDropdown.text.toString() } ?: FlowControl.NONE
            )
            viewModel.updateSerialConfig(config)
        }
        binding.baudRateDropdown.afterTextChangedListener({ onConfigChanged(null) })
        binding.dataBitsDropdown.setOnItemClickListener { _, _, _, _ -> onConfigChanged(null) }
        binding.stopBitsDropdown.setOnItemClickListener { _, _, _, _ -> onConfigChanged(null) }
        binding.parityDropdown.setOnItemClickListener { _, _, _, _ -> onConfigChanged(null) }
        binding.flowControlDropdown.setOnItemClickListener { _, _, _, _ -> onConfigChanged(null) }

        binding.uploadBaudRateDropdown.afterTextChangedListener({ text ->
            text?.toString()?.toIntOrNull()?.let { viewModel.updateUploadBaudRate(it) }
        })
        binding.uploadBaudRateDropdown.setOnItemClickListener { _, _, _, _ ->
            binding.uploadBaudRateDropdown.text.toString().toIntOrNull()?.let { viewModel.updateUploadBaudRate(it) }
        }

        binding.deviceDropdown.setOnItemClickListener { _, _, position, _ ->
            val state = viewModel.uiState.value
            state.availableDevices.getOrNull(position)?.let { viewModel.selectDevice(it) }
        }
    }

    private fun setupExposedDropdown(view: AutoCompleteTextView, items: List<String>) {
        view.setAdapter(ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, items))
    }

    private fun setupConsole() {
        binding.consoleRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.consoleRecyclerView.adapter = logAdapter
    }

    private fun setupListeners() {
        binding.refreshDevicesButton.setOnClickListener { viewModel.refreshDevices() }
        binding.connectButton.setOnClickListener { viewModel.connect() }
        binding.disconnectButton.setOnClickListener { viewModel.disconnect() }
        binding.resetButton.setOnClickListener { viewModel.resetDevice() }
        binding.bootloaderButton.setOnClickListener { viewModel.enterBootloader() }

        binding.detectButton.setOnClickListener { viewModel.detect() }
        binding.eraseButton.setOnClickListener { confirmThenErase() }
        binding.flashButton.setOnClickListener { viewModel.flash() }
        binding.verifyButton.setOnClickListener { viewModel.verify() }
        binding.readButton.setOnClickListener {
            createDumpFileLauncher.launch("flash_dump.bin")
        }
        binding.stopButton.setOnClickListener { viewModel.stop() }

        val optionsChanged = View.OnClickListener { updateFlashOptionsFromUi() }
        binding.verifyAfterWriteCheck.setOnClickListener(optionsChanged)
        binding.eraseBeforeWriteCheck.setOnClickListener(optionsChanged)
        binding.compressDataCheck.setOnClickListener(optionsChanged)
        binding.resetAfterFlashingCheck.setOnClickListener(optionsChanged)
        binding.skipChecksumCheck.setOnClickListener(optionsChanged)
        binding.keepUsbConnectionCheck.setOnClickListener(optionsChanged)
        binding.useStubLoaderCheck.setOnClickListener(optionsChanged)

        binding.copyLogButton.setOnClickListener {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("ESP Flasher Log", viewModel.logAsText()))
        }
        binding.clearLogButton.setOnClickListener { viewModel.clearLog() }
        binding.saveLogButton.setOnClickListener {
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(java.util.Date())
            createLogFileLauncher.launch("esp_flasher_log_$stamp.txt")
        }

        binding.regAddressInput.afterTextChangedListener({ viewModel.advancedRegAddressChanged(it?.toString().orEmpty()) })
        binding.regValueInput.afterTextChangedListener({ viewModel.advancedRegValueChanged(it?.toString().orEmpty()) })
        binding.readRegButton.setOnClickListener { viewModel.readRegister() }
        binding.writeRegButton.setOnClickListener { viewModel.writeRegister() }

        binding.readOffsetInput.afterTextChangedListener({ viewModel.advancedReadOffsetChanged(it?.toString().orEmpty()) })
        binding.readLengthInput.afterTextChangedListener({ viewModel.advancedReadLengthChanged(it?.toString().orEmpty()) })
        binding.readToFileButton.setOnClickListener { createDumpFileLauncher.launch("flash_dump.bin") }
    }

    private fun confirmThenErase() {
        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle(R.string.action_erase)
            .setMessage("This erases the entire flash chip. Continue?")
            .setPositiveButton(R.string.action_erase) { _, _ -> viewModel.erase() }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun confirmThenEraseSpiffs() {
        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle(R.string.action_erase_spiffs)
            .setMessage("This erases just the SPIFFS partition (offset+size read from the last Partition Table file you picked), not the whole chip. Continue?")
            .setPositiveButton(R.string.action_erase_spiffs) { _, _ -> viewModel.eraseSpiffsOnly() }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun updateFlashOptionsFromUi() {
        viewModel.updateFlashOptions(
            FlashOptions(
                verifyAfterWrite = binding.verifyAfterWriteCheck.isChecked,
                eraseBeforeWrite = binding.eraseBeforeWriteCheck.isChecked,
                compressData = binding.compressDataCheck.isChecked,
                resetAfterFlashing = binding.resetAfterFlashingCheck.isChecked,
                skipChecksum = binding.skipChecksumCheck.isChecked,
                keepUsbConnection = binding.keepUsbConnectionCheck.isChecked,
                useStubLoader = binding.useStubLoaderCheck.isChecked
            )
        )
    }

    // -----------------------------------------------------------------
    // State rendering
    // -----------------------------------------------------------------

    private fun observeState() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.uiState.collect { render(it) }
            }
        }
    }

    private fun render(state: MainUiState) {
        binding.usbHostWarningText.visibility = if (state.usbHostSupported) View.GONE else View.VISIBLE

        if (!binding.uploadBaudRateDropdown.hasFocus() &&
            binding.uploadBaudRateDropdown.text.toString() != state.uploadBaudRate.toString()
        ) {
            binding.uploadBaudRateDropdown.setText(state.uploadBaudRate.toString(), false)
        }

        renderDeviceDropdown(state)
        renderDeviceInfoText(state)

        val connected = state.isConnected
        val busy = state.isBusy
        binding.connectButton.isEnabled = !connected && !busy && state.availableDevices.isNotEmpty()
        binding.disconnectButton.isEnabled = connected && !busy
        binding.resetButton.isEnabled = connected && !busy
        binding.bootloaderButton.isEnabled = connected && !busy
        binding.detectButton.isEnabled = connected && !busy
        binding.eraseButton.isEnabled = connected && !busy
        binding.flashButton.isEnabled = connected && !busy
        binding.verifyButton.isEnabled = connected && !busy
        binding.readButton.isEnabled = connected && !busy
        binding.stopButton.isEnabled = busy

        renderFileSlots(state)
        renderCustomEntries(state)
        renderFlashOptions(state.flashOptions)
        renderProgress(state)
        renderDeviceInfoPanel(state)
        renderLog(state)
        renderAdvanced(state)
    }

    private fun renderDeviceDropdown(state: MainUiState) {
        val labels = state.availableDevices.map { "${it.displayLabel} (${it.vidPidHex})" }
        val current = binding.deviceDropdown.tag as? List<*>
        if (current != labels) {
            binding.deviceDropdown.setAdapter(ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, labels))
            binding.deviceDropdown.tag = labels
        }
        val selectedIndex = state.availableDevices.indexOfFirst { it.androidDeviceName == state.selectedDeviceName }
        if (selectedIndex >= 0 && binding.deviceDropdown.text.toString() != labels[selectedIndex]) {
            binding.deviceDropdown.setText(labels[selectedIndex], false)
        } else if (state.availableDevices.isEmpty()) {
            binding.deviceDropdown.setText("", false)
        }
    }

    private fun renderDeviceInfoText(state: MainUiState) {
        val info: UsbDeviceInfo? = state.availableDevices.firstOrNull { it.androidDeviceName == state.selectedDeviceName }
        binding.deviceInfoText.text = if (info == null) {
            "No device selected"
        } else {
            buildString {
                append("VID:PID ${info.vidPidHex}  [${info.chipFamily.label}]\n")
                append("Manufacturer: ${info.manufacturerName ?: "—"}\n")
                append("Product: ${info.productName ?: "—"}\n")
                append("Serial: ${info.serialNumber ?: "— (grant permission to view)"}")
            }
        }
    }

    private fun renderFileSlots(state: MainUiState) {
        suppressOffsetWatchers = true
        val hasSpiffsPartition = state.partitionTable?.findSpiffs() != null
        for (slot in slotOrder) {
            val row = slotViews[slot] ?: continue
            val file = state.files[slot]
            row.slotFileName.text = file?.fileName ?: getString(R.string.no_file_selected)

            val enabled = slot in state.enabledSlots
            if (row.slotEnabledCheck.isChecked != enabled) {
                row.slotEnabledCheck.setOnCheckedChangeListener(null)
                row.slotEnabledCheck.isChecked = enabled
                row.slotEnabledCheck.setOnCheckedChangeListener { _, checked -> viewModel.setSlotEnabled(slot, checked) }
            }
            row.slotEnabledCheck.isEnabled = file != null

            val offsetText = state.offsetText[slot].orEmpty()
            if (row.slotOffsetInput.text?.toString() != offsetText && !row.slotOffsetInput.hasFocus()) {
                row.slotOffsetInput.setText(offsetText)
            }

            if (slot == ImageSlot.SPIFFS) {
                row.slotSpiffsToolsRow.visibility = View.VISIBLE
                row.slotDetectButton.isEnabled = !state.isBusy && state.isConnected
                row.slotGenerateButton.isEnabled = !state.isBusy
                row.slotEraseButton.isEnabled = !state.isBusy && state.isConnected && hasSpiffsPartition
            }
        }
        suppressOffsetWatchers = false
    }

    private fun renderCustomEntries(state: MainUiState) {
        val currentIds = state.customEntries.map { it.id }.toSet()

        // Remove views for entries that no longer exist.
        val toRemove = customEntryViews.keys - currentIds
        for (id in toRemove) {
            customEntryViews.remove(id)?.let { binding.customEntriesContainer.removeView(it.root) }
        }

        // Add or update a view per entry.
        for (entry in state.customEntries) {
            var rowBinding = customEntryViews[entry.id]
            if (rowBinding == null) {
                rowBinding = io.espflasher.app.databinding.ItemCustomEntryBinding.inflate(
                    LayoutInflater.from(this), binding.customEntriesContainer, false
                )
                rowBinding.entryDeleteButton.setOnClickListener { viewModel.removeCustomEntry(entry.id) }
                rowBinding.entryOffsetInput.afterTextChangedListener { text ->
                    if (!suppressOffsetWatchers) viewModel.customEntryOffsetChanged(entry.id, text?.toString().orEmpty())
                }
                binding.customEntriesContainer.addView(rowBinding.root)
                customEntryViews[entry.id] = rowBinding
            }

            rowBinding.entryFileName.text = entry.fileName

            if (rowBinding.entryEnabledCheck.isChecked != entry.enabled) {
                rowBinding.entryEnabledCheck.setOnCheckedChangeListener(null)
                rowBinding.entryEnabledCheck.isChecked = entry.enabled
            }
            rowBinding.entryEnabledCheck.setOnCheckedChangeListener { _, checked ->
                viewModel.setCustomEntryEnabled(entry.id, checked)
            }

            if (rowBinding.entryOffsetInput.text?.toString() != entry.offsetText && !rowBinding.entryOffsetInput.hasFocus()) {
                suppressOffsetWatchers = true
                rowBinding.entryOffsetInput.setText(entry.offsetText)
                suppressOffsetWatchers = false
            }
        }
    }

    private fun renderFlashOptions(options: FlashOptions) {
        binding.verifyAfterWriteCheck.isChecked = options.verifyAfterWrite
        binding.eraseBeforeWriteCheck.isChecked = options.eraseBeforeWrite
        binding.compressDataCheck.isChecked = options.compressData
        binding.resetAfterFlashingCheck.isChecked = options.resetAfterFlashing
        binding.skipChecksumCheck.isChecked = options.skipChecksum
        binding.keepUsbConnectionCheck.isChecked = options.keepUsbConnection
        binding.useStubLoaderCheck.isChecked = options.useStubLoader
    }

    private fun renderProgress(state: MainUiState) {
        val p = state.progress
        binding.operationLabelText.text = if (state.isBusy) p.operationLabel else "Idle"
        binding.progressBar.progress = p.percent
        binding.progressBar.isIndeterminate = state.isBusy && p.bytesTotal == 0L
        binding.progressDetailText.text = if (p.bytesTotal > 0) {
            "%d%%  addr=0x%08X  %d / %d B  %s/s  ETA %ds".format(
                p.percent, p.currentAddress, p.bytesDone, p.bytesTotal,
                humanReadableBytes(p.speedBytesPerSec.toLong()), p.etaSeconds
            )
        } else ""
    }

    private fun renderDeviceInfoPanel(state: MainUiState) {
        val info = state.deviceInfo
        binding.deviceInfoDetailText.text = if (info == null) {
            getString(R.string.no_device_detected)
        } else {
            buildString {
                append("Chip: ${info.chip.displayName}\n")
                append("Revision: ${info.revision}\n")
                append("MAC: ${info.macAddress}\n")
                append("Crystal: ${info.crystalFreqMHz} MHz (nominal)\n")
                append("Flash: ${info.flashSizeBytes?.let { io.espflasher.app.protocol.FlashLayout.humanReadableSize(it) } ?: "Unknown"}\n")
                append("Flash mode: ${info.flashMode ?: "N/A (select a firmware file to see its declared mode)"}\n")
                append("Features: ${info.features.joinToString(", ")}\n")
                append("Secure Boot: ${info.secureBootStatus}\n")
                append("Flash Encryption: ${info.flashEncryptionStatus}")
            }
        }
    }

    private fun renderLog(state: MainUiState) {
        logAdapter.setFontSize(state.consoleFontSizeSp.toFloat())
        logAdapter.submitList(state.logs) {
            if (state.logs.isNotEmpty()) binding.consoleRecyclerView.scrollToPosition(state.logs.size - 1)
        }
    }

    private fun renderAdvanced(state: MainUiState) {
        if (binding.regAddressInput.text?.toString() != state.advancedRegAddressText && !binding.regAddressInput.hasFocus()) {
            binding.regAddressInput.setText(state.advancedRegAddressText)
        }
        if (binding.regValueInput.text?.toString() != state.advancedRegValueText && !binding.regValueInput.hasFocus()) {
            binding.regValueInput.setText(state.advancedRegValueText)
        }
        if (binding.readOffsetInput.text?.toString() != state.advancedReadOffsetText && !binding.readOffsetInput.hasFocus()) {
            binding.readOffsetInput.setText(state.advancedReadOffsetText)
        }
        if (binding.readLengthInput.text?.toString() != state.advancedReadLengthText && !binding.readLengthInput.hasFocus()) {
            binding.readLengthInput.setText(state.advancedReadLengthText)
        }
    }

    private fun humanReadableBytes(bytesPerSec: Long): String = when {
        bytesPerSec >= 1024 * 1024 -> "%.1f MB".format(bytesPerSec / (1024.0 * 1024.0))
        bytesPerSec >= 1024 -> "%.1f KB".format(bytesPerSec / 1024.0)
        else -> "$bytesPerSec B"
    }

    // -----------------------------------------------------------------
    // Content resolver helpers
    // -----------------------------------------------------------------

    private fun queryFileName(uri: android.net.Uri): String? {
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && cursor.moveToFirst()) return cursor.getString(idx)
        }
        return null
    }

    private fun queryFileSize(uri: android.net.Uri): Long? {
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(android.provider.OpenableColumns.SIZE)
            if (idx >= 0 && cursor.moveToFirst() && !cursor.isNull(idx)) return cursor.getLong(idx)
        }
        return null
    }
}

/** Small helper so plain EditText/AutoCompleteTextView views can use a lambda-based watcher. */
private fun android.widget.EditText.afterTextChangedListener(afterTextChanged: (CharSequence?) -> Unit) {
    addTextChangedListener(object : android.text.TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        override fun afterTextChanged(s: android.text.Editable?) {
            afterTextChanged(s?.toString())
        }
    })
}
