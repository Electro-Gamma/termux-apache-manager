package io.espflasher.app.protocol

/**
 * The 8-byte header every Espressif app/bootloader image starts with. This
 * is a publicly documented, stable on-flash format (see the "Firmware Image
 * Format" page in Espressif's ESP-IDF docs) - parsing it here is just
 * reading a binary layout, not reusing any tool's source.
 *
 * Only used for informational display and for validating that a file
 * "looks like" a real ESP image before wasting time flashing it.
 */
data class ImageHeader(
    val magic: Int,
    val segmentCount: Int,
    val flashMode: String,
    val flashFreqMHz: Int,
    val flashSizeLabel: String,
    val entryPoint: Long
) {
    companion object {
        fun parse(bytes: ByteArray): ImageHeader? {
            if (bytes.size < 8) return null
            val magic = bytes[0].toInt() and 0xFF
            if (magic != EspCommand.IMAGE_MAGIC) return null
            val segmentCount = bytes[1].toInt() and 0xFF
            val flashModeCode = bytes[2].toInt() and 0xFF
            val flashSizeFreq = bytes[3].toInt() and 0xFF
            val entryPoint = (0 until 4).fold(0L) { acc, i ->
                acc or ((bytes[4 + i].toLong() and 0xFF) shl (8 * i))
            }
            val flashMode = when (flashModeCode) {
                0 -> "QIO"
                1 -> "QOUT"
                2 -> "DIO"
                3 -> "DOUT"
                else -> "Unknown (0x%02X)".format(flashModeCode)
            }
            val freqCode = flashSizeFreq and 0x0F
            val flashFreq = when (freqCode) {
                0x0 -> 40
                0x1 -> 26
                0x2 -> 20
                0xF -> 80
                else -> 40
            }
            val sizeCode = (flashSizeFreq shr 4) and 0x0F
            val sizeLabel = when (sizeCode) {
                0x0 -> "1MB"
                0x1 -> "2MB"
                0x2 -> "4MB"
                0x3 -> "8MB"
                0x4 -> "16MB"
                0x5 -> "32MB"
                0x6 -> "64MB"
                0x7 -> "128MB"
                else -> "Unknown"
            }
            return ImageHeader(magic, segmentCount, flashMode, flashFreq, sizeLabel, entryPoint)
        }

        /** Cheap sanity check used before flashing: does this look like a real image? */
        fun looksValid(bytes: ByteArray): Boolean = bytes.isNotEmpty() && (bytes[0].toInt() and 0xFF) == EspCommand.IMAGE_MAGIC
    }
}
