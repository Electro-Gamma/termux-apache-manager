package io.espflasher.app.arduinohex

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.res.ColorStateList
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.widget.ArrayAdapter
import android.widget.RadioButton
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.updateLayoutParams
import androidx.core.view.updatePadding
import androidx.lifecycle.lifecycleScope
import io.espflasher.app.R
import io.espflasher.app.databinding.ActivityArduinoHexUploadBinding
import io.espflasher.app.service.FlashForegroundService
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kr.co.makeitall.arduino.ArduinoUploader.Config.Arduino
import kr.co.makeitall.arduino.ArduinoUploader.Config.McuIdentifier
import kr.co.makeitall.arduino.ArduinoUploader.Config.Protocol
import kr.co.makeitall.arduino.Boards
import kr.co.makeitall.arduino.LineReader
import kr.co.makeitall.arduino.UsbSerialManager
import kr.co.makeitall.arduino.arduinoisp.ArduinoIspManager
import kr.co.makeitall.arduino.usbasp.IntelHexWriter
import kr.co.makeitall.arduino.usbasp.UsbaspManager
import kr.co.makeitall.arduino.usbasp.UsbaspMcuInfo
import kr.co.makeitall.arduino.usbasp.UsbaspMcuTable
import kr.co.makeitall.arduino.usbasp.UsbaspMemoryType
import kr.co.makeitall.arduino.usbasp.UsbaspReadResult
import kr.co.makeitall.arduino.usbasp.UsbaspSckOption
import IntelHexFormatReader.HexFileReader
import IntelHexFormatReader.Model.MemoryBlock
import java.io.InputStreamReader

/**
 * A near-verbatim port of the reference `arduino-hex-upload` app's own
 * `MainActivity` - AVR programming (STK500v1/v2, AVR109 bootloaders,
 * USBasp, and ArduinoISP) is different enough from every other device mode
 * in this app (different protocols, different UI shape - a 2x2 mode toggle
 * rather than named file slots, and USBasp needs an entirely separate
 * raw-USB connection with no serial port at all - see [UsbaspManager]) that
 * reusing the reference app's own tested screen wholesale, rather than
 * re-deriving its behavior against this app's file-slot/[io.espflasher.app.flashing.FlashOperationManager]
 * architecture, is both safer (no risk of mistranscribing a working
 * protocol implementation) and more honest about what's actually shared
 * between the two.
 *
 * Reached via the "Open Arduino Hex Upload" button on the main screen when
 * Device mode is set to Arduino Hex Upload
 * ([io.espflasher.app.flashing.DeviceMode.ARDUINO_HEX_UPLOAD]) - this
 * Activity owns its own USB connection state independently of
 * [io.espflasher.app.ui.MainViewModel]/[io.espflasher.app.ui.MainActivity]'s
 * Connect button, exactly like the reference app did as a standalone app.
 *
 * Visual style ([R.style.Theme_ArduinoHexUploader], set on this Activity in
 * AndroidManifest.xml) and every id referenced here via [binding] both come
 * from the reference app's own resources. The layout/component styles are
 * still the reference app's own (card shape, button corner radius, toolbar
 * layout), but the color palette now matches this app's own
 * Theme.EspNativeFlasher (teal/cyan brand colors) instead of the reference
 * app's original teal+orange scheme - see activity_arduino_hex_upload.xml,
 * arduino_hex_upload_theme.xml, arduino_hex_upload_colors.xml, and
 * arduino_hex_upload_strings.xml's own comments for exactly what changed
 * (colors + name collisions only; no behavior).
 */
class ArduinoHexUploadActivity : AppCompatActivity() {

    private enum class UploadMode { STANDARD, CUSTOM, USBASP, ARDUINO_ISP }

    private lateinit var binding: ActivityArduinoHexUploadBinding
    private lateinit var usbSerialManager: UsbSerialManager
    private lateinit var usbaspManager: UsbaspManager
    private lateinit var arduinoIspManager: ArduinoIspManager

    private val boards = Boards.values()
    private val mcus = McuIdentifier.values()
    private val protocols = Protocol.values()
    private val sckOptions = UsbaspSckOption.values()
    private val usbaspMcus = UsbaspMcuTable.all
    private val memoryTypes = UsbaspMemoryType.values()

    private var uploadMode = UploadMode.STANDARD
    private var selectedBoard: Boards = Boards.ARDUINO_UNO
    private var selectedMcu: McuIdentifier = McuIdentifier.AtMega328P
    private var selectedProtocol: Protocol = Protocol.Stk500v1
    private var selectedUsbaspMcu: UsbaspMcuInfo = UsbaspMcuTable.default
    private var selectedSckOption: UsbaspSckOption = UsbaspSckOption.AUTO
    private var selectedMemoryType: UsbaspMemoryType = UsbaspMemoryType.FLASH
    private var selectedArduinoIspMcu: UsbaspMcuInfo = UsbaspMcuTable.default
    private var selectedArduinoIspMemoryType: UsbaspMemoryType = UsbaspMemoryType.FLASH

    private var selectedHexUri: Uri? = null
    private var hexValidated = false
    private var isUploading = false
    private var pendingReadBytes: ByteArray? = null

    // Backs the shared FlashForegroundService notification while an
    // Upload/Read/Verify is running - see setUploading() and
    // mainThreadPercentCallback() below, and FlashForegroundService's own
    // class doc comment for why this reuses the ESP screen's service
    // instead of standing up a second one.
    private var currentProgressLabel: String = ""
    private var lastNotifiedPercent = -1

    private val openHexFile =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            uri?.let { onHexFilePicked(it) }
        }

    private val saveReadResult =
        registerForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
            onSaveLocationPicked(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        binding = ActivityArduinoHexUploadBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        // The theme's android:statusBarColor / windowLightStatusBar are dead
        // weight here - both are silently ignored once setDecorFitsSystemWindows(false)
        // is in play (which targetSdk 35's enforced edge-to-edge effectively
        // requires). Without this, the status bar showed whatever the OS's own
        // light/dark default happened to be instead of matching the toolbar -
        // it "worked" in dark mode by coincidence and showed plain system icons
        // over a blank strip in light mode. The toolbar (appBarLayout's
        // colorPrimary, see applyWindowInsets() below for why that background
        // needs to reach behind the status bar too) is dark teal in both light
        // and dark theme, so light/white icons are correct unconditionally -
        // no day/night branch needed here, matching the theme's own
        // always-false windowLightStatusBar before edge-to-edge made it moot.
        WindowInsetsControllerCompat(window, binding.root).isAppearanceLightStatusBars = false
        applyWindowInsets()
        // Belt-and-suspenders alongside the XML attribute: makes sure this small log box
        // properly claims scroll gestures instead of losing them to the outer page ScrollView.
        binding.logScrollView.isNestedScrollingEnabled = true

        usbSerialManager = UsbSerialManager(this, lifecycle)
        usbSerialManager
            .addOnStateListener { refreshDeviceStatus(); updateUploadEnabled() }
            .addOnPermissionListener { refreshDeviceStatus(); updateUploadEnabled() }
            .addOnErrorListener { refreshDeviceStatus(); updateUploadEnabled() }

        usbaspManager = UsbaspManager(this, lifecycle)
        usbaspManager.addOnChangeListener { refreshDeviceStatus(); updateUploadEnabled() }

        // ArduinoISP uses a normal Arduino board — the same CH340/FTDI/CDC device already
        // managed by usbSerialManager — just speaking a different protocol over it, so it
        // doesn't need its own device-detection manager the way USBasp does.
        arduinoIspManager = ArduinoIspManager(this, usbSerialManager)

        setupUploadTypeToggle()
        setupBoardDropdown()
        setupCustomFields()
        setupUsbaspFields()
        setupArduinoIspFields()

        binding.browseButton.setOnClickListener { openHexFile.launch(arrayOf("*/*")) }
        binding.deviceStatusRow.setOnClickListener { onDeviceStatusRowClicked() }
        binding.uploadFab.setOnClickListener { startUpload() }
        binding.copyLogButton.setOnClickListener { copyLogToClipboard() }
        binding.usbaspReadButton.setOnClickListener { startRead() }
        binding.usbaspVerifyButton.setOnClickListener { startVerify() }
        binding.arduinoIspReadButton.setOnClickListener { startRead() }
        binding.arduinoIspVerifyButton.setOnClickListener { startVerify() }

        refreshDeviceStatus()
        updateUploadEnabled()
    }

    // region Setup

    private fun applyWindowInsets() {
        // Android 15 (targetSdk 35) draws edge-to-edge by default, so without this the FAB and
        // toolbar title can end up hidden behind the system status/navigation bars depending on
        // the device (3-button nav, gesture nav, etc.) — apply the real inset instead of a
        // fixed guess. This only pushes the toolbar's *content* down by the inset amount; the
        // space it opens up above the toolbar is still part of appBarLayout, which is why that
        // view needs its own colorPrimary background (see the layout XML) — otherwise that gap
        // shows through as whatever appBarLayout's default background is instead of matching
        // the toolbar, which is the other half of the status-bar-only-looks-right-in-dark-mode
        // issue this and the onCreate() isAppearanceLightStatusBars line together fix.
        val baseFabMargin = (binding.uploadFab.layoutParams as CoordinatorLayout.LayoutParams).bottomMargin
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())

            binding.appBarLayout.updatePadding(top = bars.top)
            binding.scrollContent.updatePadding(bottom = 96.dpToPx() + bars.bottom)
            binding.uploadFab.updateLayoutParams<CoordinatorLayout.LayoutParams> {
                bottomMargin = baseFabMargin + bars.bottom
            }

            insets
        }
    }

    private fun Int.dpToPx(): Int = (this * resources.displayMetrics.density).toInt()

    /**
     * Four modes no longer fit a single-row RadioGroup, and RadioGroup only manages direct
     * children for mutual exclusion anyway (these are laid out as a 2x2 grid of plain
     * RadioButtons), so exclusivity is handled here instead.
     */
    private fun setupUploadTypeToggle() {
        val radios = listOf(binding.radioStandard, binding.radioCustom, binding.radioUsbasp, binding.radioArduinoIsp)
        val modes = listOf(UploadMode.STANDARD, UploadMode.CUSTOM, UploadMode.USBASP, UploadMode.ARDUINO_ISP)

        val onSelected: (RadioButton, UploadMode) -> Unit = { selected, mode ->
            radios.forEach { it.isChecked = (it === selected) }
            uploadMode = mode
            binding.boardInputLayout.visibility = if (mode == UploadMode.STANDARD) View.VISIBLE else View.GONE
            binding.customFieldsContainer.visibility = if (mode == UploadMode.CUSTOM) View.VISIBLE else View.GONE
            binding.usbaspFieldsContainer.visibility = if (mode == UploadMode.USBASP) View.VISIBLE else View.GONE
            binding.arduinoIspFieldsContainer.visibility = if (mode == UploadMode.ARDUINO_ISP) View.VISIBLE else View.GONE
            if (selectedHexUri != null) validateSelectedHex()
            refreshDeviceStatus()
            updateUploadEnabled()
        }

        radios.forEachIndexed { index, radio ->
            radio.setOnClickListener { onSelected(radio, modes[index]) }
        }
    }

    private fun setupBoardDropdown() {
        val names = boards.map { it.boardName }
        binding.boardDropdown.setAdapter(
            ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, names)
        )
        binding.boardDropdown.setText(selectedBoard.boardName, false)
        binding.boardDropdown.setOnItemClickListener { _, _, position, _ ->
            selectedBoard = boards[position]
            if (selectedHexUri != null) validateSelectedHex()
        }
    }

    private fun setupCustomFields() {
        binding.mcuDropdown.setAdapter(
            ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, mcus.map { it.name })
        )
        binding.mcuDropdown.setText(selectedMcu.name, false)
        binding.mcuDropdown.setOnItemClickListener { _, _, position, _ ->
            selectedMcu = mcus[position]
            if (selectedHexUri != null) validateSelectedHex()
        }

        binding.protocolDropdown.setAdapter(
            ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, protocols.map { it.name })
        )
        binding.protocolDropdown.setText(selectedProtocol.name, false)
        binding.protocolDropdown.setOnItemClickListener { _, _, position, _ ->
            selectedProtocol = protocols[position]
            binding.customBaudRate.setText(defaultBaudRateFor(selectedProtocol).toString())
        }
    }

    private fun setupUsbaspFields() {
        // 169 parts — AutoCompleteTextView supports type-to-filter out of the box, which is
        // how a list this size stays usable (matches ZFlasher-style search-as-you-type UX).
        binding.usbaspMcuDropdown.setAdapter(
            ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, usbaspMcus.map { it.displayName })
        )
        binding.usbaspMcuDropdown.setText(selectedUsbaspMcu.displayName, false)
        binding.usbaspMcuDropdown.setOnItemClickListener { _, _, position, _ ->
            selectedUsbaspMcu = usbaspMcus[position]
            if (selectedHexUri != null) validateSelectedHex()
        }

        binding.usbaspMemoryDropdown.setAdapter(
            ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, memoryTypes.map { it.label })
        )
        binding.usbaspMemoryDropdown.setText(selectedMemoryType.label, false)
        binding.usbaspMemoryDropdown.setOnItemClickListener { _, _, position, _ ->
            selectedMemoryType = memoryTypes[position]
            if (selectedHexUri != null) validateSelectedHex()
            updateUploadEnabled()
        }

        binding.usbaspSckDropdown.setAdapter(
            ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, sckOptions.map { it.label })
        )
        binding.usbaspSckDropdown.setText(selectedSckOption.label, false)
        binding.usbaspSckDropdown.setOnItemClickListener { _, _, position, _ ->
            selectedSckOption = sckOptions[position]
        }
    }

    private fun setupArduinoIspFields() {
        binding.arduinoIspMcuDropdown.setAdapter(
            ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, usbaspMcus.map { it.displayName })
        )
        binding.arduinoIspMcuDropdown.setText(selectedArduinoIspMcu.displayName, false)
        binding.arduinoIspMcuDropdown.setOnItemClickListener { _, _, position, _ ->
            selectedArduinoIspMcu = usbaspMcus[position]
            if (selectedHexUri != null) validateSelectedHex()
        }

        binding.arduinoIspMemoryDropdown.setAdapter(
            ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, memoryTypes.map { it.label })
        )
        binding.arduinoIspMemoryDropdown.setText(selectedArduinoIspMemoryType.label, false)
        binding.arduinoIspMemoryDropdown.setOnItemClickListener { _, _, position, _ ->
            selectedArduinoIspMemoryType = memoryTypes[position]
            if (selectedHexUri != null) validateSelectedHex()
            updateUploadEnabled()
        }
    }

    // endregion

    // region Hex file picking + validation

    private fun onHexFilePicked(uri: Uri) {
        selectedHexUri = uri
        binding.hexFileName.text = queryDisplayName(uri) ?: uri.lastPathSegment ?: uri.toString()
        validateSelectedHex()
    }

    private fun queryDisplayName(uri: Uri): String? =
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && cursor.moveToFirst()) cursor.getString(idx) else null
        }

    /** The memory type relevant to whichever ISP-style mode (USBasp/ArduinoISP) is active. */
    private fun currentIspMemoryType(): UsbaspMemoryType =
        if (uploadMode == UploadMode.ARDUINO_ISP) selectedArduinoIspMemoryType else selectedMemoryType

    private fun currentIspMcu(): UsbaspMcuInfo =
        if (uploadMode == UploadMode.ARDUINO_ISP) selectedArduinoIspMcu else selectedUsbaspMcu

    /** Byte-size ceiling hex validation should check the selected file against. */
    private fun currentValidationSize(): Int = when (uploadMode) {
        UploadMode.STANDARD -> flashSizeFor(selectedBoard.chipType)
        UploadMode.CUSTOM -> flashSizeFor(selectedMcu)
        UploadMode.USBASP, UploadMode.ARDUINO_ISP -> {
            val mcu = currentIspMcu()
            if (currentIspMemoryType() == UsbaspMemoryType.EEPROM) mcu.eepromSize else mcu.flashSize
        }
    }

    private fun flashSizeFor(mcu: McuIdentifier): Int = when (mcu) {
        McuIdentifier.AtMega168 -> 16 * 1024
        McuIdentifier.AtMega328P -> 32 * 1024
        McuIdentifier.AtMega32U4 -> 32 * 1024
        McuIdentifier.AtMega1284, McuIdentifier.AtMega1284P -> 128 * 1024
        McuIdentifier.AtMega2560 -> 256 * 1024
    }

    private fun validateSelectedHex() {
        val uri = selectedHexUri ?: return
        val targetSize = currentValidationSize()

        binding.verifyRow.visibility = View.VISIBLE
        binding.verifyIcon.setImageResource(R.drawable.ic_check_circle_ahu)
        binding.verifyText.setTextColor(ContextCompat.getColor(this, R.color.ahu_neutral_500))
        binding.verifyText.text = getString(R.string.verify_checking)
        hexValidated = false
        updateUploadEnabled()

        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val lines = contentResolver.openInputStream(uri)?.use { input ->
                        LineReader(InputStreamReader(input)).readLines()
                    } ?: throw IllegalStateException("Could not open the selected file")
                    HexFileReader(lines, targetSize).Parse() as MemoryBlock
                }
            }

            result.onSuccess { block ->
                val used = block.highestModifiedOffset + 1
                if (used > targetSize) {
                    showVerifyError(getString(R.string.verify_too_big_format, formatBytes(targetSize)))
                } else {
                    val pct = (used * 100 / targetSize).coerceIn(0, 100)
                    binding.verifyIcon.setImageResource(R.drawable.ic_check_circle_ahu)
                    binding.verifyText.setTextColor(ContextCompat.getColor(this@ArduinoHexUploadActivity, R.color.ahu_success_600))
                    binding.verifyText.text =
                        getString(R.string.verify_valid_format, formatBytes(used), formatBytes(targetSize), pct)
                    hexValidated = true
                }
                updateUploadEnabled()
            }.onFailure { e ->
                showVerifyError(e.message ?: e.toString())
            }
        }
    }

    private fun showVerifyError(message: String) {
        binding.verifyIcon.setImageResource(R.drawable.ic_error_circle_ahu)
        binding.verifyText.setTextColor(ContextCompat.getColor(this, R.color.ahu_error_600))
        binding.verifyText.text = getString(R.string.verify_invalid_format, message)
        hexValidated = false
        updateUploadEnabled()
    }

    private fun formatBytes(n: Int): String = "%,d".format(n)

    // endregion

    // region Device status

    private fun onDeviceStatusRowClicked() {
        if (uploadMode == UploadMode.USBASP) {
            if (usbaspManager.device != null && !usbaspManager.hasPermission()) {
                usbaspManager.requestPermission()
            }
        } else {
            if (usbSerialManager.usbDevice != null && !usbSerialManager.hasPermission()) {
                usbSerialManager.requestPermission()
            }
        }
    }

    private fun refreshDeviceStatus() {
        if (uploadMode == UploadMode.USBASP) {
            val device = usbaspManager.device
            when {
                device == null -> {
                    binding.deviceStatusText.text = getString(R.string.device_none_usbasp)
                    tintStatusIcon(R.color.ahu_neutral_500)
                }
                !usbaspManager.hasPermission() -> {
                    binding.deviceStatusText.text = getString(R.string.device_needs_permission)
                    tintStatusIcon(R.color.ahu_warning_700)
                }
                else -> {
                    binding.deviceStatusText.text = getString(R.string.device_ready_format, "USBasp programmer")
                    tintStatusIcon(R.color.ahu_success_600)
                }
            }
            return
        }

        // Standard/Custom/ArduinoISP all use the same connected serial board.
        val device = usbSerialManager.usbDevice
        when {
            device == null -> {
                binding.deviceStatusText.text = getString(R.string.device_none)
                tintStatusIcon(R.color.ahu_neutral_500)
            }
            !usbSerialManager.hasPermission() -> {
                binding.deviceStatusText.text = getString(R.string.device_needs_permission)
                tintStatusIcon(R.color.ahu_warning_700)
            }
            else -> {
                binding.deviceStatusText.text =
                    getString(R.string.device_ready_format, UsbChipIdentifier.friendlyName(device))
                tintStatusIcon(R.color.ahu_success_600)
            }
        }
    }

    private fun tintStatusIcon(colorRes: Int) {
        binding.deviceStatusIcon.imageTintList = ColorStateList.valueOf(ContextCompat.getColor(this, colorRes))
    }

    // endregion

    // region Upload / Verify / Read

    private fun defaultBaudRateFor(protocol: Protocol): Int = when (protocol) {
        Protocol.Stk500v1 -> 57600
        Protocol.Stk500v2 -> 115200
        Protocol.Avr109 -> 57600
    }

    private fun defaultResetBehaviorFor(protocol: Protocol): Pair<String?, String?> = when (protocol) {
        Protocol.Stk500v1 -> "DTR;true" to "DTR-RTS;250;50"
        Protocol.Stk500v2 -> "DTR-RTS;50;250;true" to "DTR-RTS;250;50;true"
        Protocol.Avr109 -> "1200bps" to null
    }

    private fun isDeviceReady(): Boolean = if (uploadMode == UploadMode.USBASP) {
        usbaspManager.device != null && usbaspManager.hasPermission()
    } else {
        usbSerialManager.usbDevice != null && usbSerialManager.hasPermission()
    }

    /** Whether the active mode's selected memory type can be written/verified (Flash/EEPROM only). */
    private fun isWritableMemoryType(): Boolean = when (uploadMode) {
        UploadMode.USBASP, UploadMode.ARDUINO_ISP ->
            currentIspMemoryType() == UsbaspMemoryType.FLASH || currentIspMemoryType() == UsbaspMemoryType.EEPROM
        else -> true
    }

    private fun updateUploadEnabled() {
        val deviceReady = isDeviceReady()
        val writable = isWritableMemoryType()

        val uploadReady = !isUploading && hexValidated && deviceReady && writable
        binding.uploadFab.isEnabled = uploadReady
        binding.uploadFab.alpha = if (uploadReady) 1f else 0.5f

        val ispBaseReady = !isUploading && deviceReady
        binding.usbaspReadButton.isEnabled = ispBaseReady
        binding.usbaspVerifyButton.isEnabled = ispBaseReady && hexValidated && writable
        binding.arduinoIspReadButton.isEnabled = ispBaseReady
        binding.arduinoIspVerifyButton.isEnabled = ispBaseReady && hexValidated && writable
    }

    /**
     * [label] is only applied while turning the progress row ON - it drove
     * the same fixed "Uploading…" text for Upload, Read, *and* Verify
     * before, which is exactly why a USBasp Read used to show "Uploading…"
     * the whole time instead of "Reading…": all three called this with no
     * way to say which operation was actually running.
     *
     * Also starts/stops the shared [FlashForegroundService] notification
     * (owner [FlashForegroundService.OWNER_AVR]) so a long AVR
     * upload/read/verify keeps the app process alive if it's backgrounded,
     * the same protection the ESP Flasher screen already has - see that
     * service's class doc comment for how the two screens share it safely.
     */
    private fun setUploading(active: Boolean, label: CharSequence = getString(R.string.uploading)) {
        isUploading = active
        binding.progressContainer.visibility = if (active) View.VISIBLE else View.GONE
        if (active) {
            binding.progressLabelText.text = label
            currentProgressLabel = label.toString()
            lastNotifiedPercent = -1
            FlashForegroundService.start(applicationContext, "$currentProgressLabel 0%", FlashForegroundService.OWNER_AVR)
        } else {
            FlashForegroundService.stop(applicationContext, FlashForegroundService.OWNER_AVR)
        }
        binding.browseButton.isEnabled = !active
        binding.radioStandard.isEnabled = !active
        binding.radioCustom.isEnabled = !active
        binding.radioUsbasp.isEnabled = !active
        binding.radioArduinoIsp.isEnabled = !active
        binding.boardDropdown.isEnabled = !active
        binding.mcuDropdown.isEnabled = !active
        binding.protocolDropdown.isEnabled = !active
        binding.customBaudRate.isEnabled = !active
        binding.customBoardName.isEnabled = !active
        binding.usbaspMcuDropdown.isEnabled = !active
        binding.usbaspMemoryDropdown.isEnabled = !active
        binding.usbaspSckDropdown.isEnabled = !active
        binding.arduinoIspMcuDropdown.isEnabled = !active
        binding.arduinoIspMemoryDropdown.isEnabled = !active
        if (!active) binding.progressBar.setProgressCompat(0, false)
        updateUploadEnabled()
    }

    private fun appendLog(message: String) {
        if (binding.logText.text.isNullOrBlank()) {
            binding.logText.text = message
        } else {
            binding.logText.append("\n$message")
        }
        binding.logText.post { binding.logScrollView.fullScroll(View.FOCUS_DOWN) }
    }

    private fun copyLogToClipboard() {
        val text = binding.logText.text?.toString().orEmpty()
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Upload log", text))
        Snackbar.make(binding.root, R.string.log_copied, Snackbar.LENGTH_SHORT).show()
    }

    // UsbSerialManager/UsbaspManager/ArduinoIspManager all invoke these callbacks from a
    // background dispatcher while an operation is running, but the callback bodies touch Views
    // — so they must always hop back to the main thread. runOnUiThread executes immediately if
    // already on it, so this is free in the common case and just correct in the background case.
    private fun mainThreadPercentCallback(): (Int) -> Unit = { percent ->
        runOnUiThread {
            binding.progressBar.setProgressCompat(percent, true)
            binding.progressPercentText.text = "$percent%"
            // Throttled to every 5% - updating the system notification on
            // every single 1% tick would spam NotificationManager for no
            // visible benefit once the shade is already showing "running".
            if (percent - lastNotifiedPercent >= 5 || percent >= 100) {
                lastNotifiedPercent = percent
                FlashForegroundService.updateStatus(
                    applicationContext, "$currentProgressLabel $percent%", FlashForegroundService.OWNER_AVR
                )
            }
        }
    }

    private fun mainThreadMessageCallback(): (String) -> Unit = { message ->
        runOnUiThread { appendLog(message) }
    }

    private fun startUpload() {
        val uri = selectedHexUri
        if (uri == null) {
            Snackbar.make(binding.root, R.string.error_pick_hex_first, Snackbar.LENGTH_SHORT).show()
            return
        }
        if (!isDeviceReady()) {
            Snackbar.make(binding.root, R.string.error_device_first, Snackbar.LENGTH_SHORT).show()
            return
        }

        setUploading(true)
        binding.logText.text = ""

        lifecycleScope.launch {
            val stream = withContext(Dispatchers.IO) { contentResolver.openInputStream(uri) }
            if (stream == null) {
                appendLog("Could not open the selected file.")
                setUploading(false)
                return@launch
            }

            val percentCallback = mainThreadPercentCallback()
            val messageCallback = mainThreadMessageCallback()
            val completeCallback: (Boolean) -> Unit = { success ->
                runOnUiThread {
                    setUploading(false)
                    appendLog(if (success) "\u2713 Upload complete" else "\u2717 Upload failed — see the error above")
                    Snackbar.make(
                        binding.root,
                        if (success) R.string.upload_success else R.string.upload_failed,
                        Snackbar.LENGTH_LONG
                    ).show()
                }
            }

            when (uploadMode) {
                UploadMode.STANDARD -> usbSerialManager.uploadHex(
                    firmware = stream,
                    board = selectedBoard,
                    percentCallback = percentCallback,
                    messageCallback = messageCallback,
                    completeCallback = completeCallback
                )

                UploadMode.CUSTOM -> {
                    val (preOpen, close) = defaultResetBehaviorFor(selectedProtocol)
                    val arduino = Arduino(
                        model = binding.customBoardName.text?.toString()?.ifBlank { null } ?: "Custom board",
                        mcu = selectedMcu,
                        baudRate = binding.customBaudRate.text?.toString()?.toIntOrNull()
                            ?: defaultBaudRateFor(selectedProtocol),
                        protocol = selectedProtocol,
                        preOpenResetBehavior = preOpen,
                        closeResetBehavior = close
                    )
                    usbSerialManager.uploadHexCustom(
                        firmware = stream,
                        arduino = arduino,
                        percentCallback = percentCallback,
                        messageCallback = messageCallback,
                        completeCallback = completeCallback
                    )
                }

                UploadMode.USBASP -> usbaspManager.uploadHex(
                    firmware = stream,
                    mcu = selectedUsbaspMcu,
                    memoryType = selectedMemoryType,
                    sckOption = selectedSckOption,
                    percentCallback = percentCallback,
                    messageCallback = messageCallback,
                    completeCallback = completeCallback
                )

                UploadMode.ARDUINO_ISP -> arduinoIspManager.uploadHex(
                    firmware = stream,
                    mcu = selectedArduinoIspMcu,
                    memoryType = selectedArduinoIspMemoryType,
                    percentCallback = percentCallback,
                    messageCallback = messageCallback,
                    completeCallback = completeCallback
                )
            }
        }
    }

    private fun startVerify() {
        val uri = selectedHexUri
        if (uri == null) {
            Snackbar.make(binding.root, R.string.error_pick_hex_first, Snackbar.LENGTH_SHORT).show()
            return
        }
        if (!isDeviceReady()) {
            Snackbar.make(binding.root, R.string.error_device_first, Snackbar.LENGTH_SHORT).show()
            return
        }

        setUploading(true, getString(R.string.verifying))
        binding.logText.text = ""

        lifecycleScope.launch {
            val stream = withContext(Dispatchers.IO) { contentResolver.openInputStream(uri) }
            if (stream == null) {
                appendLog("Could not open the selected file.")
                setUploading(false)
                return@launch
            }

            val percentCallback = mainThreadPercentCallback()
            val messageCallback = mainThreadMessageCallback()
            val completeCallback: (Boolean) -> Unit = { success ->
                runOnUiThread {
                    setUploading(false)
                    appendLog(if (success) "\u2713 Verify complete" else "\u2717 Verify failed — see the error above")
                    Snackbar.make(
                        binding.root,
                        if (success) R.string.verify_success else R.string.verify_failed,
                        Snackbar.LENGTH_LONG
                    ).show()
                }
            }

            if (uploadMode == UploadMode.ARDUINO_ISP) {
                arduinoIspManager.verify(
                    firmware = stream,
                    mcu = selectedArduinoIspMcu,
                    memoryType = selectedArduinoIspMemoryType,
                    percentCallback = percentCallback,
                    messageCallback = messageCallback,
                    completeCallback = completeCallback
                )
            } else {
                usbaspManager.verify(
                    firmware = stream,
                    mcu = selectedUsbaspMcu,
                    memoryType = selectedMemoryType,
                    sckOption = selectedSckOption,
                    percentCallback = percentCallback,
                    messageCallback = messageCallback,
                    completeCallback = completeCallback
                )
            }
        }
    }

    private fun startRead() {
        if (!isDeviceReady()) {
            Snackbar.make(binding.root, R.string.error_device_first, Snackbar.LENGTH_SHORT).show()
            return
        }

        setUploading(true, getString(R.string.reading_device))
        binding.logText.text = ""

        lifecycleScope.launch {
            val percentCallback = mainThreadPercentCallback()
            val messageCallback = mainThreadMessageCallback()

            val result = if (uploadMode == UploadMode.ARDUINO_ISP) {
                arduinoIspManager.readMemory(
                    mcu = selectedArduinoIspMcu,
                    memoryType = selectedArduinoIspMemoryType,
                    percentCallback = percentCallback,
                    messageCallback = messageCallback
                )
            } else {
                usbaspManager.readMemory(
                    mcu = selectedUsbaspMcu,
                    memoryType = selectedMemoryType,
                    sckOption = selectedSckOption,
                    percentCallback = percentCallback,
                    messageCallback = messageCallback
                )
            }

            when (result) {
                is UsbaspReadResult.Data -> {
                    // Read succeeded — now ask where to save it. setUploading(false) happens in
                    // onSaveLocationPicked() once that finishes (or is cancelled).
                    pendingReadBytes = result.bytes
                    val safeName = currentIspMcu().displayName.replace(Regex("[^A-Za-z0-9._-]"), "_")
                    val modePrefix = if (uploadMode == UploadMode.ARDUINO_ISP) "arduinoisp" else "usbasp"
                    saveReadResult.launch("${modePrefix}_${currentIspMemoryType().label.lowercase()}_$safeName.hex")
                }
                UsbaspReadResult.SingleValueLogged -> {
                    setUploading(false)
                    appendLog("\u2713 Read complete")
                    Snackbar.make(binding.root, R.string.read_success, Snackbar.LENGTH_LONG).show()
                }
                UsbaspReadResult.Failed -> {
                    setUploading(false)
                    appendLog("\u2717 Read failed — see the error above")
                    Snackbar.make(binding.root, R.string.read_failed, Snackbar.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun onSaveLocationPicked(uri: Uri?) {
        val bytes = pendingReadBytes
        pendingReadBytes = null

        if (uri == null || bytes == null) {
            setUploading(false)
            return
        }

        lifecycleScope.launch {
            val saved = withContext(Dispatchers.IO) {
                runCatching {
                    contentResolver.openOutputStream(uri)?.use { out ->
                        out.write(IntelHexWriter.encode(bytes).toByteArray())
                    } ?: throw IllegalStateException("Could not open the destination file")
                }
            }
            setUploading(false)
            saved.onSuccess {
                appendLog(getString(R.string.read_saved_format, queryDisplayName(uri) ?: uri.toString()))
                appendLog("\u2713 Read complete")
                Snackbar.make(binding.root, R.string.read_success, Snackbar.LENGTH_LONG).show()
            }.onFailure { e ->
                appendLog("ERROR: ${e.message ?: e.javaClass.simpleName}")
                Snackbar.make(binding.root, R.string.read_failed, Snackbar.LENGTH_LONG).show()
            }
        }
    }

    // endregion

    /**
     * Safety net for leaving this screen mid-operation (back button, task
     * kill, ...): lifecycleScope cancels the running upload/read/verify
     * coroutine right away, but that means it never reaches its own
     * completeCallback - the one place setUploading(false) would otherwise
     * run - so without this, FlashForegroundService's AVR owner would stay
     * registered forever and keep the shared notification pinned on.
     */
    override fun onDestroy() {
        if (isUploading) {
            FlashForegroundService.stop(applicationContext, FlashForegroundService.OWNER_AVR)
        }
        super.onDestroy()
    }
}
