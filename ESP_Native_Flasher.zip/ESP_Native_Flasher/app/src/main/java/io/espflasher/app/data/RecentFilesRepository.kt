package io.espflasher.app.data

import android.content.Context
import android.net.Uri
import io.espflasher.app.flashing.ImageSlot

data class RecentFileEntry(val uri: Uri, val fileName: String, val offset: Long)

/**
 * Small SharedPreferences-backed store for "remember previously selected
 * files" - just five slots (Bootloader/Partition Table/OTA Data/Application/
 * Firmware), each remembering its content:// URI, display name, and the
 * offset the person last typed in for it.
 */
class RecentFilesRepository(context: Context) {

    private val prefs = context.getSharedPreferences("esp_flasher_recent_files", Context.MODE_PRIVATE)

    fun save(slot: ImageSlot, uri: Uri, fileName: String, offset: Long) {
        prefs.edit()
            .putString(uriKey(slot), uri.toString())
            .putString(nameKey(slot), fileName)
            .putLong(offsetKey(slot), offset)
            .apply()
    }

    fun load(slot: ImageSlot): RecentFileEntry? {
        val uriString = prefs.getString(uriKey(slot), null) ?: return null
        val name = prefs.getString(nameKey(slot), "") ?: ""
        val offset = prefs.getLong(offsetKey(slot), defaultOffset(slot))
        return RecentFileEntry(Uri.parse(uriString), name, offset)
    }

    fun clear(slot: ImageSlot) {
        prefs.edit().remove(uriKey(slot)).remove(nameKey(slot)).remove(offsetKey(slot)).apply()
    }

    /** Just the offset (used to pre-fill a slot's offset field even with no file chosen yet). */
    fun loadOffset(slot: ImageSlot): Long = prefs.getLong(offsetKey(slot), defaultOffset(slot))

    fun saveOffset(slot: ImageSlot, offset: Long) {
        prefs.edit().putLong(offsetKey(slot), offset).apply()
    }

    private fun defaultOffset(slot: ImageSlot): Long = when (slot) {
        ImageSlot.BOOTLOADER -> 0x1000L
        ImageSlot.PARTITION_TABLE -> 0x8000L
        ImageSlot.OTA_DATA -> 0xD000L
        ImageSlot.APPLICATION -> 0x10000L
        ImageSlot.FIRMWARE -> 0x0L
        ImageSlot.CUSTOM -> 0x0L
    }

    private fun uriKey(slot: ImageSlot) = "${slot.name}_uri"
    private fun nameKey(slot: ImageSlot) = "${slot.name}_name"
    private fun offsetKey(slot: ImageSlot) = "${slot.name}_offset"
}
