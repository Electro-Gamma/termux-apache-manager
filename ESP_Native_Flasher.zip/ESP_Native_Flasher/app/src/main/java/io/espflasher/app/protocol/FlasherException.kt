package io.espflasher.app.protocol

/**
 * Base type for every error this app can raise, so the UI layer can show a
 * meaningful, specific message instead of a generic failure.
 */
sealed class FlasherException(message: String, cause: Throwable? = null) : Exception(message, cause) {

    class UsbDisconnected :
        FlasherException("USB device was disconnected.")

    class PermissionDenied(deviceName: String) :
        FlasherException("USB permission denied for $deviceName. Reconnect the device and accept the permission prompt.")

    class SyncFailed(attempts: Int) :
        FlasherException("Failed to sync with the chip after $attempts attempts. Hold BOOT/IO0 while resetting, or check wiring and baud rate.")

    class InvalidFirmware(reason: String) :
        FlasherException("Invalid firmware image: $reason")

    class FlashTimeout(operation: String) :
        FlasherException("Timed out waiting for a response during $operation.")

    class UnsupportedChip(detail: String) :
        FlasherException("Could not identify a supported Espressif chip ($detail).")

    class InvalidAddress(address: Long) :
        FlasherException("Invalid flash address: 0x%08X".format(address))

    class ChecksumMismatch(expected: String, actual: String) :
        FlasherException("Checksum mismatch after write: expected $expected, got $actual.")

    class RomError(op: String, statusByte: Int, reasonByte: Int) :
        FlasherException("ROM rejected '$op' (status=0x%02X reason=0x%02X)".format(statusByte, reasonByte))

    class NoDeviceFound :
        FlasherException("No supported USB-UART bridge was found. Plug in a device and grant USB permission.")

    class OperationCancelled :
        FlasherException("Operation cancelled.")

    class Generic(message: String, cause: Throwable? = null) : FlasherException(message, cause)
}
