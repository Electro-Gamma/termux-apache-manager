package io.espflasher.app.ui

import android.net.Uri
import io.espflasher.app.flashing.DeviceInfoSnapshot
import io.espflasher.app.flashing.FlashOptions
import io.espflasher.app.flashing.ImageSlot
import io.espflasher.app.flashing.LogEntry
import io.espflasher.app.flashing.ProgressState
import io.espflasher.app.usb.SerialConfig
import io.espflasher.app.usb.UsbDeviceInfo

enum class ConnectionState { DISCONNECTED, CONNECTING, CONNECTED }

/** A file the person picked via SAF for one of the five named slots. */
data class SelectedFile(
    val uri: Uri,
    val fileName: String,
    val sizeBytes: Long
)

data class MainUiState(
    val usbHostSupported: Boolean = true,
    val availableDevices: List<UsbDeviceInfo> = emptyList(),
    val selectedDeviceName: String? = null,
    val connectionState: ConnectionState = ConnectionState.DISCONNECTED,
    val serialConfig: SerialConfig = SerialConfig(),

    val files: Map<ImageSlot, SelectedFile> = emptyMap(),
    val offsetText: Map<ImageSlot, String> = emptyMap(),
    val enabledSlots: Set<ImageSlot> = emptySet(),

    val flashOptions: FlashOptions = FlashOptions(),

    val progress: ProgressState = ProgressState.IDLE,
    val deviceInfo: DeviceInfoSnapshot? = null,
    val logs: List<LogEntry> = emptyList(),
    val isBusy: Boolean = false,
    val consoleFontSizeSp: Int = 12,

    val advancedRegAddressText: String = "0x3FF00000",
    val advancedRegValueText: String = "",
    val advancedReadOffsetText: String = "0x0",
    val advancedReadLengthText: String = "0x1000",

    val lastError: String? = null
) {
    val isConnected: Boolean get() = connectionState == ConnectionState.CONNECTED
}
