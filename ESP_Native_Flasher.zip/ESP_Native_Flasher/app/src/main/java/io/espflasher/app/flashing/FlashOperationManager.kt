package io.espflasher.app.flashing

import android.content.Context
import android.hardware.usb.UsbDevice
import android.net.Uri
import io.espflasher.app.protocol.ChipType
import io.espflasher.app.protocol.Compressor
import io.espflasher.app.protocol.EspCommand
import io.espflasher.app.protocol.EspRomLoader
import io.espflasher.app.protocol.FlashLayout
import io.espflasher.app.protocol.FlasherException
import io.espflasher.app.protocol.ImageHeader
import io.espflasher.app.protocol.ResetSequences
import io.espflasher.app.usb.SerialConfig
import io.espflasher.app.usb.UsbSerialManager
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import java.security.MessageDigest

/**
 * The single entry point the ViewModel drives for every button on the main
 * screen. Owns the currently-open [io.espflasher.app.usb.UsbSerialPort] and
 * [EspRomLoader], and translates each high-level operation (Detect, Erase,
 * Flash, Verify, Read) into the right sequence of protocol calls, reporting
 * progress and console output through [FlashCallback] rather than touching
 * any UI/StateFlow type directly.
 *
 * Cancellation (the Stop button): callers run these suspend functions in a
 * cancellable coroutine `Job`. Block-write loops check
 * `currentCoroutineContext().ensureActive()` every block (a few KB), so Stop
 * takes effect almost immediately during the bulk of any transfer; it can
 * take a couple of seconds longer if cancelled while waiting on a single
 * long call (e.g. a multi-megabyte erase-timeout window), which is an
 * inherent limitation of interrupting blocking USB bulk I/O.
 */
class FlashOperationManager(
    private val context: Context,
    private val usbSerialManager: UsbSerialManager
) {
    companion object {
        /** Matches esptool's common --baud 921600 recommendation for fast flashing. */
        const val FAST_BAUD_RATE = 921600
    }

    private var port: io.espflasher.app.usb.UsbSerialPort? = null
    private var loader: EspRomLoader? = null

    var detectedChip: ChipType? = null
        private set
    var detectedFlashSizeBytes: Long? = null
        private set

    /**
     * True only right after a successful sync - i.e. the chip is confirmed
     * to actually be sitting in the ROM bootloader listening for commands
     * right now. Knowing the chip *type* from an earlier Detect doesn't mean
     * it's still there: a Reset (intentional, e.g. after flashing) boots it
     * into the app instead, and the next operation needs a fresh sync before
     * trusting the connection again, not just the cached chip type.
     */
    private var inBootloader: Boolean = false

    val isConnected: Boolean get() = port?.isOpen == true
    val connectedDeviceInfo get() = port?.info

    // -----------------------------------------------------------------
    // Connection lifecycle
    // -----------------------------------------------------------------

    suspend fun connect(device: UsbDevice, config: SerialConfig, callback: FlashCallback) {
        if (!usbSerialManager.hasPermission(device)) {
            callback.onLog(LogLevel.INFO, "Requesting USB permission...")
            val granted = usbSerialManager.requestPermission(device)
            if (!granted) throw FlasherException.PermissionDenied(device.deviceName)
        }
        val newPort = usbSerialManager.buildPort(device, config)
        newPort.open()
        port = newPort
        loader = EspRomLoader(newPort)
        detectedChip = null
        detectedFlashSizeBytes = null
        inBootloader = false
        callback.onLog(
            LogLevel.SUCCESS,
            "Connected to ${newPort.info.displayLabel} (${newPort.info.vidPidHex}) at ${config.baudRate} baud"
        )
    }

    suspend fun disconnect(callback: FlashCallback) {
        runCatching { port?.close() }
        port = null
        loader = null
        detectedChip = null
        detectedFlashSizeBytes = null
        inBootloader = false
        callback.onLog(LogLevel.INFO, "Disconnected")
    }

    suspend fun resetDevice(callback: FlashCallback) {
        val p = port ?: throw FlasherException.UsbDisconnected()
        ResetSequences.resetToRun(p)
        inBootloader = false
        callback.onLog(LogLevel.INFO, "Reset - device is now running its flashed application")
    }

    suspend fun enterBootloaderManual(callback: FlashCallback) {
        val p = port ?: throw FlasherException.UsbDisconnected()
        ResetSequences.enterBootloader(p)
        callback.onLog(LogLevel.INFO, "Reset into the UART download bootloader")
    }

    // -----------------------------------------------------------------
    // Detect
    // -----------------------------------------------------------------

    suspend fun detectDevice(callback: FlashCallback): DeviceInfoSnapshot {
        val ld = requireLoader()
        val p = port ?: throw FlasherException.UsbDisconnected()

        callback.onLog(LogLevel.INFO, "Resetting into bootloader...")
        ResetSequences.enterBootloader(p)
        callback.onLog(LogLevel.COMMAND, "-> SYNC")
        var synced = ld.sync()
        if (!synced) {
            callback.onLog(LogLevel.WARNING, "No response - retrying bootloader entry...")
            ResetSequences.enterBootloader(p)
            synced = ld.sync()
        }
        if (!synced) throw FlasherException.SyncFailed(7)
        callback.onLog(LogLevel.SUCCESS, "<- Sync OK")

        val chip = ld.detectChip()
        detectedChip = chip
        inBootloader = true
        callback.onLog(LogLevel.SUCCESS, "Chip: ${chip.displayName}")

        if (chip == ChipType.ESP8266) {
            // ESP8266's ROM has no SPI_ATTACH command at all - esptool attaches
            // flash as a side effect of a zero-size flash_begin() instead.
            runCatching { ld.flashBegin(chip, 0, 0) }.onFailure {
                callback.onLog(LogLevel.WARNING, "SPI attach (via zero-size flash_begin) failed: ${it.message}")
            }
        } else {
            ld.spiAttach()
        }

        val mac = runCatching { ld.readMac(chip) }.getOrElse {
            callback.onLog(LogLevel.WARNING, "Could not read MAC address: ${it.message}")
            "Unknown"
        }
        callback.onLog(LogLevel.INFO, "MAC address: $mac")

        val flashId = runCatching { ld.readFlashId(chip) }.getOrElse {
            callback.onLog(LogLevel.WARNING, "Could not read flash ID: ${it.message}")
            null
        }
        val flashSize = flashId?.sizeBytes
        detectedFlashSizeBytes = flashSize
        if (flashSize != null) {
            callback.onLog(LogLevel.INFO, "Flash: ${FlashLayout.humanReadableSize(flashSize)} " +
                "(mfr=0x%02X, memType=0x%02X)".format(flashId.manufacturer, flashId.memoryType))
            if (chip != ChipType.ESP8266) {
                // Not implemented in ESP8266's ROM at all - esptool silently skips it there too.
                runCatching { ld.setSpiFlashParameters(flashSize) }.onFailure {
                    callback.onLog(LogLevel.WARNING, "Could not set SPI flash parameters: ${it.message}")
                }
            }
        } else {
            callback.onLog(LogLevel.WARNING, "Flash size unknown - erase/write may fail until it's detected.")
        }

        val security = if (chip.supportsSecurityInfo) runCatching { ld.getSecurityInfo() }.getOrNull() else null

        return DeviceInfoSnapshot(
            chip = chip,
            revision = "Not exposed via ROM-only mode",
            macAddress = mac,
            crystalFreqMHz = 40,
            flashId = flashId,
            flashSizeBytes = flashSize,
            flashMode = null,
            features = chipFeatures(chip),
            securityInfo = security
        )
    }

    // -----------------------------------------------------------------
    // Erase
    // -----------------------------------------------------------------

    suspend fun eraseFlash(callback: FlashCallback) {
        val (ld, chip) = ensureReady(callback)
        val p = port ?: throw FlasherException.UsbDisconnected()
        withFastBaud(ld, p, callback) {
            eraseCore(ld, chip, callback)
        }
    }

    /** The actual erase, with no baud bracketing of its own - callers (eraseFlash, writeImages) handle that. */
    private suspend fun eraseCore(ld: EspRomLoader, chip: ChipType, callback: FlashCallback) {
        val size = detectedFlashSizeBytes
            ?: throw FlasherException.Generic("Flash size unknown - run Detect first, or the flash ID couldn't be read.")

        // The ROM has no dedicated "erase without writing" command outside a
        // stub loader - flash_begin's up-front erase only takes effect once
        // you actually complete the block sequence it expects; skipping
        // straight to flash_end after a bare begin gets rejected. So "erase"
        // here means writing 0xFF across the whole chip instead: flash_begin
        // already blanks every sector it covers, so this simply confirms
        // that blank state through the same write path already proven to
        // work, and since the buffer is one repeated byte, it compresses to
        // a few KB regardless of flash size - the erase is what's slow here,
        // not the transfer.
        callback.onLog(LogLevel.COMMAND, "Erasing ${FlashLayout.humanReadableSize(size)} - this can take a while...")
        val blank = ByteArray(size.toInt())
        blank.fill(0xFF.toByte())
        transferToFlash(ld, chip, blank, offset = 0, compress = true, skipChecksum = false, label = "Erasing flash", callback = callback)
        callback.onLog(LogLevel.SUCCESS, "Flash erased.")
    }

    // -----------------------------------------------------------------
    // Write
    // -----------------------------------------------------------------

    suspend fun writeImages(images: List<FlashImage>, options: FlashOptions, callback: FlashCallback) {
        if (images.isEmpty()) throw FlasherException.Generic("No files selected to flash.")
        val (ld, chip) = ensureReady(callback)
        val p = port ?: throw FlasherException.UsbDisconnected()
        val sorted = images.sortedBy { it.offset }

        // One fast-baud bracket covers erase + write + verify - all the
        // actual data transfer - then drops back to the original baud while
        // the chip is still confirmed in the bootloader (so the revert
        // command is guaranteed to actually be heard). Reset happens last,
        // after baud is already back to normal: it's a DTR/RTS pulse, not a
        // UART command, so its correctness never depended on baud anyway,
        // but doing it last keeps the ordering easy to reason about.
        withFastBaud(ld, p, callback) {
            if (options.eraseBeforeWrite) {
                eraseCore(ld, chip, callback)
            }
            for (image in sorted) {
                currentCoroutineContext().ensureActive()
                writeSingleImage(ld, chip, image, options, callback)
            }
            if (options.verifyAfterWrite) {
                verifyCore(ld, sorted, callback)
            }
        }

        if (options.resetAfterFlashing) {
            resetDevice(callback)
        }
    }

    private suspend fun writeSingleImage(
        ld: EspRomLoader,
        chip: ChipType,
        image: FlashImage,
        options: FlashOptions,
        callback: FlashCallback
    ) {
        if (image.offset < 0) throw FlasherException.InvalidAddress(image.offset)

        callback.onLog(LogLevel.INFO, "Reading ${image.fileName}...")
        val data = readAllBytes(image.uri)

        if (image.requiresImageMagic && !ImageHeader.looksValid(data)) {
            callback.onLog(
                LogLevel.WARNING,
                "${image.fileName} doesn't start with the ESP image magic byte (0xE9) - could be the wrong " +
                    "file for the ${image.label} slot, or it could be a merged/combined image, filesystem " +
                    "image, or other raw payload that's fine to flash as-is. Proceeding."
            )
        }

        transferToFlash(ld, chip, data, image.offset, options.compressData, options.skipChecksum, "Writing ${image.label}", callback)
        callback.onLog(LogLevel.SUCCESS, "Wrote ${image.label}: ${data.size} bytes at 0x%X".format(image.offset))
    }

    /**
     * The one place that actually streams bytes to flash via flash_begin,
     * flash_data, and flash_end (or the compressed _defl_ variants). Used for
     * both real file writes and for [eraseFlash]'s all-0xFF pass, so there's
     * exactly one implementation of the block-chunking/checksum/progress
     * logic to get right.
     */
    private suspend fun transferToFlash(
        ld: EspRomLoader,
        chip: ChipType,
        data: ByteArray,
        offset: Long,
        compress: Boolean,
        skipChecksum: Boolean,
        label: String,
        callback: FlashCallback
    ) {
        callback.onLog(LogLevel.COMMAND, "flash_begin size=0x%X offset=0x%X compress=%s".format(data.size, offset, compress))
        val checksumOverride = if (skipChecksum) 0 else null

        if (compress) {
            val compressed = Compressor.zlibCompress(data)
            callback.onLog(LogLevel.DEBUG, "Compressed ${data.size} -> ${compressed.size} bytes")
            ld.flashDeflBegin(chip, data.size.toLong(), compressed.size.toLong(), offset)
            val tracker = ProgressTracker(compressed.size.toLong(), label)
            var seq = 0
            var pos = 0
            while (pos < compressed.size) {
                currentCoroutineContext().ensureActive()
                val len = minOf(EspCommand.FLASH_WRITE_SIZE, compressed.size - pos)
                val block = compressed.copyOfRange(pos, pos + len)
                ld.flashDeflBlock(block, seq, checksumOverride = checksumOverride)
                pos += len
                seq++
                val estimatedAddr = offset + (pos.toLong() * data.size / compressed.size.coerceAtLeast(1))
                callback.onProgress(tracker.update(pos.toLong(), estimatedAddr))
            }
        } else {
            ld.flashBegin(chip, data.size.toLong(), offset)
            val tracker = ProgressTracker(data.size.toLong(), label)
            var seq = 0
            var pos = 0
            while (pos < data.size) {
                currentCoroutineContext().ensureActive()
                val remaining = data.size - pos
                val len = minOf(EspCommand.FLASH_WRITE_SIZE, remaining)
                val block = if (len == EspCommand.FLASH_WRITE_SIZE) {
                    data.copyOfRange(pos, pos + len)
                } else {
                    ByteArray(EspCommand.FLASH_WRITE_SIZE) { i -> if (i < len) data[pos + i] else 0xFF.toByte() }
                }
                ld.flashBlock(block, seq, checksumOverride = checksumOverride)
                pos += len
                seq++
                callback.onProgress(tracker.update(pos.toLong().coerceAtMost(data.size.toLong()), offset + pos))
            }
        }

        ld.flashFinish(reboot = false, compressed = compress)
        callback.onProgress(ProgressState.IDLE)
    }

    // -----------------------------------------------------------------
    // Verify
    // -----------------------------------------------------------------

    suspend fun verifyImages(images: List<FlashImage>, callback: FlashCallback) {
        if (images.isEmpty()) throw FlasherException.Generic("No files selected to verify.")
        val (ld, _) = ensureReady(callback)
        val p = port ?: throw FlasherException.UsbDisconnected()
        withFastBaud(ld, p, callback) {
            verifyCore(ld, images, callback)
        }
    }

    private suspend fun verifyCore(ld: EspRomLoader, images: List<FlashImage>, callback: FlashCallback) {
        for (image in images.sortedBy { it.offset }) {
            currentCoroutineContext().ensureActive()
            callback.onLog(LogLevel.INFO, "Verifying ${image.label} (${image.fileName})...")
            val data = readAllBytes(image.uri)
            val localMd5 = md5Hex(data)
            callback.onLog(LogLevel.COMMAND, "flash_md5 offset=0x%X size=0x%X".format(image.offset, data.size))
            val remoteMd5 = ld.flashMd5(image.offset, data.size.toLong())
            if (!localMd5.equals(remoteMd5, ignoreCase = true)) {
                throw FlasherException.ChecksumMismatch(localMd5, remoteMd5)
            }
            callback.onLog(LogLevel.SUCCESS, "${image.label} verified OK (MD5 $localMd5)")
        }
    }

    // -----------------------------------------------------------------
    // Read / dump
    // -----------------------------------------------------------------

    suspend fun readFlashToFile(offset: Long, length: Long, destUri: Uri, callback: FlashCallback) {
        val (ld, chip) = ensureReady(callback)
        val p = port ?: throw FlasherException.UsbDisconnected()
        if (!ld.supportsRomOnlyRead(chip)) {
            throw FlasherException.Generic(
                "Reading flash on ${chip.displayName} needs a stub loader, which this build doesn't bundle " +
                    "(see the Stub Loader note under Advanced). ROM-only reading currently only works on classic ESP32."
            )
        }
        withFastBaud(ld, p, callback) {
            val tracker = ProgressTracker(length, "Reading flash")
            callback.onLog(LogLevel.COMMAND, "read_flash offset=0x%X size=0x%X".format(offset, length))
            val data = ld.readFlashRomOnly(offset, length) { done, _ ->
                callback.onProgress(tracker.update(done, offset + done))
            }
            context.contentResolver.openOutputStream(destUri)?.use { it.write(data) }
                ?: throw FlasherException.Generic("Could not open the destination file for writing.")
            callback.onProgress(ProgressState.IDLE)
            callback.onLog(LogLevel.SUCCESS, "Read ${data.size} bytes to file.")
        }
    }

    // -----------------------------------------------------------------
    // Advanced: raw register / memory access
    // -----------------------------------------------------------------

    suspend fun readRegister(addr: Long): Long = requireLoader().readReg(addr)

    suspend fun writeRegister(addr: Long, value: Long) = requireLoader().writeReg(addr, value)

    // -----------------------------------------------------------------
    // Helpers
    // -----------------------------------------------------------------

    private suspend fun ensureReady(callback: FlashCallback): Pair<EspRomLoader, ChipType> {
        val ld = requireLoader()
        val chip = if (inBootloader && detectedChip != null) {
            detectedChip!!
        } else {
            detectDevice(callback).chip
        }
        return ld to chip
    }

    /**
     * Brackets a data-heavy operation (erase/write/verify/read) with a
     * temporary bump to [FAST_BAUD_RATE], reverting to whatever baud the
     * connection started at once [block] finishes - success, failure, or
     * cancellation. Detect deliberately never calls this: it stays at
     * whatever baud the person connected with (esptool's own default is
     * 115200, matching this app's), and only the operations that actually
     * move bulk data pay the cost of switching up and back down.
     *
     * The revert is careful to never depend on the chip still being there:
     * if it doesn't answer the revert command (e.g. it was reset to run the
     * app as part of this same operation, or the fast rate never really
     * worked in the first place), only the local port's baud is fixed back
     * up rather than raising an error - there's nothing meaningful left to
     * tell a chip that's no longer listening as a ROM bootloader.
     */
    private suspend fun <T> withFastBaud(
        ld: EspRomLoader,
        p: io.espflasher.app.usb.UsbSerialPort,
        callback: FlashCallback,
        block: suspend () -> T
    ): T {
        val originalBaud = p.config.baudRate
        var switchedUp = false
        if (originalBaud < FAST_BAUD_RATE) {
            callback.onLog(LogLevel.INFO, "Switching to $FAST_BAUD_RATE baud...")
            val switched = runCatching {
                ld.changeBaudRate(FAST_BAUD_RATE)
                ld.sync(maxAttempts = 3)
            }.getOrDefault(false)
            if (switched) {
                switchedUp = true
                callback.onLog(LogLevel.SUCCESS, "Now running at $FAST_BAUD_RATE baud")
            } else {
                callback.onLog(LogLevel.WARNING, "No response at $FAST_BAUD_RATE baud - staying at $originalBaud")
                runCatching { p.setBaudRate(originalBaud) }
                if (!ld.sync(maxAttempts = 3)) throw FlasherException.SyncFailed(3)
            }
        }
        try {
            return block()
        } finally {
            if (switchedUp) {
                val reverted = runCatching {
                    ld.changeBaudRate(originalBaud)
                    true
                }.getOrDefault(false)
                if (!reverted) {
                    runCatching { p.setBaudRate(originalBaud) }
                }
                callback.onLog(LogLevel.INFO, "Back to $originalBaud baud")
            }
        }
    }

    private fun requireLoader(): EspRomLoader = loader ?: throw FlasherException.UsbDisconnected()

    private fun readAllBytes(uri: Uri): ByteArray {
        return context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: throw FlasherException.Generic("Could not open file $uri")
    }

    private fun md5Hex(data: ByteArray): String =
        MessageDigest.getInstance("MD5").digest(data).joinToString("") { "%02x".format(it) }

    private fun chipFeatures(chip: ChipType): List<String> = when (chip) {
        ChipType.ESP8266 -> listOf("Wi-Fi", "Single-core Xtensa L106")
        ChipType.ESP32 -> listOf("Wi-Fi", "Bluetooth Classic", "BLE", "Dual-core Xtensa LX6")
        ChipType.ESP32_S2 -> listOf("Wi-Fi", "USB OTG", "Single-core Xtensa LX7")
        ChipType.ESP32_S3 -> listOf("Wi-Fi", "BLE", "USB OTG", "Dual-core Xtensa LX7", "AI vector instructions")
        ChipType.ESP32_C3 -> listOf("Wi-Fi", "BLE", "Single-core RISC-V")
        ChipType.ESP32_C6 -> listOf("Wi-Fi 6", "BLE", "802.15.4 (Thread/Zigbee)", "Single-core RISC-V")
        ChipType.ESP32_H2 -> listOf("BLE", "802.15.4 (Thread/Zigbee)", "Single-core RISC-V")
    }
}
