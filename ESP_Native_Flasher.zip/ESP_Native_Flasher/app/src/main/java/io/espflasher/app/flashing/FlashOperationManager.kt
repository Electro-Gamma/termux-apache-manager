package io.espflasher.app.flashing

import android.content.Context
import android.hardware.usb.UsbDevice
import android.net.Uri
import io.espflasher.app.protocol.ChipType
import io.espflasher.app.protocol.Compressor
import io.espflasher.app.protocol.EspCommand
import io.espflasher.app.protocol.EspRomLoader
import io.espflasher.app.protocol.FlashLayout
import io.espflasher.app.protocol.FlasherException
import io.espflasher.app.protocol.ImageHeader
import io.espflasher.app.protocol.ResetSequences
import io.espflasher.app.usb.SerialConfig
import io.espflasher.app.usb.UsbSerialManager
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import java.security.MessageDigest

/**
 * The single entry point the ViewModel drives for every button on the main
 * screen. Owns the currently-open [io.espflasher.app.usb.UsbSerialPort] and
 * [EspRomLoader], and translates each high-level operation (Detect, Erase,
 * Flash, Verify, Read) into the right sequence of protocol calls, reporting
 * progress and console output through [FlashCallback] rather than touching
 * any UI/StateFlow type directly.
 *
 * Cancellation (the Stop button): callers run these suspend functions in a
 * cancellable coroutine `Job`. Block-write loops check
 * `currentCoroutineContext().ensureActive()` every block (a few KB), so Stop
 * takes effect almost immediately during the bulk of any transfer; it can
 * take a couple of seconds longer if cancelled while waiting on a single
 * long call (e.g. a multi-megabyte erase-timeout window), which is an
 * inherent limitation of interrupting blocking USB bulk I/O.
 */
class FlashOperationManager(
    private val context: Context,
    private val usbSerialManager: UsbSerialManager
) {
    private var port: io.espflasher.app.usb.UsbSerialPort? = null
    private var loader: EspRomLoader? = null

    var detectedChip: ChipType? = null
        private set
    var detectedFlashSizeBytes: Long? = null
        private set

    val isConnected: Boolean get() = port?.isOpen == true
    val connectedDeviceInfo get() = port?.info

    // -----------------------------------------------------------------
    // Connection lifecycle
    // -----------------------------------------------------------------

    suspend fun connect(device: UsbDevice, config: SerialConfig, callback: FlashCallback) {
        if (!usbSerialManager.hasPermission(device)) {
            callback.onLog(LogLevel.INFO, "Requesting USB permission...")
            val granted = usbSerialManager.requestPermission(device)
            if (!granted) throw FlasherException.PermissionDenied(device.deviceName)
        }
        val newPort = usbSerialManager.buildPort(device, config)
        newPort.open()
        port = newPort
        loader = EspRomLoader(newPort)
        detectedChip = null
        detectedFlashSizeBytes = null
        callback.onLog(
            LogLevel.SUCCESS,
            "Connected to ${newPort.info.displayLabel} (${newPort.info.vidPidHex}) at ${config.baudRate} baud"
        )
    }

    suspend fun disconnect(callback: FlashCallback) {
        runCatching { port?.close() }
        port = null
        loader = null
        detectedChip = null
        detectedFlashSizeBytes = null
        callback.onLog(LogLevel.INFO, "Disconnected")
    }

    suspend fun resetDevice(callback: FlashCallback) {
        val p = port ?: throw FlasherException.UsbDisconnected()
        ResetSequences.resetToRun(p)
        callback.onLog(LogLevel.INFO, "Reset - device is now running its flashed application")
    }

    suspend fun enterBootloaderManual(callback: FlashCallback) {
        val p = port ?: throw FlasherException.UsbDisconnected()
        ResetSequences.enterBootloader(p)
        callback.onLog(LogLevel.INFO, "Reset into the UART download bootloader")
    }

    // -----------------------------------------------------------------
    // Detect
    // -----------------------------------------------------------------

    suspend fun detectDevice(callback: FlashCallback): DeviceInfoSnapshot {
        val ld = requireLoader()
        val p = port ?: throw FlasherException.UsbDisconnected()

        callback.onLog(LogLevel.INFO, "Resetting into bootloader...")
        ResetSequences.enterBootloader(p)
        callback.onLog(LogLevel.COMMAND, "-> SYNC")
        var synced = ld.sync()
        if (!synced) {
            callback.onLog(LogLevel.WARNING, "No response - retrying bootloader entry...")
            ResetSequences.enterBootloader(p)
            synced = ld.sync()
        }
        if (!synced) throw FlasherException.SyncFailed(7)
        callback.onLog(LogLevel.SUCCESS, "<- Sync OK")

        val chip = ld.detectChip()
        detectedChip = chip
        callback.onLog(LogLevel.SUCCESS, "Chip: ${chip.displayName}")

        ld.spiAttach()

        val mac = runCatching { ld.readMac(chip) }.getOrElse {
            callback.onLog(LogLevel.WARNING, "Could not read MAC address: ${it.message}")
            "Unknown"
        }
        callback.onLog(LogLevel.INFO, "MAC address: $mac")

        val flashId = runCatching { ld.readFlashId(chip) }.getOrElse {
            callback.onLog(LogLevel.WARNING, "Could not read flash ID: ${it.message}")
            null
        }
        val flashSize = flashId?.sizeBytes
        detectedFlashSizeBytes = flashSize
        if (flashSize != null) {
            callback.onLog(LogLevel.INFO, "Flash: ${FlashLayout.humanReadableSize(flashSize)} " +
                "(mfr=0x%02X, memType=0x%02X)".format(flashId.manufacturer, flashId.memoryType))
        }

        val security = if (chip.supportsSecurityInfo) runCatching { ld.getSecurityInfo() }.getOrNull() else null

        return DeviceInfoSnapshot(
            chip = chip,
            revision = "Not exposed via ROM-only mode",
            macAddress = mac,
            crystalFreqMHz = 40,
            flashId = flashId,
            flashSizeBytes = flashSize,
            flashMode = null,
            features = chipFeatures(chip),
            securityInfo = security
        )
    }

    // -----------------------------------------------------------------
    // Erase
    // -----------------------------------------------------------------

    suspend fun eraseFlash(callback: FlashCallback) {
        val (ld, chip) = ensureReady(callback)
        val size = detectedFlashSizeBytes
            ?: throw FlasherException.Generic("Flash size unknown - run Detect first, or the flash ID couldn't be read.")

        callback.onLog(LogLevel.COMMAND, "Erasing ${FlashLayout.humanReadableSize(size)} - this can take a while...")
        callback.onProgress(ProgressState(operationLabel = "Erasing flash", bytesTotal = size, isRunning = true))
        ld.eraseFullChip(chip, size)
        callback.onProgress(ProgressState.IDLE)
        callback.onLog(LogLevel.SUCCESS, "Flash erased.")
    }

    // -----------------------------------------------------------------
    // Write
    // -----------------------------------------------------------------

    suspend fun writeImages(images: List<FlashImage>, options: FlashOptions, callback: FlashCallback) {
        if (images.isEmpty()) throw FlasherException.Generic("No files selected to flash.")
        val (ld, chip) = ensureReady(callback)

        if (options.eraseBeforeWrite) {
            eraseFlash(callback)
        }

        val sorted = images.sortedBy { it.offset }
        for (image in sorted) {
            currentCoroutineContext().ensureActive()
            writeSingleImage(ld, chip, image, options, callback)
        }

        if (options.resetAfterFlashing) {
            resetDevice(callback)
        }

        if (options.verifyAfterWrite) {
            verifyImages(sorted, callback)
        }
    }

    private suspend fun writeSingleImage(
        ld: EspRomLoader,
        chip: ChipType,
        image: FlashImage,
        options: FlashOptions,
        callback: FlashCallback
    ) {
        if (image.offset < 0) throw FlasherException.InvalidAddress(image.offset)

        callback.onLog(LogLevel.INFO, "Reading ${image.fileName}...")
        val data = readAllBytes(image.uri)

        val needsMagicCheck = image.slot == ImageSlot.BOOTLOADER || image.slot == ImageSlot.APPLICATION || image.slot == ImageSlot.FIRMWARE
        if (needsMagicCheck && !ImageHeader.looksValid(data)) {
            throw FlasherException.InvalidFirmware(
                "${image.fileName} doesn't start with the ESP image magic byte (0xE9) - wrong file for the ${image.slot.label} slot?"
            )
        }

        callback.onLog(
            LogLevel.COMMAND,
            "flash_begin size=0x%X offset=0x%X compress=%s".format(data.size, image.offset, options.compressData)
        )

        val checksumOverride = if (options.skipChecksum) 0 else null

        if (options.compressData) {
            val compressed = Compressor.zlibCompress(data)
            callback.onLog(LogLevel.DEBUG, "Compressed ${data.size} -> ${compressed.size} bytes")
            ld.flashDeflBegin(chip, data.size.toLong(), compressed.size.toLong(), image.offset)
            val tracker = ProgressTracker(compressed.size.toLong(), "Writing ${image.slot.label}")
            var seq = 0
            var offset = 0
            while (offset < compressed.size) {
                currentCoroutineContext().ensureActive()
                val len = minOf(EspCommand.FLASH_WRITE_SIZE, compressed.size - offset)
                val block = compressed.copyOfRange(offset, offset + len)
                ld.flashDeflBlock(block, seq, checksumOverride = checksumOverride)
                offset += len
                seq++
                val estimatedAddr = image.offset + (offset.toLong() * data.size / compressed.size.coerceAtLeast(1))
                callback.onProgress(tracker.update(offset.toLong(), estimatedAddr))
            }
        } else {
            ld.flashBegin(chip, data.size.toLong(), image.offset)
            val tracker = ProgressTracker(data.size.toLong(), "Writing ${image.slot.label}")
            var seq = 0
            var offset = 0
            while (offset < data.size) {
                currentCoroutineContext().ensureActive()
                val remaining = data.size - offset
                val len = minOf(EspCommand.FLASH_WRITE_SIZE, remaining)
                val block = if (len == EspCommand.FLASH_WRITE_SIZE) {
                    data.copyOfRange(offset, offset + len)
                } else {
                    ByteArray(EspCommand.FLASH_WRITE_SIZE) { i -> if (i < len) data[offset + i] else 0xFF.toByte() }
                }
                ld.flashBlock(block, seq, checksumOverride = checksumOverride)
                offset += len
                seq++
                callback.onProgress(tracker.update(offset.toLong().coerceAtMost(data.size.toLong()), image.offset + offset))
            }
        }

        ld.flashFinish(reboot = false, compressed = options.compressData)
        callback.onProgress(ProgressState.IDLE)
        callback.onLog(LogLevel.SUCCESS, "Wrote ${image.slot.label}: ${data.size} bytes at 0x%X".format(image.offset))
    }

    // -----------------------------------------------------------------
    // Verify
    // -----------------------------------------------------------------

    suspend fun verifyImages(images: List<FlashImage>, callback: FlashCallback) {
        if (images.isEmpty()) throw FlasherException.Generic("No files selected to verify.")
        val (ld, _) = ensureReady(callback)

        for (image in images.sortedBy { it.offset }) {
            currentCoroutineContext().ensureActive()
            callback.onLog(LogLevel.INFO, "Verifying ${image.slot.label} (${image.fileName})...")
            val data = readAllBytes(image.uri)
            val localMd5 = md5Hex(data)
            callback.onLog(LogLevel.COMMAND, "flash_md5 offset=0x%X size=0x%X".format(image.offset, data.size))
            val remoteMd5 = ld.flashMd5(image.offset, data.size.toLong())
            if (!localMd5.equals(remoteMd5, ignoreCase = true)) {
                throw FlasherException.ChecksumMismatch(localMd5, remoteMd5)
            }
            callback.onLog(LogLevel.SUCCESS, "${image.slot.label} verified OK (MD5 $localMd5)")
        }
    }

    // -----------------------------------------------------------------
    // Read / dump
    // -----------------------------------------------------------------

    suspend fun readFlashToFile(offset: Long, length: Long, destUri: Uri, callback: FlashCallback) {
        val (ld, chip) = ensureReady(callback)
        if (!ld.supportsRomOnlyRead(chip)) {
            throw FlasherException.Generic(
                "Reading flash on ${chip.displayName} needs a stub loader, which this build doesn't bundle " +
                    "(see the Stub Loader note under Advanced). ROM-only reading currently only works on classic ESP32."
            )
        }
        val tracker = ProgressTracker(length, "Reading flash")
        callback.onLog(LogLevel.COMMAND, "read_flash offset=0x%X size=0x%X".format(offset, length))
        val data = ld.readFlashRomOnly(offset, length) { done, _ ->
            callback.onProgress(tracker.update(done, offset + done))
        }
        context.contentResolver.openOutputStream(destUri)?.use { it.write(data) }
            ?: throw FlasherException.Generic("Could not open the destination file for writing.")
        callback.onProgress(ProgressState.IDLE)
        callback.onLog(LogLevel.SUCCESS, "Read ${data.size} bytes to file.")
    }

    // -----------------------------------------------------------------
    // Advanced: raw register / memory access
    // -----------------------------------------------------------------

    suspend fun readRegister(addr: Long): Long = requireLoader().readReg(addr)

    suspend fun writeRegister(addr: Long, value: Long) = requireLoader().writeReg(addr, value)

    // -----------------------------------------------------------------
    // Helpers
    // -----------------------------------------------------------------

    private suspend fun ensureReady(callback: FlashCallback): Pair<EspRomLoader, ChipType> {
        val ld = requireLoader()
        val chip = detectedChip ?: detectDevice(callback).chip
        return ld to chip
    }

    private fun requireLoader(): EspRomLoader = loader ?: throw FlasherException.UsbDisconnected()

    private fun readAllBytes(uri: Uri): ByteArray {
        return context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: throw FlasherException.Generic("Could not open file $uri")
    }

    private fun md5Hex(data: ByteArray): String =
        MessageDigest.getInstance("MD5").digest(data).joinToString("") { "%02x".format(it) }

    private fun chipFeatures(chip: ChipType): List<String> = when (chip) {
        ChipType.ESP8266 -> listOf("Wi-Fi", "Single-core Xtensa L106")
        ChipType.ESP32 -> listOf("Wi-Fi", "Bluetooth Classic", "BLE", "Dual-core Xtensa LX6")
        ChipType.ESP32_S2 -> listOf("Wi-Fi", "USB OTG", "Single-core Xtensa LX7")
        ChipType.ESP32_S3 -> listOf("Wi-Fi", "BLE", "USB OTG", "Dual-core Xtensa LX7", "AI vector instructions")
        ChipType.ESP32_C3 -> listOf("Wi-Fi", "BLE", "Single-core RISC-V")
        ChipType.ESP32_C6 -> listOf("Wi-Fi 6", "BLE", "802.15.4 (Thread/Zigbee)", "Single-core RISC-V")
        ChipType.ESP32_H2 -> listOf("BLE", "802.15.4 (Thread/Zigbee)", "Single-core RISC-V")
    }
}
