package io.espflasher.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import io.espflasher.app.R
import io.espflasher.app.ui.MainActivity

/**
 * A minimal started (not bound) foreground service whose only job is to give
 * the process foreground priority - and a visible, honest notification -
 * while a device is connected or a flash operation is running. The actual
 * work (FlashOperationManager, the coroutine doing the flashing) still lives
 * in MainViewModel/viewModelScope exactly as before; this service doesn't
 * duplicate any of that. It exists purely so Android doesn't kill the app
 * process for being "in the background" in the middle of a multi-minute
 * erase or flash.
 *
 * MainViewModel starts this when a connection is established and stops it on
 * disconnect, updating its status text as operations progress.
 */
class FlashForegroundService : Service() {

    companion object {
        private const val CHANNEL_ID = "esp_flasher_session"
        private const val NOTIFICATION_ID = 1001
        private const val EXTRA_STATUS = "status"

        fun start(context: Context, status: String) {
            val intent = Intent(context, FlashForegroundService::class.java).putExtra(EXTRA_STATUS, status)
            androidx.core.content.ContextCompat.startForegroundService(context, intent)
        }

        /** Same entry point as [start] - onStartCommand re-posts the notification with the new text. */
        fun updateStatus(context: Context, status: String) = start(context, status)

        fun stop(context: Context) {
            context.stopService(Intent(context, FlashForegroundService::class.java))
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannelIfNeeded()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val status = intent?.getStringExtra(EXTRA_STATUS) ?: getString(R.string.notification_status_idle)
        val notification = buildNotification(status)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceCompat.startForeground(
                this, NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun buildNotification(status: String): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_UPDATE_CURRENT or
                (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_IMMUTABLE else 0)
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(status)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(openAppIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createChannelIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                CHANNEL_ID, getString(R.string.notification_channel_name), NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_channel_description)
            }
            manager.createNotificationChannel(channel)
        }
    }
}
