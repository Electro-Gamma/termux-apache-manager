package io.espflasher.app.protocol

/**
 * Per-chip constants needed to talk to each ROM bootloader: the SPI flash
 * controller register map (used to issue raw SPI NOR commands such as
 * "read JEDEC ID" through generic READ_REG/WRITE_REG), the efuse MAC
 * register, and sane default partition offsets following ESP-IDF's
 * standard `partitions.csv` layout.
 *
 * All of these are hardware facts (register addresses baked into chip
 * silicon/ROM, and Espressif's public partition-table conventions) rather
 * than expression copied from any third-party tool.
 */
enum class ChipType(
    val displayName: String,
    /** Value read back from CHIP_DETECT_MAGIC_REG_ADDR on chips that support it, else null. */
    val magicValue: Long?,
    /** chip_id reported by the GET_SECURITY_INFO command, for chips without a magic value. */
    val imageChipId: Int?,
    val bootloaderOffset: Long,
    val partitionTableOffset: Long,
    val otaDataOffset: Long,
    val appOffset: Long,
    val efuseMacRegAddr: Long,
    val spiRegBase: Long,
    val spiUsrOffset: Long,
    val spiUsr1Offset: Long,
    val spiUsr2Offset: Long,
    val spiW0Offset: Long,
    val spiMosiDlenOffset: Long?, // null on ESP8266 (older-style length encoding)
    val spiMisoDlenOffset: Long?,
    val spiAddrRegMsb: Boolean,
    val supportsSecurityInfo: Boolean,
    val supportsFlashEncryptionStatus: Boolean
) {
    ESP8266(
        displayName = "ESP8266",
        magicValue = 0xFFF0C101L,
        imageChipId = null,
        bootloaderOffset = 0x0000L,
        partitionTableOffset = 0x8000L,
        otaDataOffset = 0xD000L,
        appOffset = 0x10000L,
        efuseMacRegAddr = 0x3FF00050L, // legacy scattered efuse layout, handled specially
        spiRegBase = 0x60000200L,
        spiUsrOffset = 0x1CL,
        spiUsr1Offset = 0x20L,
        spiUsr2Offset = 0x24L,
        spiW0Offset = 0x40L,
        spiMosiDlenOffset = null,
        spiMisoDlenOffset = null,
        spiAddrRegMsb = true,
        supportsSecurityInfo = false,
        supportsFlashEncryptionStatus = false
    ),
    ESP32(
        displayName = "ESP32",
        magicValue = 0x00F01D83L,
        imageChipId = 0,
        bootloaderOffset = 0x1000L,
        partitionTableOffset = 0x8000L,
        otaDataOffset = 0xD000L,
        appOffset = 0x10000L,
        efuseMacRegAddr = 0x3FF5A000L, // legacy scattered efuse layout, handled specially
        spiRegBase = 0x3FF42000L,
        spiUsrOffset = 0x1CL,
        spiUsr1Offset = 0x20L,
        spiUsr2Offset = 0x24L,
        spiW0Offset = 0x80L,
        spiMosiDlenOffset = 0x28L,
        spiMisoDlenOffset = 0x2CL,
        spiAddrRegMsb = true,
        supportsSecurityInfo = false,
        supportsFlashEncryptionStatus = true
    ),
    ESP32_S2(
        displayName = "ESP32-S2",
        magicValue = 0x000007C6L,
        imageChipId = 2,
        bootloaderOffset = 0x1000L,
        partitionTableOffset = 0x8000L,
        otaDataOffset = 0xD000L,
        appOffset = 0x10000L,
        efuseMacRegAddr = 0x3F41A044L,
        spiRegBase = 0x3F402000L,
        spiUsrOffset = 0x18L,
        spiUsr1Offset = 0x1CL,
        spiUsr2Offset = 0x20L,
        spiW0Offset = 0x58L,
        spiMosiDlenOffset = 0x24L,
        spiMisoDlenOffset = 0x28L,
        spiAddrRegMsb = false,
        supportsSecurityInfo = true, // 12-byte reply only (no chip_id)
        supportsFlashEncryptionStatus = true
    ),
    ESP32_S3(
        displayName = "ESP32-S3",
        magicValue = null,
        imageChipId = 9,
        bootloaderOffset = 0x0000L,
        partitionTableOffset = 0x8000L,
        otaDataOffset = 0xD000L,
        appOffset = 0x10000L,
        efuseMacRegAddr = 0x60007044L,
        spiRegBase = 0x60002000L,
        spiUsrOffset = 0x18L,
        spiUsr1Offset = 0x1CL,
        spiUsr2Offset = 0x20L,
        spiW0Offset = 0x58L,
        spiMosiDlenOffset = 0x24L,
        spiMisoDlenOffset = 0x28L,
        spiAddrRegMsb = false,
        supportsSecurityInfo = true,
        supportsFlashEncryptionStatus = true
    ),
    ESP32_C3(
        displayName = "ESP32-C3",
        magicValue = null,
        imageChipId = 5,
        bootloaderOffset = 0x0000L,
        partitionTableOffset = 0x8000L,
        otaDataOffset = 0xD000L,
        appOffset = 0x10000L,
        efuseMacRegAddr = 0x60008844L,
        spiRegBase = 0x60002000L,
        spiUsrOffset = 0x18L,
        spiUsr1Offset = 0x1CL,
        spiUsr2Offset = 0x20L,
        spiW0Offset = 0x58L,
        spiMosiDlenOffset = 0x24L,
        spiMisoDlenOffset = 0x28L,
        spiAddrRegMsb = false,
        supportsSecurityInfo = true,
        supportsFlashEncryptionStatus = true
    ),
    ESP32_C6(
        displayName = "ESP32-C6",
        magicValue = null,
        imageChipId = 13,
        bootloaderOffset = 0x0000L,
        partitionTableOffset = 0x8000L,
        otaDataOffset = 0xD000L,
        appOffset = 0x10000L,
        efuseMacRegAddr = 0x600B0844L,
        spiRegBase = 0x60003000L,
        spiUsrOffset = 0x18L,
        spiUsr1Offset = 0x1CL,
        spiUsr2Offset = 0x20L,
        spiW0Offset = 0x58L,
        spiMosiDlenOffset = 0x24L,
        spiMisoDlenOffset = 0x28L,
        spiAddrRegMsb = false,
        supportsSecurityInfo = true,
        supportsFlashEncryptionStatus = true
    ),
    ESP32_H2(
        displayName = "ESP32-H2",
        magicValue = null,
        imageChipId = 16,
        bootloaderOffset = 0x0000L,
        partitionTableOffset = 0x8000L,
        otaDataOffset = 0xD000L,
        appOffset = 0x10000L,
        efuseMacRegAddr = 0x600B0844L, // H2 ROM shares the C6 register map
        spiRegBase = 0x60003000L,
        spiUsrOffset = 0x18L,
        spiUsr1Offset = 0x1CL,
        spiUsr2Offset = 0x20L,
        spiW0Offset = 0x58L,
        spiMosiDlenOffset = 0x24L,
        spiMisoDlenOffset = 0x28L,
        spiAddrRegMsb = false,
        supportsSecurityInfo = true,
        supportsFlashEncryptionStatus = true
    );

    companion object {
        /** Chips whose ROM exposes a magic value at CHIP_DETECT_MAGIC_REG_ADDR. */
        fun byMagicValue(value: Long): ChipType? = entries.firstOrNull { it.magicValue == value }

        /** Chips identified via the GET_SECURITY_INFO chip_id field instead. */
        fun byImageChipId(id: Int): ChipType? = entries.firstOrNull { it.imageChipId == id && it.magicValue == null }
    }
}
