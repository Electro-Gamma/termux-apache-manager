package io.espflasher.app.protocol

/**
 * The minimal serial operations the ESP protocol layer needs. Implemented by
 * [io.espflasher.app.usb.UsbSerialPort] over the real USB Host API, which
 * keeps this file (and everything in the `protocol` package) free of any
 * Android USB imports - it could just as easily run against a mock or a
 * TCP socket in tests.
 */
interface SerialTransport {
    /** True while the underlying connection is open and usable. */
    val isOpen: Boolean

    /** Write raw bytes to the wire. */
    suspend fun write(data: ByteArray)

    /**
     * Read one raw byte from the wire, waiting up to [timeoutMs].
     * Returns null on timeout (not an error - callers decide what that means).
     */
    suspend fun readByteOrNull(timeoutMs: Long): Int?

    /** Change the UART baud rate on the fly (used after CHANGE_BAUDRATE). */
    suspend fun setBaudRate(baud: Int)

    /** Drive DTR/RTS lines directly, used for bootloader-entry reset sequences. */
    suspend fun setDtrRts(dtr: Boolean, rts: Boolean)

    /** Discard any buffered but unread input. */
    suspend fun purgeInput()
}
