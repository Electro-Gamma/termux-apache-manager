package io.espflasher.app.protocol

/**
 * ## Why this app runs "no-stub" by default (and ships no stub at all)
 *
 * esptool.py normally uploads a small second-stage program ("the stub") into
 * chip RAM over [EspRomLoader.memBegin]/[EspRomLoader.memBlock] before doing
 * any real work, because the permanent ROM bootloader is slow and, on most
 * chips, can't read flash back or bulk-erase it at all.
 *
 * That stub is Espressif's own precompiled firmware image (one per chip
 * family, built from their `flasher_stub` sources and shipped as binary
 * blobs). Bundling those blobs here would mean embedding third-party
 * compiled code inside this app - exactly what "don't embed or invoke
 * esptool" rules out, even though the stub isn't esptool.py itself.
 *
 * So this build talks *only* to the permanent ROM bootloader, using the
 * commands every ESP chip's ROM exposes natively: SYNC, READ_REG/WRITE_REG,
 * FLASH_BEGIN/DATA/END (and their compressed FLASH_DEFL_* counterparts),
 * and SPI_FLASH_MD5. That covers every operation this app advertises -
 * sync, chip/flash ID, full-chip erase, write, verify - on all seven chip
 * families, on the real (slower) ROM transfer path.
 *
 * The one gap: **reading flash back to a file only works on classic ESP32.**
 * Its ROM is the only one in the whole ESP32 family that exposes a native
 * flash-read primitive ([EspRomLoader.readFlashRomOnly], driven by the
 * documented `READ_FLASH_SLOW` opcode). Every other ROM - ESP8266 included -
 * has no flash-read command at all; upstream esptool itself requires the
 * stub for that operation on those chips, not just this app.
 *
 * ## If you want to add stub support later
 *
 * The protocol/transport plumbing for it already exists and doesn't need to
 * change: [EspRomLoader.memBegin]/[EspRomLoader.memBlock]/[EspRomLoader.memFinish]
 * upload and jump to arbitrary RAM code exactly the way esptool's
 * `_upload_segment()` + `mem_finish()` do. Implementing this interface with
 * your own stub build (compiled from source you have the right to embed, or
 * uploaded by the user at runtime via SAF rather than bundled in the APK)
 * is enough to light up [StubCapabilities.hasStub]-gated features such as
 * fast bulk erase and flash reading on chips other than ESP32.
 */
interface StubLoader {
    /** True once a stub has been uploaded and confirmed running for this session. */
    val isRunning: Boolean

    /** Upload and start the stub against an already-synced [loader]. */
    suspend fun start(loader: EspRomLoader): Boolean
}

/** The default, always-available "no stub" implementation: does nothing and reports not running. */
object NoStubLoader : StubLoader {
    override val isRunning: Boolean = false
    override suspend fun start(loader: EspRomLoader): Boolean = false
}

/** What a caller can rely on given the currently active [StubLoader]. */
data class StubCapabilities(val hasStub: Boolean) {
    val fastBulkErase: Boolean get() = hasStub
    val flashReadOnAllChips: Boolean get() = hasStub

    companion object {
        fun of(loader: StubLoader): StubCapabilities = StubCapabilities(hasStub = loader.isRunning)
    }
}
