package io.espflasher.app.protocol

import io.espflasher.app.util.BinaryUtils.hex
import java.io.ByteArrayOutputStream
import java.security.MessageDigest

/**
 * Reads SPI flash off a running stub loader, using the stub's `READ_FLASH`
 * command (0xD2).
 *
 * This is the app's single, canonical implementation of stub-based flash
 * reading - the "stub read" referred to throughout [StubLoader] and
 * [EspRomLoader]'s doc comments - and it is what every caller in this app
 * (partition-table reads, SPIFFS extraction, the Read/Dump screen) now goes
 * through instead of talking to the stub directly. It replaces the earlier,
 * equivalent `EspRomLoader.readFlashStub()` method, which has been removed;
 * [EspRomLoader] now only exposes the two low-level primitives this class
 * needs ([EspRomLoader.sendReadFlashRequest], [EspRomLoader.ackReadFlashTotal])
 * plus the raw-frame reader it already had ([EspRomLoader.readRawFrame]).
 *
 * Every protocol detail below - opcode, packet layout, timeouts, the
 * read-flash wire protocol itself - matches esptool's own reference
 * implementation (`esptool/loader.py`'s `ESPLoader.read_flash()`, the
 * `IS_STUB` branch, and `cmds.py`'s `read_flash()` command wrapper around
 * it). This is a from-scratch, original implementation written directly
 * against that publicly documented wire protocol; it does not embed, shell
 * out to, or otherwise invoke esptool.py or any other third-party flashing
 * tool - only [EspCommand]'s opcode constants and [SlipCodec]'s SLIP framing,
 * both already original to this project.
 *
 * ## The read-flash exchange
 *
 * Reading flash through a stub is a fundamentally different exchange from
 * every other command this app sends (see [EspRomLoader]'s normal
 * `command`/`exec` command-response shape):
 *
 * 1. One ordinary command/response ([EspRomLoader.sendReadFlashRequest])
 *    triggers the read and hands the stub its parameters: offset, length,
 *    a nominal block size of one flash sector (0x1000 bytes), and a
 *    max-in-flight value.
 * 2. The stub then pushes raw SLIP frames of flash data completely
 *    unprompted, up to one sector each - NOT shaped like a normal
 *    8-byte-header response, so these are read with
 *    [EspRomLoader.readRawFrame] the same way a stub's initial "OHAI"
 *    boot greeting is (see [EspressifStubLoader]).
 * 3. After *every* frame, the host must echo back a bare SLIP frame
 *    containing a little-endian u32 of the *cumulative* bytes received so
 *    far ([EspRomLoader.ackReadFlashTotal]) - this is the read's entire
 *    flow-control mechanism. There is no opcode, no header, just four raw
 *    bytes in a SLIP frame. Skipping or misforming it stalls the stub
 *    indefinitely.
 * 4. Once the requested length has been accumulated, one final raw SLIP
 *    frame carries a 16-byte MD5 digest of everything received, which is
 *    verified locally - flash data has no per-frame checksum of its own
 *    the way FLASH_DATA/MEM_DATA writes do, so this digest is the only
 *    integrity check the whole read gets.
 *
 * ## Scope
 *
 * This class only performs the read itself, once a stub is already running.
 * Chip detection ([EspRomLoader.detectChip]) and stub upload
 * ([EspressifStubLoader]) are deliberately not duplicated here - this app
 * already has a single, tested implementation of each, and a second copy
 * living inside a "read flash" class would just be two sources of truth for
 * the same thing. A caller is expected to have already synced, identified
 * the chip, and confirmed [StubLoader.isRunning] before constructing this.
 *
 * @param loader an already-synced [EspRomLoader] with a stub currently
 *   running on the far end (see [StubLoader.isRunning]/[EspressifStubLoader]).
 */
class EsptoolReadFlash(private val loader: EspRomLoader) {

    companion object {
        /**
         * Nominal per-frame block size the stub is told to use - one flash
         * sector. Matches esptool's own `FLASH_SECTOR_SIZE` (loader.py).
         */
        private const val FLASH_SECTOR_SIZE = 0x1000L

        /**
         * How many bytes' worth of frames the stub may have "in flight"
         * (sent but not yet acked) at once. 64 matches esptool's own
         * literal exactly, and the reasoning for it is documented on
         * [EspRomLoader.sendReadFlashRequest].
         */
        private const val MAX_IN_FLIGHT = 64L

        /** Per-frame read timeout - generous, since a full sector at low baud can take a moment. */
        private const val FRAME_TIMEOUT_MS = 5000L
    }

    /**
     * Reads [length] bytes of SPI flash starting at [offset], returning the
     * raw bytes once the trailing MD5 digest has been verified against them.
     *
     * @param onProgress optional callback invoked after every acked frame
     *   with `(bytesReadSoFar, totalBytesRequested)` - both callback
     *   parameters and the returned data length always reflect flash
     *   offsets, not wire-frame counts.
     * @throws FlasherException.FlashTimeout if the stub doesn't answer the
     *   initial request, or stops sending frames, within the per-step
     *   timeout.
     * @throws FlasherException.Generic if the stub sends a short frame
     *   before the requested length has been reached (corrupt/desynced
     *   stream), or more data than was requested.
     * @throws FlasherException.ChecksumMismatch if the locally computed MD5
     *   of the received bytes doesn't match the digest frame the stub sends
     *   at the end - the read completed, but the data is not trustworthy.
     */
    suspend fun readFlashStub(
        offset: Long,
        length: Long,
        onProgress: ((Long, Long) -> Unit)? = null
    ): ByteArray {
        // Step 1: trigger the read and hand over its parameters. This part
        // alone is an ordinary command/response exchange - everything after
        // it is not (see the class doc comment).
        loader.sendReadFlashRequest(offset, length, FLASH_SECTOR_SIZE, MAX_IN_FLIGHT)

        val out = ByteArrayOutputStream(length.coerceAtMost(Int.MAX_VALUE.toLong()).toInt().coerceAtLeast(0))
        var total = 0L
        while (total < length) {
            // Step 2: read one raw, unprompted data frame - up to one
            // sector - directly off the wire.
            val frame = loader.readRawFrame(timeoutMs = FRAME_TIMEOUT_MS)
                ?: throw FlasherException.FlashTimeout(
                    "read flash (no data frame within ${FRAME_TIMEOUT_MS / 1000}s)"
                )
            out.write(frame)
            total += frame.size

            if (total < length && frame.size.toLong() < FLASH_SECTOR_SIZE) {
                // A frame shorter than a full sector is only valid as the
                // very last one. Getting one early means the stream is
                // corrupt or desynced - show the tail of the short frame in
                // the error itself, not just a bare "got N bytes": the
                // actual trailing bytes tell you whether it's an
                // unterminated SLIP escape (a lone 0xDB) or something else,
                // instead of guessing blind.
                val tail = frame.copyOfRange((frame.size - 16).coerceAtLeast(0), frame.size)
                throw FlasherException.Generic(
                    "Corrupt data during flash read: expected a %d-byte sector but got %d bytes (last bytes: %s)."
                        .format(FLASH_SECTOR_SIZE, frame.size, hex(tail))
                )
            }

            // Step 3: ack the new cumulative total - a bare SLIP frame, not
            // a command()-shaped packet. This is what keeps the stub
            // sending; see EspRomLoader.ackReadFlashTotal's doc comment.
            loader.ackReadFlashTotal(total)
            onProgress?.invoke(total.coerceAtMost(length), length)
        }
        if (total > length) {
            throw FlasherException.Generic("Read more data than requested during flash read.")
        }

        // Step 4: the trailing MD5 digest frame, and the only integrity
        // check this whole read gets.
        val digestFrame = loader.readRawFrame(timeoutMs = FRAME_TIMEOUT_MS)
            ?: throw FlasherException.FlashTimeout("read flash (no digest frame)")
        if (digestFrame.size != 16) {
            throw FlasherException.Generic(
                "Expected a 16-byte MD5 digest after flash read, got ${digestFrame.size} bytes."
            )
        }
        val data = out.toByteArray()
        val actualDigest = MessageDigest.getInstance("MD5").digest(data)
        if (!actualDigest.contentEquals(digestFrame)) {
            throw FlasherException.ChecksumMismatch(hex(digestFrame), hex(actualDigest))
        }
        return data
    }
}
