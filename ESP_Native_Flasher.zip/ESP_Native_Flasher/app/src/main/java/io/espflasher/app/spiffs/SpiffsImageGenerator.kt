package io.espflasher.app.spiffs

import io.espflasher.app.util.BinaryUtils

/**
 * Builds a SPIFFS filesystem image in memory, the same job ESP-IDF's
 * `spiffsgen.py` does on a desktop - so a SPIFFS partition can be generated
 * and flashed entirely on-device, with no Python involved.
 *
 * ============================================================================
 * VALIDATION STATUS - READ BEFORE TRUSTING THIS ON REAL HARDWARE
 * ============================================================================
 * This is a from-scratch reimplementation of the on-flash SPIFFS layout
 * (pellepl/spiffs, as used by ESP-IDF), written from general knowledge of
 * the format rather than checked line-by-line against `spiffsgen.py` or
 * `spiffs.h` - neither was available to cross-reference while writing this.
 * The overall structure (blocks, pages, per-block lookup tables, object
 * index pages referencing data pages) is solid, but a few specific byte-
 * level details are the sort of thing that's easy to get subtly wrong from
 * memory and WILL cause "SPIFFS mount failed" or silent corruption on a
 * real device if wrong - specifically the page-header flag bit values, and
 * the exact field order/sizes in the object-index header (both marked
 * `VERIFY:` below).
 *
 * Cheap way to confirm it's right before relying on it: run this generator
 * and the existing `spiffsgen.py` (the one your Pi tool already calls) over
 * the *same* input directory and `--size/--page-size/--block-size`, and
 * byte-diff the two `.bin` outputs. If they're identical, this is provably
 * correct for your config and you're done. If they differ, the diff will
 * point straight at which structure is off, and I can fix it from there.
 * ============================================================================
 *
 * @param imageSize total size of the SPIFFS partition in bytes (must be a
 *   whole number of [blockSize]) - this is exactly the `size` you'd pass to
 *   `spiffsgen.py`, and matches [io.espflasher.app.protocol.PartitionEntry.size]
 *   once you've located the partition via [io.espflasher.app.protocol.PartitionTable].
 * @param pageSize physical page size in bytes. ESP-IDF default is 256
 *   (`CONFIG_SPIFFS_PAGE_SIZE`) - must match what the firmware mounts with.
 * @param blockSize erase-block size in bytes, must be a multiple of
 *   [pageSize]. ESP-IDF default is 4096 (`CONFIG_SPIFFS_PAGE_BLOCK_SIZE` /
 *   the underlying flash sector size) - must match what the firmware mounts with.
 * @param objNameLen max file name length INCLUDING the null terminator
 *   (`CONFIG_SPIFFS_OBJ_NAME_LEN`, default 32 -> 31 usable characters). The
 *   *full* relative path (e.g. "/www/index.html") is the name - SPIFFS has
 *   no real directory tree, "/" is just a character allowed in a flat name.
 * @param metaLen per-file metadata length (`CONFIG_SPIFFS_META_LENGTH`,
 *   default 4). This build never has real metadata to store, so those bytes
 *   are always written as zero - but the *length* still has to match the
 *   firmware's Kconfig or the fixed-size header layout won't line up.
 */
class SpiffsImageGenerator(
    private val imageSize: Long,
    private val pageSize: Int = 256,
    private val blockSize: Int = 4096,
    private val objNameLen: Int = 32,
    private val metaLen: Int = 4
) {
    companion object {
        private const val PAGE_HEADER_SIZE = 5 // obj_id(u16) + span_ix(u16) + flags(u8)
        private const val IX_FLAG = 0x8000 // set in obj_id for index pages, clear for data pages
        private const val TYPE_FILE = 1 // spiffs_type SPIFFS_TYPE_FILE

        // VERIFY: these three flag bytes. "Active low" (erased page = 0xFF,
        // specific bits clear as the page is committed) is definitely the
        // right *mechanism* - SPIFFS_PH_FLAG_USED/FINAL/INDEX are the right
        // *names* - but the exact bit *positions* below are from memory.
        // (untouched/erased page = 0xFF - this generator never writes that value as a "flags" byte, it's just the baseline)
        private const val DATA_PAGE_FLAGS = 0xFC // USED (bit0) + FINAL (bit1) cleared, INDEX (bit2) left set
        private const val INDEX_PAGE_FLAGS = 0xF8 // USED + FINAL + INDEX (bit2) all cleared
    }

    init {
        require(blockSize % pageSize == 0) { "blockSize ($blockSize) must be a multiple of pageSize ($pageSize)" }
        require(imageSize % blockSize == 0L) { "imageSize ($imageSize) must be a multiple of blockSize ($blockSize)" }
        require(objNameLen in 2..255) { "objNameLen must be a small positive size (ESP-IDF default is 32)" }
    }

    private val pagesPerBlock = blockSize / pageSize
    private val luPagesPerBlock = ((pagesPerBlock * 2) + pageSize - 1) / pageSize
    private val totalBlocks = (imageSize / blockSize).toInt()
    private val dataPageCapacity = pageSize - PAGE_HEADER_SIZE
    private val objectIndexHeaderSize = 4 + 1 + objNameLen + metaLen // size(u32) + type(u8) + name + meta
    private val firstIndexPageRefCapacity = (pageSize - PAGE_HEADER_SIZE - objectIndexHeaderSize) / 4
    private val indexPageRefCapacity = (pageSize - PAGE_HEADER_SIZE) / 4

    init {
        require(luPagesPerBlock < pagesPerBlock) {
            "blockSize/pageSize combination leaves no room for data - " +
                "$luPagesPerBlock of $pagesPerBlock pages per block would be lookup-table overhead"
        }
        require(firstIndexPageRefCapacity > 0) {
            "pageSize ($pageSize) is too small to fit even one data-page reference alongside the object index header " +
                "(header is $objectIndexHeaderSize bytes + $PAGE_HEADER_SIZE page-header bytes)"
        }
    }

    private var blockIndex = 0
    private var pageInBlock = luPagesPerBlock
    private val lookupSlotWrites = mutableListOf<Pair<Int, Int>>() // (globalPageNumber, obj_id-to-store)

    /**
     * @param files relative path (e.g. "config/wifi.json" or "/config/wifi.json"
     *   - a leading slash is added automatically if missing, matching
     *   `spiffsgen.py`'s own convention) plus raw file content.
     * @return the full [imageSize]-byte image, ready to flash at the
     *   partition's offset (e.g. via
     *   [io.espflasher.app.flashing.FlashOperationManager.erasePartition] +
     *   a normal write).
     */
    fun generate(files: List<SpiffsSourceFile>): ByteArray {
        // Reset per-call state so one generator instance can safely be reused for a second image.
        blockIndex = 0
        pageInBlock = luPagesPerBlock
        lookupSlotWrites.clear()

        val image = ByteArray(imageSize.toInt())
        image.fill(0xFF.toByte()) // erased-flash default - anything never written stays exactly this

        require(files.size < 0x7FFE) { "Too many files (${files.size}) - object IDs are 15-bit" }

        var nextObjId = 1
        for (file in files) {
            val name = if (file.path.startsWith("/")) file.path else "/${file.path}"
            val nameBytes = name.toByteArray(Charsets.US_ASCII)
            require(nameBytes.size < objNameLen) {
                "\"$name\" is ${nameBytes.size} bytes, but objNameLen=$objNameLen only leaves room for " +
                    "${objNameLen - 1} bytes (SPIFFS has no real directory tree - the whole path counts against " +
                    "this limit, which is the single most common reason a real spiffsgen run fails too)"
            }
            writeFile(image, nextObjId, name, file.content)
            nextObjId++
        }

        for ((globalPage, objId) in lookupSlotWrites) {
            val block = globalPage / pagesPerBlock
            val slotInBlock = globalPage % pagesPerBlock
            val slotOffset = block * blockSize + slotInBlock * 2
            writeU16(image, slotOffset, objId)
        }

        return image
    }

    private fun writeFile(image: ByteArray, objId: Int, name: String, content: ByteArray) {
        // Pass 1: data pages, chunked to dataPageCapacity bytes each. A
        // zero-byte file produces none here - it still gets exactly one
        // (empty) index page in pass 2 below, so it exists in the filesystem.
        val dataPageNumbers = mutableListOf<Int>()
        var pos = 0
        var spanIx = 0
        while (pos < content.size) {
            val len = minOf(dataPageCapacity, content.size - pos)
            val page = allocatePage()
            writePageHeader(image, page, objId, spanIx, DATA_PAGE_FLAGS)
            val payloadOffset = page * pageSize + PAGE_HEADER_SIZE
            content.copyInto(image, payloadOffset, pos, pos + len)
            dataPageNumbers += page
            pos += len
            spanIx++
        }

        // Pass 2: one or more index pages referencing those data pages -
        // the first carries the object-index header (size/type/name/meta),
        // every subsequent one is header + refs only.
        var refPos = 0
        var indexSpanIx = 0
        do {
            val page = allocatePage()
            val capacity = if (indexSpanIx == 0) firstIndexPageRefCapacity else indexPageRefCapacity
            val refsHere = minOf(capacity, dataPageNumbers.size - refPos)
            writePageHeader(image, page, objId or IX_FLAG, indexSpanIx, INDEX_PAGE_FLAGS)

            var writeOffset = page * pageSize + PAGE_HEADER_SIZE
            if (indexSpanIx == 0) {
                // VERIFY: field order/sizes here (size u32, type u8, name[objNameLen], meta[metaLen])
                // is from memory of spiffs_page_object_ix_header - see the class doc above.
                writeU32(image, writeOffset, content.size.toLong()); writeOffset += 4
                image[writeOffset] = TYPE_FILE.toByte(); writeOffset += 1
                val nameBytes = name.toByteArray(Charsets.US_ASCII)
                nameBytes.copyInto(image, writeOffset, 0, nameBytes.size)
                // remaining name bytes + all meta bytes stay 0x00 here (NOT 0xFF -
                // this region is inside a page we're actively finalizing, and a
                // null-padded C string is what the firmware's reader expects)
                for (i in nameBytes.size until objNameLen) image[writeOffset + i] = 0
                writeOffset += objNameLen
                for (i in 0 until metaLen) image[writeOffset + i] = 0
                writeOffset += metaLen
            }
            for (i in 0 until refsHere) {
                writeU32(image, writeOffset, dataPageNumbers[refPos + i].toLong())
                writeOffset += 4
            }
            // any remaining ref slots in this index page are left at the
            // 0xFF fill from generate() - that reads back as 0xFFFFFFFF,
            // the same "no page" value used elsewhere in SPIFFS.

            refPos += refsHere
            indexSpanIx++
        } while (refPos < dataPageNumbers.size)
    }

    private fun allocatePage(): Int {
        if (pageInBlock >= pagesPerBlock) {
            blockIndex++
            pageInBlock = luPagesPerBlock
        }
        check(blockIndex < totalBlocks) {
            "SPIFFS image ($imageSize bytes) is too small for the given files - ran out of space after block $blockIndex of $totalBlocks"
        }
        val globalPage = blockIndex * pagesPerBlock + pageInBlock
        pageInBlock++
        return globalPage
    }

    private fun writePageHeader(image: ByteArray, page: Int, objId: Int, spanIx: Int, flags: Int) {
        val offset = page * pageSize
        writeU16(image, offset, objId)
        writeU16(image, offset + 2, spanIx)
        image[offset + 4] = flags.toByte()
        lookupSlotWrites += page to objId
    }

    private fun writeU16(image: ByteArray, offset: Int, value: Int) {
        BinaryUtils.u16le(value).copyInto(image, offset)
    }

    private fun writeU32(image: ByteArray, offset: Int, value: Long) {
        BinaryUtils.u32le(value).copyInto(image, offset)
    }
}

/** One file to embed - [path] relative to the SPIFFS root, [content] its raw bytes. */
data class SpiffsSourceFile(val path: String, val content: ByteArray)
