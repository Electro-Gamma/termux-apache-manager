package io.espflasher.app.protocol

/**
 * SPI NOR flash geometry constants shared by every supported chip (the value
 * of the SPI flash part is standardized across vendors, not chip-specific).
 */
object FlashLayout {
    const val SECTOR_SIZE = 0x1000 // 4 KiB - smallest erasable unit
    const val BLOCK_SIZE = 0x10000 // 64 KiB
    const val PAGE_SIZE = 0x100 // 256 B - smallest programmable unit

    /**
     * The erase_size field sent in FLASH_BEGIN/FLASH_DEFL_BEGIN.
     *
     * This is NOT the same as rounding [size] up to a whole number of
     * sectors starting at [offset] - that was this function's previous
     * (wrong) implementation, and it happened to go unnoticed because most
     * test writes were already sector-aligned. What each chip's ROM
     * actually wants here, per esptool:
     *  - Every chip except ESP8266 (which is every chip in this app, since
     *    they all ultimately inherit `ESP32ROM.get_erase_size`) wants
     *    [size] passed through completely unchanged - the ROM does its own
     *    sector rounding internally.
     *  - ESP8266's ROM has a documented erase-size bug in FLASH_BEGIN, and
     *    needs esptool's specific compensating formula instead
     *    (`targets/esp8266.py`'s `get_erase_size`, whose own comment reads
     *    "Provides a workaround for the bootloader erase bug"). Sending
     *    the naively-correct value there is exactly what triggers status
     *    0x0106 ("message was understood, but executing it failed") on a
     *    real ESP8266 - this isn't hypothetical, it's what a real device hit.
     */
    fun eraseSizeForFlashBegin(c: ChipType, offset: Long, size: Long): Long =
        if (c == ChipType.ESP8266) esp8266EraseSizeWorkaround(offset, size) else size

    private fun esp8266EraseSizeWorkaround(offset: Long, size: Long): Long {
        val sectorsPerBlock = 16L
        val sectorSize = SECTOR_SIZE.toLong()
        val numSectors = (size + sectorSize - 1) / sectorSize
        val startSector = offset / sectorSize
        var headSectors = sectorsPerBlock - (startSector % sectorsPerBlock)
        if (numSectors < headSectors) headSectors = numSectors
        return if (numSectors < 2 * headSectors) {
            (numSectors + 1) / 2 * sectorSize
        } else {
            (numSectors - headSectors) * sectorSize
        }
    }

    /** Decode a SPI flash JEDEC capacity byte (3rd byte of RDID/0x9F) to a size in bytes. */
    fun capacityByteToSize(capacityByte: Int): Long? {
        // Standard SPI NOR convention: size = 2^capacityByte bytes. Sanity-bound
        // it to 512 KB..128 MB so garbage reads don't produce nonsense values.
        if (capacityByte < 0x10 || capacityByte > 0x19) return null
        return 1L shl capacityByte
    }

    fun humanReadableSize(bytes: Long): String = when {
        bytes >= 1024 * 1024 -> "${bytes / (1024 * 1024)} MB"
        bytes >= 1024 -> "${bytes / 1024} KB"
        else -> "$bytes B"
    }
}
