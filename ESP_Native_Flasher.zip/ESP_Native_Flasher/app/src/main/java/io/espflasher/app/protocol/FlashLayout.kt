package io.espflasher.app.protocol

/**
 * SPI NOR flash geometry constants shared by every supported chip (the value
 * of the SPI flash part is standardized across vendors, not chip-specific).
 */
object FlashLayout {
    const val SECTOR_SIZE = 0x1000 // 4 KiB - smallest erasable unit
    const val BLOCK_SIZE = 0x10000 // 64 KiB
    const val PAGE_SIZE = 0x100 // 256 B - smallest programmable unit

    /**
     * Mirrors the ROM's own erase-size rounding used inside FLASH_BEGIN: round
     * the requested [size] starting at [offset] up to a whole number of erase
     * sectors so the ROM erases exactly the region about to be written.
     */
    fun roundedEraseSize(offset: Long, size: Long): Long {
        if (size == 0L) return 0L
        val sectorsCovered = ((offset + size + SECTOR_SIZE - 1) / SECTOR_SIZE) - (offset / SECTOR_SIZE)
        return sectorsCovered * SECTOR_SIZE
    }

    /** Decode a SPI flash JEDEC capacity byte (3rd byte of RDID/0x9F) to a size in bytes. */
    fun capacityByteToSize(capacityByte: Int): Long? {
        // Standard SPI NOR convention: size = 2^capacityByte bytes. Sanity-bound
        // it to 512 KB..128 MB so garbage reads don't produce nonsense values.
        if (capacityByte < 0x10 || capacityByte > 0x19) return null
        return 1L shl capacityByte
    }

    fun humanReadableSize(bytes: Long): String = when {
        bytes >= 1024 * 1024 -> "${bytes / (1024 * 1024)} MB"
        bytes >= 1024 -> "${bytes / 1024} KB"
        else -> "$bytes B"
    }
}
