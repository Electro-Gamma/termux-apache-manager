package io.espflasher.app.usb

import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import io.espflasher.app.protocol.SerialTransport
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/**
 * A single open USB-UART connection. Extends the protocol layer's
 * [SerialTransport] so an [io.espflasher.app.protocol.EspRomLoader] can talk
 * to it directly, plus the lifecycle/configuration calls the UI needs.
 */
interface UsbSerialPort : SerialTransport {
    val info: UsbDeviceInfo
    var config: SerialConfig

    /** Claims the interface, applies [config], and asserts the idle line state. */
    suspend fun open()

    /** Releases the interface and closes the underlying connection. */
    suspend fun close()

    /** Re-applies baud/data/stop/parity/flow-control without closing the port. */
    suspend fun applyConfig(newConfig: SerialConfig)
}

/**
 * Shared bulk-endpoint plumbing (buffered byte-at-a-time reads, chunked
 * writes, DTR/RTS bookkeeping) so each chip driver only has to implement the
 * vendor-specific control transfers in [applyConfig] and [setDtrRts].
 */
abstract class AbstractUsbSerialPort(
    protected val connection: UsbDeviceConnection,
    protected val usbInterface: UsbInterface,
    protected val endpointIn: UsbEndpoint,
    protected val endpointOut: UsbEndpoint,
    override val info: UsbDeviceInfo,
    initialConfig: SerialConfig
) : UsbSerialPort {

    override var config: SerialConfig = initialConfig

    private val readBuffer = ByteArray(READ_BUFFER_SIZE)
    private var readBufLen = 0
    private var readBufPos = 0
    private val readMutex = Mutex()
    private val writeMutex = Mutex()

    @Volatile protected var dtrAsserted = false
    @Volatile protected var rtsAsserted = false
    @Volatile private var opened = false

    override val isOpen: Boolean get() = opened

    protected fun markOpen() { opened = true }
    protected fun markClosed() { opened = false }

    override suspend fun write(data: ByteArray): Unit = writeMutex.withLock {
        withContext(Dispatchers.IO) {
            var offset = 0
            while (offset < data.size) {
                val len = minOf(MAX_WRITE_CHUNK, data.size - offset)
                val chunk = if (offset == 0 && len == data.size) data else data.copyOfRange(offset, offset + len)
                writeChunkFully(chunk, len)
                offset += len
            }
        }
    }

    /**
     * Submits [len] bytes of [chunk] to the OUT endpoint, resubmitting
     * whatever's left over if a single `bulkTransfer()` call returns a
     * short write.
     *
     * `bulkTransfer()` is built directly on the Linux `USBDEVFS_BULK`
     * ioctl, which documents returning the *actual* number of bytes
     * transferred - possibly less than requested - as a normal outcome
     * (a timeout partway through, the device momentarily not draining its
     * endpoint fast enough), not just as a failure signal. The previous
     * version of this function only checked `sent < 0` and otherwise
     * assumed `sent == len`, silently dropping whatever was left over on
     * a partial return. That corrupts the SLIP-framed byte stream from
     * that point on with no error raised at all - the ROM/stub then either
     * rejects the truncated packet's checksum or never sees its closing
     * 0xC0, and the caller's response read times out. Because whether any
     * given transfer comes up short is down to USB host-controller/OS
     * scheduling rather than packet content, this is exactly the kind of
     * bug that shows up as a write stalling at an unpredictable point -
     * more likely the longer a transfer runs (more `bulkTransfer` calls,
     * more chances to hit it), and at a different point every time.
     */
    private fun writeChunkFully(chunk: ByteArray, len: Int) {
        var sentSoFar = 0
        var zeroProgressStreak = 0
        while (sentSoFar < len) {
            val remaining = len - sentSoFar
            val buf = if (sentSoFar == 0) chunk else chunk.copyOfRange(sentSoFar, sentSoFar + remaining)
            val sent = connection.bulkTransfer(endpointOut, buf, remaining, WRITE_TIMEOUT_MS)
            if (sent < 0) throw io.espflasher.app.protocol.FlasherException.UsbDisconnected()
            if (sent == 0) {
                // No error, but no progress either - can legitimately happen
                // once (device momentarily busy). Retry a bounded number of
                // times rather than either spinning forever or (the old bug)
                // silently treating zero-progress as if it were complete.
                zeroProgressStreak++
                if (zeroProgressStreak >= MAX_ZERO_PROGRESS_RETRIES) {
                    throw io.espflasher.app.protocol.FlasherException.UsbDisconnected()
                }
                continue
            }
            zeroProgressStreak = 0
            sentSoFar += sent
        }
    }

    override suspend fun readByteOrNull(timeoutMs: Long): Int? = readMutex.withLock {
        withContext(Dispatchers.IO) {
            if (readBufPos >= readBufLen) {
                val budget = timeoutMs.coerceIn(1, Int.MAX_VALUE.toLong()).toInt()
                val n = connection.bulkTransfer(endpointIn, readBuffer, readBuffer.size, budget)
                if (n <= 0) return@withContext null
                readBufLen = n
                readBufPos = 0
            }
            val b = readBuffer[readBufPos].toInt() and 0xFF
            readBufPos++
            b
        }
    }

    override suspend fun purgeInput(): Unit = readMutex.withLock {
        readBufPos = 0
        readBufLen = 0
        withContext(Dispatchers.IO) {
            val scratch = ByteArray(READ_BUFFER_SIZE)
            // Drain whatever is already sitting in the endpoint with short, non-blocking-ish reads.
            repeat(8) {
                val n = connection.bulkTransfer(endpointIn, scratch, scratch.size, 5)
                if (n <= 0) return@repeat
            }
        }
    }

    companion object {
        const val READ_BUFFER_SIZE = 4096
        const val MAX_WRITE_CHUNK = 4096
        const val WRITE_TIMEOUT_MS = 3000
        const val MAX_ZERO_PROGRESS_RETRIES = 5
    }
}
