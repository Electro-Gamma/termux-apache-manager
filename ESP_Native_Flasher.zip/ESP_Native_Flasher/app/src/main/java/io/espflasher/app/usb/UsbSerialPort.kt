package io.espflasher.app.usb

import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import io.espflasher.app.protocol.SerialTransport
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/**
 * A single open USB-UART connection. Extends the protocol layer's
 * [SerialTransport] so an [io.espflasher.app.protocol.EspRomLoader] can talk
 * to it directly, plus the lifecycle/configuration calls the UI needs.
 */
interface UsbSerialPort : SerialTransport {
    val info: UsbDeviceInfo
    var config: SerialConfig

    /** Claims the interface, applies [config], and asserts the idle line state. */
    suspend fun open()

    /** Releases the interface and closes the underlying connection. */
    suspend fun close()

    /** Re-applies baud/data/stop/parity/flow-control without closing the port. */
    suspend fun applyConfig(newConfig: SerialConfig)
}

/**
 * Shared bulk-endpoint plumbing (buffered byte-at-a-time reads, chunked
 * writes, DTR/RTS bookkeeping) so each chip driver only has to implement the
 * vendor-specific control transfers in [applyConfig] and [setDtrRts].
 */
abstract class AbstractUsbSerialPort(
    protected val connection: UsbDeviceConnection,
    protected val usbInterface: UsbInterface,
    protected val endpointIn: UsbEndpoint,
    protected val endpointOut: UsbEndpoint,
    override val info: UsbDeviceInfo,
    initialConfig: SerialConfig
) : UsbSerialPort {

    override var config: SerialConfig = initialConfig

    // rawReadBuffer is what bulkTransfer() writes into directly; readBuffer
    // is what readByteOrNull actually serves bytes from. They're the same
    // *bytes* for most chips (see [filterIncoming]'s default), but kept as
    // two separate references because a driver whose endpoint doesn't carry
    // a clean, contiguous serial stream on its own - see
    // [io.espflasher.app.usb.drivers.FtdiSerialDriver] - needs to hand back
    // a shorter, repacked array without disturbing rawReadBuffer, which
    // the next bulkTransfer() call will overwrite regardless.
    //
    // READ_BUFFER_SIZE (4096) is deliberately a multiple of every USB bulk
    // max-packet-size in practical use here (64 for full-speed, 512 for
    // high-speed) - [FtdiSerialDriver.filterIncoming] depends on that: a
    // bulk transfer can only ever end on a full buffer, a short packet, or
    // a timeout, and it's what makes "every chunk except possibly the last
    // one is a full max-packet-size packet" a safe assumption to walk the
    // raw buffer with. Don't resize this to something that isn't a multiple
    // of 512 without re-checking that.
    private val rawReadBuffer = ByteArray(READ_BUFFER_SIZE)
    private var readBuffer: ByteArray = ByteArray(0)
    private var readBufLen = 0
    private var readBufPos = 0
    private val readMutex = Mutex()
    private val writeMutex = Mutex()

    @Volatile protected var dtrAsserted = false
    @Volatile protected var rtsAsserted = false
    @Volatile private var opened = false

    override val isOpen: Boolean get() = opened

    protected fun markOpen() { opened = true }
    protected fun markClosed() { opened = false }

    override suspend fun write(data: ByteArray): Unit = writeMutex.withLock {
        withContext(Dispatchers.IO) {
            var offset = 0
            while (offset < data.size) {
                val len = minOf(MAX_WRITE_CHUNK, data.size - offset)
                val chunk = if (offset == 0 && len == data.size) data else data.copyOfRange(offset, offset + len)
                writeChunkFully(chunk, len)
                offset += len
            }
        }
    }

    /**
     * Submits [len] bytes of [chunk] to the OUT endpoint, resubmitting
     * whatever's left over if a single `bulkTransfer()` call returns a
     * short write.
     *
     * `bulkTransfer()` is built directly on the Linux `USBDEVFS_BULK`
     * ioctl, which documents returning the *actual* number of bytes
     * transferred - possibly less than requested - as a normal outcome
     * (a timeout partway through, the device momentarily not draining its
     * endpoint fast enough), not just as a failure signal. The previous
     * version of this function only checked `sent < 0` and otherwise
     * assumed `sent == len`, silently dropping whatever was left over on
     * a partial return. That corrupts the SLIP-framed byte stream from
     * that point on with no error raised at all - the ROM/stub then either
     * rejects the truncated packet's checksum or never sees its closing
     * 0xC0, and the caller's response read times out. Because whether any
     * given transfer comes up short is down to USB host-controller/OS
     * scheduling rather than packet content, this is exactly the kind of
     * bug that shows up as a write stalling at an unpredictable point -
     * more likely the longer a transfer runs (more `bulkTransfer` calls,
     * more chances to hit it), and at a different point every time.
     */
    private fun writeChunkFully(chunk: ByteArray, len: Int) {
        var sentSoFar = 0
        var zeroProgressStreak = 0
        while (sentSoFar < len) {
            val remaining = len - sentSoFar
            val buf = if (sentSoFar == 0) chunk else chunk.copyOfRange(sentSoFar, sentSoFar + remaining)
            val sent = connection.bulkTransfer(endpointOut, buf, remaining, WRITE_TIMEOUT_MS)
            if (sent < 0) throw io.espflasher.app.protocol.FlasherException.UsbDisconnected()
            if (sent == 0) {
                // No error, but no progress either - can legitimately happen
                // once (device momentarily busy). Retry a bounded number of
                // times rather than either spinning forever or (the old bug)
                // silently treating zero-progress as if it were complete.
                zeroProgressStreak++
                if (zeroProgressStreak >= MAX_ZERO_PROGRESS_RETRIES) {
                    throw io.espflasher.app.protocol.FlasherException.UsbDisconnected()
                }
                continue
            }
            zeroProgressStreak = 0
            sentSoFar += sent
        }
    }

    override suspend fun readByteOrNull(timeoutMs: Long): Int? = readMutex.withLock {
        withContext(Dispatchers.IO) {
            val deadline = System.currentTimeMillis() + timeoutMs
            // A while loop, not an if: [filterIncoming] can legitimately
            // come back with zero bytes even though bulkTransfer() itself
            // succeeded (n > 0) - an FTDI packet that was pure modem-status
            // with no data, most commonly. That's not a timeout, so this
            // loops around for another bulkTransfer() within whatever
            // budget is left, rather than reporting a false one. For every
            // other driver (identity [filterIncoming]) this is never zero
            // when n > 0, so the loop always exits after one iteration,
            // same as before.
            while (readBufPos >= readBufLen) {
                val remaining = (deadline - System.currentTimeMillis())
                    .coerceIn(1, Int.MAX_VALUE.toLong()).toInt()
                val n = connection.bulkTransfer(endpointIn, rawReadBuffer, rawReadBuffer.size, remaining)
                if (n <= 0) return@withContext null
                readBuffer = filterIncoming(rawReadBuffer, n)
                readBufLen = readBuffer.size
                readBufPos = 0
            }
            val b = readBuffer[readBufPos].toInt() and 0xFF
            readBufPos++
            b
        }
    }

    /**
     * Extracts the real serial payload from the [n] valid bytes just read
     * off the bulk-IN endpoint into `raw[0 until n]`.
     *
     * The default here is the identity transform - a straight pass-through
     * (copied only if the read didn't fill the whole buffer). That's
     * correct for CP210x, CH340/341, PL2303, and standard CDC-ACM: on all
     * four, the bulk-IN endpoint really does carry a clean, contiguous
     * serial byte stream with nothing else mixed in, so none of those
     * driver files override this.
     *
     * [io.espflasher.app.usb.drivers.FtdiSerialDriver] is the one exception
     * and does override it - see that override's doc comment for why.
     */
    protected open fun filterIncoming(raw: ByteArray, n: Int): ByteArray =
        if (n == raw.size) raw else raw.copyOf(n)

    override suspend fun purgeInput(): Unit = readMutex.withLock {
        readBufPos = 0
        readBufLen = 0
        withContext(Dispatchers.IO) {
            val scratch = ByteArray(READ_BUFFER_SIZE)
            // Drain whatever is already sitting in the endpoint with short, non-blocking-ish reads.
            repeat(8) {
                val n = connection.bulkTransfer(endpointIn, scratch, scratch.size, 5)
                if (n <= 0) return@repeat
            }
        }
    }

    companion object {
        const val READ_BUFFER_SIZE = 4096
        const val MAX_WRITE_CHUNK = 4096
        const val WRITE_TIMEOUT_MS = 3000
        const val MAX_ZERO_PROGRESS_RETRIES = 5
    }
}
