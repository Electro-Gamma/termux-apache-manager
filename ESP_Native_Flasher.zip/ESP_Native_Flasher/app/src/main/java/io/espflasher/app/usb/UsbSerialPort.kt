package io.espflasher.app.usb

import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import io.espflasher.app.protocol.SerialTransport
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

/**
 * A single open USB-UART connection. Extends the protocol layer's
 * [SerialTransport] so an [io.espflasher.app.protocol.EspRomLoader] can talk
 * to it directly, plus the lifecycle/configuration calls the UI needs.
 */
interface UsbSerialPort : SerialTransport {
    val info: UsbDeviceInfo
    var config: SerialConfig

    /** Claims the interface, applies [config], and asserts the idle line state. */
    suspend fun open()

    /** Releases the interface and closes the underlying connection. */
    suspend fun close()

    /** Re-applies baud/data/stop/parity/flow-control without closing the port. */
    suspend fun applyConfig(newConfig: SerialConfig)
}

/**
 * Shared bulk-endpoint plumbing (a background read pump feeding buffered
 * reads, chunked writes, DTR/RTS bookkeeping) so each chip driver only has
 * to implement the vendor-specific control transfers in [applyConfig] and
 * [setDtrRts].
 */
abstract class AbstractUsbSerialPort(
    protected val connection: UsbDeviceConnection,
    protected val usbInterface: UsbInterface,
    protected val endpointIn: UsbEndpoint,
    protected val endpointOut: UsbEndpoint,
    override val info: UsbDeviceInfo,
    initialConfig: SerialConfig
) : UsbSerialPort {

    override var config: SerialConfig = initialConfig

    // ---------------------------------------------------------------------
    // Read side: a background "pump" coroutine continuously drains the IN
    // endpoint into this channel, independent of whether/when anyone is
    // actually asking for data. readByteOrNull/readBytes just consume from
    // it. See startReadPump()'s doc comment for why this exists - reading
    // only on-demand (the previous design) left the endpoint undrained
    // between individual protocol-layer requests for long enough, on real
    // hardware, that a fast/bursty sender (a stub flasher can have up to 64
    // flash-read sectors in flight at once) overflowed its own UART FIFO
    // and silently dropped bytes.
    // ---------------------------------------------------------------------
    private val incomingChunks = Channel<ByteArray>(Channel.UNLIMITED)
    private var curChunk: ByteArray = ByteArray(0)
    private var curChunkPos: Int = 0
    private val readMutex = Mutex()
    private val writeMutex = Mutex()
    private val pumpScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var pumpJob: Job? = null

    @Volatile protected var dtrAsserted = false
    @Volatile protected var rtsAsserted = false
    @Volatile private var opened = false

    override val isOpen: Boolean get() = opened

    protected fun markOpen() {
        opened = true
        startReadPump()
    }

    /**
     * Stops the read pump and waits for it to actually finish
     * ([Job.cancelAndJoin], not just [Job.cancel]) before returning, so a
     * driver's `close()` can safely call `connection.close()` right after
     * this without racing the pump's own in-flight `bulkTransfer()` call on
     * a different thread.
     */
    protected suspend fun markClosed() {
        pumpJob?.cancelAndJoin()
        pumpJob = null
        readMutex.withLock { clearReadState() }
        opened = false
    }

    /**
     * Continuously issues `bulkTransfer()` reads on the IN endpoint and
     * pushes whatever comes back into [incomingChunks], as fast as the
     * device can send it - completely decoupled from whether
     * [readByteOrNull]/[readBytes] happen to be waiting right now.
     *
     * This is the actual fix for "Corrupt data during flash read: expected
     * a 4096-byte sector but got N bytes" errors that persisted even after
     * batching reads into larger chunks (a real improvement, but not the
     * root cause): with on-demand reading, the gap between the protocol
     * layer finishing one read/ACK cycle and asking for the next is real
     * time during which nothing is draining the endpoint, and a stub
     * flasher's read-flash protocol allows up to 64 sectors in flight
     * without waiting for an ACK - it isn't strictly waiting for us between
     * sectors, so that gap is exactly where a burst can overflow the
     * device-side UART FIFO and silently lose bytes. A background pump
     * removes the gap entirely: the endpoint gets drained continuously
     * regardless of consumer timing, and an unlimited in-memory channel
     * (a few MB at most for any read this app does) absorbs whatever the
     * consumer hasn't gotten to yet.
     *
     * A `bulkTransfer()` timeout (no data within [PUMP_POLL_TIMEOUT_MS])
     * just means "nothing to forward this iteration" - not a failure - so
     * the loop simply polls again immediately. Any actual exception (e.g.
     * the connection getting closed out from under it) ends the pump
     * quietly; subsequent reads then just time out waiting on the channel,
     * consistent with how a failed on-demand read used to surface as well.
     */
    private fun startReadPump() {
        pumpJob = pumpScope.launch {
            val buf = ByteArray(READ_BUFFER_SIZE)
            while (isActive) {
                val n = try {
                    connection.bulkTransfer(endpointIn, buf, buf.size, PUMP_POLL_TIMEOUT_MS)
                } catch (e: Throwable) {
                    break
                }
                if (n > 0) {
                    incomingChunks.trySend(buf.copyOf(n))
                }
            }
        }
    }

    private fun clearReadState() {
        curChunk = ByteArray(0)
        curChunkPos = 0
        while (true) {
            val result = incomingChunks.tryReceive()
            if (!result.isSuccess) break
        }
    }

    override suspend fun write(data: ByteArray): Unit = writeMutex.withLock {
        withContext(Dispatchers.IO) {
            var offset = 0
            while (offset < data.size) {
                val len = minOf(MAX_WRITE_CHUNK, data.size - offset)
                val chunk = if (offset == 0 && len == data.size) data else data.copyOfRange(offset, offset + len)
                writeChunkFully(chunk, len)
                offset += len
            }
        }
    }

    /**
     * Submits [len] bytes of [chunk] to the OUT endpoint, resubmitting
     * whatever's left over if a single `bulkTransfer()` call returns a
     * short write.
     *
     * `bulkTransfer()` is built directly on the Linux `USBDEVFS_BULK`
     * ioctl, which documents returning the *actual* number of bytes
     * transferred - possibly less than requested - as a normal outcome
     * (a timeout partway through, the device momentarily not draining its
     * endpoint fast enough), not just as a failure signal. The previous
     * version of this function only checked `sent < 0` and otherwise
     * assumed `sent == len`, silently dropping whatever was left over on
     * a partial return. That corrupts the SLIP-framed byte stream from
     * that point on with no error raised at all - the ROM/stub then either
     * rejects the truncated packet's checksum or never sees its closing
     * 0xC0, and the caller's response read times out. Because whether any
     * given transfer comes up short is down to USB host-controller/OS
     * scheduling rather than packet content, this is exactly the kind of
     * bug that shows up as a write stalling at an unpredictable point -
     * more likely the longer a transfer runs (more `bulkTransfer` calls,
     * more chances to hit it), and at a different point every time.
     */
    private fun writeChunkFully(chunk: ByteArray, len: Int) {
        var sentSoFar = 0
        var zeroProgressStreak = 0
        while (sentSoFar < len) {
            val remaining = len - sentSoFar
            val buf = if (sentSoFar == 0) chunk else chunk.copyOfRange(sentSoFar, sentSoFar + remaining)
            val sent = connection.bulkTransfer(endpointOut, buf, remaining, WRITE_TIMEOUT_MS)
            if (sent < 0) throw io.espflasher.app.protocol.FlasherException.UsbDisconnected()
            if (sent == 0) {
                // No error, but no progress either - can legitimately happen
                // once (device momentarily busy). Retry a bounded number of
                // times rather than either spinning forever or (the old bug)
                // silently treating zero-progress as if it were complete.
                zeroProgressStreak++
                if (zeroProgressStreak >= MAX_ZERO_PROGRESS_RETRIES) {
                    throw io.espflasher.app.protocol.FlasherException.UsbDisconnected()
                }
                continue
            }
            zeroProgressStreak = 0
            sentSoFar += sent
        }
    }

    override suspend fun readByteOrNull(timeoutMs: Long): Int? = readMutex.withLock {
        if (curChunkPos >= curChunk.size) {
            val next = withTimeoutOrNull(timeoutMs) { incomingChunks.receive() } ?: return@withLock null
            curChunk = next
            curChunkPos = 0
        }
        val b = curChunk[curChunkPos].toInt() and 0xFF
        curChunkPos++
        b
    }

    /**
     * See [SerialTransport.readBytes]'s doc comment for why this exists
     * alongside [readByteOrNull]. Waits (up to [timeoutMs]) for at least
     * one chunk the background pump has already pulled off the wire, then
     * opportunistically drains any further chunks already sitting in the
     * channel (without blocking for them) to fill [buf] as much as
     * possible in one call.
     */
    override suspend fun readBytes(buf: ByteArray, timeoutMs: Long): Int = readMutex.withLock {
        if (curChunkPos >= curChunk.size) {
            val next = withTimeoutOrNull(timeoutMs) { incomingChunks.receive() } ?: return@withLock 0
            curChunk = next
            curChunkPos = 0
        }
        var written = 0
        while (written < buf.size) {
            if (curChunkPos >= curChunk.size) {
                val more = incomingChunks.tryReceive().getOrNull() ?: break
                curChunk = more
                curChunkPos = 0
            }
            val available = curChunk.size - curChunkPos
            val toCopy = minOf(available, buf.size - written)
            System.arraycopy(curChunk, curChunkPos, buf, written, toCopy)
            curChunkPos += toCopy
            written += toCopy
        }
        written
    }

    override suspend fun purgeInput(): Unit = readMutex.withLock {
        clearReadState()
    }

    companion object {
        const val READ_BUFFER_SIZE = 4096
        const val MAX_WRITE_CHUNK = 4096
        const val WRITE_TIMEOUT_MS = 3000
        const val MAX_ZERO_PROGRESS_RETRIES = 5

        /**
         * Per-poll timeout for the background read pump's `bulkTransfer()`
         * calls. Long enough that the pump isn't needlessly spinning the
         * CPU when idle (a call returns as soon as data arrives, well
         * before this elapses, so this only matters when nothing is
         * coming), short enough that the pump notices cancellation
         * (`markClosed()` via [cancelAndJoin]) reasonably promptly on
         * close.
         */
        const val PUMP_POLL_TIMEOUT_MS = 1000
    }
}
