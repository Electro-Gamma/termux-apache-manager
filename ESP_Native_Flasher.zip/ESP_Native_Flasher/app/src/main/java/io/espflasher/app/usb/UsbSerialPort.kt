package io.espflasher.app.usb

import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import io.espflasher.app.protocol.SerialTransport
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/**
 * A single open USB-UART connection. Extends the protocol layer's
 * [SerialTransport] so an [io.espflasher.app.protocol.EspRomLoader] can talk
 * to it directly, plus the lifecycle/configuration calls the UI needs.
 */
interface UsbSerialPort : SerialTransport {
    val info: UsbDeviceInfo
    var config: SerialConfig

    /** Claims the interface, applies [config], and asserts the idle line state. */
    suspend fun open()

    /** Releases the interface and closes the underlying connection. */
    suspend fun close()

    /** Re-applies baud/data/stop/parity/flow-control without closing the port. */
    suspend fun applyConfig(newConfig: SerialConfig)
}

/**
 * Shared bulk-endpoint plumbing (buffered byte-at-a-time reads, chunked
 * writes, DTR/RTS bookkeeping) so each chip driver only has to implement the
 * vendor-specific control transfers in [applyConfig] and [setDtrRts].
 */
abstract class AbstractUsbSerialPort(
    protected val connection: UsbDeviceConnection,
    protected val usbInterface: UsbInterface,
    protected val endpointIn: UsbEndpoint,
    protected val endpointOut: UsbEndpoint,
    override val info: UsbDeviceInfo,
    initialConfig: SerialConfig
) : UsbSerialPort {

    override var config: SerialConfig = initialConfig

    private val readBuffer = ByteArray(READ_BUFFER_SIZE)
    private var readBufLen = 0
    private var readBufPos = 0
    private val readMutex = Mutex()
    private val writeMutex = Mutex()

    @Volatile protected var dtrAsserted = false
    @Volatile protected var rtsAsserted = false
    @Volatile private var opened = false

    override val isOpen: Boolean get() = opened

    protected fun markOpen() { opened = true }
    protected fun markClosed() { opened = false }

    override suspend fun write(data: ByteArray): Unit = writeMutex.withLock {
        withContext(Dispatchers.IO) {
            var offset = 0
            while (offset < data.size) {
                val len = minOf(MAX_WRITE_CHUNK, data.size - offset)
                val chunk = if (offset == 0 && len == data.size) data else data.copyOfRange(offset, offset + len)
                val sent = connection.bulkTransfer(endpointOut, chunk, len, WRITE_TIMEOUT_MS)
                if (sent < 0) throw io.espflasher.app.protocol.FlasherException.UsbDisconnected()
                offset += len
            }
        }
    }

    override suspend fun readByteOrNull(timeoutMs: Long): Int? = readMutex.withLock {
        withContext(Dispatchers.IO) {
            if (readBufPos >= readBufLen) {
                val budget = timeoutMs.coerceIn(1, Int.MAX_VALUE.toLong()).toInt()
                val n = connection.bulkTransfer(endpointIn, readBuffer, readBuffer.size, budget)
                if (n <= 0) return@withContext null
                readBufLen = n
                readBufPos = 0
            }
            val b = readBuffer[readBufPos].toInt() and 0xFF
            readBufPos++
            b
        }
    }

    override suspend fun purgeInput(): Unit = readMutex.withLock {
        readBufPos = 0
        readBufLen = 0
        withContext(Dispatchers.IO) {
            val scratch = ByteArray(READ_BUFFER_SIZE)
            // Drain whatever is already sitting in the endpoint with short, non-blocking-ish reads.
            repeat(8) {
                val n = connection.bulkTransfer(endpointIn, scratch, scratch.size, 5)
                if (n <= 0) return@repeat
            }
        }
    }

    companion object {
        const val READ_BUFFER_SIZE = 4096
        const val MAX_WRITE_CHUNK = 4096
        const val WRITE_TIMEOUT_MS = 3000
    }
}
