package io.espflasher.app.ui

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import io.espflasher.app.R
import io.espflasher.app.flashing.LogEntry
import io.espflasher.app.flashing.LogLevel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Renders the console log, color-coding each line by [LogLevel]. */
class LogAdapter(private var fontSizeSp: Float = 12f) : ListAdapter<LogEntry, LogAdapter.ViewHolder>(DIFF) {

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<LogEntry>() {
            override fun areItemsTheSame(oldItem: LogEntry, newItem: LogEntry) = oldItem === newItem
            override fun areContentsTheSame(oldItem: LogEntry, newItem: LogEntry) = oldItem == newItem
        }
        private val TIME_FORMAT = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
    }

    fun setFontSize(sp: Float) {
        fontSizeSp = sp
        notifyDataSetChanged()
    }

    class ViewHolder(val textView: TextView) : RecyclerView.ViewHolder(textView)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_log_entry, parent, false) as TextView
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val entry = getItem(position)
        val time = TIME_FORMAT.format(Date(entry.timestampMs))
        holder.textView.text = "[$time] ${entry.message}"
        holder.textView.setTextColor(colorFor(entry.level))
        holder.textView.textSize = fontSizeSp
    }

    private fun colorFor(level: LogLevel): Int = when (level) {
        LogLevel.COMMAND -> Color.parseColor("#4FC3F7")
        LogLevel.RESPONSE -> Color.parseColor("#B0BEC5")
        LogLevel.INFO -> Color.parseColor("#CFD8DC")
        LogLevel.SUCCESS -> Color.parseColor("#66BB6A")
        LogLevel.WARNING -> Color.parseColor("#FFCA28")
        LogLevel.ERROR -> Color.parseColor("#EF5350")
        LogLevel.DEBUG -> Color.parseColor("#B39DDB")
    }
}
