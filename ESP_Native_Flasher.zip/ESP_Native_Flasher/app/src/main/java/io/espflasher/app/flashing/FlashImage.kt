package io.espflasher.app.flashing

import android.net.Uri

/** Which named slot a [FlashImage] came from - purely for UI/log labeling. */
enum class ImageSlot(val label: String) {
    BOOTLOADER("Bootloader"),
    PARTITION_TABLE("Partition Table"),
    OTA_DATA("OTA Data"),
    APPLICATION("Application BIN"),
    FIRMWARE("Firmware BIN"),
    CUSTOM("Custom")
}

data class FlashImage(
    val slot: ImageSlot,
    val uri: Uri,
    val fileName: String,
    val offset: Long,
    val sizeBytes: Long
)
