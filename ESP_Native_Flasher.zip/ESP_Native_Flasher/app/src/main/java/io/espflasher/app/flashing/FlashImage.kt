package io.espflasher.app.flashing

import android.net.Uri

/**
 * Which named slot a [FlashImage] came from - purely for UI/log labeling,
 * plus the offset each slot pre-fills with. [hasConventionalOffset] is false
 * for slots whose real address depends entirely on the person's own
 * partition table (SPIFFS/LittleFS especially varies a lot), so those start
 * blank rather than pre-filled with a guess that could be wrong for their
 * board and silently overwrite the wrong region.
 */
enum class ImageSlot(val label: String, val defaultOffset: Long?) {
    BOOTLOADER("Bootloader", 0x1000L),
    PARTITION_TABLE("Partition Table", 0x8000L),
    APPLICATION("Application BIN", 0x10000L),
    OTA_DATA("OTA Data", 0xE000L),
    SPIFFS("SPIFFS / Filesystem", null),
    CUSTOM_1("Custom Binary 1", null),
    CUSTOM_2("Custom Binary 2", null),
    FIRMWARE("Firmware BIN", 0x0L);

    val hasConventionalOffset: Boolean get() = defaultOffset != null
}

data class FlashImage(
    val slot: ImageSlot,
    val uri: Uri,
    val fileName: String,
    val offset: Long,
    val sizeBytes: Long
)

