package io.espflasher.app.flashing

import android.net.Uri

/**
 * Which named slot a [FlashImage] came from - purely for UI/log labeling,
 * plus the offset each slot pre-fills with. A null [defaultOffset] is for
 * slots whose real address depends entirely on the person's own partition
 * table (SPIFFS/LittleFS especially varies a lot), so those start blank
 * rather than pre-filled with a guess that could be wrong for their board
 * and silently overwrite the wrong region.
 *
 * Beyond these six fixed slots, the file-selection panel also supports an
 * unlimited number of additional entries added via "+" (see
 * `MainUiState.customEntries`) for anything that doesn't fit a named slot.
 */
enum class ImageSlot(val label: String, val defaultOffset: Long?, val requiresImageMagic: Boolean) {
    BOOTLOADER("Bootloader", 0x1000L, requiresImageMagic = true),
    PARTITION_TABLE("Partition Table", 0x8000L, requiresImageMagic = false),
    APPLICATION("Application BIN", 0x10000L, requiresImageMagic = true),
    OTA_DATA("Boot App", 0xE000L, requiresImageMagic = false),
    SPIFFS("SPIFFS / Filesystem", null, requiresImageMagic = false),
    FIRMWARE("Firmware BIN", 0x0L, requiresImageMagic = true);

    val hasConventionalOffset: Boolean get() = defaultOffset != null
}

data class FlashImage(
    val label: String,
    val uri: Uri,
    val fileName: String,
    val offset: Long,
    val sizeBytes: Long,
    /** Whether to warn if this file doesn't start with the ESP image magic byte (0xE9). */
    val requiresImageMagic: Boolean = false
)
