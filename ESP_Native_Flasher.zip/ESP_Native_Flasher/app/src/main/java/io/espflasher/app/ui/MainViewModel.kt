package io.espflasher.app.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import io.espflasher.app.data.RecentFilesRepository
import io.espflasher.app.data.SettingsRepository
import io.espflasher.app.flashing.DeviceInfoSnapshot
import io.espflasher.app.flashing.FlashCallback
import io.espflasher.app.flashing.FlashImage
import io.espflasher.app.flashing.FlashOperationManager
import io.espflasher.app.flashing.FlashOptions
import io.espflasher.app.flashing.ImageSlot
import io.espflasher.app.flashing.LogEntry
import io.espflasher.app.flashing.LogLevel
import io.espflasher.app.flashing.ProgressState
import io.espflasher.app.protocol.FlasherException
import io.espflasher.app.service.FlashForegroundService
import io.espflasher.app.usb.SerialConfig
import io.espflasher.app.usb.UsbDeviceInfo
import io.espflasher.app.usb.UsbSerialManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val usbSerialManager = UsbSerialManager(application)
    private val flashManager = FlashOperationManager(application, usbSerialManager)
    private val settingsRepository = SettingsRepository(application)
    private val recentFilesRepository = RecentFilesRepository(application)

    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    private var operationJob: Job? = null

    companion object {
        private const val MAX_LOG_LINES = 4000
    }

    init {
        _uiState.update { it.copy(usbHostSupported = usbSerialManager.isUsbHostSupported()) }
        refreshDevices()
        restoreRememberedFiles()
        viewModelScope.launch {
            settingsRepository.settingsFlow.collect { settings ->
                _uiState.update {
                    it.copy(
                        consoleFontSizeSp = settings.consoleFontSizeSp,
                        serialConfig = it.serialConfig.copy(baudRate = it.serialConfig.baudRate.takeIf { b -> b != 115200 } ?: settings.defaultBaudRate)
                    )
                }
            }
        }
    }

    private fun restoreRememberedFiles() {
        val offsets = ImageSlot.entries.mapNotNull { slot ->
            recentFilesRepository.loadOffsetOrNull(slot)?.let { slot to "0x%X".format(it) }
        }.toMap()
        val files = mutableMapOf<ImageSlot, SelectedFile>()
        for (slot in ImageSlot.entries) {
            recentFilesRepository.load(slot)?.let { entry ->
                files[slot] = SelectedFile(entry.uri, entry.fileName, sizeBytes = 0L)
            }
        }
        // Deliberately NOT added to enabledSlots here - a file remembered from a
        // previous session should never be silently included in a flash again
        // without the person consciously re-checking it this session.
        _uiState.update { it.copy(offsetText = offsets, files = files) }
    }

    // -----------------------------------------------------------------
    // Device discovery
    // -----------------------------------------------------------------

    fun refreshDevices() {
        val devices = usbSerialManager.listDevices()
        _uiState.update { state ->
            val stillPresent = devices.any { it.androidDeviceName == state.selectedDeviceName }
            state.copy(
                availableDevices = devices,
                selectedDeviceName = if (stillPresent) state.selectedDeviceName else devices.firstOrNull()?.androidDeviceName
            )
        }
    }

    fun selectDevice(device: UsbDeviceInfo) {
        _uiState.update { it.copy(selectedDeviceName = device.androidDeviceName) }
    }

    fun updateSerialConfig(config: SerialConfig) {
        _uiState.update { it.copy(serialConfig = config) }
    }

    fun updateUploadBaudRate(baud: Int) {
        _uiState.update { it.copy(uploadBaudRate = baud) }
    }

    // -----------------------------------------------------------------
    // Connection panel
    // -----------------------------------------------------------------

    fun connect() {
        val state = _uiState.value
        val deviceInfo = state.availableDevices.firstOrNull { it.androidDeviceName == state.selectedDeviceName }
        if (deviceInfo == null) {
            appendLog(LogLevel.ERROR, "No USB device selected.")
            return
        }
        val device = usbSerialManager.findUsbDevice(deviceInfo.androidDeviceName)
        if (device == null) {
            appendLog(LogLevel.ERROR, "Device is no longer attached.")
            refreshDevices()
            return
        }
        runOperation(setConnecting = true) {
            flashManager.connect(device, state.serialConfig, callback)
            _uiState.update { it.copy(connectionState = ConnectionState.CONNECTED) }
            // Keeps the process (and any long flash/erase running in it) alive
            // if the app gets backgrounded mid-operation, with an honest
            // notification showing what's actually happening.
            FlashForegroundService.start(getApplication(), "Connected to ${deviceInfo.displayLabel} - idle")
        }
    }

    fun disconnect() {
        runOperation {
            flashManager.disconnect(callback)
            _uiState.update { it.copy(connectionState = ConnectionState.DISCONNECTED, deviceInfo = null) }
            FlashForegroundService.stop(getApplication())
        }
    }

    fun resetDevice() {
        runOperation { flashManager.resetDevice(callback) }
    }

    fun enterBootloader() {
        runOperation { flashManager.enterBootloaderManual(callback) }
    }

    // -----------------------------------------------------------------
    // File selection
    // -----------------------------------------------------------------

    fun fileSelected(slot: ImageSlot, uri: Uri, fileName: String, sizeBytes: Long) {
        val offset = recentFilesRepository.loadOffsetOrNull(slot) ?: slot.defaultOffset ?: 0L
        recentFilesRepository.save(slot, uri, fileName, offset)
        _uiState.update { state ->
            state.copy(
                files = state.files + (slot to SelectedFile(uri, fileName, sizeBytes)),
                offsetText = state.offsetText + (slot to "0x%X".format(offset)),
                // A file picked this session is what the person clearly wants
                // flashed - auto-include it rather than making them find a
                // second checkbox right after they just picked the file.
                enabledSlots = state.enabledSlots + slot
            )
        }
    }

    fun clearFile(slot: ImageSlot) {
        recentFilesRepository.clear(slot)
        _uiState.update { it.copy(files = it.files - slot, enabledSlots = it.enabledSlots - slot) }
    }

    /** The checkbox next to each slot - whether it's actually included in the next Flash/Verify. */
    fun setSlotEnabled(slot: ImageSlot, enabled: Boolean) {
        _uiState.update {
            it.copy(enabledSlots = if (enabled) it.enabledSlots + slot else it.enabledSlots - slot)
        }
    }

    fun offsetTextChanged(slot: ImageSlot, text: String) {
        _uiState.update { it.copy(offsetText = it.offsetText + (slot to text)) }
        parseAddress(text)?.let { recentFilesRepository.saveOffset(slot, it) }
    }

    // -----------------------------------------------------------------
    // Additional files ("+" button - unlimited extra entries beyond the six named slots)
    // -----------------------------------------------------------------

    fun addCustomEntry(uri: Uri, fileName: String) {
        val entry = CustomFileEntry(
            id = java.util.UUID.randomUUID().toString(),
            uri = uri,
            fileName = fileName,
            offsetText = "0x0",
            enabled = true
        )
        _uiState.update { it.copy(customEntries = it.customEntries + entry) }
    }

    fun removeCustomEntry(id: String) {
        _uiState.update { it.copy(customEntries = it.customEntries.filterNot { e -> e.id == id }) }
    }

    fun customEntryOffsetChanged(id: String, text: String) {
        _uiState.update { state ->
            state.copy(customEntries = state.customEntries.map { if (it.id == id) it.copy(offsetText = text) else it })
        }
    }

    fun setCustomEntryEnabled(id: String, enabled: Boolean) {
        _uiState.update { state ->
            state.copy(customEntries = state.customEntries.map { if (it.id == id) it.copy(enabled = enabled) else it })
        }
    }

    // -----------------------------------------------------------------
    // Flash options
    // -----------------------------------------------------------------

    fun updateFlashOptions(options: FlashOptions) {
        _uiState.update { it.copy(flashOptions = options) }
    }

    // -----------------------------------------------------------------
    // Bottom action bar
    // -----------------------------------------------------------------

    fun detect() {
        runOperation {
            val info = flashManager.detectDevice(callback)
            applyChipDefaults(info)
            _uiState.update { it.copy(deviceInfo = info) }
        }
    }

    private fun applyChipDefaults(info: DeviceInfoSnapshot) {
        val bootloaderOffset = "0x%X".format(info.chip.bootloaderOffset)
        _uiState.update { it.copy(offsetText = it.offsetText + (ImageSlot.BOOTLOADER to bootloaderOffset)) }
    }

    fun erase() {
        runOperation { flashManager.eraseFlash(callback) }
    }

    fun flash() {
        val state = _uiState.value
        val images = buildImageList(state)
        if (images.isEmpty()) {
            appendLog(LogLevel.WARNING, "No files enabled - pick a file and make sure its checkbox is checked before flashing.")
            return
        }
        runOperation { flashManager.writeImages(images, state.flashOptions, state.uploadBaudRate, callback) }
    }

    fun verify() {
        val state = _uiState.value
        val images = buildImageList(state)
        if (images.isEmpty()) {
            appendLog(LogLevel.WARNING, "No files enabled - pick a file and make sure its checkbox is checked before verifying.")
            return
        }
        runOperation { flashManager.verifyImages(images, callback) }
    }

    fun readFlashToFile(destUri: Uri) {
        val state = _uiState.value
        val offset = parseAddress(state.advancedReadOffsetText)
        val length = parseAddress(state.advancedReadLengthText)
        if (offset == null || length == null) {
            appendLog(LogLevel.ERROR, "Invalid read offset/length.")
            return
        }
        runOperation { flashManager.readFlashToFile(offset, length, destUri, state.uploadBaudRate, callback) }
    }

    fun stop() {
        operationJob?.cancel()
        appendLog(LogLevel.WARNING, "Stop requested.")
        _uiState.update { it.copy(isBusy = false, progress = ProgressState.IDLE) }
    }

    private fun buildImageList(state: MainUiState): List<FlashImage> {
        val namedImages = state.files.mapNotNull { (slot, file) ->
            if (slot !in state.enabledSlots) return@mapNotNull null
            val offsetStr = state.offsetText[slot] ?: return@mapNotNull null
            val offset = parseAddress(offsetStr) ?: return@mapNotNull null
            FlashImage(slot.label, file.uri, file.fileName, offset, file.sizeBytes, slot.requiresImageMagic)
        }
        val customImages = state.customEntries.mapNotNull { entry ->
            if (!entry.enabled) return@mapNotNull null
            val offset = parseAddress(entry.offsetText) ?: return@mapNotNull null
            FlashImage(entry.fileName, entry.uri, entry.fileName, offset, 0L, requiresImageMagic = false)
        }
        return namedImages + customImages
    }

    // -----------------------------------------------------------------
    // Advanced panel
    // -----------------------------------------------------------------

    fun advancedRegAddressChanged(text: String) = _uiState.update { it.copy(advancedRegAddressText = text) }
    fun advancedRegValueChanged(text: String) = _uiState.update { it.copy(advancedRegValueText = text) }
    fun advancedReadOffsetChanged(text: String) = _uiState.update { it.copy(advancedReadOffsetText = text) }
    fun advancedReadLengthChanged(text: String) = _uiState.update { it.copy(advancedReadLengthText = text) }

    fun readRegister() {
        val addr = parseAddress(_uiState.value.advancedRegAddressText)
        if (addr == null) {
            appendLog(LogLevel.ERROR, "Invalid register address.")
            return
        }
        runOperation {
            val value = flashManager.readRegister(addr)
            _uiState.update { it.copy(advancedRegValueText = "0x%08X".format(value)) }
            appendLog(LogLevel.SUCCESS, "Read 0x%08X from 0x%08X".format(value, addr))
        }
    }

    fun writeRegister() {
        val state = _uiState.value
        val addr = parseAddress(state.advancedRegAddressText)
        val value = parseAddress(state.advancedRegValueText)
        if (addr == null || value == null) {
            appendLog(LogLevel.ERROR, "Invalid register address or value.")
            return
        }
        runOperation {
            flashManager.writeRegister(addr, value)
            appendLog(LogLevel.SUCCESS, "Wrote 0x%08X to 0x%08X".format(value, addr))
        }
    }

    // -----------------------------------------------------------------
    // Console
    // -----------------------------------------------------------------

    fun clearLog() {
        _uiState.update { it.copy(logs = emptyList()) }
    }

    fun saveLog(destUri: Uri) {
        viewModelScope.launch {
            val text = _uiState.value.logs.joinToString("\n") { formatLogLine(it) }
            runCatching {
                getApplication<Application>().contentResolver.openOutputStream(destUri)?.use {
                    it.write(text.toByteArray())
                }
            }.onSuccess {
                appendLog(LogLevel.SUCCESS, "Log saved.")
            }.onFailure {
                appendLog(LogLevel.ERROR, "Could not save log: ${it.message}")
            }
        }
    }

    fun logAsText(): String = _uiState.value.logs.joinToString("\n") { formatLogLine(it) }

    private fun formatLogLine(entry: LogEntry): String {
        val time = java.text.SimpleDateFormat("HH:mm:ss.SSS", java.util.Locale.US).format(java.util.Date(entry.timestampMs))
        return "[$time] [${entry.level}] ${entry.message}"
    }

    // -----------------------------------------------------------------
    // Internals
    // -----------------------------------------------------------------

    private var lastNotificationUpdateMs = 0L

    private val callback = object : FlashCallback {
        override fun onLog(level: LogLevel, message: String) = appendLog(level, message)
        override fun onProgress(progress: ProgressState) {
            _uiState.update { it.copy(progress = progress) }
            if (progress.isRunning) {
                val now = System.currentTimeMillis()
                if (now - lastNotificationUpdateMs > 500) {
                    lastNotificationUpdateMs = now
                    val status = if (progress.bytesTotal > 0) {
                        "${progress.operationLabel} - ${progress.percent}%"
                    } else {
                        progress.operationLabel
                    }
                    FlashForegroundService.updateStatus(getApplication(), status)
                }
            }
        }
    }

    private fun appendLog(level: LogLevel, message: String) {
        _uiState.update { state ->
            val updated = (state.logs + LogEntry(level, message))
            state.copy(logs = if (updated.size > MAX_LOG_LINES) updated.takeLast(MAX_LOG_LINES) else updated)
        }
    }

    private fun runOperation(setConnecting: Boolean = false, block: suspend () -> Unit) {
        if (_uiState.value.isBusy) {
            appendLog(LogLevel.WARNING, "Another operation is already running.")
            return
        }
        operationJob = viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true, lastError = null, connectionState = if (setConnecting) ConnectionState.CONNECTING else it.connectionState) }
            try {
                block()
            } catch (e: FlasherException) {
                appendLog(LogLevel.ERROR, e.message ?: "Unknown error")
                _uiState.update { it.copy(lastError = e.message) }
                if (setConnecting) _uiState.update { it.copy(connectionState = ConnectionState.DISCONNECTED) }
            } catch (e: kotlinx.coroutines.CancellationException) {
                appendLog(LogLevel.WARNING, "Operation cancelled.")
            } catch (e: Exception) {
                appendLog(LogLevel.ERROR, "Unexpected error: ${e.message}")
                _uiState.update { it.copy(lastError = e.message) }
            } finally {
                _uiState.update { it.copy(isBusy = false, progress = ProgressState.IDLE) }
                if (_uiState.value.isConnected) {
                    val label = flashManager.connectedDeviceInfo?.displayLabel ?: "device"
                    FlashForegroundService.updateStatus(getApplication(), "Connected to $label - idle")
                }
            }
        }
    }

    private fun parseAddress(text: String): Long? {
        val trimmed = text.trim()
        return try {
            if (trimmed.startsWith("0x", ignoreCase = true)) {
                trimmed.substring(2).toLong(16)
            } else {
                trimmed.toLong()
            }
        } catch (e: NumberFormatException) {
            null
        }
    }

    override fun onCleared() {
        super.onCleared()
        if (flashManager.isConnected) {
            viewModelScope.launch { runCatching { flashManager.disconnect(callback) } }
        }
        FlashForegroundService.stop(getApplication())
    }
}
