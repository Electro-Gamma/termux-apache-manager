# ESP Native Flasher (Android)

A native Android/Kotlin USB flashing tool for Espressif chips (ESP8266, ESP32,
ESP32-S2/S3/C3/C6/H2). It talks the ESP serial ROM-bootloader protocol
directly over the Android USB Host API - **no Python, no JNI/C, no bundled
esptool binary, no shelling out to any external tool.** Every USB-UART bridge
driver (CP210x, CH340/341, FTDI, PL2303, CDC-ACM) and the ESP protocol itself
(SLIP framing, SYNC, flash begin/data/end, MD5 verify, chip/flash
identification, ...) are implemented from scratch in Kotlin against publicly
documented hardware/protocol behaviour.

## Read this first: how this differs from esptool

This app deliberately runs in **ROM-only ("no-stub") mode all the time.**
esptool.py normally uploads a small second-stage program (Espressif's
precompiled "flasher stub") into chip RAM before doing real work, because the
permanent ROM bootloader is slower and, on most chips, can't read flash back
at all. That stub is Espressif's own compiled binary - bundling it here would
mean embedding third-party compiled code in the APK, which defeats the point
of a from-scratch reimplementation just as much as embedding esptool.py
itself would.

Running ROM-only instead of stub-only costs exactly one feature:

| Operation | ESP8266 | ESP32 | S2/S3/C3/C6/H2 |
|---|---|---|---|
| Sync / detect chip | ✅ | ✅ | ✅ |
| Read MAC / flash ID / flash size | ✅ | ✅ | ✅ |
| Erase (full chip) | ✅ | ✅ | ✅ |
| Write flash (raw or compressed) | ✅ | ✅ | ✅ |
| Verify (MD5) | stub-only* | ✅ | ✅ |
| **Read flash back / dump to file** | ❌ (needs stub) | ✅ | ❌ (needs stub) |

*ESP8266's ROM doesn't implement the `SPI_FLASH_MD5` opcode either - this is
a genuine ROM limitation, not something this app chose to skip. If you hit
it, the app will tell you exactly that instead of failing silently.

`ChipType`, `EspRomLoader`, and `StubLoader.kt` in the `protocol` package
document exactly which chip supports what and why - `StubLoader.kt`
specifically explains the extension point if you ever want to plug in your
own (separately-sourced) stub build.

## Project structure

```
app/src/main/java/io/espflasher/app/
├── protocol/         Transport-agnostic ESP serial protocol implementation
│   ├── SlipCodec.kt          SLIP framing (encode + incremental decode)
│   ├── EspCommand.kt         Wire-protocol opcodes / constants
│   ├── ChipType.kt           Per-chip register maps, magic values, offsets
│   ├── EspRomLoader.kt       The protocol engine: sync, flash, erase, MD5, SPI...
│   ├── SerialTransport.kt    Interface EspRomLoader talks to (no android.* deps)
│   ├── ResetSequences.kt     DTR/RTS bootloader-entry / reset timing
│   ├── Compressor.kt         zlib compression for FLASH_DEFL_*
│   ├── ImageHeader.kt        Parses the 8-byte ESP image header
│   ├── FlasherException.kt  Typed errors (sync failed, checksum mismatch, ...)
│   └── StubLoader.kt         No-stub-by-default rationale + extension point
│
├── usb/               Android USB Host API transport layer
│   ├── UsbSerialPort.kt       Interface + shared bulk-transfer buffering
│   ├── UsbSerialManager.kt    Enumeration, permission flow, driver factory
│   ├── SerialConfig.kt        Baud/data/stop/parity/flow-control model
│   └── drivers/                One file per bridge chip's control-transfer dialect
│       ├── CdcAcmSerialDriver.kt   (also covers native ESP32-S2/S3/C3/C6/H2 USB)
│       ├── Cp210xSerialDriver.kt
│       ├── Ch340SerialDriver.kt
│       ├── FtdiSerialDriver.kt
│       └── Pl2303SerialDriver.kt
│
├── flashing/          Business-logic orchestration (UI-agnostic)
│   ├── FlashOperationManager.kt  Connect/Detect/Erase/Flash/Verify/Read
│   ├── FlashImage.kt, FlashOptions.kt, ProgressState.kt, FlashCallback.kt
│
├── data/               Persistence
│   ├── SettingsRepository.kt      DataStore-backed app settings
│   └── RecentFilesRepository.kt   Remembered SAF file URIs + offsets
│
├── ui/                 MVVM presentation layer
│   ├── MainActivity.kt / MainViewModel.kt / MainUiState.kt
│   ├── SettingsActivity.kt / SettingsViewModel.kt
│   └── LogAdapter.kt
│
└── util/BinaryUtils.kt  Little-endian pack/unpack helpers
```

Each layer only depends on the one below it (`ui` → `flashing` → `usb`
and `protocol`; `protocol` never imports `android.hardware.usb.*`), so the
protocol engine is unit-testable against a fake `SerialTransport` without
touching real USB hardware.

## Flashing workflow (what actually happens when you tap a button)

1. **Connect** - opens the USB device, requests runtime permission if
   needed, claims the interface, and configures the UART (baud/data/stop/
   parity/flow-control) via the chip-specific driver. No chip communication
   yet.
2. **Detect** - drives the DTR/RTS auto-reset circuit into the download
   bootloader (`ResetSequences.enterBootloader`), sends `SYNC` until the ROM
   answers, reads the chip-detect magic register (or, on chips without one,
   the `GET_SECURITY_INFO` chip ID), attaches the SPI flash controller
   (`SPI_ATTACH`), then reads the MAC address, flash JEDEC ID, and security/
   flash-encryption status - all via generic `READ_REG`/`WRITE_REG` calls
   the ROM already exposes, no stub required.
3. **Flash** - for each selected file (sorted by offset): reads the bytes,
   sanity-checks the image magic byte where relevant, optionally zlib-
   compresses it, then streams it in via `FLASH_BEGIN`/`FLASH_DATA`/
   `FLASH_END` (or the `_DEFL_` compressed variants). The ROM erases exactly
   the sectors it's about to overwrite as part of `FLASH_BEGIN` - that's also
   how whole-chip **Erase** works (one `FLASH_BEGIN` covering the full
   detected flash size, no data written, then `FLASH_END`).
4. **Verify** - re-reads each file's bytes, computes a local MD5, and
   compares it against the chip's own `SPI_FLASH_MD5` response for that
   region.
5. **Read** - only offered when the detected chip is classic ESP32 (see the
   table above); streams 64-byte blocks via the ROM's `READ_FLASH_SLOW`
   opcode into a file you pick via SAF.
6. **Stop** cancels the underlying coroutine; block-write loops check for
   cancellation every block so it takes effect almost immediately during the
   bulk of a transfer.

## Building

### Android Studio
Open the project root in Android Studio (Giraffe or newer), let Gradle sync
pull the AndroidX/Material/Coroutines/DataStore dependencies (all from
Google's and Maven Central's public repos - nothing exotic), and run the
`app` configuration. Min SDK 26, target/compile SDK 35, Kotlin 1.9.24,
AGP 8.5.2, Gradle 8.7.

### Google Colab (no PC required)
`Build_ESP_Native_Flasher.ipynb` in the project root mirrors the toolchain
setup from this repo's companion TCP_UART_Bridge build notebook: it installs
a JDK 17 + Android cmdline-tools + platform 35 + build-tools 35.0.0 + Gradle
8.7 environment in the Colab VM, zips up this project (or pulls it from a
Drive/Git location you point it at), runs `gradle assembleDebug`, and hands
back a downloadable `app-debug.apk`.

## Known limitations / honest caveats

- **PL2303 vendor init sequence**: PL2303's line-coding (baud/parity/stop/
  data) requests are the same CDC-style requests as CDC-ACM and are solid;
  the vendor-specific register-poke sequence some PL2303 revisions expect at
  open time is not publicly documented by Prolific and varies by silicon
  revision (H/HX/TA/TB). `Pl2303SerialDriver.runVendorInitSequence()` uses
  the commonly-published "type 0/HX" sequence and is wrapped so a failure
  there doesn't block the rest of `open()`. If your specific adapter needs
  different magic values, that's the one function to adjust.
- **CH340 pre-0x30 silicon**: only reconfigures the baud divisor; data/
  parity/stop bits stay at the hardware default (8N1). This mirrors a real
  limitation of that silicon generation, not a shortcut this app took.
- **Crystal frequency** is reported as the chip's nominal design value
  (40 MHz for essentially every modern dev board), not measured - a true
  measurement needs a timing trick this build doesn't implement.
- **Chip revision** isn't read back; the per-chip efuse bit layout for
  silicon revision differs enough across the seven supported chips that it
  wasn't worth the risk of reporting a wrong number. The field says so
  explicitly rather than guessing.
- **Flash mode/frequency** shown on the Information page comes from parsing
  the selected firmware file's own 8-byte image header (a documented,
  stable on-flash format), not from asking the chip - flash mode is a
  property of how an image was built, not something the hardware reports.
- File reads for flashing/verifying currently buffer the whole file in
  memory via `ContentResolver`, which is fine for typical firmware sizes
  (well under available RAM) but isn't a streaming implementation.

## License / provenance note

Every protocol constant here (opcodes, magic values, register addresses)
reflects publicly documented hardware/firmware behaviour - the same facts
independent reimplementations like Espressif's own `esptool-js` are built
from. The code expressing those facts is original Kotlin written for this
project; no esptool source is included, linked, or executed.
