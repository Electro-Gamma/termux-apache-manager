// Top-level build file. Individual module build files declare their own
// plugin versions against these shared plugin ids.
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
