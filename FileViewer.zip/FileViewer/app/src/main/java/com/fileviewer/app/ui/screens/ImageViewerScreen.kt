package com.fileviewer.app.ui.screens

import android.graphics.drawable.Drawable
import android.widget.ImageView
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.fileviewer.app.ui.components.ActionChip
import com.fileviewer.app.ui.components.ActionChipRow
import com.fileviewer.app.ui.components.ZoomState
import com.fileviewer.app.ui.components.ZoomableBox
import com.fileviewer.app.ui.components.rememberZoomState

/**
 * Displays a decoded raster image (including animated GIF/WebP via [ImageView] +
 * [Drawable.setImageDrawable], which natively animates an AnimatedImageDrawable).
 * Zoom/pan/double-tap/rotate are handled by [ZoomableBox]; "fit to screen" vs
 * "actual size" is a scale-type toggle on the underlying ImageView itself, so the
 * zoom gesture always composes on top of whichever base scale is selected.
 */
@Composable
fun ImageViewerScreen(
    drawable: Drawable,
    rotationDegrees: Float,
    onRotate: () -> Unit,
    zoomState: ZoomState = rememberZoomState()
) {
    var actualSize by remember { mutableStateOf(false) }

    LaunchedEffect(rotationDegrees) {
        zoomState.rotationDegrees = rotationDegrees
    }

    Column(modifier = Modifier.fillMaxSize()) {
        ActionChipRow {
            ActionChip(label = if (actualSize) "Fit to screen" else "Actual size") {
                actualSize = !actualSize
            }
            ActionChip(label = "Rotate", onClick = onRotate)
            ActionChip(label = "Reset zoom", onClick = { zoomState.resetZoom() })
        }
        Surface(modifier = Modifier.fillMaxSize()) {
            ZoomableBox(state = zoomState, modifier = Modifier.fillMaxSize()) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { context ->
                        ImageView(context).apply {
                            scaleType = if (actualSize) ImageView.ScaleType.CENTER else ImageView.ScaleType.FIT_CENTER
                            adjustViewBounds = true
                        }
                    },
                    update = { view ->
                        view.setImageDrawable(drawable)
                        view.scaleType = if (actualSize) ImageView.ScaleType.CENTER else ImageView.ScaleType.FIT_CENTER
                    }
                )
            }
        }
    }
}
