package com.fileviewer.app.reader

import android.graphics.Bitmap
import android.graphics.Color

/**
 * Hand-rolled decoder for the Netpbm family (PBM/PGM/PPM, magic numbers P1-P6).
 * Android has no built-in support for these formats, and they're simple enough
 * (a short whitespace/comment-delimited header followed by ASCII or raw binary
 * samples) that a small direct implementation is preferable to a dependency.
 */
object NetpbmDecoder {

    fun decode(bytes: ByteArray): Bitmap? {
        if (bytes.size < 2 || bytes[0] != 'P'.code.toByte()) return null
        val kind = bytes[1].toInt().toChar()
        if (kind !in '1'..'6') return null

        var pos = 2

        fun skipWhitespaceAndComments() {
            while (pos < bytes.size) {
                val c = bytes[pos].toInt().toChar()
                when {
                    c == '#' -> while (pos < bytes.size && bytes[pos].toInt().toChar() != '\n') pos++
                    c.isWhitespace() -> pos++
                    else -> return
                }
            }
        }

        fun readInt(): Int {
            skipWhitespaceAndComments()
            val start = pos
            while (pos < bytes.size && bytes[pos].toInt().toChar().isDigit()) pos++
            if (pos == start) throw IllegalArgumentException("Malformed Netpbm header")
            return String(bytes, start, pos - start, Charsets.US_ASCII).toInt()
        }

        return try {
            val width = readInt()
            val height = readInt()
            if (width <= 0 || height <= 0 || width.toLong() * height.toLong() > 64_000_000L) return null

            val maxVal = if (kind == '1' || kind == '4') 1 else readInt()
            if (kind in charArrayOf('4', '5', '6')) {
                pos++ // exactly one whitespace byte separates header from binary data
            }

            val pixels = IntArray(width * height)

            fun nextAsciiToken(): Int {
                skipWhitespaceAndComments()
                val start = pos
                while (pos < bytes.size && !bytes[pos].toInt().toChar().isWhitespace()) pos++
                return String(bytes, start, pos - start, Charsets.US_ASCII).trim().toIntOrNull() ?: 0
            }

            when (kind) {
                '1' -> for (i in 0 until width * height) {
                    pixels[i] = if (nextAsciiToken() == 0) Color.WHITE else Color.BLACK
                }
                '2' -> for (i in 0 until width * height) {
                    val gray = (nextAsciiToken() * 255 / maxVal).coerceIn(0, 255)
                    pixels[i] = Color.rgb(gray, gray, gray)
                }
                '3' -> for (i in 0 until width * height) {
                    val r = (nextAsciiToken() * 255 / maxVal).coerceIn(0, 255)
                    val g = (nextAsciiToken() * 255 / maxVal).coerceIn(0, 255)
                    val b = (nextAsciiToken() * 255 / maxVal).coerceIn(0, 255)
                    pixels[i] = Color.rgb(r, g, b)
                }
                '4' -> { // 1 bit/pixel, MSB first, rows padded to a byte boundary
                    var bitPos = pos
                    for (y in 0 until height) {
                        var bitInByte = 0
                        var currentByte = bytes.getOrElse(bitPos) { 0 }.toInt() and 0xFF
                        for (x in 0 until width) {
                            if (bitInByte == 8) {
                                bitPos++
                                currentByte = bytes.getOrElse(bitPos) { 0 }.toInt() and 0xFF
                                bitInByte = 0
                            }
                            val bit = (currentByte shr (7 - bitInByte)) and 1
                            pixels[y * width + x] = if (bit == 1) Color.BLACK else Color.WHITE
                            bitInByte++
                        }
                        bitPos++
                    }
                }
                '5' -> { // 1 or 2 bytes/sample depending on maxVal
                    val twoBytes = maxVal > 255
                    var p = pos
                    for (i in 0 until width * height) {
                        val v = if (twoBytes) {
                            val hi = bytes.getOrElse(p) { 0 }.toInt() and 0xFF
                            val lo = bytes.getOrElse(p + 1) { 0 }.toInt() and 0xFF
                            p += 2
                            (hi shl 8) or lo
                        } else {
                            val g = bytes.getOrElse(p) { 0 }.toInt() and 0xFF
                            p += 1
                            g
                        }
                        val gray = (v * 255 / maxVal).coerceIn(0, 255)
                        pixels[i] = Color.rgb(gray, gray, gray)
                    }
                }
                '6' -> {
                    val twoBytes = maxVal > 255
                    var p = pos
                    fun nextSample(): Int = if (twoBytes) {
                        val hi = bytes.getOrElse(p) { 0 }.toInt() and 0xFF
                        val lo = bytes.getOrElse(p + 1) { 0 }.toInt() and 0xFF
                        p += 2
                        (hi shl 8) or lo
                    } else {
                        val v = bytes.getOrElse(p) { 0 }.toInt() and 0xFF
                        p += 1
                        v
                    }
                    for (i in 0 until width * height) {
                        val r = (nextSample() * 255 / maxVal).coerceIn(0, 255)
                        val g = (nextSample() * 255 / maxVal).coerceIn(0, 255)
                        val b = (nextSample() * 255 / maxVal).coerceIn(0, 255)
                        pixels[i] = Color.rgb(r, g, b)
                    }
                }
            }

            Bitmap.createBitmap(pixels, width, height, Bitmap.Config.ARGB_8888)
        } catch (e: Exception) {
            null
        }
    }
}
