package com.fileviewer.app.model

import android.net.Uri

data class OpenedFile(
    val uri: Uri,
    val displayName: String,
    val mimeType: String?,
    val sizeBytes: Long,
    val lastModifiedMillis: Long?
)

data class FileMetadata(
    val file: OpenedFile,
    val typeLabel: String,
    val encodingLabel: String? = null,
    val imageWidth: Int? = null,
    val imageHeight: Int? = null,
    val language: String? = null,
    val lineCount: Int? = null,
    val charCount: Int? = null
)
