package com.fileviewer.app.markdown

import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import com.fileviewer.app.detection.LanguageSpec
import com.fileviewer.app.highlight.LanguageDefinitions
import com.fileviewer.app.highlight.SpannableHighlight

/**
 * Adds syntax-highlight color spans to fenced code blocks inside an already-rendered
 * Markwon [Spanned].
 *
 * Design note: rather than hooking into Markwon's internal node-visitor pipeline (which
 * would tie this code to Markwon's non-public rendering internals), this walks the raw
 * markdown source with a small fence scanner to find each fenced block's language tag and
 * literal code text, then locates that same literal text inside the final rendered output
 * and layers additional [ForegroundColorSpan]s on top — leaving every span Markwon itself
 * added (background, monospace typeface, margins) completely untouched. This only depends
 * on stable, public Android text APIs.
 *
 * Scope: only *fenced* code blocks (``` or ~~~) with a language tag are highlighted here —
 * this covers the vast majority of real-world markdown. Four-space-indented code blocks
 * still render with Markwon's normal code-block styling, just without added color, since
 * reliably locating them via line-scanning (vs. list-item indentation, etc.) needs a real
 * CommonMark parse.
 */
object MarkdownCodeHighlighter {

    private data class FencedBlock(val lang: String?, val code: String)

    private val LANG_ALIASES = mapOf(
        "js" to "js", "javascript" to "js", "jsx" to "jsx",
        "ts" to "ts", "typescript" to "ts", "tsx" to "tsx",
        "py" to "py", "python" to "py", "python3" to "py",
        "sh" to "sh", "shell" to "sh", "bash" to "sh", "zsh" to "sh", "console" to "sh",
        "yml" to "yml", "yaml" to "yaml",
        "kt" to "kt", "kotlin" to "kt",
        "c++" to "cpp", "cpp" to "cpp", "cc" to "cpp",
        "cs" to "cs", "csharp" to "cs", "c#" to "cs",
        "html" to "html", "xml" to "xml", "json" to "json", "sql" to "sql",
        "dockerfile" to "dockerfile", "docker" to "dockerfile",
        "makefile" to "makefile", "make" to "makefile",
        "gradle" to "gradle", "rust" to "rs", "rs" to "rs",
        "go" to "go", "golang" to "go", "php" to "php", "java" to "java",
        "css" to "css", "scss" to "scss", "toml" to "toml", "ini" to "ini",
        "md" to "md", "markdown" to "md", "arduino" to "ino"
    )

    private fun resolveLanguage(info: String?): LanguageSpec? {
        if (info.isNullOrBlank()) return null
        val mappedExt = LANG_ALIASES[info.lowercase()] ?: info.lowercase()
        return LanguageDefinitions.forFile("f.$mappedExt")
    }

    private fun extractFencedCodeBlocks(markdown: String): List<FencedBlock> {
        val lines = markdown.split("\n")
        val blocks = mutableListOf<FencedBlock>()
        var i = 0
        while (i < lines.size) {
            val line = lines[i]
            val trimmed = line.trimStart()
            val indent = line.length - trimmed.length
            if (indent <= 3 && (trimmed.startsWith("```") || trimmed.startsWith("~~~"))) {
                val fenceChar = trimmed[0]
                var fenceLen = 0
                while (fenceLen < trimmed.length && trimmed[fenceLen] == fenceChar) fenceLen++
                val infoString = trimmed.substring(fenceLen).trim()
                val lang = infoString.split(Regex("\\s+")).firstOrNull()?.takeIf { it.isNotBlank() }

                val codeLines = mutableListOf<String>()
                var j = i + 1
                while (j < lines.size) {
                    val closingTrimmed = lines[j].trimStart()
                    val closingIndent = lines[j].length - closingTrimmed.length
                    var k = 0
                    while (k < closingTrimmed.length && closingTrimmed[k] == fenceChar) k++
                    val isClosingFence = closingIndent <= 3 && k == closingTrimmed.length && k >= fenceLen && k > 0
                    if (isClosingFence) {
                        j++
                        break
                    }
                    codeLines.add(lines[j])
                    j++
                }
                blocks.add(FencedBlock(lang, codeLines.joinToString("\n")))
                i = j
            } else {
                i++
            }
        }
        return blocks
    }

    fun apply(rendered: Spanned, rawMarkdown: String, colors: SpannableHighlight.SpanColors): Spanned {
        val blocks = extractFencedCodeBlocks(rawMarkdown).filter { it.code.isNotEmpty() }
        if (blocks.isEmpty()) return rendered

        val builder = SpannableStringBuilder(rendered)
        val fullText = builder.toString()
        var searchFrom = 0

        for (block in blocks) {
            val idx = fullText.indexOf(block.code, searchFrom)
            if (idx == -1) continue // rendering may have normalized whitespace; skip this block gracefully

            val lang = resolveLanguage(block.lang)
            if (lang != null) {
                val highlighted = SpannableHighlight.highlight(block.code, lang, colors)
                if (highlighted is Spanned) {
                    for (span in highlighted.getSpans(0, highlighted.length, ForegroundColorSpan::class.java)) {
                        val start = highlighted.getSpanStart(span)
                        val end = highlighted.getSpanEnd(span)
                        if (start in 0..highlighted.length && end in start..highlighted.length) {
                            builder.setSpan(
                                ForegroundColorSpan(span.foregroundColor),
                                idx + start, idx + end,
                                Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
                            )
                        }
                    }
                }
            }
            searchFrom = idx + block.code.length
        }

        return builder
    }
}
