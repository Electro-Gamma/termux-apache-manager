package com.fileviewer.app.detection

import java.nio.ByteBuffer
import java.nio.charset.CodingErrorAction

enum class DetectedEncoding(val label: String, val charsetName: String, val bomLength: Int) {
    UTF8_BOM("UTF-8 (BOM)", "UTF-8", 3),
    UTF16LE_BOM("UTF-16LE (BOM)", "UTF-16LE", 2),
    UTF16BE_BOM("UTF-16BE (BOM)", "UTF-16BE", 2),
    UTF8_NO_BOM("UTF-8", "UTF-8", 0),
    LATIN1_FALLBACK("ISO-8859-1 (fallback)", "ISO-8859-1", 0)
}

/**
 * Detects a BOM when present (UTF-8 / UTF-16LE / UTF-16BE, per spec), and otherwise
 * prefers strict UTF-8 with a safe ISO-8859-1 fallback so a decode failure can never
 * crash the viewer or corrupt what gets displayed. The original file bytes are never
 * touched — this only governs what string is shown.
 */
object EncodingDetector {

    fun detectBom(header: ByteArray): DetectedEncoding? {
        if (header.size >= 3 && header[0] == 0xEF.toByte() && header[1] == 0xBB.toByte() && header[2] == 0xBF.toByte()) {
            return DetectedEncoding.UTF8_BOM
        }
        // Check the 2-byte UTF-16 BOMs only when they are NOT actually the start of the longer
        // UTF-8 BOM sequence checked above (already excluded by the branch order).
        if (header.size >= 2 && header[0] == 0xFF.toByte() && header[1] == 0xFE.toByte()) {
            return DetectedEncoding.UTF16LE_BOM
        }
        if (header.size >= 2 && header[0] == 0xFE.toByte() && header[1] == 0xFF.toByte()) {
            return DetectedEncoding.UTF16BE_BOM
        }
        return null
    }

    fun decode(bytes: ByteArray): Pair<String, DetectedEncoding> {
        detectBom(bytes)?.let { bom ->
            val text = runCatching {
                String(bytes, bom.bomLength, bytes.size - bom.bomLength, charset(bom.charsetName))
            }.getOrElse { String(bytes, Charsets.ISO_8859_1) }
            return text to bom
        }

        val strictUtf8 = Charsets.UTF_8.newDecoder()
            .onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT)

        return try {
            strictUtf8.decode(ByteBuffer.wrap(bytes)).toString() to DetectedEncoding.UTF8_NO_BOM
        } catch (e: Exception) {
            String(bytes, Charsets.ISO_8859_1) to DetectedEncoding.LATIN1_FALLBACK
        }
    }
}
