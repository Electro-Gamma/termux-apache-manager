package com.fileviewer.app.highlight

import com.fileviewer.app.detection.LanguageSpec

/**
 * Data-driven language table used by both the standalone source-code viewer and
 * the syntax-highlighted code blocks inside rendered Markdown.
 *
 * This is a lightweight, regex/keyword-based highlighter (see SyntaxHighlighter.kt) —
 * not a full grammar/AST-based engine. That is a deliberate trade-off: it keeps the
 * app free of a heavy external highlighting engine or WebView-based renderer, at the
 * cost of perfect fidelity on deeply nested or unusual syntax. Keywords/comments/
 * strings/numbers are still highlighted correctly for normal code.
 */
object LanguageDefinitions {

    val KOTLIN = LanguageSpec(
        displayName = "Kotlin",
        extensions = listOf("kt", "kts"),
        lineComment = listOf("//"),
        blockCommentStart = "/*", blockCommentEnd = "*/",
        supportsTripleQuoteStrings = true,
        keywords = setOf(
            "as", "break", "class", "continue", "do", "else", "false", "for", "fun", "if",
            "in", "interface", "is", "null", "object", "package", "return", "super", "this",
            "throw", "true", "try", "typealias", "val", "var", "when", "while", "by", "catch",
            "constructor", "delegate", "dynamic", "field", "file", "finally", "get", "import",
            "init", "param", "property", "receiver", "set", "setparam", "where", "actual",
            "abstract", "annotation", "companion", "const", "crossinline", "data", "enum",
            "expect", "external", "final", "infix", "inline", "inner", "internal", "lateinit",
            "noinline", "open", "operator", "out", "override", "private", "protected", "public",
            "reified", "sealed", "suspend", "tailrec", "vararg"
        ),
        types = setOf("Int", "Long", "Short", "Byte", "Float", "Double", "Boolean", "Char", "String", "Unit", "Any", "Nothing", "Array", "List", "Map", "Set")
    )

    val JAVA = LanguageSpec(
        displayName = "Java",
        extensions = listOf("java"),
        lineComment = listOf("//"),
        blockCommentStart = "/*", blockCommentEnd = "*/",
        keywords = setOf(
            "abstract", "assert", "boolean", "break", "byte", "case", "catch", "char", "class",
            "const", "continue", "default", "do", "double", "else", "enum", "extends", "final",
            "finally", "float", "for", "goto", "if", "implements", "import", "instanceof", "int",
            "interface", "long", "native", "new", "package", "private", "protected", "public",
            "return", "short", "static", "strictfp", "super", "switch", "synchronized", "this",
            "throw", "throws", "transient", "try", "void", "volatile", "while", "true", "false", "null", "var", "record", "yield", "sealed", "permits"
        ),
        types = setOf("String", "Integer", "Long", "Double", "Float", "Boolean", "Character", "Object", "List", "Map", "Set")
    )

    val JAVASCRIPT = LanguageSpec(
        displayName = "JavaScript",
        extensions = listOf("js", "mjs", "cjs", "jsx"),
        lineComment = listOf("//"),
        blockCommentStart = "/*", blockCommentEnd = "*/",
        supportsTripleQuoteStrings = false,
        stringDelimiters = listOf('"', '\'', '`'),
        keywords = setOf(
            "break", "case", "catch", "class", "const", "continue", "debugger", "default",
            "delete", "do", "else", "export", "extends", "finally", "for", "function", "if",
            "import", "in", "instanceof", "let", "new", "return", "super", "switch", "this",
            "throw", "try", "typeof", "var", "void", "while", "with", "yield", "async", "await",
            "static", "get", "set", "of", "true", "false", "null", "undefined"
        )
    )

    val TYPESCRIPT = JAVASCRIPT.copy(
        displayName = "TypeScript",
        extensions = listOf("ts", "tsx"),
        keywords = JAVASCRIPT.keywords + setOf(
            "interface", "type", "enum", "namespace", "declare", "implements", "private",
            "protected", "public", "readonly", "abstract", "as", "is", "keyof", "infer", "satisfies"
        ),
        types = setOf("string", "number", "boolean", "any", "unknown", "never", "void", "object", "Array", "Record", "Partial")
    )

    val PYTHON = LanguageSpec(
        displayName = "Python",
        extensions = listOf("py", "pyw", "pyi"),
        lineComment = listOf("#"),
        supportsTripleQuoteStrings = true,
        keywords = setOf(
            "and", "as", "assert", "async", "await", "break", "class", "continue", "def", "del",
            "elif", "else", "except", "finally", "for", "from", "global", "if", "import", "in",
            "is", "lambda", "nonlocal", "not", "or", "pass", "raise", "return", "try", "while",
            "with", "yield", "True", "False", "None", "self", "match", "case"
        ),
        types = setOf("int", "str", "float", "bool", "list", "dict", "tuple", "set", "bytes", "object")
    )

    val C = LanguageSpec(
        displayName = "C",
        extensions = listOf("c", "h"),
        lineComment = listOf("//"),
        blockCommentStart = "/*", blockCommentEnd = "*/",
        keywords = setOf(
            "auto", "break", "case", "char", "const", "continue", "default", "do", "double",
            "else", "enum", "extern", "float", "for", "goto", "if", "int", "long", "register",
            "return", "short", "signed", "sizeof", "static", "struct", "switch", "typedef",
            "union", "unsigned", "void", "volatile", "while", "NULL", "include", "define",
            "ifdef", "ifndef", "endif", "pragma"
        )
    )

    val CPP = C.copy(
        displayName = "C++",
        extensions = listOf("cpp", "cc", "cxx", "hpp", "hh", "hxx"),
        keywords = C.keywords + setOf(
            "class", "namespace", "template", "typename", "public", "private", "protected",
            "virtual", "override", "new", "delete", "this", "friend", "using", "try", "catch",
            "throw", "true", "false", "nullptr", "constexpr", "noexcept", "explicit", "operator",
            "inline", "mutable", "auto", "decltype", "static_cast", "dynamic_cast", "const_cast", "reinterpret_cast"
        ),
        types = setOf("std", "string", "vector", "map", "set", "pair", "unique_ptr", "shared_ptr", "bool")
    )

    val CSHARP = LanguageSpec(
        displayName = "C#",
        extensions = listOf("cs"),
        lineComment = listOf("//"),
        blockCommentStart = "/*", blockCommentEnd = "*/",
        keywords = setOf(
            "abstract", "as", "base", "bool", "break", "byte", "case", "catch", "char", "checked",
            "class", "const", "continue", "decimal", "default", "delegate", "do", "double", "else",
            "enum", "event", "explicit", "extern", "false", "finally", "fixed", "float", "for",
            "foreach", "goto", "if", "implicit", "in", "int", "interface", "internal", "is", "lock",
            "long", "namespace", "new", "null", "object", "operator", "out", "override", "params",
            "private", "protected", "public", "readonly", "ref", "return", "sbyte", "sealed",
            "short", "sizeof", "stackalloc", "static", "string", "struct", "switch", "this",
            "throw", "true", "try", "typeof", "uint", "ulong", "unchecked", "unsafe", "ushort",
            "using", "var", "virtual", "void", "volatile", "while", "async", "await", "get", "set", "record"
        )
    )

    val RUST = LanguageSpec(
        displayName = "Rust",
        extensions = listOf("rs"),
        lineComment = listOf("//"),
        blockCommentStart = "/*", blockCommentEnd = "*/",
        keywords = setOf(
            "as", "break", "const", "continue", "crate", "dyn", "else", "enum", "extern", "false",
            "fn", "for", "if", "impl", "in", "let", "loop", "match", "mod", "move", "mut", "pub",
            "ref", "return", "self", "Self", "static", "struct", "super", "trait", "true", "type",
            "unsafe", "use", "where", "while", "async", "await", "async", "yield"
        ),
        types = setOf("i8", "i16", "i32", "i64", "isize", "u8", "u16", "u32", "u64", "usize", "f32", "f64", "bool", "char", "str", "String", "Vec", "Option", "Result", "Box")
    )

    val GO = LanguageSpec(
        displayName = "Go",
        extensions = listOf("go"),
        lineComment = listOf("//"),
        blockCommentStart = "/*", blockCommentEnd = "*/",
        keywords = setOf(
            "break", "case", "chan", "const", "continue", "default", "defer", "else", "fallthrough",
            "for", "func", "go", "goto", "if", "import", "interface", "map", "package", "range",
            "return", "select", "struct", "switch", "type", "var", "true", "false", "nil", "iota"
        ),
        types = setOf("string", "int", "int8", "int16", "int32", "int64", "uint", "byte", "rune", "float32", "float64", "bool", "error")
    )

    val PHP = LanguageSpec(
        displayName = "PHP",
        extensions = listOf("php", "phtml"),
        lineComment = listOf("//", "#"),
        blockCommentStart = "/*", blockCommentEnd = "*/",
        keywords = setOf(
            "abstract", "and", "array", "as", "break", "callable", "case", "catch", "class",
            "clone", "const", "continue", "declare", "default", "do", "echo", "else", "elseif",
            "empty", "enddeclare", "endfor", "endforeach", "endif", "endswitch", "endwhile",
            "extends", "final", "finally", "fn", "for", "foreach", "function", "global", "goto",
            "if", "implements", "include", "include_once", "instanceof", "insteadof", "interface",
            "isset", "list", "match", "namespace", "new", "or", "print", "private", "protected",
            "public", "readonly", "require", "require_once", "return", "static", "switch", "throw",
            "trait", "try", "unset", "use", "var", "while", "xor", "yield", "true", "false", "null"
        )
    )

    val HTML = LanguageSpec(
        displayName = "HTML",
        extensions = listOf("html", "htm", "xhtml"),
        blockCommentStart = "<!--", blockCommentEnd = "-->",
        keywords = emptySet()
    )

    val CSS = LanguageSpec(
        displayName = "CSS",
        extensions = listOf("css", "scss", "sass", "less"),
        blockCommentStart = "/*", blockCommentEnd = "*/",
        keywords = setOf(
            "important", "media", "import", "charset", "font-face", "keyframes", "supports",
            "from", "to", "and", "or", "not", "hover", "active", "focus", "before", "after"
        )
    )

    val XML = LanguageSpec(
        displayName = "XML",
        extensions = listOf("xml", "xsd", "xsl", "svg", "plist", "manifest"),
        blockCommentStart = "<!--", blockCommentEnd = "-->",
        keywords = emptySet()
    )

    val JSON = LanguageSpec(
        displayName = "JSON",
        extensions = listOf("json", "jsonc", "geojson", "webmanifest"),
        keywords = setOf("true", "false", "null")
    )

    val YAML = LanguageSpec(
        displayName = "YAML",
        extensions = listOf("yaml", "yml"),
        lineComment = listOf("#"),
        keywords = setOf("true", "false", "null", "yes", "no", "on", "off")
    )

    val BASH = LanguageSpec(
        displayName = "Bash / Shell",
        extensions = listOf("sh", "bash", "zsh", "ksh", "bashrc", "zshrc", "profile"),
        lineComment = listOf("#"),
        keywords = setOf(
            "if", "then", "else", "elif", "fi", "for", "while", "until", "do", "done", "case",
            "esac", "function", "return", "exit", "export", "local", "readonly", "shift", "in",
            "select", "time", "coproc", "echo", "printf", "read", "set", "unset", "source", "trap"
        )
    )

    val SQL = LanguageSpec(
        displayName = "SQL",
        extensions = listOf("sql"),
        lineComment = listOf("--"),
        blockCommentStart = "/*", blockCommentEnd = "*/",
        keywords = setOf(
            "select", "insert", "update", "delete", "from", "where", "join", "inner", "outer",
            "left", "right", "full", "on", "group", "by", "order", "having", "limit", "offset",
            "as", "and", "or", "not", "null", "is", "in", "between", "like", "exists", "union",
            "all", "distinct", "create", "table", "alter", "drop", "index", "view", "into",
            "values", "set", "default", "primary", "key", "foreign", "references", "constraint",
            "cascade", "begin", "commit", "rollback", "transaction", "case", "when", "then", "end"
        )
    )

    val ARDUINO = CPP.copy(
        displayName = "Arduino",
        extensions = listOf("ino", "pde"),
        keywords = CPP.keywords + setOf(
            "setup", "loop", "pinMode", "digitalWrite", "digitalRead", "analogRead", "analogWrite",
            "delay", "delayMicroseconds", "millis", "micros", "Serial", "HIGH", "LOW", "INPUT",
            "OUTPUT", "INPUT_PULLUP", "attachInterrupt"
        )
    )

    val MARKDOWN = LanguageSpec(
        displayName = "Markdown",
        extensions = listOf("md", "markdown", "mdown", "mkd")
    )

    val INI = LanguageSpec(
        displayName = "INI",
        extensions = listOf("ini", "cfg", "conf", "properties", "env"),
        lineComment = listOf(";", "#")
    )

    val TOML = LanguageSpec(
        displayName = "TOML",
        extensions = listOf("toml"),
        lineComment = listOf("#"),
        keywords = setOf("true", "false")
    )

    val GRADLE = LanguageSpec(
        displayName = "Gradle",
        extensions = listOf("gradle"),
        lineComment = listOf("//"),
        blockCommentStart = "/*", blockCommentEnd = "*/",
        keywords = setOf(
            "plugins", "dependencies", "repositories", "android", "apply", "implementation",
            "api", "testImplementation", "androidTestImplementation", "id", "version", "kotlin",
            "sourceSets", "buildTypes", "defaultConfig", "compileSdk", "minSdk", "targetSdk", "task", "def", "ext"
        )
    )

    val DOCKERFILE = LanguageSpec(
        displayName = "Dockerfile",
        extensions = listOf("dockerfile"),
        lineComment = listOf("#"),
        keywords = setOf(
            "FROM", "RUN", "CMD", "LABEL", "EXPOSE", "ENV", "ADD", "COPY", "ENTRYPOINT", "VOLUME",
            "USER", "WORKDIR", "ARG", "ONBUILD", "STOPSIGNAL", "HEALTHCHECK", "SHELL", "AS"
        )
    )

    val MAKEFILE = LanguageSpec(
        displayName = "Makefile",
        extensions = listOf("makefile", "mk"),
        lineComment = listOf("#"),
        keywords = setOf("ifeq", "ifneq", "ifdef", "ifndef", "else", "endif", "include", "export", "define", "endef", ".PHONY")
    )

    /** Every known language, used to build the extension lookup below. */
    val ALL: List<LanguageSpec> = listOf(
        KOTLIN, JAVA, JAVASCRIPT, TYPESCRIPT, PYTHON, C, CPP, CSHARP, RUST, GO, PHP, HTML, CSS,
        XML, JSON, YAML, BASH, SQL, ARDUINO, MARKDOWN, INI, TOML, GRADLE, DOCKERFILE, MAKEFILE
    )

    private val byExtension: Map<String, LanguageSpec> = buildMap {
        for (lang in ALL) {
            for (ext in lang.extensions) {
                put(ext.lowercase(), lang)
            }
        }
    }

    /** Special-cased exact (lowercased) file names for extension-less config files. */
    private val byFileName: Map<String, LanguageSpec> = mapOf(
        "dockerfile" to DOCKERFILE,
        "makefile" to MAKEFILE,
        "gnumakefile" to MAKEFILE,
        ".gitignore" to INI,
        ".env" to INI
    )

    fun forFile(fileName: String): LanguageSpec? {
        val lower = fileName.lowercase()
        byFileName[lower]?.let { return it }
        val ext = lower.substringAfterLast('.', missingDelimiterValue = "")
        if (ext.isEmpty()) return null
        return byExtension[ext]
    }
}
