package com.fileviewer.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import com.caverock.androidsvg.SVG
import com.fileviewer.app.ui.components.ActionChip
import com.fileviewer.app.ui.components.ActionChipRow
import com.fileviewer.app.ui.components.ZoomableBox
import com.fileviewer.app.ui.components.rememberZoomState

/**
 * Renders SVG as an actual vector — AndroidSVG's [SVG.renderToPicture] draws vector commands
 * directly into an [android.graphics.Picture], so zooming in stays crisp rather than showing
 * a rasterized/blurry image, unlike decoding the SVG to a fixed-resolution Bitmap once.
 */
@Composable
fun SvgViewerScreen(
    svg: SVG,
    intrinsicWidth: Float,
    intrinsicHeight: Float,
    rotationDegrees: Float,
    onRotate: () -> Unit
) {
    val zoomState = rememberZoomState()
    var actualSize by remember { mutableStateOf(false) }

    LaunchedEffect(rotationDegrees) {
        zoomState.rotationDegrees = rotationDegrees
    }

    val picture = remember(svg) { svg.renderToPicture() }

    Column(modifier = Modifier.fillMaxSize()) {
        ActionChipRow {
            ActionChip(label = if (actualSize) "Fit to screen" else "Actual size") { actualSize = !actualSize }
            ActionChip(label = "Rotate", onClick = onRotate)
            ActionChip(label = "Reset zoom", onClick = { zoomState.resetZoom() })
        }
        Surface(modifier = Modifier.fillMaxSize()) {
            ZoomableBox(state = zoomState, modifier = Modifier.fillMaxSize()) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val baseScale = if (actualSize) {
                        1f
                    } else {
                        val sx = size.width / intrinsicWidth
                        val sy = size.height / intrinsicHeight
                        val fit = minOf(sx, sy)
                        if (fit.isFinite() && fit > 0f) fit else 1f
                    }
                    val drawWidth = intrinsicWidth * baseScale
                    val drawHeight = intrinsicHeight * baseScale
                    val offsetX = (size.width - drawWidth) / 2f
                    val offsetY = (size.height - drawHeight) / 2f

                    drawIntoCanvas { canvas ->
                        val nativeCanvas = canvas.nativeCanvas
                        val saveCount = nativeCanvas.save()
                        nativeCanvas.translate(offsetX, offsetY)
                        nativeCanvas.scale(baseScale, baseScale)
                        nativeCanvas.drawPicture(picture)
                        nativeCanvas.restoreToCount(saveCount)
                    }
                }
            }
        }
    }
}
