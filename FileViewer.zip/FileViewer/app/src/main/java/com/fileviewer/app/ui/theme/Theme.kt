package com.fileviewer.app.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.fileviewer.app.highlight.HighlightColors

// Static fallback palette (used pre-Android-12, where dynamic color isn't available).
private val LightColors = lightColorScheme(
    primary = Color(0xFF3A5B99),
    onPrimary = Color(0xFFFFFFFF),
    background = Color(0xFFFCFCFF),
    surface = Color(0xFFFCFCFF),
    onSurface = Color(0xFF1A1B20),
    surfaceVariant = Color(0xFFE1E2EC)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFAAC7FF),
    onPrimary = Color(0xFF0A2E5C),
    background = Color(0xFF121316),
    surface = Color(0xFF121316),
    onSurface = Color(0xFFE3E2E9),
    surfaceVariant = Color(0xFF44474E)
)

private val AppTypography = Typography(
    bodyLarge = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.Normal, fontSize = 16.sp, lineHeight = 24.sp),
    titleLarge = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.SemiBold, fontSize = 22.sp, lineHeight = 28.sp)
)

val LightHighlightColors = HighlightColors(
    keyword = Color(0xFF8250DF),
    string = Color(0xFF116329),
    comment = Color(0xFF6E7781),
    number = Color(0xFF953800),
    type = Color(0xFF0550AE),
    default = Color(0xFF1A1B20)
)

val DarkHighlightColors = HighlightColors(
    keyword = Color(0xFFC678DD),
    string = Color(0xFF98C379),
    comment = Color(0xFF7F848E),
    number = Color(0xFFD19A66),
    type = Color(0xFFE5C07B),
    default = Color(0xFFE3E2E9)
)

@Composable
fun FileViewerTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        darkTheme -> DarkColors
        else -> LightColors
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = AppTypography,
        content = content
    )
}

val monoFontFamily = FontFamily.Monospace
