package com.fileviewer.app.ui.components

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fileviewer.app.model.SearchMatch

/**
 * Shared line-oriented viewer used by the code, plain-text, and Markdown-raw-source
 * screens. Handles: optional line numbers, a word-wrap toggle, per-line syntax
 * highlighting (when [highlightedLines] is supplied), and search-match highlighting
 * with the current match distinguished from the rest.
 *
 * Word wrap off shares a single [androidx.compose.foundation.ScrollState] across every
 * visible row, so dragging any one line horizontally scrolls all of them together.
 */
@Composable
fun LineListViewer(
    lines: List<String>,
    showLineNumbers: Boolean,
    wordWrap: Boolean,
    highlightedLines: List<AnnotatedString>?,
    searchMatches: List<SearchMatch>,
    currentMatchIndex: Int,
    modifier: Modifier = Modifier
) {
    val listState = rememberLazyListState()
    val hScroll = rememberScrollState()

    val matchesByLine = remember(searchMatches) { searchMatches.groupBy { it.lineIndex } }
    val currentMatch = searchMatches.getOrNull(currentMatchIndex)

    LaunchedEffect(currentMatchIndex, searchMatches.size) {
        currentMatch?.let { match ->
            if (lines.isNotEmpty()) {
                listState.animateScrollToItem(match.lineIndex.coerceIn(0, lines.size - 1))
            }
        }
    }

    val lineNumberWidth = remember(lines.size) { (lines.size.toString().length * 9 + 16).dp }

    LazyColumn(state = listState, modifier = modifier.fillMaxSize()) {
        items(lines.size) { index ->
            val line = lines[index]
            val base = highlightedLines?.getOrNull(index) ?: AnnotatedString(line)
            val styled = applySearchHighlight(base, matchesByLine[index].orEmpty(), currentMatch)

            Row(
                modifier = (if (!wordWrap) Modifier.horizontalScroll(hScroll) else Modifier.fillMaxWidth())
                    .padding(horizontal = 4.dp, vertical = 1.dp)
            ) {
                if (showLineNumbers) {
                    Text(
                        text = (index + 1).toString(),
                        modifier = Modifier.width(lineNumberWidth),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 13.sp
                    )
                }
                Text(
                    text = styled,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 13.sp,
                    softWrap = wordWrap,
                    maxLines = if (wordWrap) Int.MAX_VALUE else 1
                )
            }
        }
    }
}

private fun applySearchHighlight(
    base: AnnotatedString,
    lineMatches: List<SearchMatch>,
    current: SearchMatch?
): AnnotatedString {
    if (lineMatches.isEmpty()) return base
    return buildAnnotatedString {
        append(base)
        for (m in lineMatches) {
            val isCurrent = m == current
            addStyle(
                SpanStyle(background = if (isCurrent) Color(0xFFFFA726) else Color(0x664FC3F7)),
                m.start.coerceIn(0, base.length),
                m.end.coerceIn(0, base.length)
            )
        }
    }
}
