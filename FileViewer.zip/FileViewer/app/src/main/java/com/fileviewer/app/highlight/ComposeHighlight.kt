package com.fileviewer.app.highlight

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import com.fileviewer.app.detection.LanguageSpec

data class HighlightColors(
    val keyword: Color,
    val string: Color,
    val comment: Color,
    val number: Color,
    val type: Color,
    val default: Color
)

private fun colorFor(type: TokenType, colors: HighlightColors): Color = when (type) {
    TokenType.KEYWORD -> colors.keyword
    TokenType.STRING -> colors.string
    TokenType.COMMENT -> colors.comment
    TokenType.NUMBER -> colors.number
    TokenType.TYPE -> colors.type
    TokenType.DEFAULT -> colors.default
}

/** Highlights every line of [lines] against [lang], carrying block-comment / triple-string state across lines. */
fun highlightLinesToAnnotatedStrings(
    lines: List<String>,
    lang: LanguageSpec?,
    colors: HighlightColors
): List<AnnotatedString> {
    if (lang == null) {
        return lines.map { AnnotatedString(it) }
    }
    var state = SyntaxHighlighter.HighlightState()
    val result = ArrayList<AnnotatedString>(lines.size)
    for (line in lines) {
        val (tokens, newState) = SyntaxHighlighter.highlightLine(line, lang, state)
        state = newState
        result.add(buildAnnotatedString {
            append(line)
            for (token in tokens) {
                if (token.type == TokenType.DEFAULT) continue
                addStyle(SpanStyle(color = colorFor(token.type, colors)), token.start, token.end)
            }
        })
    }
    return result
}

@Composable
fun rememberHighlightedLines(lines: List<String>, lang: LanguageSpec?, colors: HighlightColors): List<AnnotatedString> {
    return remember(lines, lang) { highlightLinesToAnnotatedStrings(lines, lang, colors) }
}
