package com.fileviewer.app.model

import android.graphics.drawable.Drawable
import com.caverock.androidsvg.SVG
import com.fileviewer.app.detection.LanguageSpec

sealed class ViewerUiState {

    data object Idle : ViewerUiState()

    data class Loading(val fileName: String) : ViewerUiState()

    data class ImageContent(
        val metadata: FileMetadata,
        val drawable: Drawable,
        val isAnimated: Boolean
    ) : ViewerUiState()

    data class SvgContent(
        val metadata: FileMetadata,
        val svg: SVG,
        val rawSource: String,
        val intrinsicWidth: Float,
        val intrinsicHeight: Float
    ) : ViewerUiState()

    data class MarkdownContent(
        val metadata: FileMetadata,
        val rawText: String,
        val truncated: Boolean
    ) : ViewerUiState()

    data class CodeContent(
        val metadata: FileMetadata,
        val lines: List<String>,
        val language: LanguageSpec?,
        val truncated: Boolean
    ) : ViewerUiState()

    data class TextContent(
        val metadata: FileMetadata,
        val lines: List<String>,
        val truncated: Boolean
    ) : ViewerUiState()

    data class UnknownBinaryContent(
        val metadata: FileMetadata,
        val hexLines: List<String>,
        val sampleTruncated: Boolean
    ) : ViewerUiState()

    data class Error(
        val fileName: String?,
        val title: String,
        val message: String
    ) : ViewerUiState()
}
