package com.fileviewer.app.reader

import android.content.Context
import android.net.Uri

private const val HEX_SAMPLE_BYTES = 64 * 1024 // enough to usefully inspect an unrecognized file
private const val BYTES_PER_ROW = 16

data class HexDump(val lines: List<String>, val truncated: Boolean, val sampleBytes: ByteArray)

/** Fallback for files that are neither a recognized image nor readable text: metadata + a safe hex preview. */
object UnknownContentReader {

    fun readHexDump(context: Context, uri: Uri): HexDump {
        val bytes = context.contentResolver.openInputStream(uri)?.use { stream ->
            val buffer = ByteArray(HEX_SAMPLE_BYTES)
            var total = 0
            while (total < buffer.size) {
                val read = stream.read(buffer, total, buffer.size - total)
                if (read == -1) break
                total += read
            }
            buffer.copyOf(total)
        } ?: ByteArray(0)

        val lines = ArrayList<String>(bytes.size / BYTES_PER_ROW + 1)
        var offset = 0
        while (offset < bytes.size) {
            val end = minOf(offset + BYTES_PER_ROW, bytes.size)
            val hex = StringBuilder()
            val ascii = StringBuilder()
            for (i in offset until end) {
                val b = bytes[i].toInt() and 0xFF
                hex.append(String.format("%02X ", b))
                ascii.append(if (b in 32..126) b.toChar() else '.')
            }
            while (hex.length < BYTES_PER_ROW * 3) hex.append(' ')
            lines.add(String.format("%08X  %s %s", offset, hex.toString(), ascii.toString()))
            offset = end
        }
        return HexDump(lines, bytes.size >= HEX_SAMPLE_BYTES, bytes)
    }
}
