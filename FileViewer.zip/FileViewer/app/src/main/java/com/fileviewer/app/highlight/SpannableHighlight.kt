package com.fileviewer.app.highlight

import android.graphics.Color
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import com.fileviewer.app.detection.LanguageSpec

/** Android-Spannable flavor of the highlighter, used by the Markdown code-block plugin. */
object SpannableHighlight {

    data class SpanColors(
        val keyword: Int,
        val string: Int,
        val comment: Int,
        val number: Int,
        val type: Int
    )

    private fun colorFor(type: TokenType, colors: SpanColors): Int? = when (type) {
        TokenType.KEYWORD -> colors.keyword
        TokenType.STRING -> colors.string
        TokenType.COMMENT -> colors.comment
        TokenType.NUMBER -> colors.number
        TokenType.TYPE -> colors.type
        TokenType.DEFAULT -> null
    }

    fun highlight(code: String, lang: LanguageSpec?, colors: SpanColors): CharSequence {
        val spannable = SpannableString(code)
        if (lang == null) return spannable

        var state = SyntaxHighlighter.HighlightState()
        var offset = 0
        val lines = code.split("\n")
        for ((idx, line) in lines.withIndex()) {
            val (tokens, newState) = SyntaxHighlighter.highlightLine(line, lang, state)
            state = newState
            for (token in tokens) {
                val color = colorFor(token.type, colors) ?: continue
                val start = offset + token.start
                val end = offset + token.end
                if (start in 0..spannable.length && end in start..spannable.length) {
                    spannable.setSpan(ForegroundColorSpan(color), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
            }
            offset += line.length + 1 // account for the '\n' removed by split, except possibly the last line
        }
        return spannable
    }
}
