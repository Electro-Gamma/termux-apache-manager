package com.fileviewer.app.util

import java.text.DateFormat
import java.util.Date
import kotlin.math.ln
import kotlin.math.pow

object Format {

    fun bytes(size: Long): String {
        if (size < 0) return "Unknown"
        if (size < 1024) return "$size B"
        val units = arrayOf("KB", "MB", "GB", "TB")
        val digitGroups = (ln(size.toDouble()) / ln(1024.0)).toInt().coerceIn(1, units.size)
        val value = size / 1024.0.pow(digitGroups.toDouble())
        return String.format("%.1f %s", value, units[digitGroups - 1])
    }

    fun timestamp(millis: Long?): String {
        if (millis == null || millis <= 0) return "Unknown"
        return DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(millis))
    }
}
