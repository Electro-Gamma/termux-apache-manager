package com.fileviewer.app

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import com.fileviewer.app.ui.AppRoot
import com.fileviewer.app.ui.theme.FileViewerTheme
import com.fileviewer.app.viewmodel.FileViewerViewModel

/**
 * Single-activity app. Handles three ways a file can arrive: the in-app "Open a file"
 * button (Storage Access Framework document picker), a launcher "Open with" (ACTION_VIEW),
 * and the system Sharesheet (ACTION_SEND) — see the manifest's intent filters.
 */
class MainActivity : ComponentActivity() {

    private val viewModel: FileViewerViewModel by viewModels()

    private val openDocumentLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            tryPersistPermission(uri)
            viewModel.openFile(this, uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        handleIncomingIntent(intent)

        setContent {
            FileViewerTheme {
                AppRoot(
                    viewModel = viewModel,
                    onRequestOpenFile = { openDocumentLauncher.launch(arrayOf("*/*")) }
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun handleIncomingIntent(intent: Intent?) {
        if (intent == null) return
        val uri: Uri? = when (intent.action) {
            Intent.ACTION_VIEW -> intent.data
            Intent.ACTION_SEND -> intent.getParcelableExtraCompat(Intent.EXTRA_STREAM)
            else -> null
        }
        uri?.let { viewModel.openFile(this, it) }
    }

    /** Best-effort: not every document provider supports persistable grants, and we don't need one to just view the file now. */
    private fun tryPersistPermission(uri: Uri) {
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: SecurityException) {
            // Provider doesn't support persistable permissions — fine, we only need read access for this session.
        }
    }
}

private fun Intent.getParcelableExtraCompat(name: String): Uri? {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        getParcelableExtra(name, Uri::class.java)
    } else {
        @Suppress("DEPRECATION")
        getParcelableExtra(name)
    }
}
