package com.fileviewer.app.reader

import android.content.Context
import android.net.Uri
import com.fileviewer.app.detection.DetectedEncoding
import com.fileviewer.app.detection.EncodingDetector
import java.io.ByteArrayOutputStream
import java.io.InputStream

/** Files at or above this size are read only up to this many bytes — see class doc. */
const val MAX_INLINE_TEXT_BYTES = 5L * 1024 * 1024 // 5 MB

data class DecodedText(val lines: List<String>, val encoding: DetectedEncoding, val truncated: Boolean, val charCount: Int)

/**
 * Reads and decodes a file's text content.
 *
 * Large-file strategy: Compose's LazyColumn only composes the rows currently on screen, so
 * holding the decoded lines of a multi-megabyte text file in memory does not, by itself, make
 * scrolling janky. What *does* risk an OutOfMemoryError is an unbounded read of an arbitrarily
 * large file (a multi-gigabyte log, for instance) — so reads are capped at
 * [MAX_INLINE_TEXT_BYTES] and the UI is told explicitly when a file was truncated, rather than
 * silently reading forever or crashing.
 */
object TextContentReader {

    fun read(context: Context, uri: Uri): DecodedText {
        val cap = MAX_INLINE_TEXT_BYTES + 1 // read one extra byte to detect truncation reliably
        val raw = context.contentResolver.openInputStream(uri)?.use { readBounded(it, cap) } ?: ByteArray(0)

        val truncated = raw.size.toLong() > MAX_INLINE_TEXT_BYTES
        val bytes = if (truncated) raw.copyOf(MAX_INLINE_TEXT_BYTES.toInt()) else raw

        val (text, encoding) = EncodingDetector.decode(bytes)
        val lines = text.split("\n")
        return DecodedText(lines, encoding, truncated, text.length)
    }

    private fun readBounded(stream: InputStream, cap: Long): ByteArray {
        val out = ByteArrayOutputStream(minOf(cap, 1 shl 20).toInt())
        val buffer = ByteArray(64 * 1024)
        var total = 0L
        while (total < cap) {
            val toRead = minOf(buffer.size.toLong(), cap - total).toInt()
            val read = stream.read(buffer, 0, toRead)
            if (read == -1) break
            out.write(buffer, 0, read)
            total += read
        }
        return out.toByteArray()
    }
}
