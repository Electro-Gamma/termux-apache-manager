package com.fileviewer.app.detection

import com.fileviewer.app.highlight.LanguageDefinitions

/**
 * Central classifier: decides which of the app's readers should handle a file.
 * Order matters and mirrors the "unknown files" decision procedure in the spec:
 * signature first (most trustworthy), then MIME type, then extension/content —
 * an unfamiliar or misleading extension never causes an outright rejection.
 */
object FileDetector {

    private val MARKDOWN_EXTENSIONS = LanguageDefinitions.MARKDOWN.extensions.toSet()

    fun classify(fileName: String, mimeType: String?, header: ByteArray): FileType {
        // 1. Magic-byte signature — most reliable signal, catches mis-named/extensionless images.
        val sig = FileSignature.detect(header)
        if (sig != ImageSignature.NONE) return FileType.IMAGE_RASTER

        // 2. Provider-supplied MIME type (skip SVG here; it gets its own vector path below).
        if (mimeType != null && mimeType.startsWith("image/") && mimeType != "image/svg+xml") {
            return FileType.IMAGE_RASTER
        }

        val ext = fileName.substringAfterLast('.', missingDelimiterValue = "").lowercase()

        // 3. Binary/text gate. Anything that doesn't look like text and isn't a known image
        //    falls through to the unknown-binary (metadata + hex) handler.
        if (!FileSignature.looksLikeText(header)) return FileType.UNKNOWN_BINARY

        // 4. SVG — by extension, MIME type, or a content sniff for the misnamed case.
        val headerText = runCatching { String(header, Charsets.UTF_8) }.getOrDefault("")
        if (ext == "svg" || mimeType == "image/svg+xml" || FileSignature.looksLikeSvg(headerText)) {
            return FileType.IMAGE_SVG
        }

        // 5. Markdown.
        if (ext in MARKDOWN_EXTENSIONS || mimeType == "text/markdown") return FileType.MARKDOWN

        // 6. Recognized source/config language -> code viewer with syntax highlighting.
        if (LanguageDefinitions.forFile(fileName) != null) return FileType.SOURCE_CODE

        // 7. Anything else that reads as text -> plain text viewer. Unknown extensions land
        //    here rather than being rejected, per the "never reject an unfamiliar extension" rule.
        return FileType.TEXT
    }
}
