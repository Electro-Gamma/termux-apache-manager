package com.fileviewer.app.reader

import android.content.Context
import android.graphics.ImageDecoder
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import com.fileviewer.app.detection.FileSignature
import com.fileviewer.app.detection.ImageSignature

data class DecodedImage(val drawable: Drawable, val width: Int, val height: Int, val isAnimated: Boolean)

private const val MAX_DIMENSION = 4096 // caps decode target size so a huge image can't OOM the app

/**
 * Decodes raster images. Static and animated GIF/WebP, JPEG, PNG, BMP, and — where the
 * device's platform codecs support it — HEIF/HEIC and AVIF are all handled by the
 * platform's [ImageDecoder] (API 28+), which natively downsamples during decode for
 * memory safety and returns an [AnimatedImageDrawable] for animated content, so no
 * separate GIF library is needed. Netpbm (PBM/PGM/PPM) has no platform decoder, so it's
 * routed to [NetpbmDecoder].
 */
object ImageContentReader {

    fun decode(context: Context, uri: Uri, header: ByteArray): DecodedImage? {
        if (FileSignature.detect(header) == ImageSignature.NETPBM) {
            val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return null
            val bmp = NetpbmDecoder.decode(bytes) ?: return null
            return DecodedImage(BitmapDrawable(context.resources, bmp), bmp.width, bmp.height, false)
        }

        return try {
            val source = ImageDecoder.createSource(context.contentResolver, uri)
            var outW = 0
            var outH = 0
            val drawable = ImageDecoder.decodeDrawable(source) { decoder, info, _ ->
                outW = info.size.width
                outH = info.size.height
                val longest = maxOf(outW, outH)
                if (longest > MAX_DIMENSION) {
                    val sample = Integer.highestOneBit((longest / MAX_DIMENSION).coerceAtLeast(1))
                    decoder.setTargetSampleSize(sample.coerceAtLeast(1))
                }
                decoder.isMutableRequired = false
            }
            val isAnimated = drawable is AnimatedImageDrawable
            if (isAnimated) (drawable as AnimatedImageDrawable).start()
            DecodedImage(drawable, outW, outH, isAnimated)
        } catch (e: Exception) {
            null
        }
    }
}
