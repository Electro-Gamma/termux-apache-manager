package com.fileviewer.app.ui.components

import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput

private const val MIN_SCALE = 1f
private const val MAX_SCALE = 8f
private const val DOUBLE_TAP_SCALE = 3f

/** Holds pinch-zoom/pan/rotate state for a single image/SVG viewer instance. */
class ZoomState {
    var scale by mutableFloatStateOf(1f)
    var offsetX by mutableFloatStateOf(0f)
    var offsetY by mutableFloatStateOf(0f)
    var rotationDegrees by mutableFloatStateOf(0f)

    fun resetZoom() {
        scale = 1f
        offsetX = 0f
        offsetY = 0f
    }
}

@Composable
fun rememberZoomState(): ZoomState = remember { ZoomState() }

/**
 * Wraps [content] (expected to fill the box, e.g. an Image or a Canvas drawing an SVG Picture)
 * with pinch-to-zoom, pan, and double-tap-to-zoom gestures. Rotation is driven externally via
 * [ZoomState.rotationDegrees] so a screen's rotate button can animate it independent of touch.
 */
@Composable
fun ZoomableBox(
    state: ZoomState,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    val newScale = (state.scale * zoom).coerceIn(MIN_SCALE, MAX_SCALE)
                    state.scale = newScale
                    if (newScale <= MIN_SCALE) {
                        state.offsetX = 0f
                        state.offsetY = 0f
                    } else {
                        state.offsetX += pan.x
                        state.offsetY += pan.y
                    }
                }
            }
            .pointerInput(Unit) {
                detectTapGestures(
                    onDoubleTap = {
                        if (state.scale > MIN_SCALE) {
                            state.resetZoom()
                        } else {
                            state.scale = DOUBLE_TAP_SCALE
                        }
                    }
                )
            }
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = state.scale
                    scaleY = state.scale
                    translationX = state.offsetX
                    translationY = state.offsetY
                    rotationZ = state.rotationDegrees
                }
        ) {
            content()
        }
    }
}
