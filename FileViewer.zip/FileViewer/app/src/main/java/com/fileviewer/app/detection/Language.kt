package com.fileviewer.app.detection

/**
 * A source-code / config language the syntax highlighter and code viewer know
 * about. Extensions are matched case-insensitively, without the leading dot.
 */
data class LanguageSpec(
    val displayName: String,
    val extensions: List<String>,
    val lineComment: List<String> = emptyList(),
    val blockCommentStart: String? = null,
    val blockCommentEnd: String? = null,
    val stringDelimiters: List<Char> = listOf('"', '\''),
    val keywords: Set<String> = emptySet(),
    val types: Set<String> = emptySet(),
    /** True for languages whose strings can start with a triple-quote / heredoc-style token. */
    val supportsTripleQuoteStrings: Boolean = false
)
