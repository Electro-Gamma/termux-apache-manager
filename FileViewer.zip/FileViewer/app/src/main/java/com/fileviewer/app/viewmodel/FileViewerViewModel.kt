package com.fileviewer.app.viewmodel

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.fileviewer.app.model.LineSearch
import com.fileviewer.app.model.SearchState
import com.fileviewer.app.model.ViewerUiState
import com.fileviewer.app.reader.FileOpener
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Owns the currently-open file's UI state and drives every viewer screen from it.
 * File reading/decoding always happens on [Dispatchers.IO] — see [openFile] — so the
 * UI thread is never blocked by SAF I/O, image decoding, or text/markdown parsing.
 */
class FileViewerViewModel : ViewModel() {

    private val _uiState = MutableStateFlow<ViewerUiState>(ViewerUiState.Idle)
    val uiState: StateFlow<ViewerUiState> = _uiState.asStateFlow()

    private val _search = MutableStateFlow(SearchState())
    val search: StateFlow<SearchState> = _search.asStateFlow()

    private val _showInfo = MutableStateFlow(false)
    val showInfo: StateFlow<Boolean> = _showInfo.asStateFlow()

    private val _markdownRawMode = MutableStateFlow(false)
    val markdownRawMode: StateFlow<Boolean> = _markdownRawMode.asStateFlow()

    private val _wordWrap = MutableStateFlow(true)
    val wordWrap: StateFlow<Boolean> = _wordWrap.asStateFlow()

    private val _imageRotationDegrees = MutableStateFlow(0f)
    val imageRotationDegrees: StateFlow<Float> = _imageRotationDegrees.asStateFlow()

    fun openFile(context: Context, uri: Uri) {
        val appContext = context.applicationContext
        _uiState.value = ViewerUiState.Loading(uri.lastPathSegment ?: "file")
        _search.value = SearchState()
        _markdownRawMode.value = false
        _wordWrap.value = true
        _imageRotationDegrees.value = 0f
        _showInfo.value = false

        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) { FileOpener.open(appContext, uri) }
            _uiState.value = result
        }
    }

    fun closeFile() {
        _uiState.value = ViewerUiState.Idle
        _search.value = SearchState()
    }

    fun toggleInfo() {
        _showInfo.value = !_showInfo.value
    }

    fun dismissInfo() {
        _showInfo.value = false
    }

    fun toggleMarkdownRawMode() {
        _markdownRawMode.value = !_markdownRawMode.value
    }

    fun toggleWordWrap() {
        _wordWrap.value = !_wordWrap.value
    }

    fun rotateImage() {
        _imageRotationDegrees.value = (_imageRotationDegrees.value + 90f) % 360f
    }

    fun openSearch() {
        _search.value = _search.value.copy(active = true)
        // Search highlighting is computed against the raw markdown source (see
        // MarkdownCodeHighlighter's doc comment on scope) — switch to source view so what's
        // highlighted matches what's on screen.
        if (_uiState.value is ViewerUiState.MarkdownContent) _markdownRawMode.value = true
        recomputeMatches()
    }

    fun closeSearch() {
        _search.value = SearchState()
    }

    fun updateQuery(query: String) {
        _search.value = _search.value.copy(query = query)
        recomputeMatches()
    }

    fun toggleCaseSensitive() {
        _search.value = _search.value.copy(caseSensitive = !_search.value.caseSensitive)
        recomputeMatches()
    }

    fun nextMatch() {
        val s = _search.value
        if (s.matches.isEmpty()) return
        _search.value = s.copy(currentIndex = (s.currentIndex + 1) % s.matches.size)
    }

    fun prevMatch() {
        val s = _search.value
        if (s.matches.isEmpty()) return
        _search.value = s.copy(currentIndex = if (s.currentIndex <= 0) s.matches.size - 1 else s.currentIndex - 1)
    }

    private fun linesForSearch(): List<String>? = when (val state = _uiState.value) {
        is ViewerUiState.CodeContent -> state.lines
        is ViewerUiState.TextContent -> state.lines
        is ViewerUiState.MarkdownContent -> state.rawText.split("\n")
        else -> null
    }

    private fun recomputeMatches() {
        val lines = linesForSearch()
        if (lines == null) {
            _search.value = _search.value.copy(matches = emptyList(), currentIndex = -1)
            return
        }
        val s = _search.value
        val matches = LineSearch.find(lines, s.query, s.caseSensitive)
        _search.value = s.copy(matches = matches, currentIndex = if (matches.isEmpty()) -1 else 0)
    }
}
