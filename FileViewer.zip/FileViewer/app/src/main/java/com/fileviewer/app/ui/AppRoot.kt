package com.fileviewer.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.fileviewer.app.model.ViewerUiState
import com.fileviewer.app.ui.components.ErrorScreen
import com.fileviewer.app.ui.components.FileInfoSheet
import com.fileviewer.app.ui.components.LoadingScreen
import com.fileviewer.app.ui.components.SearchBarRow
import com.fileviewer.app.ui.components.ViewerTopBar
import com.fileviewer.app.ui.screens.CodeViewerScreen
import com.fileviewer.app.ui.screens.HexViewerScreen
import com.fileviewer.app.ui.screens.HomeScreen
import com.fileviewer.app.ui.screens.ImageViewerScreen
import com.fileviewer.app.ui.screens.MarkdownViewerScreen
import com.fileviewer.app.ui.screens.SvgViewerScreen
import com.fileviewer.app.ui.screens.TextViewerScreen
import com.fileviewer.app.viewmodel.FileViewerViewModel

/**
 * Single top-level composable that switches between the home screen and whichever
 * viewer matches the currently-open file's [ViewerUiState], plus the shared top bar,
 * search bar, and file-info sheet that overlay every viewer.
 */
@Composable
fun AppRoot(
    viewModel: FileViewerViewModel,
    onRequestOpenFile: () -> Unit
) {
    val state by viewModel.uiState.collectAsState()
    val search by viewModel.search.collectAsState()
    val showInfo by viewModel.showInfo.collectAsState()
    val markdownRaw by viewModel.markdownRawMode.collectAsState()
    val wordWrap by viewModel.wordWrap.collectAsState()
    val rotation by viewModel.imageRotationDegrees.collectAsState()

    val supportsSearch = state is ViewerUiState.CodeContent ||
        state is ViewerUiState.TextContent ||
        state is ViewerUiState.MarkdownContent

    val supportsInfo = state is ViewerUiState.ImageContent ||
        state is ViewerUiState.SvgContent ||
        state is ViewerUiState.MarkdownContent ||
        state is ViewerUiState.CodeContent ||
        state is ViewerUiState.TextContent ||
        state is ViewerUiState.UnknownBinaryContent

    val title = when (val s = state) {
        is ViewerUiState.Idle -> "File Viewer"
        is ViewerUiState.Loading -> s.fileName
        is ViewerUiState.ImageContent -> s.metadata.file.displayName
        is ViewerUiState.SvgContent -> s.metadata.file.displayName
        is ViewerUiState.MarkdownContent -> s.metadata.file.displayName
        is ViewerUiState.CodeContent -> s.metadata.file.displayName
        is ViewerUiState.TextContent -> s.metadata.file.displayName
        is ViewerUiState.UnknownBinaryContent -> s.metadata.file.displayName
        is ViewerUiState.Error -> s.fileName ?: "Error"
    }

    // Back closes search first, then the open document, then (system default) the app.
    BackHandler(enabled = state !is ViewerUiState.Idle) {
        if (search.active) viewModel.closeSearch() else viewModel.closeFile()
    }

    Scaffold(
        topBar = {
            if (state !is ViewerUiState.Idle) {
                Column {
                    ViewerTopBar(
                        title = title,
                        onBack = { if (search.active) viewModel.closeSearch() else viewModel.closeFile() },
                        onSearch = if (supportsSearch) ({ viewModel.openSearch() }) else null,
                        onInfo = if (supportsInfo) ({ viewModel.toggleInfo() }) else null
                    )
                    if (search.active) {
                        SearchBarRow(
                            query = search.query,
                            caseSensitive = search.caseSensitive,
                            matchCount = search.matchCount,
                            currentIndex = search.currentIndex,
                            onQueryChange = viewModel::updateQuery,
                            onNext = viewModel::nextMatch,
                            onPrev = viewModel::prevMatch,
                            onToggleCase = viewModel::toggleCaseSensitive,
                            onClose = viewModel::closeSearch
                        )
                    }
                }
            }
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            when (val s = state) {
                is ViewerUiState.Idle -> HomeScreen(onOpenFile = onRequestOpenFile)

                is ViewerUiState.Loading -> LoadingScreen(fileName = s.fileName)

                is ViewerUiState.ImageContent -> ImageViewerScreen(
                    drawable = s.drawable,
                    rotationDegrees = rotation,
                    onRotate = viewModel::rotateImage
                )

                is ViewerUiState.SvgContent -> SvgViewerScreen(
                    svg = s.svg,
                    intrinsicWidth = s.intrinsicWidth,
                    intrinsicHeight = s.intrinsicHeight,
                    rotationDegrees = rotation,
                    onRotate = viewModel::rotateImage
                )

                is ViewerUiState.MarkdownContent -> MarkdownViewerScreen(
                    rawText = s.rawText,
                    truncated = s.truncated,
                    rawMode = markdownRaw,
                    onToggleRawMode = viewModel::toggleMarkdownRawMode,
                    searchMatches = search.matches,
                    currentMatchIndex = search.currentIndex
                )

                is ViewerUiState.CodeContent -> CodeViewerScreen(
                    lines = s.lines,
                    language = s.language,
                    truncated = s.truncated,
                    wordWrap = wordWrap,
                    onToggleWordWrap = viewModel::toggleWordWrap,
                    searchMatches = search.matches,
                    currentMatchIndex = search.currentIndex
                )

                is ViewerUiState.TextContent -> TextViewerScreen(
                    lines = s.lines,
                    truncated = s.truncated,
                    wordWrap = wordWrap,
                    onToggleWordWrap = viewModel::toggleWordWrap,
                    searchMatches = search.matches,
                    currentMatchIndex = search.currentIndex
                )

                is ViewerUiState.UnknownBinaryContent -> HexViewerScreen(
                    hexLines = s.hexLines,
                    truncatedSample = s.sampleTruncated
                )

                is ViewerUiState.Error -> ErrorScreen(title = s.title, message = s.message)
            }
        }

        if (showInfo) {
            val metadata = when (val s = state) {
                is ViewerUiState.ImageContent -> s.metadata
                is ViewerUiState.SvgContent -> s.metadata
                is ViewerUiState.MarkdownContent -> s.metadata
                is ViewerUiState.CodeContent -> s.metadata
                is ViewerUiState.TextContent -> s.metadata
                is ViewerUiState.UnknownBinaryContent -> s.metadata
                else -> null
            }
            metadata?.let { FileInfoSheet(metadata = it, onDismiss = viewModel::dismissInfo) }
        }
    }
}
