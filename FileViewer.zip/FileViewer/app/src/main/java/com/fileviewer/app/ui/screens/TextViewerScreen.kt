package com.fileviewer.app.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.fileviewer.app.model.SearchMatch
import com.fileviewer.app.reader.MAX_INLINE_TEXT_BYTES
import com.fileviewer.app.ui.components.ActionChip
import com.fileviewer.app.ui.components.ActionChipRow
import com.fileviewer.app.ui.components.LargeFileBanner
import com.fileviewer.app.ui.components.LineListViewer
import com.fileviewer.app.util.Format

/** Clean reader for plain, unrecognized-language text files — no line numbers, no highlighting. */
@Composable
fun TextViewerScreen(
    lines: List<String>,
    truncated: Boolean,
    wordWrap: Boolean,
    onToggleWordWrap: () -> Unit,
    searchMatches: List<SearchMatch>,
    currentMatchIndex: Int
) {
    Column(modifier = Modifier.fillMaxSize()) {
        ActionChipRow {
            ActionChip(label = if (wordWrap) "No wrap" else "Wrap", onClick = onToggleWordWrap)
        }
        if (truncated) {
            LargeFileBanner("Large file — showing the first ${Format.bytes(MAX_INLINE_TEXT_BYTES)}. Some content is not loaded.")
        }
        LineListViewer(
            lines = lines,
            showLineNumbers = false,
            wordWrap = wordWrap,
            highlightedLines = null,
            searchMatches = searchMatches,
            currentMatchIndex = currentMatchIndex,
            modifier = Modifier.fillMaxSize()
        )
    }
}
