package com.fileviewer.app.detection

/**
 * The broad category a file was classified into. Every reader/viewer in the app
 * is keyed off one of these — see FileDetector for how a file is assigned one.
 */
enum class FileType {
    IMAGE_RASTER,
    IMAGE_SVG,
    MARKDOWN,
    SOURCE_CODE,
    TEXT,
    UNKNOWN_BINARY
}
