package com.fileviewer.app.reader

import com.caverock.androidsvg.SVG
import com.caverock.androidsvg.SVGParseException

data class DecodedSvg(val svg: SVG, val width: Float, val height: Float)

/** Parses SVG as an actual vector document (AndroidSVG) rather than rasterizing it once. */
object SvgContentReader {

    fun decode(rawText: String): DecodedSvg? {
        return try {
            val svg = SVG.getFromString(rawText)
            var w = svg.documentWidth
            var h = svg.documentHeight
            if (w <= 0f || h <= 0f) {
                svg.documentViewBox?.let { vb ->
                    w = vb.width()
                    h = vb.height()
                }
            }
            if (w <= 0f || h <= 0f) {
                w = 300f
                h = 300f
            }
            DecodedSvg(svg, w, h)
        } catch (e: SVGParseException) {
            null
        } catch (e: Exception) {
            null
        }
    }
}
