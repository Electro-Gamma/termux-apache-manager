package com.fileviewer.app.highlight

import com.fileviewer.app.detection.LanguageSpec

enum class TokenType { DEFAULT, KEYWORD, TYPE, STRING, COMMENT, NUMBER }

data class Token(val start: Int, val end: Int, val type: TokenType)

/**
 * A small, dependency-free, line-oriented tokenizer. It is intentionally simple —
 * a single-pass scanner that recognizes comments, strings, numbers, and keywords
 * per LanguageDefinitions — rather than a full parser. This keeps the app free of
 * a heavy grammar engine while still giving correct highlighting for normal code.
 *
 * State (e.g. "are we inside a block comment that started on a previous line?")
 * is tracked explicitly via [HighlightState] so multi-line block comments and
 * triple-quoted strings highlight correctly across line boundaries in a
 * line-by-line viewer.
 */
object SyntaxHighlighter {

    data class HighlightState(val inBlockComment: Boolean = false, val inTripleString: Boolean = false)

    private val numberRegex = Regex("^-?\\d+(\\.\\d+)?([eE][+-]?\\d+)?[fFdDlLuU]?")
    private val identifierStart = Regex("[A-Za-z_]")
    private val identifierRegex = Regex("[A-Za-z_][A-Za-z0-9_]*")

    fun highlightLine(line: String, lang: LanguageSpec, stateIn: HighlightState): Pair<List<Token>, HighlightState> {
        val tokens = mutableListOf<Token>()
        var i = 0
        var inBlockComment = stateIn.inBlockComment
        var inTripleString = stateIn.inTripleString
        val n = line.length

        // Continuing a block comment from a previous line.
        if (inBlockComment && lang.blockCommentEnd != null) {
            val endIdx = line.indexOf(lang.blockCommentEnd, i)
            if (endIdx == -1) {
                tokens.add(Token(0, n, TokenType.COMMENT))
                return tokens to HighlightState(inBlockComment = true, inTripleString = inTripleString)
            } else {
                tokens.add(Token(0, endIdx + lang.blockCommentEnd.length, TokenType.COMMENT))
                i = endIdx + lang.blockCommentEnd.length
                inBlockComment = false
            }
        }

        // Continuing a triple-quoted string from a previous line.
        if (inTripleString) {
            val endIdx = line.indexOf("\"\"\"", i)
            if (endIdx == -1) {
                tokens.add(Token(i, n, TokenType.STRING))
                return tokens to HighlightState(inBlockComment = false, inTripleString = true)
            } else {
                tokens.add(Token(i, endIdx + 3, TokenType.STRING))
                i = endIdx + 3
                inTripleString = false
            }
        }

        while (i < n) {
            val c = line[i]

            // Line comment — rest of the line.
            val lineCommentMatch = lang.lineComment.firstOrNull { line.startsWith(it, i) }
            if (lineCommentMatch != null) {
                tokens.add(Token(i, n, TokenType.COMMENT))
                i = n
                break
            }

            // Block comment start.
            if (lang.blockCommentStart != null && line.startsWith(lang.blockCommentStart, i)) {
                val endIdx = line.indexOf(lang.blockCommentEnd!!, i + lang.blockCommentStart.length)
                if (endIdx == -1) {
                    tokens.add(Token(i, n, TokenType.COMMENT))
                    inBlockComment = true
                    i = n
                    break
                } else {
                    tokens.add(Token(i, endIdx + lang.blockCommentEnd.length, TokenType.COMMENT))
                    i = endIdx + lang.blockCommentEnd.length
                    continue
                }
            }

            // Triple-quoted string start.
            if (lang.supportsTripleQuoteStrings && line.startsWith("\"\"\"", i)) {
                val endIdx = line.indexOf("\"\"\"", i + 3)
                if (endIdx == -1) {
                    tokens.add(Token(i, n, TokenType.STRING))
                    inTripleString = true
                    i = n
                    break
                } else {
                    tokens.add(Token(i, endIdx + 3, TokenType.STRING))
                    i = endIdx + 3
                    continue
                }
            }

            // Regular quoted string.
            if (c in lang.stringDelimiters) {
                val start = i
                i++
                while (i < n && line[i] != c) {
                    if (line[i] == '\\' && i + 1 < n) i++
                    i++
                }
                if (i < n) i++ // consume closing delimiter
                tokens.add(Token(start, i, TokenType.STRING))
                continue
            }

            // Number.
            if (c.isDigit()) {
                val match = numberRegex.find(line.substring(i))
                if (match != null && match.range.first == 0) {
                    val len = match.value.length
                    tokens.add(Token(i, i + len, TokenType.NUMBER))
                    i += len
                    continue
                }
            }

            // Identifier / keyword / type.
            if (identifierStart.matches(c.toString())) {
                val match = identifierRegex.find(line.substring(i))!!
                val word = match.value
                val type = when {
                    word in lang.keywords -> TokenType.KEYWORD
                    word in lang.types -> TokenType.TYPE
                    else -> TokenType.DEFAULT
                }
                if (type != TokenType.DEFAULT) {
                    tokens.add(Token(i, i + word.length, type))
                }
                i += word.length
                continue
            }

            i++
        }

        return tokens to HighlightState(inBlockComment = inBlockComment, inTripleString = inTripleString)
    }
}
