package com.fileviewer.app.ui.screens

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.fileviewer.app.detection.LanguageSpec
import com.fileviewer.app.highlight.rememberHighlightedLines
import com.fileviewer.app.model.SearchMatch
import com.fileviewer.app.reader.MAX_INLINE_TEXT_BYTES
import com.fileviewer.app.ui.components.ActionChip
import com.fileviewer.app.ui.components.ActionChipRow
import com.fileviewer.app.ui.components.LargeFileBanner
import com.fileviewer.app.ui.components.LineListViewer
import com.fileviewer.app.ui.theme.DarkHighlightColors
import com.fileviewer.app.ui.theme.LightHighlightColors
import com.fileviewer.app.util.Format

/** Read-only, code-editor-style viewer: line numbers, monospace font, syntax highlighting. */
@Composable
fun CodeViewerScreen(
    lines: List<String>,
    language: LanguageSpec?,
    truncated: Boolean,
    wordWrap: Boolean,
    onToggleWordWrap: () -> Unit,
    searchMatches: List<SearchMatch>,
    currentMatchIndex: Int
) {
    val colors = if (isSystemInDarkTheme()) DarkHighlightColors else LightHighlightColors
    val highlighted = rememberHighlightedLines(lines, language, colors)

    Column(modifier = Modifier.fillMaxSize()) {
        ActionChipRow {
            ActionChip(label = if (wordWrap) "No wrap" else "Wrap", onClick = onToggleWordWrap)
            if (language != null) {
                ActionChip(label = language.displayName, onClick = {})
            }
        }
        if (truncated) {
            LargeFileBanner("Large file — showing the first ${Format.bytes(MAX_INLINE_TEXT_BYTES)}. Some content is not loaded.")
        }
        LineListViewer(
            lines = lines,
            showLineNumbers = true,
            wordWrap = wordWrap,
            highlightedLines = highlighted,
            searchMatches = searchMatches,
            currentMatchIndex = currentMatchIndex,
            modifier = Modifier.fillMaxSize()
        )
    }
}
