package com.fileviewer.app.ui.screens

import android.text.method.LinkMovementMethod
import android.widget.TextView
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.fileviewer.app.R
import com.fileviewer.app.highlight.SpannableHighlight
import com.fileviewer.app.markdown.MarkdownCodeHighlighter
import com.fileviewer.app.markdown.MarkwonFactory
import com.fileviewer.app.model.SearchMatch
import com.fileviewer.app.reader.MAX_INLINE_TEXT_BYTES
import com.fileviewer.app.ui.components.ActionChip
import com.fileviewer.app.ui.components.ActionChipRow
import com.fileviewer.app.ui.components.LargeFileBanner
import com.fileviewer.app.ui.components.LineListViewer
import com.fileviewer.app.util.Format

/**
 * Document-focused Markdown viewer with a Rendered/Source toggle. Rendering never mutates
 * the original file — Markwon reads [rawText] and produces a new Spanned each time; nothing
 * is written back.
 */
@Composable
fun MarkdownViewerScreen(
    rawText: String,
    truncated: Boolean,
    rawMode: Boolean,
    onToggleRawMode: () -> Unit,
    searchMatches: List<SearchMatch>,
    currentMatchIndex: Int
) {
    Column(modifier = Modifier.fillMaxSize()) {
        ActionChipRow {
            ActionChip(label = if (rawMode) "Rendered" else "Source", onClick = onToggleRawMode)
        }
        if (truncated) {
            LargeFileBanner("Large file — showing the first ${Format.bytes(MAX_INLINE_TEXT_BYTES)}. Some content is not loaded.")
        }
        if (rawMode) {
            LineListViewer(
                lines = rawText.split("\n"),
                showLineNumbers = false,
                wordWrap = true,
                highlightedLines = null,
                searchMatches = searchMatches,
                currentMatchIndex = currentMatchIndex,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            RenderedMarkdown(rawText = rawText, modifier = Modifier.fillMaxSize())
        }
    }
}

@Composable
private fun RenderedMarkdown(rawText: String, modifier: Modifier) {
    val context = LocalContext.current
    val markwon = remember(context) { MarkwonFactory.create(context) }
    val spanColors = remember(context) {
        SpannableHighlight.SpanColors(
            keyword = ContextCompat.getColor(context, R.color.code_keyword),
            string = ContextCompat.getColor(context, R.color.code_string),
            comment = ContextCompat.getColor(context, R.color.code_comment),
            number = ContextCompat.getColor(context, R.color.code_number),
            type = ContextCompat.getColor(context, R.color.code_type)
        )
    }

    AndroidView(
        modifier = modifier.padding(16.dp),
        factory = { ctx ->
            TextView(ctx).apply {
                movementMethod = LinkMovementMethod.getInstance()
                setTextIsSelectable(true)
            }
        },
        update = { textView ->
            val rendered = markwon.toMarkdown(rawText)
            val withCodeHighlight = MarkdownCodeHighlighter.apply(rendered, rawText, spanColors)
            markwon.setParsedMarkdown(textView, withCodeHighlight)
        }
    )
}
