package com.fileviewer.app.model

/** A single occurrence of the search query within one line of line-oriented content. */
data class SearchMatch(val lineIndex: Int, val start: Int, val end: Int)

data class SearchState(
    val active: Boolean = false,
    val query: String = "",
    val caseSensitive: Boolean = false,
    val matches: List<SearchMatch> = emptyList(),
    val currentIndex: Int = -1
) {
    val matchCount: Int get() = matches.size
    val current: SearchMatch? get() = matches.getOrNull(currentIndex)
}

object LineSearch {
    fun find(lines: List<String>, query: String, caseSensitive: Boolean): List<SearchMatch> {
        if (query.isEmpty()) return emptyList()
        val needle = if (caseSensitive) query else query.lowercase()
        val results = mutableListOf<SearchMatch>()
        for ((idx, rawLine) in lines.withIndex()) {
            val haystack = if (caseSensitive) rawLine else rawLine.lowercase()
            var from = 0
            while (true) {
                val at = haystack.indexOf(needle, from)
                if (at == -1) break
                results.add(SearchMatch(idx, at, at + needle.length))
                from = at + needle.length
            }
        }
        return results
    }
}
