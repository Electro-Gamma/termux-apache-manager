package com.fileviewer.app.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fileviewer.app.R

/** Fallback viewer for files that aren't a recognized image or readable text. */
@Composable
fun HexViewerScreen(hexLines: List<String>, truncatedSample: Boolean) {
    Column(modifier = Modifier.fillMaxSize()) {
        Text(
            text = stringResource(R.string.unknown_binary_message),
            modifier = Modifier.padding(16.dp),
            style = MaterialTheme.typography.bodyMedium
        )
        LazyColumn(modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
            items(hexLines.size) { i ->
                Text(
                    text = hexLines[i],
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                    softWrap = false,
                    modifier = Modifier.padding(vertical = 1.dp)
                )
            }
            if (truncatedSample) {
                item {
                    Text(
                        text = "…preview truncated…",
                        modifier = Modifier.padding(vertical = 8.dp),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
