package com.fileviewer.app.reader

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import com.fileviewer.app.detection.FileDetector
import com.fileviewer.app.detection.FileType
import com.fileviewer.app.highlight.LanguageDefinitions
import com.fileviewer.app.model.FileMetadata
import com.fileviewer.app.model.OpenedFile
import com.fileviewer.app.model.ViewerUiState
import java.io.File
import java.io.FileNotFoundException

private const val SNIFF_BYTES = 8192

/**
 * Top-level orchestrator: figures out what a file is (via [FileDetector]) and dispatches to
 * the matching reader, or produces a friendly [ViewerUiState.Error] instead of letting any
 * exception propagate and crash the app (per the "never crash on an unsupported/corrupted
 * file" requirement).
 */
object FileOpener {

    fun open(context: Context, uri: Uri): ViewerUiState {
        val basic = queryBasicInfo(context, uri)
        return try {
            val header = readHeader(context, uri, SNIFF_BYTES)
            when (FileDetector.classify(basic.displayName, basic.mimeType, header)) {
                FileType.IMAGE_RASTER -> openImage(context, basic, header)
                FileType.IMAGE_SVG -> openSvg(context, basic)
                FileType.MARKDOWN -> openMarkdown(context, basic)
                FileType.SOURCE_CODE -> openSourceCode(context, basic)
                FileType.TEXT -> openText(context, basic)
                FileType.UNKNOWN_BINARY -> openUnknown(context, basic)
            }
        } catch (e: SecurityException) {
            ViewerUiState.Error(basic.displayName, "Permission denied", "This app was not granted permission to read this file.")
        } catch (e: FileNotFoundException) {
            ViewerUiState.Error(basic.displayName, "File not found", "This file is no longer available. It may have been moved or deleted.")
        } catch (e: Exception) {
            ViewerUiState.Error(basic.displayName, "Couldn't open file", e.message ?: "The file provider couldn't supply this file's contents.")
        }
    }

    private fun queryBasicInfo(context: Context, uri: Uri): OpenedFile {
        var name = uri.lastPathSegment?.substringAfterLast('/') ?: "file"
        var size = -1L
        var lastModified: Long? = null

        if (uri.scheme == "content") {
            try {
                context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME).takeIf { it >= 0 }?.let { idx ->
                            cursor.getString(idx)?.let { name = it }
                        }
                        cursor.getColumnIndex(OpenableColumns.SIZE).takeIf { it >= 0 }?.let { idx ->
                            if (!cursor.isNull(idx)) size = cursor.getLong(idx)
                        }
                        cursor.getColumnIndex(DocumentsContract.Document.COLUMN_LAST_MODIFIED).takeIf { it >= 0 }?.let { idx ->
                            if (!cursor.isNull(idx)) lastModified = cursor.getLong(idx)
                        }
                    }
                }
            } catch (e: Exception) {
                // Some providers don't support a metadata query at all; fall back to URI-derived name.
            }
        } else if (uri.scheme == "file") {
            val f = File(uri.path ?: "")
            name = f.name
            if (f.exists()) {
                size = f.length()
                lastModified = f.lastModified()
            }
        }

        val mime = context.contentResolver.getType(uri)
            ?: MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substringAfterLast('.', "").lowercase())

        return OpenedFile(uri, name, mime, size, lastModified)
    }

    private fun readHeader(context: Context, uri: Uri, n: Int): ByteArray {
        val stream = context.contentResolver.openInputStream(uri) ?: throw FileNotFoundException(uri.toString())
        return stream.use {
            val buffer = ByteArray(n)
            var total = 0
            while (total < n) {
                val read = it.read(buffer, total, n - total)
                if (read == -1) break
                total += read
            }
            buffer.copyOf(total)
        }
    }

    private fun openImage(context: Context, basic: OpenedFile, header: ByteArray): ViewerUiState {
        val decoded = ImageContentReader.decode(context, basic.uri, header)
            ?: return ViewerUiState.Error(
                basic.displayName, "Invalid image",
                "The image data is invalid or corrupted, or uses a codec this device doesn't support."
            )
        val metadata = FileMetadata(
            file = basic, typeLabel = "Image",
            imageWidth = decoded.width, imageHeight = decoded.height
        )
        return ViewerUiState.ImageContent(metadata, decoded.drawable, decoded.isAnimated)
    }

    private fun openSvg(context: Context, basic: OpenedFile): ViewerUiState {
        val raw = TextContentReader.read(context, basic.uri)
        val rawText = raw.lines.joinToString("\n")
        val decoded = SvgContentReader.decode(rawText)
            ?: return ViewerUiState.Error(basic.displayName, "Invalid SVG", "This SVG file is malformed and couldn't be parsed.")
        val metadata = FileMetadata(
            file = basic, typeLabel = "Vector image (SVG)",
            imageWidth = decoded.width.toInt(), imageHeight = decoded.height.toInt(),
            encodingLabel = raw.encoding.label
        )
        return ViewerUiState.SvgContent(metadata, decoded.svg, rawText, decoded.width, decoded.height)
    }

    private fun openMarkdown(context: Context, basic: OpenedFile): ViewerUiState {
        val decoded = TextContentReader.read(context, basic.uri)
        val text = decoded.lines.joinToString("\n")
        val metadata = FileMetadata(
            file = basic, typeLabel = "Markdown",
            encodingLabel = decoded.encoding.label,
            lineCount = decoded.lines.size, charCount = decoded.charCount
        )
        return ViewerUiState.MarkdownContent(metadata, text, decoded.truncated)
    }

    private fun openSourceCode(context: Context, basic: OpenedFile): ViewerUiState {
        val decoded = TextContentReader.read(context, basic.uri)
        val lang = LanguageDefinitions.forFile(basic.displayName)
        val metadata = FileMetadata(
            file = basic, typeLabel = "Source code",
            encodingLabel = decoded.encoding.label, language = lang?.displayName,
            lineCount = decoded.lines.size, charCount = decoded.charCount
        )
        return ViewerUiState.CodeContent(metadata, decoded.lines, lang, decoded.truncated)
    }

    private fun openText(context: Context, basic: OpenedFile): ViewerUiState {
        val decoded = TextContentReader.read(context, basic.uri)
        val metadata = FileMetadata(
            file = basic, typeLabel = "Text",
            encodingLabel = decoded.encoding.label,
            lineCount = decoded.lines.size, charCount = decoded.charCount
        )
        return ViewerUiState.TextContent(metadata, decoded.lines, decoded.truncated)
    }

    private fun openUnknown(context: Context, basic: OpenedFile): ViewerUiState {
        val dump = UnknownContentReader.readHexDump(context, basic.uri)
        val metadata = FileMetadata(file = basic, typeLabel = "Unknown binary file")
        return ViewerUiState.UnknownBinaryContent(metadata, dump.lines, dump.truncated)
    }
}
