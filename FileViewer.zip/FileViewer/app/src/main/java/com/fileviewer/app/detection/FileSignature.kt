package com.fileviewer.app.detection

/** Raster image formats we can attempt to decode, detected by magic bytes rather than extension. */
enum class ImageSignature { PNG, JPEG, GIF, BMP, WEBP, HEIF, AVIF, NETPBM, NONE }

/**
 * Sniffs the first bytes of a file to determine its real type, independent of
 * (and more trustworthy than) its extension — per the "never reject a file just
 * because its extension is unfamiliar" requirement.
 */
object FileSignature {

    fun detect(header: ByteArray): ImageSignature {
        if (header.size >= 8 &&
            header[0] == 0x89.toByte() && header[1] == 0x50.toByte() && header[2] == 0x4E.toByte() &&
            header[3] == 0x47.toByte() && header[4] == 0x0D.toByte() && header[5] == 0x0A.toByte() &&
            header[6] == 0x1A.toByte() && header[7] == 0x0A.toByte()
        ) return ImageSignature.PNG

        if (header.size >= 3 &&
            header[0] == 0xFF.toByte() && header[1] == 0xD8.toByte() && header[2] == 0xFF.toByte()
        ) return ImageSignature.JPEG

        if (matchesAscii(header, 0, "GIF87a") || matchesAscii(header, 0, "GIF89a")) {
            return ImageSignature.GIF
        }

        if (header.size >= 2 && header[0] == 'B'.code.toByte() && header[1] == 'M'.code.toByte()) {
            return ImageSignature.BMP
        }

        if (header.size >= 12 && matchesAscii(header, 0, "RIFF") && matchesAscii(header, 8, "WEBP")) {
            return ImageSignature.WEBP
        }

        // ISO base media file format "ftyp" box, used by both HEIF/HEIC and AVIF.
        if (header.size >= 12 && matchesAscii(header, 4, "ftyp")) {
            val brand = if (header.size >= 12) String(header, 8, 4, Charsets.US_ASCII) else ""
            return when (brand) {
                "avif", "avis" -> ImageSignature.AVIF
                "heic", "heix", "heim", "heis", "hevc", "hevm", "hevs", "mif1", "msf1" -> ImageSignature.HEIF
                else -> ImageSignature.NONE
            }
        }

        // Netpbm: ASCII magic "P1".."P6" followed by whitespace.
        if (header.size >= 3 && header[0] == 'P'.code.toByte() &&
            (header[1].toInt() and 0xFF) in '1'.code..'6'.code &&
            header[2].toInt().toChar().isWhitespace()
        ) return ImageSignature.NETPBM

        return ImageSignature.NONE
    }

    private fun matchesAscii(bytes: ByteArray, offset: Int, ascii: String): Boolean {
        if (offset + ascii.length > bytes.size) return false
        for (i in ascii.indices) {
            if (bytes[offset + i] != ascii[i].code.toByte()) return false
        }
        return true
    }

    /**
     * Heuristic "is this probably readable text" check over a sample of bytes.
     * We look for a null byte (a strong binary signal) and for a high ratio of
     * non-printable control characters. Not a substitute for real encoding
     * detection — see EncodingDetector — just a fast binary/text gate.
     */
    fun looksLikeText(sample: ByteArray): Boolean {
        if (sample.isEmpty()) return true
        var suspicious = 0
        for (b in sample) {
            val v = b.toInt() and 0xFF
            if (v == 0) return false // NUL byte essentially never appears in real text
            val isControl = v < 0x20 && v != 0x09 && v != 0x0A && v != 0x0D
            if (isControl) suspicious++
        }
        return suspicious.toDouble() / sample.size < 0.02
    }

    /** Quick textual sniff for SVG content that may arrive without a reliable extension/MIME type. */
    fun looksLikeSvg(sampleText: String): Boolean {
        val head = sampleText.trimStart().take(1024)
        return head.contains("<svg", ignoreCase = true) &&
            (head.startsWith("<svg", ignoreCase = true) || head.contains("<?xml", ignoreCase = true) || head.contains("<!DOCTYPE svg", ignoreCase = true))
    }
}
