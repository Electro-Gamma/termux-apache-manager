package com.fileviewer.app.markdown

import android.content.Context
import io.noties.markwon.Markwon
import io.noties.markwon.ext.strikethrough.StrikethroughPlugin
import io.noties.markwon.ext.tables.TablePlugin
import io.noties.markwon.ext.tasklist.TaskListPlugin
import io.noties.markwon.html.HtmlPlugin
import io.noties.markwon.linkify.LinkifyPlugin

/**
 * Builds the shared Markwon instance used to render GitHub-Flavored Markdown.
 *
 * Markwon renders CommonMark/GFM to native Android Spannables — there is no WebView
 * and no JavaScript execution anywhere in this path, which is what keeps rendering
 * of untrusted markdown/inline-HTML content safe by construction rather than by
 * sanitization alone (HtmlPlugin still only allows a constrained, non-executable
 * subset of HTML tags to affect Spannable styling).
 */
object MarkwonFactory {
    fun create(context: Context): Markwon {
        return Markwon.builder(context)
            .usePlugin(TablePlugin.create(context))
            .usePlugin(StrikethroughPlugin.create())
            .usePlugin(TaskListPlugin.create(context))
            .usePlugin(HtmlPlugin.create())
            .usePlugin(LinkifyPlugin.create())
            .build()
    }
}
