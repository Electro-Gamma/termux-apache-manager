# This is a read-only viewer app; R8/ProGuard shrinking is disabled for the debug
# build produced by the Colab pipeline (isMinifyEnabled = false). These rules only
# apply if a minified release build is built later.
-keep class com.fileviewer.app.model.** { *; }
-dontwarn org.jsoup.**
