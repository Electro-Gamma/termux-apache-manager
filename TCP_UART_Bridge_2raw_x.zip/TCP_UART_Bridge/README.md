# TCP UART Bridge

Turns an Android phone into a non-root USB-Serial ↔ TCP bridge. Plug a
CH340 / CP2102 / FTDI FT232 / PL2303 adapter (or an ESP32 board with native
USB CDC-ACM) into the phone's USB-C/OTG port, start the bridge, and connect
to `phone_ip:3333` from anywhere on the same network — including
`esptool.py` for wireless ESP32 flashing.

**Note on this delivery:** this is a complete, ready-to-build Android
Studio project (Gradle config, manifest, Kotlin sources, resources). It was
generated in an environment with no Android SDK and no network access, so
no `.apk` binary is included — you'll need to build it with the steps
below. The Gradle config is set up so the built file is literally named
`TCP_UART_Bridge.apk`.

**On the RFC2217 implementation specifically:** the Telnet/RFC2217
byte-stream framing (option negotiation, IAC escaping, subnegotiation
parsing) was written and unit-tested standalone against a battery of
cases — negotiation handshakes, embedded 0xFF bytes, and arbitrary chunk
splitting — before being ported into this Kotlin project, and the reset
logic mirrors Espressif's own `esp_rfc2217_server.py` line for line. The
same no-SDK/no-network environment means none of this has been through an
actual Android build or real hardware, so treat each change below as
logically reviewed, not hardware-verified.

**Changes in this round**, based on real testing feedback:
- **Confirmed fix, from your own test**: pre-setting the UART Settings baud
  rate to match `--baud` before starting the bridge (so the RFC2217
  negotiation is a no-op - the value already matches, so no hardware
  `setParameters()` call happens at all) made a 921600/1500000 flash finish
  in ~25 seconds with no stall. That's strong evidence the RFC2217 stall
  really was `setParameters()`'s own cost, not something fixable in this
  app's protocol handling - the practical fix is avoiding that call
  whenever possible, which is exactly what **Raw (auto-baud)** already
  does by design (see below) and what the two new features below extend
  to cover the workflow around it.
- **Re-added BW16/AmebaD support** - properly scoped this time. A third
  **Target Chip** option, **BW16 / AmebaD (auto reset)**, runs the exact
  reset-to-download-mode sequence from your `upload_amebad.py`
  (`enter_download_mode()`/`set_dtr_rts()`, see `ResetSequences.kt`) for
  the manual button and the new automatic trigger below. It's deliberately
  **not** wired into RFC2217's SET-CONTROL interception this time (see
  `Rfc2217Session.kt`'s class doc) - that's what caused it to misfire and
  get pulled last time. For RFC2217, BW16 behaves like Generic: direct
  passthrough, so a real BW16 client (`upload_amebad.py` with `--auto`
  over `rfc2217://`) driving its own reset still works, without this app's
  ESP32-shaped heuristics second-guessing it.
- **Added automatic reset-on-connect/disconnect for Raw and Raw-autobaud
  modes.** When the first client connects, the app now runs the selected
  chip's bootloader/download-mode entry sequence automatically - before
  any data flows, and before Raw-autobaud's baud-rate sniffing would ever
  see a `CHANGE_BAUDRATE` command - so `esptool`'s (or `upload_amebad.py`'s)
  initial sync succeeds without a manual button press first. When the last
  client disconnects, it runs a normal reset (so the newly-flashed
  firmware starts running, matching esptool's own default
  `--after hard-reset`) and, for Raw-autobaud specifically, resets the
  UART back to 115200 baud - fixing the exact problem from your last test,
  where a `socket://` session stayed stuck at 1500000 after the upload
  finished. None of this applies to RFC2217 (which already gets a correct
  reset from the client's own DTR/RTS commands - adding a second one here
  would race with it) or to **Generic** (still pure passthrough, no
  automatic behavior at all, by design). See `triggerAutoReset()` in
  `BridgeService.kt`.
- **Added `ResetSequences.kt`**, a single shared module for every chip's
  DTR/RTS pulse timing - used by `Rfc2217Session`'s automatic ESP32
  detection, the manual reset button, and the new automatic trigger above.
  Previously each of those had its own copy of the same timing logic,
  which is exactly the kind of duplication that let a real bug (DTR set
  after releasing RTS instead of before, in one earlier copy but not
  another) go unnoticed for a while - consolidating removes that risk
  going forward.
- **Removed BW16/AmebaD-specific support.** The dedicated `upload_amebad.py`
  reset sequence and its "BW16 / AmebaD" dropdown entry are gone. **Target
  Chip** is now just **ESP32 (auto reset)** or **Generic (manual
  RTS/DTR)** - Generic relays whatever DTR/RTS the client sends straight
  through with no canned timing, and is the fallback path (alongside the
  manual RTS/DTR switches, which are unchanged) for any board whose reset
  behavior doesn't match ESP32's. If the automatic ESP32 sequence fails on
  your hardware, switch to Generic or just drive the switches by hand -
  see "Target Chip: Generic (manual RTS/DTR) fallback" below.
- **The RFC2217 baud-change stall fix from the previous round didn't
  resolve it in testing.** The `PURGE_DATA` fix (a few bullets down) is
  still in place - it was a genuine bug regardless - but since it didn't
  fix the actual stall, this round takes a different approach for anyone
  who hit that: a new **Raw (auto-baud)** protocol mode (below) that gets
  you `esptool --baud` support without RFC2217 at all, sidestepping that
  code path entirely rather than continuing to chase it blind. If you can
  share an esptool `--trace` log next time (`esptool --trace --port ...
  write-flash ... 2>&1 | tee trace.log`), that would show exactly which
  command is stalling and make the RFC2217 path fixable for real instead
  of by inference.
- **Added a "Raw (auto-baud)" protocol mode.** Behaves like plain Raw
  (byte passthrough, no control channel) but watches the wire for
  esptool's own `CHANGE_BAUDRATE` command - the same in-band mechanism
  esptool always uses to actually change speed on the chip - and retunes
  the local UART to match, live, mid-session. So `--baud` works over a
  plain `socket://` connection without needing RFC2217 (or its option
  negotiation / SET_CONTROL / SET_BAUDRATE round-trips) at all. Always
  opens at 115200 (matches the ESP ROM/stub loader's fixed initial-sync
  speed) - see "Raw (auto-baud)" below for details and caveats.
- **Added higher baud rates**, up to `5000000` (5 Mbps), to the Baud Rate
  dropdown - useful for adapters that support it (FT232H, some CP2102N/
  CH9102 boards) regardless of which protocol mode you're using.
- **Fixed a long stall (many seconds) right after an RFC2217 baud-rate
  change** - e.g. esptool's "Changing baud rate to 921600... Changed."
  followed by a long pause before flashing actually starts, on any chip.
  Root cause: `PURGE_DATA` (RFC2217 section 3.7) was implemented as a fake
  acknowledgement that didn't actually discard anything. esptool/pyserial
  call the equivalent of this (`reset_input_buffer()`) right around a
  baud-rate change to get a clean slate; with the old no-op, whatever was
  still sitting in this app's per-client outbound queue at that moment
  (the tail of a burst captured at the old baud, or a stray byte from the
  reset pulse) got delivered right as esptool expected a fresh response,
  which desynced its sync/retry state machine and forced it to burn
  through several retry timeouts before recovering on its own - that's
  the ~20 second stall. Fixed by actually draining the queued backlog on
  `PURGE_DATA`, and proactively on every baud-rate change and reset pulse
  even when the client doesn't explicitly ask. See `handlePurgeData` /
  `handleSetBaudrate` in `Rfc2217Session.kt` and `purgeOutboundQueue()` in
  `TcpServerManager.kt`. **As noted above, this didn't fix the stall in
  testing** - it's still correct/worth keeping, but treat the RFC2217 path
  as still having an open, not-yet-diagnosed issue; see **Raw (auto-baud)**
  for a working alternative in the meantime.
- **Fixed data corruption on high-baud reads** (`read-flash` at 921600
  returning truncated/corrupt data). Root cause: incoming UART bytes were
  broadcast to the TCP socket directly from the USB driver's read-callback
  thread, so any momentary stall in the (blocking) socket write backed up
  into the USB hardware FIFO and silently dropped bytes. Fixed by routing
  all outgoing socket writes through a per-client queue drained by a
  separate coroutine, so the USB read thread never blocks on network I/O.
  See `TcpServerManager.kt`.
- **Moved the Start/Stop button** off the system nav bar using proper
  window-insets handling (the app targets Android 15, where edge-to-edge
  is enforced, so a fixed margin alone isn't reliable across devices).
- **Re-verified the ESP32 manual "Reset to Bootloader" sequence** byte-for-
  byte against `esptool/reset.py`'s `ClassicReset` again — it already
  matches exactly (DTR before releasing RTS, 100ms/50ms delays). Added
  timestamped step-by-step logging to the app's log panel so a mismatch
  between intended and actual behavior is visible if it still doesn't work
  - if it's still just doing a normal reset with this build, that most
    likely means a wiring/adapter-chip polarity difference on your
    specific hardware rather than a sequence bug; the log will help narrow
    it down (see "Troubleshooting the ESP32 reset button" below).

## Project layout

```
TCP_UART_Bridge/
├── build.gradle, settings.gradle, gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
└── app/
    ├── build.gradle
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/tcpuartbridge/app/
        │   ├── MainActivity.kt        — UI, USB permission flow, service binding
        │   ├── BridgeService.kt       — foreground service, notification, RTS/DTR
        │   ├── UsbSerialManager.kt    — usb-serial-for-android wrapper
        │   ├── TcpServerManager.kt    — multi-client TCP server (raw + RFC2217 modes)
        │   ├── Rfc2217Protocol.kt     — Telnet/RFC2217 byte-stream codec
        │   ├── Rfc2217Session.kt      — per-client RFC2217 session + reset-sequence logic
        │   ├── EspBaudRateSniffer.kt  — in-band esptool CHANGE_BAUDRATE detection for Raw (auto-baud)
        │   └── BridgeStatus.kt        — shared status model
        └── res/                       — layout, strings, colors, icons, USB device filter
```

## Build instructions

### Option A — Android Studio (recommended)
1. Install **Android Studio Ladybug (2024.2) or newer**, with JDK 17 and
   Android SDK Platform 35 installed via the SDK Manager.
2. `File → Open`, select the `TCP_UART_Bridge` folder.
3. Android Studio will detect there's no Gradle wrapper jar and offer to
   generate one — accept it (or it will regenerate automatically on sync).
4. Let Gradle sync. It needs internet access once, to pull dependencies
   from Google's Maven, Maven Central, and **JitPack** (for
   `com.github.mik3y:usb-serial-for-android`).
5. `Build → Build App Bundle(s) / APK(s) → Build APK(s)`.
6. Output: `app/build/outputs/apk/debug/TCP_UART_Bridge.apk`.

For a release build (`Build → Generate Signed Bundle / APK → APK`),
you'll need to create/select a signing keystore — Android Studio walks
you through this.

### Option B — Command line
```bash
cd TCP_UART_Bridge
gradle wrapper --gradle-version 8.7   # only needed once, to create gradlew
./gradlew assembleDebug
# → app/build/outputs/apk/debug/TCP_UART_Bridge.apk
```
Requires JDK 17 and `ANDROID_HOME`/`ANDROID_SDK_ROOT` pointing at an SDK
with Platform 35 and Build-Tools installed.

## Using it

1. Plug in a USB-serial adapter (with a USB-OTG cable/adapter if your
   phone doesn't have USB-C host support built in).
2. Open the app, grant the USB permission popup, and it appears in the
   device dropdown with its detected chip type.
3. Pick baud rate / data bits / stop bits / parity, a **Protocol**
   (RFC2217 for automatic esptool resets, Raw for a plain byte pipe, or
   Raw (auto-baud) for a plain byte pipe that still follows esptool's
   `--baud` - see "ESP32 flashing over the network" below), a **Target
   Chip** (**ESP32 (auto reset)** for esptool's timed reset sequence, or
   **Generic (manual RTS/DTR)** for direct passthrough), set the TCP port
   (default `3333`), and tap **Start Bridge**. The IP address and port to
   connect to are shown on screen and in the persistent notification.
4. In either Raw mode, connect from a PC with `nc phone_ip 3333`, PuTTY
   (raw socket), or any TCP client - everything you send goes out the
   UART TX pin, everything the UART RX pin receives comes back to you. In
   RFC2217 mode, point esptool (or any RFC2217-capable client) at
   `rfc2217://phone_ip:3333?ign_set_control` instead - see below.

The service is declared as a `connectedDevice` foreground service, so it
keeps running with the screen off, and Android won't kill it for being in
the background.

## ESP32 flashing over the network

Wire the adapter's control lines the same way a standard ESP32 dev board's
auto-program circuit does:
- **RTS → EN / RESET**
- **DTR → GPIO0 / BOOT**

The app now supports three TCP protocols, picked from the **Protocol**
dropdown before you tap **Start Bridge**:

### RFC2217 (automatic reset - has a known unresolved stall issue)

The app speaks RFC 2217 (Telnet COM-Port-Control), the same protocol
Espressif's own `esp_rfc2217_server.py` uses. esptool's DTR/RTS reset
commands travel over the TCP connection and this app drives real,
correctly-timed reset pulses on the actual USB adapter - no manual
button-pressing needed.

```bash
esptool --port "rfc2217://PHONE_IP:PORT?ign_set_control" --baud 460800 write-flash 0x1000 firmware.bin
```

The `?ign_set_control` suffix tells esptool's RFC2217 client not to wait
for/require an acknowledgement on every single control-line command -
this app does send one, but keeping this flag matches Espressif's own
server's documented usage and avoids any edge-case stalls.

Why not just relay every DTR/RTS command as it arrives? esptool's reset
sequences need millisecond-precision timing between DTR and RTS
transitions, and relaying each command individually over Wi-Fi adds
unpredictable jitter that breaks it. Instead - mirroring
`esp_rfc2217_server.py`'s own approach - the app detects the *start* of a
reset sequence and then runs a precisely-timed sequence locally, ignoring
the redundant follow-up commands the client sends as part of the same
sequence. See the comment at the top of `Rfc2217Session.kt` for details.

**Known issue:** a long stall (~20s) right after the baud-rate change, in
testing, that a previous fix attempt (`PURGE_DATA`, still in the code -
see the changelog) didn't resolve. If you hit this, either try **Raw
(auto-baud)** below (works around it entirely, but no auto-reset), or - if
you want RFC2217's auto-reset specifically and are up for helping pin
this down - capture `esptool --trace ... 2>&1 | tee trace.log` next time
and share it; that log shows exactly which command/response is stalling,
which is enough to fix it for real.

### Raw (auto-baud)

Plain byte passthrough like Raw below (no control-line channel, still
needs the **Reset to Bootloader** button or RTS/DTR switches before
flashing), but this app watches the wire for esptool's own in-band
`CHANGE_BAUDRATE` command - the same mechanism esptool always uses to
actually change the chip's speed, regardless of transport - and retunes
the local UART to match, live, mid-session. So `--baud` works over a
plain socket without RFC2217's option negotiation/SET_CONTROL/
SET_BAUDRATE round-trips (and without hitting the stall above).

```bash
esptool --port socket://PHONE_IP:PORT --baud 921600 --before no-reset --after no-reset write-flash 0x1000 firmware.bin
```

Always opens the port at 115200 - that's what the ESP ROM/stub loader
itself always expects for the initial SYNC handshake, matching what
esptool does on its end regardless of your `--baud` value (it syncs at
115200 first, then requests the higher speed in-band). The **Baud Rate**
spinner is ignored in this mode for that reason; data bits/stop bits/
parity from it still apply. See `EspBaudRateSniffer.kt` for exactly how
this is detected, and the caveats there.

### Raw (manual reset)

Plain byte passthrough - works with any TCP client (`nc`, PuTTY raw
socket), but a plain socket has no channel for control lines *or* baud
rate at all, so esptool can't reset the chip remotely over it, and the
UART stays at whatever you picked in **UART Settings** for the whole
session (see "Raw mode always flashes at your configured UART baud"
below). Use **Raw (auto-baud)** above instead if you want `--baud` to
actually take effect without switching to RFC2217.

```bash
esptool --port socket://PHONE_IP:PORT --baud 460800 --before no-reset --after no-reset write-flash 0x1000 firmware.bin
```

Use the **Reset to Bootloader** button (or the RTS/DTR switches) in the
app to put the board in bootloader mode before flashing in this mode.

### Troubleshooting the ESP32 reset button

The manual sequence (DTR low → RTS high → wait → DTR high + RTS low →
wait → DTR low) matches `esptool/reset.py`'s `ClassicReset` exactly - this
was re-checked byte-for-byte against your esptool source. Tapping the
button now logs each step with a timestamp, e.g.:
```
[+0ms] ESP32 reset: DTR=0 (IO0=HIGH), RTS=1 (EN=LOW, reset)
[+101ms] DTR=1 (IO0=LOW), RTS=0 (EN=HIGH, exits reset -> should sample IO0 LOW -> bootloader)
[+151ms] DTR=0 (IO0=HIGH, done)
```
If the board still just does a normal reset (boots the running app)
instead of entering the bootloader with this exact sequence, the most
likely explanations are hardware-side, not app logic:
- **Wiring**: confirm RTS→EN and DTR→GPIO0 specifically (not swapped).
- **Adapter chip driver quirk**: `usb-serial-for-android`'s DTR/RTS
  handling has historically had chip-specific quirks (particularly some
  CH340/CH341 clones). Worth testing: does the *same* adapter/board work
  with real esptool + a PC over an actual serial cable? If yes there but
  not through this app, it narrows the problem to the Android USB driver
  for that specific chip.
- If you can share which adapter chip you're using (CH340/CP210x/FTDI/
  PL2303) and whether the PC+cable path works, that'll help pin down
  whether this needs a driver-level workaround.

## Target Chip: ESP32 / BW16 / Generic

Three options in the **Target Chip** dropdown, governing both the manual
reset button and (for Raw/Raw-autobaud) the automatic reset-on-connect/
disconnect described above:

- **ESP32 (auto reset)** - esptool's `ClassicReset`/`HardReset` timing
  (see `ResetSequences.esp32BootloaderEntry`/`esp32HardReset`).
- **BW16 / AmebaD (auto reset)** - `upload_amebad.py`'s
  `enter_download_mode()`/`reset_to_boot()` timing (see
  `ResetSequences.bw16DownloadModeEntry`/`bw16NormalReset`).
- **Generic (manual RTS/DTR)** - no board-specific logic at all, so
  there's nothing here to keep in sync as your hardware lineup changes.
  Use this for anything that doesn't follow either sequence above:
  - In **RFC2217** mode, every DTR/RTS SET-CONTROL command from the client
    is relayed straight through to the hardware immediately, in the order
    it arrives, with no sequence detection/substitution. If your board's
    own flashing tool drives DTR/RTS with its own timing, that timing is
    preserved as-is.
  - In **Raw**/**Raw-autobaud** mode, or for a one-off manual reset in any
    mode, use the **RTS**/**DTR** switches (or the "Reset to Bootloader"
    button, which just logs a note in Generic mode - there's no canned
    sequence to run) to drive the lines by hand.

This is also the fallback if the **ESP32** or **BW16** sequence doesn't
work on a given board or adapter: switch to Generic, or just use the
RTS/DTR switches directly, without needing to restart the bridge.

## Raw mode always flashes at your configured UART baud

This applies to plain **Raw (manual reset)** specifically - see **Raw
(auto-baud)** above if you want `--baud` to actually work without RFC2217.

A plain TCP socket (`socket://`) has no control channel at all - not just
for DTR/RTS (see above), but for baud rate too. `esptool` can't ask a raw
socket to change speed mid-session the way it does over RFC2217, so in
plain Raw mode the UART stays at whatever baud you picked in **UART
Settings** before hitting **Start Bridge** for the entire session - that's
the "connects fast but uploads at 115200" behavior. To flash at a higher
speed over plain Raw, set the **Baud Rate** spinner itself to the speed
you want (e.g. `921600`) before starting the bridge, and pass a matching
`--baud` to esptool - or use **Raw (auto-baud)** or **RFC2217** instead,
where the speed change happens automatically.

Note this doesn't apply to **Raw (auto-baud)**: that mode always opens at
115200 and retunes itself live from whatever `esptool` actually requests,
so there's no need to pre-set the spinner there - and once the last client
disconnects, it now resets back to 115200 automatically too (see
"Added automatic reset-on-connect/disconnect" above), so the UART doesn't
stay stuck at whatever speed the previous session left it at.

## Permissions requested

| Permission | Why |
|---|---|
| USB host feature | Talk to the serial adapter over USB |
| `INTERNET` | Run the TCP server |
| `ACCESS_NETWORK_STATE` / `ACCESS_WIFI_STATE` | Show the phone's IP address |
| `FOREGROUND_SERVICE` / `FOREGROUND_SERVICE_CONNECTED_DEVICE` | Keep bridging with the screen off |
| `POST_NOTIFICATIONS` | Show the status notification (Android 13+) |

## Supported chips

CH340/CH341, CP2102/CP210x, FTDI FT232, PL2303, and CDC-ACM (including
ESP32-S2/S3/C3 native USB). `app/src/main/res/xml/device_filter.xml` lists
the known VID/PID pairs used for auto-launch-on-attach; add more there if
you have a specific adapter that isn't recognized automatically — the
underlying `usb-serial-for-android` prober will still find any of the five
supported chip families even if they're not listed there, that file only
controls whether Android auto-opens the app when the device is plugged in.

Target range: Android 8.0 (API 26) through current Android releases.
