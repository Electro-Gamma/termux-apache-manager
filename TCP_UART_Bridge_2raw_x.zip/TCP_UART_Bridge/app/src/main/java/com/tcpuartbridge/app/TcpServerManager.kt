package com.tcpuartbridge.app

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.CopyOnWriteArrayList

enum class ServerMode { RAW, RAW_AUTOBAUD, RFC2217 }

/**
 * A minimal multi-client TCP server. Every connected client receives every
 * byte that arrives from the UART (RX broadcast), and anything a client
 * sends is forwarded to the UART (TX). Nagle's algorithm is disabled on
 * every socket to keep latency low, which matters for esptool.py's
 * socket:// transport.
 *
 * In [ServerMode.RFC2217], every client's byte stream is instead run
 * through an [Rfc2217Session] (Telnet + RFC2217 COM-Port-Control), which
 * unwraps plain data before it reaches the UART, answers option
 * negotiation/subnegotiation on the client's behalf, and drives real
 * DTR/RTS resets. See [Rfc2217Session] for why resets are handled locally
 * rather than by naively relaying each control-line command.
 *
 * In [ServerMode.RAW_AUTOBAUD], bytes are relayed exactly like
 * [ServerMode.RAW] (no protocol wrapping, no reset control) - but an
 * [EspBaudRateSniffer] passively watches the same bytes for esptool's own
 * in-band CHANGE_BAUDRATE command and retunes the local UART to match, so
 * `--baud` works over a plain `socket://` without needing RFC2217 at all.
 * See [EspBaudRateSniffer] for why/how.
 *
 * IMPORTANT: [broadcast] is called directly from the USB driver's read
 * callback thread (see UsbSerialManager/SerialInputOutputManager). It must
 * never block on network I/O - if a socket write stalls even briefly, that
 * would back up into the USB hardware FIFO and silently drop incoming UART
 * bytes (this is what caused corrupted high-baud-rate flash reads). So the
 * actual socket write happens on a separate per-client coroutine, fed by an
 * unbounded [Channel]; [broadcast]/[send] only ever do a non-blocking enqueue.
 */
class TcpServerManager {

    private var serverSocket: ServerSocket? = null
    private val clients = CopyOnWriteArrayList<ClientHandler>()
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var acceptJob: Job? = null
    private var mode: ServerMode = ServerMode.RAW
    private var rfc2217Control: Rfc2217ControlBridge? = null
    private var targetChip: TargetChip = TargetChip.ESP32

    var onDataFromClient: ((ByteArray) -> Unit)? = null
    var onClientConnected: ((String) -> Unit)? = null
    var onClientDisconnected: ((String) -> Unit)? = null
    var onError: ((Exception) -> Unit)? = null
    /** Fired from [ServerMode.RAW_AUTOBAUD] whenever [EspBaudRateSniffer] detects and applies a baud-rate switch. */
    var onAutoBaudChanged: ((Int) -> Unit)? = null

    val clientCount: Int
        get() = clients.size

    fun start(
        port: Int,
        mode: ServerMode = ServerMode.RAW,
        rfc2217Control: Rfc2217ControlBridge? = null,
        targetChip: TargetChip = TargetChip.ESP32
    ) {
        this.mode = mode
        this.rfc2217Control = rfc2217Control
        this.targetChip = targetChip
        val socket = ServerSocket(port)
        serverSocket = socket
        acceptJob = scope.launch {
            try {
                while (isActive) {
                    val client = socket.accept()
                    client.tcpNoDelay = true
                    val handler = ClientHandler(client)
                    clients.add(handler)
                    onClientConnected?.invoke(client.inetAddress.hostAddress ?: "unknown")
                    handler.start()
                }
            } catch (e: Exception) {
                if (isActive) onError?.invoke(e)
            }
        }
    }

    /**
     * Raw UART RX bytes, broadcast to every connected client (IAC-escaped
     * first in RFC2217 mode). Called directly on the USB read thread -
     * must return immediately, see class doc.
     */
    fun broadcast(data: ByteArray) {
        val toSend = if (mode == ServerMode.RFC2217) Rfc2217Encoder.escapeData(data) else data
        clients.forEach { it.send(toSend) }
    }

    fun stop() {
        acceptJob?.cancel()
        clients.forEach { it.close(notify = false) }
        clients.clear()
        try {
            serverSocket?.close()
        } catch (_: Exception) {
        }
        serverSocket = null
    }

    private inner class ClientHandler(private val socket: Socket) {
        private var readJob: Job? = null
        private var writeJob: Job? = null
        private val remoteAddress = socket.inetAddress?.hostAddress ?: "unknown"
        private val out = socket.getOutputStream()

        // Unbounded on purpose: the producer side (broadcast(), called from the USB
        // read thread) must never block or drop data. In practice this stays small -
        // it only grows if the TCP receiver momentarily can't keep up - and even a
        // full 4MB flash read sitting in memory for a moment is trivial on a phone.
        private val writeChannel = Channel<ByteArray>(capacity = Channel.UNLIMITED)

        private val rfc2217Session: Rfc2217Session? = rfc2217Control?.takeIf { mode == ServerMode.RFC2217 }?.let {
            Rfc2217Session(
                control = it,
                scope = scope,
                targetChip = targetChip,
                onDecodedData = { data -> onDataFromClient?.invoke(data) },
                sendToClient = { bytes -> send(bytes) },
                onPurge = { rx, _ -> if (rx) purgeOutboundQueue() }
            )
        }

        private val baudSniffer: EspBaudRateSniffer? = rfc2217Control?.takeIf { mode == ServerMode.RAW_AUTOBAUD }?.let { control ->
            EspBaudRateSniffer { newBaud ->
                control.reconfigure(baudRate = newBaud)
                onAutoBaudChanged?.invoke(newBaud)
            }
        }

        fun start() {
            rfc2217Session?.sendInitialOffer()

            writeJob = scope.launch {
                try {
                    for (data in writeChannel) {
                        out.write(data)
                        out.flush()
                    }
                } catch (_: Exception) {
                    close(notify = true)
                }
            }

            readJob = scope.launch {
                try {
                    val input = socket.getInputStream()
                    val buffer = ByteArray(4096)
                    while (isActive) {
                        val len = input.read(buffer)
                        if (len == -1) break
                        val session = rfc2217Session
                        if (session != null) {
                            session.feed(buffer, len)
                        } else {
                            baudSniffer?.watchFromHost(buffer, len)
                            onDataFromClient?.invoke(buffer.copyOf(len))
                        }
                    }
                } catch (_: Exception) {
                    // connection dropped or reset - fall through to cleanup
                } finally {
                    close(notify = true)
                }
            }
        }

        /** Non-blocking: only ever enqueues. Safe to call from the USB read thread. */
        fun send(data: ByteArray) {
            baudSniffer?.watchFromChip(data, data.size)
            writeChannel.trySend(data)
        }

        /**
         * Drops any bytes already queued to be written to this client but not
         * yet sent - see [Rfc2217Session]'s PURGE_DATA handling and the
         * proactive purges after a baud-rate change / reset pulse. There's an
         * inherent small race against [broadcast] enqueueing new bytes
         * concurrently from the USB read thread (a byte captured in the same
         * instant as the purge could be dropped too) - acceptable here since
         * the same race exists on a real UART purge, and the alternative
         * (leaving stale bytes queued for delivery right when esptool expects
         * a fresh response) is the actual bug being fixed.
         */
        fun purgeOutboundQueue() {
            while (writeChannel.tryReceive().isSuccess) {
                // drain
            }
        }

        fun close(notify: Boolean) {
            writeChannel.close()
            try {
                socket.close()
            } catch (_: Exception) {
            }
            readJob?.cancel()
            writeJob?.cancel()
            if (clients.remove(this) && notify) {
                onClientDisconnected?.invoke(remoteAddress)
            }
        }
    }
}
