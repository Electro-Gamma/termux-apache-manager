package com.tcpuartbridge.app

import android.Manifest
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.os.SystemClock
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.hoho.android.usbserial.driver.UsbSerialDriver
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.driver.UsbSerialProber
import com.tcpuartbridge.app.databinding.ActivityMainBinding
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private var bridgeService: BridgeService? = null
    private var bound = false
    private var drivers: List<UsbSerialDriver> = emptyList()
    private var selectedDriver: UsbSerialDriver? = null

    private val baudRates = intArrayOf(
        9600, 19200, 38400, 57600, 115200, 230400, 380400, 460800,
        500000, 921600, 1000000, 1382400, 1444400, 1500000,
        2000000, 2500000, 3000000, 3500000, 4000000, 4500000, 5000000
    )
    private val dataBitsOptions = intArrayOf(5, 6, 7, 8)
    private val stopBitsLabels = arrayOf("1", "1.5", "2")
    private val stopBitsValues = intArrayOf(UsbSerialPort.STOPBITS_1, UsbSerialPort.STOPBITS_1_5, UsbSerialPort.STOPBITS_2)
    private val parityLabels = arrayOf("None", "Odd", "Even", "Mark", "Space")
    private val parityValues = intArrayOf(
        UsbSerialPort.PARITY_NONE,
        UsbSerialPort.PARITY_ODD,
        UsbSerialPort.PARITY_EVEN,
        UsbSerialPort.PARITY_MARK,
        UsbSerialPort.PARITY_SPACE
    )
    private val protocolLabels = arrayOf("RFC2217 (automatic reset)", "Raw (manual reset)", "Raw (auto-baud)")
    private val protocolValues = arrayOf(ServerMode.RFC2217, ServerMode.RAW, ServerMode.RAW_AUTOBAUD)
    // BW16/AmebaD's reset-to-download-mode sequence, translated from upload_amebad.py, is used
    // by the automatic on-connect/on-disconnect trigger for Raw/Raw-autobaud modes (see
    // BridgeService.triggerAutoReset) and this tab's manual reset button. It's intentionally
    // NOT wired into RFC2217's SET-CONTROL interception (see Rfc2217Session's class doc) -
    // BW16 support there caused more problems than it solved, so for RFC2217 sessions this
    // selection just means "don't apply ESP32's sequence", same as Generic.
    private val targetChipLabels = arrayOf("ESP32 (auto reset)", "BW16 / AmebaD (auto reset)", "Generic (manual RTS/DTR)")
    private val targetChipValues = arrayOf(TargetChip.ESP32, TargetChip.BW16, TargetChip.GENERIC)

    private val serviceConnection = object : android.content.ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val localBinder = service as BridgeService.LocalBinder
            bridgeService = localBinder.getService()
            bound = true
            bridgeService?.setListener(bridgeListener)
            bridgeService?.getStatus()?.let { updateStatusUi(it) }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            bound = false
            bridgeService = null
        }
    }

    private val bridgeListener = object : BridgeListener {
        override fun onLog(message: String) {
            runOnUiThread { appendLog(message) }
        }

        override fun onStatusChanged(status: BridgeStatus) {
            runOnUiThread { updateStatusUi(status) }
        }
    }

    private val usbAttachReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                UsbManager.ACTION_USB_DEVICE_ATTACHED,
                UsbManager.ACTION_USB_DEVICE_DETACHED -> refreshDeviceList()
            }
        }
    }

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* no-op either way */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupSpinners()
        refreshDeviceList()
        applyBottomInsets()

        binding.btnRefreshDevices.setOnClickListener { refreshDeviceList() }
        binding.btnStartStop.setOnClickListener { onStartStopClicked() }
        binding.switchRts.setOnCheckedChangeListener { _, checked -> bridgeService?.setRTS(checked) }
        binding.switchDtr.setOnCheckedChangeListener { _, checked -> bridgeService?.setDTR(checked) }
        binding.btnAutoReset.setOnClickListener { performAutoReset() }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        val filter = IntentFilter().apply {
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(usbAttachReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(usbAttachReceiver, filter)
        }

        bindService(Intent(this, BridgeService::class.java), serviceConnection, Context.BIND_AUTO_CREATE)
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(usbAttachReceiver)
        if (bound) {
            bridgeService?.setListener(null)
            unbindService(serviceConnection)
            bound = false
        }
    }

    private var currentTargetChip = TargetChip.ESP32
    private var currentProtocolMode = ServerMode.RFC2217

    // ---- setup ------------------------------------------------------------

    private fun setupSpinners() {
        binding.spinnerBaud.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, baudRates.map { it.toString() }
        )
        binding.spinnerBaud.setSelection(baudRates.indexOf(115200))

        binding.spinnerDataBits.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, dataBitsOptions.map { it.toString() }
        )
        binding.spinnerDataBits.setSelection(dataBitsOptions.indexOf(8))

        binding.spinnerStopBits.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, stopBitsLabels
        )
        binding.spinnerStopBits.setSelection(0)

        binding.spinnerParity.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, parityLabels
        )
        binding.spinnerParity.setSelection(0)

        binding.spinnerTargetChip.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, targetChipLabels
        )
        binding.spinnerTargetChip.setSelection(0) // ESP32 by default
        binding.spinnerTargetChip.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                currentTargetChip = targetChipValues[position]
                refreshHints()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        binding.spinnerProtocol.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, protocolLabels
        )
        binding.spinnerProtocol.setSelection(0) // RFC2217 by default
        binding.spinnerProtocol.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                currentProtocolMode = protocolValues[position]
                refreshHints()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        refreshHints()
        binding.etTcpPort.setText("3333")
    }

    private fun refreshHints() {
        binding.tvProtocolHint.text = when (currentProtocolMode) {
            ServerMode.RFC2217 ->
                "RFC2217: esptool talks to this app directly and drives real, correctly-timed DTR/RTS resets. " +
                    "Use --port rfc2217://PHONE_IP:PORT?ign_set_control with esptool."
            ServerMode.RAW_AUTOBAUD ->
                "Raw (auto-baud): plain byte passthrough like Raw, but this app watches the wire for " +
                    "esptool's own CHANGE_BAUDRATE command and follows it, so --baud works over a plain " +
                    "socket:// without RFC2217. Always opens the port at 115200 first (data bits/stop " +
                    "bits/parity below still apply - the Baud Rate value itself is ignored in this mode). " +
                    "Still has no channel for remote reset control, same as Raw."
            else ->
                "Raw: plain byte passthrough, works with any TCP client " +
                    "(nc, PuTTY raw socket, esptool --port socket://...), but has no channel for remote reset control."
        }

        binding.tvEsp32Note.text = when {
            currentProtocolMode == ServerMode.RFC2217 && currentTargetChip == TargetChip.ESP32 ->
                "In RFC2217 mode, esptool resets the board automatically before/after flashing - you " +
                    "shouldn't need these manual switches. They're still here as a fallback: if the automatic " +
                    "sequence fails on your board, drive RTS/DTR by hand with the switches or this button."
            currentProtocolMode == ServerMode.RFC2217 ->
                // BW16 or Generic over RFC2217: passthrough, relies on the client driving its own reset.
                "DTR/RTS commands from the client are relayed straight through with no ESP32-style sequence " +
                    "timing - works if the client drives its own reset over RFC2217 (e.g. upload_amebad.py " +
                    "with --auto and a rfc2217:// port). Falls back to the RTS/DTR switches below otherwise."
            currentTargetChip == TargetChip.GENERIC ->
                "Generic mode: no automatic sequence is applied here, on connect/disconnect or otherwise. " +
                    "Use the RTS/DTR switches below as a manual fallback to put the board in bootloader/" +
                    "download mode by hand - useful for boards whose reset conventions don't match ESP32's."
            currentTargetChip == TargetChip.BW16 ->
                "Raw/Raw-autobaud + BW16: this app now drives BW16's own download-mode entry automatically " +
                    "when the first client connects, and a normal reset when the last one disconnects - " +
                    "matching upload_amebad.py's enter_download_mode()/reset_to_boot() timing. The button " +
                    "below runs the same download-mode sequence manually if you want to trigger it yourself."
            else ->
                "Raw/Raw-autobaud + ESP32: this app now drives the bootloader-entry sequence automatically " +
                    "when the first client connects, and a normal reset when the last one disconnects - you " +
                    "shouldn't need the button below for a typical esptool session anymore. It's still here " +
                    "for manual use, and Raw-autobaud also resets the UART back to 115200 baud once the last " +
                    "client disconnects, so the next session starts clean."
        }
    }

    private fun refreshDeviceList() {
        val usbManager = getSystemService(Context.USB_SERVICE) as UsbManager
        drivers = UsbSerialProber.getDefaultProber().findAllDrivers(usbManager)

        if (drivers.isEmpty()) {
            binding.spinnerDevices.adapter = ArrayAdapter(
                this, android.R.layout.simple_spinner_dropdown_item, listOf("No USB serial device found")
            )
            binding.tvUsbStatus.text = "USB: not connected"
            selectedDriver = null
            return
        }

        val labels = drivers.map { d ->
            val dev = d.device
            "${UsbChipIdentifier.name(dev.vendorId, dev.productId)}  (VID:${dev.vendorId} PID:${dev.productId})"
        }
        binding.spinnerDevices.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        binding.spinnerDevices.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedDriver = drivers.getOrNull(position)
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        selectedDriver = drivers.first()
        binding.tvUsbStatus.text = "USB: ${drivers.size} device(s) found"
    }

    // ---- start / stop -------------------------------------------------

    private fun onStartStopClicked() {
        val svc = bridgeService
        if (svc == null) {
            appendLog("Service not ready yet, please try again")
            return
        }

        if (svc.getStatus().running) {
            svc.stopBridge()
            return
        }

        val driver = selectedDriver
        if (driver == null) {
            appendLog("No USB serial device selected")
            return
        }

        val port = binding.etTcpPort.text.toString().toIntOrNull()
        if (port == null || port !in 1..65535) {
            appendLog("Invalid TCP port")
            return
        }

        val baud = baudRates[binding.spinnerBaud.selectedItemPosition]
        val dataBits = dataBitsOptions[binding.spinnerDataBits.selectedItemPosition]
        val stopBits = stopBitsValues[binding.spinnerStopBits.selectedItemPosition]
        val parity = parityValues[binding.spinnerParity.selectedItemPosition]
        val protocolMode = currentProtocolMode
        val targetChip = currentTargetChip

        val usbManager = getSystemService(Context.USB_SERVICE) as UsbManager
        if (!usbManager.hasPermission(driver.device)) {
            requestUsbPermission(driver) { granted ->
                if (granted) {
                    launchBridge(driver, baud, dataBits, stopBits, parity, port, protocolMode, targetChip)
                } else {
                    appendLog("USB permission denied")
                }
            }
        } else {
            launchBridge(driver, baud, dataBits, stopBits, parity, port, protocolMode, targetChip)
        }
    }

    private fun launchBridge(
        driver: UsbSerialDriver,
        baud: Int,
        dataBits: Int,
        stopBits: Int,
        parity: Int,
        port: Int,
        protocolMode: ServerMode,
        targetChip: TargetChip
    ) {
        ContextCompat.startForegroundService(this, Intent(this, BridgeService::class.java))
        bridgeService?.startBridge(driver, baud, dataBits, stopBits, parity, port, protocolMode, targetChip)
    }

    private fun requestUsbPermission(driver: UsbSerialDriver, callback: (Boolean) -> Unit) {
        val usbManager = getSystemService(Context.USB_SERVICE) as UsbManager
        val action = "com.tcpuartbridge.app.USB_PERMISSION"
        val mutabilityFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0
        val permissionIntent = PendingIntent.getBroadcast(
            this, 0, Intent(action).setPackage(packageName), mutabilityFlag
        )

        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                if (intent.action == action) {
                    unregisterReceiver(this)
                    callback(intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false))
                }
            }
        }
        val filter = IntentFilter(action)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(receiver, filter)
        }
        usbManager.requestPermission(driver.device, permissionIntent)
    }

    private fun performAutoReset() {
        val svc = bridgeService ?: return
        when (currentTargetChip) {
            TargetChip.ESP32 -> performEsp32BootloaderReset(svc)
            TargetChip.BW16 -> performBw16DownloadModeReset(svc)
            TargetChip.GENERIC -> appendLog(
                "Generic mode has no built-in auto-reset sequence - use the RTS/DTR switches above " +
                    "as the manual fallback to drive the lines by hand for your board's reset convention."
            )
        }
    }

    /** Classic ESP32 auto-reset-to-bootloader pulse sequence (DTR=GPIO0, RTS=EN) - mirrors esptool's ClassicReset. */
    private fun performEsp32BootloaderReset(svc: BridgeService) {
        val t0 = SystemClock.elapsedRealtime()
        lifecycleScope.launch {
            ResetSequences.esp32BootloaderEntry(svc.controlBridge) { msg ->
                appendLog("[+${SystemClock.elapsedRealtime() - t0}ms] $msg")
            }
            appendLog(
                "Sent bootloader reset sequence. If the board still boots normally instead of entering the " +
                    "bootloader, that's very likely a wiring/chip-driver polarity issue rather than sequence " +
                    "timing - the steps above match esptool's ClassicReset exactly."
            )
        }
    }

    /** BW16/AmebaD reset-to-download-mode sequence, translated from upload_amebad.py - see ResetSequences. */
    private fun performBw16DownloadModeReset(svc: BridgeService) {
        val t0 = SystemClock.elapsedRealtime()
        lifecycleScope.launch {
            ResetSequences.bw16DownloadModeEntry(svc.controlBridge) { msg ->
                appendLog("[+${SystemClock.elapsedRealtime() - t0}ms] $msg")
            }
            appendLog("Sent BW16/AmebaD download-mode reset sequence")
        }
    }

    /**
     * Adds the system navigation bar's height on top of the button's base XML
     * margin, so it never sits flush against gesture-nav or 3-button-nav
     * controls on any device (the fixed XML margin alone isn't enough on
     * devices with a tall nav bar).
     */
    private fun applyBottomInsets() {
        val baseMarginPx = (binding.btnStartStop.layoutParams as ViewGroup.MarginLayoutParams).bottomMargin
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { _, insets ->
            val navBarInset = insets.getInsets(WindowInsetsCompat.Type.systemBars()).bottom
            val params = binding.btnStartStop.layoutParams as ViewGroup.MarginLayoutParams
            params.bottomMargin = baseMarginPx + navBarInset
            binding.btnStartStop.layoutParams = params
            insets
        }
        ViewCompat.requestApplyInsets(binding.root)
    }

    // ---- UI updates -----------------------------------------------------

    private fun updateStatusUi(status: BridgeStatus) {
        binding.tvUsbStatus.text = if (status.usbConnected) "USB: ${status.deviceName}" else "USB: not connected"
        val modeLabel = when (status.protocolMode) {
            ServerMode.RFC2217 -> "RFC2217"
            ServerMode.RAW_AUTOBAUD -> "raw, auto-baud"
            ServerMode.RAW -> "raw"
        }
        binding.tvIpPort.text = "IP: ${status.ipAddress}   Port: ${status.tcpPort}   Protocol: $modeLabel"
        binding.tvClientCount.text = "Clients connected: ${status.clientCount}"
        binding.btnStartStop.text = if (status.running) getString(R.string.stop_bridge) else getString(R.string.start_bridge)
    }

    private fun appendLog(message: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        binding.tvLog.append("[$time] $message\n")
        binding.scrollLog.post { binding.scrollLog.fullScroll(View.FOCUS_DOWN) }
    }
}
