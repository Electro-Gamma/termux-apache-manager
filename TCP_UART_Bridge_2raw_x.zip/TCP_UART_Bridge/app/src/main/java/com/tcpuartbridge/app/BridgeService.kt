package com.tcpuartbridge.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Binder
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.hoho.android.usbserial.driver.UsbSerialDriver
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.net.Inet4Address
import java.net.NetworkInterface

/**
 * Foreground service that owns the live [UsbSerialManager] and
 * [TcpServerManager] instances and pipes data between them. Runs
 * independently of the Activity so the bridge keeps working with the
 * screen off, per the "connectedDevice" foreground service type declared
 * in the manifest.
 */
class BridgeService : Service() {

    private val binder = LocalBinder()
    private lateinit var usbSerial: UsbSerialManager
    private lateinit var tcpServer: TcpServerManager
    private var listener: BridgeListener? = null
    private var status = BridgeStatus()
    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var autoResetJob: Job? = null

    // Set once per startBridge() call, read by the onClientConnected/onClientDisconnected
    // auto-reset trigger below - not exposed outside this class, so plain vars are fine.
    private var activeProtocolMode: ServerMode = ServerMode.RAW
    private var activeTargetChip: TargetChip = TargetChip.ESP32

    private val rfc2217Control = object : Rfc2217ControlBridge {
        override fun setDTR(value: Boolean) = usbSerial.setDTR(value)
        override fun setRTS(value: Boolean) = usbSerial.setRTS(value)
        override fun reconfigure(baudRate: Int?, dataBits: Int?, stopBits: Int?, parity: Int?) {
            usbSerial.reconfigure(baudRate, dataBits, stopBits, parity)
        }
        override val currentBaudRate: Int get() = usbSerial.currentBaudRate
        override val currentDataBits: Int get() = usbSerial.currentDataBits
        override val currentStopBits: Int get() = usbSerial.currentStopBits
        override val currentParity: Int get() = usbSerial.currentParity
    }

    inner class LocalBinder : Binder() {
        fun getService(): BridgeService = this@BridgeService
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        usbSerial = UsbSerialManager(this)
        tcpServer = TcpServerManager()
        createNotificationChannel()

        usbSerial.onDataReceived = { data ->
            tcpServer.broadcast(data)
            listener?.onLog("RX ${data.size}B (UART -> TCP)")
        }
        usbSerial.onError = { e -> listener?.onLog("USB error: ${e.message}") }
        usbSerial.onLog = { msg -> listener?.onLog(msg) }

        tcpServer.onDataFromClient = { data ->
            usbSerial.write(data)
            listener?.onLog("TX ${data.size}B (TCP -> UART)")
        }
        tcpServer.onClientConnected = { addr ->
            status = status.copy(clientCount = tcpServer.clientCount)
            listener?.onLog("Client connected: $addr")
            refreshNotification()
            listener?.onStatusChanged(status)
            if (tcpServer.clientCount == 1) triggerAutoReset(entering = true)
        }
        tcpServer.onClientDisconnected = { addr ->
            status = status.copy(clientCount = tcpServer.clientCount)
            listener?.onLog("Client disconnected: $addr")
            refreshNotification()
            listener?.onStatusChanged(status)
            if (tcpServer.clientCount == 0) triggerAutoReset(entering = false)
        }
        tcpServer.onError = { e -> listener?.onLog("TCP error: ${e.message}") }
        tcpServer.onAutoBaudChanged = { newBaud ->
            status = status.copy(baudRate = newBaud)
            listener?.onLog("Auto-baud: detected esptool's CHANGE_BAUDRATE -> UART switched to ${newBaud} baud")
            refreshNotification()
            listener?.onStatusChanged(status)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopBridge()
        }
        return START_STICKY
    }

    fun setListener(l: BridgeListener?) {
        listener = l
    }

    fun getStatus(): BridgeStatus = status

    /** Opens the USB serial port and starts the TCP server. Returns true on success. */
    fun startBridge(
        driver: UsbSerialDriver,
        baudRate: Int,
        dataBits: Int,
        stopBits: Int,
        parity: Int,
        tcpPort: Int,
        protocolMode: ServerMode = ServerMode.RAW,
        targetChip: TargetChip = TargetChip.ESP32
    ): Boolean {
        if (status.running) return true
        activeProtocolMode = protocolMode
        activeTargetChip = targetChip

        // Raw auto-baud always opens at 115200 - that's what the ESP ROM/stub loader
        // itself always expects for the initial SYNC handshake regardless of --baud
        // (esptool syncs at up to 115200, then requests a higher speed in-band via
        // CHANGE_BAUDRATE if you passed --baud - see EspBaudRateSniffer, which is what
        // then retunes this to match). Whatever the UART Settings baud spinner says is
        // ignored in this mode; data bits/stop bits/parity from it still apply as given.
        val effectiveBaud = if (protocolMode == ServerMode.RAW_AUTOBAUD) RAW_AUTOBAUD_DEFAULT_BAUD else baudRate

        val opened = usbSerial.open(driver, effectiveBaud, dataBits, stopBits, parity)
        if (!opened) {
            listener?.onLog("Failed to open USB serial port")
            return false
        }

        try {
            tcpServer.start(tcpPort, protocolMode, rfc2217Control, targetChip)
        } catch (e: Exception) {
            listener?.onLog("Failed to start TCP server on port $tcpPort: ${e.message}")
            usbSerial.close()
            return false
        }

        status = BridgeStatus(
            running = true,
            usbConnected = true,
            deviceName = usbSerial.deviceInfo(driver),
            baudRate = effectiveBaud,
            tcpPort = tcpPort,
            clientCount = 0,
            ipAddress = getLocalIpAddress(),
            protocolMode = protocolMode
        )

        startForeground(NOTIF_ID, buildNotification())
        val modeLabel = when (protocolMode) {
            ServerMode.RFC2217 -> "RFC2217"
            ServerMode.RAW_AUTOBAUD -> "raw, auto-baud"
            ServerMode.RAW -> "raw"
        }
        listener?.onLog("Bridge started: UART ${effectiveBaud}bps <-> TCP ${status.ipAddress}:$tcpPort ($modeLabel)")
        listener?.onStatusChanged(status)
        return true
    }

    fun stopBridge() {
        autoResetJob?.cancel()
        tcpServer.stop()
        usbSerial.close()
        status = status.copy(running = false, usbConnected = false, clientCount = 0)
        listener?.onLog("Bridge stopped")
        listener?.onStatusChanged(status)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    fun setRTS(value: Boolean) = usbSerial.setRTS(value)
    fun setDTR(value: Boolean) = usbSerial.setDTR(value)

    /** Exposed so MainActivity's manual reset button can drive the shared ResetSequences functions. */
    val controlBridge: Rfc2217ControlBridge get() = rfc2217Control

    /**
     * Automatic reset for Raw/Raw-autobaud modes: bootloader/download-mode
     * entry when the first client connects (so esptool's initial sync
     * succeeds without a manual button press first), normal reset when the
     * last client disconnects (so the newly-flashed firmware starts running
     * - matching esptool's own default `--after hard-reset`), and, for
     * Raw-autobaud specifically, restoring the UART to its default baud
     * rate afterwards so the next session starts from a known state instead
     * of wherever the previous esptool run left it (see the earlier report
     * of a socket:// session staying stuck at 1500000).
     *
     * Deliberately does nothing for RFC2217: that mode already gets a
     * correctly-timed reset driven by the client's own DTR/RTS commands
     * (see Rfc2217Session) - triggering a second, independent reset here on
     * top of that would race with it. Also does nothing for
     * TargetChip.GENERIC, which exists specifically to mean "no automatic
     * sequence, pure passthrough."
     */
    private fun triggerAutoReset(entering: Boolean) {
        if (activeProtocolMode == ServerMode.RFC2217) return
        if (activeTargetChip == TargetChip.GENERIC) return

        autoResetJob?.cancel()
        autoResetJob = serviceScope.launch {
            val label = if (entering) "bootloader/download-mode entry" else "normal reset"
            val onStep: (String) -> Unit = { msg -> listener?.onLog("Auto-reset: $msg") }
            when (activeTargetChip) {
                TargetChip.ESP32 -> if (entering) {
                    ResetSequences.esp32BootloaderEntry(rfc2217Control, onStep)
                } else {
                    ResetSequences.esp32HardReset(rfc2217Control, onStep)
                }
                TargetChip.BW16 -> if (entering) {
                    ResetSequences.bw16DownloadModeEntry(rfc2217Control, onStep)
                } else {
                    ResetSequences.bw16NormalReset(rfc2217Control, onStep)
                }
                TargetChip.GENERIC -> Unit // unreachable, guarded above
            }
            listener?.onLog("Auto-reset: $label complete")

            if (!entering && activeProtocolMode == ServerMode.RAW_AUTOBAUD &&
                usbSerial.currentBaudRate != RAW_AUTOBAUD_DEFAULT_BAUD
            ) {
                usbSerial.reconfigure(baudRate = RAW_AUTOBAUD_DEFAULT_BAUD)
                status = status.copy(baudRate = RAW_AUTOBAUD_DEFAULT_BAUD)
                listener?.onLog("Auto-baud: reset UART back to ${RAW_AUTOBAUD_DEFAULT_BAUD} baud for the next session")
                listener?.onStatusChanged(status)
            }
        }
    }

    override fun onDestroy() {
        autoResetJob?.cancel()
        serviceScope.cancel()
        tcpServer.stop()
        usbSerial.close()
        super.onDestroy()
    }

    // ---- notification -------------------------------------------------

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Bridge Service",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Shows TCP UART Bridge status while running"
            setShowBadge(false)
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val mutabilityFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            PendingIntent.FLAG_MUTABLE
        } else {
            0
        }

        val contentIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or mutabilityFlag
        )

        val stopIntent = Intent(this, BridgeService::class.java).apply { action = ACTION_STOP }
        val stopPending = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or mutabilityFlag
        )

        val usbLine = if (status.usbConnected) "USB: ${status.deviceName}" else "USB: not connected"
        val uartLine = "UART: ${status.baudRate} baud"
        val modeLabel = when (status.protocolMode) {
            ServerMode.RFC2217 -> "RFC2217"
            ServerMode.RAW_AUTOBAUD -> "raw, auto-baud"
            ServerMode.RAW -> "raw"
        }
        val tcpLine = "TCP: ${status.ipAddress}:${status.tcpPort} ($modeLabel) - ${status.clientCount} client(s)"

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("TCP UART Bridge running")
            .setContentText("$usbLine  ·  $tcpLine")
            .setStyle(NotificationCompat.BigTextStyle().bigText("$usbLine\n$uartLine\n$tcpLine"))
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(contentIntent)
            .addAction(0, "Stop", stopPending)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun refreshNotification() {
        if (!status.running) return
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
    }

    // ---- helpers --------------------------------------------------------

    private fun getLocalIpAddress(): String {
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val iface = interfaces.nextElement()
                val addresses = iface.inetAddresses
                while (addresses.hasMoreElements()) {
                    val addr = addresses.nextElement()
                    if (!addr.isLoopbackAddress && addr is Inet4Address) {
                        return addr.hostAddress ?: "unknown"
                    }
                }
            }
        } catch (_: Exception) {
        }
        return "unknown"
    }

    companion object {
        const val NOTIF_ID = 1001
        const val CHANNEL_ID = "bridge_channel"
        const val ACTION_STOP = "com.tcpuartbridge.app.ACTION_STOP"
        // Matches the fixed baud RAW_AUTOBAUD always opens at (see startBridge) - what
        // the port gets reset to once the last client disconnects, ready for a fresh
        // esptool session that expects to find the ROM/stub loader's default sync speed.
        const val RAW_AUTOBAUD_DEFAULT_BAUD = 115200
    }
}
