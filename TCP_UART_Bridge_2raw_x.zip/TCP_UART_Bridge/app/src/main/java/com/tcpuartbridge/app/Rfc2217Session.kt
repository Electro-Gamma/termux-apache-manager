package com.tcpuartbridge.app

import com.hoho.android.usbserial.driver.UsbSerialPort
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/** Which chip's reset conventions to use for automatic RFC2217 resets. */
enum class TargetChip { ESP32, BW16, GENERIC }

/**
 * Everything an [Rfc2217Session] needs from the actual hardware, without
 * knowing anything about USB or sockets. Implemented by [BridgeService]
 * on top of [UsbSerialManager].
 */
interface Rfc2217ControlBridge {
    fun setDTR(value: Boolean)
    fun setRTS(value: Boolean)
    fun reconfigure(baudRate: Int? = null, dataBits: Int? = null, stopBits: Int? = null, parity: Int? = null)
    val currentBaudRate: Int
    val currentDataBits: Int
    val currentStopBits: Int
    val currentParity: Int
}

/**
 * One RFC2217 (Telnet COM-Port-Control, RFC 2217) session for a single TCP
 * client. Decodes the incoming byte stream, replies to option negotiation
 * and COM-PORT-OPTION subnegotiations, and forwards plain UART-bound data
 * via [onDecodedData].
 *
 * Reset handling depends on [targetChip]:
 *
 * - [TargetChip.ESP32]: does NOT just relay each DTR/RTS SET-CONTROL
 *   command straight to the hardware as it arrives. esptool.py's reset
 *   sequences (ClassicReset / HardReset, see esptool/reset.py) depend on
 *   millisecond-level timing between DTR and RTS transitions, and each
 *   pyserial `.dtr =` / `.rts =` assignment is a *separate* SET-CONTROL
 *   command/round-trip, so relaying them individually risks extra latency
 *   breaking that timing. Instead - mirroring Espressif's own
 *   esp_rfc2217_server (esp_port_manager.py) - this detects the *start* of
 *   a reset sequence from which control line changes first, then runs a
 *   precisely-timed sequence locally, ignoring the redundant follow-up
 *   commands the client sends as part of the same sequence.
 *
 * - [TargetChip.GENERIC]: every DTR/RTS command is applied immediately and
 *   directly, in the order it arrives, with no detection/substitution.
 *   This is the fallback for any board whose reset conventions don't match
 *   ESP32's: whatever timing the client's own reset routine relies on is
 *   preserved as-is, since nothing here tries to interpret or collapse the
 *   sequence.
 *
 * - [TargetChip.BW16]: also routed through the same direct passthrough as
 *   [TargetChip.GENERIC] for RFC2217 - BW16/AmebaD's real reset sequence
 *   (see [ResetSequences.bw16DownloadModeEntry]) lives in the automatic
 *   on-connect/on-disconnect trigger for Raw/Raw-autobaud modes instead
 *   (see [BridgeService]), not here. Wiring it into this class's ESP32-
 *   shaped SET-CONTROL interception would misfire: BW16's upload_amebad.py
 *   sends its own distinct DTR/RTS pattern over RFC2217 that doesn't match
 *   what this class's ESP32-specific heuristics expect, so this selection
 *   only matters for RFC2217 sessions in that it avoids misapplying the
 *   ESP32 sequence to BW16's commands.
 */
class Rfc2217Session(
    private val control: Rfc2217ControlBridge,
    private val scope: CoroutineScope,
    private val targetChip: TargetChip,
    private val onDecodedData: (ByteArray) -> Unit,
    private val sendToClient: (ByteArray) -> Unit,
    /**
     * Discards bytes already queued to go out to this client but not yet
     * written (rx = server's "receive buffer" per RFC2217 3.7, i.e. UART
     * data captured but not yet delivered to the client; tx = the reverse,
     * unused today - see class doc on PURGE_DATA/handlePurgeData). Called
     * both on an explicit client PURGE_DATA request and proactively right
     * after a baud-rate change or reset pulse, since both can leave stale
     * bytes sitting in the outbound queue that would otherwise be delivered
     * right when esptool expects a fresh response.
     */
    private val onPurge: (rx: Boolean, tx: Boolean) -> Unit = { _, _ -> }
) {
    // Mirrors EspPortManager.is_download_mode: true while a bootloader-entry
    // sequence is in progress, so the trailing RTS-off from that same
    // sequence doesn't also get misread as a plain hard-reset request.
    @Volatile
    private var isDownloadMode = false

    // Locally cached signal state, since usb-serial-for-android's control
    // lines are effectively write-only from the host side (nothing to query
    // back from the adapter chip) - same approach real RFC2217 servers use.
    @Volatile
    private var dtrState = false

    @Volatile
    private var rtsState = false

    private var resetJob: Job? = null

    private val decoder = TelnetIacDecoder(
        onData = { data -> onDecodedData(data) },
        onNegotiation = { verb, option -> handleNegotiation(verb, option) },
        onSubnegotiation = { payload -> handleSubnegotiation(payload) }
    )

    /** Called by the client-handler's read loop with each chunk read from the socket. */
    fun feed(bytes: ByteArray, length: Int) = decoder.feed(bytes, length)

    /** Sent once, right when a client connects, so we work with clients that wait for the server to offer first. */
    fun sendInitialOffer() {
        sendToClient(Rfc2217Encoder.negotiation(Telnet.WILL, Telnet.COM_PORT_OPTION))
        sendToClient(Rfc2217Encoder.negotiation(Telnet.WILL, Telnet.BINARY))
        sendToClient(Rfc2217Encoder.negotiation(Telnet.DO, Telnet.BINARY))
    }

    // ---- Telnet option negotiation (RFC 854/855) ----

    private fun handleNegotiation(verb: Int, option: Int) {
        val supported = option == Telnet.COM_PORT_OPTION || option == Telnet.BINARY
        when (verb) {
            Telnet.WILL -> sendToClient(
                Rfc2217Encoder.negotiation(if (supported) Telnet.DO else Telnet.DONT, option)
            )
            Telnet.DO -> sendToClient(
                Rfc2217Encoder.negotiation(if (supported) Telnet.WILL else Telnet.WONT, option)
            )
            // WONT / DONT: acknowledged implicitly by not re-negotiating; nothing to send.
        }
    }

    // ---- COM-PORT-OPTION subnegotiations (RFC 2217 section 3) ----

    private fun handleSubnegotiation(payload: ByteArray) {
        if (payload.isEmpty() || (payload[0].toInt() and 0xFF) != Telnet.COM_PORT_OPTION) return
        if (payload.size < 2) return
        val command = payload[1].toInt() and 0xFF
        val value = if (payload.size > 2) payload[2].toInt() and 0xFF else -1

        when (command) {
            Rfc2217.SIGNATURE -> handleSignature(payload)
            Rfc2217.SET_BAUDRATE -> handleSetBaudrate(payload)
            Rfc2217.SET_DATASIZE -> handleSetDataSize(value)
            Rfc2217.SET_PARITY -> handleSetParity(value)
            Rfc2217.SET_STOPSIZE -> handleSetStopSize(value)
            Rfc2217.SET_CONTROL -> handleSetControl(value)
            Rfc2217.SET_LINESTATE_MASK -> ackSingleByte(Rfc2217.SET_LINESTATE_MASK, value)
            Rfc2217.SET_MODEMSTATE_MASK -> ackSingleByte(Rfc2217.SET_MODEMSTATE_MASK, value)
            Rfc2217.PURGE_DATA -> handlePurgeData(value)
            // NOTIFY-LINESTATE / NOTIFY-MODEMSTATE are normally server -> client pushes;
            // we don't poll hardware status lines continuously, so there's nothing
            // meaningful to report if a client asks - safely ignored.
        }
    }

    private fun handleSignature(payload: ByteArray) {
        if (payload.size > 2) return // client is *sending* a signature, not asking for ours - ignore
        val sig = "TCP_UART_Bridge".toByteArray(Charsets.US_ASCII)
        val out = ByteArray(2 + sig.size)
        out[0] = Telnet.COM_PORT_OPTION.toByte()
        out[1] = Rfc2217.SIGNATURE.toByte()
        sig.copyInto(out, 2)
        sendToClient(Rfc2217Encoder.subnegotiation(out))
    }

    /**
     * RFC2217 PURGE-DATA (section 3.7): 1 = purge the server's receive
     * buffer (UART bytes already captured but not yet delivered to the
     * client), 2 = purge the server's transmit buffer (bytes received from
     * the client but not yet written to the UART - nothing queued at that
     * layer in this app today, see [TcpServerManager], so this is a no-op),
     * 3 = both.
     *
     * This used to just echo an acknowledgement without discarding
     * anything. esptool/pyserial calls the equivalent of this (via
     * `reset_input_buffer()`) to recover cleanly after things like a
     * baud-rate change - if stale bytes are still sitting in the outbound
     * queue when that happens, they get delivered right as esptool expects
     * a fresh response, which desyncs its sync/retry state machine and can
     * burn through several retry timeouts (many seconds) before it
     * recovers on its own. Actually discarding the queued backlog here
     * fixes that at the source.
     */
    private fun handlePurgeData(value: Int) {
        val purgeRx = value == 1 || value == 3
        val purgeTx = value == 2 || value == 3
        if (purgeRx || purgeTx) onPurge(purgeRx, purgeTx)
        ackSingleByte(Rfc2217.PURGE_DATA, value)
    }

    private fun handleSetBaudrate(payload: ByteArray) {
        if (payload.size < 6) return
        val baud = ((payload[2].toInt() and 0xFF) shl 24) or
            ((payload[3].toInt() and 0xFF) shl 16) or
            ((payload[4].toInt() and 0xFF) shl 8) or
            (payload[5].toInt() and 0xFF)
        val effective = if (baud == 0) control.currentBaudRate else baud
        if (baud != 0) {
            control.reconfigure(baudRate = baud)
            // Anything still sitting in the outbound queue from before the switch (e.g.
            // the tail end of a burst captured at the old baud) delivered right after this
            // is exactly what confuses esptool's sync state machine post-baud-change - see
            // handlePurgeData doc. Clients that don't send an explicit PURGE_DATA request
            // still get a clean slate.
            onPurge(true, false)
        }
        sendToClient(
            Rfc2217Encoder.comPortSubnegotiation(
                Rfc2217.SET_BAUDRATE + Rfc2217.SERVER_OFFSET,
                *Rfc2217Encoder.baudRateBytes(effective)
            )
        )
    }

    private fun handleSetDataSize(value: Int) {
        val effective = if (value == 0 || value !in 5..8) control.currentDataBits else value
        if (value in 5..8) control.reconfigure(dataBits = value)
        ackSingleByte(Rfc2217.SET_DATASIZE, effective)
    }

    private fun handleSetParity(value: Int) {
        // RFC2217: 0=request, 1=none, 2=odd, 3=even, 4=mark, 5=space.
        val mapped = when (value) {
            1 -> UsbSerialPort.PARITY_NONE
            2 -> UsbSerialPort.PARITY_ODD
            3 -> UsbSerialPort.PARITY_EVEN
            4 -> UsbSerialPort.PARITY_MARK
            5 -> UsbSerialPort.PARITY_SPACE
            else -> null
        }
        if (mapped != null) {
            control.reconfigure(parity = mapped)
            ackSingleByte(Rfc2217.SET_PARITY, value)
        } else {
            // request: report back current parity translated the other way
            val current = when (control.currentParity) {
                UsbSerialPort.PARITY_NONE -> 1
                UsbSerialPort.PARITY_ODD -> 2
                UsbSerialPort.PARITY_EVEN -> 3
                UsbSerialPort.PARITY_MARK -> 4
                UsbSerialPort.PARITY_SPACE -> 5
                else -> 1
            }
            ackSingleByte(Rfc2217.SET_PARITY, current)
        }
    }

    private fun handleSetStopSize(value: Int) {
        // RFC2217 1/2/3 (1 / 2 / 1.5 stop bits) line up 1:1 with usb-serial-for-android's
        // STOPBITS_1/STOPBITS_2/STOPBITS_1_5 constants, but we go through named constants
        // rather than relying on that so it stays correct even if that assumption changes.
        val mapped = when (value) {
            1 -> UsbSerialPort.STOPBITS_1
            2 -> UsbSerialPort.STOPBITS_2
            3 -> UsbSerialPort.STOPBITS_1_5
            else -> null
        }
        if (mapped != null) {
            control.reconfigure(stopBits = mapped)
            ackSingleByte(Rfc2217.SET_STOPSIZE, value)
        } else {
            val current = when (control.currentStopBits) {
                UsbSerialPort.STOPBITS_1 -> 1
                UsbSerialPort.STOPBITS_2 -> 2
                UsbSerialPort.STOPBITS_1_5 -> 3
                else -> 1
            }
            ackSingleByte(Rfc2217.SET_STOPSIZE, current)
        }
    }

    /**
     * SET-CONTROL dispatch. For [TargetChip.ESP32], only DTR-OFF (always)
     * and the *first* command of a reset sequence (DTR-ON for bootloader
     * entry, RTS-OFF for a plain hard reset) trigger real action; the rest
     * of an in-flight sequence is intentionally swallowed. For
     * [TargetChip.GENERIC] and [TargetChip.BW16], every ON/OFF command is
     * applied immediately. See the class doc.
     */
    private fun handleSetControl(value: Int) {
        if (targetChip == TargetChip.GENERIC || targetChip == TargetChip.BW16) {
            handleSetControlGeneric(value)
            return
        }
        when (value) {
            Rfc2217.SET_CONTROL_DTR_OFF -> {
                isDownloadMode = false
                dtrState = false
                control.setDTR(false)
            }
            Rfc2217.SET_CONTROL_RTS_OFF -> {
                if (!isDownloadMode) startHardResetSequence()
                rtsState = false
            }
            Rfc2217.SET_CONTROL_DTR_ON -> {
                if (!isDownloadMode) {
                    isDownloadMode = true
                    startBootloaderResetSequence()
                }
                dtrState = true
            }
            Rfc2217.SET_CONTROL_RTS_ON -> {
                // Deliberately ignored (matches EspPortManager): asserting EN/reset live off
                // the network, outside a controlled local sequence, risks leaving the chip
                // stuck in reset if the connection stalls mid-sequence.
                rtsState = true
            }
            Rfc2217.SET_CONTROL_DTR_REQ -> ackSingleByte(
                Rfc2217.SET_CONTROL,
                if (dtrState) Rfc2217.SET_CONTROL_DTR_ON else Rfc2217.SET_CONTROL_DTR_OFF
            )
            Rfc2217.SET_CONTROL_RTS_REQ -> ackSingleByte(
                Rfc2217.SET_CONTROL,
                if (rtsState) Rfc2217.SET_CONTROL_RTS_ON else Rfc2217.SET_CONTROL_RTS_OFF
            )
            Rfc2217.SET_CONTROL_BREAK_REQ -> ackSingleByte(Rfc2217.SET_CONTROL, Rfc2217.SET_CONTROL_BREAK_OFF)
            else -> {
                // Break on/off and all the flow-control negotiation values (0-3, 13-19):
                // not wired to real hardware (esptool never sends these), just ack so a
                // spec-following client's negotiation doesn't stall waiting for a reply.
                ackSingleByte(Rfc2217.SET_CONTROL, value)
            }
        }
    }

    /** Direct, immediate passthrough - no sequence detection. See class doc for why. */
    private fun handleSetControlGeneric(value: Int) {
        when (value) {
            Rfc2217.SET_CONTROL_DTR_OFF -> {
                dtrState = false
                control.setDTR(false)
            }
            Rfc2217.SET_CONTROL_DTR_ON -> {
                dtrState = true
                control.setDTR(true)
            }
            Rfc2217.SET_CONTROL_RTS_OFF -> {
                rtsState = false
                control.setRTS(false)
            }
            Rfc2217.SET_CONTROL_RTS_ON -> {
                rtsState = true
                control.setRTS(true)
            }
            Rfc2217.SET_CONTROL_DTR_REQ -> ackSingleByte(
                Rfc2217.SET_CONTROL,
                if (dtrState) Rfc2217.SET_CONTROL_DTR_ON else Rfc2217.SET_CONTROL_DTR_OFF
            )
            Rfc2217.SET_CONTROL_RTS_REQ -> ackSingleByte(
                Rfc2217.SET_CONTROL,
                if (rtsState) Rfc2217.SET_CONTROL_RTS_ON else Rfc2217.SET_CONTROL_RTS_OFF
            )
            Rfc2217.SET_CONTROL_BREAK_REQ -> ackSingleByte(Rfc2217.SET_CONTROL, Rfc2217.SET_CONTROL_BREAK_OFF)
            else -> ackSingleByte(Rfc2217.SET_CONTROL, value)
        }
    }

    private fun ackSingleByte(command: Int, value: Int) {
        sendToClient(Rfc2217Encoder.comPortSubnegotiation(command + Rfc2217.SERVER_OFFSET, value))
    }

    // ---- Locally-timed reset sequences (mirrors esptool/reset.py; see ResetSequences) ----

    /** Mirrors ClassicReset: pulse into the bootloader with IO0 held low across the reset edge. */
    private fun startBootloaderResetSequence() {
        resetJob?.cancel()
        resetJob = scope.launch {
            ResetSequences.esp32BootloaderEntry(control)
            dtrState = false
            isDownloadMode = false
            // Toggling DTR/RTS can put transient glitch bytes on some adapters' RX line -
            // discard them before esptool starts its ROM sync, same reasoning as handlePurgeData.
            onPurge(true, false)
        }
    }

    /** Mirrors HardReset (non-USB-CDC branch): pulse EN only, IO0 untouched -> normal boot. */
    private fun startHardResetSequence() {
        resetJob?.cancel()
        resetJob = scope.launch {
            ResetSequences.esp32HardReset(control)
            rtsState = false
            onPurge(true, false)
        }
    }
}
