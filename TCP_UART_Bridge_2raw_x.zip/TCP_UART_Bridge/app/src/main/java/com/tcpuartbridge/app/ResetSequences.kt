package com.tcpuartbridge.app

import kotlinx.coroutines.delay

/**
 * Chip-specific DTR/RTS reset pulse sequences. Kept in exactly one place and
 * shared by every caller - [Rfc2217Session]'s automatic ESP32 sequence
 * detection, [MainActivity]'s manual reset button, and [BridgeService]'s
 * automatic on-connect/on-disconnect triggers for Raw/Raw-autobaud modes -
 * so the timing can't quietly drift out of sync between them the way a
 * copy-pasted version in each place eventually would. [onStep] is an
 * optional callback fired before each pulse (for the manual button's
 * timestamped diagnostic log); automatic callers can just leave it out.
 */
object ResetSequences {

    /** ClassicReset: pulse into the bootloader with IO0 held low across the reset edge. */
    suspend fun esp32BootloaderEntry(control: Rfc2217ControlBridge, onStep: (String) -> Unit = {}) {
        onStep("ESP32 reset: DTR=0 (IO0=HIGH), RTS=1 (EN=LOW, reset)")
        control.setDTR(false) // IO0 = HIGH
        control.setRTS(true) // EN = LOW, chip in reset
        delay(100)
        onStep("DTR=1 (IO0=LOW), RTS=0 (EN=HIGH, exits reset -> should sample IO0 LOW -> bootloader)")
        control.setDTR(true) // IO0 = LOW
        control.setRTS(false) // EN = HIGH, chip exits reset and samples IO0 = LOW -> bootloader
        delay(50) // DEFAULT_RESET_DELAY
        onStep("DTR=0 (IO0=HIGH, done)")
        control.setDTR(false) // IO0 = HIGH, done
    }

    /** HardReset (non-USB-CDC branch): pulse EN only, IO0 untouched -> normal boot. */
    suspend fun esp32HardReset(control: Rfc2217ControlBridge, onStep: (String) -> Unit = {}) {
        onStep("ESP32 reset: RTS=1 (EN=LOW, reset)")
        control.setRTS(true) // EN = LOW
        delay(100)
        onStep("RTS=0 (EN=HIGH, exits reset -> runs the flashed app)")
        control.setRTS(false) // EN = HIGH, exits reset -> runs the flashed app
    }

    /**
     * BW16/AmebaD reset-to-download-mode, translated exactly from
     * upload_amebad.py's enter_download_mode()/set_dtr_rts():
     * ```
     * def set_dtr_rts(ser, level):
     *     ser.rts = not bool(level & 0x1)
     *     ser.dtr = not bool(level & 0x2)
     *
     * def enter_download_mode(ser):
     *     set_dtr_rts(ser, 0x2)   # rts=True,  dtr=False  (EN low / reset)
     *     time.sleep(0.5)
     *     set_dtr_rts(ser, 0x1)   # rts=False, dtr=True   (download-mode select)
     *     time.sleep(0.2)
     *     set_dtr_rts(ser, 0x3)   # rts=False, dtr=False  (release)
     *     time.sleep(0.5)
     * ```
     */
    suspend fun bw16DownloadModeEntry(control: Rfc2217ControlBridge, onStep: (String) -> Unit = {}) {
        onStep("BW16 download-mode: RTS=1, DTR=0 (EN low / reset)")
        control.setRTS(true)
        control.setDTR(false) // 0x2: EN low / reset
        delay(500)
        onStep("RTS=0, DTR=1 (download-mode select)")
        control.setRTS(false)
        control.setDTR(true) // 0x1: download-mode select
        delay(200)
        onStep("RTS=0, DTR=0 (release)")
        control.setRTS(false)
        control.setDTR(false) // 0x3: release
        delay(500)
    }

    /**
     * BW16/AmebaD reset_to_boot(), translated the same way:
     * ```
     * def reset_to_boot(ser):
     *     set_dtr_rts(ser, 0x2)
     *     time.sleep(0.5)
     *     set_dtr_rts(ser, 0x3)
     * ```
     * Same first step as download-mode entry, but skips the download-select
     * step - EN is released with DTR already low, so the chip boots normally.
     */
    suspend fun bw16NormalReset(control: Rfc2217ControlBridge, onStep: (String) -> Unit = {}) {
        onStep("BW16 reset: RTS=1, DTR=0 (EN low / reset)")
        control.setRTS(true)
        control.setDTR(false) // 0x2
        delay(500)
        onStep("RTS=0, DTR=0 (release)")
        control.setRTS(false)
        control.setDTR(false) // 0x3
    }
}
