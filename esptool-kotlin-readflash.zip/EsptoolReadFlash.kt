// EsptoolReadFlash.kt
//
// A from-scratch Kotlin/JVM port of esptool's `read-flash` command with
// stub-loader support, talking to the chip over a TCP socket (the
// socket://host:port transport, i.e. the Termux-TCP-bridge scenario this
// whole tool has been built around).
//
// This is a REWRITE, not a mechanical repackaging like the earlier Python
// single-file bundle. Every protocol detail below (opcodes, packet layout,
// timeouts, the stub-upload sequence, the read-flash wire protocol, and the
// per-chip identification values) was read directly out of the original
// esptool-5.3.1 Python source (esptool/loader.py, esptool/cmds.py,
// esptool/targets/*.py) while writing this file, not recalled from memory --
// each piece below is commented with roughly where it came from. Even so,
// this has NOT been tested against real hardware (no device, no serial/TCP
// bridge available in the environment this was written in) -- only
// compiled, and exercised with a small self-test against the same stub
// JSON files and known protocol byte sequences. Please test cautiously
// against a real board before relying on it. Read-flash is non-destructive
// (it never writes to flash), which is why this command was chosen for a
// from-scratch port, but a protocol bug could still mean it just doesn't
// work, or reads back wrong data without noticing -- the MD5 check guards
// against the latter for what it's worth.
//
// ---------------------------------------------------------------------
// SCOPE / WHAT'S DELIBERATELY NOT HERE (vs. the Python original):
//  - Only socket:// transport (no real serial/COM ports) -- matches the
//    Termux-TCP use case, and Python's own esptool ALSO disables chip
//    reset (DTR/RTS toggling) for socket:// ports, since that's not
//    possible over a plain TCP socket (loader.py connect(): "if
//    self._port.name.startswith('socket:'): mode = 'no-reset'"). So you
//    need to put the chip in bootloader/download mode yourself before
//    running this, exactly as with the Python version over socket://.
//  - No custom SPI pin configuration (--spi-connection). Fine for
//    standard boards: when the stub loader is running, its own startup
//    code attaches SPI flash with default pins already (see
//    esptool/cmds.py attach_flash(): the "elif not esp.IS_STUB:" branch
//    that calls flash_spi_attach() is skipped entirely once the stub is
//    up, which is always the case here).
//  - No flash-size auto-detect/bounds-check convenience (Python's
//    check_flash_size()) -- you give an explicit address+size and it
//    reads exactly that.
//  - ESP32-E22 and ESP32-H21 are left out of chip detection: the
//    original project ships no stub_flasher JSON for either of them
//    either (checked: targets/stub_flasher/{1,2}/ has no esp32e22.json
//    or esp32h21.json), so stub-based read-flash can't work for them in
//    the Python version either.
//  - ESP32-P4's chip-revision-dependent stub selection (it has both
//    esp32p4.json and esp32p4-rev1.json upstream, picked by
//    self.get_chip_revision() -- see esp32p4.py stub_json_name()) is
//    simplified to always use esp32p4.json (the newer-silicon default).
//  - The ESP32-S3-with-secure-boot-enabled stub injection workaround
//    (loader.py run_stub(), the "secure_boot_workflow" branch that
//    pokes a ROM function pointer instead of a normal jump) isn't
//    implemented. Affects only ESP32-S3 boards with secure boot burned
//    in.
// ---------------------------------------------------------------------

import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.net.Socket
import java.net.SocketTimeoutException
import java.net.URI
import java.security.MessageDigest
import java.util.Base64
import kotlin.system.exitProcess

// ============================================================================
// Little-endian packing helpers
// (Python uses struct.pack("<...", ...) throughout loader.py; the JVM has
// no built-in little-endian primitive packing, so these are hand-rolled)
// ============================================================================

private fun le16(v: Int): ByteArray =
    byteArrayOf((v and 0xFF).toByte(), ((v ushr 8) and 0xFF).toByte())

private fun le32(v: Long): ByteArray = byteArrayOf(
    (v and 0xFF).toByte(),
    ((v ushr 8) and 0xFF).toByte(),
    ((v ushr 16) and 0xFF).toByte(),
    ((v ushr 24) and 0xFF).toByte(),
)

private fun le32(v: Int): ByteArray = le32(v.toLong() and 0xFFFFFFFFL)

private fun readLe16(b: ByteArray, off: Int): Int =
    (b[off].toInt() and 0xFF) or ((b[off + 1].toInt() and 0xFF) shl 8)

private fun readLe32(b: ByteArray, off: Int): Long =
    (b[off].toLong() and 0xFF) or
        ((b[off + 1].toLong() and 0xFF) shl 8) or
        ((b[off + 2].toLong() and 0xFF) shl 16) or
        ((b[off + 3].toLong() and 0xFF) shl 24)

private fun ByteArray.toHex(): String = joinToString("") { "%02x".format(it) }

// ============================================================================
// Errors
// ============================================================================

class FatalError(message: String) : Exception(message)

// ============================================================================
// SLIP framing
// (Python: ESPLoader.write() around loader.py:542, and the slip_reader()
// generator around loader.py:2174 -- standard RFC 1055 SLIP: frames are
// delimited by 0xC0, and any literal 0xC0/0xDB byte inside the payload is
// escaped as 0xDB 0xDC / 0xDB 0xDD respectively)
// ============================================================================

private object Slip {
    const val END = 0xC0
    const val ESC = 0xDB
    const val ESC_END = 0xDC
    const val ESC_ESC = 0xDD

    fun encode(payload: ByteArray): ByteArray {
        val out = ByteArrayOutputStream(payload.size + 8)
        out.write(END)
        for (b in payload) {
            when (val u = b.toInt() and 0xFF) {
                END -> { out.write(ESC); out.write(ESC_END) }
                ESC -> { out.write(ESC); out.write(ESC_ESC) }
                else -> out.write(u)
            }
        }
        out.write(END)
        return out.toByteArray()
    }
}

/**
 * Reads one fully unescaped SLIP frame at a time from a blocking
 * [java.io.InputStream]. Relies on the underlying socket's SO_TIMEOUT for
 * the actual timeout (a blocking read() throws [SocketTimeoutException]
 * once it's exceeded), mirroring how the Python version relies on
 * pyserial's port.timeout.
 */
private class SlipReader(private val input: java.io.InputStream) {
    fun readPacket(): ByteArray {
        val out = ByteArrayOutputStream()
        var started = false
        var inEscape = false
        while (true) {
            val b = input.read()
            if (b == -1) throw FatalError("Connection closed while reading.")
            val u = b and 0xFF
            if (!started) {
                if (u == Slip.END) started = true
                continue
            }
            if (u == Slip.END) {
                if (out.size() == 0) continue // tolerate repeated/leading delimiters
                return out.toByteArray()
            }
            if (inEscape) {
                inEscape = false
                when (u) {
                    Slip.ESC_END -> out.write(Slip.END)
                    Slip.ESC_ESC -> out.write(Slip.ESC)
                    else -> out.write(u) // be lenient, same spirit as the original
                }
            } else if (u == Slip.ESC) {
                inEscape = true
            } else {
                out.write(u)
            }
        }
    }
}

// ============================================================================
// Command opcodes
// (Python: ESPLoader.ESP_CMDS dict, loader.py:310-349 -- only the subset
// this build actually uses)
// ============================================================================

private object Cmd {
    const val MEM_BEGIN = 0x05
    const val MEM_END = 0x06
    const val MEM_DATA = 0x07
    const val SYNC = 0x08
    const val READ_REG = 0x0A
    const val GET_SECURITY_INFO = 0x14
    const val READ_FLASH = 0xD2 // stub-only
}

private const val CHIP_DETECT_MAGIC_REG_ADDR = 0x40001000L // loader.py:381
private const val FLASH_SECTOR_SIZE = 0x1000L // loader.py:367
private const val ESP_RAM_BLOCK = 0x1800 // loader.py:358
private const val ESP_CHECKSUM_MAGIC = 0xEF // loader.py:365

// ============================================================================
// The connection: SLIP + command/response framing over a TCP socket
// (Python: ESPLoader.command()/checksum()/sync()/mem_begin()/mem_block()/
// mem_finish()/run_stub()/read_flash(), loader.py:542-1650 roughly)
// ============================================================================

class EspConnection(host: String, port: Int, connectTimeoutMs: Int = 5000) {
    private val socket = Socket().apply {
        connect(java.net.InetSocketAddress(host, port), connectTimeoutMs)
        tcpNoDelay = true
    }
    private val output = socket.getOutputStream()
    private val input = socket.getInputStream()
    private var slip = SlipReader(input)

    /** Discards whatever's currently sitting in the socket's read buffer
     * (Python: self._port.reset_input_buffer(), used before each connect
     * attempt to isolate the chip's own boot-log noise from a real reply). */
    fun drainInput() {
        val avail = input.available()
        if (avail > 0) input.skip(avail.toLong())
    }

    private fun writePacket(payload: ByteArray) {
        output.write(Slip.encode(payload))
        output.flush()
    }

    /** Raw SLIP write with no command envelope -- used for the read-flash
     * ACK, which is just a bare 4-byte little-endian count (loader.py
     * read_flash(): `self.write(struct.pack("<I", data_len))`). */
    fun writeRaw(payload: ByteArray) = writePacket(payload)

    private fun readPacket(timeoutMs: Int): ByteArray {
        socket.soTimeout = timeoutMs
        return try {
            slip.readPacket()
        } catch (e: SocketTimeoutException) {
            throw FatalError("Timed out waiting for a response.")
        }
    }

    /** Also exposed directly for the read-flash streaming loop, which reads
     * raw data frames rather than command-response frames. */
    fun readRaw(timeoutMs: Int): ByteArray = readPacket(timeoutMs)

    private fun checksum(data: ByteArray): Int {
        var state = ESP_CHECKSUM_MAGIC
        for (b in data) state = state xor (b.toInt() and 0xFF)
        return state
    }

    /**
     * Send a command and wait for its response. Mirrors ESPLoader.command()
     * (loader.py:571): 8-byte header (direction=0x00, op, len(data) u16,
     * checksum u32) + payload, response header is (direction=0x01, op,
     * len u16, value u32) + response payload. When [op] is null, nothing
     * is written and this just waits for and returns the next valid frame
     * (used to drain the extra SYNC acks some ROMs send).
     *
     * Returns (value, responseData).
     */
    fun command(
        op: Int?,
        data: ByteArray = ByteArray(0),
        chk: Int = 0,
        waitResponse: Boolean = true,
        timeoutMs: Int = 3000,
    ): Pair<Long, ByteArray> {
        if (op != null) {
            val header = byteArrayOf(0x00, op.toByte()) + le16(data.size) + le32(chk.toLong())
            writePacket(header + data)
        }
        if (!waitResponse) return Pair(0L, ByteArray(0))

        repeat(100) {
            val p = try {
                readPacket(timeoutMs)
            } catch (e: IOException) {
                throw FatalError("I/O error waiting for response: ${e.message}")
            }
            if (p.size < 8) return@repeat
            val resp = p[0].toInt() and 0xFF
            val opRet = p[1].toInt() and 0xFF
            val value = readLe32(p, 4)
            val respData = p.copyOfRange(8, p.size)
            if (resp != 1) return@repeat
            if (op == null || opRet == op) return Pair(value, respData)
            // Unsupported-command / mismatched-op replies are just retried
            // here rather than specially detected, unlike the Python
            // version's UnsupportedCommandError path -- callers that care
            // (chip detection) catch the eventual FatalError instead.
        }
        throw FatalError("Response doesn't match request.")
    }

    /** For commands where only success/failure + the header's numeric
     * "value" field matters (MEM_BEGIN/MEM_DATA/MEM_END/READ_REG/READ_FLASH
     * trigger). Mirrors ESPLoader.check_command() (loader.py:596) for the
     * resp_data_len == 0 case. */
    fun checkCommand(
        opDescription: String,
        op: Int,
        data: ByteArray = ByteArray(0),
        chk: Int = 0,
        timeoutMs: Int = 3000,
    ): Long {
        val (value, respData) = command(op, data, chk, timeoutMs = timeoutMs)
        if (respData.size < 2) {
            throw FatalError("Failed to $opDescription. Only got ${respData.size} byte status response.")
        }
        if (respData[0].toInt() != 0) {
            throw FatalError("Failed to $opDescription (status byte ${respData[1]}).")
        }
        return value
    }

    /** For commands that return actual payload data followed by status
     * bytes (e.g. GET_SECURITY_INFO). Mirrors check_command() for the
     * resp_data_len > 0 case. */
    fun checkCommandData(
        opDescription: String,
        op: Int,
        data: ByteArray = ByteArray(0),
        respDataLen: Int,
        timeoutMs: Int = 3000,
    ): ByteArray {
        val (_, respData) = command(op, data, timeoutMs = timeoutMs)
        if (respData.size < respDataLen + 2) {
            throw FatalError("Failed to $opDescription. Only got ${respData.size} byte status response.")
        }
        val statusBytes = respData.copyOfRange(respDataLen, respDataLen + 2)
        if (statusBytes[0].toInt() != 0) {
            throw FatalError("Failed to $opDescription (status byte ${statusBytes[1]}).")
        }
        return respData.copyOfRange(0, respDataLen)
    }

    /** loader.py:707 sync(): send the fixed SYNC pattern, then drain up to
     * 7 extra ack frames some ROMs send. */
    fun sync(timeoutMs: Int = 300) {
        val syncPayload = byteArrayOf(0x07, 0x07, 0x12, 0x20) + ByteArray(32) { 0x55.toByte() }
        command(Cmd.SYNC, syncPayload, timeoutMs = timeoutMs)
        repeat(7) {
            try {
                command(null, timeoutMs = timeoutMs)
            } catch (e: FatalError) {
                // fine if fewer than 7 extra acks show up
            }
        }
    }

    /** loader.py:1018 read_reg(). */
    fun readReg(addr: Long, timeoutMs: Int = 3000): Long =
        checkCommand("read target memory", Cmd.READ_REG, le32(addr), timeoutMs = timeoutMs)

    // ---- stub upload: mem_begin / mem_block / mem_finish (loader.py:1053-1103) ----

    private fun memBegin(size: Int, blocks: Int, blockSize: Int, offset: Long) {
        val data = le32(size) + le32(blocks) + le32(blockSize) + le32(offset)
        checkCommand("enter RAM download mode", Cmd.MEM_BEGIN, data)
    }

    private fun memBlock(data: ByteArray, seq: Int) {
        val header = le32(data.size) + le32(seq) + le32(0) + le32(0)
        checkCommand("write to target RAM", Cmd.MEM_DATA, header + data, checksum(data))
    }

    private fun memFinish(entrypoint: Long) {
        val data = le32(if (entrypoint == 0L) 1 else 0) + le32(entrypoint)
        try {
            checkCommand("leave RAM download mode", Cmd.MEM_END, data, timeoutMs = 500)
        } catch (e: FatalError) {
            // The ROM often resets/changes baud before acking this one
            // cleanly -- same leniency as the Python version's ROM-mode
            // MEM_END_ROM_TIMEOUT handling (loader.py:1122).
        }
    }

    private fun uploadSegment(data: ByteArray, offset: Long) {
        val blocks = (data.size + ESP_RAM_BLOCK - 1) / ESP_RAM_BLOCK
        memBegin(data.size, blocks, ESP_RAM_BLOCK, offset)
        for (seq in 0 until blocks) {
            val from = seq * ESP_RAM_BLOCK
            val to = minOf(from + ESP_RAM_BLOCK, data.size)
            memBlock(data.copyOfRange(from, to), seq)
        }
    }

    /** loader.py:1387 run_stub(): upload .text (+ .data if present), jump
     * to the entry point, and expect the stub's "OHAI" greeting back. */
    fun runStub(stub: StubData) {
        uploadSegment(stub.text, stub.textStart)
        if (stub.data != null && stub.dataStart != null) {
            uploadSegment(stub.data, stub.dataStart)
        }
        memFinish(stub.entry)
        val greeting = readPacket(3000)
        if (greeting.size != 4 || String(greeting, Charsets.US_ASCII) != "OHAI") {
            throw FatalError(
                "Failed to start stub flasher. Unexpected response: " +
                    String(greeting, Charsets.ISO_8859_1)
            )
        }
    }

    /** loader.py:1612 read_flash(), stub-based path. Issues READ_FLASH,
     * then reads raw (non-command-framed) SLIP data frames until [length]
     * bytes have arrived, ACKing the running total after each one, and
     * finally checks a trailing 16-byte MD5 digest frame. */
    fun readFlashStub(offset: Long, length: Long, onProgress: ((Long, Long) -> Unit)? = null): ByteArray {
        checkCommand(
            "read flash",
            Cmd.READ_FLASH,
            le32(offset) + le32(length) + le32(FLASH_SECTOR_SIZE) + le32(64),
        )
        val out = ByteArrayOutputStream()
        var total = 0L
        while (total < length) {
            val p = readRaw(5000)
            out.write(p)
            total += p.size
            if (total < length && p.size.toLong() < FLASH_SECTOR_SIZE) {
                throw FatalError(
                    "Corrupt data, expected ${FLASH_SECTOR_SIZE} bytes but received ${p.size} bytes."
                )
            }
            writeRaw(le32(total))
            onProgress?.invoke(total, length)
        }
        if (total > length) throw FatalError("Read more than expected.")

        val digestFrame = readRaw(5000)
        if (digestFrame.size != 16) {
            throw FatalError("Expected a 16-byte MD5 digest, got ${digestFrame.size} bytes.")
        }
        val actual = MessageDigest.getInstance("MD5").digest(out.toByteArray())
        if (!actual.contentEquals(digestFrame)) {
            throw FatalError(
                "Digest mismatch: expected ${digestFrame.toHex()}, got ${actual.toHex()}."
            )
        }
        return out.toByteArray()
    }

    fun close() {
        try { socket.close() } catch (e: IOException) { /* ignore */ }
    }
}

// ============================================================================
// Chip identification
// (Python: ESPLoader.connect()'s detection block, loader.py:936-1006, plus
// each target's CHIP_NAME/IMAGE_CHIP_ID/MAGIC_VALUE in esptool/targets/*.py)
// ============================================================================

data class ChipDef(
    val name: String,       // e.g. "ESP32-C3", matches Python CHIP_NAME
    val slug: String,       // e.g. "esp32c3", matches --chip and the stub json filename stem
    val imageChipId: Int?,  // matched against GET_SECURITY_INFO's chip_id field, if present
    val magicValue: Long?,  // matched against CHIP_DETECT_MAGIC_REG_ADDR, if present
) {
    val jsonName get() = "$slug.json"
}

val CHIPS = listOf(
    ChipDef("ESP32", "esp32", imageChipId = 0, magicValue = 0x00F01D83L),
    ChipDef("ESP32-S2", "esp32s2", imageChipId = 2, magicValue = 0x000007C6L),
    ChipDef("ESP32-S3", "esp32s3", imageChipId = 9, magicValue = null),
    ChipDef("ESP32-C3", "esp32c3", imageChipId = 5, magicValue = null),
    ChipDef("ESP32-C2", "esp32c2", imageChipId = 12, magicValue = null),
    ChipDef("ESP32-C6", "esp32c6", imageChipId = 13, magicValue = null),
    ChipDef("ESP32-C61", "esp32c61", imageChipId = 20, magicValue = null),
    ChipDef("ESP32-C5", "esp32c5", imageChipId = 23, magicValue = null),
    ChipDef("ESP32-H2", "esp32h2", imageChipId = 16, magicValue = null),
    ChipDef("ESP32-H4", "esp32h4", imageChipId = 28, magicValue = null),
    ChipDef("ESP32-P4", "esp32p4", imageChipId = 18, magicValue = null),
    ChipDef("ESP32-S31", "esp32s31", imageChipId = 32, magicValue = null),
    ChipDef("ESP8266", "esp8266", imageChipId = null, magicValue = 0xFFF0C101L),
)
// Not included: ESP32-E22 (image_chip_id=31) and ESP32-H21 (image_chip_id=25)
// -- both USES_MAGIC_VALUE=False and neither ships stub_flasher JSON data in
// the original project either, so stub-based read-flash can't work for them
// regardless of language. See esp32e22.py / esp32h21.py.

/**
 * loader.py's connect() tries GET_SECURITY_INFO first (works on ESP32-S3
 * and later), and falls back to the classic magic-value register read for
 * older chips (ESP8266/ESP32) or ESP32-S2 (whose 12-byte security-info
 * reply doesn't include a chip_id, so this naturally falls through to the
 * magic-value path and finds it there instead -- see the file header notes
 * on why that's fine here).
 */
fun detectChip(conn: EspConnection): ChipDef {
    var chipIdFromSecurityInfo: Int? = null
    try {
        val resp = conn.checkCommandData(
            "get security info", Cmd.GET_SECURITY_INFO, respDataLen = 20, timeoutMs = 1000
        )
        // layout: flags(4) + flash_crypt_cnt(1) + 7*key_purposes(1 each) +
        // chip_id(4) + api_version(4) -- chip_id starts at byte offset 12
        chipIdFromSecurityInfo = readLe32(resp, 12).toInt()
    } catch (e: FatalError) {
        // GET_SECURITY_INFO unsupported (old ROM) or came back short (the
        // ESP32-S2 12-byte variant) -- fall back to magic-value below either way.
    }
    if (chipIdFromSecurityInfo != null) {
        return CHIPS.firstOrNull { it.imageChipId == chipIdFromSecurityInfo }
            ?: throw FatalError(
                "Connected, but chip_id $chipIdFromSecurityInfo doesn't match any " +
                    "chip this build knows about."
            )
    }
    val magic = conn.readReg(CHIP_DETECT_MAGIC_REG_ADDR)
    return CHIPS.firstOrNull { it.magicValue == magic }
        ?: throw FatalError(
            "Could not auto-detect chip type (magic value 0x${magic.toString(16)})."
        )
}

// ============================================================================
// Minimal JSON parsing, just for the stub_flasher/*.json files
// (their schema: {"text": "<base64>", "text_start": int, "entry": int,
//  "data": "<base64>", "data_start": int, "bss_start": int, ...extra
//  plugin-related fields we don't use}. A small real recursive-descent
// parser rather than a hand-rolled extractor, to avoid depending on any
// external JSON library.)
// ============================================================================

private sealed class Json {
    data class Obj(val map: Map<String, Json>) : Json()
    data class Arr(val items: List<Json>) : Json()
    data class Str(val value: String) : Json()
    data class Num(val value: Double) : Json()
    data class Bool(val value: Boolean) : Json()
    object Null : Json()
}

private class JsonParser(private val s: String) {
    private var i = 0

    fun parse(): Json {
        skipWs()
        val v = parseValue()
        skipWs()
        return v
    }

    private fun skipWs() { while (i < s.length && s[i].isWhitespace()) i++ }

    private fun parseValue(): Json {
        skipWs()
        return when (s[i]) {
            '{' -> parseObject()
            '[' -> parseArray()
            '"' -> Json.Str(parseStringRaw())
            't' -> { expect("true"); Json.Bool(true) }
            'f' -> { expect("false"); Json.Bool(false) }
            'n' -> { expect("null"); Json.Null }
            else -> parseNumber()
        }
    }

    private fun expect(lit: String) {
        if (!s.regionMatches(i, lit, 0, lit.length)) {
            error("Expected '$lit' at position $i")
        }
        i += lit.length
    }

    private fun parseObject(): Json.Obj {
        i++ // {
        val map = LinkedHashMap<String, Json>()
        skipWs()
        if (s[i] == '}') { i++; return Json.Obj(map) }
        while (true) {
            skipWs()
            val key = parseStringRaw()
            skipWs()
            if (s[i] != ':') error("Expected ':' at position $i")
            i++
            map[key] = parseValue()
            skipWs()
            when (s[i]) {
                ',' -> { i++; continue }
                '}' -> { i++; break }
                else -> error("Expected ',' or '}' at position $i")
            }
        }
        return Json.Obj(map)
    }

    private fun parseArray(): Json.Arr {
        i++ // [
        val items = mutableListOf<Json>()
        skipWs()
        if (s[i] == ']') { i++; return Json.Arr(items) }
        while (true) {
            items.add(parseValue())
            skipWs()
            when (s[i]) {
                ',' -> { i++; continue }
                ']' -> { i++; break }
                else -> error("Expected ',' or ']' at position $i")
            }
        }
        return Json.Arr(items)
    }

    private fun parseStringRaw(): String {
        if (s[i] != '"') error("Expected '\"' at position $i")
        i++
        val sb = StringBuilder()
        while (s[i] != '"') {
            if (s[i] == '\\') {
                i++
                when (s[i]) {
                    '"' -> sb.append('"')
                    '\\' -> sb.append('\\')
                    '/' -> sb.append('/')
                    'n' -> sb.append('\n')
                    't' -> sb.append('\t')
                    'r' -> sb.append('\r')
                    'b' -> sb.append('\b')
                    'f' -> sb.append('\u000C')
                    'u' -> {
                        val hex = s.substring(i + 1, i + 5)
                        sb.append(hex.toInt(16).toChar())
                        i += 4
                    }
                    else -> sb.append(s[i])
                }
                i++
            } else {
                sb.append(s[i]); i++
            }
        }
        i++ // closing quote
        return sb.toString()
    }

    private fun parseNumber(): Json.Num {
        val start = i
        if (s[i] == '-') i++
        while (i < s.length && s[i].isDigit()) i++
        if (i < s.length && s[i] == '.') {
            i++
            while (i < s.length && s[i].isDigit()) i++
        }
        if (i < s.length && (s[i] == 'e' || s[i] == 'E')) {
            i++
            if (s[i] == '+' || s[i] == '-') i++
            while (i < s.length && s[i].isDigit()) i++
        }
        return Json.Num(s.substring(start, i).toDouble())
    }
}

private fun Json.asObj(): Map<String, Json> = (this as Json.Obj).map
private fun Json.asStr(): String = (this as Json.Str).value
private fun Json.asLong(): Long = (this as Json.Num).value.toLong()

// ============================================================================
// Stub flasher payload (loader.py:185-260 StubFlasher.__init__)
// ============================================================================

data class StubData(
    val text: ByteArray,
    val textStart: Long,
    val entry: Long,
    val data: ByteArray?,
    val dataStart: Long?,
)

/**
 * Loads targets/stub_flasher/{2,1}/<chip>.json, same search order and same
 * file format as the Python version's StubFlasher (loader.py:187-260) --
 * this build re-uses the exact same JSON asset files, no stub bytecode was
 * re-implemented or ported, only the loader for it.
 */
fun loadStub(stubDir: File, chip: ChipDef): StubData {
    val candidates = listOf(File(stubDir, "2/${chip.jsonName}"), File(stubDir, "1/${chip.jsonName}"))
    val jsonFile = candidates.firstOrNull { it.exists() }
        ?: throw FatalError(
            "No stub flasher data for ${chip.name}. Looked for: " +
                candidates.joinToString(", ") { it.path }
        )
    val obj = JsonParser(jsonFile.readText(Charsets.UTF_8)).parse().asObj()
    val text = Base64.getDecoder().decode(obj.getValue("text").asStr())
    val textStart = obj.getValue("text_start").asLong()
    val entry = obj.getValue("entry").asLong()
    val data = obj["data"]?.let { Base64.getDecoder().decode(it.asStr()) }
    val dataStart = obj["data_start"]?.asLong()
    return StubData(text, textStart, entry, data, dataStart)
}

// ============================================================================
// CLI
// ============================================================================

private fun parseIntArg(s: String): Long =
    if (s.startsWith("0x") || s.startsWith("0X")) s.substring(2).toLong(16) else s.toLong()

private fun parseSizeArg(s: String): Long {
    val trimmed = s.trim()
    val mult = when {
        trimmed.endsWith("K", ignoreCase = true) -> 1024L
        trimmed.endsWith("M", ignoreCase = true) -> 1024L * 1024L
        else -> 1L
    }
    val numPart = if (mult != 1L) trimmed.dropLast(1) else trimmed
    return parseIntArg(numPart) * mult
}

private fun jarDirectory(): File {
    val location = object {}.javaClass.protectionDomain.codeSource.location.toURI()
    val f = File(location)
    return if (f.isFile) f.parentFile else f
}

private fun printUsage() {
    System.err.println(
        """
        Usage: esptool_readflash.jar --port socket://HOST:PORT [--chip auto|esp32|esp32c3|...] ADDRESS SIZE OUTPUT

        Reads SIZE bytes of SPI flash starting at ADDRESS and writes them to OUTPUT,
        using the stub flasher for speed. Only socket:// (TCP bridge, e.g. Termux'
        TCPUART app) ports are supported -- put the chip in bootloader/download mode
        yourself first, since reset can't be done over a plain TCP socket.

        ADDRESS and SIZE accept 0x-prefixed hex or decimal, and SIZE also accepts a
        trailing K or M suffix (e.g. 0x400000 or 4M).

        Example:
          esptool_readflash.jar --port socket://127.0.0.1:8080 --chip esp32 read-flash 0x0 0x400000 dump.bin
        """.trimIndent()
    )
}

// ============================================================================
// Self-test: no real hardware was available while writing this, so this
// exercises what CAN be checked mechanically -- SLIP framing round-trips,
// the checksum algorithm against a hand-computed value, little-endian
// packing round-trips, and the JSON parser against a real, bundled
// stub_flasher JSON file. It does NOT prove the wire protocol is correct
// against an actual chip -- only that these building blocks behave as
// intended. Run with `--selftest [path-to-targets-dir]`.
// ============================================================================

private fun runSelfTest(stubDirArg: String?): Boolean {
    var ok = true
    fun check(name: String, pass: Boolean, detail: String = "") {
        println((if (pass) "PASS" else "FAIL") + " - $name" + if (detail.isNotEmpty()) " ($detail)" else "")
        if (!pass) ok = false
    }

    // SLIP round-trip, including bytes that need escaping (0xC0, 0xDB)
    run {
        val original = byteArrayOf(0x01, 0x02, 0x03, 0xC0.toByte(), 0xDB.toByte(), 0x00, 0xFF.toByte())
        val encoded = Slip.encode(original)
        val decoded = SlipReader(java.io.ByteArrayInputStream(encoded)).readPacket()
        check("SLIP round-trip", decoded.contentEquals(original), "got ${decoded.toHex()}")
    }

    // Checksum against a hand-computed expected value (XOR of 0xEF with each byte)
    run {
        val data = byteArrayOf(0x01, 0x02, 0x03, 0xC0.toByte(), 0xDB.toByte())
        var state = ESP_CHECKSUM_MAGIC
        for (b in data) state = state xor (b.toInt() and 0xFF)
        check("checksum algorithm", state == 0xF4, "got 0x${state.toString(16)}, expected 0xf4")
    }

    // little-endian pack/unpack round-trip
    run {
        val v = 0x12345678L
        val packed = le32(v)
        val expected = byteArrayOf(0x78, 0x56, 0x34.toByte(), 0x12)
        check("le32 byte order", packed.contentEquals(expected), "got ${packed.toHex()}")
        check("le32/readLe32 round-trip", readLe32(packed, 0) == v)
    }
    run {
        val v = 0xABCD
        val packed = le16(v)
        check("le16/readLe16 round-trip", readLe16(packed, 0) == v)
    }

    // JSON parser against a real bundled stub file, if we can find one
    val stubDir = File(stubDirArg ?: File(jarDirectory(), "targets/stub_flasher").path)
    val sampleJson = File(stubDir, "2/esp32.json").let {
        if (it.exists()) it else File(stubDir, "1/esp32.json")
    }
    if (sampleJson.exists()) {
        try {
            val stub = loadStub(stubDir, CHIPS.first { it.slug == "esp32" })
            check(
                "JSON parse of ${sampleJson.path}",
                stub.text.isNotEmpty() && stub.textStart > 0 && stub.entry > 0,
                "text=${stub.text.size} bytes, textStart=0x${stub.textStart.toString(16)}, " +
                    "entry=0x${stub.entry.toString(16)}"
            )
        } catch (e: Exception) {
            check("JSON parse of ${sampleJson.path}", false, e.message ?: e.toString())
        }
    } else {
        println(
            "SKIP - JSON parse test (no targets/stub_flasher/{1,2}/esp32.json found near " +
                "the jar or at the given path; pass --selftest <path-to-targets-dir> if you " +
                "extracted the zip somewhere unusual)"
        )
    }

    return ok
}

fun main(args: Array<String>) {
    if (args.isNotEmpty() && args[0] == "--selftest") {
        val stubDirArg = args.getOrNull(1)
        val passed = runSelfTest(stubDirArg)
        exitProcess(if (passed) 0 else 1)
    }

    var port: String? = null
    var chipArg = "auto"
    val positional = mutableListOf<String>()
    var i = 0
    while (i < args.size) {
        when (args[i]) {
            "--port", "-p" -> { port = args.getOrNull(i + 1); i += 2 }
            "--chip", "-c" -> { chipArg = args.getOrNull(i + 1) ?: "auto"; i += 2 }
            "--help", "-h" -> { printUsage(); return }
            "read-flash" -> { i += 1 } // accepted and ignored, for command-line familiarity
            else -> { positional.add(args[i]); i += 1 }
        }
    }
    if (positional.size != 3) {
        printUsage()
        exitProcess(1)
    }
    val portArg: String = port ?: run {
        printUsage()
        exitProcess(1)
    }

    val address: Long
    val size: Long
    val outputPath: String
    try {
        address = parseIntArg(positional[0])
        size = parseSizeArg(positional[1])
        outputPath = positional[2]
    } catch (e: NumberFormatException) {
        System.err.println("Couldn't parse ADDRESS/SIZE: ${e.message}")
        exitProcess(1)
    }

    val uri = try { URI(portArg) } catch (e: Exception) {
        System.err.println("Invalid --port value: $portArg")
        exitProcess(1)
    }
    val host: String = uri.host ?: run {
        System.err.println(
            "Only socket://HOST:PORT ports are supported by this build (got: $portArg)."
        )
        exitProcess(1)
    }
    val tcpPort = uri.port
    if (uri.scheme != "socket" || tcpPort == -1) {
        System.err.println(
            "Only socket://HOST:PORT ports are supported by this build (got: $portArg)."
        )
        exitProcess(1)
    }

    println("Connecting to $host:$tcpPort ...")
    println(
        "Note: this build can't reset the chip over TCP -- make sure it's already " +
            "in bootloader/download mode."
    )

    val conn = try {
        EspConnection(host, tcpPort)
    } catch (e: IOException) {
        System.err.println("Couldn't connect to $host:$tcpPort: ${e.message}")
        exitProcess(1)
    }

    var connected = false
    var lastError: Exception? = null
    for (attempt in 1..5) {
        try {
            conn.drainInput()
            conn.sync()
            connected = true
            break
        } catch (e: Exception) {
            lastError = e
            print(".")
            System.out.flush()
            Thread.sleep(50)
        }
    }
    println()
    if (!connected) {
        System.err.println("Failed to connect: ${lastError?.message}")
        conn.close()
        exitProcess(1)
    }

    try {
        val chip = if (chipArg == "auto") {
            detectChip(conn)
        } else {
            CHIPS.firstOrNull { it.slug.equals(chipArg, ignoreCase = true) }
                ?: run {
                    System.err.println(
                        "Unknown --chip '$chipArg'. Known: auto, " +
                            CHIPS.joinToString(", ") { it.slug }
                    )
                    exitProcess(1)
                }
        }
        println("Detected chip: ${chip.name}")

        val stubDir = File(jarDirectory(), "targets/stub_flasher")
        val stub = loadStub(stubDir, chip)

        println("Uploading stub flasher...")
        conn.runStub(stub)
        println("Stub flasher running.")

        println("Reading $size bytes from 0x${address.toString(16)}...")
        val data = conn.readFlashStub(address, size) { done, total ->
            print("\rRead $done / $total bytes")
            System.out.flush()
        }
        println()
        File(outputPath).writeBytes(data)
        println("Wrote ${data.size} bytes to $outputPath")
    } catch (e: FatalError) {
        println()
        System.err.println("Error: ${e.message}")
        exitProcess(1)
    } finally {
        conn.close()
    }
}
