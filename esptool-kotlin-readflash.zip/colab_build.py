# ============================================================
# Build the Kotlin esptool read-flash tool (Google Colab)
#
# Paste this into a Colab code cell and run it. It will:
#   1. Ask you to upload esptool-kotlin-readflash.zip (the file from chat)
#   2. Install a JDK and the Kotlin compiler
#   3. Compile EsptoolReadFlash.kt into a single runnable jar
#   4. Run --selftest (SLIP framing / checksum / byte packing / JSON
#      parsing checks -- NOT a substitute for testing against real hardware)
#   5. Package the jar + the stub data it needs, and download it back to you
# ============================================================
import os
import subprocess

def run(cmd):
    print(f"$ {cmd}")
    result = subprocess.run(cmd, shell=True)
    if result.returncode != 0:
        raise RuntimeError(f"Command failed ({result.returncode}): {cmd}")

# 1) Upload esptool-kotlin-readflash.zip
from google.colab import files
print("Select esptool-kotlin-readflash.zip to upload...")
uploaded = files.upload()
zip_name = next(iter(uploaded))

# 2) Unpack it
run(f"rm -rf esptool-kotlin && mkdir esptool-kotlin && unzip -q -o '{zip_name}' -d esptool-kotlin")
os.chdir("esptool-kotlin")

# 3) Make sure a JDK, unzip, and curl are available
run("apt-get -qq update && apt-get -qq install -y openjdk-17-jdk-headless unzip curl > /dev/null")
run("java -version")

# 4) Install the Kotlin compiler if it isn't already on PATH
have_kotlinc = subprocess.run(
    "command -v kotlinc", shell=True,
    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
).returncode == 0
if not have_kotlinc and not os.path.exists("/opt/kotlinc/bin/kotlinc"):
    run(
        "KOTLIN_VERSION=$(curl -fsSL https://api.github.com/repos/JetBrains/kotlin/releases/latest "
        "| grep -Po '\"tag_name\": \"v\\K[^\"]*' || echo 2.4.0); "
        "echo \"Installing Kotlin $KOTLIN_VERSION\"; "
        "curl -fsSL \"https://github.com/JetBrains/kotlin/releases/download/v${KOTLIN_VERSION}"
        "/kotlin-compiler-${KOTLIN_VERSION}.zip\" -o /tmp/kotlinc.zip && "
        "unzip -q -o /tmp/kotlinc.zip -d /opt"
    )
os.environ["PATH"] = "/opt/kotlinc/bin:" + os.environ["PATH"]
run("kotlinc -version")

# 5) Compile the single Kotlin file into a runnable, self-contained jar
run("kotlinc EsptoolReadFlash.kt -include-runtime -d esptool_readflash.jar")

# 6) Run the self-test -- checks SLIP framing, the checksum algorithm, byte
#    packing, and JSON parsing against the real bundled stub files. This is
#    NOT a real-hardware test; it only proves these building blocks work.
run("java -jar esptool_readflash.jar --selftest")

print()
print("Build succeeded: esptool-kotlin/esptool_readflash.jar")
print("Usage:")
print("  java -jar esptool_readflash.jar --port socket://HOST:PORT [--chip auto] ADDRESS SIZE OUTPUT")

# 7) Package the jar + the stub data it needs alongside it, and download
run("zip -q -r ../esptool_readflash_build.zip esptool_readflash.jar targets")
os.chdir("..")
files.download("esptool_readflash_build.zip")
