# esptool read-flash — Kotlin/JVM port

A from-scratch Kotlin rewrite of `read-flash` with stub-loader support,
talking to the chip over a TCP socket (`socket://host:port` — the
Termux-TCP-bridge scenario this whole project has been built around).

## Please read this before trusting it

Everything before this was a **mechanical repackaging** of the real
esptool source — verifiably byte-identical, tested end-to-end against the
actual protocol logic. This is different: it's a **reimplementation in a
different language**, written by reading the relevant parts of
`esptool/loader.py`, `esptool/cmds.py`, and `esptool/targets/*.py` and
translating the protocol by hand. I do not have a Kotlin compiler or any
ESP hardware / TCP bridge available in the environment this was written
in, so:

- It has **not been compiled**. I reviewed it line by line for syntax
  and logic errors (and found and fixed four real bugs that way — see
  below), and checked brace/paren balance mechanically, but that's not a
  substitute for a real compiler. The Colab cell below compiles it for
  real, as the first thing it does.
- It has **not been run against a real chip**. The `--selftest` mode
  (see below) checks what can be checked without hardware — SLIP framing,
  the checksum algorithm, byte packing, and JSON parsing against the
  actual bundled stub files — but none of that proves the wire protocol
  is correct against real silicon. Please test cautiously.

Bugs found during review, for transparency: an `uploadSegment` loop that
didn't match the block-count logic it was supposed to; a `detectChip`
bug where a real error ("connected, but I don't recognize this chip")
was accidentally swallowed by its own fallback path; a retry loop using
`return@repeat`, which only skips to the next attempt rather than
stopping the loop, so it would've kept retrying after already
succeeding; and a couple of nullable-type edge cases around CLI argument
parsing that would likely have been compile errors. All fixed, per the
comments in the file — but this list is exactly why "please test
cautiously" above isn't boilerplate.

## Scope (see the comment block at the top of the .kt file for the full list)

Included: TCP socket transport, full SLIP framing, sync/connect, stub
upload (MEM_BEGIN/DATA/END), the "OHAI" stub handshake, and the
stub-based read-flash streaming protocol (data frames + ACK + MD5
verification) — for all 13 chips that both (a) support stub loading and
(b) ship stub data in the original project.

Not included: real serial ports (socket:// only), custom SPI pin
configs, NAND flash, flash-size bounds-checking, ESP32-P4's
revision-dependent stub selection (always uses the newer-silicon stub),
and the ESP32-S3-secure-boot stub-injection workaround. ESP32-E22 and
ESP32-H21 aren't included in chip detection since the original project
ships no stub data for either of them either.

## Files

```
EsptoolReadFlash.kt                <- the entire program, one file
targets/stub_flasher/1/*.json      <- same stub payload data as the Python version
targets/stub_flasher/2/*.json
```

The stub JSON files are reused as-is from the original project — no stub
bytecode was reimplemented, only the loader for it, so these need to sit
next to the compiled jar in a `targets/stub_flasher/...` folder, same
convention as the earlier single-file Python build.

## Building it

See the Colab cell provided separately (or below, if you're reading this
alongside it) — it installs a JDK and the Kotlin compiler, compiles
`EsptoolReadFlash.kt` into a single runnable jar with
`kotlinc -include-runtime`, and runs `--selftest`.

To build locally instead (Linux/macOS with a JDK installed):

```bash
# install kotlinc: https://kotlinlang.org/docs/command-line.html
kotlinc EsptoolReadFlash.kt -include-runtime -d esptool_readflash.jar
java -jar esptool_readflash.jar --selftest
```

## Running it

```bash
java -jar esptool_readflash.jar --port socket://127.0.0.1:8080 --chip esp32 0x0 0x400000 dump.bin
java -jar esptool_readflash.jar --port socket://127.0.0.1:8080 0x0 4M dump.bin   # --chip auto is the default
```

As with the Python version over `socket://`, this can't reset the chip
into bootloader/download mode over a plain TCP socket — do that manually
first.
