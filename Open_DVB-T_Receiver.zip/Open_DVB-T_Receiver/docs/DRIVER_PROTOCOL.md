# DVB-T Driver interface (from the driver source and cross-checked with Aerial TV's client)

**Start:** `startActivityForResult(Intent(ACTION_VIEW, Uri "dtvdriver:"))`. `ActivityNotFoundException` ⇒ driver app missing.
The driver also broadcasts an activity intent with action `info.martinmarinov.dvbdriver.DVB_DEVICE_ATTACHED` when a supported tuner is plugged in.

**Result:** `RESULT_OK` → extras `ControlPort:int`, `TransferPort:int`, `DeviceName:String`, `VendorIds:int[]`, `ProductIds:int[]`.
`RESULT_FIRST_USER` → `ErrorCode:String` (BAD_API_USAGE, IO_EXCEPTION, NO_DVB_DEVICES_FOUND, UNSUPPORTED_PLATFORM, USB_PERMISSION_DENIED, CANNOT_OPEN_USB, HARDWARE_EXCEPTION, CANNOT_TUNE_TO_FREQ, UNSUPPORTED_BANDWIDTH, DVB_DEVICE_UNSUPPORTED), `RawTrace`, optional vendor/product lists. `RESULT_CANCELED` = cancelled.

**Sockets:** two TCP connections to `127.0.0.1`: control (`ControlPort`) and transfer (`TransferPort`, raw MPEG-TS, 188-byte aligned). The driver accepts within 60 s.

**Control messages** (big-endian): request `[ordinal:u8][n:u8][n × int64]`; response same shape, first int64 = 1 on success.

| # | Command | Request | Response (after flag) |
|---|---|---|---|
| 0 | PROTOCOL_VERSION | – | version, command count |
| 1 | EXIT | – | – |
| 2 | TUNE | freqHz, bandwidthHz, system | – |
| 3 | GET_STATUS | – | snr, ber, droppedUsbFps, rfStrength%, hasSignal, hasCarrier, hasSync, hasLock |
| 4 | SET_PIDS | pid… | – |
| 5 | GET_CAPABILITIES | – | systemMask, freqMin, freqMax, freqStep, vendorId, productId |

System ordinals: DVBT=0, DVBT2=1, DVBC=2 (mask bit = 1 << ordinal). Units of snr/ber are not specified by the driver API; the app shows them raw.
Implementation: `driver/DriverProtocol.kt`, `DriverClient.kt`; tested against a fake driver in `ProtocolAndParserTest.kt`.
