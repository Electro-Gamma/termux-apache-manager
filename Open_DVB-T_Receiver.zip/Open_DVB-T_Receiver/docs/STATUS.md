# Implementation / test status (honest report)

Legend: ✅ done and verified here · 🟡 implemented, **not compiled/run on a device** · ⛔ not implemented

| Area | State | Evidence |
|---|---|---|
| Driver protocol codec + client | ✅ | JVM tests incl. fake driver over real TCP sockets (`ProtocolAndParserTest`) — 15/15 pass, run with Kotlin 1.9.24 compiler in the dev sandbox |
| TS packet alignment/resync, CRC-32, section reassembly, CC checks | ✅ | same tests |
| PAT/PMT/SDT/NIT/EIT parsers, DVB text, MJD time | ✅ | synthetic sections built to spec; **not** validated against real broadcasts |
| PID-filtered writer (pipe/recording) | ✅ | unit test |
| Android code (UI, DvbSession, Scanner, PlaybackEngine, ChannelStore, recorder) | 🟡 | passes the Kotlin parser; **not compiled** (no Android SDK / Maven access in the dev sandbox). First Colab build may need small compile fixes |
| libVLC playback (HW→SW fallback, pipe fd) | 🟡 | design verified from Aerial TV code; never run |
| Channel scan, manual tune, EPG, recording, diagnostics UI | 🟡 | never run on hardware |
| DVB-T2 | 🟡 | tried only if the tuner reports it; no T2 hardware tested |
| DVB subtitles / teletext rendering | ⛔ | PIDs are parsed and listed; no renderer (libVLC may render DVB subs if selectable) |
| Tested tuners / phones / codecs | none | see `COMPATIBILITY.md` (empty on purpose) |

Known limits: European raster only for scanning (use Manual elsewhere); ISO-6937 text approximated by Latin-1; EPG kept in memory only; SNR/BER shown raw.

Background operation: playback is owned by the app (`OpenDvbApp.engine`), not the player screen. Home / app switch keeps audio, a recording and a scan running under `BackgroundService` (foreground service, mediaPlayback, ongoing notification with Open/Stop, partial wake lock); the picture is detached and re-attached on return. Back stops playback and recording.
FC0012: GPIO4 reset + output enable retry before tuner probing, FC0012 PLL range fix, extra RTL2832U USB IDs; the "unrecognised tuner" error now lists the raw I2C probe values.
