# Design: Material 3, light and dark

* **Theme:** `Theme.Material3.DayNight` (`AppTheme`). It follows the system setting automatically; nothing to switch in the app.
  The player uses an always-dark Material 3 theme (`AppThemeDark`) because it shows video.
* **Palette:** a teal scheme, defined once as colour roles in `app/src/main/res/values/colors.xml` (light) and
  `values-night/colors.xml` (dark). The dark values are `md_dark_*`. Change these two files to re-colour the whole app, including the
  driver screens. Dynamic (wallpaper) colour is deliberately not used so contrast and look are the same on every phone.
* **One theme for everything:** the driver screens (diagnostics, network receiver, licence) and the device chooser are declared in the
  driver libraries; the app manifest overrides their theme with `AppTheme.NoActionBar` / `AppTheme.Dialog`, so they share the palette and dark mode.
* **Components:** `ui/Ui.kt` builds Material buttons (filled = main action, tonal = secondary, text = video overlay), a tonal status card,
  automatic spacing between stacked widgets, Material list text styles. Dialogs use `MaterialAlertDialogBuilder`; the manual-tune
  frequency is an outlined `TextInputLayout`; the scan progress is a `LinearProgressIndicator`.
* **Unchanged:** screens, navigation, menu entries and behaviour. Only the look changed.
* Light/dark switching uses resource qualifiers (`-night`), so the colours are right on the first frame without recreating anything by hand.
