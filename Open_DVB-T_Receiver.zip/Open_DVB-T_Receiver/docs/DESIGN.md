# Design: Material 3, light and dark

* **Theme:** `Theme.Material3.DayNight` (`AppTheme`). It follows the system setting automatically; nothing to switch in the app.
  The player uses an always-dark Material 3 theme (`AppThemeDark`) because it shows video.
* **Palette:** a teal scheme, defined once as colour roles in `app/src/main/res/values/colors.xml` (light) and
  `values-night/colors.xml` (dark). The dark values are `md_dark_*`. Change these two files to re-colour the whole app, including the
  driver screens. Dynamic (wallpaper) colour is deliberately not used so contrast and look are the same on every phone.
* **One theme for everything:** the driver screens (diagnostics, network receiver, driver info, licence) and the device chooser are declared
  in the driver libraries; the app manifest overrides their theme with `AppTheme` (same action bar, palette and dark mode as the home screen)
  / `AppTheme.Dialog`. Every secondary screen, driver or receiver, extends `UpActivity` (action bar with a back arrow). Driver layouts use
  the same components as the home screen: pill `MaterialButton`s (filled = main action, tonal = secondary), outlined `TextInputLayout`s,
  exposed drop-downs instead of spinners, `MaterialCheckBox`, rounded `LinearProgressIndicator`, and the tonal `DvbCard` (same fill and
  16 dp radius as the receiver's status card). Dialogs everywhere are `MaterialAlertDialogBuilder`.
* **Components:** `ui/Ui.kt` builds Material buttons (filled = main action, tonal = secondary, text = video overlay), a tonal status card,
  automatic spacing between stacked widgets, Material list text styles. Dialogs use `MaterialAlertDialogBuilder`; the manual-tune
  frequency is an outlined `TextInputLayout`; the scan progress is a `LinearProgressIndicator`.
* **Channel list = the VNC tab's list:** `ChannelListAdapter` draws the scanned channels exactly like the connections on the VNC home screen:
  list view (rows grouped with 16 dp / 4 dp corners, 2 dp gap, 1 dp outline, 76 x 64 dp preview, title, subtitle, badges) or grid view (outlined
  cards, preview band of 0.72 x width with badges over it). The toolbar button switches between them and the choice is remembered; favourites
  ("pinned") come first. Pressing plays, holding toggles the favourite (as before). Column counts follow the same rule as the VNC tab.
* **Channel previews:** while a channel plays, `PlayerActivity` copies the video frame (PixelCopy, Android 7+) a few seconds after playback
  starts and every 20 s, and `ChannelThumbnails` keeps the latest picture per channel key (frequency + service id) in
  `files/channel_previews/`. The picture stays with its channel across screens, restarts and rescans; only "Delete channel list" clears it.
  Channels that have not been watched yet show a faint TV icon, like a VNC connection that was never opened. Black frames are never stored.
* **Scanning:** each multiplex is added to the channel list as soon as it has been scanned (`Scanner.onMultiplexFound`), not only at the end.
* **Unchanged:** scanning and tuning logic, driver protocol, navigation, menu entries and the other behaviour. The home screen's "Manual tune"
  button is now "Manual".
* Light/dark switching uses resource qualifiers (`-night`), so the colours are right on the first frame without recreating anything by hand.
