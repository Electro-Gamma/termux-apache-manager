# How the driver was integrated

Goal: one application, one launcher, the original Open DVB Receiver behaviour intact, driver diagnostics and network receiver in the menu.

## Structure
The driver's Gradle project (`app`, `drivers`, `dvbservice`, `usbxfer`) was brought into this project. Its `app` module became the **library
`driverui`** (same Java package and namespace `info.martinmarinov.dvbdriver`, no launcher, no application id), so exactly one module is an
application: `:app` (`org.opendvb.receiver`). The other three modules are unchanged apart from the network receiver (see below).

    :app -> :driverui -> :drivers -> :usbxfer (native)
         -> :dvbservice -> :drivers

## The contract is unchanged
Open DVB Receiver still starts the driver with `ACTION_VIEW dtvdriver:` and talks to the loopback ports it gets back. The only difference:
the intent is now restricted to this app (`setPackage(packageName)`), so it reaches the built-in `DeviceChooserActivity` and can never be
answered by a separately installed DVB-T Driver. USB attach (`UsbDelegate`) still ends in the app's `DVB_DEVICE_ATTACHED` filter on `MainActivity`.

## Conflicts resolved
| Area | Problem when merging | Resolution |
|---|---|---|
| Launcher | driver `WelcomeActivity` was a second MAIN/LAUNCHER | filter removed in `driverui`; `scripts/preflight.py` fails if there is ever more than one |
| `<application>` attributes | the manifest merger errors when the app and a library disagree (`allowBackup` false vs true) | libraries no longer set `allowBackup`/`label`/`supportsRtl`/`icon`/`theme`; the app keeps its values (`tools:replace` added as a safeguard) |
| `uses-feature usb.host` | libraries said `required=true`; the merger ORs `required`, so it could not be relaxed from the app | now `false` in the libraries and `tools:node="replace"` in the app: installable without USB host (network receiver); USB still works where present |
| Themes | the app theme (`AppTheme`, DayNight DarkActionBar) would replace the driver's `AppTheme` for driver screens | driver theme renamed `DvbDriverTheme`, set on each driver activity |
| `app_name` | `values-nb` of the driver UI would override the app label for Norwegian users | `app_name` removed from `driverui`; the app's value is used everywhere (including the service notification) |
| R constants | driver Java uses `R.id.*` in `switch` and `BuildConfig` | `android.nonFinalResIds=false`, `android.defaults.buildfeatures.buildconfig=true` in `gradle.properties` |
| Native library | `libUsbXfer.so` (C, CMake/NDK) next to libVLC | no name clash; libVLC's `libc++_shared.so` pickFirst rule unchanged; per-ABI split APKs unchanged; NDK + CMake added to the build steps |
| Versions | appcompat 1.5.1 (driver) vs 1.6.1 (app); same AGP 8.5.2, Gradle 8.7, Java 8 level, compileSdk 34, minSdk 21 | Gradle resolves to 1.6.1; targetSdk stays 34 (app) |
| Permissions added by the driver | FOREGROUND_SERVICE (+ media playback type), READ/WRITE_EXTERNAL_STORAGE (driver TS dump), INTERNET (already there) | kept as the driver needs them; the app's own code does not use storage permissions |

## Network receiver
`drivers/.../network/` adds `DvbNetworkDevice`, a `DvbDevice` that talks the driver's own control protocol to `dvbnetd`; `dvbservice`
(`DeviceChooserActivity`, `DvbService`) lists it when an address is saved in `driverui`'s `NetworkReceiverActivity`. See `dvbnetd/docs/PROTOCOL.md`.

## Files of the original Open DVB Receiver that changed
`app/build.gradle` (3 dependencies), `app/src/main/AndroidManifest.xml` (tools namespace, usb.host optional, comments),
`driver/DriverLauncher.kt` (one added overload), `ui/MainActivity.kt` (two menu items, restricted intent, About text, missing-driver message).
All other Kotlin sources, resources and tests are byte-identical to the originals.

## Not verified
Compilation with the Android SDK, installation, USB and network operation on devices. `scripts/preflight.py` covers the static merge risks only.
