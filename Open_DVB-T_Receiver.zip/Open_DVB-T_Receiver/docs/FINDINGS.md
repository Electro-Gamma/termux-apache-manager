# Aerial TV 1.523 – reverse-engineering findings

Method: `REVERSE_ENGINEERING_GUIDE.md` (triage → decompile → string/xref anchors → separate verified facts from assumptions).
Scope: interoperability with the open-source *Android DVB-T Driver* (GPL-2.0, `info.martinmarinov.dvbdriver`).
Not examined, not reproduced, not bypassed: Aerial TV's billing / trial / licence logic. Nothing from the target is copied into this project (code, assets, branding or binaries).

Legend: **[V]** verified in the supplied files · **[S]** taken from the driver source (supplied zip) · **[A]** assumption · **[U]** unknown / not checkable.

## 1. Inventory

| Item | Value |
|---|---|
| `base.apk` | package `info.martinmarinov.aerialtv`, versionName 1.523 (6051), minSdk 21, targetSdk 36, sha256 `64cb788b…14192a` |
| `split_config.arm64_v8a.apk` | contains only `lib/arm64-v8a/libvlcjni.so` (100 288 B) and `libc++_shared.so`; **`libvlc.so` was removed by the user** (size), sha256 `a79fe06e…ce553` |
| Obfuscation | R8: only 12 classes keep readable names (activities, `DvbService`, `ItemScroller`, `AnimatedProgress`); logic is in short-named packages (`z1`, `C1`, `A1`, `u1`, `w1`, `x1`, `s1`, `D1`, `E1`) – names below are the obfuscated ones **[V]** |
| Assets | `assets/lua/**` (VLC lua playlist/meta scripts for web services – unused for DVB), `assets/hrtfs/*.sofa` (VLC audio HRTF) → both come from the stock VLC-Android library **[V]** |
| Permissions | INTERNET, FOREGROUND_SERVICE(+MEDIA_PLAYBACK), BILLING, ACCESS_NETWORK_STATE; `uses-feature usb.host` required **[V]** |
| Components | `SplashScreen` (launcher; also filters `info.martinmarinov.dvbdriver.DVB_DEVICE_ATTACHED`), `TvActivity`, `TuneStartActivity`, `TuneActivity`, `ManualTuneActivity`, `EpgActivity`, `LicenseDisplayActivity`, `DvbService` (foreground, `mediaPlayback`) **[V]** |

## 2. Driver integration (verified from both sides)

1. Launch `Intent(ACTION_VIEW, Uri "dtvdriver:")` with `startActivityForResult` (`C1.h.f57d`). `ActivityNotFoundException` ⇒ "driver not installed" screen. **[V]** and **[S]** (`README.md`)
2. Result extras (`E1.l`, driver `DeviceChooserActivity`): success `RESULT_OK` → `ControlPort:int`, `TransferPort:int`, `DeviceName:String`, `ProductIds:int[]`, `VendorIds:int[]`. Error `RESULT_FIRST_USER (1)` → `ErrorCode:String` (enum `BAD_API_USAGE, IO_EXCEPTION, NO_DVB_DEVICES_FOUND, UNSUPPORTED_PLATFORM, USB_PERMISSION_DENIED, CANNOT_OPEN_USB, HARDWARE_EXCEPTION, CANNOT_TUNE_TO_FREQ, UNSUPPORTED_BANDWIDTH, DVB_DEVICE_UNSUPPORTED`), `RawTrace:String`, plus lists of attached USB ids. `RESULT_CANCELED` = user cancelled. **[V][S]**
3. Both ports are TCP on **127.0.0.1** (`C1.l.f65a`; driver `InetAddressTools.getLocalLoopback`). Driver accepts within 60 s (`SOCKET_TIMEOUT_MS`). Aerial opens the transfer socket first, then the control socket, `TCP_NODELAY`, control `SO_TIMEOUT` 60 s (`z1.C0440c.b`). **[V][S]**
4. Control protocol (big-endian, `A1.b` ⇄ driver `Request`/`Response`), identical in both: request `[ordinal u8][n u8][n × int64]`, response `[ordinal u8][n u8][n × int64]`, first int64 of the response = success flag (1 = ok); client rejects ordinal mismatch or flag ≠ 1. **[V][S]**

| ordinal | command | request payload | response payload (after flag) |
|---|---|---|---|
| 0 | PROTOCOL_VERSION | – | version (=0), number of commands |
| 1 | EXIT | – | – (Aerial sends it on shutdown and waits 15 s) |
| 2 | TUNE | freqHz, bandwidthHz, deliverySystem ordinal | – |
| 3 | GET_STATUS | – | snr, ber, droppedUsbFps, rfStrength %, hasSignal, hasCarrier, hasSync, hasLock |
| 4 | SET_PIDS | pid… (≤255) | – |
| 5 | GET_CAPABILITIES | – | deliverySystem bitmask (`1<<ordinal`), freqMin, freqMax, freqStep, vendorId, productId |

   `DeliverySystem` ordinals: `DVBT=0, DVBT2=1, DVBC=2` (driver comment: "do not reorder"). Aerial's own enum `z1.EnumC0438a` is decoded with the same bit test. **[V][S]**
5. Transfer socket: raw 188-byte-aligned TS (driver writes chunks of 5×188). **[S]** Units/scaling of `snr` and `ber` are not documented in the driver API → **[U]**, shown raw only.
6. Hardware PID filtering: Aerial's TS layer (`w1.C0371a` reads the socket, 188-byte packets, per-PID processor table) registers processors per PID and then sends **SET_PIDS** with the union (`z1.C0444g.g`). Processors left behind are detected and cleaned up when a "mode" ends. **[V]**
7. Aerial passes `CtrlPort`/`TransfPort`/`DeviceName` to its internal `DvbService` via intent extras – these are Aerial-internal names, **not** the driver contract. **[V]**

## 3. Playback / libVLC

| Question | Answer |
|---|---|
| libVLC API line | Java classes `org.videolan.libvlc.*` (`LibVLC`, `Media`, `MediaPlayer`, `IVLCVout`, `VLCVideoLayout`, `stubs/*`) = the stock **libvlc-android 3.x** AAR layout (`MediaPlayer.getVLCVout`, `Media.setHWDecoderEnabled`). **[V]** for the API line; **[U]** for the exact patch version (`libvlc.so`, where the version string lives, was removed) |
| Native libs | `libvlcjni.so` (AArch64, 118 JNI functions `Java_org_videolan_libvlc_*`, `NEEDED libvlc.so`), `libc++_shared.so`, and `libvlc.so` (missing from the upload). `LibVLC.<clinit>` loads `c++_shared`, `vlc`, `vlcjni` in that order **[V]** |
| ABIs | Only `arm64-v8a` seen in the supplied split; other ABI splits **[U]** |
| Custom native changes | all 118 `Java_*` exports are in package `org.videolan.libvlc`; other exports are `JNI_OnLoad/OnUnload`, `VLCJniObject_*`, `jni_get_env`, `std_logger_*` (the stock VLC-Android helper names). No Aerial-specific JNI symbol → no evidence of custom native code in the shim **[V]**; **[U]** for `libvlc.so` |
| LibVLC options (`z1.o` ctor) | `--aout=opensles --vout=android-display --video-filter=deinterlace --deinterlace=-1 --sout-deinterlace-mode=bob --vbi-opaque --autoscale` **[V]** |
| How TS reaches VLC | **Pipe**: `ParcelFileDescriptor.createPipe()` (`x1.C0381j`). Filtered 188-byte packets are written to the write end; VLC opens the **read end as a file descriptor**: `new Media(libVLC, FileDescriptor)`. A "resetter" thread drains the pipe if a write stalls > 100 ms. **[V]** |
| Start / retry | `Media.setHWDecoderEnabled(hw, false)`; HW decoding on for the first attempt, off afterwards; max 4 attempts, counter reset if the last attempt was > 30 s ago; then "can't tune" error (`z1.o.d`). Stop waits up to 10 s for the player to stop. **[V]** |
| Tracks | audio tracks from `MediaPlayer.getAudioTracks()`, subtitle (SPU) tracks from `getSpuTracks()`; entries matching `Teletext - [..]` are ignored ("currently unsupported") **[V]** |
| Quick channel scan data | per-country frequency lists (e.g. `474…786 MHz`, 8 MHz) + a slower "Full Scan" option (`u1.l`, strings `country_selection`) **[V]** |
| Reuse of the original `.so` | **No.** libvlc/libvlcjni are LGPL-2.1+ (VideoLAN), so redistribution is possible *under LGPL terms*, but an extracted binary has unknown build flags/patches and provenance, and `libvlc.so` is not supplied. This project uses the **official** `org.videolan.android:libvlc-all` AAR from Maven Central. |

## 4. Not investigated / unknown

* Aerial's EPG, PAT/PMT/SDT/EIT parsers, subtitle and Teletext handling were only located (`w1`, `x1`, `s1`, `u1`), not analysed line-by-line; this app's parsers are written from ETSI EN 300 468 / ISO 13818-1 instead. **[A]**
* Ghidra analysis of `libvlcjni.so` was not run in this sandbox (only `readelf`/`strings`); JNI function list taken from `--dyn-syms`. Native addresses are therefore not recorded. **[U]**
* Billing, trial and entitlement code: deliberately not examined.

## 5. Differences in this implementation

* Same driver contract and same libVLC technology (3.x, official AAR); no code reuse.
* Pipe-fd playback like Aerial, but backed by a bounded queue that drops packets instead of a stall-resetter thread.
* Playback options reproduced from the verified list above (HW first, fall back to software).
