# Compatibility matrix

Nothing has been tested on real hardware yet. Fill in after testing.

| Tuner (USB id) | Android device / version | Standard | Codecs verified | Scan | Playback | EPG | Notes |
|---|---|---|---|---|---|---|---|
| – | – | – | – | – | – | – | untested |
