# Architecture

```
MainActivity ──launch──> Driver app (dtvdriver:) ──result(ports)──> DvbSession.connect()
                                                                         │ 2 loopback sockets
 DriverClient (control)  <────────── DvbSession ──────────> TsReader (raw TS) ──> sinks:
   tune / status / setPids                                     TsStats, EPG PsiCollector,
                                                               FilteredTsWriter→pipe→libVLC,
                                                               FilteredTsWriter→SAF file (recording)
 Scanner: tune → waitForLock → PAT+SDT → PMTs → Channel list (ChannelStore, JSON in filesDir)
 PlaybackEngine: tune → SET_PIDS(PAT,PMT,PCR,ES + SDT,EIT) → pipe fd → Media(libVLC, fd)
```
Requested module split mapped to packages: USB/Tuner manager → `driver/`+`tuner/DvbSession`; Driver manager → `driver/`; Scanner → `tuner/Scanner`; MPEG-TS manager → `transport/`; Channel manager → `services/`; EPG → `epg/`; libVLC engine → `player/`; UI → `ui/`.
USB permission is handled by the driver app (it owns the USB device); this app reports its error codes.
Threading: one TS reader thread; sinks must not block (writers use their own thread + bounded queue, dropping when slow). Control calls are serialised by a lock.
