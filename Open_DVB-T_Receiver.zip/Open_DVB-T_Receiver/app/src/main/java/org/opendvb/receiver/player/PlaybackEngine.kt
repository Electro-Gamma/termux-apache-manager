package org.opendvb.receiver.player

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.util.Log
import org.opendvb.receiver.services.Channel
import org.opendvb.receiver.transport.Ts
import org.opendvb.receiver.tuner.DvbSession
import org.opendvb.receiver.tuner.TuneParams
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout
import java.io.FileDescriptor

/**
 * libVLC playback of one DVB service.
 *
 * Design mirrors what was verified in Aerial TV: the filtered transport stream is written into an
 * Android pipe and VLC opens the read end as a file descriptor (`Media(libVLC, FileDescriptor)`).
 * Start strategy: hardware decoding first, software decoding afterwards, at most 4 attempts
 * (counter resets after 30 s). Only the libVLC options verified in Aerial TV are used.
 */
class PlaybackEngine(
    private val context: Context,
    private val session: DvbSession,
    private val listener: Listener,
) {
    interface Listener {
        fun onStatus(text: String)
        fun onError(text: String)
        fun onTracksChanged(audio: List<Pair<Int, String>>)
    }

    private val main = Handler(Looper.getMainLooper())
    private var libVlc: LibVLC? = null
    private var player: MediaPlayer? = null
    private var layout: VLCVideoLayout? = null
    private var writer: FilteredTsWriter? = null
    private var pipeRead: ParcelFileDescriptor? = null
    private var filePfd: ParcelFileDescriptor? = null
    private var attempts = 0
    private var lastAttemptMs = 0L
    @Volatile private var released = false
    private var fd: FileDescriptor? = null

    // ---- live TV ----------------------------------------------------------------------------------

    /** Tunes (if needed), sets the hardware PID filter and starts playback. Blocking: call from a worker thread. */
    fun startChannel(channel: Channel, videoLayout: VLCVideoLayout) {
        main.post { listener.onStatus("Tuning ${channel.frequencyMhz} MHz…") }
        session.tune(TuneParams(channel.frequencyHz, channel.bandwidthHz, channel.system))
        if (!session.waitForLock(3500) { released }) {
            main.post { listener.onError("No signal lock on ${channel.frequencyMhz} MHz") }
            return
        }
        val playPids = channel.playbackPids()
        // EPG (EIT) and SDT also pass the hardware filter so the guide can be collected while watching.
        session.setPids(playPids + Ts.PID_SDT + Ts.PID_EIT)

        val pipe = ParcelFileDescriptor.createPipe()
        val w = FilteredTsWriter(ParcelFileDescriptor.AutoCloseOutputStream(pipe[1]), playPids, 1024, "VlcPipeWriter")
        main.post {
            if (released) { w.close(); pipe[0].close(); return@post }
            stopInternal()
            pipeRead = pipe[0]
            writer = w
            fd = pipe[0].fileDescriptor
            w.start()
            session.sinks.add(w)
            layout = videoLayout
            ensurePlayer(videoLayout)
            attempts = 0
            playAttempt()
        }
    }

    // ---- offline .ts file -------------------------------------------------------------------------

    fun playFile(uri: Uri, videoLayout: VLCVideoLayout) {
        val pfd = context.contentResolver.openFileDescriptor(uri, "r")
        if (pfd == null) { listener.onError("Cannot open the file"); return }
        stopInternal()
        filePfd = pfd
        fd = pfd.fileDescriptor
        layout = videoLayout
        ensurePlayer(videoLayout)
        attempts = 0
        playAttempt()
    }

    // ---- libVLC -----------------------------------------------------------------------------------

    private fun ensurePlayer(videoLayout: VLCVideoLayout) {
        if (player != null) return
        val options = arrayListOf(
            "--aout=opensles",
            "--vout=android-display",
            "--video-filter=deinterlace",
            "--deinterlace=-1",
            "--sout-deinterlace-mode=bob",
            "--vbi-opaque",
            "--autoscale",
        )
        val vlc = LibVLC(context, options)
        val mp = MediaPlayer(vlc)
        mp.setEventListener { event ->
            when (event.type) {
                MediaPlayer.Event.Playing -> main.post { listener.onStatus("Playing"); refreshTracks() }
                MediaPlayer.Event.ESAdded, MediaPlayer.Event.ESSelected -> main.post { refreshTracks() }
                MediaPlayer.Event.Buffering -> {}
                MediaPlayer.Event.EncounteredError -> main.post { retry() }
                else -> {}
            }
        }
        mp.attachViews(videoLayout, null, false, false)
        libVlc = vlc
        player = mp
    }

    private fun playAttempt() {
        val vlc = libVlc ?: return
        val mp = player ?: return
        val f = fd ?: return
        val now = System.currentTimeMillis()
        if (now - lastAttemptMs > 30_000) attempts = 0
        lastAttemptMs = now
        if (attempts >= MAX_ATTEMPTS) {
            listener.onError("Playback failed after $MAX_ATTEMPTS attempts (stream not decodable on this device?)")
            return
        }
        val hw = attempts == 0
        attempts++
        listener.onStatus(if (hw) "Starting (hardware decoding)…" else "Starting (software decoding)…")
        val media = Media(vlc, f)
        media.setHWDecoderEnabled(hw, false)
        mp.setMedia(media)
        media.release()
        mp.play()
    }

    private fun retry() {
        if (released) return
        Log.w(TAG, "libVLC reported an error, attempt $attempts")
        val mp = player ?: return
        try { mp.stop() } catch (_: Exception) {}
        playAttempt()
    }

    private fun refreshTracks() {
        val mp = player ?: return
        val tracks = mp.audioTracks ?: return
        listener.onTracksChanged(tracks.filter { it.id >= 0 }.map { it.id to it.name })
    }

    fun selectAudioTrack(id: Int) { player?.setAudioTrack(id) }

    private var aspectIndex = 0
    private val aspects = listOf("Best fit", "Fill", "16:9", "4:3")

    /** Cycles best fit → fill → 16:9 → 4:3 and returns the label. */
    fun cycleAspect(): String {
        val mp = player ?: return aspects[0]
        aspectIndex = (aspectIndex + 1) % aspects.size
        when (aspectIndex) {
            0 -> { mp.setAspectRatio(null); mp.setVideoScale(MediaPlayer.ScaleType.SURFACE_BEST_FIT) }
            1 -> { mp.setAspectRatio(null); mp.setVideoScale(MediaPlayer.ScaleType.SURFACE_FILL) }
            2 -> { mp.setVideoScale(MediaPlayer.ScaleType.SURFACE_BEST_FIT); mp.setAspectRatio("16:9") }
            else -> { mp.setVideoScale(MediaPlayer.ScaleType.SURFACE_BEST_FIT); mp.setAspectRatio("4:3") }
        }
        return aspects[aspectIndex]
    }

    val droppedChunks: Long get() = writer?.droppedChunks ?: 0L

    private fun stopInternal() {
        writer?.let { session.sinks.remove(it) }
        try { player?.stop() } catch (_: Exception) {}
        writer?.close(); writer = null
        try { pipeRead?.close() } catch (_: Exception) {}
        pipeRead = null
        try { filePfd?.close() } catch (_: Exception) {}
        filePfd = null
        fd = null
    }

    fun release() {
        released = true
        stopInternal()
        try { player?.detachViews() } catch (_: Exception) {}
        try { player?.release() } catch (_: Exception) {}
        try { libVlc?.release() } catch (_: Exception) {}
        player = null; libVlc = null; layout = null
    }

    companion object {
        private const val TAG = "PlaybackEngine"
        private const val MAX_ATTEMPTS = 4
    }
}
