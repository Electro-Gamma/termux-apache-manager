package org.opendvb.receiver.driver

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri

/** Result of launching the DVB-T Driver app (`dtvdriver:` ACTION_VIEW intent). */
sealed class LaunchResult {
    data class Success(
        val controlPort: Int,
        val transferPort: Int,
        val deviceName: String,
        val vendorIds: IntArray,
        val productIds: IntArray,
    ) : LaunchResult()

    /** [errorCode] is one of the driver's DvbException.ErrorCode names, e.g. USB_PERMISSION_DENIED. */
    data class Error(val errorCode: String, val rawTrace: String?, val attachedUsb: List<Pair<Int, Int>>) : LaunchResult()
    object Cancelled : LaunchResult()
    object DriverMissing : LaunchResult()
}

object DriverLauncher {
    const val DRIVER_PACKAGE = "info.martinmarinov.dvbdriver"
    const val ACTION_DEVICE_ATTACHED = "info.martinmarinov.dvbdriver.DVB_DEVICE_ATTACHED"
    private const val RESULT_ERROR = Activity.RESULT_FIRST_USER // driver: RESULT_ERROR = RESULT_FIRST_USER

    fun createIntent(): Intent =
        Intent(Intent.ACTION_VIEW).setData(Uri.Builder().scheme("dtvdriver").build())

    /**
     * Same intent, restricted to this app: the driver is built in (DeviceChooserActivity from the dvbservice module),
     * so a separately installed DVB-T Driver app can never answer instead.
     */
    fun createIntent(context: Context): Intent = createIntent().setPackage(context.packageName)

    fun parseResult(resultCode: Int, data: Intent?): LaunchResult = when (resultCode) {
        Activity.RESULT_OK -> {
            val c = data?.getIntExtra("ControlPort", -1) ?: -1
            val t = data?.getIntExtra("TransferPort", -1) ?: -1
            if (data == null || c <= 0 || t <= 0) {
                LaunchResult.Error("BAD_API_USAGE", "Driver returned OK without ports", emptyList())
            } else {
                LaunchResult.Success(
                    c, t,
                    data.getStringExtra("DeviceName") ?: "Unknown tuner",
                    data.getIntArrayExtra("VendorIds") ?: IntArray(0),
                    data.getIntArrayExtra("ProductIds") ?: IntArray(0),
                )
            }
        }
        RESULT_ERROR -> {
            val v = data?.getIntArrayExtra("VendorIds") ?: IntArray(0)
            val p = data?.getIntArrayExtra("ProductIds") ?: IntArray(0)
            val usb = (0 until minOf(v.size, p.size)).map { v[it] to p[it] }
            LaunchResult.Error(data?.getStringExtra("ErrorCode") ?: "UNKNOWN", data?.getStringExtra("RawTrace"), usb)
        }
        else -> LaunchResult.Cancelled
    }

    fun describeError(code: String): String = when (code) {
        "NO_DVB_DEVICES_FOUND" -> "No USB device found. Connect the tuner with an OTG cable (some phones need a powered OTG hub)."
        "USB_PERMISSION_DENIED" -> "USB permission was denied. Try again and allow access."
        "DVB_DEVICE_UNSUPPORTED" -> "The connected USB device is not supported by the driver."
        "UNSUPPORTED_PLATFORM" -> "This Android device does not support what the driver needs (USB host)."
        "CANNOT_OPEN_USB" -> "The USB device could not be opened."
        "HARDWARE_EXCEPTION" -> "The tuner reported a hardware problem. Check cable/power."
        "CANNOT_TUNE_TO_FREQ" -> "The tuner cannot tune to that frequency."
        "UNSUPPORTED_BANDWIDTH" -> "The tuner does not support that bandwidth."
        "IO_EXCEPTION" -> "I/O error while talking to the tuner."
        else -> "Driver error: $code"
    }
}
