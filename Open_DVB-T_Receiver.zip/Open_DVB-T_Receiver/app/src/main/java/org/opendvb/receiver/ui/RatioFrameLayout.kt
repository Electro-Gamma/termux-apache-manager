package org.opendvb.receiver.ui

import android.content.Context
import android.util.AttributeSet
import android.widget.FrameLayout

/** A FrameLayout whose height is a fixed fraction of its width (the preview band on a channel card: 0.72, like the VNC cards). */
class RatioFrameLayout @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : FrameLayout(context, attrs) {
    var heightRatio = 0.72f

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val width = MeasureSpec.getSize(widthMeasureSpec)
        super.onMeasure(widthMeasureSpec, MeasureSpec.makeMeasureSpec((width * heightRatio).toInt(), MeasureSpec.EXACTLY))
    }
}
