package org.opendvb.receiver.tuner

import android.os.Handler
import android.os.Looper
import android.util.Log
import org.opendvb.receiver.driver.Capabilities
import org.opendvb.receiver.driver.DeliverySystem
import org.opendvb.receiver.driver.DriverClient
import org.opendvb.receiver.driver.DriverConnection
import org.opendvb.receiver.driver.LaunchResult
import org.opendvb.receiver.transport.TsReader
import org.opendvb.receiver.transport.TsSink
import java.util.concurrent.CopyOnWriteArrayList

enum class SessionState { DISCONNECTED, CONNECTING, CONNECTED }

data class TuneParams(val frequencyHz: Long, val bandwidthHz: Long, val system: DeliverySystem)

/**
 * Owns the connection to the DVB-T Driver for the whole process: control client, TS reader thread
 * and the list of TS sinks. Activities observe [state] through listeners (delivered on the main thread).
 */
class DvbSession {
    interface Listener { fun onSessionChanged(session: DvbSession) }

    private val main = Handler(Looper.getMainLooper())
    private val listeners = CopyOnWriteArrayList<Listener>()
    val sinks = CopyOnWriteArrayList<TsSink>()

    @Volatile var state = SessionState.DISCONNECTED; private set
    @Volatile var deviceName: String? = null; private set
    @Volatile var capabilities: Capabilities? = null; private set
    @Volatile var protocolVersion: Long = -1; private set
    @Volatile var lastError: String? = null; private set
    @Volatile var currentTune: TuneParams? = null; private set
    @Volatile var currentPids: IntArray = IntArray(0); private set

    private var connection: DriverConnection? = null
    private var reader: TsReader? = null
    val tsReader: TsReader? get() = reader

    val client: DriverClient? get() = connection?.client

    fun addListener(l: Listener) { listeners.add(l) }
    fun removeListener(l: Listener) { listeners.remove(l) }
    private fun notifyChanged() { main.post { for (l in listeners) l.onSessionChanged(this) } }

    /** Opens the TCP connections after the driver app returned its ports. Runs on a worker thread. */
    fun connect(result: LaunchResult.Success) {
        disconnect()
        state = SessionState.CONNECTING
        lastError = null
        notifyChanged()
        Thread({
            try {
                val c = DriverConnection.open(result.controlPort, result.transferPort)
                val version = c.client.protocolVersion()
                val caps = c.client.capabilities()
                connection = c
                protocolVersion = version.first
                capabilities = caps
                deviceName = result.deviceName
                val r = TsReader(c.transportStream, sinks) { err -> onReaderEnded(c, err) }
                r.isDaemon = true
                reader = r
                state = SessionState.CONNECTED
                notifyChanged()
                r.start()
            } catch (e: Exception) {
                Log.w(TAG, "connect failed", e)
                lastError = e.message ?: e.javaClass.simpleName
                state = SessionState.DISCONNECTED
                notifyChanged()
            }
        }, "DvbConnect").start()
    }

    private fun onReaderEnded(c: DriverConnection, error: Throwable?) {
        if (connection !== c) return // we closed it ourselves
        Log.w(TAG, "transport stream ended", error)
        lastError = error?.message ?: "Transport stream closed by the driver"
        try { c.close() } catch (_: Exception) {}
        connection = null; reader = null
        currentTune = null; currentPids = IntArray(0)
        state = SessionState.DISCONNECTED
        notifyChanged()
    }

    fun disconnect() {
        val c = connection
        val r = reader
        connection = null; reader = null
        currentTune = null; currentPids = IntArray(0)
        if (c != null) {
            r?.interrupt()
            Thread({ try { c.close() } catch (_: Exception) {} }, "DvbClose").start()
        }
        if (state != SessionState.DISCONNECTED) {
            state = SessionState.DISCONNECTED
            notifyChanged()
        }
    }

    /** Tunes only if the parameters differ from the current ones (or [force]). Blocking. */
    @Synchronized
    fun tune(p: TuneParams, force: Boolean = false) {
        val cl = client ?: throw IllegalStateException("Not connected to the driver")
        if (!force && currentTune == p) return
        cl.tune(p.frequencyHz, p.bandwidthHz, p.system)
        currentTune = p
    }

    @Synchronized
    fun setPids(pids: Collection<Int>) {
        val cl = client ?: throw IllegalStateException("Not connected to the driver")
        val arr = pids.distinct().filter { it in 0..0x1FFE }.toIntArray()
        cl.setPids(arr)
        currentPids = arr
    }

    /** Polls GET_STATUS until the demodulator reports lock or [timeoutMs] elapses. Blocking. */
    fun waitForLock(timeoutMs: Long, cancelled: () -> Boolean = { false }): Boolean {
        val cl = client ?: return false
        val end = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < end && !cancelled()) {
            if (cl.status().hasLock) return true
            Thread.sleep(150)
        }
        return false
    }

    companion object { private const val TAG = "DvbSession" }
}
