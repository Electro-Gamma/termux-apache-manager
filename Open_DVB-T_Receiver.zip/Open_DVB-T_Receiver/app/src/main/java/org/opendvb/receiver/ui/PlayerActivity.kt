package org.opendvb.receiver.ui

import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.PixelCopy
import android.view.SurfaceView
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import androidx.appcompat.app.AppCompatActivity
import org.opendvb.receiver.OpenDvbApp
import org.opendvb.receiver.R
import org.opendvb.receiver.player.PlaybackEngine
import org.opendvb.receiver.services.BackgroundService
import org.opendvb.receiver.services.Channel
import org.opendvb.receiver.services.ChannelThumbnails
import org.opendvb.receiver.tuner.DvbSession
import org.opendvb.receiver.tuner.SessionState
import org.videolan.libvlc.util.VLCVideoLayout

class PlayerActivity : AppCompatActivity(), PlaybackEngine.Listener, DvbSession.Listener {
    private val app get() = OpenDvbApp.instance
    private val main = Handler(Looper.getMainLooper())

    private lateinit var video: VLCVideoLayout
    private lateinit var titleView: TextView
    private lateinit var epgView: TextView
    private lateinit var statusView: TextView
    private lateinit var overlayTop: LinearLayout
    private lateinit var overlayBottom: LinearLayout
    private lateinit var recButton: android.widget.Button
    private lateinit var aspectButton: android.widget.Button

    private var channel: Channel? = null
    private var fileUri: Uri? = null
    private var audioTracks: List<Pair<Int, String>> = emptyList()

    private val createDoc = registerForActivityResult(ActivityResultContracts.CreateDocument("video/mp2t")) { uri: Uri? ->
        if (uri != null) startRecording(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        fileUri = intent.data
        channel = intent.getStringExtra(EXTRA_CHANNEL_KEY)?.let { app.channels.find(it) }
        if (fileUri == null && channel == null) { finish(); return }

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        video = VLCVideoLayout(this)
        root.addView(video, FrameLayout.LayoutParams(-1, -1))
        video.setOnClickListener { toggleOverlay() }

        overlayTop = vertical(10, 2).apply { setBackgroundColor(0x99000000.toInt()) }
        titleView = label("", 18f).apply { setTextColor(Color.WHITE) }
        epgView = label("", 13f).apply { setTextColor(0xFFDDDDDD.toInt()) }
        statusView = label("Starting…", 12f).apply { setTextColor(0xFF9FD8FF.toInt()) }
        overlayTop.addView(titleView); overlayTop.addView(epgView); overlayTop.addView(statusView)
        root.addView(overlayTop, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        overlayBottom = horizontal().apply { setBackgroundColor(0x99000000.toInt()); setPadding(dp(6), dp(6), dp(6), dp(6)) }
        if (fileUri == null) {
            overlayBottom.addView(overlayIconButton(R.drawable.ic_prev, "Previous channel") { step(-1) }, overlayParams(0.55f))
            overlayBottom.addView(overlayIconButton(R.drawable.ic_next, "Next channel") { step(+1) }, overlayParams(0.55f))
        }
        overlayBottom.addView(overlayButton("Audio") { chooseAudio() }, overlayParams(1f))
        aspectButton = overlayButton("Fit") { aspectButton.text = app.engine?.cycleAspect() ?: "Fit" }
        overlayBottom.addView(aspectButton, overlayParams(1f))
        recButton = overlayButton("● Rec") { toggleRecording() }
        if (fileUri == null) overlayBottom.addView(recButton, overlayParams(1.3f))
        root.addView(overlayBottom, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        setContentView(root)
        updateTitle()
    }

    override fun onStart() {
        super.onStart()
        app.session.addListener(this)
        val running = app.engine
        if (fileUri == null && running != null && running.isPlaying && app.playingChannel?.key == channel?.key) {
            // Coming back from Home / another app: the stream kept playing, just show the picture again.
            running.listener = this
            running.attachVideo(video)
            statusView.text = "Playing"
            main.removeCallbacks(captureTick)
            main.postDelayed(captureTick, FIRST_CAPTURE_DELAY_MS)
        } else {
            startPlayback()
        }
        main.post(ticker)
    }

    override fun onStop() {
        main.removeCallbacks(ticker)
        main.removeCallbacks(captureTick)
        app.session.removeListener(this)
        if (isFinishing || fileUri != null) {
            // Back button (or an offline file): really stop. Home / app switch below keeps everything running.
            if (app.recorder.isRecording) {
                val n = app.recorder.stop()
                Toast.makeText(this, "Recording stopped (left the player): $n bytes", Toast.LENGTH_LONG).show()
                recButton.text = "● Rec"
            }
            stopPlayback()
        } else {
            app.engine?.let { it.listener = PlaybackEngine.NO_LISTENER; it.detachVideo() }
            BackgroundService.sync(this)
        }
        super.onStop()
    }

    private val ticker = object : Runnable {
        override fun run() {
            updateTitle()
            if (app.recorder.isRecording) {
                val f = app.recorder.failure()
                recButton.text = if (f != null) "Rec failed" else "■ %.1f MB".format(app.recorder.bytesWritten() / 1048576.0)
            }
            main.postDelayed(this, 2000)
        }
    }

    private fun updateTitle() {
        val ch = channel
        if (ch == null) { titleView.text = fileUri?.lastPathSegment ?: "File"; epgView.text = ""; return }
        titleView.text = ch.displayName + (if (ch.scrambled) "  (encrypted)" else "")
        val now = app.epg.now(ch.key); val next = app.epg.next(ch.key)
        epgView.text = (now?.let { "Now ${fmtTime(it.startUtcMs)}: ${it.title}" } ?: "No programme information yet") +
            (next?.let { "\nNext ${fmtTime(it.startUtcMs)}: ${it.title}" } ?: "")
    }

    private fun startPlayback() {
        main.removeCallbacks(captureTick)   // never a picture of the previous channel under the new one's name
        stopPlayback()
        val e = PlaybackEngine(applicationContext, app.session, this)
        app.engine = e
        app.playingChannel = if (fileUri == null) channel else null
        val uri = fileUri
        if (uri != null) {
            try { e.playFile(uri, video) } catch (ex: Exception) { onError("Cannot play file: ${ex.message}") }
            return
        }
        val ch = channel ?: return
        if (app.session.state != SessionState.CONNECTED) { onError("Tuner is not connected"); return }
        if (ch.scrambled) statusView.text = "This service is flagged as encrypted; it will probably not play."
        BackgroundService.sync(this)
        Thread({
            try { e.startChannel(ch, video) } catch (ex: Exception) {
                main.post { onError("Could not start: ${ex.message ?: ex.javaClass.simpleName}") }
            }
        }, "PlayerStart").start()
    }

    private fun stopPlayback() = app.stopPlayback()

    private fun step(delta: Int) {
        val cur = channel ?: return
        val all = app.channels.load()
        if (all.size < 2) return
        val i = all.indexOfFirst { it.key == cur.key }
        channel = all[(i + delta + all.size) % all.size]
        audioTracks = emptyList()
        updateTitle()
        startPlayback()
    }

    private fun chooseAudio() {
        if (audioTracks.isEmpty()) { Toast.makeText(this, "No audio tracks reported yet", Toast.LENGTH_SHORT).show(); return }
        MaterialAlertDialogBuilder(this).setTitle("Audio track")
            .setItems(audioTracks.map { it.second }.toTypedArray()) { _, which -> app.engine?.selectAudioTrack(audioTracks[which].first) }
            .show()
    }

    private fun toggleRecording() {
        val ch = channel ?: return
        if (app.recorder.isRecording) {
            val n = app.recorder.stop()
            recButton.text = "● Rec"
            BackgroundService.sync(this)
            Toast.makeText(this, "Saved recording: ${"%.1f".format(n / 1048576.0)} MB", Toast.LENGTH_LONG).show()
        } else {
            val stamp = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US).format(java.util.Date())
            createDoc.launch(ch.displayName.replace(Regex("[^A-Za-z0-9._-]+"), "_") + "_" + stamp + ".ts")
        }
    }

    private fun startRecording(uri: Uri) {
        val ch = channel ?: return
        try {
            val out = contentResolver.openOutputStream(uri) ?: throw java.io.IOException("cannot open output")
            app.recorder.start(out, ch.playbackPids())
            recButton.text = "■ 0.0 MB"
            BackgroundService.sync(this)
            if (ch.scrambled) Toast.makeText(this, "Warning: encrypted service, the recording will not be playable", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Cannot record: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun toggleOverlay() {
        val v = if (overlayTop.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        overlayTop.visibility = v; overlayBottom.visibility = v
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_DPAD_UP -> { step(+1); return true }
            KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_DPAD_DOWN -> { step(-1); return true }
        }
        return super.onKeyDown(keyCode, event)
    }

    // PlaybackEngine.Listener (always called on the main thread)
    override fun onStatus(text: String) {
        statusView.text = text
        // First picture a few seconds after playback starts, then refreshed, so the list always shows a recent frame.
        if (text == "Playing" && fileUri == null) {
            main.removeCallbacks(captureTick)
            main.postDelayed(captureTick, FIRST_CAPTURE_DELAY_MS)
        }
    }
    override fun onError(text: String) { statusView.text = "⚠ $text" }
    override fun onTracksChanged(audio: List<Pair<Int, String>>) { audioTracks = audio }

    // DvbSession.Listener
    override fun onSessionChanged(session: DvbSession) {
        if (session.state == SessionState.DISCONNECTED && fileUri == null) {
            onError("Tuner disconnected (${session.lastError ?: "connection closed"}). Go back and reconnect.")
            stopPlayback()
        }
    }

    // ---- channel preview (the picture on the channel list) -------------------------------------------------------

    private val captureTick = object : Runnable {
        override fun run() {
            capturePreview()
            main.postDelayed(this, CAPTURE_INTERVAL_MS)
        }
    }

    /** Copies the current video frame (PixelCopy, Android 7+) and keeps it as the latest preview of the playing channel. */
    private fun capturePreview() {
        val ch = channel ?: return
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return
        val surface = findSurfaceView(video) ?: return
        if (!surface.holder.surface.isValid || surface.width <= 0 || surface.height <= 0) return
        val scale = 640f / maxOf(surface.width, surface.height)
        val w = maxOf(2, if (scale < 1f) Math.round(surface.width * scale) else surface.width)
        val h = maxOf(2, if (scale < 1f) Math.round(surface.height * scale) else surface.height)
        val bmp = try { Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888) } catch (_: OutOfMemoryError) { return }
        val key = ch.key
        try {
            PixelCopy.request(surface, bmp, { result ->
                // A blank (black) frame is the surface being created or torn down: keep the previous good picture instead.
                if (result == PixelCopy.SUCCESS && !ChannelThumbnails.isBlank(bmp)) app.previews.save(key, bmp)
            }, main)
        } catch (_: Exception) {
            // surface gone or copy not possible right now: try again at the next tick
        }
    }

    private fun findSurfaceView(v: View): SurfaceView? {
        if (v is SurfaceView) return if (v.visibility == View.VISIBLE) v else null
        if (v is ViewGroup) for (i in 0 until v.childCount) findSurfaceView(v.getChildAt(i))?.let { return it }
        return null
    }

    companion object {
        const val EXTRA_CHANNEL_KEY = "channelKey"
        private const val FIRST_CAPTURE_DELAY_MS = 4_000L
        private const val CAPTURE_INTERVAL_MS = 20_000L
    }
}
