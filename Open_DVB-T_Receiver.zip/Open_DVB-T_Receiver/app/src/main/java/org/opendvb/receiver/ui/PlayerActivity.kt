package org.opendvb.receiver.ui

import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import org.opendvb.receiver.OpenDvbApp
import org.opendvb.receiver.player.PlaybackEngine
import org.opendvb.receiver.services.Channel
import org.opendvb.receiver.tuner.DvbSession
import org.opendvb.receiver.tuner.SessionState
import org.videolan.libvlc.util.VLCVideoLayout

class PlayerActivity : AppCompatActivity(), PlaybackEngine.Listener, DvbSession.Listener {
    private val app get() = OpenDvbApp.instance
    private val main = Handler(Looper.getMainLooper())

    private lateinit var video: VLCVideoLayout
    private lateinit var titleView: TextView
    private lateinit var epgView: TextView
    private lateinit var statusView: TextView
    private lateinit var overlayTop: LinearLayout
    private lateinit var overlayBottom: LinearLayout
    private lateinit var recButton: android.widget.Button
    private lateinit var aspectButton: android.widget.Button

    private var engine: PlaybackEngine? = null
    private var channel: Channel? = null
    private var fileUri: Uri? = null
    private var audioTracks: List<Pair<Int, String>> = emptyList()

    private val createDoc = registerForActivityResult(ActivityResultContracts.CreateDocument("video/mp2t")) { uri: Uri? ->
        if (uri != null) startRecording(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        fileUri = intent.data
        channel = intent.getStringExtra(EXTRA_CHANNEL_KEY)?.let { app.channels.find(it) }
        if (fileUri == null && channel == null) { finish(); return }

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        video = VLCVideoLayout(this)
        root.addView(video, FrameLayout.LayoutParams(-1, -1))
        video.setOnClickListener { toggleOverlay() }

        overlayTop = vertical(10).apply { setBackgroundColor(0x99000000.toInt()) }
        titleView = label("", 18f).apply { setTextColor(Color.WHITE) }
        epgView = label("", 13f).apply { setTextColor(0xFFDDDDDD.toInt()) }
        statusView = label("Starting…", 12f).apply { setTextColor(0xFF9FD8FF.toInt()) }
        overlayTop.addView(titleView); overlayTop.addView(epgView); overlayTop.addView(statusView)
        root.addView(overlayTop, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        overlayBottom = horizontal().apply { setBackgroundColor(0x99000000.toInt()); setPadding(dp(6), dp(6), dp(6), dp(6)) }
        if (fileUri == null) {
            overlayBottom.addView(button("◀") { step(-1) }, weighted(0.6f))
            overlayBottom.addView(button("▶") { step(+1) }, weighted(0.6f))
        }
        overlayBottom.addView(button("Audio") { chooseAudio() }, weighted())
        aspectButton = button("Fit") { aspectButton.text = engine?.cycleAspect() ?: "Fit" }
        overlayBottom.addView(aspectButton, weighted())
        recButton = button("● Rec") { toggleRecording() }
        if (fileUri == null) overlayBottom.addView(recButton, weighted())
        root.addView(overlayBottom, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        setContentView(root)
        updateTitle()
    }

    override fun onStart() {
        super.onStart()
        app.session.addListener(this)
        startPlayback()
        main.post(ticker)
    }

    override fun onStop() {
        main.removeCallbacks(ticker)
        app.session.removeListener(this)
        if (app.recorder.isRecording) {
            val n = app.recorder.stop()
            Toast.makeText(this, "Recording stopped (left the player): $n bytes", Toast.LENGTH_LONG).show()
            recButton.text = "● Rec"
        }
        stopPlayback()
        super.onStop()
    }

    private val ticker = object : Runnable {
        override fun run() {
            updateTitle()
            if (app.recorder.isRecording) {
                val f = app.recorder.failure()
                recButton.text = if (f != null) "Rec failed" else "■ %.1f MB".format(app.recorder.bytesWritten() / 1048576.0)
            }
            main.postDelayed(this, 2000)
        }
    }

    private fun updateTitle() {
        val ch = channel
        if (ch == null) { titleView.text = fileUri?.lastPathSegment ?: "File"; epgView.text = ""; return }
        titleView.text = ch.displayName + (if (ch.scrambled) "  (encrypted)" else "")
        val now = app.epg.now(ch.key); val next = app.epg.next(ch.key)
        epgView.text = (now?.let { "Now ${fmtTime(it.startUtcMs)}: ${it.title}" } ?: "No programme information yet") +
            (next?.let { "\nNext ${fmtTime(it.startUtcMs)}: ${it.title}" } ?: "")
    }

    private fun startPlayback() {
        stopPlayback()
        val e = PlaybackEngine(this, app.session, this)
        engine = e
        val uri = fileUri
        if (uri != null) {
            try { e.playFile(uri, video) } catch (ex: Exception) { onError("Cannot play file: ${ex.message}") }
            return
        }
        val ch = channel ?: return
        if (app.session.state != SessionState.CONNECTED) { onError("Tuner is not connected"); return }
        if (ch.scrambled) statusView.text = "This service is flagged as encrypted; it will probably not play."
        Thread({
            try { e.startChannel(ch, video) } catch (ex: Exception) {
                main.post { onError("Could not start: ${ex.message ?: ex.javaClass.simpleName}") }
            }
        }, "PlayerStart").start()
    }

    private fun stopPlayback() {
        engine?.release()
        engine = null
    }

    private fun step(delta: Int) {
        val cur = channel ?: return
        val all = app.channels.load()
        if (all.size < 2) return
        val i = all.indexOfFirst { it.key == cur.key }
        channel = all[(i + delta + all.size) % all.size]
        audioTracks = emptyList()
        updateTitle()
        startPlayback()
    }

    private fun chooseAudio() {
        if (audioTracks.isEmpty()) { Toast.makeText(this, "No audio tracks reported yet", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this).setTitle("Audio track")
            .setItems(audioTracks.map { it.second }.toTypedArray()) { _, which -> engine?.selectAudioTrack(audioTracks[which].first) }
            .show()
    }

    private fun toggleRecording() {
        val ch = channel ?: return
        if (app.recorder.isRecording) {
            val n = app.recorder.stop()
            recButton.text = "● Rec"
            Toast.makeText(this, "Saved recording: ${"%.1f".format(n / 1048576.0)} MB", Toast.LENGTH_LONG).show()
        } else {
            val stamp = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US).format(java.util.Date())
            createDoc.launch(ch.displayName.replace(Regex("[^A-Za-z0-9._-]+"), "_") + "_" + stamp + ".ts")
        }
    }

    private fun startRecording(uri: Uri) {
        val ch = channel ?: return
        try {
            val out = contentResolver.openOutputStream(uri) ?: throw java.io.IOException("cannot open output")
            app.recorder.start(out, ch.playbackPids())
            recButton.text = "■ 0.0 MB"
            if (ch.scrambled) Toast.makeText(this, "Warning: encrypted service, the recording will not be playable", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Cannot record: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun toggleOverlay() {
        val v = if (overlayTop.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        overlayTop.visibility = v; overlayBottom.visibility = v
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_DPAD_UP -> { step(+1); return true }
            KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_DPAD_DOWN -> { step(-1); return true }
        }
        return super.onKeyDown(keyCode, event)
    }

    // PlaybackEngine.Listener (always called on the main thread)
    override fun onStatus(text: String) { statusView.text = text }
    override fun onError(text: String) { statusView.text = "⚠ $text" }
    override fun onTracksChanged(audio: List<Pair<Int, String>>) { audioTracks = audio }

    // DvbSession.Listener
    override fun onSessionChanged(session: DvbSession) {
        if (session.state == SessionState.DISCONNECTED && fileUri == null) {
            onError("Tuner disconnected (${session.lastError ?: "connection closed"}). Go back and reconnect.")
            stopPlayback()
        }
    }

    companion object { const val EXTRA_CHANNEL_KEY = "channelKey" }
}
