package org.opendvb.receiver.recording

import org.opendvb.receiver.player.FilteredTsWriter
import org.opendvb.receiver.tuner.DvbSession
import java.io.OutputStream

/**
 * Records the selected service's packets (PAT, PMT, PCR and elementary streams, unaltered) as a .ts file.
 * The output stream comes from the Storage Access Framework (user-chosen location). Encrypted
 * (scrambled) services are recorded as received and will not be playable.
 */
class TsRecorder(private val session: DvbSession) {
    private var writer: FilteredTsWriter? = null
    val isRecording: Boolean get() = writer != null

    @Synchronized
    fun start(out: OutputStream, pids: Set<Int>) {
        stop()
        val w = FilteredTsWriter(out, pids, 4096, "TsRecorder")
        w.start()
        session.sinks.add(w)
        writer = w
    }

    @Synchronized
    fun bytesWritten(): Long = writer?.bytesWritten ?: 0L

    /** @return bytes written, or -1 when nothing was recording */
    @Synchronized
    fun stop(): Long {
        val w = writer ?: return -1
        session.sinks.remove(w)
        val n = w.bytesWritten
        w.close()
        writer = null
        return n
    }

    @Synchronized fun failure(): String? = writer?.failure?.message
}
