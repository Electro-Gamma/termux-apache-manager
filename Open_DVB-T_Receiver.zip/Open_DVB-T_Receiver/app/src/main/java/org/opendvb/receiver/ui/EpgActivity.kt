package org.opendvb.receiver.ui

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import info.martinmarinov.dvbdriver.UpActivity
import org.opendvb.receiver.OpenDvbApp
import org.opendvb.receiver.services.Channel
import org.opendvb.receiver.tuner.SessionState
import org.opendvb.receiver.tuner.TuneParams
import org.opendvb.receiver.transport.EpgEvent
import org.opendvb.receiver.transport.Ts

class EpgActivity : UpActivity() {
    private val app get() = OpenDvbApp.instance
    private val main = Handler(Looper.getMainLooper())
    private lateinit var picker: Dropdown
    private lateinit var info: TextView
    private lateinit var list: RecyclerView
    private val adapter = EventAdapter()
    private var channels: List<Channel> = emptyList()
    @Volatile private var collecting = false
    @Volatile private var alive = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Programme guide"
        channels = app.channels.load()
        val root = vertical(8)
        picker = dropdown("Channel", channels.map { it.displayName })
        info = label("", 12f).muted()
        list = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@EpgActivity)
            clipToPadding = false
            adapter = this@EpgActivity.adapter
        }
        root.addView(picker.layout, matchWrap())
        root.addView(button("Collect guide for this channel's multiplex (45 s)") { collect() }, matchWrap())
        root.addView(info, matchWrap())
        root.addView(list, fill())
        setContentView(root)
        picker.onSelected = { refresh() }
        if (channels.isEmpty()) info.text = "No channels. Run a scan first." else refresh()
    }

    private fun selected(): Channel? = channels.getOrNull(picker.index)

    private fun refresh() {
        val ch = selected() ?: return
        app.epg.prune()
        val events = app.epg.eventsFor(ch.key)
        adapter.submit(events)
        if (!collecting) {
            info.text = if (events.isEmpty())
                "No programme data for this channel yet. The guide comes from the broadcast (EIT); some broadcasters do not send it. " +
                    "Watching a channel also collects it."
            else "${events.size} events"
        }
    }

    private fun collect() {
        val ch = selected() ?: return
        if (app.session.state != SessionState.CONNECTED) { info.text = "Not connected to the tuner."; return }
        if (collecting || app.tunerBusy) { info.text = "Tuner is busy."; return }
        collecting = true
        app.tunerBusy = true
        Thread({
            try {
                app.session.tune(TuneParams(ch.frequencyHz, ch.bandwidthHz, ch.system))
                if (!app.session.waitForLock(3500)) { main.post { info.text = "No signal lock." }; return@Thread }
                app.session.setPids(listOf(Ts.PID_PAT, Ts.PID_SDT, Ts.PID_EIT))
                val end = System.currentTimeMillis() + 45_000
                while (alive && System.currentTimeMillis() < end) {
                    val left = (end - System.currentTimeMillis()) / 1000
                    main.post { info.text = "Collecting… ${left}s left"; refresh() }
                    Thread.sleep(1000)
                }
                try { app.session.setPids(emptyList()) } catch (_: Exception) {}
            } catch (e: Exception) {
                main.post { info.text = "Failed: ${e.message}" }
            } finally {
                collecting = false
                app.tunerBusy = false
                main.post { if (alive) refresh() }
            }
        }, "EpgCollect").start()
    }

    override fun onDestroy() { alive = false; super.onDestroy() }

    /** Programme rows in the same grouped, outlined style as the channel list (large corners at the ends of the run, small between). */
    private class EventAdapter : RecyclerView.Adapter<EventAdapter.Holder>() {
        private var items: List<EpgEvent> = emptyList()

        fun submit(events: List<EpgEvent>) { items = events; notifyDataSetChanged() }

        class Holder(val box: LinearLayout, val title: TextView, val text: TextView) : RecyclerView.ViewHolder(box)

        override fun getItemCount() = items.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
            val ctx = parent.context
            val title = ctx.label("").appearance(com.google.android.material.R.style.TextAppearance_Material3_TitleSmall)
            val text = ctx.label("").appearance(com.google.android.material.R.style.TextAppearance_Material3_BodyMedium).muted()
            val box = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(ctx.dp(16), ctx.dp(10), ctx.dp(16), ctx.dp(10))
                addView(title, matchWrap())
                addView(text, matchWrap())
                layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            }
            return Holder(box, title, text)
        }

        override fun onBindViewHolder(h: Holder, position: Int) {
            val ctx = h.box.context
            val e = items[position]
            h.title.text = fmtTime(e.startUtcMs) + " – " + fmtTime(e.endUtcMs) + "  " + e.title
            h.text.text = e.text
            h.text.visibility = if (e.text.isBlank()) View.GONE else View.VISIBLE
            val first = position == 0
            val last = position == items.size - 1
            h.box.background = ctx.groupedBackground(if (first) 16 else 4, if (last) 16 else 4)
            val lp = h.box.layoutParams as ViewGroup.MarginLayoutParams
            lp.setMargins(0, 0, 0, if (last) 0 else ctx.dp(2))
            h.box.layoutParams = lp
        }
    }
}
