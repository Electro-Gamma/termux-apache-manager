package org.opendvb.receiver.ui

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import org.opendvb.receiver.OpenDvbApp
import org.opendvb.receiver.services.Channel
import org.opendvb.receiver.tuner.SessionState
import org.opendvb.receiver.tuner.TuneParams
import org.opendvb.receiver.transport.EpgEvent
import org.opendvb.receiver.transport.Ts

class EpgActivity : AppCompatActivity() {
    private val app get() = OpenDvbApp.instance
    private val main = Handler(Looper.getMainLooper())
    private lateinit var spinner: Spinner
    private lateinit var info: TextView
    private lateinit var list: ListView
    private lateinit var adapter: ArrayAdapter<EpgEvent>
    private var channels: List<Channel> = emptyList()
    @Volatile private var collecting = false
    @Volatile private var alive = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Programme guide"
        channels = app.channels.load()
        val root = vertical(8)
        spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, channels.map { it.displayName })
        info = label("", 12f)
        list = ListView(this)
        adapter = object : ArrayAdapter<EpgEvent>(this, android.R.layout.simple_list_item_2, android.R.id.text1, ArrayList()) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = super.getView(position, convertView, parent)
                val e = getItem(position)!!
                v.findViewById<TextView>(android.R.id.text1).text = fmtTime(e.startUtcMs) + " – " + fmtTime(e.endUtcMs) + "  " + e.title
                v.findViewById<TextView>(android.R.id.text2).text = e.text
                return v
            }
        }
        list.adapter = adapter
        root.addView(spinner, matchWrap())
        root.addView(button("Collect guide for this channel's multiplex (45 s)") { collect() }, matchWrap())
        root.addView(info, matchWrap())
        root.addView(list, fill())
        setContentView(root)
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { refresh() }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        if (channels.isEmpty()) info.text = "No channels. Run a scan first."
    }

    private fun selected(): Channel? = channels.getOrNull(spinner.selectedItemPosition)

    private fun refresh() {
        val ch = selected() ?: return
        app.epg.prune()
        val events = app.epg.eventsFor(ch.key)
        adapter.clear(); adapter.addAll(events); adapter.notifyDataSetChanged()
        if (!collecting) {
            info.text = if (events.isEmpty())
                "No programme data for this channel yet. The guide comes from the broadcast (EIT); some broadcasters do not send it. " +
                    "Watching a channel also collects it."
            else "${events.size} events"
        }
    }

    private fun collect() {
        val ch = selected() ?: return
        if (app.session.state != SessionState.CONNECTED) { info.text = "Not connected to the tuner."; return }
        if (collecting || app.tunerBusy) { info.text = "Tuner is busy."; return }
        collecting = true
        app.tunerBusy = true
        Thread({
            try {
                app.session.tune(TuneParams(ch.frequencyHz, ch.bandwidthHz, ch.system))
                if (!app.session.waitForLock(3500)) { main.post { info.text = "No signal lock." }; return@Thread }
                app.session.setPids(listOf(Ts.PID_PAT, Ts.PID_SDT, Ts.PID_EIT))
                val end = System.currentTimeMillis() + 45_000
                while (alive && System.currentTimeMillis() < end) {
                    val left = (end - System.currentTimeMillis()) / 1000
                    main.post { info.text = "Collecting… ${left}s left"; refresh() }
                    Thread.sleep(1000)
                }
                try { app.session.setPids(emptyList()) } catch (_: Exception) {}
            } catch (e: Exception) {
                main.post { info.text = "Failed: ${e.message}" }
            } finally {
                collecting = false
                app.tunerBusy = false
                main.post { if (alive) refresh() }
            }
        }, "EpgCollect").start()
    }

    override fun onDestroy() { alive = false; super.onDestroy() }
}
