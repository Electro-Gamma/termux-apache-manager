package org.opendvb.receiver.services

import android.content.Context
import info.martinmarinov.drivers.TunerOptions
import org.opendvb.receiver.OpenDvbApp

/**
 * FC0012 LNA gain policy. Mode AUTO (default) lets a scan try several gains per frequency and remembers the one that gave a
 * clean multiplex; playback then tunes with that gain. A fixed mode (0..3) is used everywhere. Other tuners ignore all of this.
 */
object GainStore {
    const val AUTO = -1
    private val prefs get() = OpenDvbApp.instance.getSharedPreferences("settings", Context.MODE_PRIVATE)

    fun mode(): Int = prefs.getInt("fc0012_gain", AUTO)
    fun setMode(m: Int) { prefs.edit().putInt("fc0012_gain", m).apply(); TunerOptions.fc0012Gain = base() }
    fun base(): Int = mode().let { if (it == AUTO) 1 else it }

    fun remember(freqHz: Long, gain: Int) { prefs.edit().putInt("g_$freqHz", gain).apply() }
    fun forFrequency(freqHz: Long): Int = if (mode() != AUTO) mode() else prefs.getInt("g_$freqHz", 1)

    /** Gains a scan tries on each frequency, best guess first. */
    fun scanOrder(): List<Int> = when {
        !TunerOptions.fc0012Active -> listOf(base())
        mode() == AUTO -> listOf(1, 2, 0)
        else -> listOf(mode())
    }
}
