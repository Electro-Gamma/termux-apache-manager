package org.opendvb.receiver.player

import org.opendvb.receiver.transport.Ts
import org.opendvb.receiver.transport.TsSink
import java.io.IOException
import java.io.OutputStream
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.TimeUnit

/**
 * TsSink that keeps only the packets of the wanted PIDs and writes them to [out] from its own thread.
 * The TS reader thread never blocks: when the consumer is too slow, whole chunks are dropped
 * (counted in [droppedChunks]). Used for the libVLC pipe and for recording.
 */
class FilteredTsWriter(
    private val out: OutputStream,
    pids: Set<Int>,
    queueCapacity: Int = 1024,
    threadName: String = "TsWriter",
) : TsSink {
    @Volatile var pids: Set<Int> = pids
    @Volatile var droppedChunks = 0L
        private set
    @Volatile var bytesWritten = 0L
        private set
    @Volatile var failure: IOException? = null
        private set
    @Volatile private var closed = false

    private val queue = ArrayBlockingQueue<ByteArray>(queueCapacity)
    private val chunk = ByteArray(CHUNK_BYTES)
    private var fill = 0
    private var chunkStartNs = 0L

    private val thread = Thread({
        while (!closed) {
            val c = try { queue.poll(20, TimeUnit.MILLISECONDS) } catch (e: InterruptedException) { null }
            if (c == null) { flushIfStale(); continue }
            try {
                out.write(c)
                bytesWritten += c.size
            } catch (e: IOException) {
                failure = e
                closed = true
            }
        }
    }, threadName).also { it.isDaemon = true }

    fun start() { thread.start() }

    @Synchronized
    override fun onPacket(buf: ByteArray, off: Int) {
        if (closed) return
        if (Ts.pid(buf, off) !in pids) return
        if (fill == 0) chunkStartNs = System.nanoTime()
        System.arraycopy(buf, off, chunk, fill, Ts.PACKET_SIZE)
        fill += Ts.PACKET_SIZE
        if (fill == CHUNK_BYTES || System.nanoTime() - chunkStartNs > MAX_CHUNK_AGE_NS) flushChunk()
    }

    /** Called from the writer thread when idle so a partial chunk never waits for more packets. */
    @Synchronized
    private fun flushIfStale() {
        if (fill > 0 && System.nanoTime() - chunkStartNs > MAX_CHUNK_AGE_NS) flushChunk()
    }

    private fun flushChunk() {
        if (fill == 0) return
        if (!queue.offer(chunk.copyOf(fill))) droppedChunks++
        fill = 0
    }

    fun close() {
        closed = true
        thread.interrupt()
        try { out.close() } catch (_: IOException) {}
    }

    companion object {
        const val CHUNK_BYTES = Ts.PACKET_SIZE * 7
        const val MAX_CHUNK_AGE_NS = 30_000_000L
    }
}
