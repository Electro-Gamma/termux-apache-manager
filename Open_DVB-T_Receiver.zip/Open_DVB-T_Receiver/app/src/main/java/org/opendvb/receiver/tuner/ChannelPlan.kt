package org.opendvb.receiver.tuner

import org.opendvb.receiver.driver.Capabilities

data class Candidate(val label: String, val frequencyHz: Long, val bandwidthHz: Long)

/**
 * Frequency raster for scanning. Only the European terrestrial raster is built in
 * (VHF band III 7 MHz, UHF 8 MHz); other regions can be tuned manually.
 * Aerial TV uses per-country lists (verified in its code); full-raster scanning is the slower "full scan" equivalent.
 */
object ChannelPlan {
    /** UHF channels 21..69: centre = 474 MHz + 8 MHz * (ch - 21), 8 MHz wide. */
    fun uhfEurope(): List<Candidate> = (21..69).map {
        Candidate("UHF $it", 474_000_000L + (it - 21) * 8_000_000L, 8_000_000L)
    }

    /** VHF band III channels 5..12: centre = 177.5 MHz + 7 MHz * (ch - 5), 7 MHz wide. */
    fun vhfEurope(): List<Candidate> = (5..12).map {
        Candidate("VHF $it", 177_500_000L + (it - 5) * 7_000_000L, 7_000_000L)
    }

    fun europeFull(): List<Candidate> = vhfEurope() + uhfEurope()

    /** Drops frequencies outside what the tuner reports it can tune. */
    fun filter(list: List<Candidate>, caps: Capabilities?): List<Candidate> {
        if (caps == null || caps.frequencyMaxHz <= 0) return list
        return list.filter { it.frequencyHz >= caps.frequencyMinHz && it.frequencyHz <= caps.frequencyMaxHz }
    }
}
