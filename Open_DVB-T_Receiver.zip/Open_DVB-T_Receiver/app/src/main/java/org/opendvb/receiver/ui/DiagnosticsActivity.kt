package org.opendvb.receiver.ui

import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import org.opendvb.receiver.OpenDvbApp
import org.opendvb.receiver.diagnostics.TsFileAnalyzer
import org.opendvb.receiver.tuner.SessionState

class DiagnosticsActivity : AppCompatActivity() {
    private val app get() = OpenDvbApp.instance
    private val main = Handler(Looper.getMainLooper())
    private lateinit var out: TextView
    private var fileReport: String? = null

    private val openTs = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) analyzeFile(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Diagnostics"
        val root = vertical(8)
        val row = horizontal()
        row.addView(button("Reset counters") { app.stats.reset() }, weighted())
        row.addView(button("Analyse .ts file…") { openTs.launch(arrayOf("*/*")) }, weighted())
        out = label("", 11f, mono = true)
        val sv = ScrollView(this)
        sv.addView(out)
        root.addView(row, matchWrap())
        root.addView(sv, fill())
        setContentView(root)
    }

    private fun analyzeFile(uri: Uri) {
        out.text = "Analysing (first 64 MB)…"
        Thread({
            val text = try {
                contentResolver.openInputStream(uri).use { ins ->
                    if (ins == null) "Cannot open file" else
                        "FILE ${uri.lastPathSegment}\n" + TsFileAnalyzer.describe(TsFileAnalyzer.analyze(ins), TsFileAnalyzer::wellKnownPidName)
                }
            } catch (e: Exception) { "Analysis failed: ${e.message}" }
            main.post { fileReport = text; render() }
        }, "TsAnalyse").start()
    }

    private val ticker = object : Runnable {
        override fun run() { render(); main.postDelayed(this, 1000) }
    }

    override fun onStart() { super.onStart(); main.post(ticker) }
    override fun onStop() { main.removeCallbacks(ticker); super.onStop() }

    private fun render() {
        fileReport?.let { out.text = it; return }
        val s = app.session
        val sb = StringBuilder()
        sb.append("Session: ").append(s.state).append('\n')
        if (s.state == SessionState.CONNECTED) {
            sb.append("Tuner: ").append(s.deviceName).append("  protocol v").append(s.protocolVersion).append('\n')
            s.capabilities?.let {
                sb.append("Capabilities: ").append(it.deliverySystems.joinToString("/"))
                    .append("  ").append(it.frequencyMinHz / 1000).append("–").append(it.frequencyMaxHz / 1000).append(" kHz, step ")
                    .append(it.frequencyStepHz).append(" Hz, USB ")
                    .append(Integer.toHexString(it.vendorId)).append(':').append(Integer.toHexString(it.productId)).append('\n')
            }
            s.currentTune?.let { sb.append("Tuned: ").append(it.frequencyHz / 1000).append(" kHz, bw ").append(it.bandwidthHz / 1000000).append(" MHz, ").append(it.system).append('\n') }
            sb.append("Hardware PID filter: ").append(s.currentPids.joinToString(" ") { "0x" + Integer.toHexString(it) }).append('\n')
            if (!app.tunerBusy && s.currentTune != null) {
                try {
                    s.client?.status()?.let {
                        sb.append("Status: lock=").append(it.hasLock).append(" signal=").append(it.hasSignal).append(" carrier=").append(it.hasCarrier)
                            .append(" sync=").append(it.hasSync).append(" RF=").append(it.rfStrengthPercent).append("% SNR(raw)=").append(it.snr)
                            .append(" BER(raw)=").append(it.bitErrorRate).append(" USB drops/s=").append(it.droppedUsbFps).append('\n')
                    }
                } catch (e: Exception) { sb.append("Status error: ").append(e.message).append('\n') }
            }
            s.tsReader?.let { sb.append("TS resyncs: ").append(it.resyncCount).append("  bytes: ").append(it.bytesRead).append('\n') }
        } else {
            sb.append("Last error: ").append(s.lastError ?: "-").append('\n')
        }
        sb.append("Packets: ").append(app.stats.totalPackets).append("  avg ").append(app.stats.averageKbps()).append(" kbit/s\n\n")
        sb.append("PID      name       packets   ccErr  scrambled  tei\n")
        val channel = s.currentTune?.let { t -> app.channels.load().filter { it.frequencyHz == t.frequencyHz } } ?: emptyList()
        for (p in app.stats.snapshot()) {
            val name = TsFileAnalyzer.wellKnownPidName(p.pid) ?: channel.firstNotNullOfOrNull { c ->
                when {
                    c.pmtPid == p.pid -> "PMT " + c.serviceId
                    else -> c.streams.firstOrNull { it.pid == p.pid }?.let { it.kind.name.lowercase() + " " + c.serviceId }
                }
            } ?: ""
            sb.append("0x").append(Integer.toHexString(p.pid).padStart(4, '0')).append("  ").append(name.padEnd(10)).append(' ')
                .append(p.packets.toString().padStart(8)).append(' ').append(p.ccErrors.toString().padStart(7)).append(' ')
                .append(p.scrambled.toString().padStart(9)).append(' ').append(p.tei.toString().padStart(4)).append('\n')
        }
        out.text = sb.toString()
    }

    override fun onBackPressed() {
        if (fileReport != null) { fileReport = null; render() } else super.onBackPressed()
    }
}
