package org.opendvb.receiver.ui

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Spinner
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import org.opendvb.receiver.OpenDvbApp
import org.opendvb.receiver.driver.DeliverySystem
import org.opendvb.receiver.tuner.Scanner
import org.opendvb.receiver.tuner.SessionState
import org.opendvb.receiver.tuner.TuneParams
import java.util.concurrent.atomic.AtomicBoolean

class ManualTuneActivity : AppCompatActivity() {
    private val app get() = OpenDvbApp.instance
    private val main = Handler(Looper.getMainLooper())
    private lateinit var freq: EditText
    private lateinit var bw: Spinner
    private lateinit var sys: Spinner
    private lateinit var out: TextView
    private val systems = ArrayList<DeliverySystem>()
    private val bandwidths = listOf(5, 6, 7, 8)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Manual tune"
        val root = vertical()
        val freqLayout = TextInputLayout(this, null, com.google.android.material.R.attr.textInputOutlinedStyle).apply {
            hint = "Frequency in MHz, e.g. 538.0"
        }
        freq = TextInputEditText(freqLayout.context).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
        freqLayout.addView(freq)
        bw = Spinner(this)
        bw.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, bandwidths.map { "$it MHz" })
        bw.setSelection(bandwidths.indexOf(8))
        sys = Spinner(this)
        app.session.capabilities?.deliverySystems?.filter { it != DeliverySystem.DVBC }?.let { systems.addAll(it) }
        if (systems.isEmpty()) systems.add(DeliverySystem.DVBT) // not connected yet: allow typing
        sys.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, systems.map { it.name })
        out = label("", 12f, mono = true)

        root.addView(freqLayout, matchWrap())
        root.addView(label("Bandwidth"), matchWrap()); root.addView(bw, matchWrap())
        root.addView(label("Standard (only what the tuner reports is offered)"), matchWrap()); root.addView(sys, matchWrap())
        root.addView(button("Tune and show signal") { tune(scan = false) }, matchWrap())
        root.addView(button("Tune and add channels from this multiplex") { tune(scan = true) }, matchWrap())
        root.addView(out, matchWrap())
        setContentView(root)
    }

    private fun tune(scan: Boolean) {
        val f = freq.text.toString().replace(',', '.').toDoubleOrNull()
        if (f == null || f <= 0) { out.text = "Enter a frequency in MHz"; return }
        if (app.session.state != SessionState.CONNECTED) { out.text = "Not connected to the tuner."; return }
        if (app.tunerBusy) { out.text = "Tuner is busy."; return }
        val params = TuneParams((f * 1_000_000).toLong(), bandwidths[bw.selectedItemPosition] * 1_000_000L, systems[sys.selectedItemPosition])
        app.tunerBusy = true
        out.text = "Tuning…"
        Thread {
            var text = ""
            try {
                app.session.tune(params, force = true)
                val lock = app.session.waitForLock(3000)
                val st = app.session.client?.status()
                text = "lock=${lock}" + (st?.let { "\nRF=${it.rfStrengthPercent}%  SNR(raw)=${it.snr}  BER(raw)=${it.bitErrorRate}\nsignal=${it.hasSignal} carrier=${it.hasCarrier} sync=${it.hasSync}" } ?: "")
                if (scan && lock) {
                    val found = Scanner(app.session, AtomicBoolean(false)).collect(params)
                    app.channels.merge(found)
                    text += "\n\nAdded ${found.size} services:" + found.joinToString("") { "\n  ${it.displayName}" }
                } else if (scan) text += "\n\nNo lock, nothing added."
            } catch (e: Exception) {
                text = "Failed: ${e.message}"
            } finally {
                app.tunerBusy = false
            }
            main.post { out.text = text }
        }.start()
    }
}
