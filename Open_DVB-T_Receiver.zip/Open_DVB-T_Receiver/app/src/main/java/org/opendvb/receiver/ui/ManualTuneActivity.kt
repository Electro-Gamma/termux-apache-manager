package org.opendvb.receiver.ui

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.widget.EditText
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import android.widget.TextView
import info.martinmarinov.dvbdriver.UpActivity
import org.opendvb.receiver.OpenDvbApp
import org.opendvb.receiver.driver.DeliverySystem
import org.opendvb.receiver.tuner.Scanner
import org.opendvb.receiver.tuner.SessionState
import org.opendvb.receiver.tuner.TuneParams
import java.util.concurrent.atomic.AtomicBoolean

class ManualTuneActivity : UpActivity() {
    private val app get() = OpenDvbApp.instance
    private val main = Handler(Looper.getMainLooper())
    private lateinit var freq: EditText
    private lateinit var bw: Dropdown
    private lateinit var sys: Dropdown
    private lateinit var out: TextView
    private val systems = ArrayList<DeliverySystem>()
    private val bandwidths = listOf(5, 6, 7, 8)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Manual tune"
        val root = vertical()
        val freqLayout = TextInputLayout(this, null, com.google.android.material.R.attr.textInputOutlinedStyle).apply {
            hint = "Frequency in MHz, e.g. 538.0"
        }
        freq = TextInputEditText(freqLayout.context).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
        freqLayout.addView(freq)
        app.session.capabilities?.deliverySystems?.filter { it != DeliverySystem.DVBC }?.let { systems.addAll(it) }
        if (systems.isEmpty()) systems.add(DeliverySystem.DVBT) // not connected yet: allow typing
        bw = dropdown("Bandwidth", bandwidths.map { "$it MHz" }, bandwidths.indexOf(8))
        sys = dropdown("Standard", systems.map { it.name }, 0, helper = "Only what the tuner reports is offered")
        out = label("", 12f, mono = true)

        root.addView(freqLayout, matchWrap())
        root.addView(bw.layout, matchWrap())
        root.addView(sys.layout, matchWrap())
        root.addView(button("Tune and show signal") { tune(scan = false) }, matchWrap())
        root.addView(button("Tune and add channels from this multiplex", ButtonKind.TONAL) { tune(scan = true) }, matchWrap())
        root.addView(textCard(out), matchWrap())
        setContentView(root)
    }

    private fun tune(scan: Boolean) {
        val f = freq.text.toString().replace(',', '.').toDoubleOrNull()
        if (f == null || f <= 0) { out.text = "Enter a frequency in MHz"; return }
        if (app.session.state != SessionState.CONNECTED) { out.text = "Not connected to the tuner."; return }
        if (app.tunerBusy) { out.text = "Tuner is busy."; return }
        val params = TuneParams((f * 1_000_000).toLong(), bandwidths[bw.index] * 1_000_000L, systems[sys.index])
        app.tunerBusy = true
        out.text = "Tuning…"
        Thread {
            var text = ""
            try {
                app.session.tune(params, force = true)
                val lock = app.session.waitForLock(3000)
                val st = app.session.client?.status()
                text = "lock=${lock}" + (st?.let { "\nRF=${it.rfStrengthPercent}%  SNR(raw)=${it.snr}  BER(raw)=${it.bitErrorRate}\nsignal=${it.hasSignal} carrier=${it.hasCarrier} sync=${it.hasSync}" } ?: "")
                if (scan && lock) {
                    val found = Scanner(app.session, AtomicBoolean(false)).collect(params)
                    app.channels.merge(found)
                    text += "\n\nAdded ${found.size} services:" + found.joinToString("") { "\n  ${it.displayName}" }
                } else if (scan) text += "\n\nNo lock, nothing added."
            } catch (e: Exception) {
                text = "Failed: ${e.message}"
            } finally {
                app.tunerBusy = false
            }
            main.post { out.text = text }
        }.start()
    }
}
