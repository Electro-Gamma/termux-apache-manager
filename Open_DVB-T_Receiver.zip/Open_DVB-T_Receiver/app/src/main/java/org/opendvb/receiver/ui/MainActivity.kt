package org.opendvb.receiver.ui

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import info.martinmarinov.dvbdriver.DvbFrontendActivity
import info.martinmarinov.dvbdriver.NetworkReceiverActivity
import info.martinmarinov.dvbdriver.WelcomeActivity
import org.opendvb.receiver.OpenDvbApp
import org.opendvb.receiver.driver.DriverLauncher
import org.opendvb.receiver.driver.LaunchResult
import org.opendvb.receiver.services.Channel
import org.opendvb.receiver.tuner.DvbSession
import org.opendvb.receiver.tuner.SessionState

class MainActivity : AppCompatActivity(), DvbSession.Listener {
    private val app get() = OpenDvbApp.instance
    private lateinit var status: TextView
    private lateinit var signal: TextView
    private lateinit var connectButton: android.widget.Button
    private lateinit var list: ListView
    private lateinit var empty: TextView
    private lateinit var adapter: ArrayAdapter<Channel>
    private var favoritesOnly = false
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var polling = false
    private var lastSignalText = ""

    private val driverLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        when (val result = DriverLauncher.parseResult(r.resultCode, r.data)) {
            is LaunchResult.Success -> app.session.connect(result)
            is LaunchResult.Error -> {
                val usb = if (result.attachedUsb.isEmpty()) "" else
                    "\n\nUSB devices seen: " + result.attachedUsb.joinToString { "%04x:%04x".format(it.first, it.second) }
                AlertDialog.Builder(this)
                    .setTitle("Tuner problem")
                    .setMessage(DriverLauncher.describeError(result.errorCode) + usb)
                    .setPositiveButton("Retry") { _, _ -> launchDriver() }
                    .setNegativeButton("Close", null)
                    .show()
            }
            LaunchResult.Cancelled -> Toast.makeText(this, "Cancelled", Toast.LENGTH_SHORT).show()
            LaunchResult.DriverMissing -> showDriverMissing()
        }
    }

    private val openTs = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) startActivity(Intent(this, PlayerActivity::class.java).setData(uri))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Open DVB Receiver"
        val root = vertical(8)
        status = label("", 15f)
        signal = label("", 12f, mono = true)
        connectButton = button("Connect tuner") { launchDriver() }
        val row = horizontal()
        row.addView(button("Scan") { startActivity(Intent(this, ScanActivity::class.java)) }, weighted())
        row.addView(button("Manual tune") { startActivity(Intent(this, ManualTuneActivity::class.java)) }, weighted())
        row.addView(button("Guide") { startActivity(Intent(this, EpgActivity::class.java)) }, weighted())
        list = ListView(this)
        empty = label("No channels yet.\nConnect the tuner, then press Scan.", 15f).apply { setPadding(dp(8), dp(24), dp(8), 0) }

        root.addView(status, matchWrap())
        root.addView(signal, matchWrap())
        root.addView(connectButton, matchWrap())
        root.addView(row, matchWrap())
        root.addView(empty, matchWrap())
        root.addView(list, fill())
        setContentView(root)

        adapter = object : ArrayAdapter<Channel>(this, android.R.layout.simple_list_item_2, android.R.id.text1, ArrayList()) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = super.getView(position, convertView, parent)
                val c = getItem(position)!!
                val t1 = v.findViewById<TextView>(android.R.id.text1)
                val t2 = v.findViewById<TextView>(android.R.id.text2)
                t1.text = (if (c.favorite) "★ " else "") + c.displayName + (if (c.scrambled) "  🔒" else "") + (if (c.isRadio) "  (radio)" else "")
                val now = app.epg.now(c.key)
                t2.text = "%.1f MHz · %s · %s · %s".format(c.frequencyMhz, c.system.name, c.videoSummary(), c.audioSummary()) +
                    (now?.let { "\nNow: ${it.title}" } ?: "")
                return v
            }
        }
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ -> play(adapter.getItem(pos)!!) }
        list.setOnItemLongClickListener { _, _, pos, _ ->
            val c = adapter.getItem(pos)!!
            app.channels.toggleFavorite(c.key)
            refreshList()
            Toast.makeText(this, if (!c.favorite) "Added to favourites" else "Removed from favourites", Toast.LENGTH_SHORT).show()
            true
        }
        handleAttachIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleAttachIntent(intent)
    }

    private fun handleAttachIntent(i: Intent?) {
        if (i?.action == DriverLauncher.ACTION_DEVICE_ATTACHED && app.session.state == SessionState.DISCONNECTED) launchDriver()
    }

    private fun launchDriver() {
        if (app.session.state == SessionState.CONNECTING) return
        try {
            driverLauncher.launch(DriverLauncher.createIntent(this))
        } catch (e: ActivityNotFoundException) {
            showDriverMissing()
        }
    }

    private fun showDriverMissing() {
        AlertDialog.Builder(this)
            .setTitle("Built-in driver unavailable")
            .setMessage("The DVB driver that is built into this app could not be started. Reinstall the app; if it keeps happening, report it together with the Android version.")
            .setPositiveButton("Project page") { _, _ -> openUrl("https://github.com/signalwareltd/AndroidDvbDriver") }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun openUrl(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: ActivityNotFoundException) {}
    }

    private fun play(c: Channel) {
        if (app.session.state != SessionState.CONNECTED) {
            Toast.makeText(this, "Connect the tuner first", Toast.LENGTH_SHORT).show()
            return
        }
        startActivity(Intent(this, PlayerActivity::class.java).putExtra(PlayerActivity.EXTRA_CHANNEL_KEY, c.key))
    }

    private fun refreshList() {
        val all = app.channels.load()
        val shown = if (favoritesOnly) all.filter { it.favorite } else all
        adapter.clear()
        adapter.addAll(shown)
        adapter.notifyDataSetChanged()
        empty.show(shown.isEmpty())
        empty.text = if (favoritesOnly) "No favourites yet.\nLong-press a channel to add one." else "No channels yet.\nConnect the tuner, then press Scan."
    }

    private fun refreshStatus() {
        val s = app.session
        when (s.state) {
            SessionState.CONNECTED -> {
                val c = s.capabilities
                val sys = c?.deliverySystems?.joinToString("/") { it.name } ?: "?"
                status.text = "Connected: ${s.deviceName}\nSupports: $sys" +
                    (c?.let { "  ·  %.0f–%.0f MHz".format(it.frequencyMinHz / 1e6, it.frequencyMaxHz / 1e6) } ?: "") +
                    "  ·  driver protocol v${s.protocolVersion}"
                connectButton.text = "Disconnect"
                connectButton.setOnClickListener { s.disconnect() }
            }
            SessionState.CONNECTING -> {
                status.text = "Connecting to the driver…"
                connectButton.text = "Please wait…"
                connectButton.setOnClickListener(null)
            }
            SessionState.DISCONNECTED -> {
                status.text = "Not connected." + (s.lastError?.let { "\nLast problem: $it" } ?: "")
                signal.text = ""
                connectButton.text = if (s.lastError != null) "Reconnect tuner" else "Connect tuner"
                connectButton.setOnClickListener { launchDriver() }
            }
        }
    }

    override fun onSessionChanged(session: DvbSession) { refreshStatus() }

    override fun onStart() {
        super.onStart()
        app.session.addListener(this)
        refreshStatus(); refreshList()
        polling = true
        pollSignal()
    }

    override fun onStop() {
        polling = false
        app.session.removeListener(this)
        super.onStop()
    }

    /** Polls GET_STATUS about once a second while visible and connected (skipped while scanning). */
    private fun pollSignal() {
        if (!polling) return
        val s = app.session
        if (s.state == SessionState.CONNECTED && !app.tunerBusy && s.currentTune != null) {
            Thread {
                val text = try {
                    val st = s.client?.status()
                    if (st == null) "" else "lock=${yn(st.hasLock)} signal=${yn(st.hasSignal)} carrier=${yn(st.hasCarrier)} sync=${yn(st.hasSync)}  RF=${st.rfStrengthPercent}%  SNR(raw)=${st.snr}  BER(raw)=${st.bitErrorRate}  USB drops/s=${st.droppedUsbFps}"
                } catch (e: Exception) { "" }
                main.post { if (polling) signal.text = text }
            }.start()
        } else if (s.currentTune == null && s.state == SessionState.CONNECTED) {
            signal.text = "Tuner idle (no frequency tuned yet)"
        }
        main.postDelayed({ pollSignal() }, 1500)
    }

    private fun yn(b: Boolean) = if (b) "yes" else "no"

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menu.add(0, 1, 0, "Favourites only").isCheckable = true
        menu.add(0, 2, 1, "Diagnostics")
        menu.add(0, 6, 2, "Driver diagnostics (Advanced mode)")
        menu.add(0, 7, 3, "Network receiver (Raspberry Pi)")
        menu.add(0, 3, 4, "Open .ts capture…")
        menu.add(0, 4, 5, "Delete channel list")
        menu.add(0, 5, 6, "About / licences")
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            1 -> { favoritesOnly = !item.isChecked; item.isChecked = favoritesOnly; refreshList() }
            2 -> startActivity(Intent(this, DiagnosticsActivity::class.java))
            3 -> openTs.launch(arrayOf("video/mp2t", "video/MP2T", "application/octet-stream", "*/*"))
            4 -> AlertDialog.Builder(this).setMessage("Delete all saved channels and favourites?")
                .setPositiveButton("Delete") { _, _ -> app.channels.clear(); refreshList() }
                .setNegativeButton("Cancel", null).show()
            5 -> AlertDialog.Builder(this).setTitle("About").setMessage(ABOUT)
                .setPositiveButton("OK", null)
                .setNeutralButton("Driver info / licence") { _, _ -> startActivity(Intent(this, WelcomeActivity::class.java)) }
                .show()
            6 -> openDriverDiagnostics()
            7 -> startActivity(Intent(this, NetworkReceiverActivity::class.java))
        }
        return true
    }

    /** The driver's Advanced mode opens the USB tuner itself, so the receiver's own connection has to be released first. */
    private fun openDriverDiagnostics() {
        if (app.session.state == SessionState.DISCONNECTED) {
            startActivity(Intent(this, DvbFrontendActivity::class.java))
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Tuner in use")
            .setMessage("The tuner is connected to the receiver. Driver diagnostics need the tuner for themselves. Disconnect it now?")
            .setPositiveButton("Disconnect and open") { _, _ ->
                app.session.disconnect()
                startActivity(Intent(this, DvbFrontendActivity::class.java))
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    companion object {
        private const val ABOUT = "Open DVB Receiver 0.1.0\n\n" +
            "Independent Kotlin DVB-T/T2 receiver. Its tuner driver is the open-source \"DVB-T Driver\" " +
            "(AndroidDvbDriver, GPL-2.0-or-later, Signalware Ltd / Martin Marinov), built into this app and used over a local TCP " +
            "interface. It can also use a tuner on a Raspberry Pi running dvbnetd (menu: Network receiver).\n\n" +
            "Video/audio playback: VLC libVLC for Android (VideoLAN, LGPL-2.1+). " +
            "See NOTICE.md in the source for details.\n\n" +
            "The app contains no TV content. Use it only for broadcasts you are entitled to receive."
    }
}
