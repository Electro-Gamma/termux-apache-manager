package org.opendvb.receiver.ui

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.view.Gravity
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import info.martinmarinov.dvbdriver.DvbFrontendActivity
import info.martinmarinov.dvbdriver.NetworkReceiverActivity
import info.martinmarinov.dvbdriver.WelcomeActivity
import org.opendvb.receiver.OpenDvbApp
import org.opendvb.receiver.R
import org.opendvb.receiver.driver.DriverLauncher
import org.opendvb.receiver.driver.LaunchResult
import org.opendvb.receiver.services.Channel
import org.opendvb.receiver.tuner.DvbSession
import org.opendvb.receiver.tuner.SessionState

class MainActivity : AppCompatActivity(), DvbSession.Listener {
    private val app get() = OpenDvbApp.instance
    private lateinit var status: TextView
    private lateinit var signal: TextView
    private lateinit var connectButton: android.widget.Button
    private lateinit var list: RecyclerView
    private lateinit var empty: EmptyState
    private lateinit var adapter: ChannelListAdapter
    private var favoritesOnly = false
    private val uiPrefs by lazy { getSharedPreferences("ui", MODE_PRIVATE) }
    /** List (rows) or grid (cards): the same choice the VNC tab offers, remembered. Rows by default. */
    private var listView: Boolean
        get() = uiPrefs.getBoolean("channelListView", true)
        set(v) { uiPrefs.edit().putBoolean("channelListView", v).apply() }
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var polling = false
    private var lastSignalText = ""

    private val driverLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        when (val result = DriverLauncher.parseResult(r.resultCode, r.data)) {
            is LaunchResult.Success -> app.session.connect(result)
            is LaunchResult.Error -> {
                val usb = if (result.attachedUsb.isEmpty()) "" else
                    "\n\nUSB devices seen: " + result.attachedUsb.joinToString { "%04x:%04x".format(it.first, it.second) }
                MaterialAlertDialogBuilder(this)
                    .setTitle("Tuner problem")
                    .setMessage(DriverLauncher.describeError(result.errorCode) + usb)
                    .setPositiveButton("Retry") { _, _ -> launchDriver() }
                    .setNegativeButton("Close", null)
                    .show()
            }
            LaunchResult.Cancelled -> Toast.makeText(this, "Cancelled", Toast.LENGTH_SHORT).show()
            LaunchResult.DriverMissing -> showDriverMissing()
        }
    }

    private val openTs = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) startActivity(Intent(this, PlayerActivity::class.java).setData(uri))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Open DVB Receiver"
        val root = vertical(0, 0)
        status = label("", 15f)
        signal = label("", 12f, mono = true).muted()
        connectButton = button("Connect tuner") { launchDriver() }
        val row = horizontal()
        row.addView(button("Scan", ButtonKind.TONAL) { startActivity(Intent(this, ScanActivity::class.java)) }, weighted())
        row.addView(button("Manual", ButtonKind.TONAL) { startActivity(Intent(this, ManualTuneActivity::class.java)) }, weighted())
        row.addView(button("Guide", ButtonKind.TONAL) { startActivity(Intent(this, EpgActivity::class.java)) }, weighted())

        val statusBox = vertical(16)
        statusBox.addView(status, matchWrap())
        statusBox.addView(signal, matchWrap())
        // Header (status, connect, scan / manual / guide) keeps its 16 dp margin; the channel list below runs edge to edge
        // because its rows and cards bring their own insets, exactly as on the VNC tab.
        val header = vertical(16, 8).apply { setPadding(dp(16), dp(16), dp(16), dp(8)) }
        header.addView(card().apply { addView(statusBox, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)) }, matchWrap())
        header.addView(connectButton, matchWrap())
        header.addView(row, matchWrap())
        root.addView(header, matchWrap())

        list = RecyclerView(this).apply {
            layoutManager = GridLayoutManager(this@MainActivity, 1)
            clipToPadding = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        empty = emptyState()
        val body = FrameLayout(this)
        body.addView(list, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        body.addView(empty.view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP))
        root.addView(body, fill())
        setContentView(root)

        adapter = ChannelListAdapter(
            previews = app.previews,
            nowTitle = { c -> app.epg.now(c.key)?.title },
            onClick = { c -> play(c) },
            onLongClick = { c ->
                app.channels.toggleFavorite(c.key)
                refreshList()
                Toast.makeText(this, if (!c.favorite) "Added to favourites" else "Removed from favourites", Toast.LENGTH_SHORT).show()
            },
        )
        list.adapter = adapter
        handleAttachIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleAttachIntent(intent)
    }

    private fun handleAttachIntent(i: Intent?) {
        if (i?.action == DriverLauncher.ACTION_DEVICE_ATTACHED && app.session.state == SessionState.DISCONNECTED) launchDriver()
    }

    private fun launchDriver() {
        if (app.session.state == SessionState.CONNECTING) return
        try {
            driverLauncher.launch(DriverLauncher.createIntent(this))
        } catch (e: ActivityNotFoundException) {
            showDriverMissing()
        }
    }

    private fun showDriverMissing() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Built-in driver unavailable")
            .setMessage("The DVB driver that is built into this app could not be started. Reinstall the app; if it keeps happening, report it together with the Android version.")
            .setPositiveButton("Project page") { _, _ -> openUrl("https://github.com/signalwareltd/AndroidDvbDriver") }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun openUrl(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: ActivityNotFoundException) {}
    }

    private fun play(c: Channel) {
        if (app.session.state != SessionState.CONNECTED) {
            Toast.makeText(this, "Connect the tuner first", Toast.LENGTH_SHORT).show()
            return
        }
        startActivity(Intent(this, PlayerActivity::class.java).putExtra(PlayerActivity.EXTRA_CHANNEL_KEY, c.key))
    }

    private fun refreshList() {
        val all = app.channels.load()
        val filtered = if (favoritesOnly) all.filter { it.favorite } else all
        val shown = filtered.filter { it.favorite } + filtered.filter { !it.favorite }   // pinned first, like the VNC list
        val asList = listView
        // As many columns as fit, the VNC rule: a row wants about 480 dp, a card about 240 dp (never fewer than two cards).
        val widthDp = resources.configuration.screenWidthDp
        val span = if (asList) maxOf(1, Math.round(widthDp / 480f)) else maxOf(2, Math.round(widthDp / 240f))
        (list.layoutManager as GridLayoutManager).spanCount = span
        val side = if (asList) 0 else dp(8)
        list.setPadding(side, if (asList) dp(8) else 0, side, dp(16))
        adapter.submit(shown, asList, span)
        empty.view.show(shown.isEmpty())
        if (favoritesOnly) empty.set("No favourites", "Long-press a channel to add one.")
        else empty.set("No channels yet", "Connect the tuner, then press Scan.")
    }

    private fun refreshStatus() {
        val s = app.session
        when (s.state) {
            SessionState.CONNECTED -> {
                val c = s.capabilities
                val sys = c?.deliverySystems?.joinToString("/") { it.name } ?: "?"
                status.text = "Connected: ${s.deviceName}\nSupports: $sys" +
                    (c?.let { "  ·  %.0f–%.0f MHz".format(it.frequencyMinHz / 1e6, it.frequencyMaxHz / 1e6) } ?: "") +
                    "  ·  driver protocol v${s.protocolVersion}"
                connectButton.text = "Disconnect"
                connectButton.setOnClickListener { s.disconnect() }
            }
            SessionState.CONNECTING -> {
                status.text = "Connecting to the driver…"
                connectButton.text = "Please wait…"
                connectButton.setOnClickListener(null)
            }
            SessionState.DISCONNECTED -> {
                status.text = "Not connected." + (s.lastError?.let { "\nLast problem: $it" } ?: "")
                signal.text = ""
                connectButton.text = if (s.lastError != null) "Reconnect tuner" else "Connect tuner"
                connectButton.setOnClickListener { launchDriver() }
            }
        }
    }

    override fun onSessionChanged(session: DvbSession) { refreshStatus() }

    override fun onStart() {
        super.onStart()
        app.session.addListener(this)
        refreshStatus(); refreshList()
        polling = true
        pollSignal()
    }

    override fun onStop() {
        polling = false
        app.session.removeListener(this)
        super.onStop()
    }

    /** Polls GET_STATUS about once a second while visible and connected (skipped while scanning). */
    private fun pollSignal() {
        if (!polling) return
        val s = app.session
        if (s.state == SessionState.CONNECTED && !app.tunerBusy && s.currentTune != null) {
            Thread {
                val text = try {
                    val st = s.client?.status()
                    if (st == null) "" else "lock=${yn(st.hasLock)} signal=${yn(st.hasSignal)} carrier=${yn(st.hasCarrier)} sync=${yn(st.hasSync)}  RF=${st.rfStrengthPercent}%  SNR(raw)=${st.snr}  BER(raw)=${st.bitErrorRate}  USB drops/s=${st.droppedUsbFps}"
                } catch (e: Exception) { "" }
                main.post { if (polling) signal.text = text }
            }.start()
        } else if (s.currentTune == null && s.state == SessionState.CONNECTED) {
            signal.text = "Tuner idle (no frequency tuned yet)"
        }
        main.postDelayed({ pollSignal() }, 1500)
    }

    private fun yn(b: Boolean) = if (b) "yes" else "no"

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // The icon and the label are the shape being switched *to*, as on the VNC tab.
        menu.add(0, 8, 0, if (listView) "Grid view" else "List view").apply {
            setIcon(if (listView) R.drawable.ic_view_grid else R.drawable.ic_view_list)
            icon?.mutate()?.setTint(color(R.color.md_on_surface_variant))
            setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS)
        }
        menu.add(0, 1, 1, "Favourites only").apply { isCheckable = true; isChecked = favoritesOnly }
        menu.add(0, 2, 2, "Diagnostics")
        menu.add(0, 6, 3, "Driver diagnostics (Advanced mode)")
        menu.add(0, 7, 4, "Network receiver (Raspberry Pi)")
        menu.add(0, 3, 5, "Open .ts capture…")
        menu.add(0, 4, 6, "Delete channel list")
        menu.add(0, 5, 7, "About / licences")
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            1 -> { favoritesOnly = !item.isChecked; item.isChecked = favoritesOnly; refreshList() }
            8 -> { listView = !listView; invalidateOptionsMenu(); refreshList() }
            2 -> startActivity(Intent(this, DiagnosticsActivity::class.java))
            3 -> openTs.launch(arrayOf("video/mp2t", "video/MP2T", "application/octet-stream", "*/*"))
            4 -> MaterialAlertDialogBuilder(this).setMessage("Delete all saved channels and favourites?")
                .setPositiveButton("Delete") { _, _ -> app.channels.clear(); app.previews.clear(); refreshList() }
                .setNegativeButton("Cancel", null).show()
            5 -> MaterialAlertDialogBuilder(this).setTitle("About").setMessage(ABOUT)
                .setPositiveButton("OK", null)
                .setNeutralButton("Driver info / licence") { _, _ -> startActivity(Intent(this, WelcomeActivity::class.java)) }
                .show()
            6 -> openDriverDiagnostics()
            7 -> startActivity(Intent(this, NetworkReceiverActivity::class.java))
        }
        return true
    }

    /** The driver's Advanced mode opens the USB tuner itself, so the receiver's own connection has to be released first. */
    private fun openDriverDiagnostics() {
        if (app.session.state == SessionState.DISCONNECTED) {
            startActivity(Intent(this, DvbFrontendActivity::class.java))
            return
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Tuner in use")
            .setMessage("The tuner is connected to the receiver. Driver diagnostics need the tuner for themselves. Disconnect it now?")
            .setPositiveButton("Disconnect and open") { _, _ ->
                app.session.disconnect()
                startActivity(Intent(this, DvbFrontendActivity::class.java))
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    companion object {
        private const val ABOUT = "Open DVB Receiver 0.1.0\n\n" +
            "Independent Kotlin DVB-T/T2 receiver. Its tuner driver is the open-source \"DVB-T Driver\" " +
            "(AndroidDvbDriver, GPL-2.0-or-later, Signalware Ltd / Martin Marinov), built into this app and used over a local TCP " +
            "interface. It can also use a tuner on a Raspberry Pi running dvbnetd (menu: Network receiver).\n\n" +
            "Video/audio playback: VLC libVLC for Android (VideoLAN, LGPL-2.1+). " +
            "See NOTICE.md in the source for details.\n\n" +
            "The app contains no TV content. Use it only for broadcasts you are entitled to receive."
    }
}
