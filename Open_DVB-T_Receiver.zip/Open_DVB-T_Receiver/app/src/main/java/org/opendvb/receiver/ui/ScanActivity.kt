package org.opendvb.receiver.ui

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ProgressBar
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import info.martinmarinov.dvbdriver.UpActivity
import com.google.android.material.radiobutton.MaterialRadioButton
import org.opendvb.receiver.OpenDvbApp
import org.opendvb.receiver.services.BackgroundService
import org.opendvb.receiver.tuner.ChannelPlan
import org.opendvb.receiver.tuner.Scanner
import org.opendvb.receiver.tuner.SessionState
import java.util.concurrent.atomic.AtomicBoolean

class ScanActivity : UpActivity() {
    private val app get() = OpenDvbApp.instance
    private val main = Handler(Looper.getMainLooper())
    private val cancel = AtomicBoolean(false)
    private lateinit var log: TextView
    private lateinit var progress: ProgressBar
    private lateinit var startButton: android.widget.Button
    private lateinit var plans: RadioGroup
    @Volatile private var running = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Channel scan"
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val root = vertical()
        root.addView(label("Scans the European terrestrial raster (VHF III 7 MHz, UHF 8 MHz) and tries every standard the tuner reports. " +
            "For other regions use Manual.", 14f).muted(), matchWrap())
        plans = RadioGroup(this).apply { setPadding(dp(8), dp(8), dp(8), dp(8)) }
        val items = listOf("Full scan (VHF III + UHF)", "UHF only (channels 21–69)", "VHF III only (channels 5–12)")
        items.forEachIndexed { i, t -> plans.addView(MaterialRadioButton(this).apply { text = t; id = 100 + i }) }
        plans.check(100)
        root.addView(card().apply { addView(plans, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)) }, matchWrap())
        startButton = button("Start scan") { toggle() }
        root.addView(startButton, matchWrap())
        progress = com.google.android.material.progressindicator.LinearProgressIndicator(this)
        root.addView(progress, matchWrap())
        log = label("", 12f, mono = true).apply { setPadding(dp(12), dp(12), dp(12), dp(12)) }
        val sv = ScrollView(this)
        sv.addView(log)
        // The log sits in the same tonal card as the status card on the home screen.
        root.addView(card().apply { addView(sv, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)) }, fill())
        setContentView(root)
    }

    private fun toggle() {
        if (running) { cancel.set(true); return }
        if (app.session.state != SessionState.CONNECTED) { log.text = "Not connected to the tuner. Go back and connect first.\n"; return }
        val candidates = ChannelPlan.filter(
            when (plans.checkedRadioButtonId) {
                101 -> ChannelPlan.uhfEurope()
                102 -> ChannelPlan.vhfEurope()
                else -> ChannelPlan.europeFull()
            }, app.session.capabilities,
        )
        if (candidates.isEmpty()) { log.text = "The tuner's frequency range does not cover this plan.\n"; return }
        cancel.set(false)
        running = true
        app.tunerBusy = true
        BackgroundService.sync(this)
        startButton.text = "Cancel"
        progress.max = candidates.size
        progress.progress = 0
        log.text = "Scanning ${candidates.size} frequencies…\n"
        Thread({
            try {
                val scanner = Scanner(app.session, cancel)
                // A multiplex is added to the channel list the moment it has been scanned (not only when the whole scan ends).
                scanner.onMultiplexFound = { app.channels.merge(it) }
                val found = scanner.scan(candidates) { p ->
                    main.post {
                        progress.progress = p.index
                        if (p.locked) log.append(p.label + "  " + "%.1f".format(p.frequencyHz / 1e6) + " MHz: lock, " + p.found + " services so far\n")
                    }
                }
                app.channels.merge(found)
                try { app.session.setPids(emptyList()) } catch (_: Exception) {}
                main.post {
                    log.append(if (cancel.get()) "\nCancelled. Kept ${found.size} services found so far.\n" else "\nDone: ${found.size} services.\n")
                    for (c in found) log.append("  " + c.displayName + "  (" + "%.1f".format(c.frequencyMhz) + " MHz, " + c.system.name + ")\n")
                }
            } catch (e: Exception) {
                main.post { log.append("\nScan failed: ${e.message}\n") }
            } finally {
                running = false
                app.tunerBusy = false
                main.post { startButton.text = "Start scan"; BackgroundService.sync(this) }
            }
        }, "Scan").start()
    }

    override fun onDestroy() {
        // Home / app switch only stops the activity, so a running scan keeps going in the background; leaving the screen cancels it.
        cancel.set(true)
        super.onDestroy()
    }
}
