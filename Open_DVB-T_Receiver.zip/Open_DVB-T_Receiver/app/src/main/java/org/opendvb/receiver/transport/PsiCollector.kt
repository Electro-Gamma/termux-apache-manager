package org.opendvb.receiver.transport

import java.util.concurrent.ConcurrentHashMap

/**
 * TsSink that collects PAT / PMT / SDT / NIT / EIT from the stream. Callbacks run on the TS reader
 * thread; keep them short. PMT PIDs are discovered from the PAT.
 */
class PsiCollector(
    private val onPat: (Pat) -> Unit = {},
    private val onPmt: (Pmt) -> Unit = {},
    private val onSdt: (Sdt) -> Unit = {},
    private val onNit: (Nit) -> Unit = {},
    private val onEit: (Eit) -> Unit = {},
) : TsSink {
    @Volatile var pat: Pat? = null
        private set
    @Volatile var sdt: Sdt? = null
        private set
    @Volatile var nit: Nit? = null
        private set
    private val pmts = ConcurrentHashMap<Int, Pmt>() // by program number
    private val assemblers = HashMap<Int, SectionAssembler>()

    val pmtByProgram: Map<Int, Pmt> get() = pmts

    private fun handlePat(s: ByteArray) { Psi.parsePat(s)?.let { pat = it; onPat(it) } }
    private fun handleNit(s: ByteArray) { Psi.parseNit(s)?.let { nit = it; onNit(it) } }
    private fun handleSdt(s: ByteArray) { Psi.parseSdt(s)?.let { sdt = it; onSdt(it) } }
    private fun handleEit(s: ByteArray) { Psi.parseEit(s)?.let { onEit(it) } }
    private fun handlePmt(s: ByteArray) { Psi.parsePmt(s)?.let { pmts[it.programNumber] = it; onPmt(it) } }

    private fun assembler(pid: Int): SectionAssembler? {
        assemblers[pid]?.let { return it }
        val handler: ((ByteArray) -> Unit)? = when (pid) {
            Ts.PID_PAT -> this::handlePat
            Ts.PID_NIT -> this::handleNit
            Ts.PID_SDT -> this::handleSdt
            Ts.PID_EIT -> this::handleEit
            else -> {
                val p = pat
                if (p != null && p.programs.any { it.pid == pid }) this::handlePmt else null
            }
        }
        if (handler == null) return null
        val a = SectionAssembler(handler)
        assemblers[pid] = a
        return a
    }

    override fun onPacket(buf: ByteArray, off: Int) {
        val pid = Ts.pid(buf, off)
        if (pid == Ts.PID_NULL) return
        assembler(pid)?.push(buf, off)
    }

    fun reset() {
        pat = null; sdt = null; nit = null
        pmts.clear(); assemblers.clear()
    }
}
