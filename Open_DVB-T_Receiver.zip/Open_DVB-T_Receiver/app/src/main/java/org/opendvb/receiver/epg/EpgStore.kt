package org.opendvb.receiver.epg

import org.opendvb.receiver.transport.Eit
import org.opendvb.receiver.transport.EpgEvent

/** In-memory EPG, filled from EIT sections of the multiplex that is currently tuned. Thread-safe. */
class EpgStore {
    private val events = HashMap<String, MutableMap<Int, EpgEvent>>() // key -> eventId -> event
    @Volatile var lastUpdateMs = 0L
        private set

    private fun key(frequencyHz: Long, serviceId: Int) = "$frequencyHz:$serviceId"

    @Synchronized
    fun add(frequencyHz: Long, eit: Eit) {
        if (eit.events.isEmpty()) return
        val m = events.getOrPut(key(frequencyHz, eit.serviceId)) { HashMap() }
        for (e in eit.events) m[e.eventId] = e
        lastUpdateMs = System.currentTimeMillis()
    }

    @Synchronized
    fun eventsFor(channelKey: String): List<EpgEvent> =
        (events[channelKey]?.values ?: emptyList<EpgEvent>()).sortedBy { it.startUtcMs }

    fun now(channelKey: String, nowMs: Long = System.currentTimeMillis()): EpgEvent? =
        eventsFor(channelKey).firstOrNull { nowMs >= it.startUtcMs && nowMs < it.endUtcMs }

    fun next(channelKey: String, nowMs: Long = System.currentTimeMillis()): EpgEvent? =
        eventsFor(channelKey).firstOrNull { it.startUtcMs > nowMs }

    /** Drops events that ended more than an hour ago. */
    @Synchronized
    fun prune(nowMs: Long = System.currentTimeMillis()) {
        for (m in events.values) m.values.removeAll { it.endUtcMs < nowMs - 3_600_000L }
    }

    @Synchronized fun clear() { events.clear() }
}
