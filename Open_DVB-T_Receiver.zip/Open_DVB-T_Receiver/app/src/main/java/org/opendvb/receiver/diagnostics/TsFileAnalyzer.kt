package org.opendvb.receiver.diagnostics

import org.opendvb.receiver.transport.Ts
import org.opendvb.receiver.transport.TsReader
import org.opendvb.receiver.transport.PsiCollector
import org.opendvb.receiver.transport.TsSink
import org.opendvb.receiver.transport.TsStats
import java.io.InputStream

/** Offline analysis of a recorded/user-provided .ts capture with the same parsers used for live streams. */
object TsFileAnalyzer {
    class Result(
        val bytes: Long, val resyncs: Long, val stats: TsStats, val collector: PsiCollector,
    )

    fun analyze(input: InputStream, maxBytes: Long = 64L * 1024 * 1024): Result {
        val stats = TsStats()
        val collector = PsiCollector()
        val sinks = listOf<TsSink>(stats, collector)
        val buf = ByteArray(Ts.PACKET_SIZE * 256)
        var fill = 0
        var total = 0L
        var resyncs = 0L
        while (total < maxBytes) {
            val n = input.read(buf, fill, buf.size - fill)
            if (n < 0) break
            fill += n
            total += n
            fill = TsReader.dispatch(buf, fill, sinks) { resyncs++ }
        }
        return Result(total, resyncs, stats, collector)
    }

    private fun hex4(v: Int) = "0x" + Integer.toHexString(v).uppercase().padStart(4, '0')
    private fun hex2(v: Int) = "0x" + Integer.toHexString(v and 0xFF).uppercase().padStart(2, '0')

    fun describe(r: Result, pidName: (Int) -> String?): String {
        val sb = StringBuilder()
        sb.append("Bytes analysed: ").append(r.bytes).append("  (packets: ").append(r.stats.totalPackets)
            .append(", resyncs: ").append(r.resyncs).append(")\n")
        val pat = r.collector.pat
        if (pat == null) {
            sb.append("\nNo PAT found.\n")
        } else {
            sb.append("\nPAT  tsId=").append(pat.transportStreamId).append("  programs=").append(pat.programs.size).append('\n')
            for (e in pat.programs) sb.append("  program ").append(e.programNumber).append(" -> PMT pid ").append(hex4(e.pid)).append('\n')
        }
        r.collector.sdt?.let { sdt ->
            sb.append("\nSDT  onid=").append(sdt.originalNetworkId).append('\n')
            for (s in sdt.services) {
                sb.append("  ").append(s.serviceId).append(": ").append(s.name).append(" [").append(s.provider)
                    .append("] type=").append(hex2(s.serviceType)).append(if (s.scrambled) " scrambled" else "").append('\n')
            }
        }
        r.collector.nit?.let {
            sb.append("\nNIT  network=").append(it.networkName ?: "?").append(" (id ").append(it.networkId)
                .append("), ").append(it.transportStreams.size).append(" TS\n")
        }
        for ((prog, pmt) in r.collector.pmtByProgram.toSortedMap()) {
            sb.append("\nPMT program ").append(prog).append("  PCR pid ").append(hex4(pmt.pcrPid)).append('\n')
            for (es in pmt.streams) {
                sb.append("  pid ").append(hex4(es.pid)).append("  ").append(es.kind).append("  ").append(es.codec)
                    .append(es.language?.let { " ($it)" } ?: "").append('\n')
            }
        }
        sb.append("\nPID statistics\n")
        for (p in r.stats.snapshot()) {
            sb.append("  ").append(hex4(p.pid)).append(' ').append((pidName(p.pid) ?: "").padEnd(10))
                .append(" packets=").append(p.packets).append(" ccErrors=").append(p.ccErrors)
                .append(" scrambled=").append(p.scrambled).append(" tei=").append(p.tei).append('\n')
        }
        return sb.toString()
    }

    fun wellKnownPidName(pid: Int): String? = when (pid) {
        Ts.PID_PAT -> "PAT"
        Ts.PID_NIT -> "NIT"
        Ts.PID_SDT -> "SDT/BAT"
        Ts.PID_EIT -> "EIT"
        0x0013 -> "RST"
        0x0014 -> "TDT/TOT"
        Ts.PID_NULL -> "null"
        else -> null
    }
}
