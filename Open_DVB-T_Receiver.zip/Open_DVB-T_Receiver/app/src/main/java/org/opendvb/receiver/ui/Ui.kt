package org.opendvb.receiver.ui

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.annotation.ColorRes
import androidx.annotation.StyleRes
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.core.widget.TextViewCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.textfield.MaterialAutoCompleteTextView
import com.google.android.material.textfield.TextInputLayout
import info.martinmarinov.dvbdriver.NoFilterAdapter
import org.opendvb.receiver.R

internal fun Context.dp(v: Int): Int = TypedValue.applyDimension(
    TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics,
).toInt()

/** A palette colour (res/values/colors.xml, dark values in values-night): follows light/dark automatically. */
internal fun Context.color(@ColorRes id: Int): Int = ContextCompat.getColor(this, id)

internal fun Context.label(text: CharSequence = "", sizeSp: Float = 14f, mono: Boolean = false): TextView =
    TextView(this).apply {
        this.text = text
        textSize = sizeSp
        if (mono) typeface = Typeface.MONOSPACE
    }

/** Secondary text colour (on-surface-variant). */
internal fun TextView.muted(): TextView = apply { setTextColor(context.color(R.color.md_on_surface_variant)) }

internal fun TextView.appearance(@StyleRes style: Int): TextView = apply { TextViewCompat.setTextAppearance(this, style) }

internal enum class ButtonKind { FILLED, TONAL, OUTLINED, TEXT }

/** Material 3 button. FILLED = primary action, TONAL = secondary, OUTLINED / TEXT = low emphasis. */
internal fun Context.button(text: String, kind: ButtonKind = ButtonKind.FILLED, onClick: () -> Unit): MaterialButton =
    MaterialButton(this).apply {
        this.text = text
        isAllCaps = false
        when (kind) {
            ButtonKind.FILLED -> Unit   // theme default: colorPrimary / colorOnPrimary
            ButtonKind.TONAL -> {
                backgroundTintList = ColorStateList.valueOf(context.color(R.color.md_secondary_container))
                setTextColor(context.color(R.color.md_on_secondary_container))
            }
            ButtonKind.OUTLINED -> {
                backgroundTintList = ColorStateList.valueOf(Color.TRANSPARENT)
                setTextColor(context.color(R.color.md_primary))
                strokeWidth = context.dp(1)
                strokeColor = ColorStateList.valueOf(context.color(R.color.md_outline))
            }
            ButtonKind.TEXT -> {
                backgroundTintList = ColorStateList.valueOf(Color.TRANSPARENT)
                setTextColor(context.color(R.color.md_primary))
            }
        }
        setOnClickListener { onClick() }
    }

/** Button for the always-dark video overlay: the same pill shape as every other button, translucent white container, white label. */
internal fun Context.overlayButton(text: String, onClick: () -> Unit): MaterialButton =
    button(text, ButtonKind.TEXT, onClick).apply {
        setTextColor(Color.WHITE)
        backgroundTintList = ColorStateList.valueOf(Color.argb(0x33, 0xFF, 0xFF, 0xFF))
        compactOverlay(this)
    }

/** Icon-only variant (previous / next channel): a centred glyph instead of a tiny text arrow. */
internal fun Context.overlayIconButton(iconRes: Int, description: String, onClick: () -> Unit): MaterialButton =
    button("", ButtonKind.TEXT, onClick).apply {
        backgroundTintList = ColorStateList.valueOf(Color.argb(0x33, 0xFF, 0xFF, 0xFF))
        compactOverlay(this)
        icon = ContextCompat.getDrawable(context, iconRes)
        iconTint = ColorStateList.valueOf(Color.WHITE)
        iconSize = dp(24)
        iconPadding = 0
        iconGravity = MaterialButton.ICON_GRAVITY_TEXT_START
        setPadding(0, 0, 0, 0)
        contentDescription = description
    }

/** Overlay buttons share a row, so each label stays on one line and the padding is small enough to fit a phone width. */
private fun Context.compactOverlay(b: MaterialButton) = b.apply {
    isSingleLine = true
    maxLines = 1
    ellipsize = android.text.TextUtils.TruncateAt.END
    minWidth = 0
    minimumWidth = 0
    minHeight = dp(44)
    minimumHeight = dp(44)
    insetTop = 0
    insetBottom = 0
    setPadding(dp(6), 0, dp(6), 0)
    textSize = 13f
    isAllCaps = false
}

/** Filled (tonal) card, M3 style. Put one child inside. */
internal fun Context.card(): MaterialCardView = MaterialCardView(this).apply {
    radius = context.dp(16).toFloat()
    cardElevation = 0f
    strokeWidth = 0
    setCardBackgroundColor(context.color(R.color.md_surface_container_high))
}

private fun Context.gapDrawable(horizontal: Boolean, gapDp: Int): GradientDrawable = GradientDrawable().apply {
    setColor(Color.TRANSPARENT)
    if (horizontal) setSize(dp(gapDp), 1) else setSize(1, dp(gapDp))
}

/** Vertical stack; children are separated by [gap] dp automatically. */
internal fun Context.vertical(pad: Int = 12, gap: Int = 8): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
    dividerDrawable = gapDrawable(false, gap)
    showDividers = LinearLayout.SHOW_DIVIDER_MIDDLE
}

internal fun Context.horizontal(gap: Int = 8): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.HORIZONTAL
    dividerDrawable = gapDrawable(true, gap)
    showDividers = LinearLayout.SHOW_DIVIDER_MIDDLE
}

internal fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
internal fun weighted(w: Float = 1f) = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, w)
internal fun Context.overlayParams(w: Float) = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, w).apply {
    setMargins(dp(3), 0, dp(3), 0)
}
internal fun fill() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)

internal fun View.show(visible: Boolean) { visibility = if (visible) View.VISIBLE else View.GONE }

internal fun fmtTime(ms: Long): String =
    java.text.SimpleDateFormat("EEE HH:mm", java.util.Locale.getDefault()).format(java.util.Date(ms))

// ---- shared building blocks (one look for every screen) -------------------------------------------

/** Clips a view to a rounded rectangle: the preview picture on a list row, the whole card on the grid. */
internal fun View.roundClip(radiusDp: Int) {
    val r = context.dp(radiusDp).toFloat()
    outlineProvider = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) { outline.setRoundRect(0, 0, view.width, view.height, r) }
    }
    clipToOutline = true
}

/**
 * Background of a list item, as on the VNC list: surface fill, 1 dp outline-variant stroke, its own corner radii
 * (large at the ends of a group, small between rows) and a primary-coloured ripple.
 */
internal fun Context.groupedBackground(topDp: Int, bottomDp: Int): Drawable {
    fun shape(stroke: Boolean) = GradientDrawable().apply {
        val t = dp(topDp).toFloat()
        val b = dp(bottomDp).toFloat()
        cornerRadii = floatArrayOf(t, t, t, t, b, b, b, b)
        setColor(color(R.color.md_surface))
        if (stroke) setStroke(dp(1), color(R.color.md_outline_variant))
    }
    val ripple = ColorStateList.valueOf(ColorUtils.setAlphaComponent(color(R.color.md_primary), 0x1F))
    return RippleDrawable(ripple, shape(true), shape(false))
}

/** An outlined Material 3 drop-down (exposed dropdown menu). [index] is the selected position. */
internal class Dropdown(val layout: TextInputLayout, private val field: MaterialAutoCompleteTextView, private val items: List<String>) {
    var index = 0
        private set
    var onSelected: ((Int) -> Unit)? = null

    fun select(i: Int) {
        if (items.isEmpty()) return
        index = i.coerceIn(0, items.size - 1)
        field.setText(items[index], false)
    }

    internal fun attach() {
        field.setOnItemClickListener { _, _, pos, _ -> index = pos; onSelected?.invoke(pos) }
    }
}

internal fun Context.dropdown(hint: String, items: List<String>, selected: Int = 0, helper: String? = null): Dropdown {
    val layout = TextInputLayout(this, null, com.google.android.material.R.attr.textInputOutlinedExposedDropdownMenuStyle).apply {
        this.hint = hint
        if (helper != null) helperText = helper
    }
    val field = MaterialAutoCompleteTextView(layout.context).apply {
        inputType = InputType.TYPE_NULL
        setAdapter(NoFilterAdapter(layout.context, items))
    }
    layout.addView(field)
    return Dropdown(layout, field, items).also { it.attach(); it.select(selected) }
}

/** "Nothing here yet": an icon, a title and a hint, centred, as the VNC tab shows for an empty list. */
internal class EmptyState(val view: LinearLayout, private val title: TextView, private val hint: TextView) {
    fun set(titleText: String, hintText: String) { title.text = titleText; hint.text = hintText }
}

internal fun Context.emptyState(): EmptyState {
    val icon = ImageView(this).apply {
        setImageResource(R.drawable.ic_tv)
        alpha = 0.35f
        imageTintList = ColorStateList.valueOf(color(R.color.md_on_surface))
    }
    val title = label("").appearance(com.google.android.material.R.style.TextAppearance_Material3_TitleMedium)
    val hint = label("").appearance(com.google.android.material.R.style.TextAppearance_Material3_BodyMedium).muted()
    title.gravity = Gravity.CENTER
    hint.gravity = Gravity.CENTER
    val box = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(dp(24), dp(48), dp(24), dp(24))
        addView(icon, LinearLayout.LayoutParams(dp(56), dp(56)))
        addView(title, matchWrap().apply { topMargin = dp(12) })
        addView(hint, matchWrap().apply { topMargin = dp(4) })
    }
    return EmptyState(box, title, hint)
}

/** Text in a tonal card (the log of a scan, the diagnostics dump): same card as the status card on the home screen. */
internal fun Context.textCard(content: View, pad: Int = 12): MaterialCardView = card().apply {
    addView(content, ViewGroup.MarginLayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    (content as? TextView)?.setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
}
