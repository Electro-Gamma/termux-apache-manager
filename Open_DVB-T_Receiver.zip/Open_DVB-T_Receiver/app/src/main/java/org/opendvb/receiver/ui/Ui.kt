package org.opendvb.receiver.ui

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.annotation.ColorRes
import androidx.annotation.StyleRes
import androidx.core.content.ContextCompat
import androidx.core.widget.TextViewCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import org.opendvb.receiver.R

internal fun Context.dp(v: Int): Int = TypedValue.applyDimension(
    TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics,
).toInt()

/** A palette colour (res/values/colors.xml, dark values in values-night): follows light/dark automatically. */
internal fun Context.color(@ColorRes id: Int): Int = ContextCompat.getColor(this, id)

internal fun Context.label(text: CharSequence = "", sizeSp: Float = 14f, mono: Boolean = false): TextView =
    TextView(this).apply {
        this.text = text
        textSize = sizeSp
        if (mono) typeface = Typeface.MONOSPACE
    }

/** Secondary text colour (on-surface-variant). */
internal fun TextView.muted(): TextView = apply { setTextColor(context.color(R.color.md_on_surface_variant)) }

internal fun TextView.appearance(@StyleRes style: Int): TextView = apply { TextViewCompat.setTextAppearance(this, style) }

internal enum class ButtonKind { FILLED, TONAL, OUTLINED, TEXT }

/** Material 3 button. FILLED = primary action, TONAL = secondary, OUTLINED / TEXT = low emphasis. */
internal fun Context.button(text: String, kind: ButtonKind = ButtonKind.FILLED, onClick: () -> Unit): MaterialButton =
    MaterialButton(this).apply {
        this.text = text
        isAllCaps = false
        when (kind) {
            ButtonKind.FILLED -> Unit   // theme default: colorPrimary / colorOnPrimary
            ButtonKind.TONAL -> {
                backgroundTintList = ColorStateList.valueOf(context.color(R.color.md_secondary_container))
                setTextColor(context.color(R.color.md_on_secondary_container))
            }
            ButtonKind.OUTLINED -> {
                backgroundTintList = ColorStateList.valueOf(Color.TRANSPARENT)
                setTextColor(context.color(R.color.md_primary))
                strokeWidth = context.dp(1)
                strokeColor = ColorStateList.valueOf(context.color(R.color.md_outline))
            }
            ButtonKind.TEXT -> {
                backgroundTintList = ColorStateList.valueOf(Color.TRANSPARENT)
                setTextColor(context.color(R.color.md_primary))
            }
        }
        setOnClickListener { onClick() }
    }

/** Text button for the always-dark video overlay (white label, no background). */
internal fun Context.overlayButton(text: String, onClick: () -> Unit): MaterialButton =
    button(text, ButtonKind.TEXT, onClick).apply { setTextColor(Color.WHITE) }

/** Filled (tonal) card, M3 style. Put one child inside. */
internal fun Context.card(): MaterialCardView = MaterialCardView(this).apply {
    radius = context.dp(16).toFloat()
    cardElevation = 0f
    strokeWidth = 0
    setCardBackgroundColor(context.color(R.color.md_surface_container_high))
}

private fun Context.gapDrawable(horizontal: Boolean, gapDp: Int): GradientDrawable = GradientDrawable().apply {
    setColor(Color.TRANSPARENT)
    if (horizontal) setSize(dp(gapDp), 1) else setSize(1, dp(gapDp))
}

/** Vertical stack; children are separated by [gap] dp automatically. */
internal fun Context.vertical(pad: Int = 12, gap: Int = 8): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
    dividerDrawable = gapDrawable(false, gap)
    showDividers = LinearLayout.SHOW_DIVIDER_MIDDLE
}

internal fun Context.horizontal(gap: Int = 8): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.HORIZONTAL
    dividerDrawable = gapDrawable(true, gap)
    showDividers = LinearLayout.SHOW_DIVIDER_MIDDLE
}

internal fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
internal fun weighted(w: Float = 1f) = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, w)
internal fun fill() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)

internal fun View.show(visible: Boolean) { visibility = if (visible) View.VISIBLE else View.GONE }

internal fun fmtTime(ms: Long): String =
    java.text.SimpleDateFormat("EEE HH:mm", java.util.Locale.getDefault()).format(java.util.Date(ms))
