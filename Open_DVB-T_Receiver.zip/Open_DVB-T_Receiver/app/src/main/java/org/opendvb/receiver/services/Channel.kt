package org.opendvb.receiver.services

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import org.opendvb.receiver.driver.DeliverySystem
import org.opendvb.receiver.transport.EsInfo
import org.opendvb.receiver.transport.EsKind
import java.io.File

data class Channel(
    val serviceId: Int,
    val transportStreamId: Int,
    val originalNetworkId: Int,
    val name: String,
    val provider: String,
    val serviceType: Int,
    val frequencyHz: Long,
    val bandwidthHz: Long,
    val system: DeliverySystem,
    val pmtPid: Int,
    val pcrPid: Int,
    val streams: List<EsInfo>,
    val scrambled: Boolean,
    val favorite: Boolean = false,
) {
    /** Stable identity: the same service on the same multiplex frequency. */
    val key: String get() = "$frequencyHz:$serviceId"
    val isRadio: Boolean get() = serviceType == 0x02 || serviceType == 0x0A
    val isTv: Boolean get() = !isRadio
    val displayName: String get() = name.ifBlank { "Service $serviceId" }
    val frequencyMhz: Double get() = frequencyHz / 1_000_000.0

    fun videoSummary(): String = streams.firstOrNull { it.kind == EsKind.VIDEO }?.codec ?: "no video"
    fun audioSummary(): String = streams.filter { it.kind == EsKind.AUDIO }.joinToString(", ") {
        it.codec + (it.language?.let { l -> " ($l)" } ?: "")
    }.ifEmpty { "no audio" }

    /** PIDs the receiver needs for playback: PAT, this PMT, PCR and every elementary stream. */
    fun playbackPids(): Set<Int> {
        val s = LinkedHashSet<Int>()
        s.add(0); s.add(pmtPid); s.add(pcrPid)
        streams.forEach { s.add(it.pid) }
        s.remove(0x1FFF)
        return s
    }

    companion object {
        /** DVB service types we list: digital TV/radio (incl. MPEG-2 HD, AVC, HEVC variants). Others (data, teletext...) are skipped. */
        fun isListable(serviceType: Int) = serviceType in setOf(0x01, 0x02, 0x0A, 0x11, 0x16, 0x17, 0x19, 0x1A, 0x1F, 0x20)
    }
}

/** JSON persistence of the channel list (no extra dependencies). */
object ChannelJson {
    fun toJson(list: List<Channel>): String {
        val arr = JSONArray()
        for (c in list) {
            val o = JSONObject()
            o.put("serviceId", c.serviceId); o.put("tsId", c.transportStreamId); o.put("onId", c.originalNetworkId)
            o.put("name", c.name); o.put("provider", c.provider); o.put("type", c.serviceType)
            o.put("freq", c.frequencyHz); o.put("bw", c.bandwidthHz); o.put("system", c.system.name)
            o.put("pmtPid", c.pmtPid); o.put("pcrPid", c.pcrPid); o.put("scrambled", c.scrambled); o.put("fav", c.favorite)
            val st = JSONArray()
            for (e in c.streams) {
                val so = JSONObject()
                so.put("type", e.streamType); so.put("pid", e.pid); so.put("kind", e.kind.name); so.put("codec", e.codec)
                so.put("lang", e.language ?: JSONObject.NULL)
                st.put(so)
            }
            o.put("streams", st)
            arr.put(o)
        }
        return JSONObject().put("version", 1).put("channels", arr).toString()
    }

    fun fromJson(text: String): List<Channel> {
        val arr = JSONObject(text).getJSONArray("channels")
        val out = ArrayList<Channel>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val sa = o.getJSONArray("streams")
            val streams = ArrayList<EsInfo>()
            for (j in 0 until sa.length()) {
                val so = sa.getJSONObject(j)
                streams.add(
                    EsInfo(
                        so.getInt("type"), so.getInt("pid"), EsKind.valueOf(so.getString("kind")), so.getString("codec"),
                        if (so.isNull("lang")) null else so.getString("lang"),
                    )
                )
            }
            out.add(
                Channel(
                    o.getInt("serviceId"), o.getInt("tsId"), o.getInt("onId"), o.getString("name"), o.getString("provider"),
                    o.getInt("type"), o.getLong("freq"), o.getLong("bw"), DeliverySystem.valueOf(o.getString("system")),
                    o.getInt("pmtPid"), o.getInt("pcrPid"), streams, o.getBoolean("scrambled"), o.optBoolean("fav", false),
                )
            )
        }
        return out
    }
}

class ChannelStore(context: Context) {
    private val file = File(context.filesDir, "channels.json")
    @Volatile private var cache: List<Channel>? = null

    @Synchronized
    fun load(): List<Channel> {
        cache?.let { return it }
        val list = try { if (file.exists()) ChannelJson.fromJson(file.readText()) else emptyList() } catch (e: Exception) { emptyList() }
        cache = list
        return list
    }

    @Synchronized
    fun save(list: List<Channel>) {
        cache = list
        val tmp = File(file.parentFile, "channels.json.tmp")
        tmp.writeText(ChannelJson.toJson(list))
        if (!tmp.renameTo(file)) { file.writeText(tmp.readText()); tmp.delete() }
    }

    /** Replaces channels of the scanned multiplexes by the new results, keeping favourites and other frequencies. */
    @Synchronized
    fun merge(found: List<Channel>) {
        val old = load()
        val favs = old.filter { it.favorite }.map { it.key }.toSet()
        val scannedFreqs = found.map { it.frequencyHz }.toSet()
        val kept = old.filter { it.frequencyHz !in scannedFreqs }
        save((kept + found.map { it.copy(favorite = it.key in favs) }).sortedWith(compareBy({ it.frequencyHz }, { it.displayName.lowercase() })))
    }

    @Synchronized
    fun toggleFavorite(key: String) = save(load().map { if (it.key == key) it.copy(favorite = !it.favorite) else it })

    @Synchronized fun clear() = save(emptyList())
    fun find(key: String): Channel? = load().firstOrNull { it.key == key }
}
