package org.opendvb.receiver.driver

import java.io.IOException
import java.io.InputStream

/**
 * Wire protocol of the open-source Android DVB-T Driver (module `dvbservice`, classes Request/Response).
 * Big-endian; request = [ordinal u8][count u8][count x int64]; response has the same shape and the
 * first int64 is a success flag (1 = ok). Verified against the driver source and the Aerial TV client.
 */
enum class DeliverySystem {
    // WARNING: order is part of the wire protocol (driver: "Do not reorder!")
    DVBT, DVBT2, DVBC
}

object Req {
    const val PROTOCOL_VERSION = 0
    const val EXIT = 1
    const val TUNE = 2
    const val GET_STATUS = 3
    const val SET_PIDS = 4
    const val GET_CAPABILITIES = 5
}

class DriverException(message: String, cause: Throwable? = null) : IOException(message, cause)

data class Capabilities(
    val deliverySystems: Set<DeliverySystem>,
    val frequencyMinHz: Long,
    val frequencyMaxHz: Long,
    val frequencyStepHz: Long,
    val vendorId: Int,
    val productId: Int,
)

/** Raw values as reported by the driver. SNR/BER units are not documented by the driver API. */
data class SignalStatus(
    val snr: Long,
    val bitErrorRate: Long,
    val droppedUsbFps: Long,
    val rfStrengthPercent: Long,
    val hasSignal: Boolean,
    val hasCarrier: Boolean,
    val hasSync: Boolean,
    val hasLock: Boolean,
)

object DriverCodec {
    fun encodeRequest(ordinal: Int, vararg payload: Long): ByteArray {
        require(payload.size <= 255) { "payload too large: ${payload.size}" }
        val out = ByteArray(2 + payload.size * 8)
        out[0] = ordinal.toByte()
        out[1] = payload.size.toByte()
        for (i in payload.indices) writeLong(out, 2 + i * 8, payload[i])
        return out
    }

    fun writeLong(buf: ByteArray, off: Int, v: Long) {
        for (i in 0 until 8) buf[off + i] = (v ushr (56 - 8 * i)).toByte()
    }

    fun readLong(buf: ByteArray, off: Int): Long {
        var r = 0L
        for (i in 0 until 8) r = (r shl 8) or (buf[off + i].toLong() and 0xFF)
        return r
    }

    fun readFully(input: InputStream, buf: ByteArray, len: Int) {
        var got = 0
        while (got < len) {
            val n = input.read(buf, got, len - got)
            if (n < 0) throw DriverException("End of stream before $len bytes were read")
            got += n
        }
    }

    /** Reads one response; returns the payload *after* the success flag. */
    fun readResponse(input: InputStream, expectedOrdinal: Int): LongArray {
        val head = ByteArray(2)
        readFully(input, head, 2)
        val ordinal = head[0].toInt() and 0xFF
        val count = head[1].toInt() and 0xFF
        if (count == 0) throw DriverException("Payload size is 0")
        val body = ByteArray(count * 8)
        readFully(input, body, body.size)
        val ok = readLong(body, 0) == 1L
        if (!ok) throw DriverException("Command $expectedOrdinal returned failure")
        if (ordinal != expectedOrdinal) {
            throw DriverException("Response does not match request, expected $expectedOrdinal but got $ordinal")
        }
        return LongArray(count - 1) { readLong(body, 8 + it * 8) }
    }
}
