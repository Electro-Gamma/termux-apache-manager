package org.opendvb.receiver.services

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import org.opendvb.receiver.OpenDvbApp
import org.opendvb.receiver.R
import org.opendvb.receiver.ui.MainActivity
import org.opendvb.receiver.ui.PlayerActivity

/**
 * Keeps the process (and so the tuner session, libVLC playback, a running recording or a channel scan) alive while the app is
 * not on screen. It runs only while something is actually active and shows an ongoing notification with Open / Stop.
 */
class BackgroundService : Service() {
    private var wakeLock: android.os.PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        try { wakeLock?.takeIf { it.isHeld }?.release() } catch (_: Exception) {}
        wakeLock = null
        super.onDestroy()
    }

    /** CPU stays on with the screen off so the stream, recording or scan is not starved. */
    private fun holdWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
        wakeLock = pm.newWakeLock(android.os.PowerManager.PARTIAL_WAKE_LOCK, "opendvb:background").apply { setReferenceCounted(false); acquire() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val app = application as OpenDvbApp
        if (intent?.action == ACTION_STOP) {
            app.stopEverything()
            stopForeground(true)
            stopSelf()
            return START_NOT_STICKY
        }
        if (!app.backgroundActive()) {
            // Started but nothing to keep alive any more: still must call startForeground once, then leave.
            startForegroundCompat(buildNotification(app))
            stopForeground(true)
            stopSelf()
            return START_NOT_STICKY
        }
        startForegroundCompat(buildNotification(app))
        holdWakeLock()
        return START_NOT_STICKY
    }

    private fun startForegroundCompat(n: Notification) {
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(NOTIFICATION_ID, n)
    }

    private fun buildNotification(app: OpenDvbApp): Notification {
        ensureChannel(this)
        val ch = app.playingChannel
        val title = when {
            ch != null -> ch.displayName
            app.tunerBusy -> "Scanning channels"
            else -> "Open DVB Receiver"
        }
        val parts = ArrayList<String>()
        if (ch != null) parts += "Playing in the background"
        if (app.recorder.isRecording) parts += "Recording %.1f MB".format(app.recorder.bytesWritten() / 1048576.0)
        if (app.tunerBusy) parts += "Scan running"
        val open = Intent(this, if (ch != null) PlayerActivity::class.java else MainActivity::class.java).apply {
            if (ch != null) putExtra(PlayerActivity.EXTRA_CHANNEL_KEY, ch.key)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val immutable = if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        val openPi = PendingIntent.getActivity(this, 1, open, PendingIntent.FLAG_UPDATE_CURRENT or immutable)
        val stopPi = PendingIntent.getService(
            this, 2, Intent(this, BackgroundService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT or immutable,
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_tv)
            .setContentTitle(title)
            .setContentText(parts.joinToString(" · "))
            .setContentIntent(openPi)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(0, "Open", openPi)
            .addAction(0, "Stop", stopPi)
            .build()
    }

    companion object {
        private const val CHANNEL_ID = "background"
        private const val NOTIFICATION_ID = 41
        private const val ACTION_STOP = "org.opendvb.receiver.STOP"

        private fun ensureChannel(ctx: Context) {
            if (Build.VERSION.SDK_INT < 26) return
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.getNotificationChannel(CHANNEL_ID) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(CHANNEL_ID, "Background playback and recording", NotificationManager.IMPORTANCE_LOW),
                )
            }
        }

        /** Starts (or refreshes) the service while playback, a recording or a scan is active, and stops it otherwise. Main thread. */
        fun sync(ctx: Context) {
            val app = ctx.applicationContext as OpenDvbApp
            val intent = Intent(app, BackgroundService::class.java)
            if (app.backgroundActive()) {
                try { ContextCompat.startForegroundService(app, intent) } catch (_: Exception) { /* not allowed right now: keeps working while visible */ }
            } else {
                app.stopService(intent)
            }
        }
    }
}
