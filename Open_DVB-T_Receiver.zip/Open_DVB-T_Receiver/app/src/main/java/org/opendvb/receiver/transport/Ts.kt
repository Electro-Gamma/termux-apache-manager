package org.opendvb.receiver.transport

import java.io.InputStream

object Ts {
    const val PACKET_SIZE = 188
    const val SYNC_BYTE = 0x47
    const val PID_PAT = 0x0000
    const val PID_NIT = 0x0010
    const val PID_SDT = 0x0011
    const val PID_EIT = 0x0012
    const val PID_NULL = 0x1FFF

    fun pid(buf: ByteArray, off: Int): Int = ((buf[off + 1].toInt() and 0x1F) shl 8) or (buf[off + 2].toInt() and 0xFF)
    fun pusi(buf: ByteArray, off: Int): Boolean = (buf[off + 1].toInt() and 0x40) != 0
    fun tei(buf: ByteArray, off: Int): Boolean = (buf[off + 1].toInt() and 0x80) != 0
    fun scrambling(buf: ByteArray, off: Int): Int = (buf[off + 3].toInt() shr 6) and 0x3
    fun adaptation(buf: ByteArray, off: Int): Int = (buf[off + 3].toInt() shr 4) and 0x3
    fun continuity(buf: ByteArray, off: Int): Int = buf[off + 3].toInt() and 0x0F
}

/** Receives complete 188-byte packets. The buffer is only valid during the call: copy to keep. */
interface TsSink {
    fun onPacket(buf: ByteArray, off: Int)
}

/**
 * Reads a byte stream, aligns it to 188-byte TS packets (re-synchronising on 0x47) and
 * dispatches every packet to the sinks. [onEnd] is called once with the error (or null on EOF).
 */
class TsReader(
    private val input: InputStream,
    private val sinks: List<TsSink>,
    private val onEnd: (Throwable?) -> Unit,
) : Thread("TsReader") {
    @Volatile var resyncCount = 0L
        private set
    @Volatile var bytesRead = 0L
        private set

    override fun run() {
        var error: Throwable? = null
        try {
            pump()
        } catch (t: Throwable) {
            error = t
        }
        onEnd(error)
    }

    private fun pump() {
        val buf = ByteArray(Ts.PACKET_SIZE * 128)
        var fill = 0
        while (!isInterrupted) {
            val n = input.read(buf, fill, buf.size - fill)
            if (n < 0) return
            fill += n
            bytesRead += n
            fill = dispatch(buf, fill, sinks) { resyncCount++ }
        }
    }

    companion object {
        /**
         * Dispatches all complete packets in buf[0 until fill]; moves the unconsumed tail to the start.
         * @return the new fill level
         */
        fun dispatch(buf: ByteArray, fill: Int, sinks: List<TsSink>, onResync: () -> Unit = {}): Int {
            var pos = 0
            while (fill - pos >= Ts.PACKET_SIZE) {
                val ok = (buf[pos].toInt() and 0xFF) == Ts.SYNC_BYTE &&
                    (fill - pos < Ts.PACKET_SIZE + 1 || (buf[pos + Ts.PACKET_SIZE].toInt() and 0xFF) == Ts.SYNC_BYTE)
                if (!ok) {
                    onResync()
                    pos++
                    continue
                }
                for (s in sinks) s.onPacket(buf, pos)
                pos += Ts.PACKET_SIZE
            }
            val rest = fill - pos
            if (rest > 0 && pos > 0) System.arraycopy(buf, pos, buf, 0, rest)
            return rest
        }
    }
}

/** MPEG-2 CRC-32 (poly 0x04C11DB7, init 0xFFFFFFFF, no reflection, no final xor). A valid section yields 0. */
object Crc32Mpeg {
    private val table = IntArray(256).also {
        for (i in 0 until 256) {
            var c = i shl 24
            for (j in 0 until 8) c = if (c and 0x80000000.toInt() != 0) (c shl 1) xor 0x04C11DB7 else c shl 1
            it[i] = c
        }
    }

    fun compute(data: ByteArray, off: Int = 0, len: Int = data.size - off): Int {
        var crc = -1
        for (i in off until off + len) {
            crc = (crc shl 8) xor table[((crc ushr 24) xor (data[i].toInt() and 0xFF)) and 0xFF]
        }
        return crc
    }
}

/** Rebuilds PSI/SI sections from the packets of ONE pid. Emits only sections with a valid CRC (long form). */
class SectionAssembler(private val onSection: (ByteArray) -> Unit) {
    private var buf = ByteArray(4096 + 188)
    private var len = 0
    private var lastCc = -1
    var crcErrors = 0L
        private set
    var discontinuities = 0L
        private set

    fun push(pkt: ByteArray, off: Int) {
        if (Ts.tei(pkt, off)) { reset(); return }
        val afc = Ts.adaptation(pkt, off)
        if (afc and 1 == 0) return // no payload
        val cc = Ts.continuity(pkt, off)
        if (lastCc >= 0) {
            if (cc == lastCc) return // duplicate packet
            if (cc != (lastCc + 1) and 0xF) { discontinuities++; reset() }
        }
        lastCc = cc
        var p = off + 4
        if (afc and 2 != 0) p += 1 + (pkt[off + 4].toInt() and 0xFF)
        val end = off + Ts.PACKET_SIZE
        if (p >= end) return

        if (Ts.pusi(pkt, off)) {
            val pointer = pkt[p].toInt() and 0xFF
            p++
            if (p + pointer > end) { reset(); return }
            if (len > 0) { append(pkt, p, pointer); drain() }
            reset()
            p += pointer
            append(pkt, p, end - p)
            drain()
        } else {
            if (len == 0) return
            append(pkt, p, end - p)
            drain()
        }
    }

    private fun reset() { len = 0 }

    private fun append(src: ByteArray, off: Int, n: Int) {
        if (n <= 0) return
        if (len + n > buf.size) { len = 0; return } // oversize, drop
        System.arraycopy(src, off, buf, len, n)
        len += n
    }

    private fun drain() {
        while (len >= 3) {
            if ((buf[0].toInt() and 0xFF) == 0xFF) { len = 0; return } // stuffing
            val sectionLen = 3 + (((buf[1].toInt() and 0x0F) shl 8) or (buf[2].toInt() and 0xFF))
            if (sectionLen > 4096) { len = 0; return }
            if (len < sectionLen) return
            val section = buf.copyOfRange(0, sectionLen)
            System.arraycopy(buf, sectionLen, buf, 0, len - sectionLen)
            len -= sectionLen
            val longForm = (section[1].toInt() and 0x80) != 0
            if (!longForm || Crc32Mpeg.compute(section) == 0) onSection(section) else crcErrors++
        }
    }
}

/** Per-PID statistics for the diagnostics screen. Thread-safe snapshots. */
class TsStats : TsSink {
    class PidInfo(val pid: Int) {
        var packets = 0L; var ccErrors = 0L; var scrambled = 0L; var tei = 0L
        internal var lastCc = -1
    }

    private val pids = HashMap<Int, PidInfo>()
    var totalPackets = 0L; private set
    private var startNs = System.nanoTime()

    @Synchronized
    override fun onPacket(buf: ByteArray, off: Int) {
        totalPackets++
        val pid = Ts.pid(buf, off)
        val info = pids.getOrPut(pid) { PidInfo(pid) }
        info.packets++
        if (Ts.tei(buf, off)) info.tei++
        if (Ts.scrambling(buf, off) > 1) info.scrambled++
        if (pid == Ts.PID_NULL) return
        val afc = Ts.adaptation(buf, off)
        if (afc and 1 != 0) { // CC only counts for packets with payload
            val cc = Ts.continuity(buf, off)
            if (info.lastCc >= 0 && cc != info.lastCc && cc != (info.lastCc + 1) and 0xF) info.ccErrors++
            info.lastCc = cc
        }
    }

    @Synchronized fun reset() { pids.clear(); totalPackets = 0; startNs = System.nanoTime() }

    @Synchronized
    fun snapshot(): List<PidInfo> = pids.values.map {
        PidInfo(it.pid).also { c -> c.packets = it.packets; c.ccErrors = it.ccErrors; c.scrambled = it.scrambled; c.tei = it.tei }
    }.sortedBy { it.pid }

    @Synchronized
    fun averageKbps(): Long {
        val s = (System.nanoTime() - startNs) / 1e9
        return if (s <= 0.0) 0 else (totalPackets * Ts.PACKET_SIZE * 8 / 1000 / s).toLong()
    }
}
