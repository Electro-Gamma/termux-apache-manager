package org.opendvb.receiver.tuner

import org.opendvb.receiver.driver.DeliverySystem
import org.opendvb.receiver.services.Channel
import org.opendvb.receiver.transport.Pmt
import org.opendvb.receiver.transport.PsiCollector
import org.opendvb.receiver.transport.Ts
import java.util.concurrent.atomic.AtomicBoolean

data class ScanProgress(val index: Int, val total: Int, val label: String, val frequencyHz: Long, val locked: Boolean, val found: Int)

/**
 * Blocking channel scan; run it on a worker thread. For every candidate frequency and every
 * delivery system the tuner reports (DVB-T2 first, then DVB-T) it waits for lock, collects PAT/SDT,
 * then the PMTs, and turns the result into [Channel]s. Nothing is assumed about which standard a
 * multiplex uses: a system is only tried if GET_CAPABILITIES lists it.
 */
class Scanner(private val session: DvbSession, private val cancel: AtomicBoolean) {
    var lockTimeoutMs = 2500L
    var tableTimeoutMs = 7000L
    var pmtTimeoutMs = 4000L

    /** Called (on the scan thread) with the services of each multiplex as soon as it has been scanned. */
    var onMultiplexFound: ((List<Channel>) -> Unit)? = null

    fun scan(candidates: List<Candidate>, progress: (ScanProgress) -> Unit): List<Channel> {
        val caps = session.capabilities ?: throw IllegalStateException("No tuner capabilities")
        val systems = listOf(DeliverySystem.DVBT2, DeliverySystem.DVBT).filter { it in caps.deliverySystems }
        if (systems.isEmpty()) throw IllegalStateException("Tuner supports neither DVB-T nor DVB-T2")

        val all = ArrayList<Channel>()
        for ((i, cand) in candidates.withIndex()) {
            if (cancel.get()) break
            var locked = false
            for (system in systems) {
                if (cancel.get()) break
                val params = TuneParams(cand.frequencyHz, cand.bandwidthHz, system)
                try {
                    session.tune(params, force = true)
                    if (!session.waitForLock(lockTimeoutMs) { cancel.get() }) continue
                } catch (e: java.io.IOException) {
                    // driver refused this frequency/bandwidth: try the next system / candidate
                    continue
                }
                locked = true
                var found = collect(params)
                if (found.isEmpty() && !cancel.get()) {
                    // locked but no clean tables (noisy reception): retune once and listen again before giving up
                    try { session.tune(params, force = true); session.waitForLock(lockTimeoutMs) { cancel.get() } } catch (_: java.io.IOException) {}
                    found = collect(params)
                }
                all.addAll(found)
                if (found.isNotEmpty()) {
                    onMultiplexFound?.invoke(found)
                    break
                }
            }
            progress(ScanProgress(i + 1, candidates.size, cand.label, cand.frequencyHz, locked, all.size))
        }
        return all
    }

    /** Waits for tables on the current multiplex. Public for the manual tune screen. */
    fun collect(params: TuneParams): List<Channel> {
        val collector = PsiCollector()
        session.sinks.add(collector)
        try {
            session.setPids(listOf(Ts.PID_PAT, Ts.PID_SDT, Ts.PID_NIT))
            val tEnd = System.currentTimeMillis() + tableTimeoutMs
            while (System.currentTimeMillis() < tEnd && !cancel.get()) {
                val pat = collector.pat; val sdt = collector.sdt
                if (pat != null && sdt != null && pat.transportStreamId == sdt.transportStreamId) break
                Thread.sleep(100)
            }
            val pat = collector.pat ?: return emptyList()
            val sdt = collector.sdt
            val programs = pat.programs
            if (programs.isEmpty()) return emptyList()

            session.setPids(listOf(Ts.PID_PAT, Ts.PID_SDT) + programs.map { it.pid })
            val pEnd = System.currentTimeMillis() + pmtTimeoutMs
            while (System.currentTimeMillis() < pEnd && !cancel.get()) {
                if (programs.all { collector.pmtByProgram.containsKey(it.programNumber) }) break
                Thread.sleep(100)
            }
            return build(params, collector, pat.transportStreamId, programs.map { it.programNumber to it.pid }, sdt)
        } finally {
            session.sinks.remove(collector)
        }
    }

    private fun build(
        params: TuneParams, collector: PsiCollector, tsId: Int, programs: List<Pair<Int, Int>>,
        sdt: org.opendvb.receiver.transport.Sdt?,
    ): List<Channel> {
        val out = ArrayList<Channel>()
        val services = sdt?.services?.associateBy { it.serviceId } ?: emptyMap()
        val onid = sdt?.originalNetworkId ?: 0
        for ((program, pmtPid) in programs) {
            val svc = services[program]
            val pmt: Pmt? = collector.pmtByProgram[program]
            val type = svc?.serviceType ?: -1
            // Without SDT info keep services that have video or audio; with SDT keep TV/radio service types.
            val listable = if (svc != null) Channel.isListable(type) else pmt != null
            if (!listable) continue
            out.add(
                Channel(
                    serviceId = program, transportStreamId = tsId, originalNetworkId = onid,
                    name = svc?.name ?: "", provider = svc?.provider ?: "", serviceType = type,
                    frequencyHz = params.frequencyHz, bandwidthHz = params.bandwidthHz, system = params.system,
                    pmtPid = pmtPid, pcrPid = pmt?.pcrPid ?: 0x1FFF, streams = pmt?.streams ?: emptyList(),
                    scrambled = svc?.scrambled ?: false,
                )
            )
        }
        return out
    }
}
