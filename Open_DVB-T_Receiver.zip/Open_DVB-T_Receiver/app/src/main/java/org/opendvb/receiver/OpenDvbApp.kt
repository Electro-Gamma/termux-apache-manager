package org.opendvb.receiver

import android.app.Application
import org.opendvb.receiver.epg.EpgStore
import org.opendvb.receiver.recording.TsRecorder
import org.opendvb.receiver.services.ChannelStore
import org.opendvb.receiver.transport.PsiCollector
import org.opendvb.receiver.transport.TsStats
import org.opendvb.receiver.tuner.DvbSession

/** Process-wide singletons: driver session, channel list, EPG, live statistics, recorder. */
class OpenDvbApp : Application() {
    val session = DvbSession()
    val stats = TsStats()
    val epg = EpgStore()
    val recorder by lazy { TsRecorder(session) }
    lateinit var channels: ChannelStore
        private set
    /** True while a scan or EPG collection owns the tuner; other screens should not retune. */
    @Volatile var tunerBusy = false

    override fun onCreate() {
        super.onCreate()
        instance = this
        channels = ChannelStore(this)
        session.sinks.add(stats)
        // Global EPG collector: runs only when EIT packets pass the driver's PID filter.
        session.sinks.add(PsiCollector(onEit = { eit ->
            val f = session.currentTune?.frequencyHz
            if (f != null && channels.load().any { it.frequencyHz == f && it.transportStreamId == eit.transportStreamId }) {
                epg.add(f, eit)
            }
        }))
    }

    companion object {
        lateinit var instance: OpenDvbApp
            private set
    }
}
