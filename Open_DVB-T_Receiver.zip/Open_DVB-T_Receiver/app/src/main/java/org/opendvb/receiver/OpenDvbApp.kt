package org.opendvb.receiver

import android.app.Application
import org.opendvb.receiver.epg.EpgStore
import org.opendvb.receiver.services.BackgroundService
import org.opendvb.receiver.recording.TsRecorder
import org.opendvb.receiver.services.ChannelStore
import org.opendvb.receiver.services.ChannelThumbnails
import org.opendvb.receiver.transport.PsiCollector
import org.opendvb.receiver.transport.TsStats
import org.opendvb.receiver.tuner.DvbSession

/** Process-wide singletons: driver session, channel list, EPG, live statistics, recorder. */
class OpenDvbApp : Application() {
    val session = DvbSession()
    val stats = TsStats()
    val epg = EpgStore()
    val recorder by lazy { TsRecorder(session) }
    lateinit var channels: ChannelStore
        private set
    /** Latest captured picture of each channel (shown in the channel list). */
    lateinit var previews: ChannelThumbnails
        private set
    /** The running live-TV playback. Owned by the app (not by the player screen) so it survives Home / app switching. */
    @Volatile var engine: org.opendvb.receiver.player.PlaybackEngine? = null
    @Volatile var playingChannel: org.opendvb.receiver.services.Channel? = null

    /** Stops playback (and releases libVLC); the background service ends if nothing else is running. Main thread. */
    fun stopPlayback() {
        engine?.release()
        engine = null
        playingChannel = null
        BackgroundService.sync(this)
    }

    /** Everything the background service keeps alive: playback, a recording, a scan. */
    fun backgroundActive(): Boolean = engine != null || recorder.isRecording || tunerBusy

    /** Stop button of the notification. */
    fun stopEverything() {
        if (recorder.isRecording) try { recorder.stop() } catch (_: Exception) {}
        stopPlayback()
    }

    /** True while a scan or EPG collection owns the tuner; other screens should not retune. */
    @Volatile var tunerBusy = false

    override fun onCreate() {
        super.onCreate()
        instance = this
        channels = ChannelStore(this)
        previews = ChannelThumbnails(this)
        info.martinmarinov.drivers.TunerOptions.fc0012Gain = getSharedPreferences("settings", MODE_PRIVATE).getInt("fc0012_gain", 1)
        session.sinks.add(stats)
        session.addListener(object : DvbSession.Listener {
            override fun onSessionChanged(session: DvbSession) {
                // The tuner went away while playing in the background: nothing left to play.
                if (session.state == org.opendvb.receiver.tuner.SessionState.DISCONNECTED && engine != null && playingChannel != null) stopPlayback()
                else BackgroundService.sync(this@OpenDvbApp)
            }
        })
        // Global EPG collector: runs only when EIT packets pass the driver's PID filter.
        session.sinks.add(PsiCollector(onEit = { eit ->
            val f = session.currentTune?.frequencyHz
            if (f != null && channels.load().any { it.frequencyHz == f && it.transportStreamId == eit.transportStreamId }) {
                epg.add(f, eit)
            }
        }))
    }

    companion object {
        lateinit var instance: OpenDvbApp
            private set
    }
}
