package org.opendvb.receiver.transport

import java.nio.charset.Charset

enum class EsKind { VIDEO, AUDIO, SUBTITLE, TELETEXT, DATA }

data class EsInfo(val streamType: Int, val pid: Int, val kind: EsKind, val codec: String, val language: String?)
data class PatEntry(val programNumber: Int, val pid: Int)
data class Pat(val transportStreamId: Int, val version: Int, val entries: List<PatEntry>) {
    val programs: List<PatEntry> get() = entries.filter { it.programNumber != 0 }
    val nitPid: Int? get() = entries.firstOrNull { it.programNumber == 0 }?.pid
}
data class Pmt(val programNumber: Int, val pcrPid: Int, val streams: List<EsInfo>)
data class SdtService(
    val serviceId: Int, val name: String, val provider: String, val serviceType: Int,
    val runningStatus: Int, val scrambled: Boolean, val hasEitSchedule: Boolean, val hasEitPf: Boolean,
)
data class Sdt(val transportStreamId: Int, val originalNetworkId: Int, val services: List<SdtService>)
data class NitTs(val transportStreamId: Int, val originalNetworkId: Int)
data class Nit(val networkId: Int, val networkName: String?, val transportStreams: List<NitTs>)
data class EpgEvent(
    val serviceId: Int, val eventId: Int, val startUtcMs: Long, val durationSec: Int,
    val title: String, val text: String, val runningStatus: Int,
) {
    val endUtcMs: Long get() = startUtcMs + durationSec * 1000L
}
data class Eit(val serviceId: Int, val transportStreamId: Int, val tableId: Int, val events: List<EpgEvent>)

/** Parsers for already CRC-checked sections (ISO/IEC 13818-1, ETSI EN 300 468). All return null on malformed input. */
object Psi {
    private fun u8(b: ByteArray, o: Int) = b[o].toInt() and 0xFF
    private fun u16(b: ByteArray, o: Int) = (u8(b, o) shl 8) or u8(b, o + 1)
    private fun bcd(v: Int) = ((v shr 4) and 0xF) * 10 + (v and 0xF)

    /** Bytes of the table payload (after the 8-byte long header, before the 4-byte CRC). */
    private fun bodyRange(s: ByteArray): IntRange? = if (s.size >= 12) 8 until (s.size - 4) else null

    fun tableId(s: ByteArray) = u8(s, 0)

    fun parsePat(s: ByteArray): Pat? = try {
        if (tableId(s) != 0x00) null else {
            val r = bodyRange(s)!!
            val list = ArrayList<PatEntry>()
            var p = r.first
            while (p + 4 <= r.last + 1) {
                list.add(PatEntry(u16(s, p), u16(s, p + 2) and 0x1FFF))
                p += 4
            }
            Pat(u16(s, 3), (u8(s, 5) shr 1) and 0x1F, list)
        }
    } catch (e: Exception) { null }

    fun streamKind(streamType: Int, descriptors: List<Pair<Int, ByteArray>>): Pair<EsKind, String> {
        when (streamType) {
            0x01 -> return EsKind.VIDEO to "MPEG-1 video"
            0x02 -> return EsKind.VIDEO to "MPEG-2 video"
            0x1B -> return EsKind.VIDEO to "H.264/AVC"
            0x24 -> return EsKind.VIDEO to "HEVC"
            0x03, 0x04 -> return EsKind.AUDIO to "MPEG audio"
            0x0F -> return EsKind.AUDIO to "AAC (ADTS)"
            0x11 -> return EsKind.AUDIO to "AAC (LATM)"
            0x81 -> return EsKind.AUDIO to "AC-3"
        }
        for ((tag, _) in descriptors) when (tag) {
            0x6A -> return EsKind.AUDIO to "AC-3"
            0x7A -> return EsKind.AUDIO to "E-AC-3"
            0x7C -> return EsKind.AUDIO to "AAC"
            0x56 -> return EsKind.TELETEXT to "Teletext"
            0x59 -> return EsKind.SUBTITLE to "DVB subtitles"
        }
        return EsKind.DATA to "type 0x%02X".format(streamType)
    }

    fun parseDescriptors(s: ByteArray, from: Int, to: Int): List<Pair<Int, ByteArray>> {
        val out = ArrayList<Pair<Int, ByteArray>>()
        var p = from
        while (p + 2 <= to) {
            val tag = u8(s, p)
            val len = u8(s, p + 1)
            if (p + 2 + len > to) break
            out.add(tag to s.copyOfRange(p + 2, p + 2 + len))
            p += 2 + len
        }
        return out
    }

    fun parsePmt(s: ByteArray): Pmt? = try {
        if (tableId(s) != 0x02 || s.size < 16) null else {
            val program = u16(s, 3)
            val pcr = u16(s, 8) and 0x1FFF
            val progInfoLen = u16(s, 10) and 0x0FFF
            var p = 12 + progInfoLen
            val end = s.size - 4
            val streams = ArrayList<EsInfo>()
            while (p + 5 <= end) {
                val type = u8(s, p)
                val pid = u16(s, p + 1) and 0x1FFF
                val esLen = u16(s, p + 3) and 0x0FFF
                val d = parseDescriptors(s, p + 5, minOf(p + 5 + esLen, end))
                val (kind, codec) = streamKind(type, d)
                val lang = d.firstOrNull { it.first == 0x0A && it.second.size >= 3 }
                    ?.let { String(it.second, 0, 3, Charsets.ISO_8859_1) }
                streams.add(EsInfo(type, pid, kind, codec, lang))
                p += 5 + esLen
            }
            Pmt(program, pcr, streams)
        }
    } catch (e: Exception) { null }

    fun parseSdt(s: ByteArray): Sdt? = try {
        if (tableId(s) != 0x42) null else { // actual transport stream only
            val tsId = u16(s, 3)
            val onid = u16(s, 8)
            val services = ArrayList<SdtService>()
            var p = 11
            val end = s.size - 4
            while (p + 5 <= end) {
                val sid = u16(s, p)
                val eitSchedule = u8(s, p + 2) and 0x02 != 0
                val eitPf = u8(s, p + 2) and 0x01 != 0
                val running = (u8(s, p + 3) shr 5) and 0x7
                val freeCa = u8(s, p + 3) and 0x10 != 0
                val dLen = u16(s, p + 3) and 0x0FFF
                var name = ""; var provider = ""; var type = -1
                for ((tag, d) in parseDescriptors(s, p + 5, minOf(p + 5 + dLen, end))) {
                    if (tag == 0x48 && d.size >= 3) {
                        type = u8(d, 0)
                        val pl = u8(d, 1)
                        if (2 + pl + 1 <= d.size) {
                            provider = DvbText.decode(d, 2, pl)
                            val nl = u8(d, 2 + pl)
                            if (3 + pl + nl <= d.size) name = DvbText.decode(d, 3 + pl, nl)
                        }
                    }
                }
                services.add(SdtService(sid, name, provider, type, running, freeCa, eitSchedule, eitPf))
                p += 5 + dLen
            }
            Sdt(tsId, onid, services)
        }
    } catch (e: Exception) { null }

    fun parseNit(s: ByteArray): Nit? = try {
        if (tableId(s) != 0x40) null else { // actual network
            val networkId = u16(s, 3)
            val netDescLen = u16(s, 8) and 0x0FFF
            val name = parseDescriptors(s, 10, 10 + netDescLen).firstOrNull { it.first == 0x40 }
                ?.let { DvbText.decode(it.second, 0, it.second.size) }
            var p = 10 + netDescLen
            val tsLoopLen = u16(s, p) and 0x0FFF
            p += 2
            val end = minOf(p + tsLoopLen, s.size - 4)
            val list = ArrayList<NitTs>()
            while (p + 6 <= end) {
                list.add(NitTs(u16(s, p), u16(s, p + 2)))
                p += 6 + (u16(s, p + 4) and 0x0FFF)
            }
            Nit(networkId, name, list)
        }
    } catch (e: Exception) { null }

    /** MJD + BCD UTC time (EN 300 468 annex C) to epoch millis; null for the "undefined" value. */
    fun decodeStartTime(s: ByteArray, o: Int): Long? {
        if (u8(s, o) == 0xFF && u8(s, o + 1) == 0xFF && u8(s, o + 2) == 0xFF) return null
        val mjd = u16(s, o)
        val h = bcd(u8(s, o + 2)); val m = bcd(u8(s, o + 3)); val sec = bcd(u8(s, o + 4))
        return ((mjd - 40587L) * 86400L + h * 3600L + m * 60L + sec) * 1000L
    }

    fun parseEit(s: ByteArray): Eit? = try {
        val id = tableId(s)
        if (!(id == 0x4E || id in 0x50..0x5F) || s.size < 18) null else { // actual TS only
            val serviceId = u16(s, 3)
            val tsId = u16(s, 8)
            var p = 14
            val end = s.size - 4
            val events = ArrayList<EpgEvent>()
            while (p + 12 <= end) {
                val eventId = u16(s, p)
                val start = decodeStartTime(s, p + 2)
                val dur = bcd(u8(s, p + 7)) * 3600 + bcd(u8(s, p + 8)) * 60 + bcd(u8(s, p + 9))
                val running = (u8(s, p + 10) shr 5) and 0x7
                val dLen = u16(s, p + 10) and 0x0FFF
                var title = ""; var text = ""
                for ((tag, d) in parseDescriptors(s, p + 12, minOf(p + 12 + dLen, end))) {
                    if (tag == 0x4D && d.size >= 5) { // short_event_descriptor
                        val nl = u8(d, 3)
                        if (4 + nl < d.size) {
                            title = DvbText.decode(d, 4, nl)
                            val tl = u8(d, 4 + nl)
                            if (5 + nl + tl <= d.size) text = DvbText.decode(d, 5 + nl, tl)
                        }
                    }
                }
                if (start != null) events.add(EpgEvent(serviceId, eventId, start, dur, title, text, running))
                p += 12 + dLen
            }
            Eit(serviceId, tsId, id, events)
        }
    } catch (e: Exception) { null }
}

/** DVB text (EN 300 468 annex A). ISO 6937 default table is approximated with ISO-8859-1. */
object DvbText {
    private fun charsetOf(name: String): Charset =
        try { Charset.forName(name) } catch (e: Exception) { Charsets.ISO_8859_1 }

    fun decode(b: ByteArray, off: Int, len: Int): String {
        if (len <= 0) return ""
        var start = off
        var chosen: Charset = Charsets.ISO_8859_1
        val first = b[off].toInt() and 0xFF
        if (first < 0x20) {
            when (first) {
                0x01 -> chosen = charsetOf("ISO-8859-5")
                0x02 -> chosen = charsetOf("ISO-8859-6")
                0x03 -> chosen = charsetOf("ISO-8859-7")
                0x04 -> chosen = charsetOf("ISO-8859-8")
                0x05 -> chosen = charsetOf("ISO-8859-9")
                0x06 -> chosen = charsetOf("ISO-8859-10")
                0x07 -> chosen = charsetOf("ISO-8859-11")
                0x09 -> chosen = charsetOf("ISO-8859-13")
                0x0A -> chosen = charsetOf("ISO-8859-14")
                0x0B -> chosen = charsetOf("ISO-8859-15")
                0x11 -> chosen = Charsets.UTF_16BE
                0x15 -> chosen = Charsets.UTF_8
                0x10 -> if (len >= 3) {
                    val n = ((b[off + 1].toInt() and 0xFF) shl 8) or (b[off + 2].toInt() and 0xFF)
                    chosen = charsetOf("ISO-8859-$n")
                    start = off + 2
                }
                else -> {}
            }
            start++
        }
        val raw = String(b, start, len - (start - off), chosen)
        val out = StringBuilder()
        for (ch in raw) {
            if (ch == '\u008A' || ch == '\uE08A') out.append('\n')
            else if (ch in '\u0080'..'\u009F' || ch in '\uE080'..'\uE09F') continue
            else out.append(ch)
        }
        return out.toString().trim()
    }
}
