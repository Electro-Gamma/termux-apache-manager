package org.opendvb.receiver.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.widget.ImageViewCompat
import androidx.core.widget.TextViewCompat
import androidx.recyclerview.widget.RecyclerView
import org.opendvb.receiver.R
import org.opendvb.receiver.services.Channel
import org.opendvb.receiver.services.ChannelThumbnails

/**
 * The scanned channels, drawn exactly like the connections on the VNC tab's home screen:
 *  - list view: rows of one run share a group (16 dp corners at the ends, 4 dp between, 2 dp gap, 1 dp outline), 76 x 64 dp preview
 *    on the left, title, subtitle and badges on the right;
 *  - grid view: outlined cards, preview band (0.72 of the width) with badges over it, title and subtitle below.
 * Pressing plays the channel; holding toggles the favourite (pinned channels are listed first, shown with a pin).
 */
internal class ChannelListAdapter(
    private val previews: ChannelThumbnails,
    private val nowTitle: (Channel) -> String?,
    private val onClick: (Channel) -> Unit,
    private val onLongClick: (Channel) -> Unit,
) : RecyclerView.Adapter<ChannelListAdapter.Holder>() {

    private var items: List<Channel> = emptyList()
    private var listView = true
    private var span = 1

    fun submit(channels: List<Channel>, asList: Boolean, columns: Int) {
        items = channels
        listView = asList
        span = columns
        notifyDataSetChanged()
    }

    class Holder(view: View) : RecyclerView.ViewHolder(view) {
        var key: String = ""
        val thumbBox: View = view.findViewById(R.id.thumbBox)
        val thumb: ImageView = view.findViewById(R.id.thumb)
        val placeholder: ImageView = view.findViewById(R.id.placeholder)
        val title: TextView = view.findViewById(R.id.title)
        val subtitle: TextView = view.findViewById(R.id.subtitle)
        val now: TextView = view.findViewById(R.id.now)
        val badges: LinearLayout = view.findViewById(R.id.badges)
        val typeBadge: TextView? = view.findViewById(R.id.typeBadge)   // card only
        val pin: ImageView? = view.findViewById(R.id.pin)               // card only
    }

    override fun getItemViewType(position: Int) = if (listView) VIEW_ROW else VIEW_CARD

    override fun getItemCount() = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val ctx = parent.context
        val inflater = LayoutInflater.from(ctx)
        val h = if (viewType == VIEW_ROW) {
            Holder(inflater.inflate(R.layout.item_channel_row, parent, false)).also { it.thumbBox.roundClip(8) }
        } else {
            Holder(inflater.inflate(R.layout.item_channel_card, parent, false)).also { it.itemView.roundClip(16) }
        }
        h.itemView.setOnClickListener {
            val p = h.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) onClick(items[p])
        }
        h.itemView.setOnLongClickListener {
            val p = h.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) onLongClick(items[p])
            true
        }
        return h
    }

    override fun onBindViewHolder(h: Holder, position: Int) {
        val ctx = h.itemView.context
        val c = items[position]
        h.key = c.key

        // Place in the group, margins and outlined background: the same rules as the VNC list.
        val lp = h.itemView.layoutParams as ViewGroup.MarginLayoutParams
        if (listView) {
            val last = items.size - 1
            val first = position < span
            val atBottom = position >= last - last % span
            h.itemView.background = ctx.groupedBackground(if (first) 16 else 4, if (atBottom) 16 else 4)
            lp.setMargins(ctx.dp(16), 0, ctx.dp(16), if (atBottom) 0 else ctx.dp(2))
        } else {
            h.itemView.background = ctx.groupedBackground(16, 16)
            lp.setMargins(ctx.dp(8), ctx.dp(8), ctx.dp(8), ctx.dp(8))
        }
        h.itemView.layoutParams = lp

        h.title.text = c.displayName
        h.subtitle.text = "%.1f MHz · %s · %s".format(c.frequencyMhz, c.videoSummary(), c.audioSummary())
        val now = nowTitle(c)
        h.now.text = if (now != null) "Now: $now" else ""
        h.now.visibility = if (now != null) View.VISIBLE else View.GONE

        // Badges: the delivery system (over the picture on a card, with the others on a row), then radio / encrypted.
        h.badges.removeAllViews()
        val surfaceBadgeBg = ctx.color(R.color.md_surface_variant)
        val surfaceBadgeFg = ctx.color(R.color.md_on_surface_variant)
        if (listView) {
            if (c.favorite) h.badges.addView(pinIcon(ctx, ctx.color(R.color.md_on_surface_variant), 14), spaced(ctx, 0, 6))
            h.badges.addView(badge(ctx, c.system.name, surfaceBadgeBg, surfaceBadgeFg), spaced(ctx, 0, 0))
        } else {
            h.typeBadge?.let { styleBadge(it, c.system.name, BADGE_SCRIM, ON_SCRIM) }
            h.pin?.let { pin ->
                pin.visibility = if (c.favorite) View.VISIBLE else View.GONE
                pin.setColorFilter(ON_SCRIM)
                pin.background = GradientDrawable().apply { setColor(BADGE_SCRIM); cornerRadius = ctx.dp(6).toFloat() }
            }
        }
        fun extra(text: String, bg: Int, fg: Int) {
            h.badges.addView(badge(ctx, text, bg, fg), spaced(ctx, if (h.badges.childCount > 0) 6 else 0, 0))
        }
        if (c.isRadio) extra("Radio", ctx.color(R.color.md_secondary_container), ctx.color(R.color.md_on_secondary_container))
        if (c.scrambled) extra("Encrypted", ctx.color(R.color.md_error_container), ctx.color(R.color.md_on_error_container))
        h.badges.visibility = if (h.badges.childCount > 0) View.VISIBLE else View.GONE

        // Preview picture: from memory at once if possible (no flicker), otherwise read off the main thread.
        val cached = previews.cached(c.key)
        showPicture(h, cached)
        if (cached == null) {
            val key = c.key
            previews.load(key) { bmp -> if (h.key == key) showPicture(h, bmp) }
        }
    }

    private fun showPicture(h: Holder, bmp: Bitmap?) {
        if (bmp != null) {
            h.thumb.setImageBitmap(bmp)
            h.placeholder.visibility = View.GONE
        } else {
            h.thumb.setImageDrawable(null)
            h.placeholder.visibility = View.VISIBLE
        }
    }

    private fun spaced(ctx: Context, startDp: Int, endDp: Int) =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            marginStart = ctx.dp(startDp); marginEnd = ctx.dp(endDp)
        }

    private fun pinIcon(ctx: Context, tint: Int, sizeDp: Int) = ImageView(ctx).apply {
        setImageResource(R.drawable.ic_pin)
        ImageViewCompat.setImageTintList(this, android.content.res.ColorStateList.valueOf(tint))
        layoutParams = LinearLayout.LayoutParams(ctx.dp(sizeDp), ctx.dp(sizeDp))
        contentDescription = "Favourite"
    }

    private fun badge(ctx: Context, text: String, bg: Int, fg: Int) = TextView(ctx).also { styleBadge(it, text, bg, fg) }

    private fun styleBadge(v: TextView, text: String, bg: Int, fg: Int) {
        val ctx = v.context
        TextViewCompat.setTextAppearance(v, com.google.android.material.R.style.TextAppearance_Material3_LabelSmall)
        v.text = text
        v.setTextColor(fg)
        v.setPadding(ctx.dp(6), ctx.dp(2), ctx.dp(6), ctx.dp(2))
        v.background = GradientDrawable().apply { setColor(bg); cornerRadius = ctx.dp(6).toFloat() }
    }

    companion object {
        private const val VIEW_ROW = 0
        private const val VIEW_CARD = 1
        private val BADGE_SCRIM = Color.argb(0x99, 0, 0, 0)
        private val ON_SCRIM = Color.argb(0xE8, 0xFF, 0xFF, 0xFF)
    }
}
