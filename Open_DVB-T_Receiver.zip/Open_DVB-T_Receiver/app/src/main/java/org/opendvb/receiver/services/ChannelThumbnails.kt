package org.opendvb.receiver.services

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import java.io.File
import java.util.concurrent.Executors

/**
 * The picture shown on a channel in the list: the last frame captured while the channel was playing.
 *
 * Same idea as the preview on a VNC connection: one small picture per item, written when it is captured, kept on disk, and read
 * back off the main thread. It is stored per channel key (frequency + service id, see [Channel.key]), so it stays with its channel
 * across screens, restarts and rescans. Only "Delete channel list" removes it.
 *
 * One thread does all the disk work, so a read queued behind a write sees it and two writes never touch the same file at once.
 */
class ChannelThumbnails(context: Context) {
    private val dir = File(context.applicationContext.filesDir, "channel_previews")
    private val io = Executors.newSingleThreadExecutor { r -> Thread(r, "channel-previews").apply { isDaemon = true } }
    private val main = Handler(Looper.getMainLooper())
    private val cache = object : LruCache<String, Bitmap>(CACHE_ENTRIES) {}

    private fun file(key: String) = File(dir, key.map { if (it.isLetterOrDigit()) it else '_' }.joinToString("") + ".jpg")

    /** The picture if it is already in memory (no disk access, safe on the main thread). */
    fun cached(key: String): Bitmap? = cache.get(key)

    /** Calls [done] on the main thread with the picture, or null when this channel has none yet. */
    fun load(key: String, done: (Bitmap?) -> Unit) {
        cache.get(key)?.let { done(it); return }
        io.execute {
            val bmp = try {
                val f = file(key)
                if (f.isFile) BitmapFactory.decodeFile(f.path) else null
            } catch (_: Exception) { null } catch (_: OutOfMemoryError) { null }
            if (bmp != null) cache.put(key, bmp)
            main.post { done(bmp) }
        }
    }

    /** Keeps [frame] as the latest picture of [key]. [frame] is scaled down first; the caller keeps ownership of it. */
    fun save(key: String, frame: Bitmap) {
        if (frame.isRecycled || frame.width <= 0 || frame.height <= 0) return
        val small = try { scaled(frame) } catch (_: Exception) { return } catch (_: OutOfMemoryError) { return }
        cache.put(key, small)
        io.execute {
            try {
                if (!dir.isDirectory) dir.mkdirs()
                val target = file(key)
                val tmp = File(dir, target.name + ".tmp")
                tmp.outputStream().use { small.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, it) }
                if (!tmp.renameTo(target)) { target.delete(); tmp.renameTo(target) }
            } catch (_: Exception) {
            }
        }
    }

    /** Forgets every picture (used together with "Delete channel list"). */
    fun clear() {
        cache.evictAll()
        io.execute { try { dir.listFiles()?.forEach { it.delete() } } catch (_: Exception) {} }
    }

    private fun scaled(src: Bitmap): Bitmap {
        val scale = MAX_SIDE.toFloat() / maxOf(src.width, src.height)
        if (scale >= 1f) return src.copy(Bitmap.Config.ARGB_8888, false)
        return Bitmap.createScaledBitmap(src, maxOf(1, Math.round(src.width * scale)), maxOf(1, Math.round(src.height * scale)), true)
    }

    companion object {
        private const val MAX_SIDE = 640
        private const val JPEG_QUALITY = 85
        private const val CACHE_ENTRIES = 48

        /** True when the frame has nothing in it but black (a surface that was just created or just released). */
        fun isBlank(bmp: Bitmap): Boolean {
            val steps = 12
            for (yi in 0 until steps) for (xi in 0 until steps) {
                val p = bmp.getPixel((bmp.width - 1) * xi / (steps - 1), (bmp.height - 1) * yi / (steps - 1))
                val luma = (((p shr 16) and 0xFF) * 3 + ((p shr 8) and 0xFF) * 6 + (p and 0xFF)) / 10
                if (luma > 14) return false
            }
            return true
        }
    }
}
