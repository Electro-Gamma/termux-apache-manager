package org.opendvb.receiver.driver

import java.io.Closeable
import java.io.InputStream
import java.io.OutputStream
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

/** Synchronous client for the driver's control connection. Thread-safe (one request at a time). */
class DriverClient(private val input: InputStream, private val output: OutputStream) : Closeable {
    private val lock = ReentrantLock()

    private fun call(ordinal: Int, vararg payload: Long): LongArray = lock.withLock {
        output.write(DriverCodec.encodeRequest(ordinal, *payload))
        output.flush()
        DriverCodec.readResponse(input, ordinal)
    }

    /** @return Pair(protocol version, number of commands the driver knows) */
    fun protocolVersion(): Pair<Long, Long> {
        val p = call(Req.PROTOCOL_VERSION)
        if (p.size < 2) throw DriverException("Short PROTOCOL_VERSION response")
        return p[0] to p[1]
    }

    fun tune(frequencyHz: Long, bandwidthHz: Long, system: DeliverySystem) {
        call(Req.TUNE, frequencyHz, bandwidthHz, system.ordinal.toLong())
    }

    fun status(): SignalStatus {
        val p = call(Req.GET_STATUS)
        if (p.size < 8) throw DriverException("Short GET_STATUS response")
        return SignalStatus(p[0], p[1], p[2], p[3], p[4] == 1L, p[5] == 1L, p[6] == 1L, p[7] == 1L)
    }

    fun setPids(pids: IntArray) {
        call(Req.SET_PIDS, *LongArray(pids.size) { pids[it].toLong() })
    }

    fun capabilities(): Capabilities {
        val p = call(Req.GET_CAPABILITIES)
        if (p.size < 6) throw DriverException("Short GET_CAPABILITIES response")
        val systems = DeliverySystem.values().filter { (p[0] shr it.ordinal) and 1L != 0L }.toSet()
        return Capabilities(systems, p[1], p[2], p[3], p[4].toInt(), p[5].toInt())
    }

    /** Asks the driver to close the session. The driver closes the sockets afterwards. */
    fun exit() {
        try { call(Req.EXIT) } catch (_: Exception) { /* driver may close first */ }
    }

    override fun close() {
        try { input.close() } catch (_: Exception) {}
        try { output.close() } catch (_: Exception) {}
    }
}
