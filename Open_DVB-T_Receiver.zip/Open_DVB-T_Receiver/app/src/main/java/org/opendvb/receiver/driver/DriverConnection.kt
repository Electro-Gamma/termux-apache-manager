package org.opendvb.receiver.driver

import java.io.Closeable
import java.io.InputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket

/** The two loopback TCP connections to the driver: control (commands) and transfer (raw MPEG-TS). */
class DriverConnection private constructor(
    val client: DriverClient,
    val transportStream: InputStream,
    private val control: Socket,
    private val transfer: Socket,
) : Closeable {

    override fun close() {
        client.exit()
        client.close()
        try { transfer.close() } catch (_: Exception) {}
        try { control.close() } catch (_: Exception) {}
    }

    companion object {
        /** Control socket timeout used by the driver and by Aerial TV (60 s). */
        private const val CONTROL_TIMEOUT_MS = 60_000

        fun open(controlPort: Int, transferPort: Int, host: InetAddress = InetAddress.getByName("127.0.0.1")): DriverConnection {
            val transfer = Socket()
            val control = Socket()
            try {
                transfer.tcpNoDelay = true
                transfer.connect(InetSocketAddress(host, transferPort), 10_000)
                control.tcpNoDelay = true
                control.connect(InetSocketAddress(host, controlPort), 10_000)
                control.soTimeout = CONTROL_TIMEOUT_MS
                val client = DriverClient(control.getInputStream(), control.getOutputStream())
                return DriverConnection(client, transfer.getInputStream(), control, transfer)
            } catch (e: Exception) {
                try { transfer.close() } catch (_: Exception) {}
                try { control.close() } catch (_: Exception) {}
                throw e
            }
        }
    }
}
