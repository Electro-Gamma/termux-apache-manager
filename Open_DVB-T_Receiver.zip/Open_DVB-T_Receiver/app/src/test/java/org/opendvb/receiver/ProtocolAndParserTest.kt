package org.opendvb.receiver

import org.junit.Assert.*
import org.junit.Test
import org.opendvb.receiver.driver.*
import org.opendvb.receiver.transport.*
import java.io.ByteArrayInputStream
import java.io.PipedInputStream
import java.io.PipedOutputStream
import java.net.ServerSocket
import java.net.Socket

class DriverCodecTest {
    @Test fun requestLayoutMatchesDriver() {
        val b = DriverCodec.encodeRequest(Req.TUNE, 538_000_000L, 8_000_000L, 1L)
        assertEquals(2 + 24, b.size)
        assertEquals(2, b[0].toInt()); assertEquals(3, b[1].toInt())
        assertEquals(538_000_000L, DriverCodec.readLong(b, 2))
        assertEquals(1L, DriverCodec.readLong(b, 18))
    }

    @Test fun deliverySystemOrderIsWireCompatible() {
        assertEquals(0, DeliverySystem.DVBT.ordinal); assertEquals(1, DeliverySystem.DVBT2.ordinal); assertEquals(2, DeliverySystem.DVBC.ordinal)
    }

    private fun response(ordinal: Int, ok: Boolean, vararg p: Long): ByteArray {
        val b = ByteArray(2 + 8 + p.size * 8)
        b[0] = ordinal.toByte(); b[1] = (p.size + 1).toByte()
        DriverCodec.writeLong(b, 2, if (ok) 1 else 0)
        for (i in p.indices) DriverCodec.writeLong(b, 10 + i * 8, p[i])
        return b
    }

    @Test fun parsesSuccessAndRejectsFailureAndMismatch() {
        assertArrayEquals(longArrayOf(0, 6), DriverCodec.readResponse(ByteArrayInputStream(response(0, true, 0, 6)), 0))
        try { DriverCodec.readResponse(ByteArrayInputStream(response(2, false)), 2); fail() } catch (e: DriverException) {}
        try { DriverCodec.readResponse(ByteArrayInputStream(response(3, true)), 2); fail() } catch (e: DriverException) {}
        try { DriverCodec.readResponse(ByteArrayInputStream(byteArrayOf(2, 1, 0)), 2); fail() } catch (e: DriverException) {}
    }

    @Test fun negativeNumbersRoundTrip() {
        val b = ByteArray(8); DriverCodec.writeLong(b, 0, -12345L)
        assertEquals(-12345L, DriverCodec.readLong(b, 0))
    }
}

/** Integration test: DriverClient against a fake driver implementing the protocol from the driver source. */
class FakeDriverIntegrationTest {
    private fun serve(server: ServerSocket, handler: (Int, LongArray) -> LongArray?) = Thread {
        server.accept().use { s ->
            val i = s.getInputStream(); val o = s.getOutputStream()
            while (true) {
                val head = ByteArray(2)
                try { DriverCodec.readFully(i, head, 2) } catch (e: Exception) { break }
                val ord = head[0].toInt() and 0xFF; val n = head[1].toInt() and 0xFF
                val body = ByteArray(n * 8); DriverCodec.readFully(i, body, body.size)
                val payload = LongArray(n) { DriverCodec.readLong(body, it * 8) }
                val r = handler(ord, payload)
                val out = ByteArray(10 + (r?.size ?: 0) * 8)
                out[0] = ord.toByte(); out[1] = ((r?.size ?: 0) + 1).toByte()
                DriverCodec.writeLong(out, 2, if (r != null) 1 else 0)
                r?.forEachIndexed { k, v -> DriverCodec.writeLong(out, 10 + k * 8, v) }
                o.write(out); o.flush()
                if (ord == Req.EXIT) break
            }
        }
    }.also { it.isDaemon = true; it.start() }

    @Test fun clientTalksToFakeDriver() {
        val tuned = ArrayList<List<Long>>(); var pids: List<Long> = emptyList()
        val server = ServerSocket(0, 1, java.net.InetAddress.getByName("127.0.0.1"))
        serve(server) { ord, p ->
            when (ord) {
                Req.PROTOCOL_VERSION -> longArrayOf(0, 6)
                Req.TUNE -> { tuned.add(p.toList()); longArrayOf() }
                Req.GET_STATUS -> longArrayOf(30, 5, 0, 77, 1, 1, 1, 1)
                Req.SET_PIDS -> { pids = p.toList(); longArrayOf() }
                Req.GET_CAPABILITIES -> longArrayOf(3, 44_000_000, 1_002_000_000, 166_667, 0x0bda, 0x2838)
                Req.EXIT -> longArrayOf()
                else -> null
            }
        }
        val sock = Socket("127.0.0.1", server.localPort)
        val c = DriverClient(sock.getInputStream(), sock.getOutputStream())
        assertEquals(0L to 6L, c.protocolVersion())
        val caps = c.capabilities()
        assertEquals(setOf(DeliverySystem.DVBT, DeliverySystem.DVBT2), caps.deliverySystems)
        assertEquals(0x2838, caps.productId)
        c.tune(538_000_000, 8_000_000, DeliverySystem.DVBT2)
        assertEquals(listOf(538_000_000L, 8_000_000L, 1L), tuned[0])
        val st = c.status(); assertTrue(st.hasLock); assertEquals(77, st.rfStrengthPercent.toInt())
        c.setPids(intArrayOf(0, 0x11, 0x12)); assertEquals(listOf(0L, 17L, 18L), pids)
        c.exit(); sock.close(); server.close()
    }

    @Test fun driverFailureBecomesException() {
        val server = ServerSocket(0, 1, java.net.InetAddress.getByName("127.0.0.1"))
        serve(server) { _, _ -> null }
        val sock = Socket("127.0.0.1", server.localPort)
        val c = DriverClient(sock.getInputStream(), sock.getOutputStream())
        try { c.tune(1, 2, DeliverySystem.DVBT); fail() } catch (e: DriverException) {}
        sock.close(); server.close()
    }
}

class TransportTest {
    private fun feed(a: SectionAssembler, packets: List<ByteArray>) = packets.forEach { a.push(it, 0) }

    @Test fun crcOfValidSectionIsZero() {
        assertEquals(0, Crc32Mpeg.compute(TestSupport.pat(1, listOf(1 to 0x100))))
    }

    @Test fun patPmtSdtParse() {
        val pat = Psi.parsePat(TestSupport.pat(0x2001, listOf(0 to 0x10, 1 to 0x100, 2 to 0x200)))!!
        assertEquals(0x2001, pat.transportStreamId)
        assertEquals(listOf(1, 2), pat.programs.map { it.programNumber })
        assertEquals(0x100, pat.programs[0].pid); assertEquals(0x10, pat.nitPid)

        val lang = byteArrayOf(0x0A, 4, 'e'.code.toByte(), 'n'.code.toByte(), 'g'.code.toByte(), 0)
        val pmt = Psi.parsePmt(TestSupport.pmt(1, 0x101, listOf(
            Triple(0x1B, 0x101, ByteArray(0)), Triple(0x0F, 0x102, lang), Triple(0x06, 0x103, byteArrayOf(0x59, 0)), Triple(0x24, 0x104, ByteArray(0)))))!!
        assertEquals(0x101, pmt.pcrPid)
        assertEquals(listOf(EsKind.VIDEO, EsKind.AUDIO, EsKind.SUBTITLE, EsKind.VIDEO), pmt.streams.map { it.kind })
        assertEquals("eng", pmt.streams[1].language); assertEquals("HEVC", pmt.streams[3].codec)

        val sdt = Psi.parseSdt(TestSupport.sdt(0x2001, 0x20FA, listOf(Triple(1, 0x19, "Canal Un"), Triple(2, 0x02, "Radio 2"))))!!
        assertEquals(0x20FA, sdt.originalNetworkId)
        assertEquals("Canal Un", sdt.services[0].name); assertEquals(0x19, sdt.services[0].serviceType)
        assertEquals("Prov", sdt.services[1].provider)
    }

    @Test fun eitParseAndTime() {
        val eit = Psi.parseEit(TestSupport.eit(1, 0x2001, "News", "Daily news"))!!
        val e = eit.events.single()
        assertEquals("News", e.title); assertEquals("Daily news", e.text); assertEquals(3600, e.durationSec)
        // MJD 60379 = 2024-03-10, 20:00 UTC
        assertEquals(java.time.Instant.parse("2024-03-10T20:00:00Z").toEpochMilli(), e.startUtcMs)
    }

    @Test fun badCrcIsDropped() {
        val s = TestSupport.pat(1, listOf(1 to 0x100)); s[s.size - 1] = (s[s.size - 1] + 1).toByte()
        var got = 0
        feed(SectionAssembler { got++ }, TestSupport.packetize(s, 0))
        assertEquals(0, got)
    }

    @Test fun multiPacketSectionAndContinuityBreak() {
        val big = TestSupport.sdt(1, 1, (1..40).map { Triple(it, 1, "Service number $it") })
        val packets = TestSupport.packetize(big, 0x11)
        assertTrue(packets.size > 1)
        var got = 0
        feed(SectionAssembler { got++ }, packets); assertEquals(1, got)
        got = 0
        feed(SectionAssembler { got++ }, packets.filterIndexed { i, _ -> i != 1 }); assertEquals(0, got) // lost packet
    }

    @Test fun readerResynchronises() {
        val p = TestSupport.packetize(TestSupport.pat(1, listOf(1 to 0x100)), 0).single()
        val data = byteArrayOf(1, 2, 3) + p + byteArrayOf(9) + p + p
        val buf = ByteArray(2048); System.arraycopy(data, 0, buf, 0, data.size)
        var packets = 0; var resync = 0
        val left = TsReader.dispatch(buf, data.size, listOf(object : TsSink { override fun onPacket(buf: ByteArray, off: Int) { packets++ } })) { resync++ }
        // the first packet is followed by a junk byte, so only the two aligned ones are accepted
        assertEquals(2, packets); assertTrue(resync >= 4); assertEquals(0, left)
    }

    @Test fun collectorAndStats() {
        val stats = TsStats(); var services = 0
        val col = PsiCollector(onSdt = { services += it.services.size })
        val sinks = listOf<TsSink>(stats, col)
        val pkts = TestSupport.packetize(TestSupport.pat(5, listOf(1 to 0x100)), 0) +
            TestSupport.packetize(TestSupport.pmt(1, 0x101, listOf(Triple(0x02, 0x101, ByteArray(0)))), 0x100) +
            TestSupport.packetize(TestSupport.sdt(5, 1, listOf(Triple(1, 1, "A"))), 0x11)
        pkts.forEach { p -> sinks.forEach { it.onPacket(p, 0) } }
        assertEquals(1, services); assertEquals(5, col.pat!!.transportStreamId)
        assertEquals(0x101, col.pmtByProgram[1]!!.pcrPid)
        assertEquals(3L, stats.totalPackets)
        // continuity error counting
        val p = TestSupport.packetize(TestSupport.pat(5, listOf(1 to 0x100)), 0x200)[0]
        stats.onPacket(p, 0); p[3] = 0x15; stats.onPacket(p, 0)
        assertEquals(1L, stats.snapshot().first { it.pid == 0x200 }.ccErrors)
    }

    @Test fun dvbText() {
        assertEquals("Café", DvbText.decode("Café".toByteArray(Charsets.ISO_8859_1), 0, 4))
        val utf = byteArrayOf(0x15) + "Привет".toByteArray(Charsets.UTF_8)
        assertEquals("Привет", DvbText.decode(utf, 0, utf.size))
        val iso5 = byteArrayOf(0x01, 0xBF.toByte(), 0xE0.toByte()) // ISO-8859-5: П р
        assertEquals("Пр", DvbText.decode(iso5, 0, 3))
    }

    @Test fun filteredWriterKeepsOnlyWantedPids() {
        val sink = java.io.ByteArrayOutputStream()
        val w = org.opendvb.receiver.player.FilteredTsWriter(sink, setOf(0x100), 16)
        w.start()
        val a = TestSupport.packetize(TestSupport.pat(1, listOf(1 to 0x100)), 0x100)[0]
        val b = TestSupport.packetize(TestSupport.pat(1, listOf(1 to 0x100)), 0x200)[0]
        repeat(3) { w.onPacket(a, 0); w.onPacket(b, 0) }
        Thread.sleep(300)
        w.close()
        assertEquals(3 * 188, sink.size())
    }
}
