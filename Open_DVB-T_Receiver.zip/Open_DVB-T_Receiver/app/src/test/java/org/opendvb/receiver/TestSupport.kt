package org.opendvb.receiver

import org.opendvb.receiver.transport.Crc32Mpeg
import org.opendvb.receiver.transport.Ts
import java.io.ByteArrayOutputStream

/** Builds synthetic PSI/SI sections and TS packets for parser tests. */
object TestSupport {
    fun u16(v: Int) = byteArrayOf((v shr 8).toByte(), v.toByte())

    fun longSection(tableId: Int, idField: Int, version: Int, body: ByteArray): ByteArray {
        val sectionLength = 5 + body.size + 4
        val o = ByteArrayOutputStream()
        o.write(tableId)
        o.write(0xB0 or ((sectionLength shr 8) and 0x0F))
        o.write(sectionLength and 0xFF)
        o.write(u16(idField))
        o.write(0xC1 or (version shl 1))
        o.write(0); o.write(0)
        o.write(body)
        val noCrc = o.toByteArray()
        val crc = Crc32Mpeg.compute(noCrc)
        o.write(byteArrayOf((crc ushr 24).toByte(), (crc ushr 16).toByte(), (crc ushr 8).toByte(), crc.toByte()))
        return o.toByteArray()
    }

    fun pat(tsId: Int, programs: List<Pair<Int, Int>>): ByteArray {
        val b = ByteArrayOutputStream()
        for ((n, pid) in programs) { b.write(u16(n)); b.write(u16(0xE000 or pid)) }
        return longSection(0x00, tsId, 1, b.toByteArray())
    }

    fun pmt(program: Int, pcr: Int, streams: List<Triple<Int, Int, ByteArray>>): ByteArray {
        val b = ByteArrayOutputStream()
        b.write(u16(0xE000 or pcr)); b.write(u16(0xF000))
        for ((type, pid, desc) in streams) {
            b.write(type); b.write(u16(0xE000 or pid)); b.write(u16(0xF000 or desc.size)); b.write(desc)
        }
        return longSection(0x02, program, 1, b.toByteArray())
    }

    fun sdt(tsId: Int, onid: Int, services: List<Triple<Int, Int, String>>): ByteArray {
        val b = ByteArrayOutputStream()
        b.write(u16(onid)); b.write(0xFF)
        for ((sid, type, name) in services) {
            val n = name.toByteArray(Charsets.ISO_8859_1)
            val provider = "Prov".toByteArray()
            val d = ByteArrayOutputStream()
            d.write(0x48); d.write(3 + provider.size + n.size)
            d.write(type); d.write(provider.size); d.write(provider); d.write(n.size); d.write(n)
            val desc = d.toByteArray()
            b.write(u16(sid)); b.write(0xFD)
            b.write(u16(0x8000 or desc.size)) // running_status=4, free_CA=0
            b.write(desc)
        }
        return longSection(0x42, tsId, 1, b.toByteArray())
    }

    /** EIT with one event; start = 2024-03-10 20:00:00 UTC (MJD 60379), 1 h long. */
    fun eit(serviceId: Int, tsId: Int, title: String, text: String): ByteArray {
        val t = title.toByteArray(Charsets.ISO_8859_1); val x = text.toByteArray(Charsets.ISO_8859_1)
        val d = ByteArrayOutputStream()
        d.write(0x4D); d.write(5 + t.size + x.size)
        d.write("eng".toByteArray()); d.write(t.size); d.write(t); d.write(x.size); d.write(x)
        val desc = d.toByteArray()
        val b = ByteArrayOutputStream()
        b.write(u16(tsId)); b.write(u16(1)); b.write(0); b.write(0x4E)
        b.write(u16(0x1234))
        b.write(u16(60379)); b.write(0x20); b.write(0x00); b.write(0x00)
        b.write(0x01); b.write(0x00); b.write(0x00)
        b.write(u16(0x8000 or desc.size)); b.write(desc)
        return longSection(0x4E, serviceId, 1, b.toByteArray())
    }

    /** Packs a section into TS packets of [pid]; continuity counter starts at [cc0]. */
    fun packetize(section: ByteArray, pid: Int, cc0: Int = 0): List<ByteArray> {
        val data = byteArrayOf(0) + section // pointer_field = 0
        val out = ArrayList<ByteArray>()
        var pos = 0; var cc = cc0
        while (pos < data.size) {
            val p = ByteArray(Ts.PACKET_SIZE) { 0xFF.toByte() }
            p[0] = Ts.SYNC_BYTE.toByte()
            p[1] = (((if (pos == 0) 0x40 else 0) or (pid shr 8))).toByte()
            p[2] = pid.toByte()
            p[3] = (0x10 or (cc and 0xF)).toByte()
            val n = minOf(184, data.size - pos)
            System.arraycopy(data, pos, p, 4, n)
            out.add(p); pos += n; cc++
        }
        return out
    }
}
