package info.martinmarinov.drivers;

/**
 * Run-time tuner options shared between the app and the built-in driver (same process).
 * Changes apply at the next tune.
 */
public final class TunerOptions {
    private TunerOptions() {}

    /** FC0012 LNA gain: 0 = very low (-9.9 dB), 1 = low (-4 dB, librtlsdr default), 2 = middle (+7.1 dB), 3 = high (+19.2 dB). */
    public static volatile int fc0012Gain = 1;

    /** True while the connected stick has an FC0012 tuner (set by the driver). */
    public static volatile boolean fc0012Active = false;

    public static int fc0012GainRegister() {
        switch (fc0012Gain) {
            case 0: return 0x02;
            case 2: return 0x08;
            case 3: return 0x10;
            case 1:
            default: return 0x00;
        }
    }
}
