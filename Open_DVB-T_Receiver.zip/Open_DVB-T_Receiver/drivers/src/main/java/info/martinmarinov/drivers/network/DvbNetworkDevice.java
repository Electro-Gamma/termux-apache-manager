/*
 * Network receiver support (dvbnetd client) for the Android user space port of DVB-T Linux kernel modules.
 * Structure derived from file/DvbFileDevice.java.
 *
 * Copyright (C) 2022 by Signalware Ltd <driver at aerialtv.eu>
 * Network additions: same licence.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

package info.martinmarinov.drivers.network;

import androidx.annotation.NonNull;

import java.io.IOException;
import java.util.EnumSet;
import java.util.Set;

import info.martinmarinov.drivers.DeliverySystem;
import info.martinmarinov.drivers.DeviceFilter;
import info.martinmarinov.drivers.DvbCapabilities;
import info.martinmarinov.drivers.DvbDemux;
import info.martinmarinov.drivers.DvbDevice;
import info.martinmarinov.drivers.DvbException;
import info.martinmarinov.drivers.DvbStatus;
import info.martinmarinov.usbxfer.ByteSource;

import static info.martinmarinov.drivers.DvbException.ErrorCode.BAD_API_USAGE;

/**
 * A DvbDevice backed by a remote dvbnetd server (a Linux box with a DVB-T/T2 USB receiver) instead of a
 * local USB device. To the rest of the app, including the loopback DvbServer that Open DVB-T Receiver talks
 * to, it is just another DvbDevice, so the dtvdriver: intent contract is unchanged.
 */
public class DvbNetworkDevice extends DvbDevice {
    private static final int TIMEOUT_MS = 10_000;
    private static final long STATUS_CACHE_MS = 50;

    private final String host;
    private final int controlPort, transferPort;
    private final NetworkClient client;

    private NetworkClient.Capabilities caps;
    private NetworkClient.Status status;
    private long statusFetchedAt;

    public DvbNetworkDevice(String host, int controlPort, int transferPort) {
        super(DvbDemux.DvbDmxSwfilter());
        this.host = host;
        this.controlPort = controlPort;
        this.transferPort = transferPort;
        this.client = new NetworkClient(host, controlPort, transferPort, TIMEOUT_MS);
    }

    @Override
    public void open() throws DvbException {
        client.connectControl();
        try {
            client.protocolVersion();
            caps = client.capabilities();
        } catch (DvbException e) {
            client.close();
            throw e;
        }
    }

    @Override
    public DeviceFilter getDeviceFilter() {
        // Before open() the USB ids are unknown (-1, like DvbFileDevice); afterwards they are the remote device's.
        int vid = caps != null ? caps.vendorId : -1;
        int pid = caps != null ? caps.productId : -1;
        return new NetworkDeviceFilter("Network receiver " + host, vid, pid, host, controlPort, transferPort);
    }

    @Override
    public DvbCapabilities readCapabilities() throws DvbException {
        if (caps == null) throw new DvbException(BAD_API_USAGE, "Device not opened");
        return caps.dvb;
    }

    @Override
    protected void tuneTo(long freqHz, long bandwidthHz, @NonNull DeliverySystem deliverySystem) throws DvbException {
        client.tune(freqHz, bandwidthHz, deliverySystem);   // the server resets its PID filter to {0}, as DvbDevice.tune() does locally
        status = null;
    }

    /**
     * Request.REQ_GET_STATUS calls readSnr, readBitErrorRate, readDroppedUsbFps, readRfStrengthPercentage and
     * getStatus one after another; one network round trip serves all of them.
     */
    private synchronized NetworkClient.Status snapshot() throws DvbException {
        long now = System.nanoTime() / 1_000_000L;
        if (status == null || now - statusFetchedAt > STATUS_CACHE_MS) {
            status = client.status();
            statusFetchedAt = now;
        }
        return status;
    }

    @Override
    public int readSnr() throws DvbException {
        return snapshot().snr;                 // 0.1 dB, measured by the Linux frontend on the server
    }

    @Override
    public int readRfStrengthPercentage() throws DvbException {
        return snapshot().rfStrengthPercentage;
    }

    @Override
    public int readBitErrorRate() throws DvbException {
        return snapshot().ber;
    }

    @Override
    public int readDroppedUsbFps() throws DvbException {
        return snapshot().droppedUsbFps;       // counted on the server over the full TS, same algorithm as DvbDemux
    }

    @Override
    public Set<DvbStatus> getStatus() throws DvbException {
        NetworkClient.Status s = snapshot();
        Set<DvbStatus> set = EnumSet.noneOf(DvbStatus.class);
        if (s.hasSignal) set.add(DvbStatus.FE_HAS_SIGNAL);
        if (s.hasCarrier) set.add(DvbStatus.FE_HAS_CARRIER);
        if (s.hasSync) set.add(DvbStatus.FE_HAS_SYNC);
        if (s.hasLock) set.add(DvbStatus.FE_HAS_LOCK);
        return set;
    }

    @Override
    public void setPidFilter(int... pids) throws DvbException {
        client.setPids(pids);                  // filter on the server so unwanted PIDs never cross the network
        super.setPidFilter(pids);              // and locally, which keeps DvbDemux.reset() semantics identical
    }

    @Override
    public void disablePidFilter() throws DvbException {
        // The dvbservice protocol has no "pass everything" request, and no client can send one.
        throw new DvbException(BAD_API_USAGE, "Disabling the PID filter is not supported on a network receiver");
    }

    @Override
    protected ByteSource createTsSource() {
        return new NetworkTsSource(client);
    }

    @Override
    public String getDebugString() {
        return "Network - " + host + ":" + controlPort + "/" + transferPort;
    }

    @Override
    public void close() throws IOException {
        client.close();
        super.close();
    }
}
