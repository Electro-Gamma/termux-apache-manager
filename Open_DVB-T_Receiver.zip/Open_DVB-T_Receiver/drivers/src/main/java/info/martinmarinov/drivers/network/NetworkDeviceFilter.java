/*
 * Network receiver support (dvbnetd client) for the Android user space port of DVB-T Linux kernel modules.
 * Structure derived from file/DvbFileDevice.java.
 *
 * Copyright (C) 2022 by Signalware Ltd <driver at aerialtv.eu>
 * Network additions: same licence.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

package info.martinmarinov.drivers.network;

import info.martinmarinov.drivers.DeviceFilter;

/** Identifies the configured network receiver. Equality is by host and ports (like FileDeviceFilter by file). */
public class NetworkDeviceFilter extends DeviceFilter {
    private final String host;
    private final int controlPort, transferPort;

    NetworkDeviceFilter(String name, int vendorId, int productId, String host, int controlPort, int transferPort) {
        super(vendorId, productId, name);
        this.host = host;
        this.controlPort = controlPort;
        this.transferPort = transferPort;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        NetworkDeviceFilter that = (NetworkDeviceFilter) o;
        return controlPort == that.controlPort && transferPort == that.transferPort && host.equals(that.host);
    }

    @Override
    public int hashCode() {
        int result = host.hashCode();
        result = 31 * result + controlPort;
        result = 31 * result + transferPort;
        return result;
    }
}
