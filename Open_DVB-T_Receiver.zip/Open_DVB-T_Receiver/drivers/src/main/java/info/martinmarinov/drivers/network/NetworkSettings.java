/*
 * Network receiver support (dvbnetd client) for the Android user space port of DVB-T Linux kernel modules.
 * Structure derived from file/DvbFileDevice.java.
 *
 * Copyright (C) 2022 by Signalware Ltd <driver at aerialtv.eu>
 * Network additions: same licence.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

package info.martinmarinov.drivers.network;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.List;

import info.martinmarinov.drivers.DvbDevice;

/** Address of the dvbnetd server, kept in the driver app's private preferences. Empty host = feature off. */
public final class NetworkSettings {
    private static final String PREFS = "network_receiver";
    public static final int DEFAULT_CONTROL_PORT = 7500;
    public static final int DEFAULT_TRANSFER_PORT = 7501;

    public static final class Target {
        public final String host;
        public final int controlPort, transferPort;

        public Target(String host, int controlPort, int transferPort) {
            this.host = host;
            this.controlPort = controlPort;
            this.transferPort = transferPort;
        }

        public boolean isEnabled() {
            return !host.isEmpty();
        }
    }

    private NetworkSettings() {}

    public static Target load(Context ctx) {
        SharedPreferences p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String host = p.getString("host", "");
        return new Target(host == null ? "" : host, p.getInt("control", DEFAULT_CONTROL_PORT), p.getInt("transfer", DEFAULT_TRANSFER_PORT));
    }

    public static void save(Context ctx, Target t) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString("host", t.host).putInt("control", t.controlPort).putInt("transfer", t.transferPort).apply();
    }

    public static boolean validPort(int port) {
        return port >= 1 && port <= 65535;
    }

    /** 0 or 1 network devices: the configured receiver. No connection is made here. */
    public static List<DvbDevice> getNetworkDevices(Context ctx) {
        List<DvbDevice> devices = new ArrayList<>(1);
        Target t = load(ctx);
        if (t.isEnabled()) devices.add(new DvbNetworkDevice(t.host, t.controlPort, t.transferPort));
        return devices;
    }
}
