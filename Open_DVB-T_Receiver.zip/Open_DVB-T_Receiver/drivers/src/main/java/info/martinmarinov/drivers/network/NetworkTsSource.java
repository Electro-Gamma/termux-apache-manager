/*
 * Network receiver support (dvbnetd client) for the Android user space port of DVB-T Linux kernel modules.
 * Structure derived from file/DvbFileDevice.java.
 *
 * Copyright (C) 2022 by Signalware Ltd <driver at aerialtv.eu>
 * Network additions: same licence.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

package info.martinmarinov.drivers.network;

import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.net.SocketTimeoutException;

import info.martinmarinov.usbxfer.ByteSink;
import info.martinmarinov.usbxfer.ByteSource;

/**
 * Feeds the MPEG-TS arriving on the dvbnetd transfer socket into the DvbDemux.
 * A short read timeout keeps the DataPump thread interruptible: DvbDevice.close() interrupts it
 * and waits for it to die, and a blocking socket read would otherwise never return.
 */
public class NetworkTsSource implements ByteSource {
    private static final int READ_TIMEOUT_MS = 200;

    private final NetworkClient client;
    private final byte[] buf = new byte[188 * 64];

    private Socket socket;
    private InputStream in;

    public NetworkTsSource(NetworkClient client) {
        this.client = client;
    }

    @Override
    public void open() throws IOException {
        socket = client.openTransfer();
        socket.setSoTimeout(READ_TIMEOUT_MS);
        in = socket.getInputStream();
    }

    @Override
    public void readNext(ByteSink sink) throws IOException, InterruptedException {
        int n;
        try {
            n = in.read(buf);
        } catch (SocketTimeoutException e) {
            if (Thread.currentThread().isInterrupted()) throw new InterruptedException();
            return; // no data right now
        }
        if (n < 0) throw new IOException("The network receiver closed the transport stream");
        if (n > 0) sink.consume(buf, n);
    }

    @Override
    public void close() throws IOException {
        if (socket != null) socket.close();
    }
}
