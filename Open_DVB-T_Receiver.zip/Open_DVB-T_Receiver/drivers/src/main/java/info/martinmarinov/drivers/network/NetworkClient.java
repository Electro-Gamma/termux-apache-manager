/*
 * Network receiver support (dvbnetd client) for the Android user space port of DVB-T Linux kernel modules.
 * Structure derived from file/DvbFileDevice.java.
 *
 * Copyright (C) 2022 by Signalware Ltd <driver at aerialtv.eu>
 * Network additions: same licence.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

package info.martinmarinov.drivers.network;

import java.io.Closeable;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.EnumSet;
import java.util.Set;

import info.martinmarinov.drivers.DeliverySystem;
import info.martinmarinov.drivers.DvbCapabilities;
import info.martinmarinov.drivers.DvbException;

import static info.martinmarinov.drivers.DvbException.ErrorCode.HARDWARE_EXCEPTION;
import static info.martinmarinov.drivers.DvbException.ErrorCode.IO_EXCEPTION;

/**
 * Client side of the dvbservice TCP protocol (see dvbservice/.../Request.java and Response.java):
 * request  = [ordinal][N][N x big-endian long]
 * response = [ordinal][N][N x big-endian long], first long is the success flag.
 * Talks to a dvbnetd server (or to another Android driver). Pure Java, no Android classes.
 */
public class NetworkClient implements Closeable {
    // Request enum order of dvbservice/Request.java. Never reorder.
    static final int REQ_PROTOCOL_VERSION = 0;
    static final int REQ_EXIT = 1;
    static final int REQ_TUNE = 2;
    static final int REQ_GET_STATUS = 3;
    static final int REQ_SET_PIDS = 4;
    static final int REQ_GET_CAPABILITIES = 5;
    static final int KNOWN_REQUESTS = 6;

    private final String host;
    private final int controlPort, transferPort, timeoutMs;

    private Socket control;
    private DataInputStream in;
    private OutputStream out;

    public NetworkClient(String host, int controlPort, int transferPort, int timeoutMs) {
        this.host = host;
        this.controlPort = controlPort;
        this.transferPort = transferPort;
        this.timeoutMs = timeoutMs;
    }

    public static final class Status {
        public final int snr, ber, droppedUsbFps, rfStrengthPercentage;
        public final boolean hasSignal, hasCarrier, hasSync, hasLock;

        Status(long[] v) {
            snr = (int) v[0];
            ber = (int) v[1];
            droppedUsbFps = (int) v[2];
            rfStrengthPercentage = (int) v[3];
            hasSignal = v[4] != 0;
            hasCarrier = v[5] != 0;
            hasSync = v[6] != 0;
            hasLock = v[7] != 0;
        }
    }

    public static final class Capabilities {
        public final DvbCapabilities dvb;
        public final int vendorId, productId;

        Capabilities(DvbCapabilities dvb, int vendorId, int productId) {
            this.dvb = dvb;
            this.vendorId = vendorId;
            this.productId = productId;
        }
    }

    /** The control socket is connected first, exactly as the Android driver server expects (DvbServer.serve). */
    public synchronized void connectControl() throws DvbException {
        try {
            Socket s = new Socket();
            s.connect(new InetSocketAddress(host, controlPort), timeoutMs);
            s.setTcpNoDelay(true);
            s.setSoTimeout(timeoutMs);
            s.setKeepAlive(true);
            control = s;
            in = new DataInputStream(s.getInputStream());
            out = s.getOutputStream();
        } catch (IOException e) {
            closeQuietly();
            throw new DvbException(IO_EXCEPTION, "Cannot connect to the network receiver " + host + ":" + controlPort, e);
        }
    }

    /** Opens the transfer socket (raw MPEG-TS, server to client). */
    public Socket openTransfer() throws IOException {
        Socket s = new Socket();
        s.connect(new InetSocketAddress(host, transferPort), timeoutMs);
        s.setTcpNoDelay(true);
        s.setKeepAlive(true);
        return s;
    }

    /** Sends one request and returns the payload that follows the success flag. */
    private synchronized long[] request(int ordinal, long... payload) throws DvbException {
        if (control == null) throw new DvbException(IO_EXCEPTION, "Network receiver is not connected");
        if (payload.length > 255) throw new IllegalArgumentException("payload too long");
        try {
            byte[] raw = new byte[2 + payload.length * 8];
            raw[0] = (byte) ordinal;
            raw[1] = (byte) payload.length;
            for (int i = 0; i < payload.length; i++) writeLong(raw, 2 + i * 8, payload[i]);
            out.write(raw);
            out.flush();

            int gotOrdinal = in.readUnsignedByte();
            int n = in.readUnsignedByte();
            if (gotOrdinal != ordinal) throw new DvbException(IO_EXCEPTION, "Protocol error: response " + gotOrdinal + " to request " + ordinal);
            if (n < 1) throw new DvbException(IO_EXCEPTION, "Protocol error: empty response");
            long[] all = new long[n];
            for (int i = 0; i < n; i++) all[i] = in.readLong();
            if (all[0] != 1L) throw new DvbException(HARDWARE_EXCEPTION, "The network receiver rejected request " + ordinal);
            long[] res = new long[n - 1];
            System.arraycopy(all, 1, res, 0, n - 1);
            return res;
        } catch (IOException e) {
            if (e instanceof DvbException) throw (DvbException) e;
            throw new DvbException(IO_EXCEPTION, "Network receiver connection lost", e);
        }
    }

    private static void writeLong(byte[] b, int off, long v) {
        for (int i = 0; i < 8; i++) b[off + i] = (byte) (v >>> (56 - 8 * i));
    }

    /** @return {protocol version, number of supported requests} */
    public long[] protocolVersion() throws DvbException {
        long[] v = request(REQ_PROTOCOL_VERSION);
        if (v.length < 2) throw new DvbException(IO_EXCEPTION, "Protocol error: short version response");
        if (v[1] < KNOWN_REQUESTS) throw new DvbException(IO_EXCEPTION, "The network receiver speaks an older protocol");
        return v;
    }

    public Capabilities capabilities() throws DvbException {
        long[] v = request(REQ_GET_CAPABILITIES);
        if (v.length < 6) throw new DvbException(IO_EXCEPTION, "Protocol error: short capabilities response");
        Set<DeliverySystem> systems = EnumSet.noneOf(DeliverySystem.class);
        for (DeliverySystem d : DeliverySystem.values()) {
            if ((v[0] & (1L << d.ordinal())) != 0) systems.add(d);
        }
        return new Capabilities(new DvbCapabilities(v[1], v[2], v[3], systems), (int) v[4], (int) v[5]);
    }

    public void tune(long freqHz, long bandwidthHz, DeliverySystem system) throws DvbException {
        request(REQ_TUNE, freqHz, bandwidthHz, system.ordinal());
    }

    public Status status() throws DvbException {
        long[] v = request(REQ_GET_STATUS);
        if (v.length < 8) throw new DvbException(IO_EXCEPTION, "Protocol error: short status response");
        return new Status(v);
    }

    public void setPids(int... pids) throws DvbException {
        long[] p = new long[pids.length];
        for (int i = 0; i < pids.length; i++) p[i] = pids[i];
        request(REQ_SET_PIDS, p);
    }

    @Override
    public synchronized void close() {
        if (control != null) {
            try {
                // Best effort REQ_EXIT so the server ends the session cleanly
                byte[] raw = new byte[] {(byte) REQ_EXIT, 0};
                out.write(raw);
                out.flush();
            } catch (IOException ignored) {
                // connection already gone
            }
        }
        closeQuietly();
    }

    private void closeQuietly() {
        if (control != null) {
            try { control.close(); } catch (IOException ignored) { }
        }
        control = null; in = null; out = null;
    }
}
