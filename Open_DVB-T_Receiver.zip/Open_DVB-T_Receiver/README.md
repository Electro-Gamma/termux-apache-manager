# Open DVB-T Receiver (with the DVB-T Driver built in)

One Android application, one launcher icon: **Open DVB Receiver** (Kotlin DVB-T/T2 receiver, libVLC playback) with the open-source
**AndroidDvbDriver** compiled into it, so no separate driver app is needed any more. It can use a USB tuner on the phone (OTG) or a
tuner on a **Raspberry Pi / Banana Pi / Orange Pi** running `dvbnetd` (included in `dvbnetd/`).

## What is in the three-dot menu
Favourites only · Diagnostics · **Driver diagnostics (Advanced mode)** · **Network receiver (Raspberry Pi)** · Open .ts capture… ·
Delete channel list · About / licences (button *Driver info / licence* opens the driver's own start page: licence text, source code link).
Everything the app did before is unchanged; the two bold entries are new.

## Build
**Google Colab (easiest):** put `Open_DVB-T_Receiver.zip` in your GitHub repository, open `OpenDvbReceiver_APK_Release.ipynb`
in Colab and run the cells top to bottom. It downloads the ZIP, runs a static pre-flight check, installs JDK 17 / Android SDK 34 / NDK / CMake,
builds, signs and verifies the per-ABI release APKs (`arm64-v8a`, `armeabi-v7a`) and lets you download them together with the keystore.

**Locally:** JDK 17, Android SDK (platform 34, build-tools 34.0.0, NDK 26.1.10909125, CMake 3.22.1), then

    echo "sdk.dir=/path/to/android-sdk" > local.properties
    python3 scripts/preflight.py .            # optional static checks, no SDK needed
    ./gradlew :app:testDebugUnitTest          # Open DVB Receiver's JVM tests
    ./gradlew :app:assembleDebug              # debug APKs in app/build/outputs/apk/debug
    # release: provide your own signing config (none is stored in this repo; the Colab notebook adds one)

`gradle.properties: libvlcVersion` selects the official `org.videolan.android:libvlc-all` release (the notebook picks the newest 3.6.x).

## Use
* **USB tuner:** plug it in with an OTG cable, open the app, **Connect tuner**, allow USB access, **Scan**, tap a channel.
  Plugging a supported tuner in while the app is installed offers to open it.
* **Network tuner:** build/install `dvbnetd` on the Pi (`dvbnetd/README.md`), then menu -> **Network receiver (Raspberry Pi)** -> enter the
  Pi's address -> *Save and test connection*. Back on the main screen press **Connect tuner**. With only the network receiver configured it connects
  directly; with a USB tuner attached too, a small chooser lists both. Clear the address to use USB only.
* **Driver diagnostics (Advanced mode):** the driver's own tuning/diagnostic screen. It needs the USB tuner for itself, so the app offers to
  disconnect the receiver first.

## Modules
`app` Open DVB Receiver (Kotlin) · `driverui` driver screens (library) · `dvbservice` loopback server + device chooser (the `dtvdriver:` contract) ·
`drivers` USB drivers + the network receiver device · `usbxfer` native USB transfer library (`libUsbXfer.so`) · `dvbnetd` Linux server (not part of the Gradle build).
Details of the merge: `docs/INTEGRATION.md`. Open DVB Receiver's own notes: `docs/FINDINGS.md`, `docs/STATUS.md`, `docs/DRIVER_PROTOCOL.md`.

## Status
Assembled and statically checked offline (`scripts/preflight.py`: manifests, launcher count, resource collisions, Gradle wiring); the dvbnetd protocol is
tested against the original driver code (`dvbnetd/docs/REPORT.md`). **The merged Android project has not been compiled by its author** (no Android SDK or
network where it was assembled), and nothing has been run on a phone, a Pi or a tuner. If the Colab build fails, paste the `e:` / `error:` / `Manifest merger` lines back.

## Licence
Open DVB Receiver's own code: MIT (`LICENSE`). Driver modules (`driverui`, `dvbservice`, `drivers`, `usbxfer`) and `dvbnetd`: GPL-2.0-or-later (`COPYING`).
The APK contains both, plus libVLC (LGPL-2.1+): if you give the APK to anyone you must also offer them this source. See `NOTICE.md`.
