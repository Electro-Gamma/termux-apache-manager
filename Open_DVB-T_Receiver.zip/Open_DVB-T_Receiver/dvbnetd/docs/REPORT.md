# Verification report

## A. Source-verified (read from the original AndroidDvbDriver source)
Wire format, ordinals, response framing, error handling, unknown-ordinal behaviour, connection sequence, tune/filter
reset semantics, drop accounting algorithm, units of SNR / RF / BER, RTL2832 capabilities. See PROTOCOL.md.

## B. Software-tested here (no hardware involved)
| Test | What it compares | Result |
|---|---|---|
| `make test-compat`, 4 variants (T2 on/off x control-first/transfer-first), 31 steps each | Byte-identical control transcripts and observed TS PID sets between **REF** (the original, unmodified Request/Response/DvbServer/TransferThread/DvbDemux behind a scripted device), **NET** (dvbnetd, synthetic TS backend) and **CHAIN** (original server in front of the new `DvbNetworkDevice` talking to dvbnetd) | all identical |
| Dropped-packet accounting | C port vs the original `DvbDemux` on 60 000 generated packets (glitches, TEI, adaptation-only, odd/even PIDs, 0x1FFF, random chunking) | 1019 = 1019 |
| Mutation check | dvbnetd with the filter reset on TUNE removed | test fails as it should |
| Compile | server: gcc 13 x86-64, `-Wall -Wextra -Wconversion` clean; `-m32` ILP32 syntax check clean (proxy for ARMv7); all new Java compiled together with the original driver classes at Java 8 source level | ok |
| Android UI/settings | `NetworkReceiverActivity`, `NetworkSettings` type-checked against hand-written stubs of the framework signatures | ok (not the real SDK) |

## C. NOT done / NOT proven
* **No hardware test**: no RTL-SDR/DVB-T stick, no Raspberry Pi/Banana Pi/Orange Pi, no Android device or emulator.
* **ARMv7 and ARM64 were not built or run**: no ARM cross-compiler or qemu in the build sandbox. `scripts/build-arm.sh` does it.
* **The Android app was not built with Gradle/the Android SDK** (no network access); the driver's own unit tests
  (JUnit/Mockito/PowerMock) were not run. Build it with the Colab notebook and report any `e:` / `error:` lines.
* Open DVB-T Receiver was not run against the patched driver.
* The scripted REF device and the fake backend are my own: they prove protocol equality, not tuner behaviour.
