# dvbnetd / AndroidDvbDriver protocol (verified against the driver source)

Source of truth: AndroidDvbDriver (Signalware Ltd, GPL-2.0-or-later), files
`dvbservice/.../Request.java`, `Response.java`, `DvbServer.java`, `TransferThread.java`,
`drivers/.../DvbDevice.java`, `DvbDemux.java`, `FastIntFilter.java`, `DeliverySystem.java`,
`DeviceChooserActivity.java`, `DvbService.java`. Everything in "Verified" was read from that source.

## Verified: wire format
* Two TCP connections. **Control**: request/response. **Transfer**: raw MPEG-TS, server to client only.
* Request: `[ordinal u8][N u8][N x int64 big-endian]`. Response: `[ordinal u8][N u8][N x int64]`, where the first
  int64 is the success flag (1/0) and N counts it. An error response is `[ordinal][1][0]` with no payload.
* Ordinals (enum order, "never reorder"): 0 PROTOCOL_VERSION, 1 EXIT, 2 TUNE, 3 GET_STATUS, 4 SET_PIDS, 5 GET_CAPABILITIES.
* An ordinal >= 6: payload is consumed and **no response is sent**.
* Any exception while executing a request returns the error response; the connection stays open.
* DeliverySystem ordinals: 0 DVBT, 1 DVBT2, 2 DVBC.

| Request | Payload | Success payload |
|---|---|---|
| PROTOCOL_VERSION | none | `0`, number of requests (6) |
| EXIT | none | none, then the server ends the session |
| TUNE | freqHz, bandwidthHz, deliverySystem (fewer than 3 values: error; extra values ignored) | none |
| GET_STATUS | none | snr, ber, droppedUsbFps, rfStrength%, hasSignal, hasCarrier, hasSync, hasLock |
| SET_PIDS | PID list (each cast to int; ids outside 0..0x1FFF fail) | none |
| GET_CAPABILITIES | none | systemMask (bit = 1<<ordinal), freqMin, freqMax, freqStep (Hz), vendorId, productId |

## Verified: behaviour
* Connection: server accepts **control first**, serves control requests immediately, and accepts the transfer socket
  in a worker thread (60 s timeout for each accept). Clients that connect transfer first also work (TCP backlog).
* `DvbDevice.tune()` = `tuneTo()` then `dvbDemux.reset()`. `reset()` sets the PID filter to **{0}** (PAT only) unless
  full-TS mode is on (never reachable over the protocol). The same reset happens when the stream starts.
* SET_PIDS with an empty list passes nothing. PID filtering happens before the transfer socket.
* `droppedUsbFps` = (packets with the transport-error bit + continuity-counter errors) * 1000 / ms since last read,
  counted on the whole TS before PID filtering; the timer also restarts on reset.
* Units: **SNR 0.1 dB** (RTL2832 comment; 0 or -1 when unavailable). **RF strength 0..100 %**. **BER**: AF9033 and Si2168
  report error-ratio * 0xFFFF and 0xFFFF without lock; the RTL2832 reports its raw 16-bit register ("bit errors per
  1 MB" in the source comment). The file device uses 0 when tuned and 0xFFFF when not. Open DVB-T Receiver shows these raw.
* The real RTL2832 frontend reports DVB-T only, 174-862 MHz, step 166667 Hz, bandwidths 6/7/8 MHz.
* The driver app serves Open DVB-T Receiver through `dtvdriver:` -> `DeviceChooserActivity` -> `DvbService` ->
  `DvbServer` bound to 127.0.0.1 on random ports, returned as `ControlPort`/`TransferPort` extras.

## dvbnetd deviations (deliberate; each one is the only difference from the original)
1. **Invalid PID** (negative or > 0x1FFF): the original throws inside `FastIntFilter` after clearing the old filter and
   storing the new array, which leaves it corrupted: every later SET_PIDS and every TUNE then fails until the device is
   reopened (found by running the original). dvbnetd answers with the same error response but keeps the previous filter.
2. **Stream start** does not wipe the PID filter (it only restarts the drop statistics), because in network mode a wipe
   on the Pi could race with a SET_PIDS already sent. Tune still resets to {0}.
3. dvbnetd is a daemon: it waits for a control connection without timeout and serves one session after another.
4. The transfer connection must come from the same IP address as the control connection (loopback-only in the original).
5. A client that cannot keep up gets packets dropped after a 512 KiB backlog (`--backlog`) instead of blocking the tuner.
6. TS misalignment resync (`findNextPacket`) is not ported: Linux `dvr0` delivers aligned packets.
7. DVB-C is never advertised (tune has no symbol rate). T and T2 are advertised only if the kernel frontend lists them.
8. Status values come from the Linux frontend, so their exact numbers differ from the Android demod code:
   SNR = kernel CNR / 100 when the frontend reports dB, else 0; RF = kernel signal-strength stat (relative scale exact,
   dBm mapped linearly -90..-30 -> 0..100, or legacy ioctl; 0 without signal); BER = bit-error ratio between two polls * 0xFFFF
   from the kernel's post-FEC counters, 0xFFFF without lock or without counters. Which stats exist depends on the kernel driver.

## Not verifiable without hardware
Which stats the kernel rtl2832/r820t drivers expose on your kernel, tuning/lock times, USB and Wi-Fi throughput on each board.
