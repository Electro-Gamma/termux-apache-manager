# Recording / scheduling / playback: what was verified

## Tested here (synthetic backend, x86-64 Linux, no tuner, no Raspberry Pi, no Android device)
`python3 test/test_rec.py ./dvbnetd-fake ./original-dvbnetd-fake`: 84 checks.
* A: byte-identical protocol transcripts between the previous dvbnetd binary and the new one when recording is not used.
* B manual start/stop, status (state, file, elapsed, size), file naming, no overwrite, info file.
* C duration-based recording (stops by itself, about the requested length).
* D scheduled recording: starts and stops on time, overlap rejection, cancel, persistence over a restart, a window already open at start-up,
  schedule preempting a manual recording, 12-hour and 24-hour input, overnight windows, dates, invalid input. (Wall-clock windows in the test are
  injected as epochs to keep the test short; the clock/date/overnight parsing is covered separately by `make test`, `test/rec_time_test.c`.)
* E recording while a client is connected (tap), continuing after it leaves, refusing a second client during a standalone recording, retune handling.
* F single-service and PID-list recording.
* G crash recovery (kill -9, half packet appended), SIGTERM finalisation.
* H free-space reserve, size cap, real write failure (process file-size limit as stand-in for a full disk), CLI without daemon, bad directory.
* I playback: protocol, byte-exact packets, PCR pacing (3 s of broadcast takes ~3 s), start from the beginning, end of file, `--loop`,
  second client, play by name, missing file, stream without PCR, recording disabled in playback mode.

## Not tested
* Real RTL-SDR V3 / R820T reception and the real Linux DVB backend path (`backend_linux.c` is only renamed `backend_impl` -> `backend_live`; it compiles).
* ARM (Raspberry Pi) builds, SD-card/USB-disk write speed, a real full disk, power loss on real storage.
* The Android app against playback mode (the protocol answers are the same as the live ones in the tests, but no app was run).
* Multi-packet PAT/PMT sections are not followed by `--service` (single-packet sections only, which covers normal DVB-T multiplexes).
* Timezone/DST edge cases beyond what `rec_time_test.c` covers.

## Sanitizer runs
The same 83 checks (all except the comparison with the old binary) run clean under AddressSanitizer + UBSan (no reports).
ThreadSanitizer reports only plain volatile stop flags (`quit`, `run`, `ended`) and the globals of the synthetic test backend; no
race on recorder data (all of it is behind one mutex).
