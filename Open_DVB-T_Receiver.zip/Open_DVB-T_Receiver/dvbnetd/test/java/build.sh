#!/bin/sh
# Compiles the ORIGINAL AndroidDvbDriver protocol classes + the new network classes against tiny stubs for
# the Android SDK (so they can run on a plain JVM). Usage: build.sh /path/to/AndroidDvbDriver-master [outdir]
set -e
SRC="$1"; OUT="${2:-/tmp/dvbjava}"
HERE="$(cd "$(dirname "$0")" && pwd)"
D="$SRC/drivers/src/main/java/info/martinmarinov/drivers"
S="$SRC/dvbservice/src/main/java/info/martinmarinov/dvbservice"
U="$SRC/usbxfer/src/main/java/info/martinmarinov/usbxfer"
rm -rf "$OUT"; mkdir -p "$OUT"
if command -v javac >/dev/null 2>&1; then JAVAC=javac; else JAVAC="java -m jdk.compiler/com.sun.tools.javac.Main"; fi
$JAVAC -nowarn -d "$OUT" \
  $(find "$HERE/stubs" -name '*.java') \
  $D/DvbDevice.java $D/DvbDemux.java $D/DvbException.java $D/DvbStatus.java $D/DvbCapabilities.java \
  $D/DeliverySystem.java $D/DeviceFilter.java $D/tools/FastIntFilter.java $D/tools/SetUtils.java \
  $U/ByteSource.java $U/ByteSink.java \
  $S/Request.java $S/Response.java $S/DvbServer.java $S/DvbServerPorts.java $S/TransferThread.java \
  $D/network/NetworkClient.java $D/network/NetworkTsSource.java $D/network/NetworkDeviceFilter.java $D/network/DvbNetworkDevice.java \
  $(find "$HERE/harness" -name '*.java')
echo "built into $OUT"
