package info.martinmarinov.drivers.tools.io;

import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;

/**
 * TEST REPLACEMENT for the original NativePipe, which wraps android.os.ParcelFileDescriptor and cannot
 * run off-device. Same contract: closing either end closes both. Everything else in the chain is the
 * original, unmodified source.
 */
public class NativePipe implements Closeable {
    private final PipedInputStream inputStream;
    private final PipedOutputStream outputStream;

    public NativePipe() {
        try {
            final PipedOutputStream[] o = new PipedOutputStream[1];
            inputStream = new PipedInputStream(1 << 20) {
                private boolean closed;
                @Override public void close() throws IOException {
                    if (closed) return;
                    closed = true;
                    super.close();
                    o[0].close();
                }
            };
            outputStream = new PipedOutputStream(inputStream) {
                private boolean closed;
                // wake the reader immediately, like an OS pipe (PipedInputStream otherwise polls once a second)
                @Override public void write(byte[] b, int off, int len) throws IOException { super.write(b, off, len); super.flush(); }
                @Override public void close() throws IOException {
                    if (closed) return;
                    closed = true;
                    super.close();
                    inputStream.close();
                }
            };
            o[0] = outputStream;
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public InputStream getInputStream() { return inputStream; }
    public OutputStream getOutputStream() { return outputStream; }
    @Override public void close() throws IOException { inputStream.close(); outputStream.close(); }
}
