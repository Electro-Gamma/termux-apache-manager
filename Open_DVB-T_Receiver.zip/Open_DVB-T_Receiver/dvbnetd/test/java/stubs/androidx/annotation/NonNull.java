package androidx.annotation;
import java.lang.annotation.*;
/** Test stub for androidx.annotation.NonNull. */
@Retention(RetentionPolicy.CLASS)
public @interface NonNull {}
