package android.hardware.usb;
/** Test stub: the real class is part of the Android SDK. */
public class UsbDevice {
    public int getVendorId() { return 0; }
    public int getProductId() { return 0; }
}
