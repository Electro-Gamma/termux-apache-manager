package info.martinmarinov.drivers;

import java.io.RandomAccessFile;
import java.lang.reflect.Field;
import java.util.Random;

/** Feeds a TS file to the ORIGINAL DvbDemux in random chunk sizes and prints its droppedUsbFps counter. */
public class DemuxCountCheck {
    public static void main(String[] a) throws Exception {
        byte[] all;
        try (RandomAccessFile f = new RandomAccessFile(a[0], "r")) {
            all = new byte[(int) f.length()];
            f.readFully(all);
        }
        DvbDemux d = DvbDemux.DvbDmxSwfilter();
        d.setPidFilter();            // pass nothing: we only want the counter, and the pipe must not fill up
        Random r = new Random(1);
        int p = 0;
        while (p < all.length) {
            int n = Math.min(all.length - p, 1 + r.nextInt(5000));
            byte[] chunk = new byte[n];
            System.arraycopy(all, p, chunk, 0, n);
            d.consume(chunk, n);
            p += n;
        }
        Field fld = DvbDemux.class.getDeclaredField("droppedUsbFps");
        fld.setAccessible(true);
        System.out.println(fld.getInt(d));
        System.exit(0);
    }
}
