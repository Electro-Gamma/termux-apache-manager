package info.martinmarinov.dvbservice;

import java.io.IOException;
import java.net.InetAddress;
import java.util.EnumSet;
import java.util.Set;

import androidx.annotation.NonNull;
import info.martinmarinov.drivers.DeliverySystem;
import info.martinmarinov.drivers.DeviceFilter;
import info.martinmarinov.drivers.DvbCapabilities;
import info.martinmarinov.drivers.DvbDemux;
import info.martinmarinov.drivers.DvbDevice;
import info.martinmarinov.drivers.DvbException;
import info.martinmarinov.drivers.DvbStatus;
import info.martinmarinov.drivers.network.DvbNetworkDevice;
import info.martinmarinov.usbxfer.ByteSink;
import info.martinmarinov.usbxfer.ByteSource;

/**
 * Runs the ORIGINAL dvbservice.DvbServer (Request/Response/TransferThread/DvbDemux, unmodified) on loopback.
 *   scripted            : behind a scripted device whose answers equal dvbnetd-fake's (reference behaviour)
 *   chain HOST CP TP    : behind the new DvbNetworkDevice that talks to a dvbnetd at HOST (the real integration path)
 * Prints "PORTS <control> <transfer>" and serves exactly one client session.
 */
public class ServerHarness {
    static final boolean T2 = System.getProperty("t2") != null;

    static class ScriptedDevice extends DvbDevice {
        private volatile boolean tuned;

        ScriptedDevice() { super(DvbDemux.DvbDmxSwfilter()); }
        @Override public void open() {}
        @Override public DeviceFilter getDeviceFilter() { return new DeviceFilter(0x0bda, 0x2838, "scripted"); }
        @Override public DvbCapabilities readCapabilities() {
            Set<DeliverySystem> s = EnumSet.of(DeliverySystem.DVBT);
            if (T2) s.add(DeliverySystem.DVBT2);
            return new DvbCapabilities(174000000L, 862000000L, 166667L, s);
        }
        @Override public int readSnr() { return 215; }
        @Override public int readRfStrengthPercentage() { return tuned ? 80 : 0; }
        @Override public int readBitErrorRate() { return tuned ? 7 : 0xFFFF; }
        @Override public Set<DvbStatus> getStatus() {
            return tuned ? EnumSet.of(DvbStatus.FE_HAS_SIGNAL, DvbStatus.FE_HAS_CARRIER, DvbStatus.FE_HAS_SYNC, DvbStatus.FE_HAS_LOCK)
                         : EnumSet.noneOf(DvbStatus.class);
        }
        @Override public String getDebugString() { return "scripted"; }
        @Override protected void tuneTo(long f, long bw, @NonNull DeliverySystem sys) throws DvbException {
            if (sys == DeliverySystem.DVBT2 && !T2) throw new DvbException(DvbException.ErrorCode.CANNOT_TUNE_TO_FREQ, "no T2");
            if (sys == DeliverySystem.DVBC) throw new DvbException(DvbException.ErrorCode.CANNOT_TUNE_TO_FREQ, "no DVB-C");
            if (f < 174000000L || f > 862000000L) throw new DvbException(DvbException.ErrorCode.CANNOT_TUNE_TO_FREQ, "range");
            if (bw != 6000000L && bw != 7000000L && bw != 8000000L) throw new DvbException(DvbException.ErrorCode.UNSUPPORTED_BANDWIDTH, "bw");
            tuned = true;
        }
        @Override protected ByteSource createTsSource() {
            return new ByteSource() {
                private final int[] pids = {0x000, 0x100, 0x101, 0x1FFF};
                private final int[] cc = new int[4];
                @Override public void open() {}
                @Override public void close() {}
                @Override public void readNext(ByteSink sink) throws IOException, InterruptedException {
                    byte[] buf = new byte[188 * 16];
                    for (int i = 0; i < 16; i++) {
                        int k = i & 3, o = i * 188;
                        java.util.Arrays.fill(buf, o, o + 188, (byte) 0xAA);
                        buf[o] = 0x47;
                        buf[o + 1] = (byte) (pids[k] >> 8);
                        buf[o + 2] = (byte) pids[k];
                        buf[o + 3] = (byte) (0x10 | (cc[k]++ & 0xF));
                    }
                    sink.consume(buf, buf.length);
                    Thread.sleep(2);
                }
            };
        }
    }

    public static void main(String[] a) throws Exception {
        DvbDevice device;
        if (a[0].equals("scripted")) device = new ScriptedDevice();
        else device = new DvbNetworkDevice(a[1], Integer.parseInt(a[2]), Integer.parseInt(a[3]));

        DvbServer server = new DvbServer(device);
        DvbServerPorts ports = server.bind(InetAddress.getByName("127.0.0.1"));
        server.open();   // same order as DvbService: bind, open, tell the client, serve
        System.out.println("PORTS " + ports.getControlPort() + " " + ports.getTransferPort());
        System.out.flush();
        try {
            server.serve();
        } finally {
            server.close();
        }
    }
}
