#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-2.0-or-later
"""Functional tests of the optional recording / scheduling / playback features, using the synthetic test backend
(no hardware). Usage: test_rec.py NEW_FAKE_BINARY [ORIGINAL_FAKE_BINARY]
With the original binary it also proves that the live protocol behaves identically when the new features are unused."""
import os, shutil, signal, socket, struct, subprocess, sys, tempfile, threading, time

NEW = os.path.abspath(sys.argv[1])
ORIG = os.path.abspath(sys.argv[2]) if len(sys.argv) > 2 else None
CP, TP = 19500, 19501
results = []
def check(name, cond, detail=""):
    results.append((name, bool(cond)))
    print(("PASS  " if cond else "FAIL  ") + name + ("" if cond else "   -> " + str(detail)))

# ---------- protocol client (same wire format as the Android driver) ----------
class Ctl:
    def __init__(self, port=CP):
        self.s = socket.create_connection(("127.0.0.1", port)); self.s.settimeout(5)
    def rn(self, n):
        b = b""
        while len(b) < n:
            c = self.s.recv(n - len(b)); assert c, "EOF"; b += c
        return b
    def req(self, ordinal, *vals):
        self.s.sendall(bytes([ordinal, len(vals)]) + b"".join(struct.pack(">q", v) for v in vals))
        h = self.rn(2); return h + self.rn(h[1] * 8)
    def ok(self, raw): return struct.unpack(">q", raw[2:10])[0] == 1
    def vals(self, raw): return [struct.unpack(">q", raw[2 + 8 * i:10 + 8 * i])[0] for i in range(raw[1])]
    def close(self): self.s.close()

class Ts:
    def __init__(self, port=TP):
        self.s = socket.create_connection(("127.0.0.1", port)); self.s.settimeout(0.2)
        self.buf = bytearray(); self.pk = []; self.stop = False; self.lock = threading.Lock()
        self.t = threading.Thread(target=self.run, daemon=True); self.t.start()
    def run(self):
        while not self.stop:
            try: d = self.s.recv(65536)
            except socket.timeout: continue
            except OSError: return
            if not d: return
            now = time.time()
            with self.lock:
                self.buf += d
                n = len(self.buf) // 188 * 188
                for i in range(0, n, 188): self.pk.append((now, bytes(self.buf[i:i + 188])))
                del self.buf[:n]
    def packets(self):
        with self.lock: return list(self.pk)
    def close(self):
        self.stop = True
        try: self.s.close()
        except OSError: pass

class Daemon:
    def __init__(self, binary, args, env=None, pre=None):
        e = dict(os.environ, **(env or {}))
        cmd = [binary] + args
        if pre: cmd = pre + cmd
        self.p = subprocess.Popen(cmd, stderr=subprocess.PIPE, text=True, env=e)
        self.log = []
        threading.Thread(target=self.drain, daemon=True).start()
        for _ in range(100):
            if any("listening" in l for l in self.log): break
            time.sleep(0.05)
        time.sleep(0.2)
    def drain(self):
        for l in self.p.stderr: self.log.append(l.rstrip())
    def stop(self, sig=signal.SIGTERM):
        self.p.send_signal(sig)
        try: self.p.wait(15)
        except Exception: self.p.kill()
    def text(self): return "\n".join(self.log)

def cli(args, rec_dir, binary=NEW, timeout=30):
    r = subprocess.run([binary, "rec"] + args + ["--rec-dir", rec_dir], capture_output=True, text=True, timeout=timeout)
    return r.returncode, r.stdout + r.stderr

def ctl_raw(rec_dir, line):
    s = socket.socket(socket.AF_UNIX); s.connect(os.path.join(rec_dir, "dvbnetd.sock")); s.sendall(line.encode())
    out = b""
    while True:
        d = s.recv(4096)
        if not d: break
        out += d
    s.close(); return out.decode()

def ts_files(d): return sorted(f for f in os.listdir(d) if f.endswith(".ts"))
def info(path):
    kv = {}
    for l in open(path + ".info"):
        if "=" in l: k, v = l.rstrip("\n").split("=", 1); kv[k] = v
    return kv
def pids_of(path):
    data = open(path, "rb").read()
    return {((data[i + 1] & 0x1f) << 8) | data[i + 2] for i in range(0, len(data), 188)}, len(data)
def wait_idle(rd, secs=15):
    for _ in range(int(secs * 10)):
        rc, out = cli(["status"], rd)
        if "state: idle" in out: return True
        time.sleep(0.1)
    return False

# ======================= A. live protocol unchanged =======================
def scenario(port_c, port_t):
    T = []
    c = Ctl(port_c); x = Ts(port_t)
    T.append(("version", c.req(0))); T.append(("caps", c.req(5)))
    T.append(("tune", c.req(2, 474000000, 8000000, 0)))
    T.append(("tune bad bw", c.req(2, 474000000, 5000000, 0)))
    T.append(("tune low", c.req(2, 100000000, 8000000, 0)))
    T.append(("set_pids", c.req(4, 0x100, 0x101)))
    time.sleep(0.8); t0 = time.time(); time.sleep(0.5)
    T.append(("pids", sorted({((p[1] & 0x1f) << 8) | p[2] for (t, p) in x.packets() if t >= t0})))
    T.append(("set_pids bad", c.req(4, 0x2000)))
    T.append(("exit", c.req(1)))
    c.close(); x.close()
    return T

if ORIG:
    outs = []
    for b in (ORIG, NEW):
        d = Daemon(b, ["-b", "127.0.0.1", "-c", str(CP), "-t", str(TP)])
        outs.append(scenario(CP, TP)); d.stop()
        time.sleep(0.3)
    check("A1 live protocol transcript identical to the original binary (recording unused)", outs[0] == outs[1], (outs[0], outs[1]))

work = tempfile.mkdtemp(prefix="dvbrec_")
RD = os.path.join(work, "rec")
def start_daemon(extra=None, env=None, pre=None, rd=RD):
    return Daemon(NEW, ["-b", "127.0.0.1", "-c", str(CP), "-t", str(TP), "--rec-dir", rd, "--rec-min-free", "1"] + (extra or []), env=env, pre=pre)

# ======================= B. manual start/stop =======================
d = start_daemon()
check("B0 recording enabled message", "recording enabled" in d.text(), d.text())
rc, out = cli(["start", "--mhz", "474", "--name", "News 1"], RD)
check("B1 manual start OK", rc == 0 and "recording started" in out, out)
time.sleep(2.0)
rc, out = cli(["status"], RD)
check("B2 status shows state, file, elapsed, size", "state: recording" in out and ".ts" in out and "elapsed: 00:00:0" in out and "size:" in out, out)
rc, out = cli(["start", "--mhz", "474"], RD)
check("B3 second start refused while recording", rc != 0 and "already" in out, out)
rc, out = cli(["stop"], RD)
check("B4 stop saves the file", rc == 0 and "stopped and saved" in out, out)
fs = ts_files(RD)
check("B5 exactly one file, name has date/time/frequency/tag", len(fs) == 1 and "_474MHz_News_1.ts" in fs[0], fs)
p = os.path.join(RD, fs[0]); pids, size = pids_of(p)
check("B6 file is whole packets, has data, null packets not stored", size > 0 and size % 188 == 0 and 0x1FFF not in pids and {0, 0x100, 0x101} <= pids, (size, pids))
i = info(p)
check("B7 info file: status stopped, frequency, bytes match", i.get("status") == "stopped" and i.get("freq_hz") == "474000000" and int(i["bytes"]) == size, i)
rc, out = cli(["list"], RD)
check("B8 list shows the recording", fs[0] in out and "stopped" in out, out)
rc, out = cli(["stop"], RD)
check("B9 stop with nothing running is an error", rc != 0 and "no recording" in out, out)
# collision: same second must never overwrite
cli(["start", "--mhz", "474", "--name", "x"], RD); cli(["stop"], RD); cli(["start", "--mhz", "474", "--name", "x"], RD); cli(["stop"], RD)
fx = [f for f in ts_files(RD) if f.endswith("_x.ts") or "_x-" in f]
check("B10 no overwrite (second recording in the same second gets a new name)", len(fx) == 2 and len(set(fx)) == 2, fx)

# ======================= C. duration =======================
rc, out = cli(["start", "--mhz", "474", "--duration", "3s", "--name", "dur"], RD)
check("C1 duration start OK", rc == 0, out)
time.sleep(1.0)
rc, out = cli(["status"], RD)
check("C2 status shows time left", "ends: in 00:00:0" in out, out)
check("C3 stops by itself", wait_idle(RD, 8))
f = [x for x in ts_files(RD) if "_dur" in x][0]; i = info(os.path.join(RD, f))
check("C4 status complete / reason duration", i["status"] == "complete" and "duration" in i["reason"], i)
span = int(i["end"]) - int(i["start"])
check("C5 length is about the requested duration", 2 <= span <= 5, span)
rc, out = cli(["start", "--mhz", "474", "--duration", "abc"], RD)
check("C6 bad duration rejected", rc != 0, out)

# ======================= D. scheduled =======================
now = int(time.time())
r = ctl_raw(RD, "SCHED start=%d end=%d freq=474000000 bw=8000000 sys=0 dur=0 mode=full svc=0 pids=0 tag=sched" % (now + 3, now + 7))
check("D1 schedule accepted", r.startswith("OK") and "#" in r, r)
r2 = ctl_raw(RD, "SCHED start=%d end=%d freq=474000000 bw=8000000 sys=0 dur=0 mode=full svc=0 pids=0 tag=ov" % (now + 5, now + 9))
check("D2 overlapping schedule rejected", r2.startswith("ERR") and "overlaps" in r2, r2)
rc, out = cli(["schedules"], RD)
check("D3 schedules lists the pending job", "pending" in out and "474.000" in out, out)
time.sleep(1.0)
check("D4 not started before its time", "state: idle" in cli(["status"], RD)[1])
time.sleep(3.5)
rc, out = cli(["status"], RD)
check("D5 started automatically at the scheduled time", "state: recording" in out and "ends: in" in out, out)
check("D6 stops automatically at the end", wait_idle(RD, 8))
f = [x for x in ts_files(RD) if "_sched" in x][0]; i = info(os.path.join(RD, f)); span = int(i["end"]) - int(i["start"])
check("D7 scheduled file complete, about 4 s long", i["status"] == "complete" and 2 <= span <= 6 and "scheduled" in i["reason"], (i, span))
rc, out = cli(["schedules"], RD)
check("D8 job shown as done", "done" in out, out)
# cancel before start
now = int(time.time())
r = ctl_raw(RD, "SCHED start=%d end=%d freq=474000000 bw=8000000 sys=0 dur=0 mode=full svc=0 pids=0 tag=cancelme" % (now + 600, now + 700))
jid = r.split("#")[1].split()[0]
rc, out = cli(["cancel", jid], RD)
check("D9 cancel before start", rc == 0, out)
rc, out = cli(["schedules"], RD)
check("D10 cancelled job listed as cancelled", "cancelled" in out, out)
rc, out = cli(["cancel", jid], RD)
check("D11 cancelling twice is an error", rc != 0, out)
# CLI times: 12h and 24h, overnight, date
rc, out = cli(["schedule", "--mhz", "474", "--from", "11:00 PM", "--to", "1:00 AM", "--date", "2031-03-01", "--name", "night"], RD)
check("D12 overnight 11 PM -> 1 AM accepted", rc == 0, out)
rc, out = cli(["schedule", "--mhz", "474", "--from", "8:00 AM", "--to", "9:30 AM", "--date", "2031-03-02", "--name", "am"], RD)
check("D13 8:00 AM - 9:30 AM accepted", rc == 0, out)
rc, out = cli(["schedule", "--mhz", "474", "--from", "18:00", "--to", "19:00", "--date", "2031-03-03"], RD)
check("D14 24-hour times accepted", rc == 0, out)
rc, out = cli(["schedule", "--mhz", "474", "--from", "6pm", "--duration", "1h", "--date", "2031-03-04"], RD)
check("D15 --from with --duration accepted", rc == 0, out)
rc, out = cli(["schedules"], RD)
check("D16 overnight window ends the next day", "2031-03-01 23:00" in out and "2031-03-02 01:00" in out, out)
check("D17 12h/24h windows listed", "2031-03-02 08:00" in out and "2031-03-02 09:30" in out and "2031-03-03 18:00" in out and "2031-03-04 18:00" in out and "2031-03-04 19:00" in out, out)
rc, out = cli(["schedule", "--mhz", "474", "--from", "25:00", "--to", "7pm"], RD)
check("D18 invalid time rejected", rc != 0, out)
rc, out = cli(["schedule", "--mhz", "474", "--from", "6pm", "--to", "7pm", "--date", "2020-01-01"], RD)
check("D19 date in the past rejected", rc != 0, out)
# schedule persists over a restart
d.stop(); time.sleep(0.5)
d = start_daemon()
rc, out = cli(["schedules"], RD)
check("D20 schedule list survives a daemon restart", "2031-03-01 23:00" in out and "2031-03-04 18:00" in out, out)
# a window already open at start-up starts late
now = int(time.time())
ctl_raw(RD, "SCHED start=%d end=%d freq=474000000 bw=8000000 sys=0 dur=0 mode=full svc=0 pids=0 tag=late" % (now - 5, now + 4))
time.sleep(2.0)
check("D21 job whose window is already open starts at once (ends on time)", "state: recording" in cli(["status"], RD)[1])
check("D22 and ends at its planned time", wait_idle(RD, 8))
# schedule preempts a manual continuous recording
cli(["start", "--mhz", "474", "--name", "manual"], RD)
now = int(time.time())
ctl_raw(RD, "SCHED start=%d end=%d freq=482000000 bw=8000000 sys=0 dur=0 mode=full svc=0 pids=0 tag=prio" % (now + 2, now + 6))
time.sleep(4.5)
rc, out = cli(["status"], RD)
check("D23 scheduled recording takes priority over a manual one", "_482MHz_prio" in out and "state: recording" in out, out)
fm = [x for x in ts_files(RD) if "_manual" in x][0]
check("D24 preempted manual recording is finalised and kept", info(os.path.join(RD, fm))["status"] == "stopped", info(os.path.join(RD, fm)))
check("D25 idle afterwards", wait_idle(RD, 8))

# ======================= E. live client + recording together =======================
c = Ctl(); x = Ts()
c.req(2, 474000000, 8000000, 0); c.req(4, 0x100, 0x101)
rc, out = cli(["start", "--mhz", "482", "--name", "other"], RD)
check("E1 recording another frequency while a client is tuned is refused", rc != 0 and "in use by a connected client" in out, out)
rc, out = cli(["start", "--name", "tap"], RD)
check("E2 recording the client's multiplex (no --mhz) taps its stream", rc == 0 and "client" in out, out)
time.sleep(1.5)
before = len(x.packets()); time.sleep(0.6); after = len(x.packets())
check("E3 live client keeps receiving while recording", after > before, (before, after))
ftap = [f for f in ts_files(RD) if "_tap" in f][0]; sz1 = os.path.getsize(os.path.join(RD, ftap))
c.req(1); c.close(); x.close(); time.sleep(1.5)
sz2 = os.path.getsize(os.path.join(RD, ftap)); time.sleep(1.0); sz3 = os.path.getsize(os.path.join(RD, ftap))
check("E4 recording continues on the tuner after the client leaves", sz3 > sz2 >= sz1 > 0, (sz1, sz2, sz3))
cc = Ctl(); time.sleep(1.0)
try: cc.s.settimeout(3); gone = cc.s.recv(1) == b""
except Exception: gone = True
check("E5 a client connecting during a standalone recording is refused (closed at once)", gone and "tuner is busy recording" in d.text(), d.text()[-300:])
cli(["stop"], RD)
i = info(os.path.join(RD, ftap))
check("E6 tap recording finalised", i["status"] == "stopped" and i["source"] in ("tuner", "client-stream"), i)
time.sleep(0.5)
c = Ctl(); x = Ts()
check("E7 after the recording the live client works normally again", c.ok(c.req(2, 474000000, 8000000, 0)))
c.close(); x.close(); time.sleep(0.5)
# client retunes during a tap recording -> recording stops cleanly
c = Ctl(); x = Ts(); c.req(2, 474000000, 8000000, 0)
cli(["start", "--name", "retune"], RD); time.sleep(0.8)
c.req(2, 482000000, 8000000, 0); time.sleep(1.0)
check("E8 client retuning to another multiplex ends the tap recording safely", "state: idle" in cli(["status"], RD)[1])
fr = [f for f in ts_files(RD) if "_retune" in f][0]
check("E9 ... and the file is intact", info(os.path.join(RD, fr))["status"] == "stopped" and os.path.getsize(os.path.join(RD, fr)) % 188 == 0)
c.close(); x.close(); time.sleep(0.5)
d.stop()

# ======================= F. service / PID selection =======================
d = start_daemon(env={"FAKE_PSI": "1"})
cli(["start", "--mhz", "474", "--service", "1", "--duration", "2s", "--name", "svc1"], RD); wait_idle(RD, 8)
p = os.path.join(RD, [f for f in ts_files(RD) if "_svc1" in f][0]); pids, size = pids_of(p)
check("F1 --service 1 keeps its PMT/video/audio plus PAT, drops the other service", {0, 0x100, 0x101, 0x102} <= pids and not ({0x300, 0x301} & pids), pids)
cli(["start", "--mhz", "474", "--pids", "0x0,0x301", "--duration", "2s", "--name", "pl"], RD); wait_idle(RD, 8)
p = os.path.join(RD, [f for f in ts_files(RD) if "_pl" in f][0]); pids, size = pids_of(p)
check("F2 --pids list", 0x301 in pids and 0x300 not in pids and 0x101 not in pids, pids)
d.stop(); time.sleep(0.3)

# ======================= G. recovery after a crash =======================
d = start_daemon()
cli(["start", "--mhz", "474", "--name", "crash"], RD); time.sleep(1.5)
d.stop(signal.SIGKILL); time.sleep(0.3)
fc = [f for f in ts_files(RD) if "_crash" in f][0]; pc = os.path.join(RD, fc)
check("G1 after kill -9 the info still says recording", info(pc)["status"] == "recording")
with open(pc, "ab") as fh: fh.write(b"\x47" * 100)   # simulate a half-written packet
d = start_daemon()
check("G2 restart reports the recovery", "recovery: 1 interrupted" in d.text(), d.text())
check("G3 file trimmed to whole packets, marked interrupted", os.path.getsize(pc) % 188 == 0 and info(pc)["status"] == "interrupted", (os.path.getsize(pc), info(pc)))
rc, out = cli(["list"], RD)
check("G4 list shows interrupted", "interrupted" in out, out)
check("G5 new recording works after recovery", cli(["start", "--mhz", "474", "--duration", "2s", "--name", "after"], RD)[0] == 0 and wait_idle(RD, 8))
# graceful SIGTERM while recording finalises the file
cli(["start", "--mhz", "474", "--name", "term"], RD); time.sleep(1.2)
d.stop(); time.sleep(0.3)
pt = os.path.join(RD, [f for f in ts_files(RD) if "_term" in f][0])
check("G6 SIGTERM while recording: file finalised, status stopped", info(pt)["status"] == "stopped" and os.path.getsize(pt) % 188 == 0 and os.path.getsize(pt) > 0, info(pt))

# ======================= H. disk space and errors =======================
d = Daemon(NEW, ["-b", "127.0.0.1", "-c", str(CP), "-t", str(TP), "--rec-dir", RD, "--rec-min-free", "999999999"])
rc, out = cli(["start", "--mhz", "474"], RD)
check("H1 start refused when free space is below the reserve", rc != 0 and "not enough free disk space" in out, out)
check("H2 refused start leaves the daemon idle and usable", "state: idle" in cli(["status"], RD)[1])
d.stop(); time.sleep(0.3)
d = start_daemon(["--rec-max-size", "1"])
cli(["start", "--mhz", "474", "--name", "cap"], RD); time.sleep(0.5)
wait_idle(RD, 40)
pcap = os.path.join(RD, [f for f in ts_files(RD) if "_cap" in f][0])
check("H3 size cap stops the recording cleanly", info(pcap)["status"] == "stopped" and "size limit" in info(pcap)["reason"], info(pcap))
d.stop(); time.sleep(0.3)
# real write failure: file size limit of the process (EFBIG) behaves like a full disk
d = start_daemon(pre=["sh", "-c", 'ulimit -f 100; exec "$0" "$@"'])
cli(["start", "--mhz", "474", "--name", "full"], RD); time.sleep(2.0)
rc, out = cli(["status"], RD)
check("H4 write failure stops the recording (daemon survives)", "state: idle" in out, out)
pf = os.path.join(RD, [f for f in ts_files(RD) if "_full" in f][0])
check("H5 write failure: file kept, whole packets, status error with the reason", info(pf)["status"] == "error" and "write error" in info(pf)["reason"] and os.path.getsize(pf) % 188 == 0 and os.path.getsize(pf) > 0, info(pf))
rc, out = cli(["list"], RD)
check("H6 list shows the error reason", "write error" in out, out)
c = Ctl(); check("H7 live reception still works after a recording error", c.ok(c.req(2, 474000000, 8000000, 0))); c.close()
d.stop(); time.sleep(0.3)
rc, out = cli(["start", "--mhz", "474"], RD)
check("H8 CLI without daemon explains instead of hanging", rc != 0 and "cannot reach" in out, out)
rc, out = cli(["list"], RD)
check("H9 list works without the daemon", rc == 0 and ".ts" in out, out)
# recording off by default
d = Daemon(NEW, ["-b", "127.0.0.1", "-c", str(CP), "-t", str(TP)])
check("H10 without --rec-dir no recording code runs (no socket, nothing logged)", "recording" not in d.text(), d.text())
d.stop()
# unwritable directory: live server still starts
d = Daemon(NEW, ["-b", "127.0.0.1", "-c", str(CP), "-t", str(TP), "--rec-dir", "/proc/nonexistent/x"])
c = Ctl(); check("H11 bad --rec-dir disables recording only; live server runs", "recording disabled" in d.text() and c.ok(c.req(0)), d.text()); c.close()
d.stop()

# ======================= I. playback without a tuner =======================
def make_ts(path, seconds=3.0, kbps=2000):
    """PID 0x100 carries the PCR (every 40 ms) and a counter; PID 0x101 audio-like filler; PAT on 0."""
    out = bytearray(); cc = {0: 0, 0x100: 0, 0x101: 0}; pkts_per_iv = int(kbps * 1000 / 8 / 188 * 0.04); n_iv = int(seconds / 0.04)
    seq = 0
    for iv in range(n_iv):
        pcr = int((1000 + iv * 0.04) * 27000000) % ((1 << 33) * 300)
        base, ext = pcr // 300, pcr % 300
        for k in range(pkts_per_iv):
            pk = bytearray(b"\xff" * 188)
            if k == 0:
                pid = 0x100; pk[0:4] = bytes([0x47, 0x01, 0x00, 0x30 | cc[0x100]]); cc[0x100] = (cc[0x100] + 1) & 15
                pk[4] = 7; pk[5] = 0x10
                pk[6:12] = bytes([(base >> 25) & 255, (base >> 17) & 255, (base >> 9) & 255, (base >> 1) & 255, ((base & 1) << 7) | 0x7e | (ext >> 8), ext & 255])
            else:
                pid = 0x101 if k % 2 else 0x100
                pk[0:4] = bytes([0x47, pid >> 8, pid & 255, 0x10 | cc[pid]]); cc[pid] = (cc[pid] + 1) & 15
                pk[4:8] = struct.pack(">I", seq); seq += 1
            out += pk
    open(path, "wb").write(out)
    return len(out) // 188
PLAY = os.path.join(work, "play.ts")
npk = make_ts(PLAY)
open(PLAY + ".info", "w").write("status=complete\nfreq_hz=474000000\nbw_hz=8000000\nsystem=0\nstart=1000\nend=1003\nbytes=%d\n" % (npk * 188))
def play_session(extra, wait_s):
    d = Daemon(NEW, ["-b", "127.0.0.1", "-c", str(CP), "-t", str(TP), "-p", PLAY] + extra)
    c = Ctl(); x = Ts()
    r = {}
    r["version"] = c.req(0); caps = c.req(5); r["caps"] = c.vals(caps)
    bad = c.req(2, 482000000, 8000000, 0); r["bad_tune_ok"] = c.ok(bad)
    r["st0"] = c.vals(c.req(3))
    r["tune_ok"] = c.ok(c.req(2, 474000000, 8000000, 0))
    c.req(4, 0x100)
    t0 = time.time(); time.sleep(wait_s)
    r["st_end"] = c.vals(c.req(3)); r["pk"] = x.packets(); r["t0"] = t0; r["ctl"] = c; r["x"] = x; r["d"] = d
    return r
r = play_session([], 4.8)
check("I1 playback server starts without any tuner and says so", "PLAYBACK mode" in r["d"].text(), r["d"].text())
check("I2 protocol: version/capabilities like a live receiver (DVB-T, 174-862 MHz)", r["version"][1] == 3 and r["caps"][1] == 1 and r["caps"][2:5] == [174000000, 862000000, 166667], r["caps"])
check("I3 tuning another frequency fails like a lost channel; before the first tune status = no lock", (not r["bad_tune_ok"]) and r["st0"][8] == 0 and r["tune_ok"], (r["bad_tune_ok"], r["st0"]))
got = [p for (t, p) in r["pk"]]
want = [p for p in (open(PLAY, "rb").read()[i:i + 188] for i in range(0, npk * 188, 188)) if (((p[1] & 0x1f) << 8) | p[2]) in (0x100, 0)]
check("I4 delivers the recorded packets of the selected PID, byte for byte, in order", got == want, (len(got), len(want)))
ts_ = [t for (t, p) in r["pk"]]
span = ts_[-1] - ts_[0] if ts_ else 0
check("I5 original timing preserved (3.0 s of broadcast takes ~3 s, not an instant burst)", 2.5 <= span <= 3.6, span)
check("I6 starts from the beginning (first PCR packet first)", got and got[0][5] == 0x10, got[:1])
check("I7 end of recording: stream stops and GET_STATUS reports no lock", r["st_end"][8] == 0 and r["st_end"][2] == 0xFFFF and "end of recording" in r["d"].text(), (r["st_end"], r["d"].text()))
r["ctl"].req(1); r["ctl"].close(); r["x"].close()
# a second client starts again from the beginning
c = Ctl(); x = Ts(); c.req(2, 474000000, 8000000, 0); c.req(4, 0x100); time.sleep(1.3)
first = x.packets()
check("I8 second client gets the recording again from the beginning", first and first[0][1][5] == 0x10 and first[0][1] == want[0], first[:1])
c.close(); x.close(); r["d"].stop(); time.sleep(0.3)
r = play_session(["--loop"], 4.2)
n_pcr = sum(1 for p in [q for (t, q) in r["pk"]] if p[5] == 0x10 and (p[3] & 0x20))
check("I9 --loop restarts the recording at its end", n_pcr > 75 and r["st_end"][8] == 1, (n_pcr, r["st_end"]))
r["ctl"].close(); r["x"].close(); r["d"].stop(); time.sleep(0.3)
# play by name from the recording directory + errors
shutil.copy(PLAY, os.path.join(RD, "mine.ts")); shutil.copy(PLAY + ".info", os.path.join(RD, "mine.ts.info"))
d = Daemon(NEW, ["play", "mine", "--rec-dir", RD, "-b", "127.0.0.1", "-c", str(CP), "-t", str(TP)])
check("I10 `dvbnetd play NAME` finds the recording in the directory", "PLAYBACK mode" in d.text() and "mine.ts" in d.text(), d.text()); d.stop()
r2 = subprocess.run([NEW, "-p", "/nonexistent.ts", "-c", str(CP)], capture_output=True, text=True, timeout=10)
check("I11 missing recording: clear error, exit status 1", r2.returncode == 1 and "cannot read recording" in r2.stderr, r2.stderr)
# playback of a plain foreign .ts without .info and without PCR: any frequency tunes, constant-rate pacing
RAW = os.path.join(work, "raw.ts")
with open(RAW, "wb") as fh:
    for i in range(400): fh.write(bytes([0x47, 0x01, 0x01, 0x10 | (i & 15)]) + b"\xaa" * 184)
d = Daemon(NEW, ["-b", "127.0.0.1", "-c", str(CP), "-t", str(TP), "-p", RAW, "--play-rate", "1"])
c = Ctl(); x = Ts(); ok1 = c.ok(c.req(2, 611000000, 8000000, 0)); c.req(4, 0x101); time.sleep(0.8)
n_early = len(x.packets()); time.sleep(2.0)
check("I12 foreign .ts without PCR/.info plays at the given constant rate (no burst)", ok1 and 0 < n_early < 400 and len(x.packets()) > n_early, (ok1, n_early, len(x.packets())))
c.close(); x.close(); d.stop()
# rec-dir ignored in playback mode
d = Daemon(NEW, ["-b", "127.0.0.1", "-c", str(CP), "-t", str(TP), "-p", PLAY, "--rec-dir", RD])
check("I13 recording is disabled in playback mode", "recording is disabled in playback mode" in d.text(), d.text()); d.stop()

shutil.rmtree(work, ignore_errors=True)
bad = [n for n, ok in results if not ok]
print("\n%d checks, %d failed" % (len(results), len(bad)))
sys.exit(1 if bad else 0)
