/* SPDX-License-Identifier: GPL-2.0-or-later
 * Reads a raw 188-byte-packet TS file and prints how many packets the ported DvbDemux
 * accounting counts as dropped (TEI + continuity errors). Compared against the ORIGINAL
 * DvbDemux.java by test/java/DemuxCountCheck.java. With no argument: self-checks. */
#include "ts_stats.h"
#include <assert.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char **argv)
{
	struct ts_stats s;
	ts_stats_init(&s, 0);
	if (argc > 1) {
		FILE *f = fopen(argv[1], "rb");
		uint8_t pk[188];
		long total = 0;
		if (!f) { perror(argv[1]); return 1; }
		while (fread(pk, 1, 188, f) == 188) { if (pk[0] == 0x47) { ts_stats_packet(&s, pk); total++; } }
		printf("%d\n", s.dropped);
		fclose(f);
		return 0;
	}
	/* rate arithmetic, as DvbDemux.getDroppedUsbFps */
	s.dropped = 10; s.last_ms = 0;
	assert(ts_stats_rate(&s, 2000) == 5 && s.dropped == 0 && s.last_ms == 2000);
	s.dropped = 1; assert(ts_stats_rate(&s, 2000 + 3000) == 0);       /* 0.33/s truncates to 0 */
	s.dropped = 0; assert(ts_stats_rate(&s, 5000) == 0);              /* elapsed 0, none dropped: NaN -> 0 */
	s.dropped = 3; assert(ts_stats_rate(&s, 5000) == INT_MAX);        /* elapsed 0: Infinity -> INT_MAX */
	/* clean stream: counters 0..15 wrap without errors; pid 0x1FFF never counted */
	ts_stats_init(&s, 0);
	for (int i = 0; i < 100; i++) {
		uint8_t pk[188] = { 0x47, 0x01, 0x00, (uint8_t)(0x10 | (i & 15)) };
		ts_stats_packet(&s, pk);
	}
	assert(s.dropped == 1);   /* as in the original: a PID starts with stored counter 0 and a first packet with cc 0 counts as one error */
	puts("ts_stats self-test ok");
	return 0;
}
