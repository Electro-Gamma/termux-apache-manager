#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-2.0-or-later
"""Differential compatibility test.

Runs the same client script, byte for byte, against
  REF    the ORIGINAL AndroidDvbDriver server classes (Request/Response/DvbServer/TransferThread/DvbDemux,
         unmodified) in front of a scripted device                              [reference behaviour]
  NET    dvbnetd (test backend)                                                  [the Linux server]
  CHAIN  the original server in front of the new DvbNetworkDevice, which talks to dvbnetd
         [the real integration path: Open DVB-T Receiver -> driver app -> Pi]
and requires identical protocol transcripts. Usage: test_compat.py DVBNETD_FAKE_BINARY JAVA_CLASSES_DIR
This proves protocol compatibility; it does not prove anything about real tuner hardware."""
import os, socket, struct, subprocess, sys, time

FAKE, CLASSES = sys.argv[1], sys.argv[2]
CP, TP = 18500, 18501
_ = lambda *a: None

def spawn_java(args, props=()):
    p = subprocess.Popen(["java", *props, "-cp", CLASSES, "info.martinmarinov.dvbservice.ServerHarness", *args],
                         stdout=subprocess.PIPE, text=True)
    line = p.stdout.readline().split()
    assert line and line[0] == "PORTS", "harness did not start"
    return p, int(line[1]), int(line[2])

def spawn_net(t2):
    env = dict(os.environ, **({"FAKE_T2": "1"} if t2 else {}))
    p = subprocess.Popen([FAKE, "-b", "127.0.0.1", "-c", str(CP), "-t", str(TP)], env=env, stderr=subprocess.DEVNULL)
    time.sleep(0.3)
    return p

class Target:
    def __init__(self, kind, t2):
        self.kind, self.procs = kind, []
        props = ["-Dt2=1"] if t2 else []
        if kind == "REF":
            p, self.cp, self.tp = spawn_java(["scripted"], props); self.procs.append(p)
        elif kind == "NET":
            self.procs.append(spawn_net(t2)); self.cp, self.tp = CP, TP
        else:
            self.procs.append(spawn_net(t2))
            p, self.cp, self.tp = spawn_java(["chain", "127.0.0.1", str(CP), str(TP)]); self.procs.append(p)
    def connect(self, transfer_first):
        def c(port):
            s = socket.create_connection(("127.0.0.1", port)); s.settimeout(5); return s
        if transfer_first:
            x = c(self.tp); ctl = c(self.cp)
        else:
            ctl = c(self.cp); x = c(self.tp)
        return Ctl(ctl), Ts(x)
    def stop(self):
        for p in reversed(self.procs):
            p.terminate()
            try: p.wait(5)
            except Exception: p.kill()

class Ctl:
    def __init__(self, s): self.s = s
    def send(self, ordinal, *vals):
        self.s.sendall(bytes([ordinal, len(vals)]) + b"".join(struct.pack(">q", v) for v in vals))
    def recv_raw(self):
        h = self.rn(2); return h + self.rn(h[1] * 8)
    def rn(self, n):
        b = b""
        while len(b) < n:
            c = self.s.recv(n - len(b)); assert c, "EOF"; b += c
        return b
    def req(self, ordinal, *vals):
        self.send(ordinal, *vals); return self.recv_raw()
    def silent(self, secs=0.4):
        self.s.settimeout(secs)
        try:
            d = self.s.recv(1); return d == b""   # EOF counts as "closed"
        except socket.timeout:
            return True
        finally:
            self.s.settimeout(5)

class Ts:
    """Drains the transfer socket continuously (so stale data cannot pile up) and timestamps every packet."""
    def __init__(self, s):
        import threading
        self.s, self.buf, self.pk, self.stop = s, bytearray(), [], False
        self.lock = threading.Lock()
        s.settimeout(0.2)
        self.t = threading.Thread(target=self.run, daemon=True); self.t.start()
    def run(self):
        while not self.stop:
            try:
                d = self.s.recv(65536)
            except socket.timeout:
                continue
            except OSError:
                return
            if not d: return
            now = time.time()
            with self.lock:
                self.buf += d
                n = len(self.buf) // 188 * 188
                for i in range(0, n, 188):
                    p = bytes(self.buf[i:i+188])
                    assert p[0] == 0x47, "TS misaligned"
                    self.pk.append((now, ((p[1] & 0x1f) << 8) | p[2]))
                del self.buf[:n]
    def pids(self, flush=0.7, window=0.5):
        time.sleep(flush); t0 = time.time(); time.sleep(window)
        with self.lock:
            return sorted({pid for (t, pid) in self.pk if t >= t0})

def mask_dropped(raw):                      # header(2)+flag(8)+snr(8)+ber(8) -> dropped is the next long
    assert raw[1] == 9
    d = struct.unpack(">q", raw[26:34])[0]
    assert d >= 0
    return raw[:26] + b"\0" * 8 + raw[34:]

def scenario(c, x, t2):
    T = []
    add = lambda k, v: T.append((k, v))
    add("version", c.req(0))
    add("caps", c.req(5))
    add("status untuned", mask_dropped(c.req(3)))
    add("pids before tune/SET_PIDS", x.pids())               # original: only PID 0 until told otherwise
    add("tune ok", c.req(2, 474000000, 8000000, 0))
    add("status tuned", mask_dropped(c.req(3)))
    add("pids after tune", x.pids())
    add("tune 4 values (extra ignored)", c.req(2, 474000000, 8000000, 0, 12345))
    add("tune 2 values", c.req(2, 474000000, 8000000))
    add("tune freq too low", c.req(2, 100000000, 8000000, 0))
    add("tune bad bandwidth", c.req(2, 474000000, 5000000, 0))
    add("tune DVB-C", c.req(2, 474000000, 8000000, 2))
    add("tune system index 3", c.req(2, 474000000, 8000000, 3))
    add("tune DVB-T2", c.req(2, 474000000, 8000000, 1))
    c.req(2, 474000000, 8000000, 0)
    add("set_pids 0x100", c.req(4, 0x100))
    add("pids {0x100}", x.pids())
    add("set_pids 0x100,0x101", c.req(4, 0x100, 0x101))
    add("pids {0x100,0x101}", x.pids())
    add("tune resets filter", c.req(2, 482000000, 8000000, 0))
    add("pids after retune", x.pids())
    add("set_pids 0x1FFF", c.req(4, 0x1FFF))
    add("pids {0x1FFF}", x.pids())
    add("set_pids empty", c.req(4))
    add("pids empty", x.pids())
    add("set_pids 2^32+0x100 wraps to int", c.req(4, (1 << 32) + 0x100))
    add("pids {0x100} via wrapped value", x.pids())
    add("unknown ordinal 99 gets no reply", (c.send(99, 1, 2), c.silent())[1])
    add("works after unknown", c.req(0))
    # Invalid PIDs LAST: in the original one bad id corrupts FastIntFilter (every later SET_PIDS/TUNE then
    # throws until the device is reopened). dvbnetd rejects the same requests but keeps working: deliberate
    # deviation, see docs/PROTOCOL.md. Only the first failure response is compared.
    add("set_pids out of range", c.req(4, 0x2000))
    add("exit", c.req(1))
    add("closed after exit", c.silent(1.0))
    return T

def run(kind, t2, transfer_first):
    t = Target(kind, t2)
    try:
        c, x = t.connect(transfer_first)
        return scenario(c, x, t2)
    finally:
        t.stop(); time.sleep(0.3)

fail = 0
QUICK = os.environ.get('COMPAT_QUICK')
for t2 in ((False,) if QUICK else (False, True)):
    for tf in ((False,) if QUICK else (False, True)):
        tag = "T2=%s %s" % (t2, "transfer-first" if tf else "control-first")
        res = {k: run(k, t2, tf) for k in ("REF", "NET", "CHAIN")}
        for kind in ("NET", "CHAIN"):
            for (k1, v1), (k2, v2) in zip(res["REF"], res[kind]):
                if v1 != v2:
                    fail += 1
                    print("MISMATCH [%s] %s vs REF at '%s':\n   REF %s\n   %s %s" % (tag, kind, k1, v1, kind, v2))
        print("%-32s compared %d steps x 2 targets" % (tag, len(res["REF"])))
print("RESULT:", "ALL TRANSCRIPTS IDENTICAL" if not fail else "%d MISMATCHES" % fail)
sys.exit(1 if fail else 0)
