/* SPDX-License-Identifier: GPL-2.0-or-later
 * Unit test of the recording CLI's time parsing: 12/24-hour clocks, durations, dates, overnight windows. */
#include "rec.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

static void clk(const char *s, int h, int m) { int a = -1, b = -1; assert(rt_parse_clock(s, &a, &b) == 0); if (a != h || b != m) { printf("FAIL clock '%s' -> %d:%d (want %d:%d)\n", s, a, b, h, m); exit(1); } }
static void badclk(const char *s) { int a, b; if (rt_parse_clock(s, &a, &b) == 0) { printf("FAIL clock '%s' accepted\n", s); exit(1); } }
static void dur(const char *s, long long want) { int64_t v = -1; if (rt_parse_duration(s, &v) != 0 || v != want) { printf("FAIL duration '%s' -> %lld (want %lld)\n", s, (long long)v, want); exit(1); } }
static void baddur(const char *s) { int64_t v; if (rt_parse_duration(s, &v) == 0) { printf("FAIL duration '%s' accepted\n", s); exit(1); } }
static time_t mk(int y, int mo, int d, int h, int mi) { struct tm t = { .tm_year = y - 1900, .tm_mon = mo - 1, .tm_mday = d, .tm_hour = h, .tm_min = mi, .tm_isdst = -1 }; return mktime(&t); }

int main(void)
{
	setenv("TZ", "Africa/Casablanca", 1); tzset();
	clk("6:00 PM", 18, 0); clk("6:00PM", 18, 0); clk("6pm", 18, 0); clk("06:30 pm", 18, 30); clk("8:00 AM", 8, 0); clk("9:30 am", 9, 30);
	clk("12:00 AM", 0, 0); clk("12:30 AM", 0, 30); clk("12:00 PM", 12, 0); clk("11:00 PM", 23, 0); clk("1:00 AM", 1, 0);
	clk("18:00", 18, 0); clk("00:15", 0, 15); clk("23:59", 23, 59); clk("1800", 18, 0); clk("18", 18, 0); clk("7", 7, 0); clk("7.30", 7, 30);
	badclk("25:00"); badclk("13 PM"); badclk("0 PM"); badclk("6:60"); badclk(""); badclk("abc"); badclk("6:00:00");
	dur("30m", 1800); dur("1h", 3600); dur("2h", 7200); dur("3h", 10800); dur("1h30m", 5400); dur("2h 15m", 8100); dur("90", 5400); dur("1:30", 5400); dur("45s", 45); dur("30", 1800);
	baddur("0"); baddur("abc"); baddur("-5"); baddur("h"); baddur("");
	{
		time_t now = mk(2026, 11, 10, 17, 0), s, e;
		int y, mo, d;
		/* 6 PM - 7 PM today (it is 17:00) */
		assert(rt_resolve_window(now, 18, 0, 19, 0, 0, 0, 0, 0, &s, &e) == 0 && s == mk(2026, 11, 10, 18, 0) && e == mk(2026, 11, 10, 19, 0));
		/* 8:00 - 9:30 AM: already past today -> tomorrow */
		assert(rt_resolve_window(now, 8, 0, 9, 30, 0, 0, 0, 0, &s, &e) == 0 && s == mk(2026, 11, 11, 8, 0) && e == mk(2026, 11, 11, 9, 30));
		/* 11 PM - 1 AM overnight */
		assert(rt_resolve_window(now, 23, 0, 1, 0, 0, 0, 0, 0, &s, &e) == 0 && s == mk(2026, 11, 10, 23, 0) && e == mk(2026, 11, 11, 1, 0));
		/* explicit date overnight across a month end */
		assert(rt_resolve_window(now, 23, 0, 1, 0, 1, 2026, 11, 30, &s, &e) == 0 && s == mk(2026, 11, 30, 23, 0) && e == mk(2026, 12, 1, 1, 0));
		/* explicit date in the future */
		assert(rt_resolve_window(now, 18, 0, 19, 0, 1, 2026, 12, 25, &s, &e) == 0 && s == mk(2026, 12, 25, 18, 0));
		/* window currently open (17:30 inside 17:00-18:00 given at 17:30): next occurrence whose END is in the future = today */
		assert(rt_resolve_window(mk(2026, 11, 10, 17, 30), 17, 0, 18, 0, 0, 0, 0, 0, &s, &e) == 0 && s == mk(2026, 11, 10, 17, 0));
		/* equal clocks = 24 h */
		assert(rt_resolve_window(now, 6, 0, 6, 0, 0, 0, 0, 0, &s, &e) == 0 && e - s == 24 * 3600);
		assert(rt_parse_date("2026-11-25", now, &y, &mo, &d) == 0 && y == 2026 && mo == 11 && d == 25);
		assert(rt_parse_date("25/11/2026", now, &y, &mo, &d) == 0 && y == 2026 && mo == 11 && d == 25);
		assert(rt_parse_date("tomorrow", now, &y, &mo, &d) == 0 && d == 11);
		assert(rt_parse_date("today", now, &y, &mo, &d) == 0 && d == 10);
		assert(rt_parse_date("2026-02-31", now, &y, &mo, &d) != 0);
		assert(rt_parse_date("junk", now, &y, &mo, &d) != 0);
	}
	puts("rec_time self-test ok");
	return 0;
}
