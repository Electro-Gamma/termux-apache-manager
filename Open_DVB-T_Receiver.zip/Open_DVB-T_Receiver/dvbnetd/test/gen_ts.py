#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-2.0-or-later
"""Deterministic TS with continuity glitches, TEI packets, adaptation-only packets, PID 0x1FFF, odd and even PIDs."""
import random, sys
r = random.Random(7)
cc = {}
out = bytearray()
pids = [0, 0x11, 0x100, 0x101, 0x1abc, 0x1abd, 0x1fff, 0x0fff, 0x1000, 0x20]
for i in range(60000):
    pid = r.choice(pids)
    payload = r.random() > 0.1                # 10% adaptation-field-only packets: counter must not advance
    c = cc.get(pid, 0)
    if payload: c = (c + 1) & 15
    if r.random() < 0.01: c = r.randrange(16)  # glitch
    cc[pid] = c
    tei = 0x80 if r.random() < 0.005 else 0
    p = bytearray(188)
    p[0] = 0x47; p[1] = tei | (pid >> 8); p[2] = pid & 0xff
    p[3] = (0x10 if payload else 0x20) | c
    out += p
open(sys.argv[1], "wb").write(out)
