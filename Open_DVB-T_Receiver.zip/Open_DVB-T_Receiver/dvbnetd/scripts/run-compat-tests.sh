#!/bin/sh
# Builds the ORIGINAL AndroidDvbDriver protocol classes (+ the new network classes) against Android stubs and
# runs (1) the exact packet-accounting comparison and (2) the differential protocol test.
# Needs: java 11+ with the jdk.compiler module (or javac), python3, gcc. Usage: run-compat-tests.sh /path/to/AndroidDvbDriver-master
set -e
SRC="$1"
[ -d "$SRC/dvbservice" ] || { echo "usage: $0 /path/to/AndroidDvbDriver-master"; exit 2; }
HERE="$(cd "$(dirname "$0")/.." && pwd)"
OUT="${TMPDIR:-/tmp}/dvbjava.$$"
sh "$HERE/test/java/build.sh" "$SRC" "$OUT"
python3 "$HERE/test/gen_ts.py" "$OUT/t.ts"
C=$("$HERE/ts_stats_test" "$OUT/t.ts"); J=$(java -cp "$OUT" info.martinmarinov.drivers.DemuxCountCheck "$OUT/t.ts")
echo "dropped-packet accounting: dvbnetd=$C original DvbDemux=$J"
[ "$C" = "$J" ] || { echo "MISMATCH"; exit 1; }
python3 "$HERE/test/test_compat.py" "$HERE/dvbnetd-fake" "$OUT"
