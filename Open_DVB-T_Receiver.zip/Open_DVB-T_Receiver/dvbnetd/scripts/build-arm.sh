#!/bin/sh
# Cross-compile dvbnetd for ARMv7 (32-bit: Raspberry Pi Zero 2 W on 32-bit OS, Banana Pi M2 Zero, most Orange Pi
# on 32-bit images) and ARM64 (64-bit images). Needs: sudo apt install gcc-arm-linux-gnueabihf gcc-aarch64-linux-gnu
# Building natively on the board (`make`) is equally fine and needs no cross compiler.
set -e
cd "$(dirname "$0")/.."
build() {  # $1 compiler  $2 output
    command -v "$1" >/dev/null 2>&1 || { echo "skip: $1 not installed"; return 0; }
    make clean >/dev/null
    make CC="$1" LDFLAGS=-static dvbnetd
    mkdir -p dist && cp dvbnetd "dist/$2"
    if command -v file >/dev/null 2>&1; then file "dist/$2"; fi
}
build arm-linux-gnueabihf-gcc dvbnetd-armv7
build aarch64-linux-gnu-gcc dvbnetd-arm64
make clean >/dev/null
echo "binaries are in dist/ ; check on the board with: file dvbnetd-*  &&  uname -m   (armv7l -> armv7, aarch64 -> arm64)"
