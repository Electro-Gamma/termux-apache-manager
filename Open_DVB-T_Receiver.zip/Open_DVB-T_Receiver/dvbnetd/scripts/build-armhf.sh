#!/bin/sh
# Build a static 32-bit ARM (armhf) dvbnetd for Raspberry Pi (32-bit OS) and Banana Pi M2 Zero.
# Run on an x86 Debian/Ubuntu PC:  sudo apt install -y make gcc-arm-linux-gnueabihf
set -e
cd "$(dirname "$0")/.."
command -v arm-linux-gnueabihf-gcc >/dev/null 2>&1 || {
	echo "missing: sudo apt install -y make gcc-arm-linux-gnueabihf" >&2; exit 1; }
make clean
# env CFLAGS is kept by the Makefile (it appends its warning flags)
CFLAGS="-O2 -march=armv7-a -mfpu=vfpv3-d16 -mfloat-abi=hard" \
	make CC=arm-linux-gnueabihf-gcc LDFLAGS="-static" dvbnetd
arm-linux-gnueabihf-strip dvbnetd
mkdir -p dist && mv dvbnetd dist/dvbnetd-armhf
file dist/dvbnetd-armhf 2>/dev/null || true
echo "built dist/dvbnetd-armhf -> scp it to the board, then: sudo install -m755 dvbnetd-armhf /usr/local/bin/dvbnetd"
