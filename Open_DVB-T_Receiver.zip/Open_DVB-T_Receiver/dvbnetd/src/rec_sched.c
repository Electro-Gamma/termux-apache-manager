/* SPDX-License-Identifier: GPL-2.0-or-later
 * dvbnetd - recording scheduler (OPTIONAL). One thread, wakes once a second, uses the Raspberry Pi's local clock.
 * The list lives in <rec-dir>/schedule.txt so it survives restarts; a job whose window is still open when the daemon
 * (re)starts begins late and ends at its planned time. Windows may not overlap (one tuner). */
#define _GNU_SOURCE
#include "rec.h"
#include <errno.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

enum { J_PENDING, J_RUNNING, J_DONE, J_MISSED, J_FAILED, J_CANCELLED };
static const char *const state_name[] = { "pending", "running", "done", "missed", "failed", "cancelled" };

struct job {
	int id, state, attempts;
	time_t start, end;
	struct rec_req req;
	char note[96];
};

#define MAX_JOBS 128
static struct {
	pthread_mutex_t m;
	struct job jobs[MAX_JOBS];
	int n, next_id, running_id;
	char path[REC_PATH_MAX];
	pthread_t th;
	volatile int quit, started;
} S = { .m = PTHREAD_MUTEX_INITIALIZER, .next_id = 1 };

static void save_locked(void)
{
	char tmp[REC_PATH_MAX + 8];
	FILE *f;
	snprintf(tmp, sizeof tmp, "%s.tmp", S.path);
	f = fopen(tmp, "w");
	if (!f) return;
	for (int i = 0; i < S.n; i++) {
		struct job *j = &S.jobs[i];
		char pids[400] = "";
		int p = 0;
		for (int k = 0; k < j->req.npids && p < 380; k++) p += snprintf(pids + p, sizeof pids - (size_t)p, "%s%u", k ? "," : "", j->req.pids[k]);
		fprintf(f, "%d|%lld|%lld|%lld|%lld|%d|%d|%d|%s|%s|%d|%s\n", j->id, (long long)j->start, (long long)j->end, (long long)j->req.freq_hz,
		        (long long)j->req.bw_hz, j->req.system, j->req.mode, j->req.service_id, pids, j->req.tag, j->state, j->note);
	}
	fflush(f); fsync(fileno(f)); fclose(f);
	rename(tmp, S.path);
}

static void prune_locked(void)       /* keep the file small: drop the oldest finished jobs beyond 40 */
{
	int fin = 0;
	for (int i = 0; i < S.n; i++) if (S.jobs[i].state >= J_DONE) fin++;
	for (int i = 0; i < S.n && fin > 40;) {
		if (S.jobs[i].state >= J_DONE) { memmove(&S.jobs[i], &S.jobs[i + 1], (size_t)(S.n - i - 1) * sizeof S.jobs[0]); S.n--; fin--; }
		else i++;
	}
}

static void load(void)
{
	FILE *f = fopen(S.path, "r");
	char line[900];
	if (!f) return;
	while (fgets(line, sizeof line, f) && S.n < MAX_JOBS) {
		struct job j;
		long long st, en, fr, bw;
		char pids[400] = "", tag[64] = "", note[120] = "";
		int id, sys, mode, svc, state;
		memset(&j, 0, sizeof j);
		line[strcspn(line, "\r\n")] = 0;
		if (sscanf(line, "%d|%lld|%lld|%lld|%lld|%d|%d|%d|%399[^|]|%63[^|]|%d|%119[^\n]", &id, &st, &en, &fr, &bw, &sys, &mode, &svc, pids, tag, &state, note) < 11) {
			/* empty pids/tag/note fields shift sscanf: parse by splitting instead */
			char *f2[12]; int k = 0; char *p = line;
			f2[k++] = p;
			while (*p && k < 12) { if (*p == '|') { *p = 0; f2[k++] = p + 1; } p++; }
			if (k < 11) continue;
			id = atoi(f2[0]); st = atoll(f2[1]); en = atoll(f2[2]); fr = atoll(f2[3]); bw = atoll(f2[4]); sys = atoi(f2[5]); mode = atoi(f2[6]); svc = atoi(f2[7]);
			snprintf(pids, sizeof pids, "%s", f2[8]); snprintf(tag, sizeof tag, "%s", f2[9]); state = atoi(f2[10]); snprintf(note, sizeof note, "%s", k > 11 ? f2[11] : "");
		}
		j.id = id; j.start = (time_t)st; j.end = (time_t)en; j.req.freq_hz = fr; j.req.bw_hz = bw; j.req.system = sys; j.req.mode = mode; j.req.service_id = svc;
		snprintf(j.req.tag, sizeof j.req.tag, "%s", tag); snprintf(j.note, sizeof j.note, "%s", note);
		for (char *t = strtok(pids, ","); t && j.req.npids < 64; t = strtok(NULL, ",")) j.req.pids[j.req.npids++] = (uint16_t)atoi(t);
		j.state = state;
		if (j.state == J_RUNNING) { j.state = J_PENDING; }          /* the daemon restarted mid-recording: continue if the window is still open */
		S.jobs[S.n++] = j;
		if (id >= S.next_id) S.next_id = id + 1;
	}
	fclose(f);
}

static void fmt_time(time_t t, char *b, size_t n)
{
	struct tm tm;
	localtime_r(&t, &tm);
	strftime(b, n, "%Y-%m-%d %H:%M", &tm);
}

int sched_add(const struct rec_req *r, time_t start, time_t end, char *err, size_t errlen)
{
	int id = -1;
	time_t now = time(NULL);
	if (end <= start) { snprintf(err, errlen, "the end time must be after the start time"); return -1; }
	if (end <= now) { snprintf(err, errlen, "that time window is already over"); return -1; }
	if (end - start > 24 * 3600 * 2) { snprintf(err, errlen, "a scheduled recording may last at most 48 hours"); return -1; }
	if (r->freq_hz <= 0) { snprintf(err, errlen, "a scheduled recording needs a frequency (--mhz)"); return -1; }
	pthread_mutex_lock(&S.m);
	for (int i = 0; i < S.n; i++) {
		struct job *j = &S.jobs[i];
		if ((j->state == J_PENDING || j->state == J_RUNNING) && start < j->end && end > j->start) {
			char a[32], b[32];
			fmt_time(j->start, a, sizeof a); fmt_time(j->end, b, sizeof b);
			snprintf(err, errlen, "overlaps scheduled recording #%d (%s - %s): one tuner can only record one thing at a time", j->id, a, b);
			pthread_mutex_unlock(&S.m);
			return -1;
		}
	}
	if (S.n >= MAX_JOBS) prune_locked();
	if (S.n >= MAX_JOBS) { snprintf(err, errlen, "too many scheduled recordings"); pthread_mutex_unlock(&S.m); return -1; }
	{
		struct job *j = &S.jobs[S.n++];
		memset(j, 0, sizeof *j);
		j->id = id = S.next_id++; j->start = start; j->end = end; j->req = *r; j->state = J_PENDING;
	}
	save_locked();
	pthread_mutex_unlock(&S.m);
	return id;
}

int sched_cancel(int id, char *err, size_t errlen)
{
	int rc = -1, stop = 0;
	pthread_mutex_lock(&S.m);
	for (int i = 0; i < S.n; i++) {
		struct job *j = &S.jobs[i];
		if (j->id != id) continue;
		if (j->state == J_PENDING) { j->state = J_CANCELLED; snprintf(j->note, sizeof j->note, "cancelled by the user"); rc = 0; save_locked(); }
		else if (j->state == J_RUNNING) { stop = 1; rc = 0; }
		else snprintf(err, errlen, "#%d is already %s", id, state_name[j->state]);
		break;
	}
	if (rc < 0 && !err[0]) snprintf(err, errlen, "no scheduled recording #%d", id);
	pthread_mutex_unlock(&S.m);
	if (stop) rec_stop("user");   /* cancelling a running scheduled recording stops it; what was recorded is kept */
	return rc;
}

void sched_list_text(void (*line)(void *, const char *), void *ctx)
{
	char b[400];
	pthread_mutex_lock(&S.m);
	if (!S.n) line(ctx, "no scheduled recordings");
	else {
		snprintf(b, sizeof b, "%-4s %-16s %-16s %-9s %-10s %s", "ID", "START", "END", "MHZ", "STATE", "NOTE");
		line(ctx, b);
	}
	for (int i = 0; i < S.n; i++) {
		struct job *j = &S.jobs[i];
		char a[32], e[32];
		fmt_time(j->start, a, sizeof a); fmt_time(j->end, e, sizeof e);
		snprintf(b, sizeof b, "%-4d %-16s %-16s %-9.3f %-10s %s%s%s", j->id, a, e, (double)j->req.freq_hz / 1e6, state_name[j->state], j->note,
		         j->req.tag[0] ? (j->note[0] ? "  tag=" : "tag=") : "", j->req.tag);
		line(ctx, b);
	}
	pthread_mutex_unlock(&S.m);
}

static void on_finish(int ok, const char *reason)
{
	pthread_mutex_lock(&S.m);
	for (int i = 0; i < S.n; i++) {
		struct job *j = &S.jobs[i];
		if (j->id != S.running_id || j->state != J_RUNNING) continue;
		j->state = ok ? J_DONE : J_FAILED;
		snprintf(j->note, sizeof j->note, "%s", reason);
		save_locked();
	}
	S.running_id = 0;
	pthread_mutex_unlock(&S.m);
}

void sched_tick(time_t now)
{
	pthread_mutex_lock(&S.m);
	for (int i = 0; i < S.n; i++) {
		struct job *j = &S.jobs[i];
		char err[160] = "";
		if (j->state != J_PENDING) continue;
		if (now >= j->end) { j->state = J_MISSED; if (!j->note[0]) snprintf(j->note, sizeof j->note, "its time passed (daemon not running, or tuner busy)"); save_locked(); continue; }
		if (now < j->start) continue;
		if (S.running_id) continue;
		if (rec_active()) {   /* a manual recording holds the tuner: the schedule takes priority */
			rec_stop("preempted by a scheduled recording");
			for (int k = 0; k < 50 && rec_active(); k++) { pthread_mutex_unlock(&S.m); usleep(100000); pthread_mutex_lock(&S.m); }
			if (rec_active()) continue;
		}
		{
			struct rec_req r = j->req;
			r.end_epoch = j->end;
			S.running_id = j->id;
			pthread_mutex_unlock(&S.m);
			int rc = rec_start(&r, err, sizeof err);
			pthread_mutex_lock(&S.m);
			if (rc == 0) { j->state = J_RUNNING; j->note[0] = 0; }
			else {
				S.running_id = 0;
				snprintf(j->note, sizeof j->note, "%s", err);
				if (++j->attempts >= 5) { j->state = J_FAILED; }
			}
			save_locked();
		}
	}
	prune_locked();
	pthread_mutex_unlock(&S.m);
}

static void *sched_thread(void *a)
{
	(void)a;
	while (!S.quit) {
		sched_tick(time(NULL));
		for (int i = 0; i < 10 && !S.quit; i++) usleep(100000);
	}
	return NULL;
}

int sched_init(const char *dir)
{
	snprintf(S.path, sizeof S.path, "%s/schedule.txt", dir);
	S.n = 0; S.running_id = 0; S.quit = 0;
	load();
	rec_set_finish_hook(on_finish);
	if (pthread_create(&S.th, NULL, sched_thread, NULL) != 0) return -1;
	S.started = 1;
	return 0;
}

void sched_shutdown(void)
{
	if (!S.started) return;
	S.quit = 1;
	pthread_join(S.th, NULL);
	S.started = 0;
}
