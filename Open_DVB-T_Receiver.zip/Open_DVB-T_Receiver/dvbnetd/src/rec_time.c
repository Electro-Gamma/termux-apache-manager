/* SPDX-License-Identifier: GPL-2.0-or-later
 * dvbnetd - clock/date/duration parsing for the recording CLI. Pure functions, unit-tested (test/rec_time_test.c). */
#define _GNU_SOURCE
#include "rec.h"
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

/* "6:00 PM" "6pm" "06:00pm" "18:30" "18" "1830". Returns 0 on success. 12 AM is 00:xx, 12 PM is 12:xx. */
int rt_parse_clock(const char *s, int *hour, int *min)
{
	char b[32];
	size_t n = 0;
	int h = 0, m = 0, pm = -1, i = 0, digits = 0, colon = 0;

	for (; *s && n < sizeof b - 1; s++) if (!isspace((unsigned char)*s)) b[n++] = (char)tolower((unsigned char)*s);
	b[n] = 0;
	if (!n) return -1;
	/* AM/PM suffix */
	if (n >= 2 && (b[n - 1] == 'm') && (b[n - 2] == 'a' || b[n - 2] == 'p')) { pm = b[n - 2] == 'p'; b[n - 2] = 0; n -= 2; }
	else if (n >= 1 && (b[n - 1] == 'a' || b[n - 1] == 'p')) { pm = b[n - 1] == 'p'; b[n - 1] = 0; n -= 1; }
	if (!n) return -1;
	for (i = 0; b[i]; i++) { if (b[i] == ':' || b[i] == '.' || b[i] == 'h') colon++; else if (!isdigit((unsigned char)b[i])) return -1; else digits++; }
	if (colon > 1) return -1;
	if (colon) {
		char *p = b;
		h = (int)strtol(p, &p, 10);
		if (*p == ':' || *p == '.' || *p == 'h') p++;
		m = *p ? atoi(p) : 0;
	} else if (digits <= 2) {
		h = atoi(b);
	} else if (digits <= 4) {
		int v = atoi(b); h = v / 100; m = v % 100;
	} else return -1;
	if (m < 0 || m > 59) return -1;
	if (pm >= 0) {
		if (h < 1 || h > 12) return -1;
		if (h == 12) h = 0;
		if (pm) h += 12;
	} else if (h < 0 || h > 23) return -1;
	*hour = h; *min = m;
	return 0;
}

/* "30m" "1h" "1h30m" "2h 15m" "90" (= minutes) "1:30" (= 1 h 30 min) "45s". Result in seconds, must be > 0. */
int rt_parse_duration(const char *s, int64_t *secs)
{
	int64_t total = 0, cur = 0;
	int have = 0, any = 0;

	if (strchr(s, ':')) {
		int h, m;
		if (sscanf(s, "%d:%d", &h, &m) != 2 || h < 0 || m < 0 || m > 59) return -1;
		total = h * 3600LL + m * 60LL;
		if (total <= 0) return -1;
		*secs = total;
		return 0;
	}
	for (; *s; s++) {
		if (isspace((unsigned char)*s)) continue;
		if (isdigit((unsigned char)*s)) { cur = cur * 10 + (*s - '0'); have = 1; if (cur > 100000000) return -1; continue; }
		if (!have) return -1;
		switch (tolower((unsigned char)*s)) {
		case 'h': total += cur * 3600; break;
		case 'm': total += cur * 60; break;
		case 's': total += cur; break;
		default: return -1;
		}
		cur = 0; have = 0; any = 1;
	}
	if (have) { total += cur * 60; any = 1; }   /* bare number = minutes */
	if (!any || total <= 0) return -1;
	*secs = total;
	return 0;
}

int rt_parse_date(const char *s, time_t now, int *y, int *m, int *d)
{
	struct tm t;
	int a, b, c;

	if (!strcasecmp(s, "today") || !strcasecmp(s, "tomorrow")) {
		time_t when = now + (strcasecmp(s, "today") ? 86400 : 0);
		localtime_r(&when, &t);
	} else if (sscanf(s, "%d-%d-%d", &a, &b, &c) == 3 && a > 1900) {
		memset(&t, 0, sizeof t); t.tm_year = a - 1900; t.tm_mon = b - 1; t.tm_mday = c;
	} else if (sscanf(s, "%d/%d/%d", &a, &b, &c) == 3 && c > 1900) {   /* DD/MM/YYYY */
		memset(&t, 0, sizeof t); t.tm_year = c - 1900; t.tm_mon = b - 1; t.tm_mday = a;
	} else return -1;
	{   /* validate (rejects 2026-02-31 etc.) */
		struct tm v = t; v.tm_hour = 12; v.tm_isdst = -1;
		int yy = v.tm_year, mm = v.tm_mon, dd = v.tm_mday;
		if (mktime(&v) == (time_t)-1 || v.tm_year != yy || v.tm_mon != mm || v.tm_mday != dd) return -1;
	}
	*y = t.tm_year + 1900; *m = t.tm_mon + 1; *d = t.tm_mday;
	return 0;
}

static time_t at(int y, int mo, int d, int h, int mi)
{
	struct tm t;
	memset(&t, 0, sizeof t);
	t.tm_year = y - 1900; t.tm_mon = mo - 1; t.tm_mday = d; t.tm_hour = h; t.tm_min = mi; t.tm_isdst = -1;
	return mktime(&t);
}

/* The end is the first occurrence of eh:em after the start, so 23:00 -> 01:00 ends the next day and 6 PM -> 6 PM is 24 h. */
int rt_resolve_window(time_t now, int sh, int sm, int eh, int em, int date_given, int y, int mo, int d, time_t *start, time_t *end)
{
	struct tm t;
	time_t s, e;
	int day;

	if (!date_given) { localtime_r(&now, &t); y = t.tm_year + 1900; mo = t.tm_mon + 1; d = t.tm_mday; }
	for (day = 0; day < 2; day++) {
		struct tm base;
		memset(&base, 0, sizeof base); base.tm_year = y - 1900; base.tm_mon = mo - 1; base.tm_mday = d + day; base.tm_hour = 12; base.tm_isdst = -1;
		mktime(&base);
		s = at(base.tm_year + 1900, base.tm_mon + 1, base.tm_mday, sh, sm);
		e = at(base.tm_year + 1900, base.tm_mon + 1, base.tm_mday, eh, em);
		if (e <= s) {   /* overnight (or equal clocks = 24 h) */
			struct tm nx = base; nx.tm_mday += 1; nx.tm_isdst = -1; mktime(&nx);
			e = at(nx.tm_year + 1900, nx.tm_mon + 1, nx.tm_mday, eh, em);
		}
		if (s == (time_t)-1 || e == (time_t)-1) return -1;
		if (date_given || e > now) { *start = s; *end = e; return 0; }
	}
	return -1;
}
