/* SPDX-License-Identifier: GPL-2.0-or-later
 * dvbnetd - Linux DVB API backend (frontend / demux0 / dvr0).
 * Uses only the stable kernel uAPI (linux/dvb/frontend.h, dmx.h). All
 * demodulator and tuner work is done by the in-kernel drivers, e.g. rtl2832
 * + r820t/e4000/fc0012/... via dvb_usb_rtl28xxu. */
#include "backend.h"
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <linux/dvb/frontend.h>
#include <linux/dvb/dmx.h>

static int fe_fd = -1, dmx_fd = -1, dvr = -1;
static int cur_adapter, cur_frontend;
static int64_t prev_err, prev_tot;     /* BER window baseline (cumulative kernel counters) */
static int64_t last_ber = 0xFFFF;

static int xioctl(int fd, unsigned long req, void *arg)
{
	int r;
	do r = ioctl(fd, req, arg); while (r < 0 && errno == EINTR);
	return r;
}

static int be_open(int adapter, int frontend, int dvr_buf)
{
	prev_err = prev_tot = 0; last_ber = 0xFFFF;
	char p[96];
	struct dmx_pes_filter_params f;

	cur_adapter = adapter;
	cur_frontend = frontend;
	snprintf(p, sizeof p, "/dev/dvb/adapter%d/frontend%d", adapter, frontend);
	fe_fd = open(p, O_RDWR | O_CLOEXEC);
	if (fe_fd < 0) { perror(p); goto fail; }
	snprintf(p, sizeof p, "/dev/dvb/adapter%d/demux0", adapter);
	dmx_fd = open(p, O_RDWR | O_CLOEXEC);
	if (dmx_fd < 0) { perror(p); goto fail; }
	snprintf(p, sizeof p, "/dev/dvb/adapter%d/dvr0", adapter);
	dvr = open(p, O_RDONLY | O_NONBLOCK | O_CLOEXEC);
	if (dvr < 0) { perror(p); goto fail; }

	if (dvr_buf > 0 && xioctl(dvr, DMX_SET_BUFFER_SIZE, (void *)(long)dvr_buf) < 0)
		perror("DMX_SET_BUFFER_SIZE (continuing with kernel default)");

	/* Whole transport stream (pid 0x2000) to dvr0; PID filtering happens in
	 * userspace, so SET_PIDS has no count limit and works on every adapter. */
	memset(&f, 0, sizeof f);
	f.pid = 0x2000;
	f.input = DMX_IN_FRONTEND;
	f.output = DMX_OUT_TS_TAP;
	f.pes_type = DMX_PES_OTHER;
	f.flags = DMX_IMMEDIATE_START;
	if (xioctl(dmx_fd, DMX_SET_PES_FILTER, &f) < 0) { perror("DMX_SET_PES_FILTER"); goto fail; }
	return 0;
fail:
	if (fe_fd >= 0) close(fe_fd);
	if (dmx_fd >= 0) close(dmx_fd);
	if (dvr >= 0) close(dvr);
	fe_fd = dmx_fd = dvr = -1;
	return -1;
}

static void be_close(void)
{
	if (dmx_fd >= 0) { xioctl(dmx_fd, DMX_STOP, NULL); close(dmx_fd); }
	if (dvr >= 0) close(dvr);
	if (fe_fd >= 0) close(fe_fd);
	fe_fd = dmx_fd = dvr = -1;
}

static int enum_delsys(uint32_t *sys, int max)
{
	struct dtv_property p;
	struct dtv_properties ps = { .num = 1, .props = &p };
	int n;

	memset(&p, 0, sizeof p);
	p.cmd = DTV_ENUM_DELSYS;
	if (xioctl(fe_fd, FE_GET_PROPERTY, &ps) < 0) return -1;
	n = p.u.buffer.len < (unsigned)max ? (int)p.u.buffer.len : max;
	for (int i = 0; i < n; i++) sys[i] = p.u.buffer.data[i];
	return n;
}

/* Walk up from /sys/class/dvb/dvbA.frontendF/device to the USB device node. */
static void usb_ids(int64_t *vid, int64_t *pid)
{
	char link[PATH_MAX], real[PATH_MAX], f[PATH_MAX + 32];

	*vid = *pid = 0;
	snprintf(link, sizeof link, "/sys/class/dvb/dvb%d.frontend%d/device", cur_adapter, cur_frontend);
	if (!realpath(link, real)) return;
	for (int depth = 0; depth < 6; depth++) {
		FILE *fp;
		snprintf(f, sizeof f, "%s/idVendor", real);
		fp = fopen(f, "r");
		if (fp) {
			unsigned v = 0, p = 0;
			if (fscanf(fp, "%x", &v) == 1) *vid = v;
			fclose(fp);
			snprintf(f, sizeof f, "%s/idProduct", real);
			fp = fopen(f, "r");
			if (fp) { if (fscanf(fp, "%x", &p) == 1) *pid = p; fclose(fp); }
			return;
		}
		char *s = strrchr(real, '/');
		if (!s || s == real) return;
		*s = 0;
	}
}

static int be_caps(struct be_caps *c)
{
	struct dvb_frontend_info info;
	uint32_t sys[16];
	int n;

	memset(c, 0, sizeof *c);
	if (xioctl(fe_fd, FE_GET_INFO, &info) < 0) return -1;
	n = enum_delsys(sys, 16);
	if (n < 0) return -1;
	for (int i = 0; i < n; i++) {
		if (sys[i] == SYS_DVBT)  c->system_mask |= 1 << WSYS_T;
		if (sys[i] == SYS_DVBT2) c->system_mask |= 1 << WSYS_T2;
		/* DVB-C is deliberately not advertised: no symbol-rate/annex handling here. */
	}
	c->freq_min = info.frequency_min;   /* Hz for terrestrial frontends */
	c->freq_max = info.frequency_max;
	c->freq_step = info.frequency_stepsize;
	usb_ids(&c->vendor_id, &c->product_id);
	return 0;
}

static int be_tune(int64_t freq, int64_t bw, int system)
{
	uint32_t want, sys[16];
	struct dtv_property p[14];
	struct dtv_properties ps;
	int n, ok = 0, k = 0;

	if (system == WSYS_T) want = SYS_DVBT;
	else if (system == WSYS_T2) want = SYS_DVBT2;
	else { fprintf(stderr, "tune: delivery system %d not supported by server\n", system); return -1; }

	n = enum_delsys(sys, 16);
	for (int i = 0; i < n; i++) if (sys[i] == want) ok = 1;
	if (!ok) { fprintf(stderr, "tune: frontend lacks delivery system %d\n", system); return -1; }
	if (freq <= 0 || freq > (int64_t)UINT32_MAX || bw <= 0 || bw > (int64_t)UINT32_MAX) return -1;

	memset(p, 0, sizeof p);
#define PROP(c, v) do { p[k].cmd = (c); p[k].u.data = (v); k++; } while (0)
	PROP(DTV_CLEAR, 0);
	PROP(DTV_DELIVERY_SYSTEM, want);
	PROP(DTV_FREQUENCY, (uint32_t)freq);
	PROP(DTV_BANDWIDTH_HZ, (uint32_t)bw);
	PROP(DTV_INVERSION, INVERSION_AUTO);
	PROP(DTV_MODULATION, QAM_AUTO);
	PROP(DTV_CODE_RATE_HP, FEC_AUTO);
	PROP(DTV_CODE_RATE_LP, FEC_AUTO);
	PROP(DTV_TRANSMISSION_MODE, TRANSMISSION_MODE_AUTO);
	PROP(DTV_GUARD_INTERVAL, GUARD_INTERVAL_AUTO);
	PROP(DTV_HIERARCHY, HIERARCHY_AUTO);
	if (want == SYS_DVBT2) PROP(DTV_STREAM_ID, NO_STREAM_ID_FILTER);
	PROP(DTV_TUNE, 0);
#undef PROP
	ps.num = k;
	ps.props = p;
	if (xioctl(fe_fd, FE_SET_PROPERTY, &ps) < 0) { perror("FE_SET_PROPERTY"); return -1; }
	prev_err = prev_tot = 0; last_ber = 0xFFFF;
	/* drop data buffered from the previous channel */
	xioctl(dmx_fd, DMX_STOP, NULL);
	xioctl(dmx_fd, DMX_START, NULL);
	return 0;
}

static int stat_scale(const struct dtv_property *p, int scale)
{
	return p->u.st.len > 0 && p->u.st.stat[0].scale == scale;
}

static int be_status(struct be_status *s)
{
	fe_status_t st = 0;
	struct dtv_property p[4];
	struct dtv_properties ps = { .num = 4, .props = p };
	int have_stats;

	memset(s, 0, sizeof *s);
	s->ber = 0xFFFF;
	if (xioctl(fe_fd, FE_READ_STATUS, &st) < 0) return -1;
	s->has_signal = !!(st & FE_HAS_SIGNAL);
	s->has_carrier = !!(st & FE_HAS_CARRIER);
	s->has_sync = !!(st & FE_HAS_SYNC);
	s->has_lock = !!(st & FE_HAS_LOCK);

	memset(p, 0, sizeof p);
	p[0].cmd = DTV_STAT_CNR;
	p[1].cmd = DTV_STAT_SIGNAL_STRENGTH;
	p[2].cmd = DTV_STAT_POST_ERROR_BIT_COUNT;
	p[3].cmd = DTV_STAT_POST_TOTAL_BIT_COUNT;
	have_stats = xioctl(fe_fd, FE_GET_PROPERTY, &ps) == 0;

	/* SNR: AndroidDvbDriver unit is 0.1 dB. Kernel CNR is 0.001 dB. Not reported -> 0. */
	if (have_stats && stat_scale(&p[0], FE_SCALE_DECIBEL))
		s->snr = p[0].u.st.stat[0].svalue / 100;

	/* RF strength: AndroidDvbDriver unit is 0..100 %, 0 without signal. */
	if (s->has_signal) {
		if (have_stats && stat_scale(&p[1], FE_SCALE_RELATIVE)) {
			s->rf_percent = (int64_t)p[1].u.st.stat[0].uvalue * 100 / 65535;
		} else if (have_stats && stat_scale(&p[1], FE_SCALE_DECIBEL)) {
			/* No percentage exists for dBm; linear -90..-30 dBm -> 0..100 (heuristic) */
			int64_t dbm = p[1].u.st.stat[0].svalue / 1000;
			s->rf_percent = dbm <= -90 ? 0 : dbm >= -30 ? 100 : (dbm + 90) * 100 / 60;
		} else {
			uint16_t v = 0;
			if (xioctl(fe_fd, FE_READ_SIGNAL_STRENGTH, &v) == 0) s->rf_percent = (int64_t)v * 100 / 65535;
		}
	}

	/* BER: 0..0xFFFF scale (error ratio * 0xFFFF) as AF9033/Si2168 report; 0xFFFF without lock
	 * or when the kernel driver exposes no bit-error counters. Ratio is taken between two polls. */
	if (s->has_lock && have_stats &&
	    stat_scale(&p[2], FE_SCALE_COUNTER) && stat_scale(&p[3], FE_SCALE_COUNTER)) {
		int64_t err = (int64_t)p[2].u.st.stat[0].uvalue, tot = (int64_t)p[3].u.st.stat[0].uvalue;
		if (tot < prev_tot || err < prev_err) { prev_err = prev_tot = 0; }
		if (tot > prev_tot) {
			int64_t r = (err - prev_err) * 0xFFFFLL / (tot - prev_tot);
			last_ber = r > 0xFFFF ? 0xFFFF : r;
			prev_err = err; prev_tot = tot;
		}
		s->ber = last_ber;
	}
	return 0;
}

static int be_dvr_fd(void) { return dvr; }

const struct backend backend_live = {
	be_open, be_close, be_caps, be_tune, be_status, be_dvr_fd,
};
