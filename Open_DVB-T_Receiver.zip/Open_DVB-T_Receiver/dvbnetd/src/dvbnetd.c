/* SPDX-License-Identifier: GPL-2.0-or-later
 *
 * dvbnetd - network server for a Linux DVB-T/T2 adapter that speaks the exact
 * control + transfer protocol of the Android "DVB-T Driver"
 * (AndroidDvbDriver, Signalware Ltd, GPL-2.0-or-later).
 *
 * Behaviour below mirrors these files of AndroidDvbDriver:
 *   dvbservice/.../Request.java    request parsing, command semantics, error handling
 *   dvbservice/.../Response.java   response framing
 *   dvbservice/.../DvbServer.java  connection sequence (control first, then transfer, 60 s timeouts)
 *   dvbservice/.../TransferThread.java  raw TS on the transfer socket
 *   drivers/.../DvbDemux.java      PID filter reset to {0} on tune / stream start, drop accounting
 *   drivers/.../DvbDevice.java     tune() = tuneTo() then demux.reset()
 * See docs/PROTOCOL.md for the verified facts and every deviation.
 */
#define _GNU_SOURCE
#include "backend.h"
#include "ts_stats.h"
#include <arpa/inet.h>
#include <errno.h>
#include <getopt.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <poll.h>
#include <pthread.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

#define TS_LEN 188
#define ACCEPT_TIMEOUT_MS (60 * 1000)   /* DvbServer.SOCKET_TIMEOUT_MS */
/* Request enum order is part of the wire protocol. */
enum { REQ_PROTOCOL_VERSION, REQ_EXIT, REQ_TUNE, REQ_GET_STATUS, REQ_SET_PIDS, REQ_GET_CAPABILITIES, NUM_REQUESTS };

static volatile sig_atomic_t g_quit;
static int g_verbose;

struct cfg {
	const char *bind_addr;
	int ctl_port, xfer_port, adapter, frontend;
	int dvr_buf;      /* kernel dvr0 buffer, bytes */
	int pending_max;  /* userspace backlog per client before dropping, bytes */
};

/* DvbDemux equivalent: PID filter + integrity statistics, shared by both threads. */
struct demux {
	pthread_mutex_t lock;
	uint8_t pass[8192];
	struct ts_stats st;
};

struct session {
	int ctl, lt;                  /* control socket, transfer listener */
	struct in_addr peer;          /* transfer client must come from the control client's address */
	const struct cfg *cfg;
	volatile int stop;
	struct demux dmx;
	unsigned long long sent, dropped_pkts;
};

#define LOG(...) do { fprintf(stderr, __VA_ARGS__); fputc('\n', stderr); } while (0)
#define VLOG(...) do { if (g_verbose) LOG(__VA_ARGS__); } while (0)

/* DvbDemux.reset(): by default only PID 0 passes; statistics restart. CC state is kept. */
static void demux_reset(struct demux *d)
{
	pthread_mutex_lock(&d->lock);
	memset(d->pass, 0, sizeof d->pass);
	d->pass[0] = 1;
	ts_stats_reset(&d->st, ts_now_ms());
	pthread_mutex_unlock(&d->lock);
}

static void put64(uint8_t *b, int64_t v)
{
	for (int i = 0; i < 8; i++) b[i] = (uint8_t)((uint64_t)v >> (56 - 8 * i));
}
static int64_t get64(const uint8_t *b)
{
	uint64_t r = 0;
	for (int i = 0; i < 8; i++) r = (r << 8) | b[i];
	return (int64_t)r;
}

static int send_all(int fd, const void *buf, size_t len)
{
	const uint8_t *p = buf;
	while (len) {
		ssize_t n = send(fd, p, len, MSG_NOSIGNAL);
		if (n < 0) { if (errno == EINTR) continue; return -1; }
		p += n; len -= (size_t)n;
	}
	return 0;
}

/* Response.serialize: [ordinal][payload.length + 1][success][payload...]; an error carries no payload. */
static int respond(int fd, int ordinal, int ok, const int64_t *v, int n)
{
	uint8_t out[2 + 8 * 16];
	int cnt = ok ? n + 1 : 1;

	out[0] = (uint8_t)ordinal;
	out[1] = (uint8_t)cnt;
	put64(out + 2, ok ? 1 : 0);
	for (int i = 0; ok && i < n; i++) put64(out + 10 + 8 * i, v[i]);
	return send_all(fd, out, (size_t)(2 + 8 * cnt));
}

/* ---- worker: accept transfer socket (60 s), then dvr0 -> PID filter -> socket ---- */
static int accept_transfer(struct session *s)
{
	int waited = 0;

	while (!s->stop && !g_quit && waited < ACCEPT_TIMEOUT_MS) {
		struct pollfd pf = { .fd = s->lt, .events = POLLIN };
		int r = poll(&pf, 1, 100);
		if (r < 0) { if (errno == EINTR) continue; return -1; }
		if (r == 0) { waited += 100; continue; }
		struct sockaddr_in a;
		socklen_t l = sizeof a;
		int fd = accept4(s->lt, (struct sockaddr *)&a, &l, SOCK_CLOEXEC);
		if (fd < 0) continue;
		if (a.sin_addr.s_addr != s->peer.s_addr) { LOG("transfer connection from unexpected address rejected"); close(fd); continue; }
		return fd;
	}
	if (!s->stop && !g_quit) LOG("no transfer connection within %d s", ACCEPT_TIMEOUT_MS / 1000);
	return -1;
}

static void *stream_thread(void *arg)
{
	struct session *s = arg;
	const size_t cap = (size_t)s->cfg->pending_max / TS_LEN * TS_LEN;
	uint8_t rbuf[TS_LEN * 348];
	uint8_t *pend = malloc(cap);
	size_t poff = 0, plen = 0, rlen = 0;
	int dvr = backend_impl.dvr_fd();
	int xfer = accept_transfer(s);

	if (xfer < 0 || !pend) goto out;
	{
		int one = 1, idle = 30, intvl = 10, cnt = 3, sndbuf = 256 * 1024;
		setsockopt(xfer, IPPROTO_TCP, TCP_NODELAY, &one, sizeof one);
		setsockopt(xfer, SOL_SOCKET, SO_KEEPALIVE, &one, sizeof one);
		setsockopt(xfer, IPPROTO_TCP, TCP_KEEPIDLE, &idle, sizeof idle);
		setsockopt(xfer, IPPROTO_TCP, TCP_KEEPINTVL, &intvl, sizeof intvl);
		setsockopt(xfer, IPPROTO_TCP, TCP_KEEPCNT, &cnt, sizeof cnt);
		setsockopt(xfer, SOL_SOCKET, SO_SNDBUF, &sndbuf, sizeof sndbuf);
	}
	/* drop whatever the kernel buffered before this client started streaming */
	for (int i = 0; i < 4096; i++) { if (read(dvr, rbuf, sizeof rbuf) <= 0) break; }
	/* DataPump.run() calls dvbDemux.reset() when streaming starts, which also wipes the PID filter. We only
	 * restart the statistics: wiping the filter here would race with a client (or with the Android driver
	 * in network mode) that already sent SET_PIDS on the control socket. Deliberate deviation, PROTOCOL.md. */
	pthread_mutex_lock(&s->dmx.lock);
	ts_stats_reset(&s->dmx.st, ts_now_ms());
	pthread_mutex_unlock(&s->dmx.lock);

	while (!s->stop && !g_quit) {
		struct pollfd pf[2] = {
			{ .fd = dvr, .events = POLLIN },
			{ .fd = xfer, .events = (short)((plen ? POLLOUT : 0) | POLLRDHUP) },
		};
		int r = poll(pf, 2, 200);
		if (r < 0) { if (errno == EINTR) continue; break; }
		if (pf[1].revents & (POLLERR | POLLHUP | POLLRDHUP)) { VLOG("transfer socket closed by peer"); break; }
		if (pf[1].revents & POLLIN) {
			char c;
			if (recv(xfer, &c, 1, MSG_DONTWAIT) == 0) break;
		}
		if (plen && (pf[1].revents & POLLOUT)) {
			ssize_t n = send(xfer, pend + poff, plen, MSG_DONTWAIT | MSG_NOSIGNAL);
			if (n > 0) { poff += (size_t)n; plen -= (size_t)n; s->sent += (unsigned long long)n; if (!plen) poff = 0; }
			else if (n < 0 && errno != EAGAIN && errno != EINTR) break;
		}
		if (!(pf[0].revents & POLLIN)) continue;

		ssize_t n = read(dvr, rbuf + rlen, sizeof rbuf - rlen);
		if (n < 0) {
			if (errno == EOVERFLOW) { VLOG("dvr0 buffer overflow (data lost; shows up in droppedUsbFps)"); continue; }
			if (errno == EAGAIN || errno == EINTR) continue;
			LOG("dvr read: %s", strerror(errno));
			break;
		}
		rlen += (size_t)n;
		size_t npk = rlen / TS_LEN;

		pthread_mutex_lock(&s->dmx.lock);
		for (size_t i = 0; i < npk; i++) {
			const uint8_t *pk = rbuf + i * TS_LEN;
			if (pk[0] != 0x47) continue;              /* unsynchronised data is skipped */
			unsigned pid = (unsigned)(((pk[1] & 0x1f) << 8) | pk[2]);
			ts_stats_packet(&s->dmx.st, pk);          /* counted before filtering, as in DvbDemux */
			if (!s->dmx.pass[pid]) continue;
			if (poff + plen + TS_LEN > cap) {
				if (plen && poff) { memmove(pend, pend + poff, plen); poff = 0; }
				if (plen + TS_LEN > cap) { s->dropped_pkts++; continue; } /* slow client: drop, never block the tuner */
			}
			memcpy(pend + poff + plen, pk, TS_LEN);
			plen += TS_LEN;
		}
		pthread_mutex_unlock(&s->dmx.lock);
		rlen -= npk * TS_LEN;
		if (rlen) memmove(rbuf, rbuf + npk * TS_LEN, rlen);

		if (plen) {
			ssize_t w = send(xfer, pend + poff, plen, MSG_DONTWAIT | MSG_NOSIGNAL);
			if (w > 0) { poff += (size_t)w; plen -= (size_t)w; s->sent += (unsigned long long)w; if (!plen) poff = 0; }
			else if (w < 0 && errno != EAGAIN && errno != EINTR) break;
		}
	}
out:
	if (xfer >= 0) close(xfer);
	free(pend);
	s->stop = 1;
	return NULL;
}

/* ---- control loop (Request.parseAndExecute) ---- */
static int read_exact(struct session *s, uint8_t *b, size_t len)
{
	size_t got = 0;
	while (got < len) {
		struct pollfd pf = { .fd = s->ctl, .events = POLLIN };
		int r = poll(&pf, 1, 100);
		if (s->stop || g_quit) return -1;
		if (r < 0) { if (errno == EINTR) continue; return -1; }
		if (r == 0) continue;
		ssize_t n = recv(s->ctl, b + got, len - got, 0);
		if (n == 0) return -1;
		if (n < 0) { if (errno == EINTR || errno == EAGAIN) continue; return -1; }
		got += (size_t)n;
	}
	return 0;
}

static void control_loop(struct session *s)
{
	uint8_t hdr[2], body[255 * 8];

	for (;;) {
		int64_t arg[255], out[8];
		int ord, n, ok = 1, nout = 0;

		if (read_exact(s, hdr, 2) < 0) return;
		ord = hdr[0]; n = hdr[1];
		if (n && read_exact(s, body, (size_t)n * 8) < 0) return;
		for (int i = 0; i < n; i++) arg[i] = get64(body + 8 * i);

		if (ord >= NUM_REQUESTS) {
			/* Request.parseAndExecute: unknown ordinal -> payload consumed, NO response is sent. */
			VLOG("unknown request %d ignored (no response, as the Android driver does)", ord);
			continue;
		}
		switch (ord) {
		case REQ_PROTOCOL_VERSION:
			out[0] = 0; out[1] = NUM_REQUESTS; nout = 2;
			break;
		case REQ_EXIT:
			respond(s->ctl, ord, 1, NULL, 0);
			return;
		case REQ_TUNE:
			/* payload[0..2]; fewer values -> ArrayIndexOutOfBounds -> error; extra values ignored */
			if (n < 3 || arg[2] < 0 || arg[2] > WSYS_C) { ok = 0; break; }
			VLOG("TUNE %lld Hz bw %lld Hz sys %lld", (long long)arg[0], (long long)arg[1], (long long)arg[2]);
			ok = backend_impl.tune(arg[0], arg[1], (int)arg[2]) == 0;
			if (ok) demux_reset(&s->dmx);   /* DvbDevice.tune(): reset only after a successful tuneTo */
			break;
		case REQ_GET_STATUS: {
			struct be_status st;
			int dropped;
			if (backend_impl.status(&st) < 0) { ok = 0; break; }
			pthread_mutex_lock(&s->dmx.lock);
			dropped = ts_stats_rate(&s->dmx.st, ts_now_ms());
			pthread_mutex_unlock(&s->dmx.lock);
			out[0] = st.snr; out[1] = st.ber; out[2] = dropped; out[3] = st.rf_percent;
			out[4] = st.has_signal; out[5] = st.has_carrier; out[6] = st.has_sync; out[7] = st.has_lock;
			nout = 8;
			break;
		}
		case REQ_SET_PIDS: {
			/* (int) cast as in Request.java; FastIntFilter(0x1fff) throws for ids outside 0..0x1FFF -> error */
			static uint8_t np[8192];
			memset(np, 0, sizeof np);
			for (int i = 0; i < n && ok; i++) {
				int32_t pid = (int32_t)arg[i];
				if (pid < 0 || pid > 0x1FFF) ok = 0; else np[pid] = 1;
			}
			if (!ok) break;       /* filter left unchanged (the original leaves it half-updated; see PROTOCOL.md) */
			pthread_mutex_lock(&s->dmx.lock);
			memcpy(s->dmx.pass, np, sizeof np);   /* an empty list passes nothing (FastIntFilter semantics) */
			pthread_mutex_unlock(&s->dmx.lock);
			VLOG("SET_PIDS count=%d", n);
			break;
		}
		case REQ_GET_CAPABILITIES: {
			struct be_caps c;
			if (backend_impl.caps(&c) < 0) { ok = 0; break; }
			out[0] = c.system_mask; out[1] = c.freq_min; out[2] = c.freq_max;
			out[3] = c.freq_step; out[4] = c.vendor_id; out[5] = c.product_id;
			nout = 6;
			break;
		}
		}
		if (respond(s->ctl, ord, ok, out, nout) < 0) return;
	}
}

static void tune_ctl_socket(int fd)
{
	int one = 1, idle = 30, intvl = 10, cnt = 3;
	setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &one, sizeof one);   /* DvbServer: control.setTcpNoDelay(true) */
	setsockopt(fd, SOL_SOCKET, SO_KEEPALIVE, &one, sizeof one);
	setsockopt(fd, IPPROTO_TCP, TCP_KEEPIDLE, &idle, sizeof idle);
	setsockopt(fd, IPPROTO_TCP, TCP_KEEPINTVL, &intvl, sizeof intvl);
	setsockopt(fd, IPPROTO_TCP, TCP_KEEPCNT, &cnt, sizeof cnt);
}

/* DvbServer.serve(): control accepted first; the transfer socket is accepted by the worker meanwhile,
 * and control commands are served immediately. */
static void run_session(const struct cfg *cfg, int ctl, int lt, struct in_addr peer)
{
	struct session s;
	pthread_t th;

	memset(&s, 0, sizeof s);
	s.ctl = ctl; s.lt = lt; s.peer = peer; s.cfg = cfg;
	pthread_mutex_init(&s.dmx.lock, NULL);
	ts_stats_init(&s.dmx.st, ts_now_ms());
	s.dmx.pass[0] = 1;
	tune_ctl_socket(ctl);

	if (backend_impl.open(cfg->adapter, cfg->frontend, cfg->dvr_buf) < 0) {
		LOG("cannot open DVB adapter %d frontend %d", cfg->adapter, cfg->frontend);
		goto done;
	}
	if (pthread_create(&th, NULL, stream_thread, &s) != 0) { backend_impl.close(); goto done; }
	control_loop(&s);
	s.stop = 1;
	pthread_join(th, NULL);
	backend_impl.close();
	LOG("session ended: %llu bytes sent, %llu packets dropped (slow client)", s.sent, s.dropped_pkts);
done:
	pthread_mutex_destroy(&s.dmx.lock);
}

static int listen_on(const char *addr, int port)
{
	struct sockaddr_in a;
	int fd = socket(AF_INET, SOCK_STREAM | SOCK_CLOEXEC, 0), one = 1;

	if (fd < 0) return -1;
	setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof one);
	memset(&a, 0, sizeof a);
	a.sin_family = AF_INET;
	a.sin_port = htons((uint16_t)port);
	if (inet_pton(AF_INET, addr, &a.sin_addr) != 1) { LOG("bad bind address %s", addr); close(fd); return -1; }
	if (bind(fd, (struct sockaddr *)&a, sizeof a) < 0 || listen(fd, 4) < 0) {
		LOG("port %d: %s", port, strerror(errno)); close(fd); return -1;
	}
	return fd;
}

static void on_sig(int sig) { (void)sig; g_quit = 1; }

static void usage(const char *p)
{
	fprintf(stderr,
	"Usage: %s [options]\n"
	"  -b, --bind ADDR        IPv4 address to listen on (default 0.0.0.0)\n"
	"  -c, --control-port N   control port  (default 7500)\n"
	"  -t, --transfer-port N  TS port       (default 7501)\n"
	"  -a, --adapter N        /dev/dvb/adapterN (default 0)\n"
	"  -f, --frontend N       frontend index (default 0)\n"
	"      --dvr-buffer BYTES kernel dvr0 buffer (default 1048576)\n"
	"      --backlog BYTES    per-client userspace backlog before dropping (default 524288)\n"
	"  -v, --verbose\n"
	"The protocol has no authentication: bind to a trusted LAN interface only.\n", p);
}

int main(int argc, char **argv)
{
	struct cfg cfg = { "0.0.0.0", 7500, 7501, 0, 0, 1 << 20, 512 * 1024 };
	static const struct option lo[] = {
		{ "bind", 1, 0, 'b' }, { "control-port", 1, 0, 'c' }, { "transfer-port", 1, 0, 't' },
		{ "adapter", 1, 0, 'a' }, { "frontend", 1, 0, 'f' }, { "verbose", 0, 0, 'v' },
		{ "dvr-buffer", 1, 0, 1000 }, { "backlog", 1, 0, 1001 }, { "help", 0, 0, 'h' }, { 0, 0, 0, 0 }
	};
	int o, lc, lt;
	struct sigaction sa;

	while ((o = getopt_long(argc, argv, "b:c:t:a:f:vh", lo, NULL)) != -1) {
		switch (o) {
		case 'b': cfg.bind_addr = optarg; break;
		case 'c': cfg.ctl_port = atoi(optarg); break;
		case 't': cfg.xfer_port = atoi(optarg); break;
		case 'a': cfg.adapter = atoi(optarg); break;
		case 'f': cfg.frontend = atoi(optarg); break;
		case 'v': g_verbose = 1; break;
		case 1000: cfg.dvr_buf = atoi(optarg); break;
		case 1001: cfg.pending_max = atoi(optarg); break;
		default: usage(argv[0]); return o == 'h' ? 0 : 2;
		}
	}
	if (cfg.pending_max < TS_LEN * 16) cfg.pending_max = TS_LEN * 16;

	memset(&sa, 0, sizeof sa);
	sa.sa_handler = on_sig;           /* no SA_RESTART: let poll() return */
	sigaction(SIGINT, &sa, NULL);
	sigaction(SIGTERM, &sa, NULL);
	signal(SIGPIPE, SIG_IGN);

	lc = listen_on(cfg.bind_addr, cfg.ctl_port);
	lt = listen_on(cfg.bind_addr, cfg.xfer_port);
	if (lc < 0 || lt < 0) return 1;
	LOG("dvbnetd listening on %s control=%d transfer=%d (adapter %d)", cfg.bind_addr, cfg.ctl_port, cfg.xfer_port, cfg.adapter);

	while (!g_quit) {
		struct pollfd pf = { .fd = lc, .events = POLLIN };
		struct sockaddr_in pc;
		socklen_t l = sizeof pc;
		int r = poll(&pf, 1, 1000), ctl;

		if (r <= 0) continue;
		ctl = accept4(lc, (struct sockaddr *)&pc, &l, SOCK_CLOEXEC);
		if (ctl < 0) continue;
		{ char ip[INET_ADDRSTRLEN]; inet_ntop(AF_INET, &pc.sin_addr, ip, sizeof ip); LOG("client %s connected", ip); }
		run_session(&cfg, ctl, lt, pc.sin_addr);
		close(ctl);
	}
	close(lc); close(lt);
	return 0;
}
