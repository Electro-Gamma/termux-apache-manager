/* SPDX-License-Identifier: GPL-2.0-or-later
 * dvbnetd - TEST-ONLY backend. Produces a synthetic MPEG-TS (PIDs 0x000,
 * 0x100, 0x101, 0x1FFF) with per-PID continuity counters, and fake
 * capabilities/status, so the protocol server can be tested on a machine
 * without DVB hardware. It is NOT built into the real `dvbnetd` binary and
 * is not a substitute for testing against real hardware. */
#define _GNU_SOURCE
#include "backend.h"
#include <fcntl.h>
#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

static int pfd[2] = { -1, -1 };
static pthread_t th;
static volatile int run;
static volatile int64_t tuned_freq;
static volatile int is_tuned;
static int t2_enabled;

static int psi_mode;   /* FAKE_PSI=1: also emit a PAT (services 1 -> PMT 0x100, 2 -> PMT 0x300) and the PMT of service 1; used to test recording of one service */

static void put_section(uint8_t *p, const uint8_t *sec, int len)
{
	p[4] = 0;                       /* pointer_field */
	memcpy(p + 5, sec, (size_t)len);
	memset(p + 5 + len, 0xFF, (size_t)(188 - 5 - len));
}

static void *gen(void *a)
{
	static const unsigned pids[4] = { 0x000, 0x100, 0x101, 0x1FFF };
	static const unsigned pids_psi[8] = { 0x000, 0x100, 0x101, 0x102, 0x300, 0x301, 0x1FFF, 0x101 };
	static const uint8_t pat[] = { 0x00, 0xB0, 17, 0x00, 0x01, 0xC1, 0, 0, 0x00, 0x01, 0xE1, 0x00, 0x00, 0x02, 0xE3, 0x00, 0, 0, 0, 0 };
	static const uint8_t pmt[] = { 0x02, 0xB0, 23, 0x00, 0x01, 0xC1, 0, 0, 0xE1, 0x01, 0xF0, 0x00,
	                               0x1B, 0xE1, 0x01, 0xF0, 0x00, 0x03, 0xE1, 0x02, 0xF0, 0x00, 0, 0, 0, 0 };
	uint8_t cc[8] = { 0 }, buf[188 * 16];
	(void)a;
	while (run) {
		for (int i = 0; i < 16; i++) {
			int k = psi_mode ? (i & 7) : (i & 3);
			unsigned pid = psi_mode ? pids_psi[k] : pids[k];
			uint8_t *p = buf + i * 188;
			int64_t f = is_tuned ? tuned_freq : 0;
			memset(p, 0xAA, 188);
			p[0] = 0x47;
			p[1] = pid >> 8;
			p[2] = pid & 0xff;
			p[3] = 0x10 | (cc[k]++ & 0xf);
			if (psi_mode && pid == 0x000) { p[1] |= 0x40; put_section(p, pat, sizeof pat); }
			else if (psi_mode && pid == 0x100) { p[1] |= 0x40; put_section(p, pmt, sizeof pmt); }
			else for (int j = 0; j < 8; j++) p[4 + j] = (uint64_t)f >> (56 - 8 * j);
		}
		if (write(pfd[1], buf, sizeof buf) < 0) break;
		usleep(2000);
	}
	return NULL;
}

static int be_open(int adapter, int frontend, int buf)
{
	(void)adapter; (void)frontend; (void)buf;
	t2_enabled = getenv("FAKE_T2") != NULL;
	psi_mode = getenv("FAKE_PSI") != NULL;
	is_tuned = 0;
	if (pipe2(pfd, O_CLOEXEC) < 0) return -1;
	fcntl(pfd[0], F_SETFL, O_NONBLOCK);
	run = 1;
	return pthread_create(&th, NULL, gen, NULL);
}
static void be_close(void)
{
	run = 0;
	close(pfd[0]);
	pthread_join(th, NULL);
	close(pfd[1]);
}
static int be_caps(struct be_caps *c)
{
	c->system_mask = (1 << WSYS_T) | (t2_enabled ? 1 << WSYS_T2 : 0);
	c->freq_min = 174000000; c->freq_max = 862000000; c->freq_step = 166667;
	c->vendor_id = 0x0bda; c->product_id = 0x2838;
	return 0;
}
static int be_tune(int64_t f, int64_t bw, int sys)
{
	if (sys == WSYS_T2 && !t2_enabled) return -1;
	if (sys != WSYS_T && sys != WSYS_T2) return -1;
	if (f < 174000000 || f > 862000000) return -1;
	if (bw != 6000000 && bw != 7000000 && bw != 8000000) return -1;
	tuned_freq = f; is_tuned = 1;
	return 0;
}
static int be_status(struct be_status *s)
{
	memset(s, 0, sizeof *s);
	s->snr = 215; s->ber = is_tuned ? 7 : 0xFFFF; s->rf_percent = is_tuned ? 80 : 0;
	s->has_signal = s->has_carrier = s->has_sync = s->has_lock = is_tuned;
	return 0;
}
static int be_dvr_fd(void) { return pfd[0]; }
const struct backend backend_live = { be_open, be_close, be_caps, be_tune, be_status, be_dvr_fd };
