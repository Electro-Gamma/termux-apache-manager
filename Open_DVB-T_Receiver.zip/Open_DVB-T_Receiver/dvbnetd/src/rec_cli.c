/* SPDX-License-Identifier: GPL-2.0-or-later
 * dvbnetd - command-line client of the optional recorder:   dvbnetd rec <command> [options]
 * "rec list" reads the directory itself (works without the daemon); every other command talks to the running daemon
 * through its local UNIX socket. */
#define _GNU_SOURCE
#include "rec.h"
#include <errno.h>
#include <getopt.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>

#define DEFAULT_DIR "/var/lib/dvbnetd/recordings"

static void usage(void)
{
	fputs(
"Recording (needs the daemon started with --rec-dir DIR; default DIR for these commands: " DEFAULT_DIR ")\n"
"  dvbnetd rec start --mhz 610 [--bw 8] [--duration 30m|1h|2h|3h|1h30m|N] [--service ID | --pids A,B,C] [--name TAG]\n"
"        Start recording now. Without --duration it records until `rec stop`. Without --mhz it records the\n"
"        multiplex a connected client (the Android app) is tuned to. Default content: the whole multiplex.\n"
"  dvbnetd rec stop                     Stop the running recording (the file is finalised and kept)\n"
"  dvbnetd rec status                   State, file name, elapsed time, size\n"
"  dvbnetd rec list                     List recordings (also works without the daemon)\n"
"  dvbnetd rec schedule --mhz 610 --from \"6:00 PM\" --to \"7:00 PM\" [--date YYYY-MM-DD|today|tomorrow]\n"
"                       [--duration 1h] [--service ID | --pids ...] [--name TAG]\n"
"        Times may be 12-hour (6:00 PM, 6pm) or 24-hour (18:00). 23:00 -> 01:00 records overnight.\n"
"        Without --date the next occurrence is used. --duration may replace --to.\n"
"  dvbnetd rec schedules                List scheduled recordings\n"
"  dvbnetd rec cancel ID                Cancel a scheduled recording (a running one is stopped)\n"
"Common option: --rec-dir DIR (or environment DVBNETD_REC_DIR).\n"
"Playback without a tuner:   dvbnetd -p FILE   or   dvbnetd play NAME     (then connect the Android app as usual)\n", stderr);
}

static void print_line(void *ctx, const char *s) { (void)ctx; puts(s); }

static int talk(const char *dir, const char *req)
{
	struct sockaddr_un a;
	char path[REC_PATH_MAX + 32], buf[4096];
	size_t have = 0;
	int fd, ok = 0;
	ssize_t n;

	ctl_socket_path(dir, path, sizeof path);
	fd = socket(AF_UNIX, SOCK_STREAM, 0);
	memset(&a, 0, sizeof a); a.sun_family = AF_UNIX;
	if (strlen(path) >= sizeof a.sun_path) { fprintf(stderr, "path too long\n"); return 1; }
	strcpy(a.sun_path, path);
	if (fd < 0 || connect(fd, (struct sockaddr *)&a, sizeof a) < 0) {
		fprintf(stderr, "cannot reach the dvbnetd recorder (%s): %s\nIs the daemon running with --rec-dir %s ? (permissions: the socket is group-accessible, see README)\n", path, strerror(errno), dir);
		return 1;
	}
	(void)!write(fd, req, strlen(req));
	while ((n = read(fd, buf + have, sizeof buf - 1 - have)) > 0) have += (size_t)n;
	close(fd);
	buf[have] = 0;
	for (char *l = strtok(buf, "\n"); l; l = strtok(NULL, "\n")) {
		if (!strncmp(l, "> ", 2)) puts(l + 2);
		else if (!strncmp(l, "OK", 2)) { ok = 1; if (l[2] == ' ' && l[3]) puts(l + 3); }
		else if (!strncmp(l, "ERR", 3)) { fprintf(stderr, "error: %s\n", l + (l[3] ? 4 : 3)); }
	}
	return ok ? 0 : 1;
}

static int parse_bw(const char *s, int64_t *bw)
{
	double v = atof(s);
	if (v <= 0) return -1;
	*bw = v < 1000 ? (int64_t)(v * 1e6) : (int64_t)v;
	return 0;
}

int cli_main(int argc, char **argv)
{
	/* argv[0] = "rec" */
	const char *dir = getenv("DVBNETD_REC_DIR");
	const char *cmd;
	int64_t freq = 0, bw = 8000000, dur = 0;
	int sys = 0, mode = REC_FULL, svc = 0, date_given = 0, y = 0, mo = 0, d = 0, sh = -1, sm = 0, eh = -1, em = 0, o;
	char pids[256] = "", tag[64] = "";
	static const struct option lo[] = {
		{ "mhz", 1, 0, 'm' }, { "freq", 1, 0, 'f' }, { "bw", 1, 0, 'w' }, { "system", 1, 0, 's' }, { "duration", 1, 0, 'd' },
		{ "service", 1, 0, 'S' }, { "pids", 1, 0, 'P' }, { "name", 1, 0, 'n' }, { "from", 1, 0, 1 }, { "to", 1, 0, 2 },
		{ "date", 1, 0, 3 }, { "rec-dir", 1, 0, 4 }, { "help", 0, 0, 'h' }, { 0, 0, 0, 0 }
	};
	char req[1024];
	time_t now = time(NULL);

	if (!dir || !*dir) dir = DEFAULT_DIR;
	if (argc < 2) { usage(); return 2; }
	cmd = argv[1];
	optind = 2;
	while ((o = getopt_long(argc, argv, "m:f:w:s:d:S:P:n:h", lo, NULL)) != -1) {
		switch (o) {
		case 'm': freq = (int64_t)(atof(optarg) * 1e6 + 0.5); break;
		case 'f': freq = atoll(optarg); break;
		case 'w': if (parse_bw(optarg, &bw) < 0) { fprintf(stderr, "bad --bw\n"); return 2; } break;
		case 's': sys = (!strcasecmp(optarg, "t2") || !strcmp(optarg, "1")) ? 1 : 0; break;
		case 'd': if (rt_parse_duration(optarg, &dur) < 0) { fprintf(stderr, "bad --duration '%s' (examples: 30m, 1h, 1h30m, 90)\n", optarg); return 2; } break;
		case 'S': svc = (int)strtol(optarg, NULL, 0); mode = REC_SERVICE; break;
		case 'P': snprintf(pids, sizeof pids, "%s", optarg); mode = REC_PIDS; break;
		case 'n': snprintf(tag, sizeof tag, "%s", optarg); for (char *t = tag; *t; t++) if (!((*t >= 'a' && *t <= 'z') || (*t >= 'A' && *t <= 'Z') || (*t >= '0' && *t <= '9') || *t == '-')) *t = '_'; break;
		case 1: if (rt_parse_clock(optarg, &sh, &sm) < 0) { fprintf(stderr, "bad --from time '%s' (examples: 6:00 PM, 6pm, 18:00)\n", optarg); return 2; } break;
		case 2: if (rt_parse_clock(optarg, &eh, &em) < 0) { fprintf(stderr, "bad --to time '%s' (examples: 7:00 PM, 7pm, 19:00)\n", optarg); return 2; } break;
		case 3: if (rt_parse_date(optarg, now, &y, &mo, &d) < 0) { fprintf(stderr, "bad --date '%s' (use YYYY-MM-DD, DD/MM/YYYY, today, tomorrow)\n", optarg); return 2; } date_given = 1; break;
		case 4: dir = optarg; break;
		default: usage(); return o == 'h' ? 0 : 2;
		}
	}
	{ int n = snprintf(req, sizeof req, "freq=%lld bw=%lld sys=%d dur=%lld mode=%s svc=%d pids=%s tag=%s", (long long)freq, (long long)bw, sys, (long long)dur,
	                   mode == REC_PIDS ? "pids" : mode == REC_SERVICE ? "service" : "full", svc, pids[0] ? pids : "0", tag);
	  (void)n; }

	if (!strcmp(cmd, "list")) { rec_list_text(dir, print_line, NULL); return 0; }
	if (!strcmp(cmd, "start") || !strcmp(cmd, "schedule")) {
		char line[1100];
		if (!strcmp(cmd, "start")) {
			snprintf(line, sizeof line, "START %s", req);
			return talk(dir, line);
		}
		if (sh < 0) { fprintf(stderr, "schedule needs --from (and --to or --duration)\n"); return 2; }
		{
			time_t s, e;
			if (eh >= 0) {
				if (rt_resolve_window(now, sh, sm, eh, em, date_given, y, mo, d, &s, &e) < 0) { fprintf(stderr, "that time window is in the past\n"); return 2; }
			} else if (dur > 0) {
				if (rt_resolve_window(now, sh, sm, sh, sm, date_given, y, mo, d, &s, &e) < 0) { fprintf(stderr, "that time window is in the past\n"); return 2; }
				e = s + (time_t)dur;
				if (!date_given && e <= now) { s += 86400; e += 86400; }
			} else { fprintf(stderr, "schedule needs --to or --duration\n"); return 2; }
			snprintf(line, sizeof line, "SCHED start=%lld end=%lld %s", (long long)s, (long long)e, req);
			return talk(dir, line);
		}
	}
	if (!strcmp(cmd, "stop")) return talk(dir, "STOP");
	if (!strcmp(cmd, "status")) return talk(dir, "STATUS");
	if (!strcmp(cmd, "schedules")) return talk(dir, "SCHEDULES");
	if (!strcmp(cmd, "cancel")) {
		char line[64];
		if (optind >= argc) { fprintf(stderr, "cancel needs the schedule ID (see `rec schedules`)\n"); return 2; }
		snprintf(line, sizeof line, "CANCEL id=%d", atoi(argv[optind]));
		return talk(dir, line);
	}
	usage();
	return 2;
}
