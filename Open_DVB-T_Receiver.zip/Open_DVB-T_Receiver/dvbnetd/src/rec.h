/* SPDX-License-Identifier: GPL-2.0-or-later
 * dvbnetd - OPTIONAL recording / scheduling component.
 *
 * Nothing here runs unless the daemon is started with --rec-dir. The live protocol server (dvbnetd.c) only
 * calls the four small hooks at the bottom of this file; with recording disabled each of them returns at once. */
#ifndef DVBNETD_REC_H
#define DVBNETD_REC_H
#include "backend.h"
#include <stddef.h>
#include <stdint.h>
#include <time.h>

#define REC_PATH_MAX 512

struct rec_cfg {
	char dir[REC_PATH_MAX];
	int64_t min_free_bytes;   /* stop (and refuse to start) below this much free space */
	int64_t max_bytes;        /* optional size cap per recording, 0 = none */
	size_t ring_bytes;        /* memory buffer between tuner and disk */
	int adapter, frontend, dvr_buf;
	unsigned sock_mode;       /* permissions of the control socket */
	int stall_secs;           /* stop a standalone recording after this long without data */
};

/* What to record: the whole multiplex, an explicit PID list, or one service (PAT/PMT are followed). */
enum { REC_FULL = 0, REC_PIDS = 1, REC_SERVICE = 2 };

struct rec_req {
	int64_t freq_hz, bw_hz;   /* freq_hz == 0: use the multiplex a connected client is tuned to */
	int system;               /* wire ordinal: 0 DVB-T, 1 DVB-T2 */
	int64_t duration_s;       /* 0 = until stopped */
	int mode;
	uint16_t pids[64]; int npids;
	int service_id;
	char tag[48];
	time_t end_epoch;         /* scheduled recordings: absolute end (0 = use duration_s) */
};

/* ---- daemon side ---- */
extern volatile int rec_enabled;
extern volatile int rec_tap_on;
int  rec_init(const struct rec_cfg *cfg, const struct backend *live_backend);
void rec_shutdown(void);
void rec_cfg_defaults(struct rec_cfg *c);

/* hooks used by the live server (cheap no-ops when recording is disabled) */
int  rec_session_begin(void);                                 /* 0: tuner owned by a recording, refuse the client */
void rec_session_end(void);
void rec_note_tune(int64_t freq, int64_t bw, int system);     /* client tuned successfully */
void rec_tap(const uint8_t *pk, size_t len);                  /* raw aligned packets read from the tuner */

/* ---- recorder API (also used by the scheduler and the control socket) ---- */
int  rec_start(const struct rec_req *r, char *err, size_t errlen);   /* 0 / -1 */
int  rec_stop(const char *reason);                                    /* 0 if something was stopped */
int  rec_active(void);
void rec_status_text(char *out, size_t n);
void rec_set_finish_hook(void (*cb)(int ok, const char *reason));

/* ---- directory listing (works without a running daemon) ---- */
void rec_list_text(const char *dir, void (*line)(void *ctx, const char *s), void *ctx);
int  rec_recover(const char *dir);                            /* marks crashed recordings "interrupted" */

/* ---- scheduler ---- */
int  sched_init(const char *dir);
void sched_shutdown(void);
int  sched_add(const struct rec_req *r, time_t start, time_t end, char *err, size_t errlen);   /* id or -1 */
int  sched_cancel(int id, char *err, size_t errlen);
void sched_list_text(void (*line)(void *ctx, const char *s), void *ctx);
void sched_tick(time_t now);

/* ---- control socket ---- */
int  ctl_start(const char *dir, unsigned mode);
void ctl_stop(void);
const char *ctl_socket_path(const char *dir, char *buf, size_t n);

/* ---- command-line client + time parsing (rec_time.c) ---- */
int  cli_main(int argc, char **argv);
int  rt_parse_clock(const char *s, int *hour, int *min);       /* "6:00 PM", "6pm", "18:30", "1800" */
int  rt_parse_duration(const char *s, int64_t *secs);          /* "30m", "1h", "1h30m", "90" (minutes), "1:30" */
int  rt_parse_date(const char *s, time_t now, int *y, int *m, int *d);   /* YYYY-MM-DD, DD/MM/YYYY, today, tomorrow */
/* Resolves a window to absolute times. date_given=0: the next occurrence whose end is still in the future. */
int  rt_resolve_window(time_t now, int sh, int sm, int eh, int em, int date_given, int y, int mo, int d,
                       time_t *start, time_t *end);
#endif
