/* SPDX-License-Identifier: GPL-2.0-or-later
 * dvbnetd - transport-stream integrity statistics.
 *
 * Faithful C port of the packet accounting in AndroidDvbDriver's
 * drivers/.../DvbDemux.java (swfilterPacket / checkSequenceIntegrity /
 * getDroppedUsbFps), whose result is what the Android driver reports as
 * "droppedUsbFps" in GET_STATUS. Ported for protocol compatibility;
 * Copyright of the original: Signalware Ltd, GPL-2.0-or-later. */
#ifndef DVBNETD_TS_STATS_H
#define DVBNETD_TS_STATS_H
#include <stdint.h>

struct ts_stats {
	uint8_t cnt[(0x1fff / 2) + 1]; /* per-PID continuity state, 2 nibbles per byte */
	int dropped;                   /* error packets since last rate read */
	int64_t last_ms;               /* time of last rate read / reset */
};

void ts_stats_init(struct ts_stats *s, int64_t now_ms);
/* Same as DvbDemux.reset(): clears the dropped counter and timer, NOT the CC state. */
void ts_stats_reset(struct ts_stats *s, int64_t now_ms);
/* Account one 188-byte packet that starts with 0x47 (before PID filtering). */
void ts_stats_packet(struct ts_stats *s, const uint8_t *pk);
/* Same as DvbDemux.getDroppedUsbFps(): dropped*1000/elapsed_ms, truncated, absolute. */
int ts_stats_rate(struct ts_stats *s, int64_t now_ms);
int64_t ts_now_ms(void);
#endif
