/* SPDX-License-Identifier: GPL-2.0-or-later
 * dvbnetd - recorder core (OPTIONAL, see rec.h).
 *
 * Data path:   tuner dvr0 --(reader thread, or a tap inside a live session)--> filter --> ring buffer --> writer thread --> file
 * The ring decouples the tuner from disk speed: when the disk stalls, whole packets are dropped and counted, the tuner
 * (and a live client) never wait for the disk.
 * Tuner ownership: a live client session and a standalone recording exclude each other (one Linux frontend, one opener).
 * While a client is connected the recorder can instead "tap" the raw packets of that session. If the client leaves
 * during such a recording, the recorder re-opens the tuner itself and keeps recording. */
#define _GNU_SOURCE
#include "rec.h"
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <pthread.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/statvfs.h>
#include <unistd.h>

#define TS_LEN 188
volatile int rec_enabled;
volatile int rec_tap_on;

enum owner { O_FREE, O_SESSION, O_REC };

static struct {
	pthread_mutex_t m;
	pthread_cond_t cv;
	struct rec_cfg cfg;
	const struct backend *be;
	enum owner owner;
	int tune_valid; int64_t t_freq, t_bw; int t_sys;        /* what the connected client is tuned to */

	int active, tap, stop, nthreads, finalized;
	char stop_reason[96];
	int fd; char path[REC_PATH_MAX], info[REC_PATH_MAX + 8];
	time_t start_epoch; int64_t start_mono, end_mono;       /* end_mono 0 = no end */
	int64_t bytes, dropped_bytes, last_data_mono;
	struct rec_req req;
	uint8_t pass[8192]; int pmt_pid;
	uint8_t *ring; size_t cap, head, tail, used;
	void (*finish_hook)(int ok, const char *reason);
} R = { .m = PTHREAD_MUTEX_INITIALIZER, .cv = PTHREAD_COND_INITIALIZER, .fd = -1 };

static int64_t mono_ms(void)
{
	struct timespec t;
	clock_gettime(CLOCK_MONOTONIC, &t);
	return (int64_t)t.tv_sec * 1000 + t.tv_nsec / 1000000;
}

void rec_cfg_defaults(struct rec_cfg *c)
{
	memset(c, 0, sizeof *c);
	c->min_free_bytes = 500LL << 20;
	c->ring_bytes = 4u << 20;
	c->dvr_buf = 1 << 20;
	c->sock_mode = 0660;
	c->stall_secs = 120;
}

/* ---------- info file (key=value) ---------- */
static void write_info(const char *status, const char *reason)
{
	char tmp[REC_PATH_MAX + 16], pids[512] = "";
	FILE *f;
	int n = 0;

	snprintf(tmp, sizeof tmp, "%s.tmp", R.info);
	f = fopen(tmp, "w");
	if (!f) return;
	for (int i = 0; i < R.req.npids && n < (int)sizeof pids - 8; i++) n += snprintf(pids + n, sizeof pids - (size_t)n, "%s%u", i ? "," : "", R.req.pids[i]);
	fprintf(f, "status=%s\nreason=%s\nstart=%lld\nend=%lld\nfreq_hz=%lld\nbw_hz=%lld\nsystem=%d\nbytes=%lld\ndropped_bytes=%lld\nmode=%s\nservice=%d\npids=%s\nsource=%s\ntag=%s\n",
	        status, reason ? reason : "", (long long)R.start_epoch,
	        strcmp(status, "recording") ? (long long)time(NULL) : 0LL,
	        (long long)R.req.freq_hz, (long long)R.req.bw_hz, R.req.system, (long long)R.bytes, (long long)R.dropped_bytes,
	        R.req.mode == REC_FULL ? "full" : R.req.mode == REC_PIDS ? "pids" : "service", R.req.service_id, pids,
	        R.tap ? "client-stream" : "tuner", R.req.tag);
	fflush(f);
	fsync(fileno(f));
	fclose(f);
	rename(tmp, R.info);
}

static int read_info(const char *path, char key[][24], char val[][96], int max)
{
	FILE *f = fopen(path, "r");
	char line[160];
	int n = 0;
	if (!f) return 0;
	while (n < max && fgets(line, sizeof line, f)) {
		char *eq = strchr(line, '=');
		if (!eq) continue;
		*eq = 0; eq++; eq[strcspn(eq, "\r\n")] = 0;
		snprintf(key[n], 24, "%s", line); snprintf(val[n], 96, "%s", eq); n++;
	}
	fclose(f);
	return n;
}
static const char *kv(char key[][24], char val[][96], int n, const char *k)
{
	for (int i = 0; i < n; i++) if (!strcmp(key[i], k)) return val[i];
	return "";
}

/* ---------- PAT / PMT following for --service ---------- */
static const uint8_t *section_of(const uint8_t *pk)
{
	int off = 4;
	if (!(pk[1] & 0x40)) return NULL;                       /* only sections that start in this packet */
	if (pk[3] & 0x20) off += 1 + pk[4];
	if (off >= TS_LEN - 1) return NULL;
	off += 1 + pk[off];                                      /* pointer_field */
	return off < TS_LEN - 8 ? pk + off : NULL;
}
static void follow_psi(const uint8_t *pk, unsigned pid)
{
	const uint8_t *s = section_of(pk);
	int len;
	if (!s) return;
	len = ((s[1] & 0x0f) << 8) | s[2];
	if (s + 3 + len > pk + TS_LEN || len < 9) return;       /* multi-packet sections are not followed */
	if (pid == 0 && s[0] == 0x00) {
		for (const uint8_t *p = s + 8; p + 4 <= s + 3 + len - 4; p += 4)
			if (((p[0] << 8) | p[1]) == R.req.service_id) { R.pmt_pid = ((p[2] & 0x1f) << 8) | p[3]; R.pass[R.pmt_pid] = 1; }
	} else if ((int)pid == R.pmt_pid && s[0] == 0x02 && ((s[3] << 8) | s[4]) == R.req.service_id) {
		int pil = ((s[10] & 0x0f) << 8) | s[11];
		const uint8_t *p = s + 12 + pil, *end = s + 3 + len - 4;
		R.pass[((s[8] & 0x1f) << 8) | s[9]] = 1;            /* PCR pid */
		while (p + 5 <= end) { R.pass[((p[1] & 0x1f) << 8) | p[2]] = 1; p += 5 + (((p[3] & 0x0f) << 8) | p[4]); }
	}
}

/* ---------- ring ---------- */
/* Called with R.m held. Keeps only wanted packets; a full ring drops (and counts) the packet. */
static void push_locked(const uint8_t *buf, size_t len)
{
	int added = 0;
	if (!R.ring || R.stop) return;                      /* finishing: only what is already buffered is written */
	for (size_t o = 0; o + TS_LEN <= len; o += TS_LEN) {
		const uint8_t *pk = buf + o;
		unsigned pid;
		if (pk[0] != 0x47) continue;
		pid = (unsigned)(((pk[1] & 0x1f) << 8) | pk[2]);
		if (pid == 0x1FFF) continue;                         /* null packets carry nothing: not stored */
		if (R.req.mode == REC_SERVICE && (pid == 0 || (int)pid == R.pmt_pid)) follow_psi(pk, pid);
		if (!R.pass[pid]) continue;
		if (R.cap - R.used < TS_LEN) { R.dropped_bytes += TS_LEN; continue; }
		memcpy(R.ring + R.head, pk, TS_LEN);
		R.head = (R.head + TS_LEN) % R.cap;
		R.used += TS_LEN;
		added = 1;
	}
	if (added) { R.last_data_mono = mono_ms(); pthread_cond_signal(&R.cv); }
}

void rec_tap(const uint8_t *pk, size_t len)
{
	if (!rec_tap_on) return;
	pthread_mutex_lock(&R.m);
	if (R.active && R.tap && !R.stop) push_locked(pk, len);
	pthread_mutex_unlock(&R.m);
}

/* ---------- stop / finish ---------- */
static void request_stop_locked(const char *reason)
{
	if (R.stop) return;
	R.stop = 1;
	snprintf(R.stop_reason, sizeof R.stop_reason, "%s", reason);
	pthread_cond_broadcast(&R.cv);
}

static void thread_done(void)
{
	void (*hook)(int, const char *) = NULL;
	int ok = 0;
	char reason[96] = "";

	pthread_mutex_lock(&R.m);
	if (--R.nthreads == 0) {
		R.active = 0; rec_tap_on = 0;
		if (R.owner == O_REC) R.owner = O_FREE;
		hook = R.finish_hook;
		ok = R.finalized;
		snprintf(reason, sizeof reason, "%s", R.stop_reason);
		pthread_cond_broadcast(&R.cv);
	}
	pthread_mutex_unlock(&R.m);
	if (hook) hook(ok, reason);
}

static int free_space_ok(const char *dir, int64_t *free_out)
{
	struct statvfs v;
	int64_t fr;
	if (statvfs(dir, &v) < 0) return 1;                      /* cannot tell: do not block */
	fr = (int64_t)v.f_bavail * (int64_t)v.f_frsize;
	if (free_out) *free_out = fr;
	return fr >= R.cfg.min_free_bytes;
}

static void *writer_thread(void *arg)
{
	uint8_t *chunk = malloc(TS_LEN * 348);
	int64_t last_check = 0, last_sync = 0;
	const char *status = "stopped";
	(void)arg;

	for (;;) {
		size_t n = 0;
		int stop;
		pthread_mutex_lock(&R.m);
		if (!R.used && !R.stop) {
			struct timespec ts;
			clock_gettime(CLOCK_REALTIME, &ts);
			ts.tv_nsec += 200 * 1000000L; if (ts.tv_nsec >= 1000000000L) { ts.tv_sec++; ts.tv_nsec -= 1000000000L; }
			pthread_cond_timedwait(&R.cv, &R.m, &ts);
		}
		while (n + TS_LEN <= TS_LEN * 348 && R.used >= TS_LEN) {
			memcpy(chunk + n, R.ring + R.tail, TS_LEN);
			R.tail = (R.tail + TS_LEN) % R.cap; R.used -= TS_LEN; n += TS_LEN;
		}
		stop = R.stop && R.used == 0;
		pthread_mutex_unlock(&R.m);

		for (size_t off = 0; off < n;) {
			ssize_t w = write(R.fd, chunk + off, n - off);
			if (w < 0) {
				if (errno == EINTR) continue;
				pthread_mutex_lock(&R.m);
				{ char why[96]; snprintf(why, sizeof why, "write error: %s", strerror(errno)); request_stop_locked(why); }
				status = "error";
				R.used = 0; R.tail = R.head;                   /* nothing more can be written: discard the rest */
				pthread_mutex_unlock(&R.m);
				stop = 1; n = 0;
				break;
			}
			off += (size_t)w;
		}
		if (n) { pthread_mutex_lock(&R.m); R.bytes += (int64_t)n; pthread_mutex_unlock(&R.m); }

		{
			int64_t now = mono_ms();
			if (now - last_check >= 1000) {
				last_check = now;
				pthread_mutex_lock(&R.m);
				if (!R.stop) {
					if (!free_space_ok(R.cfg.dir, NULL)) { request_stop_locked("disk space low"); status = "error"; }
					else if (R.cfg.max_bytes && R.bytes >= R.cfg.max_bytes) request_stop_locked("size limit reached");
					else if (R.end_mono && now >= R.end_mono) request_stop_locked(R.req.end_epoch ? "scheduled end" : "duration reached");
					else if (!R.tap && R.cfg.stall_secs && now - R.last_data_mono > R.cfg.stall_secs * 1000LL) { request_stop_locked("no data from the tuner"); status = "error"; }
				}
				pthread_mutex_unlock(&R.m);
			}
			if (now - last_sync >= 10000 && R.fd >= 0) { last_sync = now; fdatasync(R.fd); }
		}
		if (stop) break;
	}

	/* finalise: everything buffered is on disk; make it durable, then describe it */
	pthread_mutex_lock(&R.m);
	{
		const char *why = R.stop_reason;
		if (!strcmp(status, "error")) { /* set by the writer itself: keep */ }
		else if (!strcmp(why, "scheduled end") || !strcmp(why, "duration reached")) status = "complete";
		else if (!strcmp(why, "user") || !strcmp(why, "shutdown") || strstr(why, "retuned") || strstr(why, "client disconnected") ||
		         strstr(why, "preempted") || strstr(why, "size limit")) status = "stopped";
		else status = "error";
		{ struct stat sb; if (fstat(R.fd, &sb) == 0 && sb.st_size % TS_LEN) (void)!ftruncate(R.fd, sb.st_size / TS_LEN * TS_LEN); }   /* never leave half a packet */
		fdatasync(R.fd); close(R.fd); R.fd = -1;
		write_info(status, why);
		R.finalized = !strcmp(status, "complete") || !strcmp(status, "stopped");
		free(R.ring); R.ring = NULL;
	}
	pthread_mutex_unlock(&R.m);
	free(chunk);
	thread_done();
	return NULL;
}

static void *reader_thread(void *arg)
{
	const struct backend *be = R.be;
	uint8_t buf[TS_LEN * 348];
	size_t rlen = 0;
	int dvr;
	int need_open = arg != NULL;

	if (need_open) {   /* the client left a tap recording: take the tuner over */
		pthread_mutex_lock(&R.m);
		int64_t f = R.t_freq, bw = R.t_bw; int sys = R.t_sys;
		pthread_mutex_unlock(&R.m);
		if (be->open(R.cfg.adapter, R.cfg.frontend, R.cfg.dvr_buf) < 0 || be->tune(f, bw, sys) < 0) {
			if (be->close) be->close();
			pthread_mutex_lock(&R.m); request_stop_locked("could not continue after the client left"); pthread_mutex_unlock(&R.m);
			thread_done();
			return NULL;
		}
	}
	dvr = be->dvr_fd();
	for (;;) {
		struct pollfd pf = { .fd = dvr, .events = POLLIN };
		int r, stop;
		pthread_mutex_lock(&R.m); stop = R.stop; pthread_mutex_unlock(&R.m);
		if (stop) break;
		r = poll(&pf, 1, 200);
		if (r < 0 && errno != EINTR) break;
		if (r > 0 && (pf.revents & POLLIN)) {
			ssize_t n = read(dvr, buf + rlen, sizeof buf - rlen);
			if (n < 0) { if (errno == EOVERFLOW) { pthread_mutex_lock(&R.m); R.dropped_bytes += 65536; pthread_mutex_unlock(&R.m); } continue; }
			rlen += (size_t)n;
			size_t npk = rlen / TS_LEN;
			if (npk) {
				pthread_mutex_lock(&R.m);
				push_locked(buf, npk * TS_LEN);
				pthread_mutex_unlock(&R.m);
				rlen -= npk * TS_LEN;
				if (rlen) memmove(buf, buf + npk * TS_LEN, rlen);
			}
		}
	}
	be->close();
	thread_done();
	return NULL;
}

static int spawn(void *(*fn)(void *), void *arg)
{
	pthread_t t;
	pthread_attr_t a;
	int r;
	pthread_attr_init(&a);
	pthread_attr_setdetachstate(&a, PTHREAD_CREATE_DETACHED);
	r = pthread_create(&t, &a, fn, arg);
	pthread_attr_destroy(&a);
	return r;
}

/* ---------- public recorder API ---------- */
static void sanitize_tag(char *dst, size_t n, const char *src)
{
	size_t j = 0;
	for (; *src && j + 1 < n; src++) {
		char c = *src;
		if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '-' || c == '_') dst[j++] = c;
		else if (c == ' ' && j && dst[j - 1] != '_') dst[j++] = '_';
	}
	dst[j] = 0;
}

static int open_unique(char *path, size_t n, time_t t, int64_t freq, const char *tag)
{
	struct tm tm;
	char base[REC_PATH_MAX + 160];
	localtime_r(&t, &tm);
	snprintf(base, sizeof base, "%s/%04d%02d%02d_%02d%02d%02d_%lldMHz%s%s", R.cfg.dir, tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday,
	         tm.tm_hour, tm.tm_min, tm.tm_sec, (long long)(freq / 1000000), *tag ? "_" : "", tag);
	for (int i = 1; i < 1000; i++) {           /* never overwrite: O_EXCL, numbered on collision */
		int fd;
		if (i == 1) snprintf(path, n, "%s.ts", base); else snprintf(path, n, "%s-%d.ts", base, i);
		fd = open(path, O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC, 0644);
		if (fd >= 0) return fd;
		if (errno != EEXIST) return -1;
	}
	errno = EEXIST;
	return -1;
}

int rec_active(void)
{
	int a;
	pthread_mutex_lock(&R.m); a = R.active; pthread_mutex_unlock(&R.m);
	return a;
}

void rec_set_finish_hook(void (*cb)(int, const char *)) { R.finish_hook = cb; }

int rec_start(const struct rec_req *rq, char *err, size_t errlen)
{
	int tap = 0, standalone = 0, lock_ok = 0;
	int64_t freq = rq->freq_hz, bw = rq->bw_hz, fr = 0;
	int sys = rq->system;

#define FAIL(...) do { snprintf(err, errlen, __VA_ARGS__); goto fail; } while (0)
	pthread_mutex_lock(&R.m);
	if (!rec_enabled) { pthread_mutex_unlock(&R.m); snprintf(err, errlen, "recording is not enabled (start the daemon with --rec-dir)"); return -1; }
	if (R.active) { pthread_mutex_unlock(&R.m); snprintf(err, errlen, "a recording is already running (stop it first)"); return -1; }
	if (!free_space_ok(R.cfg.dir, &fr)) {
		pthread_mutex_unlock(&R.m);
		snprintf(err, errlen, "not enough free disk space (%lld MiB free, %lld MiB required)", (long long)(fr >> 20), (long long)(R.cfg.min_free_bytes >> 20));
		return -1;
	}
	if (R.owner == O_SESSION) {
		if (!R.tune_valid) { pthread_mutex_unlock(&R.m); snprintf(err, errlen, "a client is connected but has not tuned yet"); return -1; }
		if (freq && freq != R.t_freq) {
			pthread_mutex_unlock(&R.m);
			snprintf(err, errlen, "the tuner is in use by a connected client (tuned to %.3f MHz); record that multiplex or disconnect the client", R.t_freq / 1e6);
			return -1;
		}
		tap = 1; freq = R.t_freq; bw = R.t_bw; sys = R.t_sys;
	} else {
		if (freq <= 0) { pthread_mutex_unlock(&R.m); snprintf(err, errlen, "no frequency given (use --mhz or --freq)"); return -1; }
		if (bw <= 0) bw = 8000000;
		R.owner = O_REC; standalone = 1;
	}
	R.active = 1; R.stop = 0; R.finalized = 0; R.stop_reason[0] = 0;       /* reserve the slot while the tuner is opened */
	pthread_mutex_unlock(&R.m);

	if (standalone) {
		if (R.be->open(R.cfg.adapter, R.cfg.frontend, R.cfg.dvr_buf) < 0) FAIL("cannot open the tuner (adapter %d); is another program using it?", R.cfg.adapter);
		if (R.be->tune(freq, bw, sys) < 0) { R.be->close(); FAIL("cannot tune %.3f MHz", (double)freq / 1e6); }
		for (int i = 0; i < 40 && !lock_ok; i++) {          /* up to ~8 s for lock */
			struct be_status st;
			if (R.be->status(&st) == 0 && st.has_lock) lock_ok = 1; else usleep(200000);
		}
		if (!lock_ok) { R.be->close(); FAIL("no signal lock on %.3f MHz (antenna/frequency?)", (double)freq / 1e6); }
	}

	{
		time_t now = time(NULL);
		char tag[48];
		int fd;
		sanitize_tag(tag, sizeof tag, rq->tag);
		pthread_mutex_lock(&R.m);
		fd = open_unique(R.path, sizeof R.path, now, freq, tag);
		if (fd < 0) { int e = errno; pthread_mutex_unlock(&R.m); if (standalone) R.be->close(); snprintf(err, errlen, "cannot create the recording file in %s: %s", R.cfg.dir, strerror(e)); goto fail; }
		R.ring = malloc(R.cfg.ring_bytes / TS_LEN * TS_LEN);
		if (!R.ring) { close(fd); unlink(R.path); pthread_mutex_unlock(&R.m); if (standalone) R.be->close(); snprintf(err, errlen, "out of memory"); goto fail; }
		R.cap = R.cfg.ring_bytes / TS_LEN * TS_LEN; R.head = R.tail = R.used = 0;
		R.fd = fd; snprintf(R.info, sizeof R.info, "%s.info", R.path);
		R.req = *rq; R.req.freq_hz = freq; R.req.bw_hz = bw; R.req.system = sys; snprintf(R.req.tag, sizeof R.req.tag, "%s", tag);
		R.start_epoch = now; R.start_mono = mono_ms(); R.last_data_mono = R.start_mono;
		R.end_mono = 0;
		if (rq->end_epoch) { int64_t left = (int64_t)(rq->end_epoch - now); R.end_mono = R.start_mono + (left > 0 ? left : 1) * 1000; }
		else if (rq->duration_s > 0) R.end_mono = R.start_mono + rq->duration_s * 1000;
		R.bytes = R.dropped_bytes = 0; R.tap = tap; R.pmt_pid = -1;
		memset(R.pass, 0, sizeof R.pass);
		if (rq->mode == REC_FULL) memset(R.pass, 1, sizeof R.pass);
		else {
			R.pass[0] = R.pass[0x10] = R.pass[0x11] = R.pass[0x12] = R.pass[0x14] = 1;   /* PAT NIT SDT EIT TDT */
			for (int i = 0; i < rq->npids; i++) if (rq->pids[i] < 8192) R.pass[rq->pids[i]] = 1;
		}
		write_info("recording", "");
		R.nthreads = 1 + (standalone ? 1 : 0);
		pthread_mutex_unlock(&R.m);
	}
	if (spawn(writer_thread, NULL) != 0) { snprintf(err, errlen, "cannot start the writer thread"); R.nthreads = 1; if (standalone) R.be->close(); pthread_mutex_lock(&R.m); R.stop = 1; pthread_mutex_unlock(&R.m); close(R.fd); R.fd = -1; thread_done(); return -1; }
	if (standalone && spawn(reader_thread, NULL) != 0) { pthread_mutex_lock(&R.m); request_stop_locked("cannot start the reader thread"); pthread_mutex_unlock(&R.m); R.be->close(); thread_done(); }
	if (tap) rec_tap_on = 1;
	return 0;
fail:
	pthread_mutex_lock(&R.m);
	R.active = 0;
	if (standalone && R.owner == O_REC) R.owner = O_FREE;
	pthread_mutex_unlock(&R.m);
	return -1;
#undef FAIL
}

int rec_stop(const char *reason)
{
	int was;
	pthread_mutex_lock(&R.m);
	was = R.active && !R.stop;
	if (was) request_stop_locked(reason ? reason : "user");
	pthread_mutex_unlock(&R.m);
	return was ? 0 : -1;
}

void rec_status_text(char *out, size_t n)
{
	char free_s[64] = "?";
	struct statvfs v;
	int64_t now = mono_ms();

	pthread_mutex_lock(&R.m);
	if (statvfs(R.cfg.dir, &v) == 0) snprintf(free_s, sizeof free_s, "%.1f GiB free", (double)v.f_bavail * (double)v.f_frsize / (1024.0 * 1024 * 1024));
	if (!R.active) {
		snprintf(out, n, "state: idle\ndirectory: %s (%s)\n", R.cfg.dir, free_s);
	} else {
		int64_t el = (now - R.start_mono) / 1000;
		char ends[96] = "never (until stopped)";
		if (R.end_mono) { int64_t left = (R.end_mono - now) / 1000; if (left < 0) left = 0; snprintf(ends, sizeof ends, "in %02lld:%02lld:%02lld", (long long)(left / 3600), (long long)(left / 60 % 60), (long long)(left % 60)); }
		snprintf(out, n,
		         "state: %s\nfile: %s\nelapsed: %02lld:%02lld:%02lld\nsize: %.1f MiB\nfrequency: %.3f MHz\nsource: %s\ncontent: %s\ndropped: %lld KiB\nends: %s\ndirectory: %s (%s)\n",
		         R.stop ? "stopping" : "recording", R.path, (long long)(el / 3600), (long long)(el / 60 % 60), (long long)(el % 60),
		         (double)R.bytes / 1048576.0, (double)R.req.freq_hz / 1e6, R.tap ? "stream of the connected client" : "tuner",
		         R.req.mode == REC_FULL ? "whole multiplex" : R.req.mode == REC_PIDS ? "selected PIDs" : "one service",
		         (long long)(R.dropped_bytes / 1024), ends, R.cfg.dir, free_s);
	}
	pthread_mutex_unlock(&R.m);
}

/* ---------- tuner ownership hooks for the live server ---------- */
int rec_session_begin(void)
{
	if (!rec_enabled) return 1;
	pthread_mutex_lock(&R.m);
	if (R.owner == O_REC) { pthread_mutex_unlock(&R.m); return 0; }
	R.owner = O_SESSION; R.tune_valid = 0;
	pthread_mutex_unlock(&R.m);
	return 1;
}

void rec_session_end(void)
{
	int takeover = 0;
	if (!rec_enabled) return;
	pthread_mutex_lock(&R.m);
	if (R.owner == O_SESSION) R.owner = O_FREE;
	if (R.active && R.tap && !R.stop) {
		if (R.tune_valid && R.cap) {
			R.owner = O_REC; R.tap = 0; rec_tap_on = 0; R.nthreads++; takeover = 1;
			R.last_data_mono = mono_ms();
		} else request_stop_locked("client disconnected");
	}
	R.tune_valid = 0;
	pthread_mutex_unlock(&R.m);
	if (takeover && spawn(reader_thread, (void *)1) != 0) { pthread_mutex_lock(&R.m); request_stop_locked("cannot continue after the client left"); pthread_mutex_unlock(&R.m); thread_done(); }
}

void rec_note_tune(int64_t freq, int64_t bw, int system)
{
	if (!rec_enabled) return;
	pthread_mutex_lock(&R.m);
	if (R.active && R.tap && R.t_freq != freq && R.tune_valid) request_stop_locked("client retuned to another multiplex");
	R.t_freq = freq; R.t_bw = bw; R.t_sys = system; R.tune_valid = 1;
	pthread_mutex_unlock(&R.m);
}

/* ---------- directory: listing and crash recovery ---------- */
static int cmp_str(const void *a, const void *b) { return strcmp((const char *)a, (const char *)b); }

static int scan_dir(const char *dir, char (*names)[256], int max)
{
	DIR *d = opendir(dir);
	struct dirent *e;
	int n = 0;
	if (!d) return -1;
	while ((e = readdir(d)) && n < max) {
		size_t l = strlen(e->d_name);
		if (l > 8 && !strcmp(e->d_name + l - 8, ".ts.info")) snprintf(names[n++], 256, "%.*s", (int)(l - 5), e->d_name);   /* the .ts name */
	}
	closedir(d);
	qsort(names, (size_t)n, 256, cmp_str);
	return n;
}

int rec_recover(const char *dir)
{
	static char names[512][256];
	int n = scan_dir(dir, names, 512), fixed = 0;
	for (int i = 0; i < n; i++) {
		char p[REC_PATH_MAX], ip[REC_PATH_MAX + 8], key[16][24], val[16][96];
		struct stat st;
		int c;
		snprintf(p, sizeof p, "%s/%s", dir, names[i]); snprintf(ip, sizeof ip, "%s.info", p);
		c = read_info(ip, key, val, 16);
		if (strcmp(kv(key, val, c, "status"), "recording")) continue;
		if (stat(p, &st) == 0) {
			off_t good = st.st_size / TS_LEN * TS_LEN;      /* a power cut can leave half a packet */
			if (good != st.st_size && truncate(p, good) != 0) { /* leave as is */ }
		}
		{
			FILE *f = fopen(ip, "a");
			if (f) { fprintf(f, "status=interrupted\nreason=the recorder stopped unexpectedly (power loss or crash); the file is playable up to this point\n"); fclose(f); fixed++; }
		}
	}
	return fixed;
}

static const char *last_kv(const char *path, const char *k, char *buf, size_t n)
{
	FILE *f = fopen(path, "r");
	char line[200];
	size_t kl = strlen(k);
	buf[0] = 0;
	if (!f) return buf;
	while (fgets(line, sizeof line, f))     /* the last occurrence wins (recovery appends) */
		if (!strncmp(line, k, kl) && line[kl] == '=') { line[strcspn(line, "\r\n")] = 0; snprintf(buf, n, "%s", line + kl + 1); }
	fclose(f);
	return buf;
}

void rec_list_text(const char *dir, void (*line)(void *, const char *), void *ctx)
{
	static char names[512][256];
	int n = scan_dir(dir, names, 512);
	char b[512];
	if (n < 0) { snprintf(b, sizeof b, "cannot read %s: %s", dir, strerror(errno)); line(ctx, b); return; }
	if (n == 0) { line(ctx, "no recordings"); return; }
	snprintf(b, sizeof b, "%-44s %-16s %-9s %-10s %-9s %s", "NAME", "STARTED", "LENGTH", "SIZE", "MHZ", "STATUS");
	line(ctx, b);
	for (int i = 0; i < n; i++) {
		char p[REC_PATH_MAX], ip[REC_PATH_MAX + 8], st[40], s0[32], e0[32], fq[32], rs[96], when[32];
		struct stat sb;
		long long start, end, secs;
		struct tm tm;
		snprintf(p, sizeof p, "%s/%s", dir, names[i]); snprintf(ip, sizeof ip, "%s.info", p);
		last_kv(ip, "status", st, sizeof st); last_kv(ip, "start", s0, sizeof s0); last_kv(ip, "end", e0, sizeof e0);
		last_kv(ip, "freq_hz", fq, sizeof fq); last_kv(ip, "reason", rs, sizeof rs);
		start = atoll(s0); end = atoll(e0);
		if (stat(p, &sb) != 0) memset(&sb, 0, sizeof sb);
		if (!end || end < start) end = (long long)sb.st_mtime;
		secs = end > start ? end - start : 0;
		{ time_t t = (time_t)start; localtime_r(&t, &tm); strftime(when, sizeof when, "%Y-%m-%d %H:%M", &tm); }
		snprintf(b, sizeof b, "%-44s %-16s %02lld:%02lld:%02lld  %7.1f MiB %9.3f %s%s%s", names[i], when, secs / 3600, secs / 60 % 60, secs % 60,
		         (double)sb.st_size / 1048576.0, atoll(fq) / 1e6, st[0] ? st : "?",
		         (strcmp(st, "complete") && strcmp(st, "stopped") && strcmp(st, "recording") && rs[0]) ? " - " : "",
		         (strcmp(st, "complete") && strcmp(st, "stopped") && strcmp(st, "recording") && rs[0]) ? rs : "");
		line(ctx, b);
	}
}

/* ---------- init / shutdown ---------- */
static int mkdir_p(const char *path)
{
	char t[REC_PATH_MAX];
	snprintf(t, sizeof t, "%s", path);
	for (char *p = t + 1; *p; p++) if (*p == '/') { *p = 0; mkdir(t, 0755); *p = '/'; }
	return mkdir(t, 0755) == 0 || errno == EEXIST ? 0 : -1;
}

int rec_init(const struct rec_cfg *cfg, const struct backend *be)
{
	struct stat st;
	R.cfg = *cfg; R.be = be;
	signal(SIGXFSZ, SIG_IGN);                                  /* a file-size limit must surface as a write error, not kill the server */
	if (mkdir_p(cfg->dir) < 0 || stat(cfg->dir, &st) != 0 || !S_ISDIR(st.st_mode) || access(cfg->dir, W_OK) != 0) {
		fprintf(stderr, "recording disabled: %s is not a writable directory\n", cfg->dir);
		return -1;
	}
	{ int fixed = rec_recover(cfg->dir); if (fixed) fprintf(stderr, "recovery: %d interrupted recording(s) marked\n", fixed); }
	rec_enabled = 1;
	if (sched_init(cfg->dir) < 0) fprintf(stderr, "scheduler could not load its list; continuing with an empty one\n");
	if (ctl_start(cfg->dir, cfg->sock_mode) < 0) fprintf(stderr, "recording control socket unavailable (the CLI will not reach the daemon)\n");
	fprintf(stderr, "recording enabled: directory %s, keep %lld MiB free\n", cfg->dir, (long long)(cfg->min_free_bytes >> 20));
	return 0;
}

void rec_shutdown(void)
{
	if (!rec_enabled) return;
	sched_shutdown();
	ctl_stop();
	rec_stop("shutdown");
	pthread_mutex_lock(&R.m);
	for (int i = 0; i < 100 && R.active; i++) {                /* up to ~10 s for the file to be finalised */
		struct timespec ts;
		clock_gettime(CLOCK_REALTIME, &ts); ts.tv_nsec += 100 * 1000000L; if (ts.tv_nsec >= 1000000000L) { ts.tv_sec++; ts.tv_nsec -= 1000000000L; }
		pthread_cond_timedwait(&R.cv, &R.m, &ts);
	}
	pthread_mutex_unlock(&R.m);
	rec_enabled = 0;
}
