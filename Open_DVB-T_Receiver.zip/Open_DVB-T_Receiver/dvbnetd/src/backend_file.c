/* SPDX-License-Identifier: GPL-2.0-or-later
 * dvbnetd - PLAYBACK backend (dvbnetd -p FILE): serves a recorded transport stream through the unchanged protocol server.
 * No tuner is touched. To the client (the Android app) this is an ordinary receiver: GET_CAPABILITIES, TUNE, SET_PIDS and
 * GET_STATUS behave as in live mode, and the stream arrives on the transfer socket.
 *
 *  - The file starts from the beginning when the client first tunes (once per connection).
 *  - Timing is the broadcast's own: delivery is paced by the PCR clock inside the stream, so the original data rate is
 *    reproduced. A stream without PCR is paced at --play-rate (or the rate stored in the recording's .info).
 *  - TUNE succeeds only for the frequency the recording was made on (read from FILE.info; any frequency is accepted for
 *    a foreign .ts without .info). A different frequency fails exactly like an unlockable channel on a real tuner.
 *  - At the end of the file the stream stops and GET_STATUS reports "no lock", like a transmitter that went off air.
 *    With --loop the recording restarts from the beginning instead. */
#define _GNU_SOURCE
#include "backend.h"
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#define TS_LEN 188
#define PCR_HZ 27000000LL
#define START_DELAY_MS 700

static char g_path[1024];
static int g_loop;
static double g_rate_mbps;           /* fallback pacing, Mbit/s */
static int64_t m_freq, m_bw;         /* from FILE.info (0 = unknown) */
static int m_sys = -1;
static double m_info_rate;

static int pfd[2] = { -1, -1 };
static int ffd = -1;
static pthread_t th;
static volatile int run, started, ended, tuned;

int backend_file_configure(const char *path, int loop, double rate_mbps)
{
	char ip[1100], line[200];
	FILE *f;
	long long start = 0, end = 0, bytes = 0;

	snprintf(g_path, sizeof g_path, "%s", path);
	g_loop = loop; g_rate_mbps = rate_mbps;
	m_freq = m_bw = 0; m_sys = -1; m_info_rate = 0;
	if (access(path, R_OK) != 0) return -1;
	snprintf(ip, sizeof ip, "%s.info", path);
	f = fopen(ip, "r");
	if (f) {
		while (fgets(line, sizeof line, f)) {
			long long v;
			if (sscanf(line, "freq_hz=%lld", &v) == 1) m_freq = v;
			else if (sscanf(line, "bw_hz=%lld", &v) == 1) m_bw = v;
			else if (sscanf(line, "system=%lld", &v) == 1) m_sys = (int)v;
			else if (sscanf(line, "start=%lld", &v) == 1) start = v;
			else if (sscanf(line, "end=%lld", &v) == 1 && v > 0) end = v;
			else if (sscanf(line, "bytes=%lld", &v) == 1) bytes = v;
		}
		fclose(f);
		if (end > start && bytes > 0) m_info_rate = (double)bytes * 8.0 / (double)(end - start) / 1e6;
	}
	return 0;
}

static int64_t now_ns(void)
{
	struct timespec t;
	clock_gettime(CLOCK_MONOTONIC, &t);
	return (int64_t)t.tv_sec * 1000000000LL + t.tv_nsec;
}

static void sleep_until_ns(int64_t when)
{
	while (run) {
		int64_t d = when - now_ns();
		struct timespec ts;
		if (d <= 0) return;
		if (d > 50000000LL) d = 50000000LL;     /* wake up often enough to notice a stop request */
		ts.tv_sec = 0; ts.tv_nsec = (long)d;
		nanosleep(&ts, NULL);
	}
}

static int write_all(const uint8_t *p, size_t n)
{
	while (n && run) {
		struct pollfd pf = { .fd = pfd[1], .events = POLLOUT };
		ssize_t w;
		if (poll(&pf, 1, 100) <= 0) continue;
		w = write(pfd[1], p, n);
		if (w < 0) { if (errno == EAGAIN || errno == EINTR) continue; return -1; }
		p += w; n -= (size_t)w;
	}
	return run ? 0 : -1;
}

static int pcr_of(const uint8_t *pk, int64_t *pcr)
{
	if (!(pk[3] & 0x20) || pk[4] < 7 || !(pk[5] & 0x10)) return 0;
	*pcr = (((int64_t)pk[6] << 25) | ((int64_t)pk[7] << 17) | ((int64_t)pk[8] << 9) | ((int64_t)pk[9] << 1) | (pk[10] >> 7)) * 300 +
	       (((pk[10] & 1) << 8) | pk[11]);
	return 1;
}

static void *feeder(void *a)
{
	uint8_t buf[TS_LEN * 256];
	size_t have = 0;
	int64_t t0 = now_ns(), last_pcr = -1, ticks = 0, sent = 0;
	int pcr_pid = -1;
	double rate = g_rate_mbps > 0 ? g_rate_mbps : (m_info_rate > 0 ? m_info_rate : 12.0);
	(void)a;

	/* A client tunes first and sets its PID filter a moment later (until then only PID 0 passes, as with a real tuner).
	 * Waiting a little before the first byte makes the recording reach the client from its very first packet. */
	for (int i = 0; i < START_DELAY_MS / 10 && run; i++) usleep(10000);
	t0 = now_ns();

	while (run) {
		ssize_t n = read(ffd, buf + have, sizeof buf - have);
		size_t npk, batch = 0;
		if (n < 0 && errno == EINTR) continue;
		if (n <= 0) {                                          /* end of the recording */
			if (g_loop && have == 0 && lseek(ffd, 0, SEEK_SET) == 0) { t0 = now_ns(); last_pcr = -1; ticks = 0; sent = 0; pcr_pid = -1; continue; }
			ended = 1;
			fprintf(stderr, "playback: end of recording\n");
			while (run) usleep(100000);                          /* stay quiet until the client leaves */
			break;
		}
		have += (size_t)n;
		npk = have / TS_LEN;
		for (size_t i = 0; i < npk; i++) {
			const uint8_t *pk = buf + i * TS_LEN;
			int64_t pcr;
			if (pk[0] != 0x47) continue;
			if (pcr_of(pk, &pcr)) {
				int pid = ((pk[1] & 0x1f) << 8) | pk[2];
				if (pcr_pid < 0) pcr_pid = pid;
				if (pid == pcr_pid) {
					if (last_pcr >= 0) {
						int64_t dlt = pcr - last_pcr;
						if (dlt < 0) dlt += (1LL << 33) * 300;       /* 33-bit base wrap */
						ticks += (dlt <= 2 * PCR_HZ) ? dlt : PCR_HZ / 25;    /* a jump (splice/discontinuity): continue at 40 ms */
					}
					last_pcr = pcr;
					if (write_all(buf + batch * TS_LEN, (i + 1 - batch) * TS_LEN) < 0) goto out;
					sent += (int64_t)(i + 1 - batch) * TS_LEN;
					batch = i + 1;
					sleep_until_ns(t0 + ticks * 1000000000LL / PCR_HZ);
				}
			}
		}
		if (batch < npk) {
			if (write_all(buf + batch * TS_LEN, (npk - batch) * TS_LEN) < 0) goto out;
			sent += (int64_t)(npk - batch) * TS_LEN;
			if (pcr_pid < 0) sleep_until_ns(t0 + (int64_t)((double)sent * 8.0 / (rate * 1e6) * 1e9));   /* no PCR (yet): constant rate */
		}
		have -= npk * TS_LEN;
		if (have) memmove(buf, buf + npk * TS_LEN, have);
	}
out:
	return NULL;
}

static int be_open(int adapter, int frontend, int buf)
{
	(void)adapter; (void)frontend; (void)buf;
	started = ended = tuned = 0;
	ffd = open(g_path, O_RDONLY | O_CLOEXEC);
	if (ffd < 0) { perror(g_path); return -1; }
	if (pipe2(pfd, O_CLOEXEC | O_NONBLOCK) < 0) { close(ffd); ffd = -1; return -1; }
	fcntl(pfd[1], F_SETPIPE_SZ, 256 * 1024);
	return 0;
}

static void be_close(void)
{
	if (started) { run = 0; pthread_join(th, NULL); started = 0; }
	if (pfd[0] >= 0) close(pfd[0]);
	if (pfd[1] >= 0) close(pfd[1]);
	if (ffd >= 0) close(ffd);
	pfd[0] = pfd[1] = ffd = -1;
	tuned = 0;
}

static int be_caps(struct be_caps *c)
{
	memset(c, 0, sizeof *c);
	c->system_mask = (1 << WSYS_T) | (m_sys == WSYS_T2 ? 1 << WSYS_T2 : 0);
	c->freq_min = 174000000; c->freq_max = 862000000; c->freq_step = 166667;
	c->vendor_id = 0x0bda; c->product_id = 0x2838;     /* presents itself like the RTL2832U stick the recording came from */
	return 0;
}

static int be_tune(int64_t f, int64_t bw, int sys)
{
	(void)bw;
	if (sys != WSYS_T && sys != WSYS_T2) return -1;
	if (m_freq && (f < m_freq - 1000 || f > m_freq + 1000)) { fprintf(stderr, "playback: tune %.3f MHz refused (recording is %.3f MHz)\n", (double)f / 1e6, (double)m_freq / 1e6); return -1; }
	if (m_sys >= 0 && sys != m_sys) return -1;
	tuned = 1;
	if (!started) {      /* first tune of this connection: the recording starts from the beginning */
		run = 1;
		if (pthread_create(&th, NULL, feeder, NULL) != 0) { run = 0; return -1; }
		started = 1;
	}
	return 0;
}

static int be_status(struct be_status *s)
{
	int lock = tuned && !ended;
	memset(s, 0, sizeof *s);
	s->snr = lock ? 250 : 0; s->ber = lock ? 0 : 0xFFFF; s->rf_percent = lock ? 80 : 0;
	s->has_signal = s->has_carrier = s->has_sync = s->has_lock = lock;
	return 0;
}

static int be_dvr_fd(void) { return pfd[0]; }

const struct backend backend_file = { be_open, be_close, be_caps, be_tune, be_status, be_dvr_fd };
