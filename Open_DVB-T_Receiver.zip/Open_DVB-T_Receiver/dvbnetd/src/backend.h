/* SPDX-License-Identifier: GPL-2.0-or-later
 * dvbnetd - interface between the protocol server and a DVB source.
 * Implementations: backend_linux.c (real /dev/dvb) and
 * backend_fake.c (TEST ONLY synthetic TS, used by `make test`). */
#ifndef DVBNETD_BACKEND_H
#define DVBNETD_BACKEND_H
#include <stdint.h>

/* Wire-protocol delivery-system ordinals = DeliverySystem.java order: DVBT, DVBT2, DVBC. */
enum { WSYS_T = 0, WSYS_T2 = 1, WSYS_C = 2 };

struct be_caps {
	int64_t system_mask;                    /* bit (1 << ordinal) */
	int64_t freq_min, freq_max, freq_step;  /* Hz */
	int64_t vendor_id, product_id;
};
/* Units follow AndroidDvbDriver:
 *   snr         0.1 dB resolution (0 when unavailable)
 *   ber         0..0xFFFF, 0xFFFF = 100 % errors / no lock / unavailable
 *   rf_percent  0..100
 * "dropped USB fps" is NOT here: the server derives it from the TS (ts_stats). */
struct be_status {
	int64_t snr, ber, rf_percent;
	int has_signal, has_carrier, has_sync, has_lock;
};

struct backend {
	int  (*open)(int adapter, int frontend, int dvr_buf_bytes); /* 0 / -1 */
	void (*close)(void);
	int  (*caps)(struct be_caps *c);
	int  (*tune)(int64_t freq_hz, int64_t bw_hz, int system);   /* 0 / -1 */
	int  (*status)(struct be_status *s);
	int  (*dvr_fd)(void);       /* pollable fd delivering 188-byte aligned TS */
};
extern const struct backend backend_impl;
#endif
