/* SPDX-License-Identifier: GPL-2.0-or-later
 * dvbnetd - local control socket of the optional recorder: <rec-dir>/dvbnetd.sock (UNIX domain, never a network port).
 * One request line "VERB key=value ...", reply lines "> text" ending with "OK ..." or "ERR ...".  Used by `dvbnetd rec ...`. */
#define _GNU_SOURCE
#include "rec.h"
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/un.h>
#include <unistd.h>

static pthread_t th;
static int lfd = -1, started;
static volatile int quit;
static char sockpath[REC_PATH_MAX + 32];

const char *ctl_socket_path(const char *dir, char *buf, size_t n)
{
	snprintf(buf, n, "%s/dvbnetd.sock", dir);
	return buf;
}

struct out { int fd; };
static void put_line(void *ctx, const char *s)
{
	struct out *o = ctx;
	char b[700];
	int n = snprintf(b, sizeof b, "> %s\n", s);
	if (n > 0) (void)!write(o->fd, b, (size_t)(n < (int)sizeof b ? n : (int)sizeof b - 1));
}
static void put_block(struct out *o, const char *text)
{
	char b[1024];
	snprintf(b, sizeof b, "%s", text);
	for (char *l = strtok(b, "\n"); l; l = strtok(NULL, "\n")) put_line(o, l);
}
static void finish(struct out *o, int ok, const char *msg)
{
	char b[400];
	int n = snprintf(b, sizeof b, "%s %s\n", ok ? "OK" : "ERR", msg);
	(void)!write(o->fd, b, (size_t)n);
}

static const char *arg(char *line, const char *key, char *buf, size_t n)
{
	size_t kl = strlen(key);
	buf[0] = 0;
	for (char *p = strstr(line, key); p; p = strstr(p + 1, key)) {
		if ((p == line || p[-1] == ' ') && p[kl] == '=') {
			size_t i = 0;
			for (p += kl + 1; *p && *p != ' ' && i + 1 < n; p++) buf[i++] = *p;
			buf[i] = 0;
			return buf;
		}
	}
	return NULL;
}

static void parse_req(char *line, struct rec_req *r)
{
	char v[512];
	memset(r, 0, sizeof *r);
	r->bw_hz = 8000000;
	if (arg(line, "freq", v, sizeof v)) r->freq_hz = atoll(v);
	if (arg(line, "bw", v, sizeof v)) r->bw_hz = atoll(v);
	if (arg(line, "sys", v, sizeof v)) r->system = atoi(v);
	if (arg(line, "dur", v, sizeof v)) r->duration_s = atoll(v);
	if (arg(line, "tag", v, sizeof v)) snprintf(r->tag, sizeof r->tag, "%s", v);
	if (arg(line, "mode", v, sizeof v)) r->mode = !strcmp(v, "pids") ? REC_PIDS : !strcmp(v, "service") ? REC_SERVICE : REC_FULL;
	if (arg(line, "svc", v, sizeof v)) r->service_id = atoi(v);
	if (arg(line, "pids", v, sizeof v))
		for (char *t = strtok(v, ","); t && r->npids < 64; t = strtok(NULL, ",")) { int p = (int)strtol(t, NULL, 0); if (p >= 0 && p < 8192) r->pids[r->npids++] = (uint16_t)p; }
}

static void handle(int fd)
{
	char line[1024], v[64], err[256] = "";
	struct out o = { fd };
	struct rec_req r;
	ssize_t n;

	n = read(fd, line, sizeof line - 1);
	if (n <= 0) return;
	line[n] = 0; line[strcspn(line, "\r\n")] = 0;

	if (!strncmp(line, "PING", 4)) finish(&o, 1, "dvbnetd");
	else if (!strncmp(line, "START", 5)) {
		parse_req(line, &r);
		if (rec_start(&r, err, sizeof err) < 0) finish(&o, 0, err);
		else { char st[1024]; rec_status_text(st, sizeof st); put_block(&o, st); finish(&o, 1, "recording started"); }
	} else if (!strncmp(line, "STOP", 4)) {
		if (rec_stop("user") < 0) finish(&o, 0, "no recording is running");
		else {
			for (int i = 0; i < 100 && rec_active(); i++) usleep(100000);
			finish(&o, 1, rec_active() ? "stopping (still flushing to disk)" : "recording stopped and saved");
		}
	} else if (!strncmp(line, "STATUS", 6)) {
		char st[1024];
		rec_status_text(st, sizeof st); put_block(&o, st);
		finish(&o, 1, "");
	} else if (!strncmp(line, "LIST", 4)) {
		char dir[REC_PATH_MAX];
		if (arg(line, "dir", dir, sizeof dir)) rec_list_text(dir, put_line, &o);
		finish(&o, 1, "");
	} else if (!strncmp(line, "SCHEDULES", 9)) {
		sched_list_text(put_line, &o);
		finish(&o, 1, "");
	} else if (!strncmp(line, "SCHED", 5)) {
		time_t s, e;
		int id;
		parse_req(line, &r);
		s = arg(line, "start", v, sizeof v) ? (time_t)atoll(v) : 0;
		e = arg(line, "end", v, sizeof v) ? (time_t)atoll(v) : 0;
		id = sched_add(&r, s, e, err, sizeof err);
		if (id < 0) finish(&o, 0, err);
		else { snprintf(err, sizeof err, "scheduled recording #%d added", id); finish(&o, 1, err); }
	} else if (!strncmp(line, "CANCEL", 6)) {
		int id = arg(line, "id", v, sizeof v) ? atoi(v) : 0;
		if (sched_cancel(id, err, sizeof err) < 0) finish(&o, 0, err);
		else finish(&o, 1, "cancelled");
	} else finish(&o, 0, "unknown command");
}

static void *serve(void *a)
{
	(void)a;
	while (!quit) {
		struct pollfd pf = { .fd = lfd, .events = POLLIN };
		int c;
		if (poll(&pf, 1, 300) <= 0) continue;
		c = accept4(lfd, NULL, NULL, SOCK_CLOEXEC);
		if (c < 0) continue;
		{ struct timeval tv = { 2, 0 }; setsockopt(c, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv); }
		handle(c);
		close(c);
	}
	return NULL;
}

int ctl_start(const char *dir, unsigned mode)
{
	struct sockaddr_un a;
	ctl_socket_path(dir, sockpath, sizeof sockpath);
	if (strlen(sockpath) >= sizeof a.sun_path) return -1;
	lfd = socket(AF_UNIX, SOCK_STREAM | SOCK_CLOEXEC, 0);
	if (lfd < 0) return -1;
	memset(&a, 0, sizeof a);
	a.sun_family = AF_UNIX;
	strcpy(a.sun_path, sockpath);
	unlink(sockpath);
	if (bind(lfd, (struct sockaddr *)&a, sizeof a) < 0 || listen(lfd, 4) < 0) { close(lfd); lfd = -1; return -1; }
	chmod(sockpath, mode);
	quit = 0;
	if (pthread_create(&th, NULL, serve, NULL) != 0) { close(lfd); lfd = -1; return -1; }
	started = 1;
	return 0;
}

void ctl_stop(void)
{
	if (!started) return;
	quit = 1;
	pthread_join(th, NULL);
	close(lfd); lfd = -1; started = 0;
	unlink(sockpath);
}
