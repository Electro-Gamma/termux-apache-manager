/* SPDX-License-Identifier: GPL-2.0-or-later
 * See ts_stats.h. Port of DvbDemux.java (AndroidDvbDriver, Signalware Ltd). */
#include "ts_stats.h"
#include <limits.h>
#include <math.h>
#include <string.h>
#include <time.h>

int64_t ts_now_ms(void)
{
	struct timespec t;
	clock_gettime(CLOCK_MONOTONIC, &t);
	return (int64_t)t.tv_sec * 1000 + t.tv_nsec / 1000000;
}

void ts_stats_init(struct ts_stats *s, int64_t now_ms)
{
	memset(s, 0, sizeof *s);
	s->last_ms = now_ms;
}

void ts_stats_reset(struct ts_stats *s, int64_t now_ms)
{
	s->dropped = 0;
	s->last_ms = now_ms;
}

/* returns 1 if the packet's continuity counter is as expected */
static int check_sequence(struct ts_stats *s, int pid, const uint8_t *b)
{
	int loc, val;

	if (pid == 0x1FFF) return 1;           /* garbage PID, always ignored */
	loc = pid >> 1;
	if ((pid & 1) == 0) {                  /* even PIDs live in the high nibble */
		if ((b[3] & 0x10) != 0) {
			val = ((s->cnt[loc] & 0xF0) + 0x10) & 0xF0;
			s->cnt[loc] = (uint8_t)((s->cnt[loc] & 0x0F) | val);
		}
		if ((b[3] & 0x0F) != ((s->cnt[loc] & 0xF0) >> 4)) {
			val = (b[3] & 0x0F) << 4;
			s->cnt[loc] = (uint8_t)((s->cnt[loc] & 0x0F) | val);
			return 0;
		}
		return 1;
	}
	if ((b[3] & 0x10) != 0) {              /* odd PIDs live in the low nibble */
		val = ((s->cnt[loc] & 0x0F) + 0x01) & 0x0F;
		s->cnt[loc] = (uint8_t)((s->cnt[loc] & 0xF0) | val);
	}
	if ((b[3] & 0x0F) != (s->cnt[loc] & 0x0F)) {
		val = b[3] & 0x0F;
		s->cnt[loc] = (uint8_t)((s->cnt[loc] & 0xF0) | val);
		return 0;
	}
	return 1;
}

void ts_stats_packet(struct ts_stats *s, const uint8_t *pk)
{
	int pid = ((pk[1] & 0x1F) << 8) + pk[2];

	if ((pk[1] & 0x80) != 0) {
		s->dropped++;   /* transport error indicator; packet is still passed on (DVB_DEMUX_FEED_ERR_PKTS) */
	} else if (!check_sequence(s, pid, pk)) {
		s->dropped++;
	}
}

int ts_stats_rate(struct ts_stats *s, int64_t now_ms)
{
	int64_t elapsed = now_ms - s->last_ms;
	double fps;

	s->last_ms = now_ms;
	/* Java: double fps = dropped * 1000.0 / elapsed; (int) Math.abs(fps)  (NaN -> 0, Infinity -> INT_MAX) */
	if (elapsed == 0) {
		int r = s->dropped == 0 ? 0 : INT_MAX;
		s->dropped = 0;
		return r;
	}
	fps = s->dropped * 1000.0 / (double)elapsed;
	s->dropped = 0;
	fps = fabs(fps);
	return fps >= (double)INT_MAX ? INT_MAX : (int)fps;
}
