# dvbnetd - Raspberry Pi / Banana Pi / Orange Pi as a network DVB-T/T2 receiver

    USB DVB-T/T2 stick -> Linux DVB kernel drivers -> dvbnetd --TCP/Wi-Fi-->
        patched AndroidDvbDriver (DvbNetworkDevice) -> loopback dtvdriver: contract -> Open DVB-T Receiver (unmodified)

License GPL-2.0-or-later. `ts_stats.c` is a port of logic from AndroidDvbDriver (Signalware Ltd, GPL-2.0-or-later);
the Linux DVB uAPI headers are the only kernel code used. Read `docs/REPORT.md` first: it separates what was
verified from what was not (no hardware or ARM test has been done).

## 1. What must be true on the Pi
    lsusb                                 # stick visible
    dmesg | grep -i -E 'rtl28|dvb|r820'   # kernel driver bound, firmware loaded
    ls /dev/dvb/adapter0                  # frontend0 demux0 dvr0 must exist
The RTL2832U demodulates in hardware through the kernel's `dvb_usb_rtl28xxu`; the Pi's CPU only moves the TS.
If you ever installed the `rtl-sdr` package, it blacklists that driver (see /etc/modprobe.d/*rtl*): remove the
blacklist line and replug. A stock RTL2832 stick is **DVB-T only**; dvbnetd offers T2 only if the kernel says so.

## 2. Build and install
Natively on the board (simplest):

    sudo apt update && sudo apt install -y build-essential make
    make && sudo make install

Cross-compile (ARMv7 and ARM64, static): `sudo apt install gcc-arm-linux-gnueabihf gcc-aarch64-linux-gnu` then
`sh scripts/build-arm.sh` -> `dist/dvbnetd-armv7`, `dist/dvbnetd-arm64`. Pick by `uname -m` on the board
(`armv7l` / `aarch64`). Raspberry Pi Zero 2 W, Banana Pi M2 Zero and Orange Pi: any of them works if its kernel
provides the DVB device nodes above; that depends on the OS image, check section 1 on your board.

## 3. Run and autostart
    dvbnetd -v                                   # control port 7500, transfer port 7501
    sudo install -m644 systemd/dvbnetd.service /etc/systemd/system/
    sudo install -m644 udev/99-dvb.rules /etc/udev/rules.d/
    sudo systemctl daemon-reload && sudo systemctl enable --now dvbnetd
    journalctl -u dvbnetd -f
The service runs unprivileged (group `video`). Memory use is a few MB plus the 1 MiB `dvr0` buffer and a 512 KiB
per-client backlog (`--dvr-buffer`, `--backlog`).

## 4. Network
* Same LAN for phone and board; give the board a fixed IP or DHCP reservation. Allow TCP 7500 and 7501 from the phone only.
* **There is no authentication.** Use a trusted network, `--bind` to one interface, or an SSH/WireGuard tunnel.
* The Pi Zero 2 W and Banana Pi M2 Zero have 2.4 GHz Wi-Fi only (untested here). A full DVB-T mux can exceed what
  that carries, so the PID filter matters: the Android driver sends it to the Pi, so only the selected service crosses the air.
  Ethernet via USB adapter is the robust choice if you see stutter (`journalctl` reports dropped packets per session).

## 5. Android
1. Build the patched driver with the notebook `AndroidDvbDriver_APK_Release_network.ipynb` (or Gradle) and install it.
2. Open "DVB-T Driver" -> **Network receiver (Raspberry Pi)** -> enter the board's IP (ports 7500/7501) ->
   "Save and test connection". The result shows the stick's USB ids and capabilities as the Pi reports them.
3. In Open DVB-T Receiver press Connect as usual. With only the network receiver configured it connects straight away;
   with a USB tuner attached too, the driver's device chooser lists both. Clear the address to go back to USB only.
Open DVB-T Receiver itself is not modified.

## 6. Troubleshooting
| Symptom | Check |
|---|---|
| Test connection fails immediately | service running (`systemctl status dvbnetd`), IP, firewall, same network |
| Connects, then closes at once | `journalctl -u dvbnetd`: cannot open `/dev/dvb/adapter0` (driver, blacklist, permissions) |
| Hangs about a minute | the Pi serves one client at a time; another client still holds the tuner |
| Connects, no lock | antenna/gain; `dmesg` for tuner errors; try `dvbv5-scan` (dvb-tools) on the Pi to separate RF from network |
| Stutter | Wi-Fi throughput; check dropped-packet lines in the journal; use Ethernet |
| "no devices found" | no USB receiver and no network address saved |

## 7. Recording, scheduling and playback (optional)
Everything in this section is off unless you ask for it: without `--rec-dir` / `-p` dvbnetd behaves exactly as before
(the test suite checks the protocol transcript against the previous binary).

**Enable recording** (daemon): `dvbnetd --rec-dir /var/lib/dvbnetd/recordings` or, for the service, install
`systemd/dvbnetd-recording.conf` as a drop-in (comments inside). Options: `--rec-min-free MB` (default 500: a recording
stops, and a new one is refused, below this free space), `--rec-max-size MB`, `--rec-buffer MB` (RAM buffer, default 4).
Add your user to the `video` group so the `dvbnetd rec` commands can reach the daemon (local UNIX socket `DIR/dvbnetd.sock`, no network port).

**Commands** (same binary; `--rec-dir` or `DVBNETD_REC_DIR` if you use another directory):

    dvbnetd rec start --mhz 610                      # record now, until you stop it (whole multiplex)
    dvbnetd rec start --mhz 610 --duration 30m       # 30m, 1h, 2h, 3h, 1h30m, 90 (minutes) ...
    dvbnetd rec start --mhz 610 --service 1 --duration 1h   # only one service (smaller files); or --pids 0,17,256,257
    dvbnetd rec stop                                 # finalises and keeps the file
    dvbnetd rec status                               # state, file, elapsed time, size, time left
    dvbnetd rec list                                 # name, start, length, size, MHz, status (works without the daemon)
    dvbnetd rec schedule --mhz 610 --from "6:00 PM" --to "7:00 PM"
    dvbnetd rec schedule --mhz 610 --from 23:00 --to 01:00            # overnight
    dvbnetd rec schedule --mhz 610 --from 8am --to 9:30am --date 2026-12-24
    dvbnetd rec schedules                            # pending / running / done / missed / failed / cancelled
    dvbnetd rec cancel 3                             # cancel before it starts (a running one is stopped, data kept)

Times are the Raspberry Pi's local clock; 12-hour (`6 PM`, `6:30pm`) and 24-hour (`18:30`) forms both work. Without `--date` the
next occurrence is used; with `--duration` instead of `--to` the end is computed. Windows may not overlap (one tuner). A job whose
window is already open when the daemon (re)starts begins late and still ends on time. A scheduled recording takes priority over a manual one.
Set the clock first (`timedatectl`): a Pi without a battery clock needs NTP.

**What is recorded.** The transport stream the tuner delivers (`dvr0`), unmodified, except that null packets (PID 0x1FFF)
are not stored. A full DVB-T multiplex is about 20 Mbit/s = roughly 9 GB per hour: use `--service` for one programme
(about 1-3 GB/h). `--service` follows the PAT/PMT, keeps the service's PMT, PCR, video and audio PIDs plus PAT/NIT/SDT/EIT/TDT.
Files: `YYYYMMDD_HHMMSS_<MHz>MHz[_name].ts` plus `.ts.info` (status, reason, frequency, bytes, ...). Existing files are never overwritten.

**Tuner sharing.** One tuner, so: a standalone recording owns it, and a client that connects meanwhile is refused (logged). If a client
is already connected and tuned, `rec start` without `--mhz` records that very multiplex from the client's stream (the client is unaffected);
if the client then disconnects, the recording continues on the tuner by itself. A different frequency than the client's is refused;
if the client retunes elsewhere the recording ends cleanly.

**Safety.** Disk free space is checked before and every second during recording; on low space, write errors, no data from the tuner for
2 minutes, size cap, or SIGTERM the file is flushed, trimmed to whole packets, fsync'ed and its `.info` says why it ended (`complete` /
`stopped` / `error`). After a power cut or crash the next start marks the unfinished file `interrupted` and trims it to whole packets.
The tuner never waits for the disk: the RAM buffer drops packets (counted as `dropped` in `rec status`) if the disk stalls.

**Playback without a tuner** (unplug the stick, if you like):

    dvbnetd -p /var/lib/dvbnetd/recordings/20261110_180000_610MHz.ts [--loop]
    dvbnetd play 20261110_180000_610MHz              # by name, from the recording directory

dvbnetd then serves the file through the unchanged protocol: connect the Android app exactly as for live reception (Network receiver,
Connect, pick a channel; the app's channel list for that frequency already works). The recording starts from the beginning
when the app tunes (about 0.7 s later, so the app's PID filter is in place), at the broadcast's own speed (paced by the PCR clock inside the
stream). Only the recorded frequency can be tuned (read from the `.info`; any frequency for a plain `.ts` without one). At the end of the file the
stream stops and the status reports "no lock", like a transmitter going off air; `--loop` restarts it. A second client starts again from the beginning.
Streams without PCR use `--play-rate MBPS`. Recording is disabled while in playback mode.

## 8. Tests
    make test                                   # packet-accounting + time-parsing unit tests
    make test-compat ANDROID_DRIVER_SRC=/path/to/AndroidDvbDriver-master   # differential protocol test (needs Java 11+)
    make dvbnetd-fake && python3 test/test_rec.py ./dvbnetd-fake [./previous-dvbnetd-fake]   # recording/scheduling/playback, synthetic backend
