# dvbnetd - Raspberry Pi / Banana Pi / Orange Pi as a network DVB-T/T2 receiver

    USB DVB-T/T2 stick -> Linux DVB kernel drivers -> dvbnetd --TCP/Wi-Fi-->
        patched AndroidDvbDriver (DvbNetworkDevice) -> loopback dtvdriver: contract -> Open DVB-T Receiver (unmodified)

License GPL-2.0-or-later. `ts_stats.c` is a port of logic from AndroidDvbDriver (Signalware Ltd, GPL-2.0-or-later);
the Linux DVB uAPI headers are the only kernel code used. Read `docs/REPORT.md` first: it separates what was
verified from what was not (no hardware or ARM test has been done).

## 1. What must be true on the Pi
    lsusb                                 # stick visible
    dmesg | grep -i -E 'rtl28|dvb|r820'   # kernel driver bound, firmware loaded
    ls /dev/dvb/adapter0                  # frontend0 demux0 dvr0 must exist
The RTL2832U demodulates in hardware through the kernel's `dvb_usb_rtl28xxu`; the Pi's CPU only moves the TS.
If you ever installed the `rtl-sdr` package, it blacklists that driver (see /etc/modprobe.d/*rtl*): remove the
blacklist line and replug. A stock RTL2832 stick is **DVB-T only**; dvbnetd offers T2 only if the kernel says so.

## 2. Build and install
Natively on the board (simplest):

    sudo apt update && sudo apt install -y build-essential make
    make && sudo make install

Cross-compile (ARMv7 and ARM64, static): `sudo apt install gcc-arm-linux-gnueabihf gcc-aarch64-linux-gnu` then
`sh scripts/build-arm.sh` -> `dist/dvbnetd-armv7`, `dist/dvbnetd-arm64`. Pick by `uname -m` on the board
(`armv7l` / `aarch64`). Raspberry Pi Zero 2 W, Banana Pi M2 Zero and Orange Pi: any of them works if its kernel
provides the DVB device nodes above; that depends on the OS image, check section 1 on your board.

## 3. Run and autostart
    dvbnetd -v                                   # control port 7500, transfer port 7501
    sudo install -m644 systemd/dvbnetd.service /etc/systemd/system/
    sudo install -m644 udev/99-dvb.rules /etc/udev/rules.d/
    sudo systemctl daemon-reload && sudo systemctl enable --now dvbnetd
    journalctl -u dvbnetd -f
The service runs unprivileged (group `video`). Memory use is a few MB plus the 1 MiB `dvr0` buffer and a 512 KiB
per-client backlog (`--dvr-buffer`, `--backlog`).

## 4. Network
* Same LAN for phone and board; give the board a fixed IP or DHCP reservation. Allow TCP 7500 and 7501 from the phone only.
* **There is no authentication.** Use a trusted network, `--bind` to one interface, or an SSH/WireGuard tunnel.
* The Pi Zero 2 W and Banana Pi M2 Zero have 2.4 GHz Wi-Fi only (untested here). A full DVB-T mux can exceed what
  that carries, so the PID filter matters: the Android driver sends it to the Pi, so only the selected service crosses the air.
  Ethernet via USB adapter is the robust choice if you see stutter (`journalctl` reports dropped packets per session).

## 5. Android
1. Build the patched driver with the notebook `AndroidDvbDriver_APK_Release_network.ipynb` (or Gradle) and install it.
2. Open "DVB-T Driver" -> **Network receiver (Raspberry Pi)** -> enter the board's IP (ports 7500/7501) ->
   "Save and test connection". The result shows the stick's USB ids and capabilities as the Pi reports them.
3. In Open DVB-T Receiver press Connect as usual. With only the network receiver configured it connects straight away;
   with a USB tuner attached too, the driver's device chooser lists both. Clear the address to go back to USB only.
Open DVB-T Receiver itself is not modified.

## 6. Troubleshooting
| Symptom | Check |
|---|---|
| Test connection fails immediately | service running (`systemctl status dvbnetd`), IP, firewall, same network |
| Connects, then closes at once | `journalctl -u dvbnetd`: cannot open `/dev/dvb/adapter0` (driver, blacklist, permissions) |
| Hangs about a minute | the Pi serves one client at a time; another client still holds the tuner |
| Connects, no lock | antenna/gain; `dmesg` for tuner errors; try `dvbv5-scan` (dvb-tools) on the Pi to separate RF from network |
| Stutter | Wi-Fi throughput; check dropped-packet lines in the journal; use Ethernet |
| "no devices found" | no USB receiver and no network address saved |

## 7. Tests
    make test                                   # packet-accounting unit test
    make test-compat ANDROID_DRIVER_SRC=/path/to/AndroidDvbDriver-master   # differential protocol test (needs Java 11+)
