# Third-party components

| Component | Use | Licence | Notes |
|---|---|---|---|
| libVLC for Android (`org.videolan.android:libvlc-all`, VideoLAN) | playback engine, bundled in the APK as native libraries | LGPL-2.1-or-later (libVLC); JNI/Java wrapper LGPL-2.1+ | Taken from Maven Central, **not** extracted from any other app. If you redistribute the APK you must comply with the LGPL (offer the corresponding libVLC source, allow relinking/replacing the libraries). Source: https://code.videolan.org/videolan/vlc-android and https://code.videolan.org/videolan/vlc |
| AndroidDvbDriver (Signalware Ltd / Martin Marinov) | **built into this app**: modules `driverui` (UI), `dvbservice`, `drivers`, `usbxfer` (native `libUsbXfer.so`); still reached through the `dtvdriver:` intent + loopback TCP | GPL-2.0-or-later (`COPYING`) | Unmodified except for the network receiver (`drivers/.../network/`, `NetworkSettings`, `NetworkReceiverActivity`), manifest/theme/resource adjustments listed in `docs/INTEGRATION.md`, and the removed launcher entry. Upstream: https://github.com/signalwareltd/AndroidDvbDriver |
| `dvbnetd` (`dvbnetd/`) | optional Linux server for the network receiver; not part of the APK | GPL-2.0-or-later | Written for this project; `ts_stats.c` ports packet-accounting logic from AndroidDvbDriver's `DvbDemux.java`. Only public Linux DVB uAPI headers are used. |
| AndroidX AppCompat / Core / Activity | UI | Apache-2.0 | |
| Kotlin stdlib | | Apache-2.0 | |

No code, assets, branding, keys or binaries from Aerial TV are included. Aerial TV's trial/licensing logic was not examined or bypassed.

**Combined work:** the APK contains MIT code (Open DVB Receiver), GPL-2.0-or-later code (the driver modules) and LGPL libraries (libVLC). Distribute it under terms that satisfy all of them (in practice GPL-2.0-or-later for the whole, with the corresponding source - this project - available to recipients). This is a practical note, not legal advice.
