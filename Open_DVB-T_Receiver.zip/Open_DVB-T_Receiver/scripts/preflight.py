#!/usr/bin/env python3
"""Static pre-flight checks for the integrated Open DVB-T Receiver project (no Android SDK needed).
Simulates the parts of the build most likely to break after merging the app with the driver modules:
Gradle wiring, manifest-merge conflicts, launcher count, resource collisions, class lookups.
Usage: preflight.py [project_root]. Exit status 1 if any check fails."""
import os, re, sys, glob
import xml.etree.ElementTree as ET

ROOT = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), ".."))
A = "{http://schemas.android.com/apk/res/android}"
T = "{http://schemas.android.com/tools}"
fails, results = [], []

def check(name, ok, detail=""):
    results.append((ok, name, detail))
    if not ok: fails.append(name)

def read(p): return open(os.path.join(ROOT, p), encoding="utf-8", errors="replace").read()

# --- Gradle wiring
settings = read("settings.gradle")
modules = re.findall(r"^include\s+'?:([\w-]+)'?", settings, re.M)
check("settings.gradle includes app + 4 driver modules", sorted(modules) == sorted(["app", "driverui", "dvbservice", "drivers", "usbxfer"]), str(modules))
for m in modules:
    ok = os.path.isfile(f"{ROOT}/{m}/build.gradle") and os.path.isfile(f"{ROOT}/{m}/src/main/AndroidManifest.xml")
    check(f"module {m}: build.gradle + manifest present", ok)
root_gradle = read("build.gradle")
vers = set(re.findall(r"com\.android\.(?:application|library)'\s+version\s+'([\d.]+)'", root_gradle))
check("one AGP version for application and library plugins", len(vers) == 1, str(vers))
props = read("gradle.properties")
check("gradle.properties: android.nonFinalResIds=false (driver Java uses R.id in switch)", re.search(r"^android\.nonFinalResIds=false", props, re.M) is not None)
check("gradle.properties: libvlcVersion present", re.search(r"^libvlcVersion=\S+", props, re.M) is not None)
check("gradle wrapper jar present", os.path.isfile(f"{ROOT}/gradle/wrapper/gradle-wrapper.jar"))
app_gradle = read("app/build.gradle")
for dep in ("driverui", "dvbservice", "drivers"):
    check(f"app depends on :{dep}", f"project(':{dep}')" in app_gradle)
check("driverui is a library module", "com.android.library" in read("driverui/build.gradle") and "applicationId" not in read("driverui/build.gradle"))
check("native build configured (usbxfer CMake)", "externalNativeBuild" in read("usbxfer/build.gradle") and os.path.isfile(f"{ROOT}/usbxfer/src/main/cpp/CMakeLists.txt"))
ns = {}
for m in modules:
    n = re.search(r"namespace\s+'([^']+)'", read(f"{m}/build.gradle"))
    ns[m] = n.group(1) if n else None
check("every module has a unique namespace", None not in ns.values() and len(set(ns.values())) == len(ns), str(ns))

# --- manifests
man = {m: ET.parse(f"{ROOT}/{m}/src/main/AndroidManifest.xml").getroot() for m in modules}
launchers = []
for m, r in man.items():
    for act in r.iter("activity"):
        for f in act.iter("intent-filter"):
            if any(c.get(A + "name") == "android.intent.category.LAUNCHER" for c in f.iter("category")):
                launchers.append(f"{m}:{act.get(A + 'name')}")
check("exactly one launcher activity in the whole project", launchers == [launchers[0]] if launchers else False, str(launchers))
check("the launcher is Open DVB-T Receiver's MainActivity", launchers == ["app:.ui.MainActivity"], str(launchers))
app_el = man["app"].find("application")
conflicts = []
for m, r in man.items():
    if m == "app": continue
    lib_app = r.find("application")
    for k, v in (lib_app.attrib.items() if lib_app is not None else []):
        if k.startswith(T): continue
        if k in app_el.attrib and app_el.attrib[k] != v and (T + "replace") not in app_el.attrib: conflicts.append((m, k))
        if k in (A + "icon", A + "theme", A + "label", A + "allowBackup", A + "supportsRtl"):
            conflicts.append((m, k + " set on a library <application> (belongs to the app)"))
check("no application-attribute conflicts between app and library manifests", not conflicts, str(conflicts))
bad_feat = []
for m, r in man.items():
    for uf in r.iter("uses-feature"):
        if m != "app" and uf.get(A + "required", "true") == "true" and uf.get(A + "name"):
            bad_feat.append((m, uf.get(A + "name")))
check("no library forces a required <uses-feature> (the merger ORs 'required')", not bad_feat, str(bad_feat))
for m, r in man.items():
    pkg = ns[m]
    for tag in ("activity", "service", "receiver", "provider"):
        for el in r.iter(tag):
            name = el.get(A + "name")
            fq = (pkg + name) if name.startswith(".") else (name if "." in name else pkg + "." + name)
            rel = fq.replace(".", "/")
            found = any(os.path.isfile(f"{ROOT}/{mm}/src/main/{kind}/{rel}.{ext}") for mm in modules for kind, ext in (("java", "java"), ("java", "kt")))
            check(f"{m}: {tag} {name} has a source file", found, fq)
unexported = []
for m, r in man.items():
    for el in r.iter("activity"):
        if el.find("intent-filter") is not None and el.get(A + "exported") is None:
            unexported.append((m, el.get(A + "name")))
check("activities with intent filters declare android:exported (required for targetSdk 31+)", not unexported, str(unexported))
for want in ("DeviceChooserActivity", "UsbDelegate", "DvbService"):
    check(f"merged project declares {want}", any(want in (e.get(A + "name") or "") for r in man.values() for e in r.iter()))
for want in ("DvbFrontendActivity", "NetworkReceiverActivity", "WelcomeActivity", "GplLicenseActivity"):
    check(f"driverui declares {want}", any(want in (e.get(A + "name") or "") for e in man["driverui"].iter("activity")))
check("DVB_DEVICE_ATTACHED filter kept on MainActivity", "info.martinmarinov.dvbdriver.DVB_DEVICE_ATTACHED" in read("app/src/main/AndroidManifest.xml"))

# --- resources: collisions that change behaviour after merging
defs = {}   # (type,name) -> {module: set(folders)}
texts = {}  # (type,name,folder) -> {module: serialized value}
for m in modules:
    for f in glob.glob(f"{ROOT}/{m}/src/main/res/values*/*.xml"):
        folder = os.path.basename(os.path.dirname(f))
        for el in ET.parse(f).getroot():
            nm = el.get("name")
            if nm:
                defs.setdefault((el.tag, nm), {}).setdefault(m, set()).add(folder)
                texts.setdefault((el.tag, nm, folder), {})[m] = ET.tostring(el, encoding="unicode", method="text").strip() + "|" + str(sorted(el.attrib.items())) + str([ET.tostring(c, encoding="unicode") for c in el])
app_defaults = {k for k, v in defs.items() if "app" in v and "values" in v["app"]}
overrides = [(k, m) for k in app_defaults for m, folders in defs[k].items() if m != "app" and any(fd != "values" for fd in folders)]
check("no library supplies a localized value for a resource the app defines (would override it)", not overrides, str(overrides))
dup_lib = [(k, v) for k, v in texts.items() if "app" not in v and len([m for m in v if m != "app"]) > 1 and len(set(v[m] for m in v if m != "app")) > 1]
check("no resource defined with different values by two library modules (identical duplicates are harmless)", not dup_lib, str(dup_lib))
check("theme names do not clash with the app's (AppTheme)", "driverui" not in defs.get(("style", "AppTheme"), {}))

# --- Kotlin <-> Java contract
main_kt = read("app/src/main/java/org/opendvb/receiver/ui/MainActivity.kt")
for cls in ("DvbFrontendActivity", "NetworkReceiverActivity", "WelcomeActivity"):
    src = read(f"driverui/src/main/java/info/martinmarinov/dvbdriver/{cls}.java")
    check(f"MainActivity -> {cls} is a public class", re.search(rf"public class {cls}\b", src) is not None and f"import info.martinmarinov.dvbdriver.{cls}" in main_kt)
ids = re.findall(r"menu\.add\(0, (\d+), (\d+),", main_kt)
check("menu item ids and orders are unique", len({i for i, _ in ids}) == len(ids) and len({o for _, o in ids}) == len(ids), str(ids))
titles = re.findall(r'menu\.add\(0, \d+, \d+, "([^"]+)"', main_kt)
for want in ("Driver diagnostics (Advanced mode)", "Network receiver (Raspberry Pi)", "Diagnostics", "Open .ts capture…", "Delete channel list", "About / licences", "Favourites only"):
    check(f"menu keeps/has '{want}'", want in titles)
check("driver intent is restricted to this app", "createIntent(this)" in main_kt and "setPackage(context.packageName)" in read("app/src/main/java/org/opendvb/receiver/driver/DriverLauncher.kt"))
check("original USB/loopback client code untouched (DriverClient/Connection/Protocol present)", all(os.path.isfile(f"{ROOT}/app/src/main/java/org/opendvb/receiver/driver/{f}.kt") for f in ("DriverClient", "DriverConnection", "DriverProtocol")))

# --- hygiene
junk = [p for p in glob.glob(ROOT + "/**/*", recursive=True) if re.search(r"\.(apk|aab|keystore|jks)$|/\.idea(/|$)|/build/", p) and "/dvbnetd/" not in p]
check("no binaries/IDE files in the tree", not junk, str(junk[:5]))

width = max(len(n) for _, n, _ in results)
for ok, n, d in results:
    print(("PASS  " if ok else "FAIL  ") + n + ("" if ok or not d else "   -> " + d))
print(f"\n{len(results) - len(fails)}/{len(results)} checks passed")
sys.exit(1 if fails else 0)
