/*
 * Network receiver support (dvbnetd client) for the Android user space port of DVB-T Linux kernel modules.
 * Structure derived from file/DvbFileDevice.java.
 *
 * Copyright (C) 2022 by Signalware Ltd <driver at aerialtv.eu>
 * Network additions: same licence.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

package info.martinmarinov.dvbdriver;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import info.martinmarinov.drivers.DvbCapabilities;
import info.martinmarinov.drivers.network.DvbNetworkDevice;
import info.martinmarinov.drivers.network.NetworkSettings;

/** Where to find the dvbnetd server. Saved settings make the network receiver appear in the device chooser. */
public class NetworkReceiverActivity extends UpActivity {
    private EditText host, controlPort, transferPort;
    private TextView result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle(R.string.network_title);
        setContentView(R.layout.activity_network_receiver);

        NetworkSettings.Target t = NetworkSettings.load(this);
        host = (EditText) findViewById(R.id.netHost);
        controlPort = (EditText) findViewById(R.id.netControlPort);
        transferPort = (EditText) findViewById(R.id.netTransferPort);
        result = (TextView) findViewById(R.id.netResult);
        host.setText(t.host);
        controlPort.setText(String.valueOf(t.controlPort));
        transferPort.setText(String.valueOf(t.transferPort));

        findViewById(R.id.netSave).setOnClickListener(v -> { if (save()) finish(); });
        findViewById(R.id.netTest).setOnClickListener(v -> { if (save()) testConnection(); });
    }

    private boolean save() {
        String h = host.getText().toString().trim();
        int c = parse(controlPort), t = parse(transferPort);
        if (!h.isEmpty() && (!NetworkSettings.validPort(c) || !NetworkSettings.validPort(t))) {
            Toast.makeText(this, R.string.network_bad_input, Toast.LENGTH_LONG).show();
            return false;
        }
        NetworkSettings.save(this, new NetworkSettings.Target(h, NetworkSettings.validPort(c) ? c : NetworkSettings.DEFAULT_CONTROL_PORT,
                NetworkSettings.validPort(t) ? t : NetworkSettings.DEFAULT_TRANSFER_PORT));
        return true;
    }

    private static int parse(EditText e) {
        try {
            return Integer.parseInt(e.getText().toString().trim());
        } catch (NumberFormatException ex) {
            return -1;
        }
    }

    /** Opens the network device, reads its capabilities, closes it. Shows what the server reports. */
    private void testConnection() {
        NetworkSettings.Target t = NetworkSettings.load(this);
        if (!t.isEnabled()) return;
        result.setText(R.string.network_testing);
        new Thread(() -> {
            String text;
            DvbNetworkDevice device = new DvbNetworkDevice(t.host, t.controlPort, t.transferPort);
            try {
                device.open();
                DvbCapabilities c = device.readCapabilities();
                text = "OK: " + device.getDeviceFilter().getVendorId() + ":" + device.getDeviceFilter().getProductId()
                        + "\n" + c;
            } catch (Exception e) {
                text = "Failed: " + e.getMessage();
            } finally {
                try { device.close(); } catch (Exception ignored) { }
            }
            final String shown = text;
            runOnUiThread(() -> result.setText(shown));
        }, "NetworkTest").start();
    }
}
