/*
 * Network receiver support (dvbnetd client) for the Android user space port of DVB-T Linux kernel modules.
 * Structure derived from file/DvbFileDevice.java.
 *
 * Copyright (C) 2022 by Signalware Ltd <driver at aerialtv.eu>
 * Network additions: same licence.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

package info.martinmarinov.dvbdriver;

import android.app.Activity;
import android.os.Bundle;
import android.text.InputType;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import info.martinmarinov.drivers.DvbCapabilities;
import info.martinmarinov.drivers.network.DvbNetworkDevice;
import info.martinmarinov.drivers.network.NetworkSettings;

/** Where to find the dvbnetd server. Saved settings make the network receiver appear in the device chooser. */
public class NetworkReceiverActivity extends Activity {
    private EditText host, controlPort, transferPort;
    private TextView result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle(R.string.network_title);

        NetworkSettings.Target t = NetworkSettings.load(this);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);

        TextView heading = new TextView(this);
        heading.setText(R.string.network_title);
        heading.setTextSize(20);
        TextView help = new TextView(this);
        help.setText(R.string.network_help);
        host = field(R.string.network_host_hint, t.host, InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        controlPort = field(R.string.network_control_port_hint, String.valueOf(t.controlPort), InputType.TYPE_CLASS_NUMBER);
        transferPort = field(R.string.network_transfer_port_hint, String.valueOf(t.transferPort), InputType.TYPE_CLASS_NUMBER);

        Button save = new Button(this);
        save.setText(R.string.network_save);
        save.setOnClickListener(v -> { if (save()) finish(); });
        Button test = new Button(this);
        test.setText(R.string.network_test);
        test.setOnClickListener(v -> { if (save()) testConnection(); });
        result = new TextView(this);

        for (android.view.View v : new android.view.View[] {heading, help, host, controlPort, transferPort, save, test, result}) {
            root.addView(v, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        setContentView(scroll);
    }

    private EditText field(int hint, String value, int inputType) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setText(value);
        e.setInputType(inputType);
        e.setSingleLine();
        return e;
    }

    private boolean save() {
        String h = host.getText().toString().trim();
        int c = parse(controlPort), t = parse(transferPort);
        if (!h.isEmpty() && (!NetworkSettings.validPort(c) || !NetworkSettings.validPort(t))) {
            Toast.makeText(this, R.string.network_bad_input, Toast.LENGTH_LONG).show();
            return false;
        }
        NetworkSettings.save(this, new NetworkSettings.Target(h, NetworkSettings.validPort(c) ? c : NetworkSettings.DEFAULT_CONTROL_PORT,
                NetworkSettings.validPort(t) ? t : NetworkSettings.DEFAULT_TRANSFER_PORT));
        return true;
    }

    private static int parse(EditText e) {
        try {
            return Integer.parseInt(e.getText().toString().trim());
        } catch (NumberFormatException ex) {
            return -1;
        }
    }

    /** Opens the network device, reads its capabilities, closes it. Shows what the server reports. */
    private void testConnection() {
        NetworkSettings.Target t = NetworkSettings.load(this);
        if (!t.isEnabled()) return;
        result.setText(R.string.network_testing);
        new Thread(() -> {
            String text;
            DvbNetworkDevice device = new DvbNetworkDevice(t.host, t.controlPort, t.transferPort);
            try {
                device.open();
                DvbCapabilities c = device.readCapabilities();
                text = "OK: " + device.getDeviceFilter().getVendorId() + ":" + device.getDeviceFilter().getProductId()
                        + "\n" + c;
            } catch (Exception e) {
                text = "Failed: " + e.getMessage();
            } finally {
                try { device.close(); } catch (Exception ignored) { }
            }
            final String shown = text;
            runOnUiThread(() -> result.setText(shown));
        }, "NetworkTest").start();
    }
}
