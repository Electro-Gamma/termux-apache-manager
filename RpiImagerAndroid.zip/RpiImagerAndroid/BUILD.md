# Building

## Easiest: Google Colab
1. Zip this folder (or use the supplied `RpiImagerAndroid.zip`).
2. Open `RpiImager_Android_Build.ipynb` in Colab, **Run all**, upload the zip when asked.
3. Download the signed APK and the keystore at the end (~45–75 min first run).

The notebook: runs host unit tests → installs JDK 17, CMake, Ninja → Android SDK 36 + NDK 27.2.12479018 →
Qt 6.9.1 (desktop + android_arm64_v8a kits via aqtinstall; only Core/Network are used) → creates a signing key →
`tools/build_native.py` (CMake cross-build of the original Imager CLI + deps; stages `librpiimagercli.so` and the
Qt Core/Network/libc++ libraries into `jniLibs`) → generates the Gradle wrapper → `assembleRelease` → verifies (aapt2, apksigner, native libs).

## Manually
```
python3 tools/build_native.py --qt-android <Qt>/6.9.1/android_arm64_v8a --qt-host <Qt>/6.9.1/gcc_64 \
        --sdk $ANDROID_HOME --ndk $ANDROID_HOME/ndk/27.2.12479018
gradle wrapper --gradle-version 8.14.3 && ./gradlew assembleRelease
```
Android Studio can open the project after `build_native.py` has run (it fills `jniLibs`).
Signing: set `RPI_KEYSTORE`, `RPI_KEYSTORE_PASS`, `RPI_KEY_ALIAS` (otherwise the debug key is used).

## Layout
* `app/src/main/cpp/third_party/rpi-imager/` – original sources (unmodified)
* `app/src/main/cpp/android_platform/` – Android replacements for Linux-specific parts + `cli_main.cpp` entry point
* `app/src/main/cpp/cmake/` – mbedTLS-backed curl, Android libusb
* `app/src/main/java/` – Kotlin UI, OS repository, USB manager, CLI runner
* `native-tests/` – host tests for the USB layer
