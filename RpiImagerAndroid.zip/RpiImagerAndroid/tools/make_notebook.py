#!/usr/bin/env python3
"""Generates RpiImager_Android_Build.ipynb (kept in the repo so the notebook is reproducible)."""
import json, sys

cells = []
def md(s): cells.append({"cell_type": "markdown", "metadata": {}, "source": s.strip("\n").splitlines(True)})
def code(s): cells.append({"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [], "source": s.strip("\n").splitlines(True)})

md(r"""
# Build Raspberry Pi Imager for Android (v2.0.12 core) — Google Colab

Run each cell top to bottom (**Runtime → Run all**). First build takes roughly **30–60 minutes** (Qt kit download, building curl/mbedTLS/libarchive/xz/zstd/libusb and the original Imager CLI for Android, then Gradle).

**What this builds:** a Kotlin Android app that runs the **original Raspberry Pi Imager 2.0.12 CLI** (cross-compiled for Android; download, extract, write, verify, OS customisation scripts) and shows the OS list incl. Raspberry Pi OS *Trixie*. No Qt GUI/QML/Java layer — the CLI itself is built on Qt *Core/Network* only, so those two libraries ship next to it. Storage access is through **USB card readers (OTG)** using Android's USB Host API and an in-app USB Mass-Storage/SCSI driver, because Android does not allow raw block-device access without root.

**Before you start:** upload `RpiImagerAndroid.zip` (the project zip from the chat) in step 1. Nothing else is required — Qt, the NDK and all libraries are fetched by the notebook.

**What you get:** a **signed release APK** + the **keystore** it was signed with. Keep the keystore to upgrade the app later.

**Honest status:** the notebook verifies that the APK builds, is signed, contains the native libraries and a single launcher. It cannot verify that writing to a real SD card works — that needs a phone, an OTG reader and a card. See `LIMITATIONS.md` in the project.

**Licence:** Raspberry Pi Imager is Apache-2.0 © Raspberry Pi Ltd (see `NOTICE.md` / `LICENSE`). Qt Core/Network are used under LGPLv3 (shared libraries, bundled unmodified).
""")

code(r"""
# 1. Upload the project zip
from google.colab import files
uploaded = files.upload()  # select RpiImagerAndroid.zip
""")

code(r"""
# 2. Unzip it and locate the project root (the folder containing settings.gradle.kts)
import glob, os
!rm -rf /content/project && mkdir -p /content/project
zips = [f for f in uploaded if f.lower().endswith(".zip")]
assert zips, "No .zip uploaded - run step 1 again"
!unzip -q -o "{zips[0]}" -d /content/project

hits = glob.glob("/content/project/**/settings.gradle.kts", recursive=True)
assert hits, "settings.gradle.kts not found - is this the right zip?"
PROJECT = os.path.dirname(sorted(hits, key=len)[0])
os.environ["PROJECT"] = PROJECT
assert os.path.isdir(PROJECT + "/app/src/main/cpp/third_party/rpi-imager/src"), "original Imager sources missing from the zip"
assert os.path.exists(PROJECT + "/tools/build_native.py"), ("This is an OLD project zip (it still has the Qt-app layout). Download the newest RpiImagerAndroid.zip from the chat, "
    "then RE-RUN step 1 and pick that file - the notebook and the zip must both be the new version.")
print("Project root:", PROJECT)
!ls "{PROJECT}"
""")

code(r"""
# 3. Host tests of the USB mass-storage (Bulk-Only/SCSI) layer - needs only g++ (fast; run before the long build)
import os
!sh "{os.environ['PROJECT']}/native-tests/run_tests.sh"
""")

code(r"""
# 4. Install JDK 17 and the native build tools (Qt for Android needs CMake >= 3.21 and Ninja)
import os
!apt-get update -qq
!apt-get install -y -qq openjdk-17-jdk ninja-build git python3-pip libgl1 libglib2.0-0 libxkbcommon0 libfontconfig1 libdbus-1-3 unzip
!pip install -q --upgrade cmake aqtinstall
os.environ["JAVA_HOME"] = "/usr/lib/jvm/java-17-openjdk-amd64"
os.environ["PATH"] = "/usr/lib/jvm/java-17-openjdk-amd64/bin:" + os.environ["PATH"]
!java -version
!cmake --version | head -1
""")

code(r"""
# 5. Android SDK (platform 36, build-tools 36.0.0) and NDK 27.2.12479018 (the NDK Qt 6.9 is built against)
import os
os.environ["ANDROID_HOME"] = "/content/android-sdk"
os.environ["ANDROID_SDK_ROOT"] = "/content/android-sdk"
NDK_VERSION = "27.2.12479018"

!mkdir -p /content/android-sdk/cmdline-tools
!wget -q https://dl.google.com/android/repository/commandlinetools-linux-14742923_latest.zip -O /content/cmdline-tools.zip
!unzip -q -o /content/cmdline-tools.zip -d /content/android-sdk/cmdline-tools
!rm -rf /content/android-sdk/cmdline-tools/latest
!mv /content/android-sdk/cmdline-tools/cmdline-tools /content/android-sdk/cmdline-tools/latest

os.environ["PATH"] += ":/content/android-sdk/cmdline-tools/latest/bin:/content/android-sdk/platform-tools"
!mkdir -p ~/.android && touch ~/.android/repositories.cfg
!yes | sdkmanager --licenses > /dev/null
!sdkmanager "platform-tools" "platforms;android-36" "build-tools;36.0.0" "ndk;{NDK_VERSION}"

with open(os.path.join(os.environ["PROJECT"], "local.properties"), "w") as f:
    f.write("sdk.dir=/content/android-sdk\n")
assert os.path.isdir(f"/content/android-sdk/ndk/{NDK_VERSION}"), "NDK not installed"
""")

code(r"""
# 6. Qt 6.9 for Android (arm64-v8a: Core/Network libs the CLI links to) + the desktop kit (moc/rcc host tools) via aqtinstall
import os
QT_VERSION = "6.9.1"
!aqt install-qt linux desktop {QT_VERSION} linux_gcc_64 -O /content/qt
!aqt install-qt linux android {QT_VERSION} android_arm64_v8a -O /content/qt
QT_HOST = f"/content/qt/{QT_VERSION}/gcc_64"
QT_ANDROID = f"/content/qt/{QT_VERSION}/android_arm64_v8a"
assert os.path.exists(QT_HOST + "/libexec/moc") or os.path.exists(QT_HOST + "/bin/moc"), "moc missing in the desktop kit"
assert os.path.exists(QT_ANDROID + "/lib/cmake/Qt6/qt.toolchain.cmake"), "Qt Android toolchain file missing"
print("Qt host   :", QT_HOST)
print("Qt android:", QT_ANDROID)
""")

code(r"""
# 7. Generate a signing key for the release build (KEEP the keystore + password for future upgrades)
import os, secrets

KEYSTORE = "/content/rpiimager-release.keystore"
_password = secrets.token_urlsafe(24)
os.environ["RPI_KEYSTORE"] = KEYSTORE
os.environ["RPI_KEYSTORE_PASS"] = _password
os.environ["RPI_KEY_ALIAS"] = "rpiimager"

!rm -f "{KEYSTORE}"
!keytool -genkeypair \
    -keystore "{KEYSTORE}" \
    -alias "{os.environ['RPI_KEY_ALIAS']}" \
    -keyalg RSA -keysize 2048 -validity 10000 \
    -storepass "{_password}" \
    -keypass "{_password}" \
    -dname "CN=RPi Imager Android Personal Build, OU=Personal, O=Personal, L=Unknown, ST=Unknown, C=US"

assert os.path.exists(KEYSTORE), "keytool didn't produce a keystore file"
print("Keystore ready. Keep this file and password to upgrade over this install later:")
print("  alias:   ", os.environ["RPI_KEY_ALIAS"])
print("  password:", _password)
""")

code(r"""
# 8. Build the original Imager CLI for Android (CMake + NDK) and stage it + its Qt Core/Network libs into the Gradle module
#    The slow step. Dependencies (curl, mbedTLS, libarchive, xz, zstd, zlib, libusb) are fetched from GitHub by CMake.
import os, subprocess
cmd = ["python3", os.environ["PROJECT"] + "/tools/build_native.py",
       "--project", os.environ["PROJECT"],
       "--qt-android", QT_ANDROID, "--qt-host", QT_HOST,
       "--sdk", "/content/android-sdk", "--ndk", f"/content/android-sdk/ndk/{NDK_VERSION}"]
proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
log = []
for line in proc.stdout:
    print(line, end="")
    log.append(line.rstrip("\n"))
proc.wait()
if proc.returncode != 0:
    print("\n" + "=" * 70)
    print("NATIVE BUILD FAILED - copy everything below and send it back:")
    print("=" * 70)
    shown = 0
    for i, l in enumerate(log):
        if "error:" in l or "CMake Error" in l or "FAILED:" in l or "undefined reference" in l or "fatal error" in l:
            print(l); shown += 1
            if shown > 80: break
    raise RuntimeError("Native build failed - see the error lines above")
print("\nNATIVE BUILD SUCCESSFUL")
""")

code(r"""
# 9. Gradle wrapper (generated here with a pinned Gradle) and the APK build
import os, subprocess
GRADLE = "8.14.3"
!wget -q https://services.gradle.org/distributions/gradle-{GRADLE}-bin.zip -O /content/gradle.zip
!unzip -q -o /content/gradle.zip -d /content
os.chdir(os.environ["PROJECT"])
!/content/gradle-{GRADLE}/bin/gradle wrapper --gradle-version {GRADLE} --no-daemon -q

proc = subprocess.Popen(["./gradlew", "assembleRelease", "--no-daemon", "--console=plain", "--stacktrace"],
                        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
log = []
for line in proc.stdout:
    print(line, end="")
    log.append(line.rstrip("\n"))
proc.wait()
if proc.returncode != 0:
    print("\n" + "=" * 70)
    print("BUILD FAILED - copy everything below and send it back:")
    print("=" * 70)
    shown = 0
    for i, l in enumerate(log):
        if l.startswith("e: ") or "FAILURE:" in l or "What went wrong" in l or "Execution failed" in l or "error:" in l:
            print(l)
            if "What went wrong" in l:
                print("\n".join(log[i + 1:i + 8]))
            shown += 1
            if shown > 60: break
    raise RuntimeError("Gradle build failed - see the error lines above")
print("\nBUILD SUCCESSFUL")
""")

code(r"""
# 10. Verify the result: one package, one launcher, signed, original Imager CLI + its libraries present, arm64 only
import glob, os, re, subprocess, zipfile

BT = "/content/android-sdk/build-tools/36.0.0"
apks = sorted(glob.glob(os.environ["PROJECT"] + "/app/build/outputs/apk/release/*.apk"))
assert apks, "No release APK found - check the build cell for errors"
apk = apks[0]
print(os.path.basename(apk), f"{os.path.getsize(apk)/1e6:.1f} MB")
assert "unsigned" not in os.path.basename(apk), "The release APK is unsigned - run step 7 in this session first"

badging = subprocess.run([BT + "/aapt2", "dump", "badging", apk], capture_output=True, text=True).stdout
pkg = re.search(r"package: name='([^']+)'", badging).group(1)
launchers = re.findall(r"launchable-activity: name='([^']+)'", badging)
print("package:", pkg, " launchers:", launchers)
assert pkg == "dev.rpiimager.android"
assert launchers == ["dev.rpiimager.android.MainActivity"], "expected exactly one launcher"
assert "usb.host" in badging, "usb host feature missing"

sig = subprocess.run([BT + "/apksigner", "verify", "--verbose", "--print-certs", apk], capture_output=True, text=True)
assert sig.returncode == 0, "apksigner verify failed:\n" + sig.stdout + sig.stderr
print(sig.stdout.strip().splitlines()[0])

names = zipfile.ZipFile(apk).namelist()
libs = [n for n in names if n.startswith("lib/")]
need = ["librpiimagercli.so", "libQt6Core_arm64-v8a.so", "libQt6Network_arm64-v8a.so", "libc++_shared.so"]
for n in need:
    assert any(l.endswith("/" + n) for l in libs), "missing native library in APK: " + n
assert all(l.startswith("lib/arm64-v8a/") for l in libs), "unexpected ABI in APK"
assert "classes.dex" in names
print(f"OK: signed, {len(libs)} native libraries (arm64-v8a), CLI present.")
print("This proves the build, NOT that SD-card writing works - test on a phone with an OTG reader.")
""")

code(r"""
# 11. Download the APK and the keystore from step 7
import glob, os
from google.colab import files
for p in sorted(glob.glob(os.environ["PROJECT"] + "/app/build/outputs/apk/release/*.apk")):
    files.download(p)
files.download(os.environ["RPI_KEYSTORE"])  # keep it (with the step 7 password) for future upgrades
""")

md(r"""
## Using the app

1. Plug a **USB card reader** with the SD card into the phone (OTG). Allow USB access when Android asks.
2. Choose the Raspberry Pi model, then the OS (e.g. **Raspberry Pi OS (64-bit) — Trixie**), or **Use custom** for a local image.
3. Pick the USB device, optionally set hostname / user / Wi-Fi / SSH / locale, then **Write**. Keep the screen on and the app in the foreground.

## Installing
Open the APK on the phone (allow "install from this source"), or `adb install app-release.apk`.

## If the build fails
Step 8 (native CLI build) or step 9 (Gradle) prints the relevant error lines — paste them back and it is usually a quick fix. Step 3 runs the USB-layer unit tests on the Colab host before the long build.
""")

nb = {"cells": cells, "metadata": {"colab": {"provenance": []}, "kernelspec": {"name": "python3", "display_name": "Python 3"}, "language_info": {"name": "python"}}, "nbformat": 4, "nbformat_minor": 0}
out = sys.argv[1] if len(sys.argv) > 1 else "RpiImager_Android_Build.ipynb"
json.dump(nb, open(out, "w"), indent=1)
print("wrote", out, len(cells), "cells")
