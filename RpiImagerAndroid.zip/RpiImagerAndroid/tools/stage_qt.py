#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Build the native Qt/C++ part and stage it into the Gradle app module.

  1. configure + build app/src/main/cpp with the Qt-for-Android toolchain
  2. run androiddeployqt --no-build (collects Qt libs, plugins, jars, res,
     manifest metadata exactly as Qt would for its own APK)
  3. copy the results into the Gradle module:
        app/src/main/jniLibs/<abi>/*.so     native libs
        app/libs/*.jar                      Qt Java classes
        app/src/main/qt_res/                Qt resources (libs.xml ...)
        app/src/main/qt_assets/             Qt assets (if any)
        app/src/main/qt_java/               Qt Java sources (if any)
        app/src/main/AndroidManifest.xml    template + Qt metadata
        app/qt_deps.gradle                  Maven deps Qt asks for
"""
import argparse, glob, json, os, re, shutil, subprocess, sys
import xml.etree.ElementTree as ET

ANDROID_NS = "http://schemas.android.com/apk/res/android"
ET.register_namespace("android", ANDROID_NS)
A = "{%s}" % ANDROID_NS


def run(cmd, **kw):
    print("+", " ".join(str(c) for c in cmd), flush=True)
    subprocess.run([str(c) for c in cmd], check=True, **kw)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--project", default=os.path.join(os.path.dirname(__file__), ".."))
    ap.add_argument("--qt-android", required=True, help="Qt kit for Android, e.g. .../6.9.1/android_arm64_v8a")
    ap.add_argument("--qt-host", required=True, help="Qt desktop kit, e.g. .../6.9.1/gcc_64")
    ap.add_argument("--sdk", required=True)
    ap.add_argument("--ndk", required=True)
    ap.add_argument("--abi", default="arm64-v8a")
    ap.add_argument("--api", default="28")
    ap.add_argument("--platform", default="android-36", help="android.jar platform for androiddeployqt")
    ap.add_argument("--build-dir", default=None)
    ap.add_argument("--jobs", default=str(os.cpu_count() or 4))
    ap.add_argument("--version", default="2.0.12")
    args = ap.parse_args()

    proj = os.path.abspath(args.project)
    cpp = os.path.join(proj, "app/src/main/cpp")
    app = os.path.join(proj, "app")
    build = os.path.abspath(args.build_dir or os.path.join(proj, "build-native", args.abi))
    os.makedirs(build, exist_ok=True)
    toolchain = os.path.join(args.qt_android, "lib/cmake/Qt6/qt.toolchain.cmake")
    if not os.path.exists(toolchain):
        sys.exit("Qt toolchain file not found: " + toolchain)

    env = dict(os.environ, ANDROID_SDK_ROOT=args.sdk, ANDROID_HOME=args.sdk, ANDROID_NDK_ROOT=args.ndk)

    run(["cmake", "-S", cpp, "-B", build, "-G", "Ninja",
         "-DCMAKE_BUILD_TYPE=Release",
         "-DCMAKE_TOOLCHAIN_FILE=" + toolchain,
         "-DQT_HOST_PATH=" + args.qt_host,
         "-DANDROID_SDK_ROOT=" + args.sdk, "-DANDROID_NDK_ROOT=" + args.ndk,
         "-DANDROID_ABI=" + args.abi, "-DANDROID_PLATFORM=android-" + args.api,
         "-DQT_ANDROID_ABIS=" + args.abi, "-DANDROID_STL=c++_shared",
         "-DIMAGER_VERSION=" + args.version,
         "-DCMAKE_POLICY_VERSION_MINIMUM=3.5"], env=env)
    run(["cmake", "--build", build, "--target", "rpiimager_native", "--parallel", args.jobs], env=env)

    lib = glob.glob(os.path.join(build, "librpiimager_native*.so"))
    if not lib:
        sys.exit("native library was not produced in " + build)
    print("native library:", lib[0], os.path.getsize(lib[0]), "bytes")

    settings = glob.glob(os.path.join(build, "android-*deployment-settings.json"))
    if not settings:
        sys.exit("androiddeployqt settings json not generated")
    out = os.path.join(build, "android-build")
    shutil.rmtree(out, ignore_errors=True)
    os.makedirs(os.path.join(out, "libs", args.abi))
    shutil.copy(lib[0], os.path.join(out, "libs", args.abi))

    deploy = os.path.join(args.qt_host, "bin", "androiddeployqt")
    run([deploy, "--input", settings[0], "--output", out, "--android-platform", args.platform,
         "--no-build", "--release"], env=env)

    # ---- copy into the Gradle module ------------------------------------
    def fresh(path):
        shutil.rmtree(path, ignore_errors=True)
        os.makedirs(path, exist_ok=True)
        return path

    jni = fresh(os.path.join(app, "src/main/jniLibs", args.abi))
    n = 0
    for so in glob.glob(os.path.join(out, "libs", args.abi, "*.so")):
        shutil.copy(so, jni); n += 1
    print("staged %d native libraries" % n)

    jars = fresh(os.path.join(app, "libs"))
    for j in glob.glob(os.path.join(out, "libs", "*.jar")) + glob.glob(os.path.join(out, "libs", "*.aar")):
        shutil.copy(j, jars)

    for src, dst in (("res", "qt_res"), ("assets", "qt_assets"), ("src", "qt_java")):
        d = os.path.join(app, "src/main", dst)
        shutil.rmtree(d, ignore_errors=True)
        s = os.path.join(out, src)
        if os.path.isdir(s) and os.listdir(s):
            shutil.copytree(s, d)
            print("staged", dst)

    # ---- manifest ---------------------------------------------------------
    qt_man = ET.parse(os.path.join(out, "AndroidManifest.xml")).getroot()
    qt_app = qt_man.find("application")
    qt_act = qt_app.find("activity")
    app_meta = [e for e in qt_app.findall("meta-data")]
    act_meta = [e for e in qt_act.findall("meta-data")]
    tpl = open(os.path.join(app, "src/main/AndroidManifest.template.xml"), encoding="utf-8").read()

    def serialise(elems):
        out_lines = []
        for e in elems:
            s = ET.tostring(e, encoding="unicode")
            s = re.sub(r'\sxmlns:\w+="[^"]+"', "", s)
            s = re.sub(r"ns\d+:", "android:", s)
            out_lines.append("        " + s.strip())
        return "\n".join(out_lines)

    manifest = tpl.replace("<!--@QT_APP_META@-->", serialise(app_meta)) \
                  .replace("<!--@QT_ACTIVITY_META@-->", serialise(act_meta))
    # keep Qt's Application class if it names one
    qt_app_name = qt_app.get(A + "name")
    if qt_app_name:
        manifest = manifest.replace("@QT_APPLICATION@", qt_app_name)
    else:
        manifest = manifest.replace("@QT_APPLICATION@", "org.qtproject.qt.android.bindings.QtApplication")
    with open(os.path.join(app, "src/main/AndroidManifest.xml"), "w", encoding="utf-8") as f:
        f.write(manifest)
    print("wrote AndroidManifest.xml (%d app meta, %d activity meta)" % (len(app_meta), len(act_meta)))

    # ---- Qt's maven dependencies ------------------------------------------
    deps = []
    gradle = os.path.join(out, "build.gradle")
    if os.path.exists(gradle):
        for m in re.finditer(r"""^\s*(?:implementation|api)\s*\(?\s*['"]([^'"]+:[^'"]+:[^'"]+)['"]""",
                             open(gradle, encoding="utf-8").read(), re.M):
            deps.append(m.group(1))
    with open(os.path.join(app, "qt_deps.gradle"), "w") as f:
        f.write("// generated by tools/stage_qt.py\ndependencies {\n")
        for d in sorted(set(deps)):
            f.write('    implementation("%s")\n' % d)
        f.write("}\n")
    print("Qt maven deps:", deps)
    print("stage complete")


if __name__ == "__main__":
    main()
