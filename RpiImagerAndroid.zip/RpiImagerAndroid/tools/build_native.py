#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Cross-build the ORIGINAL Raspberry Pi Imager CLI for Android and stage it into the Gradle module.

Output (all under app/src/main/jniLibs/<abi>/, so Gradle packs them into the APK's native-library dir):
    librpiimagercli.so      the CLI executable (+ Android platform layer)
    libQt6Core_<abi>.so, libQt6Network_<abi>.so, libc++_shared.so ... shared libraries it needs
No Qt GUI / QML / Java glue / androiddeployqt is used.
"""
import argparse, glob, os, re, shutil, subprocess, sys


def run(cmd, **kw):
    print("+", " ".join(str(c) for c in cmd), flush=True)
    return subprocess.run([str(c) for c in cmd], check=True, **kw)


def needed(readelf, path):
    out = subprocess.run([readelf, "-d", path], capture_output=True, text=True).stdout
    return re.findall(r"\(NEEDED\)\s+Shared library: \[([^\]]+)\]", out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--project", default=os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
    ap.add_argument("--qt-android", required=True, help="Qt kit for Android, e.g. .../6.9.1/android_arm64_v8a")
    ap.add_argument("--qt-host", required=True, help="Qt desktop kit, e.g. .../6.9.1/gcc_64 (moc/rcc)")
    ap.add_argument("--sdk", required=True)
    ap.add_argument("--ndk", required=True)
    ap.add_argument("--abi", default="arm64-v8a")
    ap.add_argument("--api", default="28")
    ap.add_argument("--jobs", default=str(os.cpu_count() or 4))
    ap.add_argument("--version", default="2.0.12")
    a = ap.parse_args()

    proj = os.path.abspath(a.project)
    cpp = os.path.join(proj, "app/src/main/cpp")
    build = os.path.join(proj, "build-native", a.abi)
    os.makedirs(build, exist_ok=True)
    toolchain = os.path.join(a.qt_android, "lib/cmake/Qt6/qt.toolchain.cmake")
    if not os.path.exists(toolchain):
        sys.exit("Qt toolchain file not found: " + toolchain)
    env = dict(os.environ, ANDROID_SDK_ROOT=a.sdk, ANDROID_HOME=a.sdk, ANDROID_NDK_ROOT=a.ndk)

    run(["cmake", "-S", cpp, "-B", build, "-G", "Ninja", "-DCMAKE_BUILD_TYPE=Release",
         "-DCMAKE_TOOLCHAIN_FILE=" + toolchain, "-DQT_HOST_PATH=" + a.qt_host,
         "-DANDROID_SDK_ROOT=" + a.sdk, "-DANDROID_NDK_ROOT=" + a.ndk,
         "-DANDROID_ABI=" + a.abi, "-DANDROID_PLATFORM=android-" + a.api,
         "-DQT_ANDROID_ABIS=" + a.abi, "-DANDROID_STL=c++_shared",
         "-DIMAGER_VERSION=" + a.version, "-DCMAKE_POLICY_VERSION_MINIMUM=3.5",
         "-DCMAKE_POLICY_DEFAULT_CMP0169=OLD", "-Wno-dev", "-Wno-deprecated"], env=env)
    run(["cmake", "--build", build, "--target", "rpiimager_native", "--parallel", a.jobs], env=env)

    exe = os.path.join(build, "librpiimagercli.so")
    if not os.path.exists(exe):
        sys.exit("CLI executable was not produced: " + exe)
    print("CLI:", exe, os.path.getsize(exe), "bytes")

    readelf = glob.glob(os.path.join(a.ndk, "toolchains/llvm/prebuilt/*/bin/llvm-readelf"))[0]
    triple = {"arm64-v8a": "aarch64-linux-android", "x86_64": "x86_64-linux-android"}.get(a.abi, "aarch64-linux-android")
    libdirs = [os.path.join(a.qt_android, "lib"),
               os.path.join(os.path.dirname(readelf), "..", "sysroot", "usr", "lib", triple)]
    system = {"libc.so", "libm.so", "libdl.so", "liblog.so", "libandroid.so", "libz.so", "libstdc++.so",
              "libEGL.so", "libGLESv2.so", "libGLESv3.so", "libjnigraphics.so", "libOpenSLES.so", "libvulkan.so"}

    dest = os.path.join(proj, "app/src/main/jniLibs", a.abi)
    shutil.rmtree(dest, ignore_errors=True)
    os.makedirs(dest)
    shutil.copy(exe, dest)

    todo, seen = needed(readelf, exe), set()
    while todo:
        lib = todo.pop()
        if lib in seen or lib in system:
            continue
        seen.add(lib)
        found = None
        for d in libdirs:
            p = os.path.join(d, lib)
            if os.path.exists(p):
                found = p
                break
        if not found:
            print("WARNING: dependency not found (assumed provided by Android):", lib)
            continue
        shutil.copy(found, dest)
        todo += needed(readelf, found)
        print("bundled", lib)

    print("staged:", sorted(os.listdir(dest)))
    for must in ("librpiimagercli.so",):
        assert os.path.exists(os.path.join(dest, must))
    print("native build complete")


if __name__ == "__main__":
    main()
