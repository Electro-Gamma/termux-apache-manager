/* SPDX-License-Identifier: Apache-2.0
 * Host-only: a file-backed SCSI Bulk-Only "card reader" used to drive the REAL imager CLI through
 * the same USB code path as on Android (registry -> BotDevice -> BulkTransport).
 * Enabled by compiling cli_main.cpp with -DRPI_FAKE_USB and setting RPI_FAKE_USB=<file>.
 */
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

#include <cstdlib>
#include <cstring>
#include <mutex>

#include "usb_registry.h"

namespace rpi_android {
namespace {
uint32_t be32(const uint8_t* p) { return (uint32_t)p[0] << 24 | p[1] << 16 | p[2] << 8 | p[3]; }
uint64_t be64(const uint8_t* p) { return (uint64_t)be32(p) << 32 | be32(p + 4); }
void wbe32(uint8_t* p, uint32_t v) { p[0] = v >> 24; p[1] = v >> 16; p[2] = v >> 8; p[3] = v; }
uint32_t le32(const uint8_t* p) { return p[0] | p[1] << 8 | p[2] << 16 | (uint32_t)p[3] << 24; }

class FileDisk : public BulkTransport {
 public:
  explicit FileDisk(int fd) : fd_(fd) { struct stat st; fstat(fd, &st); blocks_ = st.st_size / 512; }
  enum St { Idle, DataOut, DataIn, Csw } st_ = Idle;
  uint8_t cdb_[16]; uint32_t tag_ = 0, len_ = 0; uint8_t status_ = 0;
  std::vector<uint8_t> in_, out_;
  size_t inPos_ = 0;

  void exec() {
    in_.clear(); inPos_ = 0; status_ = 0;
    switch (cdb_[0]) {
      case 0x12: in_.assign(36, 0); memcpy(&in_[8], "FAKEVEND", 8); memcpy(&in_[16], "Fake Reader     ", 16); break;
      case 0x00: case 0x35: break;
      case 0x03: in_.assign(18, 0); in_[0] = 0x70; break;
      case 0x25: in_.assign(8, 0); wbe32(&in_[0], (uint32_t)(blocks_ - 1)); wbe32(&in_[4], 512); break;
      case 0x1A: in_.assign(4, 0); break;
      case 0x28: case 0x88: {
        uint64_t lba; uint32_t n; lbaN(lba, n);
        in_.resize((size_t)n * 512);
        if (pread(fd_, in_.data(), in_.size(), lba * 512) < 0) status_ = 1;
        break; }
      case 0x2A: case 0x8A: break;
      default: status_ = 1;
    }
  }
  void lbaN(uint64_t& lba, uint32_t& n) {
    if (cdb_[0] == 0x28 || cdb_[0] == 0x2A) { lba = be32(cdb_ + 2); n = cdb_[7] << 8 | cdb_[8]; }
    else { lba = be64(cdb_ + 2); n = be32(cdb_ + 10); }
  }
  XferResult bulkOut(const uint8_t* p, size_t len, size_t* tr, unsigned) override {
    std::lock_guard<std::mutex> l(mu_);
    if (st_ == Idle) {
      tag_ = le32(p + 4); len_ = le32(p + 8); memcpy(cdb_, p + 15, 16);
      exec();
      const bool w = cdb_[0] == 0x2A || cdb_[0] == 0x8A;
      out_.clear();
      st_ = w && len_ ? DataOut : (!in_.empty() ? DataIn : Csw);
      *tr = len; return XferResult::kOk;
    }
    if (st_ == DataOut) {
      out_.insert(out_.end(), p, p + len); *tr = len;
      if (out_.size() >= len_) {
        uint64_t lba; uint32_t n; lbaN(lba, n);
        if (pwrite(fd_, out_.data(), (size_t)n * 512, lba * 512) < 0) status_ = 1;
        st_ = Csw;
      }
      return XferResult::kOk;
    }
    return XferResult::kError;
  }
  XferResult bulkIn(uint8_t* p, size_t len, size_t* tr, unsigned) override {
    std::lock_guard<std::mutex> l(mu_);
    if (st_ == DataIn) {
      size_t n = std::min(len, in_.size() - inPos_);
      memcpy(p, in_.data() + inPos_, n); inPos_ += n; *tr = n;
      if (inPos_ >= in_.size()) st_ = Csw;
      return XferResult::kOk;
    }
    uint8_t csw[13] = {'U', 'S', 'B', 'S'}; memcpy(csw + 4, &tag_, 4); csw[12] = status_;
    memcpy(p, csw, 13); *tr = 13; st_ = Idle; return XferResult::kOk;
  }
  bool clearHaltIn() override { return true; }
  bool clearHaltOut() override { return true; }
  bool bulkOnlyReset() override { st_ = Idle; return true; }
 private:
  int fd_; uint64_t blocks_ = 0; std::mutex mu_;
};
}  // namespace

void registerFakeUsb(const char* file, const char* path) {
  int fd = ::open(file, O_RDWR);
  if (fd < 0) return;
  UsbEndpointConfig cfg; cfg.fd = fd;
  UsbDeviceInfo info; info.path = path;
  UsbRegistry::instance().add(info, cfg);
  UsbRegistry::instance().setTransportFactory(
      [fd](const std::string&, const UsbEndpointConfig&, std::string&) { return std::unique_ptr<BulkTransport>(new FileDisk(fd)); });
}
}  // namespace rpi_android
