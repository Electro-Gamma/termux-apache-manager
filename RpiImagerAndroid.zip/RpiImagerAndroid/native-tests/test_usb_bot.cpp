/* SPDX-License-Identifier: Apache-2.0
 * Host-side tests: BotDevice + AndroidFileOperations against a simulated
 * Bulk-Only mass-storage device (sparse RAM disk). No Qt/libusb/Android needed.
 */
#include <cassert>
#include <cstdio>
#include <cstring>
#include <deque>
#include <map>
#include <unistd.h>

#include "usb_registry.h"
#include "file_operations_android.h"

using namespace rpi_android;
static int g_fail = 0;
#define CHECK(c) do { if (!(c)) { std::printf("FAIL %s:%d: %s\n", __FILE__, __LINE__, #c); ++g_fail; } } while (0)

static uint32_t be32(const uint8_t* p){return (uint32_t)p[0]<<24|p[1]<<16|p[2]<<8|p[3];}
static uint64_t be64(const uint8_t* p){return (uint64_t)be32(p)<<32|be32(p+4);}
static void wbe32(uint8_t* p,uint32_t v){p[0]=v>>24;p[1]=v>>16;p[2]=v>>8;p[3]=v;}
static void wbe64(uint8_t* p,uint64_t v){wbe32(p,v>>32);wbe32(p+4,(uint32_t)v);}
static uint32_t le32(const uint8_t* p){return p[0]|p[1]<<8|p[2]<<16|(uint32_t)p[3]<<24;}

struct Disk {
  uint64_t blocks = 2048; uint32_t bs = 512; bool big = false;
  std::map<uint64_t, std::vector<uint8_t>> data;  // sparse
  int notReady = 0; bool noMedium = false; bool wp = false;
  // fault injection
  bool stallDataInOnce = false; bool failNextRw = false; bool badCswSig = false; bool phaseError = false;
  int maxCmdBytes = 0; int rwCommands = 0; int resets = 0; int clears = 0; int syncs = 0;
  std::vector<uint8_t>& blk(uint64_t lba){auto& v=data[lba]; if(v.empty()) v.assign(bs,0); return v;}
};

class MockTransport : public BulkTransport {
 public:
  explicit MockTransport(Disk* d) : d_(d) {}
  enum St { Idle, DataOut, Csw } st_ = Idle;
  uint8_t cdb_[16]; uint32_t tag_ = 0, len_ = 0; uint8_t status_ = 0; uint8_t flags_ = 0;
  std::vector<uint8_t> in_; std::vector<uint8_t> outbuf_; bool stallPending_ = false;
  uint8_t senseKey_ = 0, asc_ = 0; bool haveSense_ = false;
  Disk* d_;

  void finish() { st_ = Csw; }
  void exec() {
    const uint8_t op = cdb_[0]; in_.clear(); status_ = 0;
    auto fail = [&](uint8_t k, uint8_t a){ status_ = 1; senseKey_=k; asc_=a; haveSense_=true; };
    switch (op) {
      case 0x12: { in_.assign(36,0); in_[0]=0; memcpy(&in_[8],"MOCKVEND",8); memcpy(&in_[16],"Card Reader     ",16); break; }
      case 0x00:
        if (d_->noMedium) { fail(2,0x3A); }
        else if (d_->notReady > 0) { --d_->notReady; fail(2,0x04); }
        break;
      case 0x03: { in_.assign(18,0); in_[0]=0x70; in_[2]=haveSense_?senseKey_:0; in_[12]=asc_; in_[13]=0; haveSense_=false; break; }
      case 0x25: { in_.assign(8,0); uint64_t last = d_->blocks-1; wbe32(&in_[0], d_->big?0xFFFFFFFFu:(uint32_t)last); wbe32(&in_[4], d_->bs); break; }
      case 0x9E: { in_.assign(32,0); wbe64(&in_[0], d_->blocks-1); wbe32(&in_[8], d_->bs); break; }
      case 0x1A: { in_.assign(4,0); in_[2] = d_->wp?0x80:0; break; }
      case 0x35: ++d_->syncs; break;
      case 0x28: case 0x88: {
        uint64_t lba; uint32_t n;
        if (op==0x28){lba=be32(cdb_+2); n=cdb_[7]<<8|cdb_[8];} else {lba=be64(cdb_+2); n=be32(cdb_+10);}
        ++d_->rwCommands;
        if ((uint64_t)n*d_->bs > (d_->maxCmdBytes? (uint64_t)d_->maxCmdBytes : ~0ull)) { d_->maxCmdBytes = n*d_->bs; }
        if (d_->failNextRw) { d_->failNextRw=false; fail(3,0x11); break; }
        for (uint32_t i=0;i<n;i++){ auto& b=d_->blk(lba+i); in_.insert(in_.end(), b.begin(), b.end()); }
        if (d_->stallDataInOnce) { d_->stallDataInOnce=false; stallPending_=true; }
        break; }
      case 0x2A: case 0x8A: break;  // data stage handled on completion
      default: fail(5,0x20);
    }
  }
  void writeCommit() {
    uint64_t lba; uint32_t n;
    if (cdb_[0]==0x2A){lba=be32(cdb_+2); n=cdb_[7]<<8|cdb_[8];} else {lba=be64(cdb_+2); n=be32(cdb_+10);}
    ++d_->rwCommands;
    if ((uint64_t)n*d_->bs > (uint64_t)d_->maxCmdBytes) d_->maxCmdBytes = n*d_->bs;
    if (d_->failNextRw) { d_->failNextRw=false; status_=1; senseKey_=3; asc_=0x0C; haveSense_=true; return; }
    for (uint32_t i=0;i<n;i++){ auto& b=d_->blk(lba+i); memcpy(b.data(), outbuf_.data()+(size_t)i*d_->bs, d_->bs); }
  }
  XferResult bulkOut(const uint8_t* p, size_t len, size_t* tr, unsigned) override {
    if (st_ == Idle) {
      CHECK(len==31); CHECK(le32(p)==0x43425355);
      tag_=le32(p+4); len_=le32(p+8); flags_=p[12]; memcpy(cdb_,p+15,16);
      exec();
      const bool isWrite = (cdb_[0]==0x2A||cdb_[0]==0x8A);
      if (isWrite) { CHECK(!(flags_&0x80)); outbuf_.clear(); st_ = DataOut; if(len_==0) {writeCommit(); finish();} }
      else if (in_.empty() || stallPending_ ) { finish(); if (!in_.empty()) st_ = Csw; }
      else st_ = Csw;  // IN data is consumed by next bulkIn before CSW (tracked below)
      if (!isWrite && len_ > 0 && in_.empty()) { in_.assign(1,0); stallPending_ = true; }  // failed read: device stalls data-in
      dataInPending_ = !in_.empty() && !isWrite;
      *tr = len; return XferResult::kOk;
    }
    if (st_ == DataOut) {
      outbuf_.insert(outbuf_.end(), p, p+len); *tr = len;
      if (outbuf_.size() >= len_) { writeCommit(); finish(); }
      return XferResult::kOk;
    }
    return XferResult::kError;
  }
  bool dataInPending_ = false; bool stalledOnce_ = false;
  XferResult bulkIn(uint8_t* p, size_t len, size_t* tr, unsigned) override {
    if (dataInPending_) {
      dataInPending_ = false;
      if (stallPending_) { stallPending_ = false; stalledOnce_ = true; *tr = 0; return XferResult::kStall; }
      size_t n = std::min(len, in_.size()); memcpy(p, in_.data(), n); *tr = n; return XferResult::kOk;
    }
    CHECK(len==13);
    uint8_t csw[13]; memset(csw,0,13);
    csw[0]='U';csw[1]='S';csw[2]='B';csw[3]='S'; memcpy(csw+4,&tag_,4);
    if (d_->badCswSig) { d_->badCswSig=false; csw[0]='X'; }
    csw[12] = d_->phaseError ? (d_->phaseError=false, 2) : status_;
    memcpy(p,csw,13); *tr = 13; st_ = Idle; return XferResult::kOk;
  }
  bool clearHaltIn() override { ++d_->clears; return true; }
  bool clearHaltOut() override { ++d_->clears; return true; }
  bool bulkOnlyReset() override { ++d_->resets; st_ = Idle; dataInPending_=false; return true; }
};

static std::unique_ptr<BotDevice> mk(Disk& d) {
  auto b = std::make_unique<BotDevice>(std::make_unique<MockTransport>(&d));
  b->setRetryDelayMs(0); return b;
}

static void testInit() {
  Disk d; auto b = mk(d);
  CHECK(b->init()); CHECK(b->vendor()=="MOCKVEND"); CHECK(b->product()=="Card Reader");
  CHECK(b->blockSize()==512 && b->blockCount()==2048 && !b->writeProtected());
  Disk d2; d2.notReady = 3; CHECK(mk(d2)->init());
  Disk d3; d3.noMedium = true; auto b3 = mk(d3); CHECK(!b3->init()); CHECK(b3->error().find("No card")!=std::string::npos);
  Disk d4; d4.wp = true; auto b4 = mk(d4); CHECK(b4->init()); CHECK(b4->writeProtected());
  CHECK(!b4->write(0,(const uint8_t*)"x",1)); CHECK(b4->error().find("write protected")!=std::string::npos);
  Disk d5; d5.big = true; d5.bs = 4096; d5.blocks = 3ull*1024*1024*1024*1024/4096; auto b5 = mk(d5);
  CHECK(b5->init()); CHECK(b5->blockSize()==4096); CHECK(b5->sizeBytes()==3ull<<40);
  std::vector<uint8_t> x(4096,0xAB); CHECK(b5->writeBlocks(d5.blocks-1,1,x.data()));
  std::vector<uint8_t> y(4096); CHECK(b5->readBlocks(d5.blocks-1,1,y.data())); CHECK(x==y);
}

static void testRw() {
  Disk d; d.blocks = 16384; auto b = mk(d); CHECK(b->init());
  std::vector<uint8_t> src(5*1024*1024); for (size_t i=0;i<src.size();i++) src[i]=(uint8_t)(i*7+i/251);
  CHECK(b->write(0, src.data(), src.size()));
  CHECK(d.maxCmdBytes <= (int)BotDevice::kMaxTransferBytes);
  CHECK(d.rwCommands >= 10);
  std::vector<uint8_t> back(src.size()); CHECK(b->read(0, back.data(), back.size())); CHECK(back==src);
  // unaligned RMW leaves neighbours intact
  std::vector<uint8_t> patch(1000, 0xEE); CHECK(b->write(100, patch.data(), patch.size()));
  std::vector<uint8_t> chk(1300); CHECK(b->read(50, chk.data(), chk.size()));
  for (size_t i=0;i<chk.size();i++) { size_t off=50+i; uint8_t want = (off>=100&&off<1100)?0xEE:src[off]; if(chk[i]!=want){CHECK(false);break;} }
  CHECK(!b->write(d.blocks*512-10, patch.data(), 100));  // beyond end
  CHECK(b->error().find("beyond end")!=std::string::npos);
  CHECK(b->syncCache()); CHECK(d.syncs==1);
}

static void testFaults() {
  Disk d; auto b = mk(d); CHECK(b->init());
  uint8_t buf[512];
  d.failNextRw = true; CHECK(!b->readBlocks(0,1,buf)); CHECK(b->error().find("sense 03/11")!=std::string::npos);
  CHECK(b->readBlocks(0,1,buf));
  d.failNextRw = true; CHECK(!b->writeBlocks(0,1,buf)); CHECK(b->lastSense().key==3);
  d.stallDataInOnce = true; int c0=d.clears; CHECK(b->readBlocks(0,1,buf)==false); CHECK(d.clears>c0);
  d.badCswSig = true; unsigned r0=b->recoveryCount(); CHECK(!b->readBlocks(0,1,buf)); CHECK(b->recoveryCount()>r0);
  d.phaseError = true; CHECK(!b->readBlocks(0,1,buf)); CHECK(b->error().find("phase")!=std::string::npos);
  CHECK(b->readBlocks(0,1,buf));  // recovers
}

static void testFileOps() {
  Disk d; d.blocks = 4096; auto& reg = UsbRegistry::instance();
  reg.setTransportFactory([&](const std::string&, const UsbEndpointConfig&, std::string&) {
    return std::unique_ptr<BulkTransport>(new MockTransport(&d)); });
  UsbDeviceInfo info; info.path = "/dev/bus/usb/001/004"; reg.add(info, UsbEndpointConfig());
  rpi_imager::AndroidFileOperations ops;
  using E = rpi_imager::FileError;
  CHECK(ops.OpenDevice(info.path)==E::kSuccess);
  uint64_t sz=0; CHECK(ops.GetSize(sz)==E::kSuccess && sz==4096*512);
  std::vector<uint8_t> a(1<<20, 0x5A), b(300, 0x11);
  CHECK(ops.WriteSequential(a.data(),a.size())==E::kSuccess); CHECK(ops.Tell()==a.size());
  CHECK(ops.WriteSequential(b.data(),b.size())==E::kSuccess);
  CHECK(ops.Seek(0)==E::kSuccess);
  std::vector<uint8_t> r(a.size()+b.size()); size_t got=0;
  CHECK(ops.ReadSequential(r.data(), r.size(), got)==E::kSuccess && got==r.size());
  CHECK(memcmp(r.data(),a.data(),a.size())==0 && memcmp(r.data()+a.size(),b.data(),b.size())==0);
  CHECK(ops.Seek(sz-100)==E::kSuccess); CHECK(ops.ReadSequential(r.data(),1000,got)==E::kSuccess && got==100);
  CHECK(ops.WriteSequential(a.data(),200)==E::kWriteError);
  CHECK(ops.ClassifyLastWriteError()==rpi_imager::WriteErrorClass::kDiskFull);
  CHECK(!ops.IsAsyncIOSupported());
  CHECK(ops.Close()==E::kSuccess && d.syncs>=1);
  // plain file fallback
  char tmpl[] = "/tmp/rpiimgXXXXXX"; int fd = mkstemp(tmpl); close(fd);
  rpi_imager::AndroidFileOperations f;
  CHECK(f.CreateTestFile(tmpl, 4096)==E::kSuccess);
  CHECK(f.WriteSequential(a.data(),100)==E::kSuccess); CHECK(f.Seek(0)==E::kSuccess);
  CHECK(f.ReadSequential(r.data(),100,got)==E::kSuccess && got==100 && r[0]==0x5A);
  CHECK(f.GetSize(sz)==E::kSuccess && sz==4096); CHECK(f.ForceSync()==E::kSuccess);
  f.Close(); unlink(tmpl);
  CHECK(f.OpenDevice("/nonexistent/x")==E::kOpenError && f.GetLastErrorCode()==ENOENT);
}

int main() {
  testInit(); testRw(); testFaults(); testFileOps();
  std::printf(g_fail ? "%d FAILURES\n" : "ALL TESTS PASSED\n", g_fail);
  return g_fail ? 1 : 0;
}
