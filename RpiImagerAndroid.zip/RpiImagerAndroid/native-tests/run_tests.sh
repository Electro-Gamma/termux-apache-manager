#!/bin/sh
# Host-side unit tests for the USB mass-storage layer (needs only g++).
# usage: run_tests.sh [path-to-rpi-imager-src]
set -e
HERE=$(cd "$(dirname "$0")" && pwd)
SRC=${1:-$HERE/../app/src/main/cpp/third_party/rpi-imager/src}
PLAT=$HERE/../app/src/main/cpp/android_platform
g++ -std=c++17 -Wall -Wextra -fsanitize=address,undefined -I"$SRC" -I"$PLAT" \
  "$HERE/test_usb_bot.cpp" "$PLAT/usb_bot.cpp" "$PLAT/usb_registry.cpp" \
  "$PLAT/file_operations_android.cpp" "$SRC/file_operations.cpp" -o /tmp/test_usb_bot -pthread
/tmp/test_usb_bot
