# Feature parity vs Raspberry Pi Imager v2.0.12

Legend: DONE = written AND covered by a passing test that was actually run; WRITTEN = code exists, not compiled/run yet;
TODO = not started. Nothing here is claimed as verified on a phone.

| Area | Original | Android status |
|---|---|---|
| Catalogue fetch (os_list_imagingutility_v4.json) | curl | WRITTEN (HttpURLConnection) |
| init_format validation / locale list | oslistparser.cpp | WRITTEN + unit tests (not run) |
| Device (Pi model) filtering by tags/architecture | hwlistmodel.cpp | TODO |
| subitems_url lazy sublists, random ordering | oslistmodel | TODO |
| cloud-init(-rpi) user-data + network-config | customization_generator.cpp | WRITTEN + unit tests (not run) |
| rpi-preseed.toml | customization_generator.cpp | WRITTEN + unit tests (not run) |
| systemd firstrun.sh (Bookworm, Trixie 2025-10-01) | customization_generator.cpp | TODO (planner refuses, never silently skips) |
| yescrypt / sha256crypt password hashing | C libs | WRITTEN via JNI (original C); sha256crypt verified vs openssl on host; yescrypt unverified vs libxcrypt |
| config.txt merge / cmdline.txt edits / meta-data | downloadthread.cpp | WRITTEN + unit tests (not run) |
| Download, resume, cache | downloadthread.cpp | TODO |
| xz/gz/zstd/zip extraction, SHA-256 verify | libarchive | TODO |
| USB card-reader write (no root) | drivelist + write | TODO |
| FAT boot-partition read/write on raw device | devicewrapperfatpartition.cpp | TODO |
| Verify-after-write | downloadthread.cpp | TODO |
| Compose UI wizard (device, OS, storage, customise, write, done) | QML | PARTIAL (OS list only) |
| Local image file, custom repo URL, settings, i18n | various | TODO |
| Secure boot, fastboot, rpiboot, Pi Connect sign-in | various | TODO / Pi Connect token runcmd WRITTEN |
