# Feature parity vs Raspberry Pi Imager v2.0.12

Legend: DONE = written AND covered by a passing test that was actually run; WRITTEN = code exists, not compiled/run yet;
TODO = not started. Nothing here is claimed as verified on a phone.

| Area | Original | Android status |
|---|---|---|
| Catalogue fetch (os_list_imagingutility_v4.json) | curl | WRITTEN (HttpURLConnection) |
| init_format validation / locale list | oslistparser.cpp | WRITTEN + unit tests (not run) |
| Device (Pi model) filtering by tags/architecture | hwlistmodel.cpp | TODO |
| subitems / subitems_url sub-lists, Erase, Use custom | oslistmodel | WRITTEN (random ordering TODO) |
| cloud-init(-rpi) user-data + network-config | customization_generator.cpp | WRITTEN + unit tests (not run) |
| rpi-preseed.toml | customization_generator.cpp | WRITTEN + unit tests (not run) |
| systemd firstrun.sh (Bookworm, Trixie 2025-10-01) | customization_generator.cpp | TODO (planner refuses, never silently skips) |
| yescrypt / sha256crypt password hashing | C libs | WRITTEN via JNI (original C); sha256crypt verified vs openssl on host; yescrypt unverified vs libxcrypt |
| config.txt merge / cmdline.txt edits / meta-data | downloadthread.cpp | WRITTEN + unit tests (not run) |
| Download (https streaming), no cache/resume | downloadthread.cpp | WRITTEN (resume + cache TODO) |
| xz/gz/zip extraction + SHA-256 of extracted image | libarchive | WRITTEN (zstd TODO) |
| USB card-reader write (no root, BOT/SCSI) | drivelist + write | WRITTEN, never run on hardware; UAS-only readers unsupported |
| FAT32 boot-partition read/write on raw device | devicewrapperfatpartition.cpp | WRITTEN + in-memory tests (not run); not checked with fsck/Linux |
| Verify-after-write (read back + SHA-256) | downloadthread.cpp | WRITTEN, never run on hardware |
| Compose wizard (OS, storage, customise, confirm, write) | QML | WRITTEN (no Pi-model step, no settings screen, no i18n) |
| Local image file, custom repo URL, settings, i18n | various | TODO |
| Secure boot, fastboot, rpiboot, Pi Connect sign-in | various | TODO / Pi Connect token runcmd WRITTEN |
