# NOTICE

This project is a derivative work of **Raspberry Pi Imager v2.0.12**
(https://github.com/raspberrypi/rpi-imager), Copyright (C) 2020-2026 Raspberry Pi Ltd,
licensed under the Apache License 2.0 (see `LICENSE-rpi-imager.txt`).

It is an independent Android port and is not affiliated with or endorsed by Raspberry Pi Ltd.

Logic ported to Kotlin from the original (file headers say so individually):
`customization_generator.cpp`, `oslistparser.cpp`, `config_txt_merge.h`, `cmdline_params.h`,
and the boot-partition customisation sequence in `downloadthread.cpp` / `imagewriter.cpp`.

Original C source reused unmodified via JNI (`app/src/main/cpp/third_party`):
- yescrypt (Openwall) - BSD 2-Clause; see headers in `third_party/yescrypt`
- sha256crypt - public domain

Third-party components of the original that are NOT used here: Qt, libarchive, libcurl,
libusb, nghttp2, zstd, xz, zlib, qrcodegen. Replacements will be listed here as they are added.

## Modifications
Rewritten in Kotlin for Android; Qt/QML UI replaced by Jetpack Compose. See `PARITY.md`.
