# Notice and attribution

This project is an **unofficial Android port** of **Raspberry Pi Imager**. It is not affiliated with,
endorsed by, or supported by Raspberry Pi Ltd. "Raspberry Pi" is a trademark of Raspberry Pi Ltd; the
app uses its own generic icon and does not include Raspberry Pi logos.

## Original work
* Raspberry Pi Imager 2.0.12, Copyright © Raspberry Pi Ltd, licensed under the **Apache License 2.0**.
  The original sources are included **unmodified** in `app/src/main/cpp/third_party/rpi-imager/`
  (CLI build subset) together with their licence (`license.txt`, copy in `LICENSE`).
* The Android-specific files in `app/src/main/cpp/android_platform/`, the Kotlin app, the build
  scripts and the notebook are new work, also provided under the Apache License 2.0.

## Third-party components (fetched at build time unless noted)
| Component | Licence |
|---|---|
| Qt 6 (Core, Gui, Network, Android Java glue) | LGPL-3.0 (shared libs, unmodified) |
| libcurl | curl licence (MIT-style) |
| mbedTLS | Apache-2.0 / GPL-2.0-or-later (used under Apache-2.0) |
| libarchive | BSD-2-Clause |
| zstd | BSD-3-Clause / GPL-2.0 (used under BSD) |
| xz / liblzma | 0BSD / public domain |
| zlib | zlib licence |
| nghttp2 | MIT |
| libusb | LGPL-2.1-or-later (static link; see note) |
| yescrypt | BSD-style |
| QR Code generator (Nayuki) | MIT (bundled in original source) |

**LGPL note (Qt, libusb):** the Qt libraries ship as separate `.so` files. libusb is linked statically
into `librpiimager_native_*.so`; the complete corresponding source of this app is this project, and
you may relink it with a modified libusb by rebuilding with the supplied notebook.
