# Limitations (read before relying on this app)

## Verification status
Checked in the authoring environment (Linux host, Qt 6.9.1 Core/Network/Concurrent built from source, clang 18 + g++ 13, Kotlin 2.2.20 against android.jar API 34):

| Area | Status |
|---|---|
| Whole native CLI (original Imager sources + `android_platform/` + curl/mbedTLS/libarchive/xz/zstd/zlib/libusb built from the same CMake files) | **Compiles and links on a Linux host**; all 80 project sources also pass a clang 18 syntax check |
| Host run: xz-compressed image → file target, verify, customisation (`firstrun.sh` from the original generator) | **Works** |
| Image passed as a file descriptor over the SCM_RIGHTS socket (what the Kotlin app does) | **Works** |
| HTTPS download through the mbedTLS-based libcurl | **Works** |
| USB Bulk-Only/SCSI layer (`usb_bot.cpp`, `file_operations_android.cpp`) | **Unit-tested** with a mock device (ASan/UBSan) |
| Kotlin sources | **Compile** against android.jar (API 34) |
| NOT verified | Compilation with the Android NDK (bionic) and linking against Qt-for-Android; Gradle/AGP packaging; running on a phone; the libusb transport on a real device (`libusb_wrap_sys_device`); writing to a real card; `QStandardPaths` override on Android |

No claim of feature parity with desktop Raspberry Pi Imager is made.

## Unavoidable Android limitations
* **Storage access:** Android forbids raw block-device access without root. Only **USB mass-storage devices (card readers via OTG)** can be written, using the Android USB Host API plus our own SCSI driver. Internal SD slots and `/dev/block/*` are unavailable. Readers that are not standard Bulk-Only SCSI devices (e.g. UAS-only) may not work.
* **Mount/eject:** no unmount/eject step exists; the app flushes with SCSI SYNCHRONIZE CACHE. Remove the reader safely afterwards.
* **Background:** no foreground service; keep the app open and the screen on while writing.
* **Qt without a JVM:** the CLI links Qt Core/Network for Android but runs as a plain process. `QStandardPaths` is overridden (`qstandardpaths_override.cpp`) because Qt's Android implementation needs Java; other Android-specific Qt Core code paths without a JVM are untested.
* **CLI feature set:** only what the original CLI offers: no "Erase" mode, no `rpi-preseed` customisation, no OS-list command (the list is fetched in Kotlin), HTTP/1.1 only (no HTTP/2).
* **Compute Module (rpiboot) and fastboot flashing:** code is compiled but not exposed (needs raw USB access to unlisted devices).
* **Secure boot signing / key generation, OTP programming:** disabled (stubs).
* **NOOBS-style multi-file ZIP images:** unsupported (needs mounting).
* **Wi-Fi credential import, Raspberry Pi Connect sign-in, telemetry, update check:** disabled.
* **Language:** English only (translations not shipped).
* **Performance:** synchronous I/O, USB transfers ≤ 512 KiB; slower than desktop. No counterfeit-card sysfs checks.
* **ABI:** arm64-v8a only by default.
* **Custom images** are read through the Storage Access Framework via `/proc/self/fd`; the file picker's file must stay available during the write.
