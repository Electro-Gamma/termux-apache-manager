# Limitations (read before relying on this app)

## Verification status
| Area | Status |
|---|---|
| USB Bulk-Only/SCSI layer, byte-addressed I/O, error mapping (`usb_bot.cpp`, `file_operations_android.cpp`) | **Unit-tested on a Linux host** with a mock device (ASan/UBSan) |
| Everything else (Qt/CMake cross-build, JNI bridge, libusb transport, Kotlin UI, APK packaging) | **Written but NOT built or run** by the author: the authoring environment had no access to the Android SDK/NDK, Qt or GitHub. First build in Colab may need small fixes (compile errors in original sources on bionic, Qt packaging details). |
| Writing to a real card | **Untested** on hardware |

No claim of feature parity with desktop Raspberry Pi Imager is made.

## Unavoidable Android limitations
* **Storage access:** Android forbids raw block-device access without root. Only **USB mass-storage devices (card readers via OTG)** can be written, using the Android USB Host API plus our own SCSI driver. Internal SD slots and `/dev/block/*` are unavailable. Readers that are not standard Bulk-Only SCSI devices (e.g. UAS-only) may not work.
* **Mount/eject:** no unmount/eject step exists; the app flushes with SCSI SYNCHRONIZE CACHE. Remove the reader safely afterwards.
* **Background:** no foreground service; keep the app open and the screen on while writing.
* **Compute Module (rpiboot) and fastboot flashing:** code is compiled but not exposed (needs raw USB access to unlisted devices).
* **Secure boot signing / key generation, OTP programming:** disabled (stubs).
* **NOOBS-style multi-file ZIP images:** unsupported (needs mounting).
* **Wi-Fi credential import, Raspberry Pi Connect sign-in, telemetry, update check:** disabled.
* **Language:** English only (translations not shipped).
* **Performance:** synchronous I/O, USB transfers ≤ 512 KiB; slower than desktop. No counterfeit-card sysfs checks.
* **ABI:** arm64-v8a only by default.
* **Custom images** are read through the Storage Access Framework via `/proc/self/fd`; the file picker's file must stay available during the write.
