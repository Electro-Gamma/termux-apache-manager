# Raspberry Pi Imager for Android (unofficial port of the 2.0.12 CLI)

A Kotlin app that drives the **original Raspberry Pi Imager 2.0.12 CLI** (`cli.cpp` + core, cross-compiled
for Android and unmodified). Kotlin does the UI, the OS list (incl. Raspberry Pi OS Trixie), USB access
and process control; the CLI does download → decompress → write → verify and generates the first-boot
customisation files with the original `CustomisationGenerator`.

No Qt GUI, QML, Qt Java glue or `androiddeployqt`. (The CLI is itself written on Qt *Core/Network*, so those two
shared libraries are bundled beside the executable.)

```
Kotlin UI ──ProcessBuilder──> librpiimagercli.so (original CLI + Android platform layer)
    │                              ▲ USB fd via SCM_RIGHTS socket
    └─ UsbManager (permission, fd) ┘      ──> libusb wrap_sys_device ──> USB Mass-Storage / SCSI (usb_bot.cpp)
```

**Status: source complete, build not yet verified.** See `LIMITATIONS.md`, `BUILD.md`, `NOTICE.md`.

## Implemented
* Device filter, OS list with categories, custom image via file picker, USB (OTG) storage selection
* Download → extract (xz/gz/zst/zip/…) → write → verify through the original CLI code path
* Customisation (hostname, user/password, Wi-Fi + country, locale, SSH password/keys, SPI, serial) for
  `systemd` (firstrun.sh) and `cloudinit`/`cloudinit-rpi` (user-data + network-config) images
* Progress parsed from the CLI output, cancel, error reporting, SCSI cache flush on close
