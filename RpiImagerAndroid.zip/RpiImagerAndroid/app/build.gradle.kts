plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "dev.rpiimager.android"
    compileSdk = 36
    defaultConfig {
        applicationId = "dev.rpiimager.android"
        minSdk = 28
        targetSdk = 35
        versionCode = 2000012
        versionName = "2.0.12-android1+" + java.text.SimpleDateFormat("yyyyMMdd.HHmm").format(java.util.Date())
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    val ksPath = System.getenv("RPI_KEYSTORE")
    signingConfigs {
        if (ksPath != null) create("release") {
            storeFile = file(ksPath)
            storePassword = System.getenv("RPI_KEYSTORE_PASS")
            keyAlias = System.getenv("RPI_KEY_ALIAS") ?: "rpiimager"
            keyPassword = System.getenv("RPI_KEYSTORE_PASS")
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = if (ksPath != null) signingConfigs.getByName("release") else signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlin { compilerOptions { jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17) } }
    packaging {
        jniLibs { useLegacyPackaging = true }   // the CLI executable is run from nativeLibraryDir, so libs must be extracted
    }
    lint { abortOnError = false }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
}
