package org.rpiimager.android

import org.junit.Assert.*
import org.junit.Test
import org.rpiimager.android.fat.FatBoot
import org.rpiimager.android.usb.BlockDevice

/** In-memory 512-byte-sector disk with a hand-built MBR + FAT32 partition (1 sector per cluster,
 *  so directory extension and multi-cluster files are exercised). Checks self-consistency only. */
private class MemDisk(sectors: Int) : BlockDevice {
    val data = ByteArray(sectors * 512)
    override val blockSize = 512
    override val blockCount = sectors.toLong()
    override fun read(lba: Long, blocks: Int, out: ByteArray, off: Int) =
        System.arraycopy(data, (lba * 512).toInt(), out, off, blocks * 512)
    override fun write(lba: Long, blocks: Int, data: ByteArray, off: Int) =
        System.arraycopy(data, off, this.data, (lba * 512).toInt(), blocks * 512)
    override fun sync() {}
}

private fun p16(b: ByteArray, o: Int, v: Int) { b[o] = v.toByte(); b[o + 1] = (v shr 8).toByte() }
private fun p32(b: ByteArray, o: Int, v: Int) { p16(b, o, v and 0xFFFF); p16(b, o + 2, (v ushr 16) and 0xFFFF) }

private fun formatted(): MemDisk {
    val d = MemDisk(32768)
    val part = 2048
    val partSectors = 30720
    val fatSectors = 240
    d.data[510] = 0x55; d.data[511] = 0xAA.toByte()
    d.data[446 + 4] = 0x0C
    p32(d.data, 446 + 8, part); p32(d.data, 446 + 12, partSectors)
    val o = part * 512
    d.data[o] = 0xEB.toByte(); d.data[o + 1] = 0x58; d.data[o + 2] = 0x90.toByte()
    p16(d.data, o + 11, 512); d.data[o + 13] = 1; p16(d.data, o + 14, 32); d.data[o + 16] = 2
    d.data[o + 21] = 0xF8.toByte()
    p32(d.data, o + 32, partSectors); p32(d.data, o + 36, fatSectors); p32(d.data, o + 44, 2); p16(d.data, o + 48, 1)
    p16(d.data, o + 510, 0xAA55)
    val fs = (part + 1) * 512
    p32(d.data, fs, 0x41615252); p32(d.data, fs + 484, 0x61417272); p32(d.data, fs + 488, 1000); p32(d.data, fs + 492, 3)
    for (f in 0 until 2) {
        val fo = (part + 32 + f * fatSectors) * 512
        p32(d.data, fo, 0x0FFFFFF8); p32(d.data, fo + 4, 0x0FFFFFFF); p32(d.data, fo + 8, 0x0FFFFFFF)
    }
    return d
}

class FatBootTest {
    @Test fun roundTripShortAndLongNames() {
        val d = formatted()
        val fat = FatBoot.mount(d)
        val big = ByteArray(1500) { (it % 251).toByte() }       // 3 clusters
        fat.writeFile("cmdline.txt", "console=tty1 root=x\n".toByteArray())
        fat.writeFile("user-data", "#cloud-config\nhostname: a\n".toByteArray())
        fat.writeFile("network-config", big)
        fat.writeFile("rpi-preseed.toml", ByteArray(0))
        val again = FatBoot.mount(d)
        assertEquals("console=tty1 root=x\n", again.readFile("cmdline.txt")!!.toString(Charsets.UTF_8))
        assertEquals("#cloud-config\nhostname: a\n", again.readFile("USER-DATA")!!.toString(Charsets.UTF_8))
        assertArrayEquals(big, again.readFile("network-config"))
        assertEquals(0, again.readFile("rpi-preseed.toml")!!.size)
        assertNull(again.readFile("missing"))
    }

    @Test fun replaceExistingFile() {
        val d = formatted()
        val fat = FatBoot.mount(d)
        fat.writeFile("config.txt", ByteArray(2000) { 1 })
        fat.writeFile("config.txt", "x".toByteArray())
        val again = FatBoot.mount(d)
        assertEquals("x", again.readFile("config.txt")!!.toString())
        assertEquals(1, again.listNames().count { it.equals("config.txt", true) })
    }

    @Test fun rootDirectoryGrowsAcrossClusters() {
        val d = formatted()
        val fat = FatBoot.mount(d)
        for (i in 0 until 20) fat.writeFile("file-number-$i.dat", "v$i".toByteArray())   // LFN: 3 slots each
        val again = FatBoot.mount(d)
        for (i in 0 until 20) assertEquals("v$i", again.readFile("file-number-$i.dat")!!.toString())
    }

    @Test fun shortNameCollisionsGetDistinctAliases() {
        val d = formatted()
        val fat = FatBoot.mount(d)
        fat.writeFile("network-config-a", "1".toByteArray())
        fat.writeFile("network-config-b", "2".toByteArray())
        val again = FatBoot.mount(d)
        assertEquals("1", again.readFile("network-config-a")!!.toString())
        assertEquals("2", again.readFile("network-config-b")!!.toString())
    }
}
