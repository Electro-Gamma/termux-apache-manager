package org.rpiimager.android

import org.junit.Assert.*
import org.junit.Test
import org.rpiimager.android.catalog.OsListParser
import org.rpiimager.android.customise.*

/** Fake hasher so unit tests run on the JVM without the NDK library. */
private object FakeCrypt : CryptBackend {
    override fun yescrypt(key: ByteArray, salt: ByteArray) = "\$y\$FAKE"
    override fun sha256crypt(key: ByteArray, salt: ByteArray) = "\$5\$FAKE"
}

class CustomisationTest {
    private val s = mapOf<String, Any?>(
        "hostname" to "pi5", "sshEnabled" to true, "sshUserName" to "alice",
        "sshUserPasswordPlain" to "secret", "osReleaseDate" to "2025-11-24",
        "sshPasswordAuth" to true, "wifiSSID" to "Home\"Net", "wifiPassword" to "pw\n",
        "recommendedWifiCountry" to "GB", "timezone" to "Europe/London", "keyboard" to "gb",
        "enableI2C" to true,
    )

    @Test fun cloudInitUserData() {
        val y = CustomisationGenerator.generateCloudInitUserData(s, "", true, true, "pi", FakeCrypt)
            .toString(Charsets.UTF_8)
        assertTrue(y.startsWith("manage_resolv_conf: false\n\nhostname: \"pi5\"\n"))
        assertTrue(y.contains("  name: \"alice\"\n"))
        assertTrue(y.contains("  passwd: \"\$y\$FAKE\"\n"))
        assertTrue(y.contains("  sudo: null\n"))
        assertTrue(y.contains("ssh_pwauth: true\n"))
        assertTrue(y.contains("    i2c: true\n"))
        assertTrue(y.contains("  - [ systemctl, enable, --now, ssh ]\n"))
    }

    @Test fun networkConfigEscapesSsidAndStripsPasswordNewline() {
        val n = CustomisationGenerator.generateCloudInitNetworkConfig(s).toString(Charsets.UTF_8)
        assertTrue(n.contains("        \"Home\\\"Net\":\n"))
        assertTrue(n.contains("          password: \"pw\"\n"))
        assertTrue(n.contains("regulatory-domain: \"GB\""))
    }

    @Test fun planCloudInitRpiWritesExpectedFiles() {
        val p = CustomisationPlanner.plan("cloudinit-rpi", s, backend = FakeCrypt, nowMillis = 42)
        assertEquals(setOf("meta-data", "user-data", "network-config"), p.files.keys)
        assertEquals("instance-id: rpi-imager-42\n", p.files["meta-data"]!!.toString(Charsets.UTF_8))
        assertTrue(p.files["user-data"]!!.toString(Charsets.UTF_8).startsWith("#cloud-config\n"))
        assertEquals(" cfg80211.ieee80211_regdom=GB ds=nocloud;i=rpi-imager-42", p.cmdlineAppend)
    }

    @Test fun planPreseed() {
        val p = CustomisationPlanner.plan("rpi-preseed", s, backend = FakeCrypt)
        val t = p.files["rpi-preseed.toml"]!!.toString(Charsets.UTF_8)
        assertTrue(t.startsWith("config_version = \"1.0\"\n\n[system]\nhostname = \"pi5\"\n"))
        assertTrue(t.contains("password_encrypted = true"))
        assertFalse(p.cmdlineAppend.contains("ds=nocloud"))
    }

    @Test fun systemdIsRefusedNotSilentlySkipped() {
        try { CustomisationPlanner.plan("systemd", s, backend = FakeCrypt); fail() }
        catch (e: UnsupportedCustomisationException) { }
    }

    @Test fun noneProducesNothing() =
        assertTrue(CustomisationPlanner.plan("", s, backend = FakeCrypt).isEmpty)

    @Test fun countryCodeCannotInjectKernelParams() {
        val p = CustomisationPlanner.plan("rpi-preseed", s + ("recommendedWifiCountry" to "GB init=/bin/sh"), backend = FakeCrypt)
        assertEquals("", p.cmdlineAppend)
    }

    @Test fun configTxtMerge() {
        assertEquals("a=1\nb=2\n", CustomisationPlanner.mergeConfigTxtItem("a=1\n", "b=2"))
        assertEquals("a=1\n", CustomisationPlanner.mergeConfigTxtItem("a=1\n", "a=1"))
        assertEquals("a=1\n", CustomisationPlanner.mergeConfigTxtItem("#a=1\n", "a=1"))
    }

    @Test fun yescryptCutoff() {
        assertTrue(PasswordCrypt.osUsesYescrypt("2025-10-01"))
        assertFalse(PasswordCrypt.osUsesYescrypt("2022-12-31"))
    }

    @Test fun catalogueFiltersInvalidInitFormatAndPrunesEmptyParents() {
        val json = """{"os_list":[
          {"name":"ok","init_format":"cloudinit-rpi","url":"u"},
          {"name":"bad","init_format":"bogus"},
          {"name":"parent","subitems":[{"name":"x","init_format":"nope"}]},
          {"name":"group","subitems":[{"name":"child","init_format":"systemd"}]}]}"""
        val l = OsListParser.parse(json)
        assertEquals(listOf("ok", "group"), l.map { it.name })
        assertEquals("child", l[1].subitems[0].name)
    }
}
