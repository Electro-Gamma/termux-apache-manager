// SPDX-License-Identifier: Apache-2.0
// Mirrors how rpi-imager 2.0.12 (imagewriter.cpp _apply*CustomisationFromSettings and
// downloadthread.cpp _customizeImage) decides which files go on the FAT boot partition.
package org.rpiimager.android.customise

class UnsupportedCustomisationException(msg: String) : Exception(msg)

/** Files to create on the boot partition and edits to apply to cmdline.txt / config.txt. */
data class BootCustomisation(
    val files: Map<String, ByteArray> = emptyMap(),
    val cmdlineAppend: String = "",
    val configTxtItems: List<String> = emptyList(),
) {
    val isEmpty get() = files.isEmpty() && cmdlineAppend.isEmpty() && configTxtItems.isEmpty()
}

object CustomisationPlanner {
    fun plan(
        initFormat: String, settings: Settings, piConnectToken: String = "",
        currentUser: String = "pi", backend: CryptBackend, nowMillis: Long = System.currentTimeMillis(),
    ): BootCustomisation {
        val s = settings
        val sshEnabled = (s["sshEnabled"] as? Boolean) ?: false
        fun regdom(): String {
            val c = Escaping.sanitisedCountryCode(((s["recommendedWifiCountry"] as? String) ?: "").trim())
            return if (c.isNotEmpty()) " cfg80211.ieee80211_regdom=$c" else ""
        }
        return when (initFormat) {
            "", "none" -> BootCustomisation()
            "systemd" -> throw UnsupportedCustomisationException(
                "This image uses init_format=systemd (firstrun.sh). That generator is not ported yet; " +
                    "refusing to silently skip customisation.")
            "rpi-preseed" -> {
                val toml = CustomisationGenerator.generateRpiPreseedToml(s, piConnectToken, sshEnabled, backend)
                if (toml.isEmpty()) BootCustomisation()
                else BootCustomisation(mapOf("rpi-preseed.toml" to toml), regdom())
            }
            "cloudinit", "cloudinit-rpi" -> {
                val hasCcRpi = initFormat == "cloudinit-rpi"
                val cloud = CustomisationGenerator.generateCloudInitUserData(
                    s, piConnectToken, hasCcRpi, sshEnabled, currentUser, backend)
                val net = CustomisationGenerator.generateCloudInitNetworkConfig(s)
                if (cloud.isEmpty() && net.isEmpty()) return BootCustomisation()
                val id = "rpi-imager-$nowMillis"
                val files = linkedMapOf<String, ByteArray>("meta-data" to "instance-id: $id\n".toByteArray())
                if (cloud.isNotEmpty()) files["user-data"] = "#cloud-config\n".toByteArray() + cloud
                if (net.isNotEmpty()) files["network-config"] = net
                BootCustomisation(files, regdom() + " ds=nocloud;i=$id")
            }
            else -> throw UnsupportedCustomisationException("Unknown init_format '$initFormat'")
        }
    }

    /** cmdline.txt is one line: existing (trimmed) + appended parameters. */
    fun applyCmdline(existing: ByteArray, append: String): ByteArray =
        if (append.isEmpty()) existing
        else {
            val e = existing.toString(Charsets.UTF_8).trim()
            if (e.contains(append.trim())) existing            // already applied (safe to re-run)
            else (e + append).toByteArray(Charsets.UTF_8)
        }

    /** Port of mergeConfigTxtItem: keep if present, uncomment in place, or append. */
    fun mergeConfigTxtItem(config: String, rawItem: String): String {
        fun strip(l: String) = l.trimEnd('\r')
        val item = strip(rawItem)
        if (item.isEmpty()) return config
        val lines = config.split('\n')
        val commented = "#$item"
        var at = -1
        for ((i, l) in lines.withIndex()) {
            val sl = strip(l)
            if (sl == item) return config
            if (at < 0 && sl == commented) at = i
        }
        if (at >= 0) {
            val out = lines.toMutableList()
            out[at] = if (lines[at].endsWith("\r")) "$item\r" else item
            return out.joinToString("\n")
        }
        var r = config
        if (r.isNotEmpty() && !r.endsWith("\n")) r += "\n"
        return "$r$item\n"
    }
}
