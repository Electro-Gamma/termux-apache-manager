// SPDX-License-Identifier: Apache-2.0
package org.rpiimager.android.ui

import android.app.Application
import android.content.Context
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import org.rpiimager.android.catalog.CatalogueClient
import org.rpiimager.android.catalog.OsEntry
import org.rpiimager.android.catalog.OsListParser
import org.rpiimager.android.customise.BootCustomisation
import org.rpiimager.android.customise.CustomisationPlanner
import org.rpiimager.android.customise.NativeCrypt
import org.rpiimager.android.customise.Settings
import org.rpiimager.android.fat.BootCustomiser
import org.rpiimager.android.io.ImageSource
import org.rpiimager.android.io.ImageWriter
import org.rpiimager.android.io.WriteAbort
import org.rpiimager.android.usb.UsbMassStorage
import org.rpiimager.android.usb.UsbStorage
import java.time.LocalDate
import java.util.TimeZone
import java.util.concurrent.CancellationException

enum class Step { OS, STORAGE, CUSTOMISE, CONFIRM, WRITE }

data class Selected(
    val name: String, val url: String? = null, val uri: Uri? = null, val extractSize: Long = 0,
    val sha256: String = "", val releaseDate: String = "", val initFormat: String = "",
    val erase: Boolean = false, val custom: Boolean = false, val compressedSize: Long = 0,
)

data class Form(
    val enabled: Boolean = true,
    val hostname: String = "raspberrypi",
    val user: String = "", val password: String = "",
    val ssh: Boolean = false, val sshPasswordAuth: Boolean = true, val sshKey: String = "",
    val wifiSsid: String = "", val wifiPassword: String = "", val wifiHidden: Boolean = false,
    val country: String = "", val timezone: String = TimeZone.getDefault().id, val keyboard: String = "us",
    val i2c: Boolean = false, val spi: Boolean = false, val onewire: Boolean = false,
    val customInit: String = "none",
) {
    fun toSettings(osDate: String): Settings = mapOf(
        "hostname" to hostname, "sshEnabled" to ssh, "sshUserName" to user, "sshUserPasswordPlain" to password,
        "osReleaseDate" to osDate, "sshPasswordAuth" to sshPasswordAuth, "sshPublicKey" to sshKey,
        "wifiConfigured" to wifiSsid.isNotBlank(), "wifiSSID" to wifiSsid, "wifiPassword" to wifiPassword,
        "wifiHidden" to wifiHidden, "recommendedWifiCountry" to country, "timezone" to timezone,
        "keyboard" to keyboard, "enableI2C" to i2c, "enableSPI" to spi, "enable1Wire" to onewire,
    )

    fun problems(): List<String> {
        val p = ArrayList<String>()
        if (user.isNotEmpty() && password.isEmpty()) p.add("Enter a password for the user.")
        if (user.isEmpty() && password.isNotEmpty()) p.add("Enter a username for the password.")
        if (wifiSsid.isNotEmpty() && wifiPassword.isNotEmpty() && wifiPassword.length !in 8..63)
            p.add("Wi-Fi password must be 8-63 characters.")
        if (wifiSsid.isNotEmpty() && country.length != 2) p.add("Enter a 2-letter Wi-Fi country code (e.g. GB, US).")
        return p
    }
}

sealed interface WriteState {
    data object Idle : WriteState
    data class Running(val phase: String, val done: Long, val total: Long, val bytesPerSec: Long) : WriteState
    data class Done(val message: String) : WriteState
    data class Failed(val message: String) : WriteState
}

class WizardViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("imager", Context.MODE_PRIVATE)

    val step = MutableStateFlow(Step.OS)
    val osStack = MutableStateFlow<List<Pair<String, List<OsEntry>>>>(emptyList())
    val loading = MutableStateFlow(true)
    val loadError = MutableStateFlow<String?>(null)
    val notice = MutableStateFlow<String?>(null)
    val selected = MutableStateFlow<Selected?>(null)
    val devices = MutableStateFlow<List<UsbDevice>>(emptyList())
    val device = MutableStateFlow<UsbDevice?>(null)
    val usbMessage = MutableStateFlow<String?>(null)
    val form = MutableStateFlow(loadForm())
    val write = MutableStateFlow<WriteState>(WriteState.Idle)
    val log = MutableStateFlow<List<String>>(emptyList())
    @Volatile private var activeUsb: UsbMassStorage? = null

    private fun logLine(m: String) { log.value = (log.value + m).takeLast(120) }

    @Volatile private var cancelRequested = false
    private var job: Job? = null

    init { loadCatalogue() }

    // ---- catalogue / OS selection ---------------------------------------------------------
    private val cacheFile get() = java.io.File(getApplication<Application>().filesDir, "oslist.json")

    private fun friendly(e: Throwable): String = when (e) {
        is java.net.UnknownHostException, is java.net.ConnectException, is java.net.SocketTimeoutException ->
            "No internet connection"
        else -> e.message ?: e.toString()
    }

    /** Erase and Use custom never need internet, so they are always offered. */
    private fun builtInEntries(): List<OsEntry> {
        val noStrings = emptyList<String>()
        val noOs = emptyList<OsEntry>()
        return listOf(
            OsEntry("Erase", "Wipe the card's partition table and filesystem metadata", "",
                "internal://format", 0, "", 0, "", "", noStrings, noStrings, "", noOs),
            OsEntry("Use custom", "Select a local .img, .img.xz, .img.gz or .zip file", "",
                "internal://custom", 0, "", 0, "", "", noStrings, noStrings, "", noOs),
        )
    }

    fun loadCatalogue() {
        loading.value = true; loadError.value = null; notice.value = null
        viewModelScope.launch(Dispatchers.IO) {
            val base: List<OsEntry> = try {
                val json = CatalogueClient.fetch()
                val parsed = OsListParser.parse(json)
                runCatching { cacheFile.writeText(json) }          // keep for offline starts
                parsed
            } catch (e: Exception) {
                val saved = runCatching { OsListParser.parse(cacheFile.readText()) }.getOrNull()
                loadError.value = friendly(e) + if (saved != null)
                    ". Showing the last saved list - downloading needs internet; Erase and Use custom work offline."
                else ". Erase and Use custom work offline."
                saved ?: emptyList()
            }
            osStack.value = listOf("Choose OS" to (base + builtInEntries()))
            loading.value = false
        }
    }

    fun onOsClicked(e: OsEntry) {
        notice.value = null
        when {
            e.url == "internal://format" -> { selected.value = Selected("Erase", erase = true); step.value = Step.STORAGE }
            e.subitems.isNotEmpty() -> osStack.value = osStack.value + (e.name to e.subitems)
            e.subitemsUrl.startsWith("https://") -> {
                loading.value = true
                viewModelScope.launch(Dispatchers.IO) {
                    try {
                        val l = OsListParser.parse(CatalogueClient.fetch(e.subitemsUrl))
                        osStack.value = osStack.value + (e.name to l)
                    } catch (ex: Exception) { notice.value = "Could not open this list: " + friendly(ex) }
                    loading.value = false
                }
            }
            e.url.startsWith("https://") -> {
                selected.value = Selected(e.name, url = e.url, extractSize = e.extractSize, sha256 = e.extractSha256,
                    releaseDate = e.releaseDate, initFormat = e.initFormat)
                step.value = Step.STORAGE
            }
        }
    }

    fun onCustomPicked(uri: Uri, name: String, size: Long) {
        val raw = name.lowercase().let { it.endsWith(".img") || it.endsWith(".iso") }
        selected.value = Selected(name, uri = uri, extractSize = if (raw && size > 0) size else 0,
            compressedSize = if (size > 0) size else 0, custom = true)
        step.value = Step.STORAGE
    }

    // ---- storage ------------------------------------------------------------------------
    fun refreshDevices() { devices.value = UsbStorage.list(getApplication()) }

    fun pickDevice(d: UsbDevice) {
        viewModelScope.launch {
            val ok = UsbStorage.requestPermission(getApplication(), d)
            if (ok) { device.value = d; usbMessage.value = null } else usbMessage.value = "USB permission was denied."
        }
    }

    // ---- navigation ---------------------------------------------------------------------
    fun updateForm(f: (Form) -> Form) { form.value = f(form.value) }

    fun next() {
        step.value = when (step.value) {
            Step.STORAGE -> if (selected.value?.erase == true) Step.CONFIRM else Step.CUSTOMISE
            Step.CUSTOMISE -> { saveForm(); Step.CONFIRM }
            else -> step.value
        }
    }

    fun back() {
        if (write.value is WriteState.Running) return
        when (step.value) {
            Step.OS -> if (osStack.value.size > 1) osStack.value = osStack.value.dropLast(1)
            Step.STORAGE -> step.value = Step.OS
            Step.CUSTOMISE -> step.value = Step.STORAGE
            Step.CONFIRM -> step.value = if (selected.value?.erase == true) Step.STORAGE else Step.CUSTOMISE
            Step.WRITE -> { write.value = WriteState.Idle; step.value = Step.CONFIRM }
        }
    }

    fun restart() { write.value = WriteState.Idle; selected.value = null; device.value = null; step.value = Step.OS }

    // ---- effective customisation -----------------------------------------------------------
    fun effectiveInitFormat(s: Selected): String =
        if (s.custom) form.value.customInit.let { if (it == "none") "" else it } else s.initFormat

    private fun osDate(s: Selected) = s.releaseDate.ifEmpty { LocalDate.now().toString() }

    // ---- write ----------------------------------------------------------------------------
    /** Kept after a successful write so verification can be retried without rewriting the card. */
    private class Resume(val bytes: Long, val digest: ByteArray, val plan: BootCustomisation)
    private var resume: Resume? = null
    val canResumeVerify = MutableStateFlow(false)
    private var phaseStart = 0L
    private var lastPost = 0L

    fun cancel() {
        cancelRequested = true
        logLine("Cancel requested")
        activeUsb?.close()          // aborts a transfer that is blocked on the device
    }

    private fun beginPhase() { phaseStart = SystemClock.elapsedRealtime(); lastPost = 0L }

    private fun report(phase: String, done: Long, total: Long, force: Boolean = false) {
        val now = SystemClock.elapsedRealtime()
        if (!force && now - lastPost < 250) return
        lastPost = now
        val el = maxOf(1L, now - phaseStart)
        write.value = WriteState.Running(phase, done, total, done * 1000 / el)
    }

    fun startWrite() {
        val sel = selected.value ?: return
        val dev = device.value ?: return
        step.value = Step.WRITE
        log.value = emptyList()
        resume = null
        canResumeVerify.value = false
        write.value = WriteState.Running("Preparing", 0, -1, 0)
        job = viewModelScope.launch(Dispatchers.IO) { guarded { runWrite(sel, dev) } }
    }

    fun resumeVerify() {
        val dev = device.value ?: return
        if (resume == null) return
        write.value = WriteState.Running("Preparing", 0, -1, 0)
        logLine("--- Retrying verification (the image is already written) ---")
        job = viewModelScope.launch(Dispatchers.IO) { guarded { runResume(dev) } }
    }

    private suspend fun guarded(body: suspend () -> Unit) {
        cancelRequested = false
        try {
            body()
        } catch (e: Throwable) {
            logLine("ERROR ${e.javaClass.simpleName}: ${e.message}")
            logLine("Card reader still attached: " + UsbStorage.list(getApplication()).isNotEmpty())
            val r = resume
            write.value = if (cancelRequested || e is CancellationException) {
                WriteState.Failed(if (r != null)
                    "Cancelled during verification. The image is already written; you can retry verification."
                else "Cancelled. If a write had started, the card may be partly written and will not boot.")
            } else WriteState.Failed(e.message ?: e.toString())
            canResumeVerify.value = r != null
        } finally {
            activeUsb?.close()
            activeUsb = null
        }
    }

    /** The reader may have been re-plugged since selection; find it again and re-ask permission if needed. */
    private suspend fun reacquire(old: UsbDevice): UsbDevice {
        val ctx = getApplication<Application>()
        val all = UsbStorage.list(ctx)
        val d = all.firstOrNull { it.deviceName == old.deviceName }
            ?: all.firstOrNull { it.vendorId == old.vendorId && it.productId == old.productId }
            ?: throw WriteAbort("The card reader is not connected. Plug it in and try again.")
        if (!UsbStorage.requestPermission(ctx, d)) throw WriteAbort("USB permission was denied.")
        device.value = d
        return d
    }

    private suspend fun openReader(old: UsbDevice): UsbMassStorage {
        val ctx = getApplication<Application>()
        report("Opening card reader", 0, -1, true)
        val d = reacquire(old)
        val u = UsbMassStorage.open(ctx.getSystemService(Context.USB_SERVICE) as UsbManager, d,
            { m -> logLine(m) }, { cancelRequested })
        activeUsb = u
        return u
    }

    private suspend fun runWrite(sel: Selected, dev: UsbDevice) {
        val ctx = getApplication<Application>()
        val f = form.value
        val fmt = effectiveInitFormat(sel)
        var plan = BootCustomisation()
        if (!sel.erase && f.enabled && fmt.isNotEmpty()) {
            if (f.problems().isNotEmpty()) throw WriteAbort(f.problems().first())
            plan = CustomisationPlanner.plan(fmt, f.toSettings(osDate(sel)), backend = NativeCrypt)
        }
        beginPhase()
        logLine(if (sel.erase) "Action: erase" else "Image: ${sel.name}")
        val u = openReader(dev)
        val cap = u.blockCount * u.blockSize
        if (sel.erase) {
            beginPhase()
            ImageWriter.erase(u, { d, t -> report("Erasing", d, t) }, { cancelRequested })
            write.value = WriteState.Done("Card erased (first 32 MiB zeroed). It now has no partition table.")
            return
        }
        if (sel.extractSize > cap) throw WriteAbort(
            "The image (${sel.extractSize / 1_000_000} MB) is larger than the card (${cap / 1_000_000} MB).")
        val total = if (sel.extractSize > 0) sel.extractSize else -1L
        logLine("Card capacity ${cap / 1_000_000} MB; image size " +
            (if (sel.extractSize > 0) "${sel.extractSize / 1_000_000} MB" else "unknown until extracted"))
        val label = if (sel.url != null) "Downloading and writing" else "Writing"
        beginPhase()
        report(label, 0, total, true)
        val opened = ImageSource.open(ctx, sel.url, sel.uri, sel.name, sel.compressedSize)
        val (bytes, digest) = opened.stream.use {
            ImageWriter.write(u, it, { d ->
                if (total > 0) report(label, d, total)
                else if (opened.compressedTotal > 0) report(label, opened.compressedRead(), opened.compressedTotal)
                else report(label, d, -1)
            }, { cancelRequested })
        }
        val got = ImageWriter.hex(digest)
        logLine("Written ${bytes / 1_000_000} MB, SHA-256 $got")
        if (sel.sha256.isNotEmpty() && !got.equals(sel.sha256, ignoreCase = true))
            throw WriteAbort("Integrity check failed: the downloaded image does not match the official SHA-256. " +
                "The card now contains a bad image - write again.")
        val r = Resume(bytes, digest, plan)
        resume = r
        verifyAndFinish(u, r)
    }

    private suspend fun runResume(dev: UsbDevice) {
        val r = resume ?: throw WriteAbort("Nothing to resume - write the image again.")
        beginPhase()
        val u = openReader(dev)
        verifyAndFinish(u, r)
    }

    private fun verifyAndFinish(u: UsbMassStorage, r: Resume) {
        beginPhase()
        report("Verifying", 0, r.bytes, true)
        var verified = 0L
        val ok = try {
            ImageWriter.verify(u, r.bytes, r.digest, { d -> verified = d; report("Verifying", d, r.bytes) }, { cancelRequested })
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            throw WriteAbort("Verification was interrupted after ${verified / 1_000_000} MB: ${e.message}")
        }
        if (!ok) {
            resume = null
            throw WriteAbort("Verification failed: data read back from the card differs from what was written. " +
                "The card or reader may be faulty - write again, preferably with another card.")
        }
        logLine("Verify OK")
        var extra = ""
        if (!r.plan.isEmpty) {
            beginPhase()
            report("Applying settings", 0, -1, true)
            BootCustomiser.apply(u, r.plan)
            extra = " Settings applied."
        }
        u.sync()
        resume = null
        canResumeVerify.value = false
        write.value = WriteState.Done("Wrote and verified ${r.bytes / 1_000_000} MB " +
            "(SHA-256 ${ImageWriter.hex(r.digest).take(16)}...)." + extra + " You can remove the card.")
    }

    // ---- persistence (passwords are never stored) -----------------------------------------------
    private fun loadForm(): Form {
        val d = Form()
        return Form(
            enabled = prefs.getBoolean("enabled", d.enabled), hostname = prefs.getString("hostname", d.hostname) ?: d.hostname,
            user = prefs.getString("user", "") ?: "", ssh = prefs.getBoolean("ssh", false),
            sshPasswordAuth = prefs.getBoolean("sshPw", true), sshKey = prefs.getString("sshKey", "") ?: "",
            wifiSsid = prefs.getString("ssid", "") ?: "", wifiHidden = prefs.getBoolean("hidden", false),
            country = prefs.getString("country", "") ?: "", timezone = prefs.getString("tz", d.timezone) ?: d.timezone,
            keyboard = prefs.getString("kb", d.keyboard) ?: d.keyboard,
            i2c = prefs.getBoolean("i2c", false), spi = prefs.getBoolean("spi", false), onewire = prefs.getBoolean("ow", false),
        )
    }

    private fun saveForm() {
        val f = form.value
        prefs.edit().putBoolean("enabled", f.enabled).putString("hostname", f.hostname).putString("user", f.user)
            .putBoolean("ssh", f.ssh).putBoolean("sshPw", f.sshPasswordAuth).putString("sshKey", f.sshKey)
            .putString("ssid", f.wifiSsid).putBoolean("hidden", f.wifiHidden).putString("country", f.country)
            .putString("tz", f.timezone).putString("kb", f.keyboard).putBoolean("i2c", f.i2c)
            .putBoolean("spi", f.spi).putBoolean("ow", f.onewire).apply()
    }
}
