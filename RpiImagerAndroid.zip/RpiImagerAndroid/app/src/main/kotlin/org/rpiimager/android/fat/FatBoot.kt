// SPDX-License-Identifier: Apache-2.0
// Minimal FAT32 reader/writer for the root directory of a Raspberry Pi OS boot partition,
// operating directly on the raw card (Android cannot mount it). Supports long file names.
// Replaces devicewrapperfatpartition.cpp / fatfs from the original. Root directory only.
package org.rpiimager.android.fat

import org.rpiimager.android.usb.BlockDevice

class FatException(msg: String) : Exception(msg)

private fun le16(b: ByteArray, o: Int) = (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8)
private fun le32(b: ByteArray, o: Int): Long = le16(b, o).toLong() or (le16(b, o + 2).toLong() shl 16)
private fun put16(b: ByteArray, o: Int, v: Int) { b[o] = v.toByte(); b[o + 1] = (v ushr 8).toByte() }
private fun put32(b: ByteArray, o: Int, v: Long) { put16(b, o, (v and 0xFFFF).toInt()); put16(b, o + 2, ((v ushr 16) and 0xFFFF).toInt()) }

class FatBoot private constructor(private val dev: BlockDevice) {
    private var partLba = 0L
    private var spc = 0
    private var clusterBytes = 0
    private var reserved = 0
    private var fatLba = 0L
    private var fatSectors = 0
    private var nFats = 0
    private var dataLba = 0L
    private var rootCluster = 2
    private var maxCluster = 0
    private var fsInfoSector = 0
    private lateinit var fat: ByteArray

    companion object {
        private val LFN_OFFS = intArrayOf(1, 3, 5, 7, 9, 14, 16, 18, 20, 22, 24, 28, 30)
        fun mount(dev: BlockDevice): FatBoot = FatBoot(dev).also { it.load() }
    }

    private class Ent(
        val name: String, val short11: String, val cluster: Int, val size: Long,
        val firstIdx: Int, val lastIdx: Int, val isDir: Boolean,
    )

    private fun load() {
        if (dev.blockSize != 512) throw FatException("Customisation needs a 512-byte-sector card reader (got ${dev.blockSize})")
        val mbr = ByteArray(512)
        dev.read(0, 1, mbr)
        if (le16(mbr, 510) != 0xAA55) throw FatException("No partition table found on the card")
        var found = -1L
        for (i in 0 until 4) {
            val o = 446 + 16 * i
            val type = mbr[o + 4].toInt() and 0xFF
            if (type == 0x0B || type == 0x0C || type == 0x1B || type == 0x1C) { found = le32(mbr, o + 8); break }
        }
        if (found < 0) throw FatException("No FAT32 boot partition found (is this a Raspberry Pi image?)")
        partLba = found
        val bpb = ByteArray(512)
        dev.read(partLba, 1, bpb)
        if (le16(bpb, 11) != 512) throw FatException("Unsupported FAT sector size")
        if (le16(bpb, 17) != 0 || le16(bpb, 22) != 0) throw FatException("Boot partition is not FAT32")
        spc = bpb[13].toInt() and 0xFF
        reserved = le16(bpb, 14)
        nFats = bpb[16].toInt() and 0xFF
        fatSectors = le32(bpb, 36).toInt()
        val total = le32(bpb, 32)
        rootCluster = le32(bpb, 44).toInt()
        fsInfoSector = le16(bpb, 48)
        if (spc == 0 || nFats == 0 || fatSectors <= 0) throw FatException("Corrupt FAT32 header")
        clusterBytes = spc * 512
        fatLba = partLba + reserved
        dataLba = fatLba + nFats.toLong() * fatSectors
        maxCluster = ((total - reserved - nFats.toLong() * fatSectors) / spc).toInt() + 1
        fat = ByteArray(fatSectors * 512)
        dev.read(fatLba, fatSectors, fat)
    }

    // ---- FAT table ---------------------------------------------------------------------
    private fun fatGet(c: Int) = (le32(fat, c * 4) and 0x0FFFFFFFL).toInt()
    private fun fatSet(c: Int, v: Int) {
        val keep = le32(fat, c * 4) and 0xF0000000L
        put32(fat, c * 4, keep or (v.toLong() and 0x0FFFFFFFL))
    }

    private fun chain(start: Int): MutableList<Int> {
        val l = ArrayList<Int>()
        var c = start
        while (c in 2..maxCluster && l.size <= maxCluster) { l.add(c); c = fatGet(c) }
        return l
    }

    private fun allocate(n: Int): List<Int> {
        val out = ArrayList<Int>(n)
        var c = 2
        while (out.size < n && c <= maxCluster) { if (fatGet(c) == 0) out.add(c); c++ }
        if (out.size < n) throw FatException("Boot partition is full")
        for (i in out.indices) fatSet(out[i], if (i + 1 < out.size) out[i + 1] else 0x0FFFFFFF)
        return out
    }

    private fun clusterLba(c: Int) = dataLba + (c - 2).toLong() * spc

    private fun readClusters(list: List<Int>): ByteArray {
        val out = ByteArray(list.size * clusterBytes)
        for ((i, c) in list.withIndex()) dev.read(clusterLba(c), spc, out, i * clusterBytes)
        return out
    }

    private fun writeClusters(list: List<Int>, data: ByteArray) {
        for ((i, c) in list.withIndex()) {
            val chunk = ByteArray(clusterBytes)
            val n = minOf(clusterBytes, data.size - i * clusterBytes)
            if (n > 0) System.arraycopy(data, i * clusterBytes, chunk, 0, n)
            dev.write(clusterLba(c), spc, chunk, 0)
        }
    }

    private fun flushFat() {
        for (f in 0 until nFats) dev.write(fatLba + f.toLong() * fatSectors, fatSectors, fat, 0)
        if (fsInfoSector in 1 until reserved) {          // mark the free-cluster hints as unknown
            val b = ByteArray(512)
            dev.read(partLba + fsInfoSector, 1, b)
            if (le32(b, 0) == 0x41615252L) {
                put32(b, 488, 0xFFFFFFFFL); put32(b, 492, 0xFFFFFFFFL)
                dev.write(partLba + fsInfoSector, 1, b, 0)
            }
        }
    }

    // ---- directory parsing -------------------------------------------------------------
    private fun checksum(d: ByteArray, o: Int): Int {
        var s = 0
        for (i in 0 until 11) s = (((s and 1) shl 7) + (s ushr 1) + (d[o + i].toInt() and 0xFF)) and 0xFF
        return s
    }

    private fun lfnChars(d: ByteArray, o: Int): String {
        val sb = StringBuilder()
        for (x in LFN_OFFS) {
            val c = le16(d, o + x)
            if (c == 0 || c == 0xFFFF) break
            sb.append(c.toChar())
        }
        return sb.toString()
    }

    private fun decodeShort(d: ByteArray, o: Int): String {
        val base = String(d, o, 8, Charsets.ISO_8859_1).trimEnd()
        val ext = String(d, o + 8, 3, Charsets.ISO_8859_1).trimEnd()
        val nt = d[o + 12].toInt()
        val b = if ((nt and 0x08) != 0) base.lowercase() else base
        val e = if ((nt and 0x10) != 0) ext.lowercase() else ext
        return if (e.isEmpty()) b else "$b.$e"
    }

    private fun parseDir(d: ByteArray): List<Ent> {
        val res = ArrayList<Ent>()
        val lfn = ArrayList<Pair<Int, String>>()
        var lfnStart = -1
        var lfnCk = -1
        for (i in 0 until d.size / 32) {
            val o = i * 32
            val f = d[o].toInt() and 0xFF
            if (f == 0) break
            if (f == 0xE5) { lfn.clear(); lfnStart = -1; continue }
            val attr = d[o + 11].toInt() and 0xFF
            if (attr == 0x0F) {
                if (lfn.isEmpty()) { lfnStart = i; lfnCk = d[o + 13].toInt() and 0xFF }
                lfn.add((f and 0x3F) to lfnChars(d, o))
                continue
            }
            if ((attr and 0x08) != 0) { lfn.clear(); lfnStart = -1; continue }
            var name = decodeShort(d, o)
            var start = i
            if (lfn.isNotEmpty() && lfnCk == checksum(d, o)) {
                name = lfn.sortedBy { it.first }.joinToString("") { it.second }
                start = lfnStart
            }
            res.add(Ent(name, String(d, o, 11, Charsets.ISO_8859_1),
                (le16(d, o + 20) shl 16) or le16(d, o + 26), le32(d, o + 28), start, i, (attr and 0x10) != 0))
            lfn.clear(); lfnStart = -1
        }
        return res
    }

    // ---- public API --------------------------------------------------------------------
    fun listNames(): List<String> = parseDir(readClusters(chain(rootCluster))).map { it.name }

    fun readFile(name: String): ByteArray? {
        val e = parseDir(readClusters(chain(rootCluster))).firstOrNull { it.name.equals(name, ignoreCase = true) }
            ?: return null
        if (e.size == 0L || e.cluster < 2) return ByteArray(0)
        return readClusters(chain(e.cluster)).copyOf(e.size.toInt())
    }

    /** Create or replace a file in the root directory. Data first, then FAT, directory last. */
    fun writeFile(name: String, data: ByteArray) {
        val rootChain = chain(rootCluster)
        var dir = readClusters(rootChain)
        val ents = parseDir(dir)
        val old = ents.firstOrNull { it.name.equals(name, ignoreCase = true) }
        if (old != null) {
            if (old.isDir) throw FatException("$name is a directory")
            if (old.cluster >= 2) for (c in chain(old.cluster)) fatSet(c, 0)
            for (i in old.firstIdx..old.lastIdx) dir[i * 32] = 0xE5.toByte()
        }
        val used = ents.filter { it !== old }.map { it.short11 }.toSet()
        val clusters = if (data.isEmpty()) emptyList() else allocate((data.size + clusterBytes - 1) / clusterBytes)
        val rec = buildRecord(name, used, clusters.firstOrNull() ?: 0, data.size)
        val need = rec.size / 32
        var slot = findFree(dir, need)
        while (slot < 0) {
            val nc = allocate(1)[0]
            fatSet(rootChain.last(), nc)
            rootChain.add(nc)
            dir += ByteArray(clusterBytes)
            slot = findFree(dir, need)
        }
        System.arraycopy(rec, 0, dir, slot * 32, rec.size)
        if (data.isNotEmpty()) writeClusters(clusters, data)
        flushFat()
        writeClusters(rootChain, dir)
        dev.sync()
    }

    private fun findFree(dir: ByteArray, need: Int): Int {
        var run = 0
        for (i in 0 until dir.size / 32) {
            val f = dir[i * 32].toInt() and 0xFF
            if (f == 0 || f == 0xE5) { run++; if (run == need) return i - need + 1 } else run = 0
        }
        return -1
    }

    // ---- directory record construction ------------------------------------------------
    private fun shortNameFor(name: String, used: Set<String>): Triple<String, Int, Boolean> {
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot + 1) else ""
        val simple = Regex("[A-Za-z0-9_-]+")
        val fits = name.count { it == '.' } <= 1 && base.length in 1..8 && ext.length <= 3 &&
            simple.matches(base) && (ext.isEmpty() || simple.matches(ext)) &&
            (base == base.lowercase() || base == base.uppercase()) &&
            (ext == ext.lowercase() || ext == ext.uppercase())
        if (fits) {
            val s11 = base.uppercase().padEnd(8) + ext.uppercase().padEnd(3)
            if (s11 !in used) {
                var nt = 0
                if (base != base.uppercase()) nt = nt or 0x08
                if (ext != ext.uppercase()) nt = nt or 0x10
                return Triple(s11, nt, false)
            }
        }
        fun clean(s: String) = s.uppercase().filter { it in 'A'..'Z' || it in '0'..'9' || it == '_' || it == '-' }
        val cb = clean(base)
        val ce = clean(ext).take(3)
        for (n in 1..999999) {
            val tail = "~$n"
            val s11 = (cb.take(8 - tail.length) + tail).padEnd(8) + ce.padEnd(3)
            if (s11 !in used) return Triple(s11, 0, true)
        }
        throw FatException("Cannot generate a short file name for $name")
    }

    private fun buildRecord(name: String, used: Set<String>, first: Int, size: Int): ByteArray {
        val (s11, nt, needLfn) = shortNameFor(name, used)
        val lfnCount = if (needLfn) (name.length + 12) / 13 else 0
        val rec = ByteArray((lfnCount + 1) * 32)
        val ck = run {
            val tmp = s11.toByteArray(Charsets.ISO_8859_1)
            checksum(tmp, 0)
        }
        for (k in 0 until lfnCount) {
            val o = (lfnCount - 1 - k) * 32
            val ord = k + 1
            rec[o] = (ord or (if (ord == lfnCount) 0x40 else 0)).toByte()
            rec[o + 11] = 0x0F
            rec[o + 13] = ck.toByte()
            for (j in 0 until 13) {
                val idx = k * 13 + j
                val ch = when { idx < name.length -> name[idx].code; idx == name.length -> 0; else -> 0xFFFF }
                put16(rec, o + LFN_OFFS[j], ch)
            }
        }
        val o = lfnCount * 32
        System.arraycopy(s11.toByteArray(Charsets.ISO_8859_1), 0, rec, o, 11)
        rec[o + 11] = 0x20
        rec[o + 12] = nt.toByte()
        val now = java.time.LocalDateTime.now()
        val date = ((now.year - 1980) shl 9) or (now.monthValue shl 5) or now.dayOfMonth
        val time = (now.hour shl 11) or (now.minute shl 5) or (now.second / 2)
        put16(rec, o + 14, time); put16(rec, o + 16, date); put16(rec, o + 18, date)
        put16(rec, o + 20, first ushr 16)
        put16(rec, o + 22, time); put16(rec, o + 24, date)
        put16(rec, o + 26, first and 0xFFFF)
        put32(rec, o + 28, size.toLong())
        return rec
    }
}
