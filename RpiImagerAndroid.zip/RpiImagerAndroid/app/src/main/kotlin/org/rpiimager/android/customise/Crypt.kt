// SPDX-License-Identifier: Apache-2.0
// Port of CustomisationGenerator::cryptPassword (rpi-imager 2.0.12).
package org.rpiimager.android.customise

import java.security.SecureRandom
import java.time.LocalDate

/** Password hashing backend; the production one calls the original C code via JNI. */
interface CryptBackend {
    fun yescrypt(key: ByteArray, salt: ByteArray): String?
    fun sha256crypt(key: ByteArray, salt: ByteArray): String?
}

object NativeCrypt : CryptBackend {
    init { System.loadLibrary("rpicrypt") }
    private external fun nativeYescrypt(key: ByteArray, salt: ByteArray): ByteArray?
    private external fun nativeSha256(key: ByteArray, salt: ByteArray): ByteArray?
    // The C code returns a static buffer, so calls are serialised.
    @Synchronized override fun yescrypt(key: ByteArray, salt: ByteArray): String? =
        nativeYescrypt(key, salt)?.toString(Charsets.UTF_8)
    @Synchronized override fun sha256crypt(key: ByteArray, salt: ByteArray): String? =
        nativeSha256(key, salt)?.toString(Charsets.UTF_8)
}

object PasswordCrypt {
    private const val SALT_CHARS =
        "./0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
    private val rng = SecureRandom()

    /** yescrypt for OS releases dated 2023-01-01 or later, sha256crypt otherwise. */
    fun osUsesYescrypt(osReleaseDate: String): Boolean {
        if (osReleaseDate.isEmpty()) return false
        val d = try { LocalDate.parse(osReleaseDate) } catch (e: Exception) { return false }
        return !d.isBefore(LocalDate.of(2023, 1, 1))
    }

    fun isYescryptHash(h: String) = h.startsWith("\$y\$") || h.startsWith("\$7\$")

    private fun salt(prefix: String, n: Int): ByteArray {
        val sb = StringBuilder(prefix)
        repeat(n) { sb.append(SALT_CHARS[rng.nextInt(SALT_CHARS.length)]) }
        return sb.toString().toByteArray(Charsets.US_ASCII)
    }

    fun crypt(password: ByteArray, osReleaseDate: String, backend: CryptBackend): String {
        // CR/LF can never be part of a usable password (PAM discards them).
        val pw = password.filter { it != '\r'.code.toByte() && it != '\n'.code.toByte() }.toByteArray()
        val out = if (osUsesYescrypt(osReleaseDate))
            backend.yescrypt(pw, salt("", 16))
        else
            backend.sha256crypt(pw, salt("\$5\$", 10))
        pw.fill(0)
        return out ?: ""
    }
}
