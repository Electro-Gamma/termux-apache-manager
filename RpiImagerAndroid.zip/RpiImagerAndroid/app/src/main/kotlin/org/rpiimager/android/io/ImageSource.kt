// SPDX-License-Identifier: Apache-2.0
// Streams an image from an https URL or a user-picked file and decompresses it on the fly
// (xz, gz, zip, or raw). Replaces libcurl + libarchive from the original. zstd: not yet.
package org.rpiimager.android.io

import android.content.Context
import android.net.Uri
import org.tukaani.xz.XZInputStream
import java.io.BufferedInputStream
import java.io.FilterInputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.GZIPInputStream
import java.util.zip.ZipInputStream

object ImageSource {
    private class Counting(i: InputStream) : FilterInputStream(i) {
        @Volatile var count = 0L
        override fun read(): Int { val r = super.read(); if (r >= 0) count++; return r }
        override fun read(b: ByteArray, off: Int, len: Int): Int {
            val r = super.read(b, off, len); if (r > 0) count += r; return r
        }
    }

    /** compressedRead/compressedTotal give real progress when the extracted size is unknown. */
    class Opened(val stream: InputStream, val compressedRead: () -> Long, val compressedTotal: Long)

    fun open(ctx: Context, url: String?, uri: Uri?, nameHint: String, sizeHint: Long = 0): Opened {
        var total = sizeHint
        val raw: InputStream = when {
            url != null -> { val c = connect(url); if (c.contentLengthLong > 0) total = c.contentLengthLong; c.inputStream }
            uri != null -> ctx.contentResolver.openInputStream(uri) ?: error("Cannot open the selected file")
            else -> error("No image source")
        }
        val counting = Counting(BufferedInputStream(raw, 1 shl 16))
        val lower = (url?.substringBefore('?') ?: nameHint).lowercase()
        val s: InputStream = when {
            lower.endsWith(".xz") -> XZInputStream(counting)
            lower.endsWith(".gz") -> GZIPInputStream(counting, 1 shl 16)
            lower.endsWith(".zip") -> ZipInputStream(counting).also { z ->
                var e = z.nextEntry
                while (e != null && e.isDirectory) e = z.nextEntry
                if (e == null) error("The zip file is empty")
            }
            lower.endsWith(".zst") -> throw UnsupportedOperationException("zstd images are not supported yet")
            else -> counting
        }
        return Opened(s, { counting.count }, total)
    }

    private fun connect(url: String): HttpURLConnection {
        require(url.startsWith("https://")) { "Only https downloads are allowed" }
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 20_000
        c.readTimeout = 30_000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "RpiImagerAndroid/2.0.12")
        if (c.responseCode != 200) { c.disconnect(); error("Download failed: HTTP ${c.responseCode}") }
        return c
    }
}
