// SPDX-License-Identifier: Apache-2.0
package org.rpiimager.android.ui

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import org.rpiimager.android.usb.UsbStorage

private val STEPS = listOf("OS", "Storage", "Customise", "Write")

@Composable
fun WizardApp(vm: WizardViewModel) {
    val step by vm.step.collectAsState()
    val stack by vm.osStack.collectAsState()
    BackHandler(enabled = !(step == Step.OS && stack.size <= 1)) { vm.back() }

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding().padding(16.dp)) {
        Text("Raspberry Pi Imager (Android)", style = MaterialTheme.typography.titleLarge)
        val idx = when (step) { Step.OS -> 0; Step.STORAGE -> 1; Step.CUSTOMISE -> 2; else -> 3 }
        Text(STEPS.mapIndexed { i, s -> if (i == idx) "[ $s ]" else s }.joinToString("  >  "),
            style = MaterialTheme.typography.labelMedium)
        Spacer(Modifier.height(12.dp))
        when (step) {
            Step.OS -> OsScreen(vm)
            Step.STORAGE -> StorageScreen(vm)
            Step.CUSTOMISE -> CustomiseScreen(vm)
            Step.CONFIRM -> ConfirmScreen(vm)
            Step.WRITE -> WriteScreen(vm)
        }
    }
}

private fun queryName(ctx: Context, uri: Uri): Pair<String, Long> {
    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        if (c.moveToFirst()) {
            val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            val si = c.getColumnIndex(OpenableColumns.SIZE)
            val name = if (ni >= 0) c.getString(ni) else "image"
            val size = if (si >= 0 && !c.isNull(si)) c.getLong(si) else -1L
            return name to size
        }
    }
    return "image" to -1L
}

@Composable
private fun ColumnScope.OsScreen(vm: WizardViewModel) {
    val ctx = LocalContext.current
    val stack by vm.osStack.collectAsState()
    val loading by vm.loading.collectAsState()
    val err by vm.loadError.collectAsState()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { val (n, s) = queryName(ctx, uri); vm.onCustomPicked(uri, n, s) }
    }
    val top = stack.lastOrNull()
    Text(if (stack.size > 1) top!!.first else "Choose operating system", style = MaterialTheme.typography.titleMedium)
    if (stack.size > 1) TextButton(onClick = { vm.back() }) { Text("< Back") }
    val notice by vm.notice.collectAsState()
    if (loading) CircularProgressIndicator()
    err?.let {
        Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
        Button(onClick = { vm.loadCatalogue() }) { Text("Retry") }
    }
    notice?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium) }
    if (top != null) LazyColumn {
        items(top.second) { os ->
            val folder = os.subitems.isNotEmpty() || os.subitemsUrl.isNotEmpty()
            Column(Modifier.fillMaxWidth().clickable {
                if (os.url == "internal://custom") picker.launch(arrayOf("*/*")) else vm.onOsClicked(os)
            }.padding(vertical = 10.dp)) {
                Text(os.name + if (folder) "  >" else "", style = MaterialTheme.typography.titleMedium)
                if (os.description.isNotEmpty()) Text(os.description, style = MaterialTheme.typography.bodySmall)
                if (os.releaseDate.isNotEmpty()) Text("Released ${os.releaseDate}", style = MaterialTheme.typography.labelSmall)
            }
            HorizontalDivider()
        }
    }
}

@Composable
private fun ColumnScope.StorageScreen(vm: WizardViewModel) {
    val ctx = LocalContext.current
    val devs by vm.devices.collectAsState()
    val chosen by vm.device.collectAsState()
    val msg by vm.usbMessage.collectAsState()
    val sel by vm.selected.collectAsState()
    LaunchedEffect(Unit) { vm.refreshDevices() }
    Text("Selected: ${sel?.name ?: ""}", style = MaterialTheme.typography.bodyMedium)
    Spacer(Modifier.height(8.dp))
    Text("Choose storage", style = MaterialTheme.typography.titleMedium)
    Text("Plug a USB SD-card reader (with a card in it) into the phone, then tap Refresh.",
        style = MaterialTheme.typography.bodySmall)
    if (devs.isEmpty()) Text("\nNo USB mass-storage device found.")
    LazyColumn(Modifier.weight(1f)) {
        items(devs) { d ->
            val on = chosen?.deviceName == d.deviceName
            Column(Modifier.fillMaxWidth().clickable { vm.pickDevice(d) }.padding(vertical = 10.dp)) {
                Text((if (on) "[x] " else "[ ] ") + UsbStorage.label(d), style = MaterialTheme.typography.titleMedium)
                Text(d.deviceName, style = MaterialTheme.typography.bodySmall)
            }
            HorizontalDivider()
        }
    }
    msg?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = { vm.back() }) { Text("Back") }
        OutlinedButton(onClick = { vm.refreshDevices() }) { Text("Refresh") }
        Button(onClick = { vm.next() }, enabled = chosen != null) { Text("Next") }
    }
}

@Composable
private fun ColumnScope.CustomiseScreen(vm: WizardViewModel) {
    val f by vm.form.collectAsState()
    val sel by vm.selected.collectAsState()
    val s = sel ?: return
    val fmt = vm.effectiveInitFormat(s)
    val unsupported = !s.custom && fmt == "systemd"
    Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
        Text("Customisation", style = MaterialTheme.typography.titleMedium)
        if (s.custom) {
            Text("This is a custom image. Which first-boot method does it support?", style = MaterialTheme.typography.bodySmall)
            listOf("none" to "None (don't customise)", "cloudinit-rpi" to "cloud-init (Raspberry Pi OS Trixie)",
                "cloudinit" to "cloud-init (generic)", "rpi-preseed" to "rpi-preseed").forEach { (k, label) ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = f.customInit == k, onClick = { vm.updateForm { it.copy(customInit = k) } })
                    Text(label)
                }
            }
        }
        if (unsupported) {
            Text("This image uses the older first-boot method (firstrun.sh), which is not supported yet. " +
                "The image will be written without settings. Choose a newer Trixie image to use customisation.",
                color = MaterialTheme.colorScheme.error)
        } else if (s.custom && fmt.isEmpty()) {
            Text("No customisation will be applied.")
        } else {
            SwitchRow("Apply these settings", f.enabled) { v -> vm.updateForm { it.copy(enabled = v) } }
            if (f.enabled) {
                Text("Trixie has no default user: set a username and password so you can log in.",
                    style = MaterialTheme.typography.bodySmall)
                Field("Hostname", f.hostname) { v -> vm.updateForm { it.copy(hostname = v) } }
                Field("Username", f.user) { v -> vm.updateForm { it.copy(user = v) } }
                Field("Password", f.password, secret = true) { v -> vm.updateForm { it.copy(password = v) } }
                SwitchRow("Enable SSH", f.ssh) { v -> vm.updateForm { it.copy(ssh = v) } }
                if (f.ssh) {
                    SwitchRow("Allow password login", f.sshPasswordAuth) { v -> vm.updateForm { it.copy(sshPasswordAuth = v) } }
                    Field("SSH public key (optional)", f.sshKey, single = false) { v -> vm.updateForm { it.copy(sshKey = v) } }
                }
                Field("Wi-Fi SSID", f.wifiSsid) { v -> vm.updateForm { it.copy(wifiSsid = v) } }
                Field("Wi-Fi password", f.wifiPassword, secret = true) { v -> vm.updateForm { it.copy(wifiPassword = v) } }
                Field("Wi-Fi country (2 letters)", f.country) { v -> vm.updateForm { it.copy(country = v.take(2).uppercase()) } }
                SwitchRow("Hidden network", f.wifiHidden) { v -> vm.updateForm { it.copy(wifiHidden = v) } }
                Field("Time zone", f.timezone) { v -> vm.updateForm { it.copy(timezone = v) } }
                Field("Keyboard layout", f.keyboard) { v -> vm.updateForm { it.copy(keyboard = v) } }
                SwitchRow("Enable I2C", f.i2c) { v -> vm.updateForm { it.copy(i2c = v) } }
                SwitchRow("Enable SPI", f.spi) { v -> vm.updateForm { it.copy(spi = v) } }
                SwitchRow("Enable 1-Wire", f.onewire) { v -> vm.updateForm { it.copy(onewire = v) } }
                f.problems().forEach { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        }
    }
    val blocked = f.enabled && !unsupported && !(s.custom && fmt.isEmpty()) && f.problems().isNotEmpty()
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = { vm.back() }) { Text("Back") }
        Button(onClick = { vm.next() }, enabled = !blocked) { Text("Next") }
    }
}

@Composable
private fun Field(label: String, value: String, secret: Boolean = false, single: Boolean = true, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) }, singleLine = single,
        visualTransformation = if (secret) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = if (secret) KeyboardType.Password else KeyboardType.Text),
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
    )
}

@Composable
private fun SwitchRow(label: String, value: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked = value, onCheckedChange = onChange)
    }
}

@Composable
private fun ColumnScope.ConfirmScreen(vm: WizardViewModel) {
    val sel by vm.selected.collectAsState()
    val dev by vm.device.collectAsState()
    val f by vm.form.collectAsState()
    var ask by remember { mutableStateOf(false) }
    val s = sel ?: return
    val d = dev ?: return
    val fmt = vm.effectiveInitFormat(s)
    val settings = !s.erase && f.enabled && fmt.isNotEmpty() && fmt != "systemd"
    Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
        Text("Ready to write", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        Text(if (s.erase) "Action: erase the card" else "Image: ${s.name}")
        Text("Storage: ${UsbStorage.label(d)}")
        if (!s.erase) Text(if (settings) "Settings: applied (hostname ${f.hostname}, user ${f.user.ifEmpty { "-" }})"
        else "Settings: none")
        if (!s.erase) Text("Steps: download + write, then read back and verify (SHA-256).")
        Spacer(Modifier.height(12.dp))
        Text("ALL DATA ON THE CARD WILL BE ERASED. Keep the phone awake and the reader connected until it finishes.",
            color = MaterialTheme.colorScheme.error)
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = { vm.back() }) { Text("Back") }
        Button(onClick = { ask = true }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) {
            Text(if (s.erase) "Erase" else "Write")
        }
    }
    if (ask) AlertDialog(
        onDismissRequest = { ask = false },
        title = { Text("Erase this card?") },
        text = { Text("Everything on ${UsbStorage.label(d)} will be permanently lost.") },
        confirmButton = { TextButton(onClick = { ask = false; vm.startWrite() }) { Text("Yes, erase and write") } },
        dismissButton = { TextButton(onClick = { ask = false }) { Text("Cancel") } },
    )
}

@Composable
private fun ColumnScope.WriteScreen(vm: WizardViewModel) {
    val st by vm.write.collectAsState()
    val view = LocalView.current
    DisposableEffect(st is WriteState.Running) {
        view.keepScreenOn = st is WriteState.Running
        onDispose { view.keepScreenOn = false }
    }
    val lg by vm.log.collectAsState()
    Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
        when (val s = st) {
            is WriteState.Running -> {
                Text(s.phase, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                if (s.total > 0) LinearProgressIndicator(progress = { (s.done.toFloat() / s.total).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth())
                else LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                Text("%d MB%s  -  %.1f MB/s".format(s.done / 1_000_000,
                    if (s.total > 0) " / ${s.total / 1_000_000} MB" else "", s.bytesPerSec / 1e6))
                Spacer(Modifier.height(12.dp))
                OutlinedButton(onClick = { vm.cancel() }) { Text("Cancel") }
            }
            is WriteState.Done -> {
                Text("Finished", style = MaterialTheme.typography.titleMedium)
                Text(s.message)
                Spacer(Modifier.height(12.dp))
                Button(onClick = { vm.restart() }) { Text("Start over") }
            }
            is WriteState.Failed -> {
                Text("Failed", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.error)
                Text(s.message)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { vm.back() }) { Text("Back") }
                    Button(onClick = { vm.restart() }) { Text("Start over") }
                }
            }
            WriteState.Idle -> {}
        }
        if (lg.isNotEmpty()) {
            Spacer(Modifier.height(16.dp))
            Text("Log (long-press to select and copy)", style = MaterialTheme.typography.labelMedium)
            SelectionContainer {
                Text(lg.joinToString("\n"), style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace)
            }
        }
    }
}
