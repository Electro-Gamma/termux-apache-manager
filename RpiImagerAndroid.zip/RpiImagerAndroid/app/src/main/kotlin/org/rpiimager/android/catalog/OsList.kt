// SPDX-License-Identifier: Apache-2.0
// Port of the catalogue handling in rpi-imager 2.0.12 (oslistparser.cpp, config.h).
package org.rpiimager.android.catalog

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

const val OSLIST_URL = "https://downloads.raspberrypi.com/os_list_imagingutility_v4.json"

val VALID_INIT_FORMATS = setOf("", "systemd", "cloudinit", "cloudinit-rpi", "rpi-preseed", "none")

data class DeviceDef(
    val name: String, val description: String, val tags: List<String>,
    val matchingType: String, val architecture: String, val capabilities: List<String>,
)

data class OsEntry(
    val name: String, val description: String, val icon: String, val url: String,
    val extractSize: Long, val extractSha256: String, val imageDownloadSize: Long,
    val releaseDate: String, val initFormat: String, val devices: List<String>,
    val capabilities: List<String>, val subitemsUrl: String, val subitems: List<OsEntry>,
)

object OsListParser {
    private fun JSONArray?.strings(): List<String> =
        if (this == null) emptyList() else (0 until length()).mapNotNull { optString(it, null) }

    /** Recursively prune entries whose init_format is not in the schema (as the original does). */
    fun filterInvalidInitFormats(list: JSONArray): JSONArray {
        val out = JSONArray()
        for (i in 0 until list.length()) {
            val e = list.optJSONObject(i) ?: continue
            if (e.optString("init_format", "") !in VALID_INIT_FORMATS) continue
            if (e.has("subitems")) {
                val sub = filterInvalidInitFormats(e.optJSONArray("subitems") ?: JSONArray())
                if (sub.length() == 0) continue
                e.put("subitems", sub)
            }
            out.put(e)
        }
        return out
    }

    /** "os_list_<locale>" beats "os_list_<lang>" beats "os_list". */
    fun listForLocale(root: JSONObject, locale: String): JSONArray {
        var list: JSONArray? = root.optJSONArray("os_list_$locale")
        if (list == null && locale.contains('_'))
            list = root.optJSONArray("os_list_" + locale.substringBefore('_'))
        if (list == null || list.length() == 0) list = root.optJSONArray("os_list")
        return list ?: JSONArray()
    }

    fun parseEntry(o: JSONObject): OsEntry = OsEntry(
        name = o.optString("name"), description = o.optString("description"),
        icon = o.optString("icon"), url = o.optString("url"),
        extractSize = o.optLong("extract_size"), extractSha256 = o.optString("extract_sha256"),
        imageDownloadSize = o.optLong("image_download_size"),
        releaseDate = o.optString("release_date"), initFormat = o.optString("init_format"),
        devices = o.optJSONArray("devices").strings(),
        capabilities = o.optJSONArray("capabilities").strings(),
        subitemsUrl = o.optString("subitems_url"),
        subitems = o.optJSONArray("subitems")?.let { a ->
            (0 until a.length()).mapNotNull { a.optJSONObject(it)?.let(::parseEntry) }
        } ?: emptyList(),
    )

    fun parse(json: String, locale: String = "en"): List<OsEntry> {
        val root = JSONObject(json)
        val list = filterInvalidInitFormats(listForLocale(root, locale))
        return (0 until list.length()).mapNotNull { list.optJSONObject(it)?.let(::parseEntry) }
    }

    fun parseDevices(json: String): List<DeviceDef> {
        val arr = JSONObject(json).optJSONObject("imager")?.optJSONArray("devices") ?: return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            arr.optJSONObject(i)?.let {
                DeviceDef(it.optString("name"), it.optString("description"), it.optJSONArray("tags").strings(),
                    it.optString("matching_type", "exclusive"), it.optString("architecture"),
                    it.optJSONArray("capabilities").strings())
            }
        }
    }
}

object CatalogueClient {
    /** Fetch the live catalogue; nothing is hardcoded beyond the official manifest URL. */
    fun fetch(url: String = OSLIST_URL, timeoutMs: Int = 20_000): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = timeoutMs; c.readTimeout = timeoutMs
        c.setRequestProperty("User-Agent", "RpiImagerAndroid/2.0.12")
        try {
            if (c.responseCode != 200) error("HTTP ${c.responseCode} fetching $url")
            return c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally { c.disconnect() }
    }
}
