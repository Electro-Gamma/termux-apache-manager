// SPDX-License-Identifier: Apache-2.0
// Applies a BootCustomisation to the boot partition (mirrors downloadthread.cpp _customizeImage).
package org.rpiimager.android.fat

import org.rpiimager.android.customise.BootCustomisation
import org.rpiimager.android.customise.CustomisationPlanner
import org.rpiimager.android.usb.BlockDevice

object BootCustomiser {
    fun apply(dev: BlockDevice, plan: BootCustomisation) {
        val fat = FatBoot.mount(dev)
        for ((name, data) in plan.files) fat.writeFile(name, data)
        if (plan.cmdlineAppend.isNotEmpty()) {
            val old = fat.readFile("cmdline.txt") ?: throw FatException("cmdline.txt not found on the boot partition")
            fat.writeFile("cmdline.txt", CustomisationPlanner.applyCmdline(old, plan.cmdlineAppend))
        }
        if (plan.configTxtItems.isNotEmpty()) {
            var cfg = (fat.readFile("config.txt") ?: ByteArray(0)).toString(Charsets.UTF_8)
            for (item in plan.configTxtItems) cfg = CustomisationPlanner.mergeConfigTxtItem(cfg, item)
            fat.writeFile("config.txt", cfg.toByteArray(Charsets.UTF_8))
        }
        dev.sync()
        // Read everything back through a fresh mount.
        val check = FatBoot.mount(dev)
        for ((name, data) in plan.files) {
            val got = check.readFile(name) ?: throw FatException("$name missing after write")
            if (!got.contentEquals(data)) throw FatException("$name differs after write")
        }
        if (plan.cmdlineAppend.isNotEmpty()) {
            val c = check.readFile("cmdline.txt")?.toString(Charsets.UTF_8) ?: ""
            if (!c.contains(plan.cmdlineAppend.trim().substringAfterLast(' '))) throw FatException("cmdline.txt not updated")
        }
    }
}
