// SPDX-License-Identifier: Apache-2.0
package org.rpiimager.android.usb

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import androidx.core.content.ContextCompat
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

object UsbStorage {
    private const val ACTION = "org.rpiimager.android.USB_PERMISSION"

    fun list(ctx: Context): List<UsbDevice> {
        val m = ctx.getSystemService(Context.USB_SERVICE) as UsbManager
        return m.deviceList.values.filter { UsbMassStorage.isMassStorage(it) }
    }

    fun label(d: UsbDevice): String {
        val n = listOfNotNull(
            runCatching { d.manufacturerName }.getOrNull(),
            runCatching { d.productName }.getOrNull(),
        ).joinToString(" ")
        return n.ifBlank { "USB storage %04x:%04x".format(d.vendorId, d.productId) }
    }

    suspend fun requestPermission(ctx: Context, d: UsbDevice): Boolean {
        val m = ctx.getSystemService(Context.USB_SERVICE) as UsbManager
        if (m.hasPermission(d)) return true
        return suspendCancellableCoroutine { cont ->
            val receiver = object : BroadcastReceiver() {
                override fun onReceive(c: Context, i: Intent) {
                    runCatching { ctx.unregisterReceiver(this) }
                    if (cont.isActive) cont.resume(i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false))
                }
            }
            ContextCompat.registerReceiver(ctx, receiver, IntentFilter(ACTION), ContextCompat.RECEIVER_NOT_EXPORTED)
            val flags = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
            val pi = PendingIntent.getBroadcast(ctx, 0, Intent(ACTION).setPackage(ctx.packageName), flags)
            m.requestPermission(d, pi)
            cont.invokeOnCancellation { runCatching { ctx.unregisterReceiver(receiver) } }
        }
    }
}
