// SPDX-License-Identifier: Apache-2.0
// Kotlin port of rpi-imager 2.0.12 src/customization_generator.cpp
// (cloud-init user-data / network-config and rpi-preseed.toml).
// Original: Copyright (C) 2020-2026 Raspberry Pi Ltd, Apache-2.0.
// NOT YET PORTED: generateSystemdScript (firstrun.sh) - see CustomisationPlanner.
package org.rpiimager.android.customise

import org.json.JSONObject
import org.rpiimager.android.customise.Escaping.shellQuote
import org.rpiimager.android.customise.Escaping.tomlQuote
import org.rpiimager.android.customise.Escaping.yamlEscapeString

typealias Settings = Map<String, Any?>

private fun Settings.str(k: String) = (this[k] as? String) ?: ""
private fun Settings.bool(k: String, def: Boolean = false) = (this[k] as? Boolean) ?: def

object CustomisationGenerator {
    const val PI_CONNECT_CONFIG_PATH = ".config/com.raspberrypi.connect"
    private const val PI_CONNECT_DEPLOY_KEY_FILENAME = "auth.key"
    private const val PI_CONNECT_STATE_FILENAME = "state.json"

    private val NEWLINE = Regex("\r?\n")

    fun ssidOctets(s: Settings, wifiConfigured: Boolean): ByteArray {
        if (!wifiConfigured) return ByteArray(0)
        (s["wifiSsidOctets"] as? ByteArray)?.let { return it }
        (s["wifiSsidOctetsBase64"] as? String)?.let { return java.util.Base64.getDecoder().decode(it) }
        return s.str("wifiSSID").toByteArray(Charsets.UTF_8)
    }

    fun resolveUserPasswordCrypt(s: Settings, backend: CryptBackend): String {
        val plain = s.str("sshUserPasswordPlain")
        if (plain.isNotEmpty())
            return PasswordCrypt.crypt(plain.toByteArray(Charsets.UTF_8), s.str("osReleaseDate"), backend)
        return s.str("sshUserPassword") // already crypted
    }

    fun resolveWifiPassphrase(s: Settings, wifiConfigured: Boolean): String =
        if (!wifiConfigured) "" else Escaping.stripLineTerminators(s.str("wifiPassword"))

    private fun piConnectCredentialFile(token: String): Pair<String, String> =
        if (token.startsWith("rpdev_")) {
            val o = JSONObject()
            o.put("accessToken", token); o.put("vncDisabled", false); o.put("shellDisabled", false)
            PI_CONNECT_STATE_FILENAME to o.toString()
        } else PI_CONNECT_DEPLOY_KEY_FILENAME to token

    private fun splitKeys(raw: String) = raw.split(NEWLINE).filter { it.isNotEmpty() }

    /** cloud-init user-data body (without the "#cloud-config" header, which the writer adds). */
    fun generateCloudInitUserData(
        s: Settings, piConnectToken: String, hasCcRpi: Boolean, sshEnabled: Boolean,
        currentUser: String, backend: CryptBackend,
    ): ByteArray {
        val cloud = StringBuilder()
        fun push(l: String) { if (l.isNotEmpty()) cloud.append(l).append('\n') }
        fun q(v: String) = "\"" + yamlEscapeString(v) + "\""

        val hostname = s.str("hostname").trim()
        if (hostname.isNotEmpty()) {
            push("hostname: " + q(hostname))
            push("manage_etc_hosts: true")
            push("packages:")
            push("- avahi-daemon")
            push("")
            push("apt:")
            push("  preserve_sources_list: true")
            push("  conf: |")
            push("    Acquire {")
            push("      Check-Date \"false\";")
            push("    };")
            push("")
        }

        val timezone = s.str("timezone").trim()
        if (timezone.isNotEmpty()) push("timezone: " + q(timezone))

        val keyboard = s.str("keyboard").trim()
        if (keyboard.isNotEmpty()) {
            push("keyboard:")
            push("  model: pc105")
            push("  layout: " + q(keyboard))
        }

        val sshPasswordAuth = s.bool("sshPasswordAuth")
        val userName = s.str("sshUserName").trim()
        val userPass = resolveUserPasswordCrypt(s, backend)
        val sshPublicKey = s.str("sshPublicKey").trim()
        val sshAuthorizedKeys = s.str("sshAuthorizedKeys").trim()
        val passwordlessSudo = s.bool("passwordlessSudo")

        val hasUserCredentials = userName.isNotEmpty() && userPass.isNotEmpty()
        val hasSshKeys = sshEnabled && (sshPublicKey.isNotEmpty() || sshAuthorizedKeys.isNotEmpty())
        val effectiveUser = if (userName.isEmpty()) (if (sshEnabled) currentUser else "pi") else userName
        val needsRuncmdForSudo = passwordlessSudo && (hasUserCredentials || hasSshKeys)

        if (hasUserCredentials || hasSshKeys) {
            // Singular `user:` so cloud-init extends the distro default user and keeps its groups (#1601).
            push("user:")
            push("  name: " + q(effectiveUser))
            push("  shell: /bin/bash")
            if (userPass.isNotEmpty()) {
                push("  lock_passwd: false")
                push("  passwd: " + q(userPass))
            } else if (hasSshKeys) {
                push("  lock_passwd: true")
            }
            if (hasSshKeys) {
                push("  ssh_authorized_keys:")
                val keys = if (sshAuthorizedKeys.isNotEmpty()) splitKeys(sshAuthorizedKeys) else splitKeys(sshPublicKey)
                for (k in keys) push("    - " + q(k.trim()))
            }
            // Explicit null suppresses the distro default NOPASSWD rule.
            push(if (passwordlessSudo) "  sudo: ALL=(ALL) NOPASSWD:ALL" else "  sudo: null")
            push("")
        }

        if (sshEnabled) {
            if (sshPasswordAuth) push("ssh_pwauth: true")
            else if (sshAuthorizedKeys.isNotEmpty() || sshPublicKey.isNotEmpty()) push("ssh_pwauth: false")
        }

        val enableI2C = s.bool("enableI2C")
        val enableSPI = s.bool("enableSPI")
        val enable1Wire = s.bool("enable1Wire")
        val enableSerial = s.str("enableSerial")
        val serialEnabled = enableSerial.isNotEmpty() && enableSerial != "Disabled"
        val armInterfaceEnabled = enableI2C || enableSPI || enable1Wire || serialEnabled
        val usbGadget = s.bool("enableUsbGadget")

        if (hasCcRpi && (usbGadget || armInterfaceEnabled)) {
            push("rpi:")
            if (usbGadget) push("  enable_usb_gadget: true")
            if (armInterfaceEnabled) {
                push("  interfaces:")
                if (enableI2C) push("    i2c: true")
                if (enableSPI) push("    spi: true")
                if (enable1Wire) push("    onewire: true")
                if (serialEnabled) {
                    if (enableSerial == "Default") push("    serial: true")
                    else {
                        push("    serial:")
                        when (enableSerial) {
                            "Console & Hardware" -> { push("      console: true"); push("      hardware: true") }
                            "Console" -> { push("      console: true"); push("      hardware: false") }
                            "Hardware" -> { push("      console: false"); push("      hardware: true") }
                        }
                    }
                }
            }
        }

        val piConnectEnabled = s.bool("piConnectEnabled")
        val cleanToken = piConnectToken.trim()
        val wifiConfigured = s.bool("wifiConfigured", true)
        val ssid = ssidOctets(s, wifiConfigured)
        val wifiCountry = s.str("recommendedWifiCountry").trim()

        val needsRuncmdForWifi = wifiCountry.isNotEmpty() && ssid.isEmpty()
        val needsRuncmdForPiConnect = piConnectEnabled && cleanToken.isNotEmpty()
        val needsRuncmd = needsRuncmdForPiConnect || needsRuncmdForWifi || needsRuncmdForSudo || sshEnabled

        if (needsRuncmd) {
            push("")
            push("runcmd:")
            // cc_ssh never starts sshd, and RPi OS ships it disabled.
            if (sshEnabled) push("  - [ systemctl, enable, --now, ssh ]")
            fun runcmd(c: String) = push("  - [ sh, -c, \"" + yamlEscapeString(c) + "\" ]")

            if (needsRuncmdForSudo) {
                val f = "/etc/sudoers.d/010_" + effectiveUser + "-nopasswd"
                runcmd("echo " + shellQuote("$effectiveUser ALL=(ALL) NOPASSWD:ALL") + " >" + shellQuote(f))
                runcmd("chmod 0440 " + shellQuote(f))
            }

            if (needsRuncmdForPiConnect) {
                val home = "/home/$effectiveUser"
                val configDir = "$home/$PI_CONNECT_CONFIG_PATH"
                val (fileName, content) = piConnectCredentialFile(cleanToken)
                val target = "$configDir/$fileName"
                val userQ = shellQuote(effectiveUser)
                val ownerQ = shellQuote("$effectiveUser:$effectiveUser")
                runcmd("install -o $userQ -m 700 -d " + shellQuote(configDir))
                runcmd("printf '%s\\n' " + shellQuote(content) + " > " + shellQuote(target) +
                    " && chown $ownerQ " + shellQuote(target) + " && chmod 600 " + shellQuote(target))
                runcmd("install -o $userQ -m 700 -d " +
                    shellQuote("$home/.config/systemd/user/default.target.wants") + " " +
                    shellQuote("$home/.config/systemd/user/rpi-connect.service.wants"))
                fun link(unit: String, dest: String) = runcmd(
                    "UNIT_SRC=/usr/lib/systemd/user/$unit; [ -f \$UNIT_SRC ] || UNIT_SRC=/lib/systemd/user/$unit; ln -sf \$UNIT_SRC " +
                        shellQuote("$home/.config/systemd/user/$dest/$unit"))
                link("rpi-connect.service", "default.target.wants")
                link("rpi-connect-signin.path", "rpi-connect.service.wants")
                link("rpi-connect-wayvnc.service", "rpi-connect.service.wants")
                runcmd("chown -R $ownerQ " + shellQuote("$home/.config/systemd"))
                runcmd("install -d -m 0755 /var/lib/systemd/linger")
                runcmd("install -m 0644 /dev/null " + shellQuote("/var/lib/systemd/linger/$effectiveUser"))
                runcmd("loginctl enable-linger $userQ 2>/dev/null || true")
                push("  - [ sleep, \"2\" ]")
                val machineQ = shellQuote("$effectiveUser@.host")
                runcmd("systemctl --quiet --user --machine=$machineQ daemon-reload || true")
                for (u in listOf("rpi-connect.service", "rpi-connect-signin.path", "rpi-connect-wayvnc.service"))
                    runcmd("systemctl --quiet --user --machine=$machineQ start $u || true")
            }

            if (needsRuncmdForWifi) {
                push("  - [ rfkill, unblock, wifi ]")
                runcmd("for f in /var/lib/systemd/rfkill/*:wlan; do echo 0 > \"\$f\"; done")
            }
        }

        var text = cloud.toString()
        if (text.isNotEmpty()) text = "manage_resolv_conf: false\n\n$text"
        return text.toByteArray(Charsets.UTF_8)
    }

    fun generateCloudInitNetworkConfig(s: Settings): ByteArray {
        val out = java.io.ByteArrayOutputStream()
        fun push(l: String) { if (l.isNotEmpty()) { out.write(l.toByteArray(Charsets.UTF_8)); out.write('\n'.code) } }
        val wifiConfigured = s.bool("wifiConfigured", true)
        val ssid = ssidOctets(s, wifiConfigured)
        val hidden = if (wifiConfigured) s.bool("wifiHidden") else false
        val regDom = s.str("recommendedWifiCountry").trim().uppercase()

        if (ssid.isNotEmpty()) {
            push("network:")
            push("  version: 2")
            push("  ethernets:")
            push("    eth0:")
            push("      dhcp4: true")
            push("      dhcp6: true")
            push("      optional: true")
            push("  wifis:")
            push("    wlan0:")
            push("      dhcp4: true")
            if (regDom.isNotEmpty()) push("      regulatory-domain: \"" + yamlEscapeString(regDom) + "\"")
            push("      access-points:")
            out.write("        \"".toByteArray()); out.write(Escaping.yamlEscapeSsidOctets(ssid)); out.write("\":\n".toByteArray())
            if (hidden) push("          hidden: true")
            val pass = resolveWifiPassphrase(s, wifiConfigured)
            if (pass.isEmpty()) {
                push("          auth:")
                push("            key-management: none")
            } else {
                push("          password: \"" + yamlEscapeString(pass) + "\"")
            }
            push("      optional: true")
        }
        return out.toByteArray()
    }

    fun generateRpiPreseedToml(
        s: Settings, piConnectToken: String, sshEnabled: Boolean, backend: CryptBackend,
    ): ByteArray {
        val body = StringBuilder()
        fun push(l: String) { body.append(l).append('\n') }

        val hostname = s.str("hostname").trim()
        if (hostname.isNotEmpty()) { push("[system]"); push("hostname = " + tomlQuote(hostname)); push("") }

        // The original reads the already-crypted "sshUserPassword" here; the Android UI hashes
        // the plaintext first via resolveUserPasswordCrypt so both paths work.
        val userName = s.str("sshUserName").trim()
        val userPass = resolveUserPasswordCrypt(s, backend)
        if (userName.isNotEmpty() || userPass.isNotEmpty()) {
            push("[user]")
            push("name = " + tomlQuote(if (userName.isEmpty()) "pi" else userName))
            if (userPass.isNotEmpty()) { push("password = " + tomlQuote(userPass)); push("password_encrypted = true") }
            push("groups = [\"sudo\"]")
            if (s.bool("passwordlessSudo")) push("passwordless_sudo = true")
            push("")
        }

        if (sshEnabled) {
            val pub = s.str("sshPublicKey").trim()
            val auth = s.str("sshAuthorizedKeys").trim()
            val raw = if (auth.isNotEmpty()) auth else pub
            val keys = if (raw.isNotEmpty()) splitKeys(raw).map { it.trim() }.filter { it.isNotEmpty() } else emptyList()
            push("[ssh]")
            push("enabled = true")
            push("password_authentication = " + if (s.bool("sshPasswordAuth")) "true" else "false")
            if (keys.isNotEmpty()) {
                push("authorized_keys = [")
                for (k in keys) push("  " + tomlQuote(k) + ",")
                push("]")
            }
            push("")
        }

        val wifiConfigured = s.bool("wifiConfigured", true)
        val ssid = ssidOctets(s, wifiConfigured)
        if (ssid.isNotEmpty()) {
            val utf8 = Escaping.isValidUtf8(ssid)
            val hidden = if (wifiConfigured) (s.bool("wifiHidden") || s.bool("wifiSSIDHidden")) else false
            val country = s.str("recommendedWifiCountry").trim()
            val open = s.str("wifiMode") == "open"
            val pass = if (open) "" else resolveWifiPassphrase(s, wifiConfigured)
            push("[wlan]")
            if (utf8) push("ssid = " + tomlQuote(ssid.toString(Charsets.UTF_8)))
            else push("ssid_hex = " + tomlQuote(ssid.joinToString("") { "%02x".format(it.toInt() and 0xFF) }))
            if (pass.isNotEmpty()) push("password = " + tomlQuote(pass))
            push("hidden = " + if (hidden) "true" else "false")
            if (country.isNotEmpty()) push("country = " + tomlQuote(country))
            push("")
        }

        val timezone = s.str("timezone").trim()
        val keymap = s.str("keyboard").trim()
        if (timezone.isNotEmpty() || keymap.isNotEmpty()) {
            push("[locale]")
            if (keymap.isNotEmpty()) push("keymap = " + tomlQuote(keymap))
            if (timezone.isNotEmpty()) push("timezone = " + tomlQuote(timezone))
            push("")
        }

        if (s.bool("piConnectEnabled")) {
            val token = piConnectToken.trim()
            push("[connect]")
            push("enabled = true")
            if (token.isNotEmpty()) { push("mode = " + tomlQuote("token")); push("token = " + tomlQuote(token)) }
            else push("mode = " + tomlQuote("device-identity"))
            push("")
        }

        val i2c = s.bool("enableI2C"); val spi = s.bool("enableSPI"); val ow = s.bool("enable1Wire")
        val gadget = s.bool("enableUsbGadget")
        val serial = when (s.str("enableSerial")) {
            "Default" -> "default"; "Console" -> "console"; "Hardware" -> "hardware"
            "Console & Hardware" -> "console_hardware"; else -> ""
        }
        if (i2c || spi || ow || gadget || serial.isNotEmpty()) {
            push("[interfaces]")
            if (i2c) push("i2c = true")
            if (spi) push("spi = true")
            if (ow) push("onewire = true")
            if (gadget) push("usb_gadget = true")
            if (serial.isNotEmpty()) push("serial = " + tomlQuote(serial))
            push("")
        }

        if (body.isEmpty()) return ByteArray(0)
        var out = "config_version = \"1.0\"\n\n$body"
        while (out.endsWith("\n\n")) out = out.dropLast(1)
        return out.toByteArray(Charsets.UTF_8)
    }
}
