// SPDX-License-Identifier: Apache-2.0
// Writes a decompressed image stream to a block device, hashes it, then reads it back to verify.
package org.rpiimager.android.io

import org.rpiimager.android.usb.BlockDevice
import java.io.InputStream
import java.security.MessageDigest
import java.util.concurrent.CancellationException
import kotlin.math.min

class WriteAbort(msg: String) : Exception(msg)

object ImageWriter {
    private const val CHUNK = 1 shl 20

    fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it.toInt() and 0xFF) }

    /** Returns (bytes written, SHA-256 of the bytes written). */
    fun write(dev: BlockDevice, input: InputStream, onProgress: (Long) -> Unit, cancelled: () -> Boolean): Pair<Long, ByteArray> {
        val md = MessageDigest.getInstance("SHA-256")
        val bs = dev.blockSize
        val cap = dev.blockCount * bs
        val buf = ByteArray(CHUNK)
        var lba = 0L
        var total = 0L
        while (true) {
            if (cancelled()) throw CancellationException("Cancelled")
            var n = 0
            while (n < CHUNK) {
                val r = input.read(buf, n, CHUNK - n)
                if (r < 0) break
                n += r
            }
            if (n == 0) break
            total += n
            if (total > cap) throw WriteAbort("The image is larger than the card (${cap / 1_000_000} MB)")
            md.update(buf, 0, n)
            val blocks = (n + bs - 1) / bs
            if (blocks * bs > n) java.util.Arrays.fill(buf, n, blocks * bs, 0.toByte())
            dev.write(lba, blocks, buf, 0)
            lba += blocks
            onProgress(total)
            if (n < CHUNK) break
        }
        dev.sync()
        return total to md.digest()
    }

    fun verify(dev: BlockDevice, bytes: Long, expected: ByteArray, onProgress: (Long) -> Unit, cancelled: () -> Boolean): Boolean {
        val md = MessageDigest.getInstance("SHA-256")
        val bs = dev.blockSize
        val buf = ByteArray(CHUNK)
        var remaining = bytes
        var lba = 0L
        var done = 0L
        while (remaining > 0) {
            if (cancelled()) throw CancellationException("Cancelled")
            val want = min(CHUNK.toLong(), remaining).toInt()
            val blocks = (want + bs - 1) / bs
            dev.read(lba, blocks, buf, 0)
            md.update(buf, 0, want)
            lba += blocks
            remaining -= want
            done += want
            onProgress(done)
        }
        return md.digest().contentEquals(expected)
    }

    /** Quick erase: zero the first 32 MiB (partition table + filesystem metadata). */
    fun erase(dev: BlockDevice, onProgress: (Long, Long) -> Unit, cancelled: () -> Boolean) {
        val bs = dev.blockSize
        val total = min(32L shl 20, dev.blockCount * bs)
        val zeros = ByteArray(CHUNK)
        var done = 0L
        var lba = 0L
        while (done < total) {
            if (cancelled()) throw CancellationException("Cancelled")
            val n = min(CHUNK.toLong(), total - done).toInt()
            val blocks = (n + bs - 1) / bs
            dev.write(lba, blocks, zeros, 0)
            lba += blocks
            done += blocks.toLong() * bs
            onProgress(done, total)
        }
        dev.sync()
    }
}
