// SPDX-License-Identifier: Apache-2.0
// Ports of the quoting/escaping helpers in customization_generator.cpp (rpi-imager 2.0.12).
package org.rpiimager.android.customise

import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.charset.CodingErrorAction

object Escaping {
    fun isValidUtf8(data: ByteArray): Boolean {
        if (data.isEmpty()) return true
        return try {
            Charsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(data))
            true
        } catch (e: Exception) { false }
    }

    private fun hex(v: Int, width: Int) = v.toString(16).padStart(width, '0')

    /** YAML double-quoted-scalar escaping; valid UTF-8 passes through as characters (#1743). */
    fun yamlEscapeSsidOctets(value: ByteArray): ByteArray {
        val utf8 = isValidUtf8(value)
        val out = ByteArrayOutputStream(value.size * 2)
        fun w(s: String) = out.write(s.toByteArray(Charsets.US_ASCII))
        var i = 0
        while (i < value.size) {
            val b = value[i].toInt() and 0xFF
            if (utf8 && b >= 0x80) {
                val len = if (b >= 0xF0) 4 else if (b >= 0xE0) 3 else 2
                var cp = b and (0x7F shr len)
                for (k in 1 until len) cp = (cp shl 6) or (value[i + k].toInt() and 0x3F)
                if (cp < 0xA0 || cp == 0x2028 || cp == 0x2029 || cp == 0xFEFF || cp == 0xFFFE || cp == 0xFFFF) {
                    if (cp < 0x100) w("\\x" + hex(cp, 2)) else w("\\u" + hex(cp, 4))
                } else {
                    out.write(value, i, len)
                }
                i += len
                continue
            }
            when (b) {
                '\\'.code -> w("\\\\")
                '"'.code -> w("\\\"")
                '\n'.code -> w("\\n")
                '\r'.code -> w("\\r")
                '\t'.code -> w("\\t")
                0x08 -> w("\\b")
                0x0C -> w("\\f")
                0 -> w("\\0")
                else -> if (b in 0x20 until 0x7F) out.write(b) else w("\\x" + hex(b, 2))
            }
            i++
        }
        return out.toByteArray()
    }

    fun yamlEscapeString(v: String): String =
        yamlEscapeSsidOctets(v.toByteArray(Charsets.UTF_8)).toString(Charsets.UTF_8)

    fun shellQuote(v: String): String = "'" + v.replace("'", "'\"'\"'") + "'"

    fun stripLineTerminators(s: String) = s.filter { it != '\r' && it != '\n' }

    /** TOML basic string for rpi-preseed: only \ and " escaped, newlines dropped. */
    fun tomlQuote(v: String): String =
        "\"" + v.replace("\\", "\\\\").replace("\"", "\\\"").replace("\r", "").replace("\n", "") + "\""

    /** Two ASCII letters or nothing: this lands on the kernel command line. */
    fun sanitisedCountryCode(v: String): String {
        val t = v.trim()
        return if (t.length == 2 && t.all { it in 'A'..'Z' || it in 'a'..'z' }) t else ""
    }
}
