// SPDX-License-Identifier: Apache-2.0
package org.rpiimager.android.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.rpiimager.android.catalog.CatalogueClient
import org.rpiimager.android.catalog.OsEntry
import org.rpiimager.android.catalog.OsListParser

/** Step-1 skeleton: live catalogue retrieval and OS list. Device/storage/write steps are not built yet. */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { OsScreen() } } }
    }
}

@Composable
private fun OsScreen() {
    var state by remember { mutableStateOf<Result<List<OsEntry>>?>(null) }
    LaunchedEffect(Unit) {
        state = withContext(Dispatchers.IO) {
            runCatching { OsListParser.parse(CatalogueClient.fetch()) }
        }
    }
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(16.dp)) {
        Text("Choose OS", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))
        val r = state
        when {
            r == null -> CircularProgressIndicator()
            r.isFailure -> Text("Could not load catalogue: ${r.exceptionOrNull()?.message}")
            else -> LazyColumn {
                items(r.getOrThrow()) { os ->
                    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                        Text(os.name, style = MaterialTheme.typography.titleMedium)
                        Text(os.description, style = MaterialTheme.typography.bodySmall)
                    }
                    HorizontalDivider()
                }
            }
        }
    }
}
