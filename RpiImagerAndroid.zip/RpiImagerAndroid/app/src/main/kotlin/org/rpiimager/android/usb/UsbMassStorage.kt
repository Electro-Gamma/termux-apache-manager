// SPDX-License-Identifier: Apache-2.0
// USB Mass Storage (Bulk-Only Transport + SCSI) driver on top of the Android USB Host API.
// Lets a NON-ROOTED phone read/write a card in a USB card reader. New code (the original uses
// raw /dev block devices, which Android does not allow apps to open).
package org.rpiimager.android.usb

import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import java.io.Closeable
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.min

interface BlockDevice {
    val blockSize: Int
    val blockCount: Long
    fun read(lba: Long, blocks: Int, out: ByteArray, off: Int = 0)
    fun write(lba: Long, blocks: Int, data: ByteArray, off: Int = 0)
    fun sync()
}

open class ScsiException(msg: String) : Exception(msg)

/** The device did not answer a USB transfer at all (timeout/error), as opposed to a SCSI error. */
class UsbIoException(msg: String) : ScsiException(msg)

class UsbMassStorage private constructor(
    private val conn: UsbDeviceConnection,
    private val iface: UsbInterface,
    private val inEp: UsbEndpoint,
    private val outEp: UsbEndpoint,
    private val log: (String) -> Unit,
    private val cancelled: () -> Boolean,
) : BlockDevice, Closeable {

    private var bs = 512
    private var bc = 0L
    override val blockSize: Int get() = bs
    override val blockCount: Long get() = bc

    private var lun = 0
    private var tag = 1
    private var timeoutMs = 4_000      // short while probing; raised to 30 s once the card is ready
    private val chunk = 16 * 1024
    private val maxBlocksPerCmd: Int get() = max(1, 131072 / bs)

    companion object {
        fun findInterface(d: UsbDevice): UsbInterface? =
            (0 until d.interfaceCount).map { d.getInterface(it) }.firstOrNull {
                it.interfaceClass == UsbConstants.USB_CLASS_MASS_STORAGE &&
                    it.interfaceSubclass == 6 && it.interfaceProtocol == 0x50
            }

        fun isMassStorage(d: UsbDevice) = findInterface(d) != null

        fun open(
            mgr: UsbManager, d: UsbDevice,
            log: (String) -> Unit = {}, cancelled: () -> Boolean = { false },
        ): UsbMassStorage {
            UsbStorage.describe(d).forEach(log)
            val i = findInterface(d) ?: throw ScsiException(
                "Not a Bulk-Only mass-storage device (UAS-only readers are not supported yet)")
            log("Using Bulk-Only interface ${i.id} (alt ${i.alternateSetting})")
            val c = mgr.openDevice(d) ?: throw ScsiException("Could not open the USB device (permission?)")
            log("Device opened")
            if (!c.claimInterface(i, true)) { c.close(); throw ScsiException("Could not claim the USB interface") }
            log("Interface claimed")
            if (i.alternateSetting != 0) c.setInterface(i)
            var inE: UsbEndpoint? = null
            var outE: UsbEndpoint? = null
            for (k in 0 until i.endpointCount) {
                val e = i.getEndpoint(k)
                if (e.type == UsbConstants.USB_ENDPOINT_XFER_BULK) {
                    if (e.direction == UsbConstants.USB_DIR_IN) inE = e else outE = e
                }
            }
            if (inE == null || outE == null) { c.close(); throw ScsiException("Bulk endpoints not found") }
            log("Bulk endpoints: in=0x%02x out=0x%02x".format(inE.address, outE.address))
            val dev = UsbMassStorage(c, i, inE, outE, log, cancelled)
            try { dev.init() } catch (e: Exception) { dev.close(); throw e }
            return dev
        }
    }

    override fun close() {
        runCatching { conn.releaseInterface(iface) }
        runCatching { conn.close() }
    }

    // ---- raw bulk helpers -------------------------------------------------------------

    private fun bulkOut(buf: ByteArray, off: Int, len: Int) {
        var done = 0
        while (done < len) {
            val r = conn.bulkTransfer(outEp, buf, off + done, min(chunk, len - done), timeoutMs)
            if (r < 0) throw UsbIoException("USB write failed or timed out (code $r)")
            if (r == 0) throw ScsiException("USB write made no progress")
            done += r
        }
    }

    private fun bulkIn(buf: ByteArray, off: Int, len: Int) {
        var done = 0
        while (done < len) {
            val r = conn.bulkTransfer(inEp, buf, off + done, min(chunk, len - done), timeoutMs)
            if (r < 0) throw UsbIoException("USB read failed or timed out (code $r)")
            if (r == 0) throw ScsiException("USB read made no progress")
            done += r
        }
    }

    private fun clearHalt(ep: UsbEndpoint) {
        conn.controlTransfer(0x02, 0x01, 0, ep.address, null, 0, 1000)
    }

    private fun resetRecovery() {
        conn.controlTransfer(0x21, 0xFF, 0, iface.id, null, 0, 1000)
        clearHalt(inEp)
        clearHalt(outEp)
    }

    // ---- one SCSI command over BOT ------------------------------------------------------

    private fun scsi(cdb: ByteArray, dataLen: Int, dirIn: Boolean, buf: ByteArray?, off: Int = 0, sense: Boolean = true) {
        val t = tag++
        val cbw = ByteBuffer.allocate(31).order(ByteOrder.LITTLE_ENDIAN)
        cbw.putInt(0x43425355)
        cbw.putInt(t)
        cbw.putInt(dataLen)
        cbw.put(if (dirIn) 0x80.toByte() else 0.toByte())
        cbw.put(lun.toByte())
        cbw.put(cdb.size.toByte())
        cbw.put(cdb)
        cbw.put(ByteArray(16 - cdb.size))
        try {
            bulkOut(cbw.array(), 0, 31)
            if (dataLen > 0 && buf != null) {
                if (dirIn) bulkIn(buf, off, dataLen) else bulkOut(buf, off, dataLen)
            }
        } catch (e: ScsiException) {
            runCatching { resetRecovery() }
            throw e
        }
        val csw = ByteArray(13)
        var r = conn.bulkTransfer(inEp, csw, 13, timeoutMs)
        if (r < 0) { clearHalt(inEp); r = conn.bulkTransfer(inEp, csw, 13, timeoutMs) }
        if (r != 13) { runCatching { resetRecovery() }; throw UsbIoException("No status from device ($r)") }
        val bb = ByteBuffer.wrap(csw).order(ByteOrder.LITTLE_ENDIAN)
        if (bb.getInt(0) != 0x53425355 || bb.getInt(4) != t) {
            runCatching { resetRecovery() }
            throw ScsiException("Corrupt status from device")
        }
        when (csw[12].toInt()) {
            0 -> return
            1 -> throw ScsiException("SCSI command failed" + if (sense) ": " + senseText() else "")
            else -> { runCatching { resetRecovery() }; throw ScsiException("USB phase error") }
        }
    }

    private fun senseText(): String = try {
        val b = ByteArray(18)
        scsi(byteArrayOf(0x03, 0, 0, 0, 18, 0), 18, true, b, 0, sense = false)
        "sense key=${b[2].toInt() and 0x0F} asc=${b[12].toInt() and 0xFF} ascq=${b[13].toInt() and 0xFF}"
    } catch (e: Exception) { "sense unavailable" }

    // ---- initialisation -----------------------------------------------------------------

    private fun checkCancel() {
        if (cancelled()) throw java.util.concurrent.CancellationException("Cancelled")
    }

    private fun init() {
        log("Resetting device (mass-storage reset)")
        runCatching { resetRecovery() }
        log("Reading max LUN")
        val m = ByteArray(1)
        val r = conn.controlTransfer(0xA1, 0xFE, 0, iface.id, m, 1, 2000)
        val maxLun = if (r == 1) min(m[0].toInt() and 0xFF, 15) else 0
        log("Max LUN = $maxLun (control result $r)")
        var last: Exception? = null
        for (l in 0..maxLun) {
            checkCancel()
            lun = l
            try {
                log("LUN $l: INQUIRY")
                inquiry()
                waitReady()
                log("LUN $l: reading capacity")
                readCapacity()
                if (bc > 0) {
                    log("LUN $l: ${bc} blocks x $bs bytes = ${bc * bs / 1_000_000} MB")
                    timeoutMs = 30_000
                    return
                }
            } catch (e: java.util.concurrent.CancellationException) { throw e
            } catch (e: Exception) {
                log("LUN $l failed: ${e.message}")
                last = e
                if (e is UsbIoException) break      // device is not answering at all
            }
        }
        if (last is UsbIoException) throw ScsiException(
            "The card reader did not respond to commands (${last.message}). Unplug and re-plug it, " +
                "try another card or OTG cable/adapter, then try again.")
        throw ScsiException("No readable card found - is a card inserted in the reader? " + (last?.message ?: ""))
    }

    private fun inquiry() {
        val b = ByteArray(36)
        scsi(byteArrayOf(0x12, 0, 0, 0, 36, 0), 36, true, b, 0, sense = false)
        val vendor = String(b, 8, 8, Charsets.ISO_8859_1).trim()
        val product = String(b, 16, 16, Charsets.ISO_8859_1).trim()
        log("Device says: $vendor $product (type ${b[0].toInt() and 0x1F})")
    }

    private fun waitReady() {
        var lastMsg = ""
        for (attempt in 1..10) {
            checkCancel()
            try { scsi(byteArrayOf(0, 0, 0, 0, 0, 0), 0, true, null); return }
            catch (e: UsbIoException) { throw e }
            catch (e: ScsiException) {
                lastMsg = e.message ?: ""
                log("Not ready (attempt $attempt): $lastMsg")
                Thread.sleep(500)
            }
        }
        throw ScsiException("Card not ready: $lastMsg")
    }

    private fun readCapacity() {
        val b = ByteArray(8)
        scsi(ByteArray(10).also { it[0] = 0x25 }, 8, true, b)
        val bb = ByteBuffer.wrap(b)
        val last = bb.getInt(0).toLong() and 0xFFFFFFFFL
        var len = bb.getInt(4)
        var lastLba = last
        if (last == 0xFFFFFFFFL) {
            val c = ByteBuffer.allocate(16)
            c.put(0x9E.toByte()); c.put(0x10); c.putLong(0); c.putInt(32); c.put(0); c.put(0)
            val r = ByteArray(32)
            scsi(c.array(), 32, true, r)
            val rb = ByteBuffer.wrap(r)
            lastLba = rb.getLong(0)
            len = rb.getInt(8)
        }
        if (len !in intArrayOf(512, 1024, 2048, 4096)) throw ScsiException("Unsupported block size $len")
        bs = len
        bc = lastLba + 1
    }

    // ---- BlockDevice ---------------------------------------------------------------------

    private fun rwCdb(write: Boolean, lba: Long, n: Int): ByteArray {
        return if (lba + n <= 0xFFFFFFFFL) {
            val b = ByteBuffer.allocate(10)
            b.put((if (write) 0x2A else 0x28).toByte()); b.put(0); b.putInt(lba.toInt()); b.put(0)
            b.putShort(n.toShort()); b.put(0)
            b.array()
        } else {
            val b = ByteBuffer.allocate(16)
            b.put((if (write) 0x8A else 0x88).toByte()); b.put(0); b.putLong(lba); b.putInt(n); b.put(0); b.put(0)
            b.array()
        }
    }

    private fun rw(write: Boolean, lba: Long, blocks: Int, buf: ByteArray, off: Int) {
        var done = 0
        while (done < blocks) {
            val n = min(blocks - done, maxBlocksPerCmd)
            val cdb = rwCdb(write, lba + done, n)
            val o = off + done * bs
            try {
                scsi(cdb, n * bs, !write, buf, o)
            } catch (e: ScsiException) {
                Thread.sleep(300)      // one retry for transient errors
                scsi(cdb, n * bs, !write, buf, o)
            }
            done += n
        }
    }

    override fun read(lba: Long, blocks: Int, out: ByteArray, off: Int) = rw(false, lba, blocks, out, off)
    override fun write(lba: Long, blocks: Int, data: ByteArray, off: Int) = rw(true, lba, blocks, data, off)

    override fun sync() {
        runCatching { scsi(ByteArray(10).also { it[0] = 0x35 }, 0, true, null, 0, sense = false) }
    }
}
