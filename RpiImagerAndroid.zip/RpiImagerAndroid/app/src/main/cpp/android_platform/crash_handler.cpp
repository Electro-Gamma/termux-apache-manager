/* SPDX-License-Identifier: Apache-2.0 */
#include "crash_handler.h"

#include <dlfcn.h>
#include <signal.h>
#include <unistd.h>
#include <unwind.h>

#include <cstdint>
#include <cstdio>
#include <initializer_list>
#include <cstring>

namespace rpi_android {
namespace {

struct Ctx { int n; };

_Unwind_Reason_Code step(struct _Unwind_Context* uc, void* arg) {
  Ctx* c = static_cast<Ctx*>(arg);
  uintptr_t pc = _Unwind_GetIP(uc);
  if (!pc) return _URC_END_OF_STACK;
  if (c->n >= 24) return _URC_END_OF_STACK;
  Dl_info info;
  char line[512];
  if (dladdr(reinterpret_cast<void*>(pc), &info) && info.dli_fname) {
    uintptr_t base = reinterpret_cast<uintptr_t>(info.dli_fbase);
    std::snprintf(line, sizeof line, "  #%02d %s+0x%lx  %s\n", c->n, info.dli_fname,
                  static_cast<unsigned long>(pc - base), info.dli_sname ? info.dli_sname : "");
  } else {
    std::snprintf(line, sizeof line, "  #%02d 0x%lx\n", c->n, static_cast<unsigned long>(pc));
  }
  (void)!::write(2, line, std::strlen(line));
  ++c->n;
  return _URC_NO_REASON;
}

void handler(int sig, siginfo_t* si, void*) {
  char head[160];
  std::snprintf(head, sizeof head, "\nFatal signal %d (%s), fault address %p\n", sig, strsignal(sig),
                si ? si->si_addr : nullptr);
  (void)!::write(2, head, std::strlen(head));
  Ctx c{0};
  _Unwind_Backtrace(step, &c);
  signal(sig, SIG_DFL);
  raise(sig);
}

}  // namespace

void installCrashHandler() {
  static char altstack[64 * 1024];
  stack_t ss{};
  ss.ss_sp = altstack;
  ss.ss_size = sizeof altstack;
  sigaltstack(&ss, nullptr);
  struct sigaction sa;
  std::memset(&sa, 0, sizeof sa);
  sa.sa_sigaction = handler;
  sa.sa_flags = SA_SIGINFO | SA_ONSTACK | SA_RESETHAND;
  sigemptyset(&sa.sa_mask);
  for (int s : {SIGSEGV, SIGBUS, SIGABRT, SIGFPE, SIGILL}) sigaction(s, &sa, nullptr);
}

}  // namespace rpi_android
