/*
 * SPDX-License-Identifier: Apache-2.0
 * BulkTransport over libusb for Android.  Android never lets an app enumerate
 * /dev/bus/usb itself, so libusb is initialised with device discovery off and
 * given the file descriptor from UsbDeviceConnection.getFileDescriptor()
 * (libusb_wrap_sys_device).
 */
#include "libusb_transport_android.h"

#include <libusb.h>

#include <mutex>

namespace rpi_android {
namespace {

libusb_context* g_ctx = nullptr;
std::mutex g_ctxMutex;

libusb_context* context(std::string& err) {
  std::lock_guard<std::mutex> l(g_ctxMutex);
  if (g_ctx) return g_ctx;
  libusb_set_option(nullptr, LIBUSB_OPTION_NO_DEVICE_DISCOVERY);
  int rc = libusb_init(&g_ctx);
  if (rc != 0) {
    err = std::string("libusb_init failed: ") + libusb_strerror(static_cast<libusb_error>(rc));
    g_ctx = nullptr;
  }
  return g_ctx;
}

XferResult map(int rc) {
  switch (rc) {
    case LIBUSB_SUCCESS: return XferResult::kOk;
    case LIBUSB_ERROR_PIPE: return XferResult::kStall;
    case LIBUSB_ERROR_TIMEOUT: return XferResult::kTimeout;
    case LIBUSB_ERROR_NO_DEVICE: return XferResult::kNoDevice;
    default: return XferResult::kError;
  }
}

class LibusbTransport : public BulkTransport {
 public:
  LibusbTransport(libusb_device_handle* h, const UsbEndpointConfig& cfg) : h_(h), cfg_(cfg) {}
  ~LibusbTransport() override {
    // The interface is owned by the Java UsbDeviceConnection; the fd is not
    // closed by libusb_close() for wrapped devices.
    if (h_) libusb_close(h_);
  }
  XferResult bulkOut(const std::uint8_t* data, std::size_t len, std::size_t* transferred,
                     unsigned timeoutMs) override {
    int n = 0;
    int rc = libusb_bulk_transfer(h_, static_cast<unsigned char>(cfg_.epOut),
                                  const_cast<unsigned char*>(data), static_cast<int>(len), &n, timeoutMs);
    *transferred = n > 0 ? static_cast<std::size_t>(n) : 0;
    return map(rc);
  }
  XferResult bulkIn(std::uint8_t* data, std::size_t len, std::size_t* transferred,
                    unsigned timeoutMs) override {
    int n = 0;
    int rc = libusb_bulk_transfer(h_, static_cast<unsigned char>(cfg_.epIn), data,
                                  static_cast<int>(len), &n, timeoutMs);
    *transferred = n > 0 ? static_cast<std::size_t>(n) : 0;
    return map(rc);
  }
  bool clearHaltIn() override { return libusb_clear_halt(h_, static_cast<unsigned char>(cfg_.epIn)) == 0; }
  bool clearHaltOut() override { return libusb_clear_halt(h_, static_cast<unsigned char>(cfg_.epOut)) == 0; }
  bool bulkOnlyReset() override {
    return libusb_control_transfer(h_, 0x21, 0xFF, 0, static_cast<uint16_t>(cfg_.interfaceNumber),
                                   nullptr, 0, 5000) >= 0;
  }

 private:
  libusb_device_handle* h_;
  UsbEndpointConfig cfg_;
};

std::unique_ptr<BulkTransport> create(const std::string&, const UsbEndpointConfig& cfg,
                                      std::string& err) {
  libusb_context* ctx = context(err);
  if (!ctx) return nullptr;
  libusb_device_handle* h = nullptr;
  int rc = libusb_wrap_sys_device(ctx, static_cast<intptr_t>(cfg.fd), &h);
  if (rc != 0 || !h) {
    err = std::string("libusb_wrap_sys_device failed: ") + libusb_strerror(static_cast<libusb_error>(rc));
    return nullptr;
  }
  // The Kotlin side has already claimed this interface on the SAME open file (claimInterface(force=true),
  // which also detaches Android's usb-storage driver).  A plain claim on a file that already owns the
  // interface returns success in the kernel.
  //
  // Do NOT enable libusb's auto-detach here: it uses USBDEVFS_DISCONNECT_CLAIM with "except driver usbfs",
  // and the kernel answers EBUSY when the interface is already bound to usbfs -- i.e. exactly after
  // the Java claim.  (That was the cause of "libusb_claim_interface failed: Resource busy".)
  rc = libusb_claim_interface(h, cfg.interfaceNumber);
  if (rc == LIBUSB_ERROR_BUSY) {
    // Not claimed by the app yet and a kernel driver is bound: detach it, then claim.
    libusb_detach_kernel_driver(h, cfg.interfaceNumber);
    rc = libusb_claim_interface(h, cfg.interfaceNumber);
  }
  if (rc != 0) {
    err = std::string("libusb_claim_interface failed: ") + libusb_strerror(static_cast<libusb_error>(rc)) +
          " (interface " + std::to_string(cfg.interfaceNumber) + ")";
    libusb_close(h);
    return nullptr;
  }
  return std::unique_ptr<BulkTransport>(new LibusbTransport(h, cfg));
}

}  // namespace

void installLibusbTransportFactory() { UsbRegistry::instance().setTransportFactory(create); }

}  // namespace rpi_android
