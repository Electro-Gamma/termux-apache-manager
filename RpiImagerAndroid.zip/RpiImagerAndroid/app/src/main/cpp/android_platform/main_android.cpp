/*
 * SPDX-License-Identifier: Apache-2.0
 * Native entry point.  Qt for Android starts this from QtActivity (the Kotlin
 * MainActivity extends it).  There is no QML/Widgets UI: the UI is Kotlin and
 * talks to the Engine through JNI (jni_bridge.cpp).
 */
#include <QGuiApplication>

#include "engine.h"
#include "imagewriter.h"

int main(int argc, char* argv[]) {
  QGuiApplication app(argc, argv);
  app.setOrganizationName("Raspberry Pi");
  app.setOrganizationDomain("raspberrypi.com");
  app.setApplicationName("Raspberry Pi Imager");
  app.setApplicationVersion(ImageWriter::staticVersion());

  rpi_android::Engine engine;
  rpi_android::Engine::emitEvent(QStringLiteral("engineReady"));
  return app.exec();
}
