/*
 * SPDX-License-Identifier: Apache-2.0
 * FileOperations for Android: raw USB mass-storage devices (via BotDevice) and
 * ordinary files (POSIX).  Synchronous only; async I/O is reported unsupported
 * so the original write pipeline uses its synchronous path.
 */
#ifndef RPI_ANDROID_FILE_OPERATIONS_H_
#define RPI_ANDROID_FILE_OPERATIONS_H_

#include <memory>
#include <string>

#include "file_operations.h"
#include "usb_bot.h"

namespace rpi_imager {

class AndroidFileOperations : public FileOperations {
 public:
  AndroidFileOperations();
  ~AndroidFileOperations() override;

  FileError OpenDevice(const std::string& path) override;
  FileError CreateTestFile(const std::string& path, std::uint64_t size) override;
  FileError WriteAtOffset(std::uint64_t offset, const std::uint8_t* data, std::size_t size) override;
  FileError GetSize(std::uint64_t& size) override;
  FileError Close() override;
  bool IsOpen() const override;

  FileError WriteSequential(const std::uint8_t* data, std::size_t size) override;
  FileError ReadSequential(std::uint8_t* data, std::size_t size, std::size_t& bytes_read) override;

  bool SetAsyncQueueDepth(int depth) override;
  int GetAsyncQueueDepth() const override { return 1; }
  bool IsAsyncIOSupported() const override { return false; }
  FileError AsyncWriteSequential(const std::uint8_t* data, std::size_t size,
                                 AsyncWriteCallback callback = nullptr) override;
  int GetPendingWriteCount() const override { return 0; }
  void PollAsyncCompletions() override {}
  FileError WaitForPendingWrites() override { return FileError::kSuccess; }
  void CancelAsyncIO() override {}
  FileError AttemptSyncFallback() override;
  std::vector<PendingWriteInfo> GetPendingWritesSorted() const override { return {}; }
  void ReduceQueueDepthForRecovery(int) override {}
  bool DrainAndSwitchToSync(int stallTimeoutSeconds) override;

  FileError Seek(std::uint64_t position) override;
  std::uint64_t Tell() const override { return cursor_; }
  FileError ForceSync() override;
  FileError Flush() override;
  void PrepareForSequentialRead(std::uint64_t offset, std::uint64_t length) override;
  int GetHandle() const override { return fd_; }
  int GetLastErrorCode() const override { return last_error_code_; }
  WriteErrorClass ClassifyLastWriteError() const override;
  bool IsDirectIOEnabled() const override { return false; }
  FileError SetDirectIOEnabled(bool) override { return FileError::kSuccess; }
  DirectIOInfo GetDirectIOInfo() const override { return DirectIOInfo(); }

 private:
  bool usb() const { return bot_ != nullptr; }
  FileError OpenPosix(const char* path, int flags, unsigned mode);
  FileError UsbWrite(std::uint64_t offset, const std::uint8_t* data, std::size_t size);

  std::unique_ptr<rpi_android::BotDevice> bot_;
  int fd_ = -1;
  std::uint64_t cursor_ = 0;
  int last_error_code_ = 0;
  WriteErrorClass last_write_class_ = WriteErrorClass::kUnknown;
};

}  // namespace rpi_imager

#endif
