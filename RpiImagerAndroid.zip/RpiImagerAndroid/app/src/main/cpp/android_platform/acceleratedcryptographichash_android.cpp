/* SPDX-License-Identifier: Apache-2.0
 * SHA-256 backend for Android: Qt's own QCryptographicHash (the Linux build
 * uses GnuTLS, which is not available here). */
#include "acceleratedcryptographichash.h"

struct AcceleratedCryptographicHash::impl {
  explicit impl(QCryptographicHash::Algorithm m) : h(m) {}
  QCryptographicHash h;
};

AcceleratedCryptographicHash::AcceleratedCryptographicHash(QCryptographicHash::Algorithm method)
    : p_Impl(std::make_unique<impl>(method)), _algo(method) {}
AcceleratedCryptographicHash::~AcceleratedCryptographicHash() = default;

void AcceleratedCryptographicHash::addData(const char* data, int length) {
  p_Impl->h.addData(QByteArrayView(data, length));
}
void AcceleratedCryptographicHash::addData(const QByteArray& data) { p_Impl->h.addData(data); }

QByteArray AcceleratedCryptographicHash::result() const {
  if (!_resultCached) {
    _cachedResult = p_Impl->h.resultView().toByteArray();  // finalises; cached like the original
    _resultCached = true;
  }
  return _cachedResult;
}

void AcceleratedCryptographicHash::reset() {
  p_Impl = std::make_unique<impl>(_algo);
  _cachedResult.clear();
  _resultCached = false;
}
