/*
 * SPDX-License-Identifier: Apache-2.0
 * Android implementation of userfiles.h.  The app is never elevated and runs
 * as a single sandboxed user, so the privilege-dropping helpers are no-ops.
 */
#include "userfiles.h"

#include <QDebug>
#include <QFile>
#include <QStandardPaths>

#include <fcntl.h>
#include <unistd.h>

namespace PlatformQuirks {

InvokingUserFsScope::InvokingUserFsScope() {}
InvokingUserFsScope::~InvokingUserFsScope() {}

bool invokingUser(int*, int*) { return false; }
void runAsInvokingUser(QString&, QStringList&) {}

bool openFreshFile(QFile& file) {
  QFile::remove(file.fileName());
  return file.open(QIODevice::WriteOnly | QIODevice::Truncate);
}

FILE* openLogFile(const char* path) { return ::fopen(path, "a"); }

int reclaimOwnership(const QString&, int, int, bool) { return 0; }

QString trustedCacheLocation() { return QStandardPaths::writableLocation(QStandardPaths::CacheLocation); }

}  // namespace PlatformQuirks
