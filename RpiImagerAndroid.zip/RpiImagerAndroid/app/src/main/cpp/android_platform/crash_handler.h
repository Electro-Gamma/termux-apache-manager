/* SPDX-License-Identifier: Apache-2.0 */
#ifndef RPI_ANDROID_CRASH_HANDLER_H_
#define RPI_ANDROID_CRASH_HANDLER_H_
namespace rpi_android {
// Installs SIGSEGV/SIGBUS/SIGABRT/SIGFPE/SIGILL handlers that print the signal and a symbolised
// backtrace to stderr (the app shows it) and then terminate with the usual 128+signal exit code.
void installCrashHandler();
}  // namespace rpi_android
#endif
