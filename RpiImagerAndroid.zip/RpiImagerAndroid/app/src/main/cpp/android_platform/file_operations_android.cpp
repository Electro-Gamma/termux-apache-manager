/* SPDX-License-Identifier: Apache-2.0 */
#include "file_operations_android.h"

#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#include <cerrno>
#include <cstring>

#include "posix_write_error.h"
#include "usb_registry.h"

namespace rpi_imager {

AndroidFileOperations::AndroidFileOperations() = default;
AndroidFileOperations::~AndroidFileOperations() { Close(); }

FileError AndroidFileOperations::OpenPosix(const char* path, int flags, unsigned mode) {
  Close();
  fd_ = ::open(path, flags | O_CLOEXEC, mode);
  if (fd_ < 0) {
    last_error_code_ = errno;
    return FileError::kOpenError;
  }
  last_error_code_ = 0;
  cursor_ = 0;
  return FileError::kSuccess;
}

FileError AndroidFileOperations::OpenDevice(const std::string& path) {
  Close();
  auto& reg = rpi_android::UsbRegistry::instance();
  if (reg.contains(path)) {
    std::string err;
    auto transport = reg.openTransport(path, err);
    if (!transport) {
      FileOperationsLog("USB open failed: " + err);
      last_error_code_ = ENODEV;
      return FileError::kOpenError;
    }
    auto bot = std::make_unique<rpi_android::BotDevice>(std::move(transport));
    if (!bot->init()) {
      FileOperationsLog("USB mass storage init failed: " + bot->error());
      last_error_code_ = EIO;
      return FileError::kOpenError;
    }
    FileOperationsLog("USB device " + path + ": " + bot->vendor() + " " + bot->product() +
                      ", " + std::to_string(bot->sizeBytes()) + " bytes, block " +
                      std::to_string(bot->blockSize()));
    bot_ = std::move(bot);
    device_io_limits_.max_transfer_bytes = rpi_android::BotDevice::kMaxTransferBytes;
    cursor_ = 0;
    last_error_code_ = 0;
    return FileError::kSuccess;
  }
  return OpenPosix(path.c_str(), O_RDWR, 0);
}

FileError AndroidFileOperations::CreateTestFile(const std::string& path, std::uint64_t size) {
  FileError r = OpenPosix(path.c_str(), O_CREAT | O_RDWR | O_TRUNC, S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
  if (r != FileError::kSuccess) return r;
  if (ftruncate(fd_, static_cast<off_t>(size)) != 0) {
    last_error_code_ = errno;
    Close();
    return FileError::kSizeError;
  }
  return FileError::kSuccess;
}

FileError AndroidFileOperations::UsbWrite(std::uint64_t offset, const std::uint8_t* data,
                                          std::size_t size) {
  if (bot_->write(offset, data, size)) {
    last_error_code_ = 0;
    return FileError::kSuccess;
  }
  const std::string& e = bot_->error();
  FileOperationsLog("USB write failed: " + e);
  if (e.find("beyond end") != std::string::npos) {
    last_error_code_ = ENOSPC;
    last_write_class_ = WriteErrorClass::kDiskFull;
  } else if (e.find("write protected") != std::string::npos) {
    last_error_code_ = EROFS;
    last_write_class_ = WriteErrorClass::kWriteProtected;
  } else if (bot_->lastSense().valid && bot_->lastSense().key == 0x03) {
    last_error_code_ = EIO;
    last_write_class_ = WriteErrorClass::kMediaError;
  } else {
    last_error_code_ = EIO;
    last_write_class_ = WriteErrorClass::kIoDeviceError;
  }
  return FileError::kWriteError;
}

FileError AndroidFileOperations::WriteAtOffset(std::uint64_t offset, const std::uint8_t* data,
                                               std::size_t size) {
  if (!IsOpen()) return FileError::kOpenError;
  if (usb()) return UsbWrite(offset, data, size);
  std::size_t done = 0;
  while (done < size) {
    ssize_t r = ::pwrite(fd_, data + done, size - done, static_cast<off_t>(offset + done));
    if (r < 0 && errno == EINTR) continue;
    if (r <= 0) {
      last_error_code_ = errno;
      return FileError::kWriteError;
    }
    done += static_cast<std::size_t>(r);
  }
  return FileError::kSuccess;
}

FileError AndroidFileOperations::GetSize(std::uint64_t& size) {
  if (!IsOpen()) return FileError::kOpenError;
  if (usb()) {
    size = bot_->sizeBytes();
    return FileError::kSuccess;
  }
  struct stat st;
  if (fstat(fd_, &st) != 0) {
    last_error_code_ = errno;
    return FileError::kSizeError;
  }
  if (S_ISREG(st.st_mode)) {
    size = static_cast<std::uint64_t>(st.st_size);
    return FileError::kSuccess;
  }
  off_t end = lseek(fd_, 0, SEEK_END);
  if (end < 0) {
    last_error_code_ = errno;
    return FileError::kSizeError;
  }
  lseek(fd_, static_cast<off_t>(cursor_), SEEK_SET);
  size = static_cast<std::uint64_t>(end);
  return FileError::kSuccess;
}

FileError AndroidFileOperations::Close() {
  FileError result = FileError::kSuccess;
  if (bot_) {
    if (!bot_->syncCache()) result = FileError::kCloseError;
    bot_.reset();
  }
  if (fd_ >= 0) {
    if (::close(fd_) != 0) result = FileError::kCloseError;
    fd_ = -1;
  }
  cursor_ = 0;
  return result;
}

bool AndroidFileOperations::IsOpen() const { return bot_ != nullptr || fd_ >= 0; }

FileError AndroidFileOperations::WriteSequential(const std::uint8_t* data, std::size_t size) {
  FileError r = WriteAtOffset(cursor_, data, size);
  if (r == FileError::kSuccess) cursor_ += size;
  return r;
}

FileError AndroidFileOperations::ReadSequential(std::uint8_t* data, std::size_t size,
                                                std::size_t& bytes_read) {
  bytes_read = 0;
  if (!IsOpen()) return FileError::kOpenError;
  if (usb()) {
    const std::uint64_t total = bot_->sizeBytes();
    if (cursor_ >= total) return FileError::kSuccess;  // EOF
    const std::size_t n = static_cast<std::size_t>(std::min<std::uint64_t>(size, total - cursor_));
    if (!bot_->read(cursor_, data, n)) {
      FileOperationsLog("USB read failed: " + bot_->error());
      last_error_code_ = EIO;
      return FileError::kReadError;
    }
    cursor_ += n;
    bytes_read = n;
    return FileError::kSuccess;
  }
  ssize_t r;
  do {
    r = ::pread(fd_, data, size, static_cast<off_t>(cursor_));
  } while (r < 0 && errno == EINTR);
  if (r < 0) {
    last_error_code_ = errno;
    return FileError::kReadError;
  }
  cursor_ += static_cast<std::uint64_t>(r);
  bytes_read = static_cast<std::size_t>(r);
  return FileError::kSuccess;
}

bool AndroidFileOperations::SetAsyncQueueDepth(int) { return false; }

FileError AndroidFileOperations::AsyncWriteSequential(const std::uint8_t* data, std::size_t size,
                                                      AsyncWriteCallback callback) {
  FileError r = WriteSequential(data, size);
  if (callback) callback(r, r == FileError::kSuccess ? size : 0);
  return r;
}

FileError AndroidFileOperations::AttemptSyncFallback() {
  sync_fallback_mode_ = true;
  return FileError::kSuccess;
}

bool AndroidFileOperations::DrainAndSwitchToSync(int) {
  sync_fallback_mode_ = true;
  return true;
}

FileError AndroidFileOperations::Seek(std::uint64_t position) {
  if (!IsOpen()) return FileError::kOpenError;
  cursor_ = position;
  return FileError::kSuccess;
}

FileError AndroidFileOperations::ForceSync() {
  if (!IsOpen()) return FileError::kOpenError;
  if (usb()) return bot_->syncCache() ? FileError::kSuccess : FileError::kSyncError;
  if (::fsync(fd_) != 0) {
    last_error_code_ = errno;
    return FileError::kSyncError;
  }
  return FileError::kSuccess;
}

FileError AndroidFileOperations::Flush() {
  if (!IsOpen()) return FileError::kOpenError;
  if (usb()) return bot_->syncCache() ? FileError::kSuccess : FileError::kFlushError;
  if (::fdatasync(fd_) != 0) {
    last_error_code_ = errno;
    return FileError::kFlushError;
  }
  return FileError::kSuccess;
}

void AndroidFileOperations::PrepareForSequentialRead(std::uint64_t offset, std::uint64_t length) {
  if (fd_ >= 0) {
    ::posix_fadvise(fd_, static_cast<off_t>(offset), static_cast<off_t>(length), POSIX_FADV_SEQUENTIAL);
  }
}

WriteErrorClass AndroidFileOperations::ClassifyLastWriteError() const {
  if (usb()) return last_write_class_;
  return ClassifyPosixWriteErrno(last_error_code_);
}

FileOperations::DeviceIOLimits QueryPlatformDeviceIOLimits(const std::string& path) {
  FileOperations::DeviceIOLimits limits;
  if (rpi_android::UsbRegistry::instance().contains(path)) {
    limits.max_transfer_bytes = rpi_android::BotDevice::kMaxTransferBytes;
  }
  return limits;
}

std::unique_ptr<FileOperations> CreatePlatformFileOperations() {
  return std::make_unique<AndroidFileOperations>();
}

}  // namespace rpi_imager
