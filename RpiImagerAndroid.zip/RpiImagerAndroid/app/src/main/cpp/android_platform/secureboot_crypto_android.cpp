/* SPDX-License-Identifier: Apache-2.0
 * RSA operations for secure boot signing.  The Linux implementation shells out
 * to the `openssl` binary, which does not exist on Android.  These report
 * failure; secure-boot provisioning is a documented Android limitation. */
#include "secureboot_crypto.h"

#include <QDebug>

namespace SecureBootCrypto {

QByteArray rsaSignSha256(const QByteArray&, const QString&) {
  qWarning() << "SecureBootCrypto: RSA signing is not available on Android";
  return {};
}
QByteArray extractRsaPubkeyBin(const QString&) {
  qWarning() << "SecureBootCrypto: RSA key extraction is not available on Android";
  return {};
}
bool generateRsaKeyPair(const QString&, const QString&) {
  qWarning() << "SecureBootCrypto: RSA key generation is not available on Android";
  return false;
}

}  // namespace SecureBootCrypto
