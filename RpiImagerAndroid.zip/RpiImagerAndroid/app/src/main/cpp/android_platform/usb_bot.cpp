/*
 * SPDX-License-Identifier: Apache-2.0
 * See usb_bot.h.  Implements USB Mass Storage Bulk-Only Transport (BBB) with
 * the SCSI command subset needed to read and write a disk:
 *   INQUIRY, TEST UNIT READY, REQUEST SENSE, READ CAPACITY(10/16),
 *   READ/WRITE(10/16), SYNCHRONIZE CACHE(10), MODE SENSE(6).
 */
#include "usb_bot.h"

#include <algorithm>
#include <chrono>
#include <cstdio>
#include <cstring>
#include <thread>

namespace rpi_android {
namespace {

constexpr std::uint32_t kCbwSignature = 0x43425355;  // "USBC"
constexpr std::uint32_t kCswSignature = 0x53425355;  // "USBS"
constexpr std::size_t kCbwSize = 31;
constexpr std::size_t kCswSize = 13;
constexpr unsigned kCbwTimeoutMs = 5000;
constexpr unsigned kCswTimeoutMs = 30000;

void put16be(std::uint8_t* p, std::uint16_t v) {
  p[0] = static_cast<std::uint8_t>(v >> 8);
  p[1] = static_cast<std::uint8_t>(v);
}
void put32be(std::uint8_t* p, std::uint32_t v) {
  p[0] = static_cast<std::uint8_t>(v >> 24);
  p[1] = static_cast<std::uint8_t>(v >> 16);
  p[2] = static_cast<std::uint8_t>(v >> 8);
  p[3] = static_cast<std::uint8_t>(v);
}
void put64be(std::uint8_t* p, std::uint64_t v) {
  put32be(p, static_cast<std::uint32_t>(v >> 32));
  put32be(p + 4, static_cast<std::uint32_t>(v));
}
std::uint32_t get32be(const std::uint8_t* p) {
  return (std::uint32_t(p[0]) << 24) | (std::uint32_t(p[1]) << 16) |
         (std::uint32_t(p[2]) << 8) | std::uint32_t(p[3]);
}
std::uint64_t get64be(const std::uint8_t* p) {
  return (std::uint64_t(get32be(p)) << 32) | get32be(p + 4);
}
void put32le(std::uint8_t* p, std::uint32_t v) {
  p[0] = static_cast<std::uint8_t>(v);
  p[1] = static_cast<std::uint8_t>(v >> 8);
  p[2] = static_cast<std::uint8_t>(v >> 16);
  p[3] = static_cast<std::uint8_t>(v >> 24);
}
std::uint32_t get32le(const std::uint8_t* p) {
  return std::uint32_t(p[0]) | (std::uint32_t(p[1]) << 8) |
         (std::uint32_t(p[2]) << 16) | (std::uint32_t(p[3]) << 24);
}

std::string trimField(const std::uint8_t* p, std::size_t n) {
  std::string s(reinterpret_cast<const char*>(p), n);
  for (auto& c : s) {
    if (c < 0x20 || c > 0x7E) c = ' ';
  }
  const auto b = s.find_first_not_of(' ');
  if (b == std::string::npos) return {};
  const auto e = s.find_last_not_of(' ');
  return s.substr(b, e - b + 1);
}

}  // namespace

BotDevice::BotDevice(std::unique_ptr<BulkTransport> transport) : t_(std::move(transport)) {}

bool BotDevice::fail(const std::string& msg) {
  error_ = msg;
  return false;
}

void BotDevice::resetRecovery() {
  // Bulk-Only Transport spec 5.3.4: reset, then clear both halts.
  ++recoveries_;
  t_->bulkOnlyReset();
  t_->clearHaltIn();
  t_->clearHaltOut();
}

BotDevice::CmdOutcome BotDevice::execute(const std::uint8_t* cdb, std::uint8_t cdbLen,
                                         Dir dir, std::uint8_t* buf, std::size_t len,
                                         unsigned dataTimeoutMs) {
  CmdOutcome out;
  if (cdbLen < 1 || cdbLen > 16) {
    fail("internal error: bad CDB length");
    return out;
  }

  std::uint8_t cbw[kCbwSize];
  std::memset(cbw, 0, sizeof(cbw));
  const std::uint32_t tag = ++tag_;
  put32le(cbw + 0, kCbwSignature);
  put32le(cbw + 4, tag);
  put32le(cbw + 8, static_cast<std::uint32_t>(len));
  cbw[12] = (dir == Dir::kIn) ? 0x80 : 0x00;
  cbw[13] = 0;  // LUN 0: card readers expose the card on LUN 0
  cbw[14] = cdbLen;
  std::memcpy(cbw + 15, cdb, cdbLen);

  std::size_t n = 0;
  XferResult r = t_->bulkOut(cbw, kCbwSize, &n, kCbwTimeoutMs);
  if (r == XferResult::kStall) {
    t_->clearHaltOut();
    r = t_->bulkOut(cbw, kCbwSize, &n, kCbwTimeoutMs);
  }
  if (r != XferResult::kOk || n != kCbwSize) {
    resetRecovery();
    fail(r == XferResult::kNoDevice ? "USB device was disconnected"
                                    : "failed to send SCSI command block");
    return out;
  }

  if (len > 0 && dir != Dir::kNone) {
    n = 0;
    if (dir == Dir::kIn) {
      r = t_->bulkIn(buf, len, &n, dataTimeoutMs);
    } else {
      r = t_->bulkOut(buf, len, &n, dataTimeoutMs);
    }
    if (r == XferResult::kStall) {
      // Spec 6.7.2/6.7.3: clear the halt, then read the CSW.
      if (dir == Dir::kIn) t_->clearHaltIn(); else t_->clearHaltOut();
      out.transferred = n;
    } else if (r != XferResult::kOk) {
      resetRecovery();
      fail(r == XferResult::kNoDevice ? "USB device was disconnected"
           : r == XferResult::kTimeout ? "USB data transfer timed out"
                                       : "USB data transfer failed");
      return out;
    } else {
      out.transferred = n;
    }
  }

  std::uint8_t csw[kCswSize];
  n = 0;
  r = t_->bulkIn(csw, kCswSize, &n, kCswTimeoutMs);
  if (r == XferResult::kStall) {
    t_->clearHaltIn();
    n = 0;
    r = t_->bulkIn(csw, kCswSize, &n, kCswTimeoutMs);
  }
  if (r != XferResult::kOk || n != kCswSize) {
    resetRecovery();
    fail(r == XferResult::kNoDevice ? "USB device was disconnected"
                                    : "failed to read SCSI command status");
    return out;
  }
  if (get32le(csw) != kCswSignature || get32le(csw + 4) != tag) {
    resetRecovery();
    fail("invalid SCSI command status wrapper");
    return out;
  }

  out.residue = get32le(csw + 8);
  switch (csw[12]) {
    case 0: out.csw = CswStatus::kPassed; break;
    case 1: out.csw = CswStatus::kFailed; break;
    case 2:
      out.csw = CswStatus::kPhaseError;
      resetRecovery();
      fail("USB mass storage phase error");
      return out;
    default:
      out.csw = CswStatus::kBad;
      resetRecovery();
      fail("USB mass storage returned an unknown status");
      return out;
  }
  out.transportOk = true;
  return out;
}

bool BotDevice::requestSense(SenseInfo* out) {
  std::uint8_t cdb[6] = {0x03, 0, 0, 0, 18, 0};
  std::uint8_t d[18];
  std::memset(d, 0, sizeof(d));
  const CmdOutcome o = execute(cdb, 6, Dir::kIn, d, sizeof(d), 5000);
  SenseInfo s;
  if (o.transportOk && o.csw == CswStatus::kPassed && o.transferred >= 14) {
    const std::uint8_t code = d[0] & 0x7F;
    if (code == 0x70 || code == 0x71) {
      s.valid = true;
      s.key = d[2] & 0x0F;
      s.asc = d[12];
      s.ascq = d[13];
    }
  }
  if (out) *out = s;
  return s.valid;
}

bool BotDevice::command(const std::uint8_t* cdb, std::uint8_t cdbLen, Dir dir,
                        std::uint8_t* buf, std::size_t len, std::size_t* actual,
                        unsigned dataTimeoutMs) {
  const CmdOutcome o = execute(cdb, cdbLen, dir, buf, len, dataTimeoutMs);
  if (!o.transportOk) return false;  // error_ already set
  if (o.csw == CswStatus::kPassed) {
    if (actual) *actual = o.transferred;
    return true;
  }
  SenseInfo s;
  requestSense(&s);
  lastSense_ = s;
  char msg[128];
  if (s.valid) {
    std::snprintf(msg, sizeof(msg), "SCSI command 0x%02X failed (sense %02X/%02X/%02X)",
                  cdb[0], s.key, s.asc, s.ascq);
  } else {
    std::snprintf(msg, sizeof(msg), "SCSI command 0x%02X failed", cdb[0]);
  }
  return fail(msg);
}

bool BotDevice::readCapacity() {
  std::uint8_t cdb[16];
  std::memset(cdb, 0, sizeof(cdb));
  cdb[0] = 0x25;  // READ CAPACITY(10)
  std::uint8_t d[8];
  std::size_t got = 0;
  if (!command(cdb, 10, Dir::kIn, d, sizeof(d), &got) || got < 8) {
    return error_.empty() ? fail("READ CAPACITY failed") : false;
  }
  const std::uint32_t last = get32be(d);
  std::uint32_t bs = get32be(d + 4);
  if (last == 0xFFFFFFFFu) {
    // Capacity does not fit in 32 bits of LBA: ask READ CAPACITY(16).
    std::memset(cdb, 0, sizeof(cdb));
    cdb[0] = 0x9E;
    cdb[1] = 0x10;
    put32be(cdb + 10, 32);
    std::uint8_t d16[32];
    std::memset(d16, 0, sizeof(d16));
    got = 0;
    if (!command(cdb, 16, Dir::kIn, d16, sizeof(d16), &got) || got < 12) {
      return error_.empty() ? fail("READ CAPACITY(16) failed") : false;
    }
    blockCount_ = get64be(d16) + 1;
    bs = get32be(d16 + 8);
    use16_ = true;
  } else {
    blockCount_ = static_cast<std::uint64_t>(last) + 1;
    use16_ = false;
  }
  if (bs < 512 || bs > 65536 || (bs & (bs - 1)) != 0) {
    return fail("unsupported block size " + std::to_string(bs));
  }
  blockSize_ = bs;
  if (blockCount_ == 0) return fail("medium reports zero capacity");
  return true;
}

bool BotDevice::init() {
  error_.clear();
  std::uint8_t cdb[16];
  std::memset(cdb, 0, sizeof(cdb));

  // INQUIRY is mandatory to answer even when the unit is not ready.
  cdb[0] = 0x12;
  cdb[4] = 36;
  std::uint8_t inq[36];
  std::memset(inq, 0, sizeof(inq));
  std::size_t got = 0;
  if (!command(cdb, 6, Dir::kIn, inq, sizeof(inq), &got, 10000)) return false;
  if (got >= 32) {
    vendor_ = trimField(inq + 8, 8);
    product_ = trimField(inq + 16, 16);
  }
  const std::uint8_t devType = inq[0] & 0x1F;
  if (devType != 0x00 && devType != 0x0E) {  // direct access / simplified direct access
    return fail("USB device is not a disk (SCSI peripheral type " + std::to_string(devType) + ")");
  }

  // Wait until the unit (card) is ready.
  bool ready = false;
  for (int attempt = 0; attempt < 50 && !ready; ++attempt) {
    std::uint8_t tur[6] = {0, 0, 0, 0, 0, 0};
    const CmdOutcome o = execute(tur, 6, Dir::kNone, nullptr, 0, 5000);
    if (!o.transportOk) return false;
    if (o.csw == CswStatus::kPassed) {
      ready = true;
      break;
    }
    SenseInfo s;
    requestSense(&s);
    lastSense_ = s;
    if (s.valid && s.key == 0x02 && s.asc == 0x3A) return fail("No card inserted in the reader");
    if (s.valid && (s.key == 0x02 || s.key == 0x06)) {  // NOT READY / UNIT ATTENTION: retry
      if (retryDelayMs_) std::this_thread::sleep_for(std::chrono::milliseconds(retryDelayMs_));
      continue;
    }
    char msg[96];
    std::snprintf(msg, sizeof(msg), "storage device is not ready (sense %02X/%02X/%02X)",
                  s.key, s.asc, s.ascq);
    return fail(msg);
  }
  if (!ready) return fail("timed out waiting for the storage device to become ready");

  if (!readCapacity()) return false;

  // Best effort: write-protect bit from MODE SENSE(6), all pages.
  std::memset(cdb, 0, sizeof(cdb));
  cdb[0] = 0x1A;
  cdb[2] = 0x3F;
  cdb[4] = 4;
  std::uint8_t ms[4] = {0, 0, 0, 0};
  got = 0;
  const std::string savedError = error_;
  if (command(cdb, 6, Dir::kIn, ms, sizeof(ms), &got, 5000) && got >= 3) {
    writeProtected_ = (ms[2] & 0x80) != 0;
  }
  error_ = savedError;
  return true;
}

bool BotDevice::rwBlocks(bool isWrite, std::uint64_t lba, std::uint32_t count,
                         std::uint8_t* buf) {
  if (blockSize_ == 0) return fail("device not initialised");
  if (count == 0) return true;
  if (lba + count < lba || lba + count > blockCount_) return fail("access beyond end of device");
  if (isWrite && writeProtected_) return fail("the card is write protected");

  const std::size_t maxBlocks = std::max<std::size_t>(1, kMaxTransferBytes / blockSize_);
  while (count > 0) {
    const std::uint32_t n = static_cast<std::uint32_t>(std::min<std::uint64_t>(count, maxBlocks));
    std::uint8_t cdb[16];
    std::memset(cdb, 0, sizeof(cdb));
    std::uint8_t cdbLen;
    if (use16_ || lba > 0xFFFFFFFFull) {
      cdb[0] = isWrite ? 0x8A : 0x88;
      put64be(cdb + 2, lba);
      put32be(cdb + 10, n);
      cdbLen = 16;
    } else {
      cdb[0] = isWrite ? 0x2A : 0x28;
      put32be(cdb + 2, static_cast<std::uint32_t>(lba));
      put16be(cdb + 7, static_cast<std::uint16_t>(n));
      cdbLen = 10;
    }
    const std::size_t bytes = static_cast<std::size_t>(n) * blockSize_;
    bool ok = false;
    for (int attempt = 0; attempt < 2 && !ok; ++attempt) {
      std::size_t actual = 0;
      lastSense_ = SenseInfo();
      ok = command(cdb, cdbLen, isWrite ? Dir::kOut : Dir::kIn, buf, bytes, &actual);
      if (ok && actual != bytes) return fail("short USB transfer");
      // One retry after a UNIT ATTENTION (e.g. the reader just reset).
      if (!ok && !(lastSense_.valid && lastSense_.key == 0x06)) break;
    }
    if (!ok) return false;
    lba += n;
    count -= n;
    buf += bytes;
  }
  return true;
}

bool BotDevice::readBlocks(std::uint64_t lba, std::uint32_t count, std::uint8_t* buf) {
  return rwBlocks(false, lba, count, buf);
}

bool BotDevice::writeBlocks(std::uint64_t lba, std::uint32_t count, const std::uint8_t* buf) {
  return rwBlocks(true, lba, count, const_cast<std::uint8_t*>(buf));
}

bool BotDevice::syncCache() {
  std::uint8_t cdb[16];
  std::memset(cdb, 0, sizeof(cdb));
  cdb[0] = 0x35;  // SYNCHRONIZE CACHE(10): LBA 0, length 0 = whole medium
  lastSense_ = SenseInfo();
  if (command(cdb, 10, Dir::kNone, nullptr, 0)) return true;
  // Many cheap readers do not implement it (ILLEGAL REQUEST): not an error.
  if (lastSense_.valid && lastSense_.key == 0x05) {
    error_.clear();
    return true;
  }
  return false;
}

bool BotDevice::read(std::uint64_t offset, std::uint8_t* buf, std::size_t len) {
  if (len == 0) return true;
  if (blockSize_ == 0) return fail("device not initialised");
  if (offset + len < offset || offset + len > sizeBytes()) return fail("read beyond end of device");
  const std::size_t bs = blockSize_;
  std::vector<std::uint8_t> tmp;

  std::uint64_t lba = offset / bs;
  const std::size_t head = static_cast<std::size_t>(offset % bs);
  if (head) {
    tmp.resize(bs);
    if (!readBlocks(lba, 1, tmp.data())) return false;
    const std::size_t n = std::min(len, bs - head);
    std::memcpy(buf, tmp.data() + head, n);
    buf += n;
    len -= n;
    ++lba;
  }
  const std::size_t whole = len / bs;
  if (whole) {
    if (!readBlocks(lba, static_cast<std::uint32_t>(whole), buf)) return false;
    buf += whole * bs;
    len -= whole * bs;
    lba += whole;
  }
  if (len) {
    tmp.resize(bs);
    if (!readBlocks(lba, 1, tmp.data())) return false;
    std::memcpy(buf, tmp.data(), len);
  }
  return true;
}

bool BotDevice::write(std::uint64_t offset, const std::uint8_t* buf, std::size_t len) {
  if (len == 0) return true;
  if (blockSize_ == 0) return fail("device not initialised");
  if (offset + len < offset || offset + len > sizeBytes()) return fail("write beyond end of device");
  const std::size_t bs = blockSize_;
  std::vector<std::uint8_t> tmp;

  std::uint64_t lba = offset / bs;
  const std::size_t head = static_cast<std::size_t>(offset % bs);
  if (head) {
    tmp.resize(bs);
    if (!readBlocks(lba, 1, tmp.data())) return false;
    const std::size_t n = std::min(len, bs - head);
    std::memcpy(tmp.data() + head, buf, n);
    if (!writeBlocks(lba, 1, tmp.data())) return false;
    buf += n;
    len -= n;
    ++lba;
  }
  const std::size_t whole = len / bs;
  if (whole) {
    if (!writeBlocks(lba, static_cast<std::uint32_t>(whole), buf)) return false;
    buf += whole * bs;
    len -= whole * bs;
    lba += whole;
  }
  if (len) {
    tmp.resize(bs);
    if (!readBlocks(lba, 1, tmp.data())) return false;
    std::memcpy(tmp.data(), buf, len);
    if (!writeBlocks(lba, 1, tmp.data())) return false;
  }
  return true;
}

}  // namespace rpi_android
