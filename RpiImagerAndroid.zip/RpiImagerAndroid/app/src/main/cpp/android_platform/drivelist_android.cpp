/*
 * SPDX-License-Identifier: Apache-2.0
 * Drivelist for Android: the only writable targets are the USB mass-storage
 * devices the Kotlin layer has registered (permission granted, probed).
 */
#include "drivelist/drivelist.h"
#include "usb_registry.h"

namespace Drivelist {

std::vector<DeviceDescriptor> ListStorageDevices() {
  std::vector<DeviceDescriptor> out;
  for (const auto& d : rpi_android::UsbRegistry::instance().list()) {
    DeviceDescriptor dd;
    dd.device = d.path;
    dd.raw = d.path;
    dd.description = sanitizeForDisplay((d.vendor + " " + d.product));
    dd.size = d.size;
    dd.blockSize = d.blockSize;
    dd.logicalBlockSize = d.blockSize;
    dd.busType = "USB";
    dd.isReadOnly = d.writeProtected;
    dd.isSystem = false;
    dd.isVirtual = false;
    dd.isRemovable = true;
    dd.isUSB = true;
    dd.isSCSI = true;
    out.push_back(dd);
  }
  return out;
}

}  // namespace Drivelist
