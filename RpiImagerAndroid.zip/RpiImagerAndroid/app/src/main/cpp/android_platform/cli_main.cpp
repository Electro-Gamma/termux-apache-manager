/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * Entry point of the Android build of the ORIGINAL Raspberry Pi Imager CLI (cli.cpp).
 * It is a plain native executable (packaged as libraries/librpiimagercli.so and started by the
 * Kotlin app); there is no Qt GUI, no QML and no Qt Java glue.  This wrapper only does what the
 * Linux CLI gets from the OS and cannot get on Android:
 *
 *   --android-fd-socket NAME   Receive USB device / image file descriptors from the app over an
 *                              abstract AF_UNIX socket (SCM_RIGHTS).  Child processes do not
 *                              inherit descriptors on Android, so this is how the opened
 *                              UsbDeviceConnection reaches us.
 *   --android-probe            Probe the received USB device and print JSON, then exit.
 *   --android-customisation F  JSON settings written by the app; turned into firstrun.sh /
 *                              cloud-init files with the original CustomisationGenerator and
 *                              passed on as --first-run-script / --cloudinit-* to the CLI.
 *   --android-init-format X    systemd | cloudinit | cloudinit-rpi   (selects the generator)
 *   --android-os-release-date  used by the generator to choose the password hash
 *
 * Everything else is forwarded unchanged to the original Cli::run().
 */
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>

#include <QByteArray>
#include <QDir>
#include <QFile>
#include <QJsonDocument>
#include <QJsonObject>
#include <QVariantMap>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>

#include "android_config.h"
#include "cli.h"
#include "curlnetworkconfig.h"
#include "customization_generator.h"
#include "libusb_transport_android.h"
#include "platformquirks.h"
#include "usb_bot.h"
#include "usb_registry.h"

namespace {

struct Received {
  std::string text;
  int fd = -1;
};

int connectAbstract(const std::string& name) {
  int s = ::socket(AF_UNIX, SOCK_STREAM, 0);
  if (s < 0) return -1;
  sockaddr_un a{};
  a.sun_family = AF_UNIX;
  if (name.size() + 1 >= sizeof(a.sun_path)) return -1;
  std::memcpy(a.sun_path + 1, name.data(), name.size());
  socklen_t len = static_cast<socklen_t>(offsetof(sockaddr_un, sun_path) + 1 + name.size());
  if (::connect(s, reinterpret_cast<sockaddr*>(&a), len) != 0) { ::close(s); return -1; }
  return s;
}

bool recvOne(int s, Received* out) {
  char buf[1024];
  alignas(cmsghdr) char ctl[CMSG_SPACE(sizeof(int))];
  iovec iov{buf, sizeof(buf) - 1};
  msghdr m{};
  m.msg_iov = &iov; m.msg_iovlen = 1; m.msg_control = ctl; m.msg_controllen = sizeof(ctl);
  ssize_t n = ::recvmsg(s, &m, 0);
  if (n <= 0) return false;
  buf[n] = 0;
  out->text = buf;
  while (!out->text.empty() && (out->text.back() == '\n' || out->text.back() == '\r')) out->text.pop_back();
  out->fd = -1;
  for (cmsghdr* c = CMSG_FIRSTHDR(&m); c; c = CMSG_NXTHDR(&m, c))
    if (c->cmsg_level == SOL_SOCKET && c->cmsg_type == SCM_RIGHTS) std::memcpy(&out->fd, CMSG_DATA(c), sizeof(int));
  return true;
}

std::vector<std::string> split(const std::string& s, char d) {
  std::vector<std::string> r; std::string cur;
  for (char c : s) { if (c == d) { r.push_back(cur); cur.clear(); } else cur += c; }
  r.push_back(cur);
  return r;
}

QString jsonEscape(const std::string& s) {
  return QString::fromUtf8(QJsonDocument(QJsonObject{{"v", QString::fromStdString(s)}}).toJson(QJsonDocument::Compact))
      .mid(5).chopped(1);
}

int probe(const std::string& path) {
  using namespace rpi_android;
  std::string err;
  auto t = UsbRegistry::instance().openTransport(path, err);
  if (!t) { std::printf("{\"ok\":false,\"error\":%s}\n", jsonEscape(err).toUtf8().constData()); return 2; }
  BotDevice dev(std::move(t));
  if (!dev.init()) {
    std::printf("{\"ok\":false,\"error\":%s}\n", jsonEscape(dev.error()).toUtf8().constData());
    return 2;
  }
  std::printf("{\"ok\":true,\"vendor\":%s,\"product\":%s,\"size\":%llu,\"blockSize\":%u,\"writeProtected\":%s}\n",
              jsonEscape(dev.vendor()).toUtf8().constData(), jsonEscape(dev.product()).toUtf8().constData(),
              static_cast<unsigned long long>(dev.sizeBytes()), dev.blockSize(),
              dev.writeProtected() ? "true" : "false");
  return 0;
}

}  // namespace

int main(int argc, char* argv[]) {
  PlatformQuirks::applyQuirks();
  if (const char* ca = std::getenv("RPIIMAGER_CA_BUNDLE")) rpi_android::setCaBundlePath(ca);

  std::string sock, customJson, initFormat = "systemd", releaseDate;
  bool doProbe = false;
  std::vector<std::string> pass{argv[0]};
  for (int i = 1; i < argc; ++i) {
    std::string a = argv[i];
    auto val = [&](std::string& dst) { if (i + 1 < argc) dst = argv[++i]; };
    if (a == "--android-fd-socket") val(sock);
    else if (a == "--android-customisation") val(customJson);
    else if (a == "--android-init-format") val(initFormat);
    else if (a == "--android-os-release-date") val(releaseDate);
    else if (a == "--android-probe") doProbe = true;
    else pass.push_back(a);
  }

  // ---- receive descriptors ------------------------------------------------
  std::string firstUsb;
  std::string srcPath;  // when the image is passed as an fd
  if (!sock.empty()) {
    int s = connectAbstract(sock);
    if (s < 0) { std::fprintf(stderr, "Error: cannot connect to app fd socket\n"); return 1; }
    rpi_android::installLibusbTransportFactory();
    QString home = QString::fromLocal8Bit(qgetenv("RPIIMAGER_HOME"));
    Received r;
    while (recvOne(s, &r)) {
      auto f = split(r.text, '\t');
      if (f[0] == "done") break;
      struct Ack { int s; ~Ack() { (void)!::write(s, "k", 1); } } ack{s};
      if (f[0] == "usb" && f.size() >= 5 && r.fd >= 0) {
        rpi_android::UsbEndpointConfig cfg;
        cfg.fd = r.fd; cfg.interfaceNumber = std::atoi(f[2].c_str());
        cfg.epIn = std::atoi(f[3].c_str()); cfg.epOut = std::atoi(f[4].c_str());
        rpi_android::UsbDeviceInfo info; info.path = f[1];
        rpi_android::UsbRegistry::instance().add(info, cfg);
        if (firstUsb.empty()) firstUsb = f[1];
      } else if (f[0] == "src" && f.size() >= 2 && r.fd >= 0) {
        // Expose the descriptor under its real file name: the core chooses the decompressor by suffix.
        QString dir = home + "/src";
        QDir(dir).removeRecursively(); QDir().mkpath(dir);
        QString link = dir + "/" + QString::fromStdString(f[1]);
        if (::symlink(("/proc/self/fd/" + std::to_string(r.fd)).c_str(), link.toLocal8Bit().constData()) == 0)
          srcPath = link.toStdString();
      }
    }
    ::close(s);
  }
  if (doProbe) {
    if (firstUsb.empty()) { std::printf("{\"ok\":false,\"error\":\"no device received\"}\n"); return 2; }
    return probe(firstUsb);
  }

  // ---- customisation (original generators) ---------------------------------
  if (!customJson.empty()) {
    QFile f(QString::fromStdString(customJson));
    if (f.open(QIODevice::ReadOnly)) {
      QVariantMap s = QJsonDocument::fromJson(f.readAll()).object().toVariantMap();
      s.insert("osReleaseDate", QString::fromStdString(releaseDate));
      QString home = QString::fromLocal8Bit(qgetenv("RPIIMAGER_HOME")) + "/gen";
      QDir().mkpath(home);
      auto write = [&](const QString& name, const QByteArray& data) {
        QString p = home + "/" + name;
        QFile o(p);
        if (o.open(QIODevice::WriteOnly | QIODevice::Truncate)) { o.write(data); o.close(); }
        return p.toStdString();
      };
      if (initFormat == "systemd") {
        pass.insert(pass.end() - 2, {"--first-run-script", write("firstrun.sh", rpi_imager::CustomisationGenerator::generateSystemdScript(s))});
      } else if (initFormat == "cloudinit" || initFormat == "cloudinit-rpi") {
        const bool cc = initFormat == "cloudinit-rpi";
        const bool ssh = s.value("sshEnabled").toBool();
        const QString user = s.value("sshUserName").toString();
        pass.insert(pass.end() - 2, {"--cloudinit-userdata",
            write("user-data", rpi_imager::CustomisationGenerator::generateCloudInitUserData(s, QString(), cc, ssh, user)),
            "--cloudinit-networkconfig",
            write("network-config", rpi_imager::CustomisationGenerator::generateCloudInitNetworkConfig(s, cc))});
      }
    }
  }

  // replace the source argument (second last positional) when the image came as a descriptor
  if (!srcPath.empty() && pass.size() >= 3) pass[pass.size() - 2] = srcPath;

  std::vector<char*> av;
  for (auto& s : pass) av.push_back(s.data());
  int ac = static_cast<int>(av.size());
  av.push_back(nullptr);

  CurlNetworkConfig::ensureInitialized();
  Cli cli(ac, av.data());
  return cli.run();
}
