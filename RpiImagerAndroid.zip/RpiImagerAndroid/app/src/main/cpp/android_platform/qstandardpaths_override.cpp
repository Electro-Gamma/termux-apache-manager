/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * Qt for Android implements QStandardPaths through the Java side of Qt.  The CLI runs as a plain
 * native process with no JVM, so we interpose QStandardPaths::writableLocation (the executable's
 * definition wins over libQt6Core's, which is linked with default symbol visibility) and answer
 * from directories handed over by the Kotlin app in the environment.
 */
#include <cstdint>
#include <QByteArray>
#include <QDir>
#include <QStandardPaths>
#include <QString>
#include <QStringList>
#include <QNetworkProxy>

QString QStandardPaths::writableLocation(StandardLocation type) {
  QString home = QString::fromLocal8Bit(qgetenv("RPIIMAGER_HOME"));
  if (home.isEmpty()) home = QStringLiteral("/data/local/tmp/rpiimager");
  QString sub;
  switch (type) {
    case CacheLocation: case GenericCacheLocation: sub = QStringLiteral("cache"); break;
    case TempLocation: sub = QStringLiteral("tmp"); break;
    case DownloadLocation: case DocumentsLocation: sub = QStringLiteral("downloads"); break;
    case ConfigLocation: case GenericConfigLocation: case AppConfigLocation: sub = QStringLiteral("config"); break;
    default: sub = QStringLiteral("data"); break;
  }
  QString p = home + QLatin1Char('/') + sub;
  QDir().mkpath(p);
  return p;
}

QStringList QStandardPaths::standardLocations(StandardLocation type) {
  return QStringList{writableLocation(type)};
}

// Qt-for-Android resolves the system proxy through JNI; libcurl honours http_proxy/https_proxy itself.
QList<QNetworkProxy> QNetworkProxyFactory::systemProxyForQuery(const QNetworkProxyQuery&) {
  return QList<QNetworkProxy>{QNetworkProxy(QNetworkProxy::NoProxy)};
}

#ifdef __ANDROID__
// Last-resort safety net.  Any Qt-for-Android call that still reaches for the Java VM would
// dereference a null JavaVM and kill the process.  Hand out a JNIEnv whose every function returns 0/null
// (FindClass -> null, ExceptionCheck -> false ...); Qt treats those as "Java says nothing".
#include <jni.h>
#include <QJniEnvironment>
namespace {
intptr_t jniNothing() { return 0; }
struct FakeJniEnv {
  void* table[256];
  JNIEnv env;
  FakeJniEnv() {
    for (auto& f : table) f = reinterpret_cast<void*>(&jniNothing);
    *reinterpret_cast<void***>(&env) = table;   // JNIEnv_ == { const JNINativeInterface_* functions; }
  }
};
}  // namespace
JNIEnv* QJniEnvironment::getJniEnv() {
  static FakeJniEnv fake;
  return &fake.env;
}

// Qt-for-Android answers these through JNI, which needs a JavaVM this process does not have
// (calling them would dereference a null JavaVM).  Same interposition trick as above.
#include <android/api-level.h>
namespace QtAndroidPrivate {
int androidSdkVersion() { return android_get_device_api_level(); }
bool isUncompressedNativeLibs() { return false; }
}  // namespace QtAndroidPrivate
#endif
