/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * Qt for Android implements QStandardPaths through the Java side of Qt.  The CLI runs as a plain
 * native process with no JVM, so we interpose QStandardPaths::writableLocation (the executable's
 * definition wins over libQt6Core's, which is linked with default symbol visibility) and answer
 * from directories handed over by the Kotlin app in the environment.
 */
#include <QByteArray>
#include <QDir>
#include <QStandardPaths>
#include <QString>
#include <QStringList>

QString QStandardPaths::writableLocation(StandardLocation type) {
  QString home = QString::fromLocal8Bit(qgetenv("RPIIMAGER_HOME"));
  if (home.isEmpty()) home = QStringLiteral("/data/local/tmp/rpiimager");
  QString sub;
  switch (type) {
    case CacheLocation: case GenericCacheLocation: sub = QStringLiteral("cache"); break;
    case TempLocation: sub = QStringLiteral("tmp"); break;
    case DownloadLocation: case DocumentsLocation: sub = QStringLiteral("downloads"); break;
    case ConfigLocation: case GenericConfigLocation: case AppConfigLocation: sub = QStringLiteral("config"); break;
    default: sub = QStringLiteral("data"); break;
  }
  QString p = home + QLatin1Char('/') + sub;
  QDir().mkpath(p);
  return p;
}

QStringList QStandardPaths::standardLocations(StandardLocation type) {
  return QStringList{writableLocation(type)};
}

#ifdef __ANDROID__
// Qt-for-Android answers these through JNI, which needs a JavaVM this process does not have
// (calling them would dereference a null JavaVM).  Same interposition trick as above.
#include <android/api-level.h>
namespace QtAndroidPrivate {
int androidSdkVersion() { return android_get_device_api_level(); }
bool isUncompressedNativeLibs() { return false; }
}  // namespace QtAndroidPrivate
#endif
