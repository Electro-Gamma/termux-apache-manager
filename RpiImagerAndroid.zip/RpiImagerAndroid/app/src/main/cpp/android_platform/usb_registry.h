/*
 * SPDX-License-Identifier: Apache-2.0
 * Registry of USB mass-storage devices the Kotlin layer has obtained
 * permission for.  The device "path" is Android's UsbDevice.deviceName
 * (e.g. /dev/bus/usb/001/004), which doubles as the destination string the
 * original Imager core treats as a device path.
 */
#ifndef RPI_ANDROID_USB_REGISTRY_H_
#define RPI_ANDROID_USB_REGISTRY_H_

#include <cstdint>
#include <functional>
#include <map>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

#include "usb_bot.h"

namespace rpi_android {

struct UsbEndpointConfig {
  int fd = -1;              // from UsbDeviceConnection.getFileDescriptor()
  int interfaceNumber = 0;
  int epIn = 0x81;
  int epOut = 0x02;
};

struct UsbDeviceInfo {
  std::string path;
  std::string vendor;
  std::string product;
  std::uint64_t size = 0;
  std::uint32_t blockSize = 512;
  bool writeProtected = false;
};

using TransportFactory = std::function<std::unique_ptr<BulkTransport>(
    const std::string& path, const UsbEndpointConfig& cfg, std::string& err)>;

class UsbRegistry {
 public:
  static UsbRegistry& instance();

  void setTransportFactory(TransportFactory f);
  void add(const UsbDeviceInfo& info, const UsbEndpointConfig& cfg);
  void remove(const std::string& path);
  void clear();
  bool contains(const std::string& path) const;
  std::vector<UsbDeviceInfo> list() const;
  std::unique_ptr<BulkTransport> openTransport(const std::string& path, std::string& err) const;

 private:
  struct Entry {
    UsbDeviceInfo info;
    UsbEndpointConfig cfg;
  };
  mutable std::mutex mu_;
  std::map<std::string, Entry> devices_;
  TransportFactory factory_;
};

}  // namespace rpi_android

#endif
