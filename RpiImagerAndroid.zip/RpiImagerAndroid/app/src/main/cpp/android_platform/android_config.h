/* SPDX-License-Identifier: Apache-2.0 */
#ifndef RPI_ANDROID_CONFIG_H_
#define RPI_ANDROID_CONFIG_H_
#include <string>
namespace rpi_android {
// PEM CA bundle exported from Android's trust store by the Kotlin layer.
void setCaBundlePath(const std::string& path);
std::string caBundlePath();
}  // namespace rpi_android
#endif
