/* SPDX-License-Identifier: Apache-2.0 */
#include "usb_registry.h"

namespace rpi_android {

UsbRegistry& UsbRegistry::instance() {
  static UsbRegistry r;
  return r;
}

void UsbRegistry::setTransportFactory(TransportFactory f) {
  std::lock_guard<std::mutex> l(mu_);
  factory_ = std::move(f);
}

void UsbRegistry::add(const UsbDeviceInfo& info, const UsbEndpointConfig& cfg) {
  std::lock_guard<std::mutex> l(mu_);
  devices_[info.path] = Entry{info, cfg};
}

void UsbRegistry::remove(const std::string& path) {
  std::lock_guard<std::mutex> l(mu_);
  devices_.erase(path);
}

void UsbRegistry::clear() {
  std::lock_guard<std::mutex> l(mu_);
  devices_.clear();
}

bool UsbRegistry::contains(const std::string& path) const {
  std::lock_guard<std::mutex> l(mu_);
  return devices_.count(path) != 0;
}

std::vector<UsbDeviceInfo> UsbRegistry::list() const {
  std::lock_guard<std::mutex> l(mu_);
  std::vector<UsbDeviceInfo> v;
  for (const auto& kv : devices_) v.push_back(kv.second.info);
  return v;
}

std::unique_ptr<BulkTransport> UsbRegistry::openTransport(const std::string& path,
                                                          std::string& err) const {
  TransportFactory f;
  UsbEndpointConfig cfg;
  {
    std::lock_guard<std::mutex> l(mu_);
    auto it = devices_.find(path);
    if (it == devices_.end()) { err = "USB device is not registered"; return nullptr; }
    cfg = it->second.cfg;
    f = factory_;
  }
  if (!f) { err = "no USB transport available"; return nullptr; }
  return f(path, cfg, err);
}

}  // namespace rpi_android
