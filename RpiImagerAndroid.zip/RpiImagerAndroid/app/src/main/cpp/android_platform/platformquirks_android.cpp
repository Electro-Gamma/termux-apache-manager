/*
 * SPDX-License-Identifier: Apache-2.0
 * Android implementation of the PlatformQuirks seam (the original ships
 * linux/mac/windows variants).  Android needs no elevation (raw access goes
 * through the USB host API), has no mounted-volume management for the
 * targets, and gets TLS roots from a PEM bundle exported by Kotlin.
 */
#include "platformquirks.h"

#include <QFile>
#include <QUrl>

#include <mutex>

#include "android_config.h"

namespace rpi_android {
static std::mutex g_mu;
static std::string g_ca;
void setCaBundlePath(const std::string& p) { std::lock_guard<std::mutex> l(g_mu); g_ca = p; }
std::string caBundlePath() { std::lock_guard<std::mutex> l(g_mu); return g_ca; }
}  // namespace rpi_android

namespace PlatformQuirks {

NativePermissionScope::NativePermissionScope() {}
NativePermissionScope::~NativePermissionScope() {}

void applyQuirks() {}
WindowIconSource windowIconSource() { return {}; }
void beep() {}
bool isBeepAvailable() { return false; }
bool hasNetworkConnectivity() { return true; }  // connectivity is checked by the Kotlin layer
bool isNetworkReady() { return true; }
void setClockFloor(long long) {}
void startNetworkMonitoring(NetworkStatusCallback callback) { if (callback) callback(true); }
void stopNetworkMonitoring() {}
void bringWindowToForeground(void*) {}
bool hasElevatedPrivileges() { return true; }  // no elevation concept: USB host permission is the gate
void attachConsole() {}
const char* getBundlePath() { return ""; }
bool isElevatableBundle() { return false; }
bool hasElevationPolicyInstalled() { return true; }
bool installElevationPolicy() { return false; }
bool tryElevate(int, char**) { return false; }
bool launchDetached(const QString&, const QStringList&) { return false; }
bool openUrlExternally(const QUrl&) { return false; }
bool registerUriScheme() { return true; }
bool runElevatedPolicyInstaller() { return false; }
void execElevated(const QStringList&) {}
bool isScrollInverted(bool qtInvertedFlag) { return qtInvertedFlag; }
bool prefersReducedMotion() { return false; }
void logFontEngine() {}
qreal detectTextScaleFactor() { return 1.0; }
qreal fontDpiCorrection() { return 1.0; }
QString sshKeyGenPath() { return QString(); }  // no ssh-keygen on Android; keys are pasted in

QString getWriteDevicePath(const QString& devicePath) { return devicePath; }
QString getEjectDevicePath(const QString& devicePath) { return devicePath; }

// USB mass-storage targets are never mounted by Android for us, and writes go
// straight to the device via SCSI, so there is nothing to unmount, eject or
// re-read.  The cache flush is done by SYNCHRONIZE CACHE when the device closes.
DiskResult unmountDisk(const QString&) { return DiskResult::Success; }
DiskResult ejectDisk(const QString&) { return DiskResult::Success; }
DiskResult refreshDiskView(const QString&) { return DiskResult::Success; }

const char* findCACertBundle() {
  static std::string path;
  path = rpi_android::caBundlePath();
  if (path.empty() || !QFile::exists(QString::fromStdString(path))) return nullptr;
  return path.c_str();
}
void clearAppImageEnvironment() {}
void applyEmbeddedDisplayScaling() {}

}  // namespace PlatformQuirks
