/* SPDX-License-Identifier: Apache-2.0 */
#ifndef RPI_ANDROID_LIBUSB_TRANSPORT_H_
#define RPI_ANDROID_LIBUSB_TRANSPORT_H_
#include "usb_registry.h"

namespace rpi_android {
// Installs a libusb-backed TransportFactory into UsbRegistry. Idempotent.
void installLibusbTransportFactory();
}  // namespace rpi_android
#endif
