/* SPDX-License-Identifier: Apache-2.0 */
#ifndef RPI_ANDROID_ENGINE_H_
#define RPI_ANDROID_ENGINE_H_

#include <QJsonObject>
#include <QObject>
#include <QString>

class ImageWriter;

namespace rpi_android {

// Lives in the Qt main thread (the thread running QGuiApplication::exec()).
// Owns the original ImageWriter and forwards its signals to Kotlin as
// (name, json) events.
class Engine : public QObject {
  Q_OBJECT
 public:
  explicit Engine(QObject* parent = nullptr);
  ~Engine() override;
  ImageWriter* writer() const { return writer_; }
  static Engine* instance();

  // Emit an event to the Kotlin side (implemented in jni_bridge.cpp).
  static void emitEvent(const QString& name, const QJsonObject& payload = QJsonObject());

 private:
  ImageWriter* writer_ = nullptr;
};

}  // namespace rpi_android

#endif
