/*
 * SPDX-License-Identifier: Apache-2.0
 * JNI bridge between the Kotlin UI and the original Imager core (ImageWriter).
 *
 *  Kotlin thread --JNI--> runOnQt() --queued--> Qt main thread (ImageWriter)
 *  ImageWriter signal --> Engine --> emitEvent() --JNI--> NativeCallbacks.onEvent
 */
#include <jni.h>

#include <QJsonArray>
#include <QJsonDocument>
#include <QMetaObject>
#include <QPointer>
#include <QThread>
#include <QUrl>

#include <atomic>
#include <mutex>

#include "android_config.h"
#include "engine.h"
#include "imagewriter.h"
#include "libusb_transport_android.h"
#include "usb_bot.h"
#include "usb_registry.h"

namespace {

JavaVM* g_vm = nullptr;
jobject g_cb = nullptr;
jmethodID g_onEvent = nullptr;
std::mutex g_cbMutex;

QString toQString(JNIEnv* env, jstring s) {
  if (!s) return QString();
  const jchar* c = env->GetStringChars(s, nullptr);
  QString r = QString::fromUtf16(reinterpret_cast<const char16_t*>(c), env->GetStringLength(s));
  env->ReleaseStringChars(s, c);
  return r;
}

jstring toJString(JNIEnv* env, const QString& s) {
  return env->NewString(reinterpret_cast<const jchar*>(s.utf16()), static_cast<jsize>(s.size()));
}

QString jsonString(const QJsonObject& o) {
  return QString::fromUtf8(QJsonDocument(o).toJson(QJsonDocument::Compact));
}

// Run fn on the Qt main thread and wait for the result.
template <typename R, typename F>
R runOnQt(F fn, R fallback = R()) {
  rpi_android::Engine* e = rpi_android::Engine::instance();
  if (!e) return fallback;
  R result = fallback;
  if (QThread::currentThread() == e->thread()) {
    result = fn(e->writer());
  } else {
    QMetaObject::invokeMethod(e, [&] { result = fn(e->writer()); }, Qt::BlockingQueuedConnection);
  }
  return result;
}

// Fire-and-forget variant.
template <typename F>
void postToQt(F fn) {
  rpi_android::Engine* e = rpi_android::Engine::instance();
  if (!e) return;
  QMetaObject::invokeMethod(e, [e, fn] { fn(e->writer()); }, Qt::QueuedConnection);
}

}  // namespace

// ---------------------------------------------------------------- Engine ----

namespace rpi_android {

static QPointer<Engine> g_engine;
Engine* Engine::instance() { return g_engine.data(); }

void Engine::emitEvent(const QString& name, const QJsonObject& payload) {
  JNIEnv* env = nullptr;
  bool attached = false;
  if (!g_vm) return;
  if (g_vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) == JNI_EDETACHED) {
    if (g_vm->AttachCurrentThread(&env, nullptr) != JNI_OK) return;
    attached = true;
  }
  jobject cb = nullptr;
  jmethodID m = nullptr;
  {
    std::lock_guard<std::mutex> l(g_cbMutex);
    if (g_cb) cb = env->NewLocalRef(g_cb);
    m = g_onEvent;
  }
  if (cb && m) {
    jstring jn = toJString(env, name);
    jstring jp = toJString(env, jsonString(payload));
    env->CallVoidMethod(cb, m, jn, jp);
    if (env->ExceptionCheck()) env->ExceptionClear();
    env->DeleteLocalRef(jn);
    env->DeleteLocalRef(jp);
  }
  if (cb) env->DeleteLocalRef(cb);
  if (attached) g_vm->DetachCurrentThread();
}

static const char* stateName(ImageWriter::WriteState s) {
  switch (s) {
    case ImageWriter::WriteState::Idle: return "idle";
    case ImageWriter::WriteState::Preparing: return "preparing";
    case ImageWriter::WriteState::Writing: return "writing";
    case ImageWriter::WriteState::Verifying: return "verifying";
    case ImageWriter::WriteState::Finalizing: return "finalizing";
    case ImageWriter::WriteState::Cancelling: return "cancelling";
    case ImageWriter::WriteState::Succeeded: return "succeeded";
    case ImageWriter::WriteState::Failed: return "failed";
    case ImageWriter::WriteState::Cancelled: return "cancelled";
  }
  return "idle";
}

Engine::Engine(QObject* parent) : QObject(parent) {
  g_engine = this;
  writer_ = new ImageWriter(this);

  auto prog = [](const char* ev) {
    return [ev](QVariant now, QVariant total) {
      QJsonObject o;
      o["now"] = static_cast<double>(now.toULongLong());
      o["total"] = static_cast<double>(total.toULongLong());
      Engine::emitEvent(ev, o);
    };
  };
  connect(writer_, &ImageWriter::downloadProgress, this, prog("writeProgress"));
  connect(writer_, &ImageWriter::verifyProgress, this, prog("verifyProgress"));
  connect(writer_, &ImageWriter::success, this, [] { Engine::emitEvent("success"); });
  connect(writer_, &ImageWriter::error, this, [](QVariant msg) {
    Engine::emitEvent("error", QJsonObject{{"message", msg.toString()}});
  });
  connect(writer_, &ImageWriter::preparationStatusUpdate, this, [](QVariant msg) {
    Engine::emitEvent("status", QJsonObject{{"message", msg.toString()}});
  });
  connect(writer_, &ImageWriter::osListPrepared, this, [] { Engine::emitEvent("osListPrepared"); });
  connect(writer_, &ImageWriter::osListUnavailableChanged, this, [this] {
    Engine::emitEvent("osListUnavailable", QJsonObject{{"unavailable", writer_->isOsListUnavailable()}});
  });
  connect(writer_, &ImageWriter::cancelled, this, [] { Engine::emitEvent("cancelled"); });
  connect(writer_, &ImageWriter::finalizing, this, [] { Engine::emitEvent("finalizing"); });
  connect(writer_, &ImageWriter::operationWarning, this, [](QVariant msg) {
    Engine::emitEvent("warning", QJsonObject{{"message", msg.toString()}});
  });
  connect(writer_, &ImageWriter::selectedDeviceRemoved, this, [] { Engine::emitEvent("deviceRemoved"); });
  connect(writer_, &ImageWriter::writeStateChanged, this, [this] {
    Engine::emitEvent("writeState", QJsonObject{{"state", QString::fromLatin1(stateName(writer_->writeState()))}});
  });
  connect(writer_, &ImageWriter::cacheVerificationStarted, this, [] { Engine::emitEvent("cacheVerificationStarted"); });
  connect(writer_, &ImageWriter::cacheVerificationFinished, this, [] { Engine::emitEvent("cacheVerificationFinished"); });
}

Engine::~Engine() {
  if (g_engine == this) g_engine = nullptr;
}

}  // namespace rpi_android

// ------------------------------------------------------------------- JNI ----

#define JNI_FN(ret, name) extern "C" JNIEXPORT ret JNICALL Java_dev_rpiimager_android_NativeEngine_##name

extern "C" JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void*) {
  g_vm = vm;
  return JNI_VERSION_1_6;
}

JNI_FN(void, nativeSetCallbacks)(JNIEnv* env, jobject, jobject cb) {
  std::lock_guard<std::mutex> l(g_cbMutex);
  if (g_cb) env->DeleteGlobalRef(g_cb);
  g_cb = nullptr;
  g_onEvent = nullptr;
  if (!cb) return;
  g_cb = env->NewGlobalRef(cb);
  jclass c = env->GetObjectClass(cb);
  g_onEvent = env->GetMethodID(c, "onEvent", "(Ljava/lang/String;Ljava/lang/String;)V");
}

JNI_FN(jboolean, nativeIsReady)(JNIEnv*, jobject) {
  return rpi_android::Engine::instance() != nullptr;
}

JNI_FN(void, nativeConfigure)(JNIEnv* env, jobject, jstring caBundle) {
  rpi_android::setCaBundlePath(toQString(env, caBundle).toStdString());
  rpi_android::installLibusbTransportFactory();
}

JNI_FN(jstring, nativeVersion)(JNIEnv* env, jobject) {
  return toJString(env, ImageWriter::staticVersion());
}

// Probe a USB mass-storage device and add it to the drive list.
// Returns JSON {"ok":bool,"path","vendor","product","size","blockSize","writeProtected","error"}.
JNI_FN(jstring, nativeUsbRegister)(JNIEnv* env, jobject, jstring jpath, jint fd, jint iface,
                                   jint epIn, jint epOut) {
  using namespace rpi_android;
  const std::string path = toQString(env, jpath).toStdString();
  UsbEndpointConfig cfg;
  cfg.fd = fd;
  cfg.interfaceNumber = iface;
  cfg.epIn = epIn;
  cfg.epOut = epOut;
  UsbDeviceInfo info;
  info.path = path;
  UsbRegistry::instance().add(info, cfg);

  QJsonObject out;
  out["path"] = QString::fromStdString(path);
  std::string err;
  auto transport = UsbRegistry::instance().openTransport(path, err);
  if (!transport) {
    UsbRegistry::instance().remove(path);
    out["ok"] = false;
    out["error"] = QString::fromStdString(err);
    return toJString(env, jsonString(out));
  }
  BotDevice dev(std::move(transport));
  if (!dev.init()) {
    UsbRegistry::instance().remove(path);
    out["ok"] = false;
    out["error"] = QString::fromStdString(dev.error());
    return toJString(env, jsonString(out));
  }
  info.vendor = dev.vendor();
  info.product = dev.product();
  info.size = dev.sizeBytes();
  info.blockSize = dev.blockSize();
  info.writeProtected = dev.writeProtected();
  UsbRegistry::instance().add(info, cfg);
  out["ok"] = true;
  out["vendor"] = QString::fromStdString(info.vendor);
  out["product"] = QString::fromStdString(info.product);
  out["size"] = static_cast<double>(info.size);
  out["blockSize"] = static_cast<double>(info.blockSize);
  out["writeProtected"] = info.writeProtected;
  return toJString(env, jsonString(out));
}

JNI_FN(void, nativeUsbUnregister)(JNIEnv* env, jobject, jstring jpath) {
  rpi_android::UsbRegistry::instance().remove(toQString(env, jpath).toStdString());
}

JNI_FN(void, nativeFetchOsList)(JNIEnv*, jobject) {
  postToQt([](ImageWriter* w) { w->beginOSListFetch(); });
}

JNI_FN(jstring, nativeOsListJson)(JNIEnv* env, jobject) {
  QString s = runOnQt<QString>([](ImageWriter* w) { return QString::fromUtf8(w->getFilteredOSlist()); });
  return toJString(env, s);
}

JNI_FN(void, nativeSetHwFilter)(JNIEnv* env, jobject, jstring tagsJson, jboolean inclusive) {
  const QJsonArray tags = QJsonDocument::fromJson(toQString(env, tagsJson).toUtf8()).array();
  const bool inc = inclusive;
  runOnQt<bool>([&](ImageWriter* w) { w->setHWFilterList(tags, inc); return true; });
}

JNI_FN(void, nativeSetSource)(JNIEnv* env, jobject, jstring url, jlong downloadLen, jlong extractLen,
                              jstring sha256, jboolean multiFile, jstring parentCategory,
                              jstring osName, jstring initFormat, jstring releaseDate, jstring bmapUrl) {
  const QString u = toQString(env, url);
  const QUrl qurl = u.startsWith('/') ? QUrl::fromLocalFile(u) : QUrl(u);
  const QByteArray hash = toQString(env, sha256).toLatin1();
  const QString parent = toQString(env, parentCategory), name = toQString(env, osName),
                rel = toQString(env, releaseDate), bmap = toQString(env, bmapUrl);
  const QByteArray fmt = toQString(env, initFormat).toLatin1();
  const quint64 dl = static_cast<quint64>(downloadLen), ex = static_cast<quint64>(extractLen);
  const bool multi = multiFile;
  runOnQt<bool>([&](ImageWriter* w) {
    w->setSrc(qurl, dl, ex, hash, multi, parent, name, fmt, rel, bmap);
    return true;
  });
}

JNI_FN(void, nativeSetDestination)(JNIEnv* env, jobject, jstring device, jlong size) {
  const QString d = toQString(env, device);
  const quint64 s = static_cast<quint64>(size);
  runOnQt<bool>([&](ImageWriter* w) { w->setDst(d, s); return true; });
}

JNI_FN(void, nativeApplyCustomisation)(JNIEnv* env, jobject, jstring json) {
  const QVariantMap m = QJsonDocument::fromJson(toQString(env, json).toUtf8()).object().toVariantMap();
  runOnQt<bool>([&](ImageWriter* w) { w->applyCustomisationFromSettings(m); return true; });
}

JNI_FN(jstring, nativeHashPassword)(JNIEnv* env, jobject, jstring plain) {
  const QString p = toQString(env, plain);
  return toJString(env, runOnQt<QString>([&](ImageWriter* w) { return w->hashUserPassword(p); }));
}

JNI_FN(void, nativeSetVerify)(JNIEnv*, jobject, jboolean v) {
  const bool b = v;
  runOnQt<bool>([&](ImageWriter* w) { w->setVerifyEnabled(b); return true; });
}

JNI_FN(void, nativeSetEject)(JNIEnv*, jobject, jboolean v) {
  const bool b = v;
  runOnQt<bool>([&](ImageWriter* w) { w->setSetting(QStringLiteral("eject"), b); return true; });
}

JNI_FN(void, nativeStartWrite)(JNIEnv*, jobject) {
  postToQt([](ImageWriter* w) { w->startWrite(); });
}

JNI_FN(void, nativeCancelWrite)(JNIEnv*, jobject) {
  postToQt([](ImageWriter* w) { w->cancelWrite(); });
}

// kind: timezones | countries | keymaps | capitals
JNI_FN(jstring, nativeStringList)(JNIEnv* env, jobject, jstring kind) {
  const QString k = toQString(env, kind);
  QStringList l = runOnQt<QStringList>([&](ImageWriter* w) {
    if (k == "timezones") return w->getTimezoneList();
    if (k == "countries") return w->getCountryList();
    if (k == "keymaps") return w->getKeymapLayoutList();
    if (k == "capitals") return w->getCapitalCitiesList();
    return QStringList();
  });
  return toJString(env, QString::fromUtf8(QJsonDocument(QJsonArray::fromStringList(l)).toJson(QJsonDocument::Compact)));
}

JNI_FN(jstring, nativeLocaleForCapital)(JNIEnv* env, jobject, jstring city) {
  const QString c = toQString(env, city);
  QVariantMap m = runOnQt<QVariantMap>([&](ImageWriter* w) { return w->getLocaleDataForCapital(c); });
  return toJString(env, jsonString(QJsonObject::fromVariantMap(m)));
}
