/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * Android port of Raspberry Pi Imager - USB Mass Storage (Bulk-Only Transport)
 * + SCSI block access.
 *
 * Android does not let an app open /dev/block (block device nodes) without root, but it does let
 * an app talk to a USB device it has been granted permission for.  A USB card
 * reader is a Mass Storage Class / SCSI transparent / Bulk-Only device, so we
 * speak the protocol ourselves and expose it as a byte-addressable block
 * device.  This file has no Qt, libusb or Android dependency so that it can be
 * unit-tested on a host machine (see native-tests/).
 */
#ifndef RPI_ANDROID_USB_BOT_H_
#define RPI_ANDROID_USB_BOT_H_

#include <cstddef>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

namespace rpi_android {

enum class XferResult : int {
  kOk = 0,
  kStall = -1,     // endpoint halted (LIBUSB_ERROR_PIPE)
  kTimeout = -2,
  kNoDevice = -3,  // unplugged
  kError = -4,
};

// One bulk-IN / bulk-OUT endpoint pair plus the two class-specific control
// requests Bulk-Only Transport needs.  Implemented over libusb on Android and
// over a RAM disk in the unit tests.
class BulkTransport {
 public:
  virtual ~BulkTransport() = default;
  virtual XferResult bulkOut(const std::uint8_t* data, std::size_t len,
                             std::size_t* transferred, unsigned timeoutMs) = 0;
  virtual XferResult bulkIn(std::uint8_t* data, std::size_t len,
                            std::size_t* transferred, unsigned timeoutMs) = 0;
  virtual bool clearHaltIn() = 0;
  virtual bool clearHaltOut() = 0;
  // Bulk-Only Mass Storage Reset (class request 0xFF).
  virtual bool bulkOnlyReset() = 0;
};

struct SenseInfo {
  bool valid = false;
  std::uint8_t key = 0;
  std::uint8_t asc = 0;
  std::uint8_t ascq = 0;
};

class BotDevice {
 public:
  // Upper bound for the payload of a single SCSI READ/WRITE command.
  static constexpr std::size_t kMaxTransferBytes = 512 * 1024;

  explicit BotDevice(std::unique_ptr<BulkTransport> transport);

  // INQUIRY, wait until the unit is ready, READ CAPACITY(10 or 16),
  // best-effort MODE SENSE for the write-protect bit.
  bool init();

  // Whole-block access.
  bool readBlocks(std::uint64_t lba, std::uint32_t count, std::uint8_t* buf);
  bool writeBlocks(std::uint64_t lba, std::uint32_t count, const std::uint8_t* buf);
  bool syncCache();

  // Byte-granular access.  Writes that are not block aligned do a
  // read-modify-write of the partial head/tail block.
  bool read(std::uint64_t offset, std::uint8_t* buf, std::size_t len);
  bool write(std::uint64_t offset, const std::uint8_t* buf, std::size_t len);

  std::uint32_t blockSize() const { return blockSize_; }
  std::uint64_t blockCount() const { return blockCount_; }
  std::uint64_t sizeBytes() const { return blockCount_ * blockSize_; }
  bool writeProtected() const { return writeProtected_; }
  const std::string& vendor() const { return vendor_; }
  const std::string& product() const { return product_; }
  const std::string& error() const { return error_; }
  const SenseInfo& lastSense() const { return lastSense_; }

  // Test/tuning hooks.
  void setRetryDelayMs(unsigned ms) { retryDelayMs_ = ms; }
  unsigned recoveryCount() const { return recoveries_; }

 private:
  enum class Dir { kNone, kIn, kOut };
  enum class CswStatus { kPassed = 0, kFailed = 1, kPhaseError = 2, kBad = 3 };

  struct CmdOutcome {
    bool transportOk = false;   // false => fatal, recovery already attempted
    CswStatus csw = CswStatus::kBad;
    std::uint32_t residue = 0;
    std::size_t transferred = 0;
  };

  CmdOutcome execute(const std::uint8_t* cdb, std::uint8_t cdbLen, Dir dir,
                     std::uint8_t* buf, std::size_t len, unsigned dataTimeoutMs);
  // execute() + REQUEST SENSE on CHECK CONDITION.  Returns true on GOOD status.
  bool command(const std::uint8_t* cdb, std::uint8_t cdbLen, Dir dir,
               std::uint8_t* buf, std::size_t len, std::size_t* actual = nullptr,
               unsigned dataTimeoutMs = 30000);
  bool requestSense(SenseInfo* out);
  bool testUnitReady(SenseInfo* sense);
  void resetRecovery();
  bool readCapacity();
  bool rwBlocks(bool isWrite, std::uint64_t lba, std::uint32_t count, std::uint8_t* buf);
  bool fail(const std::string& msg);

  std::unique_ptr<BulkTransport> t_;
  std::uint32_t tag_ = 0;
  std::uint32_t blockSize_ = 0;
  std::uint64_t blockCount_ = 0;
  bool use16_ = false;
  bool writeProtected_ = false;
  std::string vendor_, product_, error_;
  SenseInfo lastSense_;
  unsigned retryDelayMs_ = 100;
  unsigned recoveries_ = 0;
};

}  // namespace rpi_android

#endif  // RPI_ANDROID_USB_BOT_H_
