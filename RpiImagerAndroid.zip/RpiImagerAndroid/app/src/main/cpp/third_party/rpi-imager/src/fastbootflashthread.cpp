/*
 * SPDX-License-Identifier: Apache-2.0
 * Copyright (C) 2025 Raspberry Pi Ltd
 */

#include "fastbootflashthread.h"
#include "rpiboot/libusb_transport.h"
#include "fastboot/fastboot_protocol.h"
#include "cmdline_params.h"
#include "config_txt_merge.h"
#include "fastboot/sparse_encoder.h"
#include "fastboot/bmap.h"
#include "fastboot/pieeprom.h"
#include "fastboot/eeprom_signer.h"
#include "connect_device_registrar.h"
#include "curlnetworkconfig.h"
#include "acceleratedcryptographichash.h"
#include "ringbuffer.h"
#include "systemmemorymanager.h"

#include <QDateTime>
#include <QDebug>
#include <QElapsedTimer>
#include <QFile>
#include <QScopeGuard>
#include <QSettings>
#include <QString>

#include <archive.h>
#include <archive_entry.h>
#include <curl/curl.h>

#include <algorithm>
#include <cctype>
#include <cerrno>
#include <cstring>
#include <thread>

// Use the canonical FASTBOOT_VID/PID from rpiboot_types.h
using rpiboot::FASTBOOT_VID;
using rpiboot::FASTBOOT_PID;

// Default max-download-size if the device doesn't report one
static constexpr uint32_t DEFAULT_MAX_DOWNLOAD_SIZE = 256 * 1024 * 1024;  // 256 MB

// Ceiling on the segment size we will honour regardless of what the device
// asks for. SparseEncoder reserves two buffers of this size, so the real cost
// is double. Beyond the default there is nothing to gain: segments are already
// large enough that per-segment overhead has vanished.
static constexpr uint32_t MAX_HONOURED_DOWNLOAD_SIZE = DEFAULT_MAX_DOWNLOAD_SIZE;

uint32_t FastbootFlashThread::resolveMaxDownloadSize(const std::string *reported,
                                                     quint64 availableBytes)
{
    quint64 size = DEFAULT_MAX_DOWNLOAD_SIZE;

    if (reported) {
        const std::string &val = *reported;
        const bool hex = val.starts_with("0x") || val.starts_with("0X");
        const size_t digitsFrom = hex ? 2 : 0;

        bool parsed = false;
        // stoull is too forgiving on its own: "0x" yields 0, "0x10zz" yields
        // 16, and "-1" yields ULLONG_MAX rather than throwing. Anything the
        // device sends that is not wholly a number is not a number.
        if (val.size() > digitsFrom) {
            const auto isDigit = [hex](unsigned char c) {
                return hex ? std::isxdigit(c) != 0 : std::isdigit(c) != 0;
            };
            if (std::all_of(val.begin() + digitsFrom, val.end(), isDigit)) {
                try {
                    // stoull, not stoul-into-uint32_t: a device reporting
                    // 0x100000000 used to narrow to 0, below the floor.
                    size = std::stoull(val, nullptr, hex ? 16 : 10);
                    parsed = true;
                } catch (const std::out_of_range &) {
                    // Larger than a uint64. It is getting clamped regardless.
                    size = MAX_HONOURED_DOWNLOAD_SIZE;
                    parsed = true;
                } catch (...) {
                }
            }
        }

        if (!parsed) {
            qDebug() << "FastbootFlashThread: could not parse max-download-size:"
                     << QString::fromStdString(val)
                     << "using default" << DEFAULT_MAX_DOWNLOAD_SIZE;
            size = DEFAULT_MAX_DOWNLOAD_SIZE;
        }
    }

    // Two buffers of this size are reserved for the duration of the flash,
    // alongside the ring buffers the memory manager has already budgeted.
    // Give the encoder at most an eighth of what is free, so a device that
    // asks for a lot cannot push the machine into swap on its own say-so.
    if (availableBytes > 0) {
        const quint64 memoryCeiling = std::max<quint64>(
            availableBytes / 8, fastboot::SparseEncoder::MIN_SEGMENT_SIZE);
        size = std::min(size, memoryCeiling);
    }

    size = std::min<quint64>(size, MAX_HONOURED_DOWNLOAD_SIZE);
    size = std::max<quint64>(size, fastboot::SparseEncoder::MIN_SEGMENT_SIZE);
    return static_cast<uint32_t>(size);
}

FastbootFlashThread::FastbootFlashThread(const QString& fastbootId,
                                           const QString& blockDevice,
                                           const QUrl& imageUrl,
                                           quint64 downloadLen,
                                           quint64 extractLen,
                                           const QByteArray& expectedHash,
                                           QObject* parent)
    : QThread(parent)
    , _fastbootId(fastbootId)
    , _blockDevice(blockDevice)
    , _imageUrl(imageUrl)
    , _downloadLen(downloadLen)
    , _extractLen(extractLen)
    , _expectedHash(expectedHash)
{
}

FastbootFlashThread::~FastbootFlashThread()
{
    cancel();
    if (!wait(10000)) {
        // Thread is stuck — most likely deadlocked in libusb_exit on macOS
        // (libusb bug: darwin_exit holds active_contexts_lock while waiting
        // for the IONotification run loop, which itself needs that lock to
        // process a pending IOKit callback).  Since we are in the destructor
        // path and the process will exit shortly, force-kill the thread.
        // QThread::~QThread() calls qFatal() if the thread is still running,
        // so we must wait until the OS has confirmed it is gone.
        qWarning() << "FastbootFlashThread: thread did not finish within 10s after cancel, terminating";
        terminate();
        wait();
    }
}

void FastbootFlashThread::cancel()
{
    _cancelled.store(true);
    if (_compressedRing)
        _compressedRing->cancel();
    if (_decompressedRing)
        _decompressedRing->cancel();
}

void FastbootFlashThread::setImageCustomisation(const QByteArray &config,
                                                  const QByteArray &cmdline,
                                                  const QByteArray &firstrun,
                                                  const QByteArray &cloudinit,
                                                  const QByteArray &cloudinitNetwork,
                                                  const QByteArray &initFormat)
{
    _config = config;
    _cmdline = cmdline;
    _firstrun = firstrun;
    _cloudinit = cloudinit;
    _cloudinitNetwork = cloudinitNetwork;
    _initFormat = initFormat;
}

void FastbootFlashThread::setConnectRegistration(const QString &apiKey,
                                                  const QString &descriptionPrefix,
                                                  const QString &baseUrl)
{
    _connectApiKey = apiKey;
    _connectDescriptionPrefix = descriptionPrefix;
    _connectBaseUrl = baseUrl;
}

namespace {

// Map a target block-device path (as seen on the device while in
// fastboot mode) to the BOOT_ORDER nibble the bootloader uses for
// that storage class. Returns nullopt for paths we don't recognise
// (so the caller skips the EEPROM tweak rather than guessing).
std::optional<fastboot::pieeprom::BootSource>
blockDeviceToBootSource(const QString& blockDevice)
{
    using BS = fastboot::pieeprom::BootSource;
    // Compare against the last path component to ignore any leading
    // /dev/ prefix.
    QString name = blockDevice;
    int slash = name.lastIndexOf('/');
    if (slash >= 0) name = name.mid(slash + 1);

    if (name.startsWith("nvme",    Qt::CaseInsensitive)) return BS::Nvme;
    if (name.startsWith("sd",       Qt::CaseInsensitive)) return BS::UsbMsd;
    if (name.startsWith("mmcblk",   Qt::CaseInsensitive)) return BS::SdCard;
    return std::nullopt;
}

} // namespace

void FastbootFlashThread::registerWithConnect(fastboot::FastbootProtocol& fb,
                                               rpiboot::IUsbTransport& transport)
{
    if (_connectApiKey.isEmpty())
        return;

    emit preparationStatusUpdate(tr("Registering device identity with Raspberry Pi Connect..."));

    // Gather board identifiers for the Connect description field.
    QString boardDescription;
    if (auto boardVar = fb.getVar(transport, "product")) {
        boardDescription = QString::fromStdString(*boardVar);
    }
    QString serial;
    if (auto serialVar = fb.getVar(transport, "serialno")) {
        serial = QString::fromStdString(*serialVar);
    }

    ConnectDeviceRegistrar registrar(_connectApiKey, _connectDescriptionPrefix,
                                     _connectBaseUrl);
    auto result = registrar.registerDevice(fb, transport, boardDescription, serial);
    if (result.ok) {
        qDebug() << "Connect: device identity registered, id="
                 << result.deviceId;
    } else {
        qWarning() << "Connect: registration failed:"
                   << result.errorMessage;
    }
}

void FastbootFlashThread::applyBootOrderUpdate(fastboot::FastbootProtocol& fb,
                                                rpiboot::IUsbTransport& transport)
{
    // Decide which BOOT_ORDER nibble corresponds to the chosen target.
    auto sourceOpt = blockDeviceToBootSource(_blockDevice);
    if (!sourceOpt) {
        qDebug() << "EEPROM: skipping BOOT_ORDER update --- unrecognised target"
                 << _blockDevice;
        return;
    }
    const auto chosen = *sourceOpt;

    // Probe for EEPROM support on the device. Older rpi-fastbootd builds
    // don't expose these vars; treat absence as "no EEPROM update path".
    auto spidevVar = fb.getVar(transport, "eeprom-device");
    if (!spidevVar || *spidevVar == "not available") {
        qDebug() << "EEPROM: skipping BOOT_ORDER update --- device reports no SPI EEPROM"
                 << "(eeprom-device=" << (spidevVar ? QString::fromStdString(*spidevVar) : QStringLiteral("<missing>")) << ")";
        return;
    }
    const std::string spidev = *spidevVar;

    auto signedVar = fb.getVar(transport, "signed-eeprom");
    const bool isSigned = signedVar && *signedVar == "yes";

    // Pull the current image off the device so we edit the EXISTING
    // EEPROM (preserves the device's existing signed boot configuration,
    // bootcode, keys, etc. --- we only flip BOOT_ORDER).
    qDebug() << "EEPROM: reading current image from" << QString::fromStdString(spidev);
    auto image = fb.readEeprom(transport, spidev, nullptr, _cancelled);
    if (image.empty()) {
        qWarning() << "EEPROM: oem eeprom-read failed:"
                   << QString::fromStdString(fb.lastError())
                   << "--- leaving BOOT_ORDER unchanged";
        return;
    }

    fastboot::pieeprom::Image pe(std::move(image));
    if (auto err = pe.parse(); !err.empty()) {
        qWarning() << "EEPROM: failed to parse pieeprom from device:"
                   << QString::fromStdString(err)
                   << "--- leaving BOOT_ORDER unchanged";
        return;
    }

    auto bootconf = pe.readBootConfText();
    if (!bootconf) {
        qWarning() << "EEPROM: no bootconf.txt section in device image"
                   << "--- leaving BOOT_ORDER unchanged";
        return;
    }

    const uint32_t currentOrder = fastboot::pieeprom::parseBootOrder(*bootconf).value_or(0u);
    const uint32_t newOrder     = fastboot::pieeprom::composeBootOrder(currentOrder, chosen);
    if (newOrder == currentOrder) {
        qDebug() << "EEPROM: BOOT_ORDER already 0x" << QString::number(currentOrder, 16)
                 << "with"
                 << QString::fromLatin1(fastboot::pieeprom::bootSourceName(chosen).data(),
                                        static_cast<int>(fastboot::pieeprom::bootSourceName(chosen).size()))
                 << "first --- no update needed";
        return;
    }
    qDebug() << "EEPROM: BOOT_ORDER 0x" << QString::number(currentOrder, 16)
             << "->  0x" << QString::number(newOrder, 16)
             << "(chosen target:"
             << QString::fromLatin1(fastboot::pieeprom::bootSourceName(chosen).data(),
                                    static_cast<int>(fastboot::pieeprom::bootSourceName(chosen).size()))
             << ")";

    const std::string newBootconf = fastboot::pieeprom::setBootOrderLine(*bootconf, newOrder);
    if (auto err = pe.writeBootConfText(newBootconf); !err.empty()) {
        qWarning() << "EEPROM: failed to write new bootconf.txt:"
                   << QString::fromStdString(err);
        return;
    }

    // Signed-EEPROM boards refuse to boot if bootconf.sig doesn't match
    // bootconf.txt. Re-sign with the same customer key the imager
    // already uses for secure-boot bootcode. If no key is configured,
    // bail out rather than write an unverifiable image.
    if (isSigned) {
        QSettings settings;
        const QString keyPath = settings.value("secureboot_rsa_key").toString();
        if (keyPath.isEmpty() || !QFile::exists(keyPath)) {
            qWarning() << "EEPROM: signed-eeprom=yes but no usable secureboot_rsa_key in settings"
                       << "--- aborting BOOT_ORDER update to avoid bricking the device";
            return;
        }

        std::span<const uint8_t> bcSpan(
            reinterpret_cast<const uint8_t*>(newBootconf.data()),
            newBootconf.size());
        fastboot::EepromSignerConfig sigCfg;
        sigCfg.pemKeyPath = keyPath.toStdString();
        // Stamp the sig with the current build time so the device's
        // anti-rollback (if enabled) accepts the update.
        sigCfg.sourceDateEpoch = QDateTime::currentSecsSinceEpoch();
        auto sigRes = fastboot::buildEepromSig(bcSpan, sigCfg);
        if (!sigRes.ok) {
            qWarning() << "EEPROM: failed to sign bootconf.txt:"
                       << QString::fromStdString(sigRes.error)
                       << "--- aborting BOOT_ORDER update";
            return;
        }
        if (auto err = pe.writeBootConfSig(sigRes.sigBytes); !err.empty()) {
            qWarning() << "EEPROM: failed to embed bootconf.sig:"
                       << QString::fromStdString(err);
            return;
        }
        qDebug() << "EEPROM: re-signed bootconf.sig (" << sigRes.sigBytes.size() << "bytes)";
    }

    // Write back and verify. Both operations can take several seconds
    // on a real SPI flash.
    qDebug() << "EEPROM: writing updated image (" << pe.bytes().size() << "bytes)";
    if (!fb.updateEeprom(transport, std::span<const uint8_t>(pe.bytes()),
                          spidev, nullptr, _cancelled)) {
        qWarning() << "EEPROM: oem eeprom-update failed:"
                   << QString::fromStdString(fb.lastError());
        return;
    }
    if (!fb.verifyEeprom(transport, std::span<const uint8_t>(pe.bytes()),
                          spidev, nullptr, _cancelled)) {
        qWarning() << "EEPROM: oem eeprom-verify failed:"
                   << QString::fromStdString(fb.lastError());
        return;
    }
    qDebug() << "EEPROM: BOOT_ORDER update committed";
}

// Where text read back from the device ends.
//
// What comes back is what the device chose to send, and a read of a fixed
// size comes back padded -- with nought, or with the 0xFF of erased flash.
// Neither byte is whitespace, so trimmed() keeps both, and whatever is
// appended afterwards lands on the far side of the padding.
//
// Neither can occur in valid UTF-8, so the first of them ends the text.
static QByteArray textBeforePadding(const uint8_t *data, size_t size)
{
    QByteArray out(reinterpret_cast<const char *>(data),
                   static_cast<qsizetype>(size));
    for (qsizetype i = 0; i < out.size(); ++i) {
        const uchar b = static_cast<uchar>(out.at(i));
        if (b == 0x00 || b == 0xFF) {
            out.truncate(i);
            break;
        }
    }
    return out;
}

bool FastbootFlashThread::applyCustomisation(fastboot::FastbootProtocol& fb,
                                              rpiboot::IUsbTransport& transport)
{
    bool hasCustomisation = !_config.isEmpty() || !_cmdline.isEmpty() ||
                            !_firstrun.isEmpty() || !_cloudinit.isEmpty() ||
                            !_cloudinitNetwork.isEmpty();
    if (!hasCustomisation || _initFormat.isEmpty())
        return true;

    emit preparationStatusUpdate(tr("Applying OS customisation..."));
    qDebug() << "applyCustomisation: initFormat=" << _initFormat
             << "config=" << _config.size() << "bytes"
             << "cmdline=" << _cmdline.size() << "bytes"
             << "cloudinit=" << _cloudinit.size() << "bytes";

    // Mount the boot partition on the device so file I/O commands can
    // reach the filesystem we just flashed.
    static const std::string MOUNTPOINT = "/mnt/bootfs";
    std::string bootPartition = _blockDevice.toStdString() + "p1";

    if (!fb.mountDevice(transport, bootPartition, MOUNTPOINT, "vfat")) {
        emit error(tr("Failed to mount boot partition: %1")
                   .arg(QString::fromStdString(fb.lastError())));
        return false;
    }

    // All file paths are relative to the mountpoint
    static const std::string BOOT = MOUNTPOINT + "/";

    // Ensure umount happens even on early return
    auto umountGuard = qScopeGuard([&] {
        if (!fb.umountDevice(transport, MOUNTPOINT)) {
            qWarning() << "applyCustomisation: umount failed:"
                       << QString::fromStdString(fb.lastError());
        }
    });

    // Helper: QByteArray → span
    auto toSpan = [](const QByteArray& ba) {
        return std::span<const uint8_t>(
            reinterpret_cast<const uint8_t*>(ba.constData()),
            static_cast<size_t>(ba.size()));
    };

    // ── config.txt: read, uncomment/append entries, write back ──
    if (!_config.isEmpty()) {
        auto configData = fb.readDeviceFile(transport, BOOT + "config.txt", _cancelled);
        if (configData.empty()) {
            emit error(tr("Failed to read config.txt: %1")
                       .arg(QString::fromStdString(fb.lastError())));
            return false;
        }
        QByteArray config = textBeforePadding(configData.data(), configData.size());

        auto items = _config.split('\n');
        items.removeAll("");
        for (const QByteArray& item : std::as_const(items))
            config = mergeConfigTxtItem(config, item);

        if (!fb.writeDeviceFile(transport, BOOT + "config.txt", toSpan(config), _cancelled)) {
            emit error(tr("Failed to write config.txt: %1")
                       .arg(QString::fromStdString(fb.lastError())));
            return false;
        }
    }

    // ── firstrun.sh (systemd format) ──
    QByteArray cmdlineAppend = _cmdline;
    if (!_firstrun.isEmpty() && _initFormat == "systemd") {
        if (!fb.writeDeviceFile(transport, BOOT + "firstrun.sh", toSpan(_firstrun), _cancelled)) {
            emit error(tr("Failed to write firstrun.sh: %1")
                       .arg(QString::fromStdString(fb.lastError())));
            return false;
        }
        cmdlineAppend += rpi_cmdline::systemdFirstRun();
    }

    // ── rpi-preseed.toml (rpi-preseed format) ──
    // rpi-preseed applies /boot/firmware/rpi-preseed.toml on first boot; its
    // units are gated on the file's presence, so no cmdline entry is required.
    if (!_firstrun.isEmpty() && _initFormat == "rpi-preseed") {
        if (!fb.writeDeviceFile(transport, BOOT + "rpi-preseed.toml", toSpan(_firstrun), _cancelled)) {
            emit error(tr("Failed to write rpi-preseed.toml: %1")
                       .arg(QString::fromStdString(fb.lastError())));
            return false;
        }
    }

    // ── cloud-init files ──
    // Only write meta-data and the ds=nocloud cmdline when there is actual
    // cloud-init content.  A stale cmdline entry (e.g. recommendedWifiCountry)
    // alone should not trigger cloud-init file writes.
    bool initCloud = (_initFormat == "cloudinit" || _initFormat == "cloudinit-rpi");
    bool hasCloudContent = !_cloudinit.isEmpty() || !_cloudinitNetwork.isEmpty();
    if (initCloud && hasCloudContent) {
        const QByteArray instanceId = rpi_cmdline::newInstanceId();
        const QByteArray metadata = rpi_cmdline::nocloudMetaData(instanceId);
        if (!fb.writeDeviceFile(transport, BOOT + "meta-data", toSpan(metadata), _cancelled)) {
            emit error(tr("Failed to write meta-data: %1")
                       .arg(QString::fromStdString(fb.lastError())));
            return false;
        }

        cmdlineAppend += rpi_cmdline::nocloudDatasource(instanceId);

        if (!_cloudinit.isEmpty()) {
            QByteArray userData = "#cloud-config\n" + _cloudinit;
            if (!fb.writeDeviceFile(transport, BOOT + "user-data", toSpan(userData), _cancelled)) {
                emit error(tr("Failed to write user-data: %1")
                           .arg(QString::fromStdString(fb.lastError())));
                return false;
            }
        }

        if (!_cloudinitNetwork.isEmpty()) {
            if (!fb.writeDeviceFile(transport, BOOT + "network-config",
                                     toSpan(_cloudinitNetwork), _cancelled)) {
                emit error(tr("Failed to write network-config: %1")
                           .arg(QString::fromStdString(fb.lastError())));
                return false;
            }
        }
    }

    // ── cmdline.txt: read, append, write back ──
    if (!cmdlineAppend.isEmpty()) {
        auto cmdlineData = fb.readDeviceFile(transport, BOOT + "cmdline.txt", _cancelled);
        if (cmdlineData.empty()) {
            emit error(tr("Failed to read cmdline.txt: %1")
                       .arg(QString::fromStdString(fb.lastError())));
            return false;
        }
        // The kernel reads its command line up to the first NUL, so anything
        // appended past the device's padding is not wrong but absent: the Pi
        // boots, the settings are simply not in effect, and nothing says so.
        // systemd.run=/boot/firstrun.sh is appended here, so the whole of
        // first-boot customisation would go the same way.
        QByteArray cmdline =
            textBeforePadding(cmdlineData.data(), cmdlineData.size()).trimmed();
        cmdline += cmdlineAppend;

        if (!fb.writeDeviceFile(transport, BOOT + "cmdline.txt", toSpan(cmdline), _cancelled)) {
            emit error(tr("Failed to write cmdline.txt: %1")
                       .arg(QString::fromStdString(fb.lastError())));
            return false;
        }
    }

    qDebug() << "FastbootFlashThread: customisation applied successfully";
    return true;
}

// ── Curl write callback → compressed ring buffer ─────────────────────
struct CurlWriteContext {
    RingBuffer* ring;
    RingBuffer::Slot* currentSlot;
    size_t slotOffset;
    std::atomic<bool>* cancelled;
};

static size_t curlWriteToRing(char *ptr, size_t size, size_t nmemb, void *userdata)
{
    auto *ctx = static_cast<CurlWriteContext*>(userdata);
    size_t totalSize = size * nmemb;
    size_t offset = 0;

    while (offset < totalSize) {
        if (ctx->cancelled->load())
            return 0;  // Abort transfer

        // Acquire a slot if we don't have one
        if (!ctx->currentSlot) {
            ctx->currentSlot = ctx->ring->acquireWriteSlot(100);
            if (!ctx->currentSlot) {
                if (ctx->ring->isCancelled() || ctx->cancelled->load())
                    return 0;
                continue;  // Retry
            }
            ctx->slotOffset = 0;
        }

        // Fill the current slot
        size_t space = ctx->currentSlot->capacity - ctx->slotOffset;
        size_t chunk = std::min(totalSize - offset, space);
        memcpy(ctx->currentSlot->data + ctx->slotOffset, ptr + offset, chunk);
        ctx->slotOffset += chunk;
        offset += chunk;

        // Commit if full
        if (ctx->slotOffset >= ctx->currentSlot->capacity) {
            ctx->ring->commitWriteSlot(ctx->currentSlot, ctx->slotOffset);
            ctx->currentSlot = nullptr;
            ctx->slotOffset = 0;
        }
    }

    return totalSize;
}

// ── Curl progress callback ───────────────────────────────────────────
struct CurlProgressContext {
    std::atomic<quint64>* dlnow;
    std::atomic<quint64>* dltotal;
    std::atomic<bool>* cancelled;
};

static int curlProgressCallback(void *clientp, curl_off_t dltotal, curl_off_t dlnow,
                                 curl_off_t /*ultotal*/, curl_off_t /*ulnow*/)
{
    auto *ctx = static_cast<CurlProgressContext*>(clientp);
    if (ctx->cancelled->load())
        return 1;  // Abort
    ctx->dlnow->store(static_cast<quint64>(dlnow));
    ctx->dltotal->store(static_cast<quint64>(dltotal));
    return 0;
}

// ── Thread 1: Download producer ──────────────────────────────────────
void FastbootFlashThread::downloadProducer()
{
    CURL *curl = curl_easy_init();
    if (!curl) {
        _downloadError = tr("Failed to initialize curl");
        _compressedRing->cancel();
        return;
    }

    char errorBuffer[CURL_ERROR_SIZE] = {0};
    CurlNetworkConfig::instance().applyCurlSettings(
        curl, CurlNetworkConfig::FetchProfile::LargeFile, errorBuffer);

    QByteArray urlBytes = _imageUrl.toEncoded();
    curl_easy_setopt(curl, CURLOPT_URL, urlBytes.constData());

    CurlWriteContext writeCtx{_compressedRing.get(), nullptr, 0, &_cancelled};
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, curlWriteToRing);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &writeCtx);

    CurlProgressContext progressCtx{&_dlnow, &_dltotal, &_cancelled};
    curl_easy_setopt(curl, CURLOPT_XFERINFOFUNCTION, curlProgressCallback);
    curl_easy_setopt(curl, CURLOPT_XFERINFODATA, &progressCtx);
    curl_easy_setopt(curl, CURLOPT_NOPROGRESS, 0L);

    CURLcode res = curl_easy_perform(curl);

    // Commit any partially-filled slot
    if (writeCtx.currentSlot && writeCtx.slotOffset > 0) {
        _compressedRing->commitWriteSlot(writeCtx.currentSlot, writeCtx.slotOffset);
    }

    curl_easy_cleanup(curl);

    if (_cancelled.load()) {
        _compressedRing->cancel();
        return;
    }

    if (res != CURLE_OK) {
        _downloadError = errorBuffer[0]
            ? QString::fromUtf8(errorBuffer)
            : QString::fromUtf8(curl_easy_strerror(res));
        _compressedRing->cancel();
        return;
    }

    _compressedRing->producerDone();
}

// ── libarchive read callback ← compressed ring buffer ────────────────
struct ArchiveReadContext {
    RingBuffer* ring;
    RingBuffer::Slot* currentSlot;
};

static ssize_t archiveReadFromRing(struct archive *a, void *clientData, const void **buffer)
{
    auto *ctx = static_cast<ArchiveReadContext*>(clientData);

    // Release previous slot
    if (ctx->currentSlot) {
        ctx->ring->releaseReadSlot(ctx->currentSlot);
        ctx->currentSlot = nullptr;
    }

    // Acquire next slot
    ctx->currentSlot = ctx->ring->acquireReadSlot(100);
    while (!ctx->currentSlot && !ctx->ring->isCancelled() && !ctx->ring->isComplete()
           && !ctx->ring->isStallTimeoutExceeded()) {
        ctx->currentSlot = ctx->ring->acquireReadSlot(100);
    }

    if (!ctx->currentSlot) {
        *buffer = nullptr;
        // A stall is not the end of the archive. Reporting EOF would hand
        // libarchive a truncated image and let the flash run on to the hash
        // check with no idea the download had stopped -- and a stalled buffer
        // refuses without waiting, so the loop above would spin flat out
        // rather than block.
        if (ctx->ring->isStallTimeoutExceeded()) {
            archive_set_error(a, EIO, "Download stalled: no data received for 90 seconds");
            return -1;
        }
        return 0;  // EOF or cancelled
    }

    *buffer = ctx->currentSlot->data;
    return static_cast<ssize_t>(ctx->currentSlot->size);
}

static int archiveCloseRing(struct archive *, void *clientData)
{
    auto *ctx = static_cast<ArchiveReadContext*>(clientData);
    if (ctx->currentSlot) {
        ctx->ring->releaseReadSlot(ctx->currentSlot);
        ctx->currentSlot = nullptr;
    }
    return ARCHIVE_OK;
}

// ── Thread 2: Decompress consumer/producer ───────────────────────────
void FastbootFlashThread::decompressConsumerProducer()
{
    struct archive *a = archive_read_new();
    archive_read_support_filter_all(a);
    archive_read_support_format_raw(a);
    archive_read_support_format_all(a);

    ArchiveReadContext readCtx{_compressedRing.get(), nullptr};

    int r = archive_read_open(a, &readCtx, nullptr, archiveReadFromRing, archiveCloseRing);
    if (r != ARCHIVE_OK) {
        _decompressError = QString::fromUtf8(archive_error_string(a));
        archive_read_free(a);
        _decompressedRing->cancel();
        return;
    }

    struct archive_entry *entry;
    if (archive_read_next_header(a, &entry) != ARCHIVE_OK) {
        _decompressError = tr("No entries in image archive");
        archive_read_free(a);
        _decompressedRing->cancel();
        return;
    }

    // Read decompressed data and push into the decompressed ring buffer
    const void *buff;
    size_t size;
    la_int64_t offset;
    int readResult;
    while ((readResult = archive_read_data_block(a, &buff, &size, &offset)) == ARCHIVE_OK) {
        if (_cancelled.load())
            break;

        // Push decompressed data into the output ring in slot-sized chunks
        size_t pos = 0;
        while (pos < size && !_cancelled.load()) {
            auto *slot = _decompressedRing->acquireWriteSlot(100);
            if (!slot) {
                if (_decompressedRing->isCancelled() || _cancelled.load())
                    break;
                if (_decompressedRing->isStallTimeoutExceeded()) {
                    // The consumer has not freed a slot in the stall window.
                    // Spinning here would burn a core for as long as the flash
                    // ran; carrying on would decompress into nothing.
                    _decompressError = tr("Writing stalled: the device stopped "
                                          "accepting data.");
                    _decompressedRing->cancel();
                    break;
                }
                continue;
            }

            size_t chunk = std::min(size - pos, slot->capacity);
            memcpy(slot->data, static_cast<const char*>(buff) + pos, chunk);
            _decompressedRing->commitWriteSlot(slot, chunk);
            pos += chunk;
        }
    }

    // Only ARCHIVE_EOF means the image ended; anything else means it stopped.
    //
    // The loop exited on the first non-OK return whatever it was, and
    // producerDone() then told the consumer the stream had finished
    // normally. A truncated download or a zip whose CRC does not match was
    // therefore flashed as far as it went and the write completed. An image
    // from the catalogue is caught afterwards by the hash, but one supplied
    // without a hash is not, and even with one the user is told the hash
    // mismatched rather than that the download was corrupt.
    if (!_cancelled.load() && readResult != ARCHIVE_EOF) {
        const char *why = archive_error_string(a);
        _decompressError = why ? QString::fromUtf8(why)
                               : tr("The image data ended unexpectedly.");
        archive_read_free(a);
        _decompressedRing->cancel();
        return;
    }

    archive_read_free(a);

    if (_cancelled.load()) {
        _decompressedRing->cancel();
        return;
    }

    _decompressedRing->producerDone();
}

// ── Main thread: Flash consumer ──────────────────────────────────────
void FastbootFlashThread::run()
{
    try {
        runImpl();
    } catch (const std::exception& e) {
        qCritical() << "FastbootFlashThread: uncaught exception:" << e.what();
        emit error(tr("Fastboot error: %1").arg(QString::fromUtf8(e.what())));
    } catch (...) {
        qCritical() << "FastbootFlashThread: unknown uncaught exception";
        emit error(tr("Fastboot error: unexpected internal error"));
    }
}

bool FastbootFlashThread::isEraseOperation() const
{
    return _imageUrl.toString() == QLatin1String("internal://format");
}

bool FastbootFlashThread::performErase(fastboot::FastbootProtocol& fb,
                                        rpiboot::IUsbTransport& transport)
{
    // The block device is the whole disk (e.g. "mmcblk0"); the flash path
    // targets it directly and mounts "<dev>p1", so no partition suffix here.
    const std::string dev = _blockDevice.toStdString();

    // Every step below is destructive, so cancellation is checked before and
    // after each one: a cancel landing between two commands must not let the
    // next one run, and must never reach emit success().
    auto stopIfCancelled = [this]() {
        if (!_cancelled.load())
            return false;
        emit error(tr("Cancelled"));
        return true;
    };

    if (stopIfCancelled())
        return false;

    // 1. Bare wipe of the whole device. The daemon's erase handler calls
    //    wipe_block_device(), which issues BLKDISCARD (near-instant on eMMC
    //    that supports it) or falls back to zeroing the device — which can
    //    take minutes on a large eMMC — so give it a generous timeout.
    emit preparationStatusUpdate(tr("Erasing storage device..."));
    qDebug() << "FastbootFlashThread: erase:" << QString::fromStdString(dev);
    auto resp = fb.sendCommand(transport, "erase:" + dev, 600000);
    if (stopIfCancelled()) {
        return false;
    }
    if (resp.type != fastboot::Response::Okay) {
        emit error(tr("Failed to erase device: %1")
                   .arg(QString::fromStdString(resp.message)));
        return false;
    }

    // 2. Write a fresh MBR (msdos) partition table.
    emit preparationStatusUpdate(tr("Writing partition table..."));
    qDebug() << "FastbootFlashThread: oem partinit" << QString::fromStdString(dev) << "dos";
    resp = fb.sendCommand(transport, "oem partinit " + dev + " dos", 60000);
    if (stopIfCancelled()) {
        return false;
    }
    if (resp.type != fastboot::Response::Okay) {
        emit error(tr("Failed to write partition table: %1")
                   .arg(QString::fromStdString(resp.message)));
        return false;
    }

    // 3. Append a single FAT32-LBA partition spanning the whole device.
    //    'c' is parsed as hex 0x0c (FAT32 LBA — matching DiskFormatter's
    //    partition type) by the daemon's partapp handler; omitting the size
    //    consumes all remaining space, and the daemon aligns the start to
    //    4 MiB. This only writes the partition *entry* — rpi-fastbootd has
    //    no mkfs, so the partition is typed FAT32 but has no filesystem.
    emit preparationStatusUpdate(tr("Creating FAT32 partition..."));
    qDebug() << "FastbootFlashThread: oem partapp" << QString::fromStdString(dev) << "c";
    resp = fb.sendCommand(transport, "oem partapp " + dev + " c", 60000);
    if (stopIfCancelled()) {
        return false;
    }
    if (resp.type != fastboot::Response::Okay) {
        emit error(tr("Failed to create partition: %1")
                   .arg(QString::fromStdString(resp.message)));
        return false;
    }

    // 4. Reboot out of fastboot mode.
    emit finalizing();
    resp = fb.sendCommand(transport, "reboot", 10000);
    if (resp.type != fastboot::Response::Okay) {
        qDebug() << "FastbootFlashThread: reboot command returned:"
                 << QString::fromStdString(resp.message);
        // Non-fatal — the erase + partitioning already succeeded.
    }

    qDebug() << "FastbootFlashThread: erase complete for" << QString::fromStdString(dev);
    emit success();
    return true;
}

std::unique_ptr<rpiboot::IUsbTransport> FastbootFlashThread::openFastbootTransport(
    rpiboot::LibusbContext& ctx, const rpiboot::UsbDeviceInfo& target)
{
    return ctx.openDevice(target);
}

void FastbootFlashThread::runImpl()
{
    emit preparationStatusUpdate(tr("Connecting to fastboot device..."));

    // 1. Open the fastboot USB device
    QElapsedTimer deviceOpenTimer;
    deviceOpenTimer.start();

    rpiboot::LibusbContext ctx;
    std::unique_ptr<rpiboot::IUsbTransport> transport;

    rpiboot::UsbDeviceInfo targetInfo{};
    targetInfo.vendorId = FASTBOOT_VID;
    targetInfo.productId = FASTBOOT_PID;

    // Parse bus:addr from _fastbootId
    auto parts = _fastbootId.split(':');
    if (parts.size() >= 2) {
        targetInfo.busNumber = static_cast<uint8_t>(parts[0].toUInt());
        targetInfo.deviceAddress = static_cast<uint8_t>(parts[1].toUInt());
    }

    transport = openFastbootTransport(ctx, targetInfo);
    if (!transport || !transport->isOpen()) {
        emit eventFastbootDeviceOpen(static_cast<quint32>(deviceOpenTimer.elapsed()), false, _fastbootId);
        emit error(tr("Failed to open fastboot device: %1").arg(_fastbootId));
        return;
    }

    fastboot::FastbootProtocol fb;

    // Safety gate: refuse to touch anything that is not a genuine
    // rpi-fastbootd gadget. The device matched only on the 18d1:4e40 VID/PID
    // the gadget borrows from Google, so verify its identity before issuing
    // any destructive command (erase / partition / flash). identifyRpiFastboot()
    // checks the authoritative USB interface descriptor ("fastbootd-provisioner")
    // and falls back to the RPi-specific block-devices getvar. This ensures a
    // non-Pi device in a colliding fastboot mode can never be written to,
    // even if it somehow reached this point.
    //
    // Only a positive confirmation is good enough here: an inconclusive probe
    // means we do not know what this device is, and "unknown" must never be
    // enough to start erasing it.
    if (fb.identifyRpiFastboot(*transport) != fastboot::RpiIdentity::ConfirmedPi) {
        emit error(tr("Refusing to flash %1: the device did not identify as a "
                      "Raspberry Pi fastboot device.").arg(_fastbootId));
        return;
    }

    // Special case: the "Erase" OS-list entry carries no image. Wipe the
    // device and write a fresh partition table instead of running the
    // download/decompress/flash pipeline.
    if (isEraseOperation()) {
        emit eventFastbootDeviceOpen(static_cast<quint32>(deviceOpenTimer.elapsed()), true,
                                     QStringLiteral("erase"));
        performErase(fb, *transport);
        return;
    }

    // 2. Query max-download-size
    auto maxDlSizeStr = fb.getVar(*transport, "max-download-size");
    const quint64 availableBytes =
        static_cast<quint64>(std::max<qint64>(
            SystemMemoryManager::instance().getAvailableMemoryMB(), 0)) * 1024 * 1024;
    const uint32_t maxDownloadSize = resolveMaxDownloadSize(
        maxDlSizeStr ? &*maxDlSizeStr : nullptr, availableBytes);
    qDebug() << "FastbootFlashThread: max-download-size ="
             << (maxDlSizeStr ? QString::fromStdString(*maxDlSizeStr)
                              : QStringLiteral("(not reported)"))
             << "-> using" << maxDownloadSize;
    emit eventFastbootDeviceOpen(static_cast<quint32>(deviceOpenTimer.elapsed()), true,
                                 QStringLiteral("max-download-size=%1").arg(maxDownloadSize));

    // 3. Allocate ring buffers
    size_t inputSlotSize, writeSlotSize, inputSlots, writeSlots;
    SystemMemoryManager::instance().getCoordinatedRingBufferConfig(
        1024 * 1024,   // 1MB input slot hint (compressed data)
        16 * 1024 * 1024, // 16MB write slot hint (fastboot download unit)
        inputSlots, writeSlots,
        inputSlotSize, writeSlotSize);

    // Both rings go idle for as long as one sparse segment takes to send: the
    // consumer holds its slot across the whole fastboot download and the
    // device's commit of it, and the decompressor backs up behind that. See
    // TimeoutDefaults::kRingBufferStallTimeoutMs for why the window allows for
    // it.
    _compressedRing = std::make_unique<RingBuffer>(inputSlots, inputSlotSize);
    _decompressedRing = std::make_unique<RingBuffer>(writeSlots, writeSlotSize);

    // 4. Initialize incremental hash if verification is needed
    if (!_expectedHash.isEmpty())
        _imageHash = std::make_unique<AcceleratedCryptographicHash>(QCryptographicHash::Sha256);

    // 5. Start pipeline threads
    emit writing();
    emit preparationStatusUpdate(tr("Downloading and flashing OS image..."));

    std::thread downloadThread([this]() { downloadProducer(); });
    std::thread decompressThread([this]() { decompressConsumerProducer(); });

    // 6. Flash consumer loop — sparse-encode and stream to device
    //
    // The sparse encoder converts the raw decompressed image into Android
    // sparse image segments.  When a bmap is available, unmapped blocks
    // become DONT_CARE (skipped entirely).  Otherwise zero-filled regions
    // are FILL(0) to guarantee correctness on non-erased storage.
    fastboot::SparseEncoder sparse(maxDownloadSize, _extractLen);

    // Fetch and apply optional block map
    if (!_bmapUrl.isEmpty()) {
        emit preparationStatusUpdate(tr("Fetching block map..."));
        qDebug() << "FastbootFlashThread: fetching bmap from" << _bmapUrl;

        QByteArray bmapData;
        {
            // Synchronous fetch — bmap files are tiny (few KB)
            CURL *curl = curl_easy_init();
            if (curl) {
                std::string responseData;
                auto writeCallback = +[](char *ptr, size_t size, size_t nmemb, void *userdata) -> size_t {
                    auto *resp = static_cast<std::string*>(userdata);
                    resp->append(ptr, size * nmemb);
                    return size * nmemb;
                };
                // The same settings every other fetch in the tree gets. Set
                // by hand, this one had no proxy, no user agent, no CA
                // bundle, no redirect protocol restriction and no size
                // limit -- so behind a proxy it was the one request that
                // could not get out, and "bmap files are tiny" was a
                // comment rather than anything enforced.
                CurlNetworkConfig::instance().applyCurlSettings(
                    curl, CurlNetworkConfig::FetchProfile::SmallFile);
                curl_easy_setopt(curl, CURLOPT_URL, _bmapUrl.toString().toUtf8().constData());
                curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, writeCallback);
                curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseData);
                // Tighter than the profile's sixty: nothing here is worth
                // holding the write up for a minute.
                curl_easy_setopt(curl, CURLOPT_TIMEOUT, 30L);
                CURLcode res = curl_easy_perform(curl);
                curl_easy_cleanup(curl);

                if (res == CURLE_OK)
                    bmapData = QByteArray::fromStdString(responseData);
                else
                    qWarning() << "FastbootFlashThread: bmap fetch failed:" << curl_easy_strerror(res);
            }
        }

        if (!bmapData.isEmpty()) {
            auto blockMap = std::make_unique<fastboot::BlockMap>();
            std::string parseError;
            if (blockMap->parse(std::string_view(bmapData.constData(), bmapData.size()), &parseError)) {
                qDebug() << "FastbootFlashThread: bmap loaded —"
                         << blockMap->mappedBlockCount() << "of"
                         << blockMap->blockCount() << "blocks mapped ("
                         << (100 * blockMap->mappedBlockCount() / std::max<uint64_t>(blockMap->blockCount(), 1))
                         << "%)";
                sparse.setBlockMap(std::move(blockMap));
            } else {
                qWarning() << "FastbootFlashThread: bmap parse failed:" << QString::fromStdString(parseError);
            }
        }
    }
    quint64 totalFed = 0;
    bool flashError = false;

    // Helper: send one sparse segment via download + flash
    uint32_t segmentIndex = 0;
    auto sendSegment = [&](std::span<const uint8_t> seg) -> bool {
        rpiboot::ProgressCallback progressCb = [this, totalFed](
            uint64_t current, uint64_t /*total*/, const std::string&) {
            emit writeProgress(totalFed,
                               _extractLen > 0 ? _extractLen : totalFed);
        };

        qDebug() << "FastbootFlashThread: downloading segment" << segmentIndex
                 << "(" << seg.size() << "bytes)";

        if (!fb.download(*transport, seg, progressCb, _cancelled)) {
            qDebug() << "FastbootFlashThread: download FAILED for segment"
                     << segmentIndex << ":" << QString::fromStdString(fb.lastError());
            if (!_cancelled.load())
                emit error(tr("Fastboot download failed: %1")
                           .arg(QString::fromStdString(fb.lastError())));
            return false;
        }

        qDebug() << "FastbootFlashThread: flashing segment" << segmentIndex;
        if (!fb.flash(*transport, _blockDevice.toStdString(), 120000)) {
            qDebug() << "FastbootFlashThread: flash FAILED for segment"
                     << segmentIndex << ":" << QString::fromStdString(fb.lastError());
            if (!_cancelled.load())
                emit error(tr("Fastboot flash failed: %1")
                           .arg(QString::fromStdString(fb.lastError())));
            return false;
        }

        qDebug() << "FastbootFlashThread: segment" << segmentIndex << "OK";
        ++segmentIndex;
        return true;
    };

    while (!_cancelled.load()) {
        auto *slot = _decompressedRing->acquireReadSlot(100);
        if (!slot) {
            if (_decompressedRing->isCancelled())
                break;
            if (_decompressedRing->isComplete())
                break;
            if (_decompressedRing->isStallTimeoutExceeded()) {
                // Same reasoning as the archive callback: continuing here
                // would spin, and breaking quietly would finish the sparse
                // stream as though the image ended where the stall began.
                emit error(tr("Writing has stalled.\n\n"
                              "No progress for 90 seconds. This could be caused by:\n"
                              "\u2022 The USB connection to the device being interrupted\n"
                              "\u2022 The device becoming unresponsive\n"
                              "\u2022 Network connection lost while downloading\n\n"
                              "Please check the connection and try again."));
                flashError = true;
                break;
            }
            continue;
        }

        // Incremental hash on raw decompressed data (before sparse encoding)
        if (_imageHash)
            _imageHash->addData(slot->data, static_cast<int>(slot->size));

        totalFed += slot->size;

        // Feed data to the sparse encoder, draining completed segments
        // as they appear.  feed() returns fewer bytes than offered when
        // a segment is ready, so we loop until all data is consumed.
        const auto* feedPtr = reinterpret_cast<const uint8_t*>(slot->data);
        size_t feedRemaining = slot->size;
        while (feedRemaining > 0 && !flashError) {
            size_t consumed = sparse.feed(feedPtr, feedRemaining);
            feedPtr += consumed;
            feedRemaining -= consumed;

            fastboot::SparseEncoder::SegmentStats segStats;
            auto seg = sparse.takeSegment(&segStats);
            if (!seg.empty()) {
                qDebug() << "FastbootFlashThread: segment" << segmentIndex
                         << "blocks=" << segStats.blocks
                         << "(raw=" << segStats.rawBlocks
                         << "fill=" << segStats.fillBlocks
                         << "skip=" << segStats.dontCareBlocks << ")"
                         << "chunks=" << segStats.chunks
                         << "wire=" << segStats.wireBytes << "bytes";
                if (!sendSegment(seg)) {
                    flashError = true;
                } else {
                    emit writeProgress(totalFed,
                                       _extractLen > 0 ? _extractLen : totalFed);
                    emit downloadProgress(_dlnow.load(), _dltotal.load());
                }
            }
        }
        _decompressedRing->releaseReadSlot(slot);

        if (flashError)
            break;
    }

    // Finish the sparse stream and drain all remaining segments.
    // finish() may need multiple calls when the trailing partial block
    // triggers a segment split.
    while (!flashError && !_cancelled.load()) {
        sparse.finish();
        fastboot::SparseEncoder::SegmentStats segStats;
        auto seg = sparse.takeSegment(&segStats);
        if (seg.empty())
            break;
        qDebug() << "FastbootFlashThread: final segment" << segmentIndex
                 << "blocks=" << segStats.blocks
                 << "(raw=" << segStats.rawBlocks
                 << "fill=" << segStats.fillBlocks
                 << "skip=" << segStats.dontCareBlocks << ")"
                 << "wire=" << segStats.wireBytes << "bytes";
        if (!sendSegment(seg))
            flashError = true;
    }

    if (!flashError && !_cancelled.load()) {
        qDebug() << "Sparse stats: raw=" << sparse.rawBlockCount()
                 << "fill=" << sparse.fillBlockCount()
                 << "dontcare=" << sparse.dontCareBlockCount()
                 << "total=" << sparse.totalBlocksProcessed();
    }

    qDebug() << "FastbootFlashThread: flash loop ended —"
             << "flashError=" << flashError
             << "cancelled=" << _cancelled.load()
             << "totalFed=" << totalFed
             << "segments=" << segmentIndex;

    // 7. Wait for pipeline threads to finish
    if (_cancelled.load()) {
        _compressedRing->cancel();
        _decompressedRing->cancel();
    }

    downloadThread.join();
    decompressThread.join();

    // Check for pipeline errors
    if (!_downloadError.isEmpty() && !_cancelled.load()) {
        emit error(tr("Download failed: %1").arg(_downloadError));
        return;
    }
    if (!_decompressError.isEmpty() && !_cancelled.load()) {
        emit error(tr("Decompression failed: %1").arg(_decompressError));
        return;
    }

    if (_cancelled.load()) {
        emit error(tr("Cancelled"));
        return;
    }

    // A flash error was already reported via error() from sendSegment().
    // Do not fall through to hash verification / customisation / success().
    if (flashError)
        return;

    // 8. Verify hash
    if (_imageHash) {
        QByteArray actualHash = _imageHash->result().toHex();
        if (actualHash != _expectedHash) {
            emit error(tr("Image hash mismatch. Expected: %1 Got: %2")
                       .arg(QString::fromLatin1(_expectedHash),
                            QString::fromLatin1(actualHash)));
            return;
        }
    }

    // 9. Apply OS customisation via fastboot file transfer
    qDebug() << "FastbootFlashThread: applying OS customisation...";
    if (!applyCustomisation(fb, *transport)) {
        qDebug() << "FastbootFlashThread: customisation FAILED";
        return;
    }
    qDebug() << "FastbootFlashThread: customisation OK";

    // 10. Register device identity with Raspberry Pi Connect (optional,
    //     non-fatal).  Must happen while the device is still in fastboot
    //     mode so we can query its public key and ask it to sign the
    //     request via the firmware crypto engine.
    registerWithConnect(fb, *transport);

    // 11. Best-effort: nudge BOOT_ORDER so the device boots from the
    //     storage we just wrote. Logs and continues on failure --- the
    //     image is already written, so we don't want to fail the whole
    //     run on an EEPROM-side issue.
    applyBootOrderUpdate(fb, *transport);

    // 12. Finalize
    emit finalizing();

    auto resp = fb.sendCommand(*transport, "reboot", 10000);
    if (resp.type != fastboot::Response::Okay) {
        qDebug() << "FastbootFlashThread: reboot command returned:"
                 << QString::fromStdString(resp.message);
        // Non-fatal — flash succeeded even if reboot fails
    }

    qDebug() << "FastbootFlashThread: flash complete, total" << totalFed << "bytes";
    emit success();
}
