/*
 * SPDX-License-Identifier: Apache-2.0
 * Copyright (C) 2022 Raspberry Pi Ltd
 */

#include "devicewrapper.h"
#include "devicewrapperblockcacheentry.h"
#include "devicewrapperstructs.h"
#include "devicewrapperfatpartition.h"
#include <QDebug>

DeviceWrapper::DeviceWrapper(rpi_imager::FileOperations *file_ops, QObject *parent)
    : QObject(parent), _dirty(false), _file_ops(file_ops)
{

}

DeviceWrapper::~DeviceWrapper()
{
    /* sync() throws on a write or flush failure, and a destructor is implicitly
       noexcept — letting that escape calls std::terminate(). A card reader that
       disappeared mid-write is exactly the case that makes the final flush fail,
       so kill the process there and the user loses the error dialog too. Callers
       that need to know a flush failed call sync() explicitly. */
    try {
        sync();
    } catch (const std::exception &err) {
        qDebug() << "DeviceWrapper: sync() failed during destruction:" << err.what();
    }
}

void DeviceWrapper::_seekToBlock(quint64 blockNr)
{
    auto result = _file_ops->Seek(blockNr * 4096);
    if (result != rpi_imager::FileError::kSuccess) {
        throw std::runtime_error("Error seeking device");
    }
}

void DeviceWrapper::sync()
{
    if (!_dirty)
        return;

    const auto blockNrs = _blockcache.keys();
    for (auto blockNr : blockNrs)
    {
        if (blockNr == 0)
            continue; /* Save writing first block with MBR for last */

        auto block = _blockcache.value(blockNr);

        if (!block->dirty)
            continue;

        _seekToBlock(blockNr);
        auto result = _file_ops->WriteSequential(reinterpret_cast<const std::uint8_t*>(block->block), 4096);
        if (result != rpi_imager::FileError::kSuccess) {
            throw std::runtime_error("Error writing to device");
        }
        block->dirty = false;
    }

    if (_blockcache.contains(0))
    {
        /* Write first block with MBR */
        auto block = _blockcache.value(0);

        if (block->dirty)
        {
            /* Force every preceding filesystem write to physical media BEFORE the
             * MBR/partition table becomes visible. On USB card readers the bridge
             * or card write-cache can reorder writes, so without this flush the MBR
             * (block 0) can reach the media ahead of the FAT blocks written above.
             * Windows then sees a partition whose filesystem is still incomplete and
             * pops "You need to format the disk in drive X:" mid-write — especially
             * when Explorer is already watching the drive. Flushing here guarantees
             * the partition only appears once its contents are durably on media.
             * (This is why the bug reproduces on real card readers but never on a
             * virtual disk, which has no reordering write-cache.) A device that does
             * not support flush returns success from Flush(), so this is a no-op there.
             * Crash-safe: unlike disabling AutoMount, this touches no global OS state. */
            auto flushResult = _file_ops->Flush();
            if (flushResult != rpi_imager::FileError::kSuccess) {
                throw std::runtime_error("Error flushing filesystem to device before writing MBR");
            }

            _seekToBlock(0);
            auto result = _file_ops->WriteSequential(reinterpret_cast<const std::uint8_t*>(block->block), 4096);
            if (result != rpi_imager::FileError::kSuccess) {
                throw std::runtime_error("Error writing MBR to device");
            }
            block->dirty = false;

            /* And flush the MBR itself so the now-complete partition is durable. */
            _file_ops->Flush();
        }
    }

    _dirty = false;
}

void DeviceWrapper::_readIntoBlockCacheIfNeeded(quint64 offset, quint64 size)
{
    if (!size)
        return;

    quint64 firstBlock = offset/4096;
    quint64 lastBlock = (offset+size)/4096;

    for (auto i = firstBlock; i <= lastBlock; i++)
    {
        if (!_blockcache.contains(i))
        {
            _seekToBlock(i);

            auto cacheEntry = new DeviceWrapperBlockCacheEntry(this);
            std::size_t bytes_read = 0;
            auto result = _file_ops->ReadSequential(reinterpret_cast<std::uint8_t*>(cacheEntry->block), 4096, bytes_read);
            if (result != rpi_imager::FileError::kSuccess || bytes_read != 4096) {
                throw std::runtime_error("Error reading from device");
            }
            _blockcache.insert(i, cacheEntry);
        }
    }
}

void DeviceWrapper::pread(char *buf, quint64 size, quint64 offset)
{
    if (!size)
        return;

    _readIntoBlockCacheIfNeeded(offset, size);
    quint64 firstBlock = offset / 4096;
    quint64 offsetInBlock = offset % 4096;

    for (auto i = firstBlock; size; i++)
    {
        auto block = _blockcache.value(i);
        size_t bytesToCopyFromBlock = qMin(4096-offsetInBlock, size);
        memcpy(buf, block->block + offsetInBlock, bytesToCopyFromBlock);

        buf  += bytesToCopyFromBlock;
        size -= bytesToCopyFromBlock;
        offsetInBlock = 0;
    }
}

void DeviceWrapper::pwrite(const char *buf, quint64 size, quint64 offset)
{
    if (!size)
        return;

    quint64 firstBlock = offset / 4096;
    quint64 offsetInBlock = offset % 4096;

    if (offsetInBlock || size % 4096)
    {
        /* Need to read existing data from disk
           as we will only be replacing a part of a block. */
        _readIntoBlockCacheIfNeeded(offset, size);
    }

    for (auto i = firstBlock; size; i++)
    {
        auto block = _blockcache.value(i, NULL);
        if (!block)
        {
            block = new DeviceWrapperBlockCacheEntry(this);
            _blockcache.insert(i, block);
        }

        block->dirty = true;
        size_t bytesToCopyFromBlock = qMin(4096-offsetInBlock, size);
        memcpy(block->block + offsetInBlock, buf, bytesToCopyFromBlock);

        buf  += bytesToCopyFromBlock;
        size -= bytesToCopyFromBlock;
        offsetInBlock = 0;
    }

    _dirty = true;
}

DeviceWrapperFatPartition *DeviceWrapper::fatPartition(int nr)
{
    if (nr > 4 || nr < 1)
        throw std::runtime_error("Only basic partitions 1-4 supported");

    /* GPT table handling */
    struct gpt_header gpt;
    struct gpt_partition gptpart;
    pread((char *) &gpt, sizeof(gpt), 512);

    if (!strncmp("EFI PART", gpt.Signature, 8) && gpt.MyLBA == 1)
    {
        qDebug() << "Using GPT partition table";
        if (nr > gpt.NumberOfPartitionEntries)
            throw std::runtime_error("Partition does not exist");

        /* Overflow-safe offset calculation for GPT partition entry */
        quint64 entryLBA = gpt.PartitionEntryLBA;
        quint64 entrySize = gpt.SizeOfPartitionEntry;
        quint64 entryIndex = static_cast<quint64>(nr - 1);
        if (entryLBA > UINT64_MAX / 512)
            throw std::runtime_error("GPT partition entry LBA overflow");
        quint64 baseOffset = entryLBA * 512;
        if (entrySize && entryIndex > (UINT64_MAX - baseOffset) / entrySize)
            throw std::runtime_error("GPT partition entry offset overflow");
        pread((char *) &gptpart, sizeof(gptpart), baseOffset + entrySize * entryIndex);

        /* Overflow-safe size calculation for GPT partition */
        if (gptpart.EndingLBA < gptpart.StartingLBA)
            throw std::runtime_error("GPT partition ending LBA before starting LBA");
        quint64 sectorCount = gptpart.EndingLBA - gptpart.StartingLBA + 1;
        if (gptpart.StartingLBA > UINT64_MAX / 512 || sectorCount > UINT64_MAX / 512)
            throw std::runtime_error("GPT partition offset/size overflow");

        return new DeviceWrapperFatPartition(this, gptpart.StartingLBA * 512, sectorCount * 512, this);
    }

    /* MBR table handling */
    struct mbr_table mbr;
    pread((char *) &mbr, sizeof(mbr), 0);

    if (mbr.signature[0] != 0x55 || mbr.signature[1] != 0xAA)
        throw std::runtime_error("MBR does not have valid signature");

    if (!mbr.part[nr-1].starting_sector || !mbr.part[nr-1].nr_of_sectors)
        throw std::runtime_error("Partition does not exist");

    /* Overflow-safe offset/size for MBR partition (uint32_t * 512) */
    quint64 mbrStart = static_cast<quint64>(mbr.part[nr-1].starting_sector) * 512;
    quint64 mbrSize  = static_cast<quint64>(mbr.part[nr-1].nr_of_sectors) * 512;

    return new DeviceWrapperFatPartition(this, mbrStart, mbrSize, this);
}

