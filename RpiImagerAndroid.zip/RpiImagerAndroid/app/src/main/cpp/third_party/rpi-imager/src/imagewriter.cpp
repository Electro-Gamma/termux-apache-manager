/*
 * SPDX-License-Identifier: Apache-2.0
 * Copyright (C) 2020-2025 Raspberry Pi Ltd
 */

#include "downloadextractthread.h"
#include "imagewriter.h"
#include "network_poll_action.h"
#include "github_keys.h"
#include "connect_device_signin.h"
#include "dependencies/qrcodegen/qrcodegen.hpp"
#include "eeprom_repo_override.h"
#include "imagesizeparser.h"
#include "imager_version.h"
#include "writeprogresswatchdog.h"
#include "embedded_config.h"
#include "config.h"
#include "file_operations.h"
#include "drivelistitem.h"
#include "customization_generator.h"
#include "drivelist/drivelist.h"
#include "driveformatthread.h"
#include "localfileextractthread.h"
#include "systemmemorymanager.h"
#include "downloadstatstelemetry.h"
#include "wlancredentials.h"
#include "device_info.h"
#include "platformquirks.h"
#include "userfiles.h"
#include "secureboot_crypto.h"
#ifndef CLI_ONLY_BUILD
#include "iconimageprovider.h"
#include "iconmultifetcher.h"
#include "nativefiledialog.h"
#include <QQmlApplicationEngine>
#include <QQuickWindow>
#endif
#include <qjsondocument.h>
#include <QJsonArray>
#include <random>
#include <QFile>
#include <QFileInfo>
#include <QTextStream>
#include <QProcess>
#include <QRegularExpression>
#include <QStandardPaths>
#include <QStorageInfo>
#include <QTimeZone>
#include <QNetworkInterface>
#include <QCoreApplication>
#include <QPointer>
#ifndef CLI_ONLY_BUILD
#include <QQmlContext>
#include <QWindow>
#include <QGuiApplication>
#include <QClipboard>
#endif
#include <QUrl>
#include <QUrlQuery>
#include <QString>
#include <QStringList>
#include <QHostAddress>
#include <QDateTime>
#include "curlfetcher.h"
#include "rpibootthread.h"
#include "fastbootflashthread.h"
#include "fastbootflashthread.h"
#include "connect_device_registrar.h"
#include "curlnetworkconfig.h"
#include <QDebug>
#include <QJsonObject>
#include <QTranslator>
#include <QVersionNumber>
#include <QCryptographicHash>
#include <QRandomGenerator>
#ifndef CLI_ONLY_BUILD
#include <QDesktopServices>
#include <QAccessible>
#endif
#include <stdlib.h>
#include <new>
#include <QLocale>
#include <QMetaType>
#include "imageadvancedoptions.h"

#ifdef Q_OS_WIN
#include <windows.h>
#include <QProcessEnvironment>
#endif

#ifdef Q_OS_LINUX
#include "linux/stpanalyzer.h"
#include <sys/reboot.h>
#include <unistd.h>
#include <sys/types.h>
#include <pwd.h>
#include <limits>
#endif

using namespace ImageOptions;

namespace {
    constexpr uint MAX_SUBITEMS_DEPTH = 16;
} // namespace anonymous

// Initialize static member for secure boot CLI override
bool ImageWriter::_forceSecureBootEnabled = false;

#ifndef CLI_ONLY_BUILD
ImageWriter *ImageWriter::s_qmlInstance = nullptr;

ImageWriter *ImageWriter::create(QQmlEngine *, QJSEngine *)
{
    Q_ASSERT(s_qmlInstance);
    // The instance is owned by main() (stack-allocated), not the QML engine.
    QQmlEngine::setObjectOwnership(s_qmlInstance, QQmlEngine::CppOwnership);
    return s_qmlInstance;
}
#endif

ImageWriter::ImageWriter(QObject *parent)
    : QObject(parent),
      _cacheManager(nullptr),
      _waitingForCacheVerification(false),
      _src(), _repo(defaultOsListUrl()),
      _dst(), _parentCategory(), _osName(), _osReleaseDate(), _currentLang(), _currentLangcode(), _currentKeyboard(),
      _expectedHash(), _cmdline(), _config(), _firstrun(), _cloudinit(), _cloudinitNetwork(), _initFormat(),
      _downloadLen(0), _extrLen(0), _devLen(0), _dlnow(0), _verifynow(0),
      _drivelist(DriveListModel(this)), // explicitly parented, so QML doesn't delete it
      _selectedDeviceValid(false),
      _writeState(WriteState::Idle),

      _cancelledDueToDeviceRemoval(false),
      _hwlist(HWListModel(*this)),
      _oslist(OSListModel(*this)),
      _engine(nullptr),
      _networkchecktimer(),
      _osListRefreshTimer(),
      _screenReaderPollTimer(),
      _suspendInhibitor(nullptr),
      _thread(nullptr),
      _verifyEnabled(true), _multipleFilesInZip(false), _online(false), _extractSizeKnown(true),
      _settings(),
      _translations(),
      _refreshIntervalOverrideMinutes(-1),
      _refreshJitterOverrideMinutes(-1),
#ifndef CLI_ONLY_BUILD
      _piConnectToken(),
      _mainWindow(nullptr),
#else
      _piConnectToken(),
#endif
      _progressWatchdog(nullptr),
      _forceSyncMode(false)
{
    // Initialise CacheManager
    _cacheManager = new CacheManager(this);
    
    // Initialise PerformanceStats
    _performanceStats = new PerformanceStats(this);
    
    // Initialize debug options with defaults
    // Direct I/O is enabled by default (matches current behavior)
    // Periodic sync is enabled by default but skipped when direct I/O is active
    _debugDirectIO = true;
    _debugPeriodicSync = true;
    _debugVerboseLogging = false;
    _debugAsyncIO = true;       // Async I/O enabled by default for performance
    _debugIPv4Only = false;     // Use both IPv4 and IPv6 by default
    _debugSkipEndOfDevice = false; // Normal behavior; enable for counterfeit cards
    _debugIgnoreDeviceLimits = false; // Use device-reported I/O limits by default
    // Rpiboot/fastboot support is off by default, but sticky once turned on:
    // the people who need it (CM provisioning) want it every session, and
    // re-entering the secret menu on every launch is needless friction.
    _debugRpiboot = _settings.value(QStringLiteral("debug_rpiboot"), false).toBool();
    _debugForceSecureBoot = false;  // No UI override; CLI flag still wins
    _debugSignFastbootGadget = false; // CM5 special-reprovision-device (SBR then fastboot)

    // Propagate a restored rpiboot setting to the poll thread; these only set
    // atomics, so it is safe before polling starts.
    if (_debugRpiboot) {
        _drivelist.setRpibootEnabled(true);
        _drivelist.setFastbootScanEnabled(true);
        qDebug() << "Debug: Rpiboot/fastboot support enabled from saved settings";
    }

    // Calculate optimal async queue depth based on system memory
    _debugAsyncQueueDepth = SystemMemoryManager::instance().getOptimalAsyncQueueDepth();
    
    // Set up file operations logging to use Qt's debug output
    rpi_imager::SetFileOperationsLogCallback([](const std::string& msg) {
        qDebug() << "[FileOps]" << msg.c_str();
    });
    qDebug() << "FileOperations log callback installed";

    QString platform;
#ifndef CLI_ONLY_BUILD
    if (qobject_cast<QGuiApplication*>(QCoreApplication::instance()) )
    {
        platform = QGuiApplication::platformName();
    }
    else
#endif
    {
        platform = "cli";
    }
    _device_info = std::make_unique<DeviceInfo>();

#ifndef CLI_ONLY_BUILD
    // QAccessible::isActive() has no change notification on macOS/Windows, so
    // we poll. Toggling a screen reader is a deliberate user gesture, so a
    // 500 ms cadence is plenty without being a measurable cost.
    _screenReaderActiveCached = QAccessible::isActive();
    _screenReaderPollTimer.setInterval(500);
    connect(&_screenReaderPollTimer, &QTimer::timeout, this, [this]() {
        const bool now = QAccessible::isActive();
        if (now != _screenReaderActiveCached) {
            _screenReaderActiveCached = now;
            emit screenReaderActiveChanged();
        }
    });
    _screenReaderPollTimer.start();
#endif

    PlatformQuirks::setClockFloor(IMAGER_SOURCE_EPOCH);

    if (::isEmbeddedMode())
    {
        connect(&_networkchecktimer, SIGNAL(timeout()), SLOT(pollNetwork()));
        _networkchecktimer.start(100);
        changeKeyboard(detectPiKeyboard());
        if (_currentKeyboard.isEmpty())
            _currentKeyboard = "us";

        // Outside the branch above, and deliberately: the locale scan below
        // only names a language when it finds a translation matching it, so
        // without a default here an unrecognised locale leaves the language
        // empty and the interface with nothing to show. The indentation used
        // to say this belonged to the keyboard fallback, which would have
        // left exactly that gap whenever a keyboard was detected.
        _currentLang = "English";

        {
            QString nvmem_blconfig_path = {};
            QFile f("/sys/firmware/devicetree/base/aliases/blconfig");
            if (f.exists() && f.open(QIODevice::ReadOnly)) {
                QByteArray fileContent = f.readAll();
                nvmem_blconfig_path = QString::fromLatin1(fileContent.constData());
                f.close();
            }

            QString blconfig_link = {};
            if (!nvmem_blconfig_path.isEmpty()) {
                QString findCommand = "/usr/bin/find";
                QStringList findArguments = {
                    "-L",
                    "/sys/bus/nvmem",
                    "-maxdepth",
                    "3",
                    "-samefile",
                    "/sys/firmware/devicetree/base" + nvmem_blconfig_path
                };
                QProcess *findProcess = new QProcess(this);
                connect(findProcess, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished),
                    [&blconfig_link, &findProcess](int exitCode, QProcess::ExitStatus exitStatus) { // clazy:exclude=lambda-in-connect
                        blconfig_link = findProcess->readAllStandardOutput();
                    });
                findProcess->start(findCommand, findArguments);
                findProcess->waitForFinished(); //Default timeout: 30s
                delete findProcess;
            }
            if (!blconfig_link.isEmpty()) {
                QDir blconfig_of_dir = QDir(blconfig_link);
                if (blconfig_of_dir.cdUp()) {
                    QFile blconfig_file = QFile(blconfig_of_dir.path() + QDir::separator() + "nvmem");
                    if (blconfig_file.exists() && blconfig_file.open(blconfig_file.ReadOnly)) {
                        const QByteArray blconfigBytes = blconfig_file.readAll();
                        blconfig_file.close();
                        const QString fromEeprom =
                            rpi_eeprom::repoUrlFromBlconfig(blconfigBytes);
                        if (!fromEeprom.isEmpty())
                        {
                            /* The same setting arriving from a URL handler
                             * goes through isValidRepoUrl first; this one
                             * came out of flash and went straight in, so a
                             * file: URL there became the OS list.
                             *
                             * Only the scheme is insisted on, not the whole
                             * of that check: a deployment may well point at
                             * an https URL whose path does not end in .json,
                             * and narrowing that here would quietly take its
                             * list away.
                             */
                            const QUrl candidate(fromEeprom);
                            if (isHttpUrl(candidate))
                            {
                                _repo = candidate;
                                qDebug() << "Repository from EEPROM:" << _repo;
                            }
                            else
                            {
                                qWarning() << "Ignoring EEPROM repository that is"
                                              " not an http(s) URL:" << fromEeprom;
                            }
                        }
                    }
                }
            }
        }

        // The STP analyzer is only built for embedded mode, so
        // unlike the block above that can be selected at runtime,
        // this must be selected at build time.
#ifdef BUILD_EMBEDDED
        StpAnalyzer *stpAnalyzer = new StpAnalyzer(5, this);
        connect(stpAnalyzer, SIGNAL(detected()), SLOT(onSTPdetected()));
        stpAnalyzer->startListening("eth0");
#endif
    }

    if (!_settings.isWritable() && !_settings.fileName().isEmpty())
    {
        /* Settings file is not writable, probably run by root previously */
        QString settingsFile = _settings.fileName();
        qDebug() << "Settings file" << settingsFile << "not writable. Recreating it";
        QFile f(_settings.fileName());
        QByteArray oldsettings;

        if (f.open(f.ReadOnly))
        {
            oldsettings = f.readAll();
            f.close();
        }
        f.remove();
        if (f.open(f.WriteOnly))
        {
            f.write(oldsettings);
            f.close();
            _settings.sync();
        }
        else
        {
            qDebug() << "Error deleting and recreating settings file. Please remove manually.";
        }
    }

    // Cache management is now handled entirely by CacheManager

    QDir dir(":/i18n", "rpi-imager_*.qm");
    const QStringList transFiles = dir.entryList();
    QMap<QString, QString> langnames;  // langcode -> name in the menu

    for (const QString &tf : transFiles)
    {
        QString langcode = tf.mid(11, tf.length()-14);

        QLocale loc(langcode);
        /* Use "English" for "en" and not "American English" */
        langnames.insert(langcode, langcode == "en" ? "English" : loc.nativeLanguageName());
    }

    /* A regional translation can have the same name as its language's: "pt"
       and "pt-BR" are both "português". Keyed by name, one would replace the
       other in the menu, so name the regional one after its region too. */
    QHash<QString, int> nameUses;
    for (const QString &langname : std::as_const(langnames))
        nameUses[langname]++;
    for (auto it = langnames.begin(); it != langnames.end(); ++it)
    {
        if (nameUses.value(it.value()) > 1 && it.key().contains('-'))
            it.value() += QStringLiteral(" (%1)").arg(QLocale(it.key()).nativeTerritoryName());
    }
    for (auto it = langnames.cbegin(); it != langnames.cend(); ++it)
        _translations.insert(it.value(), it.key());

    // Only on a match, or the embedded build's English default above is lost
    const QString localeLangcode = translationForLocale(QLocale(), langnames.keys());
    if (!localeLangcode.isEmpty())
    {
        _currentLangcode = localeLangcode;
        _currentLang = langnames.value(localeLangcode);
    }

    // Connect to CacheManager signals
    connect(_cacheManager, &CacheManager::cacheFileUpdated,
            this, [this](const QByteArray& hash) {
                qDebug() << "Received cacheFileUpdated signal - refreshing UI for hash:" << hash;
                emit cacheStatusChanged();
            });

    connect(_cacheManager, &CacheManager::cacheVerificationComplete,
            this, [this](bool isValid) {
                if (isValid) {
                    // Emit cache status changed signal for QML to react to
                    emit cacheStatusChanged();
                }
            });

    connect(_cacheManager, &CacheManager::cacheInvalidated,
            this, [this]() {
                // Emit cache status changed signal when cache is invalidated
                emit cacheStatusChanged();
            });

    // Connect to specific device removal events
    connect(&_drivelist, &DriveListModel::deviceRemoved,
            this, &ImageWriter::onSelectedDeviceRemoved);
    
    // Forward connected rpiboot chip names to hardware list model for USB boot annotations
    connect(&_drivelist, &DriveListModel::connectedRpibootChipsChanged,
            &_hwlist, &HWListModel::setConnectedRpibootChips);

    // Auto-bootstrap: when a new rpiboot device is detected, start sideloading fastbootd
    connect(&_drivelist, &DriveListModel::rpibootDeviceDetected,
            this, &ImageWriter::onRpibootDeviceDetected);

    // Connect drive list poll timing events for performance tracking
    // Only record polls that take longer than 200ms to avoid noise from normal fast polls
    connect(&_drivelist, &DriveListModel::eventDriveListPoll,
            this, [this](quint32 durationMs){
                if (durationMs >= 200) {
                    _performanceStats->recordEvent(PerformanceStats::EventType::DriveListPoll, durationMs, true);
                }
            });
    
    // Connect OS list parse timing events for performance tracking
    connect(&_oslist, &OSListModel::eventOsListParse,
            this, [this](quint32 durationMs, bool success){
                _performanceStats->recordEvent(PerformanceStats::EventType::OsListParse, durationMs, success);
            });

    // Start background cache operations early
    _cacheManager->startBackgroundOperations();

    // Start background drive list polling
    qDebug() << "Starting background drive list polling";
    _drivelist.startPolling();

    // Configure OS list refresh timer (single-shot; we reschedule after each fetch)
    _osListRefreshTimer.setSingleShot(true);
    connect(&_osListRefreshTimer, &QTimer::timeout, this, &ImageWriter::onOsListRefreshTimeout);

    // Belt-and-braces: ensure potentially dangerous flags are not persisted between runs
    // If found in settings, remove them immediately
    if (_settings.contains("disable_warnings")) {
        _settings.remove("disable_warnings");
        _settings.sync();
        qDebug() << "Removed persisted disable_warnings flag from settings";
    }
}

void ImageWriter::setMainWindow(QObject *window)
{
#ifndef CLI_ONLY_BUILD
    // Convert QObject to QWindow
    _mainWindow = qobject_cast<QWindow*>(window);
    if (!_mainWindow) {
        // If it's not a QWindow directly, try to get the window from a QQuickWindow
        QQuickWindow *quickWindow = qobject_cast<QQuickWindow*>(window);
        if (quickWindow) {
            _mainWindow = quickWindow;
        }
    }
#else
    Q_UNUSED(window);
#endif
}

void ImageWriter::bringWindowToForeground()
{
#ifndef CLI_ONLY_BUILD
    if (!_mainWindow) {
        return;
    }

    // winId() is a native handle only under a windowing plugin. The headless
    // ones return a counter, which the macOS code then messages as an NSView:
    // EXC_BAD_ACCESS on 0x1. Non-null is not enough of a test.
    const QString platform = QGuiApplication::platformName();
    if (platform.compare(QLatin1String("offscreen"), Qt::CaseInsensitive) == 0
        || platform.compare(QLatin1String("minimal"), Qt::CaseInsensitive) == 0) {
        return;
    }

    // Get the native window handle and pass it to the platform-specific implementation
    void* windowHandle = reinterpret_cast<void*>(_mainWindow->winId());
    if (windowHandle) {
        PlatformQuirks::bringWindowToForeground(windowHandle);
        qDebug() << "Requested window to be brought to foreground for rpi-connect token";
    }
#endif
}

QString ImageWriter::getNativeOpenFileName(const QString &title,
                                           const QString &initialDir,
                                           const QString &filter)
{
#ifndef CLI_ONLY_BUILD
    if (!NativeFileDialog::areNativeDialogsAvailable()) {
        return QString();
    }
    return NativeFileDialog::getOpenFileName(title, initialDir, filter, _mainWindow);
#else
    Q_UNUSED(title);
    Q_UNUSED(initialDir);
    Q_UNUSED(filter);
    return QString();
#endif
}

QString ImageWriter::readFileContents(const QString &filePath)
{
    if (filePath.isEmpty()) {
        return QString();
    }

    // A file:// URL is accepted as well as a path, and converted here rather
    // than by the caller. Every QML caller was stripping the scheme with a
    // string replace, which leaves "/C:/Users/..." on Windows -- a leading
    // slash that is not part of the path, so the open failed and the chosen
    // file read as empty. QUrl::toLocalFile() knows the difference; six
    // hand-written strips in QML did not.
    const QString path = filePath.startsWith(QLatin1String("file:"))
                             ? QUrl(filePath).toLocalFile()
                             : filePath;

    // Elevated, a picked file could be a link to one only root can read.
    PlatformQuirks::InvokingUserFsScope asUser;
    QFile file(path);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qDebug() << "Failed to open file:" << path << "Error:" << file.errorString();
        return QString();
    }

    QTextStream in(&file);
    QString content = in.readAll();
    file.close();

    return content.trimmed();
}

QString ImageWriter::localPathFromUrl(const QUrl &url) const
{
    // Anything that is not a local file url is returned as it came
    return url.toString(QUrl::PreferLocalFile);
}

QUrl ImageWriter::fileUrlFromLocalPath(const QString &path) const
{
    return QUrl::fromLocalFile(QDir::fromNativeSeparators(path));
}

ImageWriter::~ImageWriter()
{
    // Stop network monitoring first - the callback captures 'this' pointer
    // Must be done before any other cleanup to prevent use-after-free
    qDebug() << "Stopping network monitoring";
    PlatformQuirks::stopNetworkMonitoring();
    
    // Cancel FastbootFlashThread before stopping drive list polling.
    // Both use libusb; concurrent libusb_exit (FastbootFlashThread) and
    // libusb_init (DriveListModelPollThread) trigger a macOS libusb deadlock
    // where darwin_exit holds active_contexts_lock while waiting for the
    // IONotification thread, which itself needs that lock for a pending IOKit
    // callback.  Stopping FastbootFlashThread first eliminates the conflict.
    if (_fastbootFlashThread) {
        qDebug() << "Stopping FastbootFlashThread";
        _fastbootFlashThread->cancel();
        if (!_fastbootFlashThread->wait(10000)) {
            qWarning() << "FastbootFlashThread did not stop within 10s, terminating";
            _fastbootFlashThread->terminate();
            _fastbootFlashThread->wait();
        }
        delete _fastbootFlashThread;
        _fastbootFlashThread = nullptr;
    }

    // Stop background drive list polling
    qDebug() << "Stopping background drive list polling";
    _drivelist.stopPolling();

    // Stop and cleanup CacheManager background thread before Qt's automatic cleanup
    // This ensures the background thread is properly terminated before ImageWriter is destroyed
    if (_cacheManager) {
        qDebug() << "Cleaning up CacheManager";
        delete _cacheManager;
        _cacheManager = nullptr;
    }

    // Give a user-triggered eject a chance to finish before teardown. Never
    // terminate() it: killing the thread mid-DiskArbitration call is unsafe,
    // and deleting a QThread that survived terminate() is a qFatal. If it is
    // still flushing after the grace period, leave it to finish detached — the
    // worker only reaches this object through a guarded QPointer, so it cannot
    // touch a destroyed ImageWriter.
    if (_manualEjectThread) {
        qDebug() << "Waiting for manual eject thread to finish";
        if (_manualEjectThread->wait(10000)) {
            delete _manualEjectThread;
        } else {
            qWarning() << "Manual eject still running at teardown; leaving it to finish detached";
        }
        _manualEjectThread = nullptr;
    }

    // Ensure any running thread is properly cleaned up
    if (_thread) {
        if (_thread->isRunning()) {
            qDebug() << "Cancelling running thread in ImageWriter destructor";
            _thread->cancelDownload();
            if (!_thread->wait(10000)) {
                qDebug() << "Thread did not finish within 10 seconds, terminating it";
                _thread->terminate();
                // Re-read the member rather than using it again. terminate()
                // lets the thread's own teardown run, and that path clears
                // _thread -- so the wait() below was dereferencing a null
                // pointer and taking the process with it, a segfault ten
                // seconds after a write that would not stop.
                if (_thread)
                    _thread->wait(2000);
            }
        }
        delete _thread;
        _thread = nullptr;
    }

    // Cleanup suspend inhibitor if it's still active
    if (_suspendInhibitor) {
        delete _suspendInhibitor;
        _suspendInhibitor = nullptr;
    }

    for (QTranslator *trans : std::as_const(_translators))
    {
        // The application may already be gone: this is destroyed before it
        // in the GUI, but a test binary holding the writer in a static
        // outlives it, and removeTranslator() then warns about an instance
        // that is not there rather than doing anything.
        if (QCoreApplication::instance())
            QCoreApplication::removeTranslator(trans);
        delete trans;
    }
}

void ImageWriter::setEngine(QQmlApplicationEngine *engine)
{
#ifndef CLI_ONLY_BUILD
    _engine = engine;
    if (_engine) {
        // Register icon provider for image://icons/<url>
        _engine->addImageProvider(QStringLiteral("icons"), new IconImageProvider());
    }
#else
    Q_UNUSED(engine);
#endif
}

/* Set URL to download from */
void ImageWriter::setSrc(const QUrl &url, quint64 downloadLen, quint64 extrLen, QByteArray expectedHash, bool multifilesinzip, QString parentcategory, QString osname, QByteArray initFormat, QString releaseDate, QString bmapUrl)
{
    _src = url;
    _downloadLen = downloadLen;
    _expectedHash = expectedHash;
    _extractSizeKnown = false;
    _extrLen = extrLen;
    _multipleFilesInZip = multifilesinzip;
    _parentCategory = parentcategory;
    _osName = osname;
    _initFormat = (initFormat == "none") ? "" : initFormat;
    _osReleaseDate = releaseDate;
    _bmapUrl = bmapUrl;

    qDebug() << "setSrc: initFormat parameter:" << initFormat << "-> _initFormat set to:" << _initFormat;

    if (!_downloadLen && url.isLocalFile())
    {
        QFileInfo fi(url.toLocalFile());
        _downloadLen = fi.size();
    }

    // Size local files by what they contain, not by what they are called. A
    // mislabelled download -- xz bytes under a .img name -- took the "not
    // compressed" branch here and was sized at its compressed length, while
    // the write path sniffed the same file and decompressed it. Progress ran
    // past 400%, and the capacity check passed on a card far too small to
    // hold the result.
    if (!extrLen && _src.isLocalFile())
    {
        const auto measured = imagesize::measureLocalFile(_src.toLocalFile());
        _extrLen = measured.uncompressedSize;
        _extractSizeKnown = measured.sizeIsReliable;
        if (measured.fileCount > 1)
            _multipleFilesInZip = true;
    }
    else if (extrLen)
    {
        _extractSizeKnown = true;
    }
}

/* Set device to write to */
void ImageWriter::setDst(const QString &device, quint64 deviceSize)
{
    _dst = device;
    _devLen = deviceSize;
    _selectedDeviceValid = !device.isEmpty();
    _isRpibootDevice = false;  // Reset — setRpibootDevice() will re-set if needed
    _isFastbootDevice = false;  // Reset — setFastbootDevice() will re-set if needed

    // Reset write completion state when device selection changes
    if (device.isEmpty()) {
        setWriteState(WriteState::Idle);
    }

    qDebug() << "Device selection changed to:" << device;
}

void ImageWriter::setRpibootDevice(const QString &deviceId,
                                    const QString &storageTarget)
{
    _rpibootDeviceId = deviceId;
    _rpibootStorageTarget = storageTarget;
    _isRpibootDevice = true;
    // And no longer the other kind. setFastbootDevice() clears this flag's
    // counterpart for the same reason: choosePath() asks the fastboot
    // question first, so a board selected here while that was still set
    // would be sent down the fastboot path -- the imager talking fastboot to
    // something that is not listening for it, having skipped the bootstrap
    // that would have made it listen. Both states can be in the storage list
    // at once, and the step that fills it in calls one setter per selection
    // with no reset in between.
    _isFastbootDevice = false;
    _selectedDeviceValid = true;
    // Set _dst to the rpiboot ID so readyToWrite() passes
    _dst = deviceId;
    _devLen = 0;

    qDebug() << "rpiboot device selected:" << deviceId
             << "storageTarget=" << (storageTarget.isEmpty() ? QStringLiteral("<unset>") : storageTarget);
}

bool ImageWriter::isRpibootDevice() const
{
    return _isRpibootDevice;
}

void ImageWriter::setFastbootDevice(const QString &device, quint64 size)
{
    // device format: "fastboot://bus:addr/blockdevice"
    QString path = device;
    if (path.startsWith("fastboot://"))
        path = path.mid(11); // strip scheme

    // Parse "bus:addr/blockdevice"
    int slashIdx = path.indexOf('/');
    if (slashIdx > 0) {
        _fastbootId = path.left(slashIdx);
        _fastbootBlockDevice = path.mid(slashIdx + 1);
    } else {
        _fastbootId = path;
        _fastbootBlockDevice = QStringLiteral("mmcblk0");
    }

    _isFastbootDevice = true;
    _isRpibootDevice = false;
    _dst = device;
    _devLen = size;
    _selectedDeviceValid = true;

    qDebug() << "Fastboot device selected:" << device
             << "id=" << _fastbootId << "block=" << _fastbootBlockDevice;
}

bool ImageWriter::isFastbootDevice() const
{
    return _isFastbootDevice;
}

void ImageWriter::onRpibootDeviceDetected(const QString &deviceId,
                                            uint8_t busNumber, uint8_t deviceAddress,
                                            const QList<uint8_t> &portPath, uint16_t productId)
{
    // Only auto-bootstrap when rpiboot/fastboot debug mode is enabled
    if (!_debugRpiboot)
        return;

    // Compute port path key for dedup
    QString ppKey;
    for (int i = 0; i < portPath.size(); ++i) {
        if (i > 0) ppKey += '.';
        ppKey += QString::number(portPath[i]);
    }

    // Skip if already bootstrapping this device
    if (_bootstrappingDevices.contains(ppKey))
        return;

    _bootstrappingDevices.insert(ppKey);
    // Hold the device's chip annotation across the handover from rpiboot to
    // the fastboot gadget, during which it is on neither side of the bus.
    _drivelist.setBootstrapInFlight(ppKey, true);
    qDebug() << "Auto-bootstrap: starting rpiboot for" << ppKey << "deviceId=" << deviceId;

    // Create DeviceInfo from parameters
    RpibootThread::DeviceInfo devInfo;
    devInfo.busNumber = busNumber;
    devInfo.deviceAddress = deviceAddress;
    for (const auto& p : portPath)
        devInfo.portPath.push_back(p);

    // Determine chip generation from PID
    devInfo.chipGeneration = rpiboot::ChipGeneration::BCM2711; // safe default
    if (auto gen = rpiboot::chipGenerationFromPid(productId))
        devInfo.chipGeneration = *gen;

    auto *thread = new RpibootThread(devInfo, _rpibootSideloadMode, this);
    if (!_debugCustomFastbootGadget.isEmpty())
        thread->setCustomFastbootGadget(_debugCustomFastbootGadget);
    // Plumb the re-provisioning key through to FirmwareManager so the
    // bootcode upload + gadget signing run on auto-bootstrap too — without
    // this a pre-fused CM5 silently rejects the unsigned bootcode and the
    // 15s re-enumerate timeout fires.
    if (_debugSignFastbootGadget) {
        QString rsaKey = _settings.value(QStringLiteral("secureboot_rsa_key")).toString();
        if (rsaKey.isEmpty()) {
            qWarning() << "Auto-bootstrap: re-provisioning enabled but no secure boot RSA key configured; "
                          "uploaded bootcode will not be counter-signed and the device will reject it";
        } else {
            thread->setSignFastbootGadgetKey(rsaKey);
        }
        thread->setReprovisionDevice(true);
    }

    connect(thread, &RpibootThread::fastbootDeviceReady, this,
            [this, ppKey](const QString &fastbootId) {
                onBootstrapComplete(ppKey, fastbootId);
            });
    connect(thread, &RpibootThread::error, this,
            [this, ppKey](const QString &msg) {
                onBootstrapError(ppKey, msg);
            });
    connect(thread, &RpibootThread::preparationStatusUpdate, this, &ImageWriter::onPreparationStatusUpdate);

    _activeBootstrapThreads[ppKey] = thread;

    // Pause drive scanning for the duration of the bootstrap.  The poll
    // thread also calls libusb_get_device_list / scanRpibootDevices on a
    // 1 s tick, and on macOS concurrent libusb access against the same
    // bus while the bootstrap thread is doing sustained bulk transfers
    // produces sporadic LIBUSB_ERROR_IO / NO_DEVICE failures partway
    // through boot.img upload (variable cutoff at ~12-14 MB).  Same
    // pattern the regular write path uses while WriteState != Idle.
    qDebug() << "Auto-bootstrap: pausing drive scan to avoid concurrent libusb access";
    _drivelist.pausePolling();

    thread->start();
}

void ImageWriter::onBootstrapComplete(const QString &portPathKey, const QString &fastbootId)
{
    qDebug() << "Auto-bootstrap complete:" << portPathKey << "fastbootId=" << fastbootId;

    // Clean up the thread
    if (_activeBootstrapThreads.contains(portPathKey)) {
        _activeBootstrapThreads[portPathKey]->deleteLater();
        _activeBootstrapThreads.remove(portPathKey);
    }
    _bootstrappingDevices.remove(portPathKey);

    // Enable fastboot scanning so the poll thread discovers storage devices,
    // then unpause polling — paired with pausePolling() in the bootstrap kickoff.
    _drivelist.setFastbootScanEnabled(true);
    if (_activeBootstrapThreads.isEmpty()) {
        qDebug() << "Auto-bootstrap: resuming drive scan";
        _drivelist.resumePolling();
    }
}

void ImageWriter::onBootstrapError(const QString &portPathKey, const QString &msg)
{
    qWarning() << "Auto-bootstrap error for" << portPathKey << ":" << msg;

    // Clean up the thread
    if (_activeBootstrapThreads.contains(portPathKey)) {
        _activeBootstrapThreads[portPathKey]->deleteLater();
        _activeBootstrapThreads.remove(portPathKey);
    }
    _bootstrappingDevices.remove(portPathKey);
    // The device is not coming back on its own, so stop holding its
    // annotation — the next poll that doesn't see the port clears it.
    _drivelist.setBootstrapInFlight(portPathKey, false);

    // Unpause drive scanning when the last bootstrap finishes (success or
    // error).  Only resume once no bootstraps remain in flight, in case
    // multiple devices are being bootstrapped simultaneously.
    if (_activeBootstrapThreads.isEmpty()) {
        qDebug() << "Auto-bootstrap: resuming drive scan after error";
        _drivelist.resumePolling();
    }
}

QUrl ImageWriter::resolveFlashSource() const
{
    // The regular write path substitutes a file:// URL for _src when a
    // verified cache exists, so libcurl reads off disk instead of going to
    // the network. The fastboot handoff did not, which meant a fastboot
    // write always hit the network even with the image fully cached -- and
    // showed up as "Recv failure: Connection reset by peer" to a user who
    // could see the download had already happened.
    //
    // Verified is the condition, not merely present: an unverified cache
    // file may be a partial download, and writing that to a board is worse
    // than fetching it again.
    if (!_cacheManager || _expectedHash.isEmpty())
        return _src;
    if (!_cacheManager->hasPotentialCache(_expectedHash))
        return _src;

    const auto cacheStatus = _cacheManager->getCacheStatus();
    if (!cacheStatus.verificationComplete || !cacheStatus.isValid) {
        qDebug() << "FastbootFlashThread: cached file present but not yet"
                    " verified — falling back to network download";
        return _src;
    }

    qDebug() << "FastbootFlashThread: using verified cache file"
             << cacheStatus.cacheFileName;
    return QUrl::fromLocalFile(cacheStatus.cacheFileName);
}

QString ImageWriter::resolveFastbootStorageTarget() const
{
    // Drives both where the image is written and the BOOT_ORDER nibble set
    // in the EEPROM afterwards. Empty means the rpiboot selection did not
    // carry one through; eMMC is the only storage every compute module is
    // guaranteed to have, so it is the safe fallback -- but the mismatch is
    // logged, because the resulting BOOT_ORDER will not be what the user
    // picked.
    if (!_rpibootStorageTarget.isEmpty())
        return _rpibootStorageTarget;

    qWarning() << "rpiboot fastboot handoff: no storage target carried"
                  " through selection --- defaulting to mmcblk0;"
                  " EEPROM BOOT_ORDER will reflect SD/eMMC, not the"
                  " user's intended target";
    return QStringLiteral("mmcblk0");
}

void ImageWriter::onRpibootFastbootReady(const QString &fastbootId)
{
    qDebug() << "rpiboot fastboot device ready:" << fastbootId;

    if (_rpibootThread) {
        _rpibootThread->deleteLater();
        _rpibootThread = nullptr;
    }

    // Resolve cache before starting the flash thread.  The regular
    // (non-fastboot) write path at startWrite() does this — if a cached
    // image exists and has been background-verified, it substitutes a
    // file:// URL for _src so libcurl reads off disk instead of going to
    // the network.  Without the same logic here, fastboot writes always
    // hit the network even when the OS image is fully cached locally,
    // which is what produced the "Recv failure: Connection reset by peer"
    // we just saw despite the user reporting a cached image.
    const QUrl flashSrc = resolveFlashSource();

    // Start FastbootFlashThread.  Use the storage target the user picked
    // in the wizard --- this drives both where the image is written and
    // the BOOT_ORDER nibble we'll set in the EEPROM afterwards.  An empty
    // target here means the rpiboot selection didn't carry one through,
    // in which case fall back to the eMMC (the only storage every CM is
    // guaranteed to have) and log a warning so the mismatch is visible
    // in support logs.
    const QString storageTarget = resolveFastbootStorageTarget();
    _fastbootFlashThread = new FastbootFlashThread(fastbootId, storageTarget, flashSrc, _downloadLen, _extrLen, _expectedHash, this);
    _configureAndStartFastbootFlash();
}

void ImageWriter::onRpibootError(const QString &msg)
{
    qWarning() << "rpiboot error:" << msg;

    if (_rpibootThread) {
        _rpibootThread->deleteLater();
        _rpibootThread = nullptr;
    }

    onError(msg);
}

/* Returns true if src and dst are set and destination device is still valid */
bool ImageWriter::readyToWrite()
{
    return !_src.isEmpty() && !_dst.isEmpty() && _selectedDeviceValid;
}

/* Returns true if running on Raspberry Pi */
bool ImageWriter::isRaspberryPiDevice()
{
    return _device_info->isRaspberryPi();
}

bool ImageWriter::createHardwareTags()
{
    QJsonDocument doc = getFilteredOSlistDocument();
    QJsonObject root = doc.object();

    if (root.isEmpty() || !doc.isObject()) {
        qWarning() << Q_FUNC_INFO << "Invalid root";
        return false;
    }

    QJsonValue imager = root.value("imager");

    if (!imager.isObject()) {
        qWarning() << Q_FUNC_INFO << "missing imager";
        return false;
    }

    QJsonValue devices = imager.toObject().value("devices");

    const QJsonArray deviceArray = devices.toArray();

    _device_info->setHardwareTags(deviceArray);

    return true;
}

QString ImageWriter::getHardwareName()
{
    return _device_info->hardwareName();
}

/* Start writing */
// Configure the fastboot flash thread and start it.
//
// Two paths reach this with a device already in fastboot mode: the one that
// has just sideloaded it there, and the one where the user picked a fastboot
// storage device directly. Both configured the thread with the same
// forty-five lines -- customisation, the bmap URL, the Connect organisation
// registration, ten signal connections and the telemetry -- differing only in
// indentation and the wording of two comments.
void ImageWriter::_configureAndStartFastbootFlash()
{
    _fastbootFlashThread->setImageCustomisation(_config, _cmdline, _firstrun, _cloudinit, _cloudinitNetwork, _initFormat);
    if (!_bmapUrl.isEmpty())
        _fastbootFlashThread->setBmapUrl(QUrl(_bmapUrl));

    // Propagate Raspberry Pi Connect organisation registration.
    // The API key is persisted in QSettings but never handed back to
    // QML; read it directly here and forward to the flash thread.
    // Only applies when "Raspberry Pi Connect for Organisations" is
    // enabled in App Options.
    QString orgKey, orgDesc;
    if (_connectOrgRegistrationForWrite(orgKey, orgDesc))
        _fastbootFlashThread->setConnectRegistration(orgKey, orgDesc);
    connect(_fastbootFlashThread, &FastbootFlashThread::success, this, &ImageWriter::onSuccess);
    connect(_fastbootFlashThread, &FastbootFlashThread::error, this, &ImageWriter::onError);
    connect(_fastbootFlashThread, &FastbootFlashThread::preparationStatusUpdate, this, &ImageWriter::onPreparationStatusUpdate);
    connect(_fastbootFlashThread, &FastbootFlashThread::downloadProgress, this, [this](quint64 now, quint64 total) {
        emit downloadProgress(QVariant(now), QVariant(total));
    });
    connect(_fastbootFlashThread, &FastbootFlashThread::writeProgress, this, [this](quint64 now, quint64 total) {
        emit writeProgress(QVariant(now), QVariant(total));
    });
    connect(_fastbootFlashThread, &FastbootFlashThread::finalizing, this, &ImageWriter::onFinalizing);
    connect(_fastbootFlashThread, &FastbootFlashThread::writing, this, [this]() {
        setWriteState(WriteState::Writing);
        startProgressPolling();
    });

    // Clean up thread pointer when finished
    connect(_fastbootFlashThread, &QThread::finished, this, [this]() {
        if (_fastbootFlashThread) {
            _fastbootFlashThread->deleteLater();
            _fastbootFlashThread = nullptr;
        }
    });

    // Wire fastboot timing events and progress to PerformanceStats
    connect(_fastbootFlashThread, &FastbootFlashThread::eventFastbootDeviceOpen,
            this, [this](quint32 ms, bool ok, QString meta){
                _performanceStats->recordEvent(PerformanceStats::EventType::FastbootDeviceOpen, ms, ok, meta);
            });
    connect(_fastbootFlashThread, &FastbootFlashThread::downloadProgress,
            this, [this](quint64 now, quint64 total){
                _performanceStats->recordDownloadProgress(now, total);
            });
    connect(_fastbootFlashThread, &FastbootFlashThread::writeProgress,
            this, [this](quint64 now, quint64 total){
                _performanceStats->recordWriteProgress(now, total);
            });

    _fastbootFlashThread->start();
}

// Point the thread at a cache file for this download, if caching is on.
//
// Both write paths did this identically; only the condition guarding it
// differs between them, which is why the condition stays with each caller.
void ImageWriter::_attachDownloadCache()
{
    // Use CacheManager to setup cache for download
    QString cacheFilePath;
    if (_cacheManager->setupCacheForDownload(_expectedHash, _downloadLen, cacheFilePath))
    {
        qDebug() << "Setting up cache file for download:" << cacheFilePath;
        _thread->setCacheFile(cacheFilePath, _downloadLen);
        // Connect to CacheManager for cache updates (extract uncompressed hash from signal)
        connect(_thread, &DownloadThread::cacheFileHashUpdated,
                this, [this](const QByteArray& cacheFileHash, const QByteArray& imageHash) {
                    qDebug() << "DownloadThread cache update - cacheFileHash:" << cacheFileHash << "imageHash:" << imageHash;
                    // Update cache with both uncompressed hash (imageHash) and compressed hash (cacheFileHash)
                    _cacheManager->updateCacheFile(imageHash, cacheFileHash);
                });
    }
    else
    {
        qDebug() << "Cache setup failed or disabled - proceeding without caching";
    }
}

// Start the configured thread and begin reporting progress.
//
// A multi-file archive is unpacked onto a filesystem rather than written as
// an image, so the card is formatted first and the write starts from that
// thread's success signal instead of directly.
void ImageWriter::_startConfiguredWrite()
{
    if (_multipleFilesInZip)
    {
        static_cast<DownloadExtractThread *>(_thread)->enableMultipleFileExtraction();
        DriveFormatThread *dft = new DriveFormatThread(_dst.toLatin1(), this);
        connect(dft, SIGNAL(success()), _thread, SLOT(start()));
        connect(dft, SIGNAL(error(QString)), SLOT(onError(QString)));
        connect(dft, SIGNAL(preparationStatusUpdate(QString)), SLOT(onPreparationStatusUpdate(QString)));
        connect(dft, &DriveFormatThread::eventDriveFormat,
                this, [this](quint32 durationMs, bool success){
                    _performanceStats->recordEvent(PerformanceStats::EventType::DriveFormat, durationMs, success);
                });
        dft->start();
        setWriteState(WriteState::Writing);
    }
    else
    {
        _thread->start();
        setWriteState(WriteState::Writing);
    }

    startProgressPolling();
}

// Wire up the freshly constructed DownloadThread.
//
// startWrite() and the continuation that resumes after cache verification
// both built a thread and then configured it with the same three hundred
// lines: the extract total, roughly thirty signal connections, the telemetry
// events, verification, the user agent, the customisation payloads and every
// debug switch. The two copies differed by a comment and the prefix on one
// qDebug line, and nothing kept them in step -- which is how the empty-source
// check came to exist on one write path and not the other.
// Where the download counter is reported, if anywhere.
static QByteArray telemetryEndpoint()
{
    // "off" as well as empty, because empty cannot be expressed on Windows.
    // Setting a variable to an empty string there deletes it -- the CRT's
    // _putenv_s does, and so does the shell -- so a caller asking for silence
    // the POSIX way is indistinguishable from one who set nothing at all, and
    // this fell through to the production endpoint.
    //
    // That is not only a user's problem: the suite sets this empty precisely so
    // a fabricated write does not post a download counter to production, and on
    // Windows that protection did nothing at all.
    if (qEnvironmentVariableIsSet("RPI_IMAGER_TELEMETRY_URL")) {
        const QByteArray value = qgetenv("RPI_IMAGER_TELEMETRY_URL");
        if (value.compare("off", Qt::CaseInsensitive) == 0)
            return QByteArray();
        return value;
    }
    return QByteArray(TELEMETRY_URL);
}

void ImageWriter::_configureWriteThread()
{
    // Set the extract size for accurate write progress (compressed images have larger extracted size)
    _thread->setExtractTotal(_extrLen > 0 ? _extrLen : _downloadLen);

    connect(_thread, SIGNAL(success()), SLOT(onSuccess()));
    connect(_thread, SIGNAL(error(QString)), SLOT(onError(QString)));
    connect(_thread, SIGNAL(finalizing()), SLOT(onFinalizing()));
    connect(_thread, SIGNAL(preparationStatusUpdate(QString)), SLOT(onPreparationStatusUpdate(QString)));
    connect(_thread, &DownloadThread::ejectStarted, this, &ImageWriter::onEjectStarted);
    connect(_thread, &DownloadThread::ejectFinished, this, &ImageWriter::onEjectFinished);
    // Clean up the thread that finished, held through a QPointer, and clear
    // the member only if it still names that thread.
    //
    // finished() is queued, and a caller writing a second card is already
    // inside the next write by the time the previous thread's arrives. The
    // member is then the new, running thread: deleting that killed the write
    // outright, leaving the state machine in Finalizing with nothing left to
    // end it. A raw captured pointer is no better, because startWrite() has
    // already called deleteLater() on the old thread; the QPointer is what
    // makes a late arrival harmless either way.
    connect(_thread, &QThread::finished, this, [this, finished = QPointer<DownloadThread>(_thread)]() {
        if (finished)
            finished->deleteLater();
        if (_thread == finished)
            _thread = nullptr;
    });

    // Connect to progress signals if this is a DownloadExtractThread
    DownloadExtractThread *downloadThread = qobject_cast<DownloadExtractThread*>(_thread);
    if (downloadThread) {
        connect(downloadThread, &DownloadExtractThread::downloadProgressChanged,
                this, &ImageWriter::downloadProgress);
        connect(downloadThread, &DownloadExtractThread::writeProgressChanged,
                this, &ImageWriter::writeProgress);
        connect(downloadThread, &DownloadExtractThread::verifyProgressChanged,
                this, &ImageWriter::verifyProgress);
        
        // Connect async write progress signal for event-driven UI updates during WaitForPendingWrites
        // This signal is emitted from IOCP completion callbacks, providing real-time progress
        connect(downloadThread, &DownloadThread::asyncWriteProgress,
                this, &ImageWriter::writeProgress, Qt::QueuedConnection);
        
        // Capture progress for performance stats (lightweight - just stores raw samples)
        connect(downloadThread, &DownloadExtractThread::downloadProgressChanged,
                this, [this](quint64 now, quint64 total){
                    _performanceStats->recordDownloadProgress(now, total);
                });
        connect(downloadThread, &DownloadExtractThread::decompressProgressChanged,
                this, [this](quint64 now, quint64 total){
                    _performanceStats->recordDecompressProgress(now, total);
                });
        connect(downloadThread, &DownloadExtractThread::writeProgressChanged,
                this, [this](quint64 now, quint64 total){
                    _performanceStats->recordWriteProgress(now, total);
                });
        connect(downloadThread, &DownloadThread::asyncWriteProgress,
                this, [this](quint64 now, quint64 total){
                    _performanceStats->recordWriteProgress(now, total);
                }, Qt::QueuedConnection);
        connect(downloadThread, &DownloadExtractThread::verifyProgressChanged,
                this, [this](quint64 now, quint64 total){
                    _performanceStats->recordVerifyProgress(now, total);
                });
        
        // Also transition state to Verifying when verify progress first arrives
        connect(downloadThread, &DownloadExtractThread::verifyProgressChanged,
                this, [this](quint64 /*now*/, quint64 /*total*/){
                    if (_writeState != WriteState::Verifying && _writeState != WriteState::Finalizing &&
                        _writeState != WriteState::Succeeded && _writeState != WriteState::Cancelling)
                        setWriteState(WriteState::Verifying);
                });
        
        // Capture ring buffer stall events for time-series correlation
        connect(downloadThread, &DownloadExtractThread::eventRingBufferStats,
                this, [this](qint64 timestampMs, quint32 durationMs, QString metadata){
                    // Record as an event with explicit startMs from the stall timestamp
                    PerformanceStats::TimedEvent event;
                    event.type = PerformanceStats::EventType::RingBufferStarvation;
                    event.startMs = static_cast<uint32_t>(timestampMs);
                    event.durationMs = durationMs;
                    event.metadata = metadata;
                    event.success = true;
                    event.bytesTransferred = 0;
                    _performanceStats->addEvent(event);
                });
        
        // Pipeline timing summary events (emitted at end of extraction)
        connect(downloadThread, &DownloadExtractThread::eventPipelineDecompressionTime,
                this, [this](quint32 totalMs, quint64 bytesDecompressed){
                    _performanceStats->recordTransferEvent(
                        PerformanceStats::EventType::PipelineDecompressionTime,
                        totalMs, bytesDecompressed, true,
                        QString("bytes: %1 MB").arg(bytesDecompressed / (1024*1024)));
                });
        connect(downloadThread, &DownloadExtractThread::eventPipelineRingBufferWaitTime,
                this, [this](quint32 totalMs, quint64 bytesRead){
                    _performanceStats->recordTransferEvent(
                        PerformanceStats::EventType::PipelineRingBufferWaitTime,
                        totalMs, bytesRead, true,
                        QString("bytes: %1 MB").arg(bytesRead / (1024*1024)));
                });
        connect(downloadThread, &DownloadExtractThread::eventWriteRingBufferStats,
                this, [this](quint64 producerStalls, quint64 consumerStalls, 
                             quint64 producerWaitMs, quint64 consumerWaitMs){
                    QString metadata = QString("producer_stalls: %1 (%2 ms); consumer_stalls: %3 (%4 ms)")
                        .arg(producerStalls).arg(producerWaitMs)
                        .arg(consumerStalls).arg(consumerWaitMs);
                    // Use combined wait time as duration for the event
                    quint32 totalWaitMs = static_cast<quint32>(producerWaitMs + consumerWaitMs);
                    _performanceStats->recordEvent(
                        PerformanceStats::EventType::WriteRingBufferStats,
                        totalWaitMs, true, metadata);
                });
    }
    
    // Connect performance event signals from DownloadThread
    connect(_thread, &DownloadThread::eventDriveUnmount,
            this, [this](quint32 durationMs, bool success){
                _performanceStats->recordEvent(PerformanceStats::EventType::DriveUnmount, durationMs, success);
            });
    connect(_thread, &DownloadThread::eventDriveUnmountVolumes,
            this, [this](quint32 durationMs, bool success){
                _performanceStats->recordEvent(PerformanceStats::EventType::DriveUnmountVolumes, durationMs, success);
            });
    connect(_thread, &DownloadThread::eventDriveDiskClean,
            this, [this](quint32 durationMs, bool success){
                _performanceStats->recordEvent(PerformanceStats::EventType::DriveDiskClean, durationMs, success);
            });
    connect(_thread, &DownloadThread::eventDriveRescan,
            this, [this](quint32 durationMs, bool success){
                _performanceStats->recordEvent(PerformanceStats::EventType::DriveRescan, durationMs, success);
            });
    connect(_thread, &DownloadThread::eventDriveOpen,
            this, [this](quint32 durationMs, bool success, QString metadata){
                _performanceStats->recordEvent(PerformanceStats::EventType::DriveOpen, durationMs, success, metadata);
            });
    connect(_thread, &DownloadThread::eventDriveAuthorization,
            this, [this](quint32 durationMs, bool success){
                _performanceStats->recordEvent(PerformanceStats::EventType::DriveAuthorization, durationMs, success);
                // Start the progress watchdog only after device authorization completes.
                // On macOS, authorization shows system dialogs (passkey + removable media access)
                // that can take an indeterminate amount of time. Starting the watchdog earlier
                // would cause false stall detection during this auth period. (#1511)
                if (success && _progressWatchdog && _thread) {
                    _progressWatchdog->start(_thread);
                }
            });
    // Stop the watchdog before the post-write sync. The fdatasync/fsync can
    // block for minutes on slow cards and no progress indicators advance during
    // it, so the watchdog would otherwise fire a false stall timeout.
    // BlockingQueuedConnection ensures the watchdog is stopped before the
    // download thread enters fdatasync (safe — main thread never waits on
    // the download thread during normal operation).
    connect(_thread, &DownloadThread::finalSyncStarting,
            this, [this](){
                if (_progressWatchdog) {
                    _progressWatchdog->stop();
                }
            }, Qt::BlockingQueuedConnection);
    connect(_thread, &DownloadThread::eventDriveMbrZeroing,
            this, [this](quint32 durationMs, bool success, QString metadata){
                _performanceStats->recordEvent(PerformanceStats::EventType::DriveMbrZeroing, durationMs, success, metadata);
            });
    connect(_thread, &DownloadThread::eventDirectIOAttempt,
            this, [this](bool attempted, bool succeeded, bool currentlyEnabled, int errorCode, QString errorMessage){
                QString metadata = QString("attempted: %1; succeeded: %2; currently_enabled: %3; error_code: %4; error: %5")
                    .arg(attempted ? "yes" : "no")
                    .arg(succeeded ? "yes" : "no")
                    .arg(currentlyEnabled ? "yes" : "no")
                    .arg(errorCode)
                    .arg(errorMessage.isEmpty() ? "none" : errorMessage);
                _performanceStats->recordEvent(PerformanceStats::EventType::DirectIOAttempt, 0, currentlyEnabled, metadata);
                // Update systemInfo with actual direct I/O state now that we know it
                _performanceStats->updateDirectIOEnabled(currentlyEnabled);
            });
    connect(_thread, &DownloadThread::eventCustomisation,
            this, [this](quint32 durationMs, bool success, QString metadata){
                _performanceStats->recordEvent(PerformanceStats::EventType::Customisation, durationMs, success, metadata);
            });
    connect(_thread, &DownloadThread::eventCustomisationVerify,
            this, [this](quint32 durationMs, bool success, QString metadata){
                _performanceStats->recordEvent(PerformanceStats::EventType::CustomisationVerify, durationMs, success, metadata);
            });
    connect(_thread, &DownloadThread::eventFinalSync,
            this, [this](quint32 durationMs, bool success){
                _performanceStats->recordEvent(PerformanceStats::EventType::FinalSync, durationMs, success);
            });
    connect(_thread, &DownloadThread::eventVerify,
            this, [this](quint32 durationMs, bool success, QByteArray writeHash, QByteArray verifyHash){
                QString metadata = QString("Post-write verification; writeHash: %1; verifyHash: %2")
                    .arg(QString::fromLatin1(writeHash), QString::fromLatin1(verifyHash));
                _performanceStats->recordEvent(PerformanceStats::EventType::HashComputation, durationMs, success, metadata);
            });
    connect(_thread, &DownloadThread::eventPeriodicSync,
            this, [this](quint32 durationMs, bool success, quint64 bytesWritten){
                QString metadata = QString("at %1 MB").arg(bytesWritten / (1024 * 1024));
                _performanceStats->recordEvent(PerformanceStats::EventType::PeriodicSync, durationMs, success, metadata);
            });
    connect(_thread, &DownloadThread::eventImageExtraction,
            this, [this](quint32 durationMs, bool success){
                _performanceStats->recordEvent(PerformanceStats::EventType::ImageExtraction, durationMs, success);
            });
    connect(_thread, &DownloadThread::eventPartitionTableWrite,
            this, [this](quint32 durationMs, bool success){
                _performanceStats->recordEvent(PerformanceStats::EventType::PartitionTableWrite, durationMs, success);
            });
    connect(_thread, &DownloadThread::eventFatPartitionSetup,
            this, [this](quint32 durationMs, bool success){
                _performanceStats->recordEvent(PerformanceStats::EventType::FatPartitionSetup, durationMs, success);
            });
    connect(_thread, &DownloadThread::eventDeviceClose,
            this, [this](quint32 durationMs, bool success){
                _performanceStats->recordEvent(PerformanceStats::EventType::DeviceClose, durationMs, success);
            });
    connect(_thread, &DownloadThread::eventDeviceIOTimeout,
            this, [this](quint32 pendingWrites, QString metadata){
                _performanceStats->recordEvent(PerformanceStats::EventType::DeviceIOTimeout, 
                    30000, false, QString("pending=%1; %2").arg(pendingWrites).arg(metadata));
            });
    connect(_thread, &DownloadThread::eventQueueDepthReduction,
            this, [this](int oldDepth, int newDepth, int pendingWrites){
                _performanceStats->recordEvent(PerformanceStats::EventType::QueueDepthReduction, 0, true,
                    QString("depth=%1->%2; pending=%3").arg(oldDepth).arg(newDepth).arg(pendingWrites));
            });
    connect(_thread, &DownloadThread::eventDrainAndHotSwap,
            this, [this](quint32 durationMs, int pendingBefore, bool success){
                _performanceStats->recordEvent(PerformanceStats::EventType::DrainAndHotSwap, durationMs, success,
                    QString("pending=%1").arg(pendingBefore));
            });
    connect(_thread, &DownloadThread::syncFallbackActivated,
            this, [this](QString reason){
                _performanceStats->recordEvent(PerformanceStats::EventType::SyncFallbackActivated, 0, true, reason);
                emit operationWarning(reason);
            });
    connect(_thread, &DownloadThread::requestWriteRestart,
            this, &ImageWriter::restartWrite);
    connect(_thread, &DownloadThread::eventNetworkRetry,
            this, [this](quint32 sleepMs, QString metadata){
                _performanceStats->recordEvent(PerformanceStats::EventType::NetworkRetry, sleepMs, true, metadata);
            });
    connect(_thread, &DownloadThread::eventNetworkConnectionStats,
            this, [this](QString metadata){
                _performanceStats->recordEvent(PerformanceStats::EventType::NetworkConnectionStats, 0, true, metadata);
            });
    
    // Write timing breakdown signals (for detailed hypothesis testing)
    connect(_thread, &DownloadThread::eventWriteTimingBreakdown,
            this, [this](quint32 totalWriteOps, quint64 totalSyscallMs, quint64 totalPreHashWaitMs,
                         quint64 totalPostHashWaitMs, quint64 totalSyncMs, quint32 syncCount){
                QString metadata = QString("writeOps: %1; syscallMs: %2; preHashWaitMs: %3; postHashWaitMs: %4; syncMs: %5; syncCount: %6")
                    .arg(totalWriteOps).arg(totalSyscallMs).arg(totalPreHashWaitMs)
                    .arg(totalPostHashWaitMs).arg(totalSyncMs).arg(syncCount);
                // Use total time (syscall + hash waits) as duration
                quint32 totalMs = static_cast<quint32>(totalSyscallMs + totalPreHashWaitMs + totalPostHashWaitMs);
                _performanceStats->recordEvent(PerformanceStats::EventType::WriteTimingBreakdown, totalMs, true, metadata);
            });
    connect(_thread, &DownloadThread::eventWriteSizeDistribution,
            this, [this](quint32 minSizeKB, quint32 maxSizeKB, quint32 avgSizeKB, quint64 totalBytes, quint32 writeCount){
                QString metadata = QString("minKB: %1; maxKB: %2; avgKB: %3; totalBytes: %4; count: %5")
                    .arg(minSizeKB).arg(maxSizeKB).arg(avgSizeKB).arg(totalBytes).arg(writeCount);
                _performanceStats->recordEvent(PerformanceStats::EventType::WriteSizeDistribution, 0, true, metadata);
            });
    connect(_thread, &DownloadThread::eventWriteAfterSyncImpact,
            this, [this](quint32 avgThroughputBeforeSyncKBps, quint32 avgThroughputAfterSyncKBps, quint32 sampleCount){
                QString metadata = QString("beforeSyncKBps: %1; afterSyncKBps: %2; samples: %3")
                    .arg(avgThroughputBeforeSyncKBps).arg(avgThroughputAfterSyncKBps).arg(sampleCount);
                // Calculate the impact percentage (positive = degradation after sync)
                int impactPercent = 0;
                if (avgThroughputBeforeSyncKBps > 0) {
                    impactPercent = static_cast<int>(100 * (static_cast<int>(avgThroughputBeforeSyncKBps) - static_cast<int>(avgThroughputAfterSyncKBps)) / static_cast<int>(avgThroughputBeforeSyncKBps));
                }
                metadata += QString("; impactPercent: %1").arg(impactPercent);
                _performanceStats->recordEvent(PerformanceStats::EventType::WriteAfterSyncImpact, 0, true, metadata);
            });
    connect(_thread, &DownloadThread::eventAsyncIOConfig,
            this, [this](bool enabled, bool supported, int queueDepth, quint32 pendingAtEnd){
                QString metadata = QString("enabled: %1; supported: %2; queueDepth: %3; pendingAtEnd: %4")
                    .arg(enabled).arg(supported).arg(queueDepth).arg(pendingAtEnd);
                _performanceStats->recordEvent(PerformanceStats::EventType::AsyncIOConfig, 0, true, metadata);
            });
    connect(_thread, &DownloadThread::eventAsyncIOTiming,
            this, [this](quint32 totalMs, quint64 bytesWritten, quint32 writeCount){
                QString metadata = QString("wallClockMs: %1; bytesWritten: %2 MB; writeCount: %3")
                    .arg(totalMs).arg(bytesWritten / (1024*1024)).arg(writeCount);
                _performanceStats->recordTransferEvent(
                    PerformanceStats::EventType::AsyncIOTiming,
                    totalMs, bytesWritten, true, metadata);
            });
    
    // Forward bottleneck state to QML for UI feedback
    connect(_thread, &DownloadThread::bottleneckStateChanged,
            this, [this](DownloadThread::BottleneckState state, quint32 throughputKBps){
                emit bottleneckStatusChanged(
                    DownloadThread::bottleneckStatusText(state), throughputKBps);
            });

    _thread->setVerifyEnabled(_verifyEnabled);
    // Single source of truth for the User-Agent: CurlNetworkConfig (also used by
    // all the libcurl fetch paths via applyCurlSettings) so it can never drift.
    _thread->setUserAgent(CurlNetworkConfig::instance().userAgent());
    qDebug() << "configureWriteThread: passing to thread - initFormat:" << _initFormat << "cloudinit empty:" << _cloudinit.isEmpty() << "cloudinitNetwork empty:" << _cloudinitNetwork.isEmpty();
    _thread->setImageCustomisation(_config, _cmdline, _firstrun, _cloudinit, _cloudinitNetwork, _initFormat, _advancedOptions);
    
    // Pass debug options to the thread
    _thread->setDebugDirectIO(_debugDirectIO);
    _thread->setDebugPeriodicSync(_debugPeriodicSync);
    _thread->setDebugVerboseLogging(_debugVerboseLogging);
    // Disable async I/O if forced to sync mode (due to previous recovery)
    _thread->setDebugAsyncIO(_debugAsyncIO && !_forceSyncMode);
    if (_forceSyncMode) {
        qDebug() << "Compatibility mode active - using synchronous I/O";
    }
    _thread->setDebugAsyncQueueDepth(_debugAsyncQueueDepth);
    _thread->setDebugIPv4Only(_debugIPv4Only);
    _thread->setDebugSkipEndOfDevice(_debugSkipEndOfDevice);
    _thread->setDebugIgnoreDeviceLimits(_debugIgnoreDeviceLimits);
}

// Which kind of write this is going to be.
//
// Extracted from the head of startWrite() so the precedence can be tested.
// The order matters and is not obvious: a device already in fastboot mode
// takes the fastboot path even when the erase sentinel is the selected
// source, because erasing a Compute Module means talking to it over USB
// rather than writing a partition table to a block device.
ImageWriter::WritePath ImageWriter::choosePath() const
{
    if (_isFastbootDevice)
        return WritePath::FastbootDevice;
    if (_isRpibootDevice)
        return WritePath::RpibootDevice;
    if (_src.toString() == QStringLiteral("internal://format"))
        return WritePath::Erase;
    return WritePath::Normal;
}

// Why a local source cannot be written, or an empty string if it can.
//
// Two callers ask this: startWrite(), and the continuation that resumes
// after cache verification. They had a copy each, and the copies had already
// drifted -- the empty-file case was added to one and not the other. One
// definition means the next check added lands on both paths.
QString ImageWriter::_localSourceError(const QString &localPath) const
{
    // isReadable() consults the real ACL only while this is in scope. Without
    // it Qt answers from the read-only attribute alone on Windows, so a file
    // the user has genuinely been denied read access to was reported readable
    // and the write went ahead, failing somewhere less explicable than here.
    //
    // Scoped rather than global: the lookup costs a security-descriptor query
    // per call, and this is the one place that needs the true answer.
    const PlatformQuirks::NativePermissionScope nativePermissions;

    const QFileInfo fi(localPath);

    if (!fi.exists())
        return tr("Source file not found: %1").arg(localPath);
    if (!fi.isFile())
        return tr("Source is not a regular file: %1").arg(localPath);
    if (!fi.isReadable())
        return tr("Source file is not readable: %1").arg(localPath);
    if (fi.size() == 0)
    {
        // An interrupted copy or a failed download saved to disk. It passes
        // the capacity check, extracts to nothing, and the write finishes
        // reporting success -- leaving the user with a card they believe is
        // imaged and no indication otherwise.
        return tr("Source file is empty: %1").arg(localPath);
    }

    return QString();
}

void ImageWriter::startWrite()
{
    // Refuse re-entry while a write is already in progress.  The deferred-watchdog
    // fix (#1511) prevents false stall timeouts during macOS auth, so users should
    // no longer reach this path.  The guard remains as defence-in-depth. (#1511)
    if (_writeState == WriteState::Preparing || _writeState == WriteState::Writing ||
        _writeState == WriteState::Verifying || _writeState == WriteState::Finalizing ||
        _writeState == WriteState::Cancelling) {
        qDebug() << "startWrite: ignoring — write already in progress, state:" << _writeState;
        return;
    }

    // Clean up the previous write's thread, which is routinely still running:
    // the exit paths cannot have collected it yet.
    if (_thread) {
        // Cut it off before letting go. deleteLater() only schedules the
        // deletion, so without this the previous write's queued signals are
        // still delivered afterwards -- finished(), but equally a late
        // success() or error() -- and get answered as though they belonged
        // to the write now starting.
        disconnect(_thread, nullptr, this, nullptr);
        // success() is emitted from inside run(), so a caller acting on it is
        // ahead of the thread ending: with eject on, run() still has a 500 ms
        // sleep and the eject itself to go. Deleting a running QThread is
        // fatal, so let it delete itself once it finishes. The direct call
        // stays for a thread that has already finished, whose finished() has
        // fired and will not fire again; twice is harmless, never is a leak.
        connect(_thread, &QThread::finished, _thread, &QObject::deleteLater);
        if (_thread->isFinished())
            _thread->deleteLater();
        _thread = nullptr;
    }

    // Same for the rpiboot thread — if a previous attempt finished or was
    // cancelled, the handler sets _rpibootThread = nullptr via deleteLater(),
    // but the deletion may still be pending in the event queue.
    if (_rpibootThread) {
        if (_rpibootThread->isRunning()) {
            _rpibootThread->cancel();
            _rpibootThread->wait(5000);
        }
        delete _rpibootThread;
        _rpibootThread = nullptr;
    }

    // Same for the fastboot flash thread.
    if (_fastbootFlashThread) {
        if (_fastbootFlashThread->isRunning()) {
            _fastbootFlashThread->cancel();
            _fastbootFlashThread->wait(5000);
        }
        delete _fastbootFlashThread;
        _fastbootFlashThread = nullptr;
    }

    if (!readyToWrite())
    {
        // Provide a user-visible error rather than silently returning, so the UI can recover
        // Check all conditions and provide comprehensive error messages
        QStringList missingItems;
        
        if (_src.isEmpty())
            missingItems.append(tr("image"));
        if (_dst.isEmpty())
            missingItems.append(tr("storage device"));
        else if (!_selectedDeviceValid)
            missingItems.append(tr("valid storage device (device no longer available)"));
        
        QString reason;
        if (!missingItems.isEmpty())
        {
            if (missingItems.size() == 1)
                reason = tr("No %1 selected.").arg(missingItems.first());
            else
                reason = tr("No %1 selected.").arg(missingItems.join(tr(" or ")));
        }
        else
        {
            reason = tr("Unknown precondition failure.");
        }

        emit error(tr("Cannot start write. %1").arg(reason));
        return;
    }

    setWriteState(WriteState::Preparing);
    setEjectState(EjectState::EjectIdle);

    if (choosePath() == WritePath::FastbootDevice)
    {
        // Already in fastboot mode — go directly to flash
        emit preparationStatusUpdate(tr("Starting fastboot flash..."));
        _fastbootFlashThread = new FastbootFlashThread(
            _fastbootId, _fastbootBlockDevice, _src, _downloadLen, _extrLen, _expectedHash, this);
        _configureAndStartFastbootFlash();
        return;
    }

    if (choosePath() == WritePath::RpibootDevice)
    {
        emit preparationStatusUpdate(tr("Preparing device for imaging..."));

        // Parse the rpiboot device ID to extract USB bus/address/port info
        RpibootThread::DeviceInfo devInfo;

        // rpiboot://bus:addr:port.path:pid -- see rpiboot_types.h
        const rpiboot::DeviceUri parsed =
            rpiboot::parseDeviceUri(_rpibootDeviceId.toStdString());
        devInfo.busNumber = parsed.busNumber;
        devInfo.deviceAddress = parsed.deviceAddress;
        devInfo.portPath = parsed.portPath;
        // Absent or unrecognised, the generation stays at DeviceInfo's own
        // default of BCM2711, which is what this did before.
        if (parsed.chipGeneration)
            devInfo.chipGeneration = *parsed.chipGeneration;

        _rpibootThread = new RpibootThread(devInfo, _rpibootSideloadMode, this);
        if (!_debugCustomFastbootGadget.isEmpty())
            _rpibootThread->setCustomFastbootGadget(_debugCustomFastbootGadget);
        if (_debugSignFastbootGadget) {
            QString rsaKey = _settings.value("secureboot_rsa_key").toString();
            if (rsaKey.isEmpty()) {
                qWarning() << "Debug: Re-provisioning requested, but no secure boot RSA key is configured; signing will be skipped";
            } else {
                _rpibootThread->setSignFastbootGadgetKey(rsaKey);
            }
            _rpibootThread->setReprovisionDevice(true);
        }

        // After sideload, start FastbootFlashThread
        connect(_rpibootThread, &RpibootThread::fastbootDeviceReady, this, &ImageWriter::onRpibootFastbootReady);

        connect(_rpibootThread, &RpibootThread::error, this, &ImageWriter::onRpibootError);
        connect(_rpibootThread, &RpibootThread::preparationStatusUpdate, this, &ImageWriter::onPreparationStatusUpdate);

        // Wire rpiboot timing events to PerformanceStats
        connect(_rpibootThread, &RpibootThread::eventFirmwareSetup,
                this, [this](quint32 ms, bool ok, QString meta){
                    _performanceStats->recordEvent(PerformanceStats::EventType::RpibootFirmwareSetup, ms, ok, meta);
                });
        connect(_rpibootThread, &RpibootThread::eventRpibootProtocol,
                this, [this](quint32 ms, bool ok, QString meta){
                    _performanceStats->recordEvent(PerformanceStats::EventType::RpibootProtocol, ms, ok, meta);
                });
        connect(_rpibootThread, &RpibootThread::eventFastbootWait,
                this, [this](quint32 ms, bool ok){
                    _performanceStats->recordEvent(PerformanceStats::EventType::RpibootFastbootWait, ms, ok);
                });

        _rpibootThread->start();
        return;
    }

    if (choosePath() == WritePath::Erase)
    {
        // For formatting operations, skip all cache operations since we don't need cached files
        qDebug() << "Starting format operation - skipping cache operations";
        DriveFormatThread *dft = new DriveFormatThread(_dst.toLatin1(), this);
        connect(dft, SIGNAL(success()), SLOT(onSuccess()));
        connect(dft, SIGNAL(error(QString)), SLOT(onError(QString)));
        connect(dft, SIGNAL(preparationStatusUpdate(QString)), SLOT(onPreparationStatusUpdate(QString)));
        connect(dft, &DriveFormatThread::eventDriveFormat,
                this, [this](quint32 durationMs, bool success){
                    _performanceStats->recordEvent(PerformanceStats::EventType::DriveFormat, durationMs, success);
                });
        dft->start();
        return;
    }

    QByteArray urlstr = _src.toString(_src.FullyEncoded).toLatin1();

    // Proactive validation for local sources before spawning threads
    if (_src.isLocalFile())
    {
        const QString err = _localSourceError(_src.toLocalFile());
        if (!err.isEmpty())
        {
            onError(err);
            return;
        }
    }

    if (_devLen && _extrLen > _devLen)
    {
        emit error(tr("Storage capacity is not large enough.\n\n"
                      "The image requires at least %1 of storage.")
                   .arg(formatSize(_extrLen)));
        return;
    }

    if (_extrLen && !_multipleFilesInZip && _extrLen % 512 != 0)
    {
        qDebug() << "Image size" << _extrLen << "is not a multiple of 512 bytes. The last sector will be zero-padded.";
    }

    // Start performance stats session early so cache lookup is captured
    // Use platform-specific write device path (e.g., rdisk on macOS for direct I/O)
    QString writeDevicePath = PlatformQuirks::getWriteDevicePath(_dst);
    _performanceStats->startSession(_osName.isEmpty() ? _src.fileName() : _osName, 
                                    _extrLen > 0 ? _extrLen : _downloadLen, 
                                    writeDevicePath);

    // Populate system info for performance analysis
    {
        PerformanceStats::SystemInfo sysInfo;
        auto &memMgr = SystemMemoryManager::instance();
        
        // Memory info
        sysInfo.totalMemoryBytes = static_cast<quint64>(memMgr.getTotalMemoryMB()) * 1024 * 1024;
        sysInfo.availableMemoryBytes = static_cast<quint64>(memMgr.getAvailableMemoryMB()) * 1024 * 1024;
        
        // Device info - use platform-specific write device path
        sysInfo.devicePath = writeDevicePath;
        sysInfo.deviceSizeBytes = _devLen;
        sysInfo.deviceDescription = "";  // Would need DriveListItem lookup
        sysInfo.deviceIsUsb = true;      // Assume USB for now
        sysInfo.deviceIsRemovable = true;
        
        // Platform info
#ifdef Q_OS_MACOS
        sysInfo.osName = "macOS";
#elif defined(Q_OS_LINUX)
        sysInfo.osName = "Linux";
#elif defined(Q_OS_WIN)
        sysInfo.osName = "Windows";
#else
        sysInfo.osName = "Unknown";
#endif
        sysInfo.osVersion = QSysInfo::productVersion();
        sysInfo.cpuArchitecture = QSysInfo::currentCpuArchitecture();
        sysInfo.cpuCoreCount = QThread::idealThreadCount();
        
        // Imager version
        sysInfo.imagerVersion = IMAGER_VERSION_STR;
#ifdef QT_DEBUG
        sysInfo.imagerBuildType = "Debug";
#else
        sysInfo.imagerBuildType = "Release";
#endif
        sysInfo.qtVersion = qVersion();
        sysInfo.qtBuildVersion = QT_VERSION_STR;
        
        // Write configuration - not known yet, will be set later when file is opened
        // These will be set via the DirectIOAttempt event metadata
        sysInfo.directIOEnabled = false;  // Default, actual value set when file opens
        sysInfo.periodicSyncEnabled = true;  // Default
        
        auto syncConfig = memMgr.calculateSyncConfiguration();
        sysInfo.syncIntervalBytes = syncConfig.syncIntervalBytes;
        sysInfo.syncIntervalMs = syncConfig.syncIntervalMs;
        sysInfo.memoryTier = syncConfig.memoryTier;
        
        // Buffer configuration
        sysInfo.writeBufferSize = memMgr.getOptimalWriteBufferSize();
        sysInfo.inputBufferSize = memMgr.getOptimalInputBufferSize();
        sysInfo.inputRingBufferSlots = memMgr.getOptimalRingBufferSlots(sysInfo.inputBufferSize);
        // Write ring buffer is dynamically sized based on optimal queue depth
        // Report the max configurable depth (512) + headroom for logging purposes
        // Actual allocation may be smaller based on available memory
        sysInfo.writeRingBufferSlots = 512 + 4;
        
        _performanceStats->setSystemInfo(sysInfo);
    }

    // Time cache lookup for performance tracking
    // Use hasPotentialCache() which doesn't require verification to be complete
    // This allows us to start verification for cached files that haven't been verified yet
    QElapsedTimer cacheLookupTimer;
    cacheLookupTimer.start();
    bool potentialCacheHit = !_expectedHash.isEmpty() && _cacheManager->hasPotentialCache(_expectedHash);
    _performanceStats->recordEvent(PerformanceStats::EventType::CacheLookup,
        static_cast<quint32>(cacheLookupTimer.elapsed()), true,
        potentialCacheHit ? "potential_hit" : (_expectedHash.isEmpty() ? "no_hash" : "miss"));
    
    if (potentialCacheHit)
    {
        // Use background cache manager to check cache file integrity
        CacheManager::CacheStatus cacheStatus = _cacheManager->getCacheStatus();
        qDebug() << "Cache status: verificationComplete=" << cacheStatus.verificationComplete
                 << "isValid=" << cacheStatus.isValid
                 << "file=" << cacheStatus.cacheFileName;

        if (cacheStatus.verificationComplete && cacheStatus.isValid)
        {
            qDebug() << "Using verified cache file (background verified):" << cacheStatus.cacheFileName;
            // Use cached file
            urlstr = QUrl::fromLocalFile(cacheStatus.cacheFileName).toString(_src.FullyEncoded).toLatin1();
        }
        else if (cacheStatus.verificationComplete && !cacheStatus.isValid)
        {
            qDebug() << "Cache file failed background integrity check, invalidating and proceeding with download";
            _cacheManager->invalidateCache();
            // Continue with original URL - cache will be recreated during download
        }
        else
        {
            // Background verification not yet complete
            qDebug() << "Cache verification needed - waiting for completion";

            // Connect to cache verification progress and completion signals
            connect(_cacheManager, &CacheManager::cacheVerificationProgress,
                    this, &ImageWriter::onCacheVerificationProgress);
            connect(_cacheManager, &CacheManager::cacheVerificationComplete,
                    this, &ImageWriter::onCacheVerificationComplete);

            // Start timing cache verification
            _cacheVerificationTimer.start();
            
            if (!cacheStatus.verificationComplete)
            {
                qDebug() << "Starting cache verification";
                _cacheManager->startVerification(_expectedHash);
            }
            else
            {
                qDebug() << "Verification is already in progress. Waiting for it to complete.";
            }

            // Set flag to indicate we're waiting for cache verification
            _waitingForCacheVerification = true;

            // Emit signal to update UI for cache verification
            emit cacheVerificationStarted();

            // Don't proceed with write yet - wait for cache verification to complete
            return;
        }
    }

    try {
        if (QUrl(urlstr).isLocalFile())
        {
            _thread = createLocalFileThread(urlstr, writeDevicePath.toLatin1(), _expectedHash);
        }
        else
        {
            _thread = createDownloadThread(urlstr, writeDevicePath.toLatin1(), _expectedHash);
            const QByteArray endpoint = telemetryEndpoint();
            if (_repo.toString() == OSLIST_URL && !endpoint.isEmpty())
            {
                DownloadStatsTelemetry *tele = new DownloadStatsTelemetry(urlstr, _parentCategory.toLatin1(), _osName.toLatin1(), isEmbeddedMode(), _currentLangcode, this, endpoint);
                connect(tele, SIGNAL(finished()), tele, SLOT(deleteLater()));
                tele->start();
            }
        }
    } catch (const std::bad_alloc& e) {
        // Memory allocation failed during thread/buffer creation
        qDebug() << "Memory allocation failed during write setup:" << e.what();
        
        // Both of these were written out again here, identically to the
        // handlers below. _localSourceError has the same note: two copies of
        // a message drift, and the one that gets the next fix is whichever
        // the author happened to be looking at.
        _handleMemoryAllocationFailure(e.what());
        return;
    } catch (const std::exception& e) {
        _handleSetupException(e.what());
        return;
    }

    _configureWriteThread();

    // Only set up cache operations for remote downloads, not when using cached files as source
    if (!_expectedHash.isEmpty() && !QUrl(urlstr).isLocalFile())
    {
        _attachDownloadCache();
    }
    else if (!_expectedHash.isEmpty() && QUrl(urlstr).isLocalFile())
    {
        qDebug() << "Using cached file as source - skipping cache setup";
    }

    _startConfiguredWrite();
}

// Cache file update methods removed - now handled by connecting DownloadThread directly to CacheManager

/* Cancel write - for user-initiated cancellation only */
void ImageWriter::_emitCancelled()
{
    // Which of the two the UI hears decides what the user is told: that they
    // cancelled, or that the card was taken out from under the write. The
    // reason is cleared either way -- left set, the next write the user
    // cancels themselves would be reported as a card removal, on a card
    // sitting right there.
    if (_cancelledDueToDeviceRemoval) {
        _cancelledDueToDeviceRemoval = false;
        emit writeCancelledDueToDeviceRemoval();
    } else {
        emit cancelled();
    }
}

DownloadExtractThread *ImageWriter::createLocalFileThread(const QByteArray &url,
                                                          const QByteArray &dst,
                                                          const QByteArray &expectedHash)
{
    return new LocalFileExtractThread(url, dst, expectedHash, this);
}

DownloadExtractThread *ImageWriter::createDownloadThread(const QByteArray &url,
                                                         const QByteArray &dst,
                                                         const QByteArray &expectedHash)
{
    return new DownloadExtractThread(url, dst, expectedHash, this);
}

void ImageWriter::cancelWrite()
{
    setWriteState(WriteState::Cancelling);

    if (_waitingForCacheVerification)
    {
        skipCacheVerification();
        return;
    }

    if (_rpibootThread)
    {
        _rpibootThread->cancel();
        connect(_rpibootThread, &QThread::finished, this, [this]() {
            if (_rpibootThread) {
                _rpibootThread->deleteLater();
                _rpibootThread = nullptr;
            }
            setWriteState(WriteState::Cancelled);
            _emitCancelled();
        });
        return;
    }

    if (_fastbootFlashThread)
    {
        _fastbootFlashThread->cancel();
        connect(_fastbootFlashThread, &QThread::finished, this, [this]() {
            if (_fastbootFlashThread) {
                _fastbootFlashThread->deleteLater();
                _fastbootFlashThread = nullptr;
            }
            setWriteState(WriteState::Cancelled);
            _emitCancelled();
        });
        return;
    }

    if (_thread)
    {
        connect(_thread, SIGNAL(finished()), SLOT(onCancelled()));
        _thread->cancelDownload();
    }

    if (!_thread || !_thread->isRunning())
    {
        // Nothing is running, so no thread will ever finish and call
        // onCancelled() to move the state on. Without this the state stays
        // at Cancelling for good, and startWrite()'s re-entry guard -- which
        // rejects Cancelling -- then silently ignores every write from here
        // on: no error, no progress, nothing on screen. Reached whenever
        // Cancel lands after the write has already finished.
        setWriteState(WriteState::Cancelled);
        _emitCancelled();
    }
}

/* Skip only the current post-write verification pass */
void ImageWriter::skipCurrentVerification()
{
    if (_thread)
    {
        // Temporarily disable verification for the active write thread
        _thread->setVerifyEnabled(false);
        qDebug() << "User requested to skip current verification pass";
    }
}

/* Skip cache verification and proceed with download */
void ImageWriter::skipCacheVerification()
{
    if (!_waitingForCacheVerification)
    {
        qDebug() << "skipCacheVerification called but not waiting for cache verification";
        return;
    }

    qDebug() << "User skipped cache verification, proceeding with download";

    _waitingForCacheVerification = false;

    // Disconnect cache verification signals
    disconnect(_cacheManager, &CacheManager::cacheVerificationProgress,
               this, &ImageWriter::onCacheVerificationProgress);
    disconnect(_cacheManager, &CacheManager::cacheVerificationComplete,
               this, &ImageWriter::onCacheVerificationComplete);

    // Emit signal to update UI (cache verification finished)
    emit cacheVerificationFinished();

    // Proceed with download (not using cache)
    qDebug() << "Cache verification skipped, invalidating cache and proceeding with download";
    _cacheManager->invalidateCache();
    _continueStartWriteAfterCacheVerification(false); // false = cache not valid, use download
}

void ImageWriter::onCancelled()
{
    setWriteState(WriteState::Cancelled);
    stopProgressPolling();

    // Clean up thread
    QObject *senderObj = sender();
    if (senderObj) {
        senderObj->deleteLater();
        if (senderObj == _thread)
        {
            _thread = nullptr;
        }
    }

    // End performance stats session
    _performanceStats->endSession(false, _cancelledDueToDeviceRemoval ? "Device removed" : "Cancelled by user");

    _emitCancelled();
}

/* Return true if url is in our local disk cache */
bool ImageWriter::isCached(const QUrl &, const QByteArray &sha256)
{
    return _cacheManager->isCached(sha256);
}

/* Utility function to return filename part from URL */
QString ImageWriter::fileNameFromUrl(const QUrl &url)
{
    //return QFileInfo(url.toLocalFile()).fileName();
    return url.fileName();
}

QString ImageWriter::srcFileName()
{
    return _src.isEmpty() ? "" : _src.fileName();
}

quint64 ImageWriter::getSelectedSourceSize()
{
    // If we know uncompressed length, prefer that; else return download length
    if (_extrLen > 0) return _extrLen;
    if (_downloadLen > 0) return _downloadLen;
    return 0;
}

namespace {

/* Digits in whatever numbering system the locale uses.
 *
 * Only the digits are mapped. A fractional part is positional, so it must
 * never take the group separator QLocale::toString() would add, and its
 * leading zeros have to survive -- 05 is not 5. Numbering systems whose
 * zero is not a single code unit are left in Latin digits rather than
 * rendered wrongly.
 */
QString localisedDigits(const QLocale &locale, const QString &latinDigits)
{
    const QString zero = locale.zeroDigit();
    if (zero.size() != 1 || zero == QLatin1String("0"))
        return latinDigits;
    const char16_t base = zero.at(0).unicode();
    QString out;
    out.reserve(latinDigits.size());
    for (const QChar c : latinDigits)
        out += QChar(static_cast<char16_t>(base + (c.unicode() - u'0')));
    return out;
}

} // namespace

QString ImageWriter::formatSize(quint64 bytes, int decimals)
{
    /* Decimal, because every figure here is read against a number printed
     * on a card. Dividing by 1024 and labelling it GB is how "requires at
     * least 7.9 GB" appeared over a card sold as 8 GB -- long reported as
     * the warning quoting a size saying the card was big enough. It was
     * not: 8 GB of card is 8,000,000,000 bytes and the image wanted
     * 8,482,560,409. Only the units disagreed with the refusal, by about 7%
     * everywhere. Cards are sold in decimal, so the figures move rather
     * than the labels.
     */
    const quint64 KB = 1000ULL;
    const quint64 MB = KB * 1000ULL;
    const quint64 GB = MB * 1000ULL;
    const quint64 TB = GB * 1000ULL;

    /* The reader's locale decides the digits and the separator between the
     * whole and fractional parts. Grouping is deliberately switched off: a
     * unit escalates at a thousand, so the whole part only passes three
     * digits for terabyte figures no storage reaches, and a separator inside
     * the number is one more thing for anything reading these strings back
     * to have to handle.
     */
    QLocale locale;
    locale.setNumberOptions(locale.numberOptions() | QLocale::OmitGroupSeparator);

    quint64 unit = 1;
    QString unitStr = tr("B");
    if (bytes >= TB) { unit = TB; unitStr = tr("TB"); }
    else if (bytes >= GB) { unit = GB; unitStr = tr("GB"); }
    else if (bytes >= MB) { unit = MB; unitStr = tr("MB"); }
    else if (bytes >= KB) { unit = KB; unitStr = tr("KB"); }

    /* Both halves of the arithmetic below are done in quint64, and the caller
     * chooses how many digits. Seven is as many as the widest unit leaves
     * room for in the product; more than that wraps and reads as an ordinary
     * answer. Well past anything a size is read to.
     */
    const int digits = qMin(decimals, 7);

    // Integer rounding using quotient/remainder, avoiding floating point.
    // Taken from the remainder rather than by adding half a unit to the byte
    // count, which wraps at the top of the range and renders as 0 TB.
    if (digits <= 0) {
        quint64 rounded = bytes / unit;
        if ((bytes % unit) * 2 >= unit)
            ++rounded;
        return tr("%1 %2").arg(locale.toString(qulonglong(rounded)), unitStr);
    }

    quint64 scale = 1;
    for (int i = 0; i < digits; ++i) scale *= 10ULL;

    quint64 q = bytes / unit;
    quint64 r = bytes % unit;
    quint64 fracScaled = (r * scale + unit/2) / unit; // rounded fractional part

    // Normalize carry if rounding overflowed fractional part
    if (fracScaled >= scale) {
        q += 1;
        fracScaled -= scale;
    }

    if (fracScaled == 0) {
        return tr("%1 %2").arg(locale.toString(qulonglong(q)), unitStr);
    }

    QString fracStr = QString::number(fracScaled);
    if (fracStr.length() < digits) {
        fracStr = QString(digits - fracStr.length(), QChar('0')) + fracStr;
    }
    /* Assembled rather than translated: the separator between the whole and
     * fractional parts belongs to the reader's locale, not to the string
     * catalogue. A German reader is shown 1,5 GB where an English one is
     * shown 1.5 GB, and each reads the figure their language writes.
     */
    const QString number = locale.toString(qulonglong(q))
                           + locale.decimalPoint()
                           + localisedDigits(locale, fracStr);
    return tr("%1 %2").arg(number, unitStr);
}

QString ImageWriter::osListUrlForDisplay() const {
    return _repo.toString(QUrl::PreferLocalFile | QUrl::NormalizePathSegments);
}

/* Function to return current OS list URL (may be customized) */
QUrl ImageWriter::osListUrl() const
{
    return _repo;
}

QUrl ImageWriter::defaultOsListUrl()
{
    const QString override = qEnvironmentVariable("RPI_IMAGER_OSLIST_URL");
    if (!override.isEmpty())
        return QUrl(override);
    return QUrl(QString(OSLIST_URL));
}

/* Static version - for use without creating an instance */
QString ImageWriter::staticVersion()
{
    return IMAGER_VERSION_STR;
}

/* Instance method - delegates to static version (needed for QML Q_INVOKABLE) */
QString ImageWriter::constantVersion() const
{
    return staticVersion();
}

/* Returns true if version argument is newer than current program */
bool ImageWriter::isVersionNewer(const QString &version)
{
    // Strip 'v' prefix if present - QVersionNumber requires strings to start with a digit
    QString serverVersion = version.startsWith('v', Qt::CaseInsensitive) ? version.mid(1) : version;
    QString currentVersion = QString(IMAGER_VERSION_STR);
    if (currentVersion.startsWith('v', Qt::CaseInsensitive)) {
        currentVersion = currentVersion.mid(1);
    }
    
    return QVersionNumber::fromString(serverVersion) > QVersionNumber::fromString(currentVersion);
}

void ImageWriter::setCustomOsListUrl(const QUrl &url)
{
    _repo = url;
}

namespace {
    QJsonArray findAndInsertJsonResult(QJsonArray parent_list, QJsonArray incomingBody, QUrl referenceUrl, uint8_t count) {
        if (count > MAX_SUBITEMS_DEPTH) {
            qDebug() << "Aborting insertion of subitems, exceeded maximum configured limit of " << MAX_SUBITEMS_DEPTH << " levels.";
            return {};
        }

        QJsonArray returnArray = {};

        for (auto ositem : parent_list) {
            auto ositemObject = ositem.toObject();

            // subitems_url first, because after a refresh an entry can carry
            // both: the previous contents, kept so the category does not
            // empty while the new sublist is on its way, and the URL the new
            // one is coming from. Recursing on the stale contents instead
            // would leave the arriving sublist with nowhere to land.
            if (ositemObject.contains("subitems_url")
                && !ositemObject["subitems_url"].toString().compare(referenceUrl.toString())) {
                ositemObject.insert("subitems", incomingBody);
                ositemObject.remove("subitems_url");
            } else if (ositemObject.contains("subitems")) {
                // Recurse!
                ositemObject["subitems"] = findAndInsertJsonResult(ositemObject["subitems"].toArray(), incomingBody, referenceUrl, count + 1);
            }

            returnArray += ositemObject;
        }

        return returnArray;
    }

    // Bring a refreshed top-level list up to date without emptying its
    // categories.
    //
    // A category arrives from the repository as a name and a subitems_url,
    // and its contents are fetched separately; once they land, subitems_url
    // is replaced by subitems. So a refreshed list has categories that are
    // once again nothing but a URL, and dropping the previous contents on
    // the floor would blank every category until its sublist came back --
    // or for good, if that fetch then failed, because a category with
    // nothing in it is pruned from the chooser entirely.
    QJsonArray carryOverSubitems(const QJsonArray &previous, const QJsonArray &incoming,
                                 uint8_t count) {
        if (count > MAX_SUBITEMS_DEPTH)
            return incoming;

        QHash<QString, QJsonArray> known;
        for (const auto &entry : previous) {
            const QJsonObject obj = entry.toObject();
            const QString name = obj["name"].toString();
            if (!name.isEmpty() && obj.contains("subitems"))
                known.insert(name, obj["subitems"].toArray());
        }

        QJsonArray returnArray = {};
        for (const auto &entry : incoming) {
            QJsonObject obj = entry.toObject();
            const auto found = known.constFind(obj["name"].toString());
            if (found != known.constEnd()) {
                if (obj.contains("subitems")) {
                    // Both sides have contents: the new list is authoritative
                    // for what is there, and the old one only for categories
                    // nested inside it that have not been refetched yet.
                    obj["subitems"] = carryOverSubitems(*found, obj["subitems"].toArray(),
                                                        count + 1);
                } else if (obj.contains("subitems_url")) {
                    // Kept alongside subitems_url, not instead of it: the
                    // refetch is queued and will replace these.
                    obj.insert("subitems", *found);
                }
            }
            returnArray += obj;
        }

        return returnArray;
    }

    // Centralized URL preflight validation for fetches
    // Note: We intentionally skip filesystem validation (exists/isFile) for local files
    // as these calls can be slow on iCloud-synced directories or network volumes.
    // Invalid local files will fail gracefully when the actual fetch is attempted.
    bool preflightValidateUrl(const QUrl &url, const QString &context)
    {
        if (!url.isValid() || url.scheme().isEmpty()) {
            qWarning() << context << "invalid URL (missing/invalid scheme):" << url.toString();
            return false;
        }
        const QString scheme = url.scheme().toLower();
        if ((scheme == QLatin1String("http") || scheme == QLatin1String("https")) && url.host().isEmpty()) {
            qWarning() << context << "invalid URL (no host):" << url.toString();
            return false;
        }
        // Local file URLs are allowed through - actual file access will validate existence
        return true;
    }

} // namespace anonymous

// Recursively find subitems_url entries in a JSON array and queue fetches
void ImageWriter::queueSublistFetches(const QJsonArray &list, int depth)
{
    if (depth > MAX_SUBITEMS_DEPTH) {
        qDebug() << "Aborting fetch of subitems JSON, exceeded maximum configured limit of" << MAX_SUBITEMS_DEPTH << "levels.";
        return;
    }

    for (const auto &entry : list) {
        auto entryObject = entry.toObject();
        if (entryObject.contains("subitems")) {
            // Recurse into existing subitems
            queueSublistFetches(entryObject["subitems"].toArray(), depth + 1);
        } else if (entryObject.contains("subitems_url")) {
            const QString subUrlStr = entryObject["subitems_url"].toString();
            const QUrl subUrl(subUrlStr);
            if (!preflightValidateUrl(subUrl, QStringLiteral("subitems_url:"))) {
                continue;
            }

            // Create a CurlFetcher for this sublist
            auto *fetcher = new CurlFetcher(this);
            connect(fetcher, &CurlFetcher::finished, this, &ImageWriter::onOsListFetchComplete);
            connect(fetcher, &CurlFetcher::error, this, &ImageWriter::onOsListFetchError);
            connect(fetcher, &CurlFetcher::connectionStats, this, &ImageWriter::onNetworkConnectionStats);
            
            // Track start time for performance
            _pendingFetchStartTimes[subUrl] = QDateTime::currentMSecsSinceEpoch();
            fetcher->fetch(subUrl);
        }
    }
}


void ImageWriter::setHWFilterList(const QJsonArray &tags, const bool &inclusive) {
    _deviceFilter = tags;
    _deviceFilterIsInclusive = inclusive;
    emit hwFilterChanged();
}

void ImageWriter::setHWCapabilitiesList(const QJsonArray &json) {
    // TODO: maybe also clear the sw capabilities as in the UI the OS is unselected when this changes
    _hwCapabilities = json;
}

static inline void pushLower(QStringList &dst, const QString &s) {
    const QString t = s.trimmed().toLower();
    if (!t.isEmpty()) dst.push_back(t);
}

void ImageWriter::setSWCapabilitiesList(const QString &json) {
    _swCapabilities = QJsonArray{};
    QJsonParseError err{};
    const auto doc = QJsonDocument::fromJson(json.toUtf8(), &err);
    if (err.error == QJsonParseError::NoError && doc.isArray()) {
        _swCapabilities = doc.array();
    } else {
        // optional CSV fallback ("a,b,c")
        for (const auto &p : json.split(',', Qt::SkipEmptyParts))
            _swCapabilities.append(p.trimmed().toLower());
    }
}

void ImageWriter::setSWCapabilitiesList(const QVariantList &caps) {
    _swCapabilities = QJsonArray{};
    for (const auto &cap : caps) {
        _swCapabilities.append(cap.toString().trimmed().toLower());
    }
}

QJsonArray ImageWriter::getHWFilterList() {
    return _deviceFilter;
}

bool ImageWriter::getHWFilterListInclusive() {
    return _deviceFilterIsInclusive;
}

bool ImageWriter::checkHWAndSWCapability(const QString &cap, const QString &differentSWCap) {
    return this->checkHWCapability(cap) && this->checkSWCapability(differentSWCap.isEmpty() ? cap : differentSWCap);
}

// Both sides trimmed, deliberately. The capability lists arrive from a
// repository file, and the three routes into them did not agree: the
// comma-separated and QVariantList setters trim each entry, the JSON ones
// store what they were given. A list written ["i2c ", "spi"] therefore lost
// i2c, and losing one takes a customisation option off the screen with
// nothing to say why it is missing.
bool ImageWriter::checkHWCapability(const QString &cap) {
    const auto needle = cap.trimmed().toLower();
    for (const auto &v : _hwCapabilities)
        if (v.toString().trimmed().toLower() == needle) return true;
    return false;
}

bool ImageWriter::checkSWCapability(const QString &cap) {
    const auto needle = cap.trimmed().toLower();
    for (const auto &v : _swCapabilities)
        if (v.toString().trimmed().toLower() == needle) return true;
    return false;
}

void ImageWriter::onOsListFetchComplete(const QByteArray &data, const QUrl &url, const QUrl &effectiveUrl)
{
    // Calculate request duration for performance tracking
    quint32 durationMs = 0;
    qint64 bytesReceived = data.size();
    
    if (_pendingFetchStartTimes.contains(url)) {
        qint64 startTime = _pendingFetchStartTimes.take(url);
        durationMs = static_cast<quint32>(QDateTime::currentMSecsSinceEpoch() - startTime);
    }
    
    // Track if this is the top-level OS list request
    bool isTopLevelRequest = (url == osListUrl());
    
    // Only HTTP(S) redirects can change which server supplies a custom repository.
    const QString repoScheme = url.scheme().toLower();
    const bool redirectsApply = (repoScheme == QLatin1String("http") ||
                                 repoScheme == QLatin1String("https"));
    if (redirectsApply && isTopLevelRequest && customRepo() &&
        effectiveUrl.isValid() && effectiveUrl != url) {
        QString oldHost = _repo.host();
        _repo = effectiveUrl;
        QString newHost = _repo.host();
        qDebug() << "Custom repo URL was redirected. Updated display from" << oldHost << "to" << newHost;
        if (oldHost != newHost) {
            emit customRepoHostChanged();
        }
    }

    auto response_object = QJsonDocument::fromJson(data).object();

    if (response_object.contains("os_list")) {
        // Step 1: Insert the items into the canonical JSON document.
        //         It doesn't matter that these may still contain subitems_url items
        //         As these will be fixed up as the subitems_url instances are blinked in
        bool wasEmpty = _completeOsList.isEmpty();
        
        // Stop network monitoring on any successful fetch (initial or refresh)
        // This handles both the startup case and the "refresh failed, now succeeded" case
        PlatformQuirks::stopNetworkMonitoring();
        
        if (wasEmpty) {
            _completeOsList = QJsonDocument(response_object);
            // Notify UI that OS list is now available (was unavailable, now has data)
            emit osListUnavailableChanged();
        } else if (isTopLevelRequest) {
            /* A refresh of the whole list, which is a replacement and not an
               insertion. The repository asks to be refetched through
               imager.refresh_interval_minutes and scheduleOsListRefresh()
               obliges, so this is the reply to that -- but sending it through
               findAndInsertJsonResult() below looks for an entry whose
               subitems_url is this URL, finds none at the top level, and
               hands back the list exactly as it was. A new release, a changed
               download URL or a corrected checksum therefore never appeared
               in a session that stayed open; only a restart picked it up.

               Contents already fetched for a category are carried across so
               it does not empty while its sublist is refetched below. */
            QJsonObject imager_meta = response_object.contains("imager")
                                          ? response_object["imager"].toObject()
                                          : _completeOsList["imager"].toObject();
            /* Built from the reply rather than from two named keys. The
               repository ships os_list_<locale> beside os_list, and naming
               only the two dropped every localised list the moment anything
               was refetched -- so a reader who changed language after the
               first fetch could never be handed the localised list again,
               whatever locale was asked for. */
            QJsonObject merged = response_object;
            merged["imager"] = imager_meta;
            merged["os_list"] = carryOverSubitems(_completeOsList["os_list"].toArray(),
                                                  response_object["os_list"].toArray(), 1);
            _completeOsList = QJsonDocument(merged);
        } else {
            // Preserve latest top-level imager metadata if present in the top-level fetch
            auto new_list = findAndInsertJsonResult(_completeOsList["os_list"].toArray(), response_object["os_list"].toArray(), url, 1);
            QJsonObject imager_meta = _completeOsList["imager"].toObject();
            if (response_object.contains("imager") && isTopLevelRequest) {
                // Update imager metadata when this reply is for the top-level OS list
                imager_meta = response_object["imager"].toObject();
            }
            /* Start from what is cached, so the localised lists and
               anything else the repository sent survive a sublist arriving.
               See the note in the branch above. */
            QJsonObject merged = _completeOsList.object();
            merged["imager"] = imager_meta;
            merged["os_list"] = new_list;
            _completeOsList = QJsonDocument(merged);
        }

        // Queue fetches for any subitems_url entries
        queueSublistFetches(response_object["os_list"].toArray(), 1);
        emit osListPrepared();
        
        // Record performance event for OS list fetch
        if (durationMs > 0) {
            PerformanceStats::EventType eventType = isTopLevelRequest 
                ? PerformanceStats::EventType::OsListFetch 
                : PerformanceStats::EventType::SublistFetch;
            QString metadata = url.toString();
            _performanceStats->recordTransferEvent(eventType, durationMs, bytesReceived, true, metadata);
        }

        // After processing a top-level list fetch, (re)schedule the next refresh
        if (isTopLevelRequest) {
            scheduleOsListRefresh();
        }
    } else {
        qDebug() << "Incorrectly formatted OS list at:" << url;
        // If this was the top-level fetch and it failed, notify UI
        if (isTopLevelRequest && _completeOsList.isEmpty()) {
            qWarning() << "Top-level OS list fetch failed - malformed response. Operating in offline mode.";
            emit osListUnavailableChanged();
        }
    }
}

void ImageWriter::onOsListFetchError(const QString &errorMessage, const QUrl &url)
{
    // Clean up start time tracking
    _pendingFetchStartTimes.remove(url);
    
    // Track if this is the top-level OS list request
    bool isTopLevelRequest = (url == osListUrl());

    // Detect scheme-less URL usage which commonly happens with local repo files
    if (url.scheme().isEmpty() || !url.isValid()) {
        qWarning() << "Failed to fetch URL '" << url.toString()
                   << "' - the URL appears to be relative or missing a scheme."
                   << "When using a local --repo file, ensure all subitems_url entries are absolute"
                   << "(e.g., file:///path/to/sublist.json or https://...).";
    }

    qDebug() << "Failed to fetch URL [" << url << "]:" << errorMessage;

    // If the top-level OS list fetch fails with a connection error and we haven't
    // tried IPv4-only yet, retry with IPv4-only mode. This handles Windows 11 systems
    // with broken IPv6 routing where DNS returns AAAA records but IPv6 connections
    // time out, while the browser's Happy Eyeballs falls back to IPv4 transparently.
    if (isTopLevelRequest && _completeOsList.isEmpty()
        && !CurlNetworkConfig::instance().ipv4Only()
        && PlatformQuirks::hasNetworkConnectivity()) {
        qDebug() << "OS list fetch failed with connectivity present - retrying with IPv4-only";
        CurlNetworkConfig::instance().setIPv4Only(true);
        _debugIPv4Only = true;
        beginOSListFetch();
        return;
    }

    if (isTopLevelRequest) {
        if (_completeOsList.isEmpty()) {
            // No data at all - notify UI of offline state
            qWarning() << "Top-level OS list fetch failed:" << errorMessage << ". Operating in offline mode.";
            emit osListUnavailableChanged();

            // Embedded has no Retry button, and its poll stops once the network
            // looks ready, so a fetch made a moment too early -- before the
            // lease, or before the clock was set -- was the only one there would
            // ever be. Try again there. The desktop leaves it to the user's
            // Retry and the network monitor, rather than calling a firewalled
            // server every 30 seconds for as long as Imager is open.
            if (isEmbeddedMode()) {
                constexpr int kEmptyListRetryMs = 30 * 1000;
                qWarning() << "Retrying the OS list in" << kEmptyListRetryMs / 1000 << "seconds.";
                _osListRefreshTimer.start(kEmptyListRetryMs);
            }
        } else {
            // We have stale data - reschedule refresh to retry later
            // Use a shorter retry interval (5 minutes) rather than full refresh interval
            qWarning() << "OS list refresh failed:" << errorMessage << ". Will retry in 5 minutes.";
            _osListRefreshTimer.start(5 * 60 * 1000);  // 5 minute retry
            
            // Also start network monitoring to catch when connectivity returns
            if (!PlatformQuirks::hasNetworkConnectivity()) {
                PlatformQuirks::startNetworkMonitoring([this](bool available) {
                    if (available) {
                        qDebug() << "Network restored - retrying OS list refresh";
                        _osListRefreshTimer.stop();  // Cancel pending retry timer
                        QMetaObject::invokeMethod(this, "beginOSListFetch", Qt::QueuedConnection);
                    }
                });
            }
        }
    }
}

void ImageWriter::onNetworkConnectionStats(const QString &statsMetadata, const QUrl &url)
{
    // Record CURL connection timing metrics for performance analysis
    // Format: "dns_ms: X; connect_ms: X; tls_ms: X; ttfb_ms: X; total_ms: X; speed_kbps: X; size_bytes: X; http: X"
    QString fullMetadata = QString("url: %1; %2").arg(url.host(), statsMetadata);
    _performanceStats->recordEvent(PerformanceStats::EventType::NetworkConnectionStats, 0, true, fullMetadata);
}

namespace {
    QJsonArray filterOsListWithHWTags(QJsonArray incoming_os_list, QJsonArray hw_filter, const bool inclusive, uint8_t count) {
        if (count > MAX_SUBITEMS_DEPTH) {
            qDebug() << "Aborting insertion of subitems, exceeded maximum configured limit of " << MAX_SUBITEMS_DEPTH << " levels.";
            return {};
        }

        QJsonArray returnArray = {};

        for (auto ositem : incoming_os_list) {
            auto ositemObject = ositem.toObject();

            if (ositemObject.contains("subitems")) {
                // Recurse!
                ositemObject["subitems"] = filterOsListWithHWTags(ositemObject["subitems"].toArray(), hw_filter, inclusive, count + 1);
                if (ositemObject["subitems"].toArray().count() > 0) {
                    returnArray += ositemObject;
                }
            } else {
                // Filter this one!
                if (ositemObject.contains("devices")) {
                    auto keep = false;
                    const auto ositem_devices = ositemObject["devices"].toArray();

                    for (auto compat_device : ositem_devices) {
                        if (hw_filter.contains(compat_device.toString())) {
                            keep = true;
                            break;
                        }
                    }

                    if (keep) {
                        returnArray.append(ositem);
                    }
                } else {
                    // No devices tags, so work out if we're exclusive or inclusive filtering!
                    if (inclusive) {
                        returnArray.append(ositem);
                    }
                }
            }
        }

        return returnArray;
    }
} // namespace anonymous

QByteArray ImageWriter::getFilteredOSlist()
{
    return getFilteredOSlistDocument().toJson();
}

QJsonDocument ImageWriter::getFilteredOSlistDocument() {
    QJsonArray reference_os_list_array = {};
    QJsonObject reference_imager_metadata = {};

    if (_device_info->hardwareTagsSet()) {
        _deviceFilter = _device_info->getHardwareTags();
    }

    {
        if (!_completeOsList.isEmpty()) {
            if (!_deviceFilter.isEmpty()) {
                reference_os_list_array = filterOsListWithHWTags(_completeOsList.object().value("os_list").toArray(), _deviceFilter, _deviceFilterIsInclusive, 1);
            } else {
                // The device filter can be an empty array when a device filter has not been selected, or has explicitly been selected as
                // "no filtering". In that case, avoid walking the tree and use the unfiltered list.
                reference_os_list_array = _completeOsList.object().value("os_list").toArray();
            }

            reference_imager_metadata = _completeOsList.object().value("imager").toObject();
        }
    }

    reference_os_list_array.append(QJsonObject({
            {"name", QCoreApplication::translate("main", "Erase")},
            {"description", QCoreApplication::translate("main", "Format card as FAT32")},
            {"icon", "../icons/erase.png"},
            {"url", "internal://format"},
        }));

    reference_os_list_array.append(QJsonObject({
            {"name", QCoreApplication::translate("main", "Use custom")},
            {"description", QCoreApplication::translate("main", "Select a custom .img from your computer")},
            {"icon", "../icons/use_custom.png"},
            {"url", "internal://custom"},
        }));

    return QJsonDocument(
        QJsonObject({
            {"imager", reference_imager_metadata},
            {"os_list", reference_os_list_array},
        }
    ));
}

void ImageWriter::beginOSListFetch() {
    const QUrl topUrl = osListUrl();
    if (!preflightValidateUrl(topUrl, QStringLiteral("repository:"))) {
        return;
    }

    // Auto-detect system proxy (e.g. corporate proxy configured in Windows Internet Options).
    // This is a no-op if a proxy was already detected or manually configured.
    CurlNetworkConfig::instance().detectSystemProxy(topUrl);

    // Create a CurlFetcher to fetch the OS list
    auto *fetcher = new CurlFetcher(this);
    connect(fetcher, &CurlFetcher::finished, this, &ImageWriter::onOsListFetchComplete);
    connect(fetcher, &CurlFetcher::error, this, &ImageWriter::onOsListFetchError);
    connect(fetcher, &CurlFetcher::connectionStats, this, &ImageWriter::onNetworkConnectionStats);
    
    // Track start time for performance
    _pendingFetchStartTimes[topUrl] = QDateTime::currentMSecsSinceEpoch();
    
    // This will set up a chain of requests that culminate in the eventual fetch and assembly of
    // a complete cached OS list.
    fetcher->fetch(topUrl);
}

void ImageWriter::refreshOsListFrom(const QUrl &url) {
    setCustomRepo(url);
    bool wasAvailable = !_completeOsList.isEmpty();
    _completeOsList = QJsonDocument();
    if (wasAvailable) {
        // Notify UI that OS list is now unavailable (cleared for refetch)
        emit osListUnavailableChanged();
    }
    _osListRefreshTimer.stop();
#ifndef CLI_ONLY_BUILD
    // Clear icon cache when switching repositories - new repo will have different icons
    IconMultiFetcher::instance().clearCache();
#endif
    beginOSListFetch();
    emit customRepoChanged();
}

void ImageWriter::refreshOsListFromDefaultUrl() {
    refreshOsListFrom(defaultOsListUrl());
}

void ImageWriter::onOsListRefreshTimeout()
{
    qDebug() << "OS list refresh timer fired - refetching";
    beginOSListFetch();
}

void ImageWriter::scheduleOsListRefresh()
{
    // Default: do not refresh if we cannot read settings from current _completeOsList
    int baseMinutes = 0;
    int jitterMinutes = 0;

    // CLI overrides take precedence when set (>= 0)
    // A negative override means "not set". Zero means "switch refresh off",
    // so it must not fall through to the list's value below -- otherwise
    // there is no way to disable a refresh the repository has asked for.
    const bool intervalOverridden = (_refreshIntervalOverrideMinutes >= 0);
    if (intervalOverridden) {
        baseMinutes = _refreshIntervalOverrideMinutes;
    }
    if (_refreshJitterOverrideMinutes >= 0) {
        jitterMinutes = _refreshJitterOverrideMinutes;
    }

    if (!_completeOsList.isEmpty()) {
        QJsonObject root = _completeOsList.object();
        if (root.contains("imager")) {
            QJsonObject imager = root.value("imager").toObject();
            // New optional fields
            if (!intervalOverridden && baseMinutes <= 0 && imager.contains("refresh_interval_minutes")) {
                baseMinutes = imager.value("refresh_interval_minutes").toInt(0);
            }
            if (jitterMinutes <= 0 && imager.contains("refresh_jitter_minutes")) {
                jitterMinutes = imager.value("refresh_jitter_minutes").toInt(0);
            }
        }
    }

    if (baseMinutes <= 0) {
        // No refresh configured; stop timer
        _osListRefreshTimer.stop();
        qDebug() << "OS list refresh disabled (no interval provided)";
        return;
    }

    // Constrain jitter to non-negative
    if (jitterMinutes < 0) jitterMinutes = 0;

    // Compute randomized delay with second-level granularity
    // Base is in minutes; jitter is in minutes but applied as seconds
    const qint64 baseMs = static_cast<qint64>(baseMinutes) * 60 * 1000;
    const int jitterSeconds = jitterMinutes * 60;
    const int extraSeconds = (jitterSeconds > 0) ? QRandomGenerator::global()->bounded(jitterSeconds + 1) : 0;
    qint64 msec = baseMs + static_cast<qint64>(extraSeconds) * 1000;

    // Cap to a reasonable max to avoid overflow. QTimer's interval is an int,
    // so the ceiling is INT_MAX milliseconds -- about 24.8 days. The previous
    // cap of 30 days was itself above that: a list asking for a long interval
    // wrapped to a negative int and the timer then fired every millisecond,
    // re-fetching the OS list in a tight loop.
    constexpr qint64 maxMs = static_cast<qint64>(24) * 24 * 60 * 60 * 1000;
    static_assert(maxMs <= std::numeric_limits<int>::max(),
                  "refresh cap must fit in QTimer's int interval");
    if (msec > maxMs) msec = maxMs;

    _osListRefreshTimer.start(static_cast<int>(msec));
    qDebug() << "Scheduled OS list refresh in" << (msec/1000) << "seconds (base" << (baseMs/1000) << "+ jitter" << extraSeconds << ")";
}

void ImageWriter::setOsListRefreshOverride(int intervalMinutes, int jitterMinutes)
{
    _refreshIntervalOverrideMinutes = intervalMinutes;
    _refreshJitterOverrideMinutes = jitterMinutes;
    // If we already have a list, reschedule now
    if (!_completeOsList.isEmpty()) {
        scheduleOsListRefresh();
    }
}

// TODO: duplicate
void ImageWriter::setCustomRepo(const QUrl &repo)
{
    _repo = repo;
}

void ImageWriter::setCustomCacheFile(const QString &cacheFile, const QByteArray &sha256)
{
    _cacheManager->setCustomCacheFile(cacheFile, sha256);
}

/* Drive list polling runs continuously in background - no explicit start/stop needed */

DriveListModel *ImageWriter::getDriveList()
{
    return &_drivelist;
}

HWListModel *ImageWriter::getHWList()
{
    return &_hwlist;
}

OSListModel *ImageWriter::getOSList()
{
    return &_oslist;
}

void ImageWriter::startProgressPolling()
{
    // Prevent system suspend and display sleep during imaging
    try {
        if (_suspendInhibitor == nullptr)
            _suspendInhibitor = CreateSuspendInhibitor();
    } catch (...) {
        // Continue anyway if we can't create the inhibitor
    }
    
    _dlnow = 0;
    _verifynow = 0;
    
    // Create and start the progress watchdog component
    if (!_progressWatchdog) {
        _progressWatchdog = new WriteProgressWatchdog(this);
        
        // Connect watchdog signals to our handlers
        connect(_progressWatchdog, &WriteProgressWatchdog::switchedToSyncMode,
                this, [this](QString reason) {
                    qDebug() << "Watchdog: Hot-swap to sync mode succeeded";
                    _performanceStats->recordEvent(PerformanceStats::EventType::WatchdogRecovery, 0, true,
                        QString("action=hotSwap; %1").arg(reason));
                    emit operationWarning(reason);
                });
        connect(_progressWatchdog, &WriteProgressWatchdog::restartNeeded,
                this, [this](QString reason) {
                    _performanceStats->recordEvent(PerformanceStats::EventType::WatchdogRecovery, 0, false,
                        QString("action=restart; %1").arg(reason));
                    restartWrite(reason);
                });
        connect(_progressWatchdog, &WriteProgressWatchdog::hardTimeout,
                this, [this](QString error) {
                    _performanceStats->recordEvent(PerformanceStats::EventType::WatchdogRecovery, 0, false,
                        QString("action=hardTimeout; %1").arg(error));
                    onError(error);
                });
        connect(_progressWatchdog, &WriteProgressWatchdog::stallWarning,
                this, [this](int seconds, int pending) {
                    qDebug() << "Stall warning:" << seconds << "s," << pending << "pending";
                    _performanceStats->recordEvent(PerformanceStats::EventType::ProgressStall, 
                        static_cast<uint32_t>(seconds * 1000), true,
                        QString("pending=%1").arg(pending));
                });
    }
    
    // NOTE: The watchdog is NOT started here. It will be started after device
    // authorization completes, via the eventDriveAuthorization signal handler.
    // This prevents false stall detection during the indeterminate macOS auth
    // period where system dialogs block the thread but no I/O has begun. (#1511)
}

void ImageWriter::stopProgressPolling()
{
    // Stop the progress watchdog
    if (_progressWatchdog) {
        _progressWatchdog->stop();
    }
    
    // Release the inhibition on system suspend and display sleep
    if (_suspendInhibitor != nullptr) {
        delete _suspendInhibitor;
        _suspendInhibitor = nullptr;
    }
}

void ImageWriter::restartWrite(QString reason)
{
    qDebug() << "Restarting write:" << reason;
    
    // Show warning to user
    emit operationWarning(reason);
    
    // Force sync mode for the retry
    _forceSyncMode = true;
    
    // Record the failed attempt
    _performanceStats->endSession(false, "Async I/O stall - restarting in sync mode");
    
    // Stop current thread and restart when it finishes
    if (_thread && _thread->isRunning()) {
        connect(_thread, &QThread::finished, this, [this]() {
            qDebug() << "Thread stopped, starting new write in sync mode";
            _thread->deleteLater();
            _thread = nullptr;
            startWrite();
        }, Qt::SingleShotConnection);
        
        _thread->cancelDownload();
    } else {
        // Thread already stopped
        if (_thread) {
            _thread->deleteLater();
            _thread = nullptr;
        }
        startWrite();
    }
}

void ImageWriter::setEjectState(EjectState state)
{
    if (_ejectState == state)
        return;

    _ejectState = state;
    emit ejectStateChanged();
}

void ImageWriter::onEjectStarted()
{
    setEjectState(EjectState::EjectInProgress);
}

void ImageWriter::onEjectFinished(bool succeeded)
{
    // Ignore a stale result if a new write has already reset the state
    if (_ejectState != EjectState::EjectInProgress)
        return;

    setEjectState(succeeded ? EjectState::EjectSucceeded : EjectState::EjectFailed);
}

void ImageWriter::ejectDrive()
{
    // The eject result (queued onEjectFinished) can arrive before the worker's
    // finished() signal, so ejectState alone would let a retry overwrite a
    // thread that is still winding down — check the thread pointer too.
    if (_ejectState == EjectState::EjectInProgress || _manualEjectThread)
        return;

    // Only regular block devices can be ejected (not fastboot targets)
    if (_dst.isEmpty() || _dst.startsWith("fastboot://"))
        return;

    setEjectState(EjectState::EjectInProgress);

    const QString device = _dst;
    // Guard `this` with a QPointer and deliver via the application object: the
    // destructor does not join a slow eject, so the worker must never touch a
    // destroyed ImageWriter.
    QPointer<ImageWriter> self(this);
    QThread *thread = QThread::create([self, device]() {
        PlatformQuirks::DiskResult result =
            PlatformQuirks::ejectDisk(PlatformQuirks::getEjectDevicePath(device));
        const bool succeeded = (result == PlatformQuirks::DiskResult::Success);
        QMetaObject::invokeMethod(QCoreApplication::instance(), [self, succeeded]() {
            if (self)
                self->onEjectFinished(succeeded);
        }, Qt::QueuedConnection);
    });
    _manualEjectThread = thread;
    connect(thread, &QThread::finished, this, [this, thread]() {
        thread->deleteLater();
        // A retry may already own the member; only clear our own pointer.
        if (_manualEjectThread == thread)
            _manualEjectThread = nullptr;
    });
    thread->start();
}

void ImageWriter::setWriteState(WriteState state)
{
    if (_writeState == state)
        return;
    
    WriteState oldState = _writeState;
    _writeState = state;
    
    // Adaptive drive scanning based on write state
    // Pause scanning during write/verify to avoid I/O contention
    // Windows drive enumeration is expensive (~1.5-2 seconds per poll)
    switch (state) {
        case WriteState::Idle:
            // Back to device selection - resume normal scanning
            _drivelist.resumePolling();
            break;
            
        case WriteState::Preparing:
        case WriteState::Writing:
        case WriteState::Verifying:
        case WriteState::Finalizing:
        case WriteState::Cancelling:
            // Pause all scanning during write operations
            // Device removal will be detected by I/O errors in the write thread
            // This avoids 20+ seconds of overhead from drive enumeration
            if (oldState == WriteState::Idle) {
                qDebug() << "Pausing drive scanning during write operation";
                _drivelist.pausePolling();
            }
            break;
            
        case WriteState::Succeeded:
        case WriteState::Failed:
        case WriteState::Cancelled:
            // Operation complete - use slow polling until user navigates away
            // Full resume happens when returning to device selection (Idle state)
            qDebug() << "Write complete, switching to slow drive scanning";
            _drivelist.setSlowPolling();
            break;
    }
    
    emit writeStateChanged();
}

void ImageWriter::setVerifyEnabled(bool verify)
{
    _verifyEnabled = verify;
    if (_thread)
        _thread->setVerifyEnabled(verify);
}

/* Relay events from download thread to QML */
void ImageWriter::onSuccess()
{
    // Guard against a late success signal arriving after an error has
    // already been reported (e.g. FastbootFlashThread falling through
    // after a flash failure).
    if (_writeState == WriteState::Failed || _writeState == WriteState::Cancelled ||
        _writeState == WriteState::Cancelling) {
        qDebug() << "Ignoring late success signal — write already in state:" << _writeState;
        return;
    }

    setWriteState(WriteState::Succeeded);
    stopProgressPolling();

    // End performance stats session
    _performanceStats->endSession(true);

    // Clear Pi Connect token on successful write completion
    clearConnectToken();

    emit success();

    if (_settings.value("beep").toBool()) {
        PlatformQuirks::beep();
    }
}

void ImageWriter::onError(QString msg)
{
    // Guard against duplicate errors - device removal disconnects error signal,
    // but this catches any already-queued signals
    if (_cancelledDueToDeviceRemoval ||
        _writeState == WriteState::Failed ||
        _writeState == WriteState::Cancelled ||
        _writeState == WriteState::Cancelling) {
        qDebug() << "Ignoring duplicate/late error:" << msg;
        return;
    }
    
    setWriteState(WriteState::Failed);
    stopProgressPolling();
    
    // Cancel any running write thread to prevent orphaned operations.
    // Without this, a thread blocked on macOS auth could resume writing
    // after the user starts a new write attempt, causing dual-write crashes. (#1511)
    if (_thread && _thread->isRunning()) {
        _thread->cancelDownload();
    }
    if (_fastbootFlashThread && _fastbootFlashThread->isRunning()) {
        _fastbootFlashThread->cancel();
    }
    
    // End performance stats session with error
    _performanceStats->endSession(false, msg);
    
    emit error(msg);

    if (_settings.value("beep").toBool()) {
        PlatformQuirks::beep();
    }
}

void ImageWriter::onFinalizing()
{
    setWriteState(WriteState::Finalizing);
    _performanceStats->recordFinalising();
    emit finalizing();
}

void ImageWriter::onPreparationStatusUpdate(QString msg)
{
    // heuristic: entering verifying is handled via progress elsewhere
    emit preparationStatusUpdate(msg);
}

void ImageWriter::openFileDialog(const QString &title, const QString &filter, const QString &purpose)
{
#ifndef CLI_ONLY_BUILD
    QSettings settings;
    QString path = settings.value("lastpath").toString();

    // Don't validate the path with filesystem calls (exists/isReadable) - these can be
    // extremely slow on macOS with iCloud-synced directories or network volumes.
    // The native file dialog handles invalid/missing paths gracefully by falling back
    // to its default location.
    if (path.isEmpty())
        path = QStandardPaths::writableLocation(QStandardPaths::DownloadLocation);

    // Use native file dialog with modal behavior to main window
    // The caller's title, not a fixed one: this dialog is also used to pick a
    // repository file, and titling that window "Select image" tells the user
    // to choose the wrong kind of file.
    QString filename = NativeFileDialog::getOpenFileName(title.isEmpty() ? tr("Select image") : title,
                                                        path,
                                                        filter,
                                                        _mainWindow);

    // Process the selected file if one was chosen
    if (!filename.isEmpty())
    {
        onFileSelected(filename, purpose);
    }
#else
    Q_UNUSED(title);
    Q_UNUSED(purpose);
    Q_UNUSED(filter);
#endif
}

void ImageWriter::onFileSelected(QString filename, const QString &purpose)
{
    QFileInfo fi(filename);
    QSettings settings;

    if (fi.isFile())
    {
        QString path = fi.path();
        if (path != settings.value("lastpath"))
        {
            settings.setValue("lastpath", path);
            settings.sync();
        }

        emit fileSelected(QUrl::fromLocalFile(filename), purpose);
    }
    else
    {
        qDebug() << "Item selected is not a regular file";
    }

    // Only delete sender if called from a signal/slot connection
    QObject *senderObj = sender();
    if (senderObj)
    {
        senderObj->deleteLater();
    }
}

bool ImageWriter::isOnline()
{
    // Use platform abstraction for network connectivity check
    bool hasBasicConnectivity = PlatformQuirks::hasNetworkConnectivity();
    
    // For embedded mode, report IP addresses on status display and check time sync
    if (isEmbeddedMode()) {
        if (hasBasicConnectivity) {
            // A link is up before DHCP has answered. Fetching then fails, and a
            // first fetch that fails is not tried again, so keep polling until
            // there is an address the fetch can use.
            bool haveAddress = false;
            const QList<QHostAddress> addresses = QNetworkInterface::allAddresses();
            for (const QHostAddress &a : addresses)
            {
                if (rpi_net::isUsableAddress(a))
                {
                    qDebug() << "IP DETECTED: " << a.toString();
                    emit networkInfo(QString("IP: %1").arg(a.toString()));
                    haveAddress = true;
                    break;
                }
            }
            if (!haveAddress)
                return false;

            // Check if network is truly ready (including time sync)
            bool networkReady = PlatformQuirks::isNetworkReady();
            if (networkReady) {
                _networkchecktimer.stop();

                // Decided by the same state machine as the desktop branch
                // below. This arm had no state at all: it fetched and emitted
                // on every call, so a second caller -- isOnline() is
                // Q_INVOKABLE -- abandoned the fetch in flight and started it
                // again, and a list already in hand was fetched a second time.
                // Embedded is the only mode that polls this, ten times a
                // second, which is where the guard was most needed.
                switch (rpi_net::planPollAction(true, _online,
                                                !_completeOsList.isEmpty())) {
                case rpi_net::PollAction::ComeOnlineAndFetch:
                    _online = true;
                    beginOSListFetch();
                    emit networkOnline();
                    break;
                case rpi_net::PollAction::ComeOnline:
                    _online = true;
                    break;
                default:
                    break;
                }
            }
            return networkReady;
        }
        return false;
    }
    
    // For non-embedded (desktop) mode: if network becomes available after being
    // unavailable, and we never successfully fetched the OS list, trigger a retry.
    // This handles the case where the initial fetch failed due to a firewall blocking
    // access, and the user later grants permission (fixes GitHub issue #1212).
    switch (rpi_net::planPollAction(hasBasicConnectivity, _online,
                                    !_completeOsList.isEmpty())) {
    case rpi_net::PollAction::ComeOnlineAndFetch:
        qDebug() << "Network now available and OS list empty - retrying fetch";
        _online = true;
        beginOSListFetch();
        emit networkOnline();
        break;

    case rpi_net::PollAction::ComeOnline:
        // Network came online but we already have OS list data
        _online = true;
        break;

    case rpi_net::PollAction::GoOffline:
        // Network went offline
        _online = false;
        break;

    case rpi_net::PollAction::ReportUnavailable:
        // No network and no OS list - notify UI so it can show offline state
        // This handles startup without network (fixes GitHub issue #809)
        emit osListUnavailableChanged();

        // Start monitoring for network availability so we can auto-retry
        PlatformQuirks::startNetworkMonitoring([this](bool available) {
            if (available && _completeOsList.isEmpty()) {
                qDebug() << "Network became available - auto-retrying OS list fetch";
                // Use QMetaObject::invokeMethod to ensure we're on the Qt thread
                QMetaObject::invokeMethod(this, "beginOSListFetch", Qt::QueuedConnection);
            }
        });
        break;

    case rpi_net::PollAction::Nothing:
        break;
    }
    
    return hasBasicConnectivity;
}

void ImageWriter::importGitHubKeys(const QString &username)
{
    const QString name = username.trimmed();
    if (!rpi_ssh::isValidGitHubUsername(name)) {
        emit gitHubKeysImported(name, {}, QStringLiteral("invalid"));
        return;
    }

    auto *fetcher = new CurlFetcher(this);
    auto report = [this, name](const QByteArray &body, const QString &error) {
        const rpi_ssh::GitHubKeysResult r = rpi_ssh::interpretGitHubKeysReply(name, body, error);
        if (!r.detail.isEmpty())
            qWarning() << "GitHub keys for" << name << ":" << r.detail;
        emit gitHubKeysImported(name, r.keys,
                                QString::fromLatin1(rpi_ssh::gitHubKeysStatusName(r.status)));
    };
    connect(fetcher, &CurlFetcher::finished, this,
            [report](const QByteArray &data, const QUrl &, const QUrl &) { report(data, QString()); });
    connect(fetcher, &CurlFetcher::error, this,
            [report](const QString &message, const QUrl &) { report(QByteArray(), message); });
    fetcher->fetch(rpi_ssh::gitHubKeysUrl(name));
}

void ImageWriter::pollNetwork()
{
    isOnline();
}

void ImageWriter::onSTPdetected()
{
    // Only show STP warning if we don't already have an IP address
    QList<QHostAddress> addresses = QNetworkInterface::allAddresses();
    bool hasIP = false;
    foreach (QHostAddress a, addresses)
    {
        if (!a.isLoopback() && a.scopeId().isEmpty())
        {
            hasIP = true;
            break;
        }
    }
    
    if (!hasIP)
    {
        emit networkInfo(tr("STP is enabled on your Ethernet switch. Getting IP will take long time."));
    }
}

bool ImageWriter::isEmbeddedMode() const
{
    return ::isEmbeddedMode();
}

bool ImageWriter::hasWindowDecorations() const
{
#ifndef CLI_ONLY_BUILD
    // Embedded mode never has decorations
    if (isEmbeddedMode())
        return false;

    // Check platform - some don't support decorations at all
    QString platform = QGuiApplication::platformName().toLower();
    if (platform == "linuxfb" || platform == "eglfs" ||
        platform == "minimal" || platform == "offscreen")
        return false;

    // Check if main window exists and has been shown
    if (_mainWindow) {
        // Check for explicit frameless hint
        if (_mainWindow->flags() & Qt::FramelessWindowHint)
            return false;

        // Check frame margins - if top margin is 0, WM isn't providing decorations
        // (tiling WMs like i3/sway, WM rules to hide title bars, etc.)
        QMargins margins = _mainWindow->frameMargins();
        if (margins.top() == 0)
            return false;
    }

    return true;
#else
    return false;
#endif
}

/* Mount any USB sticks that can contain source images under /media */
QString ImageWriter::sysBlockRoot() const
{
    return QStringLiteral("/sys/class/block");
}

int ImageWriter::mountReadOnly(const QString &devicePath, const QString &mountPoint)
{
    const QStringList args = { QStringLiteral("-o"), QStringLiteral("ro"),
                               devicePath, mountPoint };
    return QProcess::execute(QStringLiteral("mount"), args);
}

bool ImageWriter::mountUsbSourceMedia()
{
    int devices = 0;
#ifdef Q_OS_LINUX
    const QString blockRoot = sysBlockRoot();
    const QString mediaRoot = usbMediaRoot();

    QDir dir(blockRoot);
    const QStringList list = dir.entryList(QDir::Dirs | QDir::NoDotAndDotDot);

    if (!dir.exists(mediaRoot))
        dir.mkdir(mediaRoot);

    for (const QString &devname : list)
    {
        // mmcblk0 is the card the machine is running from, and anything
        // under devices/virtual is not real storage. Mounting either would
        // be reaching for the wrong disk entirely.
        if (!devname.startsWith("mmcblk0") && !QFile::symLinkTarget(blockRoot+"/"+devname).contains("/devices/virtual/"))
        {
            QString mntdir = mediaRoot+"/"+devname;

            if (dir.exists(mntdir))
            {
                devices++;
                continue;
            }

            dir.mkdir(mntdir);

            if ( mountReadOnly(QStringLiteral("/dev/")+devname, mntdir) == 0 )
                devices++;
            else
                dir.rmdir(mntdir);
        }
    }
#endif
    return devices > 0;
}

QString ImageWriter::usbMediaRoot() const
{
    return QStringLiteral("/media");
}

QByteArray ImageWriter::getUsbSourceOSlist()
{
#ifdef Q_OS_LINUX
    QJsonArray oslist;
    const QString root = usbMediaRoot();
    QDir dir(root);
    const QStringList medialist = dir.entryList(QDir::Dirs | QDir::NoDotAndDotDot);
    QStringList namefilters = {"*.img", "*.zip", "*.gz", "*.xz", "*.zst", "*.wic"};

    for (const QString &devname : medialist)
    {
        QDir subdir(root+"/"+devname);
        const QStringList files = subdir.entryList(namefilters, QDir::Files, QDir::Name);
        for (const QString &file : files)
        {
            QString path = root+"/"+devname+"/"+file;
            QFileInfo fi(path);

            QJsonObject f = {
                {"name", file},
                {"description", devname+"/"+file},
                {"url", QUrl::fromLocalFile(path).toString() },
                {"release_date", ""},
                {"image_download_size", fi.size()}
            };
            oslist.append(f);
        }
    }

    return QJsonDocument(oslist).toJson();
#else
    return QByteArray();
#endif
}

QString ImageWriter::_sshKeyDir()
{
    return QDir::homePath()+"/.ssh";
}

QString ImageWriter::_pubKeyFileName()
{
    return _sshKeyDir()+"/id_rsa.pub";
}

QString ImageWriter::_privKeyFileName()
{
    return _sshKeyDir()+"/id_rsa";
}

QString ImageWriter::getDefaultPubKey()
{
    QByteArray pubkey;
    PlatformQuirks::InvokingUserFsScope asUser;
    QFile pubfile(_pubKeyFileName());

    if (pubfile.exists() && pubfile.open(QFile::ReadOnly))
    {
        pubkey = pubfile.readAll().trimmed();
        pubfile.close();
    }

    return pubkey;
}

bool ImageWriter::hasPubKey()
{
    return QFile::exists(_pubKeyFileName());
}

QString ImageWriter::_sshKeyGen()
{
    return PlatformQuirks::sshKeyGenPath();
}

bool ImageWriter::hasSshKeyGen()
{
    // Embedded builds ship without it whatever any path says.
    if (isEmbeddedMode())
        return false;

    const QString keygen = _sshKeyGen();
    if (keygen.isEmpty())
        return false;
    // A bare name is looked up on PATH; a path has to be what it claims.
    return !keygen.contains(QLatin1Char('/')) || QFile::exists(keygen);
}

void ImageWriter::generatePubKey()
{
    if (!hasPubKey() && !QFile::exists(_privKeyFileName()))
    {
        QDir dir;
        QProcess proc;
        QString progName = _sshKeyGen();
        QStringList args;
        args << "-t" << "rsa" << "-f" << _privKeyFileName() << "-N" << "";
        PlatformQuirks::runAsInvokingUser(progName, args);

        if (!dir.exists(_sshKeyDir()))
        {
            qDebug() << "Creating" << _sshKeyDir();
            PlatformQuirks::InvokingUserFsScope asUser;
            dir.mkdir(_sshKeyDir());
        }

        qDebug() << "Executing:" << progName << args;
        proc.start(progName, args);
        proc.waitForFinished();
        qDebug() << proc.readAll();
    }
}

QString ImageWriter::getTimezone()
{
    return QTimeZone::systemTimeZoneId();
}

QStringList ImageWriter::getTimezoneList()
{
    QStringList timezones;
    QFile f(":/timezones.txt");
    if (f.open(QFile::ReadOnly | QFile::Text)) {
        // SkipEmptyParts, as getCountryList() and getKeymapLayoutList()
        // already do: the resource ends with a newline, so splitting without
        // it left a blank entry at the end of the timezone dropdown that set
        // no timezone at all when picked.
        timezones = QString::fromUtf8(f.readAll()).split('\n', Qt::SkipEmptyParts);
        for (QString &s : timezones)
            s = s.trimmed();
        f.close();
    }

    return timezones;
}

QStringList ImageWriter::getCountryList()
{
    QStringList countries;
    QFile f(":/countries.txt");
    if (f.open(QFile::ReadOnly | QFile::Text))
    {
        countries = QString::fromUtf8(f.readAll()).split('\n', Qt::SkipEmptyParts);
        for (QString &s : countries) s = s.trimmed();
        f.close();
    }

    return countries;
}

QStringList ImageWriter::getKeymapLayoutList()
{
    QFile f(":/keymap-layouts.txt");
    if (!f.open(QFile::ReadOnly | QFile::Text))
        return {};

    QStringList list = QString::fromUtf8(f.readAll())
                           .split('\n', Qt::SkipEmptyParts);
    for (QString &s : list)
        s = s.trimmed();
    return list;
}

QStringList ImageWriter::getCapitalCitiesList()
{
    QStringList cities;
    QFile f(":/capital-cities.txt");
    if (f.open(QFile::ReadOnly | QFile::Text))
    {
        QTextStream in(&f);
        while (!in.atEnd())
        {
            QString line = in.readLine().trimmed();
            // Skip empty lines and comments
            if (line.isEmpty() || line.startsWith('#'))
                continue;
            
            // Parse: CityName|CountryName|CountryCode|Timezone|Language|KeyboardLayout
            QStringList parts = line.split('|');
            if (parts.size() >= 2)
            {
                QString cityName = parts[0];
                QString countryName = parts[1];
                // Format as "City (Country)"
                QString displayName = cityName + " (" + countryName + ")";
                cities.append(displayName);
            }
        }
        f.close();
    }
    
    return cities;
}

QVariantMap ImageWriter::getLocaleDataForCapital(const QString &capitalCity)
{
    QVariantMap result;
    QFile f(":/capital-cities.txt");
    
    if (!f.open(QFile::ReadOnly | QFile::Text))
        return result;
    
    // Extract just the city name from "City (Country)" format
    QString cityNameOnly = capitalCity;
    int parenIndex = capitalCity.indexOf(" (");
    if (parenIndex > 0)
    {
        cityNameOnly = capitalCity.left(parenIndex);
    }
    
    QTextStream in(&f);
    while (!in.atEnd())
    {
        QString line = in.readLine().trimmed();
        // Skip empty lines and comments
        if (line.isEmpty() || line.startsWith('#'))
            continue;
        
        // Parse: CityName|CountryName|CountryCode|Timezone|Language|KeyboardLayout
        QStringList parts = line.split('|');
        if (parts.size() >= 6 && parts[0] == cityNameOnly)
        {
            result["cityName"] = parts[0];
            result["countryName"] = parts[1];
            result["countryCode"] = parts[2];
            result["timezone"] = parts[3];
            result["language"] = parts[4];
            result["keyboard"] = parts[5];
            break;
        }
    }
    f.close();
    
    return result;
}

#ifdef Q_OS_DARWIN
#include "mac/location_helper.h"

// Static callback for location permission - called when permission is granted after timeout
static void locationPermissionCallback(int authorized, void *context)
{
    if (authorized && context) {
        ImageWriter *writer = static_cast<ImageWriter*>(context);
        qDebug() << "Location permission granted via callback, emitting signal";
        QMetaObject::invokeMethod(writer, "locationPermissionGranted", Qt::QueuedConnection);
    }
}
#endif

QString ImageWriter::getSSID()
{
#ifdef Q_OS_DARWIN
    // On macOS, set up a callback to be notified if location permission is granted
    // after the initial timeout. This handles the race condition where the user
    // takes longer than 5 seconds to click "Allow" in the permission dialog.
    // Pass 'this' as context so the callback can emit the signal.
    rpiimager_request_location_permission_async(locationPermissionCallback, this);
#endif
    return WlanCredentials::instance()->getSSID();
}

QString ImageWriter::getPSK()
{
#ifdef Q_OS_DARWIN
    /* On OSX the user is presented with a prompt for the admin password when opening the system key chain.
     * Request user permission through QML dialog instead of QtWidgets QMessageBox. */

    // Set up a flag to track if permission was granted
    _keychainPermissionGranted = false;
    _keychainPermissionReceived = false;

    // Emit signal to show QML permission dialog
    emit keychainPermissionRequested();

    // Wait for user response (with timeout)
    QEventLoop loop;
    QTimer timeout;
    timeout.setSingleShot(true);
    timeout.setInterval(30000); // 30 second timeout

    connect(&timeout, &QTimer::timeout, &loop, &QEventLoop::quit);
    connect(this, &ImageWriter::keychainPermissionResponseReceived, &loop, &QEventLoop::quit);

    timeout.start();
    loop.exec();

    if (!_keychainPermissionReceived || !_keychainPermissionGranted) {
        qDebug() << "Keychain access denied or timed out";
        return QString();
    }

    qDebug() << "Keychain access granted by user";
#endif

    return WlanCredentials::instance()->getPSK();
}

QString ImageWriter::getPSKForSSID(const QString &ssid)
{
    if (ssid.isEmpty()) {
        qDebug() << "ImageWriter::getPSKForSSID(): Empty SSID provided, cannot retrieve PSK";
        return QString();
    }

#ifdef Q_OS_DARWIN
    /* On OSX the user is presented with a prompt for the admin password when opening the system key chain.
     * Request user permission through QML dialog instead of QtWidgets QMessageBox. */

    // Set up a flag to track if permission was granted
    _keychainPermissionGranted = false;
    _keychainPermissionReceived = false;

    // Emit signal to show QML permission dialog
    emit keychainPermissionRequested();

    // Wait for user response (with timeout)
    QEventLoop loop;
    QTimer timeout;
    timeout.setSingleShot(true);
    timeout.setInterval(30000); // 30 second timeout

    connect(&timeout, &QTimer::timeout, &loop, &QEventLoop::quit);
    connect(this, &ImageWriter::keychainPermissionResponseReceived, &loop, &QEventLoop::quit);

    timeout.start();
    loop.exec();

    if (!_keychainPermissionReceived || !_keychainPermissionGranted) {
        qDebug() << "Keychain access denied or timed out";
        return QString();
    }

    qDebug() << "Keychain access granted by user";
#endif

    return WlanCredentials::instance()->getPSKForSSID(ssid.toUtf8());
}

void ImageWriter::keychainPermissionResponse(bool granted)
{
    _keychainPermissionGranted = granted;
    _keychainPermissionReceived = true;
    emit keychainPermissionResponseReceived();
}

bool ImageWriter::getBoolSetting(const QString &key)
{
    /* Some keys have defaults */
    if (key == "telemetry")
        return _settings.value(key, TELEMETRY_ENABLED_DEFAULT).toBool();
    else if (key == "eject")
        return _settings.value(key, true).toBool();
    else if (key == "check_version")
        return _settings.value(key, CHECK_VERSION_DEFAULT).toBool();
    else
        return _settings.value(key).toBool();
}

QString ImageWriter::getStringSetting(const QString &key)
{
    // The Connect organisation API key is a persisted secret: the
    // UI is never allowed to read it back.  Use hasConnectOrgRegistration()
    // / clearConnectOrgRegistration() from QML instead.
    if (key == QLatin1String("connect_org_api_key"))
        return QString();
    return _settings.value(key).toString();
}

void ImageWriter::setConnectOrgRegistration(const QString &apiKey,
                                              const QString &descriptionPrefix)
{
    const QString trimmedKey = apiKey.trimmed();
    const QString trimmedDesc = descriptionPrefix.trimmed();
    if (trimmedKey.isEmpty()) {
        // Leave any existing stored key intact; only update description.
        setConnectOrgDescription(trimmedDesc);
        return;
    }
    // The key is concatenated into "Authorization: Bearer <key>" before
    // hitting curl_slist_append.  Any control character (CR, LF, NUL,
    // etc.) would let a pasted value split the request and inject extra
    // headers — reject up front rather than rely on the receiver.
    for (QChar ch : trimmedKey) {
        if (ch.unicode() < 0x20 || ch.unicode() == 0x7F) {
            qWarning() << "Connect: refusing organisation API key with control characters";
            return;
        }
    }
    _settings.setValue(QStringLiteral("connect_org_api_key"), trimmedKey);
    _settings.setValue(QStringLiteral("connect_org_description"), trimmedDesc);
    _settings.sync();
}

void ImageWriter::setConnectOrgDescription(const QString &descriptionPrefix)
{
    _settings.setValue(QStringLiteral("connect_org_description"),
                       descriptionPrefix.trimmed());
    _settings.sync();
}

void ImageWriter::clearConnectOrgRegistration()
{
    _settings.remove(QStringLiteral("connect_org_api_key"));
    _settings.remove(QStringLiteral("connect_org_description"));
    _settings.sync();
}

bool ImageWriter::hasConnectOrgRegistration() const
{
    return !_settings.value(QStringLiteral("connect_org_api_key"))
                     .toString().isEmpty();
}

QString ImageWriter::getConnectOrgDescription() const
{
    return _settings.value(QStringLiteral("connect_org_description")).toString();
}

QVariantMap ImageWriter::requestOrgAuthKey(const QString &description, int ttlDays)
{
    QVariantMap out;
    out.insert(QStringLiteral("ok"), false);

    const QString apiKey =
        _settings.value(QStringLiteral("connect_org_api_key")).toString();
    if (apiKey.isEmpty()) {
        qWarning() << "Connect: cannot mint auth key — no organisation API key set";
        out.insert(QStringLiteral("error"),
                   tr("No organisation API key is configured."));
        return out;
    }

    // Clamp the TTL.  The signature is Q_INVOKABLE so any QML caller
    // (including a future bug) could ask for a 10-year key; cap it
    // server-independently to a sensible window.  <= 0 falls through
    // to the registrar's "omit field" path so the server picks its
    // own default.
    constexpr int kMaxTtlDays = 30;
    if (ttlDays > kMaxTtlDays)
        ttlDays = kMaxTtlDays;

    ConnectDeviceRegistrar registrar(apiKey, QString());
    auto result = registrar.requestAuthKey(description, ttlDays);
    if (!result.ok) {
        qWarning() << "Connect: auth-key request failed:" << result.errorMessage;
        out.insert(QStringLiteral("error"), result.errorMessage);
        return out;
    }
    // Defence-in-depth: the secret is about to be written into a
    // shell heredoc / cloud-init runcmd as a Pi Connect token.  An
    // attacker who can MITM (or compromise) the Connect API could
    // return a "secret" containing newlines / shell metacharacters,
    // closing the heredoc early and gaining root execution at first
    // boot.  Reject anything that doesn't look like a real auth key.
    if (!verifyAuthKey(result.secret, /*strict=*/false)) {
        qWarning() << "Connect: API returned a secret that does not match the "
                      "expected auth-key format; refusing to use it";
        out.insert(QStringLiteral("error"),
                   tr("Raspberry Pi Connect returned an unexpected response."));
        return out;
    }
    qDebug() << "Connect: minted auth key id=" << result.id;
    // Stash the secret directly in _piConnectToken (and emit the
    // received signal so QML reflects the new token) instead of
    // returning it to QML — keeps the secret off the QML stack and
    // lets discardOrgMintedConnectToken() recognise it later.
    _piConnectToken = result.secret;
    _piConnectTokenIsOrgMinted = true;
    emit connectTokenReceived(result.secret);
    out.insert(QStringLiteral("ok"), true);
    return out;
}

// Debug options implementation (secret menu: Cmd+Option+S on macOS, Ctrl+Alt+S on others)
bool ImageWriter::getDebugDirectIO() const
{
    return _debugDirectIO;
}

void ImageWriter::setDebugDirectIO(bool enabled)
{
    if (_debugDirectIO != enabled) {
        _debugDirectIO = enabled;
        qDebug() << "Debug: Direct I/O" << (enabled ? "enabled" : "disabled");
    }
}

bool ImageWriter::getDebugPeriodicSync() const
{
    return _debugPeriodicSync;
}

void ImageWriter::setDebugPeriodicSync(bool enabled)
{
    if (_debugPeriodicSync != enabled) {
        _debugPeriodicSync = enabled;
        qDebug() << "Debug: Periodic sync" << (enabled ? "enabled" : "disabled");
    }
}

bool ImageWriter::getDebugVerboseLogging() const
{
    return _debugVerboseLogging;
}

void ImageWriter::setDebugVerboseLogging(bool enabled)
{
    if (_debugVerboseLogging != enabled) {
        _debugVerboseLogging = enabled;
        qDebug() << "Debug: Verbose logging" << (enabled ? "enabled" : "disabled");
    }
}

bool ImageWriter::getDebugAsyncIO() const
{
    return _debugAsyncIO;
}

void ImageWriter::setDebugAsyncIO(bool enabled)
{
    if (_debugAsyncIO != enabled) {
        _debugAsyncIO = enabled;
        qDebug() << "Debug: Async I/O" << (enabled ? "enabled" : "disabled");
    }
}

int ImageWriter::getDebugAsyncQueueDepth() const
{
    return _debugAsyncQueueDepth;
}

void ImageWriter::setDebugAsyncQueueDepth(int depth)
{
    // Cap to max ring buffer depth (512) to prevent exceeding allocated slots
    depth = qBound(1, depth, 512);
    if (_debugAsyncQueueDepth != depth) {
        _debugAsyncQueueDepth = depth;
        qDebug() << "Debug: Async queue depth set to" << depth;
    }
}

bool ImageWriter::getDebugIPv4Only() const
{
    return _debugIPv4Only;
}

void ImageWriter::setDebugIPv4Only(bool enabled)
{
    if (_debugIPv4Only != enabled) {
        _debugIPv4Only = enabled;
        // Update the shared network config so all libcurl operations use IPv4-only
        CurlNetworkConfig::instance().setIPv4Only(enabled);
        qDebug() << "Debug: IPv4-only mode" << (enabled ? "enabled" : "disabled");
        
        // If IPv4-only was just enabled and we don't have an OS list yet,
        // retry the fetch - the user likely enabled this because IPv6 was failing
        if (enabled && _completeOsList.isEmpty() && isOnline()) {
            qDebug() << "IPv4-only enabled with empty OS list - retrying fetch";
            beginOSListFetch();
        }
    }
}

bool ImageWriter::getDebugSkipEndOfDevice() const
{
    return _debugSkipEndOfDevice;
}

void ImageWriter::setDebugSkipEndOfDevice(bool enabled)
{
    if (_debugSkipEndOfDevice != enabled) {
        _debugSkipEndOfDevice = enabled;
        qDebug() << "Debug: Skip end-of-device operations" << (enabled ? "enabled (counterfeit card mode)" : "disabled");
    }
}

bool ImageWriter::getDebugIgnoreDeviceLimits() const
{
    return _debugIgnoreDeviceLimits;
}

void ImageWriter::setDebugIgnoreDeviceLimits(bool enabled)
{
    if (_debugIgnoreDeviceLimits != enabled) {
        _debugIgnoreDeviceLimits = enabled;
        qDebug() << "Debug: Ignore device I/O limits" << (enabled ? "enabled" : "disabled");
    }
}

bool ImageWriter::getDebugRpiboot() const
{
    return _debugRpiboot;
}

void ImageWriter::setDebugRpiboot(bool enabled)
{
    if (_debugRpiboot != enabled) {
        _debugRpiboot = enabled;
        _drivelist.setRpibootEnabled(enabled);
        _drivelist.setFastbootScanEnabled(enabled);
        // Sticky across runs — restored in the constructor.
        _settings.setValue(QStringLiteral("debug_rpiboot"), enabled);
        _settings.sync();
        qDebug() << "Debug: Rpiboot/fastboot support" << (enabled ? "enabled" : "disabled");
    }
}

QString ImageWriter::getDebugCustomFastbootGadget() const
{
    return _debugCustomFastbootGadget;
}

void ImageWriter::setDebugCustomFastbootGadget(const QString &path)
{
    // The QML file dialog returns file:// URLs; convert to a local path
    // so downstream code (FirmwareManager::ensureAvailable) can use it
    // with std::filesystem::copy_file.
    QString localPath = path;
    if (localPath.startsWith(QStringLiteral("file://"))) {
        localPath = QUrl(localPath).toLocalFile();
    }
    if (_debugCustomFastbootGadget != localPath) {
        _debugCustomFastbootGadget = localPath;
        qDebug() << "Debug: Custom fastboot gadget" << (localPath.isEmpty() ? "cleared" : localPath);
    }
}

bool ImageWriter::getDebugForceSecureBoot() const
{
    return _debugForceSecureBoot;
}

void ImageWriter::setDebugForceSecureBoot(bool enabled)
{
    if (_debugForceSecureBoot != enabled) {
        _debugForceSecureBoot = enabled;
        qDebug() << "Debug: Force Secure Boot available" << (enabled ? "enabled" : "disabled");
    }
}

bool ImageWriter::getDebugSignFastbootGadget() const
{
    return _debugSignFastbootGadget;
}

void ImageWriter::setDebugSignFastbootGadget(bool enabled)
{
    if (_debugSignFastbootGadget != enabled) {
        _debugSignFastbootGadget = enabled;
        qDebug() << "Debug: Sign fastboot gadget" << (enabled ? "enabled" : "disabled");
    }
}

QString ImageWriter::getRsaKeyFingerprint(const QString &keyPath)
{
    if (keyPath.isEmpty() || !QFile::exists(keyPath)) {
        return QString();
    }

    // The boot ROM hashes its 264-byte (N little-endian || E little-endian) blob
    // to produce the fingerprint it reports back. The PAL builds that same blob
    // natively on every platform, so the fingerprint is just SHA-256 of it.
    const QByteArray bootloaderFormat = SecureBootCrypto::extractRsaPubkeyBin(keyPath);
    if (bootloaderFormat.size() != 264) {
        qDebug() << "getRsaKeyFingerprint: extractRsaPubkeyBin returned"
                 << bootloaderFormat.size() << "bytes, expected 264";
        return QString();
    }

    const QByteArray hash = QCryptographicHash::hash(bootloaderFormat, QCryptographicHash::Sha256);

    QString fingerprint;
    for (int i = 0; i < 16 && i < hash.size(); i++) {
        fingerprint += QString("%1").arg(static_cast<unsigned char>(hash[i]), 2, 16, QChar('0'));
        if (i == 7) fingerprint += ":";
    }
    return fingerprint.toUpper();
}

void ImageWriter::setSetting(const QString &key, const QVariant &value)
{
    _settings.setValue(key, value);
    _settings.sync();
}

void ImageWriter::setForceSecureBootEnabled(bool enabled)
{
    _forceSecureBootEnabled = enabled;
    qDebug() << "Secure boot force-enabled via CLI flag:" << enabled;
}

bool ImageWriter::isSecureBootForcedByCliFlag() const
{
    return _forceSecureBootEnabled;
}

void ImageWriter::setImageCustomisation(const QByteArray &config, const QByteArray &cmdline, const QByteArray &firstrun, const QByteArray &cloudinit, const QByteArray &cloudinitNetwork, const ImageOptions::AdvancedOptions opts, const QByteArray &initFormat)
{
    _config = config;
    _cmdline = cmdline;
    _firstrun = firstrun;
    _cloudinit = cloudinit;
    _cloudinitNetwork = cloudinitNetwork;
    _advancedOptions = opts;
    
    // If initFormat is provided, use it; otherwise keep current value
    // This allows CLI to explicitly set the format along with content
    if (!initFormat.isEmpty()) {
        _initFormat = initFormat;
    }

    qDebug() << "Custom config.txt entries:" << config;
    qDebug() << "Custom cmdline.txt entries:" << cmdline;
    qDebug() << "Custom firstrun.sh:" << firstrun;
    qDebug() << "Cloudinit:" << cloudinit;
    qDebug() << "Advanced options:" << opts;
    qDebug() << "initFormat parameter:" << initFormat << "-> _initFormat:" << _initFormat;
}

void ImageWriter::applyCustomisationFromSettings(const QVariantMap &settings)
{
    // Build customisation payloads from provided settings map
    // This method accepts settings directly (which may be a combination of
    // persistent and ephemeral/runtime settings from the wizard)

    // If the selected image does not support customisation, ensure nothing is staged
    if (_initFormat.isEmpty()) {
        setImageCustomisation(QByteArray(), QByteArray(), QByteArray(), QByteArray(), QByteArray(), NoAdvancedOptions);
        return;
    }

    // Make the selected OS release date available to the generator so it can
    // choose the right password hashing algorithm (yescrypt vs sha256crypt)
    // when hashing a freshly entered plaintext password at generation time.
    QVariantMap s = settings;
    s.insert(QStringLiteral("osReleaseDate"), _osReleaseDate);

    if (_initFormat == "systemd") {
        _applySystemdCustomisationFromSettings(s);
    } else if (_initFormat == "rpi-preseed") {
        _applyRpiPreseedCustomisationFromSettings(s);
    } else {
        // customisation for cloudinit and cloudinit-rpi
        _applyCloudInitCustomisationFromSettings(s);
    }
}

void ImageWriter::_applySystemdCustomisationFromSettings(const QVariantMap &s)
{
    // Use CustomisationGenerator for script generation
    QByteArray script = rpi_imager::CustomisationGenerator::generateSystemdScript(s, _piConnectToken);

    QByteArray cmdlineAppend;
    ImageOptions::AdvancedOptions advOpts = NoAdvancedOptions;

    if (!script.isEmpty()) {
        const QString wifiCountry = s.value("recommendedWifiCountry").toString().trimmed();
        if (!wifiCountry.isEmpty()) {
            // Held to a country code: this lands on the kernel command
            // line, where a space starts another parameter.
            const QString regdom =
                rpi_imager::CustomisationGenerator::sanitisedCountryCode(wifiCountry);
            if (!regdom.isEmpty())
                cmdlineAppend = QByteArray(" ") + QByteArray("cfg80211.ieee80211_regdom=")
                                + regdom.toUtf8();
        }

        // Check if secure boot should be enabled
        // Note: Don't validate rsaKeyPath with QFile::exists() here - it can be slow on
        // iCloud-synced or network paths. The actual write operation will validate the file.
        bool secureBootEnabled = s.value("secureBootEnabled").toBool();
        QString rsaKeyPath = _settings.value("secureboot_rsa_key").toString();
        if (secureBootEnabled && !rsaKeyPath.isEmpty()) {
            advOpts |= ImageOptions::EnableSecureBoot;
            qDebug() << "Secure boot enabled with RSA key:" << rsaKeyPath;
        }
    }

    setImageCustomisation(QByteArray(), cmdlineAppend, script, QByteArray(), QByteArray(), advOpts);
}

void ImageWriter::_applyCloudInitCustomisationFromSettings(const QVariantMap &s)
{
    // Use CustomisationGenerator for cloud-init YAML generation
    const bool sshEnabled = s.value("sshEnabled").toBool();
    const bool hasCcRpi = imageSupportsCcRpi();
    
    QByteArray cloud = rpi_imager::CustomisationGenerator::generateCloudInitUserData(
        s, _piConnectToken, hasCcRpi, sshEnabled, getCurrentUser());
    
    QByteArray netcfg = rpi_imager::CustomisationGenerator::generateCloudInitNetworkConfig(
        s, hasCcRpi);
    
    // Only emit cmdline / advanced options when there is actual content to
    // customise.  A stale persisted recommendedWifiCountry should not cause
    // device writes when customisation was skipped.
    QByteArray cmdlineAppend;
    ImageOptions::AdvancedOptions advOpts = NoAdvancedOptions;

    bool hasContent = !cloud.isEmpty() || !netcfg.isEmpty();
    if (hasContent) {
        const QString wifiCountry = s.value("recommendedWifiCountry").toString().trimmed();
        if (!wifiCountry.isEmpty()) {
            // Held to a country code: this lands on the kernel command
            // line, where a space starts another parameter.
            const QString regdom =
                rpi_imager::CustomisationGenerator::sanitisedCountryCode(wifiCountry);
            if (!regdom.isEmpty())
                cmdlineAppend = QByteArray(" ") + QByteArray("cfg80211.ieee80211_regdom=")
                                + regdom.toUtf8();
        }

        // Check if secure boot should be enabled
        // Note: Don't validate rsaKeyPath with QFile::exists() here - it can be slow on
        // iCloud-synced or network paths. The actual write operation will validate the file.
        bool secureBootEnabled = s.value("secureBootEnabled").toBool();
        QString rsaKeyPath = _settings.value("secureboot_rsa_key").toString();
        if (secureBootEnabled && !rsaKeyPath.isEmpty()) {
            advOpts |= ImageOptions::EnableSecureBoot;
            qDebug() << "Secure boot enabled with RSA key:" << rsaKeyPath;
        }
    }

    setImageCustomisation(QByteArray(), cmdlineAppend, QByteArray(), cloud, netcfg, advOpts);
}

void ImageWriter::_applyRpiPreseedCustomisationFromSettings(const QVariantMap &s)
{
    // Use CustomisationGenerator for rpi-preseed.toml generation
    const bool sshEnabled = s.value("sshEnabled").toBool();
    const bool hasCcRpi = imageSupportsCcRpi();

    QByteArray toml = rpi_imager::CustomisationGenerator::generateRpiPreseedToml(
        s, _piConnectToken, hasCcRpi, sshEnabled, getCurrentUser());

    QByteArray cmdlineAppend;
    ImageOptions::AdvancedOptions advOpts = NoAdvancedOptions;

    // Only emit cmdline / advanced options when there is actual content to
    // customise, so a stale persisted recommendedWifiCountry cannot trigger a
    // device write when customisation was skipped.
    if (!toml.isEmpty()) {
        // Set the Wi-Fi regulatory domain on the kernel cmdline, as the systemd
        // and cloud-init paths do. rpi-preseed's [wlan] applier also sets the
        // country, but only when an SSID is present; doing it here additionally
        // covers the country-without-SSID case and is harmless when both apply.
        const QString wifiCountry = s.value("recommendedWifiCountry").toString().trimmed();
        if (!wifiCountry.isEmpty()) {
            // Held to a country code: this lands on the kernel command
            // line, where a space starts another parameter.
            const QString regdom =
                rpi_imager::CustomisationGenerator::sanitisedCountryCode(wifiCountry);
            if (!regdom.isEmpty())
                cmdlineAppend = QByteArray(" ") + QByteArray("cfg80211.ieee80211_regdom=")
                                + regdom.toUtf8();
        }

        // Check if secure boot should be enabled
        // Note: Don't validate rsaKeyPath with QFile::exists() here - it can be slow on
        // iCloud-synced or network paths. The actual write operation will validate the file.
        bool secureBootEnabled = s.value("secureBootEnabled").toBool();
        QString rsaKeyPath = _settings.value("secureboot_rsa_key").toString();
        if (secureBootEnabled && !rsaKeyPath.isEmpty()) {
            advOpts |= ImageOptions::EnableSecureBoot;
            qDebug() << "Secure boot enabled with RSA key:" << rsaKeyPath;
        }
    }

    // rpi-preseed consumes a single /boot/firmware/rpi-preseed.toml on first
    // boot, so the payload is staged in the firstrun slot; the device writers
    // pick the destination filename from _initFormat. No cmdline pointer to the
    // file is needed (unlike systemd.run= or ds=nocloud): rpi-preseed's units
    // are triggered by the file's presence on the boot partition.
    setImageCustomisation(QByteArray(), cmdlineAppend, toml, QByteArray(), QByteArray(), advOpts);
}

QString ImageWriter::hashUserPassword(const QString &plaintext)
{
    // Hash eagerly so the caller can discard the plaintext immediately and keep
    // only the hash. The algorithm choice (yescrypt vs sha256crypt) follows the
    // currently selected OS's release date. Crypto lives in CustomisationGenerator.
    if (plaintext.isEmpty())
        return QString();
    return rpi_imager::CustomisationGenerator::cryptPassword(plaintext.toUtf8(), _osReleaseDate);
}

bool ImageWriter::savedUserPasswordUsableWithCurrentOs(const QString &cryptHash) const
{
    if (cryptHash.isEmpty())
        return true;
    // sha256crypt is accepted on every target; only a yescrypt hash can be
    // incompatible, and only when the selected OS predates yescrypt support.
    if (!rpi_imager::CustomisationGenerator::isYescryptHash(cryptHash))
        return true;
    return rpi_imager::CustomisationGenerator::osUsesYescrypt(_osReleaseDate);
}

QString ImageWriter::wifiSsidOctetsBase64(const QString &ssid) const
{
    return QString::fromLatin1(ssid.toUtf8().toBase64());
}

void ImageWriter::setSavedCustomisationSettings(const QVariantMap &map)
{
    _settings.beginGroup("imagecustomization");
    _settings.remove("");
    const QStringList keys = map.keys();
    for (const QString &key : keys) {
        _settings.setValue(key, map.value(key));
    }
    _settings.endGroup();
    _settings.sync();
}

QVariantMap ImageWriter::getSavedCustomisationSettings()
{
    QVariantMap result;

    _settings.beginGroup("imagecustomization");
    // Earlier versions stored a derived PMK. It is equivalent to the
    // passphrase for WPA2, so it is deleted rather than kept around.
    if (_settings.contains(QStringLiteral("wifiPasswordCrypt"))) {
        _settings.remove(QStringLiteral("wifiPasswordCrypt"));
        _settings.sync();
    }
    const QStringList keys = _settings.childKeys();
    for (const QString &key : keys) {
        result.insert(key, _settings.value(key));
    }
    _settings.endGroup();

    // Belt-and-braces: deduplicate SSH authorized keys if present.
    // Many UIs allow pasting multiple keys; ensure unique entries using a
    // collision-resistant hash (SHA-256) over each normalized line.
    if (result.contains("sshAuthorizedKeys")) {
        const QString raw = result.value("sshAuthorizedKeys").toString();
        const QStringList lines = raw.split(QRegularExpression("\r?\n"), Qt::SkipEmptyParts);
        QStringList uniqueOrdered;
        QList<QByteArray> seenHashes;
        uniqueOrdered.reserve(lines.size());

        for (const QString &line : lines) {
            const QString trimmed = line.trimmed();
            if (trimmed.isEmpty()) continue;
            const QByteArray hash = QCryptographicHash::hash(trimmed.toUtf8(), QCryptographicHash::Sha256);
            bool already = false;
            for (const QByteArray &h : seenHashes) { if (h == hash) { already = true; break; } }
            if (!already) {
                seenHashes.append(hash);
                uniqueOrdered.append(trimmed);
            }
        }

        result.insert("sshAuthorizedKeys", uniqueOrdered.join("\n"));
    }

    return result;
}

void ImageWriter::setPersistedCustomisationSetting(const QString &key, const QVariant &value)
{
    _settings.beginGroup("imagecustomization");
    _settings.setValue(key, value);
    _settings.endGroup();
    _settings.sync();
}

void ImageWriter::removePersistedCustomisationSetting(const QString &key)
{
    _settings.beginGroup("imagecustomization");
    _settings.remove(key);
    _settings.endGroup();
    _settings.sync();
}

void ImageWriter::clearSavedCustomisationSettings()
{
    _settings.beginGroup("imagecustomization");
    _settings.remove("");
    _settings.endGroup();
    _settings.sync();
}

bool ImageWriter::imageSupportsCustomization()
{
    return !_initFormat.isEmpty();
}

bool ImageWriter::imageSupportsCcRpi()
{
    return _initFormat == "cloudinit-rpi";
}

bool ImageWriter::imageSupportsInterfaceCustomisation()
{
    return _initFormat == "cloudinit-rpi" || _initFormat == "rpi-preseed";
}

QStringList ImageWriter::getTranslations()
{
    QStringList t = _translations.keys();
    t.sort(Qt::CaseInsensitive);
    return t;
}

QString ImageWriter::getCurrentLanguage()
{
    return _currentLang;
}

QString ImageWriter::getCurrentKeyboard()
{
    return _currentKeyboard;
}

void ImageWriter::changeLanguage(const QString &newLanguageName)
{
    if (newLanguageName.isEmpty() || newLanguageName == _currentLang || !_translations.contains(newLanguageName))
        return;

    QString langcode = _translations[newLanguageName];
    qDebug() << "Changing language to" << langcode;

    if (installTranslation(langcode))
    {
        _currentLang = newLanguageName;
        _currentLangcode = langcode;
        /* Numbers as well as words. Only startup set the default locale, so
         * a reader who switched language afterwards was shown translated
         * text with the decimal separator of whatever language the machine
         * started in.
         */
        QLocale::setDefault(QLocale(langcode));
    }
    else
    {
        qDebug() << "Failed to load translation file";
    }
}

void ImageWriter::setLanguageForLocale(const QLocale &locale)
{
    const QString langcode = translationForLocale(locale, _translations.values());
    if (langcode.isEmpty())
        return;

    qDebug() << "Language for locale" << locale.name() << "is" << langcode;
    if (installTranslation(langcode))
    {
        _currentLang = _translations.key(langcode);
        _currentLangcode = langcode;
    }
}

QString ImageWriter::translationForLocale(const QLocale &locale, const QStringList &langcodes)
{
    /* The translations are named with BCP 47 tags ("pt-BR"), the form
       uiLanguages() gives. QTranslator::load(QLocale, ...) would look for
       "pt_BR" instead, and settle for "pt". */
    auto find = [&langcodes](const QString &tag) -> QString {
        for (const QString &langcode : langcodes)
        {
            if (langcode.compare(tag, Qt::CaseInsensitive) == 0)
                return langcode;
        }
        return QString();
    };

    /* One entry at a time, and each settled before the next is looked at.
       Qt adds a likely region to every bare language in LANGUAGE, so a UK
       desktop's en_GB:en arrives as en-Latn-GB, en-GB, en-Latn-US, en-US,
       en-Latn, en. Matching whole tags across the list first gave that
       desktop en-US, and pt_PT:pt pt-BR.

       Within an entry the region is tried before the bare language, and a
       script subtag is passed over on the way: the first entry for Brazil is
       pt-Latn-BR, and for Taiwan zh-Hant-TW, but the translations are pt-BR
       and zh-TW. */
    for (const QString &tag : locale.uiLanguages())
    {
        const QStringList subtags = tag.split('-');
        const QString &language = subtags.first();

        // A region is two letters or three digits; a script is four letters
        for (qsizetype i = 1; i < subtags.size(); ++i)
        {
            const QString &subtag = subtags.at(i);
            if (subtag.size() == 2 || (subtag.size() == 3 && subtag.at(0).isDigit()))
            {
                const QString langcode = find(language + '-' + subtag);
                if (!langcode.isEmpty())
                    return langcode;
                break;
            }
        }

        const QString langcode = find(language);
        if (!langcode.isEmpty())
            return langcode;
    }

    return QString();
}

bool ImageWriter::installTranslation(const QString &langcode)
{
    QList<QTranslator *> translators;
    auto load = [&translators](const QString &code) {
        QTranslator *trans = new QTranslator();
        if (trans->load(":/i18n/rpi-imager_"+code+".qm"))
        {
            translators.append(trans);
            return true;
        }
        delete trans;
        return false;
    };

    /* A regional translation goes over its language's, so what it has not
       translated yet comes out in that language rather than in English:
       pt-BR falls back on pt, zh-TW on zh. Qt searches the translator
       installed last first. */
    const qsizetype dash = langcode.indexOf('-');
    if (dash > 0)
        load(langcode.left(dash));

    if (!load(langcode))
    {
        qDeleteAll(translators);
        return false;
    }

    replaceTranslators(translators);
    return true;
}

void ImageWriter::changeKeyboard(const QString &newKeymapLayout)
{
    if (newKeymapLayout.isEmpty() || newKeymapLayout == _currentKeyboard)
        return;


    _currentKeyboard = newKeymapLayout;
}

void ImageWriter::replaceTranslator(QTranslator *trans)
{
    replaceTranslators({trans});
}

void ImageWriter::replaceTranslators(const QList<QTranslator *> &translators)
{
    for (QTranslator *trans : std::as_const(_translators))
    {
        QCoreApplication::removeTranslator(trans);
        delete trans;
    }

    _translators = translators;
    for (QTranslator *trans : std::as_const(_translators))
        QCoreApplication::installTranslator(trans);

#ifndef CLI_ONLY_BUILD
    if (_engine)
    {
        _engine->retranslate();
    }
#endif

    // Regenerate the OS list, because it has some localised items
    emit osListPrepared();
}

QString ImageWriter::detectPiKeyboard()
{
    unsigned int typenr = 0;
    QFile f("/proc/device-tree/chosen/rpi-country-code");
    if (f.exists() && f.open(f.ReadOnly))
    {
        QByteArray d = f.readAll();
        f.close();

        if (d.length() == 4)
        {
            typenr = d.at(2);
        }
    }

    if (!typenr)
    {
        QDir dir("/dev/input/by-id");
        static QRegularExpression rx("RPI_Wired_Keyboard_([0-9]+)");

        const QStringList entries = dir.entryList(QDir::Files);
        for (const QString &fn : entries)
        {
            QRegularExpressionMatch match = rx.match(fn);
            if (match.hasMatch())
            {
                typenr = match.captured(1).toUInt();
            }
        }
    }

    if (typenr)
    {
        QStringList kbcountries = {
            "",
            "gb",
            "fr",
            "es",
            "us",
            "de",
            "it",
            "jp",
            "pt",
            "no",
            "se",
            "dk",
            "ru",
            "tr",
            "il"
        };

        if (typenr < kbcountries.count())
        {
            return kbcountries.at(typenr);
        }
    }

    return QString();
}

QString ImageWriter::getCurrentUser()
{
    QString user = qgetenv("USER");

    if (user.isEmpty())
        user = qgetenv("USERNAME");

    user = user.toLower();
    if (user.contains(" "))
    {
        auto names = user.split(" ");
        user = names.first();
    }

    if (user.isEmpty() || user == "root")
        user = "pi";

    return user;
}

bool ImageWriter::hasMouse()
{
    return !isEmbeddedMode() || QFile::exists("/dev/input/mouse0");
}

bool ImageWriter::isScreenReaderActive() const
{
#ifndef CLI_ONLY_BUILD
    return _screenReaderActiveCached;
#else
    return false;
#endif
}

bool ImageWriter::customRepo()
{
    // Against the default rather than the constant, so a redirected build
    // still reads as the ordinary repository and shows no "using data from".
    return _repo.toString() != defaultOsListUrl().toString();
}

QString ImageWriter::customRepoHost()
{
    if (!customRepo()) {
        return QString();
    }
    
    if (_repo.isLocalFile()) {
        // For local files, show the filename instead of host
        return _repo.fileName();
    }
    
    // Security: Detect IDN homograph attacks where attackers use lookalike Unicode
    // characters (e.g., Cyrillic 'а' U+0430 looks identical to Latin 'a' U+0061)
    // to create domains like "rаspberrypi.com" that appear legitimate.
    //
    // Strategy: Always display the punycode (ASCII) form of the hostname.
    // If the domain contains non-ASCII characters, the punycode will start with
    // "xn--" making it obvious something is unusual. For example:
    // - "raspberrypi.com" → "raspberrypi.com" (safe, no change)
    // - "rаspberrypi.com" (Cyrillic а) → "xn--rspberrypi-h4e.com" (suspicious)
    
    QString host = _repo.host(QUrl::FullyEncoded);
    
    // Additional check: if decoded host differs from encoded, it contains IDN
    // In this case, prepend a warning indicator
    QString decodedHost = _repo.host(QUrl::FullyDecoded);
    if (!decodedHost.isEmpty() && decodedHost != host) {
        // IDN detected - the punycode form will already show "xn--" prefix
        // Add explicit warning prefix so users know to be cautious
        host = QStringLiteral("⚠ ") + host;
        qWarning() << "IDN hostname detected in custom repo URL:"
                   << "displayed as" << host
                   << "decoded form:" << decodedHost;
    }
    
    // Truncate very long hostnames to prevent UI issues
    if (host.length() > 50) {
        host = host.left(47) + QStringLiteral("...");
    }
    return host;
}

bool ImageWriter::isValidRepoUrl(const QString &url) const
{
    // Validate: must be an http/https URL whose path ends with .json or the
    // manifest extension. An optional query string and/or fragment is allowed
    // after the extension so that pre-signed URLs (e.g. cloud blob storage with
    // a SAS token: ".../manifest.json?sv=...&sig=...") are accepted. The path
    // portion excludes '?' and '#' so the extension must appear before any
    // query/fragment rather than merely somewhere in the URL.
    static const QRegularExpression repoUrlRe(
        QRegularExpression::anchoredPattern(
            QStringLiteral("https?://[^ \\t\\r\\n?#]+\\.(json|" MANIFEST_EXTENSION ")([?#][^ \\t\\r\\n]*)?")),
        QRegularExpression::CaseInsensitiveOption);
    return repoUrlRe.match(url).hasMatch();
}

// Cache-related methods removed - now handled by CacheManager

void ImageWriter::onCacheVerificationProgress(qint64 bytesProcessed, qint64 totalBytes)
{
    if (_waitingForCacheVerification) {
        // Show cache verification progress as "verify" progress
        // This reuses the existing verify progress UI
        emit verifyProgress(bytesProcessed, totalBytes);
        // The progress text will be updated by the QML onVerifyProgress handler
        // which shows "Verifying... X%" - this is perfect for cache verification too
    }
}

void ImageWriter::onCacheVerificationComplete(bool isValid)
{
    if (!_waitingForCacheVerification) {
        return; // Not waiting for this verification
    }

    // Record cache verification duration for performance tracking with hash values
    quint32 verificationDurationMs = static_cast<quint32>(_cacheVerificationTimer.elapsed());
    CacheManager::CacheStatus cacheStatus = _cacheManager->getCacheStatus();
    QString metadata = QString("Cache verification; expectedHash: %1; computedHash: %2")
        .arg(QString::fromLatin1(cacheStatus.cacheFileHash),
             QString::fromLatin1(cacheStatus.computedHash));
    _performanceStats->recordEvent(PerformanceStats::EventType::CacheVerification,
        verificationDurationMs, isValid, metadata);

    _waitingForCacheVerification = false;

    // Disconnect signals to avoid receiving future notifications
    disconnect(_cacheManager, &CacheManager::cacheVerificationProgress,
               this, &ImageWriter::onCacheVerificationProgress);
    disconnect(_cacheManager, &CacheManager::cacheVerificationComplete,
               this, &ImageWriter::onCacheVerificationComplete);

    qDebug() << "Cache verification completed - valid:" << isValid << "duration:" << verificationDurationMs << "ms";

    // Emit signal to update UI (cache verification finished)
    emit cacheVerificationFinished();

    // Continue with the rest of startWrite() logic
    _continueStartWriteAfterCacheVerification(isValid);
}

void ImageWriter::onSelectedDeviceRemoved(const QString &device)
{
    qDebug() << "Device removal detected:" << device << "Current selected:" << _dst << "State:" << static_cast<int>(_writeState);

    // Only react if this is the device we currently have selected
    if (!_dst.isEmpty() && _dst == device) {
        qDebug() << "Selected device" << device << "was removed - invalidating selection";
        _selectedDeviceValid = false;

        // If we're currently writing to this device, cancel the write immediately
        if (_writeState == WriteState::Preparing || _writeState == WriteState::Writing || _writeState == WriteState::Verifying || _writeState == WriteState::Finalizing || _writeState == WriteState::Cancelling) {
            _selectedDeviceValid = false;
            qDebug() << "Cancelling write operation due to device removal";
            
            // Disconnect error signal BEFORE setting flag and cancelling
            // This prevents race where thread emits error() after we decide to show device removal message
            if (_thread) {
                disconnect(_thread, SIGNAL(error(QString)), this, SLOT(onError(QString)));
            }
            
            _cancelledDueToDeviceRemoval = true;
            cancelWrite();
            // Will show specific error message in onCancelled()
        } else if (_writeState == WriteState::Succeeded) {
            // Write completed successfully and now drive was ejected - this is normal
            qDebug() << "Device removed after successful write - ignoring (likely ejected)";
            // Don't notify UI - this is expected behavior after successful write
        } else if (_writeState == WriteState::Failed || _writeState == WriteState::Cancelled) {
            // Write already failed or was cancelled - error message already shown
            qDebug() << "Device removed but write already failed/cancelled - suppressing duplicate notification";
            // Don't notify UI - error already displayed
        } else {
            // Idle state - device removed when not writing
            emit selectedDeviceRemoved();
        }
    }
}

void ImageWriter::_continueStartWriteAfterCacheVerification(bool cacheIsValid)
{
    QString urlstr = _src.toString(_src.FullyEncoded);

    if (cacheIsValid) {
        QString cacheFilePath = _cacheManager->getCacheFilePath(_expectedHash);
        qDebug() << "Using verified cache file:" << cacheFilePath;
        urlstr = QUrl::fromLocalFile(cacheFilePath).toString(_src.FullyEncoded);
    } else {
        qDebug() << "Cache file invalid, invalidating and using original URL";
        _cacheManager->invalidateCache();
    }

    // Proactive validation for local sources before spawning threads
    if (QUrl(urlstr).isLocalFile())
    {
        const QString err = _localSourceError(QUrl(urlstr).toLocalFile());
        if (!err.isEmpty())
        {
            onError(err);
            return;
        }

        // Continue with the write operation (this is the code that was after cache verification)
        // Use platform-specific write device path (e.g., rdisk on macOS for direct I/O)
        QString writeDevicePath = PlatformQuirks::getWriteDevicePath(_dst);
        try {
            _thread = createLocalFileThread(urlstr.toLatin1(), writeDevicePath.toLatin1(), _expectedHash);
        } catch (const std::bad_alloc& e) {
            _handleMemoryAllocationFailure(e.what());
            return;
        } catch (const std::exception& e) {
            _handleSetupException(e.what());
            return;
        }
    }
    else
    {
        // Use platform-specific write device path (e.g., rdisk on macOS for direct I/O)
        QString writeDevicePath = PlatformQuirks::getWriteDevicePath(_dst);
        try {
            _thread = createDownloadThread(urlstr.toLatin1(), writeDevicePath.toLatin1(), _expectedHash);
            const QByteArray endpoint = telemetryEndpoint();
            if (_repo.toString() == OSLIST_URL && !endpoint.isEmpty())
            {
                DownloadStatsTelemetry *tele = new DownloadStatsTelemetry(urlstr.toLatin1(), _parentCategory.toLatin1(), _osName.toLatin1(), isEmbeddedMode(), _currentLangcode, this, endpoint);
                connect(tele, SIGNAL(finished()), tele, SLOT(deleteLater()));
                tele->start();
            }
        } catch (const std::bad_alloc& e) {
            _handleMemoryAllocationFailure(e.what());
            return;
        } catch (const std::exception& e) {
            _handleSetupException(e.what());
            return;
        }
    }

    _configureWriteThread();

    // Handle caching setup for downloads using CacheManager
    // Only set up caching when we're downloading (not using cached file as source)
    //
    // startWrite() asks this differently -- !QUrl(urlstr).isLocalFile() rather
    // than !cacheIsValid -- and the two disagree in one reachable case: a
    // local source with an expected hash, which the CLI allows
    // (`--sha256 <hash> /path/image.img`), where a stale cache for that hash
    // sends us here with cacheIsValid false and urlstr still pointing at the
    // user's own file. This branch then sets up a download cache for a file
    // already on disk and copies it into the cache for nothing.
    if (!_expectedHash.isEmpty() && !cacheIsValid)
    {
        _attachDownloadCache();
    }
    else if (cacheIsValid)
    {
        qDebug() << "Using cached file as source - skipping cache setup";
    }

    // Start the actual write operation
    _startConfiguredWrite();
}

ImageWriter::RebootPath ImageWriter::rebootPathFor(bool embedded)
{
    return embedded ? RebootPath::KernelCallThenQuit : RebootPath::ExternalCommand;
}

void ImageWriter::reboot()
{
    qDebug() << "Rebooting system.";
    if (rebootPathFor(isEmbeddedMode()) == RebootPath::KernelCallThenQuit) {
#ifdef Q_OS_LINUX
        ::sync();
        ::reboot(RB_AUTOBOOT);
        // Only reached if the kernel refused.
        qWarning() << "reboot(RB_AUTOBOOT) failed:" << strerror(errno)
                   << "- quitting so init reboots";
#endif
        QCoreApplication::quit();
        return;
    }

    const int rc = QProcess::execute(QStringLiteral("/sbin/reboot"), QStringList());
    if (rc != 0)
        qWarning() << "/sbin/reboot did not run cleanly, result" << rc;
}

bool ImageWriter::isHttpUrl(const QUrl &url)
{
    /* A page, and nothing else. The opener hands the address to the desktop,
     * which picks a handler by scheme: file: reaches a file manager, and the
     * platforms each keep schemes that reach something worse. Not every
     * address here is ours -- an OS list entry names its own page, and the
     * update check names a release -- so the scheme is checked rather than
     * assumed, and the host has to be there for it to be a page at all.
     */
    if (!url.isValid() || url.isRelative() || url.host().isEmpty())
        return false;
    const QString scheme = url.scheme().toLower();
    return scheme == QLatin1String("http") || scheme == QLatin1String("https");
}

void ImageWriter::openUrl(const QUrl &url)
{
    qDebug() << "Opening URL:" << url.toString();

    if (!isHttpUrl(url)) {
        qWarning() << "Refusing to open URL that is not a web page:" << url.scheme();
        return;
    }

    // Platform-native URL launching lives in the PAL (PlatformQuirks). It
    // returns false when it cannot — or deliberately will not — open the URL
    // itself (e.g. xdg-open is missing, or Windows defers to Qt to avoid
    // passing the URL through a shell), in which case we fall back to Qt's
    // cross-platform opener below.
    if (PlatformQuirks::openUrlExternally(url)) {
        return;
    }

#ifndef CLI_ONLY_BUILD
    qDebug() << "Falling back to QDesktopServices::openUrl";
    QDesktopServices::openUrl(url);
#else
    qWarning() << "Unable to open URL in CLI mode:" << url.toString();
#endif
}

void ImageWriter::announceToScreenReader(const QString &message)
{
#ifndef CLI_ONLY_BUILD
    /* A write takes minutes and moves nothing: the percentage lives in a
     * label the user is not on, and a reader speaks what the user moved to.
     * So the progress the sighted user watches is, to everyone else, silence
     * until the machine finishes.
     *
     * An announcement is the one event that asks for something to be read
     * out where the user already is. Polite, so it waits for whatever is
     * being spoken rather than cutting across it.
     *
     * Nothing is built when nothing is listening, so an ordinary run pays
     * for none of this.
     */
    if (message.isEmpty() || !QAccessible::isActive())
        return;

    QObject *target = QGuiApplication::focusWindow();
    if (!target)
        target = QGuiApplication::focusObject();
    if (!target)
        return;

    QAccessibleAnnouncementEvent ev(target, message);
    ev.setPoliteness(QAccessible::AnnouncementPoliteness::Polite);
    QAccessible::updateAccessibility(&ev);
#else
    Q_UNUSED(message)
#endif
}

bool ImageWriter::verifyAuthKey(const QString &s, bool strict) const
{
    // Base58 (no 0 O I l)
    static const QRegularExpression base58OnlyRe(QStringLiteral("^[1-9A-HJ-NP-Za-km-z]+$"));

    // Required prefix
    // rpdev_ is an access token from the device-code sign-in, which writes
    // state.json rather than auth.key; the exact length below is for keys.
    const bool isDeviceToken = s.startsWith(QStringLiteral("rpdev_"));
    bool hasPrefix = isDeviceToken || s.startsWith(QStringLiteral("rpuak_")) || s.startsWith(QStringLiteral("rpoak_"));
    if (!hasPrefix)
        return false;

    const QString payload = s.mid(6);
    bool base58Match = base58OnlyRe.match(payload).hasMatch();
    
    if (payload.isEmpty() || !base58Match)
        return false;

    if (strict && !isDeviceToken) {
        // Exactly 24 Base58 chars today → total length 30
        return payload.size() == 24;
    } else {
        // Future-proof: accept >=24 Base58 chars
        return payload.size() >= 24;
    }
}

QString ImageWriter::parseTokenFromUrl(const QUrl &url, bool strictAuthKey) const {
    // Handle QUrl or string, accept auth_key
    if (!url.isValid())
        return {};

    QUrlQuery q(url);
    const QString val = q.queryItemValue(QStringLiteral("auth_key"), QUrl::FullyDecoded);
    if (!val.isEmpty()) {
        if (verifyAuthKey(val, strictAuthKey)) {
            return val;
        }

        qWarning() << "Ignoring auth_key with invalid format/length:" << val;
    }

    return {};
}

void ImageWriter::handleIncomingUrl(const QUrl &url)
{
    qDebug() << "Incoming URL:" << url;

    // Check if this is a local file URL for a manifest file (double-click on manifest or .json file)
    if (url.isLocalFile()) {
        const QString localPath = url.toLocalFile();
        if (localPath.endsWith(QLatin1String("." MANIFEST_EXTENSION), Qt::CaseInsensitive) ||
            localPath.endsWith(QStringLiteral(".json"), Qt::CaseInsensitive)) {
            QFileInfo fi(localPath);
            if (fi.isFile() && fi.isReadable()) {
                qDebug() << "Local manifest file opened:" << localPath;
                // Local files are trusted (user explicitly opened them) — load directly
                // without a confirmation dialog, consistent with --repo CLI behavior.
                refreshOsListFrom(url);
                return;
            } else {
                qWarning() << "Cannot read manifest file:" << localPath;
            }
        }
        return;
    }

    // Check for repository URL parameter (repo=https://example.com/repo.json)
    QUrlQuery query(url);
    const QString repoVal = query.queryItemValue(QStringLiteral("repo"), QUrl::FullyDecoded);
    if (!repoVal.isEmpty()) {
        if (isValidRepoUrl(repoVal)) {
            qDebug() << "Valid repository URL received:" << repoVal;
            emit repositoryUrlReceived(repoVal);
        } else {
            qWarning() << "Ignoring invalid repository URL format:" << repoVal;
        }
    }

    // Check for auth_key token (existing behavior)
    auto token = parseTokenFromUrl(url);
    if (!token.isEmpty()) {
        if (!_piConnectToken.isEmpty()) {
            if (_piConnectToken != token) {
                // Let QML decide whether to overwrite
                emit connectTokenConflictDetected(token);
            }

            return;
        }

        overwriteConnectToken(token);
    }
}

void ImageWriter::startConnectDeviceSignIn()
{
    if (!_connectDeviceSignIn) {
        _connectDeviceSignIn = new ConnectDeviceSignIn(
            QStringLiteral(CONNECT_DEVICE_CLIENT_ID), QString(), {}, this);
        connect(_connectDeviceSignIn, &ConnectDeviceSignIn::codeReady, this,
                [this](const QString &userCode, const QString &uri, int expiresInSecs) {
            emit connectDeviceCodeReady(rpi_connect::displayUserCode(userCode), uri, expiresInSecs);
        });
        connect(_connectDeviceSignIn, &ConnectDeviceSignIn::signedIn, this,
                [this](const QString &, const QString &token) {
            overwriteConnectToken(token);
        });
        connect(_connectDeviceSignIn, &ConnectDeviceSignIn::failed,
                this, &ImageWriter::connectDeviceSignInFailed);
    }
    _connectDeviceSignIn->start();
}

void ImageWriter::cancelConnectDeviceSignIn()
{
    if (_connectDeviceSignIn)
        _connectDeviceSignIn->cancel();
}

QVariantMap ImageWriter::qrCode(const QString &text) const
{
    using qrcodegen::QrCode;
    const QByteArray utf8 = text.toUtf8();
    const QrCode qr = QrCode::encodeText(utf8.constData(), QrCode::Ecc::MEDIUM);
    const int size = qr.getSize();
    QString modules;
    modules.reserve(size * size);
    for (int y = 0; y < size; ++y)
        for (int x = 0; x < size; ++x)
            modules.append(qr.getModule(x, y) ? QLatin1Char('1') : QLatin1Char('0'));
    return { { QStringLiteral("size"), size }, { QStringLiteral("modules"), modules } };
}

void ImageWriter::overwriteConnectToken(const QString &token)
{
    // Ephemeral session-only Connect token (never persisted)
    _piConnectToken = token;
    // User-supplied (typed / pasted / browser-callback) — clear the
    // org-minted bit so discardOrgMintedConnectToken() leaves it alone.
    _piConnectTokenIsOrgMinted = false;
    emit connectTokenReceived(token);

    // Bring the window to the foreground on Windows when token is received
    bringWindowToForeground();
}

QString ImageWriter::getRuntimeConnectToken() const
{
    return _piConnectToken;
}

void ImageWriter::clearConnectToken()
{
    _piConnectToken.clear();
    _piConnectTokenIsOrgMinted = false;
    // Consumed, not invalidated: this runs on a successful write, and what
    // the user configured is what was written.
    emit connectTokenCleared(false);
}

void ImageWriter::discardOrgMintedConnectToken()
{
    if (!_piConnectTokenIsOrgMinted)
        return;
    qDebug() << "Connect: discarding org-minted auth key (storage / OS changed)";
    _piConnectToken.clear();
    _piConnectTokenIsOrgMinted = false;
    emit connectTokenCleared(true);
}

bool ImageWriter::isElevatableBundle()
{
    return PlatformQuirks::isElevatableBundle();
}

bool ImageWriter::hasElevationPolicyInstalled()
{
    return PlatformQuirks::hasElevationPolicyInstalled();
}

bool ImageWriter::installElevationPolicy()
{
    return PlatformQuirks::runElevatedPolicyInstaller();
}

void ImageWriter::restartWithElevatedPrivileges()
{
    // Pass through --log-file if present
    QStringList extraArgs;
    QStringList appArgs = QCoreApplication::arguments();
    for (int i = 0; i < appArgs.size(); i++) {
        if (appArgs[i] == "--log-file" && i + 1 < appArgs.size()) {
            extraArgs << "--log-file" << appArgs[i + 1];
            break;
        }
    }
    
    PlatformQuirks::execElevated(extraArgs);
}

bool ImageWriter::isBeepAvailable()
{
    return PlatformQuirks::isBeepAvailable();
}

bool ImageWriter::hasPerformanceData()
{
    return _performanceStats->hasData();
}

QString ImageWriter::getPerformanceDataFilename()
{
    return QString("rpi-imager-performance-%1.json")
        .arg(QDateTime::currentDateTime().toString("yyyyMMdd-HHmmss"));
}

bool ImageWriter::exportPerformanceData()
{
#ifndef CLI_ONLY_BUILD
    if (!_performanceStats->hasData()) {
        qDebug() << "No performance data to export";
        return false;
    }
    
    // Warn if there's no imaging session data (only background events)
    if (!_performanceStats->hasImagingData()) {
        qWarning() << "Performance data contains no imaging session - data may have been exported"
                   << "before a write operation or after app restart";
    }
    
    // Generate default filename with timestamp
    QString defaultFilename = getPerformanceDataFilename();
    QString initialDir = QStandardPaths::writableLocation(QStandardPaths::DocumentsLocation);
    
    // Check if native dialogs are available
    if (!NativeFileDialog::areNativeDialogsAvailable()) {
        // Emit signal for QML to handle the save dialog
        qDebug() << "Native file dialog not available, requesting QML fallback";
        emit performanceSaveDialogNeeded(defaultFilename, initialDir);
        return true; // Signal emitted, QML will handle the rest
    }
    
    // Get save location from user using native file dialog
    QString filePath = NativeFileDialog::getSaveFileName(
        tr("Save Performance Data"),
        initialDir + "/" + defaultFilename,
        tr("JSON files (*.json);;All files (*)"),
        _mainWindow
    );
    
    // Record file dialog timing as a performance event
    NativeFileDialog::TimingInfo dialogTiming = NativeFileDialog::lastTimingInfo();
    _performanceStats->recordEvent(
        PerformanceStats::EventType::FileDialogOpen,
        static_cast<uint32_t>(dialogTiming.totalBeforeShowMs + dialogTiming.userInteractionMs),
        !filePath.isEmpty(),
        fileDialogTimingToString(dialogTiming)
    );
    
    if (filePath.isEmpty()) {
        qDebug() << "Performance data export cancelled by user";
        return false;
    }
    
    return exportPerformanceDataToFile(filePath);
#else
    qDebug() << "Performance data export not available in CLI build";
    return false;
#endif
}

bool ImageWriter::exportPerformanceDataToFile(const QString &filePath)
{
#ifndef CLI_ONLY_BUILD
    if (!_performanceStats->hasData()) {
        qDebug() << "No performance data to export";
        return false;
    }
    
    QString finalPath = filePath;
    
    // Ensure .json extension
    if (!finalPath.endsWith(".json", Qt::CaseInsensitive)) {
        finalPath += ".json";
    }
    
    // Export data - all complex processing happens here, triggered by user action
    bool success = _performanceStats->exportToFile(finalPath);
    if (success) {
        qDebug() << "Performance data exported to:" << finalPath;
    }
    return success;
#else
    Q_UNUSED(filePath);
    qDebug() << "Performance data export not available in CLI build";
    return false;
#endif
}

// The Raspberry Pi Connect organisation credentials this write should
// register the device under, or false when it should register none.
//
// Both conditions have to hold. The key alone is not enough: someone who
// turned "Raspberry Pi Connect for Organisations" off in App Options has
// said they do not want devices registered, and the stored key is still
// there because turning the feature off does not erase it. Registering
// anyway would enrol a device with an organisation the person holding the
// card did not choose.
bool ImageWriter::_connectOrgRegistrationForWrite(QString &apiKey,
                                                  QString &description) const
{
    apiKey.clear();
    description.clear();

    if (!_settings.value(QStringLiteral("connect_org_enabled")).toBool())
        return false;

    const QString storedKey =
        _settings.value(QStringLiteral("connect_org_api_key")).toString();
    if (storedKey.isEmpty())
        return false;

    apiKey = storedKey;
    description = _settings.value(QStringLiteral("connect_org_description")).toString();
    return true;
}

void ImageWriter::_handleMemoryAllocationFailure(const char* what)
{
    qDebug() << "Memory allocation failed during write setup:" << what;
    
    // Log the failure to performance stats
    _performanceStats->recordEvent(
        PerformanceStats::EventType::MemoryAllocationFailure,
        0,  // No duration - immediate failure
        false,
        QString("Failed to allocate memory for write operation: %1").arg(what)
    );
    
    // Provide a clear, actionable error message to the user
    QString errorMsg = tr("Failed to start write operation: insufficient memory.\n\n"
                          "The system does not have enough available memory to perform this operation. "
                          "Try closing other applications to free up memory, then try again.\n\n"
                          "Technical details: %1").arg(what);
    
    setWriteState(WriteState::Failed);
    _performanceStats->endSession(false, "Memory allocation failure");
    emit error(errorMsg);
}

void ImageWriter::_handleSetupException(const char* what)
{
    qDebug() << "Exception during write setup:" << what;
    
    _performanceStats->recordEvent(
        PerformanceStats::EventType::MemoryAllocationFailure,
        0,
        false,
        QString("Exception during write setup: %1").arg(what)
    );
    
    setWriteState(WriteState::Failed);
    _performanceStats->endSession(false, QString("Setup exception: %1").arg(what));
    emit error(tr("Failed to start write operation: %1").arg(what));
}
