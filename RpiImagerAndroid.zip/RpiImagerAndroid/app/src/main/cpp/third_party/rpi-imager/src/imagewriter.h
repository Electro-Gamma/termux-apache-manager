#ifndef IMAGEWRITER_H
#define IMAGEWRITER_H

/*
 * SPDX-License-Identifier: Apache-2.0
 * Copyright (C) 2020-2025 Raspberry Pi Ltd
 */

#include <memory>

#include <QPointer>
#include <QJsonArray>
#include <QJsonDocument>
#include <QObject>
#include <QTimer>
#include <QUrl>
#include <QSettings>
#include <QString>
#include <QVariant>
#ifndef CLI_ONLY_BUILD
#include <QQmlEngine>
#endif
#include "config.h"
#include "suspend_inhibitor.h"
#include "drivelistmodel.h"
#include "hwlistmodel.h"
#include "oslistmodel.h"
#ifndef CLI_ONLY_BUILD
#include "nativefiledialog.h"
#include <QWindow>
#endif
#include "cachemanager.h"
#include "device_info.h"
#include "imageadvancedoptions.h"
#include "performancestats.h"
#include "rpiboot/rpiboot_types.h"

class QQmlApplicationEngine;
class DownloadThread;
class ConnectDeviceSignIn;
class DownloadExtractThread;
class QTranslator;
class QLocale;
class WriteProgressWatchdog;
#ifndef CLI_ONLY_BUILD
class NativeFileDialog;
#endif
class RpibootThread;
class FastbootFlashThread;

class ImageWriter : public QObject
{
    Q_OBJECT
#ifndef CLI_ONLY_BUILD
    QML_NAMED_ELEMENT(ImageWriterSingleton)
    QML_SINGLETON
#endif
public:
    enum class WriteState {
        Idle,
        Preparing,
        Writing,
        Verifying,
        Finalizing,
        Cancelling,
        Succeeded,
        Failed,
        Cancelled
    };
    Q_ENUM(WriteState)

    // Progress of the post-write eject, which runs in the background after
    // success() so the done screen can show a live status instead of the
    // write blocking on a slow flush. EjectIdle also covers writes where no
    // eject was requested (auto-eject disabled, fastboot flash).
    enum class EjectState {
        EjectIdle,
        EjectInProgress,
        EjectSucceeded,
        EjectFailed
    };
    Q_ENUM(EjectState)

    // NB: the parent argument is deliberately mandatory (no `= nullptr`).
    // ImageWriter is a QML_SINGLETON whose instance is supplied by main() via
    // setQmlInstance()/create(). Qt's qmlRegisterTypesAndRevisions only honours a
    // create() factory when the type is NOT default-constructible (see
    // singletonConstructionMode() in qqmlprivate.h) — a default-constructible
    // singleton is silently `new`-constructed by the engine instead, handing QML a
    // *second* ImageWriter that never receives the OS list. Keeping this parameter
    // mandatory forces create() to be used so QML shares the app-owned instance.
    explicit ImageWriter(QObject *parent);
    virtual ~ImageWriter();
    void setEngine(QQmlApplicationEngine *engine);

#ifndef CLI_ONLY_BUILD
    // QML singleton factory: returns the single app-owned instance, which main()
    // supplies via setQmlInstance() before the engine loads. Registered declaratively
    // as the "ImageWriterSingleton" QML singleton, so it is visible to qmllint/qmlsc
    // (unlike a runtime qmlRegisterSingletonInstance, which also disturbs the module).
    static ImageWriter *create(QQmlEngine *engine, QJSEngine *scriptEngine);
    static void setQmlInstance(ImageWriter *instance) { s_qmlInstance = instance; }
#endif

    Q_PROPERTY(WriteState writeState READ writeState NOTIFY writeStateChanged)
    Q_PROPERTY(EjectState ejectState READ ejectState NOTIFY ejectStateChanged)
    Q_PROPERTY(bool isOsListUnavailable READ isOsListUnavailable NOTIFY osListUnavailableChanged)
    Q_PROPERTY(bool screenReaderActive READ isScreenReaderActive NOTIFY screenReaderActiveChanged)

    /* Returns true if the extract size is reliably known (false for gz files which can't store sizes >4GB) */
    Q_INVOKABLE bool isExtractSizeKnown() const { return _extractSizeKnown; }

    /* Set URL to download from, and if known download length and uncompressed length */
    Q_INVOKABLE void setSrc(const QUrl &url, quint64 downloadLen = 0, quint64 extrLen = 0, QByteArray expectedHash = "", bool multifilesinzip = false, QString parentcategory = "", QString osname = "", QByteArray initFormat = "", QString releaseDate = "", QString bmapUrl = "");

    /* Set device to write to */
    Q_INVOKABLE void setDst(const QString &device, quint64 deviceSize = 0);

    /* Set verification enabled */
    Q_INVOKABLE void setVerifyEnabled(bool verify);

    /* Set custom repo */
    Q_INVOKABLE void setCustomRepo(const QUrl &repo);

    /* Set custom cache file - now handled by CacheManager */
    Q_INVOKABLE void setCustomCacheFile(const QString &cacheFile, const QByteArray &sha256);

    /* Returns true if src and dst are set */
    Q_INVOKABLE bool readyToWrite();

    /* Returns true if running on a Raspberry Pi */
    Q_INVOKABLE bool isRaspberryPiDevice();

    /* Returns hardware name if running on a Raspberry Pi */
    Q_INVOKABLE QString getHardwareName();

    Q_INVOKABLE bool createHardwareTags();

    /* Start writing */
    Q_INVOKABLE void startWrite();

    /* Cancel write */
    Q_INVOKABLE void cancelWrite();

    /* Manually eject the written drive (retry after a failed background
       eject, or first eject when auto-eject is disabled). Runs on a
       background thread; progress is reported via ejectState. */
    Q_INVOKABLE void ejectDrive();

    /* Skip cache verification and proceed with download */
    Q_INVOKABLE void skipCacheVerification();

    /* Skip only the current post-write verification pass (does not change default setting) */
    Q_INVOKABLE void skipCurrentVerification();

    /* Return true if url is in our local disk cache */
    Q_INVOKABLE bool isCached(const QUrl &url, const QByteArray &sha256);

    /* Drive list polling runs continuously in background */

    /* Return list of available drives. Drive polling runs continuously in background.
       Note: If you mark this as Q_INVOKABLE, be sure to parent it to ImageWriter,
       to prevent GC from deleting it.
    */
    Q_INVOKABLE DriveListModel *getDriveList();

    /* Return list of available devices. */
    Q_INVOKABLE HWListModel *getHWList();

    /* Return list of available devices. */
    Q_INVOKABLE OSListModel *getOSList();

    /* Utility function to return filename part from URL */
    Q_INVOKABLE QString fileNameFromUrl(const QUrl &url);

    /* Function to return current OS list URL in a displayable format */
    Q_INVOKABLE QString osListUrlForDisplay() const;

    /* Function to return current OS list URL (may be customized) */
    Q_INVOKABLE QUrl osListUrl() const;

    // Where the repository starts, and where refreshOsListFromDefaultUrl()
    // returns to. RPI_IMAGER_OSLIST_URL overrides it, as
    // RPI_IMAGER_TELEMETRY_URL and RPI_IMAGER_CONNECT_URL override theirs and
    // for the same reason: a suite driving the real writer should not reach
    // production. The telemetry guards still compare the built-in constant,
    // so a redirected list reports nothing.
    static QUrl defaultOsListUrl();

    /* Function to return version (for QML - C++ code should use staticVersion()) */
    Q_INVOKABLE QString constantVersion() const;

    /* Static version - for use without creating an instance */
    static QString staticVersion();

    /* Returns true if version argument is newer than current program */
    Q_INVOKABLE bool isVersionNewer(const QString &version);

    /* Set custom repository */
    Q_INVOKABLE void setCustomOsListUrl(const QUrl &url);

    /* Get the cached OS list. This may be empty if network connectivity is not available. */
    Q_INVOKABLE QByteArray getFilteredOSlist();

    /* Overload which returns QJsonDocument */
    Q_INVOKABLE QJsonDocument getFilteredOSlistDocument();

    // Which source a fastboot write reads from, and which storage it targets.
    // Both are decisions the handoff makes on the user's behalf, and both
    // were buried in the middle of onRpibootFastbootReady().
    QUrl resolveFlashSource() const;
    QString resolveFastbootStorageTarget() const;

    /** Begin the asynchronous fetch of the OS lists, and associated sublists. */
    Q_INVOKABLE void beginOSListFetch();

    /** Set the HW filter, for a filtered view of the OS list */
    Q_INVOKABLE void setHWFilterList(const QJsonArray &tags, const bool &inclusive);

    /* Set the capabilities supported by the hardware, for a filtered view of options that require the hardware to have certain capabilities. */
    Q_INVOKABLE void setHWCapabilitiesList(const QJsonArray &json);

    /* Set the capabilities supported by the hardware, for a filtered view of options that require the software to have certain capabilities. */
    Q_INVOKABLE void setSWCapabilitiesList(const QString &json);
    Q_INVOKABLE void setSWCapabilitiesList(const QVariantList &caps);

    /* Get the HW filter list */
    Q_INVOKABLE QJsonArray getHWFilterList();

    /* Get if the HW filter is in inclusive mode */
    Q_INVOKABLE bool getHWFilterListInclusive();

    /* Get if both hard and software support a certain feature. If no differentSWCap is provided it will check for cap support in SW and HW lists. */
    Q_INVOKABLE bool checkHWAndSWCapability(const QString &cap, const QString &differentSWCap = "");

    /* Check if the hardware supports a certain feature. */
    Q_INVOKABLE bool checkHWCapability(const QString &cap);

    /* Check if the software supports a certain feature. */
    Q_INVOKABLE bool checkSWCapability(const QString &cap);

    /* Utility function to open OS file dialog */
    /* Which request a file selection is answering.

       The file dialog is a single shared entry point and its result is
       broadcast to every listener, so a chooser has to say what it asked
       for. Without that, choosing a custom repository file was also taken
       as choosing a custom image: the selected OS became the repository
       file and the user's staged customisation was discarded with it.

       Defaults to the custom image, which is what an untagged selection
       has always meant. */
    Q_INVOKABLE void openFileDialog(const QString &title, const QString &filter,
                                    const QString &purpose = QStringLiteral("customImage"));

    /* Expose native file dialog availability to QML */
    Q_INVOKABLE bool nativeFileDialogAvailable() {
#ifndef CLI_ONLY_BUILD
        return NativeFileDialog::areNativeDialogsAvailable();
#else
        return false;
#endif
    }

    /* Accept selection from QML fallback FileDialog */
    Q_INVOKABLE void acceptCustomImageFromQml(const QUrl &fileUrl) { onFileSelected(fileUrl.toLocalFile(), QStringLiteral("customImage")); }

    /* Generic native open-file dialog for QML callsites (sync) */
    Q_INVOKABLE QString getNativeOpenFileName(const QString &title = QString(),
                                             const QString &initialDir = QString(),
                                             const QString &filter = QString());

    /* Set the main window for modal file dialogs */
    Q_INVOKABLE void setMainWindow(QObject *window);

    /* Bring the application window to the foreground */
    void bringWindowToForeground();

    /* Read text file contents */
    Q_INVOKABLE QString readFileContents(const QString &filePath);

    /* Fetch the public SSH keys a GitHub account publishes, for a machine with
       no clipboard or file browser to bring a key in. The answer arrives as
       gitHubKeysImported(); see github_keys.h for what each status means, and
       "invalid" for a name that was never sent. */
    Q_INVOKABLE void importGitHubKeys(const QString &username);

    /* The path of a file the QML file dialogs hand back as a url. Cutting
       "file://" off the url is not the same thing: that leaves "/C:/..." on
       Windows, and "%23" for a '#' in the name everywhere. */
    Q_INVOKABLE QString localPathFromUrl(const QUrl &url) const;
    Q_INVOKABLE QUrl fileUrlFromLocalPath(const QString &path) const;

    /// Which kind of write startWrite() is about to start.
    ///
    /// The three special targets are decided in a fixed order and the order is
    /// load-bearing: a device already in fastboot mode is flashed as one even
    /// when the erase sentinel was selected, because a Compute Module cannot
    /// be erased through the SD card path. Naming the decision keeps that
    /// precedence somewhere it can be read and tested rather than implied by
    /// the order of three ifs.
    enum class WritePath {
        FastbootDevice,   ///< already in fastboot mode; flash over USB
        RpibootDevice,    ///< needs sideloading into fastboot first
        Erase,            ///< the internal://format sentinel
        Normal,           ///< an ordinary image, cached or downloaded
    };
    WritePath choosePath() const;

    /// Why a local source cannot be written, or empty if it can. Shared by
    /// startWrite() and the post-cache-verification continuation so the two
    /// cannot drift apart again.
    QString _localSourceError(const QString &localPath) const;

    /// Configure the freshly constructed _thread: signals, telemetry,
    /// customisation and debug switches. Shared by startWrite() and the
    /// post-cache-verification continuation, which each had their own copy.
    void _configureWriteThread();

    /// Attach a download cache file to _thread. Shared by both write paths;
    /// the condition deciding whether to call it is not.
    void _attachDownloadCache();

    /// Start the configured thread and begin progress polling.
    void _startConfiguredWrite();

    /// Configure the fastboot flash thread and start it. Shared by the
    /// post-sideload path and the directly-selected fastboot device path.
    void _configureAndStartFastbootFlash();

    // Emits cancelled() or writeCancelledDueToDeviceRemoval(), whichever the
    // reason calls for, and clears the reason.
    void _emitCancelled();

    /* Handle keychain permission response from QML */
    Q_INVOKABLE void keychainPermissionResponse(bool granted);

    /* Return filename part of URL set */
    Q_INVOKABLE QString srcFileName();
    
    /* Returns size (bytes) of selected source, if known; 0 if unknown */
    Q_INVOKABLE quint64 getSelectedSourceSize();
    /* Format a byte size with an appropriate translated unit (KB/MB/GB/TB) */
    Q_INVOKABLE QString formatSize(quint64 bytes, int decimals = 1);

    /* Returns true if online */
    Q_INVOKABLE bool isOnline();

    /* Returns true if run on embedded Linux platform */
    Q_INVOKABLE bool isEmbeddedMode() const;

    /* Returns true if window has decorations (title bar visible) */
    Q_INVOKABLE bool hasWindowDecorations() const;

    /* Mount any USB sticks that can contain source images under /media
       Returns true if at least one device was mounted */
    Q_INVOKABLE bool mountUsbSourceMedia();

    /* Returns a json formatted list of the OS images found on USB stick */
    Q_INVOKABLE QByteArray getUsbSourceOSlist();

protected:
    // Where inserted media appears. Virtual so the scan above can be run
    // against a directory a test lays out, rather than only against real
    // media mounted under /media by the running system.
    virtual QString usbMediaRoot() const;

    // Where block devices are enumerated from, and how one is mounted.
    // Both virtual so the decision about *which* devices to mount can be
    // checked without mounting anything -- that decision is what keeps the
    // running system's own card from being touched.
    virtual QString sysBlockRoot() const;
    virtual int mountReadOnly(const QString &devicePath, const QString &mountPoint);

public:

    /* Functions to collect information from computer running imager to make image customization easier */
    Q_INVOKABLE QString getDefaultPubKey();
    Q_INVOKABLE bool hasPubKey();
    Q_INVOKABLE bool hasSshKeyGen();
    Q_INVOKABLE void generatePubKey();
    Q_INVOKABLE QString getTimezone();
    Q_INVOKABLE QStringList getTimezoneList();
    Q_INVOKABLE QStringList getCountryList();
    Q_INVOKABLE QStringList getKeymapLayoutList();
    Q_INVOKABLE QStringList getCapitalCitiesList();
    Q_INVOKABLE QVariantMap getLocaleDataForCapital(const QString &capitalCity);
    Q_INVOKABLE QString getSSID();
    Q_INVOKABLE QString getPSK();
    Q_INVOKABLE QString getPSKForSSID(const QString &ssid);

    Q_INVOKABLE bool getBoolSetting(const QString &key);
    Q_INVOKABLE QString getStringSetting(const QString &key);
    Q_INVOKABLE void setSetting(const QString &key, const QVariant &value);
    Q_INVOKABLE QString getRsaKeyFingerprint(const QString &keyPath);

    // Raspberry Pi Connect organisation registration.
    //
    // The API key IS persisted (QSettings) so users don't have to
    // re-enter it every session, but it is write-only from QML —
    // once saved, the value is never handed back to the UI.  QML
    // uses hasConnectOrgRegistration() to decide whether to render
    // a "key already set" placeholder, and clearConnectOrgRegistration()
    // to remove it.  The description prefix is not secret and is
    // returned through getConnectOrgDescription() for edit-in-place.
    Q_INVOKABLE void setConnectOrgRegistration(const QString &apiKey,
                                                 const QString &descriptionPrefix);
    Q_INVOKABLE void setConnectOrgDescription(const QString &descriptionPrefix);
    Q_INVOKABLE void clearConnectOrgRegistration();
    Q_INVOKABLE bool hasConnectOrgRegistration() const;
    Q_INVOKABLE QString getConnectOrgDescription() const;
    
    // Debug options (secret menu: Cmd+Option+S on macOS, Ctrl+Alt+S on others)
    Q_INVOKABLE bool getDebugDirectIO() const;
    Q_INVOKABLE void setDebugDirectIO(bool enabled);
    Q_INVOKABLE bool getDebugPeriodicSync() const;
    Q_INVOKABLE void setDebugPeriodicSync(bool enabled);
    Q_INVOKABLE bool getDebugVerboseLogging() const;
    Q_INVOKABLE void setDebugVerboseLogging(bool enabled);
    Q_INVOKABLE bool getDebugAsyncIO() const;
    Q_INVOKABLE void setDebugAsyncIO(bool enabled);
    Q_INVOKABLE int getDebugAsyncQueueDepth() const;
    Q_INVOKABLE void setDebugAsyncQueueDepth(int depth);
    Q_INVOKABLE bool getDebugIPv4Only() const;
    Q_INVOKABLE void setDebugIPv4Only(bool enabled);
    Q_INVOKABLE bool getDebugSkipEndOfDevice() const;
    Q_INVOKABLE void setDebugSkipEndOfDevice(bool enabled);
    Q_INVOKABLE bool getDebugIgnoreDeviceLimits() const;
    Q_INVOKABLE void setDebugIgnoreDeviceLimits(bool enabled);
    Q_INVOKABLE bool getDebugRpiboot() const;
    Q_INVOKABLE void setDebugRpiboot(bool enabled);
    Q_INVOKABLE QString getDebugCustomFastbootGadget() const;
    Q_INVOKABLE void setDebugCustomFastbootGadget(const QString &path);
    Q_INVOKABLE bool getDebugForceSecureBoot() const;
    Q_INVOKABLE void setDebugForceSecureBoot(bool enabled);
    Q_INVOKABLE bool getDebugSignFastbootGadget() const;
    Q_INVOKABLE void setDebugSignFastbootGadget(bool enabled);

    // Customisation API
    Q_INVOKABLE void applyCustomisationFromSettings(const QVariantMap &settings);  // Main entry: generates scripts from settings
    Q_INVOKABLE void setImageCustomisation(const QByteArray &config, const QByteArray &cmdline, const QByteArray &firstrun, const QByteArray &cloudinit, const QByteArray &cloudinitNetwork, const ImageOptions::AdvancedOptions opts = {}, const QByteArray &initFormat = {});  // Advanced: bypass generator with pre-made scripts
    
    // Persistence API
    Q_INVOKABLE void setSavedCustomisationSettings(const QVariantMap &map);  // Legacy: prefer setPersistedCustomisationSetting()
    Q_INVOKABLE QVariantMap getSavedCustomisationSettings();
    Q_INVOKABLE void setPersistedCustomisationSetting(const QString &key, const QVariant &value);
    Q_INVOKABLE void removePersistedCustomisationSetting(const QString &key);
    Q_INVOKABLE void clearSavedCustomisationSettings();
    Q_INVOKABLE bool imageSupportsCustomization();
    Q_INVOKABLE bool imageSupportsCcRpi();
    // Whether the selected OS can apply the GPIO/hardware interface toggles
    // (I2C/SPI/1-Wire/serial/USB gadget). cloud-init needs the cc_raspberry_pi
    // module; rpi-preseed configures them natively via raspi-config.
    Q_INVOKABLE bool imageSupportsInterfaceCustomisation();

    // Hash the account password from plaintext for the UI. Hashing is
    // delegated to CustomisationGenerator (the single home for credential
    // derivation); the UI hands over plaintext, gets back only the hash, and
    // never retains the plaintext in long-lived state. This keeps the
    // plaintext's RAM lifetime bounded to the input field (needed for the
    // show-password toggle) and guarantees only the hash reaches disk or the
    // generator. Returns an empty string for empty input.
    Q_INVOKABLE QString hashUserPassword(const QString &plaintext);
    Q_INVOKABLE QString wifiSsidOctetsBase64(const QString &ssid) const;

    // Whether a stored account-password hash can authenticate on the currently
    // selected OS. The crypt string is self-describing, so we never store the
    // algorithm separately: a yescrypt hash ("$y$") only works on images that
    // support it (release date >= 2023-01-01), while sha256crypt works
    // everywhere. The UI uses this to invalidate a restored/stale hash and force
    // re-entry when the user targets an older OS. Empty input is "compatible".
    Q_INVOKABLE bool savedUserPasswordUsableWithCurrentOs(const QString &cryptHash) const;

    Q_INVOKABLE QStringList getTranslations();
    Q_INVOKABLE QString getCurrentLanguage();
    Q_INVOKABLE QString getCurrentKeyboard();
    Q_INVOKABLE QString getCurrentUser();
    Q_INVOKABLE void changeLanguage(const QString &newLanguageName);
    Q_INVOKABLE void changeKeyboard(const QString &newKeymapLayout);
    Q_INVOKABLE bool customRepo();
    Q_INVOKABLE QString customRepoHost();
    
    /* Validate if a string is a valid repository URL (http/https ending with .json or .rpi-imager-manifest) */
    Q_INVOKABLE bool isValidRepoUrl(const QString &url) const;
    
    // Secure Boot CLI override
    static void setForceSecureBootEnabled(bool enabled);
    Q_INVOKABLE bool isSecureBootForcedByCliFlag() const;

    void replaceTranslator(QTranslator *trans);

    /* Switch to the translation that best suits the locale, if there is one.
       Called at startup, once the platform's UI language is known. */
    void setLanguageForLocale(const QLocale &locale);

    /* Which of langcodes ("de", "pt", "pt-BR", ...) suits the locale best:
       the most specific one among its UI languages, so pt_BR gets "pt-BR"
       ahead of "pt". Empty if none of them does. */
    static QString translationForLocale(const QLocale &locale, const QStringList &langcodes);

    QString detectPiKeyboard();
    Q_INVOKABLE bool hasMouse();
    Q_INVOKABLE void reboot();

    /* How reboot() restarts the machine. Embedded Imager is not on a system
       with an init that a reboot command can ask: pi-gen-micro has no
       /sbin/reboot, and busybox's reboot only signals PID 1, which there is
       a shell script that ignores it. So embedded makes the kernel call
       itself, and if that fails it quits and init reboots on its way out. */
    enum class RebootPath { KernelCallThenQuit, ExternalCommand };
    static RebootPath rebootPathFor(bool embedded);
    Q_INVOKABLE void openUrl(const QUrl &url);
    // An ordinary web address: http or https, with a host. Used wherever a
    // URL arrives from somewhere that is not us -- an OS list entry, the
    // update check, the bootloader's own flash -- before it is opened or
    // fetched from.
    static bool isHttpUrl(const QUrl &url);
    Q_INVOKABLE bool isScreenReaderActive() const;
    // Have a screen reader speak a message now. A label that changes on
    // screen is not announced -- readers speak what the user moved to, and
    // during a write nothing moves.
    Q_INVOKABLE void announceToScreenReader(const QString &message);
    Q_INVOKABLE void handleIncomingUrl(const QUrl &url);
    Q_INVOKABLE void overwriteConnectToken(const QString &token);

    /* Raspberry Pi Connect sign-in for embedded mode, which has no browser:
       a code to scan or type on a phone. connectDeviceCodeReady() carries
       it; a sign-in arrives through overwriteConnectToken() as an rpdev_
       token; connectDeviceSignInFailed() says why one did not. */
    Q_INVOKABLE void startConnectDeviceSignIn();
    Q_INVOKABLE void cancelConnectDeviceSignIn();

    /* A QR code for `text`, for QML to draw: "size" modules a side, and
       "modules" a string of size*size '0'/'1' characters, row by row. */
    Q_INVOKABLE QVariantMap qrCode(const QString &text) const;
    Q_INVOKABLE QString getRuntimeConnectToken() const;
    Q_INVOKABLE bool verifyAuthKey(const QString &token, bool strict = false) const;
    Q_INVOKABLE void clearConnectToken();
    // Clear the runtime Connect token only if it was minted by
    // requestOrgAuthKey().  Used by the wizard to drop a stale
    // org-minted key when the user changes storage / OS without
    // clobbering a per-user token the user typed in themselves.
    Q_INVOKABLE void discardOrgMintedConnectToken();
    
    /* Override OS list refresh schedule (in minutes); pass negative to clear override */
    Q_INVOKABLE void setOsListRefreshOverride(int intervalMinutes, int jitterMinutes);

    Q_INVOKABLE void refreshOsListFrom(const QUrl &url);
    Q_INVOKABLE void refreshOsListFromDefaultUrl();

    /* Elevatable bundle (e.g., AppImage) privilege escalation support */
    Q_INVOKABLE bool isElevatableBundle();
    Q_INVOKABLE bool hasElevationPolicyInstalled();
    Q_INVOKABLE bool installElevationPolicy();
    Q_INVOKABLE void restartWithElevatedPrivileges();

    /* Check if audio notification (beep) is available on this system */
    Q_INVOKABLE bool isBeepAvailable();

    /* Set an rpiboot device as the write target.
       `storageTarget` is the block-device name (e.g. "mmcblk0", "nvme0n1")
       to flash to once the device has been bootstrapped into fastboot
       mode.  Pass an empty string only when the storage choice is not yet
       known --- the rpiboot-then-flash path will then fall back to the
       eMMC (the only universally-present CM storage) and log a warning. */
    Q_INVOKABLE void setRpibootDevice(const QString &deviceId,
                                       const QString &storageTarget = QString());
    /* Returns true if the current target is an rpiboot device */
    Q_INVOKABLE bool isRpibootDevice() const;

    /* Set a fastboot storage device as the write target */
    Q_INVOKABLE void setFastbootDevice(const QString &device, quint64 size);
    /* Returns true if the current target is a fastboot storage device */
    Q_INVOKABLE bool isFastbootDevice() const;

    // Mint a single-use Raspberry Pi Connect auth key for the
    // currently configured organisation API key.  Used when the
    // target is not a fastboot device — the returned secret is
    // written into the OS image's customisation as if the user had
    // pasted a per-user token.  Returns a map with:
    //   ok      bool    — true on success
    //   secret  string  — "rpoak_..." on success
    //   error   string  — server message on failure (401 / 422 / other)
    Q_INVOKABLE QVariantMap requestOrgAuthKey(const QString &description,
                                               int ttlDays = 1);

    /* Performance data export - opens native save dialog and writes performance data to file.
       If native dialogs aren't available, emits performanceSaveDialogNeeded for QML fallback. */
    Q_INVOKABLE bool exportPerformanceData();
    
    /* Export performance data to a specific file path (used by QML fallback) */
    Q_INVOKABLE bool exportPerformanceDataToFile(const QString &filePath);
    
    /* Get suggested filename for performance data export */
    Q_INVOKABLE QString getPerformanceDataFilename();
    
    /* Check if performance data is available */
    Q_INVOKABLE bool hasPerformanceData();

    /* Check if OS list is unavailable - derived from whether we have data (for QML offline UI) */
    bool isOsListUnavailable() const { return _completeOsList.isEmpty(); }

    /* Get access to performance stats for instrumentation */
    PerformanceStats* performanceStats() { return _performanceStats; }

signals:
    /* We are emiting signals with QVariant as parameters because QML likes it that way */

    void downloadProgress(QVariant dlnow, QVariant dltotal);
    void writeProgress(QVariant now, QVariant total);
    void verifyProgress(QVariant now, QVariant total);
    void error(QVariant msg);
    void success();
    void fileSelected(QVariant filename, QString purpose);
    void cancelled();
    void finalizing();
    void networkOnline();
    void preparationStatusUpdate(QVariant msg);
    void osListPrepared();
    void bottleneckStatusChanged(QVariant status, QVariant throughputKBps);
    void operationWarning(QVariant message);  // Non-fatal warning during operation (e.g., sync fallback)
    void hwFilterChanged();
    void networkInfo(QVariant msg);
    void gitHubKeysImported(const QString &username, const QStringList &keys,
                            const QString &status);
    void cacheVerificationStarted();
    void cacheVerificationFinished();
    void selectedDeviceRemoved();
    void writeCancelledDueToDeviceRemoval();
    void keychainPermissionRequested();
    void keychainPermissionResponseReceived();
    void writeStateChanged();
    void ejectStateChanged();
    void connectTokenReceived(const QString &token);
    void connectDeviceCodeReady(const QString &userCode, const QString &verificationUri,
                                int expiresInSecs);
    void connectDeviceSignInFailed(const QString &reason);
    void connectTokenConflictDetected(const QString &token);
    // The session token has gone. `configurationInvalidated` separates the
    // two reasons, which want different things of the wizard: a token
    // consumed by a successful write leaves the step configured, and one
    // dropped because the OS or storage changed does not.
    void connectTokenCleared(bool configurationInvalidated);
    void repositoryUrlReceived(const QString &url);
    void customRepoChanged();
    void customRepoHostChanged();  // Emitted when displayed repo host changes (e.g., after redirect)
    void cacheStatusChanged();
    void osListUnavailableChanged();
    void permissionWarning(QVariant msg);
    void locationPermissionGranted();
    void performanceSaveDialogNeeded(const QString &suggestedFilename, const QString &initialDir);
    void screenReaderActiveChanged();

protected slots:
    void startProgressPolling();
    void stopProgressPolling();
    void pollNetwork();
    void restartWrite(QString reason);  // Restart write in sync mode after stall
    
    void onSuccess();
    void onError(QString msg);
    void onEjectStarted();
    void onEjectFinished(bool succeeded);
    void onFileSelected(QString filename,
                        const QString &purpose = QStringLiteral("customImage"));
    void onCancelled();
    void onFinalizing();
    void onPreparationStatusUpdate(QString msg);
    void onOsListFetchComplete(const QByteArray &data, const QUrl &url, const QUrl &effectiveUrl);
    void onOsListFetchError(const QString &errorMessage, const QUrl &url);
    void onNetworkConnectionStats(const QString &statsMetadata, const QUrl &url);
    void onSTPdetected();
    void onCacheVerificationProgress(qint64 bytesProcessed, qint64 totalBytes);
    void onCacheVerificationComplete(bool isValid);
    void onSelectedDeviceRemoved(const QString &device);
    void onOsListRefreshTimeout();
    void onRpibootFastbootReady(const QString &fastbootId);
    void onRpibootError(const QString &msg);
    void onRpibootDeviceDetected(const QString &deviceId,
                                  uint8_t busNumber, uint8_t deviceAddress,
                                  const QList<uint8_t> &portPath, uint16_t productId);
    void onBootstrapComplete(const QString &portPathKey, const QString &fastbootId);
    void onBootstrapError(const QString &portPathKey, const QString &msg);

private:
#ifndef CLI_ONLY_BUILD
    static ImageWriter *s_qmlInstance;   // app-owned instance returned by create()
#endif
    void setWriteState(WriteState state);
    WriteState writeState() const { return _writeState; }
    void setEjectState(EjectState state);
    EjectState ejectState() const { return _ejectState; }
protected:
    // Cache management
    //
    // Protected rather than private so a test can reach the cache the way the
    // application does. Whether pressing Write re-downloads the image, or
    // writes a cached copy that failed its integrity check, is decided from
    // this object's state at the moment startWrite() runs -- and the states
    // that matter are the ones the *background* verifier leaves behind before
    // the user gets there. Nothing else can put it in them, and nothing else
    // can tell when it has. Same reason DownloadThread::_file is protected.
    CacheManager* _cacheManager;

private:
    bool _waitingForCacheVerification;
    QElapsedTimer _cacheVerificationTimer;  // Tracks cache verification duration
    
    // Keychain permission tracking
    bool _keychainPermissionGranted;
    bool _keychainPermissionReceived;

    // Recursively walk all the entries with subitems and, for any which
    // refer to an external JSON list, fetch the list and put it in place.
    void fillSubLists(QJsonArray &topLevel);
    void queueSublistFetches(const QJsonArray &list, int depth);
    QHash<QUrl, qint64> _pendingFetchStartTimes;  // Track request start times for performance
    QJsonDocument _completeOsList;
    QJsonArray _deviceFilter, _hwCapabilities, _swCapabilities;
    bool _deviceFilterIsInclusive;
    std::shared_ptr<DeviceInfo> _device_info;

    QString parseTokenFromUrl(const QUrl &url, bool strictAuthKey = false) const;

    bool installTranslation(const QString &langcode);
    void replaceTranslators(const QList<QTranslator *> &translators);

protected:
    /*
     * How the write thread is built. Overridden by tests that need the write
     * to run against a scripted device -- a paced one, so that a case about
     * what happens *during* a write does not depend on how quickly the host
     * happens to finish it. The application never overrides these; the
     * defaults return the same threads the two call sites always built.
     */
    virtual DownloadExtractThread *createLocalFileThread(const QByteArray &url,
                                                         const QByteArray &dst,
                                                         const QByteArray &expectedHash);
    virtual DownloadExtractThread *createDownloadThread(const QByteArray &url,
                                                        const QByteArray &dst,
                                                        const QByteArray &expectedHash);

    QUrl _src, _repo;
    QString _dst, _parentCategory, _osName, _osReleaseDate, _currentLang, _currentLangcode, _currentKeyboard, _bmapUrl;
    QByteArray _expectedHash, _cmdline, _config, _firstrun, _cloudinit, _cloudinitNetwork, _initFormat;
    ImageOptions::AdvancedOptions _advancedOptions;
    quint64 _downloadLen, _extrLen, _devLen, _dlnow, _verifynow;
    DriveListModel _drivelist;
    bool _selectedDeviceValid;
    WriteState _writeState;
    EjectState _ejectState = EjectState::EjectIdle;
    QThread *_manualEjectThread = nullptr;
    bool _cancelledDueToDeviceRemoval;
    HWListModel _hwlist;
    OSListModel _oslist;
    QQmlApplicationEngine *_engine;
    QTimer _networkchecktimer;
    QTimer _osListRefreshTimer;
    QTimer _screenReaderPollTimer;
    bool _screenReaderActiveCached = false;
    SuspendInhibitor *_suspendInhibitor;
    DownloadThread *_thread;
    bool _verifyEnabled, _multipleFilesInZip, _online, _extractSizeKnown;
    QSettings _settings;
    QMap<QString,QString> _translations;
    // Installed translators, in the order installed; Qt searches the last first
    QList<QTranslator *> _translators;
    int _refreshIntervalOverrideMinutes;
    int _refreshJitterOverrideMinutes;
    // Session-only storage for Raspberry Pi Connect token
    QString _piConnectToken;
    ConnectDeviceSignIn *_connectDeviceSignIn = nullptr;
    // True when the current _piConnectToken was minted by us via
    // requestOrgAuthKey() (rather than typed/pasted by the user).
    // Lets the wizard drop only its own minted keys on storage / OS
    // changes without clobbering a user-supplied token.
    bool _piConnectTokenIsOrgMinted = false;
    // CLI flag to force enable secure boot regardless of OS capabilities
    static bool _forceSecureBootEnabled;
#ifndef CLI_ONLY_BUILD
    // QPointer, not a raw pointer: every use of this is guarded by a null
    // check, and a raw pointer to a destroyed window passes those checks
    // and then dereferences freed memory. The application's own window
    // outlives the writer, so this is not reachable today -- but nothing
    // makes that true, and the same reasoning is already why
    // PlatformHelper holds its observers through QPointer. A QPointer goes
    // null when the window is destroyed, which is what the existing checks
    // were written expecting.
    QPointer<QWindow> _mainWindow;
#endif

    // Performance statistics capture
    PerformanceStats *_performanceStats;
    
    // Progress watchdog - separate component that monitors for stalls
    WriteProgressWatchdog* _progressWatchdog = nullptr;
    bool _forceSyncMode = false;  // Force sync I/O on next write (after recovery restart)
    
    // Debug options (secret menu)
    bool _debugDirectIO;
    bool _debugPeriodicSync;
    bool _debugVerboseLogging;
    bool _debugAsyncIO;
    int _debugAsyncQueueDepth;
    bool _debugIPv4Only;
    bool _debugSkipEndOfDevice;
    bool _debugIgnoreDeviceLimits;
    bool _debugRpiboot;
    QString _debugCustomFastbootGadget;
    bool _debugForceSecureBoot;
    bool _debugSignFastbootGadget;

    QString _rpibootDeviceId;
    QString _rpibootStorageTarget;  // block device on the CM to flash after bootstrap (e.g. "mmcblk0", "nvme0n1")
    bool _isRpibootDevice = false;
    RpibootThread *_rpibootThread = nullptr;
    FastbootFlashThread *_fastbootFlashThread = nullptr;
    rpiboot::SideloadMode _rpibootSideloadMode = rpiboot::SideloadMode::Fastboot;

    // Fastboot storage device selection (pre-bootstrapped)
    bool _isFastbootDevice = false;
    QString _fastbootId;
    QString _fastbootBlockDevice;

    // Auto-bootstrap tracking
    QSet<QString> _bootstrappingDevices;           // port path keys in progress
    QMap<QString, RpibootThread*> _activeBootstrapThreads;

    QString _pubKeyFileName();
    QString _privKeyFileName();
    // Virtual so the key handling can be exercised against a directory a
    // test owns. Everything else here is derived from it, and the real one
    // is the user's ~/.ssh -- which holds keys that are not ours to write
    // over or to leave lying around after a test run.
    virtual QString _sshKeyDir();
    QString _sshKeyGen();
    void _applySystemdCustomisationFromSettings(const QVariantMap &s);
    void _applyCloudInitCustomisationFromSettings(const QVariantMap &s);
    void _applyRpiPreseedCustomisationFromSettings(const QVariantMap &s);
    void _continueStartWriteAfterCacheVerification(bool cacheIsValid);
    void scheduleOsListRefresh();
    bool _connectOrgRegistrationForWrite(QString &apiKey, QString &description) const;
    void _handleMemoryAllocationFailure(const char* what);
    void _handleSetupException(const char* what);
};

#endif // IMAGEWRITER_H
