/*
 * SPDX-License-Identifier: Apache-2.0
 * Copyright (C) 2025 Raspberry Pi Ltd
 */

#ifndef SYSTEMMEMORYMANAGER_H
#define SYSTEMMEMORYMANAGER_H

#include <QtGlobal>
#include <QString>

/**
 * @brief Platform-agnostic system memory management interface
 * 
 * Provides unified access to system memory information and calculates
 * optimal sync intervals for image writing operations based on available RAM.
 */
class SystemMemoryManager
{
public:
    /**
     * @brief Configuration for adaptive sync intervals
     */
    struct SyncConfiguration {
        qint64 syncIntervalBytes;    // How many bytes to write before syncing
        qint64 syncIntervalMs;       // Maximum time between syncs (milliseconds)
        QString memoryTier;          // Description of memory tier (for logging)
    };

    /**
     * @brief Get the singleton instance
     */
    static SystemMemoryManager& instance();

    /**
     * @brief Get total system memory in MB
     * @return Total system memory in megabytes, or 0 if detection failed
     */
    qint64 getTotalMemoryMB();

    /**
     * @brief Get available system memory in MB
     * @return Available system memory in megabytes, or 0 if detection failed
     */
    qint64 getAvailableMemoryMB();

    /**
     * @brief Calculate optimal sync configuration based on system memory
     * @return SyncConfiguration with adaptive intervals
     */
    SyncConfiguration calculateSyncConfiguration();

    /*
     * The same decision, on a memory figure rather than this machine's.
     *
     * How often the writer syncs is what decides how much written data is
     * in flight at once. Too much on a small machine and the kernel starts
     * reclaiming during a write -- or kills the application outright; too
     * little on a large one and the write is slowed down for nothing. The
     * tiers are the whole of that policy, and separating them from reading
     * /proc/meminfo is what lets each be checked rather than only whichever
     * one the machine running the tests happens to fall into.
     */
    static SyncConfiguration syncConfigurationFor(qint64 totalMemMB);

    /*
     * The other three memory ladders, on a figure rather than this machine's,
     * for the same reason syncConfigurationFor() exists.
     *
     * Each is a policy decision the user feels: the write buffer is how much
     * of a small machine the writer is willing to occupy, the input buffer is
     * what the download hands the decompressor in one go, and the queue depth
     * is how many writes a card is asked to hold at once. A machine with
     * 512MB and one with 32GB take opposite ends of every one of them, and a
     * test can only ever be run on one machine.
     */
    static size_t writeBufferSizeFor(qint64 totalMemMB);
    static size_t inputBufferSizeFor(qint64 totalMemMB);
    static size_t verifyBufferSizeFor(qint64 fileSize, qint64 totalMemMB);
    static int asyncQueueDepthFor(qint64 availableMemMB, size_t writeBlockSize);

    /*
     * The /proc/meminfo half of memory detection, given the text rather than
     * the file.
     *
     * On Linux both figures come from sysinfo(), and sysinfo() does not fail
     * on a working kernel -- its only documented error is a bad pointer. So
     * the fallback underneath it had never once been executed, which is a
     * poor state for the code that runs where sysinfo() is unavailable: a
     * sandbox that filters the syscall, or a kernel too old for it. Reading
     * the file and parsing it are separate here so the parsing can be.
     */
    //
    // Linux only, and declared that way rather than everywhere: /proc/meminfo
    // is a Linux interface, the definitions live in this file's Q_OS_LINUX
    // branch, and a declaration visible on the other two platforms is one a
    // test can call and the linker cannot satisfy.
#ifdef Q_OS_LINUX
    static qint64 totalMemoryFromMeminfo(const QString &contents);
    static qint64 availableMemoryFromMeminfo(const QString &contents);
#endif

    /**
     * @brief Get platform name for logging
     * @return Platform identifier string
     */
    QString getPlatformName();

    /**
     * @brief Calculate optimal write buffer size based on available memory
     * @return Optimal buffer size for write operations in bytes
     */
    size_t getOptimalWriteBufferSize();

    /**
     * @brief Calculate adaptive verification buffer size based on file size and available memory
     * @param fileSize Size of file to be verified in bytes
     * @return Optimal buffer size for verification operations in bytes
     */
    size_t getAdaptiveVerifyBufferSize(qint64 fileSize);

    /**
     * @brief Calculate optimal input buffer size for downloads/streams
     * @return Optimal buffer size for input operations in bytes
     */
    size_t getOptimalInputBufferSize();

    /**
     * @brief Get system page size for memory alignment
     * @return System page size in bytes
     */
    // Static: it reads the machine's page size and nothing of this object's,
    // so the ladder helpers above can align without an instance.
    static size_t getSystemPageSize();

    /**
     * @brief Calculate optimal ring buffer slot count based on available memory
     * 
     * Balances pipelining depth against memory usage. More slots allow
     * better overlap between producer and consumer, but use more memory.
     * 
     * @param slotSize Size of each slot in bytes
     * @return Optimal number of slots for the ring buffer
     */
    size_t getOptimalRingBufferSlots(size_t slotSize);

    /**
     * @brief Log a summary of all memory-based configuration
     * 
     * Useful for diagnostics - shows all adaptive settings based on detected memory.
     */
    void logConfigurationSummary();

    /**
     * @brief Calculate coordinated ring buffer configuration
     * 
     * Returns slot counts and sizes for both input and write ring buffers that 
     * together fit within a safe memory budget (30% of available RAM).
     * 
     * Strategy:
     * 1. Start with optimal buffer sizes (passed in as hints)
     * 2. If minimum slots don't fit in budget, scale down sizes (page-aligned)
     * 3. Allocate slots with 2/3 budget to write (for latency smoothing)
     * 
     * @param inputSlotSizeHint Optimal input slot size (may be scaled down)
     * @param writeSlotSizeHint Optimal write slot size (may be scaled down)
     * @param inputSlots Output: number of input ring buffer slots
     * @param writeSlots Output: number of write ring buffer slots
     * @param actualInputSize Output: actual input slot size (may differ from hint)
     * @param actualWriteSize Output: actual write slot size (may differ from hint)
     * @return Total memory that will be allocated in bytes
     */
    size_t getCoordinatedRingBufferConfig(size_t inputSlotSizeHint, size_t writeSlotSizeHint,
                                          size_t& inputSlots, size_t& writeSlots,
                                          size_t& actualInputSize, size_t& actualWriteSize);

    /**
     * @brief Calculate optimal async I/O queue depth based on system resources
     * 
     * The queue depth determines how many async writes can be in flight simultaneously.
     * Higher values can hide device latency but use more memory for buffer copies.
     * 
     * Returns a value between 4 (conservative) and 64 (aggressive) based on:
     * - Total system memory
     * - Available memory
     * - Expected write block size
     * 
     * @param writeBlockSize Size of write blocks in bytes (default 1MB)
     * @return Optimal async queue depth
     */
    int getOptimalAsyncQueueDepth(size_t writeBlockSize = 1024 * 1024);

private:
    SystemMemoryManager() = default;
    ~SystemMemoryManager() = default;
    SystemMemoryManager(const SystemMemoryManager&) = delete;
    SystemMemoryManager& operator=(const SystemMemoryManager&) = delete;

    // Platform-specific implementations
    qint64 getPlatformTotalMemoryMB();
    qint64 getPlatformAvailableMemoryMB();

    // Configuration constants
    static constexpr qint64 MIN_SYNC_INTERVAL_BYTES = 16LL * 1024 * 1024;   // 16MB minimum
    static constexpr qint64 MAX_SYNC_INTERVAL_BYTES = 256LL * 1024 * 1024;  // 256MB maximum
    static constexpr qint64 DEFAULT_SYNC_INTERVAL_MS = 5000;                // 5 seconds default
    
    // Memory tier thresholds
    static constexpr qint64 LOW_MEMORY_THRESHOLD_MB = 2048;     // 2GB
    static constexpr qint64 HIGH_MEMORY_THRESHOLD_MB = 8192;    // 8GB

    // Cached values to avoid repeated system calls
    mutable qint64 _cachedTotalMemoryMB = -1;
    mutable qint64 _cachedAvailableMemoryMB = -1;
};

#endif // SYSTEMMEMORYMANAGER_H
