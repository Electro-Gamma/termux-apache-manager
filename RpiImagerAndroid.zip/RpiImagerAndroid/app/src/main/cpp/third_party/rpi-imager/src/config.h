#ifndef CONFIG_H
#define CONFIG_H

/*
 * SPDX-License-Identifier: Apache-2.0
 * Copyright (C) 2020-2025 Raspberry Pi Ltd
 */


/* Repository URL */
#define OSLIST_URL                              "https://downloads.raspberrypi.com/os_list_imagingutility_v4.json"

/* Custom repository manifest file extension (without leading dot) */
#define MANIFEST_EXTENSION                      "rpi-imager-manifest"

/* MIME type for manifest files */
#define MANIFEST_MIME_TYPE                      "application/vnd.raspberrypi.imager-manifest+json"

/* Time synchronization URL (only used on linuxfb QPA platform, URL must be HTTP) */
#define TIME_URL                                "http://downloads.raspberrypi.com/"

/* Raspberry Pi Connect API */
#define CONNECT_API_URL                         "https://api.connect.raspberrypi.com"

/* Client ID issued to Imager for the Connect device-code sign-in (embedded
 * mode, which has no browser for the usual sign-in). The API answers 401 to
 * an ID it does not know. */
#define CONNECT_DEVICE_CLIENT_ID                "F0245915-2B1C-4FB4-86BC-15AEA995FE62"

/* Phone home the name of images downloaded for image popularity ranking */
#define TELEMETRY_URL                           "https://rpi-imager-stats.raspberrypi.com/downloads"

/* Hash algorithm for verifying (uncompressed image) checksum */
#define OSLIST_HASH_ALGORITHM                   QCryptographicHash::Sha256

/* Update progressbar every 0.1 second */
#define PROGRESS_UPDATE_INTERVAL                100

/* Default block size for buffer allocation (dynamically adjusted at runtime) */
#define IMAGEWRITER_BLOCKSIZE                   1*1024*1024

/* Enable caching */
#define IMAGEWRITER_ENABLE_CACHE_DEFAULT        true

/* Do not cache if it would bring free disk space under 5 GB */
#define IMAGEWRITER_MINIMAL_SPACE_FOR_CACHING   5*1024*1024*1024ll

#endif // CONFIG_H
