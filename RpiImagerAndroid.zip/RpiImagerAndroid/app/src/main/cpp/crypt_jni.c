/* SPDX-License-Identifier: Apache-2.0
 * JNI bridge to the ORIGINAL rpi-imager 2.0.12 password hashing code
 * (yescrypt: BSD-2-Clause, Openwall; sha256crypt: public domain).
 * Inputs are raw byte arrays (not Java strings) so non-ASCII passwords are
 * hashed as plain UTF-8, exactly as the original hashes QByteArray. */
#include <jni.h>
#include <stdlib.h>
#include <string.h>

char *sha256_crypt(const char *key, const char *salt);
char *yescrypt_crypt(const char *key, const char *salt);

static char *cstr(JNIEnv *env, jbyteArray a) {
    jsize n = (*env)->GetArrayLength(env, a);
    char *s = (char *)calloc((size_t)n + 1, 1);
    if (s) (*env)->GetByteArrayRegion(env, a, 0, n, (jbyte *)s);
    return s;
}

static jbyteArray run(JNIEnv *env, jbyteArray jkey, jbyteArray jsalt, int yes) {
    char *key = cstr(env, jkey), *salt = cstr(env, jsalt);
    jbyteArray out = NULL;
    if (key && salt) {
        char *r = yes ? yescrypt_crypt(key, salt) : sha256_crypt(key, salt);
        if (r) {
            jsize n = (jsize)strlen(r);
            out = (*env)->NewByteArray(env, n);
            if (out) (*env)->SetByteArrayRegion(env, out, 0, n, (const jbyte *)r);
        }
    }
    if (key) { memset(key, 0, strlen(key)); free(key); }
    free(salt);
    return out;
}

JNIEXPORT jbyteArray JNICALL
Java_org_rpiimager_android_customise_NativeCrypt_nativeYescrypt(JNIEnv *env, jobject t, jbyteArray k, jbyteArray s) {
    return run(env, k, s, 1);
}
JNIEXPORT jbyteArray JNICALL
Java_org_rpiimager_android_customise_NativeCrypt_nativeSha256(JNIEnv *env, jobject t, jbyteArray k, jbyteArray s) {
    return run(env, k, s, 0);
}
