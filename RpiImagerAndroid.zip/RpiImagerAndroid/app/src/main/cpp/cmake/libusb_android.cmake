# SPDX-License-Identifier: Apache-2.0
# libusb for Android, built from upstream sources using upstream's own
# android/config.h.  Used two ways:
#   * rpiboot/ (original code, Compute Module boot) - compiled but not reachable
#     without raw USB access.
#   * android_platform/libusb_transport_android.cpp - wraps the fd handed out by
#     UsbManager.openDevice() with libusb_wrap_sys_device().
set(LIBUSB_VERSION "1.0.30")
FetchContent_Declare(libusb
    GIT_REPOSITORY https://github.com/libusb/libusb.git
    GIT_TAG v${LIBUSB_VERSION}
)
FetchContent_GetProperties(libusb)
if(NOT libusb_POPULATED)
    FetchContent_Populate(libusb)
endif()
set(_lu ${libusb_SOURCE_DIR}/libusb)
add_library(usb-1.0-static STATIC
    ${_lu}/core.c ${_lu}/descriptor.c ${_lu}/hotplug.c ${_lu}/io.c
    ${_lu}/strerror.c ${_lu}/sync.c
    ${_lu}/os/events_posix.c ${_lu}/os/threads_posix.c
    ${_lu}/os/linux_usbfs.c ${_lu}/os/linux_netlink.c)
# libusb's own android/config.h is incomplete for the current sources (no PLATFORM_POSIX,
# DEFAULT_VISIBILITY, PRINTF_FORMAT), so write the config the autotools build would produce.
set(_cfg_dir ${CMAKE_CURRENT_BINARY_DIR}/libusb-config)
file(MAKE_DIRECTORY ${_cfg_dir})
file(WRITE ${_cfg_dir}/config.h
"#ifndef LIBUSB_CONFIG_H\n#define LIBUSB_CONFIG_H\n"
"#define DEFAULT_VISIBILITY __attribute__((visibility(\"default\")))\n"
"#define PRINTF_FORMAT(a, b) __attribute__((__format__(__printf__, a, b)))\n"
"#define PLATFORM_POSIX 1\n#define HAVE_CLOCK_GETTIME 1\n#define HAVE_EVENTFD 1\n#define HAVE_TIMERFD 1\n"
"#define HAVE_NFDS_T 1\n#define HAVE_SYS_TIME_H 1\n#define HAVE_POLL_H 1\n#define HAVE_ASM_TYPES_H 1\n"
"#define ENABLE_LOGGING 1\n#define USE_SYSTEM_LOGGING_FACILITY 1\n#define _GNU_SOURCE 1\n"
"#endif\n")
target_include_directories(usb-1.0-static PRIVATE ${_cfg_dir} ${_lu} ${_lu}/os)
target_compile_options(usb-1.0-static PRIVATE -Wno-unused-parameter)
set_property(TARGET usb-1.0-static PROPERTY POSITION_INDEPENDENT_CODE ON)
target_link_libraries(usb-1.0-static PUBLIC log)
set(LIBUSB_INCLUDE_DIR ${_lu})
set(LIBUSB_LIBRARIES usb-1.0-static)
