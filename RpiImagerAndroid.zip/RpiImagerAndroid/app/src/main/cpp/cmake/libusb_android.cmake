# SPDX-License-Identifier: Apache-2.0
# libusb for Android, built from upstream sources using upstream's own
# android/config.h.  Used two ways:
#   * rpiboot/ (original code, Compute Module boot) - compiled but not reachable
#     without raw USB access.
#   * android_platform/libusb_transport_android.cpp - wraps the fd handed out by
#     UsbManager.openDevice() with libusb_wrap_sys_device().
set(LIBUSB_VERSION "1.0.30")
FetchContent_Declare(libusb
    GIT_REPOSITORY https://github.com/libusb/libusb.git
    GIT_TAG v${LIBUSB_VERSION}
)
FetchContent_GetProperties(libusb)
if(NOT libusb_POPULATED)
    FetchContent_Populate(libusb)
endif()
set(_lu ${libusb_SOURCE_DIR}/libusb)
add_library(usb-1.0-static STATIC
    ${_lu}/core.c ${_lu}/descriptor.c ${_lu}/hotplug.c ${_lu}/io.c
    ${_lu}/strerror.c ${_lu}/sync.c
    ${_lu}/os/events_posix.c ${_lu}/os/threads_posix.c
    ${_lu}/os/linux_usbfs.c ${_lu}/os/linux_netlink.c)
target_include_directories(usb-1.0-static PRIVATE ${libusb_SOURCE_DIR}/android ${_lu} ${_lu}/os)
target_compile_options(usb-1.0-static PRIVATE -Wno-unused-parameter)
# Upstream android/config.h does not select the POSIX backend headers: libusbi.h only includes
# os/threads_posix.h and os/events_posix.h when PLATFORM_POSIX is defined.
target_compile_definitions(usb-1.0-static PRIVATE PLATFORM_POSIX=1 HAVE_CLOCK_GETTIME=1 HAVE_EVENTFD=1 HAVE_TIMERFD=1)
set_property(TARGET usb-1.0-static PROPERTY POSITION_INDEPENDENT_CODE ON)
target_link_libraries(usb-1.0-static PUBLIC log)
set(LIBUSB_INCLUDE_DIR ${_lu})
set(LIBUSB_LIBRARIES usb-1.0-static)
