# SPDX-License-Identifier: Apache-2.0
# mbedTLS (TLS backend for libcurl on Android)
set(MBEDTLS_VERSION "3.6.2")
FetchContent_Declare(mbedtls
    GIT_REPOSITORY https://github.com/Mbed-TLS/mbedtls.git
    GIT_TAG v${MBEDTLS_VERSION}
    GIT_SHALLOW TRUE           # submodules (framework/) are required by its CMake
)
set(ENABLE_PROGRAMS OFF CACHE BOOL "" FORCE)
set(ENABLE_TESTING OFF CACHE BOOL "" FORCE)
set(MBEDTLS_FATAL_WARNINGS OFF CACHE BOOL "" FORCE)
set(GEN_FILES OFF CACHE BOOL "" FORCE)
set(USE_SHARED_MBEDTLS_LIBRARY OFF CACHE BOOL "" FORCE)
set(USE_STATIC_MBEDTLS_LIBRARY ON CACHE BOOL "" FORCE)
set(INSTALL_MBEDTLS_HEADERS OFF CACHE BOOL "" FORCE)
FetchContent_MakeAvailable(mbedtls)
set(MBEDTLS_INCLUDE_DIR_ANDROID ${mbedtls_SOURCE_DIR}/include)
