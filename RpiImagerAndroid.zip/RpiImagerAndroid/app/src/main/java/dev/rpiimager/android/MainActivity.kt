// SPDX-License-Identifier: Apache-2.0
package dev.rpiimager.android

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.system.Os
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import org.qtproject.qt.android.bindings.QtActivity
import java.io.File
import java.util.TimeZone
import java.util.concurrent.Executors

/**
 * The Qt activity hosts the (headless) Qt event loop that runs the original Imager core.
 * All user-facing UI is native Android views layered over it.
 */
class MainActivity : QtActivity() {
    private enum class Screen { DEVICE, OS, STORAGE, CUSTOM, CONFIRM, WRITING, DONE, ABOUT }

    private val ui = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private lateinit var root: FrameLayout
    private lateinit var content: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var usb: UsbStorage
    private val prefs by lazy { getSharedPreferences("customisation", Context.MODE_PRIVATE) }

    private var screen = Screen.DEVICE
    private var ready = false
    private var osJson: JSONObject? = null
    private var devices: List<HwDevice> = emptyList()
    private var device: HwDevice? = null
    private var osTop: List<OsItem> = emptyList()
    private val osPath = ArrayList<OsItem>()           // category drill-down
    private var os: OsItem? = null
    private var customName: String? = null
    private var customPath: String? = null
    private var customSize = 0L
    private var customPfd: android.os.ParcelFileDescriptor? = null
    private var drive: UsbDrive? = null
    private var verify = true
    private var statusText = ""
    private var progressNow = 0L
    private var progressTotal = 0L
    private var phase = "preparing"
    private var resultMessage: String? = null
    private var resultOk = false
    private var writeView: Triple<TextView, ProgressBar, TextView>? = null
    private var timezones: List<String> = emptyList()
    private var keymaps: List<String> = emptyList()
    private var countries: List<String> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)        // loads Qt + starts the Qt thread
        root = FrameLayout(this).apply { setBackgroundColor(Pal.bg) }
        scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(24))
        }
        scroll.addView(content)
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        // Layered over Qt's (empty) layout so QtActivity's internal view tree stays intact.
        addContentView(root, ViewGroup.LayoutParams(-1, -1))
        render()
        usb = UsbStorage(this) { ui.post { if (screen == Screen.STORAGE) render() } }
        NativeEngine.setListener { n, p -> ui.post { onEvent(n, p) } }
        waitForEngine()
    }

    private fun waitForEngine() {
        if (NativeEngine.nativeIsReady()) {
            ready = true
            io.execute {
                try {
                    NativeEngine.nativeConfigure(CaBundle.export(this))
                    timezones = NativeEngine.stringList("timezones")
                    keymaps = NativeEngine.stringList("keymaps")
                    countries = NativeEngine.stringList("countries")
                    NativeEngine.nativeFetchOsList()
                } catch (e: Throwable) { ui.post { toast("Engine init failed: ${e.message}") } }
            }
            usb.start()
            render()
        } else ui.postDelayed({ waitForEngine() }, 100)
    }

    override fun onResume() { super.onResume(); if (ready) { usb.refresh(); } }
    override fun onDestroy() { if (::usb.isInitialized) usb.stop(); super.onDestroy() }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when (screen) {
            Screen.DEVICE -> super.onBackPressed()
            Screen.OS -> if (osPath.isNotEmpty()) { osPath.removeAt(osPath.size - 1); render() } else go(Screen.DEVICE)
            Screen.STORAGE -> go(Screen.OS)
            Screen.CUSTOM -> go(Screen.STORAGE)
            Screen.CONFIRM -> go(if (hasCustomisation()) Screen.CUSTOM else Screen.STORAGE)
            Screen.WRITING -> toast("Use Cancel to stop writing")
            Screen.DONE -> { resetAll(); go(Screen.DEVICE) }
            Screen.ABOUT -> go(Screen.DEVICE)
        }
    }

    // ------------------------------------------------------------- events ---
    private fun onEvent(name: String, p: JSONObject) {
        when (name) {
            "osListPrepared", "osListUnavailable" -> { loadOsList(); if (screen == Screen.DEVICE || screen == Screen.OS) render() }
            "status" -> { statusText = p.optString("message"); updateWrite() }
            "writeState" -> { phase = p.optString("state"); updateWrite() }
            "writeProgress" -> { progressNow = p.optDouble("now").toLong(); progressTotal = p.optDouble("total").toLong(); if (phase == "preparing") phase = "writing"; updateWrite() }
            "verifyProgress" -> { phase = "verifying"; progressNow = p.optDouble("now").toLong(); progressTotal = p.optDouble("total").toLong(); updateWrite() }
            "finalizing" -> { phase = "finalizing"; updateWrite() }
            "success" -> finish(true, "Write successful. You can remove the card.")
            "cancelled" -> finish(false, "Cancelled.")
            "error" -> finish(false, p.optString("message", "Unknown error"))
            "warning" -> toast(p.optString("message"))
            "deviceRemoved" -> if (screen == Screen.WRITING) toast("Device removed")
        }
    }

    private fun finish(ok: Boolean, msg: String) {
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        resultOk = ok; resultMessage = msg
        if (screen == Screen.WRITING) go(Screen.DONE)
    }

    private fun loadOsList() {
        io.execute {
            val txt = NativeEngine.nativeOsListJson()
            val o = try { JSONObject(txt) } catch (_: Exception) { return@execute }
            ui.post {
                osJson = o
                devices = HwDevice.parseAll(o.optJSONObject("imager") ?: JSONObject())
                val a = o.optJSONArray("os_list") ?: JSONArray()
                osTop = List(a.length()) { OsItem.parse(a.getJSONObject(it)) }
                if (screen == Screen.DEVICE || screen == Screen.OS) render()
            }
        }
    }

    // ---------------------------------------------------------- navigation ---
    private fun go(s: Screen) { screen = s; render() }
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()
    private fun resetAll() { os = null; drive = null; device = null; osPath.clear(); resultMessage = null; progressNow = 0; progressTotal = 0 }
    private fun hasCustomisation() = os?.initFormat?.isNotEmpty() == true

    private fun render() {
        content.removeAllViews(); writeView = null
        when (screen) {
            Screen.DEVICE -> deviceScreen()
            Screen.OS -> osScreen()
            Screen.STORAGE -> storageScreen()
            Screen.CUSTOM -> customScreen()
            Screen.CONFIRM -> confirmScreen()
            Screen.WRITING -> writingScreen()
            Screen.DONE -> doneScreen()
            Screen.ABOUT -> aboutScreen()
        }
        scroll.scrollTo(0, 0)
    }

    private fun header(title: String, step: String?) {
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL }
        bar.addView(label("Raspberry Pi Imager", 13f, Pal.raspberry, true), LinearLayout.LayoutParams(0, -2, 1f))
        if (screen != Screen.WRITING && screen != Screen.ABOUT)
            bar.addView(label("About", 13f, Pal.muted).apply { setPadding(dp(8), dp(8), 0, dp(8)); setOnClickListener { go(Screen.ABOUT) } })
        content.addView(bar)
        if (step != null) content.addView(label(step, 12f, Pal.muted))
        content.addView(heading(title))
    }

    private fun nav(back: (() -> Unit)?, nextText: String?, next: (() -> Unit)?, nextEnabled: Boolean = true) {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(12), 0, 0) }
        if (back != null) r.addView(secondaryButton("Back", back), LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(8) })
        if (nextText != null && next != null) r.addView(primaryButton(nextText, next).apply { isEnabled = nextEnabled; alpha = if (nextEnabled) 1f else .4f }, LinearLayout.LayoutParams(0, -2, 1f))
        content.addView(r)
    }

    // -------------------------------------------------------------- screens ---
    private fun deviceScreen() {
        header("Choose Device", "Step 1 of 4")
        if (!ready) { content.addView(label("Starting the Imager engine…", 15f, Pal.muted)); return }
        if (devices.isEmpty()) {
            content.addView(label(if (osJson == null) "Loading the Raspberry Pi repository…" else "No device list available (offline?). You can continue without a device filter.", 14f, Pal.muted))
        }
        for (d in devices) content.addView(row(d.name, d.description) { selectDevice(d) })
        content.addView(row("No filtering", "Show all images") { selectDevice(null) })
        if (osJson == null) content.addView(secondaryButton("Retry") { io.execute { NativeEngine.nativeFetchOsList() } })
    }

    private fun selectDevice(d: HwDevice?) {
        device = d
        io.execute {
            NativeEngine.nativeSetHwFilter(d?.tags?.toString() ?: "[]", d?.inclusive ?: false)
            val txt = NativeEngine.nativeOsListJson()
            val a = try { JSONObject(txt).optJSONArray("os_list") ?: JSONArray() } catch (_: Exception) { JSONArray() }
            ui.post { osTop = List(a.length()) { OsItem.parse(a.getJSONObject(it)) }; osPath.clear(); go(Screen.OS) }
        }
    }

    private fun osScreen() {
        header(osPath.lastOrNull()?.name ?: "Choose Operating System", "Step 2 of 4")
        content.addView(label(device?.let { "For ${it.name}" } ?: "No device filter", 13f, Pal.muted))
        val items = osPath.lastOrNull()?.subitems ?: osTop
        for (it in items) {
            when {
                it.isCustom -> content.addView(row("Use custom", "Select a .img/.iso/.zip/.xz/.gz/.zst file from storage") { pickCustom() })
                it.isErase -> content.addView(row("Erase", "Format card as FAT32") { os = it; customPath = null; go(Screen.STORAGE) })
                it.isCategory -> content.addView(row(it.name + "  ›", it.description) { osPath.add(it); render() })
                else -> content.addView(row(it.name, listOfNotNull(it.description.ifBlank { null },
                    it.releaseDate.ifBlank { null }, fmtSize(it.downloadSize).ifBlank { null }).joinToString(" · ")) {
                    os = it; customPath = null; go(Screen.STORAGE)
                })
            }
        }
        nav({ onBackPressed() }, null, null)
    }

    private val pickRequest = 4711
    private fun pickCustom() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
        @Suppress("DEPRECATION") startActivityForResult(i, pickRequest)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri: Uri = data?.data ?: return
        if (requestCode != pickRequest || resultCode != RESULT_OK) return
        try {
            var name = "image.img"; var size = 0L
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    c.getColumnIndex(OpenableColumns.DISPLAY_NAME).takeIf { it >= 0 }?.let { name = c.getString(it) }
                    c.getColumnIndex(OpenableColumns.SIZE).takeIf { it >= 0 }?.let { size = c.getLong(it) }
                }
            }
            customPfd?.close()
            val pfd = contentResolver.openFileDescriptor(uri, "r") ?: throw IllegalStateException("cannot open")
            customPfd = pfd
            // The core decides how to decompress by file name, so expose the fd under the real name.
            val dir = File(cacheDir, "custom").apply { deleteRecursively(); mkdirs() }
            val link = File(dir, name.replace('/', '_'))
            Os.symlink("/proc/self/fd/${pfd.fd}", link.absolutePath)
            customPath = link.absolutePath; customName = name; customSize = size
            os = OsItem("Custom: $name", "", link.absolutePath, 0, size, "", "", "", "", emptyList(), JSONObject(), false)
            go(Screen.STORAGE)
        } catch (e: Exception) { toast("Cannot open file: ${e.message}") }
    }

    private fun storageScreen() {
        header("Choose Storage", "Step 3 of 4")
        content.addView(label("Selected: ${os?.name ?: ""}", 13f, Pal.muted))
        content.addView(label(
            "Android cannot access internal SD slots or raw block devices without root. Connect the card through a USB card reader (OTG) and allow access.",
            13f, Pal.muted).apply { setPadding(0, dp(8), 0, dp(8)) })
        if (usb.drives.isEmpty()) content.addView(label(usb.lastError ?: "No USB storage detected.", 14f, if (usb.lastError != null) Pal.warn else Pal.muted))
        for (d in usb.drives.values) content.addView(row(d.label, fmtSize(d.size) + if (d.writeProtected) " · WRITE PROTECTED" else "") {
            if (d.writeProtected) toast("This device is write protected") else { drive = d; go(if (hasCustomisation()) Screen.CUSTOM else Screen.CONFIRM) }
        })
        content.addView(secondaryButton("Rescan") { usb.refresh(); render() })
        content.addView(secondaryButton("Card swapped? Re-read device") { usb.drives.keys.toList().forEach { usb.reprobe(it) } })
        nav({ onBackPressed() }, null, null)
    }

    // customisation form state
    private var fHost: EditText? = null; private var fUser: EditText? = null; private var fPass: EditText? = null
    private var fSsid: EditText? = null; private var fWpass: EditText? = null; private var fHidden: CheckBox? = null
    private var fCountry: Spinner? = null; private var fTz: Spinner? = null; private var fKb: Spinner? = null
    private var fSsh: CheckBox? = null; private var fSshPw: CheckBox? = null; private var fKeys: EditText? = null
    private var fSudo: CheckBox? = null; private var fVerify: CheckBox? = null; private var fWifi: CheckBox? = null
    private var fLocale: CheckBox? = null; private var fUserOn: CheckBox? = null; private var fHostOn: CheckBox? = null
    private var fSpi: CheckBox? = null; private var fSerial: CheckBox? = null

    private fun customScreen() {
        header("OS Customisation", "Step 4 of 4")
        content.addView(label("Applied to the image after writing (${os?.initFormat}).", 13f, Pal.muted))
        fHostOn = check("Set hostname", prefs.getBoolean("hostOn", true))
        fHost = field("hostname", prefs.getString("hostname", "raspberrypi")!!)
        content.addView(section("General", fHostOn!!, fHost!!))

        fUserOn = check("Set username and password", prefs.getBoolean("userOn", true))
        fUser = field("username", prefs.getString("user", "pi")!!)
        fPass = field("password (not saved)", "", true)
        fSudo = check("Passwordless sudo", prefs.getBoolean("sudo", false))
        content.addView(section("User", fUserOn!!, fUser!!, fPass!!, fSudo!!))

        fWifi = check("Configure wireless LAN", prefs.getBoolean("wifiOn", false))
        fSsid = field("SSID", prefs.getString("ssid", "")!!)
        fWpass = field("Wi-Fi password (not saved)", "", true)
        fHidden = check("Hidden SSID", prefs.getBoolean("hidden", false))
        fCountry = spinner(countries, prefs.getString("country", "GB"))
        content.addView(section("Wi-Fi", fWifi!!, fSsid!!, fWpass!!, fHidden!!, label("Wi-Fi country", 13f, Pal.muted), fCountry!!))

        fLocale = check("Set locale settings", prefs.getBoolean("localeOn", true))
        fTz = spinner(timezones, prefs.getString("tz", TimeZone.getDefault().id))
        fKb = spinner(keymaps, prefs.getString("kb", "us"))
        content.addView(section("Locale", fLocale!!, label("Time zone", 13f, Pal.muted), fTz!!, label("Keyboard layout", 13f, Pal.muted), fKb!!))

        fSsh = check("Enable SSH", prefs.getBoolean("ssh", false))
        fSshPw = check("Allow password authentication", prefs.getBoolean("sshPw", true))
        fKeys = field("authorized public key(s)", prefs.getString("keys", "")!!)
        content.addView(section("Services", fSsh!!, fSshPw!!, fKeys!!))

        fSpi = check("Enable SPI", prefs.getBoolean("spi", false)); fSerial = check("Enable serial console", prefs.getBoolean("serial", false))
        fVerify = check("Verify written data (recommended)", verify)
        content.addView(section("Options", fSpi!!, fSerial!!, fVerify!!))
        nav({ onBackPressed() }, "Next") { collectCustomisation(); go(Screen.CONFIRM) }
    }

    private var custJson = JSONObject()

    private fun collectCustomisation() {
        val j = JSONObject()
        fun s(sp: Spinner?) = sp?.selectedItem?.toString() ?: ""
        if (fHostOn!!.isChecked) j.put("hostname", fHost!!.text.toString().trim())
        if (fUserOn!!.isChecked && fPass!!.text.isNotEmpty()) {
            j.put("sshUserName", fUser!!.text.toString().trim()); j.put("sshUserPasswordPlain", fPass!!.text.toString())
        } else if (fUserOn!!.isChecked) j.put("sshUserName", fUser!!.text.toString().trim())
        j.put("passwordlessSudo", fSudo!!.isChecked)
        if (fWifi!!.isChecked && fSsid!!.text.isNotBlank()) {
            j.put("wifiConfigured", true); j.put("wifiSSID", fSsid!!.text.toString()); j.put("wifiPassword", fWpass!!.text.toString())
            j.put("wifiHidden", fHidden!!.isChecked); j.put("wifiSSIDHidden", fHidden!!.isChecked)
            j.put("recommendedWifiCountry", s(fCountry))
        }
        if (fLocale!!.isChecked) { j.put("timezone", s(fTz)); j.put("keyboard", s(fKb)) }
        j.put("sshEnabled", fSsh!!.isChecked); j.put("sshPasswordAuth", fSshPw!!.isChecked)
        val keys = fKeys!!.text.toString().trim()
        if (keys.isNotEmpty()) { j.put("sshPublicKey", keys); j.put("sshAuthorizedKeys", keys) }
        j.put("enableSPI", fSpi!!.isChecked); j.put("enableSerial", fSerial!!.isChecked)
        custJson = j
        verify = fVerify!!.isChecked
        prefs.edit().putBoolean("hostOn", fHostOn!!.isChecked).putString("hostname", fHost!!.text.toString())
            .putBoolean("userOn", fUserOn!!.isChecked).putString("user", fUser!!.text.toString()).putBoolean("sudo", fSudo!!.isChecked)
            .putBoolean("wifiOn", fWifi!!.isChecked).putString("ssid", fSsid!!.text.toString()).putBoolean("hidden", fHidden!!.isChecked)
            .putString("country", s(fCountry)).putBoolean("localeOn", fLocale!!.isChecked).putString("tz", s(fTz)).putString("kb", s(fKb))
            .putBoolean("ssh", fSsh!!.isChecked).putBoolean("sshPw", fSshPw!!.isChecked).putString("keys", keys)
            .putBoolean("spi", fSpi!!.isChecked).putBoolean("serial", fSerial!!.isChecked).apply()
    }

    private fun confirmScreen() {
        header("Ready to write", null)
        content.addView(section("Summary",
            label("Device: ${device?.name ?: "any"}", 14f), label("OS: ${os?.name}", 14f),
            label("Storage: ${drive?.label} (${fmtSize(drive?.size ?: 0)})", 14f),
            label("Verify after writing: ${if (verify) "yes" else "no"}", 14f),
            label("Customisation: ${if (hasCustomisation()) "yes" else "no"}", 14f)))
        content.addView(label("ALL existing data on the storage device will be erased.", 15f, Pal.warn, true).apply { setPadding(0, dp(4), 0, dp(8)) })
        nav({ onBackPressed() }, "Write") { startWrite() }
    }

    private fun startWrite() {
        val o = os ?: return; val d = drive ?: return
        resultMessage = null; progressNow = 0; progressTotal = 0; phase = "preparing"; statusText = "Starting…"
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        go(Screen.WRITING)
        io.execute {
            try {
                val parent = osPath.lastOrNull()?.name ?: ""
                NativeEngine.nativeSetSource(o.url, o.downloadSize, o.extractSize, o.sha256, false, parent, o.name, o.initFormat, o.releaseDate, o.bmapUrl)
                NativeEngine.nativeSetDestination(d.path, d.size)
                NativeEngine.nativeSetVerify(verify)
                NativeEngine.nativeSetEject(false)
                if (hasCustomisation()) NativeEngine.nativeApplyCustomisation(custJson.toString())
                NativeEngine.nativeStartWrite()
            } catch (e: Throwable) { ui.post { finish(false, "Failed to start: ${e.message}") } }
        }
    }

    private fun writingScreen() {
        header("Writing…", null)
        val st = label(statusText, 14f, Pal.muted); val pb = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 1000 }
        val tx = label("", 13f, Pal.muted)
        content.addView(label("Do not remove the device or close the app.", 14f, Pal.warn, true))
        content.addView(st); content.addView(pb, LinearLayout.LayoutParams(-1, dp(24))); content.addView(tx)
        content.addView(secondaryButton("Cancel") { io.execute { NativeEngine.nativeCancelWrite() } }.apply { (this as View).setPadding(dp(16), dp(12), dp(16), dp(12)) })
        writeView = Triple(st, pb, tx); updateWrite()
    }

    private fun updateWrite() {
        val (st, pb, tx) = writeView ?: return
        val names = mapOf("preparing" to "Preparing", "writing" to "Writing", "verifying" to "Verifying", "finalizing" to "Finalizing", "cancelling" to "Cancelling")
        st.text = (names[phase] ?: phase.replaceFirstChar { it.uppercase() }) + if (statusText.isNotBlank() && phase == "preparing") " — $statusText" else ""
        pb.progress = if (progressTotal > 0) (progressNow * 1000 / progressTotal).toInt() else 0
        pb.isIndeterminate = progressTotal <= 0
        tx.text = if (progressTotal > 0) "${fmtSize(progressNow)} / ${fmtSize(progressTotal)}" else ""
    }

    private fun doneScreen() {
        header(if (resultOk) "Write Successful" else "Write failed", null)
        content.addView(label(resultMessage ?: "", 15f, if (resultOk) Pal.ink else Pal.warn))
        if (resultOk) content.addView(label("Safely remove the reader before unplugging it.", 13f, Pal.muted).apply { setPadding(0, dp(8), 0, 0) })
        nav(null, "Write another") { resetAll(); go(Screen.DEVICE) }
    }

    private fun aboutScreen() {
        header("About", null)
        val ver = try { NativeEngine.nativeVersion() } catch (_: Throwable) { "?" }
        content.addView(section("Raspberry Pi Imager for Android",
            label("Based on Raspberry Pi Imager $ver (engine) by Raspberry Pi Ltd, licensed under the Apache License 2.0. " +
                "This is an unofficial Android port and is not affiliated with or endorsed by Raspberry Pi Ltd. " +
                "\"Raspberry Pi\" is a trademark of Raspberry Pi Ltd.", 13f)))
        content.addView(section("Limitations",
            label("• Writes only to USB mass-storage devices (card readers via OTG). Internal SD slots and raw block devices are not accessible without root.\n" +
                "• Compute Module (rpiboot/fastboot) and secure-boot signing are not available.\n" +
                "• NOOBS-style multi-file images are not supported.\n" +
                "• English only. Keep the screen on and the app in the foreground while writing.", 13f)))
        content.addView(section("Open-source licences",
            label("Raspberry Pi Imager (Apache-2.0), Qt (LGPLv3), libcurl, mbedTLS (Apache-2.0), libarchive (BSD), zstd (BSD), xz (0BSD/public domain), zlib, nghttp2 (MIT), libusb (LGPL-2.1), yescrypt (BSD), QR Code generator (MIT). See NOTICE.md in the source distribution.", 13f)))
        nav({ onBackPressed() }, null, null)
    }
}
