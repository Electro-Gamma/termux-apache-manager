// SPDX-License-Identifier: Apache-2.0
package dev.rpiimager.android

import android.content.Context
import android.net.LocalServerSocket
import android.os.ParcelFileDescriptor
import org.json.JSONObject
import java.io.File
import java.io.FileDescriptor
import java.util.UUID

/**
 * Runs the ORIGINAL Raspberry Pi Imager CLI (cross-compiled, packaged as librpiimagercli.so).
 * Android children do not inherit file descriptors, so the opened USB connection (and a custom
 * image's descriptor) are handed over through an abstract UNIX socket with SCM_RIGHTS.
 */
class CliRunner(private val ctx: Context) {
    class Fd(val text: String, val fd: FileDescriptor)

    private val libDir = ctx.applicationInfo.nativeLibraryDir
    val exe: File = File(libDir, "librpiimagercli.so")
    val home: File = File(ctx.filesDir, "rpiimager").apply { mkdirs() }
    val available get() = exe.canExecute() || exe.exists()

    private fun builder(args: List<String>, sock: String, mergeErr: Boolean): ProcessBuilder {
        val pb = ProcessBuilder(listOf(exe.absolutePath, "--android-fd-socket", sock) + args)
        pb.environment().apply {
            put("LD_LIBRARY_PATH", libDir)
            put("RPIIMAGER_HOME", home.absolutePath)
            put("RPIIMAGER_CA_BUNDLE", CaBundle.export(ctx))
            put("HOME", home.absolutePath)
            put("TMPDIR", ctx.cacheDir.absolutePath)
        }
        pb.directory(home)
        pb.redirectErrorStream(mergeErr)
        return pb
    }

    /** Starts the CLI and serves the descriptors. The returned process must be waited on by the caller. */
    fun start(args: List<String>, fds: List<Fd>, mergeErr: Boolean): Process {
        val name = "rpiimager-" + UUID.randomUUID()
        val server = LocalServerSocket(name)
        val proc = builder(args, name, mergeErr).start()
        Thread {
            try {
                server.accept().use { s ->
                    val out = s.outputStream; val inp = s.inputStream
                    for (m in fds) {
                        s.setFileDescriptorsForSend(arrayOf(m.fd))
                        out.write((m.text + "\n").toByteArray()); out.flush()
                        s.setFileDescriptorsForSend(null)
                        inp.read()                       // ack from the child
                    }
                    out.write("done\n".toByteArray()); out.flush()
                }
            } catch (_: Exception) { } finally { try { server.close() } catch (_: Exception) {} }
        }.apply { isDaemon = true }.start()
        return proc
    }

    /** Opens the SCSI device and reports vendor/product/size. Blocking. */
    fun probe(usbPath: String, usbFd: Int, iface: Int, epIn: Int, epOut: Int): JSONObject {
        if (!exe.exists()) return JSONObject().put("ok", false).put("error", "native CLI missing from APK")
        val dup = ParcelFileDescriptor.fromFd(usbFd)         // dup; closed below
        try {
            val p = start(listOf("--android-probe"), listOf(Fd("usb\t$usbPath\t$iface\t$epIn\t$epOut", dup.fileDescriptor)), false)
            val out = p.inputStream.bufferedReader().readText()
            val err = p.errorStream.bufferedReader().readText()
            p.waitFor()
            val tail = err.lines().map { it.trim() }.filter { it.isNotEmpty() }.takeLast(3).joinToString(" | ")
            return try { JSONObject(out.trim().lines().last()) }
            catch (_: Exception) { JSONObject().put("ok", false).put("error", tail.ifBlank { "probe failed (exit ${p.exitValue()})" }) }
        } finally { dup.close() }
    }

    sealed class Event {
        data class Progress(val phase: String, val percent: Int) : Event()
        data class Status(val text: String) : Event()
        data class Done(val ok: Boolean, val message: String) : Event()
    }

    private val progressRe = Regex("""(Writing|Verifying): \[[^\]]*\] (\d+) %""")

    /** Runs a write; [onEvent] is called from a worker thread. Returns the process so it can be cancelled. */
    fun write(args: List<String>, fds: List<Fd>, onEvent: (Event) -> Unit): Process {
        val p = start(args, fds, true)
        Thread {
            val sb = StringBuilder(); val errors = ArrayList<String>(); var success = false
            fun line(raw: String) {
                val l = raw.replace("\u001b[0K", "").trim()
                if (l.isEmpty()) return
                val m = progressRe.find(l)
                when {
                    m != null -> onEvent(Event.Progress(m.groupValues[1], m.groupValues[2].toInt()))
                    l.startsWith("Write successful") -> success = true
                    l.startsWith("Error:") || errors.isNotEmpty() -> errors += l.removePrefix("Error:").trim()
                    else -> onEvent(Event.Status(l))
                }
            }
            val r = p.inputStream.reader()
            val buf = CharArray(512)
            while (true) {
                val n = r.read(buf); if (n < 0) break
                for (i in 0 until n) { val c = buf[i]; if (c == '\r' || c == '\n') { line(sb.toString()); sb.setLength(0) } else sb.append(c) }
            }
            if (sb.isNotEmpty()) line(sb.toString())
            val code = p.waitFor()
            when {
                success && code == 0 -> onEvent(Event.Done(true, "Write successful. You can remove the card."))
                else -> onEvent(Event.Done(false, errors.joinToString("\n").ifBlank { "The imager exited with code $code" }))
            }
        }.apply { isDaemon = true }.start()
        return p
    }
}
