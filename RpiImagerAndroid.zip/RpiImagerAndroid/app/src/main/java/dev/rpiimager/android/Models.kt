// SPDX-License-Identifier: Apache-2.0
package dev.rpiimager.android

import org.json.JSONArray
import org.json.JSONObject

data class OsItem(
    val name: String, val description: String, val url: String,
    val extractSize: Long, val downloadSize: Long, val sha256: String, val initFormat: String,
    val releaseDate: String, val subitems: List<OsItem>, val subitemsUrl: String?, val raw: JSONObject
) {
    val isCategory get() = subitems.isNotEmpty() || subitemsUrl != null
    val isCustom get() = url == "internal://custom"
    val isErase get() = url == "internal://format"

    companion object {
        fun parse(o: JSONObject): OsItem {
            val subs = o.optJSONArray("subitems")
            val list = if (subs == null) emptyList() else List(subs.length()) { parse(subs.getJSONObject(it)) }
            return OsItem(
                o.optString("name"), o.optString("description"), o.optString("url"),
                o.optLong("extract_size"), o.optLong("image_download_size"),
                o.optString("extract_sha256"), o.optString("init_format"),
                o.optString("release_date"), list, o.optString("subitems_url").ifBlank { null }, o
            )
        }
    }
}

data class HwDevice(val name: String, val description: String, val tags: List<String>, val inclusive: Boolean) {
    companion object {
        fun parseAll(imager: JSONObject): List<HwDevice> {
            val a = imager.optJSONArray("devices") ?: return emptyList()
            return List(a.length()) {
                val d = a.getJSONObject(it)
                val t = d.optJSONArray("tags") ?: JSONArray()
                HwDevice(d.optString("name"), d.optString("description"),
                    List(t.length()) { i -> t.getString(i) }, d.optString("matching_type") == "inclusive")
            }
        }
    }
}
