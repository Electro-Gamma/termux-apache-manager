// SPDX-License-Identifier: Apache-2.0
package dev.rpiimager.android

import android.content.Context
import java.io.File
import java.security.KeyStore
import java.security.cert.X509Certificate
import java.util.Base64

/** Exports the system trust store (AndroidCAStore) as a PEM bundle for libcurl/mbedTLS. */
object CaBundle {
    fun export(ctx: Context): String {
        val out = File(ctx.filesDir, "cacert.pem")
        val ks = KeyStore.getInstance("AndroidCAStore").apply { load(null) }
        val enc = Base64.getMimeEncoder(64, "\n".toByteArray())
        val sb = StringBuilder()
        for (alias in ks.aliases()) {
            val c = ks.getCertificate(alias) as? X509Certificate ?: continue
            sb.append("-----BEGIN CERTIFICATE-----\n").append(enc.encodeToString(c.encoded))
                .append("\n-----END CERTIFICATE-----\n")
        }
        out.writeText(sb.toString())
        return out.absolutePath
    }
}
