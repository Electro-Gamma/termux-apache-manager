// SPDX-License-Identifier: Apache-2.0
package dev.rpiimager.android

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import java.util.concurrent.Executors

class UsbDrive(
    val path: String, val label: String, val size: Long, val writeProtected: Boolean,
    val conn: UsbDeviceConnection, val iface: Int, val epIn: Int, val epOut: Int
) {
    /** Descriptor message for CliRunner. The connection stays open for the lifetime of the drive. */
    fun fdMessage() = CliRunner.Fd("usb\t$path\t$iface\t$epIn\t$epOut", fdObj(conn.fileDescriptor))
    private fun fdObj(i: Int) = android.os.ParcelFileDescriptor.fromFd(i).fileDescriptor
}

/**
 * Finds USB Mass-Storage (Bulk-Only/SCSI) devices, gets permission, opens them and has the native
 * CLI probe them. The CLI later talks SCSI to the device over the descriptor we pass to it.
 */
class UsbStorage(private val ctx: Context, private val cli: CliRunner, private val onChange: () -> Unit) {
    private val mgr = ctx.getSystemService(Context.USB_SERVICE) as UsbManager
    private val action = ctx.packageName + ".USB_PERMISSION"
    private val bg = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val conns = HashMap<String, UsbDeviceConnection>()
    @Volatile var drives: Map<String, UsbDrive> = emptyMap()
        private set
    @Volatile var lastError: String? = null
        private set

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val dev: UsbDevice? = if (Build.VERSION.SDK_INT >= 33)
                i.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
            else @Suppress("DEPRECATION") i.getParcelableExtra(UsbManager.EXTRA_DEVICE)
            when (i.action) {
                action -> if (dev != null && i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) openAsync(dev)
                           else lastError = "USB permission denied"
                UsbManager.ACTION_USB_DEVICE_DETACHED -> if (dev != null) remove(dev)
                UsbManager.ACTION_USB_DEVICE_ATTACHED -> refresh()
            }
            onChange()
        }
    }

    fun start() {
        val f = IntentFilter().apply {
            addAction(action); addAction(UsbManager.ACTION_USB_DEVICE_DETACHED); addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
        }
        if (Build.VERSION.SDK_INT >= 33) ctx.registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED)
        else ctx.registerReceiver(receiver, f)
        refresh()
    }

    fun stop() { try { ctx.unregisterReceiver(receiver) } catch (_: Exception) {} }

    private fun msInterface(d: UsbDevice) = (0 until d.interfaceCount).map { d.getInterface(it) }.firstOrNull {
        it.interfaceClass == UsbConstants.USB_CLASS_MASS_STORAGE && it.interfaceSubclass == 6 && it.interfaceProtocol == 0x50
    }

    private fun path(d: UsbDevice) = "usb:" + d.deviceName

    fun refresh() {
        for (d in mgr.deviceList.values) {
            if (msInterface(d) == null || conns.containsKey(path(d))) continue
            if (mgr.hasPermission(d)) openAsync(d)
            else mgr.requestPermission(d, PendingIntent.getBroadcast(
                ctx, 0, Intent(action).setPackage(ctx.packageName),
                PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
        }
    }

    private fun openAsync(d: UsbDevice) = bg.execute { synchronized(this) { open(d) }; main.post(onChange) }

    private fun open(d: UsbDevice) {
        val p = path(d)
        if (conns.containsKey(p)) return
        val itf = msInterface(d) ?: return
        var epIn = -1; var epOut = -1
        for (e in 0 until itf.endpointCount) {
            val ep = itf.getEndpoint(e)
            if (ep.type != UsbConstants.USB_ENDPOINT_XFER_BULK) continue
            if (ep.direction == UsbConstants.USB_DIR_IN) epIn = ep.address else epOut = ep.address
        }
        if (epIn < 0 || epOut < 0) { lastError = "No bulk endpoints"; return }
        val conn = mgr.openDevice(d) ?: run { lastError = "Could not open USB device"; return }
        // force=true detaches the kernel's usb-storage driver (which Android binds to card readers
        // for its own mounting) so that we own the interface. The native side shares this open file.
        if (!conn.claimInterface(itf, true)) { lastError = "Could not claim the USB interface (in use by the system?)"; conn.close(); return }
        val res = cli.probe(p, conn.fileDescriptor, itf.id, epIn, epOut)
        if (!res.optBoolean("ok")) { lastError = res.optString("error", "device not ready"); conn.close(); return }
        conns[p] = conn
        val label = listOf(res.optString("vendor"), res.optString("product")).filter { it.isNotBlank() }
            .joinToString(" ").ifBlank { d.productName ?: "USB storage" }
        drives = drives + (p to UsbDrive(p, label, res.optLong("size"), res.optBoolean("writeProtected"), conn, itf.id, epIn, epOut))
        lastError = null
    }

    private fun remove(d: UsbDevice) {
        val p = path(d)
        conns.remove(p)?.close()
        drives = drives - p
    }

    /** Re-probe after a card was swapped in a reader that stays plugged in. */
    fun reprobe(p: String) {
        val d = mgr.deviceList.values.firstOrNull { path(it) == p } ?: return
        bg.execute { synchronized(this) { remove(d); open(d) }; main.post(onChange) }
    }
}
