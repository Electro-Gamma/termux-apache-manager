// SPDX-License-Identifier: Apache-2.0
package dev.rpiimager.android

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

/** Minimal programmatic UI toolkit (the Qt activity base class is not AppCompat). */
object Pal {
    const val raspberry = 0xFFC51A4A.toInt()
    const val bg = 0xFFF4F5F7.toInt()
    const val card = 0xFFFFFFFF.toInt()
    const val ink = 0xFF1F2933.toInt()
    const val muted = 0xFF6B7785.toInt()
    const val line = 0xFFDDE1E6.toInt()
    const val warn = 0xFFB45309.toInt()
}

fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()

fun Context.rounded(color: Int, radiusDp: Int = 10, stroke: Int? = null) = GradientDrawable().apply {
    setColor(color); cornerRadius = dp(radiusDp).toFloat(); if (stroke != null) setStroke(dp(1), stroke)
}

fun Context.label(text: String, size: Float = 15f, color: Int = Pal.ink, bold: Boolean = false) = TextView(this).apply {
    this.text = text; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD)
}

fun Context.heading(text: String) = label(text, 22f, Pal.ink, true).apply { setPadding(0, dp(4), 0, dp(4)) }

fun Context.primaryButton(text: String, onClick: () -> Unit) = Button(this).apply {
    this.text = text; isAllCaps = false; setTextColor(Color.WHITE); textSize = 16f
    background = rounded(Pal.raspberry); setPadding(dp(16), dp(12), dp(16), dp(12))
    setOnClickListener { onClick() }
}

fun Context.secondaryButton(text: String, onClick: () -> Unit) = Button(this).apply {
    this.text = text; isAllCaps = false; setTextColor(Pal.ink); textSize = 16f
    background = rounded(Pal.card, 10, Pal.line); setPadding(dp(16), dp(12), dp(16), dp(12))
    setOnClickListener { onClick() }
}

fun Context.row(title: String, subtitle: String?, onClick: (() -> Unit)?) = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    background = rounded(Pal.card, 10, Pal.line)
    setPadding(dp(14), dp(12), dp(14), dp(12))
    addView(label(title, 16f, Pal.ink, true))
    if (!subtitle.isNullOrBlank()) addView(label(subtitle, 13f, Pal.muted))
    if (onClick != null) setOnClickListener { onClick() }
    layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }
}

fun Context.field(hint: String, value: String = "", password: Boolean = false) = EditText(this).apply {
    this.hint = hint; setText(value); setSingleLine(true)
    inputType = if (password) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
    else InputType.TYPE_CLASS_TEXT
    background = rounded(Pal.card, 8, Pal.line); setPadding(dp(12), dp(10), dp(12), dp(10))
    layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }
}

fun Context.spinner(items: List<String>, selected: String?) = Spinner(this).apply {
    adapter = ArrayAdapter(context, android.R.layout.simple_spinner_dropdown_item, items)
    val i = items.indexOf(selected); if (i >= 0) setSelection(i)
    layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }
}

fun Context.check(text: String, on: Boolean) = CheckBox(this).apply { this.text = text; isChecked = on; setTextColor(Pal.ink) }

fun Context.section(title: String, vararg views: View) = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    background = rounded(Pal.card, 12, Pal.line); setPadding(dp(14), dp(12), dp(14), dp(8))
    layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) }
    addView(label(title, 16f, Pal.raspberry, true).apply { setPadding(0, 0, 0, dp(8)) })
    views.forEach { addView(it) }
}

fun fmtSize(b: Long): String = when {
    b >= 1L shl 30 -> String.format("%.1f GB", b / 1073741824.0)
    b >= 1L shl 20 -> String.format("%.0f MB", b / 1048576.0)
    b > 0 -> "$b B"
    else -> ""
}
