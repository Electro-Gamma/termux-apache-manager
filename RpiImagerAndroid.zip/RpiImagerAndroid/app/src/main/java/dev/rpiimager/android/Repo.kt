// SPDX-License-Identifier: Apache-2.0
package dev.rpiimager.android

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * OS repository access in Kotlin (the original CLI takes a ready image URL and has no list command).
 * The JSON format and the hardware-tag filtering mirror ImageWriter::getFilteredOSlist() /
 * filterOsListWithHWTags() in the original source.
 */
object Repo {
    const val OS_LIST_URL = "https://downloads.raspberrypi.com/os_list_imagingutility_v4.json"
    private const val MAX_DEPTH = 5

    fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 30000
        c.setRequestProperty("User-Agent", "rpi-imager-android/2.0.12")
        c.setRequestProperty("Accept", "application/json")
        try {
            if (c.responseCode !in 200..299) throw IllegalStateException("HTTP ${c.responseCode} for $url")
            return c.inputStream.bufferedReader().readText()
        } finally { c.disconnect() }
    }

    /** Returns the whole top-level document: {"imager": {...}, "os_list": [...]}. */
    fun fetchTop(url: String = OS_LIST_URL): JSONObject = JSONObject(get(url))

    /** Resolves a category that only carries a subitems_url. */
    fun fetchSubitems(url: String): List<OsItem> {
        val txt = get(url).trim()
        val arr = if (txt.startsWith("[")) JSONArray(txt) else JSONObject(txt).optJSONArray("os_list") ?: JSONArray()
        return List(arr.length()) { OsItem.parse(arr.getJSONObject(it)) }
    }

    fun filter(items: List<OsItem>, tags: List<String>, inclusive: Boolean, depth: Int = 1): List<OsItem> {
        if (tags.isEmpty()) return items
        if (depth > MAX_DEPTH) return emptyList()
        val out = ArrayList<OsItem>()
        for (it in items) {
            if (it.subitems.isNotEmpty()) {
                val f = filter(it.subitems, tags, inclusive, depth + 1)
                if (f.isNotEmpty()) out += it.copy(subitems = f)
            } else if (it.subitemsUrl != null) {
                out += it                                   // resolved (and filtered) when opened
            } else if (it.raw.has("devices")) {
                val d = it.raw.optJSONArray("devices")!!
                if ((0 until d.length()).any { i -> d.getString(i) in tags }) out += it
            } else if (inclusive) out += it
        }
        return out
    }
}
