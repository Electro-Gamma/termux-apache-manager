// SPDX-License-Identifier: Apache-2.0
package dev.rpiimager.android

import org.json.JSONArray
import org.json.JSONObject

/** Thin JNI wrapper around the original Raspberry Pi Imager core (ImageWriter). */
object NativeEngine {
    /** Public onEvent(String,String) is looked up by name from C++. */
    class Callbacks(private val f: (String, String) -> Unit) {
        fun onEvent(name: String, json: String) = f(name, json)
    }

    private var keep: Callbacks? = null

    external fun nativeSetCallbacks(cb: Any?)
    external fun nativeIsReady(): Boolean
    external fun nativeConfigure(caBundlePath: String)
    external fun nativeVersion(): String
    external fun nativeUsbRegister(path: String, fd: Int, iface: Int, epIn: Int, epOut: Int): String
    external fun nativeUsbUnregister(path: String)
    external fun nativeFetchOsList()
    external fun nativeOsListJson(): String
    external fun nativeSetHwFilter(tagsJson: String, inclusive: Boolean)
    external fun nativeSetSource(
        url: String, downloadLen: Long, extractLen: Long, sha256: String, multiFile: Boolean,
        parentCategory: String, osName: String, initFormat: String, releaseDate: String, bmapUrl: String
    )
    external fun nativeSetDestination(device: String, size: Long)
    external fun nativeApplyCustomisation(json: String)
    external fun nativeHashPassword(plain: String): String
    external fun nativeSetVerify(v: Boolean)
    external fun nativeSetEject(v: Boolean)
    external fun nativeStartWrite()
    external fun nativeCancelWrite()
    external fun nativeStringList(kind: String): String
    external fun nativeLocaleForCapital(city: String): String

    fun setListener(f: (String, JSONObject) -> Unit) {
        val cb = Callbacks { n, j ->
            val o = try { JSONObject(j) } catch (_: Exception) { JSONObject() }
            f(n, o)
        }
        keep = cb
        nativeSetCallbacks(cb)
    }

    fun stringList(kind: String): List<String> {
        val a = try { JSONArray(nativeStringList(kind)) } catch (_: Exception) { JSONArray() }
        return List(a.length()) { a.getString(it) }
    }
}

data class OsItem(
    val name: String, val description: String, val url: String,
    val extractSize: Long, val downloadSize: Long, val sha256: String, val initFormat: String,
    val releaseDate: String, val bmapUrl: String, val subitems: List<OsItem>, val raw: JSONObject,
    val hasPendingSubitems: Boolean
) {
    val isCategory get() = subitems.isNotEmpty() || hasPendingSubitems
    val isCustom get() = url == "internal://custom"
    val isErase get() = url == "internal://format"

    companion object {
        fun parse(o: JSONObject): OsItem {
            val subs = o.optJSONArray("subitems")
            val list = if (subs == null) emptyList() else List(subs.length()) { parse(subs.getJSONObject(it)) }
            return OsItem(
                o.optString("name"), o.optString("description"), o.optString("url"),
                o.optLong("extract_size"), o.optLong("image_download_size"),
                o.optString("extract_sha256"), o.optString("init_format"),
                o.optString("release_date"), o.optString("bmap_url"), list, o,
                o.has("subitems_url") && list.isEmpty()
            )
        }
    }
}

data class HwDevice(val name: String, val description: String, val tags: JSONArray, val inclusive: Boolean) {
    companion object {
        fun parseAll(imager: JSONObject): List<HwDevice> {
            val a = imager.optJSONArray("devices") ?: return emptyList()
            return List(a.length()) {
                val d = a.getJSONObject(it)
                HwDevice(d.optString("name"), d.optString("description"),
                    d.optJSONArray("tags") ?: JSONArray(), d.optString("matching_type") == "inclusive")
            }
        }
    }
}
