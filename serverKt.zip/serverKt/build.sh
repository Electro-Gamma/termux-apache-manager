#!/usr/bin/env bash
# Build serve.jar from Serve.kt (needs a JDK 8+ and kotlinc on PATH)
set -e
kotlinc Serve.kt -include-runtime -d serve.jar
echo "Built serve.jar  ->  run:  java -jar serve.jar assets/ncviewer-offline 8000"
