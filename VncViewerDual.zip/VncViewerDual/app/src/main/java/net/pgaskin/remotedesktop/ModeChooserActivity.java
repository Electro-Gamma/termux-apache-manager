// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later

package net.pgaskin.remotedesktop;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;

/**
 * The launcher screen: one app, two modes.
 *
 * <ul>
 *   <li>VncViewer: the built-in Kotlin/Compose VNC client in {@code :vncviewer}.
 *   <li>RealVNC: the Vento interface on RealVNC's viewer engine
 *       ({@link HomeActivity}).
 * </ul>
 *
 * With "Remember my choice" ticked this screen starts the chosen mode and
 * finishes without showing anything. Both modes have a Mode button that comes
 * back here with {@link #EXTRA_FORCE_CHOOSER}, which always shows the picker.
 */
public final class ModeChooserActivity extends AppCompatActivity {

    /** Also spelled out in :vncviewer's ModeSwitch.kt, which cannot see this class. */
    public static final String EXTRA_FORCE_CHOOSER =
            "net.pgaskin.remotedesktop.extra.FORCE_CHOOSER";

    private static final String VNCVIEWER_ACTIVITY = "com.vncviewer.app.MainActivity";

    private static final String PREFS = "launcher_mode";
    private static final String KEY_MODE = "mode";
    private static final String MODE_VNCVIEWER = "vncviewer";
    private static final String MODE_REALVNC = "realvnc";

    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);

        final String remembered = prefs.getString(KEY_MODE, null);
        final boolean forced = getIntent().getBooleanExtra(EXTRA_FORCE_CHOOSER, false);
        if (!forced && savedInstanceState == null && remembered != null && launch(remembered)) {
            return;
        }

        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        setContentView(R.layout.activity_mode_chooser);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.root), (v, insets) -> {
            final Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        final CheckBox remember = findViewById(R.id.remember);
        remember.setChecked(remembered != null);
        findViewById(R.id.mode_vncviewer).setOnClickListener(v -> choose(MODE_VNCVIEWER, remember));
        findViewById(R.id.mode_realvnc).setOnClickListener(v -> choose(MODE_REALVNC, remember));
    }

    private void choose(String mode, CheckBox remember) {
        final SharedPreferences.Editor edit = prefs.edit();
        if (remember.isChecked()) {
            edit.putString(KEY_MODE, mode);
        } else {
            edit.remove(KEY_MODE);
        }
        edit.apply();
        launch(mode);
    }

    /** Starts the mode and finishes this screen. False if the mode is unknown. */
    private boolean launch(String mode) {
        final Intent intent;
        if (MODE_VNCVIEWER.equals(mode)) {
            // By name: the class is in a library this module only depends on at
            // run time, and the package is the installed one (the debug
            // variant's applicationId has a suffix).
            intent = new Intent().setClassName(getPackageName(), VNCVIEWER_ACTIVITY);
        } else if (MODE_REALVNC.equals(mode)) {
            intent = new Intent(this, HomeActivity.class);
        } else {
            prefs.edit().remove(KEY_MODE).apply();
            return false;
        }
        startActivity(intent);
        finish();
        return true;
    }
}
