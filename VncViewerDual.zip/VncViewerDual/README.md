# VncViewer (two modes)

One app, two ways to connect. The launcher screen asks which one (and can remember the answer):

| Mode | What it is | Code |
|---|---|---|
| **VncViewer** | The original built-in Kotlin/Compose VNC client (RFB, No-auth / VNC password, quick connect, tabs) | `vncviewer/` (library, package `com.vncviewer.app`) |
| **RealVNC** | Vento's touch UI on RealVNC's viewer engine | `app/`, `control/`, `backends/`, `realvnc/` |

Both modes have a way back to the picker: the **Mode** button on the VncViewer list, and **Switch mode** in the RealVNC home screen's overflow menu.

- Saved connections are separate per mode (each keeps its own store).
- Requires Android 14+ (minSdk 34) and an arm64 phone.
- applicationId is `com.vncviewer.app` (debug: `com.vncviewer.app.debug`).
- RealVNC's `libvncviewer.so` + `libc++_shared.so` (viewer 4.9.3.60175, arm64-v8a) are NOT included. Put them in `app/src/main/jniLibs/arm64-v8a/` (the Colab notebook does this and checks SHA-256). Without them RealVNC mode cannot connect; VncViewer mode does not need them.
- Build: JDK 21, SDK platforms;android-36, build-tools;36.0.0, ndk;28.2.13676358, cmake;3.30.5, then `./gradlew :app:assembleRelease`
  (set RVNC_KEYSTORE_PATH / RVNC_KEYSTORE_PASSWORD / RVNC_KEY_ALIAS / RVNC_KEY_PASSWORD to sign).

Licences: Vento is GPL-3.0-or-later (see LICENSE). RealVNC's binaries are proprietary; don't redistribute the APK with them inside.
