# Vento VNC

Vento's interface (connection list, touch/mouse/keyboard input, settings, session screen) over **two interchangeable VNC engines**. The engine is chosen per connection in the connection editor ("Backend"), and each has its own page under Settings. Switching engine changes only the backend; every screen is the same.

| Backend | id | What it is |
|---|---|---|
| VNC (built-in) | `vncviewer` | VncViewer's own RFB client (Kotlin): RFB 3.3/3.7/3.8, None and VNC password, ZRLE/Hextile/CopyRect/RRE/Raw/DesktopSize. No native code, nothing proprietary, no encryption. `backends/vncviewer` |
| VNC (RealVNC) | `realvnc` | RealVNC's viewer core: encryption, UDP, ZRLE2, RealVNC authentication. `backends/realvnc` + `realvnc/` (JNI declarations) |

New connections default to the built-in backend (it is first in the picker; `order()` in each provider decides). Existing RealVNC connections keep working unchanged.

## How the two fit

`backends/` is the seam (`Backend`, `BackendProvider`, `Prompt`...). A protocol is a module that implements `BackendProvider` and declares it in `META-INF/services`, so what a build can connect with is what is on its classpath. `backends/vncviewer` adds the second one:

- `com.vncviewer.app.vnc.VncClient` is the original VncViewer protocol engine. Additive changes only: a damage-rectangle callback, a lock so the UI thread can read the framebuffer, a `shared` flag, and the negotiated protocol/security exposed for the connection-info sheet.
- `VncViewerBackend` (Java) adapts it to `Backend`: threads, state, the password and unencrypted-link prompts, input mapping (key ids to keysyms, button-change vs motion ordering), `readRegion`/`thumbnail`.
- VncViewer's old Compose UI, view model and key mapper are gone: Vento's UI and input stack do that job for both engines. That is also most of the size saving: no Compose.

## Build

Requires Android 14+ (minSdk 34) and an arm64 phone. JDK 21, SDK platforms;android-36, build-tools;36.0.0, ndk;28.2.13676358, cmake;3.30.5, then `./gradlew :app:assembleRelease`
(set RVNC_KEYSTORE_PATH / RVNC_KEYSTORE_PASSWORD / RVNC_KEY_ALIAS / RVNC_KEY_PASSWORD to sign). Unit tests for the new backend: `./gradlew :backends:vncviewer:testDebugUnitTest`.

RealVNC's `libvncviewer.so` + `libc++_shared.so` (viewer 4.9.3.60175, arm64-v8a) are not included: put them in `app/src/main/jniLibs/arm64-v8a/` (the Colab notebook does this and checks SHA-256). Without them only the built-in backend can connect.

Licences: Vento is GPL-3.0-or-later (LICENSE). RealVNC's binaries are proprietary: don't redistribute an APK with them inside.
