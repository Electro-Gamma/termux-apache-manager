package com.vncviewer.app.ui

import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.foundation.layout.fillMaxSize
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.vncviewer.app.session.Phase

@Composable
fun VncViewerApp(vm: VncViewModel) {
    val view = LocalView.current
    val context = LocalContext.current

    val inSession = vm.screen == Screen.SESSION
    val immersive = inSession && vm.fullscreen
    val keepAwake = inSession && vm.activeSession?.phase == Phase.CONNECTED

    BackHandler(enabled = inSession) {
        if (vm.fullscreen) {
            vm.fullscreen = false
        } else {
            vm.screen = Screen.LIST
        }
    }

    LaunchedEffect(immersive) {
        val window = (context as? Activity)?.window ?: return@LaunchedEffect
        val controller = WindowCompat.getInsetsController(window, view)
        if (immersive) {
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            controller.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    SideEffect {
        view.keepScreenOn = keepAwake
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        if (inSession) {
            SessionScreen(vm)
        } else {
            ConnectionsScreen(vm)
        }
    }
}
