package com.vncviewer.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.PointerInputScope
import androidx.compose.ui.input.pointer.PointerType
import androidx.compose.ui.input.pointer.isPrimaryPressed
import androidx.compose.ui.input.pointer.isSecondaryPressed
import androidx.compose.ui.input.pointer.isTertiaryPressed
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.dp
import com.vncviewer.app.session.MouseMode
import com.vncviewer.app.session.VncSession
import kotlin.math.abs
import kotlin.math.ln

private const val OUT_LONG = 0
private const val OUT_MOVED = 1
private const val OUT_RELEASED = 2
private const val OUT_MULTI = 3

/**
 * Draws the remote framebuffer and turns touches / a physical mouse into VNC pointer events.
 *
 * Touch mode     : tap = left click, long-press = right click, drag = left-button drag,
 *                  two-finger drag = scroll wheel, pinch = zoom, two-finger tap = right click.
 * Trackpad mode  : drag = move cursor, tap = left click, long-press + drag = hold left button,
 *                  two-finger tap = right click, two-finger drag = scroll, pinch = zoom.
 * "Pan" toggle   : one-finger drag moves the zoomed view instead of the mouse.
 */
@Composable
fun RemoteCanvas(session: VncSession, modifier: Modifier = Modifier) {
    val haptics = LocalHapticFeedback.current
    val paint = remember { android.graphics.Paint() }
    val srcRect = remember { android.graphics.Rect() }
    val dstRect = remember { android.graphics.RectF() }

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
            .onSizeChanged { size -> session.onViewSize(size.width, size.height) }
            .pointerInput(session) {
                touchGestures(session) {
                    haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                }
            }
            .pointerInput(session) {
                mouseGestures(session)
            }
    ) {
        // Reading the tick subscribes this draw block to new frames.
        val tick = session.frameTick
        val bmp = session.bitmap
        if (bmp != null && session.fbWidth > 0 && tick >= 0) {
            val sx = session.scaleX()
            val sy = session.scaleY()
            val left = session.contentLeft()
            val top = session.contentTop()
            drawIntoCanvas { canvas ->
                srcRect.set(0, 0, bmp.width, bmp.height)
                dstRect.set(left, top, left + bmp.width * sx, top + bmp.height * sy)
                paint.isFilterBitmap = sx < 3f
                canvas.nativeCanvas.drawBitmap(bmp, srcRect, dstRect, paint)
            }

            val d = 1.dp.toPx()
            val cx = session.pointerScreenX()
            val cy = session.pointerScreenY()
            if (session.mouseMode == MouseMode.TRACKPAD && !session.viewOnly) {
                val path = Path()
                path.moveTo(0f, 0f)
                path.lineTo(0f, 17f * d)
                path.lineTo(4.2f * d, 13.4f * d)
                path.lineTo(7.4f * d, 20.5f * d)
                path.lineTo(10.2f * d, 19.2f * d)
                path.lineTo(7f * d, 12.4f * d)
                path.lineTo(12f * d, 12.4f * d)
                path.close()
                val fill = if ((session.buttonMask and 1) != 0) Color(0xFF7CC4FF) else Color.White
                translate(left = cx, top = cy) {
                    drawPath(path, Color.Black, style = Stroke(width = 2.4f * d))
                    drawPath(path, fill)
                }
            } else if (session.buttonMask != 0 && !session.viewOnly) {
                drawCircle(color = Color(0x887CC4FF), radius = 18f * d, center = Offset(cx, cy))
            }
        }
    }
}

private fun countPressed(changes: List<androidx.compose.ui.input.pointer.PointerInputChange>): Int {
    var n = 0
    for (c in changes) if (c.pressed) n++
    return n
}

private suspend fun PointerInputScope.touchGestures(session: VncSession, haptic: () -> Unit) {
    val slop = viewConfiguration.touchSlop
    val longPressMs = viewConfiguration.longPressTimeoutMillis
    val wheelStepPx = 34.dp.toPx()

    awaitEachGesture {
        val down = awaitFirstDown(requireUnconsumed = false)
        // A physical mouse is handled by mouseGestures().
        if (down.type == PointerType.Mouse) return@awaitEachGesture

        val startPos = down.position
        val primaryId = down.id
        val trackpad = session.mouseMode == MouseMode.TRACKPAD
        val panOnly = session.viewOnly || session.panDragMode

        // ---- phase 1: long-press, movement, release or a second finger? -------------------
        val waited: Int? = withTimeoutOrNull(longPressMs) {
            var res = OUT_LONG
            while (true) {
                val ev = awaitPointerEvent()
                if (countPressed(ev.changes) >= 2) {
                    res = OUT_MULTI
                    break
                }
                val c = ev.changes.firstOrNull { it.id == primaryId }
                if (c == null || !c.pressed) {
                    res = OUT_RELEASED
                    break
                }
                if ((c.position - startPos).getDistance() > slop) {
                    res = OUT_MOVED
                    break
                }
            }
            res
        }
        val outcome = waited ?: OUT_LONG
        var goMulti = outcome == OUT_MULTI

        if (outcome == OUT_RELEASED) {
            if (!panOnly) {
                if (!trackpad) session.pointerToScreen(startPos.x, startPos.y)
                session.click(1)
            }
            return@awaitEachGesture
        }

        if (outcome == OUT_LONG) {
            if (panOnly) {
                while (true) {
                    val ev = awaitPointerEvent()
                    if (countPressed(ev.changes) == 0) break
                }
                return@awaitEachGesture
            }
            haptic()
            if (trackpad) {
                // Press-and-hold = left button held; moving the finger drags.
                session.buttonDown(1)
                var last = startPos
                try {
                    while (true) {
                        val ev = awaitPointerEvent()
                        val c = ev.changes.firstOrNull { it.id == primaryId }
                        if (c == null || !c.pressed) break
                        session.movePointerBy(c.position.x - last.x, c.position.y - last.y)
                        last = c.position
                        c.consume()
                    }
                } finally {
                    session.buttonUp(1)
                }
            } else {
                session.pointerToScreen(startPos.x, startPos.y)
                session.click(4)
                while (true) {
                    val ev = awaitPointerEvent()
                    if (countPressed(ev.changes) == 0) break
                    ev.changes.forEach { it.consume() }
                }
            }
            return@awaitEachGesture
        }

        // ---- phase 2: one-finger drag ---------------------------------------------------------
        if (outcome == OUT_MOVED) {
            var last = startPos
            var dragging = false
            try {
                if (!panOnly && !trackpad) {
                    session.pointerToScreen(startPos.x, startPos.y)
                    session.buttonDown(1)
                    dragging = true
                }
                while (true) {
                    val ev = awaitPointerEvent()
                    val pressed = countPressed(ev.changes)
                    if (pressed == 0) break
                    if (pressed >= 2) {
                        goMulti = true
                        break
                    }
                    val c = ev.changes.firstOrNull { it.id == primaryId } ?: break
                    if (!c.pressed) break
                    val dx = c.position.x - last.x
                    val dy = c.position.y - last.y
                    last = c.position
                    if (panOnly) {
                        session.panBy(dx, dy)
                    } else if (trackpad) {
                        session.movePointerBy(dx, dy)
                    } else {
                        session.pointerToScreen(c.position.x, c.position.y)
                    }
                    c.consume()
                }
            } finally {
                if (dragging) session.buttonUp(1)
            }
            if (!goMulti) return@awaitEachGesture
        }

        // ---- phase 3: two or more fingers (zoom / scroll / right-click tap) ---------------------
        val multiStart = System.currentTimeMillis()
        var totalZoom = 1f
        var totalPan = Offset.Zero
        var mode = 0 // 0 undecided, 1 zoom, 2 scroll (or pan)
        var wheelAcc = 0f
        var firstCentroid: Offset? = null
        while (true) {
            val ev = awaitPointerEvent()
            val pressed = countPressed(ev.changes)
            if (pressed == 0) break
            if (pressed >= 2) {
                val centroid = ev.calculateCentroid(useCurrent = true)
                if (firstCentroid == null) firstCentroid = centroid
                val z = ev.calculateZoom()
                val p = ev.calculatePan()
                totalZoom *= z
                totalPan += p
                if (mode == 0) {
                    if (abs(ln(totalZoom)) > 0.07f) {
                        mode = 1
                    } else if (totalPan.getDistance() > slop * 1.5f) {
                        mode = 2
                        if (!panOnly && !trackpad) session.pointerToScreen(centroid.x, centroid.y)
                    }
                }
                if (mode == 1) {
                    session.zoomBy(z, centroid.x, centroid.y, p.x, p.y)
                } else if (mode == 2) {
                    if (panOnly) {
                        session.panBy(p.x, p.y)
                    } else {
                        wheelAcc += p.y
                        while (wheelAcc <= -wheelStepPx) {
                            session.wheel(true)
                            wheelAcc += wheelStepPx
                        }
                        while (wheelAcc >= wheelStepPx) {
                            session.wheel(false)
                            wheelAcc -= wheelStepPx
                        }
                    }
                }
                ev.changes.forEach { if (it.positionChanged()) it.consume() }
            }
        }
        if (mode == 0 && !panOnly) {
            val elapsed = System.currentTimeMillis() - multiStart
            if (elapsed < 450 && totalPan.getDistance() < slop * 2f) {
                val c = firstCentroid
                if (!trackpad && c != null) session.pointerToScreen(c.x, c.y)
                session.click(4)
            }
        }
    }
}

/** Physical mouse (USB / Bluetooth / DeX): absolute pointer, three buttons and the wheel. */
private suspend fun PointerInputScope.mouseGestures(session: VncSession) {
    awaitPointerEventScope {
        while (true) {
            val ev = awaitPointerEvent()
            val ch = ev.changes.firstOrNull { it.type == PointerType.Mouse } ?: continue
            if (ev.type == PointerEventType.Scroll) {
                val dy = ch.scrollDelta.y
                if (dy > 0.01f) session.wheel(true) else if (dy < -0.01f) session.wheel(false)
                ch.consume()
                continue
            }
            val b = ev.buttons
            var mask = 0
            if (b.isPrimaryPressed) mask = mask or 1
            if (b.isTertiaryPressed) mask = mask or 2
            if (b.isSecondaryPressed) mask = mask or 4
            session.mouseEvent(ch.position.x, ch.position.y, mask)
        }
    }
}
