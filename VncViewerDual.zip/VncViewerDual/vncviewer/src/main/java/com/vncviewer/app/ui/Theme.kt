package com.vncviewer.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = Color(0xFF7CC4FF),
    onPrimary = Color(0xFF00263D),
    primaryContainer = Color(0xFF0F3A57),
    onPrimaryContainer = Color(0xFFCFE8FF),
    secondary = Color(0xFF6FD6A0),
    onSecondary = Color(0xFF00281A),
    background = Color(0xFF0E1116),
    onBackground = Color(0xFFE6EDF3),
    surface = Color(0xFF161B22),
    onSurface = Color(0xFFE6EDF3),
    surfaceVariant = Color(0xFF212833),
    onSurfaceVariant = Color(0xFF9DA7B3),
    outline = Color(0xFF3A4452),
    error = Color(0xFFFF7B72),
    onError = Color(0xFF3B0B08)
)

@Composable
fun VncViewerTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkColors, content = content)
}
