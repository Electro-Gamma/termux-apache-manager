package com.vncviewer.app.data

/** A saved VNC connection. [password] is empty when the user chose not to save it. */
data class VncProfile(
    val id: String,
    val name: String,
    val host: String,
    val port: Int = 5900,
    val password: String = "",
    val viewOnly: Boolean = false,
    val favorite: Boolean = false,
    val lastUsed: Long = 0L
) {
    val address: String
        get() = if (host.contains(':')) "[$host]:$port" else "$host:$port"
}
