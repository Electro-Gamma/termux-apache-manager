package com.vncviewer.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Persists saved connections as JSON in private SharedPreferences (passwords encrypted). */
class ProfileStore(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences("vncviewer_profiles", Context.MODE_PRIVATE)

    fun load(): List<VncProfile> {
        val raw = prefs.getString(KEY_LIST, null) ?: return emptyList()
        return try {
            val array = JSONArray(raw)
            val result = ArrayList<VncProfile>()
            for (i in 0 until array.length()) {
                val o = array.getJSONObject(i)
                result.add(
                    VncProfile(
                        id = o.getString("id"),
                        name = o.optString("name", ""),
                        host = o.optString("host", ""),
                        port = o.optInt("port", 5900),
                        password = SecretBox.decrypt(o.optString("pw", "")),
                        viewOnly = o.optBoolean("viewOnly", false),
                        favorite = o.optBoolean("fav", false),
                        lastUsed = o.optLong("last", 0L)
                    )
                )
            }
            result
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun save(profiles: List<VncProfile>) {
        val array = JSONArray()
        for (p in profiles) {
            val o = JSONObject()
            o.put("id", p.id)
            o.put("name", p.name)
            o.put("host", p.host)
            o.put("port", p.port)
            o.put("pw", SecretBox.encrypt(p.password))
            o.put("viewOnly", p.viewOnly)
            o.put("fav", p.favorite)
            o.put("last", p.lastUsed)
            array.put(o)
        }
        prefs.edit().putString(KEY_LIST, array.toString()).apply()
    }

    private companion object {
        const val KEY_LIST = "list"
    }
}
