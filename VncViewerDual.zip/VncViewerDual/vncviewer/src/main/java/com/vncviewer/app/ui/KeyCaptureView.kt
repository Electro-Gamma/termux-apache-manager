package com.vncviewer.app.ui

import android.content.Context
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.BaseInputConnection
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection

/**
 * An invisible 1dp view whose only job is to be the target of the Android soft keyboard.
 * Typed characters arrive through [textSink]; special keys (Backspace, Enter, ...) through [keySink].
 */
class KeyCaptureView(context: Context) : View(context) {
    var textSink: ((String) -> Unit)? = null
    var keySink: ((KeyEvent) -> Boolean)? = null

    init {
        isFocusable = true
        isFocusableInTouchMode = true
    }

    override fun onCheckIsTextEditor(): Boolean = true

    override fun onCreateInputConnection(outAttrs: EditorInfo): InputConnection {
        outAttrs.inputType = InputType.TYPE_CLASS_TEXT or
            InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD or
            InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        outAttrs.imeOptions = EditorInfo.IME_FLAG_NO_FULLSCREEN or
            EditorInfo.IME_FLAG_NO_EXTRACT_UI or
            EditorInfo.IME_ACTION_NONE
        return CaptureConnection(this)
    }

    private fun sendBackspace(count: Int) {
        for (i in 0 until count) {
            keySink?.invoke(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DEL))
            keySink?.invoke(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_DEL))
        }
    }

    private class CaptureConnection(private val owner: KeyCaptureView) : BaseInputConnection(owner, false) {
        private var composing: String = ""

        /** Make the remote text match [newText] as the IME edits its composing region. */
        private fun applyComposing(newText: String) {
            var common = 0
            val max = minOf(composing.length, newText.length)
            while (common < max && composing[common] == newText[common]) common++
            owner.sendBackspace(composing.length - common)
            if (newText.length > common) {
                owner.textSink?.invoke(newText.substring(common))
            }
            composing = newText
        }

        override fun setComposingText(text: CharSequence?, newCursorPosition: Int): Boolean {
            applyComposing(text?.toString() ?: "")
            return true
        }

        override fun commitText(text: CharSequence?, newCursorPosition: Int): Boolean {
            applyComposing(text?.toString() ?: "")
            composing = ""
            return true
        }

        override fun finishComposingText(): Boolean {
            composing = ""
            return true
        }

        override fun deleteSurroundingText(beforeLength: Int, afterLength: Int): Boolean {
            if (composing.isNotEmpty()) {
                val drop = if (beforeLength > composing.length) composing.length else beforeLength
                composing = composing.substring(0, composing.length - drop)
            }
            owner.sendBackspace(if (beforeLength < 1) 1 else beforeLength)
            return true
        }

        override fun sendKeyEvent(event: KeyEvent?): Boolean {
            if (event != null) owner.keySink?.invoke(event)
            return true
        }
    }
}
