package com.vncviewer.app.ui

import android.app.Activity
import android.content.Context
import android.content.Intent

/** Must match the app module's ModeChooserActivity. */
private const val CHOOSER_CLASS = "net.pgaskin.remotedesktop.ModeChooserActivity"
private const val EXTRA_FORCE_CHOOSER = "net.pgaskin.remotedesktop.extra.FORCE_CHOOSER"

/** Back to the mode picker (the app's launcher screen), closing this mode. */
fun switchMode(context: Context) {
    val intent = Intent()
        .setClassName(context.packageName, CHOOSER_CLASS)
        .putExtra(EXTRA_FORCE_CHOOSER, true)
    context.startActivity(intent)
    (context as? Activity)?.finish()
}
