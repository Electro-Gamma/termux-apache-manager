package com.vncviewer.app.vnc

import android.view.KeyEvent

/** X11 keysym values used by the RFB KeyEvent message, and Android key code mapping. */
object Keysyms {
    const val BACKSPACE = 0xFF08
    const val TAB = 0xFF09
    const val RETURN = 0xFF0D
    const val ESCAPE = 0xFF1B
    const val HOME = 0xFF50
    const val LEFT = 0xFF51
    const val UP = 0xFF52
    const val RIGHT = 0xFF53
    const val DOWN = 0xFF54
    const val PAGE_UP = 0xFF55
    const val PAGE_DOWN = 0xFF56
    const val END = 0xFF57
    const val INSERT = 0xFF63
    const val DELETE = 0xFFFF
    const val F1 = 0xFFBE
    const val SHIFT_L = 0xFFE1
    const val CONTROL_L = 0xFFE3
    const val ALT_L = 0xFFE9
    const val SUPER_L = 0xFFEB
    const val SPACE = 0x20

    /** Printable character (Unicode code point) -> keysym. */
    fun fromCodePoint(cp: Int): Int {
        return when {
            cp == 0x0A || cp == 0x0D -> RETURN
            cp == 0x09 -> TAB
            cp == 0x08 -> BACKSPACE
            cp == 0x7F -> DELETE
            cp == 0x1B -> ESCAPE
            cp in 0x20..0x7E -> cp
            cp in 0xA0..0xFF -> cp
            cp < 0x20 -> 0
            else -> 0x01000000 or cp
        }
    }

    /** Function key N (1..12) -> keysym. */
    fun functionKey(n: Int): Int = F1 + (n - 1)

    /**
     * Android key code -> keysym for keys that do not produce a character
     * (modifiers, arrows, function keys, numpad...). Returns 0 if the key is not special.
     */
    fun fromAndroidKeyCode(code: Int): Int {
        if (code >= KeyEvent.KEYCODE_F1 && code <= KeyEvent.KEYCODE_F12) {
            return F1 + (code - KeyEvent.KEYCODE_F1)
        }
        if (code >= KeyEvent.KEYCODE_NUMPAD_0 && code <= KeyEvent.KEYCODE_NUMPAD_9) {
            return 0xFFB0 + (code - KeyEvent.KEYCODE_NUMPAD_0)
        }
        return when (code) {
            KeyEvent.KEYCODE_DEL -> BACKSPACE
            KeyEvent.KEYCODE_FORWARD_DEL -> DELETE
            KeyEvent.KEYCODE_ENTER -> RETURN
            KeyEvent.KEYCODE_NUMPAD_ENTER -> 0xFF8D
            KeyEvent.KEYCODE_TAB -> TAB
            KeyEvent.KEYCODE_ESCAPE -> ESCAPE
            KeyEvent.KEYCODE_SPACE -> SPACE
            KeyEvent.KEYCODE_DPAD_LEFT -> LEFT
            KeyEvent.KEYCODE_DPAD_UP -> UP
            KeyEvent.KEYCODE_DPAD_RIGHT -> RIGHT
            KeyEvent.KEYCODE_DPAD_DOWN -> DOWN
            KeyEvent.KEYCODE_MOVE_HOME -> HOME
            KeyEvent.KEYCODE_MOVE_END -> END
            KeyEvent.KEYCODE_PAGE_UP -> PAGE_UP
            KeyEvent.KEYCODE_PAGE_DOWN -> PAGE_DOWN
            KeyEvent.KEYCODE_INSERT -> INSERT
            KeyEvent.KEYCODE_SHIFT_LEFT -> 0xFFE1
            KeyEvent.KEYCODE_SHIFT_RIGHT -> 0xFFE2
            KeyEvent.KEYCODE_CTRL_LEFT -> 0xFFE3
            KeyEvent.KEYCODE_CTRL_RIGHT -> 0xFFE4
            KeyEvent.KEYCODE_CAPS_LOCK -> 0xFFE5
            KeyEvent.KEYCODE_ALT_LEFT -> 0xFFE9
            KeyEvent.KEYCODE_ALT_RIGHT -> 0xFFEA
            KeyEvent.KEYCODE_META_LEFT -> 0xFFEB
            KeyEvent.KEYCODE_META_RIGHT -> 0xFFEC
            KeyEvent.KEYCODE_MENU -> 0xFF67
            KeyEvent.KEYCODE_SYSRQ -> 0xFF61
            KeyEvent.KEYCODE_BREAK -> 0xFF13
            KeyEvent.KEYCODE_SCROLL_LOCK -> 0xFF14
            KeyEvent.KEYCODE_NUM_LOCK -> 0xFF7F
            KeyEvent.KEYCODE_NUMPAD_DOT -> 0xFFAE
            KeyEvent.KEYCODE_NUMPAD_ADD -> 0xFFAB
            KeyEvent.KEYCODE_NUMPAD_SUBTRACT -> 0xFFAD
            KeyEvent.KEYCODE_NUMPAD_MULTIPLY -> 0xFFAA
            KeyEvent.KEYCODE_NUMPAD_DIVIDE -> 0xFFAF
            else -> 0
        }
    }
}
