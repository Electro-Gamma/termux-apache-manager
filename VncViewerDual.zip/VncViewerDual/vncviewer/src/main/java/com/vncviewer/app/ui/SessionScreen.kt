package com.vncviewer.app.ui

import android.content.Context
import android.view.inputmethod.InputMethodManager
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.vncviewer.app.session.MouseMode
import com.vncviewer.app.session.Phase
import com.vncviewer.app.session.VncSession
import com.vncviewer.app.vnc.Keysyms
import kotlinx.coroutines.delay

@Composable
fun SessionScreen(vm: VncViewModel) {
    val session = vm.activeSession
    if (session == null) {
        LaunchedEffect(Unit) { vm.screen = Screen.LIST }
        return
    }
    val fullscreen = vm.fullscreen
    val connected = session.phase == Phase.CONNECTED

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        if (!fullscreen) {
            SessionTabs(vm)
            SessionToolbar(vm, session)
        }
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            key(session.id) {
                RemoteCanvas(session)
                KeyCaptureHost(session)
            }

            when (session.phase) {
                Phase.CONNECTING -> ConnectingOverlay(vm, session)
                Phase.FAILED -> FailedOverlay(vm, session)
                Phase.AUTH_REQUIRED -> PasswordDialog(vm, session)
                Phase.CONNECTED -> {}
            }

            if (fullscreen) {
                FullscreenControls(vm, session, Modifier.align(Alignment.TopEnd))
            }

            val notice = session.notice
            if (notice != null) {
                LaunchedEffect(notice) {
                    delay(2400)
                    if (session.notice == notice) session.notice = null
                }
                Surface(
                    color = Color(0xE6212833),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(16.dp)
                ) {
                    Text(
                        text = notice,
                        color = Color.White,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }
            }
        }
        if (session.showDock && connected) {
            KeyDock(session)
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Chips / small building blocks
// ---------------------------------------------------------------------------------------------

@Composable
fun ToolChip(label: String, selected: Boolean = false, compact: Boolean = false, onClick: () -> Unit) {
    Surface(
        color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
        contentColor = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            maxLines = 1,
            modifier = Modifier.padding(
                horizontal = if (compact) 10.dp else 12.dp,
                vertical = if (compact) 6.dp else 8.dp
            )
        )
    }
}

@Composable
private fun SessionTabs(vm: VncViewModel) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .horizontalScroll(rememberScrollState())
            .padding(6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ToolChip("\u2039 Connections") { vm.screen = Screen.LIST }
        for (s in vm.sessions) {
            val selected = s.id == vm.activeSessionId
            Surface(
                color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.clickable { vm.activeSessionId = s.id }
            ) {
                Row(
                    modifier = Modifier.padding(start = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val dot = when (s.phase) {
                        Phase.CONNECTED -> Color(0xFF6FD6A0)
                        Phase.CONNECTING -> Color(0xFFE3B341)
                        else -> Color(0xFFFF7B72)
                    }
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(dot, RoundedCornerShape(4.dp))
                    )
                    Text(
                        text = s.title,
                        style = MaterialTheme.typography.labelLarge,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(start = 8.dp)
                    )
                    Text(
                        text = "\u00D7",
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier
                            .clickable { vm.closeSession(s.id) }
                            .padding(horizontal = 12.dp, vertical = 4.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun SessionToolbar(vm: VncViewModel, session: VncSession) {
    val view = LocalView.current
    var clickMenu by remember { mutableStateOf(false) }
    var moreMenu by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .horizontalScroll(rememberScrollState())
            .padding(start = 6.dp, end = 6.dp, bottom = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ToolChip("Keyboard") {
            val visible = ViewCompat.getRootWindowInsets(view)
                ?.isVisible(WindowInsetsCompat.Type.ime()) == true
            session.requestIme(!visible)
        }
        ToolChip("Keys", session.showDock) { session.showDock = !session.showDock }
        ToolChip("Mouse: " + session.mouseMode.label) {
            session.mouseMode = if (session.mouseMode == MouseMode.TOUCH) MouseMode.TRACKPAD else MouseMode.TOUCH
        }
        ToolChip("View: " + session.scaleMode.label) { session.cycleScaleMode() }
        ToolChip("Pan", session.panDragMode) { session.panDragMode = !session.panDragMode }

        Box {
            ToolChip("Click\u2026") { clickMenu = true }
            DropdownMenu(expanded = clickMenu, onDismissRequest = { clickMenu = false }) {
                DropdownMenuItem(text = { Text("Left click") }, onClick = { clickMenu = false; session.click(1) })
                DropdownMenuItem(text = { Text("Double click") }, onClick = { clickMenu = false; session.doubleClick() })
                DropdownMenuItem(text = { Text("Right click") }, onClick = { clickMenu = false; session.click(4) })
                DropdownMenuItem(text = { Text("Middle click") }, onClick = { clickMenu = false; session.click(2) })
            }
        }

        ToolChip("Fullscreen") { vm.fullscreen = true }

        Box {
            ToolChip("More\u2026") { moreMenu = true }
            DropdownMenu(expanded = moreMenu, onDismissRequest = { moreMenu = false }) {
                DropdownMenuItem(
                    text = { Text("Send Ctrl+Alt+Del") },
                    onClick = {
                        moreMenu = false
                        session.keyCombo(Keysyms.CONTROL_L, Keysyms.ALT_L, Keysyms.DELETE)
                    }
                )
                DropdownMenuItem(text = { Text("Refresh screen") }, onClick = { moreMenu = false; session.refresh() })
                DropdownMenuItem(text = { Text("Reset zoom") }, onClick = { moreMenu = false; session.resetViewport() })
                DropdownMenuItem(
                    text = { Text("Send phone clipboard to remote") },
                    onClick = { moreMenu = false; session.sendClipboardToRemote() }
                )
                DropdownMenuItem(
                    text = { Text("Type phone clipboard") },
                    onClick = { moreMenu = false; session.typeClipboard() }
                )
                DropdownMenuItem(
                    text = { Text(if (session.viewOnly) "View only: ON (tap to allow input)" else "View only: off") },
                    onClick = { moreMenu = false; session.viewOnly = !session.viewOnly }
                )
                if (!vm.isSaved(session.profile.id)) {
                    DropdownMenuItem(
                        text = { Text("Save connection") },
                        onClick = { moreMenu = false; vm.saveSessionAsProfile(session) }
                    )
                }
                DropdownMenuItem(
                    text = { Text("Disconnect") },
                    onClick = { moreMenu = false; vm.closeSession(session.id) }
                )
            }
        }
    }
}

@Composable
private fun KeyDock(session: VncSession) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .horizontalScroll(rememberScrollState())
            .padding(6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ToolChip("Esc", compact = true) { session.tapKey(Keysyms.ESCAPE) }
        ToolChip("Tab", compact = true) { session.tapKey(Keysyms.TAB) }
        ToolChip("Ctrl", session.ctrl, compact = true) { session.toggleCtrl() }
        ToolChip("Alt", session.alt, compact = true) { session.toggleAlt() }
        ToolChip("Shift", session.shift, compact = true) { session.toggleShift() }
        ToolChip("Win", session.meta, compact = true) { session.toggleMeta() }
        ToolChip("\u2190", compact = true) { session.tapKey(Keysyms.LEFT) }
        ToolChip("\u2191", compact = true) { session.tapKey(Keysyms.UP) }
        ToolChip("\u2193", compact = true) { session.tapKey(Keysyms.DOWN) }
        ToolChip("\u2192", compact = true) { session.tapKey(Keysyms.RIGHT) }
        ToolChip("Home", compact = true) { session.tapKey(Keysyms.HOME) }
        ToolChip("End", compact = true) { session.tapKey(Keysyms.END) }
        ToolChip("PgUp", compact = true) { session.tapKey(Keysyms.PAGE_UP) }
        ToolChip("PgDn", compact = true) { session.tapKey(Keysyms.PAGE_DOWN) }
        ToolChip("Del", compact = true) { session.tapKey(Keysyms.DELETE) }
        ToolChip("Ins", compact = true) { session.tapKey(Keysyms.INSERT) }
        ToolChip("Ctrl+Alt+Del", compact = true) {
            session.keyCombo(Keysyms.CONTROL_L, Keysyms.ALT_L, Keysyms.DELETE)
        }
        for (n in 1..12) {
            ToolChip("F$n", compact = true) { session.tapKey(Keysyms.functionKey(n)) }
        }
    }
}

@Composable
private fun FullscreenControls(vm: VncViewModel, session: VncSession, modifier: Modifier) {
    var expanded by remember { mutableStateOf(false) }
    Row(
        modifier = modifier.padding(8.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (expanded) {
            val view = LocalView.current
            ToolChip("Keyboard", compact = true) {
                val visible = ViewCompat.getRootWindowInsets(view)
                    ?.isVisible(WindowInsetsCompat.Type.ime()) == true
                session.requestIme(!visible)
            }
            ToolChip("Keys", session.showDock, compact = true) { session.showDock = !session.showDock }
            ToolChip("Exit fullscreen", compact = true) { vm.fullscreen = false }
        }
        Surface(
            color = Color(0x99212833),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.clickable { expanded = !expanded }
        ) {
            Text(
                text = if (expanded) "Hide" else "Menu",
                color = Color.White,
                style = MaterialTheme.typography.labelMedium,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
            )
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Overlays and dialogs
// ---------------------------------------------------------------------------------------------

@Composable
private fun ConnectingOverlay(vm: VncViewModel, session: VncSession) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xCC000000)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.padding(24.dp)
        ) {
            CircularProgressIndicator()
            Text(session.title, style = MaterialTheme.typography.titleMedium, color = Color.White)
            Text(session.status, style = MaterialTheme.typography.bodyMedium, color = Color(0xFF9DA7B3))
            TextButton(onClick = { vm.closeSession(session.id) }) { Text("Cancel") }
        }
    }
}

@Composable
private fun FailedOverlay(vm: VncViewModel, session: VncSession) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xCC000000)),
        contentAlignment = Alignment.Center
    ) {
        Card(modifier = Modifier.padding(24.dp)) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Disconnected", style = MaterialTheme.typography.titleMedium)
                Text(
                    session.error ?: "The connection ended.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = { session.reconnect() }) { Text("Reconnect") }
                    TextButton(onClick = { vm.closeSession(session.id) }) { Text("Close") }
                }
            }
        }
    }
}

@Composable
private fun PasswordDialog(vm: VncViewModel, session: VncSession) {
    var password by remember { mutableStateOf("") }
    var save by remember { mutableStateOf(true) }
    AlertDialog(
        onDismissRequest = { vm.closeSession(session.id) },
        title = { Text("VNC password") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = if (session.passwordRejected) {
                        "That password was rejected. Try again."
                    } else {
                        session.title + " requires a password."
                    },
                    color = if (session.passwordRejected) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                )
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    singleLine = true,
                    label = { Text("Password") },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                )
                if (vm.isSaved(session.profile.id)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = save, onCheckedChange = { save = it })
                        Text("Remember password")
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { vm.submitPassword(session, password, save) }) { Text("Connect") }
        },
        dismissButton = {
            TextButton(onClick = { vm.closeSession(session.id) }) { Text("Cancel") }
        }
    )
}

// ---------------------------------------------------------------------------------------------
// Soft keyboard host
// ---------------------------------------------------------------------------------------------

@Composable
private fun KeyCaptureHost(session: VncSession) {
    val context = LocalContext.current
    val holder = remember { arrayOfNulls<KeyCaptureView>(1) }

    AndroidView(
        factory = { ctx ->
            val v = KeyCaptureView(ctx)
            holder[0] = v
            v
        },
        update = { v ->
            v.textSink = { text -> session.imeText(text) }
            v.keySink = { event -> session.onKeyEvent(event) }
        },
        modifier = Modifier.size(1.dp)
    )

    LaunchedEffect(session.imeCommandTick) {
        if (session.imeCommandTick == 0) return@LaunchedEffect
        delay(60)
        val v = holder[0] ?: return@LaunchedEffect
        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        if (session.imeCommandShow) {
            v.requestFocus()
            imm.restartInput(v)
            imm.showSoftInput(v, InputMethodManager.SHOW_IMPLICIT)
        } else {
            imm.hideSoftInputFromWindow(v.windowToken, 0)
        }
    }
}
