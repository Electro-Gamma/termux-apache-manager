// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later

package net.pgaskin.remotedesktop.backend

import android.content.Context
import android.content.SharedPreferences
import java.util.Locale
import java.util.function.Consumer

/**
 * Which certificate each address is supposed to have.
 *
 * A remote desktop server's certificate is one it made for itself on first start. No authority
 * vouches for it and none ever will, so verifying it against a root store would reject every
 * server anybody actually runs — and a client that then offered "connect anyway" would have
 * taught its user to click through the only check it has.
 *
 * So the identity is the key, as it is over SSH: the fingerprint is pinned against the address the
 * first time somebody accepts it, and after that a connection is silent while it matches and loud
 * when it does not. That is what makes the loud case mean something — a prompt that appears every
 * time is a prompt nobody reads.
 *
 * It is deliberately keyed on the *address as written*, not on the connection record: a session
 * opened from the command line has no record, two records may point at one machine, and the thing
 * being identified is the machine. Writing the same host two different ways makes two entries,
 * which is also what SSH does about `host` and its IP address.
 *
 * Backend-neutral on purpose: RDP's certificate prompt is the same question about a different
 * protocol.
 */
object KnownHosts {

    private const val FILE = "known_hosts"

    private fun prefs(ctx: Context): SharedPreferences =
        ctx.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    /**
     * Folded for case and nothing else, which is right twice over: a name is case-insensitive in
     * DNS and an IPv6 literal is case-insensitive in its own notation, so `[FE80::1]` and
     * `[fe80::1]` are one machine rather than two prompts.
     *
     * What it does *not* fold is a default port left off or an address written a shorter way, so
     * one machine can still have two entries. Filling a port in needs the protocol's own default,
     * which is below this class, and a backend that wants a key of its own already picks one.
     */
    private fun key(address: String?): String =
        if (address == null) "" else address.trim().lowercase(Locale.ROOT)

    /** What this address is pinned to, or null if it has never been accepted. */
    @JvmStatic
    fun pinned(ctx: Context, address: String?): String? = prefs(ctx).getString(key(address), null)

    @JvmStatic
    fun pin(ctx: Context, address: String?, fingerprint: String?) {
        prefs(ctx).edit().putString(key(address), fingerprint).apply()
    }

    @JvmStatic
    fun forget(ctx: Context, address: String?) {
        prefs(ctx).edit().remove(key(address)).apply()
    }

    /**
     * Every pin here, gone: the next connection to each of them asks again, as a first one does.
     *
     * Only this store. A backend whose library keeps its own is reached through
     * [BackendProvider.forgetHosts], which is what [Backends.forgetHosts] exists to call alongside
     * this.
     */
    @JvmStatic
    fun clear(ctx: Context) {
        prefs(ctx).edit().clear().apply()
    }

    /**
     * Whether this certificate is the one this address was accepted with, in which case nothing is
     * asked. A match being silent is the point of pinning: a prompt that appears every time is a
     * prompt nobody reads.
     */
    @JvmStatic
    fun matches(ctx: Context, address: String?, fingerprint: String?): Boolean {
        val pin = pinned(ctx, address)
        return pin != null && canonical(pin) == canonical(fingerprint)
    }

    /**
     * The hex digits alone, upper case — what two fingerprints are compared as.
     *
     * A fingerprint is printed rather than defined: one library hands over `66:CC:ED:…` and another
     * the same bytes as `66:cc:ed:…`, and this store is keyed on the machine rather than on what
     * reached it, so a second client asking about a server the first has pinned must not be told
     * its identity has changed. Separators go with the case for the same reason — nothing about how
     * a library spells a digest is part of the digest.
     */
    private fun canonical(fingerprint: String?): String {
        if (fingerprint == null) return ""
        val out = StringBuilder(fingerprint.length)
        for (c in fingerprint) {
            if (Character.digit(c, 16) >= 0) out.append(c.uppercaseChar())
        }
        return out.toString()
    }

    /**
     * Put the question to somebody, and pin the answer if they say to remember it. Main thread;
     * [answer] is called there too, once.
     *
     * The interesting distinction is between "never seen" and "seen, and different now" —
     * [Prompt.Trust.Identity] carries both, and a screen says the second one loudly. Every backend
     * that hands over a fingerprint asks exactly this, which is why it is here rather than three
     * times over; a backend whose library does its own asking (TigerVNC's) is not a caller.
     */
    @JvmStatic
    fun ask(
        ctx: Context,
        address: String?,
        fingerprint: String?,
        handler: Prompt.Handler?,
        answer: Consumer<Boolean>,
    ) {
        val current = pinned(ctx, address)
        val elsewhere = if (current == null) otherAddressFor(ctx, fingerprint, address) else null
        val identity = when {
            current != null -> Prompt.Trust.Identity.CHANGED
            elsewhere != null -> Prompt.Trust.Identity.MATCHES_ANOTHER
            else -> Prompt.Trust.Identity.NEW
        }
        val prompt = object : Prompt.Trust(
            address, Prompt.Trust.Encryption.ENCRYPTED, identity, fingerprint, "", elsewhere,
        ) {
            override fun deliver(accept: Boolean, remember: Boolean) {
                if (accept && remember) pin(ctx, address, fingerprint)
                answer.accept(accept)
            }
        }
        if (handler == null) {
            prompt.cancel()
        } else {
            handler.trust(prompt)
        }
    }

    /**
     * Some other address this certificate is already pinned to, if there is one.
     *
     * Worth saying rather than reporting a bare "never seen before": one machine reached by name
     * and by number, or moved to a new address, is the ordinary explanation, and it is a different
     * thing from a fingerprint that has changed underneath an address that has not.
     */
    @JvmStatic
    fun otherAddressFor(ctx: Context, fingerprint: String?, except: String?): String? {
        if (fingerprint.isNullOrEmpty()) return null
        val skip = key(except)
        val wanted = canonical(fingerprint)
        for ((k, v) in prefs(ctx).all) {
            if (k != skip && v is String && wanted == canonical(v)) return k
        }
        return null
    }
}
