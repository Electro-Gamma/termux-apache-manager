// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later

package net.pgaskin.remotedesktop.backend

/**
 * One setting a backend understands, described well enough for the app to *offer* it without
 * knowing what it means.
 *
 * A backend is built with an opaque `Map<String, String>`, which is enough to pass options and
 * useless for building a screen out of them. The alternative to this is a hard-coded list of
 * RealVNC's parameters in the settings tree, which is exactly the coupling the flavour split
 * exists to prevent.
 *
 * The values are strings, because that is what the backends' own configuration layers take —
 * RealVNC's parameter registry parses `"true"`/`"30"`/`"ZRLE2"` out of strings itself. [Type]
 * says how to ask for one, not how to store it.
 *
 * @property key the backend's own name for it; the map key
 * @property label one line, for a preference title
 * @property summary the longer explanation, or null
 * @property type which control to offer
 * @property choices for [Type.CHOICE], in display order; empty otherwise
 * @property defaultValue what the backend does when nothing is set
 * @property scope whose setting it is: the connection's or the backend's
 * @property live whether [Backend.setOption] does anything mid-session
 * @property gate what another option must say for this one to be offered at all, or null
 */
@JvmRecord
data class BackendOption(
    val key: String,
    val label: String,
    val summary: String?,
    val type: Type,
    val choices: List<Choice>,
    val defaultValue: String?,
    val scope: Scope,
    val live: Boolean,
    val gate: Gate?,
) {

    enum class Type {
        /** `"true"` / `"false"`. */
        BOOL,

        /** One of [choices]. */
        CHOICE,

        /** A decimal integer. */
        INT,

        /** Free text. */
        TEXT,
    }

    enum class Scope {
        /**
         * Belongs to one connection: offered in the editor, stored on the connection record.
         * View-only and the desktop size are the shape of this — they are about one machine,
         * and two servers on the same phone want different answers.
         */
        CONNECTION,

        /**
         * Belongs to the backend: offered in its settings screen, stored in its own preference
         * file, and applied to every connection that uses it. Its own preference file, so a
         * backend's settings live and die with the backend.
         */
        GLOBAL,

        /**
         * The connection's, with the backend's answer as its default: offered in both screens,
         * and read from the connection where it has one and from the backend where it has not.
         * The encoding and how much of the picture may be thrown away are the shape of this —
         * mostly a fact about the link this phone is on rather than about one machine, but with
         * one machine always able to disagree.
         *
         * An editor stores an override only where the answer differs from what the connection
         * would do anyway, so moving the backend's answer moves every connection that agreed
         * with it and leaves the rest.
         */
        LAYERED,
    }

    /**
     * A value and what to call it on screen.
     *
     * @property summary why you would pick this one over the others, or null. A value whose
     *   label is the whole of what there is to say has none, which is nearly all of them; where
     *   one is given, the choice is offered as a list of described items rather than as a menu
     *   of labels, since a menu has no room for a line of prose. Only the connection editor
     *   draws these.
     * @property requires the key of a `BOOL` option this choice depends on, or null. A choice
     *   whose dependency is off is not offered at all, which is for the case where a backend can
     *   do something it should not do unasked — an encoding that is lossy, say — and offering it
     *   as a preference while it is switched off would be offering something that cannot happen.
     */
    @JvmRecord
    data class Choice(
        val value: String,
        val label: String,
        val summary: String?,
        val requires: String?,
    ) {
        constructor(value: String, label: String) : this(value, label, null, null)
    }

    /**
     * @property key another option's key
     * @property values the values of it that make this option worth offering
     */
    @JvmRecord
    data class Gate(val key: String, val values: List<String>) {
        fun open(value: String?): Boolean = value != null && values.contains(value)
    }

    /**
     * The same option, offered only where another one says one of [values].
     *
     * For a setting a backend *has* and does not always consult: not a capability, which is a
     * fact about a live session and belongs on [Backend], and not a choice that depends on a
     * switch, which is [Choice.requires]. The case it is for is a mode dial that owns several
     * settings until it is set to the value that hands them back — where leaving the row on
     * screen means offering a control that provably does nothing, and greying it out means
     * saying "not now" where the honest answer is "not here".
     *
     * The gate is read from the same values the rows are drawn from, so a screen where the
     * controlling option is missing offers nothing that depends on it.
     */
    fun `when`(key: String, vararg values: String): BackendOption =
        BackendOption(
            this.key, label, summary, type, choices, defaultValue, scope, live,
            Gate(key, java.util.List.of(*values)),
        )

    /** For a [Type.CHOICE]: what to show for [value], or the value itself. */
    fun labelFor(value: String?): String? {
        for (c in choices) {
            if (c.value == value) return c.label
        }
        return value
    }

    companion object {
        @JvmStatic
        fun bool(
            key: String, label: String, summary: String?,
            defaultValue: Boolean, scope: Scope, live: Boolean,
        ): BackendOption = BackendOption(
            key, label, summary, Type.BOOL, emptyList(),
            defaultValue.toString(), scope, live, null,
        )

        @JvmStatic
        fun integer(
            key: String, label: String, summary: String?,
            defaultValue: Int, scope: Scope, live: Boolean,
        ): BackendOption = BackendOption(
            key, label, summary, Type.INT, emptyList(),
            defaultValue.toString(), scope, live, null,
        )

        @JvmStatic
        fun text(
            key: String, label: String, summary: String?,
            defaultValue: String?, scope: Scope, live: Boolean,
        ): BackendOption = BackendOption(
            key, label, summary, Type.TEXT, emptyList(),
            defaultValue, scope, live, null,
        )

        @JvmStatic
        fun choice(
            key: String, label: String, summary: String?,
            defaultValue: String?, scope: Scope, live: Boolean,
            vararg choices: Choice,
        ): BackendOption = BackendOption(
            key, label, summary, Type.CHOICE, java.util.List.of(*choices),
            defaultValue, scope, live, null,
        )
    }
}
