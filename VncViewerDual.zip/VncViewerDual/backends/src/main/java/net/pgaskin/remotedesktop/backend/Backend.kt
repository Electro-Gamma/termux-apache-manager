// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later

package net.pgaskin.remotedesktop.backend

import android.graphics.Bitmap
import java.util.function.Consumer

/**
 * One remote desktop connection, whatever protocol is underneath.
 *
 * Everything above `CursorController` is already protocol-free — the gesture stack emits absolute
 * desktop coordinates and an RFB button mask and knows nothing else — so this interface is narrow
 * on purpose: pixels out, input in, and a small number of events.
 *
 * ## Threads
 * - Every method here may be called from the main thread, and the implementation is responsible
 *   for getting the work to wherever its library wants it. RealVNC's wants a single `Looper`
 *   thread that is not the main one, because that is where the core registers its socket and
 *   delivers every callback.
 * - [readRegion] is the exception in the other direction: it is called from whichever thread is
 *   drawing, concurrently with everything else, and must be safe there. That is deliberate —
 *   pixel fetches must not queue behind connection work, which is the one place the original
 *   steps outside its own JNI thread too.
 * - [Listener] callbacks arrive on the main thread, except [Listener.damaged] and
 *   [Listener.frameEnd], which arrive on whatever thread the protocol runs on and must be cheap
 *   and thread-safe. Those two are per-update-batch traffic; posting each one would be a flood.
 */
interface Backend {

    enum class State {
        /** Created, not started. */
        IDLE,

        /** [connect] called, nothing usable yet. */
        CONNECTING,

        /** Pixels and input are flowing. */
        CONNECTED,

        /** Over, for any reason; detail says which, and it is terminal. */
        CLOSED,
    }

    interface Listener {

        /** Main thread. [detail] is human-readable, and may be null. */
        fun state(state: State, detail: String?)

        /** Main thread. The framebuffer's size, initially and on resize. */
        fun desktopSize(width: Int, height: Int)

        /**
         * Any thread. This rectangle of the desktop has changed; the pixels are not fetched until
         * someone calls [readRegion].
         */
        fun damaged(x: Int, y: Int, width: Int, height: Int)

        /** Any thread. End of an update batch — a good moment to draw. */
        fun frameEnd()

        /**
         * Main thread. The remote cursor's shape, and the hotspot as a positive offset into the
         * bitmap. RFB carries a cursor rectangle whose origin is the *negated* hotspot, and
         * RealVNC's core passes that origin straight through; a backend undoes the negation
         * here, so a caller draws the shape at `position - hotspot` and never meets the sign.
         */
        fun cursor(shape: Bitmap?, hotX: Int, hotY: Int)

        /**
         * Main thread. Which end owns the cursor has changed.
         *
         * Relative means the far end does: [pointerRelative] is the call that means anything,
         * nobody here knows where the pointer is, and a client that draws one and follows it with
         * a viewport has to stop doing both. Only RFB against a server that asks for it —
         * QEMU's, in practice — ever says true.
         */
        fun pointerMode(relative: Boolean)

        /** Main thread. */
        fun bell()

        /** Main thread. The remote's clipboard changed. */
        fun clipboardFromRemote(text: String?)

        /**
         * Any thread. The remote is asking for ours; return null for nothing. Called inline, so it
         * must not block on the main thread.
         */
        fun clipboardForRemote(): String?
    }

    fun setListener(listener: Listener?)

    /** How to answer the connection's questions. Set before [connect]. */
    fun setPromptHandler(handler: Prompt.Handler?)

    /** Start connecting. Returns immediately; progress arrives as [Listener.state]. */
    fun connect()

    /** Ask for a graceful disconnect. [State.CLOSED] follows. */
    fun disconnect()

    /**
     * Release everything, including whatever the native side is holding. The backend is dead
     * afterwards and must not be reused.
     */
    fun destroy()

    fun state(): State

    /**
     * Change one of the settings this backend describes ([BackendOption]) on the running session.
     *
     * Only meaningful for an option whose [BackendOption.live] is set; anything else is remembered
     * for the next connection at best. Whatever a particular backend has to do to make a change
     * take effect is its own business — RealVNC's quality group needs an `applyOptions` call after
     * the set and nothing else does, and that asymmetry has no place in this interface.
     */
    fun setOption(key: String, value: String)

    /**
     * Whether this session is watching rather than driving — the one option the *app* has to know
     * about rather than merely pass through.
     *
     * Every backend already drops input for it natively, so nothing would break without this; what
     * would remain is a keyboard and a mouse overlay that quietly do nothing, which is
     * indistinguishable from a session that has stopped responding. An accessor rather than
     * `options.get("ViewOnly")` at the call site, because the key differs per backend and the
     * question does not.
     */
    fun viewOnly(): Boolean

    /**
     * Whatever the backend can say about the live connection, in display order: desktop name,
     * protocol, connection, security, encoding, line speed, and then whatever is diagnostic. What
     * the "connection information" tap region opens.
     *
     * Asynchronous, and that is not politeness: gathering this means asking the library on
     * whichever thread it insists on, and RealVNC's is the one session thread, which can be inside
     * a connect or blocked behind an unanswered password prompt.
     *
     * @param callback called once, on the main thread, with the facts in display order — or an
     *   empty list when there is nothing connected. May never be called if the session is wedged,
     *   which is why nothing on screen may depend on it arriving.
     */
    fun connectionInfo(callback: Consumer<List<ConnectionFact>>)

    /** Zero until the first [Listener.desktopSize]. */
    fun desktopWidth(): Int

    fun desktopHeight(): Int

    /**
     * Everything about a live session that has to be *asked for* rather than waited for, in one
     * answer.
     *
     * What these have in common is that there is nothing to hang a callback on. An RFB server
     * states its monitor layout in a rectangle that arrives after the connection if it arrives at
     * all; a desktop grows a screen when one is plugged into it and says so the same way; and
     * whether the far end will take a size becomes true some time after the connection, so a
     * one-shot that fired too early would never fire again. A caller must expect every one of
     * these to change while a session runs, and to differ between two sessions on the same
     * backend.
     *
     * One value rather than an accessor each, for three reasons: a poll is one crossing into the
     * library instead of five, "has anything moved" is one `equals` instead of a remembered field
     * per caller, and a backend answers in one place — which is also what stops two of these
     * disagreeing, since they are read from the far end's state at one instant rather than at
     * five.
     *
     * @property monitors how the far end's *one* desktop is divided, or empty where it has not
     *   said — which is not the same as one monitor, and is the answer for a library that never
     *   exposes the layout
     * @property displays the pictures the far end is *not* sending and will send if asked; empty
     *   for every protocol but one. Not [monitors], and the difference is which picture is on
     *   screen: a monitor is a region of the framebuffer everything else here serves, so a caller
     *   with the layout can jump the viewport between heads and the pixels are already there.
     *   Choosing a display is a message, a new size and a new framebuffer, and its rectangles are
     *   in the far end's own coordinates only so that a person can tell which screen is which.
     * @property display which of [displays] is on screen, or -1 where there is no choice
     * @property canResize whether the far end will take a new desktop size right now. Deliberately
     *   not a [BackendOption]: an option is a static description a backend gives of itself before
     *   anything is connected, and this is a fact about one live session.
     * @property viewOnly [viewOnly], which is also its own accessor — that one is what a screen
     *   reacting to the panel asks, and this is the same answer as of this instant
     * @property pointerRelative whether the far end owns the cursor. Pushed as
     *   [Listener.pointerMode] while a screen is attached, and here for the screen that attaches
     *   to a session which has been running for an hour
     */
    class Facts(
        @get:JvmName("desktopWidth") val desktopWidth: Int,
        @get:JvmName("desktopHeight") val desktopHeight: Int,
        monitors: List<Monitor>,
        displays: List<Monitor>,
        @get:JvmName("display") val display: Int,
        @get:JvmName("canResize") val canResize: Boolean,
        @get:JvmName("viewOnly") val viewOnly: Boolean,
        @get:JvmName("pointerRelative") val pointerRelative: Boolean,
    ) {
        @get:JvmName("monitors")
        val monitors: List<Monitor> = java.util.List.copyOf(monitors)

        @get:JvmName("displays")
        val displays: List<Monitor> = java.util.List.copyOf(displays)

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (other !is Facts) return false
            return desktopWidth == other.desktopWidth &&
                desktopHeight == other.desktopHeight &&
                monitors == other.monitors &&
                displays == other.displays &&
                display == other.display &&
                canResize == other.canResize &&
                viewOnly == other.viewOnly &&
                pointerRelative == other.pointerRelative
        }

        override fun hashCode(): Int {
            var h = desktopWidth
            h = 31 * h + desktopHeight
            h = 31 * h + monitors.hashCode()
            h = 31 * h + displays.hashCode()
            h = 31 * h + display
            h = 31 * h + canResize.hashCode()
            h = 31 * h + viewOnly.hashCode()
            h = 31 * h + pointerRelative.hashCode()
            return h
        }

        override fun toString(): String =
            "Facts[desktopWidth=$desktopWidth, desktopHeight=$desktopHeight, monitors=$monitors, " +
                "displays=$displays, display=$display, canResize=$canResize, " +
                "viewOnly=$viewOnly, pointerRelative=$pointerRelative]"

        companion object {
            /** Nothing connected: what a session that is over has to say. */
            @JvmField
            val NONE = Facts(0, 0, emptyList(), emptyList(), -1, false, false, false)
        }
    }

    /** @see Facts */
    fun facts(): Facts

    /**
     * Ask the far end to send another of its displays.
     *
     * A request, like [requestDesktopSize]: the far end may answer with a different one or with
     * nothing, and what actually happened arrives as [Listener.desktopSize] and in the next
     * [Facts.display].
     */
    fun requestDisplay(index: Int) {
    }

    /**
     * Ask the far end to make the desktop this size.
     *
     * A request, and the far end decides: it may refuse, or grant a different size than asked.
     * What actually happened arrives as [Listener.desktopSize], or as nothing at all when the
     * answer is no — so a caller reports the size it has rather than the size it asked for.
     */
    fun requestDesktopSize(width: Int, height: Int) {
    }

    // ---- input ------------------------------------------------------------

    /** Absolute desktop coordinates and an RFB button mask (see `Button`). */
    fun pointer(x: Int, y: Int, buttonMask: Int)

    /**
     * The same event where the far end owns the cursor: how far it moved, in desktop pixels,
     * rather than where it now is.
     *
     * Only meaningful while [Facts.pointerRelative] — every other backend ignores it, and no
     * caller may choose between the two: which one carries the pointer is the far end's decision,
     * announced through [Listener.pointerMode].
     *
     * A default where almost nothing else here has one, because it is the answer for every
     * protocol but one: the cursor is ours. A backend that says nothing is absolute.
     */
    fun pointerRelative(dx: Int, dy: Int, buttonMask: Int) {
    }

    /**
     * @param keysym an X11 keysym (`control.input.Keysym`)
     * @param keyId a stable identity for the physical key — any value, as long as the same key
     *   uses the same one. A library keeping a map of held keys keys it on this and releases the
     *   keysym recorded at press time, so it is what ties an up to its down.
     */
    fun keyDown(keysym: Int, keyId: Int)

    fun keyUp(keyId: Int)

    /**
     * Let go of every key this session still has down at the far end.
     *
     * A sweep rather than the ordinary path: the caller releases each key it knows about by id,
     * and this is for the ones it no longer knows about — a screen taken away mid-chord, an event
     * stream that stopped between a press and its release. "Held" means held over there, and it
     * stays that way until something says otherwise, so the alternative is a Ctrl that is down for
     * the rest of the session.
     *
     * Every backend keeps the map this needs, because a release names a key and the protocols
     * carry a keysym; four of them expose it and RealVNC's core does not, so that one keeps its
     * own copy of the ids.
     */
    fun releaseAllKeys()

    /**
     * Whether the session is in the foreground. Backends may pause updates when it is not, which
     * is where a backgrounded session stops costing traffic: RealVNC's core stops asking for
     * framebuffer updates at the end of the one in flight, and remembers a request that fell due
     * meanwhile.
     *
     * Deliberately *not* where keys are let go: whether losing the screen should release them is a
     * question about this phone rather than about a protocol, so it is one app setting and one
     * [releaseAllKeys] call rather than the same decision taken five times below this line.
     */
    fun focus(focused: Boolean)

    fun clipboardToRemote(text: String?)

    // ---- pixels -----------------------------------------------------------

    /**
     * Copy the desktop rectangle `(x, y, width, height)` into [dst] at `(dstX, dstY)`, 1:1.
     * **The rest of [dst] is left as it was**, which is what lets a caller hold a picture bigger
     * than any one read and refresh the parts of it that changed.
     *
     * That promise is the whole reason the offset is here. Without it a caller reading less than a
     * whole bitmap has to go through a scratch bitmap and blit the result into place — a copy of
     * everything that changed, on the drawing thread. With it, a backend that owns its framebuffer
     * writes the rows straight into the destination.
     *
     * Callable from the drawing thread at any time. Returns false if there is nothing to read yet,
     * or if the rectangle does not fit — in which case [dst] is untouched.
     *
     * @param dst [Bitmap.Config.ARGB_8888], at least `dstX + width` by `dstY + height`
     * @param dstX where in [dst] the rectangle's left edge goes
     * @param dstY where in [dst] the rectangle's top edge goes
     */
    fun readRegion(
        x: Int, y: Int, width: Int, height: Int,
        dst: Bitmap, dstX: Int, dstY: Int,
    ): Boolean

    /**
     * The whole framebuffer, no bigger than [maxWidth] by [maxHeight] — a thumbnail for the home
     * screen.
     *
     * Returns a new bitmap, whose exact size the backend chooses within the bounds given, or null
     * if there is nothing to show yet. Backends may quantise the scale — this is a preview, and the
     * RealVNC one can only downscale by whole integers.
     */
    fun thumbnail(maxWidth: Int, maxHeight: Int): Bitmap?
}
