// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later

package net.pgaskin.remotedesktop.backend

import java.util.Locale

/**
 * One line of what a backend can say about the connection it is running.
 *
 * This replaces the `Map<String, String>` [Backend] used to return, which carried display order
 * and nothing else — enough for a dialog that joined it with newlines, and not enough for a
 * screen. A panel has to know which row is the desktop's own name, because that is the heading
 * rather than a row, and which rows are diagnostics, because those are folded away.
 *
 * [Field] is the identity and is a fixed set: the panel matches on it, so a backend that calls
 * line speed something else still lands in the right place. [label] is the backend's own
 * wording for the same thing, which is what actually goes on screen — the two are separate
 * because the identity is ours and the wording is theirs.
 *
 * A backend **omits** a field it has no concept of, and **includes one with an empty value**
 * when it has the concept but no answer yet. That distinction is the original's — "Not set"
 * rather than a vanishing row: the shape of the panel should depend on what the protocol is,
 * not on how much this particular server has got round to saying.
 *
 * There is no field for the desktop *size*. It is known locally from [Backend.desktopWidth] the
 * moment the first framebuffer arrives, so asking the protocol for it would be a round trip for
 * something already on the screen.
 *
 * Make one with [of], [diagnostic] or [data]: they trim the value, and an absent one is empty.
 *
 * @property diagnostic true for something only worth reading when hunting a problem — the pixel
 *   formats are the case this exists for
 */
@JvmRecord
data class ConnectionFact(
    val field: Field,
    val label: String,
    val value: String,
    val diagnostic: Boolean,
) {

    /** What a row *is*, independently of what a backend calls it. */
    enum class Field {
        /** The desktop's own name for itself. The panel's heading. */
        DESKTOP_NAME,

        /** How the bytes get there: direct TCP, relayed, UDP. */
        CONNECTION,

        /** What is protecting them, if anything. */
        SECURITY,

        /** Which version of which protocol is being spoken. */
        PROTOCOL,

        /** The encoding in use for pixels — moves when quality moves. */
        ENCODING,

        /** The measured throughput, however the backend measures it. */
        LINE_SPEED,

        /** What the session has moved, both ways, since it was opened. */
        DATA,

        /** What the server is sending. */
        SERVER_PIXELS,

        /** What we asked it for. */
        VIEWER_PIXELS,

        /** Anything a particular protocol has that this list does not. */
        OTHER,
    }

    companion object {
        @JvmStatic
        fun of(field: Field, label: String, value: String?): ConnectionFact =
            ConnectionFact(field, label, value?.trim() ?: "", false)

        @JvmStatic
        fun diagnostic(field: Field, label: String, value: String?): ConnectionFact =
            ConnectionFact(field, label, value?.trim() ?: "", true)

        /**
         * [Field.DATA], from two raw counts. A direction the protocol has no count for is
         * **negative**, and is left out of the row rather than shown as a zero.
         *
         * The one row whose *wording* is ours rather than the backend's, which is the rule
         * everywhere else. The reason is the number: six clients count in six places, and a
         * row that means "since this session opened, at the protocol, inside whatever is
         * encrypting it" is only comparable if every backend says it the same way and rounds
         * it the same way. So they hand over bytes and this decides the rest.
         *
         * Not called by anything that has only an estimate. A backend that cannot count
         * accurately omits the field, as it would any other.
         */
        @JvmStatic
        fun data(received: Long, sent: Long): ConnectionFact {
            val value = if (sent < 0) {
                size(received) + " in"
            } else {
                size(received) + " in \u00b7 " + size(sent) + " out"
            }
            return of(Field.DATA, "Transferred", value)
        }

        /**
         * Bytes as a person reads them: powers of a thousand, and a decimal only where the
         * mantissa is small enough for one to mean anything. SI rather than binary because this
         * is a quantity that crossed a network, which is measured in thousands everywhere else
         * it is quoted.
         */
        private fun size(bytes: Long): String {
            if (bytes < 1000) return "$bytes B"
            val units = arrayOf("kB", "MB", "GB", "TB")
            var value = bytes / 1000.0
            var unit = 0
            while (value >= 999.5 && unit < units.size - 1) {
                value /= 1000.0
                unit++
            }
            // The phone's own separators, since this is a number somebody reads.
            val format = if (value < 9.995) "%.2f %s" else if (value < 99.95) "%.1f %s" else "%.0f %s"
            return String.format(Locale.getDefault(), format, value, units[unit])
        }
    }
}
