// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later

package net.pgaskin.remotedesktop.backend

import java.util.concurrent.atomic.AtomicBoolean

/**
 * A question the connection has to have answered before it can continue.
 *
 * These are not optional politeness: with nothing answering them a session against a server
 * that wants a password simply never progresses. The answer may be deferred arbitrarily — that
 * is the point, since answering means showing a dialog and waiting for a person — and may come
 * from any thread.
 *
 * Sealed, so that a handler which compiles has considered every kind. What the RealVNC core can
 * ask is wider than this (a dynamic form for interactive authentication, a choice of client
 * identity); those are declined by the backend rather than surfaced, and become new subclasses
 * when something needs them.
 */
sealed class Prompt(
    /** Being connected to, for a dialog to name. */
    @JvmField val address: String?,
) {

    /**
     * Called on the main thread. Each method receives a prompt that must eventually be answered
     * or [cancelled][Prompt.cancel] — exactly once.
     */
    interface Handler {
        fun credentials(prompt: Credentials)

        fun trust(prompt: Trust)

        fun message(prompt: Message)
    }

    // Answering twice is a protocol error at the far end.
    private val answered = AtomicBoolean()

    /** True the first time, false ever after. */
    protected fun claim(): Boolean = answered.compareAndSet(false, true)

    /** Give up on the connection. Safe to call twice; the second does nothing. */
    abstract fun cancel()

    /**
     * "Who are you?" — a user name, a password, or both, depending on what the server's
     * authentication scheme wants. Which of the two it wants is not a detail: VncAuth has no user
     * name at all, so a dialog that shows one is asking for something nobody can answer.
     */
    abstract class Credentials protected constructor(
        address: String?,
        /** The scheme's own words, or empty. */
        @JvmField val instructions: String?,
        /** False when the scheme has no notion of one. */
        @JvmField val needsUserName: Boolean,
        /** Pre-filled, from the record or a previous attempt. */
        @JvmField val userName: String?,
        @JvmField val needsPassword: Boolean,
        /** The server's identity, so it is checkable before a secret is typed. */
        @JvmField val catchphrase: String?,
        @JvmField val signature: String?,
    ) : Prompt(address) {

        fun answer(userName: String?, password: String?) {
            if (claim()) deliver(true, userName, password)
        }

        final override fun cancel() {
            if (claim()) deliver(false, null, null)
        }

        protected abstract fun deliver(ok: Boolean, userName: String?, password: String?)
    }

    /**
     * "Is this the machine you meant, and is anyone listening?" One prompt for both questions
     * because the core asks them together — and because the answer to "the identity changed"
     * depends on whether the link is encrypted.
     */
    abstract class Trust protected constructor(
        address: String?,
        @JvmField val encryption: Encryption,
        @JvmField val identity: Identity,
        /** The identity itself. */
        @JvmField val signature: String?,
        /** And its human-readable form. */
        @JvmField val catchphrase: String?,
        /** For MATCHES_ANOTHER: the address it belongs to. */
        @JvmField val matchingAddress: String?,
    ) : Prompt(address) {

        enum class Encryption {
            ENCRYPTED,

            /** Plain text, and the user should be told. */
            UNENCRYPTED_WARN,

            /** Plain text, deliberately: a local or already-tunnelled link. */
            UNENCRYPTED_QUIET,
        }

        enum class Identity {
            /** Known, and matches. */
            OK,

            /** Never seen before. */
            NEW,

            /** Seen, but under a different address. */
            MATCHES_ANOTHER,

            /** Seen under this address, and different now: the bad one. */
            CHANGED,

            /** The server offered none. */
            MISSING,

            /** Configured out of band. */
            PRESHARED,

            /** Apple Remote Desktop, which has no identity of this kind. */
            ARD,
        }

        /** @param remember accept this identity for next time, without asking */
        fun answer(accept: Boolean, remember: Boolean) {
            if (claim()) deliver(accept, remember)
        }

        final override fun cancel() {
            answer(false, false)
        }

        protected abstract fun deliver(accept: Boolean, remember: Boolean)
    }

    /**
     * Something went wrong, or something needs confirming. [question] is the difference between
     * a dialog with one button and one with two.
     */
    abstract class Message protected constructor(
        address: String?,
        @JvmField val text: String?,
        @JvmField val severity: Severity,
        /** Yes or no, rather than OK. */
        @JvmField val question: Boolean,
        /** The affirmative button's own text, if there is one. */
        @JvmField val confirmLabel: String?,
    ) : Prompt(address) {

        enum class Severity {
            INFORMATION,
            QUESTION,
            WARNING,
            ERROR,
        }

        fun answer(ok: Boolean) {
            if (claim()) deliver(ok)
        }

        final override fun cancel() {
            answer(false)
        }

        protected abstract fun deliver(ok: Boolean)
    }
}
