// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later

package net.pgaskin.remotedesktop.backend

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.util.Log
import dalvik.system.PathClassLoader
import java.io.File
import java.util.ServiceLoader
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.function.Consumer

/**
 * Which backends this build has.
 *
 * Nobody writes the list: it is every [BackendProvider] on the classpath, which is every protocol
 * module the build depends on, plus every one found in an installed add-on ([discover]). That is
 * what makes "what can this app connect with?" a question about a dependency line and an
 * installed package rather than about a class somebody has to remember to edit.
 *
 * An id this build does not have is not an error anywhere except [create]: a connection record
 * naming one still has to draw on the home screen and open in the editor, since the record
 * outlives the build that made it.
 */
object Backends {

    private const val TAG = "Backends"

    /**
     * What an add-on's manifest declares, on a component nothing ever starts, and what the app's
     * `<queries>` matches. An action rather than a package name so that neither side names the
     * other, which is the whole point of the arrangement: the app knows there may be add-ons and
     * never what any of them is for.
     */
    const val PLUGIN_ACTION = "net.pgaskin.remotedesktop.action.BACKEND_PLUGIN"

    /**
     * What an add-on may say on its `<application>` about where a build of itself for another
     * version of the app can be got: a URL with [PLUGIN_UPDATE_VERSION] standing in for the
     * version code wanted, and beside it the SHA-256 of the signing certificate the APK at that
     * URL carries.
     *
     * Manifest meta-data rather than anything in its dex, because the add-on this is for is
     * precisely the one whose dex is never loaded: an add-on built for another version of the app
     * is a manifest and nothing else as far as this process is concerned
     * ([PluginState.INCOMPATIBLE]).
     *
     * Both are optional, and an add-on that names one without the other has said nothing. The
     * signature is the add-on's *claim* about a file nobody has yet, and is worth nothing on its
     * own: what makes it usable is the app weighing it against the key it will only install an
     * add-on signed with, which is the app's own business and is done there.
     */
    const val PLUGIN_UPDATE_URL = "net.pgaskin.remotedesktop.plugin.updateUrl"

    /** @see PLUGIN_UPDATE_URL */
    const val PLUGIN_UPDATE_SIGNATURE = "net.pgaskin.remotedesktop.plugin.updateSignature"

    /** What [PLUGIN_UPDATE_URL] carries in place of a version code. */
    const val PLUGIN_UPDATE_VERSION = "{versionCode}"

    /** What became of one installed package, for a screen that has to say so. */
    enum class PluginState {
        /** Its providers are in the list. */
        LOADED,

        /** Signed by us, but not this build's companion, or it declares nothing. */
        INCOMPATIBLE,

        /** It loaded and then threw. */
        FAILED,
    }

    /**
     * One add-on the app can see. A package that fails the signature check is
     * not one of these and is never reported: there is nothing useful to offer
     * about an impostor, and naming it invites somebody to interact with it.
     */
    @JvmRecord
    data class Plugin(val packageName: String, val state: PluginState, val detail: String?)

    @Volatile
    private var providersCache: List<BackendProvider>? = null

    /** This build's own, which [discover] needs before it can publish any. */
    private var builtInCache: List<BackendProvider>? = null
    private var pluginList: List<Plugin> = emptyList()
    private var discovered: List<BackendProvider> = emptyList()

    @Volatile
    private var chain: Chain? = null

    /** What an add-on's code threw where a screen called it, by package. */
    private val failedAtUse: MutableMap<String, String> = ConcurrentHashMap()

    /** Backends that have said yes to [isSetup] once. */
    private val setUp: MutableSet<String> = ConcurrentHashMap.newKeySet()

    /** Who is waiting on an [isSetup] call, by backend; its own lock. */
    private val asking = HashMap<String, MutableList<Consumer<Boolean>>>()
    private var worker: ExecutorService? = null // under `asking`
    private val main = Handler(Looper.getMainLooper())

    // ---- loading add-ons ----------------------------------------------------

    /**
     * The app's own classloader, with a link on the end for add-ons.
     *
     * Installed from `AppComponentFactory` before anything else runs.
     * It has to be the app's *own* loader rather than a child of it because
     * that is the one the platform hands to native code that asks for a class
     * from a thread of its own — a borrowed core resolving its callbacks — and
     * such a lookup has no Java frame to take a loader from.
     */
    @JvmStatic
    fun classLoader(app: ClassLoader?): ClassLoader {
        val c = Chain(app)
        chain = c
        return c
    }

    /** The end of the chain: the app's dex first, then each add-on's. */
    private class Chain(app: ClassLoader?) : ClassLoader(app) {

        @Volatile
        private var loaders: List<Plugins> = emptyList()

        fun add(loader: Plugins) {
            val next = ArrayList(loaders)
            next.add(loader)
            loaders = java.util.List.copyOf(next)
        }

        override fun findClass(name: String): Class<*> {
            for (loader in loaders) {
                val found = loader.local(name)
                if (found != null) return found
            }
            throw ClassNotFoundException(name)
        }
    }

    /**
     * One add-on's dex. Its parent is the app's real loader rather than the
     * chain, so a lookup that reaches the chain cannot come back round.
     */
    private class Plugins(
        val packageName: String,
        dex: String,
        libs: String?,
        parent: ClassLoader?,
    ) : PathClassLoader(dex, libs, parent) {

        /** This add-on's own classes only, without asking the parent first. */
        fun local(name: String): Class<*>? =
            try {
                findClass(name)
            } catch (e: ClassNotFoundException) {
                null
            }
    }

    /**
     * Load every add-on installed beside this app, once, before anything asks
     * for the backend list.
     *
     * Called from `Application.onCreate` so that the home screen, a
     * session activity and the service all see the same list. It is once per
     * process and deliberately not repeatable: dex and a shared library that are
     * already open cannot be swapped underneath a live session, so an add-on
     * installed while the app runs is noticed ([installedPlugins]) rather
     * than loaded.
     */
    @Synchronized
    @JvmStatic
    fun discover(context: Context) {
        if (providersCache != null) {
            Log.e(TAG, "the backend list was read before discovery", IllegalStateException("too late"))
            return
        }
        try {
            find(context)
        } catch (t: Throwable) {
            Log.e(TAG, "discovering add-ons", t)
        }
    }

    private fun find(context: Context) {
        val pm = context.packageManager
        val ours = try {
            pm.getPackageInfo(context.packageName, 0).longVersionCode
        } catch (e: PackageManager.NameNotFoundException) {
            throw IllegalStateException(e) // we are installed
        }

        val own = loadBuiltIn()
        builtInCache = own
        val taken = LinkedHashSet<String>()
        for (p in own) taken.add(p.id())

        val found = ArrayList<Plugin>()
        val loaded = ArrayList<BackendProvider>()
        for (pkg in signedLikeUs(pm, context.packageName)) {
            val info = try {
                pm.getPackageInfo(pkg, 0)
            } catch (e: PackageManager.NameNotFoundException) {
                continue // uninstalled between the two calls
            }
            if (info.longVersionCode != ours) {
                found.add(
                    Plugin(pkg, PluginState.INCOMPATIBLE, "Built for app version ${info.longVersionCode}."),
                )
                continue
            }
            try {
                val mine = load(info.applicationInfo!!, taken)
                if (mine.isEmpty()) {
                    found.add(Plugin(pkg, PluginState.INCOMPATIBLE, "It has no backend in it."))
                    continue
                }
                for (p in mine) taken.add(p.id())
                loaded.addAll(mine)
                found.add(Plugin(pkg, PluginState.LOADED, null))
                Log.i(TAG, "loaded ${mine.size} backend(s) from $pkg")
            } catch (t: Throwable) {
                Log.e(TAG, "loading $pkg", t)
                val said = t.message
                found.add(
                    Plugin(pkg, PluginState.FAILED, if (said.isNullOrEmpty()) t.toString() else said),
                )
            }
        }
        pluginList = java.util.List.copyOf(found)
        discovered = java.util.List.copyOf(loaded)
    }

    /** The providers this build was compiled with, in no particular order. */
    private fun loadBuiltIn(): List<BackendProvider> {
        val own = ArrayList<BackendProvider>()
        for (p in ServiceLoader.load(BackendProvider::class.java, Backends::class.java.classLoader)) {
            own.add(p)
        }
        return java.util.List.copyOf(own)
    }

    @SuppressLint("QueryPermissionsNeeded")
    private fun signedLikeUs(pm: PackageManager, self: String): Set<String> {
        val candidates = LinkedHashSet<String>()
        for (r in pm.queryIntentServices(Intent(PLUGIN_ACTION), 0)) {
            candidates.add(r.serviceInfo.packageName)
        }
        candidates.remove(self)

        val ours = LinkedHashSet<String>()
        for (pkg in candidates) {
            if (pm.checkSignatures(self, pkg) == PackageManager.SIGNATURE_MATCH) ours.add(pkg)
        }
        return ours
    }

    /**
     * The add-on's dex, under a loader parented to ours.
     *
     * The parent is the point, and `createPackageContext` will not do:
     * its loader hangs off the boot classloader, which cannot see
     * [BackendProvider], so nothing in the add-on would resolve. Splits
     * are included because an installer may have made some.
     *
     * @param taken every id already spoken for, this build's own included
     */
    private fun load(info: ApplicationInfo, taken: Set<String>): List<BackendProvider> {
        val c = chain ?: throw IllegalStateException("This build of the app cannot load plugins.")
        val dex = StringBuilder(info.sourceDir)
        val splits = info.splitSourceDirs
        if (splits != null) {
            for (split in splits) dex.append(File.pathSeparatorChar).append(split)
        }
        val loader = Plugins(
            info.packageName, dex.toString(), info.nativeLibraryDir, Backends::class.java.classLoader,
        )

        val mine = ArrayList<BackendProvider>()
        for (p in ServiceLoader.load(BackendProvider::class.java, loader)) {
            // The service lookup consults the parent first, which finds this build's own. Only
            // what the add-on itself defines is the add-on's.
            if (p.javaClass.classLoader !== loader) continue
            if (taken.contains(p.id())) {
                throw IllegalStateException("Another backend is already called ${p.id()}.")
            }
            for (seen in mine) {
                if (seen.id() == p.id()) { // and against itself
                    throw IllegalStateException("Another backend is already called ${p.id()}.")
                }
            }
            mine.add(p)
        }
        if (mine.isNotEmpty()) c.add(loader)
        return mine
    }

    /**
     * Which add-on a class was loaded from, or null for anything of the app's.
     *
     * An add-on's code sometimes has to reach its own package — its
     * provider, its setup screen — and asking a [Context] gives the
     * app's package, since that is the process it is running in. This is the
     * only thing that knows, because it is what built the loader.
     */
    @JvmStatic
    fun packageOf(loader: ClassLoader?): String? = if (loader is Plugins) loader.packageName else null

    /** The add-on a backend came from, or null for one built into the app. */
    @JvmStatic
    fun packageOf(id: String?): String? {
        val p = provider(id) ?: return null
        return packageOf(p.javaClass.classLoader)
    }

    /**
     * What [discover] made of each add-on, for a screen that says so,
     * with anything that has since thrown ([failed]) folded in: an
     * add-on that loaded and then failed is a failed one, and the difference
     * between the two moments is of no interest to whoever has to deal with it.
     */
    @Synchronized
    @JvmStatic
    fun plugins(): List<Plugin> {
        if (failedAtUse.isEmpty()) return pluginList
        val merged = ArrayList<Plugin>(pluginList.size)
        for (p in pluginList) {
            val said = failedAtUse[p.packageName]
            merged.add(if (said == null) p else Plugin(p.packageName, PluginState.FAILED, said))
        }
        return java.util.List.copyOf(merged)
    }

    /**
     * Somebody else's code threw where a screen called it.
     *
     * Recorded against the add-on it came from, so that the failure has
     * somewhere to be said and something to be done about it — the screen that
     * caught it says so once and is gone, and the card the add-on grows is what
     * offers to uninstall it. A backend of the app's own has neither, and is
     * logged and nothing more.
     */
    @JvmStatic
    fun failed(id: String?, t: Throwable) {
        Log.e(TAG, "backend $id", t)
        val pkg = packageOf(id)
        if (pkg != null) {
            val said = t.message
            failedAtUse[pkg] = if (said.isNullOrEmpty()) t.toString() else said
        }
    }

    /**
     * The add-ons installed now, which is not what [discover] loaded if
     * one has arrived or gone since. A screen compares the two and asks for a
     * restart.
     */
    @JvmStatic
    fun installedPlugins(context: Context): Set<String> =
        signedLikeUs(context.packageManager, context.packageName)

    // ---- the list ---------------------------------------------------------------

    @Synchronized
    private fun providers(): List<BackendProvider> {
        var found = providersCache
        if (found == null) {
            val loaded = ArrayList(builtInCache ?: loadBuiltIn())
            loaded.addAll(discovered)
            loaded.sortWith(compareBy<BackendProvider>({ it.order() }, { it.id() }))
            found = java.util.List.copyOf(loaded)
            providersCache = found
        }
        return found!!
    }

    private fun provider(id: String?): BackendProvider? {
        for (p in providers()) {
            if (p.id() == id) return p
        }
        return null
    }

    @JvmStatic
    fun ids(): List<String> = providers().map { it.id() }

    @JvmStatic
    fun name(id: String?): String? {
        val p = provider(id)
        return if (p == null) id else p.name()
    }

    /**
     * Empty for a backend this build does not have — a card for one still has
     * to draw, and naming something that cannot be opened is worse than saying
     * nothing.
     */
    @JvmStatic
    fun shortName(id: String?): String {
        val p = provider(id)
        return if (p == null) "" else p.shortName()
    }

    /** Empty for a backend this build does not have, as [shortName]. */
    @JvmStatic
    fun description(id: String?): String {
        val p = provider(id)
        return if (p == null) "" else p.description()
    }

    @JvmStatic
    fun options(id: String?): List<BackendOption> {
        val p = provider(id)
        return if (p == null) emptyList() else p.options()
    }

    /** Null where the app's own wording is what the field should say. */
    @JvmStatic
    fun addressLabel(id: String?, options: Map<String, String>?): String? {
        val p = provider(id)
        return p?.addressLabel(options)
    }

    // ---- setup --------------------------------------------------------------------

    /**
     * Whether a backend can be connected with, for a screen deciding whether to
     * offer [setup] instead of what it would otherwise do.
     *
     * **Asked on a thread of its own and answered on the main one.** A
     * provider answers this by looking at what it was given — hashing somebody
     * else's library, or asking the process that holds it — and a screen asks
     * every time it resumes, so the question does not belong on the thread
     * drawing it. The answer is delivered *at once*, before this returns,
     * where it is already known: a screen that asks in `onCreate` is then
     * not a frame behind itself in the ordinary case.
     *
     * **One call at a time per backend**, however many screens ask: a
     * second asker joins the first's answer rather than starting a second hash.
     * A yes is remembered for the life of the process, since what a yes means is
     * that a file is in place and the load verifies it again anyway; a no never
     * is, because re-asking after [setup] is the whole mechanism.
     *
     * True for an id this build does not have, which is a case its callers
     * already have a sentence for. A throw is the backend saying no in the only
     * other way it can, and is recorded ([failed]) — where [setup]
     * is a person pressing a button, and lets the throw out so that they hear
     * about it.
     *
     * **An answer for a screen that has gone is dropped here**, so that
     * four call sites do not need four opinions about it: what every one of
     * them would do with a late answer is open a screen or write on one, and
     * the context it asked with is what says whether there is one.
     */
    @JvmStatic
    fun isSetup(context: Context, id: String?, answer: Consumer<Boolean>) {
        val to = whileThereIsAScreen(context, answer)
        val p = provider(id)
        if (id == null || p == null || setUp.contains(id)) {
            to.accept(true)
            return
        }
        val app = context.applicationContext
        synchronized(asking) {
            val waiting = asking[id]
            if (waiting != null) {
                waiting.add(to)
                return
            }
            asking[id] = arrayListOf(to)
            if (worker == null) {
                worker = Executors.newSingleThreadExecutor { r ->
                    val t = Thread(r, "backend-setup")
                    t.isDaemon = true
                    t
                }
            }
        }
        worker!!.execute {
            var ok: Boolean
            try {
                ok = p.isSetup(app)
            } catch (t: Throwable) {
                failed(id, t)
                ok = false
            }
            if (ok) setUp.add(id)
            val waiting = synchronized(asking) { asking.remove(id) }
            val said = ok
            main.post {
                for (c in waiting.orEmpty()) {
                    try {
                        c.accept(said)
                    } catch (t: Throwable) {
                        Log.e(TAG, "answering isSetup for $id", t)
                    }
                }
            }
        }
    }

    /**
     * The rule, in one place. A context that is not a screen — the application,
     * a service — is one nothing can have navigated away from, and its answer
     * always arrives.
     */
    private fun whileThereIsAScreen(context: Context, answer: Consumer<Boolean>): Consumer<Boolean> {
        if (context !is Activity) return answer
        return Consumer { ok ->
            if (!context.isDestroyed && !context.isFinishing) answer.accept(ok)
        }
    }

    @JvmStatic
    fun setup(host: Activity, id: String?) {
        val p = provider(id)
        p?.setup(host)
    }

    /**
     * Forget every remembered yes, so that the next asker asks the backend again.
     *
     * [isSetup] keeps a yes for the life of the process because what a
     * yes means is that a file is in place, and nothing takes one away. The app
     * deleting its own copies of an add-on's libraries is the one thing that
     * does, and it says so here — otherwise a screen goes on holding an answer
     * about a file that is gone: no card where there should be one, and a
     * session that fails where it should have offered to set the backend up.
     */
    @JvmStatic
    fun setupChanged() {
        setUp.clear()
    }

    /**
     * Every server this phone has accepted, forgotten — the shared store and
     * whatever each backend keeps of its own.
     *
     * Both halves, because "which machines am I no longer asked about?" is
     * one question and a screen offering to answer half of it would be worse
     * than one offering nothing. A backend that throws is recorded and the rest
     * still run, for the same reason the loop over four screens' callbacks is
     * guarded: one add-on must not be the others being left pinned.
     */
    @JvmStatic
    fun forgetHosts(context: Context) {
        val app = context.applicationContext
        KnownHosts.clear(app)
        for (p in providers()) {
            try {
                p.forgetHosts(app)
            } catch (t: Throwable) {
                failed(p.id(), t)
            }
        }
    }

    @JvmStatic
    fun create(
        context: Context,
        id: String?,
        address: String?,
        userName: String?,
        password: String?,
        options: Map<String, String>?,
    ): Backend {
        val p = provider(id)
            ?: throw IllegalArgumentException("no such backend in this build: $id (it has ${ids()})")
        return p.create(context, address, userName, password, options)
    }
}
