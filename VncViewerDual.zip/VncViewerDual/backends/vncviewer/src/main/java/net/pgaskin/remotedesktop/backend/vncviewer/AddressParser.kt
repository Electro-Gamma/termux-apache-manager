// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later

package net.pgaskin.remotedesktop.backend.vncviewer

/**
 * The address grammar every VNC backend in this app reads: `host`, `host:port`, `[literal]`
 * or `[literal]:port`, with a port under 100 meaning a display number (`:1` is 5901). An IPv6
 * literal must be bracketed; a bare one is an error with a sentence in it, not a guess.
 *
 * Also tolerated, because people paste them: a `vnc://` prefix, a `user@`, a trailing path,
 * and `host::port` (an absolute port, as TigerVNC writes it).
 */
internal class AddressParser private constructor(
    val host: String?,
    val port: Int,
    val error: String?,
) {
    companion object {
        const val DEFAULT_PORT = 5900

        private fun fail(error: String) = AddressParser(null, 0, error)

        fun parse(input: String?): AddressParser {
            var s = (input ?: "").trim()
            val scheme = s.indexOf("://")
            if (scheme >= 0) s = s.substring(scheme + 3)
            val slash = s.indexOf('/')
            if (slash >= 0) s = s.substring(0, slash)
            val at = s.lastIndexOf('@')
            if (at >= 0) s = s.substring(at + 1)
            if (s.isEmpty()) return fail("Enter the address of a VNC server.")

            val host: String
            var portSpec: String? = null
            var absolute = false

            if (s.startsWith("[")) {
                val end = s.indexOf(']')
                if (end < 2) return fail("Invalid address: unmatched [ in $s")
                host = s.substring(1, end)
                val rest = s.substring(end + 1)
                if (rest.startsWith("::")) {
                    portSpec = rest.substring(2)
                    absolute = true
                } else if (rest.startsWith(":")) {
                    portSpec = rest.substring(1)
                } else if (rest.isNotEmpty()) {
                    return fail("Invalid address: unexpected text after ].")
                }
            } else {
                val colons = s.count { it == ':' }
                val dbl = s.indexOf("::")
                if (colons == 0) {
                    host = s
                } else if (colons == 1) {
                    val idx = s.indexOf(':')
                    host = s.substring(0, idx)
                    portSpec = s.substring(idx + 1)
                } else if (colons == 2 && dbl > 0 && dbl + 2 < s.length &&
                    s.substring(dbl + 2).all { it.isDigit() } &&
                    // "fe80::1" is an IPv6 literal, not host "fe80" on port 1: a host
                    // made only of hex digits and colons is read as the former.
                    s.substring(0, dbl).any { Character.digit(it, 16) < 0 }
                ) {
                    host = s.substring(0, dbl)
                    portSpec = s.substring(dbl + 2)
                    absolute = true
                } else {
                    return fail(
                        "An IPv6 address must be written in brackets, " +
                            "like [fe80::1] or [fe80::1]:5900."
                    )
                }
            }

            if (host.isBlank() || host.any { it.isWhitespace() }) {
                return fail("Invalid host in address.")
            }

            var port = DEFAULT_PORT
            val spec = portSpec
            if (spec != null) {
                if (spec.isEmpty() || spec.length > 5 || !spec.all { it in '0'..'9' }) {
                    return fail("Invalid port in address.")
                }
                val n = spec.toInt()
                port = if (!absolute && n < 100) DEFAULT_PORT + n else n
            }
            if (port < 1 || port > 65535) return fail("Invalid port in address.")
            return AddressParser(host, port, null)
        }
    }
}
