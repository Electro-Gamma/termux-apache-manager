// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later

package net.pgaskin.remotedesktop.backend.vncviewer

import android.content.Context
import net.pgaskin.remotedesktop.backend.Backend
import net.pgaskin.remotedesktop.backend.BackendOption
import net.pgaskin.remotedesktop.backend.BackendOption.Scope
import net.pgaskin.remotedesktop.backend.BackendProvider

/**
 * The open-source engine: VncViewer's own RFB client, as a backend.
 *
 * Everything here describes what that client really does and nothing it does not: no quality
 * presets, because it always asks for the same encodings; no encryption setting, because
 * RFB's None and VNC password security types have none.
 */
class VncViewerProvider : BackendProvider {

    override fun id(): String = "vncviewer"

    override fun name(): String = "VNC (built-in)"

    override fun shortName(): String = "VNC"

    override fun description(): String =
        "The open-source VNC client built into this app (from VncViewer). " +
            "RFB 3.3, 3.7 and 3.8 with No authentication or VNC password, and the " +
            "ZRLE, Hextile, CopyRect, RRE and Raw encodings. Nothing proprietary and no " +
            "native code, but no encryption, UDP or RealVNC account sign-in: use RealVNC " +
            "for those, and for the best performance against a RealVNC server."

    override fun order(): Int = 20

    override fun options(): List<BackendOption> = OPTIONS

    override fun create(
        context: Context,
        address: String?,
        userName: String?,
        password: String?,
        options: Map<String, String>?,
    ): Backend = VncViewerBackend(context, address, password, options)

    override fun forgetHosts(context: Context) {
        VncViewerBackend.forgetAcknowledged(context)
    }

    internal companion object {
        const val VIEW_ONLY = "ViewOnly"
        const val SHARED = "Shared"
        const val WARN_UNENCRYPTED = "WarnUnencrypted"
        const val DOT_WHEN_NO_CURSOR = "DotWhenNoCursor"
        const val ACCEPT_BELL = "AcceptBell"

        private val OPTIONS: List<BackendOption> = listOf(
            // ---- per connection ---------------------------------------------
            BackendOption.bool(
                VIEW_ONLY, "View only",
                "Do not send input or clipboard events.",
                false, Scope.CONNECTION, true,
            ),
            BackendOption.bool(
                SHARED, "Shared",
                "Do not ask the server to disconnect other clients.",
                true, Scope.CONNECTION, false,
            ),
            // ---- per backend -------------------------------------------------
            BackendOption.bool(
                WARN_UNENCRYPTED, "Warn when unencrypted",
                "Ask before connecting, once per server. RFB's None and VNC password " +
                    "security do not encrypt the session, so this applies to every " +
                    "connection made with this backend; tunnel it (VPN, SSH) or use " +
                    "RealVNC for an encrypted one.",
                true, Scope.GLOBAL, false,
            ),
            BackendOption.bool(
                DOT_WHEN_NO_CURSOR, "Dot for an invisible cursor",
                "Show a dot when the server hides the cursor.",
                true, Scope.GLOBAL, false,
            ),
            BackendOption.bool(
                ACCEPT_BELL, "Bell",
                "Vibrate when the remote server rings the bell.",
                true, Scope.GLOBAL, false,
            ),
        )

        fun defaults(): Map<String, String> {
            val m = LinkedHashMap<String, String>()
            for (o in OPTIONS) m[o.key] = o.defaultValue ?: ""
            return m
        }
    }
}
