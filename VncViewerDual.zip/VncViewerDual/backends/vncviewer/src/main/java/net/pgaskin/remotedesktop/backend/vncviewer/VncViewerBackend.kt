// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later

package net.pgaskin.remotedesktop.backend.vncviewer

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import com.vncviewer.app.vnc.VncClient
import com.vncviewer.app.vnc.VncListener
import net.pgaskin.remotedesktop.backend.Backend
import net.pgaskin.remotedesktop.backend.ConnectionFact
import net.pgaskin.remotedesktop.backend.CursorCache
import net.pgaskin.remotedesktop.backend.Prompt
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import java.util.function.Consumer

/**
 * [Backend] on VncViewer's RFB engine ([VncClient]).
 *
 * The engine owns the socket, the decoders and the framebuffer; this class is the seam's half
 * of the conversation: it turns the engine's callbacks into [Backend.Listener] events on the
 * right threads, asks the questions the engine cannot (the password, the unencrypted-link
 * warning) through [Prompt], and answers [readRegion] from the engine's bitmap.
 *
 * An engine that needs a password has already closed its socket by the time it says so, so
 * answering the prompt starts a *new* engine. Each one gets a generation number and a callback
 * from an older one is dropped, which is also what makes [destroy] final.
 */
class VncViewerBackend internal constructor(
    context: Context,
    address: String?,
    password: String?,
    extraOptions: Map<String, String>?,
) : Backend {

    private val main = Handler(Looper.getMainLooper())
    private val appContext: Context = context.applicationContext
    private val address: String = address ?: ""
    private val password: String = password ?: ""
    private val target: AddressParser = AddressParser.parse(address)
    private val options = ConcurrentHashMap<String, String>()

    @Volatile private var listener: Backend.Listener? = null
    @Volatile private var prompts: Prompt.Handler? = null
    @Volatile private var state: Backend.State = Backend.State.IDLE
    @Volatile private var client: VncClient? = null
    private val generation = AtomicInteger()
    @Volatile private var dead = false
    @Volatile private var desktopWidth = 0
    @Volatile private var desktopHeight = 0
    @Volatile private var lastMask = 0
    @Volatile private var focused = true

    /** Key id to the keysym pressed for it, so an up releases what the down pressed. */
    private val held = HashMap<Int, Int>() // guarded by itself

    // The remote cursor: shapes are deduplicated so the UI can compare by reference, and the
    // last one is kept so a screen attaching late (or coming back) is told what it missed.
    private val cursors = CursorCache() // and `dot`, `lastShape`, `lastHot*`: guarded by it
    private var dot: Bitmap? = null
    private var lastShape: Bitmap? = null
    private var lastHotX = 0
    private var lastHotY = 0

    init {
        options.putAll(VncViewerProvider.defaults())
        extraOptions?.forEach { (k, v) -> options[k] = v }
    }

    // ---- lifecycle ---------------------------------------------------------

    override fun setListener(listener: Backend.Listener?) {
        this.listener = listener
    }

    override fun setPromptHandler(handler: Prompt.Handler?) {
        this.prompts = handler
    }

    override fun connect() {
        if (state != Backend.State.IDLE) return
        state = Backend.State.CONNECTING
        onMain {
            if (!dead) fireState(Backend.State.CONNECTING, "Connecting to $address")
        }
        val err = target.error
        if (err != null) {
            closed(err)
            return
        }
        onMain { beforeStart() }
    }

    /** The one question asked before the socket opens: is an unencrypted link all right? */
    private fun beforeStart() {
        if (dead || state != Backend.State.CONNECTING) return
        if (!isTrue(VncViewerProvider.WARN_UNENCRYPTED) || acknowledged()) {
            start(password)
            return
        }
        val h = prompts
        if (h == null) {
            closed("Connection cancelled")
            return
        }
        h.trust(object : Prompt.Trust(
            address, Prompt.Trust.Encryption.UNENCRYPTED_WARN, Prompt.Trust.Identity.MISSING,
            "", "", null,
        ) {
            override fun deliver(accept: Boolean, remember: Boolean) {
                onMain {
                    if (dead || state != Backend.State.CONNECTING) return@onMain
                    if (!accept) {
                        closed("Connection cancelled")
                        return@onMain
                    }
                    if (remember) acknowledge()
                    start(password)
                }
            }
        })
    }

    /** Main thread. Opens a fresh engine; whatever was running is already over. */
    private fun start(pw: String) {
        val g = generation.incrementAndGet()
        val c = VncClient(
            target.host!!, target.port, pw, Events(g), isTrue(VncViewerProvider.SHARED),
        )
        client = c
        c.start()
    }

    private fun askPassword(wasRejected: Boolean) {
        val h = prompts
        if (h == null) {
            closed("This server needs a password.")
            return
        }
        val shownAddress = this.address
        h.credentials(object : Prompt.Credentials(
            shownAddress,
            if (wasRejected) "The password was not accepted." else "",
            false, "", true, "", "",
        ) {
            override fun deliver(ok: Boolean, userName: String?, password: String?) {
                onMain {
                    if (dead || state != Backend.State.CONNECTING) return@onMain
                    if (!ok || password.isNullOrEmpty()) {
                        closed(if (wasRejected) "Authentication failed" else "Authentication cancelled")
                        return@onMain
                    }
                    fireState(Backend.State.CONNECTING, "Connecting to $shownAddress")
                    start(password)
                }
            }
        })
    }

    override fun disconnect() {
        // Whether it is still connecting or fully up, the engine is closed and its late
        // callbacks (the reader unwinding, a half-finished handshake) are dropped by the
        // generation bump, so this is the one place that says the session is over.
        generation.incrementAndGet()
        client?.close()
        closed("Disconnected")
    }

    override fun destroy() {
        dead = true
        generation.incrementAndGet()
        val c = client
        client = null
        c?.close()
        synchronized(held) { held.clear() }
    }

    override fun state(): Backend.State = state

    // ---- options and facts -------------------------------------------------

    override fun setOption(key: String, value: String) {
        options[key] = value
        if (key == VncViewerProvider.VIEW_ONLY && viewOnly()) releaseAllKeys()
        // Everything else is read when a connection starts.
    }

    override fun viewOnly(): Boolean = isTrue(VncViewerProvider.VIEW_ONLY)

    override fun desktopWidth(): Int = desktopWidth

    override fun desktopHeight(): Int = desktopHeight

    override fun facts(): Backend.Facts = Backend.Facts(
        desktopWidth, desktopHeight, emptyList(), emptyList(), -1, false, viewOnly(), false,
    )

    override fun connectionInfo(callback: Consumer<List<ConnectionFact>>) {
        val c = client
        if (c == null || dead || state != Backend.State.CONNECTED) {
            main.post { callback.accept(emptyList()) }
            return
        }
        val facts = listOf(
            ConnectionFact.of(ConnectionFact.Field.DESKTOP_NAME, "Desktop", c.desktopName),
            ConnectionFact.of(ConnectionFact.Field.PROTOCOL, "Protocol", "RFB ${c.protocolVersion}"),
            ConnectionFact.of(
                ConnectionFact.Field.CONNECTION, "Connection", "${target.host}:${target.port} (TCP)",
            ),
            ConnectionFact.of(
                ConnectionFact.Field.SECURITY, "Security", "${c.securityName} (not encrypted)",
            ),
            ConnectionFact.of(
                ConnectionFact.Field.ENCODING, "Encoding", "ZRLE, Hextile, CopyRect, RRE, Raw",
            ),
            ConnectionFact.diagnostic(
                ConnectionFact.Field.VIEWER_PIXELS, "Viewer pixels", "32-bit true colour, depth 24",
            ),
        )
        main.post { callback.accept(facts) }
    }

    // ---- input -------------------------------------------------------------

    override fun pointer(x: Int, y: Int, buttonMask: Int) {
        val c = client
        if (c == null || dead || viewOnly()) return
        val cx = x.coerceIn(0, 0xFFFFF)
        val cy = y.coerceIn(0, 0xFFFFF)
        if (buttonMask != lastMask) {
            lastMask = buttonMask
            c.sendPointer(cx, cy, buttonMask) // ordered: a click is never dropped
        } else {
            c.sendPointerMove(cx, cy, buttonMask) // coalesced: motion may be
        }
    }

    override fun keyDown(keysym: Int, keyId: Int) {
        val c = client
        if (c == null || dead || viewOnly()) return
        val prev = synchronized(held) { held.put(keyId, keysym) }
        if (prev != null && prev != keysym) c.sendKey(prev, false)
        c.sendKey(keysym, true)
    }

    override fun keyUp(keyId: Int) {
        val keysym = synchronized(held) { held.remove(keyId) }
        val c = client
        if (keysym != null && c != null && !dead) c.sendKey(keysym, false)
    }

    override fun releaseAllKeys() {
        val keysyms = synchronized(held) {
            val copy = ArrayList(held.values)
            held.clear()
            copy
        }
        val c = client
        if (c != null && !dead) {
            for (keysym in keysyms) c.sendKey(keysym, false)
        }
    }

    override fun focus(focused: Boolean) {
        val regained = focused && !this.focused
        this.focused = focused
        val c = client
        if (regained && c != null && !dead && state == Backend.State.CONNECTED) {
            c.refresh() // whatever changed while nobody was watching
        }
        if (focused && state == Backend.State.CONNECTED) {
            val (shape, hx, hy) = synchronized(cursors) { Triple(lastShape, lastHotX, lastHotY) }
            if (shape != null) {
                onMain {
                    val l = listener
                    if (l != null && !dead) l.cursor(shape, hx, hy)
                }
            }
        }
    }

    override fun clipboardToRemote(text: String?) {
        val c = client
        if (c != null && !dead && !viewOnly() && text != null) c.sendClipboard(text)
    }

    // ---- pixels ------------------------------------------------------------

    override fun readRegion(
        x: Int, y: Int, width: Int, height: Int, dst: Bitmap, dstX: Int, dstY: Int,
    ): Boolean {
        val c = client
        if (c == null || dst.config != Bitmap.Config.ARGB_8888) return false
        return try {
            c.copyRegion(x, y, width, height, dst, dstX, dstY)
        } catch (e: RuntimeException) { // an immutable or recycled destination
            false
        }
    }

    override fun thumbnail(maxWidth: Int, maxHeight: Int): Bitmap? =
        client?.thumbnail(maxWidth, maxHeight)

    // ---- the engine's events -----------------------------------------------

    private inner class Events(private val gen: Int) : VncListener {

        private fun live(): Boolean = !dead && gen == generation.get()

        override fun onStatus(text: String) {
            if (!live()) return
            onMain {
                if (live() && state == Backend.State.CONNECTING) {
                    fireState(Backend.State.CONNECTING, text)
                }
            }
        }

        override fun onPasswordRequired(wasRejected: Boolean) {
            if (!live()) return
            onMain {
                if (live() && state == Backend.State.CONNECTING) askPassword(wasRejected)
            }
        }

        override fun onFramebufferReady(bitmap: Bitmap, desktopName: String) {
            if (!live()) return
            val w = bitmap.width
            val h = bitmap.height
            desktopWidth = w
            desktopHeight = h
            onMain {
                if (!live() || state == Backend.State.CLOSED) return@onMain
                if (state != Backend.State.CONNECTED) {
                    state = Backend.State.CONNECTED
                    fireState(Backend.State.CONNECTED, null)
                }
                listener?.desktopSize(w, h)
            }
        }

        override fun onFrameDamaged(x: Int, y: Int, w: Int, h: Int) {
            val l = listener
            if (l != null && live()) l.damaged(x, y, w, h)
        }

        override fun onFrameUpdated() {
            val l = listener
            if (l != null && live()) l.frameEnd()
        }

        override fun onCursor(argb: IntArray?, w: Int, h: Int, hotX: Int, hotY: Int) {
            if (!live()) return
            val (shape, hx, hy) = synchronized(cursors) {
                val result: Triple<Bitmap?, Int, Int> =
                    if (argb == null || w <= 0 || h <= 0) {
                        if (isTrue(VncViewerProvider.DOT_WHEN_NO_CURSOR)) {
                            Triple(dotShape(), DOT_SIZE / 2, DOT_SIZE / 2)
                        } else {
                            Triple(null, 0, 0)
                        }
                    } else {
                        Triple(cursors.shape(CursorCache.hash(argb, w, h), argb, w, h), hotX, hotY)
                    }
                lastShape = result.first
                lastHotX = result.second
                lastHotY = result.third
                result
            }
            onMain {
                val l = listener
                if (l != null && live()) l.cursor(shape, hx, hy)
            }
        }

        override fun onServerCutText(text: String) {
            if (!live()) return
            onMain {
                val l = listener
                if (l != null && live()) l.clipboardFromRemote(text)
            }
        }

        override fun onBell() {
            if (!live() || !isTrue(VncViewerProvider.ACCEPT_BELL)) return
            onMain {
                val l = listener
                if (l != null && live()) l.bell()
            }
        }

        override fun onDisconnected(error: String?) {
            if (!live()) return
            closed(error ?: "Disconnected")
        }
    }

    /** A white-ringed black dot, for a server that hides its cursor. Under [cursors]. */
    private fun dotShape(): Bitmap? {
        var d = dot
        if (d == null) {
            val px = IntArray(DOT_SIZE * DOT_SIZE)
            for (y in 0 until DOT_SIZE) {
                for (x in 0 until DOT_SIZE) {
                    val ring = x == 0 || y == 0 || x == DOT_SIZE - 1 || y == DOT_SIZE - 1
                    px[y * DOT_SIZE + x] = if (ring) -0x1 else -0x1000000 // 0xFFFFFFFF, 0xFF000000
                }
            }
            d = cursors.shape(DOT_KEY, px, DOT_SIZE, DOT_SIZE)
            dot = d
        }
        return d
    }

    // ---- plumbing ----------------------------------------------------------

    private fun isTrue(key: String): Boolean = options[key].toBoolean()

    private fun closed(detail: String) {
        onMain {
            if (state == Backend.State.CLOSED) return@onMain
            state = Backend.State.CLOSED
            fireState(Backend.State.CLOSED, detail)
        }
    }

    private fun fireState(s: Backend.State, detail: String?) {
        listener?.state(s, detail)
    }

    private fun onMain(r: () -> Unit) {
        if (Looper.myLooper() === Looper.getMainLooper()) r() else main.post { r() }
    }

    // ---- "this server may be unencrypted", remembered per address ------------

    private fun plainPrefs(): SharedPreferences =
        appContext.getSharedPreferences(PLAIN_PREFS, Context.MODE_PRIVATE)

    private fun plainKey(): String = address.trim().lowercase(Locale.ROOT)

    private fun acknowledged(): Boolean = plainPrefs().getBoolean(plainKey(), false)

    private fun acknowledge() {
        plainPrefs().edit().putBoolean(plainKey(), true).apply()
    }

    internal companion object {
        private const val PLAIN_PREFS = "vncviewer_plain_ok"
        private const val DOT_KEY = 0x646f74L
        private const val DOT_SIZE = 5

        fun forgetAcknowledged(context: Context) {
            context.applicationContext.getSharedPreferences(PLAIN_PREFS, Context.MODE_PRIVATE)
                .edit().clear().apply()
        }
    }
}
