// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later

package net.pgaskin.remotedesktop.backend.vncviewer;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Looper;

import com.vncviewer.app.vnc.VncClient;
import com.vncviewer.app.vnc.VncListener;

import net.pgaskin.remotedesktop.backend.Backend;
import net.pgaskin.remotedesktop.backend.ConnectionFact;
import net.pgaskin.remotedesktop.backend.Prompt;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;

/**
 * {@link Backend} on VncViewer's RFB engine ({@link VncClient}).
 *
 * <p>The engine owns the socket, the decoders and the framebuffer; this class
 * is the seam's half of the conversation: it turns the engine's callbacks into
 * {@link Listener} events on the right threads, asks the questions the engine
 * cannot (the password, the unencrypted-link warning) through {@link Prompt},
 * and answers {@link #readRegion} from the engine's bitmap.
 *
 * <p>An engine that needs a password has already closed its socket by the time
 * it says so, so answering the prompt starts a <em>new</em> engine. Each one
 * gets a generation number and a callback from an older one is dropped, which
 * is also what makes {@link #destroy} final.
 */
public final class VncViewerBackend implements Backend {

    private static final String PLAIN_PREFS = "vncviewer_plain_ok";

    private final Handler main = new Handler(Looper.getMainLooper());
    private final Context context;
    private final String address;
    private final String password;
    private final AddressParser target;
    private final Map<String, String> options = new ConcurrentHashMap<>();

    private volatile Listener listener;
    private volatile Prompt.Handler prompts;
    private volatile State state = State.IDLE;
    private volatile VncClient client;
    private final AtomicInteger generation = new AtomicInteger();
    private volatile boolean dead;
    private volatile int desktopWidth;
    private volatile int desktopHeight;
    private volatile int lastMask;
    private volatile boolean focused = true;

    /** Key id to the keysym pressed for it, so an up releases what the down pressed. */
    private final Map<Integer, Integer> held = new HashMap<>(); // guarded by itself

    VncViewerBackend(Context context, String address, String password,
                     Map<String, String> extraOptions) {
        this.context = context.getApplicationContext();
        this.address = address == null ? "" : address;
        this.password = password == null ? "" : password;
        this.target = AddressParser.parse(address);
        options.putAll(VncViewerProvider.defaults());
        if (extraOptions != null) {
            extraOptions.forEach((k, v) -> {
                if (k != null && v != null) {
                    options.put(k, v);
                }
            });
        }
    }

    // ---- lifecycle ---------------------------------------------------------

    @Override
    public void setListener(Listener listener) {
        this.listener = listener;
    }

    @Override
    public void setPromptHandler(Prompt.Handler handler) {
        this.prompts = handler;
    }

    @Override
    public void connect() {
        if (state != State.IDLE) {
            return;
        }
        state = State.CONNECTING;
        onMain(() -> {
            if (!dead) {
                fireState(State.CONNECTING, "Connecting to " + address);
            }
        });
        if (target.error != null) {
            closed(target.error);
            return;
        }
        onMain(this::beforeStart);
    }

    /** The one question asked before the socket opens: is an unencrypted link all right? */
    private void beforeStart() {
        if (dead || state != State.CONNECTING) {
            return;
        }
        if (!isTrue(VncViewerProvider.WARN_UNENCRYPTED) || acknowledged()) {
            start(password);
            return;
        }
        final Prompt.Handler h = prompts;
        if (h == null) {
            closed("Connection cancelled");
            return;
        }
        h.trust(new Prompt.Trust(address, Prompt.Trust.Encryption.UNENCRYPTED_WARN,
                Prompt.Trust.Identity.MISSING, "", "", null) {
            @Override
            protected void deliver(boolean accept, boolean remember) {
                onMain(() -> {
                    if (dead || state != State.CONNECTING) {
                        return;
                    }
                    if (!accept) {
                        closed("Connection cancelled");
                        return;
                    }
                    if (remember) {
                        acknowledge();
                    }
                    start(password);
                });
            }
        });
    }

    /** Main thread. Opens a fresh engine; whatever was running is already over. */
    private void start(String pw) {
        final int g = generation.incrementAndGet();
        final VncClient c = new VncClient(target.host, target.port, pw,
                new Events(g), isTrue(VncViewerProvider.SHARED));
        client = c;
        c.start();
    }

    private void askPassword(boolean wasRejected) {
        final Prompt.Handler h = prompts;
        if (h == null) {
            closed("This server needs a password.");
            return;
        }
        h.credentials(new Prompt.Credentials(address,
                wasRejected ? "The password was not accepted." : "",
                false, "", true, "", "") {
            @Override
            protected void deliver(boolean ok, String userName, String pw) {
                onMain(() -> {
                    if (dead || state != State.CONNECTING) {
                        return;
                    }
                    if (!ok || pw == null || pw.isEmpty()) {
                        closed(wasRejected ? "Authentication failed" : "Authentication cancelled");
                        return;
                    }
                    fireState(State.CONNECTING, "Connecting to " + address);
                    start(pw);
                });
            }
        });
    }

    @Override
    public void disconnect() {
        // Whether it is still connecting or fully up, the engine is closed and
        // its late callbacks (the reader unwinding, a half-finished handshake)
        // are dropped by the generation bump, so this is the one place that says
        // the session is over.
        generation.incrementAndGet();
        final VncClient c = client;
        if (c != null) {
            c.close();
        }
        closed("Disconnected");
    }

    @Override
    public void destroy() {
        dead = true;
        generation.incrementAndGet();
        final VncClient c = client;
        client = null;
        if (c != null) {
            c.close();
        }
        synchronized (held) {
            held.clear();
        }
    }

    @Override
    public State state() {
        return state;
    }

    // ---- options and facts -------------------------------------------------

    @Override
    public void setOption(String key, String value) {
        options.put(key, value);
        if (VncViewerProvider.VIEW_ONLY.equals(key) && viewOnly()) {
            releaseAllKeys();
        }
        // Everything else is read when a connection starts.
    }

    @Override
    public boolean viewOnly() {
        return isTrue(VncViewerProvider.VIEW_ONLY);
    }

    @Override
    public int desktopWidth() {
        return desktopWidth;
    }

    @Override
    public int desktopHeight() {
        return desktopHeight;
    }

    @Override
    public Facts facts() {
        return new Facts(desktopWidth, desktopHeight, List.of(), List.of(), -1,
                false, viewOnly(), false);
    }

    @Override
    public void connectionInfo(Consumer<List<ConnectionFact>> callback) {
        final VncClient c = client;
        if (c == null || dead || state != State.CONNECTED) {
            main.post(() -> callback.accept(List.of()));
            return;
        }
        final List<ConnectionFact> facts = new ArrayList<>();
        facts.add(ConnectionFact.of(ConnectionFact.Field.DESKTOP_NAME, "Desktop",
                c.getDesktopName()));
        facts.add(ConnectionFact.of(ConnectionFact.Field.PROTOCOL, "Protocol",
                "RFB " + c.getProtocolVersion()));
        facts.add(ConnectionFact.of(ConnectionFact.Field.CONNECTION, "Connection",
                target.host + ":" + target.port + " (TCP)"));
        facts.add(ConnectionFact.of(ConnectionFact.Field.SECURITY, "Security",
                c.getSecurityName() + " (not encrypted)"));
        facts.add(ConnectionFact.of(ConnectionFact.Field.ENCODING, "Encoding",
                "ZRLE, Hextile, CopyRect, RRE, Raw"));
        facts.add(ConnectionFact.diagnostic(ConnectionFact.Field.VIEWER_PIXELS,
                "Viewer pixels", "32-bit true colour, depth 24"));
        main.post(() -> callback.accept(facts));
    }

    // ---- input -------------------------------------------------------------

    @Override
    public void pointer(int x, int y, int buttonMask) {
        final VncClient c = client;
        if (c == null || dead || viewOnly()) {
            return;
        }
        final int cx = Math.max(0, Math.min(x, 0xFFFFF));
        final int cy = Math.max(0, Math.min(y, 0xFFFFF));
        if (buttonMask != lastMask) {
            lastMask = buttonMask;
            c.sendPointer(cx, cy, buttonMask); // ordered: a click is never dropped
        } else {
            c.sendPointerMove(cx, cy, buttonMask); // coalesced: motion may be
        }
    }

    @Override
    public void keyDown(int keysym, int keyId) {
        final VncClient c = client;
        if (c == null || dead || viewOnly()) {
            return;
        }
        final Integer prev;
        synchronized (held) {
            prev = held.put(keyId, keysym);
        }
        if (prev != null && prev != keysym) {
            c.sendKey(prev, false);
        }
        c.sendKey(keysym, true);
    }

    @Override
    public void keyUp(int keyId) {
        final Integer keysym;
        synchronized (held) {
            keysym = held.remove(keyId);
        }
        final VncClient c = client;
        if (keysym != null && c != null && !dead) {
            c.sendKey(keysym, false);
        }
    }

    @Override
    public void releaseAllKeys() {
        final List<Integer> keysyms;
        synchronized (held) {
            keysyms = new ArrayList<>(held.values());
            held.clear();
        }
        final VncClient c = client;
        if (c != null && !dead) {
            for (int keysym : keysyms) {
                c.sendKey(keysym, false);
            }
        }
    }

    @Override
    public void focus(boolean focused) {
        final boolean regained = focused && !this.focused;
        this.focused = focused;
        final VncClient c = client;
        if (regained && c != null && !dead && state == State.CONNECTED) {
            c.refresh(); // whatever changed while nobody was watching
        }
    }

    @Override
    public void clipboardToRemote(String text) {
        final VncClient c = client;
        if (c != null && !dead && !viewOnly() && text != null) {
            c.sendClipboard(text);
        }
    }

    // ---- pixels ------------------------------------------------------------

    @Override
    public boolean readRegion(int x, int y, int width, int height,
                              Bitmap dst, int dstX, int dstY) {
        final VncClient c = client;
        if (c == null || dst == null || dst.getConfig() != Bitmap.Config.ARGB_8888) {
            return false;
        }
        try {
            return c.copyRegion(x, y, width, height, dst, dstX, dstY);
        } catch (RuntimeException e) { // an immutable or recycled destination
            return false;
        }
    }

    @Override
    public Bitmap thumbnail(int maxWidth, int maxHeight) {
        final VncClient c = client;
        return c == null ? null : c.thumbnail(maxWidth, maxHeight);
    }

    // ---- the engine's events -----------------------------------------------

    private final class Events implements VncListener {

        private final int gen;

        Events(int gen) {
            this.gen = gen;
        }

        private boolean live() {
            return !dead && gen == generation.get();
        }

        @Override
        public void onStatus(String text) {
            if (!live()) {
                return;
            }
            onMain(() -> {
                if (live() && state == State.CONNECTING) {
                    fireState(State.CONNECTING, text);
                }
            });
        }

        @Override
        public void onPasswordRequired(boolean wasRejected) {
            if (!live()) {
                return;
            }
            onMain(() -> {
                if (live() && state == State.CONNECTING) {
                    askPassword(wasRejected);
                }
            });
        }

        @Override
        public void onFramebufferReady(Bitmap bitmap, String desktopName) {
            if (!live()) {
                return;
            }
            final int w = bitmap.getWidth();
            final int h = bitmap.getHeight();
            desktopWidth = w;
            desktopHeight = h;
            onMain(() -> {
                if (!live() || state == State.CLOSED) {
                    return;
                }
                if (state != State.CONNECTED) {
                    state = State.CONNECTED;
                    fireState(State.CONNECTED, null);
                }
                final Listener l = listener;
                if (l != null) {
                    l.desktopSize(w, h);
                }
            });
        }

        @Override
        public void onFrameDamaged(int x, int y, int w, int h) {
            final Listener l = listener;
            if (l != null && live()) {
                l.damaged(x, y, w, h);
            }
        }

        @Override
        public void onFrameUpdated() {
            final Listener l = listener;
            if (l != null && live()) {
                l.frameEnd();
            }
        }

        @Override
        public void onServerCutText(String text) {
            if (!live()) {
                return;
            }
            onMain(() -> {
                final Listener l = listener;
                if (l != null && live()) {
                    l.clipboardFromRemote(text);
                }
            });
        }

        @Override
        public void onBell() {
            if (!live() || !isTrue(VncViewerProvider.ACCEPT_BELL)) {
                return;
            }
            onMain(() -> {
                final Listener l = listener;
                if (l != null && live()) {
                    l.bell();
                }
            });
        }

        @Override
        public void onDisconnected(String error) {
            if (!live()) {
                return;
            }
            closed(error != null ? error : "Disconnected");
        }
    }

    // ---- plumbing ----------------------------------------------------------

    private boolean isTrue(String key) {
        return Boolean.parseBoolean(options.get(key));
    }

    private void closed(String detail) {
        onMain(() -> {
            if (state == State.CLOSED) {
                return;
            }
            state = State.CLOSED;
            fireState(State.CLOSED, detail);
        });
    }

    private void fireState(State s, String detail) {
        final Listener l = listener;
        if (l != null) {
            l.state(s, detail);
        }
    }

    private void onMain(Runnable r) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            r.run();
        } else {
            main.post(r);
        }
    }

    // ---- "this server may be unencrypted", remembered per address ------------

    private SharedPreferences plainPrefs() {
        return context.getSharedPreferences(PLAIN_PREFS, Context.MODE_PRIVATE);
    }

    private String plainKey() {
        return address.trim().toLowerCase(Locale.ROOT);
    }

    private boolean acknowledged() {
        return plainPrefs().getBoolean(plainKey(), false);
    }

    private void acknowledge() {
        plainPrefs().edit().putBoolean(plainKey(), true).apply();
    }

    static void forgetAcknowledged(Context context) {
        context.getApplicationContext().getSharedPreferences(PLAIN_PREFS, Context.MODE_PRIVATE)
                .edit().clear().apply();
    }
}
