// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later

package net.pgaskin.remotedesktop.backend.vncviewer;

/**
 * The address grammar every VNC backend in this app reads: {@code host},
 * {@code host:port}, {@code [literal]} or {@code [literal]:port}, with a port
 * under 100 meaning a display number ({@code :1} is 5901). An IPv6 literal must
 * be bracketed; a bare one is an error with a sentence in it, not a guess.
 *
 * <p>Also tolerated, because people paste them: a {@code vnc://} prefix, a
 * {@code user@}, a trailing path, and {@code host::port} (an absolute port, as
 * TigerVNC writes it).
 */
final class AddressParser {

    static final int DEFAULT_PORT = 5900;

    final String host;
    final int port;
    final String error;

    private AddressParser(String host, int port, String error) {
        this.host = host;
        this.port = port;
        this.error = error;
    }

    private static AddressParser fail(String error) {
        return new AddressParser(null, 0, error);
    }

    static AddressParser parse(String input) {
        String s = input == null ? "" : input.trim();
        final int scheme = s.indexOf("://");
        if (scheme >= 0) {
            s = s.substring(scheme + 3);
        }
        final int slash = s.indexOf('/');
        if (slash >= 0) {
            s = s.substring(0, slash);
        }
        final int at = s.lastIndexOf('@');
        if (at >= 0) {
            s = s.substring(at + 1);
        }
        if (s.isEmpty()) {
            return fail("Enter the address of a VNC server.");
        }

        final String host;
        String portSpec = null;
        boolean absolute = false;

        if (s.startsWith("[")) {
            final int end = s.indexOf(']');
            if (end < 2) {
                return fail("Invalid address: unmatched [ in " + s);
            }
            host = s.substring(1, end);
            final String rest = s.substring(end + 1);
            if (rest.startsWith("::")) {
                portSpec = rest.substring(2);
                absolute = true;
            } else if (rest.startsWith(":")) {
                portSpec = rest.substring(1);
            } else if (!rest.isEmpty()) {
                return fail("Invalid address: unexpected text after ].");
            }
        } else {
            int colons = 0;
            for (int i = 0; i < s.length(); i++) {
                if (s.charAt(i) == ':') {
                    colons++;
                }
            }
            final int dbl = s.indexOf("::");
            if (colons == 0) {
                host = s;
            } else if (colons == 1) {
                final int idx = s.indexOf(':');
                host = s.substring(0, idx);
                portSpec = s.substring(idx + 1);
            } else if (colons == 2 && dbl > 0 && dbl + 2 < s.length()
                    && s.substring(dbl + 2).chars().allMatch(Character::isDigit)
                    // "fe80::1" is an IPv6 literal, not host "fe80" on port 1: a host
                    // made only of hex digits and colons is read as the former.
                    && s.substring(0, dbl).chars().anyMatch(c -> Character.digit(c, 16) < 0)) {
                host = s.substring(0, dbl);
                portSpec = s.substring(dbl + 2);
                absolute = true;
            } else {
                return fail("An IPv6 address must be written in brackets, "
                        + "like [fe80::1] or [fe80::1]:5900.");
            }
        }

        if (host.isBlank() || host.chars().anyMatch(Character::isWhitespace)) {
            return fail("Invalid host in address.");
        }

        int port = DEFAULT_PORT;
        if (portSpec != null) {
            if (portSpec.isEmpty() || portSpec.length() > 5
                    || !portSpec.chars().allMatch(c -> c >= '0' && c <= '9')) {
                return fail("Invalid port in address.");
            }
            final int n = Integer.parseInt(portSpec);
            port = !absolute && n < 100 ? DEFAULT_PORT + n : n;
        }
        if (port < 1 || port > 65535) {
            return fail("Invalid port in address.");
        }
        return new AddressParser(host, port, null);
    }
}
