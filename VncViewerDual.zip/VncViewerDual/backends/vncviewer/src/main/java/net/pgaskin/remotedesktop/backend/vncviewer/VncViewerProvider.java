// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later

package net.pgaskin.remotedesktop.backend.vncviewer;

import android.content.Context;

import net.pgaskin.remotedesktop.backend.Backend;
import net.pgaskin.remotedesktop.backend.BackendOption;
import net.pgaskin.remotedesktop.backend.BackendOption.Scope;
import net.pgaskin.remotedesktop.backend.BackendProvider;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * The open-source engine: VncViewer's own RFB client, as a backend.
 *
 * <p>Everything here describes what that client really does and nothing it
 * does not: no quality presets, because it always asks for the same
 * encodings; no encryption setting, because RFB's None and VNC password
 * security types have none.
 */
public final class VncViewerProvider implements BackendProvider {

    static final String VIEW_ONLY = "ViewOnly";
    static final String SHARED = "Shared";
    static final String WARN_UNENCRYPTED = "WarnUnencrypted";
    static final String ACCEPT_BELL = "AcceptBell";

    private static final List<BackendOption> OPTIONS = List.of(
            // ---- per connection ---------------------------------------------
            BackendOption.bool(VIEW_ONLY, "View only",
                    "Do not send input or clipboard events.",
                    false, Scope.CONNECTION, true),
            BackendOption.bool(SHARED, "Shared",
                    "Do not ask the server to disconnect other clients.",
                    true, Scope.CONNECTION, false),

            // ---- per backend -------------------------------------------------
            BackendOption.bool(WARN_UNENCRYPTED, "Warn when unencrypted",
                    "Ask before connecting, once per server. RFB's None and VNC password "
                            + "security do not encrypt the session, so this applies to every "
                            + "connection made with this backend; tunnel it (VPN, SSH) or use "
                            + "RealVNC for an encrypted one.",
                    true, Scope.GLOBAL, false),
            BackendOption.bool(ACCEPT_BELL, "Bell",
                    "Vibrate when the remote server rings the bell.",
                    true, Scope.GLOBAL, false));

    @Override
    public String id() {
        return "vncviewer";
    }

    @Override
    public String name() {
        return "VNC (built-in)";
    }

    @Override
    public String shortName() {
        return "VNC";
    }

    @Override
    public String description() {
        return "The open-source VNC client built into this app (from VncViewer). "
                + "RFB 3.3, 3.7 and 3.8 with No authentication or VNC password, and the "
                + "ZRLE, Hextile, CopyRect, RRE and Raw encodings. Nothing proprietary and no "
                + "native code, but no encryption, UDP or RealVNC account sign-in: use RealVNC "
                + "for those, and for the best performance against a RealVNC server.";
    }

    @Override
    public int order() {
        return 20;
    }

    @Override
    public List<BackendOption> options() {
        return OPTIONS;
    }

    @Override
    public Backend create(Context context, String address, String userName, String password,
                          Map<String, String> options) {
        return new VncViewerBackend(context, address, password, options);
    }

    @Override
    public void forgetHosts(Context context) {
        VncViewerBackend.forgetAcknowledged(context);
    }

    static Map<String, String> defaults() {
        final Map<String, String> m = new LinkedHashMap<>();
        for (BackendOption o : OPTIONS) {
            m.put(o.key(), o.defaultValue());
        }
        return m;
    }
}
