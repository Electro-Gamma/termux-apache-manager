// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later

package net.pgaskin.remotedesktop.backend.vncviewer

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class AddressParserTest {

    private fun ok(input: String, host: String, port: Int) {
        val p = AddressParser.parse(input)
        assertNull(input, p.error)
        assertEquals(input, host, p.host)
        assertEquals(input, port, p.port)
    }

    private fun bad(input: String) {
        assertNotNull("should reject '$input'", AddressParser.parse(input).error)
    }

    @Test
    fun hostsAndPorts() {
        ok("192.168.1.10", "192.168.1.10", 5900)
        ok("192.168.1.10:1", "192.168.1.10", 5901) // a display
        ok("host:5902", "host", 5902)
        ok("host:99", "host", 5999)
        ok("host:100", "host", 100) // 100 and up is a port
        ok("host::1", "host", 1) // absolute
        ok("10.0.0.5::5901", "10.0.0.5", 5901)
        ok("vnc://user@host:3", "host", 5903)
        ok(" host:5900/path ", "host", 5900)
    }

    @Test
    fun bracketedIpv6() {
        ok("[fe80::1]", "fe80::1", 5900)
        ok("[fe80::1]:2", "fe80::1", 5902)
        ok("[fe80::1]::5900", "fe80::1", 5900)
    }

    @Test
    fun rejects() {
        bad("")
        bad("fe80::1") // a bare literal is an error, not host "fe80" on port 1
        bad("beef::1")
        bad("fe80::1:5900")
        bad("host:abc")
        bad("host:70000")
        bad("host:")
        bad("[::1")
        bad("[::1]x")
        bad("a b")
    }
}
