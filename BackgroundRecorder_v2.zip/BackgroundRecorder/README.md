# Background Recorder

A professional-grade Android application for continuous, background video
and audio recording — Kotlin, MVVM, Hilt, CameraX + Camera2 interop,
Coroutines/StateFlow, Room, DataStore, and a genuine foreground-service
recording pipeline that survives the screen turning off, the app being
minimized, and device rotation.

This README covers what's here, how it's organized, and how to build it.
For the full feature-by-feature implementation status (what's fully wired
up vs. a documented platform limitation vs. an extension point), see
**[ARCHITECTURE.md](ARCHITECTURE.md)** — please read that before assuming
any single bullet from the original spec is 100% implemented; a few
audio/codec controls hit genuine Android platform ceilings, and that
document explains exactly which ones and why, rather than shipping code
that silently pretends to do something it can't.

## Requirements

- Android Studio Ladybug (2024.2) or newer
- JDK 17
- Android SDK Platform 35, Build-Tools 35.x
- A device or emulator running API 26+ (Android 8.0+)

## Getting started (Android Studio)

1. Open the project root (`BackgroundRecorder/`) in Android Studio.
2. Let Gradle sync (it will download CameraX, Hilt, Room, DataStore, etc.
   the first time — needs network access).
3. Run the `app` configuration on a device/emulator with API 26+.
4. On first launch you'll be asked to grant Camera, Microphone and (on
   Android 13+) Notification permissions — required before recording can
   start at all.

## Getting started (Google Colab — headless APK build)

A ready-to-run Colab notebook (`BackgroundRecorder_Build.ipynb`) is
provided alongside this project. It installs a JDK, the Android command
line tools, and Gradle inside the Colab VM, builds a debug APK from this
source tree, and gives you a download link — no local Android Studio
required. See the notebook's own markdown cells for step-by-step
instructions; in short: upload the project zip, run all cells, download
`app-debug.apk` at the end.

## Project structure

```
app/src/main/java/com/bgrecorder/app/
├── camera/        CameraX + Camera2-interop pipeline, USB detection, audio-only engine
├── data/
│   ├── local/     Room database (recordings, schedules) + DataStore settings
│   ├── model/     Plain Kotlin data classes / enums shared across all layers
│   └── repository/ Single source of truth per concern, used by ViewModels & the service
├── di/            Hilt modules
├── overlay/       Floating recording-controls service (SYSTEM_ALERT_WINDOW)
├── schedule/      AlarmManager-based scheduling engine
├── service/       The foreground RecordingService + notification + receivers
├── ui/            One package per screen: record, files, schedule, settings, permissions
├── widget/        Home-screen Quick-Start App Widget
└── work/          WorkManager housekeeping (auto-delete old recordings)
```

Every class carries a doc comment explaining *why* it's shaped the way it
is, not just what it does — especially around the trickier parts (the
service/UI camera-binding handoff, the audio-effects pipeline, alarm-based
scheduling). Start with `CameraController.kt` and `RecordingService.kt` if
you want the architectural heart of the app.

## Key architectural decisions

- **MVVM throughout**: Fragments only render state and forward user
  intent; all logic lives in `@HiltViewModel`s or repositories.
- **Single source of truth for recording state**: `RecordingSessionState`
  is a `@Singleton` holding a `StateFlow<RecordingState>`, written only by
  `RecordingService`, read by every ViewModel/UI surface that cares. This
  is what lets the UI reflect an in-progress background recording without
  binding to the service.
- **Camera binding lives on the service's lifecycle**, not the
  Activity/Fragment's — this is *the* reason recording survives the app
  being backgrounded. The UI re-attaches its `PreviewView` surface to the
  already-bound `Preview` use case (see `CameraController.attachPreviewSurface`)
  instead of ever re-binding while a recording is active, which would tear
  it down.
- **Two recording engines**: a CameraX `Recorder` pipeline for video (+
  audio) and a `MediaRecorder`-based pipeline for audio-only recording. The
  latter exists specifically because `MediaRecorder` exposes a real audio
  session id, which is what makes genuine noise suppression / echo
  cancellation / AGC possible — CameraX's video `Recorder` does not expose
  this. See ARCHITECTURE.md for the full rationale.

## Permissions

Requested with rationale, gracefully degrading:

| Permission | Why |
|---|---|
| `CAMERA` | Video preview & recording |
| `RECORD_AUDIO` | Audio capture (video and audio-only modes) |
| `POST_NOTIFICATIONS` (13+) | Persistent recording-status notification |
| `FOREGROUND_SERVICE_CAMERA` / `_MICROPHONE` (14+) | Required FGS types for a camera/mic-using foreground service |
| `SCHEDULE_EXACT_ALARM` / `USE_EXACT_ALARM` | Precise schedule timing |
| `SYSTEM_ALERT_WINDOW` | Optional floating controls |
| `WRITE_EXTERNAL_STORAGE` (≤28 only) | Legacy storage write path |

## License

Provided as-is for evaluation/educational use.
