package com.bgrecorder.app.data.model

/**
 * Logical camera selection exposed to the user. [USB_EXTERNAL] represents a
 * connected UVC-class USB camera; see [com.bgrecorder.app.camera.UsbCameraDetector]
 * for detection. Actually *driving* a USB UVC camera requires a userspace UVC
 * driver (not part of the public CameraX/Camera2 surface) - this app detects
 * and lists such devices and routes to a pluggable [com.bgrecorder.app.camera.UsbCameraProvider]
 * extension point, documented in ARCHITECTURE.md.
 */
enum class CameraFacing {
    FRONT,
    BACK,
    USB_EXTERNAL
}
