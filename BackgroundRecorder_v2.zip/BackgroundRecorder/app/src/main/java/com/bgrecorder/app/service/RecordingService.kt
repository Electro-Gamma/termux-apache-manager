package com.bgrecorder.app.service

import android.app.Notification
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.MediaMetadataRetriever
import android.os.Build
import android.os.PowerManager
import androidx.camera.video.VideoRecordEvent
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import com.bgrecorder.app.camera.AudioOnlyRecorderEngine
import com.bgrecorder.app.camera.CameraController
import com.bgrecorder.app.data.local.db.RecordingEntity
import com.bgrecorder.app.data.model.AppSettings
import com.bgrecorder.app.data.model.CameraFacing
import com.bgrecorder.app.data.model.FrameRate
import com.bgrecorder.app.data.model.RecordingMode
import com.bgrecorder.app.data.model.RecordingState
import com.bgrecorder.app.data.model.VideoQuality
import com.bgrecorder.app.data.repository.RecordingRepository
import com.bgrecorder.app.data.repository.SettingsRepository
import com.bgrecorder.app.data.repository.StorageRepository
import com.bgrecorder.app.util.RecordingError
import com.bgrecorder.app.util.StorageUtils
import com.bgrecorder.app.util.BatteryUtils
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * The foreground service that owns every active recording session.
 *
 * Design notes (mapping directly to the "Background Recording" spec):
 *  - Runs as a genuine foreground service with `camera|microphone` types
 *    declared in the manifest, so recording continues correctly with the
 *    screen off or the app minimized/backgrounded (Android does not throttle
 *    or kill a properly-declared foreground service for this).
 *  - Survives device rotation because the service (and the CameraX/MediaRecorder
 *    session it owns) is completely independent of any Activity's lifecycle -
 *    rotating just re-creates the UI, which re-attaches to [RecordingSessionState].
 *  - Holds a partial [PowerManager.WakeLock] for the duration of the
 *    recording so CPU work (encoding, file writes) isn't suspended by Doze.
 *  - "Automatic recovery after temporary interruptions where permitted":
 *    a bounded number of retries is attempted when CameraX reports a
 *    recoverable error (e.g. the camera was briefly reclaimed by another
 *    app). Recovering an in-flight encode session across an actual OS
 *    process kill is not possible on Android (the encoder/session state
 *    does not survive process death) - this limitation is inherent to the
 *    platform, not specific to this app, and is documented in ARCHITECTURE.md.
 */
@AndroidEntryPoint
class RecordingService : LifecycleService() {

    @Inject lateinit var cameraController: CameraController
    @Inject lateinit var audioEngine: AudioOnlyRecorderEngine
    @Inject lateinit var sessionState: RecordingSessionState
    @Inject lateinit var settingsRepository: SettingsRepository
    @Inject lateinit var recordingRepository: RecordingRepository
    @Inject lateinit var storageRepository: StorageRepository
    @Inject lateinit var notificationHelper: NotificationHelper

    private var wakeLock: PowerManager.WakeLock? = null
    private var activeMode: RecordingMode = RecordingMode.VIDEO
    private var activeSettings: AppSettings = AppSettings()
    private var recordingStartedAt: Long = 0L
    private var outputName: String = ""
    private var isStopping = false
    private var isSplitting = false
    private var retryCount = 0
    private var lowBatteryWarned = false

    private var monitorJob: Job? = null
    private var audioTickerJob: Job? = null

    override fun onCreate() {
        super.onCreate()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        when (intent?.action) {
            ACTION_START -> handleStart(intent)
            ACTION_PAUSE -> handlePause()
            ACTION_RESUME -> handleResume()
            ACTION_STOP -> handleStop()
            else -> {
                // No known action (e.g. service restarted by the system with a
                // null intent). There is no in-flight encoder session to resume
                // across process death, so we simply shut down cleanly.
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    // -------------------------------------------------------------------
    // START
    // -------------------------------------------------------------------

    private fun handleStart(intent: Intent) {
        activeMode = intent.getStringExtra(EXTRA_MODE)?.let(RecordingMode::valueOf) ?: RecordingMode.VIDEO
        sessionState.setActiveMode(activeMode)
        sessionState.update(RecordingState.Starting)
        promoteToForeground(notificationHelper.build(this, RecordingState.Starting))
        acquireWakeLock()
        isStopping = false
        retryCount = 0

        lifecycleScope.launch {
            val settings = settingsRepository.settings.value
            activeSettings = applyOverrides(settings, intent)
            when (activeMode) {
                RecordingMode.VIDEO -> beginVideoSegment()
                RecordingMode.AUDIO_ONLY -> beginAudioSegment()
            }
            startPeriodicMonitor()
        }
    }

    private fun applyOverrides(settings: AppSettings, intent: Intent): AppSettings {
        val facing = intent.getStringExtra(EXTRA_FACING)?.let(CameraFacing::valueOf) ?: settings.defaultCameraFacing
        val quality = intent.getStringExtra(EXTRA_QUALITY)?.let(VideoQuality::valueOf) ?: settings.defaultQuality
        val frameRate = intent.getStringExtra(EXTRA_FRAME_RATE)?.let(FrameRate::valueOf) ?: settings.defaultFrameRate
        val bitrate = if (intent.hasExtra(EXTRA_BITRATE)) intent.getIntExtra(EXTRA_BITRATE, settings.customBitrateBps)
        else (settings.defaultBitratePreset.bps ?: settings.customBitrateBps)
        return settings.copy(
            defaultCameraFacing = facing,
            defaultQuality = quality,
            defaultFrameRate = frameRate,
            customBitrateBps = bitrate
        )
    }

    private suspend fun beginVideoSegment() {
        cameraController.initialize(this)
        cameraController.bind(
            context = this,
            lifecycleOwner = this,
            previewView = null, // headless: no UI surface while running purely in the background
            facing = activeSettings.defaultCameraFacing,
            quality = activeSettings.defaultQuality,
            frameRate = activeSettings.defaultFrameRate,
            bitrateBps = activeSettings.customBitrateBps
        )
        val outputTarget = storageRepository.resolveOutputTarget(
            RecordingMode.VIDEO, activeSettings.fileNamingTemplate,
            activeSettings.storageLocation, activeSettings.customTreeUri
        )
        outputName = displayNameOf(outputTarget)
        val started = cameraController.startRecording(
            context = this,
            outputTarget = outputTarget,
            withAudio = true,
            executor = ContextCompat.getMainExecutor(this)
        ) { event -> handleVideoEvent(event) }

        if (!started) {
            failWith(RecordingError.CameraUnavailable)
        }
    }

    private fun beginAudioSegment() {
        val outputTarget = storageRepository.resolveOutputTarget(
            RecordingMode.AUDIO_ONLY, activeSettings.fileNamingTemplate,
            activeSettings.storageLocation, activeSettings.customTreeUri
        )
        outputName = displayNameOf(outputTarget)
        val ok = audioEngine.start(this, outputTarget, activeSettings)
        if (!ok) {
            failWith(RecordingError.MicUnavailable)
            return
        }
        recordingStartedAt = System.currentTimeMillis()
        sessionState.update(RecordingState.Recording(recordingStartedAt, 0L, 0L, outputName))
        updateNotification()
        startAudioTicker()
    }

    private fun startAudioTicker() {
        audioTickerJob?.cancel()
        audioTickerJob = lifecycleScope.launch {
            while (audioEngine.isActive()) {
                if (!audioEngine.isPausedState()) {
                    val elapsed = System.currentTimeMillis() - recordingStartedAt
                    val bytes = audioEngine.currentFileBytes()
                    sessionState.update(RecordingState.Recording(recordingStartedAt, elapsed, bytes, outputName))
                    updateNotification()
                    checkLimits(elapsed, bytes)
                }
                delay(1000)
            }
        }
    }

    // -------------------------------------------------------------------
    // Video event handling (CameraX Recorder callbacks)
    // -------------------------------------------------------------------

    private fun handleVideoEvent(event: VideoRecordEvent) {
        when (event) {
            is VideoRecordEvent.Start -> {
                recordingStartedAt = System.currentTimeMillis()
                sessionState.update(RecordingState.Recording(recordingStartedAt, 0L, 0L, outputName))
                updateNotification()
            }
            is VideoRecordEvent.Status -> {
                val stats = event.recordingStats
                val elapsedMs = stats.recordedDurationNanos / 1_000_000
                sessionState.update(RecordingState.Recording(recordingStartedAt, elapsedMs, stats.numBytesRecorded, outputName))
                updateNotification()
                checkLimits(elapsedMs, stats.numBytesRecorded)
            }
            is VideoRecordEvent.Pause -> {
                val stats = event.recordingStats
                sessionState.update(
                    RecordingState.Paused(recordingStartedAt, stats.recordedDurationNanos / 1_000_000, stats.numBytesRecorded, outputName)
                )
                updateNotification()
            }
            is VideoRecordEvent.Resume -> {
                val stats = event.recordingStats
                sessionState.update(
                    RecordingState.Recording(recordingStartedAt, stats.recordedDurationNanos / 1_000_000, stats.numBytesRecorded, outputName)
                )
                updateNotification()
            }
            is VideoRecordEvent.Finalize -> handleVideoFinalize(event)
        }
    }

    private fun handleVideoFinalize(event: VideoRecordEvent.Finalize) {
        if (event.hasError()) {
            val error = mapCameraXError(event.error)
            if (error.recoverable && retryCount < MAX_RETRIES && !isStopping) {
                retryCount++
                lifecycleScope.launch {
                    delay(RETRY_BACKOFF_MS)
                    beginVideoSegment()
                }
                return
            }
            failWith(error)
            return
        }

        retryCount = 0
        val stats = event.recordingStats
        lifecycleScope.launch { persistRecording(event.outputResults.outputUri.toString(), stats.recordedDurationNanos / 1_000_000, stats.numBytesRecorded) }

        if (isSplitting) {
            isSplitting = false
            lifecycleScope.launch { beginVideoSegment() }
            return
        }
        if (isStopping) {
            finishAndStopSelf()
        }
    }

    private fun mapCameraXError(errorCode: Int): RecordingError = when (errorCode) {
        VideoRecordEvent.Finalize.ERROR_INSUFFICIENT_STORAGE -> RecordingError.StorageFull
        VideoRecordEvent.Finalize.ERROR_SOURCE_INACTIVE -> RecordingError.CameraUnavailable
        VideoRecordEvent.Finalize.ERROR_ENCODING_FAILED -> RecordingError.EncoderFailure
        VideoRecordEvent.Finalize.ERROR_RECORDER_ERROR -> RecordingError.EncoderFailure
        VideoRecordEvent.Finalize.ERROR_NO_VALID_DATA -> RecordingError.WriteFailed()
        else -> RecordingError.Unknown()
    }

    // -------------------------------------------------------------------
    // PAUSE / RESUME / STOP
    // -------------------------------------------------------------------

    private fun handlePause() {
        when (activeMode) {
            RecordingMode.VIDEO -> cameraController.pauseRecording()
            RecordingMode.AUDIO_ONLY -> audioEngine.pause()
        }
    }

    private fun handleResume() {
        when (activeMode) {
            RecordingMode.VIDEO -> cameraController.resumeRecording()
            RecordingMode.AUDIO_ONLY -> audioEngine.resume()
        }
    }

    private fun handleStop() {
        isStopping = true
        sessionState.update(RecordingState.Stopping)
        when (activeMode) {
            RecordingMode.VIDEO -> cameraController.stopRecording()
            RecordingMode.AUDIO_ONLY -> {
                val uri = audioEngine.stop()
                val elapsed = System.currentTimeMillis() - recordingStartedAt
                if (uri != null) {
                    lifecycleScope.launch { persistRecording(uri.toString(), elapsed, audioEngine.currentFileBytes()) }
                }
                finishAndStopSelf()
            }
        }
    }

    /** Stops the current segment and immediately begins a new one (auto-split / max-size rollover). */
    private fun splitVideoSegment() {
        if (activeMode != RecordingMode.VIDEO) return
        isSplitting = true
        cameraController.stopRecording()
    }

    private fun finishAndStopSelf() {
        monitorJob?.cancel()
        audioTickerJob?.cancel()
        cameraController.unbind()
        releaseWakeLock()
        sessionState.update(RecordingState.Idle)
        sessionState.setActiveMode(null)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun failWith(error: RecordingError) {
        sessionState.update(RecordingState.Error(error))
        finishAndStopSelf()
    }

    // -------------------------------------------------------------------
    // Limits, storage & battery monitoring
    // -------------------------------------------------------------------

    private fun displayNameOf(target: StorageRepository.OutputTarget): String = when (target) {
        is StorageRepository.OutputTarget.MediaStoreTarget ->
            target.values.getAsString(android.provider.MediaStore.MediaColumns.DISPLAY_NAME) ?: ""
        is StorageRepository.OutputTarget.SafTarget -> target.documentFile.name ?: ""
    }

    private fun checkLimits(elapsedMs: Long, bytes: Long) {
        val maxDurationMs = activeSettings.maxDurationMinutes * 60_000L
        val maxSizeBytes = activeSettings.maxFileSizeMb * 1024L * 1024L
        val durationCapHit = activeSettings.maxDurationMinutes > 0 && elapsedMs >= maxDurationMs
        val sizeCapHit = activeSettings.maxFileSizeMb > 0 && bytes >= maxSizeBytes

        // Auto-split rolls the *current* segment over to a fresh output file
        // once it reaches the configured interval. Each new segment's own
        // elapsed time naturally restarts from 0 (a new VideoRecordEvent.Start
        // fires), so comparing this segment's elapsedMs against the interval
        // is sufficient - no separate "time since last split" bookkeeping needed.
        val splitIntervalMs = activeSettings.autoSplitIntervalMinutes * 60_000L
        val splitIntervalHit = activeMode == RecordingMode.VIDEO && activeSettings.autoSplitEnabled &&
            activeSettings.autoSplitIntervalMinutes > 0 && elapsedMs >= splitIntervalMs

        when {
            (durationCapHit || sizeCapHit) && activeSettings.autoSplitEnabled && activeMode == RecordingMode.VIDEO ->
                splitVideoSegment()
            durationCapHit || sizeCapHit -> handleStop()
            splitIntervalHit -> splitVideoSegment()
        }
    }

    private fun startPeriodicMonitor() {
        monitorJob?.cancel()
        monitorJob = lifecycleScope.launch {
            while (true) {
                delay(5000)
                if (StorageUtils.isStorageLow(this@RecordingService)) {
                    failWith(RecordingError.StorageFull)
                    break
                }
                val level = BatteryUtils.batteryLevelPercent(this@RecordingService)
                if (!lowBatteryWarned && level in 0..activeSettings.lowBatteryWarningThreshold &&
                    !BatteryUtils.isCharging(this@RecordingService)
                ) {
                    lowBatteryWarned = true
                    postLowBatteryAlert(level)
                }
            }
        }
    }

    private fun postLowBatteryAlert(level: Int) {
        val notification = androidx.core.app.NotificationCompat.Builder(this, com.bgrecorder.app.BgRecorderApplication.CHANNEL_ALERTS)
            .setSmallIcon(com.bgrecorder.app.R.drawable.ic_notif_battery)
            .setContentTitle(getString(com.bgrecorder.app.R.string.notif_low_battery_title))
            .setContentText(getString(com.bgrecorder.app.R.string.notif_low_battery_text, level))
            .setAutoCancel(true)
            .build()
        androidx.core.app.NotificationManagerCompat.from(this).apply {
            if (androidx.core.content.ContextCompat.checkSelfPermission(this@RecordingService, android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED || Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
                notify(NotificationHelper.ALERT_NOTIFICATION_ID, notification)
            }
        }
    }

    // -------------------------------------------------------------------
    // Persistence
    // -------------------------------------------------------------------

    private suspend fun persistRecording(uriString: String, durationMs: Long, bytes: Long) {
        var width = 0
        var height = 0
        if (activeMode == RecordingMode.VIDEO) {
            runCatching {
                val retriever = MediaMetadataRetriever()
                retriever.setDataSource(this, android.net.Uri.parse(uriString))
                width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
                height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
                retriever.release()
            }
        }
        recordingRepository.add(
            RecordingEntity(
                displayName = outputName.ifBlank { uriString.substringAfterLast('/') },
                uri = uriString,
                mode = activeMode,
                sizeBytes = bytes,
                durationMillis = durationMs,
                width = width,
                height = height,
                createdAtMillis = System.currentTimeMillis()
            )
        )
    }

    // -------------------------------------------------------------------
    // Foreground / wake lock plumbing
    // -------------------------------------------------------------------

    private fun promoteToForeground(notification: Notification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val type = ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            startForeground(NotificationHelper.NOTIFICATION_ID, notification, type)
        } else {
            startForeground(NotificationHelper.NOTIFICATION_ID, notification)
        }
    }

    private fun updateNotification() {
        val state = sessionState.state.value
        val notification = notificationHelper.build(this, state)
        androidx.core.app.NotificationManagerCompat.from(this).apply {
            if (ContextCompat.checkSelfPermission(this@RecordingService, android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED || Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
                notify(NotificationHelper.NOTIFICATION_ID, notification)
            }
        }
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "$packageName:RecordingWakeLock").apply {
            setReferenceCounted(false)
            acquire(MAX_WAKE_LOCK_MS)
        }
    }

    private fun releaseWakeLock() {
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // Deliberately NOT stopping the recording here: a foreground service
        // with a visible, ongoing notification is explicitly allowed (and
        // expected) to keep running after the app's task is swiped away from
        // Recents. This is exactly the "recording while app is minimized"
        // requirement.
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        monitorJob?.cancel()
        audioTickerJob?.cancel()
        releaseWakeLock()
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.bgrecorder.app.action.START"
        const val ACTION_PAUSE = "com.bgrecorder.app.action.PAUSE"
        const val ACTION_RESUME = "com.bgrecorder.app.action.RESUME"
        const val ACTION_STOP = "com.bgrecorder.app.action.STOP"

        const val EXTRA_MODE = "extra_mode"
        const val EXTRA_FACING = "extra_facing"
        const val EXTRA_QUALITY = "extra_quality"
        const val EXTRA_FRAME_RATE = "extra_frame_rate"
        const val EXTRA_BITRATE = "extra_bitrate"

        private const val MAX_RETRIES = 2
        private const val RETRY_BACKOFF_MS = 1500L
        private const val MAX_WAKE_LOCK_MS = 12L * 60 * 60 * 1000 // 12h safety cap
    }
}
