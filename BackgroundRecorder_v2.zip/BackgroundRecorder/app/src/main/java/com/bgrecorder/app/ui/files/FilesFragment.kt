package com.bgrecorder.app.ui.files

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.PopupMenu
import android.widget.SearchView
import androidx.core.view.MenuHost
import androidx.core.view.MenuProvider
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.bgrecorder.app.R
import com.bgrecorder.app.data.model.FilterType
import com.bgrecorder.app.data.model.RecordingItem
import com.bgrecorder.app.data.model.RecordingMode
import com.bgrecorder.app.data.model.SortOrder
import com.bgrecorder.app.databinding.FragmentFilesBinding
import com.bgrecorder.app.util.RecordingFileOps
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

/**
 * Lists every recording (video + audio), with search, sort and filter, plus
 * per-item playback, rename, share, export and delete.
 */
@AndroidEntryPoint
class FilesFragment : Fragment(R.layout.fragment_files) {

    private val viewModel: FilesViewModel by viewModels()
    private var binding: FragmentFilesBinding? = null
    private lateinit var adapter: RecordingsAdapter

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val b = FragmentFilesBinding.bind(view)
        binding = b

        adapter = RecordingsAdapter(
            onClick = { item -> playRecording(item) },
            onOverflow = { item, anchor -> showOverflowMenu(item, anchor) }
        )
        b.recyclerRecordings.layoutManager = LinearLayoutManager(requireContext())
        b.recyclerRecordings.adapter = adapter
        b.swipeRefresh.setOnRefreshListener { b.swipeRefresh.isRefreshing = false }

        setupMenu()
        observeRecordings(b)
    }

    private fun setupMenu() {
        (requireActivity() as MenuHost).addMenuProvider(object : MenuProvider {
            override fun onCreateMenu(menu: Menu, menuInflater: MenuInflater) {
                menuInflater.inflate(R.menu.files_menu, menu)
                val searchItem = menu.findItem(R.id.action_search)
                (searchItem.actionView as? SearchView)?.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
                    override fun onQueryTextSubmit(query: String?) = true
                    override fun onQueryTextChange(newText: String?): Boolean {
                        viewModel.setSearchQuery(newText.orEmpty())
                        return true
                    }
                })
            }

            override fun onMenuItemSelected(menuItem: MenuItem): Boolean = when (menuItem.itemId) {
                R.id.action_sort -> { showSortMenu(); true }
                R.id.action_filter -> { showFilterMenu(); true }
                else -> false
            }
        }, viewLifecycleOwner, Lifecycle.State.RESUMED)
    }

    private fun showSortMenu() {
        val options = arrayOf(
            SortOrder.DATE_NEWEST to getString(R.string.sort_date_newest),
            SortOrder.DATE_OLDEST to getString(R.string.sort_date_oldest),
            SortOrder.SIZE_LARGEST to getString(R.string.sort_size_largest),
            SortOrder.SIZE_SMALLEST to getString(R.string.sort_size_smallest),
            SortOrder.NAME to getString(R.string.sort_name)
        )
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.action_sort)
            .setItems(options.map { it.second }.toTypedArray()) { _, index -> viewModel.setSortOrder(options[index].first) }
            .show()
    }

    private fun showFilterMenu() {
        val options = arrayOf(
            FilterType.ALL to getString(R.string.filter_all),
            FilterType.VIDEO to getString(R.string.filter_video),
            FilterType.AUDIO to getString(R.string.filter_audio)
        )
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.action_filter)
            .setItems(options.map { it.second }.toTypedArray()) { _, index -> viewModel.setFilterType(options[index].first) }
            .show()
    }

    private fun observeRecordings(b: FragmentFilesBinding) {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.recordings.collect { list ->
                    adapter.submitList(list)
                    b.emptyState.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
                }
            }
        }
    }

    private fun playRecording(item: RecordingItem) {
        val mime = if (item.mode == RecordingMode.VIDEO) "video/*" else "audio/*"
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(Uri.parse(item.uri), mime)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        runCatching { startActivity(intent) }
    }

    private fun shareRecording(item: RecordingItem) {
        val mime = if (item.mode == RecordingMode.VIDEO) "video/*" else "audio/*"
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, Uri.parse(item.uri))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, getString(R.string.action_share)))
    }

    private fun showOverflowMenu(item: RecordingItem, anchor: View) {
        val popup = PopupMenu(requireContext(), anchor)
        popup.menuInflater.inflate(R.menu.recording_item_menu, popup.menu)
        popup.setOnMenuItemClickListener { menuItem ->
            when (menuItem.itemId) {
                R.id.action_play -> { playRecording(item); true }
                R.id.action_share, R.id.action_export -> { shareRecording(item); true }
                R.id.action_rename -> { showRenameDialog(item); true }
                R.id.action_delete -> { showDeleteConfirmation(item); true }
                else -> false
            }
        }
        popup.show()
    }

    private fun showRenameDialog(item: RecordingItem) {
        val input = EditText(requireContext()).apply { setText(item.displayName) }
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.dialog_rename_title)
            .setView(input)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val newName = input.text.toString().ifBlank { item.displayName }
                if (RecordingFileOps.rename(requireContext(), item.uri, newName)) {
                    viewModel.rename(item, newName)
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun showDeleteConfirmation(item: RecordingItem) {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.dialog_delete_title)
            .setMessage(getString(R.string.dialog_delete_message, item.displayName))
            .setPositiveButton(R.string.action_delete) { _, _ ->
                RecordingFileOps.delete(requireContext(), item.uri)
                viewModel.delete(item)
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        binding = null
    }
}
