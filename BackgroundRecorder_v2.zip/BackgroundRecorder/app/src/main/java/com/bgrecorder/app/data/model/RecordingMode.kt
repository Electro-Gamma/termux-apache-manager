package com.bgrecorder.app.data.model

/**
 * VIDEO uses the CameraX [androidx.camera.video.Recorder] pipeline
 * (video + audio, muxed to MP4).
 *
 * AUDIO_ONLY uses a [android.media.MediaRecorder]-based pipeline
 * ([com.bgrecorder.app.camera.AudioOnlyRecorderEngine]) which - unlike the
 * CameraX Recorder - exposes a real audio session id, enabling genuine
 * noise suppression / echo cancellation / automatic gain control, plus
 * true sample-rate, bitrate and channel-count control. See ARCHITECTURE.md.
 */
enum class RecordingMode {
    VIDEO,
    AUDIO_ONLY
}
