package com.bgrecorder.app.data.model

/** High-level lifecycle of an active (or inactive) recording session. */
sealed class RecordingState {
    data object Idle : RecordingState()
    data object Starting : RecordingState()
    data class Recording(
        val startedAtMillis: Long,
        val elapsedMillis: Long = 0L,
        val currentFileBytes: Long = 0L,
        val outputName: String = ""
    ) : RecordingState()
    data class Paused(
        val startedAtMillis: Long,
        val elapsedMillis: Long,
        val currentFileBytes: Long,
        val outputName: String = ""
    ) : RecordingState()
    data object Stopping : RecordingState()
    data class Error(val error: com.bgrecorder.app.util.RecordingError) : RecordingState()
}
