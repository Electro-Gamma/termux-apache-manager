package com.bgrecorder.app.camera

import android.content.Context
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Detects connected USB Video Class (UVC) devices, e.g. external USB
 * webcams/capture cards.
 *
 * IMPORTANT / EXTENSION POINT: Android's public frameworks (CameraX,
 * Camera2) only address cameras exposed through the platform's Camera HAL;
 * they cannot drive an arbitrary USB UVC device. Detection here is real and
 * functional (it enumerates [UsbManager.getDeviceList] and checks each
 * device's interface class for [UsbConstants.USB_CLASS_VIDEO]), but actually
 * *capturing* frames from a UVC device requires a userspace UVC driver
 * talking to the device over [android.hardware.usb.UsbDeviceConnection] -
 * this is a substantial subsystem in its own right (isochronous transfer
 * handling, UVC descriptor parsing, MJPEG/YUV decoding) and is intentionally
 * out of scope for this codebase. The recommended integration path is a
 * dedicated UVC library (for example an AOSP-derived "libuvc" wrapper); once
 * integrated, implement [CameraSourceProvider] and register it alongside
 * [CameraController] so [CameraFacing.USB_EXTERNAL] routes to real frames
 * instead of falling back to the rear camera. See ARCHITECTURE.md.
 */
@Singleton
class UsbCameraDetector @Inject constructor() {

    data class UsbCameraDevice(val deviceName: String, val vendorId: Int, val productId: Int)

    fun listConnectedUvcCameras(context: Context): List<UsbCameraDevice> {
        val usbManager = context.getSystemService(Context.USB_SERVICE) as? UsbManager ?: return emptyList()
        return usbManager.deviceList.values
            .filter { device -> isVideoClassDevice(device) }
            .map { UsbCameraDevice(it.deviceName, it.vendorId, it.productId) }
    }

    private fun isVideoClassDevice(device: UsbDevice): Boolean {
        for (i in 0 until device.interfaceCount) {
            if (device.getInterface(i).interfaceClass == UsbConstants.USB_CLASS_VIDEO) return true
        }
        return false
    }
}

/**
 * Extension point for a pluggable camera frame source (see class doc on
 * [UsbCameraDetector]). [CameraController] currently only implements the
 * built-in front/back path; a UVC implementation of this interface can be
 * registered to support [CameraFacing.USB_EXTERNAL] end-to-end.
 */
interface CameraSourceProvider {
    fun isAvailable(): Boolean
    fun startPreview(surfaceProvider: androidx.camera.core.Preview.SurfaceProvider)
    fun stop()
}
