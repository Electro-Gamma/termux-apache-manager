package com.bgrecorder.app.util

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Resolves a user-defined naming template (e.g. "REC_{yyyyMMdd}_{HHmmss}")
 * into a concrete file name. Any `{pattern}` token is treated as a
 * [SimpleDateFormat] pattern and substituted with the current time; tokens
 * that fail to parse as a date pattern are left as-is so the template never
 * throws on unexpected input.
 */
object FileNamingTemplate {

    private val tokenRegex = Regex("\\{([^{}]+)}")

    fun resolve(template: String, timestamp: Long = System.currentTimeMillis(), extension: String): String {
        val date = Date(timestamp)
        val resolved = tokenRegex.replace(template) { match ->
            val pattern = match.groupValues[1]
            runCatching { SimpleDateFormat(pattern, Locale.US).format(date) }
                .getOrDefault(match.value)
        }
        val sanitized = resolved.replace(Regex("[^A-Za-z0-9_\\-.]"), "_")
        return if (sanitized.endsWith(".$extension")) sanitized else "$sanitized.$extension"
    }

    val DEFAULT_VIDEO_TEMPLATE = "REC_{yyyyMMdd}_{HHmmss}"
    val DEFAULT_AUDIO_TEMPLATE = "AUD_{yyyyMMdd}_{HHmmss}"
}
