package com.bgrecorder.app.data.local.datastore

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.bgrecorder.app.data.model.AppSettings
import com.bgrecorder.app.data.model.AudioBitratePreset
import com.bgrecorder.app.data.model.AudioChannelMode
import com.bgrecorder.app.data.model.AudioCodec
import com.bgrecorder.app.data.model.AudioSampleRate
import com.bgrecorder.app.data.model.BitratePreset
import com.bgrecorder.app.data.model.CameraFacing
import com.bgrecorder.app.data.model.DarkModeOption
import com.bgrecorder.app.data.model.FrameRate
import com.bgrecorder.app.data.model.StorageLocation
import com.bgrecorder.app.data.model.VideoCodec
import com.bgrecorder.app.data.model.VideoQuality
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore by preferencesDataStore(name = "bg_recorder_settings")

/**
 * Thin, typed wrapper around Jetpack DataStore<Preferences>. Exposes the
 * entire settings surface as a single reactive [Flow]<[AppSettings]> plus
 * granular setters, so ViewModels never touch raw Preferences keys.
 */
@Singleton
class SettingsDataStore @Inject constructor(
    @dagger.hilt.android.qualifiers.ApplicationContext private val context: Context
) {
    private object Keys {
        val CAMERA_FACING = stringPreferencesKey("default_camera_facing")
        val QUALITY = stringPreferencesKey("default_quality")
        val FRAME_RATE = stringPreferencesKey("default_frame_rate")
        val BITRATE_PRESET = stringPreferencesKey("default_bitrate_preset")
        val CUSTOM_BITRATE = intPreferencesKey("custom_bitrate_bps")
        val VIDEO_CODEC = stringPreferencesKey("default_video_codec")

        val AUDIO_CODEC = stringPreferencesKey("default_audio_codec")
        val SAMPLE_RATE = stringPreferencesKey("default_sample_rate")
        val AUDIO_BITRATE_PRESET = stringPreferencesKey("default_audio_bitrate_preset")
        val CUSTOM_AUDIO_BITRATE = intPreferencesKey("custom_audio_bitrate_bps")
        val CHANNEL_MODE = stringPreferencesKey("default_channel_mode")
        val NOISE_SUPPRESSION = booleanPreferencesKey("noise_suppression")
        val ECHO_CANCELLATION = booleanPreferencesKey("echo_cancellation")
        val AUTO_GAIN = booleanPreferencesKey("auto_gain_control")

        val DARK_MODE = stringPreferencesKey("dark_mode")

        val STORAGE_LOCATION = stringPreferencesKey("storage_location")
        val CUSTOM_TREE_URI = stringPreferencesKey("custom_tree_uri")
        val NAMING_TEMPLATE = stringPreferencesKey("naming_template")

        val MAX_FILE_SIZE_MB = intPreferencesKey("max_file_size_mb")
        val MAX_DURATION_MIN = intPreferencesKey("max_duration_minutes")
        val AUTO_SPLIT = booleanPreferencesKey("auto_split_enabled")
        val AUTO_SPLIT_INTERVAL = intPreferencesKey("auto_split_interval_minutes")
        val AUTO_DELETE_DAYS = intPreferencesKey("auto_delete_after_days")

        val AUTO_START_BOOT = booleanPreferencesKey("auto_start_on_boot")
        val BATTERY_OPT_IGNORED = booleanPreferencesKey("battery_optimization_ignored")
        val LOW_BATTERY_THRESHOLD = intPreferencesKey("low_battery_threshold")
    }

    val settingsFlow: Flow<AppSettings> = context.dataStore.data.map { prefs ->
        AppSettings(
            defaultCameraFacing = prefs[Keys.CAMERA_FACING]?.let(CameraFacing::valueOf) ?: CameraFacing.BACK,
            defaultQuality = prefs[Keys.QUALITY]?.let(VideoQuality::valueOf) ?: VideoQuality.DEFAULT,
            defaultFrameRate = prefs[Keys.FRAME_RATE]?.let(FrameRate::valueOf) ?: FrameRate.DEFAULT,
            defaultBitratePreset = prefs[Keys.BITRATE_PRESET]?.let(BitratePreset::valueOf) ?: BitratePreset.DEFAULT,
            customBitrateBps = prefs[Keys.CUSTOM_BITRATE] ?: 8_000_000,
            defaultVideoCodec = prefs[Keys.VIDEO_CODEC]?.let(VideoCodec::valueOf) ?: VideoCodec.DEFAULT,

            defaultAudioCodec = prefs[Keys.AUDIO_CODEC]?.let(AudioCodec::valueOf) ?: AudioCodec.DEFAULT,
            defaultSampleRate = prefs[Keys.SAMPLE_RATE]?.let(AudioSampleRate::valueOf) ?: AudioSampleRate.DEFAULT,
            defaultAudioBitratePreset = prefs[Keys.AUDIO_BITRATE_PRESET]?.let(AudioBitratePreset::valueOf) ?: AudioBitratePreset.DEFAULT,
            customAudioBitrateBps = prefs[Keys.CUSTOM_AUDIO_BITRATE] ?: 128_000,
            defaultChannelMode = prefs[Keys.CHANNEL_MODE]?.let(AudioChannelMode::valueOf) ?: AudioChannelMode.DEFAULT,
            noiseSuppressionEnabled = prefs[Keys.NOISE_SUPPRESSION] ?: true,
            echoCancellationEnabled = prefs[Keys.ECHO_CANCELLATION] ?: true,
            autoGainControlEnabled = prefs[Keys.AUTO_GAIN] ?: true,

            darkMode = prefs[Keys.DARK_MODE]?.let(DarkModeOption::valueOf) ?: DarkModeOption.SYSTEM,

            storageLocation = prefs[Keys.STORAGE_LOCATION]?.let(StorageLocation::valueOf) ?: StorageLocation.MEDIA_STORE,
            customTreeUri = prefs[Keys.CUSTOM_TREE_URI],
            fileNamingTemplate = prefs[Keys.NAMING_TEMPLATE] ?: "REC_{yyyyMMdd}_{HHmmss}",

            maxFileSizeMb = prefs[Keys.MAX_FILE_SIZE_MB] ?: 0,
            maxDurationMinutes = prefs[Keys.MAX_DURATION_MIN] ?: 0,
            autoSplitEnabled = prefs[Keys.AUTO_SPLIT] ?: false,
            autoSplitIntervalMinutes = prefs[Keys.AUTO_SPLIT_INTERVAL] ?: 30,
            autoDeleteAfterDays = prefs[Keys.AUTO_DELETE_DAYS] ?: 0,

            autoStartServiceOnBoot = prefs[Keys.AUTO_START_BOOT] ?: false,
            batteryOptimizationIgnored = prefs[Keys.BATTERY_OPT_IGNORED] ?: false,
            lowBatteryWarningThreshold = prefs[Keys.LOW_BATTERY_THRESHOLD] ?: 15
        )
    }

    /**
     * Applies [transform] to the current settings snapshot and persists the
     * result. The read-modify-write happens entirely inside [edit], which
     * hands us the live [androidx.datastore.preferences.core.MutablePreferences]
     * for the *current* state - safe against races, and avoids ever
     * collecting the settings [Flow] here (that flow never completes on its
     * own, so collecting it outside of an edit block would suspend forever).
     */
    suspend fun update(transform: (AppSettings) -> AppSettings) {
        context.dataStore.edit { prefs ->
            val existing = AppSettings(
                defaultCameraFacing = prefs[Keys.CAMERA_FACING]?.let(CameraFacing::valueOf) ?: CameraFacing.BACK,
                defaultQuality = prefs[Keys.QUALITY]?.let(VideoQuality::valueOf) ?: VideoQuality.DEFAULT,
                defaultFrameRate = prefs[Keys.FRAME_RATE]?.let(FrameRate::valueOf) ?: FrameRate.DEFAULT,
                defaultBitratePreset = prefs[Keys.BITRATE_PRESET]?.let(BitratePreset::valueOf) ?: BitratePreset.DEFAULT,
                customBitrateBps = prefs[Keys.CUSTOM_BITRATE] ?: 8_000_000,
                defaultVideoCodec = prefs[Keys.VIDEO_CODEC]?.let(VideoCodec::valueOf) ?: VideoCodec.DEFAULT,
                defaultAudioCodec = prefs[Keys.AUDIO_CODEC]?.let(AudioCodec::valueOf) ?: AudioCodec.DEFAULT,
                defaultSampleRate = prefs[Keys.SAMPLE_RATE]?.let(AudioSampleRate::valueOf) ?: AudioSampleRate.DEFAULT,
                defaultAudioBitratePreset = prefs[Keys.AUDIO_BITRATE_PRESET]?.let(AudioBitratePreset::valueOf) ?: AudioBitratePreset.DEFAULT,
                customAudioBitrateBps = prefs[Keys.CUSTOM_AUDIO_BITRATE] ?: 128_000,
                defaultChannelMode = prefs[Keys.CHANNEL_MODE]?.let(AudioChannelMode::valueOf) ?: AudioChannelMode.DEFAULT,
                noiseSuppressionEnabled = prefs[Keys.NOISE_SUPPRESSION] ?: true,
                echoCancellationEnabled = prefs[Keys.ECHO_CANCELLATION] ?: true,
                autoGainControlEnabled = prefs[Keys.AUTO_GAIN] ?: true,
                darkMode = prefs[Keys.DARK_MODE]?.let(DarkModeOption::valueOf) ?: DarkModeOption.SYSTEM,
                storageLocation = prefs[Keys.STORAGE_LOCATION]?.let(StorageLocation::valueOf) ?: StorageLocation.MEDIA_STORE,
                customTreeUri = prefs[Keys.CUSTOM_TREE_URI],
                fileNamingTemplate = prefs[Keys.NAMING_TEMPLATE] ?: "REC_{yyyyMMdd}_{HHmmss}",
                maxFileSizeMb = prefs[Keys.MAX_FILE_SIZE_MB] ?: 0,
                maxDurationMinutes = prefs[Keys.MAX_DURATION_MIN] ?: 0,
                autoSplitEnabled = prefs[Keys.AUTO_SPLIT] ?: false,
                autoSplitIntervalMinutes = prefs[Keys.AUTO_SPLIT_INTERVAL] ?: 30,
                autoDeleteAfterDays = prefs[Keys.AUTO_DELETE_DAYS] ?: 0,
                autoStartServiceOnBoot = prefs[Keys.AUTO_START_BOOT] ?: false,
                batteryOptimizationIgnored = prefs[Keys.BATTERY_OPT_IGNORED] ?: false,
                lowBatteryWarningThreshold = prefs[Keys.LOW_BATTERY_THRESHOLD] ?: 15
            )
            val updated = transform(existing)
            prefs[Keys.CAMERA_FACING] = updated.defaultCameraFacing.name
            prefs[Keys.QUALITY] = updated.defaultQuality.name
            prefs[Keys.FRAME_RATE] = updated.defaultFrameRate.name
            prefs[Keys.BITRATE_PRESET] = updated.defaultBitratePreset.name
            prefs[Keys.CUSTOM_BITRATE] = updated.customBitrateBps
            prefs[Keys.VIDEO_CODEC] = updated.defaultVideoCodec.name
            prefs[Keys.AUDIO_CODEC] = updated.defaultAudioCodec.name
            prefs[Keys.SAMPLE_RATE] = updated.defaultSampleRate.name
            prefs[Keys.AUDIO_BITRATE_PRESET] = updated.defaultAudioBitratePreset.name
            prefs[Keys.CUSTOM_AUDIO_BITRATE] = updated.customAudioBitrateBps
            prefs[Keys.CHANNEL_MODE] = updated.defaultChannelMode.name
            prefs[Keys.NOISE_SUPPRESSION] = updated.noiseSuppressionEnabled
            prefs[Keys.ECHO_CANCELLATION] = updated.echoCancellationEnabled
            prefs[Keys.AUTO_GAIN] = updated.autoGainControlEnabled
            prefs[Keys.DARK_MODE] = updated.darkMode.name
            prefs[Keys.STORAGE_LOCATION] = updated.storageLocation.name
            updated.customTreeUri?.let { prefs[Keys.CUSTOM_TREE_URI] = it }
            prefs[Keys.NAMING_TEMPLATE] = updated.fileNamingTemplate
            prefs[Keys.MAX_FILE_SIZE_MB] = updated.maxFileSizeMb
            prefs[Keys.MAX_DURATION_MIN] = updated.maxDurationMinutes
            prefs[Keys.AUTO_SPLIT] = updated.autoSplitEnabled
            prefs[Keys.AUTO_SPLIT_INTERVAL] = updated.autoSplitIntervalMinutes
            prefs[Keys.AUTO_DELETE_DAYS] = updated.autoDeleteAfterDays
            prefs[Keys.AUTO_START_BOOT] = updated.autoStartServiceOnBoot
            prefs[Keys.BATTERY_OPT_IGNORED] = updated.batteryOptimizationIgnored
            prefs[Keys.LOW_BATTERY_THRESHOLD] = updated.lowBatteryWarningThreshold
        }
    }
}
