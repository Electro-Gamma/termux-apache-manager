package com.bgrecorder.app.work

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.bgrecorder.app.data.repository.RecordingRepository
import com.bgrecorder.app.data.repository.SettingsRepository
import com.bgrecorder.app.util.RecordingFileOps
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import java.util.concurrent.TimeUnit

/**
 * Daily housekeeping job implementing the "automatic deletion policy"
 * setting: recordings older than [com.bgrecorder.app.data.model.AppSettings.autoDeleteAfterDays]
 * are removed (both the underlying media file and our local metadata row).
 * A no-op when the setting is 0 (never).
 */
@HiltWorker
class AutoDeleteWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters,
    private val settingsRepository: SettingsRepository,
    private val recordingRepository: RecordingRepository
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val days = settingsRepository.settings.value.autoDeleteAfterDays
        if (days <= 0) return Result.success()

        val cutoff = System.currentTimeMillis() - TimeUnit.DAYS.toMillis(days.toLong())
        val stale = recordingRepository.purgeOlderThan(cutoff)
        stale.forEach { RecordingFileOps.delete(applicationContext, it.uri) }
        return Result.success()
    }

    companion object {
        const val UNIQUE_WORK_NAME = "auto_delete_recordings"
    }
}
