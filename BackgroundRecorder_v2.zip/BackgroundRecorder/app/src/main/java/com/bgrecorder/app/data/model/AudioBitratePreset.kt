package com.bgrecorder.app.data.model

enum class AudioBitratePreset(val bps: Int?) {
    LOW(64_000),
    MEDIUM(128_000),
    HIGH(256_000),
    CUSTOM(null);

    companion object {
        val DEFAULT = MEDIUM
    }
}
