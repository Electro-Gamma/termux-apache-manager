package com.bgrecorder.app.service

import android.app.Notification
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.bgrecorder.app.BgRecorderApplication
import com.bgrecorder.app.R
import com.bgrecorder.app.data.model.RecordingState
import com.bgrecorder.app.ui.MainActivity
import com.bgrecorder.app.util.toFileSizeString
import com.bgrecorder.app.util.toTimerString
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Builds the persistent recording notification (status, duration, file
 * size, pause/resume/stop actions) required to run [RecordingService] as a
 * foreground service.
 */
@Singleton
class NotificationHelper @Inject constructor() {

    fun build(context: Context, state: RecordingState): Notification {
        val contentIntent = PendingIntent.getActivity(
            context, 0,
            Intent(context, MainActivity::class.java).apply {
                action = "com.bgrecorder.app.ACTION_SHOW_RECORDING"
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val (title, elapsed, bytes, isPaused) = when (state) {
            is RecordingState.Recording -> Quad(
                context.getString(R.string.notif_title_recording), state.elapsedMillis, state.currentFileBytes, false
            )
            is RecordingState.Paused -> Quad(
                context.getString(R.string.notif_title_paused), state.elapsedMillis, state.currentFileBytes, true
            )
            else -> Quad(context.getString(R.string.notif_title_recording), 0L, 0L, false)
        }

        val content = context.getString(
            R.string.notif_content_template,
            elapsed.toTimerString(),
            bytes.toFileSizeString()
        )

        val builder = NotificationCompat.Builder(context, BgRecorderApplication.CHANNEL_RECORDING)
            .setSmallIcon(R.drawable.ic_notif_videocam)
            .setContentTitle(title)
            .setContentText(content)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .setContentIntent(contentIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)

        if (isPaused) {
            builder.addAction(actionFor(context, R.drawable.ic_notif_play, R.string.notif_action_resume, RecordingActionReceiver.ACTION_RESUME))
        } else {
            builder.addAction(actionFor(context, R.drawable.ic_notif_pause, R.string.notif_action_pause, RecordingActionReceiver.ACTION_PAUSE))
        }
        builder.addAction(actionFor(context, R.drawable.ic_notif_stop, R.string.notif_action_stop, RecordingActionReceiver.ACTION_STOP))

        return builder.build()
    }

    private fun actionFor(context: Context, icon: Int, textRes: Int, action: String): NotificationCompat.Action {
        val intent = Intent(context, RecordingActionReceiver::class.java).setAction(action)
        val pendingIntent = PendingIntent.getBroadcast(
            context, action.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Action.Builder(icon, context.getString(textRes), pendingIntent).build()
    }

    private data class Quad(val title: String, val elapsed: Long, val bytes: Long, val paused: Boolean)

    companion object {
        const val NOTIFICATION_ID = 4201
        const val ALERT_NOTIFICATION_ID = 4202
    }
}
