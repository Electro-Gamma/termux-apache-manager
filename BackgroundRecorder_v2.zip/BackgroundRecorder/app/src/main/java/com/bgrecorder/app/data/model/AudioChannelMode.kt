package com.bgrecorder.app.data.model

enum class AudioChannelMode(val channelCount: Int) {
    MONO(1),
    STEREO(2);

    companion object {
        val DEFAULT = STEREO
    }
}
