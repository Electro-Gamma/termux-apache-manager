package com.bgrecorder.app.data.model

/** UI-facing representation of a saved recording (video or audio). */
data class RecordingItem(
    val id: Long,
    val displayName: String,
    val uri: String,
    val mode: RecordingMode,
    val sizeBytes: Long,
    val durationMillis: Long,
    val width: Int,
    val height: Int,
    val createdAtMillis: Long
)

enum class SortOrder { DATE_NEWEST, DATE_OLDEST, SIZE_LARGEST, SIZE_SMALLEST, NAME }
enum class FilterType { ALL, VIDEO, AUDIO }
