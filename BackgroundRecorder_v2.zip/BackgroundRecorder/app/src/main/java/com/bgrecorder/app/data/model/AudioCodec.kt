package com.bgrecorder.app.data.model

/** Preferred audio codec for audio-only recordings (MediaRecorder-backed). */
enum class AudioCodec {
    AAC,
    AMR_WB;

    companion object {
        val DEFAULT = AAC
    }
}
