package com.bgrecorder.app.schedule

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.bgrecorder.app.data.model.RecordingMode
import com.bgrecorder.app.service.RecordingService
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Fires when a scheduled recording's start or stop time arrives (see
 * [ScheduleManager]). Starts or stops [RecordingService] accordingly, then
 * asks [ScheduleManager] to compute and arm the schedule's next occurrence
 * if it repeats.
 */
@AndroidEntryPoint
class ScheduleAlarmReceiver : BroadcastReceiver() {

    @Inject lateinit var scheduleManager: ScheduleManager

    override fun onReceive(context: Context, intent: Intent) {
        val scheduleId = intent.getLongExtra(EXTRA_SCHEDULE_ID, -1L)
        val isStart = intent.getBooleanExtra(EXTRA_IS_START, true)
        val modeName = intent.getStringExtra(EXTRA_MODE) ?: RecordingMode.VIDEO.name

        val serviceIntent = Intent(context, RecordingService::class.java).apply {
            action = if (isStart) RecordingService.ACTION_START else RecordingService.ACTION_STOP
            putExtra(RecordingService.EXTRA_MODE, modeName)
        }
        ContextCompat.startForegroundService(context, serviceIntent)

        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.Default).launch {
            try {
                scheduleManager.handleFired(context, scheduleId, isStart)
            } finally {
                pendingResult.finish()
            }
        }
    }

    companion object {
        const val EXTRA_SCHEDULE_ID = "extra_schedule_id"
        const val EXTRA_IS_START = "extra_is_start"
        const val EXTRA_MODE = "extra_mode"
    }
}
