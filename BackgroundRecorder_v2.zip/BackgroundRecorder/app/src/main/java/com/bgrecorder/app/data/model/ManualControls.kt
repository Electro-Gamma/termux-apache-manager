package com.bgrecorder.app.data.model

/**
 * White balance presets, mapped 1:1 onto Camera2's
 * `CaptureRequest.CONTROL_AWB_MODE_*` constants inside
 * [com.bgrecorder.app.camera.CameraController]. A discrete preset list is
 * used instead of raw RGGB color-correction gains: it is far more reliable
 * across OEM camera stacks and is what almost every consumer camera app
 * exposes to users.
 */
enum class WhiteBalanceMode {
    AUTO, INCANDESCENT, FLUORESCENT, WARM_FLUORESCENT, DAYLIGHT, CLOUDY, TWILIGHT, SHADE
}

/**
 * Autofocus vs. manual focus. When [ManualFocus.distanceDiopters] is set,
 * the camera's continuous-video autofocus is disabled and the lens is
 * driven to a fixed distance via `CaptureRequest.LENS_FOCUS_DISTANCE`
 * (0f = optical infinity; the practical maximum is queried per-device from
 * `CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE`).
 */
sealed class FocusMode {
    data object Auto : FocusMode()
    data class Manual(val distanceDiopters: Float) : FocusMode()
}
