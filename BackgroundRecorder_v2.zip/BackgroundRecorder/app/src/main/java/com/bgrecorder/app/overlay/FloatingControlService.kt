package com.bgrecorder.app.overlay

import android.app.Notification
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import com.bgrecorder.app.BgRecorderApplication
import com.bgrecorder.app.R
import com.bgrecorder.app.data.model.RecordingState
import com.bgrecorder.app.service.RecordingActionReceiver
import com.bgrecorder.app.service.RecordingService
import com.bgrecorder.app.service.RecordingSessionState
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import javax.inject.Inject
import kotlin.math.roundToInt

/**
 * Optional, permission-gated floating overlay exposing Start/Pause/Stop
 * controls above any other running app. Requires
 * [Settings.canDrawOverlays] to be granted (SYSTEM_ALERT_WINDOW) - checked
 * before the overlay view is ever attached; if not granted, the service
 * stops itself immediately and the caller (Settings/Record screen) should
 * direct the user to the system permission screen.
 */
@AndroidEntryPoint
class FloatingControlService : LifecycleService() {

    @Inject lateinit var sessionState: RecordingSessionState

    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private var layoutParams: WindowManager.LayoutParams? = null

    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        startForeground(NOTIFICATION_ID, buildNotification())
        attachOverlay()
        observeState()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.action == ACTION_STOP_OVERLAY) {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun attachOverlay() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        windowManager = wm
        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.overlay_controls, null)
        overlayView = view

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 200
        }
        layoutParams = params

        setupDrag(view, params, wm)
        wireButtons(view)
        wm.addView(view, params)
    }

    private fun setupDrag(view: View, params: WindowManager.LayoutParams, wm: WindowManager) {
        val dragHandle = view.findViewById<View>(R.id.overlay_drag_handle)
        var initialX = 0
        var initialY = 0
        var touchStartX = 0f
        var touchStartY = 0f

        dragHandle.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    touchStartX = event.rawX
                    touchStartY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - touchStartX).roundToInt()
                    params.y = initialY + (event.rawY - touchStartY).roundToInt()
                    wm.updateViewLayout(view, params)
                    true
                }
                else -> false
            }
        }
    }

    private fun wireButtons(view: View) {
        view.findViewById<View>(R.id.overlay_btn_start_pause).setOnClickListener {
            when (sessionState.state.value) {
                is RecordingState.Recording -> sendAction(RecordingActionReceiver.ACTION_PAUSE)
                is RecordingState.Paused -> sendAction(RecordingActionReceiver.ACTION_RESUME)
                else -> startDefaultRecording()
            }
        }
        view.findViewById<View>(R.id.overlay_btn_stop).setOnClickListener {
            sendAction(RecordingActionReceiver.ACTION_STOP)
        }
    }

    private fun startDefaultRecording() {
        val intent = Intent(this, RecordingService::class.java).setAction(RecordingService.ACTION_START)
        androidx.core.content.ContextCompat.startForegroundService(this, intent)
    }

    private fun sendAction(action: String) {
        sendBroadcast(Intent(this, RecordingActionReceiver::class.java).setAction(action))
    }

    private fun observeState() {
        lifecycleScope.launch {
            sessionState.state.collect { state ->
                val startPauseButton = overlayView?.findViewById<android.widget.ImageButton>(R.id.overlay_btn_start_pause)
                startPauseButton?.setImageResource(
                    when (state) {
                        is RecordingState.Recording -> R.drawable.ic_notif_pause
                        is RecordingState.Paused -> R.drawable.ic_notif_play
                        else -> R.drawable.ic_notif_videocam
                    }
                )
            }
        }
    }

    private fun buildNotification(): Notification =
        NotificationCompat.Builder(this, BgRecorderApplication.CHANNEL_RECORDING)
            .setSmallIcon(R.drawable.ic_notif_videocam)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.overlay_permission_rationale))
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()

    override fun onDestroy() {
        overlayView?.let { runCatching { windowManager?.removeView(it) } }
        overlayView = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP_OVERLAY = "com.bgrecorder.app.overlay.STOP"
        private const val NOTIFICATION_ID = 4301
    }
}
