package com.bgrecorder.app.ui.settings

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.viewModels
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat
import com.bgrecorder.app.R
import com.bgrecorder.app.data.model.StorageLocation
import dagger.hilt.android.AndroidEntryPoint

/**
 * Settings screen built on the Jetpack Preference library - a deliberate
 * choice over a hand-rolled RecyclerView screen: it gives us accessible,
 * platform-consistent widgets (switches, list dialogs, summaries) for
 * free, and [SettingsPreferenceDataStore] keeps every value flowing
 * through the same [com.bgrecorder.app.data.repository.SettingsRepository]
 * every other screen reads from.
 */
@AndroidEntryPoint
class SettingsFragment : PreferenceFragmentCompat() {

    private val viewModel: SettingsViewModel by viewModels()

    private val folderPickerLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            requireContext().contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            viewModel.update { it.copy(storageLocation = StorageLocation.CUSTOM_SAF, customTreeUri = uri.toString()) }
        }
    }

    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        preferenceManager.preferenceDataStore = SettingsPreferenceDataStore(viewModel)
        setPreferencesFromResource(R.xml.preferences, rootKey)
        bindActionPreferences()
    }

    private fun bindActionPreferences() {
        findPreference<Preference>("pref_choose_folder")?.setOnPreferenceClickListener {
            folderPickerLauncher.launch(null)
            true
        }

        findPreference<Preference>("pref_battery_optimization")?.apply {
            refreshBatteryOptimizationSummary(this)
            setOnPreferenceClickListener {
                val intent = Intent(
                    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:${requireContext().packageName}")
                )
                runCatching { startActivity(intent) }
                true
            }
        }

        findPreference<Preference>("pref_exact_alarms")?.apply {
            isVisible = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
            setOnPreferenceClickListener {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    val intent = Intent(
                        Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                        Uri.parse("package:${requireContext().packageName}")
                    )
                    runCatching { startActivity(intent) }
                }
                true
            }
        }

        findPreference<Preference>("pref_overlay_permission")?.setOnPreferenceClickListener {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:${requireContext().packageName}")
            )
            runCatching { startActivity(intent) }
            true
        }
    }

    private fun refreshBatteryOptimizationSummary(preference: Preference) {
        val pm = requireContext().getSystemService(PowerManager::class.java)
        val ignoring = pm?.isIgnoringBatteryOptimizations(requireContext().packageName) == true
        preference.summary = if (ignoring) {
            getString(R.string.settings_battery_optimization_summary) + " ✓"
        } else {
            getString(R.string.settings_battery_optimization_summary)
        }
    }

    override fun onResume() {
        super.onResume()
        findPreference<Preference>("pref_battery_optimization")?.let { refreshBatteryOptimizationSummary(it) }
    }
}
