package com.bgrecorder.app.ui.settings

import androidx.preference.PreferenceDataStore
import com.bgrecorder.app.data.model.AppSettings
import com.bgrecorder.app.data.model.AudioBitratePreset
import com.bgrecorder.app.data.model.AudioChannelMode
import com.bgrecorder.app.data.model.AudioSampleRate
import com.bgrecorder.app.data.model.BitratePreset
import com.bgrecorder.app.data.model.CameraFacing
import com.bgrecorder.app.data.model.DarkModeOption
import com.bgrecorder.app.data.model.FrameRate
import com.bgrecorder.app.data.model.StorageLocation
import com.bgrecorder.app.data.model.VideoCodec
import com.bgrecorder.app.data.model.VideoQuality

/**
 * Bridges the Jetpack Preference library's synchronous read/write contract
 * onto [SettingsViewModel] (backed by DataStore, which is inherently
 * asynchronous). Reads use the ViewModel's latest cached [AppSettings]
 * snapshot (always available via StateFlow.value); writes are fire-and-
 * forget coroutines - the standard, widely-used pattern for wiring
 * Preference screens to Flow-based settings storage, since the Preference
 * widgets already reflect the new value optimistically in their own UI
 * state the instant the user interacts with them.
 */
class SettingsPreferenceDataStore(
    private val viewModel: SettingsViewModel
) : PreferenceDataStore() {

    override fun getString(key: String, defValue: String?): String {
        val s = viewModel.current()
        return when (key) {
            "pref_default_camera" -> s.defaultCameraFacing.name
            "pref_default_resolution" -> s.defaultQuality.name
            "pref_default_fps" -> s.defaultFrameRate.name
            "pref_default_bitrate" -> s.defaultBitratePreset.name
            "pref_video_codec" -> s.defaultVideoCodec.name
            "pref_default_audio_quality" -> s.defaultAudioBitratePreset.name
            "pref_sample_rate" -> s.defaultSampleRate.name
            "pref_channel_mode" -> s.defaultChannelMode.name
            "pref_storage_location" -> s.storageLocation.name
            "pref_naming_template" -> s.fileNamingTemplate
            "pref_max_file_size_mb" -> s.maxFileSizeMb.toString()
            "pref_max_duration_min" -> s.maxDurationMinutes.toString()
            "pref_auto_split_interval" -> s.autoSplitIntervalMinutes.toString()
            "pref_auto_delete_days" -> s.autoDeleteAfterDays.toString()
            "pref_dark_mode" -> s.darkMode.name
            else -> defValue ?: ""
        }
    }

    override fun putString(key: String, value: String?) {
        val v = value ?: return
        viewModel.update { s: AppSettings ->
            when (key) {
                "pref_default_camera" -> s.copy(defaultCameraFacing = CameraFacing.valueOf(v))
                "pref_default_resolution" -> s.copy(defaultQuality = VideoQuality.valueOf(v))
                "pref_default_fps" -> s.copy(defaultFrameRate = FrameRate.valueOf(v))
                "pref_default_bitrate" -> s.copy(defaultBitratePreset = BitratePreset.valueOf(v))
                "pref_video_codec" -> s.copy(defaultVideoCodec = VideoCodec.valueOf(v))
                "pref_default_audio_quality" -> s.copy(defaultAudioBitratePreset = AudioBitratePreset.valueOf(v))
                "pref_sample_rate" -> s.copy(defaultSampleRate = AudioSampleRate.valueOf(v))
                "pref_channel_mode" -> s.copy(defaultChannelMode = AudioChannelMode.valueOf(v))
                "pref_storage_location" -> s.copy(storageLocation = StorageLocation.valueOf(v))
                "pref_naming_template" -> s.copy(fileNamingTemplate = v)
                "pref_max_file_size_mb" -> s.copy(maxFileSizeMb = v.toIntOrNull() ?: s.maxFileSizeMb)
                "pref_max_duration_min" -> s.copy(maxDurationMinutes = v.toIntOrNull() ?: s.maxDurationMinutes)
                "pref_auto_split_interval" -> s.copy(autoSplitIntervalMinutes = v.toIntOrNull() ?: s.autoSplitIntervalMinutes)
                "pref_auto_delete_days" -> s.copy(autoDeleteAfterDays = v.toIntOrNull() ?: s.autoDeleteAfterDays)
                "pref_dark_mode" -> s.copy(darkMode = DarkModeOption.valueOf(v))
                else -> s
            }
        }
    }

    override fun getBoolean(key: String, defValue: Boolean): Boolean {
        val s = viewModel.current()
        return when (key) {
            "pref_noise_suppression" -> s.noiseSuppressionEnabled
            "pref_echo_cancellation" -> s.echoCancellationEnabled
            "pref_agc" -> s.autoGainControlEnabled
            "pref_auto_split" -> s.autoSplitEnabled
            "pref_auto_start_boot" -> s.autoStartServiceOnBoot
            else -> defValue
        }
    }

    override fun putBoolean(key: String, value: Boolean) {
        viewModel.update { s: AppSettings ->
            when (key) {
                "pref_noise_suppression" -> s.copy(noiseSuppressionEnabled = value)
                "pref_echo_cancellation" -> s.copy(echoCancellationEnabled = value)
                "pref_agc" -> s.copy(autoGainControlEnabled = value)
                "pref_auto_split" -> s.copy(autoSplitEnabled = value)
                "pref_auto_start_boot" -> s.copy(autoStartServiceOnBoot = value)
                else -> s
            }
        }
    }
}
