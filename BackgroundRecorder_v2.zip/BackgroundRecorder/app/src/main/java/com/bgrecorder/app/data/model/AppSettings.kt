package com.bgrecorder.app.data.model

/**
 * The full set of user-configurable defaults, persisted via
 * [com.bgrecorder.app.data.local.datastore.SettingsDataStore]. A single
 * immutable snapshot is exposed as a [kotlinx.coroutines.flow.StateFlow]
 * so every screen observes changes reactively.
 */
data class AppSettings(
    // Camera defaults
    val defaultCameraFacing: CameraFacing = CameraFacing.BACK,
    val defaultQuality: VideoQuality = VideoQuality.DEFAULT,
    val defaultFrameRate: FrameRate = FrameRate.DEFAULT,
    val defaultBitratePreset: BitratePreset = BitratePreset.DEFAULT,
    val customBitrateBps: Int = 8_000_000,
    val defaultVideoCodec: VideoCodec = VideoCodec.DEFAULT,

    // Audio defaults
    val defaultAudioCodec: AudioCodec = AudioCodec.DEFAULT,
    val defaultSampleRate: AudioSampleRate = AudioSampleRate.DEFAULT,
    val defaultAudioBitratePreset: AudioBitratePreset = AudioBitratePreset.DEFAULT,
    val customAudioBitrateBps: Int = 128_000,
    val defaultChannelMode: AudioChannelMode = AudioChannelMode.DEFAULT,
    val noiseSuppressionEnabled: Boolean = true,
    val echoCancellationEnabled: Boolean = true,
    val autoGainControlEnabled: Boolean = true,

    // Appearance
    val darkMode: DarkModeOption = DarkModeOption.SYSTEM,

    // Storage
    val storageLocation: StorageLocation = StorageLocation.MEDIA_STORE,
    val customTreeUri: String? = null,
    val fileNamingTemplate: String = "REC_{yyyyMMdd}_{HHmmss}",

    // Limits
    val maxFileSizeMb: Int = 0, // 0 = unlimited
    val maxDurationMinutes: Int = 0, // 0 = unlimited
    val autoSplitEnabled: Boolean = false,
    val autoSplitIntervalMinutes: Int = 30,
    val autoDeleteAfterDays: Int = 0, // 0 = never

    // Background / battery
    val autoStartServiceOnBoot: Boolean = false,
    val batteryOptimizationIgnored: Boolean = false,
    val lowBatteryWarningThreshold: Int = 15
)

enum class DarkModeOption { LIGHT, DARK, SYSTEM }
enum class StorageLocation { MEDIA_STORE, CUSTOM_SAF }
