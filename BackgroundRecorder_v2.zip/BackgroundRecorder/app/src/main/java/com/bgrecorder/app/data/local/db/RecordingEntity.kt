package com.bgrecorder.app.data.local.db

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.bgrecorder.app.data.model.RecordingItem
import com.bgrecorder.app.data.model.RecordingMode

/**
 * Local metadata cache for every recording produced by this app. The
 * authoritative media bytes live in MediaStore (or a SAF tree); this table
 * only stores lightweight metadata (uri + technical details) so the Files
 * screen can list/search/sort instantly without re-probing every file.
 */
@Entity(tableName = "recordings")
data class RecordingEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val displayName: String,
    val uri: String,
    val mode: RecordingMode,
    val sizeBytes: Long,
    val durationMillis: Long,
    val width: Int,
    val height: Int,
    val createdAtMillis: Long
)

fun RecordingEntity.toRecordingItem() = RecordingItem(
    id = id,
    displayName = displayName,
    uri = uri,
    mode = mode,
    sizeBytes = sizeBytes,
    durationMillis = durationMillis,
    width = width,
    height = height,
    createdAtMillis = createdAtMillis
)
