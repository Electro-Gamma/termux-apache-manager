package com.bgrecorder.app.ui.files

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bgrecorder.app.data.model.RecordingItem
import com.bgrecorder.app.data.model.RecordingMode
import com.bgrecorder.app.databinding.ItemRecordingBinding
import com.bgrecorder.app.util.toFileSizeString
import com.bgrecorder.app.util.toTimerString
import java.text.DateFormat
import java.util.Date

class RecordingsAdapter(
    private val onClick: (RecordingItem) -> Unit,
    private val onOverflow: (RecordingItem, android.view.View) -> Unit
) : ListAdapter<RecordingItem, RecordingsAdapter.ViewHolder>(DIFF) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemRecordingBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) = holder.bind(getItem(position))

    inner class ViewHolder(private val binding: ItemRecordingBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(item: RecordingItem) {
            binding.itemName.text = item.displayName
            val dims = if (item.mode == RecordingMode.VIDEO && item.height > 0) "${item.height}p • " else ""
            val date = DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(item.createdAtMillis))
            binding.itemMeta.text = "$dims${item.durationMillis.toTimerString()} • ${item.sizeBytes.toFileSizeString()} • $date"
            binding.root.setOnClickListener { onClick(item) }
            binding.itemOverflow.setOnClickListener { onOverflow(item, it) }
        }
    }

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<RecordingItem>() {
            override fun areItemsTheSame(oldItem: RecordingItem, newItem: RecordingItem) = oldItem.id == newItem.id
            override fun areContentsTheSame(oldItem: RecordingItem, newItem: RecordingItem) = oldItem == newItem
        }
    }
}
