package com.bgrecorder.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Configuration
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.bgrecorder.app.work.AutoDeleteWorker
import com.google.android.material.color.DynamicColors
import dagger.hilt.android.HiltAndroidApp
import java.util.concurrent.TimeUnit
import javax.inject.Inject

/**
 * Application entry point. Annotated for Hilt so the dependency graph is
 * available process-wide. Also responsible for one-time process startup
 * work: creating notification channels and scheduling the daily
 * auto-delete housekeeping job.
 */
@HiltAndroidApp
class BgRecorderApplication : Application(), Configuration.Provider {

    @Inject lateinit var workerFactory: HiltWorkerFactory

    override fun onCreate() {
        super.onCreate()
        // Opts every Activity into wallpaper-derived Material You color on
        // Android 12+, falling back to the static, hand-authored palette in
        // themes.xml on older versions (the theme's own colorPrimary etc.
        // items remain the source of truth wherever dynamic color isn't
        // available or hasn't been applied yet).
        DynamicColors.applyToActivitiesIfAvailable(this)
        createNotificationChannels()
        scheduleAutoDeleteWork()
    }

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setWorkerFactory(workerFactory)
            .build()

    private fun scheduleAutoDeleteWork() {
        val request = PeriodicWorkRequestBuilder<AutoDeleteWorker>(1, TimeUnit.DAYS).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            AutoDeleteWorker.UNIQUE_WORK_NAME,
            ExistingPeriodicWorkPolicy.KEEP,
            request
        )
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(NotificationManager::class.java)

        val recordingChannel = NotificationChannel(
            CHANNEL_RECORDING,
            getString(R.string.notif_channel_recording_name),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = getString(R.string.notif_channel_recording_desc)
            setShowBadge(false)
        }

        val alertsChannel = NotificationChannel(
            CHANNEL_ALERTS,
            getString(R.string.notif_channel_alerts_name),
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = getString(R.string.notif_channel_alerts_desc)
        }

        manager.createNotificationChannels(listOf(recordingChannel, alertsChannel))
    }

    companion object {
        const val CHANNEL_RECORDING = "channel_recording"
        const val CHANNEL_ALERTS = "channel_alerts"
    }
}
