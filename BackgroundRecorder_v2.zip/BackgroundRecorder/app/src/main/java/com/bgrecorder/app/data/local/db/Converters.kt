package com.bgrecorder.app.data.local.db

import androidx.room.TypeConverter
import com.bgrecorder.app.data.model.RecordingMode
import com.bgrecorder.app.data.model.RepeatMode

/** Simple enum <-> String converters shared by the Room database. */
class Converters {
    @TypeConverter
    fun fromRecordingMode(mode: RecordingMode): String = mode.name

    @TypeConverter
    fun toRecordingMode(value: String): RecordingMode = RecordingMode.valueOf(value)

    @TypeConverter
    fun fromRepeatMode(mode: RepeatMode): String = mode.name

    @TypeConverter
    fun toRepeatMode(value: String): RepeatMode = RepeatMode.valueOf(value)
}
