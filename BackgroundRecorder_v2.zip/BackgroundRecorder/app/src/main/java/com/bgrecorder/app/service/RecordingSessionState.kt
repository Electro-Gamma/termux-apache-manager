package com.bgrecorder.app.service

import com.bgrecorder.app.data.model.RecordingMode
import com.bgrecorder.app.data.model.RecordingState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Process-wide, Hilt-[Singleton]-scoped holder for the current recording
 * session state. [RecordingService] is the sole writer; every other
 * consumer (ViewModels, the floating overlay, the widget) reads the same
 * [StateFlow] instance without needing to bind to the service - because
 * Hilt guarantees `@AndroidEntryPoint` services and activities resolve
 * `@Singleton` bindings from the identical application-scoped container.
 */
@Singleton
class RecordingSessionState @Inject constructor() {
    private val _state = MutableStateFlow<RecordingState>(RecordingState.Idle)
    val state: StateFlow<RecordingState> = _state.asStateFlow()

    private val _activeMode = MutableStateFlow<RecordingMode?>(null)
    val activeMode: StateFlow<RecordingMode?> = _activeMode.asStateFlow()

    fun update(newState: RecordingState) {
        _state.value = newState
    }

    fun setActiveMode(mode: RecordingMode?) {
        _activeMode.value = mode
    }
}
