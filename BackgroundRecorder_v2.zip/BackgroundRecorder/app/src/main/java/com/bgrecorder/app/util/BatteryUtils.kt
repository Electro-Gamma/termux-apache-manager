package com.bgrecorder.app.util

import android.content.Context
import android.os.BatteryManager

/** Helpers for reading the current battery level and charging state. */
object BatteryUtils {

    fun batteryLevelPercent(context: Context): Int {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager ?: return -1
        return bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    }

    fun isCharging(context: Context): Boolean {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager ?: return false
        return bm.isCharging
    }
}
