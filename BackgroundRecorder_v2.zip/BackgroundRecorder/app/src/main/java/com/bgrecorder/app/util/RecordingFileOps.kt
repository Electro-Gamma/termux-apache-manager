package com.bgrecorder.app.util

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import androidx.documentfile.provider.DocumentFile

/**
 * File-level operations (delete/rename) against the *actual* media a
 * [com.bgrecorder.app.data.model.RecordingItem] points at - as opposed to
 * [com.bgrecorder.app.data.repository.RecordingRepository], which only
 * manages our local metadata cache. Both a MediaStore content Uri and a
 * Storage-Access-Framework single-document Uri are backed by a
 * ContentProvider, so [android.content.ContentResolver] is the common,
 * scheme-agnostic entry point for both; SAF-specific renaming falls back to
 * [DocumentFile] since not every SAF provider honors a MediaStore-style
 * DISPLAY_NAME update.
 */
object RecordingFileOps {

    fun delete(context: Context, uriString: String): Boolean = try {
        val uri = Uri.parse(uriString)
        context.contentResolver.delete(uri, null, null) > 0
    } catch (e: Exception) {
        false
    }

    fun rename(context: Context, uriString: String, newDisplayName: String): Boolean {
        val uri = Uri.parse(uriString)
        val viaMediaStore = try {
            val values = ContentValues().apply { put(MediaStore.MediaColumns.DISPLAY_NAME, newDisplayName) }
            context.contentResolver.update(uri, values, null, null) > 0
        } catch (e: Exception) {
            false
        }
        if (viaMediaStore) return true
        return try {
            DocumentFile.fromSingleUri(context, uri)?.renameTo(newDisplayName) ?: false
        } catch (e: Exception) {
            false
        }
    }
}
