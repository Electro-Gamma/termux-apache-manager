package com.bgrecorder.app.ui.files

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.bgrecorder.app.data.model.FilterType
import com.bgrecorder.app.data.model.RecordingItem
import com.bgrecorder.app.data.model.RecordingMode
import com.bgrecorder.app.data.model.SortOrder
import com.bgrecorder.app.data.repository.RecordingRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class FilesViewModel @Inject constructor(
    private val recordingRepository: RecordingRepository
) : ViewModel() {

    private val allRecordings = recordingRepository.observeRecordings()

    private val _searchQuery = MutableStateFlow("")
    private val _sortOrder = MutableStateFlow(SortOrder.DATE_NEWEST)
    private val _filterType = MutableStateFlow(FilterType.ALL)

    val sortOrder: StateFlow<SortOrder> = _sortOrder
    val filterType: StateFlow<FilterType> = _filterType

    val recordings: StateFlow<List<RecordingItem>> = combine(
        allRecordings, _searchQuery, _sortOrder, _filterType
    ) { items, query, sort, filter ->
        items
            .filter { filter == FilterType.ALL || (filter == FilterType.VIDEO && it.mode == RecordingMode.VIDEO) || (filter == FilterType.AUDIO && it.mode == RecordingMode.AUDIO_ONLY) }
            .filter { query.isBlank() || it.displayName.contains(query, ignoreCase = true) }
            .let { list ->
                when (sort) {
                    SortOrder.DATE_NEWEST -> list.sortedByDescending { it.createdAtMillis }
                    SortOrder.DATE_OLDEST -> list.sortedBy { it.createdAtMillis }
                    SortOrder.SIZE_LARGEST -> list.sortedByDescending { it.sizeBytes }
                    SortOrder.SIZE_SMALLEST -> list.sortedBy { it.sizeBytes }
                    SortOrder.NAME -> list.sortedBy { it.displayName.lowercase() }
                }
            }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setSearchQuery(query: String) { _searchQuery.value = query }
    fun setSortOrder(order: SortOrder) { _sortOrder.value = order }
    fun setFilterType(filter: FilterType) { _filterType.value = filter }

    fun rename(item: RecordingItem, newName: String) {
        viewModelScope.launch { recordingRepository.rename(item, newName) }
    }

    fun delete(item: RecordingItem) {
        viewModelScope.launch { recordingRepository.delete(item) }
    }
}
