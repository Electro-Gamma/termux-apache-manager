package com.bgrecorder.app.data.local.db

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.bgrecorder.app.data.model.RecordingMode
import com.bgrecorder.app.data.model.RepeatMode
import com.bgrecorder.app.data.model.ScheduleItem

@Entity(tableName = "schedules")
@TypeConverters(ScheduleConverters::class)
data class ScheduleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val label: String,
    val repeatMode: RepeatMode,
    val startHour: Int,
    val startMinute: Int,
    val stopHour: Int,
    val stopMinute: Int,
    val daysOfWeek: Set<Int>,
    val oneTimeDateMillis: Long?,
    val enabled: Boolean,
    val mode: RecordingMode
)

class ScheduleConverters {
    @TypeConverter
    fun fromDaySet(days: Set<Int>): String = days.joinToString(",")

    @TypeConverter
    fun toDaySet(raw: String): Set<Int> =
        if (raw.isBlank()) emptySet() else raw.split(",").mapNotNull { it.toIntOrNull() }.toSet()
}

fun ScheduleEntity.toScheduleItem() = ScheduleItem(
    id = id, label = label, repeatMode = repeatMode, startHour = startHour,
    startMinute = startMinute, stopHour = stopHour, stopMinute = stopMinute,
    daysOfWeek = daysOfWeek, oneTimeDateMillis = oneTimeDateMillis, enabled = enabled, mode = mode
)

fun ScheduleItem.toEntity() = ScheduleEntity(
    id = id, label = label, repeatMode = repeatMode, startHour = startHour,
    startMinute = startMinute, stopHour = stopHour, stopMinute = stopMinute,
    daysOfWeek = daysOfWeek, oneTimeDateMillis = oneTimeDateMillis, enabled = enabled, mode = mode
)
