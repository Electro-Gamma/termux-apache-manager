package com.bgrecorder.app.util

import com.bgrecorder.app.R

/**
 * All the ways a recording session can fail, each mapped to a localized,
 * user-facing message and (where applicable) a suggested recovery action.
 * Centralizing this makes error handling in the service/UI exhaustive and
 * consistent (the `when` blocks over this type are compiler-checked).
 */
sealed class RecordingError(val messageRes: Int, val recoverable: Boolean) {
    data object CameraUnavailable : RecordingError(R.string.error_camera_unavailable, recoverable = true)
    data object MicUnavailable : RecordingError(R.string.error_mic_unavailable, recoverable = true)
    data object StorageFull : RecordingError(R.string.error_storage_full, recoverable = false)
    data object PermissionDenied : RecordingError(R.string.error_permission_denied, recoverable = false)
    data object InterruptedBySystem : RecordingError(R.string.error_interrupted, recoverable = true)
    data object Overheating : RecordingError(R.string.error_overheating, recoverable = false)
    data object EncoderFailure : RecordingError(R.string.error_encoder, recoverable = true)
    data class WriteFailed(val cause: String? = null) : RecordingError(R.string.error_write_failed, recoverable = false)
    data class Unknown(val cause: String? = null) : RecordingError(R.string.error_unknown, recoverable = true)
}
