package com.bgrecorder.app.camera

import android.content.Context
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.net.Uri
import android.os.Build
import android.os.ParcelFileDescriptor
import com.bgrecorder.app.data.model.AppSettings
import com.bgrecorder.app.data.repository.StorageRepository
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Audio-only recording pipeline built on [MediaRecorder].
 *
 * Unlike CameraX's video [androidx.camera.video.Recorder] (which does not
 * expose an audio session id), [MediaRecorder.getAudioSessionId] gives us a
 * real session to attach [NoiseSuppressor], [AcousticEchoCanceler] and
 * [AutomaticGainControl] to - so for audio-only recordings, every audio
 * requirement in the spec (sample rate, bitrate, channel count, codec,
 * noise suppression, AEC, AGC) is genuinely wired up, not just persisted as
 * a preference. See ARCHITECTURE.md for the video-mode audio limitations.
 */
@Singleton
class AudioOnlyRecorderEngine @Inject constructor(
    private val storageRepository: StorageRepository
) {
    private var recorder: MediaRecorder? = null
    private var noiseSuppressor: NoiseSuppressor? = null
    private var echoCanceler: AcousticEchoCanceler? = null
    private var agc: AutomaticGainControl? = null
    private var pfd: ParcelFileDescriptor? = null
    private var isPaused = false
    private var outputUri: Uri? = null

    fun start(context: Context, outputTarget: StorageRepository.OutputTarget, settings: AppSettings): Boolean {
        return try {
            val mr = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(context)
            } else {
                @Suppress("DEPRECATION") MediaRecorder()
            }
            mr.setAudioSource(MediaRecorder.AudioSource.MIC)
            mr.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            mr.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            mr.setAudioSamplingRate(settings.defaultSampleRate.hz)
            mr.setAudioChannels(settings.defaultChannelMode.channelCount)
            val bitrate = settings.defaultAudioBitratePreset.bps ?: settings.customAudioBitrateBps
            mr.setAudioEncodingBitRate(bitrate)

            when (outputTarget) {
                is StorageRepository.OutputTarget.MediaStoreTarget -> {
                    val uri = context.contentResolver.insert(outputTarget.collectionUri, outputTarget.values)
                        ?: return false
                    outputUri = uri
                    val fd = context.contentResolver.openFileDescriptor(uri, "rw") ?: return false
                    pfd = fd
                    mr.setOutputFile(fd.fileDescriptor)
                }
                is StorageRepository.OutputTarget.SafTarget -> {
                    outputUri = outputTarget.documentFile.uri
                    val fd = context.contentResolver.openFileDescriptor(outputTarget.documentFile.uri, "rw")
                        ?: return false
                    pfd = fd
                    mr.setOutputFile(fd.fileDescriptor)
                }
            }

            mr.prepare()
            mr.start()
            recorder = mr
            isPaused = false
            // Explicit getter call rather than the synthetic Kotlin property
            // (mr.audioSessionId) - more robust across toolchain/SDK-stub
            // variations, and this is the one line in the file that must
            // resolve correctly for noise suppression/AEC/AGC to work at all.
            attachAudioEffects(mr.getAudioSessionId(), settings)
            true
        } catch (e: IOException) {
            release()
            false
        } catch (e: IllegalStateException) {
            release()
            false
        }
    }

    private fun attachAudioEffects(sessionId: Int, settings: AppSettings) {
        if (settings.noiseSuppressionEnabled && NoiseSuppressor.isAvailable()) {
            noiseSuppressor = NoiseSuppressor.create(sessionId)?.apply { enabled = true }
        }
        if (settings.echoCancellationEnabled && AcousticEchoCanceler.isAvailable()) {
            echoCanceler = AcousticEchoCanceler.create(sessionId)?.apply { enabled = true }
        }
        if (settings.autoGainControlEnabled && AutomaticGainControl.isAvailable()) {
            agc = AutomaticGainControl.create(sessionId)?.apply { enabled = true }
        }
    }

    fun pause(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false
        return try {
            recorder?.pause()
            isPaused = true
            true
        } catch (e: IllegalStateException) {
            false
        }
    }

    fun resume(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false
        return try {
            recorder?.resume()
            isPaused = false
            true
        } catch (e: IllegalStateException) {
            false
        }
    }

    /** Stops the recorder and finalizes the output; returns the resulting Uri, if any. */
    fun stop(): Uri? {
        val uri = outputUri
        try {
            recorder?.stop()
        } catch (e: RuntimeException) {
            // stop() throws if start() never produced any data - the caller
            // should treat this as a failed/empty recording and clean up.
        }
        release()
        return uri
    }

    private fun release() {
        noiseSuppressor?.release(); noiseSuppressor = null
        echoCanceler?.release(); echoCanceler = null
        agc?.release(); agc = null
        recorder?.reset()
        recorder?.release()
        recorder = null
        pfd?.close()
        pfd = null
    }

    fun isActive(): Boolean = recorder != null
    fun isPausedState(): Boolean = isPaused

    /** Current on-disk size of the in-progress recording, for notification/UI display. */
    fun currentFileBytes(): Long = try { pfd?.getStatSize() ?: 0L } catch (e: Exception) { 0L }
}
