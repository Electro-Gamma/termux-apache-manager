package com.bgrecorder.app.data.repository

import com.bgrecorder.app.data.local.datastore.SettingsDataStore
import com.bgrecorder.app.data.model.AppSettings
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.CoroutineScope
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Public-facing settings API used by ViewModels and the recording service.
 * Wraps [SettingsDataStore] and exposes a hot [StateFlow] so every reader
 * shares one underlying collector against the DataStore file.
 */
@Singleton
class SettingsRepository @Inject constructor(
    private val dataStore: SettingsDataStore,
    @com.bgrecorder.app.di.ApplicationScope private val externalScope: CoroutineScope
) {
    val settings: StateFlow<AppSettings> = dataStore.settingsFlow.stateIn(
        scope = externalScope,
        started = SharingStarted.Eagerly,
        initialValue = AppSettings()
    )

    suspend fun update(transform: (AppSettings) -> AppSettings) = dataStore.update(transform)
}
