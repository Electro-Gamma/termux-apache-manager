package com.bgrecorder.app.camera

import android.annotation.SuppressLint
import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CaptureRequest
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.util.Range
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.FileDescriptorOutputOptions
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.PendingRecording
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.bgrecorder.app.data.model.CameraCapabilities
import com.bgrecorder.app.data.model.CameraFacing
import com.bgrecorder.app.data.model.FocusMode
import com.bgrecorder.app.data.model.FrameRate
import com.bgrecorder.app.data.model.VideoQuality
import com.bgrecorder.app.data.model.WhiteBalanceMode
import com.bgrecorder.app.data.repository.StorageRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.guava.await
import java.util.concurrent.Executor
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Owns the CameraX pipeline: [ProcessCameraProvider], [Preview] and the
 * video [Recorder]/[VideoCapture]. This is the single source of truth for
 * everything camera-related in the app - both [com.bgrecorder.app.ui.record.RecordFragment]
 * (for live preview + foreground control) and [com.bgrecorder.app.service.RecordingService]
 * (for headless background recording) drive the *same* controller instance
 * via Hilt's [Singleton] scope, so a recording started from the UI survives
 * the Activity being destroyed and is fully owned by the service.
 *
 * CameraX is used as the primary API end-to-end (per spec: "CameraX as
 * preferred"). Where the public CameraX surface doesn't expose a control
 * (manual focus distance, target FPS range, white balance mode), we reach
 * into the same capture session via [Camera2Interop] - this is the
 * documented, supported way CameraX allows Camera2-level tuning without
 * abandoning the CameraX lifecycle/use-case model (per spec: "Camera2 API
 * where advanced control is required").
 */
@Singleton
class CameraController @Inject constructor(
    private val storageRepository: StorageRepository
) {

    private var cameraProvider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var preview: Preview? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var activeRecording: Recording? = null
    private var pendingFileDescriptor: ParcelFileDescriptor? = null

    private var currentFacing: CameraFacing = CameraFacing.BACK
    private var currentQuality: VideoQuality = VideoQuality.DEFAULT
    private var currentFrameRate: FrameRate = FrameRate.DEFAULT
    private var currentBitrateBps: Int = 8_000_000

    private val _events = MutableStateFlow<CameraEvent>(CameraEvent.Idle)
    val events: StateFlow<CameraEvent> = _events

    /** Emitted camera/recording lifecycle events, consumed by the service & ViewModels. */
    sealed class CameraEvent {
        data object Idle : CameraEvent()
        data class Recording(val durationNanos: Long, val bytes: Long) : CameraEvent()
        data class Finalized(val uri: Uri, val durationMillis: Long, val bytes: Long, val error: Int?) : CameraEvent()
        data class Error(val message: String) : CameraEvent()
    }

    /** Must be called once before any binding, from a process with camera permission. */
    suspend fun initialize(context: Context) {
        if (cameraProvider != null) return
        cameraProvider = ProcessCameraProvider.getInstance(context).await()
    }

    /**
     * Binds Preview (optional - null when running headless in the service
     * with no visible UI) and the video capture use case to [lifecycleOwner].
     * Safe to call repeatedly (e.g. after device rotation or camera switch);
     * always unbinds previous use cases first.
     */
    @OptIn(ExperimentalCamera2Interop::class)
    fun bind(
        context: Context,
        lifecycleOwner: LifecycleOwner,
        previewView: PreviewView?,
        facing: CameraFacing,
        quality: VideoQuality,
        frameRate: FrameRate,
        bitrateBps: Int
    ) {
        val provider = cameraProvider ?: return
        currentFacing = facing
        currentQuality = quality
        currentFrameRate = frameRate
        currentBitrateBps = bitrateBps

        provider.unbindAll()

        val selector = when (facing) {
            CameraFacing.FRONT -> CameraSelector.DEFAULT_FRONT_CAMERA
            CameraFacing.BACK, CameraFacing.USB_EXTERNAL -> CameraSelector.DEFAULT_BACK_CAMERA
            // USB_EXTERNAL: true UVC camera capture is outside the CameraX/Camera2
            // public surface; see UsbCameraDetector + ARCHITECTURE.md. We fall back
            // to the back camera so recording still functions end-to-end.
        }

        val recorder = Recorder.Builder()
            .setQualitySelector(qualitySelectorFor(quality))
            .setTargetVideoEncodingBitRate(bitrateBps)
            .build()

        val videoCaptureBuilder = VideoCapture.Builder(recorder)
        Camera2Interop.Extender(videoCaptureBuilder).apply {
            setCaptureRequestOption(
                CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE,
                Range(frameRate.fps, frameRate.fps)
            )
        }
        val newVideoCapture = videoCaptureBuilder.build()

        val useCases = mutableListOf<androidx.camera.core.UseCase>(newVideoCapture)

        // A Preview use case is *always* created and bound - independent of
        // whether a PreviewView is available at bind() time - specifically so
        // that when this binding is owned by RecordingService's lifecycle
        // (headless background recording), the UI can later reconnect a
        // PreviewView to the very same running Preview use case via
        // [attachPreviewSurface] without ever calling bind()/unbindAll()
        // again. Re-binding while a Recording is in progress would tear down
        // the VideoCapture use case's surface and corrupt the in-flight
        // recording, so this is a deliberate design choice, not an oversight.
        val newPreview = Preview.Builder()
            .setResolutionSelector(
                androidx.camera.core.resolutionselector.ResolutionSelector.Builder()
                    .setAspectRatioStrategy(AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY)
                    .build()
            )
            .build()
        useCases.add(0, newPreview)
        if (previewView != null) {
            newPreview.setSurfaceProvider(previewView.surfaceProvider)
        }

        camera = provider.bindToLifecycle(lifecycleOwner, selector, *useCases.toTypedArray())
        preview = newPreview
        videoCapture = newVideoCapture
    }

    /**
     * Reconnects a (possibly new) [PreviewView] to whatever [Preview] use
     * case is currently bound - safe to call at any time, including while a
     * recording bound to [RecordingService]'s lifecycle is in progress,
     * because it never touches [ProcessCameraProvider] bindings.
     */
    fun attachPreviewSurface(previewView: PreviewView) {
        preview?.setSurfaceProvider(previewView.surfaceProvider)
    }

    /** Detaches the preview surface (e.g. Fragment view destroyed) without affecting an active recording. */
    fun detachPreviewSurface() {
        preview?.setSurfaceProvider(null)
    }

    /** True when a Preview/VideoCapture pipeline is currently bound (to *any* lifecycle owner, service or UI). */
    fun isBound(): Boolean = camera != null

    fun unbind() {
        cameraProvider?.unbindAll()
        camera = null
        preview = null
        videoCapture = null
    }

    // ---------------------------------------------------------------------
    // Recording control
    // ---------------------------------------------------------------------

    @SuppressLint("MissingPermission")
    fun startRecording(
        context: Context,
        outputTarget: StorageRepository.OutputTarget,
        withAudio: Boolean,
        executor: Executor,
        onEvent: (VideoRecordEvent) -> Unit
    ): Boolean {
        val capture = videoCapture ?: return false
        val pending: PendingRecording = when (outputTarget) {
            is StorageRepository.OutputTarget.MediaStoreTarget -> {
                val options = MediaStoreOutputOptions.Builder(
                    context.contentResolver, outputTarget.collectionUri
                ).setContentValues(outputTarget.values).build()
                capture.output.prepareRecording(context, options)
            }
            is StorageRepository.OutputTarget.SafTarget -> {
                val pfd = context.contentResolver.openFileDescriptor(outputTarget.documentFile.uri, "rw")
                    ?: return false
                pendingFileDescriptor = pfd
                val options = FileDescriptorOutputOptions.Builder(pfd).build()
                capture.output.prepareRecording(context, options)
            }
        }

        val withAudioPending = if (withAudio) pending.withAudioEnabled() else pending
        activeRecording = withAudioPending.start(executor) { event ->
            onEvent(event)
            if (event is VideoRecordEvent.Finalize) {
                pendingFileDescriptor?.close()
                pendingFileDescriptor = null
            }
        }
        return true
    }

    fun pauseRecording() = activeRecording?.pause()
    fun resumeRecording() = activeRecording?.resume()
    fun stopRecording() {
        activeRecording?.stop()
        activeRecording = null
    }

    fun isRecordingActive(): Boolean = activeRecording != null

    // ---------------------------------------------------------------------
    // Manual controls - zoom, exposure, torch, focus, white balance
    // ---------------------------------------------------------------------

    fun setZoomRatio(ratio: Float) {
        camera?.cameraControl?.setZoomRatio(ratio)
    }

    fun setLinearZoom(@androidx.annotation.FloatRange(from = 0.0, to = 1.0) value: Float) {
        camera?.cameraControl?.setLinearZoom(value)
    }

    fun setExposureCompensationIndex(index: Int) {
        camera?.cameraControl?.setExposureCompensationIndex(index)
    }

    fun enableTorch(enabled: Boolean) {
        camera?.cameraControl?.enableTorch(enabled)
    }

    /** Tap-to-focus at a normalized point provided by [androidx.camera.view.PreviewView.getMeteringPointFactory]. */
    fun triggerAutoFocus(meteringPoint: androidx.camera.core.MeteringPoint) {
        val action = FocusMeteringAction.Builder(meteringPoint).build()
        camera?.cameraControl?.startFocusAndMetering(action)
    }

    @OptIn(ExperimentalCamera2Interop::class)
    fun setFocusMode(context: Context, mode: FocusMode) {
        val cameraControl = camera?.cameraControl ?: return
        val camera2Control = androidx.camera.camera2.interop.Camera2CameraControl.from(cameraControl)
        val optionsBuilder = androidx.camera.camera2.interop.CaptureRequestOptions.Builder()
        when (mode) {
            is FocusMode.Auto -> {
                optionsBuilder.setCaptureRequestOption(
                    CaptureRequest.CONTROL_AF_MODE,
                    CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO
                )
            }
            is FocusMode.Manual -> {
                optionsBuilder
                    .setCaptureRequestOption(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF)
                    .setCaptureRequestOption(CaptureRequest.LENS_FOCUS_DISTANCE, mode.distanceDiopters)
            }
        }
        camera2Control.captureRequestOptions = optionsBuilder.build()
    }

    @OptIn(ExperimentalCamera2Interop::class)
    fun setWhiteBalanceMode(mode: WhiteBalanceMode) {
        val cameraControl = camera?.cameraControl ?: return
        val camera2Control = androidx.camera.camera2.interop.Camera2CameraControl.from(cameraControl)
        val awbMode = when (mode) {
            WhiteBalanceMode.AUTO -> CaptureRequest.CONTROL_AWB_MODE_AUTO
            WhiteBalanceMode.INCANDESCENT -> CaptureRequest.CONTROL_AWB_MODE_INCANDESCENT
            WhiteBalanceMode.FLUORESCENT -> CaptureRequest.CONTROL_AWB_MODE_FLUORESCENT
            WhiteBalanceMode.WARM_FLUORESCENT -> CaptureRequest.CONTROL_AWB_MODE_WARM_FLUORESCENT
            WhiteBalanceMode.DAYLIGHT -> CaptureRequest.CONTROL_AWB_MODE_DAYLIGHT
            WhiteBalanceMode.CLOUDY -> CaptureRequest.CONTROL_AWB_MODE_CLOUDY_DAYLIGHT
            WhiteBalanceMode.TWILIGHT -> CaptureRequest.CONTROL_AWB_MODE_TWILIGHT
            WhiteBalanceMode.SHADE -> CaptureRequest.CONTROL_AWB_MODE_SHADE
        }
        val options = androidx.camera.camera2.interop.CaptureRequestOptions.Builder()
            .setCaptureRequestOption(CaptureRequest.CONTROL_AWB_MODE, awbMode)
            .build()
        camera2Control.captureRequestOptions = options
    }

    @OptIn(ExperimentalCamera2Interop::class)
    fun queryCapabilities(context: Context, facing: CameraFacing): CameraCapabilities? {
        val provider = cameraProvider ?: return null
        val selector = if (facing == CameraFacing.FRONT) CameraSelector.DEFAULT_FRONT_CAMERA
        else CameraSelector.DEFAULT_BACK_CAMERA
        val infos = selector.filter(provider.availableCameraInfos)
        val info = infos.firstOrNull() ?: return null
        val camera2Info = Camera2CameraInfo.from(info)
        val fpsRanges = camera2Info.getCameraCharacteristic(
            CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES
        )?.map { it.upper }?.distinct()?.sorted() ?: listOf(30)

        val availableFacings = mutableListOf<CameraFacing>()
        if (CameraSelector.DEFAULT_FRONT_CAMERA.filter(provider.availableCameraInfos).isNotEmpty()) {
            availableFacings.add(CameraFacing.FRONT)
        }
        if (CameraSelector.DEFAULT_BACK_CAMERA.filter(provider.availableCameraInfos).isNotEmpty()) {
            availableFacings.add(CameraFacing.BACK)
        }

        return CameraCapabilities(
            availableFacings = availableFacings,
            supportedFrameRates = fpsRanges,
            maxZoomRatio = info.zoomState.value?.maxZoomRatio ?: 1f,
            minZoomRatio = info.zoomState.value?.minZoomRatio ?: 1f,
            hasFlash = info.hasFlashUnit(),
            minExposureIndex = info.exposureState.exposureCompensationRange.lower,
            maxExposureIndex = info.exposureState.exposureCompensationRange.upper,
            exposureStep = info.exposureState.exposureCompensationStep.toFloat()
        )
    }

    /**
     * Maps our 7-tier [VideoQuality] onto CameraX's 4 real quality tiers.
     * 240p and 360p fall back to the lowest available tier (SD); 1440p
     * falls back to the nearest higher tier (UHD) since CameraX has no
     * intermediate QHD constant. This mapping is intentionally explicit
     * and documented, rather than silently approximated.
     */
    private fun qualitySelectorFor(quality: VideoQuality): QualitySelector {
        val target = when (quality) {
            VideoQuality.P240, VideoQuality.P360, VideoQuality.P480 -> Quality.SD
            VideoQuality.P720 -> Quality.HD
            VideoQuality.P1080 -> Quality.FHD
            VideoQuality.P1440, VideoQuality.P2160 -> Quality.UHD
        }
        return QualitySelector.from(
            target,
            FallbackStrategy.lowerQualityOrHigherThan(target)
        )
    }

    companion object {
        fun mainExecutor(context: Context): Executor = ContextCompat.getMainExecutor(context)
    }
}
