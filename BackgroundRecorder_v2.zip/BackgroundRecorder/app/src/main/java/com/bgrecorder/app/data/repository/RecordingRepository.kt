package com.bgrecorder.app.data.repository

import com.bgrecorder.app.data.local.db.RecordingDao
import com.bgrecorder.app.data.local.db.RecordingEntity
import com.bgrecorder.app.data.local.db.toRecordingItem
import com.bgrecorder.app.data.model.RecordingItem
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

/** Repository over the local recordings metadata cache (see [RecordingDao]). */
@Singleton
class RecordingRepository @Inject constructor(
    private val dao: RecordingDao
) {
    fun observeRecordings(): Flow<List<RecordingItem>> =
        dao.observeAll().map { list -> list.map { it.toRecordingItem() } }

    suspend fun add(entity: RecordingEntity): Long = dao.insert(entity)

    suspend fun rename(item: RecordingItem, newDisplayName: String) {
        val entity = dao.getById(item.id) ?: return
        dao.update(entity.copy(displayName = newDisplayName))
    }

    suspend fun delete(item: RecordingItem) {
        val entity = dao.getById(item.id) ?: return
        dao.delete(entity)
    }

    suspend fun purgeOlderThan(cutoffMillis: Long): List<RecordingItem> {
        val stale = dao.getOlderThan(cutoffMillis)
        stale.forEach { dao.delete(it) }
        return stale.map { it.toRecordingItem() }
    }
}
