package com.bgrecorder.app.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

/**
 * Receives pause/resume/stop taps from the persistent recording
 * notification and forwards them to [RecordingService]. Kept as a separate
 * receiver (rather than pointing the notification's PendingIntents directly
 * at the service) so notification-triggered commands are handled
 * uniformly and quickly regardless of process state, and so the service's
 * own `onStartCommand` only has to reason about one caller shape.
 */
class RecordingActionReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val serviceAction = when (intent.action) {
            ACTION_PAUSE -> RecordingService.ACTION_PAUSE
            ACTION_RESUME -> RecordingService.ACTION_RESUME
            ACTION_STOP -> RecordingService.ACTION_STOP
            else -> return
        }
        val serviceIntent = Intent(context, RecordingService::class.java).setAction(serviceAction)
        ContextCompat.startForegroundService(context, serviceIntent)
    }

    companion object {
        const val ACTION_PAUSE = "com.bgrecorder.app.notif.PAUSE"
        const val ACTION_RESUME = "com.bgrecorder.app.notif.RESUME"
        const val ACTION_STOP = "com.bgrecorder.app.notif.STOP"
    }
}
