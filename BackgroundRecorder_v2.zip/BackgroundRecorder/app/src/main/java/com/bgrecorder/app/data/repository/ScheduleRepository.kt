package com.bgrecorder.app.data.repository

import com.bgrecorder.app.data.local.db.ScheduleDao
import com.bgrecorder.app.data.local.db.toEntity
import com.bgrecorder.app.data.local.db.toScheduleItem
import com.bgrecorder.app.data.model.ScheduleItem
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ScheduleRepository @Inject constructor(
    private val dao: ScheduleDao
) {
    fun observeSchedules(): Flow<List<ScheduleItem>> =
        dao.observeAll().map { list -> list.map { it.toScheduleItem() } }

    suspend fun save(item: ScheduleItem): Long = dao.insert(item.toEntity())

    suspend fun delete(item: ScheduleItem) = dao.delete(item.toEntity())

    suspend fun getEnabled(): List<ScheduleItem> = dao.getEnabled().map { it.toScheduleItem() }

    suspend fun getById(id: Long): ScheduleItem? = dao.getById(id)?.toScheduleItem()
}
