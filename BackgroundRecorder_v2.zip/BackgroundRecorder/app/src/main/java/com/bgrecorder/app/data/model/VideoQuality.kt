package com.bgrecorder.app.data.model

/**
 * User-facing resolution tiers. CameraX's [androidx.camera.video.Quality]
 * only defines four true tiers (SD/HD/FHD/UHD ~ 480p/720p/1080p/2160p).
 * The extra tiers below (240p, 360p, 1440p) are mapped to the nearest
 * supported CameraX quality with a [FallbackStrategy] - see
 * CameraController.qualitySelectorFor(). This is called out explicitly so
 * the mapping is never a silent surprise.
 */
enum class VideoQuality(val label: String, val approxHeight: Int) {
    P240("240p", 240),
    P360("360p", 360),
    P480("480p (SD)", 480),
    P720("720p (HD)", 720),
    P1080("1080p (Full HD)", 1080),
    P1440("1440p (QHD)", 1440),
    P2160("4K (UHD)", 2160);

    companion object {
        val DEFAULT = P1080
    }
}
