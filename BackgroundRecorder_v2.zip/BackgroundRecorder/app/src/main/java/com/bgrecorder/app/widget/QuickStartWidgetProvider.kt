package com.bgrecorder.app.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import androidx.core.content.ContextCompat
import com.bgrecorder.app.R
import com.bgrecorder.app.data.model.RecordingState
import com.bgrecorder.app.service.RecordingService
import com.bgrecorder.app.service.RecordingSessionState
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

/**
 * Home-screen "Quick Start" widget: a single tap starts recording with the
 * user's default settings, or stops it if a recording is already active.
 */
@AndroidEntryPoint
class QuickStartWidgetProvider : AppWidgetProvider() {

    @Inject lateinit var sessionState: RecordingSessionState

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { id -> updateWidget(context, appWidgetManager, id) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_TOGGLE_RECORDING) {
            val isIdle = sessionState.state.value is RecordingState.Idle
            val serviceIntent = Intent(context, RecordingService::class.java).apply {
                action = if (isIdle) RecordingService.ACTION_START else RecordingService.ACTION_STOP
            }
            ContextCompat.startForegroundService(context, serviceIntent)

            val appWidgetManager = AppWidgetManager.getInstance(context)
            val ids = appWidgetManager.getAppWidgetIds(
                android.content.ComponentName(context, QuickStartWidgetProvider::class.java)
            )
            ids.forEach { id -> updateWidget(context, appWidgetManager, id) }
        }
    }

    private fun updateWidget(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int) {
        val isIdle = sessionState.state.value is RecordingState.Idle
        val views = RemoteViews(context.packageName, R.layout.widget_quick_start)
        views.setImageViewResource(
            R.id.widget_icon,
            if (isIdle) R.drawable.ic_notif_videocam else R.drawable.ic_notif_stop
        )
        views.setTextViewText(
            R.id.widget_label,
            context.getString(if (isIdle) R.string.widget_label_start else R.string.widget_label_stop)
        )

        val toggleIntent = Intent(context, QuickStartWidgetProvider::class.java).setAction(ACTION_TOGGLE_RECORDING)
        val pendingIntent = PendingIntent.getBroadcast(
            context, appWidgetId, toggleIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        views.setOnClickPendingIntent(R.id.widget_root, pendingIntent)
        appWidgetManager.updateAppWidget(appWidgetId, views)
    }

    companion object {
        const val ACTION_TOGGLE_RECORDING = "com.bgrecorder.app.widget.ACTION_TOGGLE_RECORDING"
    }
}
