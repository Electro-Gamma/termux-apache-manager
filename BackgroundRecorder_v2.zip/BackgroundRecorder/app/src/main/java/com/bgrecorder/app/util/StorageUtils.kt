package com.bgrecorder.app.util

import android.content.Context
import android.os.Environment
import android.os.StatFs

/** Helpers for reporting free/total storage across the internal volume. */
object StorageUtils {

    /** Bytes free on the primary external (app-accessible) storage volume. */
    fun freeBytes(context: Context): Long {
        return try {
            val path = context.getExternalFilesDir(null) ?: Environment.getDataDirectory()
            val stat = StatFs(path.path)
            stat.availableBlocksLong * stat.blockSizeLong
        } catch (e: Exception) {
            -1L
        }
    }

    fun totalBytes(context: Context): Long {
        return try {
            val path = context.getExternalFilesDir(null) ?: Environment.getDataDirectory()
            val stat = StatFs(path.path)
            stat.blockCountLong * stat.blockSizeLong
        } catch (e: Exception) {
            -1L
        }
    }

    /** True when free space has dropped under [thresholdBytes] (default 100MB). */
    fun isStorageLow(context: Context, thresholdBytes: Long = 100L * 1024 * 1024): Boolean {
        val free = freeBytes(context)
        return free in 0..thresholdBytes
    }
}
