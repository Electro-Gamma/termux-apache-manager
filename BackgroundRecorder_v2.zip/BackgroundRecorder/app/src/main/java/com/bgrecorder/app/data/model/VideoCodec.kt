package com.bgrecorder.app.data.model

/**
 * Preferred video codec.
 *
 * IMPORTANT / KNOWN PLATFORM LIMITATION: androidx.camera.video's [androidx.camera.video.Recorder]
 * does not currently expose a public codec/mime-type selector in its stable
 * API - it always encodes with the platform default (H.264/AVC) regardless
 * of this setting. The preference is still fully modeled, persisted and
 * shown in Settings so the UI/UX contract is complete, and so the value is
 * ready to be wired up the moment CameraX exposes this (or if the app is
 * later extended with a custom Camera2 + MediaCodec pipeline - see
 * ARCHITECTURE.md "Known Limitations & Extension Points").
 */
enum class VideoCodec {
    H264,
    H265;

    companion object {
        val DEFAULT = H264
    }
}
