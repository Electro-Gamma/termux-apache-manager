package com.bgrecorder.app.ui.record

import android.content.Context
import android.content.Intent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.bgrecorder.app.camera.CameraController
import com.bgrecorder.app.data.model.CameraFacing
import com.bgrecorder.app.data.model.FrameRate
import com.bgrecorder.app.data.model.RecordingMode
import com.bgrecorder.app.data.model.RecordingState
import com.bgrecorder.app.data.model.VideoQuality
import com.bgrecorder.app.data.repository.SettingsRepository
import com.bgrecorder.app.service.RecordingService
import com.bgrecorder.app.service.RecordingSessionState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

/** Current, editable capture selections shown on the Record screen. */
data class RecordSelection(
    val mode: RecordingMode = RecordingMode.VIDEO,
    val facing: CameraFacing = CameraFacing.BACK,
    val quality: VideoQuality = VideoQuality.DEFAULT,
    val frameRate: FrameRate = FrameRate.DEFAULT,
    val torchOn: Boolean = false
)

@HiltViewModel
class RecordViewModel @Inject constructor(
    private val cameraController: CameraController,
    private val sessionState: RecordingSessionState,
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    val recordingState: StateFlow<RecordingState> = sessionState.state

    private val _selection = MutableStateFlow(RecordSelection())
    val selection: StateFlow<RecordSelection> = _selection

    val cameraCapabilities get() = cameraController

    init {
        // Seed the on-screen selection from the user's saved defaults once,
        // the first time settings become available.
        viewModelScope.launch {
            val settings = settingsRepository.settings.value
            _selection.value = RecordSelection(
                facing = settings.defaultCameraFacing,
                quality = settings.defaultQuality,
                frameRate = settings.defaultFrameRate
            )
        }
    }

    fun selectMode(mode: RecordingMode) { _selection.value = _selection.value.copy(mode = mode) }
    fun selectQuality(quality: VideoQuality) { _selection.value = _selection.value.copy(quality = quality) }
    fun selectFrameRate(fps: FrameRate) { _selection.value = _selection.value.copy(frameRate = fps) }

    fun switchCamera(context: Context, lifecycleOwner: LifecycleOwner, previewView: PreviewView) {
        val newFacing = if (_selection.value.facing == CameraFacing.BACK) CameraFacing.FRONT else CameraFacing.BACK
        _selection.value = _selection.value.copy(facing = newFacing)
        if (recordingState.value is RecordingState.Idle) {
            viewModelScope.launch { bindIdlePreview(context, lifecycleOwner, previewView) }
        }
    }

    fun toggleTorch() {
        val newValue = !_selection.value.torchOn
        _selection.value = _selection.value.copy(torchOn = newValue)
        cameraController.enableTorch(newValue)
    }

    fun setZoom(linear: Float) = cameraController.setLinearZoom(linear)
    fun setExposureIndex(index: Int) = cameraController.setExposureCompensationIndex(index)

    /**
     * Called from the Fragment's lifecycle whenever the preview surface
     * becomes available. Delegates to either a fresh preview-only bind
     * (idle - safe to rebind) or a non-destructive surface reattachment
     * (an active recording is already bound to [RecordingService]'s own
     * lifecycle, and must never be rebound). See [CameraController] for why.
     */
    fun attachPreview(context: Context, lifecycleOwner: LifecycleOwner, previewView: PreviewView) {
        viewModelScope.launch {
            when (recordingState.value) {
                is RecordingState.Idle -> bindIdlePreview(context, lifecycleOwner, previewView)
                is RecordingState.Recording, is RecordingState.Paused -> cameraController.attachPreviewSurface(previewView)
                else -> { /* Starting/Stopping/Error: nothing to attach to yet */ }
            }
        }
    }

    fun detachPreview() = cameraController.detachPreviewSurface()

    private suspend fun bindIdlePreview(context: Context, lifecycleOwner: LifecycleOwner, previewView: PreviewView) {
        cameraController.initialize(context)
        val s = _selection.value
        cameraController.bind(
            context = context,
            lifecycleOwner = lifecycleOwner,
            previewView = previewView,
            facing = s.facing,
            quality = s.quality,
            frameRate = s.frameRate,
            bitrateBps = settingsRepository.settings.value.let { it.defaultBitratePreset.bps ?: it.customBitrateBps }
        )
    }

    fun startRecording(context: Context) {
        val s = _selection.value
        val intent = Intent(context, RecordingService::class.java).apply {
            action = RecordingService.ACTION_START
            putExtra(RecordingService.EXTRA_MODE, s.mode.name)
            putExtra(RecordingService.EXTRA_FACING, s.facing.name)
            putExtra(RecordingService.EXTRA_QUALITY, s.quality.name)
            putExtra(RecordingService.EXTRA_FRAME_RATE, s.frameRate.name)
        }
        ContextCompat.startForegroundService(context, intent)
    }

    fun pauseRecording(context: Context) = sendCommand(context, RecordingService.ACTION_PAUSE)
    fun resumeRecording(context: Context) = sendCommand(context, RecordingService.ACTION_RESUME)
    fun stopRecording(context: Context) = sendCommand(context, RecordingService.ACTION_STOP)

    private fun sendCommand(context: Context, action: String) {
        val intent = Intent(context, RecordingService::class.java).setAction(action)
        ContextCompat.startForegroundService(context, intent)
    }
}
