package com.bgrecorder.app.util

import java.util.Locale
import java.util.concurrent.TimeUnit

/** Formats milliseconds as HH:MM:SS, growing beyond 24h gracefully. */
fun Long.toTimerString(): String {
    val totalSeconds = this / 1000
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60
    return String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
}

/** Formats a byte count as a human-readable size string (KB/MB/GB). */
fun Long.toFileSizeString(): String {
    if (this <= 0) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    var value = this.toDouble()
    var unitIndex = 0
    while (value >= 1024 && unitIndex < units.lastIndex) {
        value /= 1024
        unitIndex++
    }
    return if (unitIndex == 0) {
        "${value.toInt()} ${units[unitIndex]}"
    } else {
        String.format(Locale.US, "%.1f %s", value, units[unitIndex])
    }
}

/** Formats a duration in millis as a short "1h 24m" / "3m 12s" style label. */
fun Long.toShortDurationString(): String {
    val totalSeconds = TimeUnit.MILLISECONDS.toSeconds(this)
    val h = totalSeconds / 3600
    val m = (totalSeconds % 3600) / 60
    val s = totalSeconds % 60
    return when {
        h > 0 -> "${h}h ${m}m"
        m > 0 -> "${m}m ${s}s"
        else -> "${s}s"
    }
}
