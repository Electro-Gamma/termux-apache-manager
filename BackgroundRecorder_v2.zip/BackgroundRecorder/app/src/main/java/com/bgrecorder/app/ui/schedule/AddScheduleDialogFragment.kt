package com.bgrecorder.app.ui.schedule

import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.activityViewModels
import com.bgrecorder.app.R
import com.bgrecorder.app.data.model.RecordingMode
import com.bgrecorder.app.data.model.RepeatMode
import com.bgrecorder.app.data.model.ScheduleItem
import com.bgrecorder.app.databinding.DialogAddScheduleBinding
import com.google.android.material.chip.Chip
import com.google.android.material.datepicker.MaterialDatePicker
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.timepicker.MaterialTimePicker
import com.google.android.material.timepicker.TimeFormat
import java.text.DateFormatSymbols
import java.util.Calendar
import java.util.Locale

/**
 * Modal form for creating a new [ScheduleItem]. Kept as a single dialog
 * (rather than a full screen) since the input set is small and this keeps
 * the Schedule list screen as the obvious source of truth.
 */
class AddScheduleDialogFragment : DialogFragment() {

    private val viewModel: ScheduleViewModel by activityViewModels()
    private lateinit var binding: DialogAddScheduleBinding

    private var repeatMode = RepeatMode.ONCE
    private var recordingMode = RecordingMode.VIDEO
    private val selectedDays = mutableSetOf<Int>()
    private var pickedDateMillis: Long = System.currentTimeMillis()
    private var startHour = 8
    private var startMinute = 0
    private var stopHour = 8
    private var stopMinute = 30

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        binding = DialogAddScheduleBinding.inflate(LayoutInflater.from(requireContext()))

        setupRepeatChips()
        setupDayChips()
        setupModeChips()
        setupTimeAndDatePickers()
        refreshButtonLabels()

        val dialog = MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.schedule_add_title)
            .setView(binding.root)
            .setPositiveButton(R.string.schedule_save, null) // wired below to allow validation
            .setNegativeButton(R.string.schedule_cancel, null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(Dialog.BUTTON_POSITIVE).setOnClickListener {
                if (saveSchedule()) dialog.dismiss()
            }
        }
        return dialog
    }

    private fun setupRepeatChips() {
        val map = mapOf(
            binding.chipRepeatOnce.id to RepeatMode.ONCE,
            binding.chipRepeatDaily.id to RepeatMode.DAILY,
            binding.chipRepeatWeekly.id to RepeatMode.WEEKLY,
            binding.chipRepeatCustom.id to RepeatMode.CUSTOM_DAYS
        )
        binding.chipGroupRepeat.setOnCheckedStateChangeListener { group, checkedIds ->
            val checkedId = checkedIds.firstOrNull() ?: return@setOnCheckedStateChangeListener
            repeatMode = map[checkedId] ?: RepeatMode.ONCE
            binding.btnPickDate.visibility = if (repeatMode == RepeatMode.ONCE) android.view.View.VISIBLE else android.view.View.GONE
            binding.chipGroupDays.visibility =
                if (repeatMode == RepeatMode.WEEKLY || repeatMode == RepeatMode.CUSTOM_DAYS) android.view.View.VISIBLE else android.view.View.GONE
        }
    }

    private fun setupDayChips() {
        val shortNames = DateFormatSymbols(Locale.getDefault()).shortWeekdays
        for (day in Calendar.SUNDAY..Calendar.SATURDAY) {
            val chip = Chip(requireContext()).apply {
                text = shortNames[day]
                isCheckable = true
                tag = day
                setOnCheckedChangeListener { _, checked ->
                    if (checked) selectedDays.add(day) else selectedDays.remove(day)
                }
            }
            binding.chipGroupDays.addView(chip)
        }
    }

    private fun setupModeChips() {
        binding.chipRecordVideo.setOnClickListener { recordingMode = RecordingMode.VIDEO }
        binding.chipRecordAudio.setOnClickListener { recordingMode = RecordingMode.AUDIO_ONLY }
    }

    private fun setupTimeAndDatePickers() {
        binding.btnPickDate.setOnClickListener {
            val picker = MaterialDatePicker.Builder.datePicker()
                .setSelection(pickedDateMillis)
                .build()
            picker.addOnPositiveButtonClickListener { selection ->
                pickedDateMillis = selection
                refreshButtonLabels()
            }
            picker.show(childFragmentManager, "date_picker")
        }

        binding.btnPickStartTime.setOnClickListener {
            val picker = MaterialTimePicker.Builder()
                .setTimeFormat(TimeFormat.CLOCK_24H)
                .setHour(startHour)
                .setMinute(startMinute)
                .build()
            picker.addOnPositiveButtonClickListener {
                startHour = picker.hour
                startMinute = picker.minute
                refreshButtonLabels()
            }
            picker.show(childFragmentManager, "start_time_picker")
        }

        binding.btnPickStopTime.setOnClickListener {
            val picker = MaterialTimePicker.Builder()
                .setTimeFormat(TimeFormat.CLOCK_24H)
                .setHour(stopHour)
                .setMinute(stopMinute)
                .build()
            picker.addOnPositiveButtonClickListener {
                stopHour = picker.hour
                stopMinute = picker.minute
                refreshButtonLabels()
            }
            picker.show(childFragmentManager, "stop_time_picker")
        }
    }

    private fun refreshButtonLabels() {
        binding.btnPickDate.text = "Date: " + java.text.DateFormat.getDateInstance(java.text.DateFormat.MEDIUM)
            .format(java.util.Date(pickedDateMillis))
        binding.btnPickStartTime.text = String.format(Locale.US, "%s: %02d:%02d", getString(R.string.schedule_start_time), startHour, startMinute)
        binding.btnPickStopTime.text = String.format(Locale.US, "%s: %02d:%02d", getString(R.string.schedule_end_time), stopHour, stopMinute)
    }

    private fun saveSchedule(): Boolean {
        val label = binding.inputLabel.text?.toString()?.ifBlank { null }
            ?: getString(R.string.nav_record)
        val item = ScheduleItem(
            label = label,
            repeatMode = repeatMode,
            startHour = startHour,
            startMinute = startMinute,
            stopHour = stopHour,
            stopMinute = stopMinute,
            daysOfWeek = selectedDays.toSet(),
            oneTimeDateMillis = if (repeatMode == RepeatMode.ONCE) pickedDateMillis else null,
            enabled = true,
            mode = recordingMode
        )
        viewModel.save(requireContext(), item)
        return true
    }
}
