package com.bgrecorder.app.ui

import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.bgrecorder.app.data.model.DarkModeOption
import com.bgrecorder.app.data.repository.SettingsRepository
import com.bgrecorder.app.databinding.ActivityMainBinding
import com.bgrecorder.app.ui.permissions.PermissionManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.bgrecorder.app.R
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Single-activity host: a bottom-navigation shell around four top-level
 * destinations (Record / Files / Schedule / Settings). Owns the one-time
 * app-level concerns that don't belong to any single screen: applying the
 * dark-mode preference and running the initial permission request flow.
 */
@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    @Inject lateinit var settingsRepository: SettingsRepository

    private lateinit var binding: ActivityMainBinding

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val denied = results.filterValues { !it }.keys
        if (denied.isNotEmpty()) {
            // The Record screen also observes permission state directly and
            // will show its own inline "grant" prompt, so a silent no-op
            // here is enough at the Activity level.
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val navHostFragment = supportFragmentManager.findFragmentById(binding.navHostFragment.id) as NavHostFragment
        val navController = navHostFragment.navController
        binding.bottomNav.setupWithNavController(navController)

        observeDarkMode()
        requestInitialPermissionsIfNeeded()
    }

    private fun observeDarkMode() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                settingsRepository.settings
                    .map { it.darkMode }
                    .distinctUntilChanged()
                    .collect { mode ->
                        AppCompatDelegate.setDefaultNightMode(
                            when (mode) {
                                DarkModeOption.LIGHT -> AppCompatDelegate.MODE_NIGHT_NO
                                DarkModeOption.DARK -> AppCompatDelegate.MODE_NIGHT_YES
                                DarkModeOption.SYSTEM -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
                            }
                        )
                    }
            }
        }
    }

    private fun requestInitialPermissionsIfNeeded() {
        val required = PermissionManager.requiredForRecording()
        val missing = PermissionManager.missing(this, required)
        if (missing.isEmpty()) return

        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.perm_rationale_title)
            .setMessage(R.string.perm_rationale_body)
            .setPositiveButton(R.string.perm_grant) { _, _ -> permissionLauncher.launch(missing) }
            .setNegativeButton(R.string.action_dismiss, null)
            .show()
    }
}
