package com.bgrecorder.app.ui.record

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.bgrecorder.app.R
import com.bgrecorder.app.data.model.CameraFacing
import com.bgrecorder.app.data.model.FrameRate
import com.bgrecorder.app.data.model.RecordingMode
import com.bgrecorder.app.data.model.RecordingState
import com.bgrecorder.app.data.model.VideoQuality
import com.bgrecorder.app.databinding.FragmentRecordBinding
import com.bgrecorder.app.ui.permissions.PermissionManager
import com.bgrecorder.app.util.BatteryUtils
import com.bgrecorder.app.util.StorageUtils
import com.bgrecorder.app.util.toFileSizeString
import com.bgrecorder.app.util.toTimerString
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * The primary recording screen: live preview, transport controls, quality/
 * camera selectors and at-a-glance status (timer, battery, free storage).
 */
@AndroidEntryPoint
class RecordFragment : Fragment(R.layout.fragment_record) {

    private val viewModel: RecordViewModel by viewModels()
    private var binding: FragmentRecordBinding? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results.values.all { it }) {
            hideMessageCard()
            attachPreview()
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val b = FragmentRecordBinding.bind(view)
        binding = b

        setupSelectors(b)
        setupTransportControls(b)
        setupSideControls(b)
        observeRecordingState(b)
        observeSelection(b)
        startStatusTicker(b)
    }

    override fun onResume() {
        super.onResume()
        if (hasCameraAndMicPermission()) {
            hideMessageCard()
            attachPreview()
        } else {
            showPermissionPrompt()
        }
    }

    override fun onPause() {
        super.onPause()
        viewModel.detachPreview()
    }

    // -------------------------------------------------------------------

    private fun hasCameraAndMicPermission(): Boolean {
        val ctx = requireContext()
        return ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    }

    private fun attachPreview() {
        val b = binding ?: return
        viewModel.attachPreview(requireContext(), viewLifecycleOwner, b.previewView)
    }

    private fun showPermissionPrompt() {
        val b = binding ?: return
        b.cardMessage.visibility = View.VISIBLE
        b.textMessage.text = getString(R.string.perm_rationale_body)
        b.btnMessageAction.text = getString(R.string.perm_grant)
        b.btnMessageAction.setOnClickListener {
            permissionLauncher.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
        }
    }

    private fun hideMessageCard() {
        binding?.cardMessage?.visibility = View.GONE
    }

    private fun setupSelectors(b: FragmentRecordBinding) {
        val qualityAdapter = ArrayAdapter(
            requireContext(), android.R.layout.simple_spinner_dropdown_item, VideoQuality.entries.map { it.label }
        )
        b.spinnerQuality.adapter = qualityAdapter
        b.spinnerQuality.setSelection(VideoQuality.entries.indexOf(viewModel.selection.value.quality))
        b.spinnerQuality.onItemSelectedListener = simpleSelectionListener { position ->
            viewModel.selectQuality(VideoQuality.entries[position])
        }

        val fpsAdapter = ArrayAdapter(
            requireContext(), android.R.layout.simple_spinner_dropdown_item, FrameRate.entries.map { "${it.fps} fps" }
        )
        b.spinnerFps.adapter = fpsAdapter
        b.spinnerFps.setSelection(FrameRate.entries.indexOf(viewModel.selection.value.frameRate))
        b.spinnerFps.onItemSelectedListener = simpleSelectionListener { position ->
            viewModel.selectFrameRate(FrameRate.entries[position])
        }

        b.chipModeVideo.setOnClickListener { viewModel.selectMode(RecordingMode.VIDEO) }
        b.chipModeAudio.setOnClickListener { viewModel.selectMode(RecordingMode.AUDIO_ONLY) }
    }

    private fun setupTransportControls(b: FragmentRecordBinding) {
        b.fabRecord.setOnClickListener {
            when (viewModel.recordingState.value) {
                is RecordingState.Idle, is RecordingState.Error -> viewModel.startRecording(requireContext())
                else -> { /* while recording, the FAB is purely decorative - pause/stop are the separate buttons */ }
            }
        }
        b.btnPauseResume.setOnClickListener {
            when (viewModel.recordingState.value) {
                is RecordingState.Recording -> viewModel.pauseRecording(requireContext())
                is RecordingState.Paused -> viewModel.resumeRecording(requireContext())
                else -> Unit
            }
        }
        b.btnStop.setOnClickListener { viewModel.stopRecording(requireContext()) }
        b.btnSwitchCamera.setOnClickListener {
            viewModel.switchCamera(requireContext(), viewLifecycleOwner, b.previewView)
        }
        b.btnTorch.setOnClickListener { viewModel.toggleTorch() }
    }

    private fun setupSideControls(b: FragmentRecordBinding) {
        b.sliderZoom.addOnChangeListener { _, value, fromUser -> if (fromUser) viewModel.setZoom(value) }
        b.sliderExposure.addOnChangeListener { _, value, fromUser -> if (fromUser) viewModel.setExposureIndex(value.toInt()) }
    }

    private fun observeRecordingState(b: FragmentRecordBinding) {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.recordingState.collect { state -> renderState(b, state) }
            }
        }
    }

    private fun observeSelection(b: FragmentRecordBinding) {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.selection.collect { selection ->
                    b.btnTorch.setImageResource(if (selection.torchOn) R.drawable.ic_flash_on else R.drawable.ic_flash_off)
                    b.chipModeVideo.isChecked = selection.mode == RecordingMode.VIDEO
                    b.chipModeAudio.isChecked = selection.mode == RecordingMode.AUDIO_ONLY
                    b.previewView.visibility = if (selection.mode == RecordingMode.VIDEO) View.VISIBLE else View.INVISIBLE
                }
            }
        }
    }

    private fun renderState(b: FragmentRecordBinding, state: RecordingState) {
        val isRecording = state is RecordingState.Recording
        val isPaused = state is RecordingState.Paused
        val isActive = isRecording || isPaused

        b.recordingDot.visibility = if (isRecording) View.VISIBLE else View.INVISIBLE
        b.btnPauseResume.visibility = if (isActive) View.VISIBLE else View.GONE
        b.btnStop.visibility = if (isActive) View.VISIBLE else View.GONE
        b.fabRecord.isEnabled = state is RecordingState.Idle || state is RecordingState.Error
        b.fabRecord.alpha = if (b.fabRecord.isEnabled) 1f else 0.5f

        b.btnPauseResume.setIconResource(if (isPaused) R.drawable.ic_notif_play else R.drawable.ic_notif_pause)

        val elapsed = when (state) {
            is RecordingState.Recording -> state.elapsedMillis
            is RecordingState.Paused -> state.elapsedMillis
            else -> 0L
        }
        b.textTimer.text = elapsed.toTimerString()

        if (state is RecordingState.Error) {
            b.cardMessage.visibility = View.VISIBLE
            b.textMessage.setText(state.error.messageRes)
            b.btnMessageAction.text = getString(R.string.action_dismiss)
            b.btnMessageAction.setOnClickListener { hideMessageCard() }
        }
    }

    private fun startStatusTicker(b: FragmentRecordBinding) {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                while (true) {
                    val ctx = context
                    if (ctx != null) {
                        val battery = BatteryUtils.batteryLevelPercent(ctx)
                        b.textBattery.text = if (battery >= 0) getString(R.string.label_battery_level, battery) else ""
                        val free = StorageUtils.freeBytes(ctx)
                        b.textStorage.text = if (free >= 0) getString(R.string.label_storage_free, free.toFileSizeString()) else ""
                    }
                    delay(5000)
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        binding = null
    }

    private fun simpleSelectionListener(onSelected: (Int) -> Unit) =
        object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                onSelected(position)
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
        }
}
