package com.bgrecorder.app.ui.schedule

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.bgrecorder.app.R
import com.bgrecorder.app.databinding.FragmentScheduleBinding
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

/** Lists all recording schedules and hosts the "add schedule" flow. */
@AndroidEntryPoint
class ScheduleFragment : Fragment(R.layout.fragment_schedule) {

    private val viewModel: ScheduleViewModel by activityViewModels()
    private var binding: FragmentScheduleBinding? = null
    private lateinit var adapter: ScheduleAdapter

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val b = FragmentScheduleBinding.bind(view)
        binding = b

        adapter = ScheduleAdapter(
            nextRunProvider = { viewModel.nextRunMillis(it) },
            onToggle = { item, enabled -> viewModel.setEnabled(requireContext(), item, enabled) },
            onDelete = { item -> viewModel.delete(requireContext(), item) }
        )
        b.recyclerSchedules.layoutManager = LinearLayoutManager(requireContext())
        b.recyclerSchedules.adapter = adapter

        b.fabAddSchedule.setOnClickListener {
            AddScheduleDialogFragment().show(childFragmentManager, "add_schedule")
        }

        observeSchedules(b)
    }

    private fun observeSchedules(b: FragmentScheduleBinding) {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.schedules.collect { list ->
                    adapter.submitList(list)
                    b.scheduleEmptyState.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        binding = null
    }
}
