package com.bgrecorder.app.data.model

/** How a schedule repeats. */
enum class RepeatMode { ONCE, DAILY, WEEKLY, CUSTOM_DAYS }

/**
 * A user-defined recording schedule. [daysOfWeek] is only meaningful for
 * [RepeatMode.WEEKLY] (single day) and [RepeatMode.CUSTOM_DAYS] (any subset),
 * using [java.util.Calendar] day constants (1=Sunday..7=Saturday).
 */
data class ScheduleItem(
    val id: Long = 0L,
    val label: String,
    val repeatMode: RepeatMode,
    val startHour: Int,
    val startMinute: Int,
    val stopHour: Int,
    val stopMinute: Int,
    val daysOfWeek: Set<Int> = emptySet(),
    val oneTimeDateMillis: Long? = null,
    val enabled: Boolean = true,
    val mode: RecordingMode = RecordingMode.VIDEO
)
