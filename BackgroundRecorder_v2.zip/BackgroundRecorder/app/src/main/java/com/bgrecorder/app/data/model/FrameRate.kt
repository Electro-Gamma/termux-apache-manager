package com.bgrecorder.app.data.model

/** Selectable capture/encode frame rates. */
enum class FrameRate(val fps: Int) {
    FPS_24(24),
    FPS_30(30),
    FPS_60(60);

    companion object {
        val DEFAULT = FPS_30
    }
}
