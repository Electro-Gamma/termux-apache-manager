package com.bgrecorder.app.data.model

enum class AudioSampleRate(val hz: Int) {
    HZ_16000(16_000),
    HZ_22050(22_050),
    HZ_44100(44_100),
    HZ_48000(48_000);

    companion object {
        val DEFAULT = HZ_44100
    }
}
