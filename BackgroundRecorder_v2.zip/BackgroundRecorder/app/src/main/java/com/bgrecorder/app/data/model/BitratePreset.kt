package com.bgrecorder.app.data.model

/**
 * Video bitrate presets in bits-per-second. [CUSTOM] defers to a user
 * supplied value stored separately in [com.bgrecorder.app.data.model.AppSettings.customBitrateBps].
 */
enum class BitratePreset(val bps: Int?) {
    LOW(2_000_000),
    MEDIUM(6_000_000),
    HIGH(12_000_000),
    CUSTOM(null);

    companion object {
        val DEFAULT = MEDIUM
    }
}
