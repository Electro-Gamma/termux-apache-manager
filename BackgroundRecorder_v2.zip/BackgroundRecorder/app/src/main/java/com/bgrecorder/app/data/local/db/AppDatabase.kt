package com.bgrecorder.app.data.local.db

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters

/**
 * Single Room database for the app. Two small, independent tables
 * (recordings metadata cache + schedules) - deliberately kept in one
 * database file since both are tiny and always needed together.
 */
@Database(
    entities = [RecordingEntity::class, ScheduleEntity::class],
    version = 1,
    exportSchema = true
)
@TypeConverters(Converters::class, ScheduleConverters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun recordingDao(): RecordingDao
    abstract fun scheduleDao(): ScheduleDao

    companion object {
        const val DATABASE_NAME = "bg_recorder.db"
    }
}
