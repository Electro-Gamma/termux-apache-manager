package com.bgrecorder.app.data.model

/** Snapshot of what the currently selected camera device can actually do. */
data class CameraCapabilities(
    val availableFacings: List<CameraFacing>,
    val supportedFrameRates: List<Int>,
    val maxZoomRatio: Float,
    val minZoomRatio: Float,
    val hasFlash: Boolean,
    val minExposureIndex: Int,
    val maxExposureIndex: Int,
    val exposureStep: Float
)
