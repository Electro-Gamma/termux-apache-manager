package com.bgrecorder.app.schedule

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.bgrecorder.app.data.model.RepeatMode
import com.bgrecorder.app.data.model.ScheduleItem
import com.bgrecorder.app.data.repository.ScheduleRepository
import java.util.Calendar
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Computes trigger times for [ScheduleItem]s and arms/disarms the
 * corresponding [AlarmManager] alarms. Repeating schedules (daily/weekly/
 * custom days) are implemented as **self-rescheduling one-shot exact
 * alarms**: each time [ScheduleAlarmReceiver] fires, it asks this class to
 * compute the *next* occurrence and re-arms a fresh one-shot alarm for it.
 * This is the standard, documented pattern for reliable day-of-week /
 * daily scheduling on Android (AlarmManager.setRepeating is intentionally
 * inexact and unsuitable for "start recording at exactly 9:00 AM").
 */
@Singleton
class ScheduleManager @Inject constructor(
    private val scheduleRepository: ScheduleRepository
) {

    fun canScheduleExactAlarms(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        return am.canScheduleExactAlarms()
    }

    /** Arms both the start and (optional) stop alarms for [schedule]. */
    fun arm(context: Context, schedule: ScheduleItem) {
        val nextStart = computeNextOccurrence(schedule, isStart = true) ?: return
        scheduleAlarmAt(context, schedule, nextStart, isStart = true)

        if (schedule.stopHour != schedule.startHour || schedule.stopMinute != schedule.startMinute) {
            val nextStop = computeNextOccurrence(schedule, isStart = false, referenceStart = nextStart)
            if (nextStop != null) scheduleAlarmAt(context, schedule, nextStop, isStart = false)
        }
    }

    fun disarm(context: Context, schedule: ScheduleItem) {
        cancelPendingIntent(context, schedule.id, isStart = true)
        cancelPendingIntent(context, schedule.id, isStart = false)
    }

    suspend fun rearmAllSchedules(context: Context) {
        scheduleRepository.getEnabled().forEach { arm(context, it) }
    }

    /** Called by [ScheduleAlarmReceiver] once a start/stop alarm has fired, to chain the next one. */
    suspend fun handleFired(context: Context, scheduleId: Long, wasStart: Boolean) {
        val schedule = scheduleRepository.getById(scheduleId) ?: return
        if (!schedule.enabled) return
        if (schedule.repeatMode == RepeatMode.ONCE) {
            if (!wasStart) return // one-time schedule fully consumed once its stop alarm fires
            return
        }
        // Repeating schedule: re-arm the same alarm type for its next occurrence.
        val next = computeNextOccurrence(schedule, isStart = wasStart, referenceNow = System.currentTimeMillis() + 60_000)
        if (next != null) scheduleAlarmAt(context, schedule, next, isStart = wasStart)
    }

    // ---------------------------------------------------------------------

    private fun scheduleAlarmAt(context: Context, schedule: ScheduleItem, triggerAtMillis: Long, isStart: Boolean) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, ScheduleAlarmReceiver::class.java).apply {
            putExtra(ScheduleAlarmReceiver.EXTRA_SCHEDULE_ID, schedule.id)
            putExtra(ScheduleAlarmReceiver.EXTRA_IS_START, isStart)
            putExtra(ScheduleAlarmReceiver.EXTRA_MODE, schedule.mode.name)
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context, requestCode(schedule.id, isStart), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        if (canScheduleExactAlarms(context)) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent)
        } else {
            // Falls back to an inexact-but-battery-friendly alarm; the system
            // may deliver it a little late. The user can grant exact-alarm
            // permission from Settings to restore precise timing.
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent)
        }
    }

    private fun cancelPendingIntent(context: Context, scheduleId: Long, isStart: Boolean) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, ScheduleAlarmReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context, requestCode(scheduleId, isStart), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        am.cancel(pendingIntent)
    }

    private fun requestCode(scheduleId: Long, isStart: Boolean): Int =
        (scheduleId.toInt() * 2) + if (isStart) 0 else 1

    /**
     * Finds the next millisecond timestamp (strictly after [referenceNow])
     * at which [schedule]'s start (or stop) time next occurs, honoring its
     * [RepeatMode]. Returns null once a [RepeatMode.ONCE] schedule's single
     * occurrence has already passed.
     */
    fun computeNextOccurrence(
        schedule: ScheduleItem,
        isStart: Boolean,
        referenceNow: Long = System.currentTimeMillis(),
        referenceStart: Long? = null
    ): Long? {
        val hour = if (isStart) schedule.startHour else schedule.stopHour
        val minute = if (isStart) schedule.startMinute else schedule.stopMinute

        return when (schedule.repeatMode) {
            RepeatMode.ONCE -> {
                val base = schedule.oneTimeDateMillis ?: return null
                val cal = Calendar.getInstance().apply {
                    timeInMillis = base
                    set(Calendar.HOUR_OF_DAY, hour)
                    set(Calendar.MINUTE, minute)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }
                // If this is the stop time and it's earlier in the day than
                // the start time, it means "stop the next day" (overnight recording).
                if (!isStart && referenceStart != null && cal.timeInMillis <= referenceStart) {
                    cal.add(Calendar.DAY_OF_YEAR, 1)
                }
                cal.timeInMillis.takeIf { it > referenceNow }
            }
            RepeatMode.DAILY -> nextDailyOccurrence(hour, minute, referenceNow)
            RepeatMode.WEEKLY, RepeatMode.CUSTOM_DAYS -> nextWeeklyOccurrence(hour, minute, schedule.daysOfWeek, referenceNow)
        }
    }

    private fun nextDailyOccurrence(hour: Int, minute: Int, referenceNow: Long): Long {
        val cal = Calendar.getInstance().apply {
            timeInMillis = referenceNow
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (cal.timeInMillis <= referenceNow) cal.add(Calendar.DAY_OF_YEAR, 1)
        return cal.timeInMillis
    }

    private fun nextWeeklyOccurrence(hour: Int, minute: Int, daysOfWeek: Set<Int>, referenceNow: Long): Long? {
        if (daysOfWeek.isEmpty()) return null
        val cal = Calendar.getInstance().apply {
            timeInMillis = referenceNow
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        for (dayOffset in 0..7) {
            val candidate = cal.clone() as Calendar
            candidate.add(Calendar.DAY_OF_YEAR, dayOffset)
            if (candidate.get(Calendar.DAY_OF_WEEK) in daysOfWeek && candidate.timeInMillis > referenceNow) {
                return candidate.timeInMillis
            }
        }
        return null
    }
}
