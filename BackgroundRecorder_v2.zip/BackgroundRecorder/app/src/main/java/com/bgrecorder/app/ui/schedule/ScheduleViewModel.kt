package com.bgrecorder.app.ui.schedule

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.bgrecorder.app.data.model.ScheduleItem
import com.bgrecorder.app.data.repository.ScheduleRepository
import com.bgrecorder.app.schedule.ScheduleManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ScheduleViewModel @Inject constructor(
    private val scheduleRepository: ScheduleRepository,
    private val scheduleManager: ScheduleManager
) : ViewModel() {

    val schedules: StateFlow<List<ScheduleItem>> = scheduleRepository.observeSchedules()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun save(context: Context, item: ScheduleItem) {
        viewModelScope.launch {
            val id = scheduleRepository.save(item)
            val saved = item.copy(id = id)
            if (saved.enabled) scheduleManager.arm(context, saved)
        }
    }

    fun setEnabled(context: Context, item: ScheduleItem, enabled: Boolean) {
        viewModelScope.launch {
            val updated = item.copy(enabled = enabled)
            scheduleRepository.save(updated)
            if (enabled) scheduleManager.arm(context, updated) else scheduleManager.disarm(context, updated)
        }
    }

    fun delete(context: Context, item: ScheduleItem) {
        viewModelScope.launch {
            scheduleManager.disarm(context, item)
            scheduleRepository.delete(item)
        }
    }

    fun nextRunMillis(item: ScheduleItem): Long? = scheduleManager.computeNextOccurrence(item, isStart = true)
}
