package com.bgrecorder.app.ui.schedule

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bgrecorder.app.data.model.RepeatMode
import com.bgrecorder.app.data.model.ScheduleItem
import com.bgrecorder.app.databinding.ItemScheduleBinding
import java.text.DateFormat
import java.util.Date
import java.util.Locale

class ScheduleAdapter(
    private val nextRunProvider: (ScheduleItem) -> Long?,
    private val onToggle: (ScheduleItem, Boolean) -> Unit,
    private val onDelete: (ScheduleItem) -> Unit
) : ListAdapter<ScheduleItem, ScheduleAdapter.ViewHolder>(DIFF) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemScheduleBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) = holder.bind(getItem(position))

    inner class ViewHolder(private val binding: ItemScheduleBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(item: ScheduleItem) {
            binding.scheduleLabel.text = item.label
            val startLabel = String.format(Locale.US, "%02d:%02d", item.startHour, item.startMinute)
            val stopLabel = String.format(Locale.US, "%02d:%02d", item.stopHour, item.stopMinute)
            val repeatLabel = when (item.repeatMode) {
                RepeatMode.ONCE -> "One-time"
                RepeatMode.DAILY -> "Daily"
                RepeatMode.WEEKLY -> "Weekly"
                RepeatMode.CUSTOM_DAYS -> "Custom days"
            }
            binding.scheduleDetails.text = "$repeatLabel • $startLabel - $stopLabel"

            binding.scheduleToggle.setOnCheckedChangeListener(null)
            binding.scheduleToggle.isChecked = item.enabled
            binding.scheduleToggle.setOnCheckedChangeListener { _, checked -> onToggle(item, checked) }
            binding.scheduleDelete.setOnClickListener { onDelete(item) }

            val next = if (item.enabled) nextRunProvider(item) else null
            binding.scheduleNextRun.text = if (next != null) {
                "Next: " + DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(next))
            } else ""
        }
    }

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<ScheduleItem>() {
            override fun areItemsTheSame(oldItem: ScheduleItem, newItem: ScheduleItem) = oldItem.id == newItem.id
            override fun areContentsTheSame(oldItem: ScheduleItem, newItem: ScheduleItem) = oldItem == newItem
        }
    }
}
