package com.bgrecorder.app.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.bgrecorder.app.schedule.ScheduleManager
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Re-arms all enabled [com.bgrecorder.app.data.model.ScheduleItem]s after a
 * device reboot or app update, since [android.app.AlarmManager] alarms do
 * not survive either. Also optionally auto-starts the recording service if
 * the user enabled "auto-start on boot" in Settings.
 */
@AndroidEntryPoint
class BootCompletedReceiver : BroadcastReceiver() {

    @Inject lateinit var scheduleManager: ScheduleManager

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED && intent.action != Intent.ACTION_MY_PACKAGE_REPLACED) return
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.Default).launch {
            try {
                scheduleManager.rearmAllSchedules(context)
            } finally {
                pendingResult.finish()
            }
        }
    }
}
