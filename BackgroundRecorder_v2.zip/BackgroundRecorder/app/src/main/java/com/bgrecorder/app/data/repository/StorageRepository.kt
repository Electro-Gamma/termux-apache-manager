package com.bgrecorder.app.data.repository

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.documentfile.provider.DocumentFile
import com.bgrecorder.app.data.model.RecordingMode
import com.bgrecorder.app.data.model.StorageLocation
import com.bgrecorder.app.util.FileNamingTemplate
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Resolves *where* a new recording should be written, honoring the user's
 * [StorageLocation] preference:
 *  - [StorageLocation.MEDIA_STORE]: the standard, scoped-storage-friendly
 *    path. Videos go to `Movies/BackgroundRecorder`, audio to
 *    `Music/BackgroundRecorder`, both indexed automatically by the system
 *    gallery/file apps.
 *  - [StorageLocation.CUSTOM_SAF]: a user-chosen folder anywhere (including
 *    removable SD cards) selected via the Storage Access Framework. We keep
 *    a persisted, permission-granted tree Uri and create a new
 *    [DocumentFile] per recording.
 */
@Singleton
class StorageRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {

    /** Result of resolving an output target for a new recording. */
    sealed class OutputTarget {
        data class MediaStoreTarget(val collectionUri: Uri, val values: ContentValues) : OutputTarget()
        data class SafTarget(val documentFile: DocumentFile) : OutputTarget()
    }

    fun resolveOutputTarget(
        mode: RecordingMode,
        namingTemplate: String,
        storageLocation: StorageLocation,
        customTreeUriString: String?
    ): OutputTarget {
        val extension = if (mode == RecordingMode.VIDEO) "mp4" else "m4a"
        val fileName = FileNamingTemplate.resolve(namingTemplate, extension = extension)

        if (storageLocation == StorageLocation.CUSTOM_SAF && customTreeUriString != null) {
            val treeUri = Uri.parse(customTreeUriString)
            val treeDoc = DocumentFile.fromTreeUri(context, treeUri)
            val mime = if (mode == RecordingMode.VIDEO) "video/mp4" else "audio/mp4"
            val created = treeDoc?.createFile(mime, fileName)
            if (created != null) return OutputTarget.SafTarget(created)
            // Falls through to MediaStore if SAF creation failed (e.g. permission revoked).
        }

        val collection = if (mode == RecordingMode.VIDEO) {
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        } else {
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }
        val relativeDir = if (mode == RecordingMode.VIDEO) {
            Environment.DIRECTORY_MOVIES + "/BackgroundRecorder"
        } else {
            Environment.DIRECTORY_MUSIC + "/BackgroundRecorder"
        }
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
            put(MediaStore.MediaColumns.MIME_TYPE, if (mode == RecordingMode.VIDEO) "video/mp4" else "audio/mp4")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, relativeDir)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
        }
        return OutputTarget.MediaStoreTarget(collection, values)
    }

    /** Clears the IS_PENDING flag once writing has finished (API 29+ only). */
    fun finalizeMediaStoreEntry(uri: Uri) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
            context.contentResolver.update(uri, values, null, null)
        }
    }
}
