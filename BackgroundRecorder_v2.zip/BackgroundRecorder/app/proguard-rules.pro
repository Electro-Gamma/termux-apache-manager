# Add project specific ProGuard rules here.

# Keep Room entities & DAOs referenced via reflection-free codegen (usually not required,
# but kept defensively for generated schema classes).
-keep class com.bgrecorder.app.data.local.db.** { *; }

# Hilt generated components
-keep class dagger.hilt.internal.aggregatedroot.codegen.** { *; }
-keep class hilt_aggregated_deps.** { *; }

# CameraX
-keep class androidx.camera.** { *; }

# Keep Kotlin metadata for reflection used by DataStore / Room
-keepattributes *Annotation*, Signature, InnerClasses, EnclosingMethod
