/*
 * settings.gradle.kts
 *
 * Root Gradle settings for the Background Recorder project.
 * Declares plugin/dependency repositories and included modules.
 */
pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "BackgroundRecorder"
include(":app")
