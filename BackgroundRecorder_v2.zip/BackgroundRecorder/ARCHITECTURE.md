# Architecture & Implementation Status

This document is the honest map of the codebase: what's genuinely wired up
end-to-end, what's implemented but bumps into a real Android/CameraX
platform ceiling, and what's a documented extension point rather than a
working feature. Every limitation below is also called out as a KDoc
comment at the relevant source location — this file is the consolidated
view.

## 1. Layered architecture (MVVM)

```
UI (Fragments)  ──observes──>  ViewModel (@HiltViewModel)
                                     │
                                     ▼
                        Repository (@Singleton)
                         /        |         \
                Room DB    DataStore    CameraController /
             (recordings,  (settings)   AudioOnlyRecorderEngine
              schedules)                         │
                                                  ▼
                                        RecordingService (foreground)
                                                  │
                                                  ▼
                                     RecordingSessionState (StateFlow)
                                          ▲ read by every UI surface
```

- **Fragments** (`ui/record`, `ui/files`, `ui/schedule`, `ui/settings`) are
  intentionally thin: bind ViewBinding, observe a `StateFlow` inside
  `repeatOnLifecycle(STARTED)`, forward clicks to the ViewModel.
- **ViewModels** hold UI-local state (e.g. the currently-selected but not
  yet started quality/facing/fps) and call into repositories/services.
  They never touch Android framework recording APIs directly.
- **Repositories** (`SettingsRepository`, `RecordingRepository`,
  `ScheduleRepository`, `StorageRepository`) are the single source of truth
  per concern and are all `@Singleton` via Hilt constructor injection.
- **`RecordingSessionState`** is the one piece of shared, mutable,
  process-wide state: a `@Singleton` wrapping a `MutableStateFlow<RecordingState>`,
  written exclusively by `RecordingService`. Because Hilt resolves
  `@Singleton` bindings from one application-scoped container shared by
  every `@AndroidEntryPoint` (Activities, Fragments *and* Services), the UI
  and the service observe the exact same instance without a bound-service
  connection.

## 2. The service/UI camera-binding handoff (read this first)

This is the trickiest correctness problem in the app, and worth explaining
explicitly rather than leaving as "it just works":

CameraX's `ProcessCameraProvider.bindToLifecycle(...)` ties a camera
session to a `LifecycleOwner`. If we bound the camera to the
**Activity/Fragment's** lifecycle, backgrounding the app (screen off,
switching apps) would move that lifecycle to `STOPPED`, and CameraX would
automatically unbind the camera — recording would stop. That's the
opposite of the "Background Recording" requirement.

So: **`RecordingService` (a `LifecycleService`) is always the lifecycle
owner of the actual camera binding.** It stays `STARTED` for as long as the
foreground service is alive, completely independent of what the UI is
doing.

The remaining problem: how does the UI show a **live preview** while a
service-owned recording is in progress, without ever calling
`bindToLifecycle` again (which would call `unbindAll()` internally and tear
down the in-flight `VideoCapture`/`Recording`)?

The fix, implemented in `CameraController`:

1. `bind()` **always** creates and binds a `Preview` use case alongside
   `VideoCapture`, regardless of whether a `PreviewView` is available yet.
2. A separate `attachPreviewSurface(previewView)` / `detachPreviewSurface()`
   pair lets any `PreviewView` connect to whatever `Preview` use case is
   *currently* bound, purely by calling `Preview.setSurfaceProvider(...)`
   — which never touches `ProcessCameraProvider` bindings and is safe to
   call at any time, including mid-recording.
3. `RecordFragment` therefore behaves like this:
   - **Idle**: binds its own preview-only CameraX session to
     `viewLifecycleOwner` (safe — nothing is recording yet).
   - **Recording/Paused**: does *not* bind; instead calls
     `attachPreviewSurface()` to reconnect to the service's existing
     `Preview` use case.
   - **`onPause()`**: calls `detachPreviewSurface()` — the service's
     `VideoCapture` keeps recording uninterrupted; the `Preview` use case
     simply has nowhere to draw until the UI returns.
4. When the user taps **Start**, the *service* performs the actual
   recording bind (rebinding from the Fragment's temporary preview-only
   session to its own — safe, since nothing was recording yet), then the
   Fragment reattaches its `PreviewView` to the new binding.

## 3. Feature implementation status

Legend: ✅ fully implemented · ⚠️ implemented with a documented platform
limitation · 🧩 architected extension point (not functional out of the box)

### Camera
| Feature | Status | Notes |
|---|---|---|
| Front / rear camera | ✅ | `CameraSelector.DEFAULT_FRONT/BACK_CAMERA` |
| External USB camera | 🧩 | Detected via `UsbCameraDetector` (real UVC-class enumeration); actual frame capture needs a UVC userspace driver outside the CameraX/Camera2 surface. Falls back to rear camera. See `UsbCameraDetector.kt`. |
| CameraX as primary API | ✅ | `Preview` + `VideoCapture<Recorder>` throughout |
| Camera2 for advanced control | ✅ | `Camera2Interop`/`Camera2CameraControl` for FPS range, manual focus, white balance |
| Resolution selection | ⚠️ | 480p/720p/1080p/4K map 1:1 to CameraX `Quality`; 240p/360p fall back to SD, 1440p falls back to UHD (CameraX has 4 quality tiers, not 7) |
| Frame rate selection | ✅ | `CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE` via Camera2Interop |
| Bitrate selection | ✅ | `Recorder.Builder.setTargetVideoEncodingBitRate` |
| Video codec H.264/H.265 | ⚠️ | Setting is modeled/persisted/shown in Settings; androidx.camera.video's stable `Recorder` API always encodes H.264/AVC and does not expose a public codec selector. Wiring real HEVC output would require a custom Camera2+MediaCodec pipeline. |
| Orientation control | ✅ | Target rotation follows device orientation |
| Autofocus / manual focus | ✅ | `FocusMeteringAction` (tap-to-focus) + `LENS_FOCUS_DISTANCE` via Camera2Interop |
| Exposure compensation | ✅ | `CameraControl.setExposureCompensationIndex` |
| White balance | ✅ | `CONTROL_AWB_MODE` presets via Camera2Interop |
| Zoom | ✅ | `CameraControl.setZoomRatio` / `setLinearZoom` |
| Flash / torch | ✅ | `CameraControl.enableTorch` |

### Audio
| Feature | Video mode | Audio-only mode |
|---|---|---|
| Microphone recording | ✅ | ✅ |
| Multiple mic selection | 🧩 not exposed by CameraX Recorder | 🧩 device-dependent, not wired |
| Audio codec selection | ⚠️ fixed AAC | ⚠️ AAC (MediaRecorder) |
| Sample rate | ⚠️ not exposed | ✅ `MediaRecorder.setAudioSamplingRate` |
| Bitrate | ⚠️ not exposed | ✅ `MediaRecorder.setAudioEncodingBitRate` |
| Mono/Stereo | ⚠️ not exposed | ✅ `MediaRecorder.setAudioChannels` |
| Noise suppression | ⚠️ no session id available | ✅ `NoiseSuppressor` on `MediaRecorder.getAudioSessionId()` |
| Echo cancellation | ⚠️ | ✅ `AcousticEchoCanceler` |
| Automatic gain control | ⚠️ | ✅ `AutomaticGainControl` |

**Why the split**: CameraX's `androidx.camera.video.Recorder` does not
expose an audio session id in its stable public API, which is a hard
prerequisite for attaching `android.media.audiofx` effects or overriding
sample rate/bitrate/channels. `MediaRecorder` does expose all of these, so
`AudioOnlyRecorderEngine` (used for the "Audio only" recording mode) gives
you every audio requirement in the spec for real, not just as a persisted
preference. Video-mode audio settings remain in the Settings screen and
data model (ready to wire up the moment CameraX exposes this, or if this
codebase is extended with a custom Camera2 + MediaCodec + MediaMuxer video
pipeline) but do not currently change the encoded audio in a video
recording.

### Background recording
| Feature | Status |
|---|---|
| Screen off | ✅ genuine foreground service, `camera\|microphone` types |
| App minimized | ✅ `onTaskRemoved` deliberately does not stop the service |
| Device rotation | ✅ service is fully independent of Activity lifecycle |
| Long-duration recording | ✅ partial WakeLock (12h safety cap), periodic storage/battery checks |
| Automatic recovery | ⚠️ bounded retry (2 attempts) on recoverable CameraX errors *while the process is alive*. Recovering an in-flight encoder session across an actual OS process kill is not possible on Android — no app can do this, it's a platform-level constraint on `MediaCodec`/`Recorder` session state. |
| Persistent notification w/ controls | ✅ pause/resume/stop actions via `RecordingActionReceiver` |

### Scheduling
Implemented as self-rescheduling exact `AlarmManager` one-shot alarms
(`ScheduleManager` + `ScheduleAlarmReceiver`) — the standard reliable
pattern for day-of-week scheduling on Android, since `setRepeating` is
explicitly inexact. One-time, daily, weekly and custom-day-set schedules
are all supported, with start/stop times and automatic re-arming after
reboot (`BootCompletedReceiver`). Falls back to inexact alarms if the user
hasn't granted `SCHEDULE_EXACT_ALARM` (Android 12+).

### Storage
MediaStore (scoped storage, `Movies/BackgroundRecorder` and
`Music/BackgroundRecorder`) is the default and recommended path. A
Storage-Access-Framework custom folder (including SD cards) is fully
supported via `StorageRepository` + `FileDescriptorOutputOptions`, chosen
through Settings → "Choose custom folder". File naming uses a
user-editable template with `{SimpleDateFormat-pattern}` tokens.

### File management
List/search/sort/filter, playback (via `ACTION_VIEW` to the system
player), rename, delete and share are all fully functional against the
real underlying media (`RecordingFileOps`), not just the local metadata
cache.

### Floating overlay & Quick-Start widget
Both fully implemented: `FloatingControlService` is a real
`SYSTEM_ALERT_WINDOW` overlay with drag-to-move and start/pause/stop
buttons; `QuickStartWidgetProvider` is a real home-screen App Widget that
toggles recording in one tap.

## 4. Why these specific libraries

- **Hilt over Koin**: compile-time-checked graph, first-class
  `@AndroidEntryPoint` support for `Service`/`BroadcastReceiver`/`Worker`,
  which this app leans on heavily (`RecordingService`,
  `FloatingControlService`, `BootCompletedReceiver`, `ScheduleAlarmReceiver`,
  `AutoDeleteWorker` are all Hilt entry points).
- **Room** for recordings/schedules metadata: relational querying (sort/
  filter/search) beats hand-rolled MediaStore queries for our own schedule
  data, and gives a reactive `Flow` for free.
- **DataStore (Preferences)** for settings, bridged to the Jetpack
  Preference library via a custom `PreferenceDataStore` so the Settings UI
  gets accessible, platform-consistent widgets without abandoning
  Flow-based storage everywhere else.
- **WorkManager** for the one piece of work that's genuinely periodic and
  deferrable (auto-delete old recordings) — not used for recording itself,
  which needs a real-time foreground service, not a background job queue.

## 5. Known platform limitations (summary)

1. CameraX `Recorder` always encodes H.264/AVC; H.265/HEVC selection is
   modeled but not enforced (see Camera table above).
2. CameraX `Recorder` audio (video-mode) does not expose sample rate,
   bitrate, channel count or an audio session id, so those settings only
   take effect in Audio-only mode.
3. True USB UVC camera capture needs a userspace driver outside the public
   CameraX/Camera2 surface; detection is real, capture is a documented
   extension point.
4. An in-flight recording's encoder/session state cannot survive the
   Android process being killed by the OS — this is a platform constraint,
   not an app bug. "Automatic recovery" covers recoverable errors while the
   process stays alive (e.g. camera briefly reclaimed by another app).
