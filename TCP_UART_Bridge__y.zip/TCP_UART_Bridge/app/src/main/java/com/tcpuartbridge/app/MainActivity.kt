package com.tcpuartbridge.app

import android.Manifest
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.os.SystemClock
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.google.android.material.tabs.TabLayout
import com.hoho.android.usbserial.driver.UsbSerialDriver
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.driver.UsbSerialProber
import com.tcpuartbridge.app.databinding.ActivityMainBinding
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private var bridgeService: BridgeService? = null
    private var bound = false
    private var drivers: List<UsbSerialDriver> = emptyList()
    private var selectedDriver: UsbSerialDriver? = null

    private val baudRates = intArrayOf(
        9600, 19200, 38400, 57600, 115200, 230400, 380400, 460800,
        500000, 921600, 1000000, 1382400, 1444400, 1500000,
        2000000, 2500000, 3000000, 3500000, 4000000, 4500000, 5000000
    )
    private val dataBitsOptions = intArrayOf(5, 6, 7, 8)
    private val stopBitsLabels = arrayOf("1", "1.5", "2")
    private val stopBitsValues = intArrayOf(UsbSerialPort.STOPBITS_1, UsbSerialPort.STOPBITS_1_5, UsbSerialPort.STOPBITS_2)
    private val parityLabels = arrayOf("None", "Odd", "Even", "Mark", "Space")
    private val parityValues = intArrayOf(
        UsbSerialPort.PARITY_NONE,
        UsbSerialPort.PARITY_ODD,
        UsbSerialPort.PARITY_EVEN,
        UsbSerialPort.PARITY_MARK,
        UsbSerialPort.PARITY_SPACE
    )
    private val protocolLabels = arrayOf("RFC2217 (automatic reset)", "Raw (manual reset)", "Raw (auto-baud)")
    private val protocolValues = arrayOf(ServerMode.RFC2217, ServerMode.RAW, ServerMode.RAW_AUTOBAUD)
    // BW16/AmebaD-specific auto-reset support has been removed. "Generic" now just means direct,
    // immediate RTS/DTR passthrough with no canned sequence - the RTS/DTR switches (and this mode)
    // are the fallback path for any board whose reset behavior doesn't match ESP32's.
    // "Generic" is a plain, no-sequence RTS/DTR passthrough fallback for any board whose
    // reset convention isn't known to this app. "AmebaD / BW16" has its own known sequence
    // (see TcpServerManager's auto*AmebaD* methods and Rfc2217Session's SET_CONTROL passthrough).
    private val targetChipLabels = arrayOf(
        "ESP32 (auto reset)", "AmebaD / BW16 (auto reset)", "Arduino / AVR (auto reset)", "Generic (manual RTS/DTR)"
    )
    private val targetChipValues = arrayOf(TargetChip.ESP32, TargetChip.AMEBAD, TargetChip.AVR_ARDUINO, TargetChip.GENERIC)

    private data class CliExample(val title: String, val explanation: String, val command: String)

    // Every command below uses PHONE_IP:PORT as a placeholder for whatever this app's
    // "IP: ... Port: ..." status line actually shows once the bridge is started.
    private val cliExamples = listOf(
        CliExample(
            "ESP32/ESP8266 - RFC2217 (automatic reset)",
            "App: Protocol = RFC2217, Target Chip = ESP32. esptool drives real, correctly-timed " +
                "DTR/RTS resets over the network - no manual button needed.",
            "esptool --port \"rfc2217://PHONE_IP:PORT?ign_set_control\" --baud 460800 write-flash 0x1000 firmware.bin"
        ),
        CliExample(
            "ESP32/ESP8266 - Raw (auto-baud)",
            "App: Protocol = Raw (auto-baud), Target Chip = ESP32. Plain socket, no RFC2217 - the app " +
                "watches for esptool's own baud-change command and follows it, and auto-resets the " +
                "board on connect/disconnect.",
            "esptool --port socket://PHONE_IP:PORT --baud 921600 write-flash 0x1000 firmware.bin"
        ),
        CliExample(
            "ESP32/ESP8266 - Raw (manual reset)",
            "App: Protocol = Raw (manual reset). Works with any TCP client, but no auto-reset - put the " +
                "board in bootloader mode yourself first (the app's Reset to Bootloader button or " +
                "RTS/DTR switches).",
            "esptool --port socket://PHONE_IP:PORT --baud 460800 --before no-reset --after no-reset write-flash 0x1000 firmware.bin"
        ),
        CliExample(
            "Erase one flash region",
            "Erases only the given address range - e.g. to clear saved WiFi/NVS settings without " +
                "touching the rest of flash. Offset and size must both be a multiple of 0x1000 (4096).",
            "esptool --port socket://PHONE_IP:PORT erase-region 0x9000 0x6000"
        ),
        CliExample(
            "Erase the entire flash chip",
            "Wipes everything - bootloader, partition table, app, all data. Good starting point for a " +
                "device that's in an unknown or corrupted state.",
            "esptool --port socket://PHONE_IP:PORT erase-flash"
        ),
        CliExample(
            "Read back a partition (e.g. SPIFFS)",
            "Dumps a region of flash to a local file - useful to back up or inspect a SPIFFS/LittleFS " +
                "partition before erasing it. Get the real offset/size for your device from the " +
                "parttool.py example below rather than guessing.",
            "esptool --port socket://PHONE_IP:PORT read-flash 0x290000 0x170000 spiffs_dump.bin"
        ),
        CliExample(
            "Query the partition table (ESP-IDF parttool.py)",
            "Reads a named partition's real offset/size straight from the device instead of guessing - " +
                "use its output for the read-flash example above.",
            "parttool.py --port socket://PHONE_IP:PORT get_partition_info --partition-name=spiffs"
        ),
        CliExample(
            "AmebaD / BW16 (upload_amebad.py)",
            "App: Protocol = Raw (auto-baud), Target Chip = AmebaD / BW16 (auto reset). Don't pass " +
                "--auto - the script's own DTR/RTS attempt is a no-op over a plain socket anyway; the " +
                "app handles reset automatically instead.",
            "python upload_amebad.py path/to/firmware_dir socket://PHONE_IP:PORT"
        ),
        CliExample(
            "Arduino / AVR (avrdude)",
            "App: Protocol = Raw (auto-baud), Target Chip = Arduino / AVR (auto reset). Use -c stk500v1, " +
                "not -c arduino - the latter tries its own DTR/RTS ioctl, which fails on a network port " +
                "(\"Inappropriate ioctl for device\") and never actually resets the chip; the app drives " +
                "the reset instead.",
            "avrdude -p atmega328p -c stk500v1 -P net:PHONE_IP:PORT -b 115200 -U flash:w:blink.ino.hex:i"
        ),
        CliExample(
            "Any other UART device (plain terminal)",
            "Raw (manual reset) is a plain byte pipe - works with anything that just talks over a TCP " +
                "socket, no ESP/AVR/AmebaD-specific tooling needed.",
            "nc PHONE_IP PORT"
        )
    )

    private val serviceConnection = object : android.content.ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val localBinder = service as BridgeService.LocalBinder
            bridgeService = localBinder.getService()
            bound = true
            bridgeService?.setListener(bridgeListener)
            bridgeService?.getStatus()?.let { updateStatusUi(it) }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            bound = false
            bridgeService = null
        }
    }

    private val bridgeListener = object : BridgeListener {
        override fun onLog(message: String) {
            runOnUiThread { appendLog(message) }
        }

        override fun onStatusChanged(status: BridgeStatus) {
            runOnUiThread { updateStatusUi(status) }
        }
    }

    private val usbAttachReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                UsbManager.ACTION_USB_DEVICE_ATTACHED,
                UsbManager.ACTION_USB_DEVICE_DETACHED -> refreshDeviceList()
            }
        }
    }

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* no-op either way */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupSpinners()
        setupTabs()
        populateExamples()
        refreshDeviceList()
        applyBottomInsets()

        binding.btnRefreshDevices.setOnClickListener { refreshDeviceList() }
        binding.btnStartStop.setOnClickListener { onStartStopClicked() }
        binding.switchRts.setOnCheckedChangeListener { _, checked -> bridgeService?.setRTS(checked) }
        binding.switchDtr.setOnCheckedChangeListener { _, checked -> bridgeService?.setDTR(checked) }
        binding.btnAutoReset.setOnClickListener { performAutoReset() }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        val filter = IntentFilter().apply {
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(usbAttachReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(usbAttachReceiver, filter)
        }

        bindService(Intent(this, BridgeService::class.java), serviceConnection, Context.BIND_AUTO_CREATE)
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(usbAttachReceiver)
        if (bound) {
            bridgeService?.setListener(null)
            unbindService(serviceConnection)
            bound = false
        }
    }

    private var currentTargetChip = TargetChip.ESP32
    private var currentProtocolMode = ServerMode.RFC2217

    // ---- setup ------------------------------------------------------------

    // ---- tabs / examples ---------------------------------------------

    private fun setupTabs() {
        binding.tabLayout.addTab(binding.tabLayout.newTab().setText(R.string.tab_bridge))
        binding.tabLayout.addTab(binding.tabLayout.newTab().setText(R.string.tab_examples))
        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                val showExamples = tab.position == 1
                binding.llBridgePanel.visibility = if (showExamples) View.GONE else View.VISIBLE
                binding.llExamplesPanel.visibility = if (showExamples) View.VISIBLE else View.GONE
            }

            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })
    }

    /** Inflates one card per [cliExamples] entry into llExamplesContainer, each with a working Copy button. */
    private fun populateExamples() {
        val inflater = LayoutInflater.from(this)
        cliExamples.forEach { example ->
            val itemView = inflater.inflate(R.layout.item_example, binding.llExamplesContainer, false)
            itemView.findViewById<TextView>(R.id.tvExampleTitle).text = example.title
            itemView.findViewById<TextView>(R.id.tvExampleExplanation).text = example.explanation
            itemView.findViewById<TextView>(R.id.tvExampleCommand).text = example.command
            itemView.findViewById<Button>(R.id.btnCopyExample).setOnClickListener {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText(example.title, example.command))
                Toast.makeText(this, "Copied to clipboard", Toast.LENGTH_SHORT).show()
            }
            binding.llExamplesContainer.addView(itemView)
        }
    }

    private fun setupSpinners() {
        binding.spinnerBaud.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, baudRates.map { it.toString() }
        )
        binding.spinnerBaud.setSelection(baudRates.indexOf(115200))

        binding.spinnerDataBits.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, dataBitsOptions.map { it.toString() }
        )
        binding.spinnerDataBits.setSelection(dataBitsOptions.indexOf(8))

        binding.spinnerStopBits.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, stopBitsLabels
        )
        binding.spinnerStopBits.setSelection(0)

        binding.spinnerParity.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, parityLabels
        )
        binding.spinnerParity.setSelection(0)

        binding.spinnerTargetChip.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, targetChipLabels
        )
        binding.spinnerTargetChip.setSelection(0) // ESP32 by default
        binding.spinnerTargetChip.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                currentTargetChip = targetChipValues[position]
                refreshHints()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        binding.spinnerProtocol.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, protocolLabels
        )
        binding.spinnerProtocol.setSelection(0) // RFC2217 by default
        binding.spinnerProtocol.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                currentProtocolMode = protocolValues[position]
                refreshHints()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        refreshHints()
        binding.etTcpPort.setText("3333")
    }

    private fun refreshHints() {
        binding.tvProtocolHint.text = when (currentProtocolMode) {
            ServerMode.RFC2217 ->
                "RFC2217: esptool talks to this app directly and drives real, correctly-timed DTR/RTS resets. " +
                    "Use --port rfc2217://PHONE_IP:PORT?ign_set_control with esptool."
            ServerMode.RAW_AUTOBAUD ->
                "Raw (auto-baud): plain byte passthrough like Raw, but this app watches the wire for " +
                    "esptool's or upload_amebad.py's own baud-change command and follows it, so --baud works " +
                    "over a plain socket:// without RFC2217. Always opens at 115200 first (data bits/stop " +
                    "bits/parity below still apply - the Baud Rate value itself is ignored here), and resets " +
                    "back to 115200 when the connection closes, ready for the next session. With Target Chip " +
                    "set to ESP32, AmebaD/BW16, or Arduino/AVR, it also auto-resets the board into " +
                    "download/bootloader mode when a client connects (and, for ESP32/AmebaD, boots the " +
                    "flashed app when it disconnects too) - no manual button needed."
            else ->
                "Raw: plain byte passthrough, works with any TCP client " +
                    "(nc, PuTTY raw socket, esptool --port socket://...), but has no channel for remote reset control."
        }

        binding.tvEsp32Note.text = when {
            currentTargetChip == TargetChip.GENERIC && currentProtocolMode == ServerMode.RFC2217 ->
                "Generic mode: DTR/RTS commands from the client are relayed straight through with no " +
                    "sequence timing. Use this if the automatic ESP32/AmebaD/AVR reset sequences don't work " +
                    "on your board - or fall back to the RTS/DTR switches below to drive the lines by hand."
            currentTargetChip == TargetChip.GENERIC ->
                "Generic mode: no automatic sequence is applied here. Use the RTS/DTR switches below as a " +
                    "manual fallback to put the board in bootloader/download mode by hand - useful for boards " +
                    "whose reset conventions don't match ESP32's, AmebaD's, or AVR's."
            currentTargetChip == TargetChip.AMEBAD && currentProtocolMode == ServerMode.RAW_AUTOBAUD ->
                "Raw (auto-baud) automatically runs the AmebaD download-mode-entry sequence when a client " +
                    "connects, and resets to normal boot when it disconnects - you shouldn't need this button " +
                    "or the switches. They're still here as a fallback if that doesn't work on your board " +
                    "(manually flipping both switches by hand is unlikely to hit the required 500ms/200ms/500ms " +
                    "timing reliably, though - prefer this button, which runs the same timed sequence in code)."
            currentTargetChip == TargetChip.AMEBAD ->
                "AmebaD/BW16 download-mode sequence (500ms/200ms/500ms, from upload_amebad.py's " +
                    "enter_download_mode()). Only auto-runs on connect/disconnect in Raw (auto-baud) mode - " +
                    "elsewhere, use this button before flashing. Manually flipping the switches by hand is " +
                    "unlikely to hit the timing reliably; prefer this button."
            currentTargetChip == TargetChip.AVR_ARDUINO && currentProtocolMode == ServerMode.RAW_AUTOBAUD ->
                "Raw (auto-baud) automatically runs this reset sequence when a client connects - you " +
                    "shouldn't need this button or the switches. No pulse is needed on disconnect: Optiboot-" +
                    "style bootloaders jump to the flashed app on their own after a short idle timeout. Use " +
                    "avrdude's -c stk500v1, not -c arduino - the latter tries its own DTR/RTS ioctl, which " +
                    "fails on a network port and never actually resets the chip."
            currentTargetChip == TargetChip.AVR_ARDUINO ->
                "Arduino/AVR bootloader-entry sequence (250ms/50ms, copied from avrdude's own " +
                    "arduino_open()). Only auto-runs on connect in Raw (auto-baud) mode - elsewhere, use this " +
                    "button before flashing. Use avrdude's -c stk500v1, not -c arduino - the latter tries its " +
                    "own DTR/RTS ioctl, which fails on a network port and never actually resets the chip."
            currentProtocolMode == ServerMode.RAW_AUTOBAUD ->
                "Raw (auto-baud) automatically runs this sequence when a client connects, and a plain hard " +
                    "reset when it disconnects - you shouldn't need these manual switches. They're still here " +
                    "as a fallback if that doesn't work on your board."
            currentProtocolMode == ServerMode.RFC2217 ->
                "In RFC2217 mode, esptool resets the board automatically before/after flashing - you " +
                    "shouldn't need these manual switches. They're still here as a fallback: if the automatic " +
                    "sequence fails on your board, drive RTS/DTR by hand with the switches or this button."
            else ->
                "Note: a plain TCP socket has no control-line channel, so esptool.py cannot toggle RTS/DTR " +
                    "remotely over socket://. Use this button, or the RTS/DTR switches, to put the board in " +
                    "bootloader mode before flashing, then run esptool with --before no-reset --after no-reset."
        }
    }

    private fun refreshDeviceList() {
        val usbManager = getSystemService(Context.USB_SERVICE) as UsbManager
        drivers = UsbSerialProber.getDefaultProber().findAllDrivers(usbManager)

        if (drivers.isEmpty()) {
            binding.spinnerDevices.adapter = ArrayAdapter(
                this, android.R.layout.simple_spinner_dropdown_item, listOf("No USB serial device found")
            )
            binding.tvUsbStatus.text = "USB: not connected"
            selectedDriver = null
            return
        }

        val labels = drivers.map { d ->
            val dev = d.device
            "${UsbChipIdentifier.name(dev.vendorId, dev.productId)}  (VID:${dev.vendorId} PID:${dev.productId})"
        }
        binding.spinnerDevices.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        binding.spinnerDevices.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedDriver = drivers.getOrNull(position)
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        selectedDriver = drivers.first()
        binding.tvUsbStatus.text = "USB: ${drivers.size} device(s) found"
    }

    // ---- start / stop -------------------------------------------------

    private fun onStartStopClicked() {
        val svc = bridgeService
        if (svc == null) {
            appendLog("Service not ready yet, please try again")
            return
        }

        if (svc.getStatus().running) {
            svc.stopBridge()
            return
        }

        val driver = selectedDriver
        if (driver == null) {
            appendLog("No USB serial device selected")
            return
        }

        val port = binding.etTcpPort.text.toString().toIntOrNull()
        if (port == null || port !in 1..65535) {
            appendLog("Invalid TCP port")
            return
        }

        val baud = baudRates[binding.spinnerBaud.selectedItemPosition]
        val dataBits = dataBitsOptions[binding.spinnerDataBits.selectedItemPosition]
        val stopBits = stopBitsValues[binding.spinnerStopBits.selectedItemPosition]
        val parity = parityValues[binding.spinnerParity.selectedItemPosition]
        val protocolMode = currentProtocolMode
        val targetChip = currentTargetChip

        val usbManager = getSystemService(Context.USB_SERVICE) as UsbManager
        if (!usbManager.hasPermission(driver.device)) {
            requestUsbPermission(driver) { granted ->
                if (granted) {
                    launchBridge(driver, baud, dataBits, stopBits, parity, port, protocolMode, targetChip)
                } else {
                    appendLog("USB permission denied")
                }
            }
        } else {
            launchBridge(driver, baud, dataBits, stopBits, parity, port, protocolMode, targetChip)
        }
    }

    private fun launchBridge(
        driver: UsbSerialDriver,
        baud: Int,
        dataBits: Int,
        stopBits: Int,
        parity: Int,
        port: Int,
        protocolMode: ServerMode,
        targetChip: TargetChip
    ) {
        ContextCompat.startForegroundService(this, Intent(this, BridgeService::class.java))
        bridgeService?.startBridge(driver, baud, dataBits, stopBits, parity, port, protocolMode, targetChip)
    }

    private fun requestUsbPermission(driver: UsbSerialDriver, callback: (Boolean) -> Unit) {
        val usbManager = getSystemService(Context.USB_SERVICE) as UsbManager
        val action = "com.tcpuartbridge.app.USB_PERMISSION"
        val mutabilityFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0
        val permissionIntent = PendingIntent.getBroadcast(
            this, 0, Intent(action).setPackage(packageName), mutabilityFlag
        )

        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                if (intent.action == action) {
                    unregisterReceiver(this)
                    callback(intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false))
                }
            }
        }
        val filter = IntentFilter(action)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(receiver, filter)
        }
        usbManager.requestPermission(driver.device, permissionIntent)
    }

    private fun performAutoReset() {
        val svc = bridgeService ?: return
        when (currentTargetChip) {
            TargetChip.ESP32 -> performEsp32BootloaderReset(svc)
            TargetChip.AMEBAD -> performAmebaDownloadModeReset(svc)
            TargetChip.AVR_ARDUINO -> performArduinoReset(svc)
            TargetChip.GENERIC -> appendLog(
                "Generic mode has no built-in auto-reset sequence - use the RTS/DTR switches above " +
                    "as the manual fallback to drive the lines by hand for your board's reset convention."
            )
        }
    }

    /** Classic ESP32 auto-reset-to-bootloader pulse sequence (DTR=GPIO0, RTS=EN) - mirrors esptool's ClassicReset. */
    private fun performEsp32BootloaderReset(svc: BridgeService) {
        val t0 = SystemClock.elapsedRealtime()
        fun step(msg: String) = appendLog("[+${SystemClock.elapsedRealtime() - t0}ms] $msg")
        lifecycleScope.launch {
            step("ESP32 reset: DTR=0 (IO0=HIGH), RTS=1 (EN=LOW, reset)")
            svc.setDTR(false)
            svc.setRTS(true)
            delay(100)
            step("DTR=1 (IO0=LOW), RTS=0 (EN=HIGH, exits reset -> should sample IO0 LOW -> bootloader)")
            svc.setDTR(true)
            svc.setRTS(false)
            delay(50)
            step("DTR=0 (IO0=HIGH, done)")
            svc.setDTR(false)
            appendLog(
                "Sent bootloader reset sequence. If the board still boots normally instead of entering the " +
                    "bootloader, that's very likely a wiring/chip-driver polarity issue rather than sequence " +
                    "timing - the steps above match esptool's ClassicReset exactly."
            )
        }
    }

    /**
     * AmebaD/BW16 download-mode-entry pulse sequence - reverse-engineered exactly from
     * upload_amebad.py's enter_download_mode()/set_dtr_rts() (0x2 -> 0x1 -> 0x3, 500/200/500ms).
     * In Raw (auto-baud) mode this now also runs automatically on connect/disconnect (see
     * TcpServerManager) - this manual button remains as a fallback/for testing outside that mode.
     */
    private fun performAmebaDownloadModeReset(svc: BridgeService) {
        val t0 = SystemClock.elapsedRealtime()
        fun step(msg: String) = appendLog("[+${SystemClock.elapsedRealtime() - t0}ms] $msg")
        lifecycleScope.launch {
            step("AmebaD download mode: RTS=1, DTR=0 (EN low / reset)")
            svc.setRTS(true)
            svc.setDTR(false)
            delay(500)
            step("RTS=0, DTR=1 (download-mode select)")
            svc.setRTS(false)
            svc.setDTR(true)
            delay(200)
            step("RTS=0, DTR=0 (release)")
            svc.setRTS(false)
            svc.setDTR(false)
            delay(500)
            appendLog("Sent AmebaD/BW16 download-mode reset sequence.")
        }
    }

    /**
     * Arduino/AVR bootloader-entry pulse - the classic "DTR through a capacitor to RESET"
     * auto-reset, timing copied exactly from avrdude's own arduino_open() (clear DTR+RTS,
     * 250ms, set DTR+RTS, 50ms). In Raw (auto-baud) mode this now also runs automatically
     * on connect (see TcpServerManager) - this manual button remains as a fallback/for
     * testing outside that mode. Use avrdude's -c stk500v1 (not -c arduino) so avrdude
     * doesn't also attempt its own DTR/RTS ioctl, which fails over a network port anyway.
     */
    private fun performArduinoReset(svc: BridgeService) {
        val t0 = SystemClock.elapsedRealtime()
        fun step(msg: String) = appendLog("[+${SystemClock.elapsedRealtime() - t0}ms] $msg")
        lifecycleScope.launch {
            step("Arduino/AVR reset: DTR=0, RTS=0 (clear - discharges the reset capacitor)")
            svc.setDTR(false)
            svc.setRTS(false)
            delay(250)
            step("DTR=1, RTS=1 (set - the rising edge triggers reset)")
            svc.setDTR(true)
            svc.setRTS(true)
            delay(50)
            appendLog("Sent Arduino/AVR bootloader-entry reset sequence.")
        }
    }

    /**
     * Adds the system navigation bar's height on top of the button's base XML
     * margin, so it never sits flush against gesture-nav or 3-button-nav
     * controls on any device (the fixed XML margin alone isn't enough on
     * devices with a tall nav bar).
     */
    private fun applyBottomInsets() {
        val baseMarginPx = (binding.btnStartStop.layoutParams as ViewGroup.MarginLayoutParams).bottomMargin
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { _, insets ->
            val navBarInset = insets.getInsets(WindowInsetsCompat.Type.systemBars()).bottom
            val params = binding.btnStartStop.layoutParams as ViewGroup.MarginLayoutParams
            params.bottomMargin = baseMarginPx + navBarInset
            binding.btnStartStop.layoutParams = params
            insets
        }
        ViewCompat.requestApplyInsets(binding.root)
    }

    // ---- UI updates -----------------------------------------------------

    private fun updateStatusUi(status: BridgeStatus) {
        binding.tvUsbStatus.text = if (status.usbConnected) "USB: ${status.deviceName}" else "USB: not connected"
        val modeLabel = when (status.protocolMode) {
            ServerMode.RFC2217 -> "RFC2217"
            ServerMode.RAW_AUTOBAUD -> "raw, auto-baud"
            ServerMode.RAW -> "raw"
        }
        binding.tvIpPort.text = "IP: ${status.ipAddress}   Port: ${status.tcpPort}   Protocol: $modeLabel"
        binding.tvClientCount.text = "Clients connected: ${status.clientCount}"
        binding.btnStartStop.text = if (status.running) getString(R.string.stop_bridge) else getString(R.string.start_bridge)
    }

    private fun appendLog(message: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        binding.tvLog.append("[$time] $message\n")
        binding.scrollLog.post { binding.scrollLog.fullScroll(View.FOCUS_DOWN) }
    }
}
