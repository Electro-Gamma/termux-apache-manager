# runner.py
#
# Bridge between the Kotlin/Compose UI and the vendored `esptool` package.
# This file is the ONLY piece of integration glue in the whole app -- the
# `esptool/` package itself is copied verbatim from the official Espressif
# source and is not modified in any way.
#
# Called from Kotlin as:
#   Python.getInstance().getModule("runner").callAttr("run_command", cmd, listener)
#
# `listener` is a plain Kotlin object with two public methods:
#   onLine(line: String)     -- called for every line/progress update
#   onFinished(code: Int)    -- called exactly once, when the command ends
#
# Chaquopy exposes any Java/Kotlin object passed into Python as a proxy
# object whose public methods can be called directly, so no special
# wrapping is required on the Python side.

import os
import shlex
import sys
import traceback

import esptool

# esptool (via rich_click) will look at these to decide whether to emit
# ANSI colour codes / box-drawing characters. We want plain text, since
# it's going into a simple scrolling Compose Text view, not a real
# terminal emulator.
os.environ["NO_COLOR"] = "1"
os.environ.setdefault("TERM", "dumb")


class _CallbackWriter:
    """A minimal file-like object that forwards output to the Kotlin
    listener, one line at a time.

    esptool prints normal messages terminated with '\\n', but also uses
    bare '\\r' to redraw progress ("Writing at 0x00010000... (42 %)"), so
    we treat both as line separators. Without this, a progress bar would
    arrive as one gigantic write() call.
    """

    def __init__(self, listener):
        self._listener = listener
        self._buf = ""
        # Some libraries (rich, click) probe these attributes on sys.stdout
        # before deciding how to format output.
        self.encoding = "utf-8"
        self.errors = "replace"

    def write(self, text):
        if not text:
            return 0
        self._buf += text
        while True:
            cut = None
            for i, ch in enumerate(self._buf):
                if ch in ("\n", "\r"):
                    cut = i
                    break
            if cut is None:
                break
            line = self._buf[:cut]
            self._buf = self._buf[cut + 1 :]
            if line:
                self._listener.onLine(line)
        return len(text)

    def flush(self):
        if self._buf:
            self._listener.onLine(self._buf)
            self._buf = ""

    # Rich/click sometimes check these; keep them honest for a non-tty.
    def isatty(self):
        return False

    def writable(self):
        return True


def run_command(command_line, listener):
    """
    command_line: the part of the esptool.py command line after the
                  script name, e.g.
                  "--chip esp32 --port socket://127.0.0.1:3333 chip-id"
    listener:     Kotlin callback object, see module docstring.

    Nothing is returned -- every result (each output line, and the final
    exit code) is reported through `listener` so this call is safe to make
    from a background coroutine and simply await its completion.
    """
    try:
        args = shlex.split(command_line)
    except ValueError as e:
        # Unbalanced quotes etc. -- report and bail out before touching esptool.
        listener.onLine(f"Could not parse command line: {e}")
        listener.onFinished(2)
        return

    out = _CallbackWriter(listener)
    old_stdout, old_stderr, old_argv = sys.stdout, sys.stderr, sys.argv
    sys.stdout = out
    sys.stderr = out
    # esptool._main() (like any argparse/click program) reads sys.argv
    # rather than taking a parameter, so we set it for the duration of
    # this call and always restore it afterwards.
    sys.argv = ["esptool"] + args

    exit_code = 0
    try:
        # esptool._main() wraps main() with friendly, specific error
        # messages for connection failures, which matters a lot here since
        # a TCP-bridge connection is the most likely failure point.
        esptool._main()
    except SystemExit as e:
        code = e.code
        if code is None:
            exit_code = 0
        elif isinstance(code, int):
            exit_code = code
        else:
            out.write(str(code) + "\n")
            exit_code = 1
    except Exception:
        out.write(traceback.format_exc())
        exit_code = 1
    finally:
        out.flush()
        sys.stdout, sys.stderr, sys.argv = old_stdout, old_stderr, old_argv

    listener.onFinished(exit_code)
