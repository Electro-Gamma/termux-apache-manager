package com.espflash.terminal

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.espflash.terminal.files.FirmwareStorage
import com.espflash.terminal.ui.FilesScreen
import com.espflash.terminal.ui.TerminalScreen
import com.espflash.terminal.ui.theme.EspFlashTerminalTheme
import com.espflash.terminal.viewmodel.TerminalViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: TerminalViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            EspFlashTerminalTheme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    EspFlashApp(viewModel)
                }
            }
        }
    }
}

@Composable
private fun EspFlashApp(viewModel: TerminalViewModel) {
    val context = LocalContext.current
    val firmwareStorage = remember { FirmwareStorage(context) }
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Terminal", "Files")

    val saveLogLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/plain")
    ) { uri ->
        if (uri != null) {
            firmwareStorage.exportText(viewModel.logAsText(), uri)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("ESP Flash Terminal") })
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding)) {
            TabRow(selectedTabIndex = selectedTab) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = { Text(title) }
                    )
                }
            }

            when (selectedTab) {
                0 -> TerminalScreen(
                    viewModel = viewModel,
                    firmwareStorage = firmwareStorage,
                    onSaveLog = { saveLogLauncher.launch("esp-flash-log.txt") }
                )
                1 -> FilesScreen(
                    viewModel = viewModel,
                    firmwareStorage = firmwareStorage
                )
            }
        }
    }
}
