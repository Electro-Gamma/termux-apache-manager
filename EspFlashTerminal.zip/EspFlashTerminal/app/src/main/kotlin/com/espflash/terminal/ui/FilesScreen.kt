package com.espflash.terminal.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.espflash.terminal.files.FirmwareStorage
import com.espflash.terminal.viewmodel.TerminalViewModel
import java.util.Locale

@Composable
fun FilesScreen(
    viewModel: TerminalViewModel,
    firmwareStorage: FirmwareStorage,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var refreshKey by remember { mutableStateOf(0) }
    var pendingExport by remember { mutableStateOf<java.io.File?>(null) }

    val files = remember(refreshKey) { firmwareStorage.listFirmwareFiles() }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            val name = queryDisplayName(context, uri) ?: "firmware.bin"
            firmwareStorage.importFrom(uri, name)
            refreshKey++
        }
    }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri ->
        val source = pendingExport
        if (uri != null && source != null) {
            firmwareStorage.exportTo(source, uri)
        }
        pendingExport = null
    }

    Column(modifier = modifier.fillMaxSize().padding(12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Firmware files", style = MaterialTheme.typography.titleMedium)
            Button(onClick = { importLauncher.launch(arrayOf("*/*")) }) {
                Text("Import .bin")
            }
        }

        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

        if (files.isEmpty()) {
            Text(
                "No files yet. Import a firmware image, or run \"Read Flash\" " +
                    "from the Terminal tab to create a dump here.",
                style = MaterialTheme.typography.bodyMedium
            )
        }

        LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(files) { entry ->
                Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(entry.file.name, style = MaterialTheme.typography.bodyLarge)
                        Text(
                            humanReadableBytes(entry.sizeBytes),
                            style = MaterialTheme.typography.bodySmall
                        )
                        Row(
                            modifier = Modifier.padding(top = 8.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            TextButton(onClick = {
                                viewModel.insertPathIntoCommand(entry.file.absolutePath)
                            }) { Text("Use in command") }

                            TextButton(onClick = {
                                pendingExport = entry.file
                                exportLauncher.launch(entry.file.name)
                            }) { Text("Export") }

                            TextButton(onClick = {
                                firmwareStorage.delete(entry.file)
                                refreshKey++
                            }) { Text("Delete") }
                        }
                    }
                }
            }
        }
    }
}

private fun queryDisplayName(context: android.content.Context, uri: android.net.Uri): String? {
    val projection = arrayOf(android.provider.OpenableColumns.DISPLAY_NAME)
    context.contentResolver.query(uri, projection, null, null, null)?.use { cursor ->
        val idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
        if (idx >= 0 && cursor.moveToFirst()) {
            return cursor.getString(idx)
        }
    }
    return null
}

private fun humanReadableBytes(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val units = arrayOf("KB", "MB", "GB", "TB")
    var value = bytes.toDouble()
    var unitIndex = -1
    while (value >= 1024 && unitIndex < units.lastIndex) {
        value /= 1024
        unitIndex++
    }
    return String.format(Locale.US, "%.1f %s", value, units[unitIndex])
}
