package com.espflash.terminal.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenu
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.espflash.terminal.files.FirmwareStorage
import com.espflash.terminal.viewmodel.SUPPORTED_CHIPS
import com.espflash.terminal.viewmodel.TerminalViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TerminalScreen(
    viewModel: TerminalViewModel,
    firmwareStorage: FirmwareStorage,
    onSaveLog: () -> Unit,
    modifier: Modifier = Modifier
) {
    val chip by viewModel.chip.collectAsState()
    val port by viewModel.port.collectAsState()
    val commandText by viewModel.commandText.collectAsState()
    val logLines by viewModel.logLines.collectAsState()
    val isRunning by viewModel.isRunning.collectAsState()
    val lastExitCode by viewModel.lastExitCode.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp)
    ) {
        ConnectionRow(
            chip = chip,
            onChipChange = { viewModel.chip.value = it },
            port = port,
            onPortChange = { viewModel.port.value = it },
        )

        Box(Modifier.padding(top = 8.dp)) {
            QuickActionsRow(
                enabled = !isRunning,
                onChipId = { viewModel.runQuick("chip-id") },
                onFlashId = { viewModel.runQuick("flash-id") },
                onEraseFlash = { viewModel.runQuick("erase-flash") },
                onPrepareWriteFlash = { viewModel.setCommandText("write-flash 0x10000 ") },
                onPrepareReadFlash = {
                    val target = firmwareStorage.newDumpTarget("flash-dump.bin")
                    viewModel.setCommandText(
                        "read-flash 0x0 0x100000 \"${target.absolutePath}\""
                    )
                },
            )
        }

        OutputConsole(
            lines = logLines,
            modifier = Modifier
                .weight(1f)
                .padding(vertical = 8.dp)
        )

        StatusRow(isRunning = isRunning, lastExitCode = lastExitCode)

        CommandRow(
            commandText = commandText,
            onCommandChange = viewModel::setCommandText,
            isRunning = isRunning,
            onRun = viewModel::runCurrentCommand,
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 4.dp),
            horizontalArrangement = Arrangement.End
        ) {
            TextButton(onClick = viewModel::clearLog) { Text("Clear") }
            TextButton(onClick = onSaveLog) { Text("Save log") }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ConnectionRow(
    chip: String,
    onChipChange: (String) -> Unit,
    port: String,
    onPortChange: (String) -> Unit,
) {
    var expanded by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        ExposedDropdownMenuBox(
            expanded = expanded,
            onExpandedChange = { expanded = it },
            modifier = Modifier.weight(0.4f)
        ) {
            OutlinedTextField(
                value = chip,
                onValueChange = {},
                readOnly = true,
                label = { Text("Chip") },
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                modifier = Modifier.menuAnchor()
            )
            ExposedDropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false }
            ) {
                SUPPORTED_CHIPS.forEach { option ->
                    DropdownMenuItem(
                        text = { Text(option) },
                        onClick = {
                            onChipChange(option)
                            expanded = false
                        }
                    )
                }
            }
        }

        OutlinedTextField(
            value = port,
            onValueChange = onPortChange,
            label = { Text("Port (socket:// or rfc2217://)") },
            singleLine = true,
            modifier = Modifier.weight(0.6f)
        )
    }
}

@Composable
private fun QuickActionsRow(
    enabled: Boolean,
    onChipId: () -> Unit,
    onFlashId: () -> Unit,
    onEraseFlash: () -> Unit,
    onPrepareWriteFlash: () -> Unit,
    onPrepareReadFlash: () -> Unit,
) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        TextButton(onClick = onChipId, enabled = enabled) { Text("Chip ID") }
        TextButton(onClick = onFlashId, enabled = enabled) { Text("Flash ID") }
        TextButton(onClick = onPrepareReadFlash, enabled = enabled) { Text("Read Flash") }
        TextButton(onClick = onPrepareWriteFlash, enabled = enabled) { Text("Write Flash") }
        TextButton(onClick = onEraseFlash, enabled = enabled) { Text("Erase") }
    }
}

@Composable
private fun OutputConsole(lines: List<String>, modifier: Modifier = Modifier) {
    val listState = rememberLazyListState()

    LaunchedEffect(lines.size) {
        if (lines.isNotEmpty()) {
            listState.scrollToItem(lines.lastIndex)
        }
    }

    LazyColumn(
        state = listState,
        modifier = modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface),
        contentPadding = PaddingValues(8.dp)
    ) {
        items(lines) { line ->
            Text(
                text = line,
                fontFamily = FontFamily.Monospace,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurface,
            )
        }
    }
}

@Composable
private fun StatusRow(isRunning: Boolean, lastExitCode: Int?) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        if (isRunning) {
            CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
            Text("Running…", style = MaterialTheme.typography.bodySmall)
        } else {
            val text = when (lastExitCode) {
                null -> "Ready"
                0 -> "Last run: success"
                else -> "Last run: failed (exit $lastExitCode)"
            }
            Text(text, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun CommandRow(
    commandText: String,
    onCommandChange: (String) -> Unit,
    isRunning: Boolean,
    onRun: () -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        OutlinedTextField(
            value = commandText,
            onValueChange = onCommandChange,
            label = { Text("Command (after --chip/--port)") },
            singleLine = true,
            modifier = Modifier.weight(1f)
        )
        Button(onClick = onRun, enabled = !isRunning) { Text("Run") }
    }
}
