package com.espflash.terminal.python

import com.chaquo.python.PyObject
import com.chaquo.python.Python

/**
 * Thin Kotlin-side wrapper around `app/src/main/python/runner.py`.
 *
 * Python is started automatically before this is ever used, because
 * AndroidManifest.xml declares `android:name="com.chaquo.python.android.PyApplication"`
 * on the <application> tag -- Chaquopy calls Python.start() from
 * Application.onCreate() for us.
 */
object EsptoolBridge {

    /**
     * Implemented by the caller. `onLine` is invoked from Python, on
     * whatever thread `run()` was called from -- always call `run()` from
     * a background dispatcher (e.g. Dispatchers.IO), never the main thread.
     *
     * NOTE: these two methods are called *by name* from Python via
     * Chaquopy's Java<->Python bridge, so don't rename them without also
     * updating runner.py.
     */
    interface Listener {
        fun onLine(line: String)
        fun onFinished(exitCode: Int)
    }

    private val runnerModule: PyObject by lazy {
        Python.getInstance().getModule("runner")
    }

    /**
     * Runs one esptool invocation and blocks the calling thread until it
     * finishes. All output and the final exit code are delivered through
     * [listener], not the return value.
     *
     * @param commandLine everything that would follow "esptool.py" on the
     *   command line, e.g. "--chip esp32 --port socket://127.0.0.1:3333 chip-id"
     */
    fun run(commandLine: String, listener: Listener) {
        runnerModule.callAttr("run_command", commandLine, listener)
    }
}
