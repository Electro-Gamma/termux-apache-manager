package com.espflash.terminal.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Green = Color(0xFF4CD964)
private val DarkBackground = Color(0xFF12161C)
private val DarkSurface = Color(0xFF1B2430)

private val DarkColors = darkColorScheme(
    primary = Green,
    secondary = Green,
    background = DarkBackground,
    surface = DarkSurface,
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF1B7A34),
    secondary = Color(0xFF1B7A34),
)

@Composable
fun EspFlashTerminalTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColors else LightColors
    MaterialTheme(colorScheme = colors, content = content)
}
