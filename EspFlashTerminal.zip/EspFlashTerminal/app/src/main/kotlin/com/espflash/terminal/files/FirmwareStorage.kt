package com.espflash.terminal.files

import android.content.Context
import android.net.Uri
import java.io.File

/**
 * All firmware/dump files live in app-internal storage
 * (context.filesDir/firmware). This directory is private to the app, so
 * no storage permission is required. Files only ever enter or leave it
 * through the Storage Access Framework (ACTION_OPEN_DOCUMENT /
 * ACTION_CREATE_DOCUMENT), which is how Android 10+'s scoped storage
 * expects apps to interact with user-visible files without broad
 * filesystem permissions.
 */
class FirmwareStorage(private val context: Context) {

    val firmwareDir: File
        get() = File(context.filesDir, "firmware").apply { mkdirs() }

    val logsDir: File
        get() = File(context.filesDir, "logs").apply { mkdirs() }

    data class FirmwareFile(val file: File, val sizeBytes: Long)

    fun listFirmwareFiles(): List<FirmwareFile> =
        firmwareDir.listFiles()
            ?.filter { it.isFile }
            ?.sortedByDescending { it.lastModified() }
            ?.map { FirmwareFile(it, it.length()) }
            ?: emptyList()

    /** Copies a document picked via ACTION_OPEN_DOCUMENT into firmware storage. */
    fun importFrom(uri: Uri, suggestedName: String): File {
        val safeName = sanitizeFileName(suggestedName)
        val dest = uniqueFile(firmwareDir, safeName)
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Could not open the selected file" }
            dest.outputStream().use { output -> input.copyTo(output) }
        }
        return dest
    }

    /** Copies an internal file out to a destination picked via ACTION_CREATE_DOCUMENT. */
    fun exportTo(source: File, destination: Uri) {
        context.contentResolver.openOutputStream(destination).use { output ->
            requireNotNull(output) { "Could not open the destination" }
            source.inputStream().use { input -> input.copyTo(output) }
        }
    }

    /** Writes free-form text (e.g. the terminal log) out to a picked destination. */
    fun exportText(text: String, destination: Uri) {
        context.contentResolver.openOutputStream(destination)?.use { output ->
            output.write(text.toByteArray(Charsets.UTF_8))
        }
    }

    fun delete(file: File): Boolean = file.delete()

    /** Reserves an empty file inside firmware storage for a read-flash dump, e.g. "flash.bin". */
    fun newDumpTarget(name: String): File =
        uniqueFile(firmwareDir, sanitizeFileName(name))

    private fun sanitizeFileName(name: String): String {
        val base = name.substringAfterLast('/').substringAfterLast('\\')
        val cleaned = base.replace(Regex("[^A-Za-z0-9._-]"), "_")
        return cleaned.ifBlank { "file.bin" }
    }

    private fun uniqueFile(dir: File, name: String): File {
        var candidate = File(dir, name)
        if (!candidate.exists()) return candidate
        val dot = name.lastIndexOf('.')
        val stem = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var i = 1
        while (candidate.exists()) {
            candidate = File(dir, "$stem-$i$ext")
            i++
        }
        return candidate
    }
}
