package com.espflash.terminal.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.espflash.terminal.python.EsptoolBridge
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

private const val MAX_LOG_LINES = 4000

/** Chips supported by the vendored esptool build. "auto" lets esptool detect the chip itself. */
val SUPPORTED_CHIPS = listOf("auto", "esp32", "esp8266", "esp32s2", "esp32s3", "esp32c3")

class TerminalViewModel : ViewModel() {

    private val _logLines = MutableStateFlow<List<String>>(emptyList())
    val logLines: StateFlow<List<String>> = _logLines.asStateFlow()

    private val _isRunning = MutableStateFlow(false)
    val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

    private val _lastExitCode = MutableStateFlow<Int?>(null)
    val lastExitCode: StateFlow<Int?> = _lastExitCode.asStateFlow()

    val chip = MutableStateFlow(SUPPORTED_CHIPS[1]) // "esp32"
    val port = MutableStateFlow("socket://127.0.0.1:3333")
    val commandText = MutableStateFlow("chip-id")

    // Guards against overlapping runs; esptool + a shared TCP connection
    // to one bridge is not something you want to invoke concurrently.
    private val runLock = Mutex()

    fun setCommandText(value: String) {
        commandText.value = value
    }

    /** Inserts/replaces a firmware path into the current command text, e.g. from the Files tab. */
    fun insertPathIntoCommand(path: String) {
        commandText.value = if (commandText.value.isBlank()) {
            path
        } else {
            "${commandText.value.trimEnd()} \"$path\""
        }
    }

    fun runQuick(subcommand: String) {
        commandText.value = subcommand
        runCurrentCommand()
    }

    fun runCurrentCommand() {
        val sub = commandText.value.trim()
        if (sub.isEmpty()) return
        val full = "--chip ${chip.value} --port ${port.value} $sub"
        runRaw(full)
    }

    private fun appendLine(line: String) {
        _logLines.update { (it + line).let { l -> if (l.size > MAX_LOG_LINES) l.takeLast(MAX_LOG_LINES) else l } }
    }

    fun clearLog() {
        _logLines.value = emptyList()
    }

    private fun runRaw(commandLine: String) {
        if (_isRunning.value) return
        appendLine("$ esptool.py $commandLine")
        _isRunning.value = true
        _lastExitCode.value = null

        viewModelScope.launch(Dispatchers.IO) {
            runLock.withLock {
                EsptoolBridge.run(commandLine, object : EsptoolBridge.Listener {
                    override fun onLine(line: String) {
                        appendLine(line)
                    }

                    override fun onFinished(exitCode: Int) {
                        appendLine(
                            if (exitCode == 0) "[done -- exit code 0]"
                            else "[failed -- exit code $exitCode]"
                        )
                        _lastExitCode.value = exitCode
                        _isRunning.value = false
                    }
                })
            }
        }
    }

    fun logAsText(): String = _logLines.value.joinToString("\n")
}
