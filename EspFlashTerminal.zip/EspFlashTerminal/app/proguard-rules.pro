# This project builds with isMinifyEnabled = false by default, so these
# rules aren't applied unless you turn minification on for the release
# build type. If you do, keep Chaquopy's own runtime classes intact:
-keep class com.chaquo.python.** { *; }
