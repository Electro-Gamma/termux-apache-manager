plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.chaquo.python")
}

android {
    namespace = "com.espflash.terminal"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.espflash.terminal"
        minSdk = 29 // Android 10+, per project requirement
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"

        ndk {
            // 64-bit only keeps the APK smaller. Add "armeabi-v7a" here if
            // you need to support older 32-bit devices (Chaquopy Python
            // 3.11 or older only -- see README).
            abiFilters += listOf("arm64-v8a", "x86_64")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }

    packaging {
        resources {
            excludes += setOf("/META-INF/{AL2.0,LGPL2.1}")
        }
    }

    sourceSets {
        getByName("main") {
            kotlin.srcDirs("src/main/kotlin")
        }
    }
}

chaquopy {
    defaultConfig {
        // esptool 5.3.1 requires Python >= 3.10 (see pyproject.toml).
        // 3.12 is a mature choice that's well within Chaquopy's supported
        // range. Python 3.12+ only supports 64-bit ABIs, which matches
        // the abiFilters above.
        version = "3.12"

        pip {
            // Only what esptool's chip-id / read-flash / write-flash /
            // erase-flash commands actually import (see README for the
            // dependency trace). espefuse/espsecure and their heavier
            // deps (cryptography, bitstring, reedsolo, PyYAML) are
            // deliberately left out of this build for size -- add them
            // here if you need eFuse or secure-boot support.
            install("click<9")
            install("rich_click<2")
            install("pyserial>=3.3")
            install("intelhex")
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.activity:activity-compose:1.9.3")

    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
