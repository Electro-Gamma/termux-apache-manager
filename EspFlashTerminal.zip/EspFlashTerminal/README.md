# ESP Flash Terminal

A native Android app that runs the official [esptool](https://github.com/espressif/esptool)
inside the app process, with a small terminal-style UI, so you can flash
ESP32/ESP8266/ESP32-S2/ESP32-S3/ESP32-C3 devices over a **TCP-to-UART
bridge** without Termux, a full Python install, or a Linux environment.

No Android USB-serial access is used anywhere in this project. The only
transport supported is TCP, via pyserial's own `socket://` and
`rfc2217://` URL handlers (e.g. `socket://127.0.0.1:3333` or
`rfc2217://127.0.0.1:3333?ign_set_control`) -- exactly as you'd use them
from esptool on a desktop.

## How it's built

- **UI:** Kotlin + Jetpack Compose (Material 3), single Activity, MVVM
  (`TerminalViewModel` + `StateFlow`). No navigation library, no DI
  framework, no database -- there wasn't a need for any of them here, and
  every dependency adds to APK size and startup time.
- **Embedded Python:** [Chaquopy](https://chaquo.com/chaquopy/) 17.0,
  which embeds a real CPython 3.12 build in the APK and bridges it to
  Kotlin. Chaquopy has been fully free and open-source (MIT-licensed)
  since v12.0.1 (2022) -- there is no commercial license fee or
  restriction regardless of how you distribute the app.
- **esptool integration:** `app/src/main/python/esptool/` is the
  `esptool` package from the archive you uploaded
  (`esptool-5_3_1-termux-tcp_tar.gz`), copied in **unmodified**.
  `app/src/main/python/runner.py` is the only integration code -- about
  100 lines that call `esptool._main()` with the right `sys.argv` and
  redirect stdout/stderr to the Kotlin UI. See "Why no code changes were
  needed" below.

## What's included vs. left out, and why

The uploaded archive bundles four tools: `esptool`, `espefuse`,
`espsecure`, and `esp_rfc2217_server`. This build only includes what
`chip-id` / `read-flash` / `write-flash` / `erase-flash` actually need,
traced import-by-import rather than assumed from `pyproject.toml`
(which lists dependencies for the whole repo, not per-tool):

| Included | Why |
|---|---|
| `esptool/` package | The flashing tool itself |
| `click`, `rich_click` | esptool's CLI framework |
| `pyserial` | Transport layer -- `socket://`/`rfc2217://` are pyserial's own pure-Python URL handlers |
| `intelhex` | Imported unconditionally by `esptool/bin_image.py` (hex/merge-bin support) |

| Left out | Why |
|---|---|
| `espefuse/` | Only needed for eFuse read/write, not flashing |
| `espsecure/` | Only needed for secure boot / flash encryption signing |
| `cryptography` | Only imported by `espsecure` -- and it's a compiled OpenSSL/Rust extension, the one dependency that would have made this genuinely heavy |
| `bitstring`, `reedsolo`, `PyYAML` | Only imported by `espefuse` |
| `esp_rfc2217_server/` | This is the *server* side of an RFC2217 bridge (runs on a PC next to the real serial port). The Android app is a client only, so it isn't needed here. |

**To add eFuse or secure-boot support later:** copy `espefuse/` and/or
`espsecure/` into `app/src/main/python/`, add `bitstring`, `reedsolo`,
`pyyaml`, and/or `cryptography` to the `pip { }` block in
`app/build.gradle.kts`, and call them from `runner.py` the same way
`esptool` is called. Chaquopy ships prebuilt Android wheels for
`cryptography`, so this doesn't require any native toolchain setup on
your end -- just a larger APK per ABI.

## Why (almost) no code changes were needed

Before touching anything, I traced how esptool opens its port:
`esptool/loader.py` calls `serial.serial_for_url(self._port, ...)` --
a direct pass-through to pyserial. `socket://` and `rfc2217://` are
handled entirely inside pyserial using Python's standard `socket`
module; there's no OS-specific or Linux-specific code involved. The
only "Linux path" in the whole package is `DEFAULT_PORT =
"/dev/ttyUSB0"`, a fallback used only when `--port` is omitted -- which
never happens here, since the UI always sends an explicit `--port
socket://...` or `--port rfc2217://...`.

The one real platform risk: pyserial unconditionally imports `termios`
and `fcntl` on any POSIX system (Android counts as POSIX) even though
the socket transport doesn't use them. If Chaquopy's Python 3.12 build
doesn't include those stdlib modules, `import serial` -- and therefore
the whole app -- would fail at the first command. **Verify this on your
first build**: run "Chip ID" against any `socket://` target (even one
that will fail to connect) and confirm you get a connection-refused
error rather than a Python `ModuleNotFoundError`. Chaquopy's own docs
list `termios`/`fcntl` as supported (Android/Bionic implements the
underlying syscalls), so this is expected to work, but I can't compile
against a real Android toolchain here to confirm it firsthand.

## Project structure

```
EspFlashTerminal/
├── app/
│   ├── build.gradle.kts          # Chaquopy config, pip requirements, ABIs
│   ├── src/main/
│   │   ├── AndroidManifest.xml
│   │   ├── python/
│   │   │   ├── runner.py         # the only integration glue
│   │   │   └── esptool/          # vendored, unmodified
│   │   ├── kotlin/com/espflash/terminal/
│   │   │   ├── MainActivity.kt
│   │   │   ├── python/EsptoolBridge.kt
│   │   │   ├── viewmodel/TerminalViewModel.kt
│   │   │   ├── files/FirmwareStorage.kt
│   │   │   └── ui/{TerminalScreen,FilesScreen,theme/Theme}.kt
│   │   └── res/                  # theme, launcher icon, backup rules
├── build.gradle.kts               # plugin versions
├── settings.gradle.kts
└── gradle/wrapper/gradle-wrapper.properties
```

## Build instructions

**Requirements:** Android Studio (a version that ships with Gradle 8.11+
support -- any current one does), JDK 17.

1. **Get the Gradle wrapper jar.** This project's `.zip` includes
   `gradle/wrapper/gradle-wrapper.properties` (pointing at Gradle
   8.11.1) but not the wrapper `.jar` itself, since it's a binary I
   can't fetch from this sandbox. Either:
   - Open the project folder directly in Android Studio -- it will
     detect the missing wrapper and offer to regenerate it, or
   - From a machine with any Gradle installed, run `gradle wrapper
     --gradle-version 8.11.1` inside the project root once.
2. **Open the project** in Android Studio and let it sync. On first
   sync, Gradle will download Python 3.12 and build the `pip`
   requirements (`click`, `rich_click`, `pyserial`, `intelhex`) for
   `arm64-v8a` and `x86_64` -- this needs internet access and a working
   Python 3.12 on your build machine (Chaquopy's `pip` packaging step
   runs at build time, not just at runtime). If Chaquopy can't find
   Python 3.12 on your `PATH`, set `buildPython` in the `chaquopy {}`
   block of `app/build.gradle.kts` -- see [Chaquopy's docs](https://chaquo.com/chaquopy/doc/current/android.html#buildpython).
3. **Run** on a device or emulator running Android 10 (API 29) or
   later, on the same network as your TCP-UART bridge.

**A note on tool versions:** I pinned AGP 8.7.3 / Gradle 8.11.1 / Kotlin
2.0.21 / Compose BOM 2024.10.01 -- versions I could confirm are real,
stable, and within Chaquopy 17's supported AGP range (7.3–9.2), rather
than guessing at bleeding-edge version strings I can't verify from
here. If Android Studio's upgrade assistant offers newer AGP/Gradle/BOM
versions, it's safe to accept -- nothing in this project depends on a
specific version beyond what Chaquopy requires.

## Using the app

- **Terminal tab:** pick a chip (or `auto`), set the port (defaults to
  `socket://127.0.0.1:3333`), and either tap a quick action (Chip ID,
  Flash ID, Read Flash, Write Flash, Erase) or type the subcommand
  yourself in the command field -- e.g. `write-flash 0x10000
  firmware.bin` -- and tap Run. The command actually executed is always
  `--chip <chip> --port <port> <what you typed>`, shown at the top of
  the output.
- **Files tab:** import a `.bin` via the system file picker (copied into
  app-private storage -- no storage permission needed), tap "Use in
  command" to insert its path into the current command, or "Export" to
  save a file (e.g. a flash dump) back out through the system picker.
- **Save log:** from the Terminal tab, saves the full scrollback to a
  file you choose via the system picker.

## Testing without real hardware

To sanity-check connectivity handling before you have a bridge running,
point `--port` at anything that isn't listening (e.g.
`socket://127.0.0.1:9`) and confirm you get a clean "connection
refused"-style error in the output rather than a crash. The archive you
uploaded includes `esp_rfc2217_server.py`, which is the desktop-side
tool for turning a real serial port into an RFC2217 TCP server if you
want to test against real hardware from a PC in the loop.

## Licensing

- **esptool** (vendored in `app/src/main/python/esptool/`, `LICENSE`
  file included alongside it): GPL-2.0-or-later, © Espressif Systems and
  contributors.
- **Chaquopy**: MIT license, free and unrestricted since v12.0.1.
- **pyserial, click, rich_click, intelhex**: fetched from PyPI at build
  time via the `pip {}` block; each carries its own (permissive)
  license from its package metadata.

I'm not a lawyer -- if you're planning to distribute this app
commercially, it's worth having someone review how esptool's GPL-2.0
terms apply to the combined app, since that depends on details (how
you distribute, whether you modify esptool further, etc.) that are
outside what I can determine for you here.

## Permissions

Only `android.permission.INTERNET` is requested. Android enforces this
for *any* socket, including loopback/localhost, so it's required even
though the app never talks to the public internet. There is no storage
permission (file import/export goes through the Storage Access
Framework) and no background service.
