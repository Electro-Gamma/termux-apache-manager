package com.tcpuartbridge.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.hardware.usb.UsbDevice
import android.os.Binder
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.hoho.android.usbserial.driver.UsbSerialDriver
import com.tcpuartbridge.app.programmer.ProgrammerController
import com.tcpuartbridge.app.programmer.ProgrammerMode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.net.Inet4Address
import java.net.NetworkInterface

/**
 * Foreground service that owns the live [UsbSerialManager] and
 * [TcpServerManager] instances and pipes data between them (UART mode), and
 * the [ProgrammerController] (CH341A) whose I²C / SPI buses are exposed over TCP
 * (I²C and SPI modes). Runs
 * independently of the Activity so the bridge keeps working with the
 * screen off, per the "connectedDevice" foreground service type declared
 * in the manifest.
 */
class BridgeService : Service() {

    private val binder = LocalBinder()
    private lateinit var usbSerial: UsbSerialManager
    private lateinit var tcpServer: TcpServerManager
    private var listener: BridgeListener? = null
    private var status = BridgeStatus()

    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var programmerMode: BridgeMode = BridgeMode.I2C

    /** The CH341A session (I²C / SPI / OLED / chip files). Created lazily on first use. */
    val programmer: ProgrammerController by lazy { ProgrammerController(applicationContext) }

    private val rfc2217Control = object : Rfc2217ControlBridge {
        override fun setDTR(value: Boolean) = usbSerial.setDTR(value)
        override fun setRTS(value: Boolean) = usbSerial.setRTS(value)
        override fun reconfigure(baudRate: Int?, dataBits: Int?, stopBits: Int?, parity: Int?) {
            usbSerial.reconfigure(baudRate, dataBits, stopBits, parity)
        }
        override val currentBaudRate: Int get() = usbSerial.currentBaudRate
        override val currentDataBits: Int get() = usbSerial.currentDataBits
        override val currentStopBits: Int get() = usbSerial.currentStopBits
        override val currentParity: Int get() = usbSerial.currentParity
    }

    inner class LocalBinder : Binder() {
        fun getService(): BridgeService = this@BridgeService
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        usbSerial = UsbSerialManager(this)
        tcpServer = TcpServerManager()
        createNotificationChannel()

        usbSerial.onDataReceived = { data ->
            tcpServer.broadcast(data)
            listener?.onLog("RX ${data.size}B (UART -> TCP)")
        }
        usbSerial.onError = { e -> listener?.onLog("USB error: ${e.message}") }
        usbSerial.onLog = { msg -> listener?.onLog(msg) }

        tcpServer.onDataFromClient = { data ->
            usbSerial.write(data)
            listener?.onLog("TX ${data.size}B (TCP -> UART)")
        }
        tcpServer.onClientConnected = { addr ->
            status = status.copy(clientCount = tcpServer.clientCount)
            listener?.onLog("Client connected: $addr")
            refreshNotification()
            listener?.onStatusChanged(status)
        }
        tcpServer.onClientDisconnected = { addr ->
            status = status.copy(clientCount = tcpServer.clientCount)
            listener?.onLog("Client disconnected: $addr")
            refreshNotification()
            listener?.onStatusChanged(status)
        }
        tcpServer.onError = { e -> listener?.onLog("TCP error: ${e.message}") }
        tcpServer.onAutoBaudChanged = { newBaud ->
            status = status.copy(baudRate = newBaud)
            listener?.onLog("Auto-baud: detected a baud-rate change command on the wire -> UART switched to ${newBaud} baud")
            refreshNotification()
            listener?.onStatusChanged(status)
        }
        tcpServer.onAutoBaudReset = {
            status = status.copy(baudRate = 115200)
            listener?.onLog("Auto-baud: session ended, UART reset to 115200 baud for the next connection")
            refreshNotification()
            listener?.onStatusChanged(status)
        }
        tcpServer.onAutoReset = { description ->
            listener?.onLog("Auto-reset: $description")
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            // Notification "Stop": tear everything down, including an open CH341A session.
            if (status.programmerConnected) disconnectProgrammer() else stopBridge()
            return START_NOT_STICKY
        }
        // The activity starts us with startForegroundService(); Android requires startForeground()
        // within a few seconds, so do it right away - even if the USB open that follows fails.
        startForeground(NOTIF_ID, buildNotification())
        return START_NOT_STICKY
    }

    fun setListener(l: BridgeListener?) {
        listener = l
    }

    fun getStatus(): BridgeStatus = status

    /** Opens the USB serial port and starts the TCP server. Returns true on success. */
    fun startBridge(
        driver: UsbSerialDriver,
        baudRate: Int,
        dataBits: Int,
        stopBits: Int,
        parity: Int,
        tcpPort: Int,
        protocolMode: ServerMode = ServerMode.RAW,
        targetChip: TargetChip = TargetChip.ESP32
    ): Boolean {
        if (status.running) return true

        // Raw auto-baud always opens at 115200 - that's what the ESP ROM/stub loader
        // itself always expects for the initial SYNC handshake regardless of --baud
        // (esptool syncs at up to 115200, then requests a higher speed in-band via
        // CHANGE_BAUDRATE if you passed --baud - see EspBaudRateSniffer, which is what
        // then retunes this to match). Whatever the UART Settings baud spinner says is
        // ignored in this mode; data bits/stop bits/parity from it still apply as given.
        val effectiveBaud = if (protocolMode == ServerMode.RAW_AUTOBAUD) 115200 else baudRate

        val opened = usbSerial.open(driver, effectiveBaud, dataBits, stopBits, parity)
        if (!opened) {
            listener?.onLog("Failed to open USB serial port")
            releaseForegroundIfIdle()
            return false
        }

        try {
            tcpServer.start(tcpPort, protocolMode, rfc2217Control, targetChip)
        } catch (e: Exception) {
            listener?.onLog("Failed to start TCP server on port $tcpPort: ${e.message}")
            usbSerial.close()
            releaseForegroundIfIdle()
            return false
        }

        status = BridgeStatus(
            running = true,
            usbConnected = true,
            deviceName = usbSerial.deviceInfo(driver),
            baudRate = effectiveBaud,
            tcpPort = tcpPort,
            clientCount = 0,
            ipAddress = getLocalIpAddress(),
            protocolMode = protocolMode,
            bridgeMode = BridgeMode.UART
        )

        startForeground(NOTIF_ID, buildNotification())
        val modeLabel = when (protocolMode) {
            ServerMode.RFC2217 -> "RFC2217"
            ServerMode.RAW_AUTOBAUD -> "raw, auto-baud"
            ServerMode.RAW -> "raw"
        }
        listener?.onLog("Bridge started: UART ${effectiveBaud}bps <-> TCP ${status.ipAddress}:$tcpPort ($modeLabel)")
        listener?.onStatusChanged(status)
        return true
    }

    /** Stops whichever bridge is running. A CH341A session stays open (see [disconnectProgrammer]). */
    fun stopBridge() {
        if (status.bridgeMode == BridgeMode.UART) {
            tcpServer.stop()
            usbSerial.close()
            status = status.copy(running = false, usbConnected = false, clientCount = 0)
        } else {
            programmer.stopI2cTcpServer()
            programmer.stopSpiTcpServer()
            status = status.copy(running = false, clientCount = 0)
        }
        listener?.onLog("Bridge stopped")
        listener?.onStatusChanged(status)
        releaseForegroundIfIdle()
    }

    // ---- CH341A (I2C / SPI) ---------------------------------------------

    /**
     * Opens the CH341A and configures it for [mode] ([BridgeMode.I2C] or [BridgeMode.SPI]).
     * Result is delivered on the main thread. The session stays open until
     * [disconnectProgrammer], independent of whether the TCP server is running, so the OLED
     * and chip-file tools work without starting the bridge.
     */
    fun connectProgrammer(dev: UsbDevice, mode: BridgeMode, i2cSpeed: Int, onResult: (Boolean) -> Unit) {
        serviceScope.launch {
            val pm = if (mode == BridgeMode.SPI) ProgrammerMode.SPI_FLASH else ProgrammerMode.I2C_EEPROM
            val ok = programmer.connect(dev, pm, i2cSpeed)
            if (ok) {
                programmerMode = mode
                status = status.copy(
                    programmerConnected = true,
                    bridgeMode = mode,
                    deviceName = programmer.usbDevice.deviceLabel(),
                    ipAddress = getLocalIpAddress()
                )
                listener?.onLog("CH341A connected (${mode.label} mode) - ${programmer.usbDevice.endpointInfo}")
                refreshNotification(force = true)
            } else {
                listener?.onLog("CH341A open failed: ${programmer.usbDevice.lastError ?: "unknown error"}")
                releaseForegroundIfIdle()
            }
            listener?.onStatusChanged(status)
            onResult(ok)
        }
    }

    fun disconnectProgrammer() {
        serviceScope.launch {
            if (status.running && status.bridgeMode != BridgeMode.UART) {
                status = status.copy(running = false, clientCount = 0)
            }
            programmer.disconnect(
                if (programmerMode == BridgeMode.SPI) ProgrammerMode.SPI_FLASH else ProgrammerMode.I2C_EEPROM
            )
            status = status.copy(programmerConnected = false, deviceName = "")
            listener?.onLog("CH341A disconnected")
            listener?.onStatusChanged(status)
            releaseForegroundIfIdle()
        }
    }

    /** Starts the I²C-over-TCP or SPI-over-TCP server on [tcpPort]. Needs [connectProgrammer] first. */
    fun startProgrammerBridge(mode: BridgeMode, tcpPort: Int): Boolean {
        if (!status.programmerConnected) {
            listener?.onLog("Connect the CH341A first")
            return false
        }
        if (status.running) return true
        val onConnected: (String) -> Unit = { addr ->
            status = status.copy(clientCount = status.clientCount + 1)
            listener?.onLog("Client connected: $addr")
            refreshNotification(); listener?.onStatusChanged(status)
        }
        val onDisconnected: (String) -> Unit = { addr ->
            status = status.copy(clientCount = (status.clientCount - 1).coerceAtLeast(0))
            listener?.onLog("Client disconnected: $addr")
            refreshNotification(); listener?.onStatusChanged(status)
        }
        val onError: (Exception) -> Unit = { e -> listener?.onLog("TCP error: ${e.message}") }
        try {
            if (mode == BridgeMode.SPI) programmer.startSpiTcpServer(tcpPort, onConnected, onDisconnected, onError)
            else programmer.startI2cTcpServer(tcpPort, onConnected, onDisconnected, onError)
        } catch (e: Exception) {
            listener?.onLog("Failed to start ${mode.label} TCP server on port $tcpPort: ${e.message}")
            return false
        }
        status = status.copy(
            running = true, bridgeMode = mode, tcpPort = tcpPort, clientCount = 0,
            ipAddress = getLocalIpAddress()
        )
        listener?.onLog("Bridge started: ${mode.label} (CH341A) <-> TCP ${status.ipAddress}:$tcpPort")
        refreshNotification(force = true)
        listener?.onStatusChanged(status)
        return true
    }

    /** Leaves foreground mode once neither a UART bridge nor a CH341A session is active. */
    private fun releaseForegroundIfIdle() {
        if (status.running || status.programmerConnected) return
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    fun setRTS(value: Boolean) = usbSerial.setRTS(value)
    fun setDTR(value: Boolean) = usbSerial.setDTR(value)

    override fun onDestroy() {
        tcpServer.stop()
        usbSerial.close()
        if (status.programmerConnected) {
            programmer.stopI2cTcpServer()
            programmer.stopSpiTcpServer()
            programmer.usbDevice.close()
        }
        serviceScope.cancel()
        super.onDestroy()
    }

    // ---- notification -------------------------------------------------

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Bridge Service",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Shows TCP Bridge status while running"
            setShowBadge(false)
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val mutabilityFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            PendingIntent.FLAG_MUTABLE
        } else {
            0
        }

        val contentIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or mutabilityFlag
        )

        val stopIntent = Intent(this, BridgeService::class.java).apply { action = ACTION_STOP }
        val stopPending = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or mutabilityFlag
        )

        val title: String
        val lines: String
        if (status.bridgeMode == BridgeMode.UART) {
            val usbLine = if (status.usbConnected) "USB: ${status.deviceName}" else "USB: not connected"
            val modeLabel = when (status.protocolMode) {
                ServerMode.RFC2217 -> "RFC2217"
                ServerMode.RAW_AUTOBAUD -> "raw, auto-baud"
                ServerMode.RAW -> "raw"
            }
            title = "TCP UART Bridge running"
            lines = "$usbLine\nUART: ${status.baudRate} baud\n" +
                "TCP: ${status.ipAddress}:${status.tcpPort} ($modeLabel) - ${status.clientCount} client(s)"
        } else {
            title = if (status.running) "${status.bridgeMode.label} TCP Bridge running" else "CH341A connected"
            lines = if (status.running) {
                "${status.deviceName}\nTCP: ${status.ipAddress}:${status.tcpPort} - ${status.clientCount} client(s)"
            } else {
                "${status.deviceName}\n${status.bridgeMode.label} mode - bridge not started"
            }
        }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(lines.lines().joinToString("  ·  "))
            .setStyle(NotificationCompat.BigTextStyle().bigText(lines))
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(contentIntent)
            .addAction(0, "Stop", stopPending)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun refreshNotification(force: Boolean = false) {
        if (!force && !status.running) return
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
    }

    // ---- helpers --------------------------------------------------------

    private fun getLocalIpAddress(): String {
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val iface = interfaces.nextElement()
                val addresses = iface.inetAddresses
                while (addresses.hasMoreElements()) {
                    val addr = addresses.nextElement()
                    if (!addr.isLoopbackAddress && addr is Inet4Address) {
                        return addr.hostAddress ?: "unknown"
                    }
                }
            }
        } catch (_: Exception) {
        }
        return "unknown"
    }

    companion object {
        const val NOTIF_ID = 1001
        const val CHANNEL_ID = "bridge_channel"
        const val ACTION_STOP = "com.tcpuartbridge.app.ACTION_STOP"
    }
}
