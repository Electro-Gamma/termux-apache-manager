package com.tcpuartbridge.app

/** Which hardware bus the TCP bridge is exposing. */
enum class BridgeMode(val label: String, val defaultPort: Int) {
    UART("UART", 3333),
    I2C("I²C", 3334),
    SPI("SPI", 3335)
}

/**
 * Immutable snapshot of the bridge's current state, shared between [BridgeService]
 * and [MainActivity] / the foreground notification.
 */
data class BridgeStatus(
    val running: Boolean = false,
    val usbConnected: Boolean = false,
    val deviceName: String = "",
    val baudRate: Int = 0,
    val tcpPort: Int = 3333,
    val clientCount: Int = 0,
    val ipAddress: String = "unknown",
    val protocolMode: ServerMode = ServerMode.RAW,
    val bridgeMode: BridgeMode = BridgeMode.UART,
    /** True while a CH341A (I²C/SPI) session is open, whether or not its TCP server is running. */
    val programmerConnected: Boolean = false
)

/**
 * Callback interface used by [BridgeService] to push log lines and status
 * changes back to whatever UI is currently bound to it.
 */
interface BridgeListener {
    fun onLog(message: String)
    fun onStatusChanged(status: BridgeStatus)
}
