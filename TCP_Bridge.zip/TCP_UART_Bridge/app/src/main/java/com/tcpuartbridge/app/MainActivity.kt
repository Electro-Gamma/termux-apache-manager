package com.tcpuartbridge.app

import android.Manifest
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.LayoutInflater
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.hoho.android.usbserial.driver.UsbSerialDriver
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.driver.UsbSerialProber
import com.tcpuartbridge.app.ch341.Ch341I2c
import com.tcpuartbridge.app.ch341.Ch341UsbDevice
import com.tcpuartbridge.app.databinding.ActivityMainBinding
import com.tcpuartbridge.app.databinding.PanelBridgeBinding
import com.tcpuartbridge.app.display.OledCompositor
import com.tcpuartbridge.app.programmer.ProgrammerController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val pb: PanelBridgeBinding get() = binding.panelBridge

    private var bridgeService: BridgeService? = null
    private var bound = false

    /** Serial adapter picked by CONNECT in UART mode (permission granted, port not yet opened). */
    private var uartDriver: UsbSerialDriver? = null
    private var currentMode = BridgeMode.UART
    private var lastStatus = BridgeStatus()

    private val baudRates = intArrayOf(
        9600, 19200, 38400, 57600, 115200, 230400, 380400, 460800,
        500000, 921600, 1000000, 1382400, 1444400, 1500000,
        2000000, 2500000, 3000000, 3500000, 4000000, 4500000, 5000000
    )
    private val dataBitsOptions = intArrayOf(5, 6, 7, 8)
    private val stopBitsLabels = arrayOf("1", "1.5", "2")
    private val stopBitsValues = intArrayOf(UsbSerialPort.STOPBITS_1, UsbSerialPort.STOPBITS_1_5, UsbSerialPort.STOPBITS_2)
    private val parityLabels = arrayOf("None", "Odd", "Even", "Mark", "Space")
    private val parityValues = intArrayOf(
        UsbSerialPort.PARITY_NONE,
        UsbSerialPort.PARITY_ODD,
        UsbSerialPort.PARITY_EVEN,
        UsbSerialPort.PARITY_MARK,
        UsbSerialPort.PARITY_SPACE
    )
    private val protocolLabels = arrayOf("RFC2217 (automatic reset)", "Raw (manual reset)", "Raw (auto-baud)")
    private val protocolValues = arrayOf(ServerMode.RFC2217, ServerMode.RAW, ServerMode.RAW_AUTOBAUD)
    private val i2cSpeedLabels = arrayOf("20 kHz", "100 kHz", "400 kHz (default)", "750 kHz")
    private val i2cSpeedValues = intArrayOf(Ch341I2c.SPEED_20K, Ch341I2c.SPEED_100K, Ch341I2c.SPEED_400K, Ch341I2c.SPEED_750K)

    // "Generic" is a plain, no-sequence RTS/DTR passthrough fallback for any board whose reset
    // convention isn't known to this app.
    private var currentTargetChip = TargetChip.ESP32
    private var currentProtocolMode = ServerMode.RFC2217

    private data class OledSize(val label: String, val w: Int, val h: Int)
    private val oledSizes = listOf(
        OledSize("128 × 64", 128, 64), OledSize("128 × 32", 128, 32),
        OledSize("96 × 16", 96, 16), OledSize("64 × 32", 64, 32)
    )
    private val oledFontLabels: List<String> =
        listOf("Built-in pixel font") + ProgrammerController.BUNDLED_FONTS.map { it.displayName }


    private data class CliExample(val title: String, val explanation: String, val command: String)

    // Every command below uses PHONE_IP:PORT as a placeholder for whatever this app's
    // "IP: ... Port: ..." status line actually shows once the bridge is started.
    private val cliExamples = listOf(
        CliExample(
            "ESP32/ESP8266 - RFC2217 (automatic reset)",
            "App: Protocol = RFC2217, Target Chip = ESP32. esptool drives real, correctly-timed " +
                "DTR/RTS resets over the network - no manual button needed.",
            "esptool --port \"rfc2217://PHONE_IP:PORT?ign_set_control\" --baud 460800 write-flash 0x1000 firmware.bin"
        ),
        CliExample(
            "ESP32/ESP8266 - Raw (auto-baud)",
            "App: Protocol = Raw (auto-baud), Target Chip = ESP32. Plain socket, no RFC2217 - the app " +
                "watches for esptool's own baud-change command and follows it, and auto-resets the " +
                "board on connect/disconnect.",
            "esptool --port socket://PHONE_IP:PORT --baud 921600 write-flash 0x1000 firmware.bin"
        ),
        CliExample(
            "ESP32/ESP8266 - Raw (manual reset)",
            "App: Protocol = Raw (manual reset). Works with any TCP client, but no auto-reset - put the " +
                "board in bootloader mode yourself first (the app's Reset to Bootloader button or " +
                "RTS/DTR switches).",
            "esptool --port socket://PHONE_IP:PORT --baud 460800 --before no-reset --after no-reset write-flash 0x1000 firmware.bin"
        ),
        CliExample(
            "Erase one flash region",
            "Erases only the given address range - e.g. to clear saved WiFi/NVS settings without " +
                "touching the rest of flash. Offset and size must both be a multiple of 0x1000 (4096).",
            "esptool --port socket://PHONE_IP:PORT erase-region 0x9000 0x6000"
        ),
        CliExample(
            "Erase the entire flash chip",
            "Wipes everything - bootloader, partition table, app, all data. Good starting point for a " +
                "device that's in an unknown or corrupted state.",
            "esptool --port socket://PHONE_IP:PORT erase-flash"
        ),
        CliExample(
            "Read back a partition (e.g. SPIFFS)",
            "Dumps a region of flash to a local file - useful to back up or inspect a SPIFFS/LittleFS " +
                "partition before erasing it. Get the real offset/size for your device from the " +
                "parttool.py example below rather than guessing.",
            "esptool --port socket://PHONE_IP:PORT read-flash 0x290000 0x170000 spiffs_dump.bin"
        ),
        CliExample(
            "Query the partition table (ESP-IDF parttool.py)",
            "Reads a named partition's real offset/size straight from the device instead of guessing - " +
                "use its output for the read-flash example above.",
            "parttool.py --port socket://PHONE_IP:PORT get_partition_info --partition-name=spiffs"
        ),
        CliExample(
            "AmebaD / BW16 (upload_amebad.py)",
            "App: Protocol = Raw (auto-baud), Target Chip = AmebaD / BW16 (auto reset). Don't pass " +
                "--auto - the script's own DTR/RTS attempt is a no-op over a plain socket anyway; the " +
                "app handles reset automatically instead.",
            "python upload_amebad.py path/to/firmware_dir socket://PHONE_IP:PORT"
        ),
        CliExample(
            "Arduino / AVR (avrdude)",
            "App: Protocol = Raw (auto-baud), Target Chip = Arduino / AVR (auto reset). Use -c stk500v1, " +
                "not -c arduino - the latter tries its own DTR/RTS ioctl, which fails on a network port " +
                "(\"Inappropriate ioctl for device\") and never actually resets the chip; the app drives " +
                "the reset instead.",
            "avrdude -p atmega328p -c stk500v1 -P net:PHONE_IP:PORT -b 115200 -U flash:w:blink.ino.hex:i"
        ),
        CliExample(
            "Any other UART device (plain terminal)",
            "Raw (manual reset) is a plain byte pipe - works with anything that just talks over a TCP " +
                "socket, no ESP/AVR/AmebaD-specific tooling needed.",
            "nc PHONE_IP PORT"
        ),
        CliExample(
            "CH341A I²C - read 16 bytes from an EEPROM",
            "App: Bridge Mode = I²C, CONNECT, START BRIDGE (port 3334). Writes the word address 00, then " +
                "a repeated START and reads 16 bytes back. ch341-bridge is the Termux/PC client shipped " +
                "alongside this project.",
            "ch341-bridge i2c write-read 0x50 00 16 --host PHONE_IP --port 3334"
        ),
        CliExample(
            "CH341A I²C - probe one address",
            "Reads 1 byte from the 7-bit address; an absent device reads back all-0xFF/0x00 (the CH341A " +
                "doesn't report ACK/NAK per byte).",
            "ch341-bridge i2c read 0x3C 1 --host PHONE_IP --port 3334"
        ),
        CliExample(
            "CH341A SPI - read the flash JEDEC ID",
            "App: Bridge Mode = SPI, CONNECT, START BRIDGE (port 3335). Sends opcode 9F and reads 3 bytes.",
            "ch341-bridge spi transfer 9F 3 --host PHONE_IP --port 3335"
        ),
        CliExample(
            "CH341A SPI - read 256 bytes at address 0",
            "Uses the write-then-read opcode (opcode + 3-byte address as one burst, data as a second burst " +
                "under the same CS pulse) - required for bulk reads.",
            "ch341-bridge spi write-read 03000000 256 --host PHONE_IP --port 3335"
        ),
        CliExample(
            "Check a bridge port is open",
            "Only confirms the TCP port accepts a connection - the servers never speak first.",
            "ch341-bridge status i2c --host PHONE_IP --port 3334"
        )
    )


    // ---- service plumbing ---------------------------------------------------

    private val serviceConnection = object : android.content.ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val localBinder = service as BridgeService.LocalBinder
            bridgeService = localBinder.getService()
            bound = true
            bridgeService?.setListener(bridgeListener)
            bridgeService?.getStatus()?.let { st ->
                // Re-attach to a bridge/CH341A session that kept running while the UI was gone.
                if ((st.running || st.programmerConnected) && st.bridgeMode != currentMode) selectMode(st.bridgeMode, force = true)
                updateStatusUi(st)
            }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            bound = false
            bridgeService = null
        }
    }

    private val bridgeListener = object : BridgeListener {
        override fun onLog(message: String) {
            runOnUiThread { appendLog(message) }
        }

        override fun onStatusChanged(status: BridgeStatus) {
            runOnUiThread { updateStatusUi(status) }
        }
    }

    private val usbAttachReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                UsbManager.ACTION_USB_DEVICE_ATTACHED -> appendLog("USB device attached")
                UsbManager.ACTION_USB_DEVICE_DETACHED -> {
                    appendLog("USB device detached")
                    handleDetach()
                }
            }
        }
    }

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* no-op either way */ }

    // Image picker for the OLED card
    private val imageLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) showImageOnOled(uri)
        }

    // ---- lifecycle ------------------------------------------------------------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupInsets()
        setupSpinners()
        setupNavigation()
        setupModeAndResetTiles()
        setupOled()
        setupLogPanel()
        populateExamples()
        binding.panelSettings.tvAbout.text = aboutText()
        selectMode(BridgeMode.UART, force = true)
        selectTargetChip(TargetChip.ESP32)
        appendLog("Application started")

        pb.btnConnect.setOnClickListener { onConnectClicked() }
        pb.btnStartStop.setOnClickListener { onStartStopClicked() }
        pb.switchRts.setOnCheckedChangeListener { _, checked -> bridgeService?.setRTS(checked) }
        pb.switchDtr.setOnCheckedChangeListener { _, checked -> bridgeService?.setDTR(checked) }
        pb.btnAutoReset.setOnClickListener { performAutoReset() }
        pb.ivLogToggle.setOnClickListener { toggleLogCard() }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        val filter = IntentFilter().apply {
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(usbAttachReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(usbAttachReceiver, filter)
        }

        bindService(Intent(this, BridgeService::class.java), serviceConnection, Context.BIND_AUTO_CREATE)
    }

    override fun onResume() {
        super.onResume()
        updateStatusUi(bridgeService?.getStatus() ?: lastStatus)
    }

    override fun onDestroy() {
        super.onDestroy()
        logHandler.removeCallbacksAndMessages(null)
        unregisterReceiver(usbAttachReceiver)
        if (bound) {
            bridgeService?.setListener(null)
            unbindService(serviceConnection)
            bound = false
        }
    }

    // ---- insets (Android 15 edge-to-edge) -------------------------------------

    private fun setupInsets() {
        val headerPadTop = binding.header.paddingTop
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            binding.header.setPadding(
                binding.header.paddingLeft, headerPadTop + bars.top,
                binding.header.paddingRight, binding.header.paddingBottom
            )
            binding.root.setPadding(bars.left, 0, bars.right, ime.bottom)
            binding.bottomNav.setPadding(0, 0, 0, if (ime.bottom > 0) 0 else bars.bottom)
            insets
        }
        ViewCompat.requestApplyInsets(binding.root)
    }

    // ---- navigation -------------------------------------------------------------

    private fun setupNavigation() {
        binding.bottomNav.setOnItemSelectedListener { item ->
            showPanel(item.itemId)
            true
        }
        binding.bottomNav.selectedItemId = R.id.nav_bridge
        showPanel(R.id.nav_bridge)

        binding.btnGear.setOnClickListener { binding.bottomNav.selectedItemId = R.id.nav_settings }
        binding.btnMenu.setOnClickListener { v ->
            val popup = PopupMenu(this, v)
            popup.menu.add(0, R.id.nav_bridge, 0, "Bridge")
            popup.menu.add(0, R.id.nav_log, 1, "Log")
            popup.menu.add(0, R.id.nav_examples, 2, "Examples")
            popup.menu.add(0, R.id.nav_settings, 3, "Settings")
            popup.setOnMenuItemClickListener { binding.bottomNav.selectedItemId = it.itemId; true }
            popup.show()
        }
        binding.btnMore.setOnClickListener { v ->
            val popup = PopupMenu(this, v)
            popup.menu.add(0, 1, 0, "Copy log")
            popup.menu.add(0, 2, 1, "Clear log")
            popup.menu.add(0, 3, 2, "About")
            popup.setOnMenuItemClickListener {
                when (it.itemId) {
                    1 -> copyLog()
                    2 -> clearLog()
                    3 -> AlertDialog.Builder(this).setTitle("About").setMessage(aboutText()).setPositiveButton("OK", null).show()
                }
                true
            }
            popup.show()
        }
    }

    private fun showPanel(itemId: Int) {
        binding.panelBridge.root.visibility = if (itemId == R.id.nav_bridge) View.VISIBLE else View.GONE
        binding.panelLog.root.visibility = if (itemId == R.id.nav_log) View.VISIBLE else View.GONE
        binding.panelExamples.root.visibility = if (itemId == R.id.nav_examples) View.VISIBLE else View.GONE
        binding.panelSettings.root.visibility = if (itemId == R.id.nav_settings) View.VISIBLE else View.GONE
        if (itemId == R.id.nav_log) binding.panelLog.scrollLogFull.post { binding.panelLog.scrollLogFull.fullScroll(View.FOCUS_DOWN) }
    }

    private fun aboutText(): String =
        "TCP Bridge 2.1 - USB-serial ↔ TCP bridge (RFC2217 / raw / auto-baud) plus CH341A I²C ↔ TCP and " +
            "SPI ↔ TCP bridges (any I²C / SPI device, driven by TCP clients) and an SSD1306 I²C OLED driver.\n\n" +
            "Includes code ported from flashrom (GPL-2.0+), IMSProg (GPL-3.0+) and Adafruit's SSD1306/GFX " +
            "libraries (BSD) - see NOTICE.md in the project for details."

    // ---- spinners ---------------------------------------------------------------

    private fun spinnerAdapter(items: List<String>) =
        ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)

    private fun setupSpinners() {
        val s = binding.panelSettings
        s.spinnerBaud.adapter = spinnerAdapter(baudRates.map { it.toString() })
        s.spinnerBaud.setSelection(baudRates.indexOf(115200))
        s.spinnerDataBits.adapter = spinnerAdapter(dataBitsOptions.map { it.toString() })
        s.spinnerDataBits.setSelection(dataBitsOptions.indexOf(8))
        s.spinnerStopBits.adapter = spinnerAdapter(stopBitsLabels.toList())
        s.spinnerParity.adapter = spinnerAdapter(parityLabels.toList())
        s.spinnerI2cSpeed.adapter = spinnerAdapter(i2cSpeedLabels.toList())
        s.spinnerI2cSpeed.setSelection(i2cSpeedValues.indexOf(Ch341I2c.SPEED_400K))

        pb.spinnerProtocol.adapter = spinnerAdapter(protocolLabels.toList())
        pb.spinnerProtocol.setSelection(0) // RFC2217 by default
        pb.spinnerProtocol.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                currentProtocolMode = protocolValues[position]
                refreshHints()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        pb.spinnerOledSize.adapter = spinnerAdapter(oledSizes.map { it.label })
        pb.spinnerOledFont.adapter = spinnerAdapter(oledFontLabels)

    }

    // ---- mode / reset tiles -----------------------------------------------------

    private fun setupModeAndResetTiles() {
        pb.tileModeUart.setOnClickListener { selectMode(BridgeMode.UART) }
        pb.tileModeI2c.setOnClickListener { selectMode(BridgeMode.I2C) }
        pb.tileModeSpi.setOnClickListener { selectMode(BridgeMode.SPI) }
        pb.tileEsp32.setOnClickListener { selectTargetChip(TargetChip.ESP32) }
        pb.tileAmeba.setOnClickListener { selectTargetChip(TargetChip.AMEBAD) }
        pb.tileAvr.setOnClickListener { selectTargetChip(TargetChip.AVR_ARDUINO) }
        pb.tileGeneric.setOnClickListener { selectTargetChip(TargetChip.GENERIC) }
    }

    private fun selectTargetChip(chip: TargetChip) {
        currentTargetChip = chip
        pb.tileEsp32.isSelected = chip == TargetChip.ESP32
        pb.tileAmeba.isSelected = chip == TargetChip.AMEBAD
        pb.tileAvr.isSelected = chip == TargetChip.AVR_ARDUINO
        pb.tileGeneric.isSelected = chip == TargetChip.GENERIC
        refreshHints()
    }

    /** True while an adapter is selected/connected or a bridge is running - the mode can't change then. */
    private fun isBusy(): Boolean = uartDriver != null || lastStatus.running || lastStatus.programmerConnected

    private fun selectMode(mode: BridgeMode, force: Boolean = false) {
        if (!force && isBusy() && mode != currentMode) {
            Toast.makeText(this, "Disconnect first to change the bridge mode", Toast.LENGTH_SHORT).show()
            return
        }
        currentMode = mode
        pb.tileModeUart.isSelected = mode == BridgeMode.UART
        pb.tileModeI2c.isSelected = mode == BridgeMode.I2C
        pb.tileModeSpi.isSelected = mode == BridgeMode.SPI
        pb.cardReset.visibility = if (mode == BridgeMode.UART) View.VISIBLE else View.GONE
        pb.cardOled.visibility = if (mode == BridgeMode.I2C) View.VISIBLE else View.GONE
        if (!lastStatus.running) pb.etTcpPort.setText(mode.defaultPort.toString())
        pb.tvModeHint.text = when (mode) {
            BridgeMode.UART ->
                "Plug in a USB-serial adapter (CH340 / CP210x / FTDI / PL2303 / CDC-ACM, incl. ESP32 native USB)."
            BridgeMode.I2C ->
                "Plug in a CH341A programmer (USB 1A86:5512). Exposes its I²C bus over TCP and drives I²C OLED displays."
            BridgeMode.SPI ->
                "Plug in a CH341A programmer (USB 1A86:5512). Exposes its SPI bus (CS0) over TCP for any SPI device (flash, ADC, ...)."
        }
        pb.tvTcpHint.text = when (mode) {
            BridgeMode.UART -> ""
            BridgeMode.I2C -> "Protocol: [op][addr7][wLen u16][data][rLen u16] → [status][len u16][data]. " +
                "Client: ch341-bridge (Termux / PC), see Examples."
            BridgeMode.SPI -> "Protocol: [op][wLen u16][data][rLen u16] → [status][len u16][data]. " +
                "Client: ch341-bridge (Termux / PC), see Examples."
        }
        updateStatusUi(lastStatus)
    }

    // ---- connect / start / stop -----------------------------------------------------

    private fun isConnected(): Boolean = when (currentMode) {
        BridgeMode.UART -> uartDriver != null || (lastStatus.running && lastStatus.bridgeMode == BridgeMode.UART)
        else -> lastStatus.programmerConnected
    }

    private fun onConnectClicked() {
        if (isConnected()) {
            disconnect()
        } else if (currentMode == BridgeMode.UART) {
            connectUart { }
        } else {
            connectProgrammer { }
        }
    }

    private fun disconnect() {
        val svc = bridgeService
        if (currentMode == BridgeMode.UART) {
            if (svc?.getStatus()?.running == true) svc.stopBridge()
            uartDriver = null
            appendLog("Disconnected")
            updateStatusUi(svc?.getStatus() ?: lastStatus)
        } else {
            svc?.disconnectProgrammer()
        }
    }

    private fun connectUart(onReady: () -> Unit) {
        val usbManager = getSystemService(Context.USB_SERVICE) as UsbManager
        // A CH341A in programmer mode (1A86:5512) is not a serial port - never offer it here.
        val drivers = UsbSerialProber.getDefaultProber().findAllDrivers(usbManager).filterNot {
            it.device.vendorId == Ch341UsbDevice.VENDOR_ID && it.device.productId == Ch341UsbDevice.PRODUCT_ID_PROGRAMMER
        }
        if (drivers.isEmpty()) {
            appendLog("No USB serial device found - plug in an adapter (use an OTG cable if needed)")
            Toast.makeText(this, "No USB serial device found", Toast.LENGTH_SHORT).show()
            return
        }
        fun pick(driver: UsbSerialDriver) {
            val grant = { _: Boolean ->
                uartDriver = driver
                appendLog("Connected: ${describe(driver)}")
                updateStatusUi(bridgeService?.getStatus() ?: lastStatus)
                onReady()
            }
            if (usbManager.hasPermission(driver.device)) {
                grant(true)
            } else {
                requestUsbPermission(driver) { granted ->
                    if (granted) grant(true) else appendLog("USB permission denied")
                }
            }
        }
        if (drivers.size == 1) {
            pick(drivers[0])
        } else {
            AlertDialog.Builder(this)
                .setTitle("Select USB device")
                .setItems(drivers.map { describe(it) }.toTypedArray()) { _, which -> pick(drivers[which]) }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    private fun describe(d: UsbSerialDriver): String =
        "${UsbChipIdentifier.name(d.device.vendorId, d.device.productId)}  (VID:${d.device.vendorId} PID:${d.device.productId})"

    private fun connectProgrammer(onReady: () -> Unit) {
        val svc = bridgeService
        if (svc == null) {
            appendLog("Service not ready yet, please try again")
            return
        }
        val dev = svc.programmer.findDevice()
        if (dev == null) {
            appendLog("No CH341A programmer found (USB 1A86:5512) - a CH340 serial adapter is a different mode")
            Toast.makeText(this, "No CH341A programmer found", Toast.LENGTH_SHORT).show()
            return
        }
        val mode = currentMode
        val open = {
            ContextCompat.startForegroundService(this, Intent(this, BridgeService::class.java))
            val speed = i2cSpeedValues[binding.panelSettings.spinnerI2cSpeed.selectedItemPosition]
            svc.connectProgrammer(dev, mode, speed) { ok -> if (ok) onReady() }
        }
        if (svc.programmer.hasPermission(dev)) {
            open()
        } else {
            svc.programmer.requestPermission(dev) { granted ->
                if (granted) open() else appendLog("USB permission denied")
            }
        }
    }

    private fun onStartStopClicked() {
        val svc = bridgeService
        if (svc == null) {
            appendLog("Service not ready yet, please try again")
            return
        }
        if (svc.getStatus().running) {
            svc.stopBridge()
            return
        }
        val port = pb.etTcpPort.text.toString().toIntOrNull()
        if (port == null || port !in 1..65535) {
            appendLog("Invalid TCP port")
            return
        }
        val mode = currentMode
        if (mode == BridgeMode.UART) {
            val go = { driver: UsbSerialDriver ->
                val baud = baudRates[binding.panelSettings.spinnerBaud.selectedItemPosition]
                val dataBits = dataBitsOptions[binding.panelSettings.spinnerDataBits.selectedItemPosition]
                val stopBits = stopBitsValues[binding.panelSettings.spinnerStopBits.selectedItemPosition]
                val parity = parityValues[binding.panelSettings.spinnerParity.selectedItemPosition]
                launchBridge(driver, baud, dataBits, stopBits, parity, port, currentProtocolMode, currentTargetChip)
            }
            val d = uartDriver
            if (d != null) go(d) else connectUart { uartDriver?.let { go(it) } }
        } else {
            val go = {
                ContextCompat.startForegroundService(this, Intent(this, BridgeService::class.java))
                svc.startProgrammerBridge(mode, port)
                Unit
            }
            if (svc.getStatus().programmerConnected) go() else connectProgrammer { go() }
        }
    }

    private fun launchBridge(
        driver: UsbSerialDriver,
        baud: Int,
        dataBits: Int,
        stopBits: Int,
        parity: Int,
        port: Int,
        protocolMode: ServerMode,
        targetChip: TargetChip
    ) {
        ContextCompat.startForegroundService(this, Intent(this, BridgeService::class.java))
        bridgeService?.startBridge(driver, baud, dataBits, stopBits, parity, port, protocolMode, targetChip)
    }

    /** USB unplugged: drop whatever session pointed at the removed device. */
    private fun handleDetach() {
        val usbManager = getSystemService(Context.USB_SERVICE) as UsbManager
        val present = usbManager.deviceList.values
        uartDriver?.let { d ->
            if (present.none { it.deviceName == d.device.deviceName }) {
                if (bridgeService?.getStatus()?.running == true && lastStatus.bridgeMode == BridgeMode.UART) {
                    bridgeService?.stopBridge()
                }
                uartDriver = null
                appendLog("Serial adapter removed")
            }
        }
        val svc = bridgeService
        if (svc != null && svc.getStatus().programmerConnected && svc.programmer.findDevice() == null) {
            svc.disconnectProgrammer()
            appendLog("CH341A removed")
        }
        updateStatusUi(svc?.getStatus() ?: lastStatus)
    }

    private fun requestUsbPermission(driver: UsbSerialDriver, callback: (Boolean) -> Unit) {
        val usbManager = getSystemService(Context.USB_SERVICE) as UsbManager
        val action = "com.tcpuartbridge.app.USB_PERMISSION"
        val mutabilityFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0
        val permissionIntent = PendingIntent.getBroadcast(
            this, 0, Intent(action).setPackage(packageName), mutabilityFlag
        )

        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                if (intent.action == action) {
                    unregisterReceiver(this)
                    callback(intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false))
                }
            }
        }
        val filter = IntentFilter(action)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(receiver, filter)
        }
        usbManager.requestPermission(driver.device, permissionIntent)
    }


    private fun refreshHints() {
        pb.tvProtocolHint.text = when (currentProtocolMode) {
            ServerMode.RFC2217 ->
                "RFC2217: esptool talks to this app directly and drives real, correctly-timed DTR/RTS resets. " +
                    "Use --port rfc2217://PHONE_IP:PORT?ign_set_control with esptool."
            ServerMode.RAW_AUTOBAUD ->
                "Raw (auto-baud): plain byte passthrough like Raw, but this app watches the wire for " +
                    "esptool's or upload_amebad.py's own baud-change command and follows it, so --baud works " +
                    "over a plain socket:// without RFC2217. Always opens at 115200 first (data bits/stop " +
                    "bits/parity below still apply - the Baud Rate value itself is ignored here), and resets " +
                    "back to 115200 when the connection closes, ready for the next session. With Target Chip " +
                    "set to ESP32, AmebaD/BW16, or Arduino/AVR, it also auto-resets the board into " +
                    "download/bootloader mode when a client connects (and, for ESP32/AmebaD, boots the " +
                    "flashed app when it disconnects too) - no manual button needed."
            else ->
                "Raw: plain byte passthrough, works with any TCP client " +
                    "(nc, PuTTY raw socket, esptool --port socket://...), but has no channel for remote reset control."
        }

        pb.tvEsp32Note.text = when {
            currentTargetChip == TargetChip.GENERIC && currentProtocolMode == ServerMode.RFC2217 ->
                "Generic mode: DTR/RTS commands from the client are relayed straight through with no " +
                    "sequence timing. Use this if the automatic ESP32/AmebaD/AVR reset sequences don't work " +
                    "on your board - or fall back to the RTS/DTR switches below to drive the lines by hand."
            currentTargetChip == TargetChip.GENERIC ->
                "Generic mode: no automatic sequence is applied here. Use the RTS/DTR switches below as a " +
                    "manual fallback to put the board in bootloader/download mode by hand - useful for boards " +
                    "whose reset conventions don't match ESP32's, AmebaD's, or AVR's."
            currentTargetChip == TargetChip.AMEBAD && currentProtocolMode == ServerMode.RAW_AUTOBAUD ->
                "Raw (auto-baud) automatically runs the AmebaD download-mode-entry sequence when a client " +
                    "connects, and resets to normal boot when it disconnects - you shouldn't need this button " +
                    "or the switches. They're still here as a fallback if that doesn't work on your board " +
                    "(manually flipping both switches by hand is unlikely to hit the required 500ms/200ms/500ms " +
                    "timing reliably, though - prefer this button, which runs the same timed sequence in code)."
            currentTargetChip == TargetChip.AMEBAD ->
                "AmebaD/BW16 download-mode sequence (500ms/200ms/500ms, from upload_amebad.py's " +
                    "enter_download_mode()). Only auto-runs on connect/disconnect in Raw (auto-baud) mode - " +
                    "elsewhere, use this button before flashing. Manually flipping the switches by hand is " +
                    "unlikely to hit the timing reliably; prefer this button."
            currentTargetChip == TargetChip.AVR_ARDUINO && currentProtocolMode == ServerMode.RAW_AUTOBAUD ->
                "Raw (auto-baud) automatically runs this reset sequence when a client connects - you " +
                    "shouldn't need this button or the switches. No pulse is needed on disconnect: Optiboot-" +
                    "style bootloaders jump to the flashed app on their own after a short idle timeout. Use " +
                    "avrdude's -c stk500v1, not -c arduino - the latter tries its own DTR/RTS ioctl, which " +
                    "fails on a network port and never actually resets the chip."
            currentTargetChip == TargetChip.AVR_ARDUINO ->
                "Arduino/AVR bootloader-entry sequence (250ms/50ms, copied from avrdude's own " +
                    "arduino_open()). Only auto-runs on connect in Raw (auto-baud) mode - elsewhere, use this " +
                    "button before flashing. Use avrdude's -c stk500v1, not -c arduino - the latter tries its " +
                    "own DTR/RTS ioctl, which fails on a network port and never actually resets the chip."
            currentProtocolMode == ServerMode.RAW_AUTOBAUD ->
                "Raw (auto-baud) automatically runs this sequence when a client connects, and a plain hard " +
                    "reset when it disconnects - you shouldn't need these manual switches. They're still here " +
                    "as a fallback if that doesn't work on your board."
            currentProtocolMode == ServerMode.RFC2217 ->
                "In RFC2217 mode, esptool resets the board automatically before/after flashing - you " +
                    "shouldn't need these manual switches. They're still here as a fallback: if the automatic " +
                    "sequence fails on your board, drive RTS/DTR by hand with the switches or this button."
            else ->
                "Note: a plain TCP socket has no control-line channel, so esptool.py cannot toggle RTS/DTR " +
                    "remotely over socket://. Use this button, or the RTS/DTR switches, to put the board in " +
                    "bootloader mode before flashing, then run esptool with --before no-reset --after no-reset."
        }
    }


    private fun performAutoReset() {
        val svc = bridgeService ?: return
        when (currentTargetChip) {
            TargetChip.ESP32 -> performEsp32BootloaderReset(svc)
            TargetChip.AMEBAD -> performAmebaDownloadModeReset(svc)
            TargetChip.AVR_ARDUINO -> performArduinoReset(svc)
            TargetChip.GENERIC -> appendLog(
                "Generic mode has no built-in auto-reset sequence - use the RTS/DTR switches above " +
                    "as the manual fallback to drive the lines by hand for your board's reset convention."
            )
        }
    }

    /** Classic ESP32 auto-reset-to-bootloader pulse sequence (DTR=GPIO0, RTS=EN) - mirrors esptool's ClassicReset. */
    private fun performEsp32BootloaderReset(svc: BridgeService) {
        val t0 = SystemClock.elapsedRealtime()
        fun step(msg: String) = appendLog("[+${SystemClock.elapsedRealtime() - t0}ms] $msg")
        lifecycleScope.launch {
            step("ESP32 reset: DTR=0 (IO0=HIGH), RTS=1 (EN=LOW, reset)")
            svc.setDTR(false)
            svc.setRTS(true)
            delay(100)
            step("DTR=1 (IO0=LOW), RTS=0 (EN=HIGH, exits reset -> should sample IO0 LOW -> bootloader)")
            svc.setDTR(true)
            svc.setRTS(false)
            delay(50)
            step("DTR=0 (IO0=HIGH, done)")
            svc.setDTR(false)
            appendLog(
                "Sent bootloader reset sequence. If the board still boots normally instead of entering the " +
                    "bootloader, that's very likely a wiring/chip-driver polarity issue rather than sequence " +
                    "timing - the steps above match esptool's ClassicReset exactly."
            )
        }
    }

    /**
     * AmebaD/BW16 download-mode-entry pulse sequence - reverse-engineered exactly from
     * upload_amebad.py's enter_download_mode()/set_dtr_rts() (0x2 -> 0x1 -> 0x3, 500/200/500ms).
     * In Raw (auto-baud) mode this now also runs automatically on connect/disconnect (see
     * TcpServerManager) - this manual button remains as a fallback/for testing outside that mode.
     */
    private fun performAmebaDownloadModeReset(svc: BridgeService) {
        val t0 = SystemClock.elapsedRealtime()
        fun step(msg: String) = appendLog("[+${SystemClock.elapsedRealtime() - t0}ms] $msg")
        lifecycleScope.launch {
            step("AmebaD download mode: RTS=1, DTR=0 (EN low / reset)")
            svc.setRTS(true)
            svc.setDTR(false)
            delay(500)
            step("RTS=0, DTR=1 (download-mode select)")
            svc.setRTS(false)
            svc.setDTR(true)
            delay(200)
            step("RTS=0, DTR=0 (release)")
            svc.setRTS(false)
            svc.setDTR(false)
            delay(500)
            appendLog("Sent AmebaD/BW16 download-mode reset sequence.")
        }
    }

    /**
     * Arduino/AVR bootloader-entry pulse - the classic "DTR through a capacitor to RESET"
     * auto-reset, timing copied exactly from avrdude's own arduino_open() (clear DTR+RTS,
     * 250ms, set DTR+RTS, 50ms). In Raw (auto-baud) mode this now also runs automatically
     * on connect (see TcpServerManager) - this manual button remains as a fallback/for
     * testing outside that mode. Use avrdude's -c stk500v1 (not -c arduino) so avrdude
     * doesn't also attempt its own DTR/RTS ioctl, which fails over a network port anyway.
     */
    private fun performArduinoReset(svc: BridgeService) {
        val t0 = SystemClock.elapsedRealtime()
        fun step(msg: String) = appendLog("[+${SystemClock.elapsedRealtime() - t0}ms] $msg")
        lifecycleScope.launch {
            step("Arduino/AVR reset: DTR=0, RTS=0 (clear - discharges the reset capacitor)")
            svc.setDTR(false)
            svc.setRTS(false)
            delay(250)
            step("DTR=1, RTS=1 (set - the rising edge triggers reset)")
            svc.setDTR(true)
            svc.setRTS(true)
            delay(50)
            appendLog("Sent Arduino/AVR bootloader-entry reset sequence.")
        }
    }


    // ---- I²C OLED ---------------------------------------------------------------

    private fun setupOled() {
        pb.btnOledInit.setOnClickListener { oledInit() }
        pb.btnOledClear.setOnClickListener { oledRun("Clear") { it.displayClear() } }
        pb.btnOledTest.setOnClickListener { oledRun("Test pattern") { it.displayTestPattern() } }
        pb.btnOledText.setOnClickListener { oledText() }
        pb.btnOledImage.setOnClickListener {
            if (requireProgrammer() != null) imageLauncher.launch("image/*")
        }
        pb.btnOledClock.setOnClickListener { oledClock() }
        pb.btnOledStats.setOnClickListener { oledStats() }
        pb.btnOledStop.setOnClickListener { requireProgrammer()?.stopContinuous() }
    }

    /** Returns the connected CH341A controller, or logs why not. */
    private fun requireProgrammer(): ProgrammerController? {
        val svc = bridgeService
        if (svc == null || !svc.getStatus().programmerConnected) {
            appendLog("Connect the CH341A first")
            return null
        }
        return svc.programmer
    }

    private fun oledInit() {
        val p = requireProgrammer() ?: return
        val addr = pb.etOledAddr.text.toString().trim().toIntOrNull(16)
        if (addr == null || addr !in 0x08..0x77) {
            appendLog("Invalid OLED address - enter 7-bit hex such as 3C or 3D")
            return
        }
        val size = oledSizes[pb.spinnerOledSize.selectedItemPosition]
        lifecycleScope.launch {
            p.stopContinuous()
            val ok = p.initDisplay(addr, size.w, size.h)
            appendLog(
                if (ok) "OLED initialised at 0x%02X (%s)".format(addr, size.label)
                else "OLED init failed (0x%02X) - check wiring/address. %s".format(addr, p.usbDevice.lastError ?: "")
            )
        }
    }

    private fun oledRun(what: String, block: suspend (ProgrammerController) -> Boolean) {
        val p = requireProgrammer() ?: return
        lifecycleScope.launch {
            p.stopContinuous()
            val ok = block(p)
            appendLog(if (ok) "OLED: $what" else "OLED: $what failed - did you tap Init?")
        }
    }

    private fun applyOledFont(p: ProgrammerController): Boolean {
        val idx = pb.spinnerOledFont.selectedItemPosition
        if (idx <= 0) {
            p.clearCustomFont()
            return false
        }
        val f = ProgrammerController.BUNDLED_FONTS[idx - 1]
        val ok = p.loadBundledFont(this, f.assetPath, f.displayName)
        if (!ok) appendLog("Could not load font ${f.displayName}, using the built-in font")
        return ok
    }

    private fun oledText() {
        val p = requireProgrammer() ?: return
        val text = pb.etOledText.text.toString()
        if (text.isBlank()) {
            appendLog("Type some text first")
            return
        }
        lifecycleScope.launch {
            p.stopContinuous()
            val custom = applyOledFont(p)
            val ok = if (custom) p.displayCustomText(text) else p.displayText(text)
            appendLog(if (ok) "OLED: text drawn" else "OLED: text failed - did you tap Init?")
        }
    }

    private fun showImageOnOled(uri: Uri) {
        val p = requireProgrammer() ?: return
        lifecycleScope.launch {
            p.stopContinuous()
            val bmp = withContext(Dispatchers.IO) {
                try {
                    contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                } catch (e: Exception) {
                    null
                }
            }
            if (bmp == null) {
                appendLog("Could not decode that image")
                return@launch
            }
            val ok = p.displayBitmap(bmp)
            bmp.recycle()
            appendLog(if (ok) "OLED: image drawn" else "OLED: image failed - did you tap Init?")
        }
    }

    private fun oledClock() {
        val p = requireProgrammer() ?: return
        applyOledFont(p)
        p.startClock { err -> runOnUiThread { appendLog(err ?: "OLED: clock stopped") } }
        appendLog("OLED: clock running")
    }

    private fun oledStats() {
        val p = requireProgrammer() ?: return
        p.startStats(applicationContext) { err -> runOnUiThread { appendLog(err ?: "OLED: stats stopped") } }
        appendLog("OLED: phone stats running")
    }

    // ---- examples ---------------------------------------------------------------

    /** Inflates one card per [cliExamples] entry into llExamplesContainer, each with a working Copy button. */
    private fun populateExamples() {
        val container = binding.panelExamples.llExamplesContainer
        val inflater = LayoutInflater.from(this)
        cliExamples.forEach { example ->
            val itemView = inflater.inflate(R.layout.item_example, container, false)
            itemView.findViewById<TextView>(R.id.tvExampleTitle).text = example.title
            itemView.findViewById<TextView>(R.id.tvExampleExplanation).text = example.explanation
            itemView.findViewById<TextView>(R.id.tvExampleCommand).text = example.command
            itemView.findViewById<Button>(R.id.btnCopyExample).setOnClickListener {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText(example.title, example.command))
                Toast.makeText(this, "Copied to clipboard", Toast.LENGTH_SHORT).show()
            }
            container.addView(itemView)
        }
    }

    // ---- UI updates -----------------------------------------------------------------

    private fun updateStatusUi(status: BridgeStatus) {
        lastStatus = status
        val connected = isConnected()
        val running = status.running && status.bridgeMode == currentMode

        val stateText = when {
            running && currentMode == BridgeMode.UART -> "Bridge running · ${status.deviceName}"
            running -> "Bridge running · ${status.deviceName}"
            currentMode == BridgeMode.UART && uartDriver != null -> "Connected: ${describe(uartDriver!!)}"
            currentMode != BridgeMode.UART && status.programmerConnected -> "Connected: ${status.deviceName} (${currentMode.label} mode)"
            else -> "Not connected"
        }
        pb.tvConnState.text = stateText
        pb.viewConnDot.setBackgroundResource(if (connected || running) R.drawable.dot_ok else R.drawable.dot_idle)
        pb.btnConnect.text = if (connected) "DISCONNECT" else "CONNECT"

        pb.btnStartStop.text = if (running) "STOP BRIDGE" else "START BRIDGE"
        pb.btnStartStop.setCompoundDrawablesRelativeWithIntrinsicBounds(
            if (running) R.drawable.ic_stop else R.drawable.ic_play, 0, 0, 0
        )
        pb.etTcpPort.isEnabled = !running
        pb.etServerIp.setText(if (running) status.ipAddress else OledCompositor.wifiOrCellularIpAddress(this))
        pb.tvClientCount.text = if (running) {
            val extra = if (currentMode == BridgeMode.UART) {
                val m = when (status.protocolMode) {
                    ServerMode.RFC2217 -> "RFC2217"
                    ServerMode.RAW_AUTOBAUD -> "raw, auto-baud"
                    ServerMode.RAW -> "raw"
                }
                "  ·  Protocol: $m"
            } else ""
            "Port ${status.tcpPort}  ·  Clients connected: ${status.clientCount}$extra"
        } else {
            "Clients connected: 0"
        }

        val tilesEnabled = !(isBusy())
        listOf(pb.tileModeUart, pb.tileModeI2c, pb.tileModeSpi).forEach { it.alpha = if (tilesEnabled) 1f else 0.6f }
    }

    // ---- log ----------------------------------------------------------------------------

    private val logBuf = SpannableStringBuilder()
    private val logHandler = Handler(Looper.getMainLooper())
    private var logUpdatePending = false

    private fun appendLog(message: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        val lower = message.lowercase(Locale.ROOT)
        val (level, color) = when {
            "verify failed" in lower || "error" in lower || "failed" in lower || "denied" in lower || "invalid" in lower ->
                "ERROR" to R.color.status_error
            "no usb" in lower || "no ch341" in lower || "first" in lower || "stop the" in lower || "removed" in lower ->
                "WARN" to R.color.status_warn
            else -> "INFO" to R.color.app_blue
        }
        val start = logBuf.length
        logBuf.append("[$time] ")
        logBuf.setSpan(ForegroundColorSpan(ContextCompat.getColor(this, R.color.slate_400)), start, logBuf.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        val lvStart = logBuf.length
        logBuf.append(level.padEnd(6))
        logBuf.setSpan(ForegroundColorSpan(ContextCompat.getColor(this, color)), lvStart, logBuf.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        logBuf.append(message).append('\n')
        if (logBuf.length > MAX_LOG_CHARS) logBuf.delete(0, logBuf.length - MAX_LOG_CHARS / 2)
        scheduleLogRefresh()
    }

    private fun scheduleLogRefresh() {
        if (logUpdatePending) return
        logUpdatePending = true
        logHandler.postDelayed({
            logUpdatePending = false
            pb.tvLog.text = logBuf
            binding.panelLog.tvLogFull.text = logBuf
            pb.scrollLog.post { pb.scrollLog.fullScroll(View.FOCUS_DOWN) }
            binding.panelLog.scrollLogFull.post { binding.panelLog.scrollLogFull.fullScroll(View.FOCUS_DOWN) }
        }, 120)
    }

    private fun setupLogPanel() {
        binding.panelLog.btnLogCopy.setOnClickListener { copyLog() }
        binding.panelLog.btnLogClear.setOnClickListener { clearLog() }
    }

    private fun copyLog() {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("TCP Bridge log", logBuf.toString()))
        Toast.makeText(this, "Log copied", Toast.LENGTH_SHORT).show()
    }

    private fun clearLog() {
        logBuf.clear()
        scheduleLogRefresh()
    }

    private fun toggleLogCard() {
        val show = pb.scrollLog.visibility != View.VISIBLE
        pb.scrollLog.visibility = if (show) View.VISIBLE else View.GONE
        pb.ivLogToggle.setImageResource(if (show) R.drawable.ic_chevron_up else R.drawable.ic_chevron_down)
    }

    companion object {
        private const val MAX_LOG_CHARS = 40_000
    }
}
