# NOTICE

This project is otherwise original work, but includes protocol logic
ported from two GPL-licensed C projects (the CH341A SPI and I2C stream protocols), some BSD-licensed code and
data, and two bundled third-party font files. This file documents what
was ported from where, per those licenses' attribution expectations.
It's a factual provenance note, not a legal opinion — if you plan to
redistribute this app, check the actual license terms yourself.

## Ported code

**`app/src/main/java/com/tcpuartbridge/app/ch341/Ch341Spi.kt`**
Protocol logic (`config_stream()`, `enable_pins()`,
`ch341a_spi_send_command()`, `swap_byte()`, and the packet-framing
constants) ported from **flashrom**'s `ch341a_spi.c`
(https://github.com/flashrom/flashrom), licensed GPL-2.0-or-later.

**`app/src/main/java/com/tcpuartbridge/app/ch341/Ch341I2c.kt`**
I2C stream command-byte protocol ported from **IMSProg**'s `ch34x_i2c.c`
(`ch34xi2cBlockRead`/`ch34xi2cBlockWrite`)
(https://github.com/inexbee/IMSProg — this project was built from
IMSProg 1.8.6), licensed GPL-3.0-or-later.

## Ported code (BSD-licensed)

**`app/src/main/java/com/tcpuartbridge/app/display/Ssd1306.kt`**
The SSD1306 init sequence itself is standard across the chip's datasheet
and every SSD1306 driver library, and the word-wrap/framebuffer/flush
logic is original. But the per-panel-size (width *and* height, not just
height) COM-pin/contrast table in `panelConfig()`, the 64-wide-panel
column-address offset in `flush()`, and the hardware scroll commands
(`startScrollRight`/`Left`/`DiagRight`/`DiagLeft`/`stopScroll`) were
pulled from **Adafruit's official SSD1306 Arduino library**
(`Adafruit_SSD1306.cpp`, https://github.com/adafruit/Adafruit_SSD1306),
and `FONT_5X7` is Adafruit_GFX's classic `glcdfont.c` "Standard ASCII 5x7
font" (https://github.com/adafruit/Adafruit-GFX-Library) - both
BSD-licensed, Copyright (c) 2012 Adafruit Industries, replacing this
file's earlier hand-rolled uppercase/digits-only font and height-only
contrast bucketing (which had a real bug: it silently gave 96x16 panels
128x32's contrast value instead of their own).

## Original code

Everything else in the app is original to this project,
written from public/standard specifications rather than any GPL source:

- **`app/src/main/java/com/tcpuartbridge/app/ch341/Ch341UsbDevice.kt`** -
  the raw Android `UsbDeviceConnection` transport (bulk transfers,
  permission flow). IMSProg/flashrom talk to the same chip via `libusb`
  on desktop OSes; this uses Android's own USB host API instead, so
  there's no meaningful code to port at that layer.
- **`app/src/main/java/com/tcpuartbridge/app/display/OledCompositor.kt`**
  and the clock/stats-dashboard additions to
  `ProgrammerController.kt` - original code. The clock/stats screens are
  conceptually similar to the classic Python `clock.py`/`stats.py`
  reference scripts this project's SSD1306 support was originally
  cross-checked against (same idea: an analog clock face, a battery/RAM/
  storage dashboard), but nothing was ported from them - the graphics
  are drawn with Android's `Canvas`, the phone-stats readings come from
  Android's own `BatteryManager`/`ActivityManager`/`StatFs` APIs (a
  phone has no CPU-temperature sensor API the way the Pi scripts assumed),
  and the animation loop is this project's own take on the same idea as
  `pbm_gif_all.py` (loop over a folder of frames) adapted to
  Android-picked image files instead of a folder of `.pbm`s.
- **`app/src/main/java/com/tcpuartbridge/app/programmer/ProgrammerController.kt`**
  and the rest of the app's UI code in `MainActivity.kt` / `panel_bridge.xml`
  are original glue code specific to this app.

## Bundled font assets

**`app/src/main/assets/fonts/alagard.ttf`** and
**`app/src/main/assets/fonts/PixelOperator.ttf`** are third-party font
files bundled as-is (not modified), offered as one-tap "Custom Font"
options alongside picking any font from the phone. They're commonly
distributed as free-for-personal-and-commercial-use pixel fonts -
Alagard by Brian Kent (Vault42) and PixelOperator by Jayvee Enaguas
(HarvettFox96) - but this project didn't originate them and isn't the
place to take a license's exact terms on faith: if you plan to
redistribute this app, confirm the license of the specific copies of
these two files yourself.
