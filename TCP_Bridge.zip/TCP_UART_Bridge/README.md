# TCP Bridge 2.1

Android app that bridges USB hardware to TCP, in three modes (pick on the Bridge tab):

| Mode | Hardware | TCP side | Default port |
|---|---|---|---|
| **UART** | CH340 / CP210x / FTDI / PL2303 / CDC-ACM (incl. ESP32 native USB) | RFC2217, raw, or raw + auto-baud (esptool / PlatformIO / pyserial `rfc2217://`) | 3333 |
| **I²C** | CH341A programmer (USB 1A86:5512) | `[op][addr7][wLen u16][data][rLen u16]` -> `[status][len u16][data]` | 3334 |
| **SPI** | CH341A programmer (CS0) | `[op][wLen u16][data][rLen u16]` -> `[status][len u16][data]` | 3335 |

The I²C and SPI servers are generic: any I²C device (EEPROMs, sensors, RTCs, displays ...) or SPI device (flash, ADCs, ...) is driven by the TCP client (`ch341-bridge` Termux/PC script in this folder - see the Examples tab). The app itself has no chip-specific tools except:
* **I²C OLED (SSD1306)** card on the Bridge tab (I²C mode): init, clear, test pattern, text (built-in or bundled fonts), image, clock, phone stats.

UI follows the Stitch design (blue header, card layout, Bridge / Log / Examples / Settings bottom bar; gear icon = Settings).

## Using it
1. Plug in the adapter (OTG cable), choose the mode, tap **CONNECT** (grants USB permission).
2. Tap **START BRIDGE**; clients connect to the shown IP and port. The phone is the TCP server.
3. Mode can only be changed while disconnected. The OLED card and the TCP bridge share the one CH341A and can be used together.

## Building
`Build_TCP_Bridge_Release.ipynb` (Google Colab) builds a **signed release APK**; or locally: set `TCPBRIDGE_KEYSTORE`, `TCPBRIDGE_KEYSTORE_PASSWORD`, `TCPBRIDGE_KEY_ALIAS`, `TCPBRIDGE_KEY_PASSWORD` and run `gradle assembleRelease`. Without a keystore the release APK is unsigned and will not install.

compileSdk / targetSdk 36 (AGP 8.13, Gradle 8.13, JDK 17). Package id is unchanged (`com.tcpuartbridge.app`). Older UART-only notes: `docs/UART_NOTES.md`. Third-party licences: `NOTICE.md`.
