# TCP Bridge 2.0

Android app that bridges USB hardware to TCP, in three modes (pick on the Bridge tab):

| Mode | Hardware | TCP side | Default port |
|---|---|---|---|
| **UART** | CH340 / CP210x / FTDI / PL2303 / CDC-ACM (incl. ESP32 native USB) | RFC2217, raw, or raw + auto-baud (esptool / PlatformIO / pyserial `rfc2217://`) | 3333 |
| **I²C** | CH341A programmer (USB 1A86:5512) | `[op][addr7][wLen u16][data][rLen u16]` -> `[status][len u16][data]` | 3334 |
| **SPI** | CH341A programmer (CS0) | `[op][wLen u16][data][rLen u16]` -> `[status][len u16][data]` | 3335 |

Extra tools (CH341A only):
* **I²C OLED (SSD1306)** on the Bridge tab (I²C mode): init, clear, test pattern, text (built-in or bundled fonts), image, clock, phone stats.
* **Files tab**: read / write / erase / verify SPI flash (25xx, JEDEC auto-detect) and I²C EEPROM (24Cxx), via the Android file picker.
* `ch341-bridge` (Termux/PC client script, in this folder) talks to the I²C/SPI TCP servers - see the Examples tab.

UI follows the Stitch design (blue header, card layout, Bridge / Log / Files / Examples / Settings bottom bar; gear icon = Settings).

## Using it
1. Plug in the adapter (OTG cable), choose the mode, tap **CONNECT** (grants USB permission).
2. Tap **START BRIDGE**; clients connect to the shown IP and port. The phone is the TCP server.
3. Mode can only be changed while disconnected. Chip tools (Files tab) need the TCP bridge stopped - both share the one CH341A.

## Building
`Build_TCP_Bridge_Release.ipynb` (Google Colab) builds a **signed release APK**; or locally: set `TCPBRIDGE_KEYSTORE`, `TCPBRIDGE_KEYSTORE_PASSWORD`, `TCPBRIDGE_KEY_ALIAS`, `TCPBRIDGE_KEY_PASSWORD` and run `gradle assembleRelease`. Without a keystore the release APK is unsigned and will not install.

Package id is unchanged (`com.tcpuartbridge.app`). Older UART-only notes: `docs/UART_NOTES.md`. Third-party licences: `NOTICE.md`.
