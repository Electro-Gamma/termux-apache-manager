pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // usb-serial-for-android (com.github.mik3y:...) is published via JitPack, not
        // Maven Central - see app/build.gradle.kts and docs/ARCHITECTURE.md "Why not
        // hand-roll it". Without this, Gradle sync fails to resolve that dependency.
        maven { url = uri("https://jitpack.io") }
    }
}

rootProject.name = "PuTTYdroid"
include(":app")
include(":terminal-core")
