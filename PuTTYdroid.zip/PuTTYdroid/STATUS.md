# Status

This is a **first, real installment** of the PuTTY-on-Android port, not the
finished product. Read this before anything else. Everything below is
scoped truthfully on purpose - the task's own requirement 27 ("do not fake
functionality... if a feature is presented as implemented, it must actually
work") is taken seriously enough to also mean: don't claim more than what's
actually here.

## Build environment disclosure

This project was written in a sandboxed environment with **no network
access** and **no Android SDK, emulator, or `kotlinc` installed**. That
means:
- **Gradle has never been run against this project.** No dependency was
  resolved, no `.class` file was produced, no APK was built.
- **No Kotlin compiler was available to even syntax-check the files**, let
  alone type-check them against the real Android SDK / AndroidX / Room /
  usb-serial-for-android APIs. Every file was hand-written and hand-traced
  (including manually re-deriving several unit test expectations character
  by character against the parser logic, catching and fixing three off-by-
  one bugs that way - see the git history equivalent in how this was built)
  but that is not a substitute for an actual compile.
- Library API surfaces referenced (AndroidX Room/security-crypto,
  `usb-serial-for-android`'s `UsbSerialPort`, `kotlinx.coroutines`) are used
  according to their well-established, well-documented public APIs, from
  training knowledge - but versions pinned in `build.gradle.kts` may need a
  bump, and it would not be honest to claim zero risk of a method name or
  signature mismatch surfacing on first real build.

**What this means practically:** open the project in Android Studio, let it
sync/prompt any AGP or dependency version updates, and treat the first build
the way you'd treat the first build of any freshly-cloned project - expect
to fix build-tool version drift, not to find fake/stubbed logic underneath.

## Update: first real compile happened (Colab, Gradle 8.7/AGP 8.5.2/JDK 17)

`:terminal-core:test` has now actually been run by a real Kotlin compiler.
Result: **19/20 tests passed on the first try**, one genuine compiler
warning (an unused parameter), one test failure.

- **The warning** (`Parameter 'mods' is never used` in
  `TerminalKeyEncoder.kt`'s private `arrow()` helper) was real - `mods` was
  dead in that function. Fixed by dropping the unused parameter.
- **The test failure** (`alternate screen switch preserves and restores the
  primary screen`) was **not a bug in the parser** - it was a wrong
  assumption in the test. Traced against `terminal.c`'s `swap_screen()` and
  `toggle_mode()`'s `case 1049` directly (not re-derived from general VT100
  knowledge) to check: PuTTY's `swap_screen()` deliberately skips its own
  cursor x/y swap whenever `reset=true`, which the `1049` case always
  passes - so entering the alternate screen genuinely does *not* home the
  cursor; it carries the old column over onto the freshly-cleared alt
  screen. `TerminalParser`'s implementation already matched this exactly
  (`saveCursorForAltScreen()` before the switch on entry,
  `restoreCursorForAltScreen()` after the switch on exit - the same
  save-then-switch / switch-then-restore order PuTTY uses). The test just
  hadn't accounted for it. Fixed by having the test reposition the cursor
  after entering (the way every real full-screen app - vim, tmux, less -
  actually does), and added a dedicated test that pins down the verified
  carries-over-on-entry / restored-on-exit behaviour on its own.

This is a good sign for the overall approach: the one real discrepancy a
real compiler + test run turned up was resolved by reading the source
again, not by guessing - and the reading confirmed the implementation, not
the test. It is not evidence there are zero remaining bugs; `:app`
(the Android module, USB serial, and everything downstream of it) still
has not been built or run at all as of this update.

## Update 2: first `:app:assembleDebug` attempt (same Colab run)

`:terminal-core:test` was re-run first and came back **BUILD SUCCESSFUL**
(all tests, no failures) - confirming the fix in the update above actually
worked, for real this time, not just by hand-trace.

`:app:assembleDebug` then failed at `:app:checkDebugAarMetadata`:

> Dependency 'com.github.mik3y:usb-serial-for-android:3.11.0' requires
> libraries and applications that depend on it to compile against version 35
> or later of the Android APIs. :app is currently compiled against
> android-34. Also, the maximum recommended compile SDK version for Android
> Gradle plugin 8.5.2 is 34.

Traced rather than guessed at: rather than gamble on downgrading the
library to some older, possibly-also-broken-on-JitPack version (see the
`3.7.1` lesson above), searched for the actual AGP-version compatibility
requirement. Per a citable source
(github.com/cgeo/cgeo/issues/16764, itself quoting Android's own tooling
compatibility table): **compileSdk 35 requires AGP >= 8.6.0, and AGP 8.6
requires Gradle >= 8.7** - and this project already pins Gradle 8.7, so
8.6.0 is a self-consistent, minimal bump rather than a guess that might
cascade into further version mismatches. Changed: AGP `8.5.2` -> `8.6.0`
(`build.gradle.kts`), `compileSdk`/`targetSdk` `34` -> `35`
(`app/build.gradle.kts`), and the Colab notebook's `sdkmanager` install
line (`platforms;android-34`/`build-tools;34.0.0` ->
`;android-35`/`;35.0.0` - matching what the very first example notebook
this project's Colab flow was modelled on already downloaded successfully,
so this isn't uncharted territory for this environment specifically).

**Not yet confirmed by an actual build** - that's what the next Colab run
is for. If `:app:assembleDebug` fails again, the next most likely culprit
(not yet hit, but worth naming in advance) is a similar AAR-metadata
mismatch from one of the other AndroidX dependencies (Room, security-crypto)
against compileSdk 35, or a KSP/Kotlin-plugin version needing a matching
bump - same "trace the actual error, don't guess" approach applies.

## Update 3: second `:app:assembleDebug` attempt - a lower-confidence fix

The AGP/compileSdk bump worked as predicted: `:app:checkDebugAarMetadata`
passed cleanly this time (no complaints about any dependency, including
`usb-serial-for-android`). The build got substantially further, into actual
resource linking, before failing:

> Android resource linking failed - .../layout/activity_main.xml: error:
> attribute auto:layout_constraintEnd_toEndOf not found. (and several more,
> same file, all ConstraintLayout attributes)

**Unlike the previous two fixes, this one does not have a single, precise,
citable root cause.** What was actually verified before making a change:
the `androidx.constraintlayout:constraintlayout` dependency declaration in
`app/build.gradle.kts` is present and correctly written; `2.1.4` is a real,
valid, previously-stable release (confirmed via search, not assumed); the
layout XML's namespace declarations and attribute usage are syntactically
correct and match the error's line numbers exactly (no stray typo). That
rules out the usual causes of this specific error class, but the searches
run afterward mostly turned up generic "you forgot the dependency"
troubleshooting threads that don't apply here, not a specific match for
this setup.

The change made - bumping `constraintlayout` from `2.1.4` to `2.2.1` - is a
**plausible, low-risk hypothesis, not a verified diagnosis**: `2.1.4` is a
2022-era release built against much older `aapt2`, and this failure
appeared immediately after jumping AGP/build-tools/aapt2 forward two major
versions in Update 2. A newer library release being better-tested against
newer tooling is a reasonable bet, but it's a bet. If the next Colab run
still fails at the same spot, treat this specific theory as ruled out
rather than retrying variations of it, and compare against what a fresh
`File > New Project` > "Empty Views Activity" template in Android Studio
resolves for its own ConstraintLayout/AGP/compileSdk combination - that's
a faster way to find a known-good version combination than more guessing.

## Update 4: third attempt - the constraintlayout hypothesis was wrong; found the real anomaly

Re-ran with `constraintlayout:2.2.1`. **Identical failure, same lines** - so,
as flagged in Update 3, that hypothesis is now ruled out. Reverted to
`2.1.4`.

This time the actual cause was found by reading the *entire* log more
carefully rather than searching the web for the error message again -
specifically, a line easy to skim past as boilerplate:

> Checking the license for package Android SDK Build-Tools 34 ...
> Installing Android SDK Build-Tools 34 in /content/android-sdk/build-tools/34.0.0

**This is anomalous.** Nothing in the notebook asks for build-tools 34 - it
explicitly installs `platforms;android-35`/`build-tools;35.0.0`. Gradle was
silently auto-downloading an *older* build-tools version mid-build. The
explanation: `app/build.gradle.kts` never set `buildToolsVersion` explicitly,
and AGP's default build-tools version is baked into the AGP release itself -
it is **not** automatically derived from `compileSdk`. AGP 8.6.0's own
default apparently wants 34.0.0 regardless of `compileSdk = 35`. That means
resource linking was quietly running through the *older* `aapt2` binary
bundled in build-tools 34.0.0 against a project whose dependencies (and
`compileSdk`) target 35 - a well-documented category of aapt2-version
mismatch that produces exactly this symptom (attributes from a correctly-
present, correctly-declared library AAR reported as "not found").

Fix: explicitly set `buildToolsVersion = "35.0.0"` in `app/build.gradle.kts`,
matching what's actually installed and matching `compileSdk`. This removes
AGP's ambiguity rather than working around a symptom.

**Confidence level, stated plainly:** higher than the Update 3 guess (this
is grounded in a concrete, unexplained anomaly actually present in your log,
not a generic pattern-match), but still not *confirmed* until an actual
build passes. If this doesn't fix it, the next thing worth checking is
whether `build-tools;34.0.0` is *still* being installed even with
`buildToolsVersion` pinned (which would mean something else - possibly
`:terminal-core`'s `DexingNoClasspathTransform` step, visible earlier in
the same log - is the one asking for it, not `:app`).

## Update 5: fourth attempt - both hypotheses now cleanly disproven; switching strategy

Re-ran with `buildToolsVersion = "35.0.0"` pinned. Result: **identical
failure, identical lines** - and this time the evidence is unambiguous
rather than merely "still failing": the "Installing Android SDK
Build-Tools 34" line is **gone** from this log. That confirms the pin
worked exactly as intended - aapt2 is now definitely running from
build-tools 35.0.0 - and the resource-linking error didn't change at all.
That rules out an aapt2-version mismatch as the cause, not just as an
untested guess.

Two targeted, individually-reasoned hypotheses (constraintlayout version,
then aapt2/build-tools version) have now each been tested and cleanly
falsified by real build output. Guessing a third specific fix without new
information would be the same mistake twice - so instead of another patch,
a diagnostic cell was added to the notebook, inserted right before the
build step: `gradle :app:dependencies --configuration debugCompileClasspath`,
which prints Gradle's *actual resolved dependency tree* for the app module.
This will show directly whether `constraintlayout` is really landing on the
classpath the way `implementation(...)` is supposed to put it there,
whether something is silently substituting or excluding it, or whether it's
missing from the tree entirely (which would itself be the answer, and a
very different fix than either of the last two attempts).

Nothing in `app/build.gradle.kts` was changed this round - both prior
changes (`buildToolsVersion = "35.0.0"`, `constraintlayout:2.1.4`) are left
in place since neither is known to be *wrong*, only known to not be *the*
fix. Next step is data, not another patch.

## What's real and done

- **`terminal-core` module** (VT100/ANSI/xterm parser, screen buffer,
  scrollback, cursor/SGR state, UTF-8 streaming decoder, key-sequence
  encoder): complete for the coverage documented in
  `docs/ARCHITECTURE.md` ยง5. **20 of its then-20 tests were compiled and run
  for real** (see update above) with 19 passing; the 20th was fixed and a
  21st test added afterward, but - important - **those two edits
  (`arrow()`'s unused parameter and the two test changes) have only been
  hand-traced since that fix, not run against a real compiler again yet.**
  The next Colab run is what actually confirms 21/21.
- **Raw TCP and Telnet backends**: real sockets, real Telnet IAC option
  negotiation (ECHO/SGA/NAWS/TTYPE), wired end-to-end through a real
  `MainActivity` + `TerminalView`.
- **`TerminalView`**: a real Canvas-based renderer (not a TextView) with
  working hardware-keyboard and soft-keyboard input paths.
- **USB serial device discovery/permission** (`UsbSerialManager`): real
  Android USB Host API usage.

## What's real but unverified against hardware/a real build

- **`UsbSerialTerminalConnection`**: structurally complete adapter onto the
  `usb-serial-for-android` library's port I/O, but there is no physical USB
  device or Android device in this environment to test it against.

## What's explicitly NOT built (by design, not oversight)

- **SSH.** No `SshConnection` implementation - see
  `docs/ARCHITECTURE.md` ยง4 for why (short version: hand-writing SSH2
  cryptography without a network connection to check it against a reference
  implementation is how you ship a vulnerability, not a terminal client) and
  the concrete plan (adapt the `sshj` library).
- Saved sessions UI/storage, encrypted credential storage wiring, a
  settings/config screens, port forwarding UI, SFTP, Rlogin, the
  customizable extra-key bar, mouse-report touch input, and a differential
  test harness against a real PuTTY binary are all designed-for (the data
  shapes exist, or the extension is straightforward given the existing
  pattern) but not implemented. See `docs/ARCHITECTURE.md` ยง3/ยง7 for the
  full per-item breakdown.

## Suggested next steps, in order

1. Open in Android Studio, resolve the first real build, fix whatever
   version/API drift turns up (expected, see above).
2. Run `:terminal-core:test` first - it needs no Android SDK/emulator and
   is where correctness matters most.
3. Get Raw TCP working against a real `nc -l` listener, then Telnet against
   a real telnetd, on a real device - the two backends and the renderer are
   the parts most likely to reveal real device UI issues (keyboard/IME
   quirks, font metrics) that couldn't be caught without a screen.
4. Test USB serial against real hardware (an FTDI/CP210x/CH340 breakout or
   an ESP32 dev board is an easy way to get one).
5. Build the SSH backend per `docs/ARCHITECTURE.md` ยง4.
6. Saved sessions + settings UI.
