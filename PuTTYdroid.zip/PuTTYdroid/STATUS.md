# Status

This is a **first, real installment** of the PuTTY-on-Android port, not the
finished product. Read this before anything else. Everything below is
scoped truthfully on purpose - the task's own requirement 27 ("do not fake
functionality... if a feature is presented as implemented, it must actually
work") is taken seriously enough to also mean: don't claim more than what's
actually here.

## Build environment disclosure

This project was written in a sandboxed environment with **no network
access** and **no Android SDK, emulator, or `kotlinc` installed**. That
means:
- **Gradle has never been run against this project.** No dependency was
  resolved, no `.class` file was produced, no APK was built.
- **No Kotlin compiler was available to even syntax-check the files**, let
  alone type-check them against the real Android SDK / AndroidX / Room /
  usb-serial-for-android APIs. Every file was hand-written and hand-traced
  (including manually re-deriving several unit test expectations character
  by character against the parser logic, catching and fixing three off-by-
  one bugs that way - see the git history equivalent in how this was built)
  but that is not a substitute for an actual compile.
- Library API surfaces referenced (AndroidX Room/security-crypto,
  `usb-serial-for-android`'s `UsbSerialPort`, `kotlinx.coroutines`) are used
  according to their well-established, well-documented public APIs, from
  training knowledge - but versions pinned in `build.gradle.kts` may need a
  bump, and it would not be honest to claim zero risk of a method name or
  signature mismatch surfacing on first real build.

**What this means practically:** open the project in Android Studio, let it
sync/prompt any AGP or dependency version updates, and treat the first build
the way you'd treat the first build of any freshly-cloned project - expect
to fix build-tool version drift, not to find fake/stubbed logic underneath.

## What's real and done

- **`terminal-core` module** (VT100/ANSI/xterm parser, screen buffer,
  scrollback, cursor/SGR state, UTF-8 streaming decoder, key-sequence
  encoder): complete for the coverage documented in
  `docs/ARCHITECTURE.md` ยง5, with 19 JUnit test cases whose expected values
  were hand-traced against the implementation logic (not just written
  hopefully and left unchecked).
- **Raw TCP and Telnet backends**: real sockets, real Telnet IAC option
  negotiation (ECHO/SGA/NAWS/TTYPE), wired end-to-end through a real
  `MainActivity` + `TerminalView`.
- **`TerminalView`**: a real Canvas-based renderer (not a TextView) with
  working hardware-keyboard and soft-keyboard input paths.
- **USB serial device discovery/permission** (`UsbSerialManager`): real
  Android USB Host API usage.

## What's real but unverified against hardware/a real build

- **`UsbSerialTerminalConnection`**: structurally complete adapter onto the
  `usb-serial-for-android` library's port I/O, but there is no physical USB
  device or Android device in this environment to test it against.

## What's explicitly NOT built (by design, not oversight)

- **SSH.** No `SshConnection` implementation - see
  `docs/ARCHITECTURE.md` ยง4 for why (short version: hand-writing SSH2
  cryptography without a network connection to check it against a reference
  implementation is how you ship a vulnerability, not a terminal client) and
  the concrete plan (adapt the `sshj` library).
- Saved sessions UI/storage, encrypted credential storage wiring, a
  settings/config screens, port forwarding UI, SFTP, Rlogin, the
  customizable extra-key bar, mouse-report touch input, and a differential
  test harness against a real PuTTY binary are all designed-for (the data
  shapes exist, or the extension is straightforward given the existing
  pattern) but not implemented. See `docs/ARCHITECTURE.md` ยง3/ยง7 for the
  full per-item breakdown.

## Suggested next steps, in order

1. Open in Android Studio, resolve the first real build, fix whatever
   version/API drift turns up (expected, see above).
2. Run `:terminal-core:test` first - it needs no Android SDK/emulator and
   is where correctness matters most.
3. Get Raw TCP working against a real `nc -l` listener, then Telnet against
   a real telnetd, on a real device - the two backends and the renderer are
   the parts most likely to reveal real device UI issues (keyboard/IME
   quirks, font metrics) that couldn't be caught without a screen.
4. Test USB serial against real hardware (an FTDI/CP210x/CH340 breakout or
   an ESP32 dev board is an easy way to get one).
5. Build the SSH backend per `docs/ARCHITECTURE.md` ยง4.
6. Saved sessions + settings UI.
