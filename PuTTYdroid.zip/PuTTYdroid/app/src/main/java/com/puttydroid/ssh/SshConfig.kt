package com.puttydroid.ssh

/**
 * SSH session configuration schema.
 *
 * IMPORTANT - read before wiring this up to UI: this file defines the
 * *configuration shape* only. There is deliberately no `SshConnection`
 * class implementing `TerminalConnection` in this delivery - see
 * docs/ARCHITECTURE.md, section "SSH backend: status and plan", for why:
 * in short, correct SSH2 cryptography is not something to hand-write and
 * ship untested (no network access was available in this build environment
 * to pull in, build against, or test a crypto/SSH library at all), and a
 * connect()/write() implementation that merely *compiles* without a real,
 * verified crypto stack behind it would be exactly the kind of fake
 * functionality this project explicitly must not produce. This schema is
 * shaped so that a real implementation (planned: adapt the `sshj` library,
 * see ARCHITECTURE.md) can be dropped in behind it without changing the
 * session/config storage layer above it.
 *
 * PuTTY source reference: the CONF_ssh* fields in putty.h / config.c's SSH
 * config panel (`ssh_command`, `CONF_sshprot`, `CONF_compression`,
 * `CONF_ssh_kex_*` ordering lists, `CONF_ssh_cipherlist`, `CONF_sshbug_*`,
 * port-forwarding list `CONF_portfwd`).
 */

sealed class SshAuthMethod {
    data class Password(val username: String, val password: String) : SshAuthMethod()
    data class KeyboardInteractive(val username: String) : SshAuthMethod()
    data class PublicKey(val username: String, val privateKeyPem: String, val passphrase: String?) : SshAuthMethod()
}

enum class PortForwardType { LOCAL, REMOTE, DYNAMIC }

data class PortForward(
    val type: PortForwardType,
    val listenAddress: String,
    val listenPort: Int,
    /** Destination host:port - unused (null) for DYNAMIC (SOCKS) forwards. */
    val destinationHost: String? = null,
    val destinationPort: Int? = null
)

data class SshConfig(
    val auth: SshAuthMethod,
    val compression: Boolean = false,
    val keepaliveIntervalSeconds: Int = 0,
    val portForwards: List<PortForward> = emptyList(),
    /** Accept-and-remember-on-first-use vs. strict known_hosts checking. PuTTY: the
     *  host-key confirmation dialog backed by `store_host_key()` in storage handling. */
    val hostKeyPolicy: HostKeyPolicy = HostKeyPolicy.PromptOnFirstUse
)

sealed class HostKeyPolicy {
    object PromptOnFirstUse : HostKeyPolicy()
    object StrictKnownHostsOnly : HostKeyPolicy()
}
