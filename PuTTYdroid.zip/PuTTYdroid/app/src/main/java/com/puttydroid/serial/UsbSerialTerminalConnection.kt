package com.puttydroid.serial

import android.hardware.usb.UsbDeviceConnection
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.io.SerialInputOutputManager
import com.puttydroid.connection.ConnectionState
import com.puttydroid.connection.TerminalConnection
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.Executors

/**
 * Real serial backend: wraps one `UsbSerialPort` (from the already-permissioned,
 * already-opened `UsbDeviceConnection` handed to it by the caller - see
 * UsbSerialManager) and adapts it to the shared TerminalConnection interface,
 * so the rest of the app (terminal emulator, UI) never needs to know a session
 * is running over USB rather than a socket (requirement 15).
 *
 * PuTTY source reference: this class is the Android equivalent of the parts of
 * PuTTY's Windows serial backend (`windows/winser.c`, not present in the
 * cross-platform source tree bundled for this task) that open a COM port and
 * push bytes in both directions - conceptually the same role, necessarily a
 * from-scratch Android implementation since PuTTY's own serial backend talks
 * to Win32 `CreateFile("\\\\.\\COMn")`/POSIX `/dev/ttyUSB0`, neither of which
 * exists on Android (requirement 14 explicitly calls this out).
 *
 * Uses `SerialInputOutputManager` from `com.github.mik3y:usb-serial-for-android`
 * for the read loop, which is that library's documented pattern for
 * continuous async I/O on a dedicated thread (rather than busy-polling
 * `port.read()` ourselves).
 */
class UsbSerialTerminalConnection(
    private val port: UsbSerialPort,
    private val connection: UsbDeviceConnection,
    private var config: SerialConfig
) : TerminalConnection {

    override var onData: ((ByteArray, Int) -> Unit)? = null
    override var onStateChange: ((ConnectionState) -> Unit)? = null

    override var state: ConnectionState = ConnectionState.Idle
        private set(value) { field = value; onStateChange?.invoke(value) }

    private var ioManager: SerialInputOutputManager? = null
    private val ioExecutor = Executors.newSingleThreadExecutor()

    override suspend fun connect() {
        state = ConnectionState.Connecting
        try {
            withContext(Dispatchers.IO) {
                port.open(connection)
                applyParameters()
                applyFlowControlLines()
            }
            val listener = object : SerialInputOutputManager.Listener {
                override fun onNewData(data: ByteArray) {
                    if (data.isNotEmpty()) onData?.invoke(data, data.size)
                }
                override fun onRunError(e: Exception) {
                    state = ConnectionState.Error("Serial I/O error: ${e.message}", e)
                }
            }
            val manager = SerialInputOutputManager(port, listener)
            ioManager = manager
            ioExecutor.submit(manager)
            state = ConnectionState.Connected
        } catch (e: Exception) {
            state = ConnectionState.Error("Failed to open serial device", e)
            throw e
        }
    }

    private fun applyParameters() {
        val stopBits = when (config.stopBits) {
            SerialStopBits.ONE -> UsbSerialPort.STOPBITS_1
            SerialStopBits.ONE_POINT_FIVE -> UsbSerialPort.STOPBITS_1_5
            SerialStopBits.TWO -> UsbSerialPort.STOPBITS_2
        }
        val parity = when (config.parity) {
            SerialParity.NONE -> UsbSerialPort.PARITY_NONE
            SerialParity.ODD -> UsbSerialPort.PARITY_ODD
            SerialParity.EVEN -> UsbSerialPort.PARITY_EVEN
            SerialParity.MARK -> UsbSerialPort.PARITY_MARK
            SerialParity.SPACE -> UsbSerialPort.PARITY_SPACE
        }
        port.setParameters(config.baudRate, config.dataBits, stopBits, parity)
    }

    private fun applyFlowControlLines() {
        // Not every USB-serial chipset/driver combination supports every control line -
        // some throw UnsupportedOperationException, which we treat as "no hardware flow
        // control available on this adapter" rather than a fatal connect error.
        try {
            when (config.flowControl) {
                SerialFlowControl.RTS_CTS -> { port.rts = true }
                SerialFlowControl.DSR_DTR -> { port.dtr = true }
                else -> {}
            }
        } catch (_: UnsupportedOperationException) {
        }
    }

    /** Re-applies baud/data/stop/parity without closing the port - used when the user
     *  changes serial settings mid-session (requirement 11: serial configuration). */
    suspend fun reconfigure(newConfig: SerialConfig) {
        config = newConfig
        withContext(Dispatchers.IO) { applyParameters() }
    }

    override suspend fun write(data: ByteArray) {
        withContext(Dispatchers.IO) { port.write(data, WRITE_TIMEOUT_MS) }
    }

    /** No-op: a serial line has no protocol-level notion of "terminal size" the way NAWS
     *  does over Telnet - whatever's on the other end (an ESP32, a router console, a Linux
     *  getty) either doesn't care or is told out-of-band. Real, intentional no-op, not a
     *  missing feature - matches how PuTTY's own serial backend has no `size` callback. */
    override suspend fun resize(columns: Int, rows: Int) {}

    override suspend fun disconnect() {
        try {
            ioManager?.stop()
            withContext(Dispatchers.IO) { port.close() }
        } finally {
            state = ConnectionState.Closed("Disconnected by user")
        }
    }

    companion object {
        private const val WRITE_TIMEOUT_MS = 2000
    }
}
