package com.puttydroid.ui

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.puttydroid.R
import com.puttydroid.connection.ConnectionState
import com.puttydroid.connection.HostTarget
import com.puttydroid.connection.RawTcpConnection
import com.puttydroid.connection.TelnetConnection
import com.puttydroid.connection.TerminalConnection
import com.puttydroid.databinding.ActivityMainBinding
import com.puttydroid.terminal.TerminalEmulator
import kotlinx.coroutines.launch

/**
 * End-to-end wiring for the two backends that are fully implemented in this
 * delivery (Raw TCP and Telnet - see docs/ARCHITECTURE.md for SSH/Serial
 * status). This activity is intentionally simple: it is the "does the whole
 * pipeline actually work" proof, not the final session-management UI
 * (saved sessions, protocol-specific config panels, etc. are the next
 * phase - requirement 12).
 *
 * Wiring, matching the architecture's layered design (requirement 8):
 *   connectionBar (host/port/protocol) --builds--> TerminalConnection
 *   TerminalConnection.onData          --feeds-->   TerminalEmulator.feed()
 *   TerminalEmulator.onResponse        --writes-->  TerminalConnection.write()  (DSR/CPR replies)
 *   TerminalView.onKeyBytes            --writes-->  TerminalConnection.write()  (keyboard)
 *   TerminalView.onGridSizeChanged     --calls-->    TerminalConnection.resize()
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var connection: TerminalConnection? = null
    private val emulator = TerminalEmulator(columns = 80, rows = 24)

    private val protocols = listOf("Raw", "Telnet")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.protocolSpinner.adapter =
            ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, protocols)

        binding.terminalView.emulator = emulator
        wireEmulatorCallbacks()

        binding.terminalView.onKeyBytes = { bytes ->
            val c = connection
            if (c != null) lifecycleScope.launch {
                runCatching { c.write(bytes) }
            }
        }
        binding.terminalView.onGridSizeChanged = { cols, rows ->
            val c = connection
            if (c != null) lifecycleScope.launch { runCatching { c.resize(cols, rows) } }
        }

        binding.connectButton.setOnClickListener { onConnectClicked() }
    }

    private fun wireEmulatorCallbacks() {
        emulator.onResponse = { bytes ->
            val c = connection
            if (c != null) lifecycleScope.launch { runCatching { c.write(bytes) } }
        }
        emulator.onTitleChange = { title -> runOnUiThread { setTitle(title) } }
        // Bell: a simple, unintrusive default. Swap for a Vibrator/SoundPool call once
        // there's a settings screen to make it user-configurable (requirement 21/24).
        emulator.onBell = {}
    }

    private fun onConnectClicked() {
        if (connection != null) {
            lifecycleScope.launch { connection?.disconnect(); connection = null }
            return
        }
        val host = binding.hostInput.text?.toString()?.trim().orEmpty()
        val port = binding.portInput.text?.toString()?.trim()?.toIntOrNull()
        if (host.isEmpty() || port == null) {
            Toast.makeText(this, "Enter a host and port", Toast.LENGTH_SHORT).show()
            return
        }
        val target = HostTarget(host, port)
        val newConnection: TerminalConnection = when (protocols[binding.protocolSpinner.selectedItemPosition]) {
            "Telnet" -> TelnetConnection(target)
            else -> RawTcpConnection(target)
        }
        connection = newConnection
        newConnection.onData = { bytes, len ->
            runOnUiThread {
                emulator.feed(bytes, len)
                binding.terminalView.invalidate()
            }
        }
        newConnection.onStateChange = { state -> runOnUiThread { onConnectionStateChanged(state) } }

        lifecycleScope.launch {
            runCatching { newConnection.connect() }
                .onSuccess { newConnection.resize(emulator.columns, emulator.rows) }
                .onFailure { e ->
                    Toast.makeText(this@MainActivity, "Connect failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
        }
    }

    private fun onConnectionStateChanged(state: ConnectionState) {
        binding.statusText.text = when (state) {
            is ConnectionState.Idle -> getString(R.string.status_idle)
            is ConnectionState.Connecting -> "Connecting…"
            is ConnectionState.Connected -> "Connected"
            is ConnectionState.Closed -> {
                connection = null
                state.reason ?: "Closed"
            }
            is ConnectionState.Error -> {
                connection = null
                "Error: ${state.message}"
            }
        }
        binding.connectButton.text = if (connection != null)
            getString(R.string.action_disconnect)
        else
            getString(R.string.action_connect)
    }

    override fun onDestroy() {
        super.onDestroy()
        lifecycleScope.launch { runCatching { connection?.disconnect() } }
    }
}
