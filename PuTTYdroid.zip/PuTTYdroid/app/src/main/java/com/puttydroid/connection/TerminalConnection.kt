package com.puttydroid.connection

/**
 * Common interface for every transport the terminal can run over.
 *
 * PuTTY source reference: `struct BackendVtable` in putty.h (init/free/send/
 * size/special/connected/... - see the analysis in docs/ARCHITECTURE.md).
 * The terminal emulator (com.puttydroid.terminal.TerminalEmulator) never
 * references this interface or any implementation directly - the Kotlin
 * equivalent of requirement 15 ("the terminal emulator should not need to
 * know which protocol is being used"). Something above both layers (the
 * session/activity) wires `connection.onData -> terminal.feed` and
 * `terminal.onResponse -> connection.write` together.
 */
interface TerminalConnection {
    /** Called on the connection's own coroutine with each chunk of incoming data.
     *  Implementations must never call this on the main thread (requirement 16). */
    var onData: ((ByteArray, Int) -> Unit)?

    /** Called when the connection state changes (connecting/connected/closed/error). */
    var onStateChange: ((ConnectionState) -> Unit)?

    val state: ConnectionState

    suspend fun connect()
    suspend fun write(data: ByteArray)
    suspend fun resize(columns: Int, rows: Int)
    suspend fun disconnect()
}

sealed class ConnectionState {
    object Idle : ConnectionState()
    object Connecting : ConnectionState()
    object Connected : ConnectionState()
    data class Closed(val reason: String?) : ConnectionState()
    data class Error(val message: String, val cause: Throwable? = null) : ConnectionState()
}

/** Session parameters common to the socket-based backends (Raw/Telnet/Rlogin/SSH). */
data class HostTarget(val host: String, val port: Int, val connectTimeoutMs: Int = 10_000)
