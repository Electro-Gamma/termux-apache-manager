package com.puttydroid.serial

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import com.hoho.android.usbserial.driver.UsbSerialDriver
import com.hoho.android.usbserial.driver.UsbSerialProber
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.callbackFlow

/**
 * Discovers attached USB-serial adapters and handles the Android runtime USB
 * permission dance, using the real `android.hardware.usb` Host API (requirement
 * 14: "The application must communicate directly with Android USB devices
 * using the Android USB Host APIs").
 *
 * Device *identification* (recognising CP210x/FTDI/CH340/CDC-ACM chips from
 * vendor/product IDs) is delegated to `UsbSerialProber` from the
 * `com.github.mik3y:usb-serial-for-android` library (declared in
 * app/build.gradle.kts) rather than hand-implementing each vendor's USB
 * descriptor table here. That library is the de-facto standard,
 * actively-maintained implementation of exactly this problem on Android;
 * reimplementing FTDI/CP210x/CH340 vendor protocols from scratch inside this
 * project would mean shipping untested low-level USB framing code with no
 * hardware in this environment to validate it against, which is a worse
 * outcome for correctness than depending on a widely-used library the same
 * way the SSH backend depends on a vetted crypto library (see
 * docs/ARCHITECTURE.md "Why not hand-roll it").
 */
class UsbSerialManager(private val context: Context) {

    private val usbManager: UsbManager
        get() = context.getSystemService(Context.USB_SERVICE) as UsbManager

    private val actionUsbPermission = "${context.packageName}.USB_PERMISSION"

    /** All USB-serial-capable devices currently attached, as recognised by the prober's
     *  built-in vendor/product ID tables (FTDI, CP210x, CH34x, PL2303, CDC-ACM). */
    fun listAvailableDrivers(): List<UsbSerialDriver> =
        UsbSerialProber.getDefaultProber().findAllDrivers(usbManager)

    /** Request permission for a specific device, suspending (as a Flow of one element) until
     *  the user responds to the Android system permission dialog or it's already granted. */
    fun requestPermission(device: UsbDevice) = callbackFlow {
        if (usbManager.hasPermission(device)) {
            trySend(true)
            close()
            return@callbackFlow
        }
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context, intent: Intent) {
                if (intent.action != actionUsbPermission) return
                val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
                trySend(granted)
                close()
            }
        }
        val filter = IntentFilter(actionUsbPermission)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            context.registerReceiver(receiver, filter)
        }

        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
            PendingIntent.FLAG_MUTABLE else 0
        val permissionIntent = PendingIntent.getBroadcast(
            context, 0, Intent(actionUsbPermission), flags
        )
        usbManager.requestPermission(device, permissionIntent)

        awaitClose { context.unregisterReceiver(receiver) }
    }

    fun hasPermission(device: UsbDevice): Boolean = usbManager.hasPermission(device)

    fun openConnection(device: UsbDevice) = usbManager.openDevice(device)
}
