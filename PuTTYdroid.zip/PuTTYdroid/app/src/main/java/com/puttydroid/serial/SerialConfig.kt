package com.puttydroid.serial

/** PuTTY source reference: sercfg.c / putty.h `CONF_serline`, `CONF_serspeed`,
 *  `CONF_serdatabits`, `CONF_serstopbits`, `CONF_serparity`, `CONF_serflow`. */
enum class SerialParity { NONE, ODD, EVEN, MARK, SPACE }
enum class SerialStopBits { ONE, ONE_POINT_FIVE, TWO }
enum class SerialFlowControl { NONE, XON_XOFF, RTS_CTS, DSR_DTR }

data class SerialConfig(
    val baudRate: Int = 9600,
    val dataBits: Int = 8,
    val stopBits: SerialStopBits = SerialStopBits.ONE,
    val parity: SerialParity = SerialParity.NONE,
    val flowControl: SerialFlowControl = SerialFlowControl.NONE
)
