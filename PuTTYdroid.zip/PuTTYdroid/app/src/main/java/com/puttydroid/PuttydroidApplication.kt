package com.puttydroid

import android.app.Application

/**
 * Application entry point. Currently just a named class for the manifest to
 * point at; this is where app-wide singletons (the saved-sessions
 * repository, an encrypted credential store, a shared USB manager instance)
 * belong once storage/serial UI lands - see docs/ARCHITECTURE.md, "Next
 * steps".
 */
class PuttydroidApplication : Application()
