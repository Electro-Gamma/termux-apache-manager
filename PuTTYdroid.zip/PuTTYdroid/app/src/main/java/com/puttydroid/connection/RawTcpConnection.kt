package com.puttydroid.connection

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelChildren
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Socket

/**
 * Raw TCP backend: opens a socket and passes bytes through unmodified in
 * both directions - no protocol negotiation of any kind.
 *
 * PuTTY source reference: raw.c. `raw_init()` just opens the socket
 * (`new_connection()`); `raw_send()` writes the buffer straight through;
 * `raw_size()` is an empty no-op (raw connections carry no notion of
 * terminal size - there's no side channel to send it over), which is why
 * `resize()` below does nothing but is still a real, intentional
 * implementation of the interface contract, not a missing feature.
 *
 * This class owns its own coroutine scope (Dispatchers.IO), started in
 * connect() and cancelled in disconnect(), so a caller that forgets to
 * cancel anything itself still can't leak the read loop (requirement 16:
 * "handle cancellation and disconnection correctly").
 */
class RawTcpConnection(private val target: HostTarget) : TerminalConnection {

    override var onData: ((ByteArray, Int) -> Unit)? = null
    override var onStateChange: ((ConnectionState) -> Unit)? = null

    override var state: ConnectionState = ConnectionState.Idle
        private set(value) { field = value; onStateChange?.invoke(value) }

    private var socket: Socket? = null
    private val job = SupervisorJob()
    private val scope = CoroutineScope(Dispatchers.IO + job)

    override suspend fun connect() {
        state = ConnectionState.Connecting
        try {
            withContext(Dispatchers.IO) {
                val s = Socket()
                s.tcpNoDelay = true
                s.connect(InetSocketAddress(target.host, target.port), target.connectTimeoutMs)
                socket = s
            }
            state = ConnectionState.Connected
            startReadLoop()
        } catch (e: IOException) {
            state = ConnectionState.Error("Failed to connect to ${target.host}:${target.port}", e)
            throw e
        }
    }

    private fun startReadLoop() {
        val s = socket ?: return
        scope.launch {
            val buf = ByteArray(8192)
            try {
                val input = s.getInputStream()
                while (isActive) {
                    val n = input.read(buf)
                    if (n < 0) break // remote closed the connection
                    if (n > 0) onData?.invoke(buf, n)
                }
                if (isActive) state = ConnectionState.Closed("Connection closed by remote host")
            } catch (e: IOException) {
                if (isActive) state = ConnectionState.Error("Connection lost: ${e.message}", e)
            }
        }
    }

    override suspend fun write(data: ByteArray) {
        val s = socket ?: throw IllegalStateException("write() called before connect()")
        withContext(Dispatchers.IO) {
            s.getOutputStream().write(data)
            s.getOutputStream().flush()
        }
    }

    /** No-op: raw TCP has no side channel to communicate terminal size (see class doc). */
    override suspend fun resize(columns: Int, rows: Int) {}

    override suspend fun disconnect() {
        job.cancelChildren()
        withContext(Dispatchers.IO) {
            try { socket?.close() } catch (_: IOException) {}
        }
        socket = null
        state = ConnectionState.Closed("Disconnected by user")
    }
}
