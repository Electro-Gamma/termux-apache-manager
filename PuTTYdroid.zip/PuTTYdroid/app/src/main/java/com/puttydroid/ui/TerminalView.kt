package com.puttydroid.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.BaseInputConnection
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import com.puttydroid.terminal.CursorStyle
import com.puttydroid.terminal.KeyModifiers
import com.puttydroid.terminal.TerminalCell
import com.puttydroid.terminal.TerminalColor
import com.puttydroid.terminal.TerminalEmulator
import com.puttydroid.terminal.TerminalKey
import com.puttydroid.terminal.TerminalKeyEncoder

/**
 * Dedicated terminal grid renderer (requirement 10: "Do not use a normal
 * TextView as the main terminal renderer... Prefer a custom View, Canvas
 * renderer").
 *
 * Design notes:
 *  - Paints the character grid directly with `Canvas.drawText` per cell run,
 *    not one Android View/TextView per character or per line - this is the
 *    "efficient terminal buffer + renderer architecture" requirement 7 asks
 *    for, as opposed to "one Android UI update per byte" (requirement 20).
 *  - `invalidate()` is called once per incoming data chunk (batched by the
 *    session/coroutine layer - see requirement 20 "avoid excessive
 *    allocations" / "avoid recreating the entire terminal screen
 *    unnecessarily"), not once per byte; a full-grid repaint on a modern
 *    Android GPU-composited Canvas at a few thousand cells is materially
 *    cheaper than the per-character TextView approach requirement 7
 *    explicitly rules out, so a straightforward "repaint what's currently
 *    visible" strategy is used rather than PuTTY's own fine-grained
 *    dirty-rectangle tracking (`term->disptext` in terminal.c) - tracked as
 *    a documented, deliberately deferred optimisation in ARCHITECTURE.md,
 *    not a correctness gap.
 *  - Font metrics are measured once per typeface/size change and cached,
 *    not on every `onDraw`.
 */
class TerminalView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    var emulator: TerminalEmulator? = null
        set(value) {
            field = value
            recomputeGridSize()
            invalidate()
        }

    var fontSizeSp: Float = 14f
        set(value) { field = value; remeasureFont(); recomputeGridSize(); invalidate() }

    var palette: IntArray = TerminalColor.buildFullPalette()
    var defaultForeground: Int = TerminalColor.DEFAULT_FOREGROUND or 0xFF000000.toInt()
    var defaultBackground: Int = TerminalColor.DEFAULT_BACKGROUND or 0xFF000000.toInt()

    /** Called once the pixel size determines a new column/row count the connection layer
     *  should be told about (PTY resize / NAWS / just internal reflow bookkeeping). */
    var onGridSizeChanged: ((columns: Int, rows: Int) -> Unit)? = null

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
        typeface = Typeface.MONOSPACE
        textSize = spToPx(fontSizeSp)
    }
    private val bgPaint = Paint()
    private val cursorPaint = Paint().apply { style = Paint.Style.STROKE; strokeWidth = 2f }

    private var cellWidth = 1f
    private var cellHeight = 1f
    private var baselineOffset = 0f

    /** Every byte this view wants sent to the connection - both plain typed characters
     *  (via the soft keyboard's InputConnection) and encoded special keys (via hardware
     *  key events), see requirement 9. The session layer wires this to connection.write(). */
    var onKeyBytes: ((ByteArray) -> Unit)? = null

    init {
        remeasureFont()
        // Custom Views that paint directly in onDraw() without a background drawable can
        // have onDraw() skipped by the framework's "will not draw" optimisation unless this
        // is explicitly disabled - a classic footgun for exactly this kind of View.
        setWillNotDraw(false)
        isFocusable = true
        isFocusableInTouchMode = true
        setOnClickListener { requestFocus(); showSoftKeyboard() }
    }

    private fun showSoftKeyboard() {
        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as? android.view.inputmethod.InputMethodManager
        imm?.showSoftInput(this, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
    }

    // --- Soft keyboard input: a minimal BaseInputConnection that forwards committed text
    //     straight to the terminal instead of maintaining an Android text-editing buffer
    //     (there is no "text field" here - every character is a byte on the wire). ---
    override fun onCheckIsTextEditor(): Boolean = true

    override fun onCreateInputConnection(outAttrs: EditorInfo): InputConnection {
        outAttrs.inputType = EditorInfo.TYPE_NULL
        outAttrs.imeOptions = EditorInfo.IME_FLAG_NO_EXTRACT_UI or EditorInfo.IME_FLAG_NO_FULLSCREEN
        return object : BaseInputConnection(this, false) {
            override fun commitText(text: CharSequence, newCursorPosition: Int): Boolean {
                val mods = KeyModifiers()
                for (c in text) onKeyBytes?.invoke(TerminalKeyEncoder.encodeChar(c, mods))
                return true
            }
            override fun deleteSurroundingText(beforeLength: Int, afterLength: Int): Boolean {
                repeat(beforeLength) {
                    emulator?.let { onKeyBytes?.invoke(TerminalKeyEncoder.encode(TerminalKey.BACKSPACE, KeyModifiers(), it.state.modes)) }
                }
                return true
            }
            override fun sendKeyEvent(event: KeyEvent): Boolean {
                if (event.action == KeyEvent.ACTION_DOWN) return this@TerminalView.onKeyDown(event.keyCode, event)
                return true
            }
        }
    }

    // --- Hardware keyboard input ---
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        val emu = emulator ?: return super.onKeyDown(keyCode, event)
        val mods = KeyModifiers(
            shift = event.isShiftPressed, ctrl = event.isCtrlPressed, alt = event.isAltPressed
        )
        val special: TerminalKey? = when (keyCode) {
            KeyEvent.KEYCODE_DPAD_UP -> TerminalKey.UP
            KeyEvent.KEYCODE_DPAD_DOWN -> TerminalKey.DOWN
            KeyEvent.KEYCODE_DPAD_LEFT -> TerminalKey.LEFT
            KeyEvent.KEYCODE_DPAD_RIGHT -> TerminalKey.RIGHT
            KeyEvent.KEYCODE_MOVE_HOME -> TerminalKey.HOME
            KeyEvent.KEYCODE_MOVE_END -> TerminalKey.END
            KeyEvent.KEYCODE_INSERT -> TerminalKey.INSERT
            KeyEvent.KEYCODE_FORWARD_DEL -> TerminalKey.DELETE
            KeyEvent.KEYCODE_PAGE_UP -> TerminalKey.PAGE_UP
            KeyEvent.KEYCODE_PAGE_DOWN -> TerminalKey.PAGE_DOWN
            KeyEvent.KEYCODE_ESCAPE -> TerminalKey.ESCAPE
            KeyEvent.KEYCODE_TAB -> TerminalKey.TAB
            KeyEvent.KEYCODE_DEL -> TerminalKey.BACKSPACE
            KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> TerminalKey.ENTER
            KeyEvent.KEYCODE_F1 -> TerminalKey.F1; KeyEvent.KEYCODE_F2 -> TerminalKey.F2
            KeyEvent.KEYCODE_F3 -> TerminalKey.F3; KeyEvent.KEYCODE_F4 -> TerminalKey.F4
            KeyEvent.KEYCODE_F5 -> TerminalKey.F5; KeyEvent.KEYCODE_F6 -> TerminalKey.F6
            KeyEvent.KEYCODE_F7 -> TerminalKey.F7; KeyEvent.KEYCODE_F8 -> TerminalKey.F8
            KeyEvent.KEYCODE_F9 -> TerminalKey.F9; KeyEvent.KEYCODE_F10 -> TerminalKey.F10
            KeyEvent.KEYCODE_F11 -> TerminalKey.F11; KeyEvent.KEYCODE_F12 -> TerminalKey.F12
            else -> null
        }
        if (special != null) {
            onKeyBytes?.invoke(TerminalKeyEncoder.encode(special, mods, emu.state.modes))
            return true
        }
        // Printable character from a physical keyboard (letters/digits/punctuation),
        // honouring Ctrl/Alt - unicodeChar already reflects the current Shift state.
        val unicodeChar = event.unicodeChar
        if (unicodeChar != 0 && !event.isCtrlPressed) {
            onKeyBytes?.invoke(TerminalKeyEncoder.encodeChar(unicodeChar.toChar(), mods))
            return true
        }
        if (event.isCtrlPressed && keyCode in KeyEvent.KEYCODE_A..KeyEvent.KEYCODE_Z) {
            val letter = 'a' + (keyCode - KeyEvent.KEYCODE_A)
            onKeyBytes?.invoke(TerminalKeyEncoder.encodeChar(letter, mods))
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun spToPx(sp: Float): Float = sp * resources.displayMetrics.scaledDensity

    private fun remeasureFont() {
        textPaint.textSize = spToPx(fontSizeSp)
        val metrics = textPaint.fontMetrics
        cellHeight = metrics.descent - metrics.ascent
        baselineOffset = -metrics.ascent
        // Monospace: measure a representative character for cell width.
        cellWidth = textPaint.measureText("M")
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        recomputeGridSize()
    }

    private fun recomputeGridSize() {
        val emu = emulator ?: return
        if (width <= 0 || height <= 0 || cellWidth <= 0f || cellHeight <= 0f) return
        val cols = (width / cellWidth).toInt().coerceAtLeast(1)
        val rows = (height / cellHeight).toInt().coerceAtLeast(1)
        if (cols != emu.columns || rows != emu.rows) {
            emu.resize(cols, rows)
            onGridSizeChanged?.invoke(cols, rows)
        }
    }

    override fun onDraw(canvas: Canvas) {
        val emu = emulator ?: run {
            canvas.drawColor(defaultBackground)
            return
        }
        canvas.drawColor(defaultBackground)

        for (row in 0 until emu.rows) {
            var col = 0
            while (col < emu.columns) {
                val cell = emu.cell(row, col)
                if (cell.width == 0) { col++; continue } // wide-char shadow cell, already painted
                drawCell(canvas, row, col, cell, emu)
                col += cell.width.coerceAtLeast(1)
            }
        }

        if (emu.cursorVisible) drawCursor(canvas, emu)
    }

    private fun drawCell(canvas: Canvas, row: Int, col: Int, cell: TerminalCell, emu: TerminalEmulator) {
        val x = col * cellWidth
        val y = row * cellHeight
        val cellW = cellWidth * cell.width.coerceAtLeast(1)

        val fgRgb = TerminalColor.resolve(cell.fg, palette, defaultForeground and 0x00FFFFFF)
        val bgRgb = TerminalColor.resolve(cell.bg, palette, defaultBackground and 0x00FFFFFF)
        val (paintFg, paintBg) = if (cell.reverse) bgRgb to fgRgb else fgRgb to bgRgb

        bgPaint.color = Color.rgb((paintBg shr 16) and 0xFF, (paintBg shr 8) and 0xFF, paintBg and 0xFF)
        canvas.drawRect(x, y, x + cellW, y + cellHeight, bgPaint)

        if (cell.char != ' ' && cell.char != '\u0000' && !cell.invisible) {
            var fgColor = Color.rgb((paintFg shr 16) and 0xFF, (paintFg shr 8) and 0xFF, paintFg and 0xFF)
            if (cell.dim) fgColor = dim(fgColor)
            textPaint.color = fgColor
            textPaint.isFakeBoldText = cell.bold
            textPaint.isStrikeThruText = cell.strikethrough
            textPaint.isUnderlineText = cell.underline
            val sb = StringBuilder().append(cell.char)
            for (c in cell.combining) sb.append(c)
            canvas.drawText(sb.toString(), x, y + baselineOffset, textPaint)
        }
    }

    private fun dim(color: Int): Int {
        val r = (Color.red(color) * 0.6f).toInt()
        val g = (Color.green(color) * 0.6f).toInt()
        val b = (Color.blue(color) * 0.6f).toInt()
        return Color.rgb(r, g, b)
    }

    private fun drawCursor(canvas: Canvas, emu: TerminalEmulator) {
        val x = emu.cursorCol * cellWidth
        val y = emu.cursorRow * cellHeight
        cursorPaint.color = defaultForeground
        when (emu.cursorStyle) {
            CursorStyle.BLOCK -> {
                cursorPaint.style = Paint.Style.STROKE
                canvas.drawRect(x, y, x + cellWidth, y + cellHeight, cursorPaint)
            }
            CursorStyle.UNDERLINE -> canvas.drawRect(x, y + cellHeight - 3f, x + cellWidth, y + cellHeight, bgPaint.apply { color = defaultForeground })
            CursorStyle.BAR -> canvas.drawRect(x, y, x + 2f, y + cellHeight, bgPaint.apply { color = defaultForeground })
        }
    }

    /** Total scrollback-inclusive content height in px, for a hosting ScrollView/gesture
     *  layer to use when implementing the scrollback view (requirement 7: "Scrollback"). */
    fun contentHeightPx(): Float {
        val emu = emulator ?: return 0f
        return (emu.rows + emu.buffer.scrollback.size) * cellHeight
    }
}
