# Add project-specific ProGuard/R8 rules here. Empty for now (minifyEnabled is
# false in the release build type until a real keep-rules pass is done for
# reflection-based libraries such as Room and any SSH library integrated
# later - see docs/ARCHITECTURE.md).
