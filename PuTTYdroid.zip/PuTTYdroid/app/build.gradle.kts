plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.devtools.ksp")
}

android {
    namespace = "com.puttydroid"
    // Bumped from 34 to 35: usb-serial-for-android 3.11.0 requires compileSdk 35+
    // (see build.gradle.kts's plugins block comment for the AGP-version tracing).
    compileSdk = 35

    defaultConfig {
        applicationId = "com.puttydroid"
        // USB Host API (android.hardware.usb) requires API 12+, but we target a floor
        // that keeps modern coroutines/AndroidX/TLS defaults simple: Android 8.0.
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0-dev"
    }

    buildTypes {
        release {
            isMinifyEnabled = false // flip on with a real R8 keep-rules pass before shipping
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation(project(":terminal-core"))

    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    // NOTE: bumped from 2.1.4 to 2.2.1 after a real build hit "attribute
    // auto:layout_constraintEnd_toEndOf not found" during :app:processDebugResources,
    // immediately after the AGP 8.6.0/compileSdk 35 bump above got the build past
    // AAR-metadata checking. Unlike the AGP/compileSdk fix, this is NOT a confirmed
    // root-cause diagnosis - the dependency declaration, the 2.1.4 version string, and
    // the layout XML were all verified correct, which rules out the usual causes of this
    // error, but no single citable source pinned down why linking failed specifically
    // here. This bump is the most plausible, lowest-risk thing to try next (a 2022-era
    // library AAR built against much older aapt2 failing to link cleanly against the
    // newer aapt2 that shipped with the AGP 8.6.0/build-tools 35.0.0 bump), not a
    // verified fix - if it doesn't resolve the error, treat this comment as ruled out
    // and look elsewhere (e.g. compare against a fresh `File > New Project` template's
    // resolved dependency versions in Android Studio, which can reveal a transitive
    // conflict that Gradle's own error output didn't surface).
    implementation("androidx.constraintlayout:constraintlayout:2.2.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.4")

    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // USB-serial device support (requirement 14) - see docs/ARCHITECTURE.md
    // "Why not hand-roll it" for why this is a dependency rather than a from-
    // scratch FTDI/CP210x/CH340 implementation.
    // Pinned to the version the library's own README currently recommends (checked via
    // web search when this line was last touched) rather than an arbitrary older tag -
    // JitPack builds each version on first request and caches it, and old, rarely-
    // requested versions have been known to fail to rebuild on JitPack's infrastructure
    // (see e.g. github.com/mik3y/usb-serial-for-android/issues/592). If this ever 404s
    // again, check https://github.com/mik3y/usb-serial-for-android for the current
    // recommended version rather than just retrying the same pin.
    implementation("com.github.mik3y:usb-serial-for-android:3.11.0")

    // Local, encrypted storage for saved sessions / credentials (requirement 12/13).
    implementation("androidx.security:security-crypto:1.1.0-alpha06")
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")

    // SSH backend is NOT wired up yet (see docs/ARCHITECTURE.md and
    // ssh/SshConfig.kt) - when it is, the plan is:
    // implementation("com.hierynomus:sshj:0.38.0")

    testImplementation("org.junit.jupiter:junit-jupiter:5.10.2")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.6.1")
}
