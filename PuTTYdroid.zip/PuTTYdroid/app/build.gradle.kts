plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.devtools.ksp")
}

android {
    namespace = "com.puttydroid"
    // Bumped from 34 to 35: usb-serial-for-android 3.11.0 requires compileSdk 35+
    // (see build.gradle.kts's plugins block comment for the AGP-version tracing).
    compileSdk = 35
    // Explicitly pinned: AGP has its OWN baked-in default buildToolsVersion,
    // independent of compileSdk - it does not automatically infer "35.0.0" just
    // because compileSdk is 35. Leaving this unset let AGP 8.6.0 silently fall back
    // to its own default (34.0.0, visible in a real build log as an unexpected
    // "Installing Android SDK Build-Tools 34" mid-build), which meant resource
    // linking ran against an older aapt2 binary than the compileSdk 35 project
    // actually needed - the most likely cause of the
    // "attribute ...layout_constraint* not found" failure for legitimate,
    // correctly-declared ConstraintLayout attributes (strong circumstantial evidence:
    // the anomalous build-tools-34 install itself, plus this being a well-documented
    // aapt2-version-mismatch failure mode) - not yet confirmed by an actual passing
    // build. Pinning this to match compileSdk removes the ambiguity either way.
    buildToolsVersion = "35.0.0"

    defaultConfig {
        applicationId = "com.puttydroid"
        // USB Host API (android.hardware.usb) requires API 12+, but we target a floor
        // that keeps modern coroutines/AndroidX/TLS defaults simple: Android 8.0.
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0-dev"
    }

    buildTypes {
        release {
            isMinifyEnabled = false // flip on with a real R8 keep-rules pass before shipping
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation(project(":terminal-core"))

    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    // NOTE: was bumped 2.1.4 -> 2.2.1 as a hypothesis for the "attribute
    // layout_constraint* not found" build failure - that hypothesis was tested and
    // RULED OUT (identical failure with 2.2.1). Reverted to 2.1.4, the long-established
    // stable release, since the actual cause turned out to be the missing explicit
    // `buildToolsVersion` above, not the library version. Keeping unverified changes
    // around after they're disproven just adds noise to future debugging.
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.4")

    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // USB-serial device support (requirement 14) - see docs/ARCHITECTURE.md
    // "Why not hand-roll it" for why this is a dependency rather than a from-
    // scratch FTDI/CP210x/CH340 implementation.
    // Pinned to the version the library's own README currently recommends (checked via
    // web search when this line was last touched) rather than an arbitrary older tag -
    // JitPack builds each version on first request and caches it, and old, rarely-
    // requested versions have been known to fail to rebuild on JitPack's infrastructure
    // (see e.g. github.com/mik3y/usb-serial-for-android/issues/592). If this ever 404s
    // again, check https://github.com/mik3y/usb-serial-for-android for the current
    // recommended version rather than just retrying the same pin.
    implementation("com.github.mik3y:usb-serial-for-android:3.11.0")

    // Local, encrypted storage for saved sessions / credentials (requirement 12/13).
    implementation("androidx.security:security-crypto:1.1.0-alpha06")
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")

    // SSH backend is NOT wired up yet (see docs/ARCHITECTURE.md and
    // ssh/SshConfig.kt) - when it is, the plan is:
    // implementation("com.hierynomus:sshj:0.38.0")

    testImplementation("org.junit.jupiter:junit-jupiter:5.10.2")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.6.1")
}
