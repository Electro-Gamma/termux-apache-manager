# PuTTYdroid

A native Android terminal client, in Kotlin, informed by a direct reading of
the PuTTY 0.74 source tree (see `docs/ARCHITECTURE.md` for the full
analysis and PuTTY-source-to-Kotlin mapping).

**Read `STATUS.md` first.** This is a real, working first installment - not
a finished PuTTY replacement. It has not been compiled in the environment it
was written in (no network/Android SDK available there); see `STATUS.md`
for exactly what that does and doesn't mean for correctness.

## What works right now

- A real VT100/ANSI/xterm terminal emulator (`terminal-core` module, no
  Android dependency, unit-tested).
- Raw TCP and Telnet connections (with real IAC option negotiation), wired
  end-to-end into a working Android UI.
- A custom Canvas-based terminal renderer with hardware- and soft-keyboard
  input.
- USB-serial device discovery/permission handling via the Android USB Host
  API, adapted onto the `usb-serial-for-android` library (untested against
  physical hardware in this environment - see `STATUS.md`).

## What doesn't exist yet

SSH, saved sessions, a settings UI, port forwarding, SFTP, Rlogin. See
`docs/ARCHITECTURE.md` for the plan for each.

## Building

Requirements: Android Studio (a recent stable release), JDK 17.

```
git clone <this repo>
cd PuTTYdroid
# Open in Android Studio and let it sync, OR from the command line:
./gradlew :terminal-core:test   # pure-JVM unit tests, no device/emulator needed
./gradlew :app:assembleDebug    # requires an Android SDK install
```

There is no `gradlew`/`gradlew.bat` wrapper JAR checked in (this repository
was produced without network access to fetch one) - generate it the usual
way once you have Gradle available locally:

```
gradle wrapper --gradle-version 8.7
```

or simply open the project in Android Studio, which bootstraps the wrapper
automatically.

## Project layout

```
terminal-core/   Pure Kotlin/JVM terminal emulator - parser, screen buffer,
                 cursor/attribute state, key encoder. No android.* imports.
app/             Android application module.
  connection/    TerminalConnection + Raw TCP / Telnet implementations.
  serial/        USB Host API device management + serial backend adapter.
  ssh/           SSH configuration schema (no connection impl yet).
  ui/            TerminalView (Canvas renderer) + MainActivity.
docs/            ARCHITECTURE.md - full PuTTY source analysis and mapping.
LICENSE, NOTICE  Licensing and third-party attribution (requirement 28).
STATUS.md        Honest, load-bearing status report - read this.
```

## License

MIT - see `LICENSE`. Third-party attributions (including PuTTY's own
copyright notice) are in `NOTICE`.
