# PuTTYdroid architecture

This document is Phase 1/2 of the requested development process: PuTTY 0.74
source analysis, the Android/Kotlin architecture it informed, a backend-by-
backend decision table, and an honest status of what's implemented in this
delivery versus planned.

## 1. How this codebase was produced

The supplied `putty-0.74` source tree (226 `.c` files, 55 `.h` files, ~23,000
lines in just the files most relevant to this port - see the table below)
was extracted and read directly - `terminal.c` (7279 lines), `telnet.c`
(1070 lines), `ssh.h` (1573 lines), `config.c` (2870 lines), `settings.c`
(1335 lines), `raw.c`, `rlogin.c`, `ldisc.c`, and the backend vtable in
`putty.h` - rather than working from general knowledge of "what PuTTY does."
Several implementation choices below only came from that reading and would
have been wrong by default, for example:

- **PuTTY's default function-key mode is `FUNKY_TILDE`** (`CONF_funky_type`
  defaults to `0`, see `settings.c` and the `FUNKY_*` enum in `putty.h`),
  which sends `ESC[11~`..`ESC[24~` for **F1-F12**. Most terminals (xterm's
  own default included) send `ESC O P/Q/R/S` for F1-F4. Getting this wrong
  is exactly the "superficial knowledge" failure mode requirement 30 warns
  about; `TerminalKeyEncoder.kt` transcribes PuTTY's actual
  `key_number_to_tilde_code[]` table from `terminal.c` line ~6857.
- **PuTTY's Telnet backend proactively requests options** (`DO ECHO`,
  `WILL/DO SGA`, `WILL NAWS`, `WILL TTYPE`) rather than waiting to be asked -
  see the `Opt_*` static structs in `telnet.c` around lines 146-164, all
  initialised to state `REQUESTED`.
- **Raw TCP has no `size` callback at all** (`raw.c`'s vtable has no
  meaningful `size` handler) - there's no way to tell a raw-mode peer the
  terminal size, so `RawTcpConnection.resize()` is correctly a no-op, not a
  missing feature.

## 2. Layered architecture

```
Connection layer (TerminalConnection implementations)
    -> raw bytes in/out, no terminal semantics
Terminal layer (terminal-core module: TerminalParser -> TerminalState -> TerminalBuffer)
    -> pure Kotlin, zero Android imports, unit-testable on the JVM
Renderer (TerminalView)
    -> Canvas-based, reads TerminalEmulator's grid, has no protocol knowledge
UI/session (MainActivity, future SessionRepository)
    -> wires the above together, owns coroutine lifecycles
```

This mirrors the brief's requested layering (`Connection -> Protocol ->
Byte/Input Stream -> Terminal Parser -> Terminal State -> Screen Buffer ->
Renderer -> Android UI`) with Protocol folded into each `TerminalConnection`
implementation (e.g. Telnet's IAC negotiation lives inside
`TelnetConnection`, not as a separate layer) since, for every backend PuTTY
implements, protocol framing and the byte stream are handled by the same
object PuTTY's own backend vtable represents.

`terminal-core` is a separate Gradle module specifically so "the terminal
state should be testable independently" (requirement 8) is a build-system
guarantee, not just a convention: it has no Android Gradle plugin applied
and cannot import `android.*` even by accident.

## 3. Backend decision table (requirement 6)

| PuTTY backend | What it does | Useful on Android? | Kotlin-only feasible? | Native/library needed? | Decision | Status |
|---|---|---|---|---|---|---|
| `raw.c` (Raw TCP) | Unmodified TCP passthrough | Yes - IoT/dev boards, netcat-style debugging | Yes (`java.net.Socket`) | No | Implement | **Done** - `RawTcpConnection.kt` |
| `telnet.c` (Telnet) | TCP + IAC option negotiation | Yes - network gear, BBSes, MUDs, embedded consoles | Yes | No | Implement | **Done** (ECHO/SGA/NAWS/TTYPE; TSPEED/ENVIRON deferred) - `TelnetConnection.kt` |
| `rlogin.c` (Rlogin) | BSD rlogin protocol (trusted-host auth, no real security) | Marginal - rlogin is obsolete and Android has no concept of trusted-host `.rhosts` auth anyway | Yes, trivially (it's simpler than Telnet) | No | Implement later, low priority | Not started - straightforward extension of the Raw/Telnet pattern once someone asks for it |
| `ssh.c` + `ssh2*.c` + `sshbpp/sshcrc/sshaes/sshrsa/sshdh/sshecc...` (SSH-1 and SSH-2) | Encrypted, authenticated remote shell | Yes - this is the headline feature | **No** for the crypto - see ยง4 | Yes: a vetted SSH2 library | Implement via library adapter, not a hand-written crypto stack | Interface/config schema only (`ssh/SshConfig.kt`); no connection implementation yet - see ยง4 |
| Serial (no single PuTTY C file - Windows `winser.c`/Unix `unix/uxser.c`, neither in the shared source tree) | Direct UART I/O | Yes - ESP32/ESP8266/embedded dev is a major real-world use case | Device *discovery/permission* yes; chip-level UART framing no | Yes: `usb-serial-for-android` for CP210x/FTDI/CH340/CDC-ACM chip protocols | Implement via library adapter | **Structurally done** - `UsbSerialManager.kt` (real Android USB Host API), `UsbSerialTerminalConnection.kt` (adapter); **not hardware-tested** (no USB device in this build environment) |
| `x11fwd.c` (X11 forwarding) | Forward X11 protocol over the SSH channel | Low - no X server on stock Android | N/A | N/A | Exclude | Excluded: dead weight without an X server; revisit only if a specific Android X server integration is requested |
| `pageant.c` (Pageant, SSH agent) | Background SSH-key agent + agent forwarding | Yes in spirit (a key store), no in PuTTY's literal form (Windows-named-pipe based) | Yes, as "Android Keystore-backed key storage" | No (once SSH backend exists) | Reimplement conceptually as part of the SSH key-storage layer, not as a literal Pageant port | Deferred with the SSH backend |
| `pscp.c` / `psftp.c` (SCP/SFTP CLI tools) | File transfer over SSH | Yes, as a feature of the SSH backend (SFTP), not as separate CLI tools | Depends on the SSH library's SFTP support | Same library as SSH | Fold into the SSH backend's feature set once implemented, no separate app surface | Deferred with the SSH backend |
| `proxy.c`/`cproxy.c` (HTTP/SOCKS proxy for outbound connections) | Let any backend tunnel through a proxy | Yes - useful on restrictive networks | Yes (`java.net.Proxy`, or manual SOCKS handshake) | No | Implement as a `HostTarget` option | Not started; straightforward addition to `HostTarget`/connection construction |
| `sercfg.c` (serial config panel) | UI, not a backend | N/A | N/A | N/A | Its *data* (baud/bits/stop/parity/flow) is modelled in `SerialConfig.kt`; the config *panel* is a UI task | Data model done, settings screen not built |

## 4. SSH backend: status and plan

**No `SshConnection` implementing `TerminalConnection` exists in this
delivery.** `ssh/SshConfig.kt` defines the configuration schema
(auth methods, port forwards, host-key policy) so the session/storage layer
above it can be built without waiting on the backend, but there is
deliberately no connect()/write() body behind it yet.

### Why not hand-roll it
PuTTY's own SSH implementation is genuinely large and security-critical:
`sshaes.c`, `sshrsa.c`, `sshdh.c`, `sshecc.c`, `sshsh256.c`, `sshsh512.c`,
`sshprime.c`, `sshbcrypt.c`, and the SSH-2 transport/kex/userauth state
machines (`ssh2transport.c`, `ssh2kex-client.c`, `ssh2userauth.c`, and
friends) total many thousands of lines of deliberately conservative C,
written and hardened over two decades. Requirement 2 itself says
**"Security must be implemented correctly. Do not replace real SSH
cryptography with placeholders or simplified algorithms"** and separately
allows **"an equivalent clean-room Kotlin/native implementation using
appropriate Android-compatible libraries"** where a direct port isn't
practical. Hand-transcribing that many cryptographic primitives into Kotlin,
in a sandboxed environment with no network access to pull in a reference
crypto/test suite or even compile-check the result, is exactly how you
introduce a subtle, exploitable bug - the single worst outcome for a
terminal client whose whole job is secure remote access. A vetted library is
the responsible choice here, the same way that using OS-provided TLS instead
of hand-rolled TLS would be to any professional engineer.

### The plan
Adapt **[sshj](https://github.com/hierynomus/sshj)** (`com.hierynomus:sshj`,
Apache 2.0, pure Java/Kotlin-compatible, no native/NDK dependency): it
supports SSH-2 password/keyboard-interactive/publickey auth, modern KEX and
cipher suites, host-key verification callbacks, port forwarding, and SFTP -
covering nearly everything in requirement 2's SSH list except SSH-1 (which
sshj also does not support; given SSH-1 is cryptographically broken and
disabled by default in real-world PuTTY builds for years, this is judged an
acceptable gap rather than a reason to hand-write an SSH-1 stack). The
adapter (`SshConnection.kt`, not yet written) would:
1. Wrap `net.schmizz.sshj.SSHClient`, mapping `HostKeyPolicy` to a
   `HostKeyVerifier` (prompt-on-first-use backed by the same encrypted
   storage as saved sessions, or strict `known_hosts`-only).
2. Map `SshAuthMethod` to the corresponding `sshj` `AuthMethod`.
3. Open a `Session`, request a PTY sized from the current
   `TerminalEmulator.columns/rows`, start a `Shell`, and pump its
   `InputStream`/`OutputStream` through the same `onData`/`write()` contract
   every other `TerminalConnection` uses - the terminal/UI layers need zero
   changes to support this once it exists (requirement 15's whole point).
4. Map `PortForward` entries to `sshj`'s local/remote/dynamic forwarding
   APIs.

## 5. Terminal parser coverage

`terminal-core`'s `TerminalParser` implements, grounded in reading
`terminal.c`'s dispatch (not just general VT100 knowledge):

**Implemented:** C0 controls (BEL/BS/HT/LF/VT/FF/CR/SO/SI/ESC); `ESC 7 8 D E
M H c = >`; DEC Special Graphics line-drawing charset (`ESC ( 0`); DECALN
(`ESC # 8`); CSI cursor movement (`A B C D E F G H f d`); erase (`J K`);
insert/delete char & line (`@ P L M`); scroll (`S T`); ECH (`X`); tab
set/clear (`g`); full SGR including 256-color and truecolor (`m`); ANSI/DEC
private mode set-reset (`h`/`l`, both plain and `?`-prefixed) covering IRM,
LNM, DECCKM, DECSCNM, DECOM, DECAWM, DECTCEM, alt-screen (`47`/`1047`/
`1049`), bracketed paste (`2004`), mouse tracking mode *tracking only* (see
below); DECSTBM (`r`); save/restore cursor (`s`/`u`, `ESC 7`/`8`, and the
separate `1048`/`1049` slot); DSR/CPR (`n`); a DA reply (`c`); OSC window/
icon title (`0`/`1`/`2`) with other OSCs safely discarded rather than leaked
to the screen as text.

**Known gaps** (tracked here, not hidden - requirement 27's spirit applies
to documentation too):
- **Mouse reporting is tracked but not wired to touch input.** The mode
  flags (`MouseTrackingMode`, `MouseEncoding`) update correctly on the
  DEC private-mode sequences, but `TerminalView` doesn't yet translate
  touches into X10/SGR/urxvt mouse reports. Needed for `vim`/`htop`
  mouse support; not needed for `cat`/`ls`/`bash`/`ssh`/serial logs.
- **wcwidth approximation, not a table port.** `isWideChar()` in
  `TerminalParser.kt` is a reasonable CJK/Hangul/fullwidth range check, not
  a line-for-line port of `wcwidth.c`'s exact Unicode range table.
- **No reflow on resize.** `TerminalBuffer.resize()` truncates/pads rows and
  columns; it does not re-wrap paragraphs the way PuTTY's `term_size()`
  does by tracking a wrapped-line bit per row.
- **VT52 mode, SS2/SS3 single shifts, DECDHL/DECDWL double-width/height
  lines, sixel/ReGIS graphics** are not implemented.
- **Telnet TSPEED and (OLD/NEW)_ENVIRON subnegotiations** are not sent
  (ECHO/SGA/NAWS/TTYPE are - see ยง3's Telnet row).
- **DECSCUSR (`CSI Ps SP q`, runtime cursor-style change)** intermediate
  bytes are collected by the parser but not yet dispatched to
  `TerminalModes.cursorStyle`.

None of these gaps affect the primary correctness properties tested in
`TerminalParserTest.kt` (cursor movement, colors, erase, scrolling incl. the
scrollback/region distinction, alt-screen save/restore, UTF-8 chunk
splitting, resize).

### On behavioural test vectors (requirement 19)
`TerminalParserTest.kt` is written against the documented ECMA-48/DEC/xterm
semantics PuTTY implements (traced from `terminal.c`, see file header
comments throughout `terminal-core`), not against a running PuTTY binary -
no PuTTY executable was buildable in this sandboxed, network-disabled
environment to diff against directly. A real differential harness (driving
a Linux PuTTY build headlessly, e.g. via its `test/` fuzzing/testing
utilities such as `fuzzterm.c`, and comparing screen dumps byte-for-byte
against `TerminalEmulator`) is the natural next step and is not yet built.

## 6. Rendering (requirement 10)

`TerminalView` is a custom `View` subclass painting the grid with
`Canvas.drawText`/`drawRect` per cell, not one Android view per character.
It currently repaints the full visible grid on every `invalidate()` rather
than tracking PuTTY's fine-grained dirty rectangles (`term->disptext` diffing
in `terminal.c`) - a deliberately deferred optimisation, not a correctness
gap; full-grid Canvas repaint of a few thousand cells is cheap on modern
Android hardware and was judged the right complexity trade-off for this
delivery. If a future profiling pass shows it's a bottleneck under very
high-throughput serial/SSH output (requirement 20's `dmesg`/`top`/ESP32
boot-log scenarios), dirty-row tracking is the natural next optimisation.

## 7. What actually got built in this delivery, end to end

1. `terminal-core`: full VT100/ANSI/xterm parser, screen buffer (primary +
   alt + scrollback), cursor/attribute state, UTF-8 streaming decoder, key
   encoder - all unit-tested, all pure Kotlin/JVM.
2. `RawTcpConnection` and `TelnetConnection` - real sockets, real IAC
   negotiation, wired end-to-end through `MainActivity` into a real
   `TerminalView`.
3. `TerminalView` - real Canvas renderer with hardware-keyboard and soft-
   keyboard (`InputConnection`) input, wired to `TerminalKeyEncoder`.
4. `UsbSerialManager`/`UsbSerialTerminalConnection` - real Android USB Host
   API device discovery/permission handling and a real adapter onto
   `usb-serial-for-android`'s port I/O; not hardware-tested in this
   environment (no attached USB device, no network to fetch the library for
   a build).
5. SSH config schema; no connection implementation (ยง4).
6. Saved sessions, encrypted credential storage, a settings/config UI,
   port forwarding, SFTP, Rlogin, a customizable extra-key bar, and mouse
   reporting are all designed-for (interfaces/config shapes exist or are
   trivial extensions of the existing pattern) but not built - see the
   per-item notes above.

## 8. This project could not be compiled or run in this delivery

The environment this was authored in has no network access (no Gradle
dependency resolution, no Android SDK/emulator, no `kotlinc` even for a
syntax-only check) - see the repository root `STATUS.md` for the full
disclosure. Every file here was written and hand-traced against its own
logic and against PuTTY's source, but "open it in Android Studio, sync
Gradle, and run it" is the first verification step a real build environment
would need to perform, and bugs surfacing at that point (most likely: a
dependency version bump, not a logic error in `terminal-core`, which is the
part that was traced most rigorously against unit tests) should be expected
the way they would be for any first `git clone && open` of a fresh project.
