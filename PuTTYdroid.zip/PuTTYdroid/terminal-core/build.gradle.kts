// Pure Kotlin/JVM module - deliberately has NO Android Gradle plugin and no
// android.* imports anywhere under src/, so it builds and its tests run with
// plain `./gradlew :terminal-core:test` on a desktop JVM, no emulator or
// device required. This is what requirement 8 means by "the terminal state
// should be testable independently".
plugins {
    kotlin("jvm")
}

kotlin {
    jvmToolchain(17)
}

dependencies {
    testImplementation("org.junit.jupiter:junit-jupiter:5.10.2")
}

tasks.test {
    useJUnitPlatform()
}
