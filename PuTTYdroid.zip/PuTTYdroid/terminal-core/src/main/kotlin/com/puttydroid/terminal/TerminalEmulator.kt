package com.puttydroid.terminal

/**
 * Facade combining TerminalBuffer + TerminalState + TerminalParser into the
 * single object the connection layer and the Android renderer talk to.
 *
 * This corresponds to PuTTY's `Terminal` object (terminal.c/terminal.h) as
 * seen from the outside: `term_init()`, `term_size()`, `from_backend()`
 * (incoming data), and the various `term_*` query functions the frontend
 * uses to paint (see windows/window.c / unix/gtkwin.c's use of `term_get_*`).
 * Kotlin/Android equivalents:
 *   term_init()            -> constructor
 *   from_backend()          -> feed()
 *   term_size()              -> resize()
 *   term->screen[y].chars[x] -> cell(row, col) / screen grid accessors
 *
 * No Android imports here by design (requirement 8: "the terminal parser
 * must not depend directly on Android UI classes" / "the terminal state
 * should be testable independently").
 */
class TerminalEmulator(columns: Int, rows: Int, scrollbackLines: Int = 5000) {

    val buffer = TerminalBuffer(columns, rows, scrollbackLines)
    val state = TerminalState(buffer)
    private val parser = TerminalParser(state)

    /** Bytes the terminal needs to send back to the connection (DSR/CPR/DA replies -
     *  see requirement 8's "outgoing keyboard data should follow the reverse path":
     *  these are terminal-generated replies, not keyboard input, but they travel the
     *  same reverse path back out through the connection layer). */
    var onResponse: ((ByteArray) -> Unit)?
        get() = parser.onResponse
        set(value) { parser.onResponse = value }

    var onBell: (() -> Unit)?
        get() = parser.onBell
        set(value) { parser.onBell = value }

    var onTitleChange: ((String) -> Unit)?
        get() = parser.onTitleChange
        set(value) { parser.onTitleChange = value }

    /** Called by the connection layer with each chunk of incoming data. Safe to call from
     *  a background/IO coroutine; this class holds no Android threading assumptions, so the
     *  caller (see connection/TerminalConnection.kt) is responsible for hopping back onto
     *  the UI thread before touching the renderer, per requirement 16. */
    fun feed(bytes: ByteArray, length: Int = bytes.size) = parser.feed(bytes, length)

    fun resize(columns: Int, rows: Int) {
        buffer.resize(columns, rows)
        state.onResize(columns, rows)
    }

    val columns: Int get() = buffer.columns
    val rows: Int get() = buffer.rows
    val cursorRow: Int get() = state.cursorRow
    val cursorCol: Int get() = state.cursorCol
    val cursorVisible: Boolean get() = state.modes.cursorVisible
    val cursorStyle: CursorStyle get() = state.modes.cursorStyle

    fun cell(row: Int, col: Int): TerminalCell = buffer.cell(row, col)
}
