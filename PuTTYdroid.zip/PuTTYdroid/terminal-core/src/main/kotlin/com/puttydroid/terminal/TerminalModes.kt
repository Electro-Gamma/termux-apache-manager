package com.puttydroid.terminal

/** Cursor rendering style. PuTTY source: `conf_get_int(CONF_cursor_type)` combined with
 *  the DECSCUSR (`CSI Ps SP q`) runtime override in terminal.c. */
enum class CursorStyle { BLOCK, UNDERLINE, BAR }

/** Mouse tracking protocol. PuTTY source: terminal.c's handling of DEC private modes
 *  1000 (X10/normal), 1002 (button-event), 1003 (any-event) and the encoding modes
 *  1005/1006/1015 (UTF-8 / SGR / urxvt extended coordinates). We only model the
 *  reporting *mode*; coordinate encoding is handled where reports are generated. */
enum class MouseTrackingMode { OFF, NORMAL, BUTTON_EVENT, ANY_EVENT }
enum class MouseEncoding { X10, UTF8, SGR, URXVT }

/**
 * Mutable terminal mode state - the DEC private modes (DECSET/DECRST, `CSI ? Pm h/l`)
 * and ANSI modes (`CSI Pm h/l`) that alter how the parser and keyboard behave.
 *
 * PuTTY source reference: terminal.c's `toggle_mode()` function switches on the
 * numeric mode and mutates fields directly on the `Terminal` struct (`term->cset`,
 * `term->utf`, `term->rvideo`, `term->cursor_on`, `term->wrap`, `term->insert`, etc).
 * We collect the equivalent flags here.
 */
data class TerminalModes(
    // ANSI modes
    var insertMode: Boolean = false,          // IRM, `CSI 4 h/l`
    var lineFeedNewLineMode: Boolean = false,  // LNM, `CSI 20 h/l`

    // DEC private modes
    var applicationCursorKeys: Boolean = false,  // DECCKM, ?1
    var autoWrap: Boolean = true,                // DECAWM, ?7
    var reverseVideoScreen: Boolean = false,     // DECSCNM, ?5
    var originMode: Boolean = false,             // DECOM, ?6
    var applicationKeypad: Boolean = false,      // DECNKM / numeric-keypad app mode, ?66/DECPAM/DECPNM
    var cursorVisible: Boolean = true,           // DECTCEM, ?25
    var altScreenActive: Boolean = false,        // ?47 / ?1047 / ?1049
    var saveRestoreCursorOnAltScreen: Boolean = false, // ?1049 additionally saves/restores cursor
    var bracketedPaste: Boolean = false,         // ?2004
    var utf8: Boolean = true,                    // input encoding; PuTTY: term->utf / CJK line-drawing set select

    var mouseTracking: MouseTrackingMode = MouseTrackingMode.OFF,
    var mouseEncoding: MouseEncoding = MouseEncoding.X10,

    var cursorStyle: CursorStyle = CursorStyle.BLOCK,
    var cursorBlinks: Boolean = true,

    /** DEC Special Graphics ("line drawing") active on G0/G1, selected via `ESC ( 0` etc,
     *  and shifted in/out with SO/SI (Ctrl-N / Ctrl-O). PuTTY: term->cset_attr / term->sco_acs. */
    var g0SpecialGraphics: Boolean = false,
    var g1SpecialGraphics: Boolean = false,
    var usingG1: Boolean = false
)
