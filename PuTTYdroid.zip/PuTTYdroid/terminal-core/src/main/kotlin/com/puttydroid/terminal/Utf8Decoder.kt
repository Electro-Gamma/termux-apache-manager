package com.puttydroid.terminal

/**
 * Incremental UTF-8 decoder.
 *
 * PuTTY source reference: terminal.c decodes UTF-8 a byte at a time inline
 * in `term_out` (`term->utf8_state`, `term->utf8_char`, `term->utf8_size`)
 * because bytes can arrive split across network reads. We do the same here
 * as a small standalone class so TerminalParser.feed() can be called with
 * whatever chunk size the connection layer happens to hand it, including
 * a chunk that ends mid-codepoint.
 *
 * Malformed sequences are replaced with U+FFFD, matching PuTTY's fallback
 * behaviour of resetting UTF-8 state and treating the offending byte as
 * a fresh start rather than aborting the stream.
 */
class Utf8Decoder {
    private var pending = 0
    private var need = 0
    private var codepoint = 0

    /** Feed raw bytes, get back decoded chars (as UTF-16 code units - a supplementary-plane
     *  codepoint yields a surrogate pair, exactly like Java/Kotlin Char semantics elsewhere). */
    fun decode(bytes: ByteArray, length: Int = bytes.size): List<Char> {
        val out = ArrayList<Char>(length)
        for (i in 0 until length) {
            val b = bytes[i].toInt() and 0xFF
            if (need == 0) {
                when {
                    b < 0x80 -> out.add(b.toChar())
                    b and 0xE0 == 0xC0 -> { codepoint = b and 0x1F; need = 1 }
                    b and 0xF0 == 0xE0 -> { codepoint = b and 0x0F; need = 2 }
                    b and 0xF8 == 0xF0 -> { codepoint = b and 0x07; need = 3 }
                    else -> out.add('\uFFFD') // invalid leading byte
                }
                pending = need
            } else {
                if (b and 0xC0 == 0x80) {
                    codepoint = (codepoint shl 6) or (b and 0x3F)
                    need--
                    if (need == 0) {
                        appendCodepoint(out, codepoint)
                    }
                } else {
                    // Malformed continuation - emit replacement and reprocess this byte as a
                    // fresh start, matching PuTTY's UTF-8 error recovery.
                    out.add('\uFFFD')
                    need = 0
                    pending = 0
                    if (b < 0x80) out.add(b.toChar())
                    else if (b and 0xE0 == 0xC0) { codepoint = b and 0x1F; need = 1 }
                    else if (b and 0xF0 == 0xE0) { codepoint = b and 0x0F; need = 2 }
                    else if (b and 0xF8 == 0xF0) { codepoint = b and 0x07; need = 3 }
                    else out.add('\uFFFD')
                }
            }
        }
        return out
    }

    private fun appendCodepoint(out: MutableList<Char>, cp: Int) {
        if (cp <= 0xFFFF) {
            out.add(cp.toChar())
        } else {
            val v = cp - 0x10000
            out.add((0xD800 + (v shr 10)).toChar())
            out.add((0xDC00 + (v and 0x3FF)).toChar())
        }
    }
}
