package com.puttydroid.terminal

/**
 * The character grid: primary screen, alternate screen, and scrollback.
 *
 * PuTTY source reference: terminal.c stores three `tree234 *` of `termline *`
 * (`term->screen`, `term->alt_screen`, `term->scrollback`), each line being a
 * dynamically-sized run of `termchar`. tree234 gives PuTTY O(log n) line
 * insert/delete for scroll-region operations. On the JVM we don't need a
 * balanced tree for a few thousand lines; an ArrayDeque-backed scrollback
 * plus a plain Array<Array<TerminalCell>> screen gives the same asymptotic
 * behaviour we actually need (append/trim at the ends) with far less code,
 * while keeping the same *behavioural* contract PuTTY implements: when the
 * cursor scrolls off the bottom of the (unmargined) screen, the top line is
 * pushed onto scrollback and trimmed once `scrollbackLines` is exceeded
 * (see terminal.c `save_scrollback` line-count enforcement against
 * `conf_get_int(CONF_savelines)`).
 *
 * Only what happens *inside the active scroll region* (`term->marg_t` /
 * `term->marg_b`, DECSTBM `CSI t;b r`) goes to scrollback-less regional
 * scrolling; a scroll that includes the very top line of the whole screen
 * while the top margin is at row 0 is what feeds scrollback, exactly as in
 * PuTTY's `scroll()` function.
 */
class TerminalBuffer(
    var columns: Int,
    var rows: Int,
    var maxScrollbackLines: Int = 5000
) {
    private var primary: Array<Array<TerminalCell>> = makeBlankScreen(columns, rows)
    private var alternate: Array<Array<TerminalCell>> = makeBlankScreen(columns, rows)
    private val scrollbackDeque: ArrayDeque<Array<TerminalCell>> = ArrayDeque()

    var usingAlt: Boolean = false
        private set

    /** Active screen grid (primary or alternate), row-major: screen[row][col]. */
    val screen: Array<Array<TerminalCell>> get() = if (usingAlt) alternate else primary

    val scrollback: List<Array<TerminalCell>> get() = scrollbackDeque

    private fun makeBlankScreen(cols: Int, rws: Int): Array<Array<TerminalCell>> =
        Array(rws) { blankRow(cols) }

    private fun blankRow(cols: Int): Array<TerminalCell> = Array(cols) { TerminalCell.BLANK }

    fun cell(row: Int, col: Int): TerminalCell {
        if (row !in 0 until rows || col !in 0 until columns) return TerminalCell.BLANK
        return screen[row][col]
    }

    fun setCell(row: Int, col: Int, cell: TerminalCell) {
        if (row !in 0 until rows || col !in 0 until columns) return
        screen[row][col] = cell
    }

    /**
     * Switch to the alternate screen buffer (DEC private mode 47/1047/1049).
     * PuTTY source: terminal.c `swap_screen()`. The alternate screen is
     * cleared on entry unless `preserveContents` is requested (mode 1047/1049
     * clear it; some xterm variants of 47 do not — PuTTY's `swap_screen`
     * takes a `wipe` argument for exactly this reason).
     */
    fun switchToAlternate(wipe: Boolean) {
        if (usingAlt) return
        usingAlt = true
        if (wipe) alternate = makeBlankScreen(columns, rows)
    }

    fun switchToPrimary() {
        usingAlt = false
    }

    /**
     * Scroll the region [top, bottom] (inclusive, 0-indexed) up by `n` lines.
     * Lines scrolled off the top of the region are discarded, UNLESS the
     * region's top edge is the physical top of the (primary, non-alt) screen,
     * in which case they are pushed to scrollback - mirroring PuTTY's
     * `scroll()`, which only calls `save_scrollback` when
     * `topline == 0 && !term->alt_screen`.
     */
    fun scrollRegionUp(top: Int, bottom: Int, n: Int = 1) {
        if (top > bottom || top < 0 || bottom >= rows) return
        val count = n.coerceAtMost(bottom - top + 1)
        repeat(count) {
            val removed = screen[top]
            if (top == 0 && !usingAlt) {
                scrollbackDeque.addLast(removed)
                while (scrollbackDeque.size > maxScrollbackLines) scrollbackDeque.removeFirst()
            }
            for (r in top until bottom) screen[r] = screen[r + 1]
            screen[bottom] = blankRow(columns)
        }
    }

    /** Scroll the region [top, bottom] down by `n` lines (used by RI / DECSTBM reverse index). */
    fun scrollRegionDown(top: Int, bottom: Int, n: Int = 1) {
        if (top > bottom || top < 0 || bottom >= rows) return
        val count = n.coerceAtMost(bottom - top + 1)
        repeat(count) {
            for (r in bottom downTo top + 1) screen[r] = screen[r - 1]
            screen[top] = blankRow(columns)
        }
    }

    fun eraseRow(row: Int, fromCol: Int = 0, toCol: Int = columns - 1) {
        if (row !in 0 until rows) return
        val r = screen[row]
        for (c in fromCol..toCol.coerceAtMost(columns - 1)) r[c] = TerminalCell.BLANK
    }

    fun insertBlankChars(row: Int, atCol: Int, count: Int) {
        if (row !in 0 until rows) return
        val r = screen[row]
        val n = count.coerceAtMost(columns - atCol)
        for (c in columns - 1 downTo atCol + n) r[c] = r[c - n]
        for (c in atCol until (atCol + n).coerceAtMost(columns)) r[c] = TerminalCell.BLANK
    }

    fun deleteChars(row: Int, atCol: Int, count: Int) {
        if (row !in 0 until rows) return
        val r = screen[row]
        val n = count.coerceAtMost(columns - atCol)
        for (c in atCol until columns - n) r[c] = r[c + n]
        for (c in (columns - n).coerceAtLeast(atCol) until columns) r[c] = TerminalCell.BLANK
    }

    fun insertBlankLines(atRow: Int, bottom: Int, count: Int) {
        if (atRow !in 0..bottom || bottom >= rows) return
        val n = count.coerceAtMost(bottom - atRow + 1)
        for (r in bottom downTo atRow + n) screen[r] = screen[r - n]
        for (r in atRow until (atRow + n).coerceAtMost(bottom + 1)) screen[r] = blankRow(columns)
    }

    fun deleteLines(atRow: Int, bottom: Int, count: Int) {
        if (atRow !in 0..bottom || bottom >= rows) return
        val n = count.coerceAtMost(bottom - atRow + 1)
        for (r in atRow..bottom - n) screen[r] = screen[r + n]
        for (r in (bottom - n + 1).coerceAtLeast(atRow)..bottom) screen[r] = blankRow(columns)
    }

    fun clearAll() {
        primary = makeBlankScreen(columns, rows)
        alternate = makeBlankScreen(columns, rows)
    }

    /**
     * Resize the grid. PuTTY source: terminal.c `term_size()`. PuTTY's real
     * behaviour reflows line-wrapped text on resize (tracking a wrapped-line
     * bit per row); reflow is intentionally deferred (see ARCHITECTURE.md,
     * "Known deviations") - this resizes by truncating/padding rows and
     * columns without reflowing wrapped paragraphs, which is what the large
     * majority of terminal apps (shells, vim, top, ssh sessions) already
     * handle themselves via a SIGWINCH + redraw, same as any terminal whose
     * emulator doesn't reflow.
     */
    fun resize(newColumns: Int, newRows: Int) {
        if (newColumns == columns && newRows == rows) return
        primary = resizeScreen(primary, newColumns, newRows)
        alternate = resizeScreen(alternate, newColumns, newRows)
        columns = newColumns
        rows = newRows
    }

    private fun resizeScreen(
        src: Array<Array<TerminalCell>>,
        newColumns: Int,
        newRows: Int
    ): Array<Array<TerminalCell>> {
        val out = Array(newRows) { r ->
            if (r < src.size) {
                val oldRow = src[r]
                Array(newColumns) { c -> if (c < oldRow.size) oldRow[c] else TerminalCell.BLANK }
            } else {
                blankRow(newColumns)
            }
        }
        return out
    }
}
