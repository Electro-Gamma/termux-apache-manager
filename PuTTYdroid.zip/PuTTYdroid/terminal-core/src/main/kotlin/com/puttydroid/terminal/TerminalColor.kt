package com.puttydroid.terminal

/**
 * Terminal color model.
 *
 * PuTTY source reference: terminal.c / terminal.h `colour` handling and the
 * ATTR_FGSHIFT/ATTR_BGSHIFT bitfields packed into `termchar.attr`. PuTTY
 * packs colour indices (0..255, plus two "default" slots) into a 64-bit
 * attribute word alongside the SGR attribute bits. We use an explicit
 * sealed class instead of packed bits, because on the JVM there is no
 * performance reason to hand-pack a bitfield, and an explicit
 * representation is far easier to test and reason about (see
 * requirement 8: "the terminal state should be testable independently").
 */
sealed class TerminalColor {
    /** The color inherited from the current SGR default (not yet resolved to a palette entry). */
    object Default : TerminalColor()

    /** One of the 16 standard ANSI colors (0-7 normal, 8-15 bright). */
    data class Ansi16(val index: Int) : TerminalColor() {
        init { require(index in 0..15) { "ANSI16 index out of range: $index" } }
    }

    /** xterm 256-color palette index (0-255). Values 0-15 duplicate Ansi16, 16-231 are
     *  the 6x6x6 color cube, 232-255 are the grayscale ramp - matching xterm's layout,
     *  which PuTTY 0.74 also implements (see terminal.c parsing of `38;5;n` / `48;5;n`). */
    data class Indexed256(val index: Int) : TerminalColor() {
        init { require(index in 0..255) { "256-color index out of range: $index" } }
    }

    /** 24-bit truecolor, `38;2;r;g;b` / `48;2;r;g;b` (PuTTY 0.74 supports this via the
     *  "true colour" terminal setting). */
    data class TrueColor(val r: Int, val g: Int, val b: Int) : TerminalColor()

    companion object {
        /** Standard xterm default 16-color palette (index -> 0xRRGGBB), used when the
         *  active PuTTY palette config hasn't overridden a slot. */
        val DEFAULT_PALETTE: IntArray = intArrayOf(
            0x000000, 0xBB0000, 0x00BB00, 0xBBBB00, 0x0000BB, 0xBB00BB, 0x00BBBB, 0xBBBBBB,
            0x555555, 0xFF5555, 0x55FF55, 0xFFFF55, 0x5555FF, 0xFF55FF, 0x55FFFF, 0xFFFFFF
        )

        const val DEFAULT_FOREGROUND: Int = 0xBBBBBB
        const val DEFAULT_BACKGROUND: Int = 0x000000
        const val DEFAULT_CURSOR: Int = 0xBBBBBB

        /** Resolve any TerminalColor to a concrete 0xRRGGBB value given a 256-slot palette
         *  (slots 0-15 are the user's configured ANSI colors; 16-255 are the fixed cube/ramp
         *  unless a "palette" scheme has overridden them, which we model by making the whole
         *  array mutable). */
        fun resolve(color: TerminalColor, palette: IntArray, defaultRgb: Int): Int = when (color) {
            is Default -> defaultRgb
            is Ansi16 -> palette[color.index]
            is Indexed256 -> palette[color.index]
            is TrueColor -> (color.r shl 16) or (color.g shl 8) or color.b
        }

        /** Build the full 256-entry palette: 0-15 from the (possibly user-customized) 16-color
         *  base, 16-231 the 6x6x6 cube, 232-255 the grayscale ramp. Mirrors xterm/PuTTY layout. */
        fun buildFullPalette(base16: IntArray = DEFAULT_PALETTE): IntArray {
            require(base16.size == 16)
            val out = IntArray(256)
            base16.copyInto(out, 0)
            val steps = intArrayOf(0, 95, 135, 175, 215, 255)
            var i = 16
            for (r in 0..5) for (g in 0..5) for (b in 0..5) {
                out[i++] = (steps[r] shl 16) or (steps[g] shl 8) or steps[b]
            }
            for (gray in 0..23) {
                val v = 8 + gray * 10
                out[i++] = (v shl 16) or (v shl 8) or v
            }
            return out
        }
    }
}
