package com.puttydroid.terminal

/**
 * Streaming VT100/ANSI/xterm control-sequence parser.
 *
 * PuTTY source reference: terminal.c's `term_out()` is one big function with
 * a `switch (term->termstate)` over the enum `{TOPLEVEL, SEEN_ESC, SEEN_CSI,
 * SEEN_OSC, SEEN_OSC_P, SEEN_OSC_W, DO_CTRLS, SEEN_OSC_57, ...}` (see the
 * enum near the top of terminal.c and the dispatch starting around line
 * 3571 in PuTTY 0.74). We reproduce the same state-machine *shape*
 * (ground/escape/CSI/OSC states, parameter accumulation, final-byte
 * dispatch) as a standalone class with no PuTTY C code copied - this is a
 * clean-room reimplementation of the documented ECMA-48 / DEC / xterm
 * control-sequence grammar that PuTTY also implements, informed by reading
 * terminal.c's dispatch tables rather than by mechanical translation (see
 * requirement 19/30: behavioural compatibility via understanding, not a
 * line-by-line port).
 *
 * ## Coverage (see docs/ARCHITECTURE.md "Terminal parser coverage" for the
 * authoritative, maintained list - this docstring gives the shape only):
 *  - C0 controls: BEL, BS, HT, LF/VT/FF, CR, SO, SI, ESC
 *  - ESC sequences: 7/8 (DECSC/DECRC), D/E/M (IND/NEL/RI), H (HTS), c (RIS),
 *    =/> (DECPAM/DECPNM), ( ) charset select (ASCII / DEC special graphics),
 *    # 8 (DECALN)
 *  - CSI: cursor movement (A B C D E F G H f), erase (J K), insert/delete
 *    char & line (@ P L M), scroll (S T), ECH (X), tabs (g Z), SGR (m),
 *    modes (h l, both ANSI and DEC private `?`), DECSTBM (r), save/restore
 *    cursor (s u), DSR/CPR (n), DA (c)
 *  - OSC: 0/1/2 (window/icon title) — others are consumed and discarded,
 *    not silently mis-rendered as literal text
 *
 * Known gaps vs. real PuTTY (tracked, not hidden - see ARCHITECTURE.md):
 * DECDHL/DECDWL double-width/height lines, VT52 mode, SS2/SS3 single
 * shifts, sixel/ReGIS graphics, and exact wcwidth.c-table wide-character
 * detection (we use a reasonable approximation, see `isWideChar`).
 */
class TerminalParser(private val state: TerminalState) {

    /** Called with raw bytes the terminal wants to send back to the connection
     *  (DSR/CPR/DA replies). The connection layer is responsible for writing these out. */
    var onResponse: ((ByteArray) -> Unit)? = null
    var onBell: (() -> Unit)? = null
    var onTitleChange: ((String) -> Unit)? = null

    private enum class Mode { GROUND, ESCAPE, ESCAPE_HASH, CHARSET_G0, CHARSET_G1, CSI, OSC, OSC_ESC }

    private var mode = Mode.GROUND
    private val utf8 = Utf8Decoder()

    // --- CSI accumulation ---
    private var csiPrivateMarker: Char? = null
    private val csiParams = ArrayList<Int?>()
    private var csiParamBuf = StringBuilder()
    private var csiParamStarted = false
    private val csiIntermediates = StringBuilder()

    // --- OSC accumulation ---
    private val oscBuf = StringBuilder()

    private val buffer get() = state.buffer
    private val modes get() = state.modes

    /** Feed a chunk of raw connection bytes (may split a UTF-8 codepoint or an escape
     *  sequence across calls - both are handled correctly via retained parser state,
     *  matching PuTTY's requirement that `term_out` cope with arbitrary read() chunking). */
    fun feed(bytes: ByteArray, length: Int = bytes.size) {
        val chars = if (modes.utf8) {
            utf8.decode(bytes, length)
        } else {
            (0 until length).map { i -> (bytes[i].toInt() and 0xFF).toChar() }
        }
        for (c in chars) processChar(c)
    }

    private fun processChar(c: Char) {
        when (mode) {
            Mode.GROUND -> processGround(c)
            Mode.ESCAPE -> processEscape(c)
            Mode.ESCAPE_HASH -> processEscapeHash(c)
            Mode.CHARSET_G0 -> { modes.g0SpecialGraphics = (c == '0'); mode = Mode.GROUND }
            Mode.CHARSET_G1 -> { modes.g1SpecialGraphics = (c == '0'); mode = Mode.GROUND }
            Mode.CSI -> processCsi(c)
            Mode.OSC -> processOsc(c)
            Mode.OSC_ESC -> {
                if (c == '\\') finishOsc() else { finishOsc(); mode = Mode.GROUND; processChar(c) }
            }
        }
    }

    private fun processGround(c: Char) {
        when (c.code) {
            0x00 -> {} // NUL, ignore
            0x07 -> onBell?.invoke() // BEL
            0x08 -> state.backspace() // BS
            0x09 -> state.tab() // HT
            0x0A, 0x0B, 0x0C -> { // LF, VT, FF
                state.lineFeed()
                if (modes.lineFeedNewLineMode) state.carriageReturn()
            }
            0x0D -> state.carriageReturn() // CR
            0x0E -> modes.usingG1 = true  // SO
            0x0F -> modes.usingG1 = false // SI
            0x1B -> { mode = Mode.ESCAPE }
            0x7F -> {} // DEL, ignore (matches PuTTY's default compat handling)
            else -> if (c.code >= 0x20) putPrintable(c)
        }
    }

    private fun putPrintable(c: Char) {
        val specialGraphics = if (modes.usingG1) modes.g1SpecialGraphics else modes.g0SpecialGraphics
        val mapped = if (specialGraphics) mapDecSpecialGraphics(c) else c
        val width = if (isWideChar(mapped.code)) 2 else 1
        state.putChar(mapped, width = width)
    }

    /** DEC Special Graphics charset ("line drawing") mapping for the printable ASCII
     *  range PuTTY maps under `ESC ( 0` (see terminal.c's `unitab_xterm_std` table). */
    private fun mapDecSpecialGraphics(c: Char): Char = when (c) {
        'j' -> '\u2518'; 'k' -> '\u2510'; 'l' -> '\u250C'; 'm' -> '\u2514'
        'n' -> '\u253C'; 'q' -> '\u2500'; 't' -> '\u251C'; 'u' -> '\u2524'
        'v' -> '\u2534'; 'w' -> '\u252C'; 'x' -> '\u2502'; 'a' -> '\u2592'
        '`' -> '\u25C6'; 'f' -> '\u00B0'; 'g' -> '\u00B1'; '~' -> '\u00B7'
        '_' -> ' '
        else -> c
    }

    private fun isWideChar(cp: Int): Boolean {
        // Approximate East-Asian-Wide / Wide ranges (CJK, Hangul, fullwidth forms).
        // Not a byte-for-byte port of PuTTY's wcwidth.c table - see class docs.
        return (cp in 0x1100..0x115F) || (cp in 0x2E80..0xA4CF) || (cp in 0xAC00..0xD7A3) ||
            (cp in 0xF900..0xFAFF) || (cp in 0xFF00..0xFF60) || (cp in 0xFFE0..0xFFE6) ||
            (cp in 0x20000..0x3FFFD)
    }

    private fun processEscape(c: Char) {
        when (c) {
            '[' -> { resetCsi(); mode = Mode.CSI }
            ']' -> { oscBuf.setLength(0); mode = Mode.OSC }
            '(' -> mode = Mode.CHARSET_G0
            ')' -> mode = Mode.CHARSET_G1
            '#' -> mode = Mode.ESCAPE_HASH
            '7' -> { state.saveCursor(); mode = Mode.GROUND }
            '8' -> { state.restoreCursor(); mode = Mode.GROUND }
            'D' -> { state.lineFeed(); mode = Mode.GROUND }
            'E' -> { state.carriageReturn(); state.lineFeed(); mode = Mode.GROUND }
            'M' -> { state.reverseIndex(); mode = Mode.GROUND }
            'H' -> { state.setTabStop(); mode = Mode.GROUND }
            'c' -> { fullReset(); mode = Mode.GROUND }
            '=' -> { modes.applicationKeypad = true; mode = Mode.GROUND }
            '>' -> { modes.applicationKeypad = false; mode = Mode.GROUND }
            'N', 'O' -> { mode = Mode.GROUND } // SS2/SS3 - not fully implemented, see class docs
            else -> mode = Mode.GROUND // unrecognised ESC sequence: drop back to ground
        }
    }

    private fun processEscapeHash(c: Char) {
        if (c == '8') fillScreenWithE() // DECALN
        mode = Mode.GROUND
    }

    private fun fillScreenWithE() {
        for (r in 0 until buffer.rows) for (col in 0 until buffer.columns) {
            buffer.setCell(r, col, TerminalCell(char = 'E'))
        }
    }

    private fun resetCsi() {
        csiPrivateMarker = null
        csiParams.clear()
        csiParamBuf.setLength(0)
        csiParamStarted = false
        csiIntermediates.setLength(0)
    }

    private fun processCsi(c: Char) {
        when {
            c.code in 0x30..0x39 -> { csiParamBuf.append(c); csiParamStarted = true } // digit
            c == ';' || c == ':' -> { pushCsiParam(); }
            (c == '?' || c == '>' || c == '=' || c == '<') && csiParams.isEmpty() && !csiParamStarted ->
                csiPrivateMarker = c
            c.code in 0x20..0x2F -> csiIntermediates.append(c) // intermediate byte
            c.code in 0x40..0x7E -> { // final byte
                pushCsiParam()
                val final = c
                mode = Mode.GROUND
                dispatchCsi(final)
            }
            c == '\u0018' || c == '\u001A' -> mode = Mode.GROUND // CAN/SUB abort
            c == '\u001B' -> { mode = Mode.ESCAPE } // ESC aborts CSI, starts new sequence
            else -> { /* ignore stray byte */ }
        }
    }

    private fun pushCsiParam() {
        csiParams.add(if (csiParamBuf.isEmpty()) null else csiParamBuf.toString().toIntOrNull())
        csiParamBuf.setLength(0)
        csiParamStarted = true
    }

    private fun p(params: List<Int?>, i: Int, default: Int): Int = params.getOrNull(i) ?: default

    private fun processOsc(c: Char) {
        when (c.code) {
            0x07 -> finishOsc()
            0x1B -> mode = Mode.OSC_ESC
            else -> oscBuf.append(c)
        }
    }

    private fun finishOsc() {
        mode = Mode.GROUND
        val text = oscBuf.toString()
        oscBuf.setLength(0)
        val semi = text.indexOf(';')
        if (semi < 0) return
        val ps = text.substring(0, semi).toIntOrNull() ?: return
        val pt = text.substring(semi + 1)
        when (ps) {
            0, 1, 2 -> onTitleChange?.invoke(pt) // icon+title / icon / window title
            // 4 (palette set), 52 (clipboard), 104 (palette reset), etc: recognised-but-not-
            // wired-up OSCs are intentionally consumed and dropped here rather than leaking
            // into the visible screen as text - see ARCHITECTURE.md.
            else -> {}
        }
    }

    private fun respond(text: String) {
        onResponse?.invoke(text.toByteArray(Charsets.US_ASCII))
    }

    private fun dispatchCsi(final: Char) {
        val params = csiParams
        val priv = csiPrivateMarker
        when (final) {
            'A' -> state.moveTo(state.cursorRow - p(params, 0, 1).coerceAtLeast(1), state.cursorCol, true)
            'B' -> state.moveTo(state.cursorRow + p(params, 0, 1).coerceAtLeast(1), state.cursorCol, true)
            'C' -> state.moveTo(state.cursorRow, state.cursorCol + p(params, 0, 1).coerceAtLeast(1))
            'D' -> state.moveTo(state.cursorRow, state.cursorCol - p(params, 0, 1).coerceAtLeast(1))
            'E' -> state.moveTo(state.cursorRow + p(params, 0, 1).coerceAtLeast(1), 0, true)
            'F' -> state.moveTo(state.cursorRow - p(params, 0, 1).coerceAtLeast(1), 0, true)
            'G', '`' -> state.moveTo(state.cursorRow, p(params, 0, 1) - 1)
            'd' -> state.moveTo(p(params, 0, 1) - 1, state.cursorCol, true)
            'H', 'f' -> state.cursorPosition(p(params, 0, 1), p(params, 1, 1))
            'J' -> eraseInDisplay(p(params, 0, 0))
            'K' -> eraseInLine(p(params, 0, 0))
            'L' -> buffer.insertBlankLines(state.cursorRow, state.scrollBottom, p(params, 0, 1).coerceAtLeast(1))
            'M' -> buffer.deleteLines(state.cursorRow, state.scrollBottom, p(params, 0, 1).coerceAtLeast(1))
            '@' -> buffer.insertBlankChars(state.cursorRow, state.cursorCol, p(params, 0, 1).coerceAtLeast(1))
            'P' -> buffer.deleteChars(state.cursorRow, state.cursorCol, p(params, 0, 1).coerceAtLeast(1))
            'X' -> buffer.eraseRow(
                state.cursorRow, state.cursorCol,
                state.cursorCol + p(params, 0, 1).coerceAtLeast(1) - 1
            )
            'S' -> buffer.scrollRegionUp(state.scrollTop, state.scrollBottom, p(params, 0, 1).coerceAtLeast(1))
            'T' -> buffer.scrollRegionDown(state.scrollTop, state.scrollBottom, p(params, 0, 1).coerceAtLeast(1))
            'Z' -> repeat(p(params, 0, 1).coerceAtLeast(1)) { /* CBT: back-tab, minor feature */ }
            'g' -> when (p(params, 0, 0)) { 0 -> state.clearTabStop(); 3 -> state.clearAllTabStops() }
            'm' -> applySgr(params)
            'r' -> state.setScrollMargins(p(params, 0, 1), p(params, 1, buffer.rows))
            's' -> if (priv == null) state.saveCursor()
            'u' -> if (priv == null) state.restoreCursor()
            'n' -> when (p(params, 0, 0)) {
                5 -> respond("\u001B[0n")
                6 -> respond("\u001B[${state.cursorRow + 1};${state.cursorCol + 1}R")
            }
            'c' -> if (priv == null) respond("\u001B[?1;2c") // DA: VT100 w/ AVO, approximate
            'h' -> setModes(params, priv, true)
            'l' -> setModes(params, priv, false)
            else -> { /* unrecognised final byte: sequence consumed and dropped, not mis-rendered */ }
        }
    }

    private fun eraseInDisplay(mode0: Int) {
        val row = state.cursorRow
        when (mode0) {
            0 -> {
                buffer.eraseRow(row, state.cursorCol, buffer.columns - 1)
                for (r in row + 1 until buffer.rows) buffer.eraseRow(r)
            }
            1 -> {
                for (r in 0 until row) buffer.eraseRow(r)
                buffer.eraseRow(row, 0, state.cursorCol)
            }
            2, 3 -> for (r in 0 until buffer.rows) buffer.eraseRow(r)
        }
    }

    private fun eraseInLine(mode0: Int) {
        val row = state.cursorRow
        when (mode0) {
            0 -> buffer.eraseRow(row, state.cursorCol, buffer.columns - 1)
            1 -> buffer.eraseRow(row, 0, state.cursorCol)
            2 -> buffer.eraseRow(row)
        }
    }

    private fun applySgr(params: List<Int?>) {
        if (params.isEmpty()) { state.pen = Pen(); return }
        var i = 0
        var pen = state.pen
        while (i < params.size) {
            val n = params[i] ?: 0
            when (n) {
                0 -> pen = Pen()
                1 -> pen = pen.copy(bold = true)
                2 -> pen = pen.copy(dim = true)
                3 -> pen = pen.copy(italic = true)
                4 -> pen = pen.copy(underline = true)
                5, 6 -> pen = pen.copy(blink = true)
                7 -> pen = pen.copy(reverse = true)
                8 -> pen = pen.copy(invisible = true)
                9 -> pen = pen.copy(strikethrough = true)
                21 -> pen = pen.copy(bold = false)
                22 -> pen = pen.copy(bold = false, dim = false)
                23 -> pen = pen.copy(italic = false)
                24 -> pen = pen.copy(underline = false)
                25 -> pen = pen.copy(blink = false)
                27 -> pen = pen.copy(reverse = false)
                28 -> pen = pen.copy(invisible = false)
                29 -> pen = pen.copy(strikethrough = false)
                in 30..37 -> pen = pen.copy(fg = TerminalColor.Ansi16(n - 30))
                38 -> { val (newPen, consumed) = extendedColor(params, i, pen, foreground = true); pen = newPen; i += consumed }
                39 -> pen = pen.copy(fg = TerminalColor.Default)
                in 40..47 -> pen = pen.copy(bg = TerminalColor.Ansi16(n - 40))
                48 -> { val (newPen, consumed) = extendedColor(params, i, pen, foreground = false); pen = newPen; i += consumed }
                49 -> pen = pen.copy(bg = TerminalColor.Default)
                in 90..97 -> pen = pen.copy(fg = TerminalColor.Ansi16(n - 90 + 8))
                in 100..107 -> pen = pen.copy(bg = TerminalColor.Ansi16(n - 100 + 8))
                else -> {}
            }
            i++
        }
        state.pen = pen
    }

    /** Parses `38;5;N` / `38;2;R;G;B` (and the 48;... background equivalents) starting at
     *  index `i` (which points at the 38/48 itself). Returns the updated pen and how many
     *  *extra* params (beyond the 38/48 itself) were consumed, so the caller's main loop
     *  index can skip over them. */
    private fun extendedColor(params: List<Int?>, i: Int, pen: Pen, foreground: Boolean): Pair<Pen, Int> {
        val kind = params.getOrNull(i + 1) ?: return pen to 0
        return when (kind) {
            5 -> {
                val idx = (params.getOrNull(i + 2) ?: 0).coerceIn(0, 255)
                val color = TerminalColor.Indexed256(idx)
                (if (foreground) pen.copy(fg = color) else pen.copy(bg = color)) to 2
            }
            2 -> {
                val r = (params.getOrNull(i + 2) ?: 0).coerceIn(0, 255)
                val g = (params.getOrNull(i + 3) ?: 0).coerceIn(0, 255)
                val b = (params.getOrNull(i + 4) ?: 0).coerceIn(0, 255)
                val color = TerminalColor.TrueColor(r, g, b)
                (if (foreground) pen.copy(fg = color) else pen.copy(bg = color)) to 4
            }
            else -> pen to 1
        }
    }

    private fun setModes(params: List<Int?>, priv: Char?, set: Boolean) {
        for (raw in params) {
            val n = raw ?: continue
            if (priv == '?') setDecPrivateMode(n, set) else setAnsiMode(n, set)
        }
    }

    private fun setAnsiMode(n: Int, set: Boolean) {
        when (n) {
            4 -> modes.insertMode = set   // IRM
            20 -> modes.lineFeedNewLineMode = set // LNM
        }
    }

    private fun setDecPrivateMode(n: Int, set: Boolean) {
        when (n) {
            1 -> modes.applicationCursorKeys = set // DECCKM
            5 -> modes.reverseVideoScreen = set    // DECSCNM
            6 -> { modes.originMode = set; state.cursorPosition(1, 1) } // DECOM
            7 -> modes.autoWrap = set              // DECAWM
            12 -> modes.cursorBlinks = set
            25 -> modes.cursorVisible = set         // DECTCEM
            47 -> if (set) buffer.switchToAlternate(wipe = true) else buffer.switchToPrimary()
            1000 -> modes.mouseTracking = if (set) MouseTrackingMode.NORMAL else MouseTrackingMode.OFF
            1002 -> modes.mouseTracking = if (set) MouseTrackingMode.BUTTON_EVENT else MouseTrackingMode.OFF
            1003 -> modes.mouseTracking = if (set) MouseTrackingMode.ANY_EVENT else MouseTrackingMode.OFF
            1005 -> modes.mouseEncoding = if (set) MouseEncoding.UTF8 else MouseEncoding.X10
            1006 -> modes.mouseEncoding = if (set) MouseEncoding.SGR else MouseEncoding.X10
            1015 -> modes.mouseEncoding = if (set) MouseEncoding.URXVT else MouseEncoding.X10
            1047 -> if (set) buffer.switchToAlternate(wipe = true) else buffer.switchToPrimary()
            1048 -> if (set) state.saveCursor() else state.restoreCursor()
            1049 -> if (set) {
                state.saveCursorForAltScreen()
                buffer.switchToAlternate(wipe = true)
            } else {
                buffer.switchToPrimary()
                state.restoreCursorForAltScreen()
            }
            2004 -> modes.bracketedPaste = set
        }
    }

    private fun fullReset() {
        modes.insertMode = false
        modes.lineFeedNewLineMode = false
        modes.applicationCursorKeys = false
        modes.autoWrap = true
        modes.reverseVideoScreen = false
        modes.originMode = false
        modes.applicationKeypad = false
        modes.cursorVisible = true
        modes.bracketedPaste = false
        modes.mouseTracking = MouseTrackingMode.OFF
        modes.g0SpecialGraphics = false
        modes.g1SpecialGraphics = false
        modes.usingG1 = false
        buffer.switchToPrimary()
        buffer.clearAll()
        state.pen = Pen()
        state.resetDefaultTabStops()
        state.resetScrollMarginsForResize()
        state.cursorPosition(1, 1)
    }
}
