package com.puttydroid.terminal

/** Keys that need special-key byte sequences rather than plain character input. */
enum class TerminalKey {
    UP, DOWN, LEFT, RIGHT, HOME, END, INSERT, DELETE, PAGE_UP, PAGE_DOWN,
    F1, F2, F3, F4, F5, F6, F7, F8, F9, F10, F11, F12,
    ESCAPE, TAB, BACKSPACE, ENTER
}

data class KeyModifiers(val shift: Boolean = false, val ctrl: Boolean = false, val alt: Boolean = false)

/**
 * Encodes keys into the exact bytes a real terminal application expects on
 * the wire (requirement 9: "keyboard mappings must be implemented according
 * to the terminal mode rather than using arbitrary Android key behavior").
 *
 * PuTTY source reference: `format_function_key()` and
 * `format_small_keypad_key()` in terminal.c (read directly, see
 * docs/ARCHITECTURE.md). Critically, PuTTY's *default* function-key mode is
 * `FUNKY_TILDE` (`CONF_funky_type` defaults to 0 - see settings.c
 * `gppi(..., "LinuxFunctionKeys", 0, ...)` and the `FUNKY_TILDE` enum value
 * in putty.h), which sends `ESC[11~`..`ESC[24~` for F1-F12 - *not* the
 * `ESC O P/Q/R/S` SS3 sequences xterm sends for F1-F4 by default. Getting
 * this wrong is exactly the kind of superficial-knowledge mistake
 * requirement 30 warns about, so `keyNumberToTildeCode` below is transcribed
 * directly from PuTTY's `key_number_to_tilde_code` table rather than from
 * general terminal-emulator knowledge. Other funky_type styles (xterm-R6,
 * Linux console, VT400, SCO, VT100+) are documented in ARCHITECTURE.md as a
 * follow-up (same source table, just not wired to a settings toggle yet).
 */
object TerminalKeyEncoder {

    private val ESC = byteArrayOf(0x1B)

    // PuTTY terminal.c: key_number_to_tilde_code[]. Index 0 unused (no F0).
    private val keyNumberToTildeCode = intArrayOf(
        -1, 11, 12, 13, 14, 15, 17, 18, 19, 20, 21, 23, 24, 25, 26, 28, 29, 31, 32, 33, 34
    )

    private fun functionKeyNumber(key: TerminalKey): Int = when (key) {
        TerminalKey.F1 -> 1; TerminalKey.F2 -> 2; TerminalKey.F3 -> 3; TerminalKey.F4 -> 4
        TerminalKey.F5 -> 5; TerminalKey.F6 -> 6; TerminalKey.F7 -> 7; TerminalKey.F8 -> 8
        TerminalKey.F9 -> 9; TerminalKey.F10 -> 10; TerminalKey.F11 -> 11; TerminalKey.F12 -> 12
        else -> error("not a function key: $key")
    }

    /** Encode a special key given the terminal's current mode flags. Returns the raw bytes
     *  to write to the connection, or null if this key produces no output on its own
     *  (callers should fall back to plain character input for anything not listed here). */
    fun encode(key: TerminalKey, mods: KeyModifiers, modes: TerminalModes): ByteArray {
        val body: ByteArray = when (key) {
            TerminalKey.UP -> arrow('A', modes)
            TerminalKey.DOWN -> arrow('B', modes)
            TerminalKey.RIGHT -> arrow('C', modes)
            TerminalKey.LEFT -> arrow('D', modes)

            TerminalKey.HOME -> tilde(1)
            TerminalKey.INSERT -> tilde(2)
            TerminalKey.DELETE -> tilde(3)
            TerminalKey.END -> tilde(4)
            TerminalKey.PAGE_UP -> tilde(5)
            TerminalKey.PAGE_DOWN -> tilde(6)

            TerminalKey.F1, TerminalKey.F2, TerminalKey.F3, TerminalKey.F4,
            TerminalKey.F5, TerminalKey.F6, TerminalKey.F7, TerminalKey.F8,
            TerminalKey.F9, TerminalKey.F10, TerminalKey.F11, TerminalKey.F12 -> {
                val n = functionKeyNumber(key)
                val index = if (mods.shift && n <= 10) n + 10 else n
                tilde(keyNumberToTildeCode[index])
            }

            TerminalKey.ESCAPE -> ESC
            TerminalKey.TAB -> if (mods.shift) "\u001B[Z".toAscii() else byteArrayOf(0x09)
            TerminalKey.BACKSPACE -> byteArrayOf(0x7F) // PuTTY default: Backspace sends ^?
            TerminalKey.ENTER -> byteArrayOf(0x0D)
        }
        return if (mods.alt && key != TerminalKey.ESCAPE) concat(ESC, body) else body
    }

    private fun arrow(letter: Char, modes: TerminalModes): ByteArray =
        if (modes.applicationCursorKeys) "\u001BO$letter".toAscii() else "\u001B[$letter".toAscii()

    private fun tilde(code: Int): ByteArray = "\u001B[$code~".toAscii()

    /** Plain printable character input, honouring Ctrl and Alt. PuTTY source: `term_key()`
     *  in terminal.c computes the control code as `c & 0x1F` for Ctrl+letter (and a handful
     *  of punctuation keys per the standard C0 layout); Alt is "meta sends escape" by
     *  default (PuTTY: `CONF_alt_only` / ESC-prefixing behaviour in the Windows front end). */
    fun encodeChar(c: Char, mods: KeyModifiers): ByteArray {
        val base: ByteArray = if (mods.ctrl) {
            val upper = c.uppercaseChar()
            when {
                upper in 'A'..'_' -> byteArrayOf((upper.code and 0x1F).toByte())
                upper == '?' -> byteArrayOf(0x7F.toByte())
                else -> c.toString().toByteArray(Charsets.UTF_8)
            }
        } else {
            c.toString().toByteArray(Charsets.UTF_8)
        }
        return if (mods.alt) concat(ESC, base) else base
    }

    /** Application-keypad digit/operator encoding (PuTTY: `format_numeric_keypad_key()`).
     *  Only used when `modes.applicationKeypad` is set; callers should otherwise send the
     *  character itself. */
    fun encodeKeypadDigit(digit: Char, modes: TerminalModes): ByteArray {
        if (!modes.applicationKeypad) return digit.toString().toByteArray(Charsets.US_ASCII)
        val xkey = when (digit) {
            '0' -> 'p'; '1' -> 'q'; '2' -> 'r'; '3' -> 's'; '4' -> 't'
            '5' -> 'u'; '6' -> 'v'; '7' -> 'w'; '8' -> 'x'; '9' -> 'y'
            '.' -> 'n'; '\r' -> 'M'; '+' -> 'k'; '-' -> 'm'; '*' -> 'j'; '/' -> 'o'
            else -> return digit.toString().toByteArray(Charsets.US_ASCII)
        }
        return "\u001BO$xkey".toAscii()
    }

    private fun String.toAscii(): ByteArray = toByteArray(Charsets.US_ASCII)
    private fun concat(a: ByteArray, b: ByteArray): ByteArray =
        ByteArray(a.size + b.size).also { System.arraycopy(a, 0, it, 0, a.size); System.arraycopy(b, 0, it, a.size, b.size) }
}
