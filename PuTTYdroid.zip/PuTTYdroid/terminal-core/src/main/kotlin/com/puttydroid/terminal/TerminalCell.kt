package com.puttydroid.terminal

/**
 * A single character cell on the terminal grid.
 *
 * PuTTY source reference: `termchar` in terminal.h, which packs a Unicode
 * codepoint (`chr`), a combining-character chain pointer, and a 64-bit
 * `attr` word (colours + SGR bits) into one struct-of-arrays entry per
 * screen line (see `termline` / `resizeline` in terminal.c). We use one
 * class per cell for JVM clarity; TerminalBuffer stores cells in flat
 * Array<TerminalCell> rows, which the renderer can diff cheaply.
 *
 * `width` mirrors PuTTY's CSET/wide-character handling (see wcwidth.c,
 * ATTR_WIDE / the second, "shadow" cell PuTTY inserts after a wide
 * character in `term_out`'s UTF-8 codepath): 1 for a normal cell, 2 for
 * the leading cell of a double-width CJK character, 0 for the trailing
 * "shadow" cell that must not be painted.
 */
data class TerminalCell(
    val char: Char = ' ',
    val fg: TerminalColor = TerminalColor.Default,
    val bg: TerminalColor = TerminalColor.Default,
    val bold: Boolean = false,
    val dim: Boolean = false,
    val italic: Boolean = false,
    val underline: Boolean = false,
    val blink: Boolean = false,
    val reverse: Boolean = false,
    val strikethrough: Boolean = false,
    val invisible: Boolean = false,
    /** Combining characters applied on top of `char` (accents, etc.) - PuTTY chains these
     *  off the base termchar rather than allocating a new cell (see term_out's combining
     *  character handling, guarded by `has_compat` / unicode composition). */
    val combining: List<Char> = emptyList(),
    val width: Int = 1
) {
    companion object {
        val BLANK = TerminalCell()
        /** The invisible trailing half of a double-width character. Renderer must skip it. */
        val WIDE_SHADOW = TerminalCell(char = '\u0000', width = 0)
    }
}
