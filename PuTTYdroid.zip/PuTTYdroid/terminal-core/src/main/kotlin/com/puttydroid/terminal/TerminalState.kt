package com.puttydroid.terminal

/** Snapshot of cursor position + pen (SGR) + charset state, for DECSC/DECRC (`ESC 7` / `ESC 8`)
 *  and for the implicit save/restore xterm does around the alternate-screen switch (?1049).
 *  PuTTY source: terminal.c `struct savedcursor` / `save_cursor()`. */
data class SavedCursor(
    val row: Int,
    val col: Int,
    val pen: Pen,
    val originMode: Boolean,
    val g0SpecialGraphics: Boolean,
    val g1SpecialGraphics: Boolean,
    val usingG1: Boolean,
    val wrapPending: Boolean
)

/** The current "pen": the SGR attributes that will be applied to the next character written.
 *  PuTTY source: terminal.c `term->curr_attr` (a packed attr word); we spell it out as a
 *  data class instead of packed bits for the same testability reasons as TerminalColor. */
data class Pen(
    val fg: TerminalColor = TerminalColor.Default,
    val bg: TerminalColor = TerminalColor.Default,
    val bold: Boolean = false,
    val dim: Boolean = false,
    val italic: Boolean = false,
    val underline: Boolean = false,
    val blink: Boolean = false,
    val reverse: Boolean = false,
    val strikethrough: Boolean = false,
    val invisible: Boolean = false
) {
    fun toCell(char: Char, combining: List<Char> = emptyList(), width: Int = 1) = TerminalCell(
        char = char, fg = fg, bg = bg, bold = bold, dim = dim, italic = italic,
        underline = underline, blink = blink, reverse = reverse,
        strikethrough = strikethrough, invisible = invisible,
        combining = combining, width = width
    )
}

/**
 * All mutable terminal state that isn't the character grid itself: cursor
 * position, the current pen, scroll margins, tab stops, and the saved-cursor
 * stack. Deliberately has zero Android/UI dependencies (constructor requires
 * only a TerminalBuffer + TerminalModes) so it can be unit tested exactly as
 * required by the architecture spec ("terminal state should be testable
 * independently").
 *
 * PuTTY source reference: the bulk of `struct terminal_tag` in terminal.h
 * (curs.x/curs.y, marg_t/marg_b, tabs[], curr_attr, savecurs) and the
 * cursor-movement helper functions in terminal.c (`move()`, `set_erase_char()`,
 * `save_cursor()`, `restore_cursor()`).
 */
class TerminalState(
    val buffer: TerminalBuffer,
    val modes: TerminalModes = TerminalModes()
) {
    var cursorRow: Int = 0
        private set
    var cursorCol: Int = 0
        private set

    /** True right after writing into the last column, before the *next* printable char
     *  actually wraps - PuTTY's "delayed wrap" (`term->wrapnext`), which is what makes
     *  writing exactly N characters into an N-column terminal not leave a blank line. */
    var wrapPending: Boolean = false
        private set

    var pen: Pen = Pen()

    var scrollTop: Int = 0
        private set
    var scrollBottom: Int = buffer.rows - 1
        private set

    private var tabStops: BooleanArray = defaultTabStops(buffer.columns)

    private fun defaultTabStops(columns: Int): BooleanArray =
        BooleanArray(columns).also { arr -> for (c in arr.indices step 8) arr[c] = true }

    private var savedCursor: SavedCursor? = null
    /** Separate save slot for the ?1049 alt-screen switch, which PuTTY keeps distinct
     *  from the DECSC/DECRC slot (see terminal.c `toggle_mode` case 1049). */
    private var altScreenSavedCursor: SavedCursor? = null

    fun moveTo(row: Int, col: Int, clampToMargins: Boolean = false) {
        wrapPending = false
        val minRow = if (clampToMargins && modes.originMode) scrollTop else 0
        val maxRow = if (clampToMargins && modes.originMode) scrollBottom else buffer.rows - 1
        cursorRow = row.coerceIn(minRow, maxRow)
        cursorCol = col.coerceIn(0, buffer.columns - 1)
    }

    /** Origin-mode-aware move used by CUP/HVP (`CSI r;c H`), which interpret row/col
     *  relative to the scroll region when DECOM is set. PuTTY: terminal.c `move()`. */
    fun cursorPosition(row1Based: Int, col1Based: Int) {
        val base = if (modes.originMode) scrollTop else 0
        val limit = if (modes.originMode) scrollBottom else buffer.rows - 1
        val row = (base + row1Based - 1).coerceIn(base, limit)
        val col = (col1Based - 1).coerceIn(0, buffer.columns - 1)
        wrapPending = false
        cursorRow = row
        cursorCol = col
    }

    fun setScrollMargins(top1Based: Int, bottom1Based: Int) {
        var t = (top1Based - 1).coerceIn(0, buffer.rows - 1)
        var b = (bottom1Based - 1).coerceIn(0, buffer.rows - 1)
        if (t >= b) { t = 0; b = buffer.rows - 1 }
        scrollTop = t
        scrollBottom = b
        // DECSTBM also homes the cursor, per DEC / xterm behaviour (PuTTY terminal.c case 'r').
        cursorPosition(1, 1)
    }

    fun resetScrollMarginsForResize() {
        scrollTop = 0
        scrollBottom = buffer.rows - 1
    }

    /** Write one already-shaped cell at the cursor and advance, handling autowrap exactly
     *  like PuTTY's `term_out` main loop: advance first, and if that runs past the last
     *  column, set `wrapPending` instead of moving to the next row immediately - the actual
     *  wrap happens lazily on the *next* printable character (see `term->wrapnext` in
     *  terminal.c), which is what prevents an extra blank line when output exactly fills
     *  a row. */
    fun putChar(char: Char, combining: List<Char> = emptyList(), width: Int = 1) {
        if (wrapPending) {
            performWrap()
        }
        if (modes.insertMode) {
            buffer.insertBlankChars(cursorRow, cursorCol, width)
        }
        buffer.setCell(cursorRow, cursorCol, pen.toCell(char, combining, width))
        if (width == 2 && cursorCol + 1 < buffer.columns) {
            buffer.setCell(cursorRow, cursorCol + 1, TerminalCell.WIDE_SHADOW)
        }
        if (cursorCol + width >= buffer.columns) {
            if (modes.autoWrap) {
                wrapPending = true
                cursorCol = buffer.columns - 1
            } else {
                cursorCol = buffer.columns - 1
            }
        } else {
            cursorCol += width
        }
    }

    private fun performWrap() {
        wrapPending = false
        if (cursorRow == scrollBottom) {
            buffer.scrollRegionUp(scrollTop, scrollBottom, 1)
        } else if (cursorRow < buffer.rows - 1) {
            cursorRow += 1
        }
        cursorCol = 0
    }

    /** Line feed / index (LF, VT, FF, or ESC D). PuTTY: terminal.c `case '\n':` and `index()`. */
    fun lineFeed() {
        wrapPending = false
        if (cursorRow == scrollBottom) {
            buffer.scrollRegionUp(scrollTop, scrollBottom, 1)
        } else if (cursorRow < buffer.rows - 1) {
            cursorRow += 1
        }
    }

    /** Reverse index (ESC M). PuTTY: terminal.c `case 'M':` under SEEN_ESC. */
    fun reverseIndex() {
        wrapPending = false
        if (cursorRow == scrollTop) {
            buffer.scrollRegionDown(scrollTop, scrollBottom, 1)
        } else if (cursorRow > 0) {
            cursorRow -= 1
        }
    }

    fun carriageReturn() {
        wrapPending = false
        cursorCol = 0
    }

    fun backspace() {
        wrapPending = false
        if (cursorCol > 0) cursorCol -= 1
    }

    fun tab() {
        wrapPending = false
        var c = cursorCol + 1
        while (c < buffer.columns - 1 && !tabStops[c]) c++
        cursorCol = c.coerceAtMost(buffer.columns - 1)
    }

    fun setTabStop() { if (cursorCol in tabStops.indices) tabStops[cursorCol] = true }
    fun clearTabStop() { if (cursorCol in tabStops.indices) tabStops[cursorCol] = false }
    fun clearAllTabStops() { tabStops.fill(false) }
    /** Restore the default every-8-columns tab stops, used by RIS (full reset, `ESC c`). */
    fun resetDefaultTabStops() {
        tabStops = defaultTabStops(buffer.columns)
    }

    fun saveCursor() {
        savedCursor = SavedCursor(
            cursorRow, cursorCol, pen, modes.originMode,
            modes.g0SpecialGraphics, modes.g1SpecialGraphics, modes.usingG1, wrapPending
        )
    }

    fun restoreCursor() {
        val s = savedCursor ?: return
        cursorRow = s.row.coerceIn(0, buffer.rows - 1)
        cursorCol = s.col.coerceIn(0, buffer.columns - 1)
        pen = s.pen
        modes.originMode = s.originMode
        modes.g0SpecialGraphics = s.g0SpecialGraphics
        modes.g1SpecialGraphics = s.g1SpecialGraphics
        modes.usingG1 = s.usingG1
        wrapPending = s.wrapPending
    }

    /** Save/restore used specifically around the ?1049 alt-screen switch (distinct slot
     *  from DECSC/DECRC - see class doc). */
    fun saveCursorForAltScreen() {
        altScreenSavedCursor = SavedCursor(
            cursorRow, cursorCol, pen, modes.originMode,
            modes.g0SpecialGraphics, modes.g1SpecialGraphics, modes.usingG1, wrapPending
        )
    }

    fun restoreCursorForAltScreen() {
        val s = altScreenSavedCursor ?: return
        cursorRow = s.row.coerceIn(0, buffer.rows - 1)
        cursorCol = s.col.coerceIn(0, buffer.columns - 1)
        pen = s.pen
        wrapPending = s.wrapPending
    }

    fun onResize(newColumns: Int, newRows: Int) {
        cursorRow = cursorRow.coerceIn(0, newRows - 1)
        cursorCol = cursorCol.coerceIn(0, newColumns - 1)
        scrollTop = 0
        scrollBottom = newRows - 1
        wrapPending = false
        // A resized terminal gets fresh default tab stops (matches typical real-terminal
        // behaviour - PuTTY's `term_size()` likewise reinitialises `term->tabs[]`).
        tabStops = defaultTabStops(newColumns)
    }
}
