package com.puttydroid.terminal

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test

/**
 * Behavioural tests for TerminalEmulator/TerminalParser: input bytes in,
 * terminal state out (requirement 19: "Create automated tests comparing
 * Input bytes -> PuTTY behaviour -> Kotlin terminal behaviour").
 *
 * These test vectors are written against the documented ECMA-48/DEC/xterm
 * control-sequence semantics that PuTTY 0.74's terminal.c implements (traced
 * in TerminalParser's class doc), not against a PuTTY binary - there is no
 * PuTTY executable available in this build environment to diff against
 * directly. Wiring an actual PuTTY-vs-Kotlin differential test harness
 * (e.g. driving `windows/putty.exe` or a Linux PuTTY build headlessly and
 * comparing screen dumps) is listed as a follow-up in ARCHITECTURE.md.
 */
class TerminalParserTest {

    private fun emulator(cols: Int = 10, rows: Int = 4) = TerminalEmulator(cols, rows)
    private fun TerminalEmulator.feedStr(s: String) = feed(s.toByteArray(Charsets.UTF_8))
    private fun TerminalEmulator.text(row: Int): String =
        (0 until columns).map { c -> cell(row, c).char }.joinToString("").trimEnd(' ')

    @Test
    fun `plain characters are written left to right`() {
        val t = emulator()
        t.feedStr("hi")
        assertEquals("hi", t.text(0))
        assertEquals(0, t.cursorRow)
        assertEquals(2, t.cursorCol)
    }

    @Test
    fun `carriage return and line feed behave independently`() {
        val t = emulator()
        t.feedStr("ab\r\ncd")
        assertEquals("ab", t.text(0))
        assertEquals("cd", t.text(1))
    }

    @Test
    fun `writing exactly to the last column defers wrap until next char`() {
        val t = emulator(cols = 4, rows = 3)
        t.feedStr("abcd") // exactly fills row 0
        assertEquals(0, t.cursorRow)
        assertEquals("abcd", t.text(0))
        t.feedStr("e") // NOW it should wrap
        assertEquals(1, t.cursorRow)
        assertEquals("e", t.text(1))
    }

    @Test
    fun `cursor position CSI H moves to 1-indexed row and column`() {
        val t = emulator()
        t.feedStr("\u001B[3;5Hx")
        assertEquals(2, t.cursorRow) // 0-indexed
        assertEquals(5, t.cursorCol) // advanced past the written char
        assertEquals('x', t.cell(2, 4).char)
    }

    @Test
    fun `cursor up down forward back move relative to current position`() {
        val t = emulator()
        t.feedStr("\u001B[3;3H") // row 2, col 2 (0-indexed)
        t.feedStr("\u001B[1A"); assertEquals(1, t.cursorRow)
        t.feedStr("\u001B[2B"); assertEquals(3, t.cursorRow)
        t.feedStr("\u001B[2C"); assertEquals(4, t.cursorCol)
        t.feedStr("\u001B[1D"); assertEquals(3, t.cursorCol)
    }

    @Test
    fun `erase in display mode 2 clears the whole screen but not the cursor`() {
        val t = emulator()
        t.feedStr("hello\r\nworld")
        t.feedStr("\u001B[2J")
        assertEquals("", t.text(0))
        assertEquals("", t.text(1))
    }

    @Test
    fun `erase in line mode 0 clears from cursor to end of line only`() {
        val t = emulator()
        t.feedStr("helloworld") // fills all 10 columns; cursor pinned at col 9 (wrap pending)
        t.feedStr("\u001B[4D") // back up 4 columns from col 9, now at col 5 ('w')
        t.feedStr("\u001B[K")
        assertEquals("hello", t.text(0))
    }

    @Test
    fun `sgr bold and 16-color foreground are tracked on the cell`() {
        val t = emulator()
        t.feedStr("\u001B[1;31mX\u001B[0m")
        val cell = t.cell(0, 0)
        assertTrue(cell.bold)
        assertEquals(TerminalColor.Ansi16(1), cell.fg)
    }

    @Test
    fun `sgr reset clears attributes for subsequent characters`() {
        val t = emulator()
        t.feedStr("\u001B[1mA\u001B[0mB")
        assertTrue(t.cell(0, 0).bold)
        assertFalse(t.cell(0, 1).bold)
    }

    @Test
    fun `sgr 256-color and truecolor extended sequences are parsed`() {
        val t = emulator()
        t.feedStr("\u001B[38;5;196mA")
        assertEquals(TerminalColor.Indexed256(196), t.cell(0, 0).fg)
        t.feedStr("\u001B[48;2;10;20;30mB")
        assertEquals(TerminalColor.TrueColor(10, 20, 30), t.cell(0, 1).bg)
    }

    @Test
    fun `insert and delete character shift the rest of the line`() {
        val t = emulator()
        t.feedStr("abcde")
        t.feedStr("\u001B[3D") // cursor at col 2 ('c')
        t.feedStr("\u001B[2P") // delete 2 chars ('c','d')
        assertEquals("abe", t.text(0))
        t.feedStr("\u001B[1@") // insert 1 blank at col 2, pushing 'e' right
        assertEquals("ab e", t.text(0))
    }

    @Test
    fun `scroll region confines scrolling and feeds scrollback only from the physical top`() {
        val t = emulator(cols = 5, rows = 4)
        t.feedStr("\u001B[2;3r") // scroll region = rows 2..3 (1-indexed) -> 0-indexed 1..2
        // Fill all four rows first, positioning manually since DECSTBM homes the cursor.
        t.feedStr("\u001B[1;1Hrow0")
        t.feedStr("\u001B[2;1Hrow1")
        t.feedStr("\u001B[3;1Hrow2")
        t.feedStr("\u001B[4;1Hrow3")
        // Move into the scroll region and force a scroll via linefeed at the region's bottom.
        t.feedStr("\u001B[3;1H\n")
        assertEquals("row0", t.text(0)) // untouched: outside the scroll region
        assertEquals("row2", t.text(1)) // old row2 scrolled up into row1's slot
        assertEquals("", t.text(2))     // new blank line
        assertEquals("row3", t.text(3)) // untouched: outside the scroll region
        assertTrue(t.buffer.scrollback.isEmpty()) // region scroll must NOT feed scrollback
    }

    @Test
    fun `top-of-screen scroll feeds scrollback`() {
        val t = emulator(cols = 5, rows = 2)
        t.feedStr("row0\r\nrow1\r\n") // second \n scrolls row0 off the top
        assertEquals(1, t.buffer.scrollback.size)
        assertEquals("row0", t.buffer.scrollback[0].joinToString("") { it.char.toString() }.trimEnd())
    }

    @Test
    fun `alternate screen switch preserves and restores the primary screen`() {
        val t = emulator(cols = 20, rows = 4)
        t.feedStr("primary content")
        t.feedStr("\u001B[?1049h") // enter alt screen
        t.feedStr("alt content")
        assertEquals("alt content", t.text(0))
        t.feedStr("\u001B[?1049l") // leave alt screen
        assertEquals("primary content", t.text(0)) // untouched by the alt-screen excursion
    }

    @Test
    fun `device status report replies with cursor position`() {
        val t = emulator()
        var replied: ByteArray? = null
        t.onResponse = { replied = it }
        t.feedStr("\u001B[4;7H")
        t.feedStr("\u001B[6n")
        assertEquals("\u001B[4;7R", String(replied!!, Charsets.US_ASCII))
    }

    @Test
    fun `bell callback fires on BEL`() {
        val t = emulator()
        var rung = false
        t.onBell = { rung = true }
        t.feed(byteArrayOf(0x07))
        assertTrue(rung)
    }

    @Test
    fun `osc window title is reported and not printed to the screen`() {
        val t = emulator()
        var title: String? = null
        t.onTitleChange = { title = it }
        t.feed(("\u001B]0;my session\u0007").toByteArray(Charsets.UTF_8))
        assertEquals("my session", title)
        assertEquals("", t.text(0))
    }

    @Test
    fun `utf-8 multibyte sequence split across two feed calls decodes correctly`() {
        val t = emulator()
        val bytes = "\u00E9".toByteArray(Charsets.UTF_8) // 'é' = 2 bytes in UTF-8
        assertEquals(2, bytes.size)
        t.feed(byteArrayOf(bytes[0]))
        t.feed(byteArrayOf(bytes[1]))
        assertEquals("\u00E9", t.text(0))
    }

    @Test
    fun `tab moves to next 8-column stop`() {
        val t = emulator(cols = 20, rows = 2)
        t.feedStr("ab\t")
        assertEquals(8, t.cursorCol)
    }

    @Test
    fun `resize preserves top-left content and clamps cursor`() {
        val t = emulator(cols = 10, rows = 4)
        t.feedStr("hello")
        t.resize(6, 2)
        assertEquals("hello", t.text(0))
        assertTrue(t.cursorRow < 2)
    }
}
