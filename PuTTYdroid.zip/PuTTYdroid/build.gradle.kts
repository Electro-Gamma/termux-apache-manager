// Root build file. Plugin versions are declared here (with `apply false`) and
// applied per-module in app/build.gradle.kts and terminal-core/build.gradle.kts.
//
// NOTE ON VERSIONS: this project could not be built or dependency-resolved in
// the sandboxed environment it was authored in (no network access - see
// docs/ARCHITECTURE.md / STATUS.md). The versions below are pinned to what
// was current stable tooling at authoring time; Android Studio will very
// likely prompt an Android Gradle Plugin / Kotlin upgrade the first time you
// open this project; accept it rather than fighting to keep these exact
// numbers.
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
    id("org.jetbrains.kotlin.jvm") version "1.9.24" apply false
    id("com.google.devtools.ksp") version "1.9.24-1.0.20" apply false
}
