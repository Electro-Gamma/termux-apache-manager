// NOTE ON VERSIONS: this project could not be built or dependency-resolved in
// the sandboxed environment it was originally authored in (no network access).
// AGP was bumped from 8.5.2 to 8.6.0 after a real Colab build (Gradle 8.7,
// AGP 8.5.2, compileSdk 34) failed with: "Dependency
// 'com.github.mik3y:usb-serial-for-android:3.11.0' requires ... compile
// against version 35 or later ... the maximum recommended compile SDK
// version for Android Gradle plugin 8.5.2 is 34." Compatibility, confirmed
// via a citable source (github.com/cgeo/cgeo/issues/16764, quoting Android's
// own tooling compatibility table): compileSdk 35 requires AGP >= 8.6.0,
// and AGP 8.6 requires Gradle >= 8.7 - which this project already pins (see
// gradle-wrapper equivalent / the Colab notebook's Gradle download step) -
// so 8.6.0 was the minimal, best-sourced bump rather than a guess. Android
// Studio will likely still prompt a further upgrade the first time you open
// this project; accept it rather than fighting to keep these exact numbers.
plugins {
    id("com.android.application") version "8.6.0" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
    id("org.jetbrains.kotlin.jvm") version "1.9.24" apply false
    id("com.google.devtools.ksp") version "1.9.24-1.0.20" apply false
}
