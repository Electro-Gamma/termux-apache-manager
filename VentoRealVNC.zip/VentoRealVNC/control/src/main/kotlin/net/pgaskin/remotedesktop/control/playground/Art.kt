// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later
package net.pgaskin.remotedesktop.control.playground

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader

/** Drawn stand-ins for a remote desktop's picture and cursors, for the playground. */
object Art {

    /** A cursor shape: its bitmap, hotspot and a name for the readouts. */
    data class Cursor(val bitmap: Bitmap, val hotX: Int, val hotY: Int, val name: String)

    /** A gradient with a labelled grid and a red border, so scale, position and edges are all visible. */
    fun wallpaper(w: Int, h: Int): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val wf = w.toFloat()
        val hf = h.toFloat()
        p.shader = LinearGradient(
            0f, 0f, wf, hf,
            intArrayOf(0xff10243c.toInt(), 0xff1d4f5e.toInt(), 0xff2b6b52.toInt(), 0xff4a3b6b.toInt()),
            floatArrayOf(0f, 0.38f, 0.66f, 1f), Shader.TileMode.CLAMP,
        )
        c.drawRect(0f, 0f, wf, hf, p)
        p.shader = null

        // A few soft blobs so it reads as a picture rather than graph paper.
        val blobs = intArrayOf(0x66e0a33e, 0x5540c4a0, 0x554a90d9, 0x66d95f6b, 0x4477e0c0)
        for (i in blobs.indices) {
            val bx = wf * (0.12f + 0.19f * i)
            val by = hf * (if (i % 2 == 0) 0.28f else 0.72f)
            val br = minOf(wf, hf) * (0.16f + 0.05f * (i % 3))
            p.shader = RadialGradient(bx, by, br, blobs[i], 0x00000000, Shader.TileMode.CLAMP)
            c.drawCircle(bx, by, br, p)
        }
        p.shader = null

        // Grid: fine every 100 px, heavy every 500 px, labelled at intersections.
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f
        p.color = 0x22ffffff
        for (x in 0..w step 100) c.drawLine(x.toFloat(), 0f, x.toFloat(), hf, p)
        for (y in 0..h step 100) c.drawLine(0f, y.toFloat(), wf, y.toFloat(), p)
        p.strokeWidth = 2f
        p.color = 0x55ffffff
        for (x in 0..w step 500) c.drawLine(x.toFloat(), 0f, x.toFloat(), hf, p)
        for (y in 0..h step 500) c.drawLine(0f, y.toFloat(), wf, y.toFloat(), p)
        p.style = Paint.Style.FILL
        p.color = 0x99ffffff.toInt()
        p.textSize = 22f
        for (x in 0..w step 500) {
            for (y in 0..h step 500) {
                c.drawText("$x,$y", x + 6f, y + 24f, p)
            }
        }

        // Border so the desktop edge is unmistakable.
        p.style = Paint.Style.STROKE
        p.strokeWidth = 8f
        p.color = 0xffff5555.toInt()
        c.drawRect(4f, 4f, wf - 4, hf - 4, p)
        return bmp
    }

    fun arrowCursor(): Cursor {
        val w = 14
        val h = 22
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val path = Path()
        path.moveTo(0.5f, 0.5f)
        path.lineTo(0.5f, 16.5f)
        path.lineTo(4.5f, 12.5f)
        path.lineTo(7.0f, 19.5f)
        path.lineTo(10.0f, 18.0f)
        path.lineTo(7.5f, 11.5f)
        path.lineTo(12.5f, 11.5f)
        path.close()
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.style = Paint.Style.FILL
        p.color = Color.BLACK
        c.drawPath(path, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f
        p.color = Color.WHITE
        c.drawPath(path, p)
        return Cursor(bmp, 0, 0, "ARROW")
    }

    fun handCursor(): Cursor {
        val w = 22
        val h = 28
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        // Six rounded boxes unioned: the index finger, three curled ones, the fist and a thumb
        // bulging out to the left of it. Drawn to the same proportions as the desktop pointer it
        // stands in for, since a hand that is not that shape reads as a blob at this size.
        val parts = arrayOf(
            floatArrayOf(6.5f, 2.5f, 10.5f, 16f, 2.0f), // index
            floatArrayOf(10.2f, 9f, 13.6f, 16f, 1.7f),
            floatArrayOf(13.3f, 10.2f, 16.6f, 16f, 1.7f),
            floatArrayOf(16.3f, 11.5f, 19.3f, 17f, 1.5f), // little
            floatArrayOf(4.8f, 14f, 19.3f, 25.5f, 4.6f), // fist
            floatArrayOf(1.8f, 16.5f, 7.0f, 23.0f, 2.6f), // thumb
        )
        val path = Path()
        for (r in parts) {
            path.addRoundRect(RectF(r[0], r[1], r[2], r[3]), r[4], r[4], Path.Direction.CW)
        }
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        // Outline first and fill over it, so the white is a halo outside the hand rather than a
        // line through every box that made it.
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.6f
        p.strokeJoin = Paint.Join.ROUND
        p.color = Color.WHITE
        c.drawPath(path, p)
        p.style = Paint.Style.FILL
        p.color = Color.BLACK
        c.drawPath(path, p)
        // ... and then the gaps between the fingers, which the fill covered.
        p.style = Paint.Style.STROKE
        p.strokeWidth = 0.9f
        p.color = Color.WHITE
        c.drawLine(10.35f, 10.2f, 10.35f, 15f, p)
        c.drawLine(13.45f, 11.4f, 13.45f, 15f, p)
        c.drawLine(16.45f, 12.7f, 16.45f, 15f, p)
        return Cursor(bmp, 8, 1, "HAND")
    }

    fun crossCursor(): Cursor {
        val n = 21
        val m = n / 2
        val bmp = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint()
        val nf = n.toFloat()
        val mf = m + 0.5f
        p.style = Paint.Style.STROKE
        p.strokeWidth = 3f
        p.color = Color.WHITE
        c.drawLine(0f, mf, nf, mf, p)
        c.drawLine(mf, 0f, mf, nf, p)
        p.strokeWidth = 1f
        p.color = Color.BLACK
        c.drawLine(0f, mf, nf, mf, p)
        c.drawLine(mf, 0f, mf, nf, p)
        return Cursor(bmp, m, m, "CROSS")
    }
}
