// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later
package net.pgaskin.remotedesktop.control.input

/**
 * Turns touches into mouse gestures: one finger moves the pointer (with acceleration and momentum),
 * a quick tap clicks (one, two or three fingers for left, right, middle), two fingers pinch or
 * scroll, and a tap followed by a drag holds the button. Reproduces RealVNC Viewer's behaviour, with
 * the deliberate changes in [Config].
 */
class GestureRecognizer(
    private val cfg: Config,
    private val sink: MouseSink,
    private val zoomSink: ZoomSink?,
    private val handler: Scheduler,
) : TouchRouter.Listener {

    enum class Mode(private val label: String) {
        NONE("-"),
        ZOOM("ZOOM"),
        SCROLL("SCROLL"),
        MULTI("MULTI");

        override fun toString(): String = label
    }

    private val accel = PointerAccel(cfg, sink)
    private val inertia = PointerInertia(cfg, sink, handler)

    // --- the two tracked pointer slots ------------------------------------
    private val slotId = intArrayOf(-1, -1)
    private val startX = FloatArray(2)
    private val startY = FloatArray(2)
    private val curX = FloatArray(2)
    private val curY = FloatArray(2)
    private val slotMoved = BooleanArray(2)
    private val slotMoves = IntArray(2)
    private val slotPath = FloatArray(2)
    private val slotDownTime = LongArray(2)

    private var down = 0 // fingers currently down
    private var maxDown = 0 // high-water mark for this gesture
    private var mode = Mode.NONE
    private var relative = false // the far end owns the cursor; see setRelative
    private var pinchStartDist = 0f
    private var midX = 0f
    private var midY = 0f

    private val wheel = WheelSteps(sink)
    private var heldButton: Button? = null // null when nothing is held
    private var pendingRelease: Runnable? = null

    // --- tap regions (ours; the original has a floating toolbar instead) ----
    private var regions: TapRegions? = null
    private var regionSink: RegionSink? = null

    // --- bump scroll -------------------------------------------------------
    private var bumpArmed = false
    private var externalHold = false
    private var bumpDx = 0f
    private var bumpDy = 0f
    private var bumpRunning = false

    private val bumpTask = object : Runnable {
        override fun run() {
            // The border test lives on the one-finger path, so with a second finger down nothing is
            // left to stop this: it would go on stepping 12 dp every 100 ms for the rest of the
            // gesture, fingers still and well away from any border. Armed stays armed, so lifting
            // back to one finger resumes.
            if (down != 1) {
                stopBumpScroll()
                return
            }
            sink.mouseMove(bumpDx, bumpDy)
            handler.postDelayed(this, cfg.bumpPeriodMs)
        }
    }

    // --- flick detection: the last two single-finger positions -------------
    private val flickX = FloatArray(2)
    private val flickY = FloatArray(2)
    private var flickCount = 0

    private var viewW = 0
    private var viewH = 0

    fun setViewSize(w: Int, h: Int) {
        viewW = w
        viewH = h
    }

    fun setRegions(regions: TapRegions?, sink: RegionSink?) {
        this.regions = regions
        regionSink = sink
    }

    /** The far end owns the cursor, so motion is sent unshaped where [Config.rawMotionWhenRelative]. */
    fun setRelative(relative: Boolean) {
        this.relative = relative
    }

    fun remoteCursorChanged(t: Long) {
        if (relative && cfg.rawMotionWhenRelative) {
            return
        }
        accel.remoteCursorChanged(t, inertia.speed() > 0)
    }

    fun setExternalButtonHeld(held: Boolean) {
        externalHold = held
    }

    // ---- debug accessors --------------------------------------------------

    fun downCount(): Int = down

    fun maxDownCount(): Int = maxDown

    fun mode(): Mode = mode

    fun heldButton(): Button? = heldButton

    fun moving(): Boolean = isMoving()

    fun accelFactor(): Float = accel.lastFactor()

    fun accelSpeed(): Float = accel.speed()

    fun axisLock(): PointerAccel.Axis = accel.axisLock()

    fun turnDegrees(): Float = accel.turnDegrees()

    fun hoverGain(): Float = accel.hoverGain()

    fun hoverLagMs(): Float = accel.hoverLagMs()

    fun hoverLockedOut(now: Long): Boolean = accel.hoverLockedOut(now)

    fun glideSpeed(): Double = inertia.speed()

    // ---- TouchRouter.Listener --------------------------------------------

    override fun touchBegan(id: Int, x: Float, y: Float, t: Long) {
        val secondFinger = down == 1
        if (down < 2) {
            val s = if (slotId[0] < 0) 0 else 1
            slotId[s] = id
            startX[s] = x
            curX[s] = x
            startY[s] = y
            curY[s] = y
            slotMoves[s] = 0
            slotPath[s] = 0f
            slotDownTime[s] = t
        }
        if (secondFinger) {
            // Second finger down: arm the pinch/scroll gesture.
            setMode(Mode.NONE)
            pinchStartDist = dist(curX[0], curY[0], curX[1], curY[1])
            midX = (curX[0] + curX[1]) / 2.0f
            midY = (curY[0] + curY[1]) / 2.0f
            zoomSink?.scaleCentre(midX, midY)
        } else if (down == 0) {
            // First finger of a new gesture. If a click release is still pending, cancel it — the
            // button stays held, which is what turns tap+drag into a button drag and tap+tap into a
            // double click.
            val pending = pendingRelease
            val resumed = pending != null
            if (pending != null) {
                handler.removeCallbacks(pending)
                pendingRelease = null
            }
            // Armed while a button is held, whoever is holding it: a button held by the mouse
            // overlay is a drag too, and the original knows only about its own 250 ms window.
            bumpArmed = cfg.bumpScrollEnabled && (resumed || externalHold)
            if (cfg.accelResetOnDown) {
                accel.reset()
            }
            if (cfg.inertiaCancelOnDown) {
                inertia.cancel()
            }
        }
        down++
        // The original clears both "has moved" flags on every touch-down.
        slotMoved[0] = false
        slotMoved[1] = false
        maxDown = maxOf(maxDown, down)
    }

    override fun touchMoved(id: Int, prevX: Float, prevY: Float, x: Float, y: Float, t: Long) {
        if (maxDown == 1) {
            pushFlick(x, y)
        }
        val s = slotOf(id)
        if (s >= 0) {
            curX[s] = x
            curY[s] = y
            slotMoves[s]++
            slotPath[s] += dist(prevX, prevY, x, y)
            if (!slotMoved[s]) {
                slotMoved[s] = hasMoved(s, t)
            }
        }
        if (!isMoving()) {
            return
        }
        if (down == 1) {
            if (s < 0) {
                return // the moving finger isn't one of the tracked slots
            }
            updateBumpScroll(x, y)
            val dx = x - prevX
            val dy = y - prevY
            if (relative && cfg.rawMotionWhenRelative) {
                // Straight out, and no samples kept: a glide is one more way of deciding how far the
                // cursor goes, and the far end is deciding that. The accelerator is left untouched
                // rather than driven and ignored, so its readouts report the last gesture that went
                // through it.
                sink.mouseMove(dx, dy)
            } else {
                accel.move(dx, dy, t) // emits the (accelerated) mouse motion
                inertia.sample(dx, dy, t) // momentum samples the raw delta
            }
        } else if (down == 2) {
            twoFingerMoved()
        } else {
            setMode(Mode.MULTI)
        }
    }

    override fun touchEnded(id: Int, prevX: Float, prevY: Float, x: Float, y: Float, t: Long) {
        val s = slotOf(id)
        if (s >= 0) {
            curX[s] = x
            curY[s] = y
            slotId[s] = -1
        }
        release(false)
    }

    override fun touchCancelled(t: Long) {
        while (down > 0) {
            release(true)
        }
    }

    /** Drop everything: fingers, held button, pending click, momentum. */
    fun cancelAll(t: Long) {
        touchCancelled(t)
        stopBumpScroll()
        bumpArmed = false
        inertia.cancel()
        pendingRelease?.let {
            handler.removeCallbacks(it)
            pendingRelease = null
        }
        heldButton?.let {
            sink.mouseUp(it.mask())
            heldButton = null
        }
        reset()
    }

    // ---- internals --------------------------------------------------------

    private fun slotOf(id: Int): Int {
        if (slotId[0] == id) return 0
        if (slotId[1] == id) return 1
        return -1
    }

    private fun isMoving(): Boolean {
        if (down == 1) {
            if (slotId[0] >= 0) return slotMoved[0]
            if (slotId[1] >= 0) return slotMoved[1]
            return false
        }
        return slotMoved[0] && slotMoved[1]
    }

    private fun hasMoved(s: Int, t: Long): Boolean {
        if (Math.abs(curX[s] - startX[s]) >= cfg.moveThresholdPx ||
            Math.abs(curY[s] - startY[s]) >= cfg.moveThresholdPx
        ) {
            return true
        }
        if (cfg.tapPathThresholdPx > 0 && slotPath[s] >= cfg.tapPathThresholdPx) {
            return true
        }
        if (cfg.moveCountTest && slotMoves[s] > cfg.moveCountLimit) {
            return true // the vncpatch#1 bug, kept for A/B
        }
        return cfg.tapMaxDurationMs > 0 && (t - slotDownTime[s]) > cfg.tapMaxDurationMs
    }

    private fun setMode(m: Mode) {
        if (mode == m) {
            return
        }
        if (mode == Mode.ZOOM) {
            zoomSink?.zoomEnded()
        }
        mode = m
        if (mode == Mode.ZOOM) {
            zoomSink?.zoomBegan()
        }
    }

    private fun twoFingerMoved() {
        val travel = dist(startX[0], startY[0], curX[0], curY[0]) +
            dist(startX[1], startY[1], curX[1], curY[1])
        val spread = Math.abs(
            dist(startX[0], startY[0], startX[1], startY[1]) -
                dist(curX[0], curY[0], curX[1], curY[1]),
        )
        if (travel == 0.0f) {
            return
        }
        if (mode == Mode.NONE) {
            val ratio = spread / travel
            if (ratio > cfg.zoomRatio) {
                setMode(Mode.ZOOM)
            } else if (ratio < cfg.scrollRatio) {
                setMode(Mode.SCROLL)
            }
        }
        if (mode == Mode.ZOOM) {
            // The midpoint is the other half of a pinch, and the original uses only the separation.
            // It is read here rather than every two-finger frame so that the mode still consumes the
            // travel it was decided by: the first delta of either mode covers everything since the
            // second finger landed.
            val mx = (curX[0] + curX[1]) / 2.0f
            val my = (curY[0] + curY[1]) / 2.0f
            if (zoomSink != null) {
                if (pinchStartDist > 0) {
                    zoomSink.zoomChanged(dist(curX[0], curY[0], curX[1], curY[1]) / pinchStartDist)
                }
                zoomSink.zoomPanned(mx - midX, my - midY)
            }
            midX = mx
            midY = my
        } else if (mode == Mode.SCROLL) {
            val mx = (curX[0] + curX[1]) / 2.0f
            val my = (curY[0] + curY[1]) / 2.0f
            emitWheel(mx - midX, my - midY)
            midX = mx
            midY = my
        }
    }

    private fun emitWheel(dx: Float, dy: Float) {
        val sign = if (cfg.naturalScrolling) -1.0f else 1.0f
        wheel.add(dx * sign, dy * sign, cfg.wheelStepPx)
    }

    private fun updateBumpScroll(x: Float, y: Float) {
        if (!bumpArmed) {
            stopBumpScroll()
            return
        }
        bumpDx = 0f
        bumpDy = 0f
        if (y < cfg.bumpBorderPx) bumpDy = -cfg.bumpDeltaPx
        if (y > viewH - cfg.bumpBorderPx) bumpDy = cfg.bumpDeltaPx
        if (x < cfg.bumpBorderPx) bumpDx = -cfg.bumpDeltaPx
        if (x > viewW - cfg.bumpBorderPx) bumpDx = cfg.bumpDeltaPx
        if (bumpDx == 0f && bumpDy == 0f && cfg.bumpStopOutsideBorder) {
            stopBumpScroll()
            return
        }
        sink.mouseMove(bumpDx, bumpDy)
        if (!bumpRunning) {
            bumpRunning = true
            handler.postDelayed(bumpTask, cfg.bumpPeriodMs)
        }
    }

    private fun stopBumpScroll() {
        if (bumpRunning) {
            bumpRunning = false
            handler.removeCallbacks(bumpTask)
        }
    }

    private fun release(cancelled: Boolean) {
        if (down == 0) {
            return
        }
        if (--down != 0) {
            return
        }
        bumpArmed = false
        stopBumpScroll()
        accel.gestureEnded()
        heldButton?.let {
            sink.mouseUp(it.mask())
            heldButton = null
        }
        if (slotMoved[0] || slotMoved[1] || cancelled) {
            // It was a drag: no click, but maybe a flick. Not where the motion went out raw —
            // nothing sampled it, and the samples still in there are an older gesture's.
            if (!cancelled && !(relative && cfg.rawMotionWhenRelative) && flickCount >= 2 &&
                dist(flickX[0], flickY[0], flickX[1], flickY[1]) > cfg.flickMinDistPx
            ) {
                inertia.flick()
            }
        } else if (!regionTapped()) {
            val button = when (maxDown) {
                1 -> Button.LEFT
                2 -> Button.RIGHT
                3 -> Button.MIDDLE
                else -> null // 4+ fingers: nothing
            }
            if (button != null) {
                press(button)
            }
        }
        reset()
    }

    private fun regionTapped(): Boolean {
        val rs = regionSink
        val rg = regions
        if (rg == null || rs == null || maxDown != 1) {
            return false
        }
        val r = rg.hit(startX[0], startY[0], viewW, viewH)
        return r != null && rs.regionTapped(r, startX[0], startY[0])
    }

    private fun press(button: Button) {
        sink.mouseDown(button.mask())
        heldButton = button
        val r = Runnable {
            pendingRelease = null
            heldButton?.let {
                sink.mouseUp(it.mask())
                heldButton = null
            }
        }
        pendingRelease = r
        handler.postDelayed(r, cfg.clickHoldMs)
    }

    private fun reset() {
        down = 0
        maxDown = 0
        slotId[0] = -1
        slotId[1] = -1
        slotMoved[0] = false
        slotMoved[1] = false
        slotMoves[0] = 0
        slotMoves[1] = 0
        slotPath[0] = 0f
        slotPath[1] = 0f
        wheel.reset()
        flickCount = 0
        setMode(Mode.NONE)
    }

    private fun pushFlick(x: Float, y: Float) {
        if (flickCount < 2) {
            flickX[flickCount] = x
            flickY[flickCount] = y
            flickCount++
        } else {
            flickX[0] = flickX[1]
            flickY[0] = flickY[1]
            flickX[1] = x
            flickY[1] = y
        }
    }

    private companion object {
        fun dist(ax: Float, ay: Float, bx: Float, by: Float): Float {
            val dx = bx - ax
            val dy = by - ay
            return Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
        }
    }
}
