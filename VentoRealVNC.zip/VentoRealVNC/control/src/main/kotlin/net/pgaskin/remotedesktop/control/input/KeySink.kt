// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later
package net.pgaskin.remotedesktop.control.input

/** Where keys go. The id ties a release to its press and says which source pressed it. */
interface KeySink {
    fun keyDown(keysym: Int, keyId: Int)

    fun keyUp(keyId: Int)

    companion object {
        const val ID_EXTENSION_KEYBOARD = 0x0001_0000
        const val ID_SYSTEM_KEYBOARD = 0x0002_0000
        const val ID_TEXT = 0x0003_0000
    }
}
