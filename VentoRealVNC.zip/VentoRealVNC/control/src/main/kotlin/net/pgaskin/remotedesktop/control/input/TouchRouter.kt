// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later
package net.pgaskin.remotedesktop.control.input

import android.view.MotionEvent

/**
 * Turns a stream of touch frames into per-pointer began/moved/ended events, with the previous
 * position of each pointer, and lets widgets [Claim] a pointer before the gesture layer sees it.
 */
class TouchRouter(private val listener: Listener) {

    interface Listener {
        fun touchBegan(id: Int, x: Float, y: Float, t: Long)

        fun touchMoved(id: Int, prevX: Float, prevY: Float, x: Float, y: Float, t: Long)

        fun touchEnded(id: Int, prevX: Float, prevY: Float, x: Float, y: Float, t: Long)

        fun touchCancelled(t: Long)
    }

    /** Sees every frame before it is routed, for recording. */
    fun interface Tap {
        fun onFrame(f: TouchFrame)
    }

    /** A widget that can take a pointer for itself, before the gesture layer sees it. */
    interface Claim {
        /** @return true if this widget takes the pointer */
        fun claimTouch(id: Int, x: Float, y: Float, t: Long): Boolean

        fun claimMoved(id: Int, x: Float, y: Float, t: Long)

        fun claimEnded(id: Int, x: Float, y: Float, t: Long)

        fun claimCancelled(t: Long)
    }

    private val scratch = TouchFrame()

    // Previous position per pointer id; linear scan, there are never many.
    private val lastId = IntArray(TouchFrame.MAX_POINTERS)
    private val lastX = FloatArray(TouchFrame.MAX_POINTERS)
    private val lastY = FloatArray(TouchFrame.MAX_POINTERS)
    private var lastCount = 0

    private var optionalRecorder: Tap? = null

    // Offered each new pointer in order; the first to take it owns it.
    private val claims = ArrayList<Claim>(2)
    private val owner = arrayOfNulls<Claim>(64) // by pointer id, which is small and dense

    fun setTap(tap: Tap?) {
        optionalRecorder = tap
    }

    fun addClaim(c: Claim) {
        claims.add(c)
    }

    private fun trackable(id: Int): Boolean = id >= 0 && id < 64

    fun onTouchEvent(ev: MotionEvent): Boolean {
        val action = when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> TouchFrame.Action.DOWN
            MotionEvent.ACTION_MOVE -> TouchFrame.Action.MOVE
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> TouchFrame.Action.UP
            MotionEvent.ACTION_CANCEL -> TouchFrame.Action.CANCEL
            else -> return false
        }
        scratch.set(action, ev.actionIndex, ev.eventTime)
        for (i in 0 until ev.pointerCount) {
            scratch.add(ev.getPointerId(i), ev.getX(i), ev.getY(i))
        }
        return handle(scratch)
    }

    /** Route one frame, whether it came from a `MotionEvent` or a recording. */
    fun handle(f: TouchFrame): Boolean {
        optionalRecorder?.onFrame(f)
        when (f.action) {
            TouchFrame.Action.DOWN -> {
                val i = clampIndex(f)
                val id = f.id[i]
                val x = f.x[i]
                val y = f.y[i]
                if (trackable(id)) {
                    for (c in claims) {
                        if (c.claimTouch(id, x, y, f.time)) {
                            owner[id] = c
                            return true
                        }
                    }
                }
                remember(id, x, y)
                listener.touchBegan(id, x, y, f.time)
            }
            TouchFrame.Action.MOVE -> {
                for (i in 0 until f.count) {
                    val id = f.id[i]
                    if (trackable(id)) {
                        val owned = owner[id]
                        if (owned != null) {
                            owned.claimMoved(id, f.x[i], f.y[i], f.time)
                            continue
                        }
                    }
                    val k = indexOf(id)
                    if (k < 0) {
                        continue // never saw it go down
                    }
                    val x = f.x[i]
                    val y = f.y[i]
                    val px = lastX[k]
                    val py = lastY[k]
                    lastX[k] = x
                    lastY[k] = y
                    listener.touchMoved(id, px, py, x, y, f.time)
                }
            }
            TouchFrame.Action.UP -> {
                val i = clampIndex(f)
                val id = f.id[i]
                val x = f.x[i]
                val y = f.y[i]
                if (trackable(id)) {
                    val c = owner[id]
                    if (c != null) {
                        owner[id] = null
                        c.claimEnded(id, x, y, f.time)
                        return true
                    }
                }
                val k = indexOf(id)
                val px = if (k >= 0) lastX[k] else x
                val py = if (k >= 0) lastY[k] else y
                forget(id)
                listener.touchEnded(id, px, py, x, y, f.time)
            }
            TouchFrame.Action.CANCEL -> cancel(f.time)
        }
        return true
    }

    fun cancel(time: Long) {
        lastCount = 0
        owner.fill(null)
        // Every claimant, not only those currently holding a pointer: cancel means the touch stream
        // is gone, and a widget left holding a button because it happened to own nothing would hold
        // it forever.
        for (c in claims) {
            c.claimCancelled(time)
        }
        listener.touchCancelled(time)
    }

    private fun clampIndex(f: TouchFrame): Int = if (f.index >= 0 && f.index < f.count) f.index else 0

    private fun indexOf(id: Int): Int {
        for (i in 0 until lastCount) {
            if (lastId[i] == id) {
                return i
            }
        }
        return -1
    }

    private fun remember(id: Int, x: Float, y: Float) {
        var k = indexOf(id)
        if (k < 0) {
            if (lastCount == TouchFrame.MAX_POINTERS) {
                return
            }
            k = lastCount++
            lastId[k] = id
        }
        lastX[k] = x
        lastY[k] = y
    }

    private fun forget(id: Int) {
        val k = indexOf(id)
        if (k < 0) {
            return
        }
        lastCount--
        lastId[k] = lastId[lastCount]
        lastX[k] = lastX[lastCount]
        lastY[k] = lastY[lastCount]
    }
}
