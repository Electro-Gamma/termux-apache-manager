// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later
package net.pgaskin.remotedesktop.control.input

/**
 * Every tunable in the input stack, in one place.
 *
 * The defaults are the values reverse-engineered from RealVNC Viewer
 * 4.9.1.60165; `ARCHITECTURE.md` §1.15 lists them in one table. Two
 * presets are provided: [faithful] reproduces the original bug-for-bug,
 * [improved] applies the deliberate changes (§2 and §3 there).
 * Flipping between them at runtime is the point — it is how the "feel" gets
 * A/B'd.
 */
class Config private constructor(val density: Float) {


    var faithfulPreset = false // display only

    // ---- tap vs. drag -----------------------------------------------------

    var moveThresholdPx = 0f    // mouse_cursor_movement_threshold, 12 dp, per-axis
    /**
     * Accumulated path length that promotes a touch to a drag even if it never
     * gets 12 dp away from where it started. Replaces the original's
     * "more than 10 ACTION_MOVE events" test, which a high-report-rate screen
     * trips while the finger is stationary. 0 disables.
     */
    var tapPathThresholdPx = 0f
    var moveCountTest = false    // the test above, as the original has it: a real bug
    var moveCountLimit = 10
    var tapMaxDurationMs = 0L    // longer is a drag, not a tap; 0 disables

    // ---- clicks -----------------------------------------------------------

    /**
     * Auto-release delay for a tap-generated button press. Doubles as the
     * double-click / tap-then-drag window: a touch-down inside it cancels the
     * release, leaving the button held.
     */
    var clickHoldMs = 250L
    var flickMinDistPx = 2.0f // between the last two positions, to glide at all

    // ---- bump scroll (edge auto-repeat during a tap-then-drag) -------------

    var bumpScrollEnabled = true
    var bumpBorderPx = 0f              // bump_scroll_border_size, 24 dp
    var bumpDeltaPx = 0f               // bump_scroll_event_delta, 12 dp
    var bumpPeriodMs = 100L
    var bumpStopOutsideBorder = true // original keeps firing (0,0) once armed

    // ---- two-finger -------------------------------------------------------

    var zoomRatio = 0.7f      // |Δseparation| / totalTravel above this ⇒ pinch
    var scrollRatio = 0.2f    // ... below this ⇒ wheel; between them, undecided
    var wheelStepPx = 8.0f    // midpoint travel per wheel click, raw screen px
    var naturalScrolling = false

    // ---- acceleration ------------------------------------------------------

    var accelEnabled = true
    var accelDrainHistory = true // original drains its 3 samples: every 3rd event scales
    var accelResetOnDown = true  // original never clears them between gestures
    var accelBase = Math.sqrt(1.1).toFloat()
    var accelExponent = 2.5999999f
    var accelMin = 1.1f
    var accelMax = 5.0f

    // ---- adaptive acceleration (ours; the original has none of this) ------

    /**
     * Fade the amplification out at low speed. The curve is jerk-based, so a
     * *steady* slow drag already sits near the [accelMin] floor,
     * but a slow drag with jitter in it is all jerk and gets amplified exactly
     * where precision was wanted. Gating only the part of the factor above the
     * floor leaves the flick response intact.
     */
    var accelAdaptive = false
    var accelSlowSpeedPx = 0f  // below this the factor is pinned to accelMin, px/ms
    var accelFullSpeedPx = 0f  // at and above it the jerk curve applies unmodified

    /**
     * Zero the minor axis of a slow, near-axial movement, so a horizontal or
     * vertical drag does not wander — text selection is what it is for.
     */
    var axisLockEnabled = false
    var axisLockMaxSpeedPx = 0f         // only engages below this, px/ms
    var axisLockEnterRatio = 0.30f // smoothed minor/major below this locks
    var axisLockExitRatio = 0.55f  // ... and above this releases: exit > enter

    // ---- hover assist (ours; §3.20) ---------------------------------------

    /**
     * Lose a little distance just after the far end changes the cursor's shape,
     * so that whatever it changed shape over is easier to stop on. The third
     * precision mechanism beside the adaptive gate and the axis lock, and the
     * only one that reacts to what the far end says rather than to what the
     * finger does.
     */
    var hoverAssistEnabled = false
    var hoverAssistSpanPx = 0f         // finger travel a detent lasts
    var hoverAssistGain = 0.25f   // the factor at the catch; 1 is no assist
    /**
     * The four tests that keep an animated cursor from making the whole desktop
     * feel like treacle, and a fifth that keeps a far end whose news arrives too
     * late from decorating open desktop with detents.
     */
    var hoverAssistMaxSpeedPx = 0f     // above this the finger is not aiming at anything
    var hoverAssistIdleMs = 120L    // a change with nothing moving was not caused by us
    var hoverAssistMinTravelPx = 0f    // two shapes this close together are frames
    var hoverAssistBurstCount = 4
    var hoverAssistBurstMs = 600L
    var hoverAssistLockoutMs = 2000L
    /**
     * Measured lateness above which nothing arms, ms. Every far end measured
     * sits either side of this by a factor of two: ten to thirty milliseconds
     * where the server is told its cursor changed, a hundred and forty where it
     * polls its own screen.
     */
    var hoverAssistMaxLagMs = 60L

    /**
     * Send a finger's motion unshaped where the far end owns the cursor: no
     * acceleration, no adaptive gate, no axis lock, and no glide after a flick.
     *
     * All four are ways of deciding how far a cursor goes for a given
     * finger, and in that mode the far end decides that — it applies its own
     * acceleration to whatever deltas arrive, which is the acceleration that
     * machine's own user lives with. Ours then compounds it, and a curve on top
     * of a curve is nobody's.
     *
     * What it does *not* turn off is dividing by the viewport scale,
     * which is not shaping: a finger crossing a zoomed-in screen still covers
     * fewer desktop pixels, and the picture is this end's fact whoever owns the
     * pointer. Nor does it touch a physical mouse, whose deltas never went
     * through any of this.
     *
     * Neither preset sets it, because the original has no such mode to be
     * faithful or unfaithful to.
     */
    var rawMotionWhenRelative = true
    /**
     * The turn test, without which locking on the ratio alone flattens a third
     * of every circle drawn: the direction is smoothed over
     * `axisLockTurnSpanPx` of path and the angle between two such spans is
     * the turn. Longer sees gentler curves, shorter re-locks sooner afterwards.
     * A turn past `axisLockCornerDeg` is a corner rather than a curve, so
     * the history is dropped outright and the next straight leg — the across of
     * an L-shaped text selection — locks a few events later instead of a whole
     * span later.
     */
    var axisLockTurnSpanPx = 0f
    var axisLockMaxTurnDeg = 10.0f
    var axisLockCornerDeg = 45.0f

    // ---- mouse button overlay (ui.MouseButtons / ui.ScrollButton) ---------

    var overlayStripWidthPx = 0f   // wheel strip up the right edge, 60 dp
    var overlayRowHeightPx = 0f    // button row across the bottom, 72 dp
    var overlayDismissPx = 0f      // the square dismiss button, and its corner margin
    var overlayDismissMarginPx = 0f
    var overlayMiddleMinPx = 0f    // the middle button never narrows past this, 100 dp
    var overlayWheelTickMs = 40L
    var overlayWheelMaxRate = 4.0f       // clicks per tick at the ends of the strip
    var overlayWheelTicksPerClick = 3.0f // the strip's gearing at rate 1
    var overlayWheelStartDelayTicks = 8    // before the first repeat, so a tap is one click

    // ---- extension keyboard (ui.ExtensionKeyboard / ui.InfoBar) -----------

    var keyboardKeyHeightPx = 0f   // extension_keyboard_height, 46 dp
    /**
     * One line of a key list that has more than one, which is shorter than a
     * row on its own: 46 dp twice over is most of what is left of a phone, and
     * a line with another above or below it is aimed at against its neighbour
     * rather than against the picture, so it can lose a little padding and still
     * be hit. 40 dp is where it stops — the size of the overlay's dismiss
     * button, which is the smallest target this screen already asks a finger
     * for, and a key that is hard to hit sends the wrong keysym to somebody
     * else's machine with no undo at that end.
     */
    var keyboardKeyHeightMultiPx = 0f
    var keyboardInfoHeightPx = 0f  // the info bar above the keys, 30 dp
    var keyboardKeyPadPx = 0f      // key_horizontal_margin
    var keyboardKeyPadWidePx = 0f  // key_horizontal_margin_wide
    /**
     * The gap between key groups. The original's is 16 dp either side of a
     * divider it draws and we do not; without the divider that much space reads
     * as the row having ended.
     */
    var keyboardGroupGapPx = 0f
    var keyboardIconWidthPx = 0f    // width allowed for a key drawn as an icon
    var keyboardMinKeyWidthPx = 0f  // however short the label
    var keyboardScrollSlopPx = 0f   // movement that turns a key press into a scroll
    var keyboardFlingTickMs = 16L
    var keyboardFlingDecay = 0.94f
    var keyboardFlingMinPx = 0f     // release speed below this does not fling, px/ms
    var keyboardFlingStopPx = 0f    // ... and a glide slower than this has stopped
    var keyDoubleTapMs = 300L    // second tap on a modifier locks it; the platform's timeout
    var keyLongPressMs = 500L    // hold to lock a modifier, or to start repeating
    var keyRepeatMs = 75L
    /**
     * Whether the key row buzzes at all: the system's own keyboard setting does
     * not reach a view that draws its own keys. Checked here rather than in the
     * view so that the model simply does not ask.
     */
    var keyboardHaptics = true
    var keyboardInfoMaxChars = 256 // of the typed line kept; the bar shows the tail
    /**
     * Whether the info bar is part of the keyboard or a pane floating over the
     * desktop. Floating is the original's: the desktop runs on underneath, and
     * the bar thins as the cursor comes near so that a pointer pushed to the
     * bottom edge is not swallowed by it. Solid insets the desktop by the bar as
     * well, which costs 30 dp of picture and buys a readout that never dims and
     * never has desktop showing through it.
     */
    var keyboardInfoSolid = false

    // ---- the toolbar (ours; the original's is a floating panel) -------------

    /**
     * A square button, and the grip under the column of them. Four buttons and a
     * grip come to exactly 200 dp, which is what the platform will let an app
     * take back from the system's own edge gesture
     * (`setSystemGestureExclusionRects`) — so the size is that limit
     * divided up rather than Material's 48 dp.
     */
    var toolbarButtonPx = 0f
    var toolbarGripPx = 0f
    var toolbarDragSlopPx = 0f   // movement that turns a button press into a drag

    // ---- momentum ----------------------------------------------------------

    var inertiaEnabled = true
    var inertiaStartDelayMs = 50L
    var inertiaTickMs = 10L
    var inertiaSpeedScale = 25.0
    var inertiaSpeedMax = 200.0
    var inertiaDecay = 0.85
    var inertiaStopSpeed = 3.0
    var inertiaCancelOnDown = true // original lets a glide run through a new touch
    var inertiaResetOnDown = true  // original reuses the previous gesture's samples

    // ---- cursor / viewport ------------------------------------------------

    var recentreCursorOnZoom = true  // on every pinch step, as the original does
    var coalescePointerEvents = true // one event per frame; the original does not throttle
    /**
     * Drop a pointer event whose position *and* button mask are identical
     * to the last one sent. A finger held still keeps producing ACTION_MOVEs
     * (the digitizer jitters below a pixel), and pushing the cursor against a
     * desktop edge clamps every delta away, so without this the stack streams
     * duplicate positions for as long as a finger is down.
     *
     * Safe only because the protocol is absolute: a dropped duplicate cannot
     * lose distance the way a dropped relative delta would.
     */
    var dedupePointerEvents = true
    /**
     * Keep the desktop's edges clear of the shape of the window
     * ([setPanMargins]): a pan
     * may carry each edge in by whatever the caller measures that edge to cost,
     * leaving blank beside it. Off is the original: an edge of the desktop stops
     * at the edge of the window, which on a phone is not a rectangle — a rounded
     * corner, a camera cutout and a system bar all sit over the picture, and the
     * last row of pixels against one of them cannot be looked at squarely or
     * clicked comfortably.
     *
     * Off by default, because it is blank space in exchange for reach, and
     * whether that is worth it depends on the phone.
     */
    var panMarginInsets = false
    /**
     * A margin on every edge, the same on each and answering to nothing about
     * the window: room to bring an edge of the desktop in from the edge of the
     * screen because that is where it is easier to look at, whatever is or is
     * not over it there.
     *
     * Independent of [panMarginInsets], which is a different reason
     * to want the same thing — either alone is a margin, and both is the sum.
     * Zero by default, like the other off.
     */
    var panMarginPx = 0f

    // ---- physical mouse and keyboard --------------------------------------

    /**
     * Ask for the pointer when the session has focus, so a real mouse reports
     * relative motion and the local cursor cannot leave the window. Off falls
     * back to deriving deltas from the local pointer's position, which stops
     * dead at the screen edge — which is why the original, which never captures,
     * needs an edge auto-scroll at all.
     */
    var mouseCapture = true
    var mouseSpeed = 1.0f     // 1.0 is the pointer profile the phone already applied
    var mouseWheelStep = 1.0f // clicks per detent; not wheelStepPx, which is finger travel

    init {
        moveThresholdPx = dp(12f)
        bumpBorderPx = dp(24f)
        bumpDeltaPx = dp(12f)
        // Speeds are dp/ms. The recorded precision gestures and the purposeful
        // ones sit two decades apart, so every threshold below falls in the gap
        // between them: 0.15 dp/ms is placing the cursor, 0.6 is a real drag.
        accelSlowSpeedPx = dp(0.15f)
        accelFullSpeedPx = dp(0.60f)
        axisLockMaxSpeedPx = dp(0.25f)
        axisLockTurnSpanPx = dp(36f)
        hoverAssistMaxSpeedPx = dp(0.35f) // above the axis lock's band, and a little over
        hoverAssistSpanPx = dp(12f)        // 4.5 dp of it is withheld
        hoverAssistMinTravelPx = dp(6f)
        overlayStripWidthPx = dp(60f)
        overlayRowHeightPx = dp(72f)
        overlayDismissPx = dp(40f)
        overlayDismissMarginPx = dp(17.5f)
        overlayMiddleMinPx = dp(100f)
        keyboardKeyHeightPx = dp(46f)
        keyboardKeyHeightMultiPx = dp(40f)
        keyboardInfoHeightPx = dp(30f)
        keyboardKeyPadPx = dp(8f)
        keyboardKeyPadWidePx = dp(12f)
        keyboardGroupGapPx = dp(22f) // enough to group, not enough to look like a break
        keyboardIconWidthPx = dp(18f)
        keyboardMinKeyWidthPx = dp(32f)
        keyboardScrollSlopPx = dp(8f)
        toolbarButtonPx = dp(44f)
        toolbarGripPx = dp(24f)
        toolbarDragSlopPx = dp(8f)
        keyboardFlingMinPx = dp(0.3f)
        keyboardFlingStopPx = dp(0.02f)
    }

    fun dp(v: Float): Float = v * density

    /** Adopt every setting of [o], so a preset can be swapped under a running stack. */
    fun copyFrom(o: Config) {
        faithfulPreset = o.faithfulPreset
        moveThresholdPx = o.moveThresholdPx
        tapPathThresholdPx = o.tapPathThresholdPx
        moveCountTest = o.moveCountTest
        moveCountLimit = o.moveCountLimit
        tapMaxDurationMs = o.tapMaxDurationMs
        clickHoldMs = o.clickHoldMs
        flickMinDistPx = o.flickMinDistPx
        bumpScrollEnabled = o.bumpScrollEnabled
        bumpBorderPx = o.bumpBorderPx
        bumpDeltaPx = o.bumpDeltaPx
        bumpPeriodMs = o.bumpPeriodMs
        bumpStopOutsideBorder = o.bumpStopOutsideBorder
        zoomRatio = o.zoomRatio
        scrollRatio = o.scrollRatio
        wheelStepPx = o.wheelStepPx
        naturalScrolling = o.naturalScrolling
        accelEnabled = o.accelEnabled
        accelDrainHistory = o.accelDrainHistory
        accelResetOnDown = o.accelResetOnDown
        accelBase = o.accelBase
        accelExponent = o.accelExponent
        accelMin = o.accelMin
        accelMax = o.accelMax
        accelAdaptive = o.accelAdaptive
        accelSlowSpeedPx = o.accelSlowSpeedPx
        accelFullSpeedPx = o.accelFullSpeedPx
        axisLockEnabled = o.axisLockEnabled
        axisLockMaxSpeedPx = o.axisLockMaxSpeedPx
        axisLockEnterRatio = o.axisLockEnterRatio
        axisLockExitRatio = o.axisLockExitRatio
        hoverAssistEnabled = o.hoverAssistEnabled
        hoverAssistSpanPx = o.hoverAssistSpanPx
        hoverAssistGain = o.hoverAssistGain
        hoverAssistMaxSpeedPx = o.hoverAssistMaxSpeedPx
        hoverAssistIdleMs = o.hoverAssistIdleMs
        hoverAssistMinTravelPx = o.hoverAssistMinTravelPx
        hoverAssistBurstCount = o.hoverAssistBurstCount
        hoverAssistBurstMs = o.hoverAssistBurstMs
        hoverAssistLockoutMs = o.hoverAssistLockoutMs
        hoverAssistMaxLagMs = o.hoverAssistMaxLagMs
        rawMotionWhenRelative = o.rawMotionWhenRelative
        axisLockTurnSpanPx = o.axisLockTurnSpanPx
        axisLockMaxTurnDeg = o.axisLockMaxTurnDeg
        axisLockCornerDeg = o.axisLockCornerDeg
        overlayStripWidthPx = o.overlayStripWidthPx
        overlayRowHeightPx = o.overlayRowHeightPx
        overlayDismissPx = o.overlayDismissPx
        overlayDismissMarginPx = o.overlayDismissMarginPx
        overlayMiddleMinPx = o.overlayMiddleMinPx
        overlayWheelTickMs = o.overlayWheelTickMs
        overlayWheelMaxRate = o.overlayWheelMaxRate
        overlayWheelTicksPerClick = o.overlayWheelTicksPerClick
        overlayWheelStartDelayTicks = o.overlayWheelStartDelayTicks
        keyboardKeyHeightPx = o.keyboardKeyHeightPx
        keyboardKeyHeightMultiPx = o.keyboardKeyHeightMultiPx
        keyboardInfoHeightPx = o.keyboardInfoHeightPx
        keyboardKeyPadPx = o.keyboardKeyPadPx
        keyboardKeyPadWidePx = o.keyboardKeyPadWidePx
        keyboardGroupGapPx = o.keyboardGroupGapPx
        keyboardIconWidthPx = o.keyboardIconWidthPx
        keyboardMinKeyWidthPx = o.keyboardMinKeyWidthPx
        keyboardScrollSlopPx = o.keyboardScrollSlopPx
        keyboardFlingTickMs = o.keyboardFlingTickMs
        keyboardFlingDecay = o.keyboardFlingDecay
        keyboardFlingMinPx = o.keyboardFlingMinPx
        keyboardFlingStopPx = o.keyboardFlingStopPx
        keyDoubleTapMs = o.keyDoubleTapMs
        keyLongPressMs = o.keyLongPressMs
        keyRepeatMs = o.keyRepeatMs
        keyboardHaptics = o.keyboardHaptics
        keyboardInfoMaxChars = o.keyboardInfoMaxChars
        keyboardInfoSolid = o.keyboardInfoSolid
        toolbarButtonPx = o.toolbarButtonPx
        toolbarGripPx = o.toolbarGripPx
        toolbarDragSlopPx = o.toolbarDragSlopPx
        inertiaEnabled = o.inertiaEnabled
        inertiaStartDelayMs = o.inertiaStartDelayMs
        inertiaTickMs = o.inertiaTickMs
        inertiaSpeedScale = o.inertiaSpeedScale
        inertiaSpeedMax = o.inertiaSpeedMax
        inertiaDecay = o.inertiaDecay
        inertiaStopSpeed = o.inertiaStopSpeed
        inertiaCancelOnDown = o.inertiaCancelOnDown
        inertiaResetOnDown = o.inertiaResetOnDown
        recentreCursorOnZoom = o.recentreCursorOnZoom
        coalescePointerEvents = o.coalescePointerEvents
        dedupePointerEvents = o.dedupePointerEvents
        panMarginInsets = o.panMarginInsets
        panMarginPx = o.panMarginPx
        mouseCapture = o.mouseCapture
        mouseSpeed = o.mouseSpeed
        mouseWheelStep = o.mouseWheelStep
    }

    companion object {
        /** Bug-for-bug reproduction of RealVNC Viewer 4.9.1. */
        @JvmStatic
        fun faithful(density: Float): Config {
            val c = Config(density)
            c.faithfulPreset = true
            c.moveCountTest = true
            c.tapPathThresholdPx = 0f
            c.tapMaxDurationMs = 0
            c.bumpStopOutsideBorder = false
            c.accelDrainHistory = true
            c.accelResetOnDown = false
            c.inertiaCancelOnDown = false
            c.inertiaResetOnDown = false
            c.coalescePointerEvents = false
            c.dedupePointerEvents = false
            return c
        }

        /** The version we actually want to ship. */
        @JvmStatic
        fun improved(density: Float): Config {
            val c = Config(density)
            c.faithfulPreset = false
            c.moveCountTest = false
            c.tapPathThresholdPx = c.dp(24f)
            c.tapMaxDurationMs = 0
            c.bumpStopOutsideBorder = true
            c.accelDrainHistory = true // still the original curve; toggle separately
            c.accelAdaptive = true
            c.axisLockEnabled = true
            c.hoverAssistEnabled = true
            c.accelResetOnDown = true
            c.inertiaCancelOnDown = true
            c.inertiaResetOnDown = true
            c.coalescePointerEvents = true
            c.dedupePointerEvents = true
            return c
        }
    }
}
