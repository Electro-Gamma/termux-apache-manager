// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later
package net.pgaskin.remotedesktop.control.input

/**
 * One touch event's worth of pointers, reusable: the recogniser gets these on the hot path, so
 * they are filled in place rather than allocated.
 */
class TouchFrame {

    enum class Action(private val code: String) {
        DOWN("D"), MOVE("M"), UP("U"), CANCEL("C");

        fun code(): String = code

        companion object {
            fun fromCode(code: String): Action = when (code) {
                "D" -> DOWN
                "M" -> MOVE
                "U" -> UP
                "C" -> CANCEL
                else -> throw IllegalArgumentException("bad action $code")
            }
        }
    }

    var action: Action = Action.DOWN
    var index = 0
    var time = 0L
    var count = 0
    val id = IntArray(MAX_POINTERS)
    val x = FloatArray(MAX_POINTERS)
    val y = FloatArray(MAX_POINTERS)

    fun set(action: Action, index: Int, time: Long): TouchFrame {
        this.action = action
        this.index = index
        this.time = time
        count = 0
        return this
    }

    fun add(id: Int, x: Float, y: Float): TouchFrame {
        if (count < MAX_POINTERS) {
            this.id[count] = id
            this.x[count] = x
            this.y[count] = y
            count++
        }
        return this
    }

    fun copy(): TouchFrame {
        val f = TouchFrame().set(action, index, time)
        for (i in 0 until count) {
            f.add(id[i], x[i], y[i])
        }
        return f
    }

    override fun toString(): String {
        val sb = StringBuilder()
        sb.append(time).append(' ').append(action.code())
        if (action == Action.DOWN || action == Action.UP) {
            sb.append(' ').append(index)
        }
        for (i in 0 until count) {
            sb.append(" | ").append(id[i]).append(' ').append(x[i]).append(' ').append(y[i])
        }
        return sb.toString()
    }

    companion object {
        const val MAX_POINTERS = 10
    }
}
