// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later
package net.pgaskin.remotedesktop.control.input

/**
 * The on-screen mouse buttons: three buttons across the bottom, a dismiss corner, and a wheel strip
 * up the right edge. Model and hit-testing only, drawn by the view. Several pointers at once is the
 * point — a thumb on LEFT and a finger on the strip is a legitimate combination.
 */
class MouseOverlay(
    private val cfg: Config,
    private val sink: MouseSink,
    private val scheduler: Scheduler,
) : TouchRouter.Claim {

    interface Listener {
        fun overlayChanged()
    }

    enum class Part(private val button: Button?) {
        LEFT(Button.LEFT), MIDDLE(Button.MIDDLE), RIGHT(Button.RIGHT),
        DISMISS(null), // the corner ✕
        SCROLL(null); // the wheel strip up the right-hand edge

        fun button(): Button? = button
    }

    data class Bounds(
        val part: Part,
        val left: Float,
        val top: Float,
        val right: Float,
        val bottom: Float,
    ) {
        fun contains(x: Float, y: Float): Boolean = x >= left && x < right && y >= top && y < bottom

        fun width(): Float = right - left

        fun height(): Float = bottom - top

        fun centreY(): Float = (top + bottom) / 2.0f
    }

    private var listener: Listener? = null
    private var viewW = 0
    private var viewH = 0
    private val parts = ArrayList<Bounds>()
    private var visible = false

    // Claimed pointers: which part each one is on.
    private val ptrId = IntArray(TouchFrame.MAX_POINTERS)
    private val ptrPart = arrayOfNulls<Part>(TouchFrame.MAX_POINTERS)
    private var ptrCount = 0
    private var heldMask = 0

    // ---- the wheel strip --------------------------------------------------
    private var scrollPtr = -1 // pointer driving the strip: only the first to land on it
    private var rate = 0f // signed wheel rate, negative is up, 0 when not scrolling
    private var ticks = 0 // since the last click; starts negative for the repeat delay
    private var ticking = false
    private var handleY = 0f // centre of the drag handle; the strip's middle at rest

    private val wheelTick = Runnable {
        ticking = false
        if (rate != 0.0f) {
            ticks++
            if (ticks >= cfg.overlayWheelTicksPerClick / Math.abs(rate)) {
                click()
                ticks = 0
            }
            schedule()
        }
    }

    fun setListener(l: Listener?) {
        listener = l
    }

    fun setViewSize(w: Int, h: Int) {
        if (w == viewW && h == viewH) {
            return
        }
        viewW = w
        viewH = h
        layout()
        changed()
    }

    fun viewWidth(): Int = viewW

    fun viewHeight(): Int = viewH

    fun visible(): Boolean = visible

    fun toggle() {
        setVisible(!visible)
    }

    fun setVisible(v: Boolean) {
        if (visible == v) {
            return
        }
        visible = v
        if (!visible) {
            releaseAll()
        }
        changed()
    }

    fun parts(): List<Bounds> = parts

    fun bounds(p: Part): Bounds? = parts.firstOrNull { it.part == p }

    fun pressed(p: Part): Boolean {
        for (i in 0 until ptrCount) {
            if (ptrPart[i] == p) {
                return true
            }
        }
        return false
    }

    fun heldMask(): Int = heldMask

    fun insetRightPx(): Float = if (visible) cfg.overlayStripWidthPx else 0f

    fun insetBottomPx(): Float = if (visible) cfg.overlayRowHeightPx else 0f

    fun scrollRate(): Float = rate

    fun handleTop(): Float = handleY - handleHeight() / 2.0f

    fun handleBottom(): Float = handleY + handleHeight() / 2.0f

    fun handleHeight(): Float {
        val s = bounds(Part.SCROLL)
        return if (s == null) 0f else s.height() / 3.0f + cfg.dp(40f)
    }

    // ---- layout -----------------------------------------------------------

    private fun layout() {
        parts.clear()
        if (viewW <= 0 || viewH <= 0) {
            return
        }
        val w = viewW.toFloat()
        val h = viewH.toFloat()
        val rowTop = h - cfg.overlayRowHeightPx
        parts.add(Bounds(Part.SCROLL, w - cfg.overlayStripWidthPx, 0f, w, rowTop))
        // The dismiss button and its end margin come off the row first; the three buttons share
        // what is left, 2:1:2.
        val row = w - cfg.overlayDismissPx - cfg.overlayDismissMarginPx
        val mid = maxOf(cfg.overlayMiddleMinPx, row / 5.0f)
        val side = maxOf(0f, (row - mid) / 2.0f)
        parts.add(Bounds(Part.LEFT, 0f, rowTop, side, h))
        parts.add(Bounds(Part.MIDDLE, side, rowTop, side + mid, h))
        parts.add(Bounds(Part.RIGHT, side + mid, rowTop, row, h))
        val dc = h - cfg.overlayRowHeightPx / 2.0f
        parts.add(
            Bounds(
                Part.DISMISS, row,
                dc - cfg.overlayDismissPx / 2.0f,
                row + cfg.overlayDismissPx,
                dc + cfg.overlayDismissPx / 2.0f,
            ),
        )
        centreHandle()
    }

    private fun centreHandle() {
        val s = bounds(Part.SCROLL)
        handleY = s?.centreY() ?: 0f
    }

    // ---- TouchRouter.Claim ------------------------------------------------

    override fun claimTouch(id: Int, x: Float, y: Float, t: Long): Boolean {
        if (!visible || ptrCount == ptrId.size) {
            return false
        }
        val hit = hit(x, y) ?: return false
        ptrId[ptrCount] = id
        ptrPart[ptrCount] = hit
        ptrCount++
        val button = hit.button()
        if (button != null) {
            press(button)
        } else if (hit == Part.SCROLL && scrollPtr < 0) {
            scrollPtr = id
            // Rate from where the finger landed, so a tap anywhere on the strip is exactly one
            // wheel click. The original waits for movement, and only from a finger that landed on
            // the handle itself.
            drag(y)
        }
        changed()
        return true
    }

    override fun claimMoved(id: Int, x: Float, y: Float, t: Long) {
        val i = indexOf(id)
        if (i < 0) {
            return
        }
        if (ptrPart[i] == Part.SCROLL && id == scrollPtr) {
            drag(y)
            changed()
        }
        // A finger sliding off a button keeps it down, as a Button does: the release is what
        // matters, and a thumb resting on a button drifts.
    }

    override fun claimEnded(id: Int, x: Float, y: Float, t: Long) {
        val i = indexOf(id)
        if (i < 0) {
            return
        }
        val part = ptrPart[i]!!
        forget(i)
        val button = part.button()
        if (button != null) {
            release(button)
        } else if (part == Part.SCROLL && id == scrollPtr) {
            stopScrolling()
        } else if (part == Part.DISMISS) {
            // Only if the finger is still on it, like an ordinary click.
            val b = bounds(Part.DISMISS)
            if (b != null && b.contains(x, y)) {
                setVisible(false)
            }
        }
        changed()
    }

    override fun claimCancelled(t: Long) {
        releaseAll()
        changed()
    }

    private fun hit(x: Float, y: Float): Part? = parts.firstOrNull { it.contains(x, y) }?.part

    // ---- buttons ----------------------------------------------------------

    private fun press(b: Button) {
        if ((heldMask and b.mask()) == 0) {
            heldMask = heldMask or b.mask()
            sink.mouseDown(b.mask())
        }
    }

    private fun release(b: Button) {
        // Another finger may be on the same button; the last one out releases.
        for (i in 0 until ptrCount) {
            if (ptrPart[i]!!.button() == b) {
                return
            }
        }
        if ((heldMask and b.mask()) != 0) {
            heldMask = heldMask and b.mask().inv()
            sink.mouseUp(b.mask())
        }
    }

    private fun releaseAll() {
        ptrCount = 0
        stopScrolling()
        if (heldMask != 0) {
            val m = heldMask
            heldMask = 0
            sink.mouseUp(m)
        }
    }

    // ---- the wheel strip --------------------------------------------------

    private fun drag(y: Float) {
        val s = bounds(Part.SCROLL)
        if (s == null || s.height() <= 0) {
            return
        }
        handleY = clamp(y, s.top + handleHeight() / 2.0f, s.bottom - handleHeight() / 2.0f)
        val half = s.height() / 2.0f
        setRate(clamp((y - s.centreY()) / half, -1.0f, 1.0f) * cfg.overlayWheelMaxRate)
    }

    private fun setRate(r: Float) {
        if (rate == 0.0f && r != 0.0f) {
            // First click immediately, then a pause before the repeat starts — key repeat, so a
            // single click is easy to land.
            click(r)
            ticks = -cfg.overlayWheelStartDelayTicks
            rate = r
            schedule()
        } else if (r == 0.0f) {
            // The finger is still on the strip — it is at the middle, where the rate is zero.
            // Anything that forgot which pointer owned the strip here would stop reading it for the
            // rest of the gesture, and a slow drag through the centre lands on it exactly.
            pauseScrolling()
        } else {
            rate = r
        }
    }

    private fun stopScrolling() {
        scrollPtr = -1
        pauseScrolling()
    }

    private fun pauseScrolling() {
        rate = 0f
        ticks = 0
        if (ticking) {
            ticking = false
            scheduler.removeCallbacks(wheelTick)
        }
        centreHandle()
    }

    private fun schedule() {
        if (!ticking) {
            ticking = true
            scheduler.postDelayed(wheelTick, cfg.overlayWheelTickMs)
        }
    }

    private fun click() {
        click(rate)
    }

    private fun click(r: Float) {
        val b = if (r < 0) Button.WHEEL_UP else Button.WHEEL_DOWN
        sink.mouseDown(b.mask())
        sink.mouseUp(b.mask())
    }

    // ---- pointer bookkeeping ----------------------------------------------

    private fun indexOf(id: Int): Int {
        for (i in 0 until ptrCount) {
            if (ptrId[i] == id) {
                return i
            }
        }
        return -1
    }

    private fun forget(i: Int) {
        ptrCount--
        ptrId[i] = ptrId[ptrCount]
        ptrPart[i] = ptrPart[ptrCount]
    }

    private fun changed() {
        listener?.overlayChanged()
    }

    private companion object {
        fun clamp(v: Float, lo: Float, hi: Float): Float = if (v < lo) lo else if (v > hi) hi else v
    }
}
