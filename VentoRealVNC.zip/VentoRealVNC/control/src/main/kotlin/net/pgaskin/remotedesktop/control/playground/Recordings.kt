// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later
package net.pgaskin.remotedesktop.control.playground

import android.content.Context
import android.util.Log
import java.io.File

/** The files the playground's recorders leave in the app's external files directory. */
object Recordings {

    private const val TAG = "Recordings"
    internal const val TOUCH = "touchlogs"
    internal const val KEYS = "keytrace"

    internal fun dir(ctx: Context, name: String): File? {
        val files = ctx.getExternalFilesDir(null)
        return if (files == null) null else File(files, name)
    }

    /** Whether there is anything recorded to clear. */
    fun any(ctx: Context): Boolean {
        for (name in arrayOf(TOUCH, KEYS)) {
            val files = dir(ctx, name)?.list()
            if (files != null && files.isNotEmpty()) {
                return true
            }
        }
        return false
    }

    /** Delete every recording; returns how many files went. */
    fun clear(ctx: Context): Int {
        var gone = 0
        for (name in arrayOf(TOUCH, KEYS)) {
            val files = dir(ctx, name)?.listFiles() ?: continue
            for (f in files) {
                if (f.delete()) {
                    gone++
                } else {
                    Log.w(TAG, "could not delete $f")
                }
            }
        }
        return gone
    }
}
