// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later
package net.pgaskin.remotedesktop.control.input

import android.view.MotionEvent

/**
 * A physical mouse or trackpad, as relative motion, buttons and scroll for a [MouseSink]. The model
 * (`motion`, `buttonState`, `scroll`) knows nothing of Android; the `on…Event` methods adapt
 * `MotionEvent`s to it, for a captured pointer, for hover and for a mouse reported as touch.
 */
class PhysicalMouse(private val cfg: Config, private val sink: MouseSink) {

    interface Listener {
        fun mouseActivity()
    }

    private var listener: Listener? = null
    private var held = 0 // its own button source, so nothing else's is lost
    private val wheel = WheelSteps(sink) // the notches not yet worth a click live in here
    private var lastX = 0f
    private var lastY = 0f // the last uncaptured position, to derive deltas from
    private var havePosition = false
    private var seen = false // so the HUD can say "none"

    fun setListener(l: Listener?) {
        listener = l
    }

    fun heldMask(): Int = held

    fun seen(): Boolean = seen

    // ---- the model ---------------------------------------------------------

    fun motion(dx: Float, dy: Float) {
        if (dx == 0f && dy == 0f) {
            return
        }
        seen = true
        sink.mouseMove(dx * cfg.mouseSpeed, dy * cfg.mouseSpeed)
    }

    fun buttonState(androidButtons: Int) {
        val now = toRfbMask(androidButtons)
        if (now == held) {
            return
        }
        seen = true
        val pressed = now and held.inv()
        val released = held and now.inv()
        held = now
        // Released first: a chord that swaps one button for another should not be seen by the far
        // end as both held at once.
        if (released != 0) {
            sink.mouseUp(released)
        }
        if (pressed != 0) {
            sink.mouseDown(pressed)
        }
        changed()
    }

    fun scroll(hscroll: Float, vscroll: Float) {
        if (hscroll == 0f && vscroll == 0f) {
            return
        }
        seen = true
        val sign = if (cfg.naturalScrolling) -1.0f else 1.0f
        // Android's vertical axis is positive *up*; the wheel buttons count down, as the gesture
        // layer's do.
        wheel.add(hscroll * sign, -vscroll * sign, cfg.mouseWheelStep)
    }

    fun cancel() {
        havePosition = false
        wheel.reset()
        if (held != 0) {
            sink.mouseUp(held)
            held = 0
            changed()
        }
    }

    private fun changed() {
        listener?.mouseActivity()
    }

    // ---- the Android adapters ----------------------------------------------

    /** A captured pointer's events, which carry relative motion directly. */
    fun onCapturedPointerEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_MOVE, MotionEvent.ACTION_HOVER_MOVE -> {
                // Batched samples first: a 1000 Hz mouse delivers several per frame and dropping
                // them would quietly halve its resolution.
                for (h in 0 until ev.historySize) {
                    motion(ev.getHistoricalX(h), ev.getHistoricalY(h))
                }
                motion(ev.x, ev.y)
            }
            MotionEvent.ACTION_BUTTON_PRESS, MotionEvent.ACTION_BUTTON_RELEASE,
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_UP,
            -> buttonState(ev.buttonState)
            MotionEvent.ACTION_SCROLL -> scroll(
                ev.getAxisValue(MotionEvent.AXIS_HSCROLL),
                ev.getAxisValue(MotionEvent.AXIS_VSCROLL),
            )
            else -> return false
        }
        return true
    }

    /** An uncaptured mouse's hover and scroll events, whose deltas are derived from position. */
    fun onGenericMotionEvent(ev: MotionEvent): Boolean {
        if (!isMouse(ev)) {
            return false
        }
        when (ev.actionMasked) {
            MotionEvent.ACTION_HOVER_MOVE -> {
                for (h in 0 until ev.historySize) {
                    moveTo(ev.getHistoricalX(h), ev.getHistoricalY(h))
                }
                moveTo(ev.x, ev.y)
                buttonState(ev.buttonState)
            }
            MotionEvent.ACTION_HOVER_ENTER -> {
                lastX = ev.x
                lastY = ev.y
                havePosition = true
                seen = true
            }
            MotionEvent.ACTION_HOVER_EXIT -> havePosition = false
            MotionEvent.ACTION_SCROLL -> scroll(
                ev.getAxisValue(MotionEvent.AXIS_HSCROLL),
                ev.getAxisValue(MotionEvent.AXIS_VSCROLL),
            )
            else -> return false
        }
        return true
    }

    /** An uncaptured mouse's button-down drags, which Android reports as touch. */
    fun onTouchEvent(ev: MotionEvent): Boolean {
        if (!isMouse(ev)) {
            return false
        }
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = ev.x
                lastY = ev.y
                havePosition = true
                buttonState(ev.buttonState)
            }
            MotionEvent.ACTION_MOVE -> {
                for (h in 0 until ev.historySize) {
                    moveTo(ev.getHistoricalX(h), ev.getHistoricalY(h))
                }
                moveTo(ev.x, ev.y)
                buttonState(ev.buttonState)
            }
            MotionEvent.ACTION_UP -> {
                moveTo(ev.x, ev.y)
                // A mouse's own up reports no buttons, which is the release.
                buttonState(ev.buttonState)
                havePosition = false
            }
            MotionEvent.ACTION_CANCEL -> cancel()
            else -> return false
        }
        return true
    }

    private fun moveTo(x: Float, y: Float) {
        if (havePosition) {
            motion(x - lastX, y - lastY)
        }
        lastX = x
        lastY = y
        havePosition = true
    }

    companion object {
        // MotionEvent button bits, as literals so this class stays testable.
        private const val BUTTON_PRIMARY = 1
        private const val BUTTON_SECONDARY = 2
        private const val BUTTON_TERTIARY = 4
        private const val BUTTON_BACK = 8
        private const val BUTTON_FORWARD = 16

        internal fun toRfbMask(androidButtons: Int): Int {
            var m = 0
            if ((androidButtons and BUTTON_PRIMARY) != 0) m = m or Button.LEFT.mask()
            if ((androidButtons and BUTTON_SECONDARY) != 0) m = m or Button.RIGHT.mask()
            if ((androidButtons and BUTTON_TERTIARY) != 0) m = m or Button.MIDDLE.mask()
            if ((androidButtons and BUTTON_BACK) != 0) m = m or Button.BACK.mask()
            if ((androidButtons and BUTTON_FORWARD) != 0) m = m or Button.FORWARD.mask()
            return m
        }

        /** Whether [ev] came from a mouse or trackpad, as opposed to a finger or a stylus. */
        fun isMouse(ev: MotionEvent): Boolean {
            // SOURCE_MOUSE, and SOURCE_MOUSE_RELATIVE for a captured or trackpad device that
            // reports relative motion of its own accord.
            val source = ev.source
            if ((source and 0x2002) == 0x2002 || (source and 0x8002) == 0x8002) {
                // A stylus reports SOURCE_MOUSE on some devices; it is a third input model
                // (absolute, and with a hover of its own) and not this one.
                return ev.pointerCount == 0 || ev.getToolType(0) != MotionEvent.TOOL_TYPE_STYLUS
            }
            return false
        }
    }
}
