// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later
package net.pgaskin.remotedesktop.control.input

/** A mouse button, as its RFB mask bit. */
enum class Button(private val mask: Int) {
    LEFT(1),
    MIDDLE(2),
    RIGHT(4),
    WHEEL_UP(8),
    WHEEL_DOWN(16),
    WHEEL_LEFT(32),
    WHEEL_RIGHT(64),
    BACK(128),
    FORWARD(256);

    fun mask(): Int = mask

    /** Whether this button is one of the bits of [mask]. */
    fun `in`(mask: Int): Boolean = (mask and this.mask) != 0

    companion object {
        val DRAG_MASK = LEFT.mask or MIDDLE.mask or RIGHT.mask
        val CLICK_MASK = DRAG_MASK or BACK.mask or FORWARD.mask

        private val ALL = values()
        private val KNOWN_MASK = ALL.fold(0) { m, b -> m or b.mask }

        /** The lowest-numbered button in [mask], or null. */
        fun lowest(mask: Int): Button? = ALL.firstOrNull { it.`in`(mask) }

        /** For a log: `LEFT+RIGHT`, or `-` for none. */
        fun maskName(mask: Int): String {
            if (mask == 0) {
                return "-"
            }
            val sb = StringBuilder()
            for (b in ALL) {
                if (b.`in`(mask)) {
                    if (sb.isNotEmpty()) {
                        sb.append('+')
                    }
                    sb.append(b)
                }
            }
            // RFB allows buttons 8 and up; nothing here emits them, but a backend reading a mask
            // off the wire could hand one back.
            val unknown = mask and KNOWN_MASK.inv()
            if (unknown != 0) {
                if (sb.isNotEmpty()) {
                    sb.append('+')
                }
                sb.append("0x").append(Integer.toHexString(unknown))
            }
            return sb.toString()
        }
    }
}
