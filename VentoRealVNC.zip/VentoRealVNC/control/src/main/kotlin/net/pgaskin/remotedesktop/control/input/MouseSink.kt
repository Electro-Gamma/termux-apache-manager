// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later
package net.pgaskin.remotedesktop.control.input

/** Where the mouse goes: relative motion in desktop pixels, and RFB button masks. */
interface MouseSink {
    fun mouseMove(dx: Float, dy: Float)

    fun mouseDown(mask: Int)

    fun mouseUp(mask: Int)
}
