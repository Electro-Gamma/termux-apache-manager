// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later
package net.pgaskin.remotedesktop.control

import java.util.Arrays

/**
 * Where the desktop sits in the window: scale, origin, the insets that other things cover, and the
 * ladder of zoom levels the zoom buttons step through. Pure geometry, no Android.
 *
 * Screen coordinates are window pixels; desktop coordinates are the far end's framebuffer pixels.
 */
class Viewport(density: Float) {

    private val density: Float = maxOf(density, 1.0f)

    private var fbW = 1
    private var fbH = 1
    private var viewW = 0
    private var viewH = 0
    private var insetL = 0
    private var insetT = 0
    private var insetR = 0
    private var insetB = 0
    private var marginL = 0
    private var marginT = 0
    private var marginR = 0
    private var marginB = 0
    private var scale = 1.0f
    private var originX = 0f
    private var originY = 0f
    private var focusX = 0f
    private var focusY = 0f // scale focus, in desktop coords

    // The zoom-button ladder, ascending, and its cursor.
    private var ladder = FloatArray(0)
    private var ladderIndex = 0
    private var fitSizes = IntArray(0)

    fun setDesktopSize(w: Int, h: Int) {
        fbW = maxOf(w, 1)
        fbH = maxOf(h, 1)
        rebuildLadder()
    }

    fun setViewSize(w: Int, h: Int) {
        viewW = w
        viewH = h
        rebuildLadder()
    }

    /** Space the desktop must keep clear of (an IME, a toolbar), in window pixels. */
    fun setInsets(left: Int, top: Int, right: Int, bottom: Int) {
        insetL = maxOf(left, 0)
        insetT = maxOf(top, 0)
        insetR = maxOf(right, 0)
        insetB = maxOf(bottom, 0)
        rebuildLadder()
    }

    /**
     * How far each edge of the desktop may be carried in from the edge of the window, leaving blank
     * beside it: the shape of a phone's window is not a rectangle.
     */
    fun setPanMargins(left: Int, top: Int, right: Int, bottom: Int) {
        val l = maxOf(left, 0)
        val t = maxOf(top, 0)
        val r = maxOf(right, 0)
        val b = maxOf(bottom, 0)
        if (l == marginL && t == marginT && r == marginR && b == marginB) {
            return
        }
        marginL = l
        marginT = t
        marginR = r
        marginB = b
        // A margin that shrank can leave the picture outside what the clamp now allows, and the
        // origin is not state that anything else here rewrites — so re-centring on the focus, which
        // is what every other thing that changes the shape of the window ends with, is what brings
        // it back.
        centreOn(focusX, focusY)
    }

    fun panMarginLeft(): Int = marginL

    fun panMarginTop(): Int = marginT

    fun panMarginRight(): Int = marginR

    fun panMarginBottom(): Int = marginB

    fun insetLeft(): Int = insetL

    fun insetTop(): Int = insetT

    fun insetRight(): Int = insetR

    fun insetBottom(): Int = insetB

    fun contentWidth(): Int = maxOf(viewW - insetL - insetR, 0)

    fun contentHeight(): Int = maxOf(viewH - insetT - insetB, 0)

    fun centreScreenX(): Float = insetL + contentWidth() / 2.0f

    fun centreScreenY(): Float = insetT + contentHeight() / 2.0f

    fun desktopWidth(): Int = fbW

    fun desktopHeight(): Int = fbH

    fun viewWidth(): Int = viewW

    fun viewHeight(): Int = viewH

    fun getScale(): Float = scale

    fun originX(): Float = originX

    fun originY(): Float = originY

    fun toScreenX(dx: Float): Float = dx * scale + originX

    fun toScreenY(dy: Float): Float = dy * scale + originY

    fun toDesktopX(sx: Float): Float = (sx - originX) / scale

    fun toDesktopY(sy: Float): Float = (sy - originY) / scale

    fun setFocus(dx: Float, dy: Float) {
        focusX = dx
        focusY = dy
    }

    fun focusX(): Float = focusX

    fun focusY(): Float = focusY

    /** The scale at which the whole desktop fits. */
    fun minScale(): Float {
        if (contentWidth() == 0 || contentHeight() == 0) {
            return 1.0f
        }
        return minOf(contentWidth().toFloat() / fbW, contentHeight().toFloat() / fbH)
    }

    /** The scale at which the desktop fills the window on both axes. */
    fun fillScale(): Float {
        if (contentWidth() == 0 || contentHeight() == 0) {
            return 1.0f
        }
        return maxOf(contentWidth().toFloat() / fbW, contentHeight().toFloat() / fbH)
    }

    fun maxScale(): Float = 2.0f * Math.floor(density.toDouble()).toFloat()

    /** Quantise [s], then snap to whole-pixel multiples and the fit scales when within 4%. */
    fun snapScale(s: Float): Float {
        var q = (s * 128.0f).toInt() / 128.0f
        val w = fbW * q
        val steps = Math.floor(density.toDouble()).toInt()
        for (k in 1..steps) {
            q = snapTo(q, w, (fbW * k).toFloat())
        }
        if (contentWidth() > 0 && contentHeight() > 0) {
            q = snapTo(q, w, contentWidth().toFloat()) // fit width
            q = snapTo(q, w, fbW * (contentHeight().toFloat() / fbH)) // fit height
        }
        return clamp(q, minScale(), maxScale())
    }

    private fun snapTo(q: Float, w: Float, candidateW: Float): Float {
        if (candidateW > 0 && Math.abs(w - candidateW) <= 0.04f * candidateW) {
            return candidateW / fbW
        }
        return q
    }

    fun setScale(s: Float) {
        centreOn(focusX, focusY, snapScale(s))
    }

    fun centreOn(dx: Float, dy: Float) {
        centreOn(dx, dy, scale)
    }

    /** Put desktop point ([dx], [dy]) at the middle of the content area at scale [s], clamped to the edges. */
    fun centreOn(dx: Float, dy: Float, s: Float) {
        val cw = contentWidth()
        val ch = contentHeight()
        if (cw == 0 || ch == 0) {
            scale = s
            return
        }
        val scaleChanged = scale != s
        scale = s
        val ox = centreScreenX() - dx * s
        val oy = centreScreenY() - dy * s
        val dw = fbW * s
        val dh = fbH * s
        originX = clampAxis(ox, insetL, cw, dw, (viewW - dw) / 2.0f, marginL, marginR)
        originY = clampAxis(oy, insetT, ch, dh, (viewH - dh) / 2.0f, marginT, marginB)
        // The original stores the viewport centre back as the scale focus.
        focusX = toDesktopX(centreScreenX())
        focusY = toDesktopY(centreScreenY())
        if (scaleChanged) {
            selectNearestLadderEntry(s)
        }
    }

    fun panBy(screenDx: Float, screenDy: Float) {
        centreOn(focusX - screenDx / scale, focusY - screenDy / scale)
    }

    // ---- the zoom-button ladder (ScaleManager.z / A / B) ------------------

    fun zoomLadder(): FloatArray = ladder.clone()

    /** Pairs of width, height (desktop pixels) to add fit-to-size rungs for. */
    fun setFitSizes(vararg sizes: Int) {
        fitSizes = sizes.clone()
        rebuildLadder()
    }

    fun zoomIndex(): Int = ladderIndex

    fun canZoomIn(): Boolean = ladderIndex < ladder.size - 1

    fun canZoomOut(): Boolean = ladderIndex > 0

    fun nextZoomIn(): Float = if (canZoomIn()) ladder[ladderIndex + 1] else scale

    fun nextZoomOut(): Float = if (canZoomOut()) ladder[ladderIndex - 1] else scale

    fun zoomIn() {
        if (canZoomIn()) {
            setScale(ladder[ladderIndex + 1])
        }
    }

    fun zoomOut() {
        if (canZoomOut()) {
            setScale(ladder[ladderIndex - 1])
        }
    }

    fun zoomToFit() {
        setScale(minScale())
    }

    fun zoomToFill() {
        setScale(minOf(fillScale(), Math.floor(density.toDouble()).toFloat()))
    }

    private fun rebuildLadder() {
        if (contentWidth() == 0 || contentHeight() == 0) {
            ladder = FloatArray(0)
            ladderIndex = 0
            return
        }
        val fit = minScale()
        val raw = FloatArray(8 + 32 + fitSizes.size / 2)
        var n = 0
        var f = 1.0f
        while (f > fit && n < 32) {
            raw[n++] = snapScale(f)
            f *= 0.66f
        }
        raw[n++] = snapScale(1.5f)
        raw[n++] = snapScale(2.0f)
        raw[n++] = snapScale(fit)
        raw[n++] = snapScale(fillScale())
        var i = 0
        while (i + 1 < fitSizes.size) {
            val w = fitSizes[i]
            val h = fitSizes[i + 1]
            if (w > 0 && h > 0 && w <= fbW && h <= fbH) {
                raw[n++] = snapScale(minOf(contentWidth().toFloat() / w, contentHeight().toFloat() / h))
            }
            i += 2
        }
        Arrays.sort(raw, 0, n)
        val out = FloatArray(n)
        var m = 0
        for (j in 0 until n) {
            if (m == 0 || raw[j] - out[m - 1] > 1e-4f) {
                out[m++] = raw[j]
            }
        }
        ladder = out.copyOf(m)
        selectNearestLadderEntry(scale)
    }

    private fun selectNearestLadderEntry(s: Float) {
        var best = -1
        var bestErr = 0f
        for (i in ladder.indices) {
            val err = Math.abs(s - ladder[i])
            if (best < 0 || err < bestErr) {
                best = i
                bestErr = err
            }
        }
        ladderIndex = maxOf(best, 0)
    }

    companion object {
        @JvmStatic
        fun clamp(v: Float, lo: Float, hi: Float): Float = if (v < lo) lo else if (v > hi) hi else v

        private fun clampAxis(
            o: Float, inset: Int, content: Int, desktop: Float,
            centred: Float, marginLo: Int, marginHi: Int,
        ): Float {
            // Capped at half the content, so that no window can end up with more blank in it than
            // desktop.
            val mLo = minOf(marginLo.toFloat(), content / 2.0f)
            val mHi = minOf(marginHi.toFloat(), content / 2.0f)
            val lo: Float
            val hi: Float
            if (desktop < content) {
                val rest = clamp(centred, inset.toFloat(), inset + content - desktop)
                val blankLo = rest - inset
                val blankHi = inset + content - desktop - rest
                lo = rest - maxOf(mHi - blankHi, 0.0f)
                hi = rest + maxOf(mLo - blankLo, 0.0f)
            } else {
                lo = inset + content - desktop - mHi
                hi = inset + mLo
            }
            return clamp(o, lo, hi)
        }
    }
}
