// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later
package net.pgaskin.remotedesktop.control.input

/**
 * A detent on the pointer where the far end changed the cursor's shape.
 *
 * A shape change says one thing: whatever is under the pointer is different now. The pointer
 * loses a little distance *after* the news, over a bounded span of finger travel, so that a small
 * target is easier to stop on and harder to slide off. Nothing is pulled anywhere and nothing
 * teleports.
 *
 * **The news is a reply, and it is late** (ten to thirty ms against most far ends, a hundred and
 * forty against one that polls its own screen), which is why [changed] refuses to arm for a far
 * end measured too late to be helping.
 *
 * The budget is in *finger* travel rather than desktop pixels, so it is full strength zoomed out,
 * where a link is four screen pixels tall, and negligible zoomed in.
 */
internal class HoverAssist(private val cfg: Config) {

    private var budget = 0f // finger travel left in the detent, px
    private var armX = 0f
    private var armY = 0f // the direction it armed in; a reversal drops the rest
    private var lastDx = 0f
    private var lastDy = 0f
    private var travel = 0f // since the last change that armed
    private var lastMoveTime = -1L
    private var gain = 1.0f

    /**
     * The last move of a gesture that has ended, or -1 while one is running. A change arriving
     * after it is the only kind whose lateness can be measured.
     */
    private var gestureEnd = -1L
    private var lag = 0f

    // A shape changing on a timer would otherwise re-arm for ever, which is what these three count.
    private var burstStart = -1L
    private var burst = 0
    private var lockoutUntil = -1L

    fun reset() {
        budget = 0f
        travel = 0f
        lastMoveTime = -1
        gestureEnd = -1
        gain = 1.0f
        burstStart = -1
        burst = 0
        lockoutUntil = -1
        // The lag estimate survives: it is a fact about the far end, and a session's worth of it
        // is thrown away by a finger going down.
    }

    /** For the HUD: 1 outside a detent, [Config.hoverAssistGain] at its catch. */
    fun gain(): Float = gain

    /** The far end's measured lateness, ms, or 0 before anything has measured it. */
    fun lagMs(): Float = lag

    fun armed(): Boolean = budget > 0

    /** Whether a burst of changes has shut the mechanism off for the moment. */
    fun lockedOut(now: Long): Boolean = now < lockoutUntil

    /**
     * The factor this move is multiplied by, and the raw distance charged against the budget. Fed
     * the delta before the axis lock has been at it, since what is being spent is finger travel.
     */
    fun gain(dx: Float, dy: Float, t: Long): Float {
        lastMoveTime = t
        gestureEnd = -1
        lastDx = dx
        lastDy = dy
        val dist = Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
        travel += dist
        if (budget <= 0) {
            gain = 1.0f
            return gain
        }
        if (dx * armX + dy * armY < 0) {
            // Somebody reversing is somebody coming back to what they overshot, and slowing that
            // down is the opposite of help.
            budget = 0f
            gain = 1.0f
            return gain
        }
        val span = maxOf(cfg.hoverAssistSpanPx, 1e-3f)
        var u = (span - budget) / span // 0 at the change, 1 where the budget runs out
        u = if (u < 0) 0f else if (u > 1) 1f else u
        budget -= dist
        val s = u * u * (3 - 2 * u) // smoothstep: no kink at either end
        gain = cfg.hoverAssistGain + (1 - cfg.hoverAssistGain) * s
        return gain
    }

    /** No finger left on the screen, so the next change can be timed. */
    fun gestureEnded() {
        if (lastMoveTime >= 0) {
            gestureEnd = lastMoveTime
        }
    }

    /**
     * The far end has changed the cursor's shape. Five things have to hold before that opens a
     * detent, and four of them are the defence against a shape that changes for reasons that are
     * not a boundary.
     *
     * @param speed the smoothed finger speed [PointerAccel] keeps, px/ms
     * @param gliding whether a flick's momentum is still moving the pointer, which makes every
     *                change it causes untimeable
     */
    fun changed(speed: Float, t: Long, gliding: Boolean) {
        if (!cfg.hoverAssistEnabled || gliding) {
            return
        }
        if (gestureEnd >= 0 && t - gestureEnd <= LAG_WINDOW_MS) {
            // How late this far end is, from the one kind of change whose cause is known. A lower
            // bound rather than the interval itself. It cannot tell a late reply from a change the
            // far end made for itself, and does not have to: both are arguments against arming.
            lag += ((t - gestureEnd) - lag) * LAG_ALPHA
        }
        if (t < lockoutUntil) {
            return
        }
        if (speed >= cfg.hoverAssistMaxSpeedPx) {
            return // a purposeful drag is not aiming at anything
        }
        if (lastMoveTime < 0 || t - lastMoveTime > cfg.hoverAssistIdleMs) {
            return // nothing was moving, so this was not caused by us
        }
        if (travel < cfg.hoverAssistMinTravelPx) {
            return // two shapes in the same place are frames, not boundaries
        }
        if (lag > cfg.hoverAssistMaxLagMs) {
            return // the news is too old to be about where the pointer is
        }
        // The burst is counted over the changes that would otherwise arm, rather than over
        // everything that arrives.
        if (burstStart < 0 || t - burstStart > cfg.hoverAssistBurstMs) {
            burstStart = t
            burst = 0
        }
        if (++burst > cfg.hoverAssistBurstCount) {
            // An animated cursor running while the finger moves slowly is the one case the other
            // tests all pass.
            lockoutUntil = t + cfg.hoverAssistLockoutMs
            budget = 0f
            return
        }
        val len = Math.sqrt((lastDx * lastDx + lastDy * lastDy).toDouble()).toFloat()
        if (len <= 0) {
            return
        }
        armX = lastDx / len
        armY = lastDy / len
        budget = cfg.hoverAssistSpanPx
        travel = 0f
    }

    companion object {
        /**
         * How long after a gesture's last move a shape change still measures the far end's
         * lateness. Beyond this it is the far end's own business.
         */
        private const val LAG_WINDOW_MS = 600L

        /** Enough that two slow sessions in a row move the estimate, not one shape. */
        private const val LAG_ALPHA = 0.3f
    }
}
