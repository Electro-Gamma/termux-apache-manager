// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later
package net.pgaskin.remotedesktop.control.input

/** Where a pinch goes: the zoom's own events, in screen pixels. */
interface ZoomSink {
    fun zoomBegan()

    fun zoomChanged(factor: Float)

    fun zoomPanned(screenDx: Float, screenDy: Float)

    fun zoomEnded()

    fun scaleCentre(screenX: Float, screenY: Float)
}
