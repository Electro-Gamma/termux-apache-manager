// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later
package net.pgaskin.remotedesktop.control.input

/**
 * Finger-to-pointer shaping: the original's jerk-based acceleration, and ours on top of it — an
 * adaptive gate that fades amplification out at low speed, an axis lock for near-axial slow
 * movement, and [HoverAssist]'s detent where the far end changes the cursor's shape.
 */
class PointerAccel(private val cfg: Config, private val sink: MouseSink) {

    private val hover = HoverAssist(cfg)
    private val dx = FloatArray(3)
    private val dy = FloatArray(3)
    private val time = LongArray(3)
    private var size = 0
    private var lastDt = 1.0f
    private var lastFactor = 1.0f

    // --- running estimates, updated on every event regardless of the window --
    private var lastTime = -1L
    private var lastGapMs = NOMINAL_GAP_MS
    private var speed = 0f // px/ms
    private var magX = 0f
    private var magY = 0f // smoothed |dx|, |dy|
    private var lock = Axis.NONE

    // --- direction, smoothed over two different path lengths ----------------
    private var fastX = 0f
    private var fastY = 0f
    private var slowX = 0f
    private var slowY = 0f

    enum class Axis(private val label: String) {
        NONE("-"), X("X"), Y("Y");

        override fun toString(): String = label
    }

    fun reset() {
        size = 0
        lastTime = -1
        lastGapMs = NOMINAL_GAP_MS
        lastDt = 1.0f
        lastFactor = 1.0f
        speed = 0f
        magX = 0f
        magY = 0f
        lock = Axis.NONE
        fastX = 0f
        fastY = 0f
        slowX = 0f
        slowY = 0f
        hover.reset()
    }

    fun remoteCursorChanged(t: Long, gliding: Boolean) {
        hover.changed(speed, t, gliding)
    }

    fun gestureEnded() {
        hover.gestureEnded()
    }

    fun hoverGain(): Float = hover.gain()

    fun hoverLagMs(): Float = hover.lagMs()

    fun hoverLockedOut(now: Long): Boolean = hover.lockedOut(now)

    fun lastFactor(): Float = lastFactor

    fun speed(): Float = speed

    fun axisLock(): Axis = lock

    /** The angle between the short and the long direction estimates: how hard the path is turning. */
    fun turnDegrees(): Float {
        val cross = fastX * slowY - fastY * slowX
        val dot = fastX * slowX + fastY * slowY
        if (cross == 0f && dot == 0f) {
            return 0f
        }
        return Math.abs(Math.toDegrees(Math.atan2(cross.toDouble(), dot.toDouble()))).toFloat()
    }

    /** One move event of a finger, [dx] and [dy] in screen pixels at time [t]; sends the result to the sink. */
    fun move(dx: Float, dy: Float, t: Long) {
        var ax = dx
        var ay = dy
        track(ax, ay, t)

        // Before the lock has been at the delta, since what a detent spends is finger travel
        // rather than what comes out of this.
        val hoverGain = hover.gain(ax, ay, t)

        if (cfg.axisLockEnabled) {
            lock = nextLock()
            if (lock == Axis.X) {
                ay = 0f
            } else if (lock == Axis.Y) {
                ax = 0f
            }
        } else {
            lock = Axis.NONE
        }

        var factor = 1.0f
        if (cfg.accelEnabled) {
            factor = cfg.accelMin
            push(ax, ay, t)
            if (size == 3) {
                val jx = this.dx[1] - this.dx[0]
                val jy = this.dy[1] - this.dy[0]
                val jerk = Math.sqrt((jx * jx + jy * jy).toDouble()).toFloat()
                var dt = Math.abs(time[2] - time[0]).toFloat()
                if (dt == 0.0f) {
                    dt = lastDt
                } else {
                    lastDt = dt
                }
                val f = Math.pow((cfg.accelBase + jerk / dt).toDouble(), cfg.accelExponent.toDouble()).toFloat()
                if (f >= cfg.accelMin) {
                    factor = minOf(f, cfg.accelMax)
                }
                if (cfg.accelAdaptive) {
                    factor = gate(factor)
                }
                if (cfg.accelDrainHistory) {
                    size = 0
                } else {
                    System.arraycopy(this.dx, 1, this.dx, 0, 2)
                    System.arraycopy(this.dy, 1, this.dy, 0, 2)
                    System.arraycopy(time, 1, time, 0, 2)
                    size = 2
                }
            }
        }
        // Multiplied in rather than replacing the factor: in the slow band the adaptive gate has
        // already pulled that to the floor, and a detent is meant to take a quarter off whatever
        // the accelerator decided.
        factor *= hoverGain
        lastFactor = factor
        sink.mouseMove(ax * factor, ay * factor)
    }

    private fun track(ax: Float, ay: Float, t: Long) {
        var gap = if (lastTime < 0) 0f else (t - lastTime).toFloat()
        lastTime = t
        if (gap <= 0) {
            gap = lastGapMs
        } else {
            lastGapMs = gap
        }
        val dist = Math.sqrt((ax * ax + ay * ay).toDouble()).toFloat()
        val inst = dist / gap
        speed += (inst - speed) * EMA_ALPHA
        magX += (Math.abs(ax) - magX) * EMA_ALPHA
        magY += (Math.abs(ay) - magY) * EMA_ALPHA

        // Direction, low-passed over two path lengths rather than two event counts: the lock's
        // speed band spans more than a decade, so an event-weighted estimate would be a curvature
        // threshold that moves.
        val span = maxOf(cfg.axisLockTurnSpanPx, 1e-3f)
        val wSlow = minOf(1.0f, dist / span)
        val wFast = minOf(1.0f, dist / (span * TURN_FAST_FRACTION))
        slowX += (ax - slowX) * wSlow
        slowY += (ay - slowY) * wSlow
        fastX += (ax - fastX) * wFast
        fastY += (ay - fastY) * wFast
        if (turnDegrees() > cfg.axisLockCornerDeg) {
            // Not a curve — a corner. Forgetting the direction outright is what locks "up, then
            // across" a few events into the across rather than a whole span into it.
            fastX = ax
            slowX = ax
            fastY = ay
            slowY = ay
        }
    }

    private fun gate(factor: Float): Float {
        if (factor <= cfg.accelMin) {
            return factor
        }
        val lo = cfg.accelSlowSpeedPx
        val hi = cfg.accelFullSpeedPx
        var g = if (hi > lo) (speed - lo) / (hi - lo) else 1.0f
        if (g <= 0) {
            return cfg.accelMin
        }
        g = if (g < 1) g * g * (3 - 2 * g) else 1f // smoothstep: no kink at either end
        return cfg.accelMin + (factor - cfg.accelMin) * g
    }

    private fun nextLock(): Axis {
        if (speed >= cfg.axisLockMaxSpeedPx) {
            return Axis.NONE
        }
        if (turnDegrees() > cfg.axisLockMaxTurnDeg) {
            return Axis.NONE
        }
        val major = maxOf(magX, magY)
        if (major <= 0) {
            return lock
        }
        val ratio = minOf(magX, magY) / major
        val locked = if (lock == Axis.NONE) ratio <= cfg.axisLockEnterRatio else ratio <= cfg.axisLockExitRatio
        if (!locked) {
            return Axis.NONE
        }
        return if (magX >= magY) Axis.X else Axis.Y
    }

    private fun push(ax: Float, ay: Float, t: Long) {
        if (size == 3) {
            System.arraycopy(dx, 1, dx, 0, 2)
            System.arraycopy(dy, 1, dy, 0, 2)
            System.arraycopy(time, 1, time, 0, 2)
            size = 2
        }
        dx[size] = ax
        dy[size] = ay
        time[size] = t
        size++
    }

    private companion object {
        // Weight of the newest sample in the speed and per-axis magnitude estimates. 0.5 settles
        // within a few percent in three events, which is as long as a gate can take without being felt.
        const val EMA_ALPHA = 0.5f
        const val NOMINAL_GAP_MS = 8.0f // for the first event of a gesture

        // The short direction estimate's span, as a fraction of the long one's.
        const val TURN_FAST_FRACTION = 0.25f
    }
}
