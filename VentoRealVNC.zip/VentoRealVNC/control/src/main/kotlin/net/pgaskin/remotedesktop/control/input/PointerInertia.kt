// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later
package net.pgaskin.remotedesktop.control.input

/**
 * Momentum after a flick. Three samples of recent movement are kept; if the finger leaves moving
 * fast enough, the pointer keeps going in that direction and decays.
 */
class PointerInertia(
    private val cfg: Config,
    private val sink: MouseSink,
    private val handler: Scheduler,
) {

    private val dx = FloatArray(3)
    private val dy = FloatArray(3)
    private val time = LongArray(3)
    private var size = 0
    private var state = IDLE
    private var speed = 0.0
    private var dirX = 0f
    private var dirY = 0f

    private val startTask = Runnable { startGlide() }
    private val tickTask = Runnable { tick() }

    fun isGliding(): Boolean = state == GLIDING

    /** The current glide speed, or 0 when not gliding. */
    fun speed(): Double = if (state == GLIDING) speed else 0.0

    /** A move event of a gesture: [ax], [ay] after acceleration, at time [t]. */
    fun sample(ax: Float, ay: Float, t: Long) {
        handler.removeCallbacks(startTask)
        if (state != SAMPLING) {
            handler.removeCallbacks(tickTask)
            state = SAMPLING
            if (cfg.inertiaResetOnDown) {
                size = 0
            }
            // The original's recursive re-entry pushes a (0, 0, 0) sentinel here, which matters
            // only for a gesture of one or two move events. Not reproduced: fewer than three
            // samples do not glide.
        }
        push(ax, ay, t)
    }

    /** The finger left the screen: glide, after a short delay in case it comes back. */
    fun flick() {
        if (!cfg.inertiaEnabled) {
            return
        }
        handler.removeCallbacks(startTask)
        handler.postDelayed(startTask, cfg.inertiaStartDelayMs)
    }

    fun cancel() {
        handler.removeCallbacks(startTask)
        handler.removeCallbacks(tickTask)
        state = IDLE
        speed = 0.0
    }

    private fun startGlide() {
        if (size != 3) {
            return
        }
        state = GLIDING
        val vx = dx[0] + dx[1]
        val vy = dy[0] + dy[1]
        val mag = Math.sqrt((vx * vx + vy * vy).toDouble())
        if (mag != 0.0) {
            dirX = (vx / mag).toFloat()
            dirY = (vy / mag).toFloat()
        }
        speed = if (time[0] == time[2]) {
            0.0
        } else {
            minOf(mag * cfg.inertiaSpeedScale / (time[2] - time[0]), cfg.inertiaSpeedMax)
        }
        if (speed > 0) {
            handler.postDelayed(tickTask, cfg.inertiaTickMs)
        } else {
            state = IDLE
        }
    }

    private fun tick() {
        sink.mouseMove((dirX * speed).toFloat(), (dirY * speed).toFloat())
        speed *= cfg.inertiaDecay
        if (speed > cfg.inertiaStopSpeed) {
            handler.postDelayed(tickTask, cfg.inertiaTickMs)
        } else {
            speed = 0.0
            state = IDLE
        }
    }

    private fun push(ax: Float, ay: Float, t: Long) {
        if (size == 3) {
            System.arraycopy(dx, 1, dx, 0, 2)
            System.arraycopy(dy, 1, dy, 0, 2)
            System.arraycopy(time, 1, time, 0, 2)
            size = 2
        }
        dx[size] = ax
        dy[size] = ay
        time[size] = t
        size++
    }

    private companion object {
        const val IDLE = 0
        const val SAMPLING = 1
        const val GLIDING = 2
    }
}
