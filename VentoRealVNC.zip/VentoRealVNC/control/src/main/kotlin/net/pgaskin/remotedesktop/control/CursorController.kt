// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later
package net.pgaskin.remotedesktop.control

import net.pgaskin.remotedesktop.control.input.Button
import net.pgaskin.remotedesktop.control.input.Config
import net.pgaskin.remotedesktop.control.input.MouseSink
import net.pgaskin.remotedesktop.control.input.Scheduler

/**
 * The remote cursor: where it is on the desktop, which buttons are down (from any number of
 * sources), and what is sent to the far end about either. Moves the [Viewport] to follow it.
 *
 * Absolute mode sends positions; relative mode (where the far end owns the cursor) sends whole-pixel
 * deltas and carries the fraction.
 */
class CursorController(
    private val cfg: Config,
    private val viewport: Viewport,
    private val out: PointerSink,
    private val scheduler: Scheduler,
) : MouseSink {

    interface PointerSink {
        fun pointerEvent(x: Float, y: Float, buttons: Int)

        fun pointerEventRelative(dx: Int, dy: Int, buttons: Int) {
        }
    }

    interface Listener {
        fun onCursorChanged()

        /** Every click button has been let go: the edge a host acts on once the click has gone. */
        fun onButtonsReleased() {
        }
    }

    private var listener: Listener? = null
    private var x = 0f
    private var y = 0f // desktop coords
    private var buttons = 0 // the union of every source's mask: what the remote is told
    private var clicking = 0 // the same, wheel excluded, for the edge in clickEdge
    private val sources = ArrayList<IntArray>()
    private val own = newSourceMask()
    private var relative = false // the far end owns the cursor, so x and y mean nothing

    // Motion owed to the far end, in desktop pixels, not yet whole. The wire carries integers, and a
    // slow drag is a stream of deltas each smaller than one, so rounding every event on its own
    // would send nothing at all.
    private var owedX = 0f
    private var owedY = 0f

    private var framePending = false
    private val frameCallback = Runnable {
        framePending = false
        emit()
    }
    private var eventCount = 0
    private var suppressedCount = 0

    // The last triple actually handed to out, for the dedupe.
    private var sentX = 0f
    private var sentY = 0f
    private var sentButtons = 0
    private var everSent = false

    fun setListener(l: Listener?) {
        listener = l
    }

    fun setRelative(relative: Boolean) {
        if (this.relative == relative) {
            return
        }
        this.relative = relative
        owedX = 0f
        owedY = 0f
        // Whatever was last sent describes the other kind of session, and in relative mode a "same
        // as last time" test would swallow a real repeat of the same delta.
        everSent = false
        changed()
    }

    fun isRelative(): Boolean = relative

    fun x(): Float = x

    fun y(): Float = y

    fun buttons(): Int = buttons

    fun screenX(): Float = viewport.toScreenX(x)

    fun screenY(): Float = viewport.toScreenY(y)

    fun eventCount(): Int = eventCount

    fun suppressedCount(): Int = suppressedCount

    fun setPosition(dx: Float, dy: Float) {
        x = Viewport.clamp(dx, 0f, (viewport.desktopWidth() - 1).toFloat())
        y = Viewport.clamp(dy, 0f, (viewport.desktopHeight() - 1).toFloat())
        viewport.centreOn(x, y)
        changed()
    }

    fun setInsets(left: Int, top: Int, right: Int, bottom: Int) {
        if (relative) {
            viewport.setInsets(left, top, right, bottom)
            // The scale correction below, and nothing else: a window that grew can leave the picture
            // smaller than the space for it either way.
            viewport.centreOn(viewport.focusX(), viewport.focusY(), maxOf(viewport.getScale(), viewport.minScale()))
            changed()
            return
        }
        val centredX = Math.abs(screenX() - viewport.centreScreenX()) <= 0.5f
        val centredY = Math.abs(screenY() - viewport.centreScreenY()) <= 0.5f
        viewport.setInsets(left, top, right, bottom)
        // A window that grew can leave the picture smaller than the space for it; nothing else here
        // changes the scale.
        if (viewport.getScale() < viewport.minScale()) {
            viewport.centreOn(x, y, viewport.minScale())
        }
        val nx = if (centredX) viewport.toDesktopX(viewport.centreScreenX()) else x
        val ny = if (centredY) viewport.toDesktopY(viewport.centreScreenY()) else y
        if (nx != x || ny != y) {
            x = Viewport.clamp(nx, 0f, (viewport.desktopWidth() - 1).toFloat())
            y = Viewport.clamp(ny, 0f, (viewport.desktopHeight() - 1).toFloat())
            // The far end is told, because its idea of where the pointer is decides what is
            // highlighted under it. Not in relative mode: this is our cursor moving to where the
            // window now is, not the pointer moving on the desktop.
            if (!relative) {
                post()
            }
        }
        viewport.centreOn(x, y)
        changed()
    }

    /** Put the cursor at the middle of the window, telling the far end if [send]. */
    fun centreCursor(send: Boolean) {
        x = Viewport.clamp(viewport.toDesktopX(viewport.centreScreenX()), 0f, (viewport.desktopWidth() - 1).toFloat())
        y = Viewport.clamp(viewport.toDesktopY(viewport.centreScreenY()), 0f, (viewport.desktopHeight() - 1).toFloat())
        if (send && !relative) {
            post()
        }
        viewport.centreOn(x, y)
        changed()
    }

    // ---- MouseSink --------------------------------------------------------

    override fun mouseMove(dx: Float, dy: Float) {
        val s = viewport.getScale()
        if (relative) {
            // Still divided by the scale: a finger crossing a zoomed-in screen covers fewer desktop
            // pixels than the same finger at 1×, and that is as true of a delta as of a position.
            owedX += dx / s
            owedY += dy / s
            post()
            changed()
            return
        }
        x = Viewport.clamp(x + dx / s, 0f, (viewport.desktopWidth() - 1).toFloat())
        y = Viewport.clamp(y + dy / s, 0f, (viewport.desktopHeight() - 1).toFloat())
        post()
        viewport.centreOn(x, y)
        changed()
    }

    override fun mouseDown(mask: Int) {
        press(own, mask)
    }

    override fun mouseUp(mask: Int) {
        unpress(own, mask)
    }

    // ---- button sources ---------------------------------------------------

    /** Another holder of buttons: the far end sees the union of every source's. */
    fun newButtonSource(): MouseSink {
        val mask = newSourceMask()
        return object : MouseSink {
            override fun mouseMove(dx: Float, dy: Float) {
                this@CursorController.mouseMove(dx, dy)
            }

            override fun mouseDown(mask2: Int) {
                press(mask, mask2)
            }

            override fun mouseUp(mask2: Int) {
                unpress(mask, mask2)
            }
        }
    }

    private fun newSourceMask(): IntArray {
        val m = IntArray(1)
        sources.add(m)
        return m
    }

    // A button is part of what the cursor is, so a listener hears about one the same way it hears
    // about a move — after the event has gone, since the sink may act on it. A host that draws the
    // pointer's buttons, or one whose "remote" is the same process and so sends no frame back, has
    // nothing else to repaint on: a press with no movement is invisible without this.
    private fun press(source: IntArray, mask: Int) {
        source[0] = source[0] or mask
        union()
        flush()
        clickEdge()
        changed()
    }

    private fun unpress(source: IntArray, mask: Int) {
        source[0] = source[0] and mask.inv()
        union()
        flush()
        clickEdge()
        changed()
    }

    // After the flush, so that whatever the host does about the click — letting go of a modifier it
    // was holding for it — reaches the far end after the click itself rather than in the middle of it.
    private fun clickEdge() {
        val now = buttons and Button.CLICK_MASK
        val was = clicking
        clicking = now
        if (was != 0 && now == 0) {
            listener?.onButtonsReleased()
        }
    }

    private fun union() {
        var m = 0
        for (s in sources) {
            m = m or s[0]
        }
        buttons = m
    }

    // ---- event plumbing ---------------------------------------------------

    private fun post() {
        if (!cfg.coalescePointerEvents) {
            emit()
            return
        }
        if (!framePending) {
            framePending = true
            scheduler.postFrame(frameCallback)
        }
    }

    private fun flush() {
        if (framePending) {
            framePending = false
            scheduler.removeFrame(frameCallback)
        }
        emit()
    }

    private fun emit() {
        if (relative) {
            emitRelative()
            return
        }
        if (cfg.dedupePointerEvents && everSent && x == sentX && y == sentY && buttons == sentButtons) {
            suppressedCount++
            return
        }
        everSent = true
        sentX = x
        sentY = y
        sentButtons = buttons
        eventCount++
        out.pointerEvent(x, y, buttons)
    }

    private fun emitRelative() {
        val dx = owedX.toInt()
        val dy = owedY.toInt()
        if (dx == 0 && dy == 0 && everSent && buttons == sentButtons) {
            suppressedCount++
            return
        }
        owedX -= dx
        owedY -= dy
        everSent = true
        sentButtons = buttons
        eventCount++
        out.pointerEventRelative(dx, dy, buttons)
    }

    private fun changed() {
        listener?.onCursorChanged()
    }

    fun buttonsName(): String = Button.maskName(buttons)
}
