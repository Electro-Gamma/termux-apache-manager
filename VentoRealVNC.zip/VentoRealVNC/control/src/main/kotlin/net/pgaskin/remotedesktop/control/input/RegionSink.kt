// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later
package net.pgaskin.remotedesktop.control.input

/** Told when a tap lands in one of the screen's [TapRegions.Region]s. */
interface RegionSink {
    /** @return true if the tap was taken */
    fun regionTapped(region: TapRegions.Region, x: Float, y: Float): Boolean
}
