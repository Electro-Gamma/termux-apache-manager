// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later
package net.pgaskin.remotedesktop.control.input

import android.view.KeyEvent

/**
 * A physical keyboard, as keysyms for a [KeySink]. The keysym a key went down with is remembered by
 * Android keycode so its release names the key rather than the keysym, and so a repeat re-sends the
 * keysym recorded at press time.
 */
class PhysicalKeyboard(private val sink: KeySink) {

    /** Looks up the character a key types under a meta state; 0 for none. */
    fun interface CharMap {
        fun unicode(keyCode: Int, metaState: Int): Int
    }

    interface Listener {
        fun keyboardActivity()
    }

    private var listener: Listener? = null

    // The keysym each held key went down with, by Android keycode, or 0. A release names the key
    // rather than the keysym, so this only records what is held, for releaseAll and for telling a
    // repeat apart from a fresh press.
    //
    // Grown to fit rather than sized once: Android's keycodes are a list that gets longer with each
    // release — F13 is 326 — and a key past the end of a fixed table can only be refused, since a
    // press it cannot record is a key held down at the far end for ever.
    private var held = IntArray(256)
    private var heldCount = 0

    fun setListener(l: Listener?) {
        listener = l
    }

    fun heldCount(): Int = heldCount

    /** A key press that is [keyCode]'s own business or the system's, and so never forwarded. */
    fun keyDown(keyCode: Int, metaState: Int, repeat: Int, chars: CharMap): Boolean {
        if (keyCode < 0) {
            return false
        }
        if (keyCode >= held.size) {
            held = held.copyOf(keyCode + 1)
        }
        // A repeat re-sends the keysym recorded at press time rather than looking it up again: the
        // far end keys its held-key map on the id, so a repeat that arrived as a different keysym —
        // hold "a", press Shift, Android says "A" — would overwrite the entry, and the release
        // would let go of "A" while "a" stayed down at the far end for ever.
        if (repeat > 0 && held[keyCode] != 0) {
            sink.keyDown(held[keyCode], KeySink.ID_SYSTEM_KEYBOARD + keyCode)
            return true
        }
        val keysym = keysym(keyCode, metaState, chars)
        if (keysym == 0) {
            return false
        }
        if (held[keyCode] == 0) {
            heldCount++
        }
        held[keyCode] = keysym
        sink.keyDown(keysym, KeySink.ID_SYSTEM_KEYBOARD + keyCode)
        changed()
        return true
    }

    /** @return the keysym that was held for [keyCode], or 0 if none was */
    fun keyUp(keyCode: Int): Int {
        if (keyCode < 0 || keyCode >= held.size || held[keyCode] == 0) {
            return 0
        }
        val keysym = held[keyCode]
        held[keyCode] = 0
        heldCount--
        sink.keyUp(KeySink.ID_SYSTEM_KEYBOARD + keyCode)
        changed()
        return keysym
    }

    private fun keysym(keyCode: Int, metaState: Int, chars: CharMap): Int {
        if (reserved(keyCode)) {
            return 0
        }
        val byPosition = Keysym.fromAndroidKeyCode(keyCode)
        if (byPosition != 0) {
            return byPosition
        }
        val keypad = Keysym.keypadKeysym(keyCode, (metaState and META_NUM_LOCK) != 0)
        if (keypad != 0) {
            return keypad
        }
        var cp = chars.unicode(keyCode, charMeta(metaState))
        if (cp == 0 && (metaState and META_ALT_RIGHT) != 0) {
            // AltGr held over a layout with no third level, which is every US one: the phone has no
            // character to offer, so send the key's own and let the far end apply the level it has
            // already been told is held.
            cp = chars.unicode(keyCode, charMeta(metaState) and (META_ALT or META_ALT_RIGHT).inv())
        }
        return if (cp == 0) 0 else Keysym.fromKeyChar(cp)
    }

    fun releaseAll() {
        for (keyCode in held.indices) {
            if (held[keyCode] != 0) {
                held[keyCode] = 0
                sink.keyUp(KeySink.ID_SYSTEM_KEYBOARD + keyCode)
            }
        }
        heldCount = 0
        changed()
    }

    private fun changed() {
        listener?.keyboardActivity()
    }

    // ---- the Android adapter ----------------------------------------------

    /** Feed a `KeyEvent`; [typed] is told the keysym of each non-modifier key as it is released. */
    fun onKeyEvent(ev: KeyEvent, typed: (Int) -> Unit): Boolean {
        return when (ev.action) {
            KeyEvent.ACTION_DOWN ->
                keyDown(ev.keyCode, ev.metaState, ev.repeatCount) { _, meta -> ev.getUnicodeChar(meta) }
            KeyEvent.ACTION_UP -> {
                val keysym = keyUp(ev.keyCode)
                if (keysym != 0 && !isModifier(keysym)) {
                    typed(keysym)
                }
                keysym != 0
            }
            else -> false
        }
    }

    companion object {
        // MetaState bits, as literals for the same reason Keysym's keycodes are.
        private const val META_SHIFT = 0x1 or 0x40 or 0x80 // ON, LEFT, RIGHT
        private const val META_ALT = 0x02
        private const val META_ALT_RIGHT = 0x20
        private const val META_CAPS_LOCK = 0x100000
        private const val META_NUM_LOCK = 0x200000

        // What the character lookup is allowed to see: the modifiers that choose a character. The
        // rest are the remote's to apply.
        private const val CHAR_META = META_SHIFT or META_CAPS_LOCK

        /** Keys that belong to the phone, not the far end. */
        fun reserved(keyCode: Int): Boolean = when (keyCode) {
            3, 4, 5, 6 -> true // HOME, BACK, CALL, ENDCALL
            24, 25, 164 -> true // VOLUME_UP, VOLUME_DOWN, VOLUME_MUTE
            26, 223, 224 -> true // POWER, SLEEP, WAKEUP
            27 -> true // CAMERA
            79 -> true // HEADSETHOOK
            187 -> true // APP_SWITCH
            220, 221 -> true // BRIGHTNESS_DOWN, BRIGHTNESS_UP
            // The lock keys: applied to the character here, never forwarded.
            115, 143, 116 -> true // CAPS_LOCK, NUM_LOCK, SCROLL_LOCK
            else -> (keyCode in 85..91) || (keyCode in 126..130)
        }

        /** The meta bits a character lookup should see. */
        fun charMeta(metaState: Int): Int {
            var m = metaState and CHAR_META
            if ((metaState and META_ALT_RIGHT) != 0) {
                m = m or META_ALT or META_ALT_RIGHT
            }
            return m
        }

        internal fun isModifier(keysym: Int): Boolean =
            keysym == Keysym.SHIFT_L || keysym == Keysym.SHIFT_R ||
                keysym == Keysym.CONTROL_L || keysym == Keysym.CONTROL_R ||
                keysym == Keysym.ALT_L || keysym == Keysym.SUPER_L ||
                keysym == Keysym.SUPER_R || keysym == Keysym.ISO_LEVEL3_SHIFT
    }
}
