// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later
package net.pgaskin.remotedesktop.control.playground

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import net.pgaskin.remotedesktop.control.input.Config
import net.pgaskin.remotedesktop.control.input.TouchFrame
import net.pgaskin.remotedesktop.control.input.TouchLog
import net.pgaskin.remotedesktop.control.input.TouchRouter
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStreamWriter
import java.nio.charset.StandardCharsets
import java.util.Locale

/**
 * Records touch gestures to `.touch` files, one per gesture: a gesture starts at a DOWN with nothing
 * else on the screen and ends a moment after the last finger lifts.
 */
class TouchRecorder(private val ctx: Context, private val cfg: Config) : TouchRouter.Tap {

    private val handler = Handler(Looper.getMainLooper())
    private var armed = false
    private var relative = false
    private var writer: TouchLog.Writer? = null
    private var written = 0
    private var viewW = 0
    private var viewH = 0
    private var lastPath = ""
    private val flushTask = Runnable { flush() }

    /** How long after the last lift a gesture is considered over: the click-hold window plus slack. */
    fun idleMs(): Long = cfg.clickHoldMs + 150

    fun setViewSize(w: Int, h: Int) {
        viewW = w
        viewH = h
    }

    fun setRelative(on: Boolean) {
        relative = on
    }

    fun armed(): Boolean = armed

    fun count(): Int = written

    fun lastPath(): String = lastPath

    fun toggle() {
        handler.removeCallbacks(flushTask)
        if (armed) {
            flush()
        }
        armed = !armed
        writer = null
    }

    fun label(): String = if (armed) "REC $written" else (if (written > 0) "OFF $written" else "OFF")

    override fun onFrame(f: TouchFrame) {
        if (!armed) {
            return
        }
        handler.removeCallbacks(flushTask)
        var w = writer
        if (w == null) {
            if (f.action != TouchFrame.Action.DOWN) {
                return // wait for the start of a gesture
            }
            w = TouchLog.Writer()
                .meta("label", "unlabelled")
                .meta("density", cfg.density.toString())
                .meta("preset", if (cfg.faithfulPreset) "faithful" else "improved")
                .meta("view", "$viewW $viewH")
                .meta("pointer", if (relative) "relative" else "absolute")
            writer = w
        }
        w.add(f)
        val screenEmpty = (f.action == TouchFrame.Action.UP && f.count <= 1) || f.action == TouchFrame.Action.CANCEL
        if (screenEmpty) {
            handler.postDelayed(flushTask, idleMs())
        }
    }

    private fun flush() {
        writer?.let {
            save(it)
            writer = null
        }
    }

    private fun save(w: TouchLog.Writer) {
        val dir = Recordings.dir(ctx, Recordings.TOUCH)
        if (dir == null || (!dir.isDirectory && !dir.mkdirs())) {
            Log.e(TAG, "cannot create $dir")
            return
        }
        var out: File
        var n = written
        do {
            out = File(dir, String.format(Locale.ROOT, "%03d.touch", ++n))
        } while (out.exists())
        try {
            OutputStreamWriter(FileOutputStream(out), StandardCharsets.UTF_8).use { os ->
                os.write(w.text())
            }
        } catch (e: IOException) {
            Log.e(TAG, "write $out", e)
            return
        }
        written = n
        lastPath = "${out.name} (${w.frameCount()} frames)"
        Log.i(TAG, "recorded $out (${w.frameCount()} frames)")
    }

    private companion object {
        const val TAG = "TouchRecorder"
    }
}
