// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: MIT
package net.pgaskin.remotedesktop.control.input

/**
 * X11 keysyms for the keys a phone can produce, and the maps from Android's key codes and
 * characters to them. Kept off Android so it can be tested without it: Android constants appear
 * here as literals, commented.
 */
object Keysym {

    // Modifiers. The right-hand ones are keys of their own; right Alt is the exception and is a
    // level rather than a modifier (see fromAndroidKeyCode).
    const val SHIFT_L = 0xffe1 // 65505
    const val SHIFT_R = 0xffe2
    const val CONTROL_L = 0xffe3 // 65507
    const val CONTROL_R = 0xffe4
    const val ALT_L = 0xffe9 // 65513
    const val SUPER_L = 0xffeb // 65515
    const val SUPER_R = 0xffec
    const val ISO_LEVEL3_SHIFT = 0xfe03 // 65027 — AltGr / macOS Option

    // Editing and navigation.
    const val BACKSPACE = 0xff08
    const val TAB = 0xff09
    const val RETURN = 0xff0d
    const val ESCAPE = 0xff1b
    const val HOME = 0xff50
    const val LEFT = 0xff51
    const val UP = 0xff52
    const val RIGHT = 0xff53
    const val DOWN = 0xff54
    const val PAGE_UP = 0xff55
    const val PAGE_DOWN = 0xff56
    const val END = 0xff57
    const val INSERT = 0xff63
    const val DELETE = 0xffff

    // Keys only a physical keyboard has. The lock keys are deliberately absent from
    // fromAndroidKeyCode.
    const val MENU = 0xff67
    const val PRINT = 0xff61
    const val PAUSE = 0xff13

    // The conversion keys on a Japanese board. The two that switch kana are not here, and that is a
    // finding rather than an omission: see fromAndroidKeyCode.
    const val MUHENKAN = 0xff22
    const val HENKAN_MODE = 0xff23
    const val HIRAGANA_KATAKANA = 0xff27

    // The three dedicated editing keys, which core X11 never named — these are XFree86's, and are
    // what a Linux desktop binds them to.
    const val XF86_COPY = 0x1008ff57
    const val XF86_CUT = 0x1008ff58
    const val XF86_PASTE = 0x1008ff6d

    // The keypad; see keypadKeysym for why it is a separate set of keysyms.
    const val KP_ENTER = 0xff8d
    const val KP_MULTIPLY = 0xffaa
    const val KP_ADD = 0xffab
    const val KP_SUBTRACT = 0xffad
    const val KP_DECIMAL = 0xffae
    const val KP_DIVIDE = 0xffaf
    const val KP_EQUAL = 0xffbd
    const val KP_SEPARATOR = 0xffac
    const val KP_0 = 0xffb0

    // The Num-Lock-off half of the keypad, in Android keycode order below.
    const val KP_INSERT = 0xff9e
    const val KP_END = 0xff9c
    const val KP_DOWN = 0xff99
    const val KP_PAGE_DOWN = 0xff9b
    const val KP_LEFT = 0xff96
    const val KP_BEGIN = 0xff9d
    const val KP_RIGHT = 0xff98
    const val KP_HOME = 0xff95
    const val KP_UP = 0xff97
    const val KP_PAGE_UP = 0xff9a
    const val KP_DELETE = 0xff9f

    const val F1 = 0xffbe

    // KeyCharacterMap.COMBINING_ACCENT, as a literal for the same reason the keycodes below are.
    private const val COMBINING_ACCENT = 0x80000000.toInt()

    /** F1 is `f(1)`. */
    fun f(n: Int): Int = F1 + (n - 1)

    /** The keysym for a Unicode code point: itself where Latin-1 has it, else the `0x01000000 | cp` form. */
    fun fromUnicode(cp: Int): Int {
        if ((cp in 0x20..0x7e) || (cp in 0xa0..0xff)) {
            return cp
        }
        return 0x01000000 or cp
    }

    /** From `KeyEvent.getUnicodeChar`, which also encodes dead keys. 0 for no character. */
    fun fromKeyChar(unicodeChar: Int): Int {
        if (unicodeChar == 0) {
            return 0 // no character, rather than the encoding of code point 0
        }
        if ((unicodeChar and COMBINING_ACCENT) != 0) {
            return deadKeysym(unicodeChar and COMBINING_ACCENT.inv())
        }
        return fromUnicode(unicodeChar)
    }

    /** The dead key for a combining accent, or its plain character where X11 has no dead key for it. */
    fun deadKeysym(accent: Int): Int = when (accent) {
        0x0300 -> 0xfe50 // dead_grave
        0x0301 -> 0xfe51 // dead_acute
        0x0302 -> 0xfe52 // dead_circumflex
        0x0303 -> 0xfe53 // dead_tilde
        0x0304 -> 0xfe54 // dead_macron
        0x0306 -> 0xfe55 // dead_breve
        0x0307 -> 0xfe56 // dead_abovedot
        0x0308 -> 0xfe57 // dead_diaeresis
        0x030a -> 0xfe58 // dead_abovering
        0x030b -> 0xfe59 // dead_doubleacute
        0x030c -> 0xfe5a // dead_caron
        0x0327 -> 0xfe5b // dead_cedilla
        0x0328 -> 0xfe5c // dead_ogonek
        else -> fromUnicode(accent)
    }

    /** The keysym that types [cp]: control characters map to their keys, the rest as [fromKeyChar]. */
    fun forCharacter(cp: Int): Int = when (cp) {
        0x0a, 0x0d -> RETURN
        0x09 -> TAB
        0x1b -> ESCAPE
        0x08 -> BACKSPACE
        0x7f -> DELETE
        // A dead key can arrive here too, from an IME's own key events, and is not a control
        // character however negative it looks.
        else -> if (cp >= 0x20 || (cp and COMBINING_ACCENT) != 0) fromKeyChar(cp) else 0
    }

    /** As [forCharacter], for a character typed with a modifier that changes its case. */
    fun forCharacter(cp: Int, shiftHeld: Boolean, otherHeld: Boolean): Int {
        if (shiftHeld) {
            return forCharacter(Character.toUpperCase(cp))
        }
        if (otherHeld) {
            return forCharacter(Character.toLowerCase(cp))
        }
        return forCharacter(cp)
    }

    /** The keysym for an Android `KEYCODE_*` that is not a character, or 0. */
    fun fromAndroidKeyCode(keyCode: Int): Int = when (keyCode) {
        59 -> SHIFT_L
        60 -> SHIFT_R
        113 -> CONTROL_L
        114 -> CONTROL_R
        57 -> ALT_L // ALT_LEFT
        58 -> ISO_LEVEL3_SHIFT // ALT_RIGHT is AltGr on a PC layout
        117 -> SUPER_L // META_LEFT
        118 -> SUPER_R
        67 -> BACKSPACE // DEL
        112 -> DELETE // FORWARD_DEL
        61 -> TAB
        66 -> RETURN // ENTER
        111 -> ESCAPE
        122 -> HOME // MOVE_HOME
        123 -> END // MOVE_END
        92 -> PAGE_UP
        93 -> PAGE_DOWN
        124 -> INSERT
        19 -> UP // DPAD_*
        20 -> DOWN
        21 -> LEFT
        22 -> RIGHT
        82 -> MENU // the context-menu key
        120 -> PRINT // SYSRQ
        121 -> PAUSE // BREAK
        213 -> MUHENKAN
        214 -> HENKAN_MODE
        215 -> HIRAGANA_KATAKANA // KATAKANA_HIRAGANA
        // Not KANA (218) and not EISU (212), which look like the other two and are not: this
        // phone's own key layout gives those two keycodes to a Korean board's Hangul and Hanja
        // keys, so a keysym chosen here would be right for one keyboard and wrong for the other.
        277 -> XF86_CUT
        278 -> XF86_COPY
        279 -> XF86_PASTE
        else -> when {
            keyCode in 131..142 -> f(keyCode - 130) // F1–F12
            // F13–F24, which are nowhere near the others in Android's numbering and are
            // consecutive in X11's.
            keyCode in 326..337 -> f(keyCode - 313)
            else -> 0
        }
    }

    /** The keypad key for an Android keycode, which depends on whether Num Lock is on. */
    fun keypadKeysym(keyCode: Int, numLockOn: Boolean): Int {
        // The operators and the separators mean the same thing either way.
        when (keyCode) {
            154 -> return KP_DIVIDE
            155 -> return KP_MULTIPLY
            156 -> return KP_SUBTRACT
            157 -> return KP_ADD
            159 -> return KP_SEPARATOR // NUMPAD_COMMA
            160 -> return KP_ENTER
            161 -> return KP_EQUAL
            162 -> return '('.code // NUMPAD_LEFT_PAREN
            163 -> return ')'.code
        }
        if (keyCode < 144 || keyCode > 158) {
            return 0
        }
        if (numLockOn) {
            return if (keyCode == 158) KP_DECIMAL else KP_0 + (keyCode - 144)
        }
        return when (keyCode) {
            144 -> KP_INSERT
            145 -> KP_END
            146 -> KP_DOWN
            147 -> KP_PAGE_DOWN
            148 -> KP_LEFT
            149 -> KP_BEGIN
            150 -> KP_RIGHT
            151 -> KP_HOME
            152 -> KP_UP
            153 -> KP_PAGE_UP
            else -> KP_DELETE // 158, NUMPAD_DOT
        }
    }

    /** A short name for a keysym, for a label or a log. */
    fun name(keysym: Int): String = when (keysym) {
        SHIFT_L -> "Shift"
        SHIFT_R -> "Shift_R"
        CONTROL_L -> "Ctrl"
        CONTROL_R -> "Ctrl_R"
        ALT_L -> "Alt"
        SUPER_L -> "Super"
        SUPER_R -> "Super_R"
        ISO_LEVEL3_SHIFT -> "AltGr"
        BACKSPACE -> "BackSpace"
        TAB -> "Tab"
        RETURN -> "Return"
        ESCAPE -> "Escape"
        HOME -> "Home"
        LEFT -> "Left"
        UP -> "Up"
        RIGHT -> "Right"
        DOWN -> "Down"
        PAGE_UP -> "PageUp"
        PAGE_DOWN -> "PageDown"
        END -> "End"
        INSERT -> "Insert"
        DELETE -> "Delete"
        MENU -> "Menu"
        PRINT -> "Print"
        PAUSE -> "Pause"
        MUHENKAN -> "Muhenkan"
        HENKAN_MODE -> "Henkan_Mode"
        HIRAGANA_KATAKANA -> "Hiragana_Katakana"
        XF86_CUT -> "XF86Cut"
        XF86_COPY -> "XF86Copy"
        XF86_PASTE -> "XF86Paste"
        KP_ENTER -> "KP_Enter"
        KP_MULTIPLY -> "KP_Multiply"
        KP_ADD -> "KP_Add"
        KP_SUBTRACT -> "KP_Subtract"
        KP_DECIMAL -> "KP_Decimal"
        KP_DIVIDE -> "KP_Divide"
        KP_EQUAL -> "KP_Equal"
        KP_SEPARATOR -> "KP_Separator"
        KP_INSERT -> "KP_Insert"
        KP_END -> "KP_End"
        KP_DOWN -> "KP_Down"
        KP_PAGE_DOWN -> "KP_Next"
        KP_LEFT -> "KP_Left"
        KP_BEGIN -> "KP_Begin"
        KP_RIGHT -> "KP_Right"
        KP_HOME -> "KP_Home"
        KP_UP -> "KP_Up"
        KP_PAGE_UP -> "KP_Prior"
        KP_DELETE -> "KP_Delete"
        else -> when {
            keysym in F1..f(24) -> "F" + (keysym - F1 + 1)
            keysym in KP_0..KP_0 + 9 -> "KP_" + (keysym - KP_0)
            else -> {
                val cp = toUnicode(keysym)
                if (cp > 0) String(Character.toChars(cp)) else "0x" + Integer.toHexString(keysym)
            }
        }
    }

    /** The Unicode code point a keysym types, or 0. */
    fun toUnicode(keysym: Int): Int {
        if ((keysym and 0xff000000.toInt()) == 0x01000000) {
            return keysym and 0x00ffffff
        }
        if ((keysym in 0x20..0x7e) || (keysym in 0xa0..0xff)) {
            return keysym
        }
        return 0
    }
}
