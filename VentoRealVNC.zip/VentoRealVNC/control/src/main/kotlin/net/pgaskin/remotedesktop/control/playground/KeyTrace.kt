// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later
package net.pgaskin.remotedesktop.control.playground

import android.content.Context
import android.util.Log
import android.view.InputDevice
import android.view.KeyCharacterMap
import android.view.KeyEvent
import net.pgaskin.remotedesktop.control.input.KeySink
import net.pgaskin.remotedesktop.control.input.Keysym
import net.pgaskin.remotedesktop.control.input.PhysicalKeyboard
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStreamWriter
import java.io.Writer
import java.nio.charset.StandardCharsets
import java.util.Locale

/**
 * A [KeySink] that sits in front of another and writes one line per key event to a `.keys` file:
 * what Android said, and what the physical keyboard made of it. For working out why a key did not
 * arrive as expected.
 */
class KeyTrace(private val ctx: Context, private val next: KeySink) : KeySink {

    // What the sink saw during the event being recorded, and the keysym each held key went down
    // with, so a release can name one.
    private val held = HashMap<Int, Int>()
    private val describedDevices = HashSet<Int>()
    private var edgeKeysym = 0
    private var sawEdge = false
    private var inEvent = false
    private var armed = false
    private var out: Writer? = null
    private var lines = 0
    private var lastPath = ""

    fun armed(): Boolean = armed

    fun label(): String = if (armed) "REC $lines" else (if (lines > 0) "OFF $lines" else "OFF")

    fun lastPath(): String = lastPath

    fun toggle() {
        setArmed(!armed)
    }

    fun setArmed(on: Boolean) {
        if (on == armed) {
            return
        }
        armed = on
        if (armed) {
            open()
        } else {
            close()
        }
    }

    /**
     * Run [deliver] (which hands [ev] to the keyboard and reports whether it was consumed) while
     * watching what reaches the sink, and log the outcome.
     */
    fun record(ev: KeyEvent, deliver: () -> Boolean): Boolean {
        if (!armed) {
            return deliver()
        }
        describe(ev.deviceId)
        edgeKeysym = 0
        sawEdge = false
        inEvent = true
        val consumed = deliver()
        inEvent = false
        write(line(ev, consumed))
        return consumed
    }

    override fun keyDown(keysym: Int, keyId: Int) {
        edgeKeysym = keysym
        sawEdge = true
        held[keyId] = keysym
        unprompted("down", keysym, keyId)
        next.keyDown(keysym, keyId)
    }

    override fun keyUp(keyId: Int) {
        val keysym = held.remove(keyId)
        edgeKeysym = keysym ?: 0
        sawEdge = true
        unprompted("up", edgeKeysym, keyId)
        next.keyUp(keyId)
    }

    /** A key edge with no key event around it: the extension row, or a release the system sent late. */
    private fun unprompted(edge: String, keysym: Int, keyId: Int) {
        if (!inEvent) {
            write("# $edge ${Keysym.name(keysym)} (id 0x${Integer.toHexString(keyId)}) with no key event")
        }
    }

    private fun line(ev: KeyEvent, consumed: Boolean): String {
        val keyCode = ev.keyCode
        val meta = ev.metaState
        val down = ev.action == KeyEvent.ACTION_DOWN
        return String.format(
            Locale.ROOT, "%-4s %-22s %4d %4d %08x %-8s %5s %3d %-7s %-7s %8s %-12s %s",
            if (down) "down" else "up",
            keyName(keyCode),
            keyCode,
            ev.scanCode,
            meta,
            mods(meta),
            // Chiefly FLAG_CANCELED (0x20), which is how a chord the window manager took is taken
            // back off the app that saw its first half.
            "0x" + Integer.toHexString(ev.flags),
            ev.repeatCount,
            ch(ev.getUnicodeChar(meta)),
            ch(ev.getUnicodeChar(PhysicalKeyboard.charMeta(meta))),
            if (sawEdge) Integer.toHexString(edgeKeysym) else "-",
            if (sawEdge) Keysym.name(edgeKeysym) else "-",
            outcome(ev, consumed),
        )
    }

    private fun outcome(ev: KeyEvent, consumed: Boolean): String {
        if (sawEdge) {
            return if (consumed) "sent" else "sent-not-consumed"
        }
        if (PhysicalKeyboard.reserved(ev.keyCode)) {
            return "reserved"
        }
        return if (ev.action == KeyEvent.ACTION_DOWN) "no-keysym" else "not-held"
    }

    private fun describe(deviceId: Int) {
        if (!describedDevices.add(deviceId)) {
            return
        }
        val dev = InputDevice.getDevice(deviceId)
        if (dev == null) {
            write("# device $deviceId (gone or virtual)")
            return
        }
        write(
            String.format(
                Locale.ROOT, "# device %d \"%s\" vid=%04x pid=%04x keyboardType=%d sources=%08x",
                deviceId, dev.name, dev.vendorId, dev.productId, dev.keyboardType, dev.sources,
            ),
        )
    }

    private fun open() {
        val dir = Recordings.dir(ctx, Recordings.KEYS)
        if (dir == null || (!dir.isDirectory && !dir.mkdirs())) {
            Log.e(TAG, "cannot create $dir")
            return
        }
        var file: File
        var n = 0
        do {
            file = File(dir, String.format(Locale.ROOT, "%03d.keys", ++n))
        } while (file.exists())
        try {
            out = OutputStreamWriter(FileOutputStream(file), StandardCharsets.UTF_8)
        } catch (e: IOException) {
            Log.e(TAG, "open $file", e)
            return
        }
        lines = 0
        describedDevices.clear()
        lastPath = file.name
        Log.i(TAG, "tracing to $file")
        write("# key trace: every key event, and what the physical keyboard made of it")
        write(HEADER)
    }

    private fun close() {
        val o = out ?: return
        try {
            o.close()
        } catch (e: IOException) {
            Log.e(TAG, "close", e)
        }
        out = null
        Log.i(TAG, "traced $lines events to $lastPath")
    }

    private fun write(s: String) {
        val o = out ?: return
        try {
            o.write(s)
            o.write('\n'.code)
            o.flush()
        } catch (e: IOException) {
            Log.e(TAG, "write", e)
        }
        if (!s.startsWith("#") && s != HEADER) {
            lines++
        }
    }

    private companion object {
        const val TAG = "KeyTrace"

        val HEADER: String = String.format(
            "%-4s %-22s %4s %4s %8s %-8s %5s %3s %-7s %-7s %8s %-12s %s",
            "ev", "key", "code", "scan", "meta", "mods", "flags", "rpt",
            "uni", "chr", "keysym", "name", "outcome",
        )

        fun keyName(keyCode: Int): String {
            val s = KeyEvent.keyCodeToString(keyCode)
            return if (s.startsWith("KEYCODE_")) s.substring(8) else s
        }

        fun mods(meta: Int): String {
            val sb = StringBuilder()
            if ((meta and KeyEvent.META_SHIFT_ON) != 0) sb.append('S')
            if ((meta and KeyEvent.META_CTRL_ON) != 0) sb.append('C')
            if ((meta and KeyEvent.META_ALT_LEFT_ON) != 0) sb.append('A')
            if ((meta and KeyEvent.META_ALT_RIGHT_ON) != 0) sb.append('G')
            if ((meta and KeyEvent.META_META_ON) != 0) sb.append('M')
            if ((meta and KeyEvent.META_CAPS_LOCK_ON) != 0) sb.append('L')
            if ((meta and KeyEvent.META_NUM_LOCK_ON) != 0) sb.append('N')
            if ((meta and KeyEvent.META_SCROLL_LOCK_ON) != 0) sb.append('K')
            return if (sb.isEmpty()) "-" else sb.toString()
        }

        fun ch(cp: Int): String {
            if (cp == 0) {
                return "-"
            }
            if ((cp and KeyCharacterMap.COMBINING_ACCENT) != 0) {
                return "dead" + Integer.toHexString(cp and KeyCharacterMap.COMBINING_ACCENT_MASK)
            }
            if (cp in 0x21..0x7e) {
                return "'" + cp.toChar() + "'"
            }
            return "u+" + Integer.toHexString(cp)
        }
    }
}
