// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later
package net.pgaskin.remotedesktop.control.input

/** Fractions of the view that mean something when tapped, rather than something to send on. */
class TapRegions(vararg regions: Region) {

    /** A rectangle in fractions of the view, so it holds at any size. */
    data class Region(
        val name: String,
        val left: Float,
        val top: Float,
        val right: Float,
        val bottom: Float,
    ) {
        fun contains(fx: Float, fy: Float): Boolean = fx >= left && fx <= right && fy >= top && fy <= bottom
    }

    private val regions: List<Region> = regions.toList()

    fun regions(): List<Region> = regions

    /** The region at ([x], [y]) in view pixels, or null. */
    fun hit(x: Float, y: Float, viewW: Int, viewH: Int): Region? {
        if (viewW <= 0 || viewH <= 0) {
            return null
        }
        val fx = x / viewW
        val fy = y / viewH
        return regions.firstOrNull { it.contains(fx, fy) }
    }

    companion object {
        const val DISCONNECT = "disconnect"
        const val INFORMATION = "information"
        const val KEYBOARD = "keyboard"
        const val MOUSE = "mouse"

        /** The usual layout: a strip along the top, and a corner each along the bottom. */
        fun standard(): TapRegions {
            val top = 2f / 22f
            val bottom = 19f / 22f
            return TapRegions(
                Region(DISCONNECT, 0f, 0f, 1f / 5f, top),
                Region(INFORMATION, 1f / 5f, 0f, 1f, top),
                Region(KEYBOARD, 0f, bottom, 4f / 5f, 1f),
                Region(MOUSE, 4f / 5f, bottom, 1f, 1f),
            )
        }
    }
}
