// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later
package net.pgaskin.remotedesktop.control.input

/**
 * Turns "the text field now says X" into key presses: the minimal run of backspaces and characters
 * to get what the far end has from what it had. Composition is replaced as it changes; commit ends it.
 */
class TextDelta {

    interface Out {
        fun backspace()

        fun character(codePoint: Int)
    }

    /** What the far end has been sent for the text in progress. */
    private val sent = StringBuilder()

    /** Whether there is text in progress, which a commit or [finish] ends. */
    fun composing(): Boolean = sent.isNotEmpty()

    /** The text in progress is now [text]. */
    fun compose(text: CharSequence?, out: Out) {
        replace(text, out)
    }

    /** [text] is final: send it, and start afresh. */
    fun commit(text: CharSequence?, out: Out) {
        replace(text, out)
        sent.setLength(0)
    }

    /** Forget what was sent without sending anything: the text was accepted as it stands. */
    fun finish() {
        sent.setLength(0)
    }

    private fun replace(text: CharSequence?, out: Out) {
        val next: CharSequence = text ?: ""
        var common = 0
        while (common < sent.length && common < next.length && sent[common] == next[common]) {
            common++
        }
        // A common prefix may not end between the halves of a surrogate pair: if it did, the
        // pair's low half differs and the character it belongs to is being replaced, so the whole
        // character has to go.
        if (common > 0 && Character.isHighSurrogate(sent[common - 1])) {
            common--
        }
        var i = sent.length
        while (i > common) {
            i -= Character.charCount(sent.codePointBefore(i))
            out.backspace()
        }
        i = common
        while (i < next.length) {
            val cp = Character.codePointAt(next, i)
            i += Character.charCount(cp)
            out.character(cp)
        }
        sent.setLength(0)
        sent.append(next)
    }
}
