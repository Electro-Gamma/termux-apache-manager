// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later
package net.pgaskin.remotedesktop.control.input

/**
 * The clock the input stack runs on, so its timing logic can be driven by a fake in tests and by
 * the main thread's `Handler` and `Choreographer` on a device.
 */
interface Scheduler {
    fun postDelayed(r: Runnable, delayMs: Long)

    fun removeCallbacks(r: Runnable)

    /** Run [r] once, at the start of the next frame. */
    fun postFrame(r: Runnable)

    fun removeFrame(r: Runnable)
}
