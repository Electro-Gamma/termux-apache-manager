// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later
package net.pgaskin.remotedesktop.control.input

/**
 * The column of buttons down the edge of the screen: model and hit-testing only, drawn by the view.
 * A button fires on release if the finger is still on it; moving more than a slop turns the press
 * into a drag of the whole column up and down.
 */
class Toolbar(private val cfg: Config) : TouchRouter.Claim {

    data class Item(val name: String, val icon: String)

    interface Listener {
        fun toolbarChanged()

        fun toolbarAction(name: String)

        fun toolbarMoved(fraction: Float) {
        }
    }

    /** An item's rectangle, or the grip's when [item] is null. */
    data class Bounds(
        val item: Item?,
        val left: Float,
        val top: Float,
        val right: Float,
        val bottom: Float,
    ) {
        fun contains(x: Float, y: Float): Boolean = x >= left && x < right && y >= top && y < bottom

        fun width(): Float = right - left

        fun height(): Float = bottom - top

        fun centreX(): Float = (left + right) / 2.0f

        fun centreY(): Float = (top + bottom) / 2.0f
    }

    private var listener: Listener? = null
    private var defs: List<Item> = emptyList()
    private val items = ArrayList<Bounds>()
    private val active = LinkedHashSet<String>()
    private var grip: Bounds? = null
    private var viewW = 0
    private var viewH = 0
    private var insetLeft = 0f
    private var insetTop = 0f
    private var insetBottom = 0f
    private var visible = false
    private var fraction = 0.35f

    private var activeId = NONE
    private var activeItem: Item? = null
    private var dragging = false
    private var pressY = 0f
    private var pressTop = 0f
    private var spare = 0L // extra fingers: claimed so they cannot reach the pad, then ignored

    fun setListener(l: Listener?) {
        listener = l
    }

    fun setItems(defs: List<Item>) {
        if (this.defs == defs) {
            return // a press under the finger is not to be cancelled for nothing
        }
        this.defs = defs.toList()
        release()
        layout()
        changed()
    }

    fun setViewSize(w: Int, h: Int) {
        if (w == viewW && h == viewH) {
            return
        }
        viewW = w
        viewH = h
        layout()
        changed()
    }

    fun setInsets(left: Float, top: Float, bottom: Float) {
        if (left == insetLeft && top == insetTop && bottom == insetBottom) {
            return
        }
        insetLeft = left
        insetTop = top
        insetBottom = bottom
        layout()
        changed()
    }

    fun visible(): Boolean = visible

    fun setVisible(v: Boolean) {
        if (visible == v) {
            return
        }
        visible = v
        if (!visible) {
            release()
        }
        changed()
    }

    /** Mark an item as on (a toggle that is currently engaged). */
    fun setActive(name: String, on: Boolean) {
        if (if (on) active.add(name) else active.remove(name)) {
            changed()
        }
    }

    fun active(item: Item?): Boolean = item != null && active.contains(item.name)

    fun position(): Float = fraction

    fun setPosition(f: Float) {
        fraction = clamp(f, 0f, 1f)
        layout()
        changed()
    }

    // ---- what the view draws ----------------------------------------------

    fun items(): List<Bounds> = items

    fun grip(): Bounds? = grip

    fun pressedItem(): Item? = if (dragging) null else activeItem

    fun touched(): Boolean = activeId != NONE

    fun dragging(): Boolean = dragging

    fun left(): Float = insetLeft

    fun right(): Float = insetLeft + cfg.toolbarButtonPx

    fun top(): Float = insetTop + fraction * band()

    fun bottom(): Float = top() + height()

    fun height(): Float = if (defs.isEmpty()) 0f else defs.size * cfg.toolbarButtonPx + cfg.toolbarGripPx

    // ---- layout ------------------------------------------------------------

    private fun band(): Float = maxOf(0f, viewH - insetTop - insetBottom - height())

    private fun layout() {
        items.clear()
        grip = null
        if (viewW <= 0 || viewH <= 0 || defs.isEmpty()) {
            return
        }
        val l = left()
        val r = right()
        var y = top()
        for (d in defs) {
            items.add(Bounds(d, l, y, r, y + cfg.toolbarButtonPx))
            y += cfg.toolbarButtonPx
        }
        grip = Bounds(null, l, y, r, y + cfg.toolbarGripPx)
    }

    // ---- TouchRouter.Claim -------------------------------------------------

    override fun claimTouch(id: Int, x: Float, y: Float, t: Long): Boolean {
        if (!visible || defs.isEmpty() || x < left() || x >= right() || y < top() || y >= bottom()) {
            return false
        }
        if (activeId != NONE) {
            // A second finger on the column: claimed so it cannot reach the touchpad behind it, and
            // then ignored.
            spare = spare or bit(id)
            return true
        }
        activeId = id
        activeItem = itemAt(x, y)
        // The grip is a hint rather than a requirement — a pointer that lands on a button and
        // travels drags too (see claimMoved) — but one that lands on the grip is dragging from the
        // first pixel, since there is nothing else it could be doing.
        dragging = activeItem == null
        pressY = y
        pressTop = top()
        changed()
        return true
    }

    override fun claimMoved(id: Int, x: Float, y: Float, t: Long) {
        if (id != activeId) {
            return
        }
        if (!dragging && Math.abs(y - pressY) > cfg.toolbarDragSlopPx) {
            dragging = true
            activeItem = null // it is a drag now, and the button does not fire
        }
        if (dragging) {
            val b = band()
            fraction = if (b <= 0) 0f else clamp((pressTop + (y - pressY) - insetTop) / b, 0f, 1f)
            layout()
            changed()
        }
    }

    override fun claimEnded(id: Int, x: Float, y: Float, t: Long) {
        if (spare != 0L && (spare and bit(id)) != 0L) {
            spare = spare and bit(id).inv()
            return
        }
        if (id != activeId) {
            return
        }
        val item = activeItem
        val wasDragging = dragging
        activeId = NONE
        activeItem = null
        dragging = false
        val l = listener
        if (wasDragging) {
            l?.toolbarMoved(fraction)
        } else if (item != null && item == itemAt(x, y) && l != null) {
            // Still on the button it started on, which is the extension row's rule and an ordinary
            // click's: lifting somewhere else is how a mis-aimed button is abandoned.
            l.toolbarAction(item.name)
        }
        changed()
    }

    override fun claimCancelled(t: Long) {
        release()
        changed()
    }

    private fun release() {
        activeId = NONE
        activeItem = null
        dragging = false
        spare = 0
    }

    private fun itemAt(x: Float, y: Float): Item? {
        for (b in items) {
            if (b.contains(x, y)) {
                return b.item
            }
        }
        return null
    }

    private fun changed() {
        listener?.toolbarChanged()
    }

    companion object {
        private const val NONE = Int.MIN_VALUE

        fun standard(): List<Item> = listOf(
            Item(TapRegions.DISCONNECT, "disconnect"),
            Item(TapRegions.INFORMATION, "info"),
            Item(TapRegions.KEYBOARD, "keyboard"),
            Item(TapRegions.MOUSE, "mouse"),
        )

        private fun bit(id: Int): Long = if (id >= 0 && id < 64) 1L shl id else 0L

        private fun clamp(v: Float, lo: Float, hi: Float): Float = if (v < lo) lo else if (v > hi) hi else v
    }
}
