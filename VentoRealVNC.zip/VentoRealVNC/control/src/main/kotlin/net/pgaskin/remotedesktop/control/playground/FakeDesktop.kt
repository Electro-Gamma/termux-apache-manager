// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later
package net.pgaskin.remotedesktop.control.playground

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import net.pgaskin.remotedesktop.control.CursorController
import net.pgaskin.remotedesktop.control.input.Button
import net.pgaskin.remotedesktop.control.input.KeySink
import net.pgaskin.remotedesktop.control.input.Keysym

/**
 * A pretend remote desktop for trying the input stack without a server: a wallpaper, draggable
 * squares, a field of tiny targets, a canvas to draw on, readouts for wheel and keys, and a block of
 * toggle buttons that act on the playground itself. It is the "far end" of a [CursorController] and a
 * [KeySink], and draws itself in desktop coordinates.
 */
class FakeDesktop(
    val width: Int,
    val height: Int,
    private val toggles: ToggleHandler,
    recorders: Boolean,
) : CursorController.PointerSink, KeySink {

    enum class Toggle {
        PRESET, ACCEL, AXISLOCK, MOMENTUM, CURSOR, NATSCROLL, HUD, RECORD,
        KEYTRACE,
        ZOOMOUT, ZOOMIN, ZOOMFIT,
        INSETS,
        RELATIVE,
        REGIONS,
        TOOLBAR,
        MOUSE,
        KEYBOARD,
        TWOLINE,
        HOVER, LAG,
    }

    interface ToggleHandler {
        fun onToggle(toggle: Toggle)

        fun label(toggle: Toggle): String
    }

    class Square internal constructor(
        val title: String,
        val color: Int,
        var x: Float,
        var y: Float,
        var w: Float,
        var h: Float,
        val draggable: Boolean,
        val toggle: Toggle?,
    ) {
        var lastButton: Button? = null
        var pressed = false

        internal fun contains(px: Float, py: Float): Boolean = px >= x && px <= x + w && py >= y && py <= y + h
    }

    val wallpaper: Bitmap = Art.wallpaper(width, height)

    private val squares = ArrayList<Square>()
    private val targets: Array<FloatArray>
    private var targetsShown = false
    private val objectCursor = Art.handCursor()
    private var lastButtons = 0
    private var dragging: Square? = null
    private var dragOffX = 0f
    private var dragOffY = 0f

    // The cursor, in the mode where it belongs to this end. See setRelative.
    private var relative = false
    private var relX = 0f
    private var relY = 0f
    private val ownCursor = Art.arrowCursor()

    var wheelV = 0 // net clicks received, so scrolling is visible
    var wheelH = 0
    var lastEvent = ""
    var lastKey = "-" // the last keysym edge, for the HUD

    private val typed = StringBuilder()
    private val heldKeys = LinkedHashMap<Int, Int>()
    private val inkPath = Path()
    private var drawing = false

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ink = Paint()
    private val tmp = RectF()

    init {
        stroke.style = Paint.Style.STROKE
        stroke.strokeWidth = 1.5f
        ink.style = Paint.Style.STROKE
        ink.strokeWidth = 3f
        ink.strokeCap = Paint.Cap.BUTT
        ink.strokeJoin = Paint.Join.MITER
        ink.color = 0x99e02828.toInt()
        text.textAlign = Paint.Align.CENTER
        text.isFakeBoldText = true

        val colors = intArrayOf(
            0xff4a90d9.toInt(), 0xffe0a33e.toInt(), 0xff40c4a0.toInt(),
            0xffd95f6b.toInt(), 0xff9b6bd9.toInt(), 0xff6bd94a.toInt(),
        )
        // Sized like real desktop widgets rather than phone-sized buttons: on a 1920x1200 remote a
        // draggable object is ~180x120 px with ~15 px labels, and getting that scale right matters
        // for judging cursor feel — the same cursor travel reads as much faster across oversized
        // objects. Small on the phone is correct: that is what zoom is for, and it is how a real
        // remote looks. Laid out clear of the toggle block (60..720 x 60..254) and the wheel
        // readout (top right).
        val at = arrayOf(
            floatArrayOf(980f, 120f), floatArrayOf(1500f, 260f), floatArrayOf(200f, 400f),
            floatArrayOf(700f, 620f), floatArrayOf(1150f, 500f), floatArrayOf(1550f, 800f),
        )
        for (i in at.indices) {
            squares.add(Square("SQ${i + 1}", colors[i], at[i][0], at[i][1], 180f, 120f, true, null))
        }

        // Three rows of them, each row a sweep from 4 px across to 44, and the rows offset so that a
        // drag along one crosses a different set of sizes than a drag along the next. Clear of the
        // squares' start positions, which are what a drag along a row would otherwise run into.
        val radii = floatArrayOf(2f, 4f, 6f, 9f, 13f, 18f, 22f)
        targets = Array(3 * radii.size) { idx ->
            val row = idx / radii.size
            val i = idx % radii.size
            floatArrayOf(260f + i * 200 + row * 60, 780f + row * 110, radii[i])
        }

        val toggleDefs = ArrayList<Toggle>()
        for (t in Toggle.values()) {
            if (recorders || (t != Toggle.RECORD && t != Toggle.KEYTRACE)) {
                toggleDefs.add(t)
            }
        }
        for (i in toggleDefs.indices) {
            val tx = 60f + (i % 4) * 170
            val ty = 60f + (i / 4) * 70
            squares.add(Square(toggleDefs[i].name, 0xff3a3f4b.toInt(), tx, ty, 150f, 54f, false, toggleDefs[i]))
        }
    }

    fun squares(): List<Square> = squares

    // ---- the "remote" input handler ---------------------------------------

    /** Make the cursor this end's (drawn into the picture, moved by deltas) or the phone's. */
    fun setRelative(on: Boolean, x: Float, y: Float) {
        relative = on
        relX = clamp(x, 0f, (width - 1).toFloat())
        relY = clamp(y, 0f, (height - 1).toFloat())
    }

    fun relative(): Boolean = relative

    override fun pointerEventRelative(dx: Int, dy: Int, buttons: Int) {
        relX = clamp(relX + dx, 0f, (width - 1).toFloat())
        relY = clamp(relY + dy, 0f, (height - 1).toFloat())
        pointerEvent(relX, relY, buttons)
    }

    override fun pointerEvent(x: Float, y: Float, buttons: Int) {
        val changed = buttons xor lastButtons
        val pressed = changed and buttons
        val released = changed and buttons.inv()
        // Before dispatching anything: a toggle handler is free to move the cursor, which re-enters
        // this method with the same button mask. Latch the mask first so the re-entrant call sees no
        // change and stops.
        lastButtons = buttons
        if (Button.WHEEL_UP.`in`(pressed)) wheelV--
        if (Button.WHEEL_DOWN.`in`(pressed)) wheelV++
        if (Button.WHEEL_LEFT.`in`(pressed)) wheelH--
        if (Button.WHEEL_RIGHT.`in`(pressed)) wheelH++

        if ((pressed and Button.DRAG_MASK) != 0) {
            val s = hit(x, y)
            if (s != null) {
                s.lastButton = Button.lowest(pressed and Button.DRAG_MASK)
                s.pressed = true
                if (s.toggle != null) {
                    toggles.onToggle(s.toggle)
                } else if (s.draggable) {
                    dragging = s
                    dragOffX = s.x - x
                    dragOffY = s.y - y
                }
            } else {
                // Pressed on the background: start a new stroke, dropping the last one. A tap
                // therefore clears the canvas.
                inkPath.rewind()
                inkPath.moveTo(x, y)
                drawing = true
            }
        }
        val d = dragging
        if (d != null && (buttons and Button.DRAG_MASK) != 0) {
            d.x = clamp(x + dragOffX, 0f, width - d.w)
            d.y = clamp(y + dragOffY, 0f, height - d.h)
        }
        if (drawing) {
            if ((buttons and Button.DRAG_MASK) != 0) {
                inkPath.lineTo(x, y)
            } else {
                drawing = false
            }
        }
        if ((released and Button.DRAG_MASK) != 0 && (buttons and Button.DRAG_MASK) == 0) {
            for (s in squares) {
                s.pressed = false
            }
            dragging = null
        }
        if (changed != 0) {
            lastEvent = (if (pressed != 0) "down " + Button.lowest(pressed) else "up " + Button.lowest(released)) +
                " @" + x.toInt() + "," + y.toInt()
        }
    }

    // ---- the "remote" keyboard handler ------------------------------------

    override fun keyDown(keysym: Int, keyId: Int) {
        lastKey = "down " + Keysym.name(keysym)
        heldKeys[keyId] = keysym
        if (keysym == Keysym.BACKSPACE) {
            if (typed.isNotEmpty()) {
                typed.setLength(typed.length - 1)
            }
            return
        }
        if (keysym == Keysym.RETURN) {
            typed.append('⏎')
            trimTyped()
            return
        }
        val cp = Keysym.toUnicode(keysym)
        if (cp != 0) {
            // Shift is held by the extension keyboard, not folded into the character, so apply it
            // here — the remote is what owns the layout.
            typed.appendCodePoint(
                if (heldKeys.containsValue(Keysym.SHIFT_L) || heldKeys.containsValue(Keysym.SHIFT_R)) {
                    Character.toUpperCase(cp)
                } else {
                    cp
                },
            )
            trimTyped()
        }
    }

    override fun keyUp(keyId: Int) {
        val keysym = heldKeys.remove(keyId)
        lastKey = "up " + (if (keysym == null) "?" else Keysym.name(keysym))
    }

    private fun trimTyped() {
        if (typed.length > 48) {
            typed.delete(0, typed.length - 48)
        }
    }

    fun typedText(): String = typed.toString()

    fun heldKeysText(): String {
        if (heldKeys.isEmpty()) {
            return "-"
        }
        val sb = StringBuilder()
        for (k in heldKeys.values) {
            if (sb.isNotEmpty()) {
                sb.append('+')
            }
            sb.append(Keysym.name(k))
        }
        return sb.toString()
    }

    /** The cursor shape the far end would show at ([x], [y]): the hand over an object, else null (the default). */
    fun shapeAt(x: Float, y: Float): Art.Cursor? {
        if (hit(x, y) != null) {
            return objectCursor
        }
        if (targetsShown) {
            for (t in targets) {
                val dx = x - t[0]
                val dy = y - t[1]
                if (dx * dx + dy * dy <= t[2] * t[2]) {
                    return objectCursor
                }
            }
        }
        return null
    }

    fun setTargets(shown: Boolean) {
        targetsShown = shown
    }

    private fun hit(x: Float, y: Float): Square? {
        for (i in squares.indices.reversed()) {
            if (squares[i].contains(x, y)) {
                return squares[i]
            }
        }
        return null
    }

    // ---- rendering (in desktop coordinates) -------------------------------

    fun draw(c: Canvas) {
        c.drawBitmap(wallpaper, 0f, 0f, null)

        // Under the ink, so a trail across one still shows where it went.
        if (targetsShown) {
            for (t in targets) {
                fill.color = 0x55ffffff
                c.drawCircle(t[0], t[1], t[2], fill)
                stroke.color = 0x88ffffff.toInt()
                c.drawCircle(t[0], t[1], t[2], stroke)
            }
        }
        c.drawPath(inkPath, ink)

        for (s in squares) {
            tmp.set(s.x, s.y, s.x + s.w, s.y + s.h)
            fill.color = if (s.pressed) darken(s.color) else s.color
            c.drawRoundRect(tmp, 6f, 6f, fill)
            stroke.color = if (s.pressed) 0xffffffff.toInt() else 0x66000000
            c.drawRoundRect(tmp, 6f, 6f, stroke)
            text.color = 0xddffffff.toInt()
            text.textSize = 15f
            c.drawText(s.title, s.x + s.w / 2, s.y + 20, text)
            val sub = if (s.toggle != null) {
                toggles.label(s.toggle)
            } else {
                (s.lastButton?.toString() ?: "-")
            }
            text.color = 0xffffffff.toInt()
            text.textSize = if (s.toggle != null) 17f else 22f
            c.drawText(sub, s.x + s.w / 2, s.y + s.h / 2 + 12, text)
        }

        // Wheel readout, so two-finger scroll is verifiable at a glance.
        tmp.set(width - 300f, 60f, width - 40f, 124f)
        fill.color = 0xcc202531.toInt()
        c.drawRoundRect(tmp, 6f, 6f, fill)
        text.color = 0xffffffff.toInt()
        text.textSize = 20f
        c.drawText("WHEEL  V $wheelV   H $wheelH", tmp.centerX(), tmp.centerY() + 7, text)

        // The remote's "text field": what the keyboard actually delivered.
        tmp.set(60f, height - 160f, width - 60f, height - 60f)
        fill.color = 0xcc202531.toInt()
        c.drawRoundRect(tmp, 6f, 6f, fill)
        text.color = 0xff9fb4d0.toInt()
        text.textSize = 15f
        c.drawText("KEYS   held ${heldKeysText()}   last $lastKey", tmp.centerX(), tmp.top + 26, text)
        text.color = 0xffffffff.toInt()
        text.textSize = 26f
        c.drawText(
            if (typed.isEmpty()) "(nothing typed)" else typed.toString(),
            tmp.centerX(), tmp.bottom - 22, text,
        )

        // Last, and in desktop pixels: a cursor this end owns is one drawn into the picture, at the
        // size the desktop draws it and zooming with it.
        if (relative) {
            c.drawBitmap(ownCursor.bitmap, relX - ownCursor.hotX, relY - ownCursor.hotY, null)
        }
    }

    private companion object {
        fun darken(color: Int): Int = Color.argb(
            Color.alpha(color),
            (Color.red(color) * 0.5f).toInt(),
            (Color.green(color) * 0.5f).toInt(),
            (Color.blue(color) * 0.5f).toInt(),
        )

        fun clamp(v: Float, lo: Float, hi: Float): Float = if (v < lo) lo else if (v > hi) hi else v
    }
}
