// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later
package net.pgaskin.remotedesktop.control.input

import java.io.BufferedReader
import java.io.IOException
import java.io.Reader
import java.io.StringReader

/**
 * A recorded touch session as text: `# key value` header lines, then one frame per line as
 * `time action [index] | id x y | id x y …`, with time relative to the first frame.
 */
object TouchLog {

    const val FORMAT = "remotedesktop-touch-1"

    /** What was read: the header's key/value pairs and the frames, in order. */
    class Log(
        val meta: MutableMap<String, String> = LinkedHashMap(),
        val frames: MutableList<TouchFrame> = ArrayList(),
    ) {
        fun meta(key: String, def: String?): String? = meta[key] ?: def

        fun metaFloat(key: String, def: Float): Float {
            val v = meta[key]
            return try {
                v?.toFloat() ?: def
            } catch (e: NumberFormatException) {
                def
            }
        }
    }

    class Writer {
        private val head = StringBuilder()
        private val body = StringBuilder()
        private var t0 = Long.MIN_VALUE
        private var frames = 0

        init {
            meta("format", FORMAT)
        }

        fun meta(key: String, value: String): Writer {
            head.append("# ").append(key).append(' ').append(value).append('\n')
            return this
        }

        fun add(f: TouchFrame): Writer {
            if (t0 == Long.MIN_VALUE) {
                t0 = f.time
            }
            body.append(f.time - t0).append(' ').append(f.action.code())
            if (f.action == TouchFrame.Action.DOWN || f.action == TouchFrame.Action.UP) {
                body.append(' ').append(f.index)
            }
            for (i in 0 until f.count) {
                body.append(" | ").append(f.id[i])
                    .append(' ').append(f.x[i])
                    .append(' ').append(f.y[i])
            }
            body.append('\n')
            frames++
            return this
        }

        fun frameCount(): Int = frames

        fun text(): String = head.toString() + body
    }

    fun parse(text: String): Log = try {
        parse(StringReader(text))
    } catch (e: IOException) {
        throw IllegalStateException(e) // StringReader does not throw
    }

    @Throws(IOException::class)
    fun parse(input: Reader): Log {
        val log = Log()
        val r = if (input is BufferedReader) input else BufferedReader(input)
        var lineNo = 0
        while (true) {
            val raw = r.readLine() ?: break
            lineNo++
            val line = raw.trim()
            if (line.isEmpty()) {
                continue
            }
            if (line[0] == '#') {
                val kv = line.substring(1).trim().split(Regex("\\s+"), 2)
                if (kv.size == 2) {
                    log.meta[kv[0]] = kv[1]
                }
                continue
            }
            try {
                log.frames.add(parseFrame(line))
            } catch (e: RuntimeException) {
                throw IllegalArgumentException("line $lineNo: $line", e)
            }
        }
        return log
    }

    private fun parseFrame(line: String): TouchFrame {
        // Java's split drops trailing empty strings; so does this.
        val parts = line.split('|').dropLastWhile { it.isEmpty() }
        val head = parts[0].trim().split(Regex("\\s+"))
        val time = head[0].toLong()
        val action = TouchFrame.Action.fromCode(head[1])
        val index = if (head.size > 2) head[2].toInt() else 0
        val f = TouchFrame().set(action, index, time)
        for (i in 1 until parts.size) {
            val p = parts[i].trim().split(Regex("\\s+"))
            f.add(p[0].toInt(), p[1].toFloat(), p[2].toFloat())
        }
        return f
    }
}
