// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later
package net.pgaskin.remotedesktop.control.input

import java.util.IdentityHashMap

/**
 * The row of keys a phone's own keyboard lacks: modifiers that stay down, arrows, function keys. Model
 * and hit-testing only, drawn by the view. Keys fire on release, so a drag can scroll the row instead;
 * a modifier is one-shot on a tap, locked on a double tap or a hold; some keys repeat while held.
 */
class ExtensionKeyboard(
    private val cfg: Config,
    private val sink: KeySink,
    private val scheduler: Scheduler,
    keys: List<Key>,
) : TouchRouter.Claim {

    enum class Feedback {
        /** A key tapped, or a modifier armed. */
        PRESS,
        /** A modifier locked, by a hold or by two taps. */
        LOCK,
        /** One repeat of a held key: up to thirteen a second, so the lightest tick there is. */
        REPEAT,
    }

    interface Listener {
        fun keyboardChanged()

        fun keyFeedback(what: Feedback) {
        }

        /** A key with an `action` was tapped, instead of sending a keysym. */
        fun keyAction(name: String) {
        }

        fun modifierPressed(key: Key) {
        }
    }

    /** Measures a label in the same units the layout works in; the view supplies a real one. */
    fun interface LabelWidth {
        fun measure(label: String): Float
    }

    /**
     * One key. [group] clusters keys with a gap between clusters; [row] is the line it sits on in a
     * multi-line row; [action] makes it a button that tells the listener rather than sending a keysym.
     */
    data class Key(
        val label: String,
        val icon: String?,
        val keysym: Int,
        val modifier: Boolean,
        val repeats: Boolean,
        val group: Int,
        val row: Int,
        val wide: Boolean,
        val action: String?,
    ) {
        constructor(
            label: String, icon: String?, keysym: Int,
            modifier: Boolean, repeats: Boolean, group: Int, wide: Boolean,
        ) : this(label, icon, keysym, modifier, repeats, group, 0, wide, null)

        fun repeating(): Key = copy(repeats = true)

        fun onRow(r: Int): Key = copy(row = r)

        companion object {
            fun normal(label: String, keysym: Int, group: Int): Key =
                Key(label, null, keysym, false, false, group, false)

            fun wide(label: String, keysym: Int, group: Int): Key =
                Key(label, null, keysym, false, false, group, true)

            fun icon(label: String, icon: String?, keysym: Int, group: Int): Key =
                Key(label, icon, keysym, false, false, group, true)

            fun modifier(label: String, icon: String?, keysym: Int, group: Int): Key =
                Key(label, icon, keysym, true, false, group, false)

            fun action(label: String, icon: String?, name: String, group: Int): Key =
                Key(label, icon, 0, false, false, group, 0, icon != null, name)
        }
    }

    enum class Sticky { OFF, ONESHOT, LOCKED }

    /** A key's rectangle in view pixels, or the info bar's part when [key] is null. */
    data class Bounds(
        val key: Key?,
        val left: Float,
        val top: Float,
        val right: Float,
        val bottom: Float,
    ) {
        fun contains(x: Float, y: Float): Boolean = x >= left && x < right && y >= top && y < bottom

        fun width(): Float = right - left

        fun centreX(): Float = (left + right) / 2.0f

        fun centreY(): Float = (top + bottom) / 2.0f
    }

    enum class Part {
        /** Show the typed text, or mask it as dots. */
        MASK,
        /** Hide the whole thing. */
        DISMISS,
    }

    private var keyList: List<Key> = emptyList()
    private val keyIndex = IdentityHashMap<Key, Int>()
    private val modifiers = ArrayList<Key>()
    private var state: Array<Sticky> = emptyArray()
    private var rows = 1 // lines of keys: max(Key.row) + 1

    private var listener: Listener? = null
    private var labelWidth = LabelWidth { estimateWidth(it) }
    private var viewW = 0
    private var viewH = 0
    private var bottomOffset = 0f // what already covers the bottom: the system IME
    private var visible = false
    private var masked = false

    private val keys = ArrayList<Bounds>()
    private var contentWidth = 0f
    private var scrollX = 0f

    // Fling: a smoothed drag velocity, and the glide it leaves behind.
    private var dragVelocity = 0f
    private var lastMoveTime = 0L
    private var flingVelocity = 0f

    private val typed = StringBuilder()
    private val heldIds = HashMap<Int, Int>()

    // ---- the pointer driving the keyboard, if any -------------------------
    private var activeId = NONE
    private var activeKey: Key? = null
    private var activePart: Part? = null
    private var pressX = 0f
    private var pressY = 0f
    private var lastX = 0f
    private var scrolling = false
    private var consumed = false // a long press decided; the lift does nothing
    private var spare = 0L // extra fingers: claimed so they cannot reach the pad, then ignored
    private var lastTapKey: Key? = null // for the double tap that locks a modifier
    private var lastTapTime = 0L

    private val longPressTask = Runnable { onLongPress() }

    private val repeatTask = object : Runnable {
        override fun run() {
            val k = activeKey
            if (k == null || !k.repeats) {
                return
            }
            // Only now has the hold produced anything, so only now must the lift stop producing one
            // of its own.
            consumed = true
            fire(k)
            feedback(Feedback.REPEAT)
            scheduler.postDelayed(this, cfg.keyRepeatMs)
        }
    }

    private val flingTask = object : Runnable {
        override fun run() {
            scrollBy(flingVelocity * cfg.keyboardFlingTickMs)
            flingVelocity *= cfg.keyboardFlingDecay
            if (Math.abs(flingVelocity) < cfg.keyboardFlingStopPx || atScrollLimit()) {
                flingVelocity = 0f
            } else {
                scheduler.postDelayed(this, cfg.keyboardFlingTickMs)
            }
            changed()
        }
    }

    init {
        adopt(keys)
    }

    fun setKeys(keys: List<Key>) {
        clearModifiers()
        release()
        heldIds.clear()
        adopt(keys)
        layout()
        changed()
    }

    private fun adopt(keys: List<Key>) {
        keyList = keys.toList()
        state = Array(keyList.size) { Sticky.OFF }
        rows = 1
        keyIndex.clear()
        modifiers.clear()
        for (i in keyList.indices) {
            keyIndex[keyList[i]] = i
        }
        for (i in state.indices) {
            val k = keyList[i]
            if (k.modifier) {
                modifiers.add(k)
            }
            rows = maxOf(rows, k.row + 1)
        }
    }

    fun setListener(l: Listener?) {
        listener = l
    }

    /** Supply real text measurement; null goes back to the estimate. */
    fun setLabelWidth(m: LabelWidth?) {
        labelWidth = m ?: LabelWidth { estimateWidth(it) }
        layout()
        changed()
    }

    fun setViewSize(w: Int, h: Int) {
        if (w == viewW && h == viewH) {
            return
        }
        viewW = w
        viewH = h
        layout()
        changed()
    }

    fun setBottomOffset(px: Float) {
        if (px == bottomOffset) {
            return
        }
        bottomOffset = px
        layout()
        changed()
    }

    fun allKeys(): List<Key> = keyList

    fun modifiers(): List<Key> = modifiers

    /** The keysyms of the modifiers currently held, one-shot or locked. */
    fun heldModifiers(): Set<Int> {
        val held = LinkedHashSet<Int>()
        for (m in modifiers) {
            if (sticky(m) != Sticky.OFF) {
                held.add(m.keysym)
            }
        }
        return held
    }

    fun sticky(k: Key): Sticky {
        val i = keyIndex[k]
        return if (i == null) Sticky.OFF else state[i]
    }

    fun visible(): Boolean = visible

    fun toggle() {
        setVisible(!visible)
    }

    fun setVisible(v: Boolean) {
        if (visible == v) {
            return
        }
        visible = v
        if (!visible) {
            release()
            clearModifiers()
            typed.setLength(0)
        }
        changed()
    }

    // ---- what the view draws ----------------------------------------------

    fun keys(): List<Bounds> = keys

    fun pressedKey(): Key? = if (scrolling) null else activeKey

    fun pressedX(): Float = pressX

    fun pressedY(): Float = pressY

    fun infoBarTop(): Float = keyRowTop() - cfg.keyboardInfoHeightPx

    fun keyRowTop(): Float = viewH - bottomOffset - rows * lineHeight()

    fun rows(): Int = rows

    fun contentWidth(): Float = contentWidth

    fun lineHeight(): Float = if (rows > 1) cfg.keyboardKeyHeightMultiPx else cfg.keyboardKeyHeightPx

    fun keyRowBottom(): Float = viewH - bottomOffset

    /** The info bar's button for [p], as a rectangle (its `key` is null). */
    fun part(p: Part): Bounds {
        val top = infoBarTop()
        val bottom = keyRowTop()
        val side = cfg.keyboardInfoHeightPx
        val right = if (p == Part.DISMISS) viewW.toFloat() else viewW - side
        return Bounds(null, right - side, top, right, bottom)
    }

    fun lightsLeft(): Float = cfg.dp(6f)

    fun lightCell(): Float = cfg.keyboardInfoHeightPx * 0.55f

    fun textLeft(): Float = lightsLeft() + modifiers.size * lightCell() + cfg.dp(8f)

    fun textRight(): Float = viewW - 2 * cfg.keyboardInfoHeightPx - cfg.dp(6f)

    fun masked(): Boolean = masked

    /** What the info bar shows: the typed line's tail, or dots. */
    fun infoText(): String {
        if (!masked) {
            return typed.toString()
        }
        return "●".repeat(typed.length)
    }

    /** How far to inset the desktop from the bottom so the keyboard does not cover it. */
    fun insetBottomPx(): Float {
        if (!visible) {
            return 0f
        }
        return bottomOffset + rows * lineHeight() + (if (cfg.keyboardInfoSolid) cfg.keyboardInfoHeightPx else 0f)
    }

    fun heightPx(): Float {
        if (!visible) {
            return 0f
        }
        return bottomOffset + rows * lineHeight() + cfg.keyboardInfoHeightPx
    }

    // ---- layout ------------------------------------------------------------

    private fun layout() {
        keys.clear()
        if (viewW <= 0 || viewH <= 0) {
            return
        }
        val n = keyList.size
        val runs = ArrayList<IntArray>() // {from, to} of each group
        val cols = ArrayList<FloatArray>() // its column widths
        contentWidth = 0f
        var i = 0
        while (i < n) {
            val group = keyList[i].group
            var j = i
            while (j < n && keyList[j].group == group) {
                j++
            }
            val w = columnWidths(i, j)
            if (i > 0) {
                contentWidth += cfg.keyboardGroupGapPx
            }
            for (cw in w) {
                contentWidth += cw
            }
            runs.add(intArrayOf(i, j))
            cols.add(w)
            i = j
        }
        val origin: Float
        if (contentWidth <= viewW) {
            scrollX = 0f
            origin = (viewW - contentWidth) / 2.0f
        } else {
            scrollX = clamp(scrollX, 0f, contentWidth - viewW)
            origin = -scrollX
        }
        val top = keyRowTop()
        val height = lineHeight()
        var x = origin
        for (g in runs.indices) {
            if (g > 0) {
                x += cfg.keyboardGroupGapPx
            }
            val run = runs[g]
            val w = cols[g]
            val next = IntArray(rows)
            for (k in run[0] until run[1]) {
                val key = keyList[k]
                val c = next[key.row]++
                var left = x
                for (q in 0 until c) {
                    left += w[q]
                }
                val keyTop = top + key.row * height
                keys.add(Bounds(key, left, keyTop, left + w[c], keyTop + height))
            }
            for (cw in w) {
                x += cw
            }
        }
    }

    private fun columnWidths(from: Int, to: Int): FloatArray {
        val w = FloatArray(to - from)
        val next = IntArray(rows)
        var columns = 0
        for (i in from until to) {
            val k = keyList[i]
            val c = next[k.row]++
            w[c] = maxOf(w[c], widthOf(k))
            columns = maxOf(columns, c + 1)
        }
        return w.copyOf(columns)
    }

    private fun widthOf(k: Key): Float {
        val pad = if (k.wide) cfg.keyboardKeyPadWidePx else cfg.keyboardKeyPadPx
        // An icon key is its icon wide, whatever its label says: the label is a fallback for a
        // renderer that cannot draw the icon.
        val content = if (k.icon != null) cfg.keyboardIconWidthPx else labelWidth.measure(k.label)
        return maxOf(cfg.keyboardMinKeyWidthPx, content + 2 * pad)
    }

    private fun scrollBy(dx: Float) {
        if (contentWidth <= viewW) {
            return
        }
        val before = scrollX
        scrollX = clamp(scrollX - dx, 0f, contentWidth - viewW)
        if (scrollX != before) {
            layout()
        }
    }

    // ---- TouchRouter.Claim -------------------------------------------------

    override fun claimTouch(id: Int, x: Float, y: Float, t: Long): Boolean {
        if (!visible || y < infoBarTop() || y >= keyRowBottom() || x < 0 || x >= viewW) {
            return false
        }
        if (activeId != NONE) {
            // A second finger on the keyboard: claimed so it cannot reach the touchpad behind, but
            // the row is one finger wide in practice.
            spare = spare or bit(id)
            return true
        }
        stopFling()
        activeId = id
        activeKey = null
        activePart = null
        pressX = x
        lastX = x
        pressY = y
        lastMoveTime = t
        dragVelocity = 0f
        scrolling = false
        consumed = false
        if (inInfoBar(y)) {
            activePart = partAt(x)
        } else {
            activeKey = keyAt(x, y)
            if (activeKey != null) {
                scheduler.postDelayed(longPressTask, cfg.keyLongPressMs)
            }
        }
        changed()
        return true
    }

    override fun claimMoved(id: Int, x: Float, y: Float, t: Long) {
        if (id != activeId) {
            return
        }
        if (!scrolling && activePart == null && Math.abs(x - pressX) > cfg.keyboardScrollSlopPx) {
            // Dragging, not tapping: give up on the key and scroll the row under it. This is why
            // keys fire on release rather than on press.
            scrolling = true
            activeKey = null
            cancelTimers()
        }
        if (scrolling) {
            scrollBy(x - lastX)
            // Smoothed: a fling is judged from the last delta before the finger left, and a single
            // frame's delta is noisy.
            val dt = maxOf(1L, t - lastMoveTime)
            val sample = (x - lastX) / dt
            dragVelocity = if (dragVelocity == 0f) sample else dragVelocity * 0.6f + sample * 0.4f
            changed()
        }
        lastX = x
        lastMoveTime = t
    }

    override fun claimEnded(id: Int, x: Float, y: Float, t: Long) {
        if (spare != 0L && (spare and bit(id)) != 0L) {
            spare = spare and bit(id).inv()
            return
        }
        if (id != activeId) {
            return
        }
        cancelTimers()
        val key = activeKey
        val part = activePart
        val act = !scrolling && !consumed
        val wasScrolling = scrolling
        activeId = NONE
        activeKey = null
        activePart = null
        scrolling = false
        if (wasScrolling && Math.abs(dragVelocity) >= cfg.keyboardFlingMinPx) {
            flingVelocity = dragVelocity
            scheduler.postDelayed(flingTask, cfg.keyboardFlingTickMs)
        }
        if (act && key != null && key == keyAt(x, y)) {
            // Still on the key it started on, which is the rule the info bar's parts below already
            // follow: lifting somewhere else is how a mis-aimed key is abandoned, and only sideways
            // movement — the scroll slop — used to do that.
            tap(key, t)
        } else if (act && part != null && inInfoBar(y) && partAt(x) == part) {
            // Still on what it started on, like an ordinary click.
            if (part == Part.DISMISS) {
                setVisible(false)
            } else {
                masked = !masked
            }
        }
        changed()
    }

    override fun claimCancelled(t: Long) {
        release()
        changed()
    }

    private fun release() {
        cancelTimers()
        stopFling()
        activeId = NONE
        activeKey = null
        activePart = null
        scrolling = false
        consumed = false
        spare = 0
        // The double-tap memory goes too. Hiding the row clears every modifier's state, so a
        // remembered tap that outlived it would meet a key that is off and read as the second of a
        // pair — locking on what is somebody's first tap since the row came back.
        lastTapKey = null
        lastTapTime = 0
    }

    private fun cancelTimers() {
        scheduler.removeCallbacks(longPressTask)
        scheduler.removeCallbacks(repeatTask)
    }

    private fun stopFling() {
        if (flingVelocity != 0f) {
            flingVelocity = 0f
            scheduler.removeCallbacks(flingTask)
        }
    }

    private fun atScrollLimit(): Boolean =
        contentWidth <= viewW || scrollX <= 0 || scrollX >= contentWidth - viewW

    fun flinging(): Boolean = flingVelocity != 0f

    private fun keyAt(x: Float, y: Float): Key? {
        for (b in keys) {
            if (b.contains(x, y)) {
                return b.key
            }
        }
        return null
    }

    private fun inInfoBar(y: Float): Boolean = y >= infoBarTop() && y < keyRowTop()

    private fun partAt(x: Float): Part {
        for (p in Part.values()) {
            val b = part(p)
            if (x >= b.left && x < b.right) {
                return p
            }
        }
        // The original's whole info bar toggles the mask; only the two buttons at the right end do
        // anything else.
        return Part.MASK
    }

    // ---- keys --------------------------------------------------------------

    private fun onLongPress() {
        val k = activeKey ?: return
        if (k.modifier) {
            consumed = true
            set(k, if (sticky(k) == Sticky.LOCKED) Sticky.OFF else Sticky.LOCKED)
            feedback(Feedback.LOCK)
        } else if (k.repeats) {
            scheduler.postDelayed(repeatTask, cfg.keyRepeatMs)
        }
        changed()
    }

    private fun tap(k: Key, t: Long) {
        val second = k == lastTapKey && t - lastTapTime <= cfg.keyDoubleTapMs
        lastTapKey = k
        lastTapTime = t
        if (!k.modifier) {
            fire(k)
        } else if (second) {
            set(k, if (sticky(k) == Sticky.LOCKED) Sticky.OFF else Sticky.LOCKED)
        } else {
            set(k, if (sticky(k) == Sticky.OFF) Sticky.ONESHOT else Sticky.OFF)
        }
        if (k.modifier) {
            listener?.modifierPressed(k)
        }
        feedback(if (second && k.modifier) Feedback.LOCK else Feedback.PRESS)
    }

    private fun fire(k: Key) {
        val action = k.action
        if (action != null) {
            listener?.keyAction(action)
            releaseOneShotModifiers()
            return
        }
        val id = keyId(k)
        sink.keyDown(k.keysym, id)
        sink.keyUp(id)
        note(k.keysym)
        releaseOneShotModifiers()
    }

    private fun keyId(k: Key): Int {
        val i = keyIndex[k]
        return KeySink.ID_EXTENSION_KEYBOARD + (i ?: -1)
    }

    /** A key typed some other way (the phone's keyboard): note it in the info bar and release one-shots. */
    fun externalKey(keysym: Int) {
        note(keysym)
        releaseOneShotModifiers()
        changed()
    }

    /** A click happened elsewhere: one-shot modifiers apply to it, so they are spent. */
    fun externalClick() {
        releaseOneShotModifiers()
        changed()
    }

    fun releaseOneShotModifiers() {
        for (m in modifiers) {
            if (sticky(m) == Sticky.ONESHOT) {
                set(m, Sticky.OFF)
            }
        }
    }

    fun clearModifiers() {
        for (m in modifiers) {
            set(m, Sticky.OFF)
        }
    }

    fun heldModifierCount(): Int {
        var n = 0
        for (m in modifiers) {
            if (sticky(m) != Sticky.OFF) {
                n++
            }
        }
        return n
    }

    private fun set(k: Key, to: Sticky) {
        val i = keyIndex[k] ?: -1
        if (i < 0 || state[i] == to) {
            return
        }
        val was = state[i] != Sticky.OFF
        state[i] = to
        val now = to != Sticky.OFF
        if (was == now) {
            return // ONESHOT ⇄ LOCKED: still held, nothing to send.
        }
        // Two keys can share a keysym — Windows and CMD are both Super_L — so the remote hears only
        // the first press and the last release, and the release has to name the id the *press*
        // used: press Windows then CMD and CMD's release ends a hold the far end recorded under
        // Windows.
        if (othersHold(i, k.keysym)) {
            return
        }
        if (now) {
            heldIds[k.keysym] = keyId(k)
            sink.keyDown(k.keysym, keyId(k))
        } else {
            val id = heldIds.remove(k.keysym)
            sink.keyUp(id ?: keyId(k))
        }
    }

    private fun othersHold(except: Int, keysym: Int): Boolean {
        for (i in state.indices) {
            if (i != except && state[i] != Sticky.OFF && keyList[i].keysym == keysym) {
                return true
            }
        }
        return false
    }

    private fun note(keysym: Int) {
        if (keysym == Keysym.BACKSPACE) {
            if (typed.isNotEmpty()) {
                typed.setLength(typed.length - 1)
            }
            return
        }
        if (keysym == Keysym.RETURN) {
            typed.setLength(0)
            return
        }
        val cp = Keysym.toUnicode(keysym)
        if (cp != 0) {
            typed.appendCodePoint(cp)
            if (typed.length > cfg.keyboardInfoMaxChars) {
                typed.delete(0, typed.length - cfg.keyboardInfoMaxChars)
            }
        }
    }

    private fun feedback(what: Feedback) {
        if (cfg.keyboardHaptics) {
            listener?.keyFeedback(what)
        }
    }

    private fun changed() {
        listener?.keyboardChanged()
    }

    companion object {
        const val ACTION_PASTE = "paste"

        private const val NONE = Int.MIN_VALUE

        fun standardKeys(): List<Key> {
            val k = ArrayList<Key>()
            // Labels, icons and grouping are the original's, key for key.
            k.add(Key.modifier("Shift", "shift", Keysym.SHIFT_L, 0))
            k.add(Key.modifier("Ctrl", null, Keysym.CONTROL_L, 0))
            k.add(Key.modifier("Alt", null, Keysym.ALT_L, 0))
            k.add(Key.modifier("Windows", "windows", Keysym.SUPER_L, 0))
            k.add(Key.modifier("Option", "option", Keysym.ISO_LEVEL3_SHIFT, 0))
            k.add(Key.modifier("CMD", "command", Keysym.SUPER_L, 0))
            k.add(Key.icon("Backspace", "backspace", Keysym.BACKSPACE, 1).repeating())
            k.add(Key.normal("Del", Keysym.DELETE, 1).repeating())
            k.add(Key.normal("Esc", Keysym.ESCAPE, 1))
            k.add(Key.normal("Tab", Keysym.TAB, 1).repeating())
            k.add(Key.normal("Ins", Keysym.INSERT, 1))
            k.add(Key.icon("Enter", "return", Keysym.RETURN, 2))
            k.add(Key.icon("Up", "arrow_up", Keysym.UP, 3).repeating())
            k.add(Key.icon("Down", "arrow_down", Keysym.DOWN, 3).repeating())
            k.add(Key.icon("Left", "arrow_left", Keysym.LEFT, 3).repeating())
            k.add(Key.icon("Right", "arrow_right", Keysym.RIGHT, 3).repeating())
            // Ours: the host types the phone's clipboard out, which works against a remote whose own
            // clipboard we cannot reach. A group to itself, so it has a gap either side — it is the
            // one key here the row cannot undo.
            k.add(Key.action("Paste", "paste", ACTION_PASTE, 4))
            k.add(Key.normal("Home", Keysym.HOME, 5))
            k.add(Key.normal("End", Keysym.END, 5))
            k.add(Key.normal("Page Up", Keysym.PAGE_UP, 5).repeating())
            k.add(Key.normal("Page Down", Keysym.PAGE_DOWN, 5).repeating())
            for (i in 1..12) {
                k.add(Key.wide("F$i", Keysym.f(i), 6))
            }
            return k
        }

        /** The same keys over two lines, for a phone held upright. */
        fun twoLineKeys(): List<Key> {
            val k = ArrayList<Key>()
            k.add(Key.modifier("Shift", "shift", Keysym.SHIFT_L, 0).onRow(1))
            k.add(Key.modifier("Ctrl", null, Keysym.CONTROL_L, 0).onRow(1))
            k.add(Key.modifier("Alt", null, Keysym.ALT_L, 0).onRow(1))
            k.add(Key.modifier("Windows", "windows", Keysym.SUPER_L, 0).onRow(1))
            k.add(Key.modifier("Option", "option", Keysym.ISO_LEVEL3_SHIFT, 0).onRow(1))
            k.add(Key.modifier("CMD", "command", Keysym.SUPER_L, 0).onRow(1))
            k.add(Key.icon("Backspace", "backspace", Keysym.BACKSPACE, 0).repeating())
            k.add(Key.normal("Del", Keysym.DELETE, 0).repeating())
            k.add(Key.normal("Esc", Keysym.ESCAPE, 0))
            k.add(Key.normal("Tab", Keysym.TAB, 0).repeating())
            k.add(Key.normal("Ins", Keysym.INSERT, 0))
            // Home and End are drawn as arrows here, where they sit over Left and Right: at that
            // width a word beside three arrow glyphs is what breaks the cluster up, and the shape is
            // the thing that says which is which.
            k.add(Key.icon("Home", "home", Keysym.HOME, 1))
            k.add(Key.icon("Up", "arrow_up", Keysym.UP, 1).repeating())
            k.add(Key.icon("End", "end", Keysym.END, 1))
            k.add(Key.icon("Left", "arrow_left", Keysym.LEFT, 1).repeating().onRow(1))
            k.add(Key.icon("Down", "arrow_down", Keysym.DOWN, 1).repeating().onRow(1))
            k.add(Key.icon("Right", "arrow_right", Keysym.RIGHT, 1).repeating().onRow(1))
            // Abbreviated, since the pair is a column of its own and "Page Down" is the widest label
            // on the row by half again.
            k.add(Key.normal("PgUp", Keysym.PAGE_UP, 2).repeating())
            k.add(Key.normal("PgDn", Keysym.PAGE_DOWN, 2).repeating().onRow(1))
            k.add(Key.action("Paste", "paste", ACTION_PASTE, 3))
            k.add(Key.icon("Enter", "return", Keysym.RETURN, 3).onRow(1))
            for (i in 1..12) {
                k.add(Key.wide("F$i", Keysym.f(i), 4).onRow(if (i <= 6) 0 else 1))
            }
            return k
        }

        private fun estimateWidth(label: String): Float = label.length * 12.0f

        private fun bit(id: Int): Long = if (id >= 0 && id < 64) 1L shl id else 0L

        private fun clamp(v: Float, lo: Float, hi: Float): Float = if (v < lo) lo else if (v > hi) hi else v
    }
}
