// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later
package net.pgaskin.remotedesktop.control.input

/** Turns scrolled distance into wheel clicks, carrying the remainder so slow scrolls still land. */
internal class WheelSteps(private val sink: MouseSink) {

    private var accX = 0f
    private var accY = 0f

    fun add(dx: Float, dy: Float, stepPx: Float) {
        accY += dy
        accX += dx
        val vsteps = (accY / stepPx).toInt()
        val hsteps = (accX / stepPx).toInt()
        var i = 0
        while (i < vsteps) {
            click(Button.WHEEL_DOWN)
            i++
        }
        i = 0
        while (i > vsteps) {
            click(Button.WHEEL_UP)
            i--
        }
        i = 0
        while (i < hsteps) {
            click(Button.WHEEL_RIGHT)
            i++
        }
        i = 0
        while (i > hsteps) {
            click(Button.WHEEL_LEFT)
            i--
        }
        accY %= stepPx
        accX %= stepPx
    }

    fun reset() {
        accX = 0f
        accY = 0f
    }

    private fun click(button: Button) {
        sink.mouseDown(button.mask())
        sink.mouseUp(button.mask())
    }
}
