// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later
package net.pgaskin.remotedesktop.control.input

import android.os.Handler
import android.os.Looper
import android.view.Choreographer

/** [Scheduler] on the main thread: a `Handler` for delays and the `Choreographer` for frames. */
class AndroidScheduler : Scheduler {

    private val handler = Handler(Looper.getMainLooper())
    private val choreographer = Choreographer.getInstance()
    private val frames = HashMap<Runnable, Choreographer.FrameCallback>()

    override fun postDelayed(r: Runnable, delayMs: Long) {
        handler.postDelayed(r, delayMs)
    }

    override fun removeCallbacks(r: Runnable) {
        handler.removeCallbacks(r)
    }

    override fun postFrame(r: Runnable) {
        if (frames.containsKey(r)) {
            // Already queued for the next frame. Posting the same callback again would run it
            // twice, which is not what "post this for the next frame" can be taken to mean.
            return
        }
        val cb = Choreographer.FrameCallback {
            frames.remove(r)
            r.run()
        }
        frames[r] = cb
        choreographer.postFrameCallback(cb)
    }

    override fun removeFrame(r: Runnable) {
        val cb = frames.remove(r)
        if (cb != null) {
            choreographer.removeFrameCallback(cb)
        }
    }
}
