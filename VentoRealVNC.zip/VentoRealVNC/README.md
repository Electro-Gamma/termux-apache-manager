# Vento RealVNC

RealVNC-only build of [Vento](https://github.com/pgaskin/vento) (GPL-3.0-or-later).

- Only the RealVNC backend is included (no TigerVNC, LibVNC, RDP, SPICE, RustDesk, no add-on/plugin mechanism).
- RealVNC's own `libvncviewer.so` + `libc++_shared.so` (viewer 4.9.3.60175, arm64-v8a) are NOT in this zip.
  Put them in `app/src/main/jniLibs/arm64-v8a/` before building (the Colab notebook does this and checks their SHA-256).
- Requires Android 14+ (minSdk 34), arm64 phone.
- Build: JDK 21, Android SDK with platforms;android-36, build-tools;36.0.0, ndk;28.2.13676358, cmake;3.30.5, then
  `./gradlew :app:assembleRelease` (set RVNC_KEYSTORE_PATH / RVNC_KEYSTORE_PASSWORD / RVNC_KEY_ALIAS / RVNC_KEY_PASSWORD to sign).
