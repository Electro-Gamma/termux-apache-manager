// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later

package net.pgaskin.remotedesktop.backend.realvnc;

import android.content.Context;

import java.io.File;
import java.io.IOException;

/**
 * Where {@code libvncviewer.so} comes from in this build: the APK itself.
 *
 * <p>The two libraries are RealVNC's own binaries for the build the JNI
 * declarations in {@code :realvnc-jni} were read from, supplied by whoever builds
 * this and packaged unchanged under {@code app/src/main/jniLibs/<abi>/}. They
 * are therefore extracted into the app's native library directory at install
 * time and loaded by name, in dependency order.
 */
final class RealVncLibrary {

    private static boolean loaded;

    private RealVncLibrary() {
    }

    /** True where this APK carries the viewer library for the phone's ABI. */
    static boolean isSetup(Context context) {
        final File dir = new File(context.getApplicationInfo().nativeLibraryDir);
        return new File(dir, "libvncviewer.so").isFile();
    }

    /** Both libraries, in order. Idempotent. */
    static synchronized void load(Context app) throws IOException {
        if (loaded) {
            return;
        }
        if (!isSetup(app)) {
            throw new IOException("This APK has no RealVNC library for this phone's CPU (arm64-v8a only).");
        }
        try {
            // libvncviewer.so has a DT_NEEDED on this one.
            System.loadLibrary("c++_shared");
            System.loadLibrary("vncviewer");
        } catch (UnsatisfiedLinkError e) {
            throw new IOException("Could not load RealVNC's library: " + e.getMessage(), e);
        }
        loaded = true;
    }
}
