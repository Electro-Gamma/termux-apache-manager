// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later
package net.pgaskin.remotedesktop.backend.realvnc

import android.content.Context
import net.pgaskin.remotedesktop.backend.Backend
import net.pgaskin.remotedesktop.backend.BackendOption
import net.pgaskin.remotedesktop.backend.BackendOption.Choice
import net.pgaskin.remotedesktop.backend.BackendOption.Scope
import net.pgaskin.remotedesktop.backend.BackendProvider

/**
 * RealVNC's own client, which is the only one here that speaks UDP, ZRLE2 and RealVNC's
 * proprietary authentication and encryption. Declared as a `ServiceLoader` service in
 * `META-INF/services`, so it must stay a public class with a public no-argument constructor.
 */
class RealVncProvider : BackendProvider {

    override fun id(): String = "realvnc"

    override fun name(): String = "VNC (RealVNC)"

    override fun shortName(): String = "RealVNC"

    override fun description(): String =
        "RealVNC's proprietary client implementation. This is the only one which supports UDP, " +
            "ZRLE2, and RealVNC's proprietary authentication/encryption. It performs " +
            "significantly better than the others when connecting to a RealVNC server, " +
            "especially for typical desktop usage."

    override fun order(): Int = 30

    override fun options(): List<BackendOption> = OPTIONS

    override fun create(
        context: Context, address: String, userName: String?, password: String?,
        options: Map<String, String>,
    ): Backend = RealVncBackend(context, address, userName, password, options)

    override fun isSetup(context: Context): Boolean = RealVncLibrary.isSetup(context)

    override fun forgetHosts(context: Context) {
        RealVncBackend.forgetIdentities(context)
    }

    internal companion object {
        private val COLOR_LEVEL = BackendOption.choice(
            "ColorLevel", "Colour depth",
            "Pixel color depth. Only used when quality is set to Low or Custom.",
            "full", Scope.LAYERED, true,
            Choice("full", "Full colour (24-bit)"),
            Choice("rgb222", "64 colours (rgb222)"),
            Choice("rgb111", "8 colours (rgb111)"),
        ).`when`("Quality", "Low", "Custom")

        /** The colour depth a quality preset implies when nothing else says. */
        fun colorLevelFor(quality: String?): String = if (quality == "Low") "rgb111" else "full"

        private val ENCODING = BackendOption.choice(
            "PreferredEncoding", "Encoding",
            "Preferred image encoding. The server may still choose to use a different one. " +
                "Only used when quality is set to Custom",
            "ZRLE2", Scope.LAYERED, true,
            Choice("JPEG", "JPEG (lossy)"),
            Choice("Zlib", "Zlib"),
            Choice("ZRLE", "ZRLE"),
            Choice("ZRLE2", "ZRLE2"),
            Choice("TRLE", "TRLE"),
            Choice("Hextile", "Hextile"),
            Choice("Raw", "Raw (uncompressed)"),
            Choice("JRLE", "JRLE (lossy)"),
        ).`when`("Quality", "Custom")

        private val OPTIONS: List<BackendOption> = listOf(
            // ---- per connection ---------------------------------------------
            // Auto, not the core's own default of High: Auto follows the measured line speed,
            // and pinning High on every connection is deciding for a network nobody has seen.
            BackendOption.choice(
                "Quality", "Picture quality",
                "Encoding and color depth preset.",
                "Auto", Scope.LAYERED, true,
                Choice("Auto", "Automatic"),
                Choice("High", "High"),
                Choice("Medium", "Medium"),
                Choice("Low", "Low"),
                Choice("Custom", "Custom"),
            ),
            ENCODING,
            COLOR_LEVEL,
            BackendOption.bool(
                "ViewOnly", "View only",
                "Do not send input or clipboard events.",
                false, Scope.CONNECTION, true,
            ),
            BackendOption.bool(
                "Shared", "Shared",
                "Do not ask the server to disconnect other clients.",
                true, Scope.CONNECTION, false,
            ),
            BackendOption.bool(
                "AutoReconnect", "Reconnect automatically",
                "Do not ask before re-establishing dropped connections.",
                true, Scope.CONNECTION, true,
            ),
            BackendOption.bool(
                "EnableUdpRfb", "Enable UDP",
                "Enable RealVNC's proprietary SCTP/RTP-based UDP protocol, falling back to TCP " +
                    "if the server doesn't respond within 500ms.",
                true, Scope.CONNECTION, false,
            ),

            // ---- per backend -------------------------------------------------
            BackendOption.choice(
                "Encryption", "Encryption",
                "Whether to encrypt connections.",
                "PreferOn", Scope.GLOBAL, false,
                Choice("AlwaysOn", "Required"),
                Choice("PreferOn", "If supported by the server"),
                Choice("PreferOff", "Only if required by the server"),
                Choice("Server", "Let the server decide"),
            ),
            BackendOption.bool(
                "WarnUnencrypted", "Warn when unencrypted",
                "Show a warning when connecting to a server which doesn't support encryption.",
                true, Scope.GLOBAL, false,
            ),
            BackendOption.bool(
                "DotWhenNoCursor", "Dot for an invisible cursor",
                "Show a dot when the server hides the cursor.",
                true, Scope.GLOBAL, false,
            ),
            BackendOption.bool(
                "AcceptBell", "Bell",
                "Vibrate when the remote servers rings the bell.",
                true, Scope.GLOBAL, false,
            ),
            // The three clipboard parameters this core has are deliberately not rows. Whether a
            // phone's clipboard goes to a remote machine and comes back is a question about the
            // phone, asked once in the app's own settings and enforced there.
            BackendOption.integer(
                "KeepAliveInterval", "Keep-alive interval",
                "Seconds between keep-alives on an idle connection.",
                30, Scope.GLOBAL, false,
            ),
            BackendOption.integer(
                "KeepAliveResponseTimeout", "Keep-alive timeout",
                "Seconds to wait for an answer before giving up.",
                30, Scope.GLOBAL, false,
            ),
        )

        /** Whether changing [key] mid-session needs `applyOptions` to take effect. */
        fun needsApply(key: String?): Boolean =
            key == "Quality" || key == "ColorLevel" || key == "PreferredEncoding"

        /** Every option's default, by key. */
        fun defaults(): Map<String, String> {
            val m = LinkedHashMap<String, String>()
            for (o in OPTIONS) {
                o.defaultValue?.let { m[o.key] = it }
            }
            return m
        }
    }
}
