// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later
package net.pgaskin.remotedesktop.backend.realvnc

import android.util.Log
import com.realvnc.vncviewer.jni.ConnectionInfoBindings
import com.realvnc.vncviewer.jni.SessionBindings

/**
 * A running count of bytes received, recovered from the core's line speed estimator.
 *
 * The estimator's own readout (a display string) is used as a checksum: the native shim reads
 * the estimator's fields, and the count is trusted only while the arithmetic over them agrees
 * with what the core itself publishes. After [GIVE_UP_AFTER] disagreements it stops, and
 * [received] answers -1.
 */
internal class RealVncTraffic {

    private val fields = LongArray(4)
    private var total = 0L
    private var mark = -1L // no sample yet, which is not a mark of zero
    private var mismatches = 0
    private var agreed = false
    private var gaveUp = false
    private var logged = false

    /** Bytes received so far, or -1 while there is no trustworthy count. */
    fun received(): Long = if (agreed && !gaveUp) total else -1

    /** Take a sample. Call regularly; the stream position wraps at 32 bits. */
    fun sample(session: SessionBindings.Session?) {
        if (gaveUp || session == null) {
            return
        }
        if (!nativeEstimator(session.getToken(), fields)) {
            return
        }
        val elapsed = fields[0]
        val kilobits = fields[1]
        val rtt = fields[2]
        val position = fields[3]

        // Their arithmetic, both of it: a kilobit total over an elapsed time in 100 ns units,
        // and a division that truncates towards zero. The divisor is zero until the first
        // window closes, where their aarch64 sdiv answers zero and the JVM would throw.
        val speed = if (elapsed == 0L) 0 else (kilobits * 10_000_000L / elapsed).toInt()
        val rttMs = (rtt / 10_000).toInt()
        val published = ConnectionInfoBindings.getLineSpeed(session)
        if (!states(published, speed, rttMs)) {
            if (++mismatches >= GIVE_UP_AFTER) {
                gaveUp = true
                Log.w(
                    RealVncCore.TAG,
                    "the line speed estimator is not where it was: \"$published\" against " +
                        "$speed kbit/s, $rttMs ms — no byte count",
                )
            }
            return
        }
        mismatches = 0
        agreed = true
        // The first mark is the total rather than a baseline: the position is the stream's,
        // so it already counts everything before this sample.
        total = if (mark < 0) position else total + ((position - mark) and 0xFFFFFFFFL)
        mark = position
        if (!logged) {
            logged = true
            Log.i(
                RealVncCore.TAG,
                "the bandwidth estimator agrees with \"$published\": $total bytes received so far",
            )
        }
    }

    companion object {
        private const val GIVE_UP_AFTER = 3

        init {
            System.loadLibrary("remotedesktop_realvnc")
        }

        /**
         * Implemented in `realvnc_traffic.c`. Public and `@JvmStatic` so it compiles to a plain
         * `static native` on [RealVncTraffic] under its exact JNI name.
         */
        @JvmStatic
        external fun nativeEstimator(token: Long, out: LongArray): Boolean

        /**
         * Whether [published] (a string like "1,234 kbit/s, 12 ms") states these two numbers,
         * as the first two numbers in it, ignoring digit-group separators.
         */
        private fun states(published: String?, speed: Int, rttMs: Int): Boolean {
            if (published.isNullOrEmpty()) {
                return false
            }
            var first = -1L
            var second = -1L
            var value = 0L
            var inNumber = false
            for (i in 0..published.length) {
                val c = if (i < published.length) published[i] else ' '
                val grouped = inNumber && isGroupSeparator(c) &&
                    i + 1 < published.length && isDigit(published[i + 1])
                if (isDigit(c)) {
                    value = value * 10 + (c - '0')
                    inNumber = true
                } else if (!grouped && inNumber) {
                    if (first < 0) {
                        first = value
                    } else if (second < 0) {
                        second = value
                    }
                    value = 0
                    inNumber = false
                }
            }
            return first == speed.toLong() && second == rttMs.toLong()
        }

        private fun isDigit(c: Char): Boolean = c in '0'..'9'

        private fun isGroupSeparator(c: Char): Boolean =
            c == ',' || c == '.' || c == ' ' || c == '\u00a0' || c == '\u202f'
    }
}
