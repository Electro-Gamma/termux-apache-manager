// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later
package net.pgaskin.remotedesktop.backend.realvnc

import android.content.Context
import java.io.File
import java.io.IOException

/**
 * RealVNC's proprietary `libvncviewer.so`, which is packaged into the APK's native library
 * directory at build time and is not part of this repository.
 */
internal object RealVncLibrary {

    private var loaded = false

    fun isSetup(context: Context): Boolean {
        val dir = File(context.applicationInfo.nativeLibraryDir)
        return File(dir, "libvncviewer.so").isFile
    }

    @Synchronized
    @Throws(IOException::class)
    fun load(app: Context) {
        if (loaded) {
            return
        }
        if (!isSetup(app)) {
            throw IOException("This APK has no RealVNC library for this phone's CPU (arm64-v8a only).")
        }
        try {
            // libvncviewer.so has a DT_NEEDED on this one.
            System.loadLibrary("c++_shared")
            System.loadLibrary("vncviewer")
        } catch (e: UnsatisfiedLinkError) {
            throw IOException("Could not load RealVNC's library: ${e.message}", e)
        }
        loaded = true
    }
}
