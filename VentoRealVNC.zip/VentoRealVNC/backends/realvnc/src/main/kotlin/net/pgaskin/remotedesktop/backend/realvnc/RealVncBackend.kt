// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later
package net.pgaskin.remotedesktop.backend.realvnc

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import com.realvnc.vncviewer.jni.ConnectionInfoBindings
import com.realvnc.vncviewer.jni.SessionBindings
import net.pgaskin.remotedesktop.backend.Backend
import net.pgaskin.remotedesktop.backend.ConnectionFact
import net.pgaskin.remotedesktop.backend.Prompt
import java.io.File
import java.nio.ByteBuffer

/**
 * [Backend] over RealVNC's own viewer core.
 *
 * Threads: the core runs everything on its own `HandlerThread` ([RealVncCore]); this class is
 * called from the main thread and from the drawing thread, and answers the core's callbacks on
 * the core's. State that crosses between them is `@Volatile`, and the pixel buffer is under
 * [pixels] because the native allocator does not lock.
 */
class RealVncBackend(
    context: Context,
    private val address: String,
    userName: String?,
    password: String?,
    extraOptions: Map<String, String>?,
) : Backend, SessionBindings.DesktopCallback, SessionBindings.SessionCallback {

    private val main = Handler(Looper.getMainLooper())
    private val context: Context = context.applicationContext

    // Empty is not a password: the core authenticates with whatever it is given, so "" fails the
    // connection outright instead of asking. Null is how it is told there is nothing stored.
    private val password: String? = if (password.isNullOrEmpty()) null else password
    private val options = LinkedHashMap<String, String>()

    private var listener: Backend.Listener? = null
    private var prompts: Prompt.Handler? = null

    @Volatile
    private var session: SessionBindings.Session? = null // written on the session thread, read everywhere

    @Volatile
    private var state = Backend.State.IDLE

    @Volatile
    private var desktopWidth = 0

    @Volatile
    private var desktopHeight = 0

    private val traffic = RealVncTraffic()
    private var lastSample = 0L

    private val pixels = Any()
    private var buffer: ByteBuffer? = null
    private var bufferWidth = 0
    private var bufferHeight = 0

    @Volatile
    private var dead = false // destroy() has run: every native call is a no-op after

    private val connectTimeout = Runnable { onConnectTimeout() }
    private var outstandingPrompts = 0

    private var colorLevelPinned = false

    @Volatile
    private var clipboard: String? = null

    private val held = LinkedHashSet<Int>()

    private var scratch: Bitmap? = null // guarded by pixels, like the buffer it is read through
    private var scratchCanvas: Canvas? = null
    private val scratchSrc = Rect()
    private val scratchDst = Rect()

    private var loggedDrawThread = false
    private var loggedEndThread = false

    init {
        // Every offered parameter at its default, then whatever the caller has stored over the
        // top. The list, the defaults and the wording all live in RealVncProvider, so the
        // settings screen and the connect path cannot drift apart.
        options.putAll(RealVncProvider.defaults())
        if (!userName.isNullOrEmpty()) {
            options["UserName"] = userName
        }
        if (extraOptions != null) {
            options.putAll(extraOptions)
        }

        // What this server was last accepted as. The core's own security prompt is silent for an
        // identity it recognises, which is the same "accepted once, loud if it changes" rule the
        // other backends get from KnownHosts.
        val identity = identities(context).getString(address, null)
        if (identity != null && !options.containsKey("Identity")) {
            options["Identity"] = identity
        }

        // Whether the colour depth is this connection's own choice. The store keeps only what
        // differs from the default, so the key being present *is* the statement that somebody set
        // it — and a depth somebody set must not be moved out from under them by the quality control.
        colorLevelPinned = extraOptions != null && extraOptions.containsKey("ColorLevel")
        if (!colorLevelPinned) {
            options["ColorLevel"] = RealVncProvider.colorLevelFor(options["Quality"])
        }
    }

    internal fun address(): String = address

    // ---- connect timeout ---------------------------------------------------

    private fun onConnectTimeout() {
        if (state == Backend.State.CONNECTING) {
            Log.w(TAG, "no connSuccess within $CONNECT_TIMEOUT_MS ms")
            reap(true)
            closed("Could not connect to $address")
        }
    }

    /** A question is on screen, so the clock stops: a person is taking as long as they take. */
    private fun promptShown() {
        RealVncCore.post {
            outstandingPrompts++
            RealVncCore.cancel(connectTimeout)
        }
    }

    internal fun promptAnswered() {
        RealVncCore.post {
            outstandingPrompts = maxOf(0, outstandingPrompts - 1)
            if (outstandingPrompts == 0 && state == Backend.State.CONNECTING && !dead) {
                RealVncCore.postDelayed(connectTimeout, CONNECT_TIMEOUT_MS)
            }
        }
    }

    // ---- lifecycle ---------------------------------------------------------

    override fun setListener(listener: Backend.Listener?) {
        this.listener = listener
    }

    override fun setPromptHandler(handler: Prompt.Handler?) {
        prompts = handler
    }

    override fun connect() {
        if (state != Backend.State.IDLE) {
            return
        }
        state = Backend.State.CONNECTING
        RealVncCore.start(context)
        RealVncCore.postDelayed(connectTimeout, CONNECT_TIMEOUT_MS)
        onMain { fireState(Backend.State.CONNECTING, "Connecting to $address") }
        RealVncCore.post {
            if (dead) {
                return@post
            }
            val t0 = System.nanoTime()
            RealVncPrompts.connecting(this)
            var s: SessionBindings.Session? = null
            try {
                s = SessionBindings.createSession(this, this, address, password, HashMap(options))
            } catch (t: Throwable) {
                Log.e(TAG, "createSession failed", t)
            } finally {
                RealVncPrompts.connected(this)
            }
            // It returns in a few ms and the connect proceeds as callbacks on this same thread, so
            // what follows runs before the connection is up. Logged rather than assumed, because
            // everything below depends on it.
            Log.i(TAG, "createSession returned after ${(System.nanoTime() - t0) / 1_000_000} ms on ${thread()} -> $s")
            if (s == null) {
                closed("Could not start the connection")
                return@post
            }
            session = s
            RealVncPrompts.attach(s, this)
            synchronized(pixels) {
                resizeBuffer(256, 256)
            }
            SessionBindings.focusEvent(s, true)
        }
    }

    override fun disconnect() {
        if (session != null) {
            reap(true)
        } else {
            closed("Disconnected")
        }
    }

    override fun destroy() {
        dead = true
        reap(true)
    }

    /** Let go of the session: on the core's thread, under the pixel lock, closing it unless it already closed. */
    private fun reap(close: Boolean) {
        RealVncCore.cancel(connectTimeout)
        val s = session ?: return
        session = null
        RealVncPrompts.detach(s)
        RealVncCore.post {
            // The pixel lock as well as the session thread: a fetch in flight on the drawing thread
            // must not be looking at the buffer this frees, and the native allocator does not lock.
            synchronized(pixels) {
                buffer = null
                bufferWidth = 0
                bufferHeight = 0
                scratch?.let {
                    it.recycle()
                    scratch = null
                    scratchCanvas = null
                }
                try {
                    // Not once the core has said it is closed: it tears the session down in
                    // `sessionClosed`, and a close after that faults in the same place a second one does.
                    if (close && state != Backend.State.CLOSED) {
                        SessionBindings.closeSession(s)
                    }
                } catch (t: Throwable) {
                    Log.w(TAG, "closing session", t)
                }
            }
        }
    }

    /** Run [what] on the core's thread against the current session, if there still is one. */
    private fun onSession(what: (SessionBindings.Session) -> Unit): Boolean {
        val s = session
        if (s == null || dead) {
            return false
        }
        RealVncCore.post {
            if (session === s) {
                what(s)
            }
        }
        return true
    }

    override fun state(): Backend.State = state

    override fun desktopWidth(): Int = desktopWidth

    override fun desktopHeight(): Int = desktopHeight

    override fun facts(): Backend.Facts =
        Backend.Facts(desktopWidth, desktopHeight, emptyList(), emptyList(), -1, false, viewOnly(), false)

    override fun connectionInfo(callback: (List<ConnectionFact>) -> Unit) {
        val s = session
        if (s == null || dead || state != Backend.State.CONNECTED) {
            main.post { callback(emptyList()) }
            return
        }
        RealVncCore.post {
            val facts = ArrayList<ConnectionFact>()
            if (!dead && session === s) {
                // Sampled here as well as on every update, since an idle desktop can be seconds
                // past the last one.
                traffic.sample(s)
                facts.add(ConnectionFact.of(ConnectionFact.Field.DESKTOP_NAME, "Desktop", ConnectionInfoBindings.getDesktopName(s)))
                facts.add(ConnectionFact.of(ConnectionFact.Field.PROTOCOL, "Protocol", ConnectionInfoBindings.getProtoVersion(s)))
                facts.add(ConnectionFact.of(ConnectionFact.Field.CONNECTION, "Connection", ConnectionInfoBindings.getConnectionType(s)))
                facts.add(ConnectionFact.of(ConnectionFact.Field.SECURITY, "Security", ConnectionInfoBindings.getSecurityDesc(s)))
                facts.add(ConnectionFact.of(ConnectionFact.Field.ENCODING, "Encoding", ConnectionInfoBindings.getLastUsedEncoding(s)))
                facts.add(ConnectionFact.of(ConnectionFact.Field.LINE_SPEED, "Line speed", ConnectionInfoBindings.getLineSpeed(s)))
                // Received only, and no row at all where there is no trustworthy number: the core
                // counts one direction and has no count of the other anywhere, and a zero would be a claim.
                val received = traffic.received()
                if (received >= 0) {
                    facts.add(ConnectionFact.data(received, -1))
                }
                facts.add(ConnectionFact.diagnostic(ConnectionFact.Field.SERVER_PIXELS, "Server pixels", ConnectionInfoBindings.getServerPixelFormat(s)))
                facts.add(ConnectionFact.diagnostic(ConnectionFact.Field.VIEWER_PIXELS, "Viewer pixels", ConnectionInfoBindings.getViewerPixelFormat(s)))
            }
            main.post { callback(facts) }
        }
    }

    override fun viewOnly(): Boolean = options["ViewOnly"].toBoolean()

    override fun setOption(key: String, value: String) {
        val s = session
        options[key] = value
        if (s == null) {
            return
        }
        // Same rule as the constructor's: a depth somebody has set is theirs, whether they set it
        // before the session or during it.
        colorLevelPinned = colorLevelPinned || key == "ColorLevel"
        val group = RealVncProvider.needsApply(key)

        // The quality group goes over as a group, always: the core re-reads the three together on
        // applyOptions, and the three decide one thing between them — which encodings to ask for
        // and which pixel format. Colour depth first, quality last, which is the order the pair
        // was seen to work in.
        val alsoSet = LinkedHashMap<String, String>()
        if (group) {
            // And the depth is the quality's, unless this connection chose one. Only a quality
            // change moves it, so a depth set in the panel is the one that goes over.
            if (!colorLevelPinned && key == "Quality") {
                options["ColorLevel"] = RealVncProvider.colorLevelFor(value)
            }
            alsoSet["ColorLevel"] = options["ColorLevel"] ?: "full"
            alsoSet["PreferredEncoding"] = options["PreferredEncoding"] ?: "ZRLE2"
            alsoSet["Quality"] = options["Quality"] ?: "Auto"
        } else {
            alsoSet[key] = value
        }
        RealVncCore.post {
            if (dead || session !== s) {
                return@post
            }
            for ((k, v) in alsoSet) {
                SessionBindings.setOption(s, k, v)
            }
            if (group) {
                SessionBindings.applyOptions(s)
            }
        }
    }

    // ---- input -------------------------------------------------------------

    override fun pointer(x: Int, y: Int, buttonMask: Int) {
        onSession { s -> SessionBindings.pointerEvent(s, x, y, buttonMask) }
    }

    override fun keyDown(keysym: Int, keyId: Int) {
        onSession { s ->
            held.add(keyId)
            SessionBindings.keyDownEvent(s, keysym.toLong(), keyId)
        }
    }

    override fun keyUp(keyId: Int) {
        onSession { s ->
            held.remove(keyId)
            SessionBindings.keyUpEvent(s, keyId)
        }
    }

    override fun releaseAllKeys() {
        onSession { s ->
            for (keyId in held) {
                SessionBindings.keyUpEvent(s, keyId)
            }
            held.clear()
        }
    }

    override fun focus(focused: Boolean) {
        onSession { s -> SessionBindings.focusEvent(s, focused) }
    }

    override fun clipboardToRemote(text: String) {
        // The core pulls ours through getClipboard() rather than being pushed, so there is nothing
        // to send: remember it and answer when asked.
        clipboard = text
    }

    // ---- pixels ------------------------------------------------------------

    override fun readRegion(x: Int, y: Int, width: Int, height: Int, dst: Bitmap, dstX: Int, dstY: Int): Boolean {
        if (dst.config != Bitmap.Config.ARGB_8888 || dstX < 0 || dstY < 0) {
            return false
        }
        if (dstX == 0 && dstY == 0 && width == dst.width && height == dst.height) {
            // Nothing outside the rectangle to preserve, so the copy lands in the caller's bitmap
            // and the scratch is not involved at all.
            return read(x, y, width, height, 1f, dst)
        }
        if (dstX + width > dst.width || dstY + height > dst.height) {
            return false
        }
        return synchronized(pixels) {
            var sc = scratch
            if (sc == null || sc.width != dst.width || sc.height != dst.height) {
                sc?.recycle()
                sc = Bitmap.createBitmap(dst.width, dst.height, Bitmap.Config.ARGB_8888)
                scratch = sc
                scratchCanvas = Canvas()
            }
            if (!read(x, y, width, height, 1f, sc!!)) {
                return@synchronized false
            }
            scratchSrc.set(0, 0, width, height)
            scratchDst.set(dstX, dstY, dstX + width, dstY + height)
            val canvas = scratchCanvas!!
            canvas.setBitmap(dst)
            canvas.drawBitmap(sc, scratchSrc, scratchDst, null)
            // Not left holding the caller's bitmap: a Canvas keeps its bitmap alive, and the
            // caller's are the biggest things in the app.
            canvas.setBitmap(null)
            true
        }
    }

    override fun thumbnail(maxWidth: Int, maxHeight: Int): Bitmap? {
        val w = desktopWidth
        val h = desktopHeight
        if (w <= 0 || h <= 0 || maxWidth <= 0 || maxHeight <= 0) {
            return null
        }
        // Powers of two only, and that is not a quality decision. The native step is
        // (int)(1/scale), so the scale we pass has to survive a round trip through a float
        // reciprocal exactly: 1f/3 is 0.33333334, whose reciprocal is 2.99999994, which truncates
        // to a step of *2* — the scaler then walks the source in half the intended stride and
        // writes 960 pixels a row into a 640-wide buffer, which is a native crash on the way out
        // of every session. 1/2, 1/4 and 1/8 are exact in binary.
        // Tested against what is allocated below rather than against the floor of the same
        // division, so the bitmap is never bigger than asked for.
        var step = 1
        while ((w + step - 1) / step > maxWidth || (h + step - 1) / step > maxHeight) {
            step = step shl 1
        }
        // Rounded up, so a desktop whose size is not a multiple of the step has a destination at
        // least as big as whatever the scaler decides to write.
        val tw = maxOf(1, (w + step - 1) / step)
        val th = maxOf(1, (h + step - 1) / step)
        val out = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888)
        if (!read(0, 0, w, h, 1f / step, out)) {
            out.recycle()
            return null
        }
        return out
    }

    private fun read(x: Int, y: Int, width: Int, height: Int, scale: Float, dst: Bitmap): Boolean {
        if (dst.config != Bitmap.Config.ARGB_8888) {
            return false
        }
        return synchronized(pixels) {
            val s = session
            if (s == null || dead || desktopWidth <= 0) {
                return@synchronized false
            }
            val dw = dst.width
            val dh = dst.height
            // The scaler writes at the *buffer's* row stride, so the buffer has to be exactly the
            // destination's width or the rows shear.
            if (buffer == null || bufferWidth != dw || bufferHeight < dh) {
                if (!resizeBuffer(dw, dh)) {
                    return@synchronized false
                }
            }
            try {
                SessionBindings.copyScaledRegion(s, x, y, width, height, scale)
            } catch (t: Throwable) {
                Log.w(TAG, "copyScaledRegion", t)
                return@synchronized false
            }
            val b = buffer ?: return@synchronized false
            b.rewind()
            dst.copyPixelsFromBuffer(b)
            true
        }
    }

    private fun resizeBuffer(width: Int, height: Int): Boolean {
        val s = session
        if (s == null || dead) {
            return false
        }
        buffer = try {
            SessionBindings.setScaleBufferSize(s, width, height)
        } catch (t: Throwable) {
            Log.w(TAG, "setScaleBufferSize", t)
            null
        }
        if (buffer == null) {
            bufferHeight = 0
            bufferWidth = 0
            return false
        }
        bufferWidth = width
        bufferHeight = height
        return true
    }

    // ---- DesktopCallback (native session thread) ---------------------------

    override fun connSuccess() {
        Log.i(TAG, "connSuccess on ${Thread.currentThread().name}")
        RealVncCore.cancel(connectTimeout)
        onMain {
            state = Backend.State.CONNECTED
            fireState(Backend.State.CONNECTED, null)
        }
    }

    override fun setDesktopSize(width: Int, height: Int) {
        Log.i(TAG, "setDesktopSize ${width}x$height on ${Thread.currentThread().name}")
        desktopWidth = width
        desktopHeight = height
        onMain { listener?.desktopSize(width, height) }
    }

    override fun drawRegion(x: Int, y: Int, width: Int, height: Int) {
        if (!loggedDrawThread) {
            loggedDrawThread = true
            Log.i(TAG, "drawRegion on ${thread()}")
        }
        listener?.damaged(x, y, width, height)
    }

    override fun framebufferUpdateEnd() {
        if (!loggedEndThread) {
            loggedEndThread = true
            Log.i(TAG, "framebufferUpdateEnd on ${thread()}")
        }
        // Where the received count is sampled, because this is the edge that moves it: the
        // estimator's window is the update this call ends. Once a second is enough — the mark is
        // cumulative, so a skipped update costs nothing at all.
        val now = SystemClock.uptimeMillis()
        if (now - lastSample >= SAMPLE_INTERVAL_MS) {
            lastSample = now
            traffic.sample(session)
        }
        listener?.frameEnd()
    }

    override fun setCursor(bitmap: Any?, negHotX: Int, negHotY: Int) {
        // The two ints are the negated hotspot: their RFB parser rewrites a cursor rectangle to
        // Rect(-hot, size - hot) on arrival and this callback forwards that rectangle's origin.
        val shape = bitmap as? Bitmap
        onMain { listener?.cursor(shape, -negHotX, -negHotY) }
    }

    override fun bell() {
        onMain { listener?.bell() }
    }

    override fun getClipboard(): String? {
        // Answered inline, on the core's thread, as the original does.
        val fromApp = listener?.clipboardForRemote()
        val out = fromApp ?: clipboard
        Log.i(TAG, "getClipboard: ${if (out == null) "none" else "${out.length} chars"}")
        return out
    }

    override fun setClipboard(text: String?) {
        Log.i(TAG, "setClipboard: ${if (text == null) "none" else "${text.length} chars"}")
        onMain { listener?.clipboardFromRemote(text) }
    }

    // ---- SessionCallback ---------------------------------------------------

    override fun sessionClosed(session: SessionBindings.Session?) {
        Log.i(TAG, "sessionClosed on ${Thread.currentThread().name}")
        val current = this.session
        if (session != null && current != null && session !== current) {
            return // not ours: the identity check the rest of this class is built on
        }
        // Already closed by definition, so do not close it again.
        reap(false)
        closed(null)
    }

    // ---- called by RealVncPrompts ------------------------------------------

    internal fun ask(prompt: Prompt) {
        promptShown()
        onMain {
            val h = prompts
            if (h == null) {
                prompt.cancel()
                return@onMain
            }
            when (prompt) {
                is Prompt.Credentials -> h.credentials(prompt)
                is Prompt.Trust -> h.trust(prompt)
                is Prompt.Message -> h.message(prompt)
            }
        }
    }

    internal fun status(text: String?) {
        Log.i(TAG, "status: $text")
        onMain { fireState(state, text) }
    }

    internal fun reconnecting(message: String?, detail: String?) {
        onMain { fireState(Backend.State.CONNECTING, message) }
    }

    internal fun reconnected() {
        onMain { fireState(state, null) }
    }

    internal fun saveCredentials(userName: String?, password: String?) {
        // The connection store is where these belong, and nothing here has a way to reach it:
        // saying so is better than silently dropping them.
        Log.i(TAG, "server asked to save credentials for $userName")
    }

    internal fun saveIdentity(identity: String?) {
        // Answering the prompt with "remember" is what makes the core send this; storing it is
        // what makes the next connection silent.
        identities(context).edit().putString(address, identity).apply()
    }

    // ---- plumbing ----------------------------------------------------------

    private fun closed(detail: String?) {
        onMain {
            if (state == Backend.State.CLOSED) {
                return@onMain
            }
            state = Backend.State.CLOSED
            fireState(Backend.State.CLOSED, detail)
        }
    }

    private fun fireState(s: Backend.State, detail: String?) {
        listener?.state(s, detail)
    }

    private fun onMain(r: Runnable) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            r.run()
        } else {
            main.post(r)
        }
    }

    companion object {
        private const val TAG = RealVncCore.TAG
        private const val SAMPLE_INTERVAL_MS = 1000L
        private const val CONNECT_TIMEOUT_MS = 20_000L

        @Suppress("DEPRECATION") // Thread.threadId() is Java 19; Android 14 is 17
        private fun thread(): String {
            val t = Thread.currentThread()
            return "${t.name} #${t.id}"
        }

        private fun identities(context: Context): SharedPreferences =
            context.getSharedPreferences("realvnc_identities", Context.MODE_PRIVATE)

        /** Forget every server identity this backend has accepted, the app's and the core's own. */
        internal fun forgetIdentities(context: Context) {
            identities(context).edit().clear().apply()
            val own = File(File(RealVncCore.dataDir(context), ".vnc"), "identities")
            if (own.exists() && !own.delete()) {
                Log.w(TAG, "could not delete $own")
            }
        }
    }
}
