// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later
package net.pgaskin.remotedesktop.backend.realvnc

import android.content.Context
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import com.realvnc.vncviewer.jni.AuthkeyStoreAndroid
import com.realvnc.vncviewer.jni.Bindings
import com.realvnc.vncviewer.jni.ConfigurationBindings
import java.io.File
import java.io.IOException

/**
 * The process-wide RealVNC core: its library, its one thread, and its bootstrap.
 *
 * Everything the core does happens on one `HandlerThread`; [post] and friends are how the rest
 * of the backend gets onto it.
 */
object RealVncCore {

    internal const val TAG = "RealVnc"
    private const val APP_NAME = "net.pgaskin.remotedesktop"

    private var handler: Handler? = null
    private var initialised = false

    internal fun dataDir(context: Context): File =
        File(context.applicationContext.filesDir, APP_NAME)

    /**
     * Bring the core up, once, and return the handler for its thread. Blocks until the
     * bootstrap has returned: everything else is illegal until then, and the caller is on
     * the main thread at startup where a few ms is invisible.
     */
    @Synchronized
    fun start(context: Context): Handler {
        if (initialised) {
            return handler!!
        }
        val app = context.applicationContext

        // Their library, out of the add-on, by absolute path. This call is what sets the
        // classloader the core's own lookups are answered from, so it has to be made from a
        // class of the add-on's — which this is.
        try {
            RealVncLibrary.load(app)
        } catch (e: IOException) {
            throw IllegalStateException(e.message, e)
        }

        // No client certificates: nothing here enrols one, so the core's identity
        // authentication has an empty list to choose from and falls back to a password.
        AuthkeyStoreAndroid.configure(app, emptySet())

        val thread = HandlerThread("VncCore")
        thread.start()
        val h = Handler(thread.looper)
        handler = h

        try {
            runBlocking {
                val logDir = File(app.filesDir, "vnclog")
                logDir.mkdirs()
                val global = mapOf(
                    // The cursor is ours to draw, at our own scale, over a desktop the viewport
                    // may be magnifying — so it is not offered as a setting.
                    "UseLocalCursor" to "true",
                    "Locale" to "en_US",
                    "SctpMaxMtu" to "1200",
                )
                Bindings.initApp(
                    APP_NAME,
                    "1",
                    app.filesDir.absolutePath,
                    logDir.absolutePath,
                    "vncviewer",
                    app,
                    global,
                    true,
                    Bindings.LogMode.LOG_DEBUG,
                )
                // The other half of the bootstrap. Everything it wants is about RealVNC
                // accounts, which we do not use; the bindings answer all of it themselves.
                Bindings.initViewer()
                RealVncPrompts.registerFactories()
                Log.i(TAG, "core initialised on ${Thread.currentThread().name}")
            }
        } catch (t: Throwable) {
            // A bootstrap that failed leaves nothing worth keeping: the thread goes, so the
            // next attempt is a whole one rather than a second initApp on a half-set-up looper.
            thread.quitSafely()
            handler = null
            throw t
        }
        // Last, so that a bootstrap which threw is not a core the next caller is told is ready.
        initialised = true
        return h
    }

    /** Run [r] on the core's thread — now, if already on it. */
    internal fun post(r: Runnable) {
        val h = handler!!
        if (Thread.currentThread() === h.looper.thread) {
            r.run()
        } else {
            h.post(r)
        }
    }

    internal fun postDelayed(r: Runnable, delayMs: Long) {
        handler!!.postDelayed(r, delayMs)
    }

    internal fun cancel(r: Runnable) {
        handler!!.removeCallbacks(r)
    }

    /**
     * Run [r] on the core's thread and wait for it. Exceptions are rethrown on the caller's
     * thread. Must not be called from a callback on the core's thread that is holding a lock
     * the caller needs; there is none today.
     */
    internal fun runBlocking(r: Runnable) {
        val h = handler!!
        if (Thread.currentThread() === h.looper.thread) {
            r.run()
            return
        }
        val lock = Object()
        var done = false
        var threw: Throwable? = null
        h.post {
            try {
                r.run()
            } catch (t: Throwable) {
                threw = t
            } finally {
                synchronized(lock) {
                    done = true
                    lock.notifyAll()
                }
            }
        }
        val failed: Throwable?
        synchronized(lock) {
            while (!done) {
                try {
                    lock.wait()
                } catch (e: InterruptedException) {
                    Thread.currentThread().interrupt()
                    return
                }
            }
            failed = threw
        }
        when (failed) {
            null -> {}
            is RuntimeException -> throw failed
            is Error -> throw failed
            else -> throw RuntimeException(failed)
        }
    }

    /** Set a core parameter, at the level the viewer applies its own expert options at. */
    fun setParameter(name: String, value: String) {
        post { ConfigurationBindings.set(name, value, 10, false) }
    }
}
