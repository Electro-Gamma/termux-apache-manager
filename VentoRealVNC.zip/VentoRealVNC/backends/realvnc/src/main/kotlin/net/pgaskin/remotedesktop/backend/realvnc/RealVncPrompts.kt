// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later
package net.pgaskin.remotedesktop.backend.realvnc

import android.util.Log
import com.realvnc.vncviewer.jni.AuthkeyChoiceDlgBindings
import com.realvnc.vncviewer.jni.InteractiveTextDlgBindings
import com.realvnc.vncviewer.jni.MsgBoxBindings
import com.realvnc.vncviewer.jni.PasswdDlgBindings
import com.realvnc.vncviewer.jni.ReconnectorBindings
import com.realvnc.vncviewer.jni.SaveCredentialsBindings
import com.realvnc.vncviewer.jni.SaveIdentityBindings
import com.realvnc.vncviewer.jni.SecurityDlgBindings
import com.realvnc.vncviewer.jni.SecurityNotificationBindings
import com.realvnc.vncviewer.jni.SessionBindings
import com.realvnc.vncviewer.jni.StatusNotificationBindings
import net.pgaskin.remotedesktop.backend.Prompt
import java.util.IdentityHashMap

/**
 * The core's questions, routed to the backend that owns the session they are about.
 *
 * A prompt can arrive *during* `createSession`, before a `Session` exists to key anything on,
 * which is what [connecting] and [pending] are for.
 */
internal object RealVncPrompts {

    private val owners = IdentityHashMap<SessionBindings.Session, RealVncBackend>()

    @Volatile
    private var pending: RealVncBackend? = null

    @Synchronized
    fun attach(session: SessionBindings.Session, backend: RealVncBackend) {
        owners[session] = backend
    }

    @Synchronized
    fun detach(session: SessionBindings.Session) {
        owners.remove(session)
    }

    /** [backend] is about to call `createSession`, so a prompt with no session is its. */
    fun connecting(backend: RealVncBackend) {
        pending = backend
    }

    fun connected(backend: RealVncBackend) {
        if (pending === backend) {
            pending = null
        }
    }

    /** An answer goes back to the core on its own thread, and the backend learns it was given. */
    private fun answered(backend: RealVncBackend, result: () -> Unit) {
        backend.promptAnswered()
        RealVncCore.post { result() }
    }

    @Synchronized
    private fun owner(session: SessionBindings.Session?): RealVncBackend? {
        val b = if (session == null) null else owners[session]
        return b ?: pending
    }

    /** Register every factory the core asks for. Runs on the core thread during bootstrap. */
    fun registerFactories() {
        PasswdDlgBindings.setPasswdDlgFactory { session, cookie, _ -> createPasswd(session, cookie) }
        SecurityDlgBindings.setSecurityDlgFactory { session, cookie -> createSecurity(session, cookie) }
        MsgBoxBindings.setMsgBoxFactory { session, cookie, message, flags, customButton ->
            createMsgBox(session, cookie, message, flags, customButton)
        }

        // The two below are answered without asking anyone. Interactive authentication needs a
        // form UI, and choosing a client identity needs identities we never enrol; both decline
        // rather than hang, which is the difference between "this server is not supported yet"
        // and "the app froze".
        InteractiveTextDlgBindings.setInteractiveTextDlgFactory { _, cookie ->
            object : InteractiveTextDlgBindings.InteractiveTextDlg {
                override fun promptInteractive(
                    elements: List<InteractiveTextDlgBindings.UiElement>?,
                    userNameFixed: Boolean,
                ) {
                    Log.w(RealVncCore.TAG, "declining interactive prompt with ${elements?.size ?: 0} elements")
                    RealVncCore.post { InteractiveTextDlgBindings.promptResult(cookie, false, null) }
                }

                override fun close() {
                }
            }
        }
        AuthkeyChoiceDlgBindings.setAuthkeyChoiceDlgFactory { _, cookie ->
            object : AuthkeyChoiceDlgBindings.AuthkeyChoiceDlg {
                override fun show(identities: Array<String>?) {
                    Log.w(RealVncCore.TAG, "declining identity choice")
                    RealVncCore.post { AuthkeyChoiceDlgBindings.identityChosen(cookie, false, null) }
                }

                override fun close() {
                }
            }
        }

        ReconnectorBindings.setDlgFactory { session ->
            object : ReconnectorBindings.ReconnectDlg {
                override fun show(message: String?, detail: String?) {
                    owner(session)?.reconnecting(message, detail)
                }

                override fun hide() {
                    owner(session)?.reconnected()
                }

                override fun close() {
                }
            }
        }

        // Notifications, not questions: the core has already acted.
        SaveCredentialsBindings.setCredentialsStore { session, userName, password ->
            owner(session)?.saveCredentials(userName, password)
        }
        SaveIdentityBindings.setIdentityStore { session, identity ->
            owner(session)?.saveIdentity(identity)
        }
        StatusNotificationBindings.setStatusNotifier { session, text ->
            owner(session)?.status(text)
        }
        SecurityNotificationBindings.setSecurityNotifier { _, text, background, _ ->
            Log.i(RealVncCore.TAG, "security banner: $text ($background)")
        }
    }

    // ---- the three we actually ask -----------------------------------------

    private fun createPasswd(session: SessionBindings.Session?, cookie: Long): PasswdDlgBindings.PasswdDlg {
        val backend = owner(session)
        return object : PasswdDlgBindings.PasswdDlg {
            override fun getUserPasswd(
                unused: String?, serverName: String?, userName: String?,
                wantsPassword: Boolean, catchphrase: String?, signature: String?,
                instructions: String?,
            ) {
                if (backend == null) {
                    RealVncCore.post { PasswdDlgBindings.passwdResult(cookie, false, null, null) }
                    return
                }
                backend.ask(
                    object : Prompt.Credentials(
                        serverName ?: "", instructions ?: "", userName != null,
                        userName ?: "", wantsPassword, catchphrase ?: "", signature ?: "",
                    ) {
                        override fun deliver(ok: Boolean, userName: String?, password: String?) {
                            answered(backend) { PasswdDlgBindings.passwdResult(cookie, ok, userName, password) }
                        }
                    },
                )
            }

            override fun close() {
            }
        }
    }

    private fun createSecurity(session: SessionBindings.Session?, cookie: Long): SecurityDlgBindings.SecurityDlg {
        val backend = owner(session)
        return object : SecurityDlgBindings.SecurityDlg {
            override fun promptSecurity(
                identityState: Int, encryptionState: Int, signature: String?,
                catchphrase: String?, name: String?, matchingName: String?,
                hint: String?,
            ) {
                if (backend == null) {
                    RealVncCore.post { SecurityDlgBindings.securityResult(cookie, false, false, false) }
                    return
                }
                // The identity is the first argument and the encryption the second, which is
                // the opposite of what their names in a decompiled signature suggest — see
                // SecurityDlgBindings.
                Log.i(RealVncCore.TAG, "promptSecurity id=$identityState enc=$encryptionState name=$name")
                backend.ask(
                    object : Prompt.Trust(
                        name ?: "", encryption(encryptionState), identity(identityState),
                        signature ?: "", catchphrase ?: "", matchingName,
                    ) {
                        override fun deliver(accept: Boolean, remember: Boolean) {
                            // The two save flags are identity and encryption; the encryption
                            // decision is not one we want remembered silently, so only the
                            // identity is offered.
                            answered(backend) { SecurityDlgBindings.securityResult(cookie, accept, remember, false) }
                        }
                    },
                )
            }

            override fun close() {
            }
        }
    }

    private fun createMsgBox(
        session: SessionBindings.Session?, cookie: Long, message: String?,
        flags: Int, customButton: String?,
    ): MsgBoxBindings.MsgBox {
        val backend = owner(session)
        val question = (flags and MsgBoxBindings.MB_OKCANCEL) != 0 || (flags and MsgBoxBindings.MB_YESNO) != 0
        val severity = severity(flags)
        if (backend != null) {
            backend.ask(
                object : Prompt.Message(
                    backend.address(), message ?: "", severity, question,
                    if ((flags and MsgBoxBindings.MB_CUSTOM) != 0) customButton else null,
                ) {
                    override fun deliver(ok: Boolean) {
                        answered(backend) { MsgBoxBindings.msgBoxResult(cookie, ok) }
                    }
                },
            )
        } else {
            RealVncCore.post { MsgBoxBindings.msgBoxResult(cookie, false) }
        }
        return MsgBoxBindings.MsgBox { }
    }

    private fun encryption(state: Int): Prompt.Trust.Encryption = when (state) {
        SecurityDlgBindings.ENC_ENCRYPTED -> Prompt.Trust.Encryption.ENCRYPTED
        SecurityDlgBindings.ENC_UNENCRYPTED_NO_WARN -> Prompt.Trust.Encryption.UNENCRYPTED_QUIET
        else -> Prompt.Trust.Encryption.UNENCRYPTED_WARN
    }

    private fun identity(state: Int): Prompt.Trust.Identity = when (state) {
        SecurityDlgBindings.ID_OK -> Prompt.Trust.Identity.OK
        SecurityDlgBindings.ID_NEW -> Prompt.Trust.Identity.NEW
        SecurityDlgBindings.ID_MATCHES_ANOTHER_SERVER -> Prompt.Trust.Identity.MATCHES_ANOTHER
        SecurityDlgBindings.ID_CHANGED -> Prompt.Trust.Identity.CHANGED
        SecurityDlgBindings.ID_PRESHARED -> Prompt.Trust.Identity.PRESHARED
        SecurityDlgBindings.ID_ARD -> Prompt.Trust.Identity.ARD
        else -> Prompt.Trust.Identity.MISSING
    }

    private fun severity(flags: Int): Prompt.Message.Severity {
        // The icon bits are a small enum in the high nibble, not independent flags:
        // MB_ICONWARNING is 48, which is MB_ICONERROR | MB_ICONQUESTION.
        return when (flags and MsgBoxBindings.MB_ICON_MASK) {
            MsgBoxBindings.MB_ICONERROR -> Prompt.Message.Severity.ERROR
            MsgBoxBindings.MB_ICONQUESTION -> Prompt.Message.Severity.QUESTION
            MsgBoxBindings.MB_ICONWARNING -> Prompt.Message.Severity.WARNING
            else -> Prompt.Message.Severity.INFORMATION
        }
    }
}
