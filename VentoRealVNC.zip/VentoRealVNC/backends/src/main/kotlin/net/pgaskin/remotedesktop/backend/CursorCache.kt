// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later
package net.pgaskin.remotedesktop.backend

import android.graphics.Bitmap

/**
 * The remote cursor's shapes, kept rather than rebuilt.
 *
 * What this saves is the `ARGB_8888` and the `setPixels` behind each shape, and then the
 * texture the renderer uploads for it: a pointer crossing a window's edge changes shape
 * several times a second, between two or three shapes it has already had.
 *
 * The identity is a hash of the pixels, computed by whichever shim already has them, and
 * this class trusts it.
 *
 * **Bounded:** there is a count and a byte budget and the least recently used goes first.
 *
 * Not thread-safe, and does not need to be: a backend's cursor callback arrives on its own
 * protocol thread and nothing else touches this.
 */
class CursorCache {

    private val shapes = LinkedHashMap<Long, Bitmap>(8, 0.75f, true)
    private var bytes = 0

    /**
     * The shape for these pixels, from the cache where it has been seen before and built
     * and kept where it has not.
     *
     * @param hash of the pixels, from wherever they were filled in
     * @param argb `width * height` pixels; null or empty hides the cursor, which is not a
     *             shape and is not cached
     * @return the bitmap, or null for a hidden cursor. Owned by this cache and valid until
     *         it is evicted, so a caller must not recycle it
     */
    fun shape(hash: Long, argb: IntArray?, width: Int, height: Int): Bitmap? {
        if (argb == null || width <= 0 || height <= 0 || argb.size < width * height) {
            return null
        }
        val cached = shapes[hash]
        if (cached != null) {
            return cached
        }
        val shape = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        shape.setPixels(argb, 0, width, 0, 0, width, height)
        shapes[hash] = shape
        bytes += width * height * 4
        // Eviction after insertion rather than before, so a single shape larger than the
        // whole budget is still returned once. Nothing recycles what it drops.
        val it = shapes.entries.iterator()
        while (it.hasNext() && (shapes.size > MAX_SHAPES || bytes > MAX_BYTES) && shapes.size > 1) {
            val evicted = it.next().value
            bytes -= evicted.width * evicted.height * 4
            it.remove()
        }
        return shape
    }

    fun clear() {
        shapes.clear()
        bytes = 0
    }

    companion object {
        /** More shapes than a desktop has. Windows ships about a dozen. */
        private const val MAX_SHAPES = 16

        /** A 256×256 cursor is a quarter of this, and is already absurd. */
        private const val MAX_BYTES = 1024 * 1024

        /**
         * FNV-1a over the pixels, which is what every shim computes natively and what this
         * exists to define in one place.
         */
        @JvmStatic
        fun hash(argb: IntArray, width: Int, height: Int): Long {
            var h = -0x340d631b7bdddcdbL // 0xcbf29ce484222325
            h = (h xor width.toLong()) * 0x100000001b3L
            h = (h xor height.toLong()) * 0x100000001b3L
            for (p in argb) {
                // Masked, because an opaque pixel is a negative int and sign extension
                // would not match the shims, where it is a u32.
                h = (h xor (p.toLong() and 0xffffffffL)) * 0x100000001b3L
            }
            return h
        }
    }
}
