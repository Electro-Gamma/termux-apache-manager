// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later
package net.pgaskin.remotedesktop.backend

import android.graphics.Bitmap

/**
 * One connection to one remote desktop, as the app sees it: pixels come out, input goes in,
 * and everything protocol-specific stays behind this interface.
 *
 * Created by a [BackendProvider], not yet started; [connect] starts it and [destroy] ends it
 * for good. [Listener] callbacks arrive on the backend's own thread unless a backend says
 * otherwise.
 */
interface Backend {

    enum class State {
        /** Created, not started. */
        IDLE,
        /** [connect] called, nothing usable yet. */
        CONNECTING,
        /** Pixels and input are flowing. */
        CONNECTED,
        /** Over, for any reason; detail says which, and it is terminal. */
        CLOSED,
    }

    interface Listener {
        fun state(state: State, detail: String?)

        fun desktopSize(width: Int, height: Int)

        fun damaged(x: Int, y: Int, width: Int, height: Int)

        fun frameEnd()

        /** A new cursor shape; null hides it. */
        fun cursor(shape: Bitmap?, hotX: Int, hotY: Int)

        fun pointerMode(relative: Boolean)

        fun bell()

        fun clipboardFromRemote(text: String?)

        fun clipboardForRemote(): String?
    }

    fun setListener(listener: Listener?)

    fun setPromptHandler(handler: Prompt.Handler?)

    fun connect()

    fun disconnect()

    fun destroy()

    fun state(): State

    /** Change an option mid-session; only meaningful for a [BackendOption.live] one. */
    fun setOption(key: String, value: String)

    fun viewOnly(): Boolean

    /** What the backend can say about the connection, delivered to [callback]. */
    fun connectionInfo(callback: (List<ConnectionFact>) -> Unit)

    fun desktopWidth(): Int

    fun desktopHeight(): Int

    /** A snapshot of what the connection currently is, for the UI to read in one go. */
    class Facts(
        val desktopWidth: Int,
        val desktopHeight: Int,
        monitors: List<Monitor>,
        displays: List<Monitor>,
        /** Which of [displays] is the picture, or -1. */
        val display: Int,
        val canResize: Boolean,
        val viewOnly: Boolean,
        val pointerRelative: Boolean,
    ) {
        val monitors: List<Monitor> = monitors.toList()
        val displays: List<Monitor> = displays.toList()

        companion object {
            @JvmField
            val NONE = Facts(0, 0, emptyList(), emptyList(), -1, false, false, false)
        }
    }

    fun facts(): Facts

    /** Switch to another of [Facts.displays], for the protocol that sends one screen at a time. */
    fun requestDisplay(index: Int) {
    }

    /** Ask the far end to resize its desktop, where [Facts.canResize]. */
    fun requestDesktopSize(width: Int, height: Int) {
    }

    // ---- input ------------------------------------------------------------

    fun pointer(x: Int, y: Int, buttonMask: Int)

    fun pointerRelative(dx: Int, dy: Int, buttonMask: Int) {
    }

    fun keyDown(keysym: Int, keyId: Int)

    fun keyUp(keyId: Int)

    fun releaseAllKeys()

    fun focus(focused: Boolean)

    fun clipboardToRemote(text: String)

    // ---- pixels -----------------------------------------------------------

    /** Copy a desktop region into [dst] at ([dstX], [dstY]); false if there is nothing to copy. */
    fun readRegion(x: Int, y: Int, width: Int, height: Int, dst: Bitmap, dstX: Int, dstY: Int): Boolean

    fun thumbnail(maxWidth: Int, maxHeight: Int): Bitmap?
}
