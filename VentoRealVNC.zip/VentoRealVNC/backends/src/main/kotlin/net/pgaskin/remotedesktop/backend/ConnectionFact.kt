// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later
package net.pgaskin.remotedesktop.backend

import java.util.Locale

/**
 * One line of what a backend can say about the connection it is running.
 *
 * [Field] is the identity and is a fixed set: the panel matches on it, so a backend
 * that calls line speed something else still lands in the right place. [label] is the
 * backend's own wording for the same thing, which is what actually goes on screen.
 *
 * A backend **omits** a field it has no concept of, and **includes one with an empty
 * value** when it has the concept but no answer yet.
 *
 * There is no field for the desktop *size*: it is known locally from
 * [Backend.desktopWidth] the moment the first framebuffer arrives.
 *
 * @param diagnostic true for something only worth reading when hunting a problem
 */
class ConnectionFact(
    val field: Field,
    val label: String,
    value: String?,
    val diagnostic: Boolean,
) {
    /** The value, trimmed; never null. */
    val value: String = value?.trim() ?: ""

    /** What a row *is*, independently of what a backend calls it. */
    enum class Field {
        /** The desktop's own name for itself. The panel's heading. */
        DESKTOP_NAME,
        /** How the bytes get there: direct TCP, relayed, UDP. */
        CONNECTION,
        /** What is protecting them, if anything. */
        SECURITY,
        /** Which version of which protocol is being spoken. */
        PROTOCOL,
        /** The encoding in use for pixels — moves when quality moves. */
        ENCODING,
        /** The measured throughput, however the backend measures it. */
        LINE_SPEED,
        /** What the session has moved, both ways, since it was opened. */
        DATA,
        /** What the server is sending. */
        SERVER_PIXELS,
        /** What we asked it for. */
        VIEWER_PIXELS,
        /** Anything a particular protocol has that this list does not. */
        OTHER,
    }

    operator fun component1(): Field = field
    operator fun component2(): String = label
    operator fun component3(): String = value
    operator fun component4(): Boolean = diagnostic

    override fun equals(other: Any?): Boolean =
        other is ConnectionFact && field == other.field && label == other.label &&
            value == other.value && diagnostic == other.diagnostic

    override fun hashCode(): Int = arrayOf<Any?>(field, label, value, diagnostic).contentHashCode()

    override fun toString(): String = "ConnectionFact[field=$field, label=$label, value=$value, diagnostic=$diagnostic]"

    companion object {
        @JvmStatic
        fun of(field: Field, label: String, value: String?): ConnectionFact =
            ConnectionFact(field, label, value, false)

        @JvmStatic
        fun diagnostic(field: Field, label: String, value: String?): ConnectionFact =
            ConnectionFact(field, label, value, true)

        /**
         * [Field.DATA], from two raw counts. A direction the protocol has no count for
         * is **negative**, and is left out of the row rather than shown as a zero.
         *
         * Bytes are handed over raw so every backend says it the same way and rounds
         * it the same way.
         */
        @JvmStatic
        fun data(received: Long, sent: Long): ConnectionFact {
            val value = if (sent < 0) {
                "${size(received)} in"
            } else {
                "${size(received)} in · ${size(sent)} out"
            }
            return of(Field.DATA, "Transferred", value)
        }

        /**
         * Bytes as a person reads them: powers of a thousand, and a decimal only where
         * the mantissa is small enough for one to mean anything.
         */
        private fun size(bytes: Long): String {
            if (bytes < 1000) {
                return "$bytes B"
            }
            val units = arrayOf("kB", "MB", "GB", "TB")
            var value = bytes / 1000.0
            var unit = 0
            while (value >= 999.5 && unit < units.size - 1) {
                value /= 1000.0
                unit++
            }
            // The phone's own separators, since this is a number somebody reads.
            val format = if (value < 9.995) "%.2f %s" else if (value < 99.95) "%.1f %s" else "%.0f %s"
            return String.format(Locale.getDefault(), format, value, units[unit])
        }
    }
}
