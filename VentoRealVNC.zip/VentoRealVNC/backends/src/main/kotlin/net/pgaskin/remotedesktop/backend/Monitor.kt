// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later
package net.pgaskin.remotedesktop.backend

/**
 * One of the far end's screens, as a rectangle in its coordinates.
 *
 * [Backend.monitors] is a multi-head desktop as most protocols here serve it: *one*
 * framebuffer with the heads laid out inside it, so the rectangles tile the picture and
 * nothing about the pixels or the pointer is built on them. [Backend.displays] is
 * RustDesk's, where the far end sends one screen at a time: the rectangles are then a
 * menu rather than a map.
 */
data class Monitor(val x: Int, val y: Int, val width: Int, val height: Int) {

    fun right(): Int = x + width

    fun bottom(): Int = y + height

    fun contains(px: Int, py: Int): Boolean = px >= x && py >= y && px < right() && py < bottom()

    companion object {
        /**
         * The shape every native backend hands its layout over in: four ints per
         * monitor, x, y, width, height. The empty and null cases are the same answer
         * in every backend.
         */
        @JvmStatic
        fun fromFlat(flat: IntArray?): List<Monitor> {
            if (flat == null || flat.size < 4) {
                return emptyList()
            }
            val monitors = ArrayList<Monitor>(flat.size / 4)
            var i = 0
            while (i + 3 < flat.size) {
                if (flat[i + 2] > 0 && flat[i + 3] > 0) {
                    monitors.add(Monitor(flat[i], flat[i + 1], flat[i + 2], flat[i + 3]))
                }
                i += 4
            }
            return monitors.toList()
        }
    }
}
