// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later
package net.pgaskin.remotedesktop.backend

import android.content.Context
import android.content.SharedPreferences
import java.util.Locale

/**
 * Trust-on-first-use for server identities, for the backends whose library hands the
 * decision to us rather than keeping a store of its own. An address maps to the
 * fingerprint accepted for it.
 */
object KnownHosts {

    private const val FILE = "known_hosts"

    private fun prefs(ctx: Context): SharedPreferences =
        ctx.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    private fun key(address: String?): String = address?.trim()?.lowercase(Locale.ROOT) ?: ""

    /** The fingerprint accepted for [address], or null. */
    fun pinned(ctx: Context, address: String?): String? = prefs(ctx).getString(key(address), null)

    fun pin(ctx: Context, address: String?, fingerprint: String?) {
        prefs(ctx).edit().putString(key(address), fingerprint).apply()
    }

    fun forget(ctx: Context, address: String?) {
        prefs(ctx).edit().remove(key(address)).apply()
    }

    fun clear(ctx: Context) {
        prefs(ctx).edit().clear().apply()
    }

    /** Whether [fingerprint] is the one pinned for [address], ignoring case and separators. */
    fun matches(ctx: Context, address: String?, fingerprint: String?): Boolean {
        val pin = pinned(ctx, address)
        return pin != null && canonical(pin) == canonical(fingerprint)
    }

    /** Hex digits only, upper-cased, so `ab:cd` and `ABCD` are the same fingerprint. */
    private fun canonical(fingerprint: String?): String {
        if (fingerprint == null) {
            return ""
        }
        val out = StringBuilder(fingerprint.length)
        for (c in fingerprint) {
            if (Character.digit(c, 16) >= 0) {
                out.append(c.uppercaseChar())
            }
        }
        return out.toString()
    }

    /**
     * Ask whether to trust a server whose identity is not (or no longer) the pinned one.
     * [answer] receives the decision. A null [handler] cancels, since nobody can answer.
     */
    fun ask(
        ctx: Context, address: String, fingerprint: String,
        handler: Prompt.Handler?, answer: (Boolean) -> Unit,
    ) {
        val pin = pinned(ctx, address)
        val elsewhere = if (pin == null) otherAddressFor(ctx, fingerprint, address) else null
        val identity = when {
            pin != null -> Prompt.Trust.Identity.CHANGED
            elsewhere != null -> Prompt.Trust.Identity.MATCHES_ANOTHER
            else -> Prompt.Trust.Identity.NEW
        }
        val prompt = object : Prompt.Trust(
            address, Encryption.ENCRYPTED, identity, fingerprint, "", elsewhere,
        ) {
            override fun deliver(accept: Boolean, remember: Boolean) {
                if (accept && remember) {
                    pin(ctx, address, fingerprint)
                }
                answer(accept)
            }
        }
        if (handler == null) {
            prompt.cancel()
        } else {
            handler.trust(prompt)
        }
    }

    /** Another address this fingerprint is already pinned under, or null. */
    fun otherAddressFor(ctx: Context, fingerprint: String?, except: String?): String? {
        if (fingerprint.isNullOrEmpty()) {
            return null
        }
        val skip = key(except)
        val wanted = canonical(fingerprint)
        for ((k, v) in prefs(ctx).all) {
            if (k != skip && v is String && wanted == canonical(v)) {
                return k
            }
        }
        return null
    }
}
