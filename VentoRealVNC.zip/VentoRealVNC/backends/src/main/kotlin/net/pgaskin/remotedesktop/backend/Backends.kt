// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later
package net.pgaskin.remotedesktop.backend

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.util.Log
import dalvik.system.PathClassLoader
import java.io.File
import java.util.ServiceLoader
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Every backend this build can connect with: the ones on its own classpath (found through
 * [ServiceLoader]) and the ones that arrive as add-on apps signed like it.
 *
 * Nothing above this names a protocol; the app asks by id.
 */
object Backends {

    private const val TAG = "Backends"

    /** The action an add-on's service declares to be found. */
    const val PLUGIN_ACTION = "net.pgaskin.remotedesktop.action.BACKEND_PLUGIN"

    const val PLUGIN_UPDATE_URL = "net.pgaskin.remotedesktop.plugin.updateUrl"

    const val PLUGIN_UPDATE_SIGNATURE = "net.pgaskin.remotedesktop.plugin.updateSignature"

    const val PLUGIN_UPDATE_VERSION = "{versionCode}"

    enum class PluginState {
        LOADED,
        INCOMPATIBLE,
        FAILED,
    }

    /** What discovery made of one add-on; [detail] is its own words where it failed. */
    data class Plugin(val packageName: String, val state: PluginState, val detail: String?)

    @Volatile
    private var providerList: List<BackendProvider>? = null
    private var builtInList: List<BackendProvider>? = null
    private var pluginList: List<Plugin> = emptyList()
    private var discovered: List<BackendProvider> = emptyList()

    @Volatile
    private var chain: Chain? = null

    private val failedAtUse = ConcurrentHashMap<String, String>()
    private val setUp: MutableSet<String> = ConcurrentHashMap.newKeySet()
    private val asking = HashMap<String, MutableList<(Boolean) -> Unit>>()
    private var worker: ExecutorService? = null // under `asking`
    private val main = Handler(Looper.getMainLooper())

    /**
     * The app's class loader, wrapped so an add-on's classes are reachable by name from
     * native code too. Called once from `Application.attachBaseContext`.
     */
    fun classLoader(app: ClassLoader): ClassLoader {
        val c = Chain(app)
        chain = c
        return c
    }

    /** Falls through to each add-on's own loader, in the order they were added. */
    private class Chain(app: ClassLoader) : ClassLoader(app) {
        @Volatile
        private var loaders: List<Plugins> = emptyList()

        fun add(loader: Plugins) {
            loaders = loaders + loader
        }

        override fun findClass(name: String): Class<*> {
            for (loader in loaders) {
                val found = loader.local(name)
                if (found != null) {
                    return found
                }
            }
            throw ClassNotFoundException(name)
        }
    }

    private class Plugins(
        val packageName: String, dex: String, libs: String?, parent: ClassLoader?,
    ) : PathClassLoader(dex, libs, parent) {
        /** Only this loader's own classes, not its parent's. */
        fun local(name: String): Class<*>? = try {
            findClass(name)
        } catch (e: ClassNotFoundException) {
            null
        }
    }

    /**
     * Find the add-ons. Must run before anything reads the list. Nothing here may be the
     * reason the app will not start, so everything is guarded.
     */
    @Synchronized
    fun discover(context: Context) {
        if (providerList != null) {
            Log.e(TAG, "the backend list was read before discovery", IllegalStateException("too late"))
            return
        }
        try {
            find(context)
        } catch (t: Throwable) {
            Log.e(TAG, "discovering add-ons", t)
        }
    }

    private fun find(context: Context) {
        val pm = context.packageManager
        val ours = try {
            pm.getPackageInfo(context.packageName, 0).longVersionCode
        } catch (e: PackageManager.NameNotFoundException) {
            throw IllegalStateException(e) // we are installed
        }

        // This build's own, before any add-on's, because an id is what a saved connection
        // names and two things cannot answer to one.
        val own = builtIn()
        builtInList = own
        val taken = LinkedHashSet<String>()
        for (p in own) {
            taken.add(p.id())
        }

        val found = ArrayList<Plugin>()
        val loaded = ArrayList<BackendProvider>()
        for (pkg in signedLikeUs(pm, context.packageName)) {
            val info = try {
                pm.getPackageInfo(pkg, 0)
            } catch (e: PackageManager.NameNotFoundException) {
                continue // uninstalled between the two calls
            }
            if (info.longVersionCode != ours) {
                found.add(Plugin(pkg, PluginState.INCOMPATIBLE, "Built for app version ${info.longVersionCode}."))
                continue
            }
            // Everything from here is somebody else's code being asked to construct itself.
            try {
                val mine = load(info.applicationInfo!!, taken)
                if (mine.isEmpty()) {
                    found.add(Plugin(pkg, PluginState.INCOMPATIBLE, "It has no backend in it."))
                    continue
                }
                for (p in mine) {
                    taken.add(p.id())
                }
                loaded.addAll(mine)
                found.add(Plugin(pkg, PluginState.LOADED, null))
                Log.i(TAG, "loaded ${mine.size} backend(s) from $pkg")
            } catch (t: Throwable) {
                Log.e(TAG, "loading $pkg", t)
                // Its own words where it has any: a class name on a card helps nobody.
                val said = t.message
                found.add(Plugin(pkg, PluginState.FAILED, if (said.isNullOrEmpty()) t.toString() else said))
            }
        }
        pluginList = found.toList()
        discovered = loaded.toList()
    }

    private fun builtIn(): List<BackendProvider> {
        // The classloader is named rather than defaulted: the thread context one is the
        // app's here, but it is not ours to assume.
        val own = ArrayList<BackendProvider>()
        for (p in ServiceLoader.load(BackendProvider::class.java, Backends::class.java.classLoader)) {
            own.add(p)
        }
        return own.toList()
    }

    /**
     * Packages that declare [PLUGIN_ACTION] and are signed with our key. The `<queries>`
     * declaration this needs is the app's.
     */
    @SuppressLint("QueryPermissionsNeeded")
    private fun signedLikeUs(pm: PackageManager, self: String): Set<String> {
        val candidates = LinkedHashSet<String>()
        for (r in pm.queryIntentServices(Intent(PLUGIN_ACTION), 0)) {
            candidates.add(r.serviceInfo.packageName)
        }
        candidates.remove(self)
        val ours = LinkedHashSet<String>()
        for (pkg in candidates) {
            if (pm.checkSignatures(self, pkg) == PackageManager.SIGNATURE_MATCH) {
                ours.add(pkg)
            }
        }
        return ours
    }

    private fun load(info: ApplicationInfo, taken: Set<String>): List<BackendProvider> {
        // Without the chain an add-on's classes are reachable from Kotlin and from nothing
        // else. Half of that is worse than none of it.
        val chain = chain ?: throw IllegalStateException("This build of the app cannot load plugins.")
        val dex = StringBuilder(info.sourceDir)
        info.splitSourceDirs?.let { splits ->
            for (split in splits) {
                dex.append(File.pathSeparatorChar).append(split)
            }
        }
        val loader = Plugins(info.packageName, dex.toString(), info.nativeLibraryDir, Backends::class.java.classLoader)
        val mine = ArrayList<BackendProvider>()
        for (p in ServiceLoader.load(BackendProvider::class.java, loader)) {
            // Its own loader sees ours, so it finds the built-in services too.
            if (p.javaClass.classLoader !== loader) {
                continue
            }
            // Against this build's own ids as well as the other add-ons': otherwise an
            // add-on could claim `rfb` at a lower order and replace that client for every
            // connection on the phone.
            if (p.id() in taken) {
                throw IllegalStateException("Another backend is already called ${p.id()}.")
            }
            for (seen in mine) {
                if (seen.id() == p.id()) { // and against itself
                    throw IllegalStateException("Another backend is already called ${p.id()}.")
                }
            }
            mine.add(p)
        }
        if (mine.isNotEmpty()) {
            chain.add(loader)
        }
        return mine
    }

    /** Which add-on a class loader belongs to, or null for the app's own. */
    fun packageOf(loader: ClassLoader?): String? = (loader as? Plugins)?.packageName

    /** Which add-on backend [id] came from, or null for a built-in one. */
    fun packageOf(id: String): String? {
        val p = provider(id)
        return if (p == null) null else packageOf(p.javaClass.classLoader)
    }

    /** What discovery found, with anything that has since failed in use marked failed. */
    @Synchronized
    fun plugins(): List<Plugin> {
        if (failedAtUse.isEmpty()) {
            return pluginList
        }
        return pluginList.map { p ->
            val said = failedAtUse[p.packageName]
            if (said == null) p else Plugin(p.packageName, PluginState.FAILED, said)
        }
    }

    /** Record that backend [id] threw, so its add-on shows as failed. */
    fun failed(id: String, t: Throwable) {
        Log.e(TAG, "backend $id", t)
        val pkg = packageOf(id)
        if (pkg != null) {
            val said = t.message
            failedAtUse[pkg] = if (said.isNullOrEmpty()) t.toString() else said
        }
    }

    /** Packages signed like us that declare themselves as backends, whether or not they loaded. */
    fun installedPlugins(context: Context): Set<String> =
        signedLikeUs(context.packageManager, context.packageName)

    @Synchronized
    private fun providers(): List<BackendProvider> {
        var found = providerList
        if (found == null) {
            // Whatever `discover` weighed the add-ons against, so that the id it refused a
            // clash on is the id in this list.
            val loaded = ArrayList(builtInList ?: builtIn())
            loaded.addAll(discovered)
            loaded.sortWith(compareBy<BackendProvider> { it.order() }.thenBy { it.id() })
            found = loaded.toList()
            providerList = found
        }
        return found
    }

    private fun provider(id: String): BackendProvider? = providers().firstOrNull { it.id() == id }

    fun ids(): List<String> = providers().map { it.id() }

    fun name(id: String): String = provider(id)?.name() ?: id

    fun shortName(id: String): String = provider(id)?.shortName() ?: ""

    fun description(id: String): String = provider(id)?.description() ?: ""

    fun options(id: String): List<BackendOption> = provider(id)?.options() ?: emptyList()

    fun addressLabel(id: String, options: Map<String, String>): String? =
        provider(id)?.addressLabel(options)

    /**
     * Whether backend [id] can be connected with yet, asked off the main thread and answered
     * on it. Simultaneous askers for one id share one question. A screen that has gone by the
     * time the answer comes is not told.
     */
    fun isSetup(context: Context, id: String, answer: (Boolean) -> Unit) {
        val to = whileThereIsAScreen(context, answer)
        val p = provider(id)
        if (p == null || id in setUp) {
            to(true)
            return
        }
        // The application context, because this outlives the screen that asked.
        val app = context.applicationContext
        val exec: ExecutorService
        synchronized(asking) {
            val waiting = asking[id]
            if (waiting != null) {
                waiting.add(to)
                return
            }
            asking[id] = mutableListOf(to)
            exec = worker ?: Executors.newSingleThreadExecutor { r ->
                Thread(r, "backend-setup").also { it.isDaemon = true }
            }.also { worker = it }
        }
        exec.execute {
            var ok: Boolean
            try {
                ok = p.isSetup(app)
            } catch (t: Throwable) {
                failed(id, t)
                ok = false
            }
            if (ok) {
                setUp.add(id)
            }
            val waiting: List<(Boolean) -> Unit>
            synchronized(asking) {
                waiting = asking.remove(id) ?: emptyList()
            }
            val said = ok
            main.post {
                // One at a time, guarded: these are unrelated screens, and one of them
                // throwing must not be the others never hearing.
                for (c in waiting) {
                    try {
                        c(said)
                    } catch (t: Throwable) {
                        Log.e(TAG, "answering isSetup for $id", t)
                    }
                }
            }
        }
    }

    private fun whileThereIsAScreen(context: Context, answer: (Boolean) -> Unit): (Boolean) -> Unit {
        if (context !is Activity) {
            return answer
        }
        return { ok ->
            if (!context.isDestroyed && !context.isFinishing) {
                answer(ok)
            }
        }
    }

    /** Start whatever backend [id] is waiting for. */
    fun setup(host: Activity, id: String) {
        provider(id)?.setup(host)
    }

    /** Something a backend's [BackendProvider.isSetup] depends on changed: ask again. */
    fun setupChanged() {
        setUp.clear()
    }

    /** Forget every server identity, ours and each backend's own. */
    fun forgetHosts(context: Context) {
        val app = context.applicationContext
        KnownHosts.clear(app)
        for (p in providers()) {
            try {
                p.forgetHosts(app)
            } catch (t: Throwable) {
                failed(p.id(), t)
            }
        }
    }

    fun create(
        context: Context, id: String, address: String, userName: String?,
        password: String?, options: Map<String, String>,
    ): Backend {
        val p = provider(id) ?: throw IllegalArgumentException(
            "no such backend in this build: $id (it has ${ids()})",
        )
        return p.create(context, address, userName, password, options)
    }
}
