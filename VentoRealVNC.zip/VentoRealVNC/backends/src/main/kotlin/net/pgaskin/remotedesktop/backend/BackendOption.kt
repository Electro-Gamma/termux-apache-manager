// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later
package net.pgaskin.remotedesktop.backend

/**
 * One setting a backend understands, described well enough for the app to *offer* it
 * without knowing what it means.
 *
 * The values are strings, because that is what the backends' own configuration layers
 * take. [Type] says how to ask for one, not how to store it.
 *
 * @param key the backend's own name for it; the map key
 * @param label one line, for a preference title
 * @param summary the longer explanation, or null
 * @param type which control to offer
 * @param choices for [Type.CHOICE], in display order; empty otherwise
 * @param defaultValue what the backend does when nothing is set
 * @param scope whose setting it is: the connection's or the backend's
 * @param live whether [Backend.setOption] does anything mid-session
 * @param gate what another option must say for this one to be offered at all, or null
 */
data class BackendOption(
    val key: String,
    val label: String,
    val summary: String?,
    val type: Type,
    val choices: List<Choice>,
    val defaultValue: String?,
    val scope: Scope,
    val live: Boolean,
    val gate: Gate?,
) {
    enum class Type {
        /** `"true"` / `"false"`. */
        BOOL,
        /** One of [choices]. */
        CHOICE,
        /** A decimal integer. */
        INT,
        /** Free text. */
        TEXT,
    }

    enum class Scope {
        /** Belongs to one connection: offered in the editor, stored on the connection record. */
        CONNECTION,

        /**
         * Belongs to the backend: offered in its settings screen, stored in its own
         * preference file, and applied to every connection that uses it.
         */
        GLOBAL,

        /**
         * The connection's, with the backend's answer as its default: offered in both
         * screens, read from the connection where it has one and from the backend
         * where it has not. An editor stores an override only where the answer differs
         * from what the connection would do anyway.
         */
        LAYERED,
    }

    /**
     * A value and what to call it on screen.
     *
     * @param summary why you would pick this one over the others, or null. Where one is
     *                given, the choice is offered as a list of described items rather
     *                than a menu of labels. Only the connection editor draws these.
     * @param requires the key of a `BOOL` option this choice depends on, or null. A
     *                 choice whose dependency is off is not offered at all.
     */
    data class Choice(
        val value: String,
        val label: String,
        val summary: String? = null,
        val requires: String? = null,
    )

    /**
     * The same option, offered only where another one says one of [values]. For a
     * setting a backend *has* and does not always consult, such as a mode dial that owns
     * several settings until it is set to the value that hands them back.
     */
    fun `when`(key: String, vararg values: String): BackendOption =
        copy(gate = Gate(key, values.toList()))

    /**
     * @param key another option's key
     * @param values the values of it that make this option worth offering
     */
    data class Gate(val key: String, val values: List<String>) {
        fun open(value: String?): Boolean = value != null && values.contains(value)
    }

    /** For a [Type.CHOICE]: what to show for [value], or the value itself. */
    fun labelFor(value: String?): String? {
        for (c in choices) {
            if (c.value == value) {
                return c.label
            }
        }
        return value
    }

    companion object {
        @JvmStatic
        fun bool(
            key: String, label: String, summary: String?,
            defaultValue: Boolean, scope: Scope, live: Boolean,
        ): BackendOption = BackendOption(
            key, label, summary, Type.BOOL, emptyList(),
            defaultValue.toString(), scope, live, null,
        )

        @JvmStatic
        fun integer(
            key: String, label: String, summary: String?,
            defaultValue: Int, scope: Scope, live: Boolean,
        ): BackendOption = BackendOption(
            key, label, summary, Type.INT, emptyList(),
            defaultValue.toString(), scope, live, null,
        )

        @JvmStatic
        fun text(
            key: String, label: String, summary: String?,
            defaultValue: String?, scope: Scope, live: Boolean,
        ): BackendOption = BackendOption(
            key, label, summary, Type.TEXT, emptyList(),
            defaultValue, scope, live, null,
        )

        @JvmStatic
        fun choice(
            key: String, label: String, summary: String?,
            defaultValue: String?, scope: Scope, live: Boolean,
            vararg choices: Choice,
        ): BackendOption = BackendOption(
            key, label, summary, Type.CHOICE, choices.toList(),
            defaultValue, scope, live, null,
        )
    }
}
