// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: GPL-3.0-or-later
package net.pgaskin.remotedesktop.backend

import android.app.Activity
import android.content.Context

/**
 * A protocol module's statement that it is in this build.
 *
 * One per protocol, declared as a `java.util.ServiceLoader` service in the module that
 * implements it, so what a build can connect with is exactly what is on its classpath.
 * Nothing above this interface names a protocol.
 */
interface BackendProvider {

    /** Stored in a connection record, so it must not change once shipped. */
    fun id(): String

    /** For a picker and a title. */
    fun name(): String

    /** A word or two, for a badge with no room for more. */
    fun shortName(): String

    /** Why somebody would choose this one, in a sentence or two, under [name] in a picker. */
    fun description(): String

    /** Where in a picker, lowest first; a build must not reshuffle its own list. */
    fun order(): Int

    /** What this backend can be told, for the editor and its settings screen. */
    fun options(): List<BackendOption>

    /**
     * A session for one connection, not yet started.
     *
     * The address is what somebody typed: `host`, `host:port`, `[literal]` or
     * `[literal]:port`, where a host is a name or an IPv4 literal and an **IPv6 literal
     * is always bracketed**. A bare literal is an error with a sentence in it rather
     * than a guess. A backend whose [addressLabel] says this field is not a host is
     * outside all of that, and says so where it parses.
     */
    fun create(
        context: Context, address: String, userName: String?, password: String?,
        options: Map<String, String>,
    ): Backend

    /**
     * What the editor's address field is called for this backend, or null for the app's
     * own wording. It takes the connection's options because for one protocol the answer
     * moves with them.
     */
    fun addressLabel(options: Map<String, String>): String? = null

    /**
     * Whether this backend can be connected with yet. False only for one that needs
     * something the build cannot contain — a library it has to be given on the device.
     */
    fun isSetup(context: Context): Boolean = true

    /**
     * Ask for whatever [isSetup] is waiting for, and return. There is no callback: the
     * only answer that survives is the caller asking [isSetup] again when it resumes.
     */
    fun setup(host: Activity) {
    }

    /**
     * Forget every server identity this backend has accepted. For a backend whose library
     * pins the far end *itself*, which nothing above this interface can find.
     */
    fun forgetHosts(context: Context) {
    }
}
