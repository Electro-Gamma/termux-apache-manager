// SPDX-License-Identifier: CC0-1.0

package com.realvnc.vncviewer.jni

/**
 * "Persist these credentials." A notification rather than a question — the only
 * way a client that keeps its own connection records learns what was typed into
 * a prompt the core owned. Required by `…_setCredentialsStore` and
 * `SaveCredentialsBindings$CredentialsStore`.
 */
object SaveCredentialsBindings {

    interface CredentialsStore {
        fun saveCredentials(session: SessionBindings.Session?, userName: String?, password: String?)
    }

    @JvmStatic
    external fun setCredentialsStore(store: CredentialsStore)
}
