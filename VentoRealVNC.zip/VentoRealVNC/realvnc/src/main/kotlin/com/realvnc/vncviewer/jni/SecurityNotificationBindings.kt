// SPDX-License-Identifier: CC0-1.0

package com.realvnc.vncviewer.jni

/**
 * The encrypted / unencrypted banner: a line of text and the name of a background
 * to draw it on. Required by `…_setSecurityNotifier` and
 * `SecurityNotificationBindings$SecurityNotifier`.
 */
object SecurityNotificationBindings {

    /** The line is encrypted. */
    const val BACKGROUND_SECURE = "StripesTileGreen"

    /** It is not. */
    const val BACKGROUND_INSECURE = "StripesTileRed"

    fun interface SecurityNotifier {
        fun show(session: SessionBindings.Session?, text: String?, background: String?, flags: Int)
    }

    @JvmStatic
    external fun setSecurityNotifier(notifier: SecurityNotifier)
}
