// SPDX-License-Identifier: CC0-1.0

package com.realvnc.vncviewer.jni

import android.os.Build

/**
 * Which build of `libvncviewer.so` the declarations in this package were read
 * from, and how to know a copy is that build.
 *
 * The library is not in this repository and is in no artefact it produces.
 * Whoever loads it verifies it against this.
 */
object Library {

    /** The viewer release these declarations were read from. */
    const val VERSION = "4.9.3.60175"

    /** In load order: `libc++_shared.so` first, so `libvncviewer.so`'s DT_NEEDED is satisfied. */
    private val NAMES = listOf("libc++_shared.so", "libvncviewer.so")

    /** SHA-256 by `<abi>/<name>`, which is also the path each lives at inside the viewer's APK. */
    private val SHA256 = mapOf(
        "arm64-v8a/libvncviewer.so" to
            "fdd67f78312bfbe4fb7861eaa42cfe5d6091668c057157d66e94aa33e41fe8ba",
        "arm64-v8a/libc++_shared.so" to
            "4397241b4bd20a8e579bfb41d21107857e12985f6a01ca0c2a5f83380d1270b4",
        "x86_64/libvncviewer.so" to
            "ee3acfbe81cdd8f9dbd9542e2a0c9bd31634d78334c5e22c27414a8b73ac364a",
        "x86_64/libc++_shared.so" to
            "db9609240e60ca18b816a5e95a6bbc784e799261efbd5b30c8e2e03b540b3fa8",
    )

    /** The libraries to load, in the order they must be loaded. */
    @JvmStatic
    fun names(): List<String> = NAMES

    /** The ABIs pinned here, which is what a device must be one of. */
    @JvmStatic
    fun abis(): Set<String> = setOf("arm64-v8a", "x86_64")

    /** Null for an ABI or a name this pin says nothing about. */
    @JvmStatic
    fun sha256(abi: String, name: String): String? = SHA256["$abi/$name"]

    /** This device's ABI, of the ones pinned here, or null. SUPPORTED_ABIS is in preference order. */
    @JvmStatic
    fun abi(): String? = Build.SUPPORTED_ABIS.firstOrNull { it in abis() }

    /**
     * What this device needs: each library's name to its SHA-256, in load order.
     *
     * **Empty means this device can never have them**, which is a different answer
     * from "has not got them yet".
     */
    @JvmStatic
    fun wanted(): Map<String, String?> {
        val abi = abi() ?: return emptyMap()
        val wanted = LinkedHashMap<String, String?>()
        for (name in NAMES) {
            wanted[name] = sha256(abi, name)
        }
        return wanted
    }
}
