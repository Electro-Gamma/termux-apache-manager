// SPDX-License-Identifier: CC0-1.0

package com.realvnc.vncviewer.jni

/**
 * A message with Win32-style flags, which is how the core reports most of what
 * goes wrong short of losing the session. The prompt protocol is
 * [PasswdDlgBindings]'s, except the question arrives at the factory.
 *
 * Required by `…_setMsgBoxFactory`, `…_msgBoxResult`, `$MsgBox`, `$MsgBoxFactory`.
 */
object MsgBoxBindings {

    /** Buttons. `MB_CUSTOM` means the button text came with the message. */
    const val MB_OK = 0
    const val MB_OKCANCEL = 1
    const val MB_YESNO = 4
    const val MB_CUSTOM = 8

    /**
     * The icon is a small enumeration in bits 4–6, not independent flags:
     * `MB_ICONWARNING` is `MB_ICONERROR | MB_ICONQUESTION`, so read it with
     * [MB_ICON_MASK] and compare.
     */
    const val MB_ICONERROR = 16
    const val MB_ICONQUESTION = 32
    const val MB_ICONWARNING = 48
    const val MB_ICONINFORMATION = 64
    const val MB_ICON_MASK = 0x70

    /** Which button is focused. Not a distinction a phone makes. */
    const val MB_DEFBUTTON1 = 0
    const val MB_DEFBUTTON2 = 256

    fun interface MsgBox {
        fun close()
    }

    fun interface MsgBoxFactory {
        fun createMsgBox(
            session: SessionBindings.Session?, cookie: Long, message: String?,
            flags: Int, customButton: String?,
        ): MsgBox
    }

    @JvmStatic
    external fun msgBoxResult(cookie: Long, ok: Boolean)

    @JvmStatic
    external fun setMsgBoxFactory(factory: MsgBoxFactory)
}
