// SPDX-License-Identifier: CC0-1.0

package com.realvnc.vncviewer.jni

import java.io.Closeable

/**
 * A small dynamic-form protocol, used for multi-factor and other interactive
 * authentication: the core hands over a list of elements to put on screen, and
 * takes back a map of answers. Prompt protocol: [PasswdDlgBindings].
 *
 * The core constructs the five `Ui…` classes directly, so each one's name and
 * constructor signature is the ABI. They are data classes whose constructor
 * parameters are the old record components, in the same order.
 */
object InteractiveTextDlgBindings {

    /** One field of the form; a sealed set so a caller's `when` is checked for completeness. */
    sealed interface UiElement {
        val id: String?
    }

    /** A text field. `echo` false means a password. */
    data class UiEdit(
        override val id: String?, val label: String?, val echo: Boolean,
        val placeholder: String?, val initialText: String?,
    ) : UiElement

    /** A drop-down. `editable` allows a value that is not in the list. */
    data class UiChoice(
        override val id: String?, val label: String?, val choices: List<String>?,
        val editable: Boolean, val initialChoice: Int,
    ) : UiElement

    /** A list to pick one row from. */
    data class UiList(
        override val id: String?, val header: String?, val choices: List<String>?,
        val initialChoice: Int,
    ) : UiElement

    /** A check box. */
    data class UiCheck(
        override val id: String?, val label: String?, val initiallyChecked: Boolean,
    ) : UiElement

    /** Text with nothing to fill in. */
    data class UiMessage(override val id: String?, val message: String?) : UiElement

    interface InteractiveTextDlg {
        fun close()

        /**
         * @param elements the form, in order; each is one of the [UiElement] classes
         * @param userNameFixed the user name is already decided, so a field for it
         *                      should be shown but not edited
         */
        fun promptInteractive(elements: List<UiElement>?, userNameFixed: Boolean)
    }

    interface InteractiveTextDlgFactory {
        fun createInteractiveTextDlg(session: SessionBindings.Session?, cookie: Long): InteractiveTextDlg
    }

    /**
     * The answers, as a native-side copy of `id → answer` that outlives the map it
     * was built from. [close] frees it.
     */
    class UiResponses(responses: Map<String, String>) : Closeable {

        private var token: Long = nativeInit(responses)

        private external fun nativeInit(responses: Map<String, String>): Long

        private external fun nativeClose(token: Long)

        override fun close() {
            val t = token
            token = 0
            if (t != 0L) {
                nativeClose(t)
            }
        }
    }

    /** `responses` may be null, and must be when `ok` is false. */
    @JvmStatic
    external fun promptResult(cookie: Long, ok: Boolean, responses: UiResponses?)

    @JvmStatic
    external fun setInteractiveTextDlgFactory(factory: InteractiveTextDlgFactory)
}
