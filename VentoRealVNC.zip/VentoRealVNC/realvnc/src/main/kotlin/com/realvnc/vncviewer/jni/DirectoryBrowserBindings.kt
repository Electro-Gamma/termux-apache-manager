// SPDX-License-Identifier: CC0-1.0

package com.realvnc.vncviewer.jni

/**
 * Browsing a team's directory of machines — a cloud account feature, not
 * supported here. `directoryChanged` is `(Ljava/util/List;[Ljava/lang/String;)V`;
 * the list holds connection records this module does not bind, hence `List<*>`.
 */
internal object DirectoryBrowserBindings {

    interface Callback {
        fun directoryChanged(entries: List<*>?, labels: Array<String>?)

        fun directoryEntryGone(id: String?)

        fun directorySearchCoveredChanged(covered: Boolean)
    }
}
