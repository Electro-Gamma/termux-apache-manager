// SPDX-License-Identifier: CC0-1.0

package com.realvnc.vncviewer.jni

/**
 * The core's global parameter registry. Required by
 * `Java_com_realvnc_vncviewer_jni_ConfigurationBindings_set`.
 */
object ConfigurationBindings {

    /**
     * @param level a priority; the viewer applies its own expert options at 10
     * @param persist whether to write the value to the config layer's data
     *                directory as well as apply it
     */
    @JvmStatic
    external fun set(name: String, value: String, level: Int, persist: Boolean)
}
