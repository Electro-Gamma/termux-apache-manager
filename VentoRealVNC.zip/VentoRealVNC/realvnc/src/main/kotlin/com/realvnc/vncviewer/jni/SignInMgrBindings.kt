// SPDX-License-Identifier: CC0-1.0

package com.realvnc.vncviewer.jni

/**
 * RealVNC account sign-in, which this client does not support. It exists because
 * [Bindings.initViewer] has to pass a [SignInUi]: the core resolves
 * `SignInMgrBindings$SignInUi` by name and caches a method id for each method.
 *
 * [Factor] and [SecondFactorRequest] are constructed *by* the core, so their
 * constructor signatures are fixed:
 * `(JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;JJ)V` and
 * `(Ljava/lang/String;JLjava/util/List;)V`.
 */
internal object SignInMgrBindings {

    /** A second authentication factor offered to the person signing in. */
    data class Factor(
        val type: Long,
        val id: String?,
        val totpName: String?,
        val emailAddress: String?,
        val backupGeneratedAt: Long,
        val backupDigits: Long,
    )

    /** The set of them, and the token that a chosen one is answered with. */
    data class SecondFactorRequest(
        val preAuthenticatedToken: String?,
        val expiry: Long,
        val factors: List<Factor>?,
    )

    interface SignInUi {
        fun openSsoUrl(url: String?)

        fun signInChanged(state: Int)

        fun signInFailed(message: String?, canRetry: Boolean, fatal: Boolean)

        fun signInNetworkStatusChanged()

        fun signInSecondFactorsRequired(request: SecondFactorRequest?)

        fun signInSignedIn()

        fun signInSignedOut(forced: Boolean)

        fun signInSsoRefreshSignedOut(): Boolean

        fun signInStarted()

        fun signInTermsChanged()

        fun signInTimedOut()
    }
}
