// SPDX-License-Identifier: CC0-1.0

package com.realvnc.vncviewer.jni

/**
 * "Remember this server's identity." What arrives here is what a later connection
 * passes back as the `Identity` option. Required by `…_setIdentityStore` and
 * `SaveIdentityBindings$IdentityStore`.
 */
object SaveIdentityBindings {

    fun interface IdentityStore {
        fun saveIdentity(session: SessionBindings.Session?, identity: String?)
    }

    @JvmStatic
    external fun setIdentityStore(store: IdentityStore)
}
