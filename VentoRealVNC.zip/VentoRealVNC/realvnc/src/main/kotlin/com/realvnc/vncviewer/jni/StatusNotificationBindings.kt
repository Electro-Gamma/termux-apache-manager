// SPDX-License-Identifier: CC0-1.0

package com.realvnc.vncviewer.jni

/**
 * The session's status line — "Connecting…", "Authenticating…" — localised by
 * the core. Required by `…_StatusNotificationBindings_setStatusNotifier` and
 * `StatusNotificationBindings$StatusNotifier`.
 */
object StatusNotificationBindings {

    fun interface StatusNotifier {
        fun update(session: SessionBindings.Session?, text: String?)
    }

    @JvmStatic
    external fun setStatusNotifier(notifier: StatusNotifier)
}
