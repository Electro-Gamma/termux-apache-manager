// SPDX-License-Identifier: CC0-1.0

package com.realvnc.vncviewer.jni

/**
 * Team labels — a cloud account feature, not supported here. The fourth of
 * [Bindings.initViewer]'s callbacks, resolved by the core as
 * `com/realvnc/vncviewer/jni/LabelBindings$Callback`.
 */
internal object LabelBindings {

    interface Callback {
        fun labelsChanged()
    }
}
