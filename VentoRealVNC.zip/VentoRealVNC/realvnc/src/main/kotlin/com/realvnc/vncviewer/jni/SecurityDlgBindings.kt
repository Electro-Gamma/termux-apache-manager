// SPDX-License-Identifier: CC0-1.0

package com.realvnc.vncviewer.jni

/**
 * "Is this server who it says it is, and is the connection encrypted?" The other
 * mandatory prompt: it fires on every unencrypted connection and on every server
 * identity that is not already known and matching. Prompt protocol: [PasswdDlgBindings].
 */
object SecurityDlgBindings {

    /** What is known about the server's identity. The first argument of the prompt. */
    const val ID_OK = 0
    const val ID_NEW = 1
    const val ID_MATCHES_ANOTHER_SERVER = 2
    const val ID_CHANGED = 3
    const val ID_MISSING = 4
    const val ID_PRESHARED = 5
    const val ID_ARD = 6

    /** What is known about the line. The second argument. */
    const val ENC_ENCRYPTED = 0
    const val ENC_UNENCRYPTED_WARN = 1
    const val ENC_UNENCRYPTED_NO_WARN = 2

    interface SecurityDlg {
        fun close()

        /**
         * The identity comes **first** and the encryption second — the opposite of
         * what a decompiled signature suggests (the viewer tests the first against
         * 5 = [ID_PRESHARED] and derives its encryption warning from the second
         * being 1 = [ENC_UNENCRYPTED_WARN]).
         *
         * @param identityState one of the `ID_*` constants
         * @param encryptionState one of the `ENC_*` constants
         * @param matchingName the server this identity is already known as, for [ID_MATCHES_ANOTHER_SERVER]
         */
        fun promptSecurity(
            identityState: Int, encryptionState: Int, signature: String?,
            catchphrase: String?, name: String?, matchingName: String?,
            hint: String?,
        )
    }

    interface SecurityDlgFactory {
        fun createSecurityDlg(session: SessionBindings.Session?, cookie: Long): SecurityDlg
    }

    /**
     * @param accept proceed with the connection
     * @param saveIdentity remember this server's identity (turns a later [ID_NEW] into [ID_OK])
     * @param saveEncryption remember the encryption decision
     */
    @JvmStatic
    external fun securityResult(cookie: Long, accept: Boolean, saveIdentity: Boolean, saveEncryption: Boolean)

    @JvmStatic
    external fun setSecurityDlgFactory(factory: SecurityDlgFactory)
}
