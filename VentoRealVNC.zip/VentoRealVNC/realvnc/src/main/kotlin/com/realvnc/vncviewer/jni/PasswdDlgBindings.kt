// SPDX-License-Identifier: CC0-1.0

package com.realvnc.vncviewer.jni

/**
 * The credentials prompt, and the pattern every other prompt in this package follows.
 *
 * ## The prompt protocol
 *
 * A factory is registered once, process-wide. When the core needs an answer it
 * asks the factory for an object, calls the question method on it, and *waits* —
 * arbitrarily long, on the session thread — until a static result native is
 * called with the same `cookie`. Then it calls `close()` and drops the object.
 *
 * The cookie is the whole identity of a question, so an answer may be given from
 * any thread; and a prompt can arrive *during* [SessionBindings.createSession],
 * before that call has returned a `Session`.
 *
 * This one is mandatory: with no factory registered, a session against a server
 * that wants a password never progresses.
 */
object PasswdDlgBindings {

    interface PasswdDlg {
        fun close()

        /**
         * Argument order, read off the viewer's own dialog: an unused first
         * string, the server name, the user name, a "wants a password" flag, the
         * catchphrase, the signature, and the instructions.
         *
         * The user name is **null when the scheme has none** (VncAuth takes a
         * password only), which is how a dialog knows not to offer the field.
         */
        fun getUserPasswd(
            unused: String?, serverName: String?, userName: String?,
            wantsPassword: Boolean, catchphrase: String?, signature: String?,
            instructions: String?,
        )
    }

    interface PasswdDlgFactory {
        fun createPasswdDlg(session: SessionBindings.Session?, cookie: Long, address: String?): PasswdDlg
    }

    @JvmStatic
    external fun passwdResult(cookie: Long, ok: Boolean, userName: String?, password: String?)

    @JvmStatic
    external fun setPasswdDlgFactory(factory: PasswdDlgFactory)
}
