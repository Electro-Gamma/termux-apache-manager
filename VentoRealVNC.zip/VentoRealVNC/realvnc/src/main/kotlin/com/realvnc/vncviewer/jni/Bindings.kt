// SPDX-License-Identifier: CC0-1.0

package com.realvnc.vncviewer.jni

import android.content.Context

/**
 * Process-wide bootstrap: bring the core up, then bring the viewer layer up.
 * Both are once-only, both must have returned before any session exists.
 *
 * Required by `Java_com_realvnc_vncviewer_jni_Bindings_initApp` and `…_initVwr`.
 *
 * JNI note: every native here is `@JvmStatic external` inside an `object`, which
 * compiles to a plain `static native` method on `Bindings` — the shape the
 * exported symbols bind to.
 */
object Bindings {

    /** Where the core writes its log. The values travel to the native side as an ordinal. */
    enum class LogMode {
        LOG_FILE,
        LOG_DEBUG,
        LOG_DEBUG_APPONLY
    }

    /**
     * Guarded by a once-flag natively, so a second call is a no-op.
     *
     * @param appName parameter namespace, and the name of the data directory created under [dataRoot]
     * @param dataRoot `dataRoot + "/" + appName` becomes the config layer's data directory
     * @param logName log file base name; `logName + ".log"`
     * @param context retained natively for platform services
     * @param parameters global parameters, applied at init
     */
    @JvmStatic
    external fun initApp(
        appName: String, version: String, dataRoot: String,
        logDir: String, logName: String, context: Context,
        parameters: Map<String, String>, fileLogging: Boolean,
        logMode: LogMode,
    )

    /**
     * The second half of the bootstrap. The four callbacks are all about RealVNC
     * accounts, which this client does not support, so [NoCloud] answers every
     * one of them with nothing and the caller never sees a cloud API.
     */
    @JvmStatic
    fun initViewer() {
        val stub = NoCloud()
        initVwr(stub, stub, stub, stub)
    }

    @JvmStatic
    private external fun initVwr(
        signInUi: SignInMgrBindings.SignInUi,
        syncCallback: SyncMgrBindings.Callback,
        dirCallback: DirectoryBrowserBindings.Callback,
        labelCallback: LabelBindings.Callback,
    )

    /**
     * One object for all four. Every method is declared on the class rather than
     * left to an interface default: the core reaches these through `GetMethodID`
     * on this object's own class.
     */
    private class NoCloud : SignInMgrBindings.SignInUi, SyncMgrBindings.Callback,
        DirectoryBrowserBindings.Callback, LabelBindings.Callback {

        override fun openSsoUrl(url: String?) {}
        override fun signInChanged(state: Int) {}
        override fun signInFailed(message: String?, canRetry: Boolean, fatal: Boolean) {}
        override fun signInNetworkStatusChanged() {}
        override fun signInSecondFactorsRequired(request: SignInMgrBindings.SecondFactorRequest?) {}
        override fun signInSignedIn() {}
        override fun signInSignedOut(forced: Boolean) {}
        override fun signInSsoRefreshSignedOut(): Boolean = false
        override fun signInStarted() {}
        override fun signInTermsChanged() {}
        override fun signInTimedOut() {}
        override fun serverEntriesChanged() {}
        override fun directoryChanged(entries: List<*>?, labels: Array<String>?) {}
        override fun directoryEntryGone(id: String?) {}
        override fun directorySearchCoveredChanged(covered: Boolean) {}
        override fun labelsChanged() {}
    }
}
