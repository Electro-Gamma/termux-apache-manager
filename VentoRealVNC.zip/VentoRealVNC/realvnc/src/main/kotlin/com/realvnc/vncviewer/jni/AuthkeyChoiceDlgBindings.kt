// SPDX-License-Identifier: CC0-1.0

package com.realvnc.vncviewer.jni

/**
 * "Which of your identities should authenticate this connection?" — asked when a
 * server authenticates viewers by client certificate and more than one is
 * available. The list comes from [AuthkeyStoreAndroid]. Prompt protocol: [PasswdDlgBindings].
 */
object AuthkeyChoiceDlgBindings {

    interface AuthkeyChoiceDlg {
        fun close()

        fun show(identities: Array<String>?)
    }

    interface AuthkeyChoiceDlgFactory {
        fun createAuthkeyChoiceDlg(session: SessionBindings.Session?, cookie: Long): AuthkeyChoiceDlg
    }

    @JvmStatic
    external fun identityChosen(cookie: Long, ok: Boolean, identity: String?)

    @JvmStatic
    external fun setAuthkeyChoiceDlgFactory(factory: AuthkeyChoiceDlgFactory)
}
