// SPDX-License-Identifier: CC0-1.0

package com.realvnc.vncviewer.jni

/**
 * Sync of connection records to a RealVNC account, which this client does not
 * support. Only the callback is here, resolved by the core as
 * `com/realvnc/vncviewer/jni/SyncMgrBindings$Callback`.
 */
internal object SyncMgrBindings {

    interface Callback {
        fun serverEntriesChanged()
    }
}
