// SPDX-License-Identifier: CC0-1.0

package com.realvnc.vncviewer.jni

/**
 * What a live session can be asked about itself. Every one of these is a display
 * string the core formats, not a value, and answers an empty string when there
 * is nothing to say.
 *
 * Required by eight exported `Java_com_realvnc_vncviewer_jni_ConnectionInfoBindings_*` symbols.
 */
object ConnectionInfoBindings {

    @JvmStatic
    external fun getConnectionType(session: SessionBindings.Session): String

    @JvmStatic
    external fun getDesktopName(session: SessionBindings.Session): String

    @JvmStatic
    external fun getLastUsedEncoding(session: SessionBindings.Session): String

    @JvmStatic
    external fun getLineSpeed(session: SessionBindings.Session): String

    /** A protocol version below 4.0 means the server is not a RealVNC one. */
    @JvmStatic
    external fun getProtoVersion(session: SessionBindings.Session): String

    @JvmStatic
    external fun getSecurityDesc(session: SessionBindings.Session): String

    @JvmStatic
    external fun getServerPixelFormat(session: SessionBindings.Session): String

    @JvmStatic
    external fun getViewerPixelFormat(session: SessionBindings.Session): String
}
