// SPDX-License-Identifier: CC0-1.0

package com.realvnc.vncviewer.jni

import android.annotation.SuppressLint
import android.content.Context
import android.security.KeyChain
import java.security.Signature

/**
 * The one class here the core calls *into* without being asked first: signing a
 * challenge with a client certificate from the Android key chain.
 *
 * Required by three static names the core resolves on this class — `getAliases`
 * `()[Ljava/lang/Object;`, `getPubKey` `(Ljava/lang/String;)[B` and
 * `signDataWithIdentity` `(Ljava/lang/String;Ljava/lang/String;[B)[B`. They are
 * `public @JvmStatic` rather than `internal`, because Kotlin mangles the JVM
 * name of an `internal` function and the core looks them up by exact name.
 *
 * With no aliases configured (the default) [getAliases] answers empty and the
 * core falls back to another authentication method.
 */
object AuthkeyStoreAndroid {

    // An application context, which configure() takes care to be given.
    @SuppressLint("StaticFieldLeak")
    private var context: Context? = null
    private var aliases: Set<String> = emptySet()
    private val lock = Any()

    /**
     * Called once, before any session, from whatever brings the core up.
     *
     * @param context the context [KeyChain] is asked through; its application context is retained
     * @param aliases key chain aliases this client is willing to authenticate with, in offer order
     */
    @JvmStatic
    fun configure(context: Context?, aliases: Set<String>?) {
        synchronized(lock) {
            this.context = context?.applicationContext
            this.aliases = if (aliases == null) emptySet() else LinkedHashSet(aliases)
        }
    }

    /** Must be `Object[]` on the JVM, hence `Array<Any>` and not `Array<String>`. */
    @JvmStatic
    fun getAliases(): Array<Any> = synchronized(lock) { aliases.toTypedArray<Any>() }

    /**
     * The leaf certificate of [alias], DER-encoded. Exceptions propagate: the core
     * is the only caller and knows what a failure should do to the connection.
     */
    @JvmStatic
    @Throws(Exception::class)
    fun getPubKey(alias: String): ByteArray =
        KeyChain.getCertificateChain(context, alias)!![0].encoded

    @JvmStatic
    @Throws(Exception::class)
    fun signDataWithIdentity(algorithm: String, alias: String, data: ByteArray): ByteArray {
        val signature = Signature.getInstance(algorithm)
        signature.initSign(KeyChain.getPrivateKey(context, alias))
        signature.update(data)
        return signature.sign()
    }
}
