// SPDX-License-Identifier: CC0-1.0

package com.realvnc.vncviewer.jni

import java.nio.ByteBuffer

/**
 * One connection, and everything that happens to it: opening it, driving it,
 * reading its framebuffer, closing it.
 *
 * Required by fourteen exported symbols (`Java_com_realvnc_vncviewer_jni_SessionBindings_*`)
 * and by three classes the core resolves by name: `SessionBindings$Session`,
 * `$SessionCallback` and `$DesktopCallback`.
 */
object SessionBindings {

    /**
     * The eight callbacks the core makes about the desktop, each resolved by name
     * on the object passed to [createSession].
     *
     * They arrive on the thread that called [createSession], which must be running
     * a `Looper` and must not be given slow work.
     */
    interface DesktopCallback {

        fun bell()

        /** Connected and ready. */
        fun connSuccess()

        /** A region changed: x, y, *width*, *height* — not a rect. */
        fun drawRegion(x: Int, y: Int, width: Int, height: Int)

        fun framebufferUpdateEnd()

        /** Our clipboard, for the server. */
        fun getClipboard(): String?

        fun setClipboard(text: String?)

        /**
         * Cursor shape and the *negated* hotspot (the RFB parser rewrites a cursor
         * rectangle to `(-hot, size - hot)`), so a drawer adds the hotspot back.
         *
         * The bitmap is an `android.graphics.Bitmap`, typed as `Any?` because that
         * is what the core constructs and hands over.
         */
        fun setCursor(bitmap: Any?, negHotX: Int, negHotY: Int)

        /** Framebuffer size, initially and on every resize. */
        fun setDesktopSize(width: Int, height: Int)
    }

    interface SessionCallback {
        /** The session ended, for any reason — remote, error, or our own close. */
        fun sessionClosed(session: Session?)
    }

    /**
     * An opaque handle. `token` is the native `AndroidSession*`, which the core
     * reads back through `getToken` on every call, so the object handed to any
     * native below has to be the one [createSession] returned.
     *
     * Nested (not inner), because the constructor the core calls is `<init>(J)V`.
     */
    class Session internal constructor(private var tokenValue: Long) {

        /** Public because it is the only way past this surface (see realvnc_traffic.c). */
        fun getToken(): Long = tokenValue

        fun setToken(token: Long) {
            tokenValue = token
        }
    }

    /**
     * Re-read the parameters that affect the encoder. Needed after changing the
     * quality group, and only then.
     */
    @JvmStatic
    external fun applyOptions(session: Session)

    /** Graceful disconnect. `sessionClosed` follows. */
    @JvmStatic
    external fun closeSession(session: Session)

    /**
     * Scale a desktop rectangle into the session's scratch buffer, at the
     * *buffer's* row stride. [scale] must be ≤ 1 and is quantised to `1/(int)(1/scale)`;
     * above 1 the native loop never advances.
     */
    @JvmStatic
    external fun copyScaledRegion(session: Session, x: Int, y: Int, width: Int, height: Int, scale: Float)

    /**
     * Starts a connection and returns in a few milliseconds; the rest arrives as
     * callbacks on this thread. A failure reports nothing at all, so a caller
     * needs a timeout of its own.
     */
    @JvmStatic
    external fun createSession(
        sessionCallback: SessionCallback,
        desktopCallback: DesktopCallback,
        address: String,
        password: String?,
        options: Map<String, String>,
    ): Session

    /** Frees the session and removes it from the native registry. */
    @JvmStatic
    external fun destroySession(session: Session)

    /** Whether the session should keep asking the server for updates. */
    @JvmStatic
    external fun focusEvent(session: Session, focused: Boolean)

    /**
     * The keycode ties a release to its press; the keysym is the payload.
     * Throws if the keysym does not fit in 31 bits.
     */
    @JvmStatic
    external fun keyDownEvent(session: Session, keysym: Long, keycode: Int)

    /** Releases the keysym recorded for [keycode] at press time. */
    @JvmStatic
    external fun keyUpEvent(session: Session, keycode: Int)

    /** Absolute desktop coordinates, RFB button mask. Clamped natively. */
    @JvmStatic
    external fun pointerEvent(session: Session, x: Int, y: Int, buttonMask: Int)

    @JvmStatic
    external fun setOption(session: Session, name: String, value: String)

    /**
     * Allocates `width * height * 4` bytes natively and returns a direct view of
     * them, for [copyScaledRegion] to write into. Calling this again re-allocates.
     */
    @JvmStatic
    external fun setScaleBufferSize(session: Session, width: Int, height: Int): ByteBuffer
}
