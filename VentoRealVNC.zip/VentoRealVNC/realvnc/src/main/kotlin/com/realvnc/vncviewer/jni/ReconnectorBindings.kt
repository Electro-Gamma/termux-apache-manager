// SPDX-License-Identifier: CC0-1.0

package com.realvnc.vncviewer.jni

/**
 * The "reconnecting…" banner: told to show, hide and close; there is no result
 * native. Required by `…_ReconnectorBindings_setDlgFactory`, `$ReconnectDlg`
 * and `$DlgFactory`.
 */
object ReconnectorBindings {

    interface ReconnectDlg {
        fun close()

        fun hide()

        fun show(message: String?, detail: String?)
    }

    interface DlgFactory {
        fun createReconnectDlg(session: SessionBindings.Session?): ReconnectDlg
    }

    @JvmStatic
    external fun setDlgFactory(factory: DlgFactory)
}
