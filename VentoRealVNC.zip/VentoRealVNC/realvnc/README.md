# realvnc

JNI `libvncviewer.so` bindings, in Kotlin (`src/main/kotlin`). Natives are `@JvmStatic external` in `object`s so the exported symbols still bind.

```bash
# build the aar
./gradlew :realvnc-jni:assembleRelease
```
