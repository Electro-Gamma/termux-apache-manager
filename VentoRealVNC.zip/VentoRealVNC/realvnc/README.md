# realvnc

JNI `libvncviewer.so`.

```bash
# build the aar
./gradlew :realvnc-jni:assembleRelease
```
