package com.tcpuartbridge.app

/**
 * Passively watches the raw, unmodified byte streams flowing between an
 * `upload_amebad.py`-style client and the UART (used for
 * [ServerMode.RAW_AUTOBAUD]) for AmebaD's own baud-rate-change command,
 * and reports the moment it's safe to retune the local UART to match -
 * the AmebaD counterpart to [EspBaudRateSniffer], which does the same for
 * esptool/ESP32's unrelated, SLIP-framed protocol. [TcpServerManager] runs
 * both on the same byte streams; they don't interfere with each other -
 * AmebaD's command bytes never include SLIP's 0xC0 frame delimiter, and
 * (see below) this class only ever matches at protocol boundaries that
 * esptool's traffic doesn't produce.
 *
 * Protocol (reverse-engineered from the user-provided `upload_amebad.py`;
 * not SLIP-framed - just bare bytes, unlike esptool). The device
 * continuously offers `0x15` (SYNC) when idle/ready; the host consumes
 * one, writes a command (`cmd_byte` + optional args), and the device
 * answers with a single `0x06` (ACK). The baud-change command is
 * `[0x05, sub_cmd]`, where `sub_cmd` is a table lookup for the target
 * speed (see [SPEED_TABLE], copied from the script's own `SPEED_TABLE`).
 * `upload_amebad.py` itself switches its own local port baud immediately
 * after receiving that command's ACK - see its `set_max_speed()` - so
 * this does the same.
 *
 * Unlike ESP32's SLIP frames, this protocol has no delimiter or escaping
 * at all for the large (1KB) firmware-data packets it also sends (`0x02`
 * + address + up to 1024 raw bytes + checksum) - nothing stops two
 * arbitrary bytes *inside* that raw firmware data from coincidentally
 * matching `[0x05, <a valid sub_cmd>]` (roughly 1-in-5000 byte pairs,
 * so a near-certainty somewhere in a multi-hundred-KB image). To avoid
 * misfiring on that - which would retune the baud mid-transfer and break
 * the flash - a candidate is only accepted if it starts *immediately*
 * after a `0x06`/`0x15` byte was last seen coming back from the chip,
 * matching exactly how every real command in this protocol is framed
 * (right after consuming a SYNC or an ACK - see `send_cmd()`/
 * `wait_sync()` in the script). Firmware-data packets always start with
 * a hardcoded `0x02` at that same boundary (`write_block()`), never
 * `0x05`, so this fully disambiguates the real command from data that
 * merely happens to contain the same two bytes somewhere in the middle.
 */
class AmebaBaudRateSniffer(private val onBaudChangeDetected: (Int) -> Unit) {

    // True only for the very next host byte after a 0x06/0x15 was seen from the chip -
    // i.e. "the host is free to start a new command right now". Starts true: nothing
    // sent yet, and the real script's first move is also a command right after sync.
    @Volatile private var atCommandBoundary = true
    @Volatile private var lastHostByteWasSetSpeed = false
    @Volatile private var pendingBaud: Int? = null

    /** Feed bytes heading from the TCP client towards the UART. Read-only tap - never mutates [data]. */
    fun watchFromHost(data: ByteArray, len: Int) {
        for (i in 0 until len) {
            val b = data[i].toInt() and 0xFF
            when {
                lastHostByteWasSetSpeed -> {
                    SPEED_TABLE[b]?.let { pendingBaud = it }
                    lastHostByteWasSetSpeed = false
                }
                atCommandBoundary && b == CMD_SET_SPEED -> lastHostByteWasSetSpeed = true
            }
            atCommandBoundary = false
        }
    }

    /** Feed bytes heading from the UART towards the TCP client. Read-only tap - never mutates [data]. */
    fun watchFromChip(data: ByteArray, len: Int) {
        for (i in 0 until len) {
            val b = data[i].toInt() and 0xFF
            if (b == ACK || b == SYNC) atCommandBoundary = true

            val baud = pendingBaud ?: continue
            when (b) {
                SYNC -> Unit // still waiting - send_cmd()'s own read loop skips these too
                ACK -> {
                    pendingBaud = null
                    onBaudChangeDetected(baud)
                }
                else -> pendingBaud = null // unexpected byte - abandon, matches send_cmd()'s own error path
            }
        }
    }

    companion object {
        private const val CMD_SET_SPEED = 0x05
        private const val SYNC = 0x15
        private const val ACK = 0x06

        // sub_cmd byte -> baud rate, copied from upload_amebad.py's SPEED_TABLE.
        private val SPEED_TABLE: Map<Int, Int> = mapOf(
            0x18 to 1500000,
            0x17 to 1444400,
            0x16 to 1382400,
            0x15 to 1000000,
            0x14 to 921600,
            0x13 to 500000,
            0x12 to 460800,
            0x11 to 380400,
            0x10 to 230400,
            0x0F to 153600,
            0x0D to 128000,
            0x0C to 115200
        )
    }
}
