package com.tcpuartbridge.app

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.CopyOnWriteArrayList

enum class ServerMode { RAW, RAW_AUTOBAUD, RFC2217 }

/**
 * A minimal multi-client TCP server. Every connected client receives every
 * byte that arrives from the UART (RX broadcast), and anything a client
 * sends is forwarded to the UART (TX). Nagle's algorithm is disabled on
 * every socket to keep latency low, which matters for esptool.py's
 * socket:// transport.
 *
 * In [ServerMode.RFC2217], every client's byte stream is instead run
 * through an [Rfc2217Session] (Telnet + RFC2217 COM-Port-Control), which
 * unwraps plain data before it reaches the UART, answers option
 * negotiation/subnegotiation on the client's behalf, and drives real
 * DTR/RTS resets. See [Rfc2217Session] for why resets are handled locally
 * rather than by naively relaying each control-line command.
 *
 * In [ServerMode.RAW_AUTOBAUD], bytes are relayed exactly like
 * [ServerMode.RAW] (no protocol wrapping) - but [EspBaudRateSniffer] and
 * [AmebaBaudRateSniffer] passively watch the same bytes for esptool's and
 * upload_amebad.py's own in-band baud-change commands and retune the
 * local UART to match, so `--baud` works over a plain `socket://` without
 * needing RFC2217 at all - and the UART is reset back to 115200 whenever
 * a client disconnects, so the next session starts clean regardless of
 * where the last one left the baud. If [TargetChip.ESP32] or
 * [TargetChip.AMEBAD] is selected, this mode also auto-drives that chip's
 * own reset-into-download-mode pulse right when a client connects, and its
 * own reset-to-normal-boot pulse right when it disconnects - the same
 * close/open gap a plain socket has always had for control lines, now
 * closed the same way baud rate is.
 *
 * IMPORTANT: [broadcast] is called directly from the USB driver's read
 * callback thread (see UsbSerialManager/SerialInputOutputManager). It must
 * never block on network I/O - if a socket write stalls even briefly, that
 * would back up into the USB hardware FIFO and silently drop incoming UART
 * bytes (this is what caused corrupted high-baud-rate flash reads). So the
 * actual socket write happens on a separate per-client coroutine, fed by an
 * unbounded [Channel]; [broadcast]/[send] only ever do a non-blocking enqueue.
 */
class TcpServerManager {

    private var serverSocket: ServerSocket? = null
    private val clients = CopyOnWriteArrayList<ClientHandler>()
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var acceptJob: Job? = null
    private var mode: ServerMode = ServerMode.RAW
    private var rfc2217Control: Rfc2217ControlBridge? = null
    private var targetChip: TargetChip = TargetChip.ESP32

    var onDataFromClient: ((ByteArray) -> Unit)? = null
    var onClientConnected: ((String) -> Unit)? = null
    var onClientDisconnected: ((String) -> Unit)? = null
    var onError: ((Exception) -> Unit)? = null
    /** Fired from [ServerMode.RAW_AUTOBAUD] whenever either baud sniffer detects and applies a live baud switch. */
    var onAutoBaudChanged: ((Int) -> Unit)? = null
    /** Fired from [ServerMode.RAW_AUTOBAUD] when a client disconnects and the UART is reset back to 115200. */
    var onAutoBaudReset: (() -> Unit)? = null
    /** Fired from [ServerMode.RAW_AUTOBAUD] + [TargetChip.ESP32] for the automatic connect/disconnect reset pulses. */
    var onAutoReset: ((String) -> Unit)? = null

    val clientCount: Int
        get() = clients.size

    fun start(
        port: Int,
        mode: ServerMode = ServerMode.RAW,
        rfc2217Control: Rfc2217ControlBridge? = null,
        targetChip: TargetChip = TargetChip.ESP32
    ) {
        this.mode = mode
        this.rfc2217Control = rfc2217Control
        this.targetChip = targetChip
        val socket = ServerSocket(port)
        serverSocket = socket
        acceptJob = scope.launch {
            try {
                while (isActive) {
                    val client = socket.accept()
                    client.tcpNoDelay = true
                    val handler = ClientHandler(client)
                    clients.add(handler)
                    onClientConnected?.invoke(client.inetAddress.hostAddress ?: "unknown")
                    handler.start()
                }
            } catch (e: Exception) {
                if (isActive) onError?.invoke(e)
            }
        }
    }

    /**
     * Raw UART RX bytes, broadcast to every connected client (IAC-escaped
     * first in RFC2217 mode). Called directly on the USB read thread -
     * must return immediately, see class doc.
     */
    fun broadcast(data: ByteArray) {
        val toSend = if (mode == ServerMode.RFC2217) Rfc2217Encoder.escapeData(data) else data
        clients.forEach { it.send(toSend) }
    }

    fun stop() {
        acceptJob?.cancel()
        clients.forEach { it.close(notify = false) }
        clients.clear()
        try {
            serverSocket?.close()
        } catch (_: Exception) {
        }
        serverSocket = null
    }

    private inner class ClientHandler(private val socket: Socket) {
        private var readJob: Job? = null
        private var writeJob: Job? = null
        private val remoteAddress = socket.inetAddress?.hostAddress ?: "unknown"
        private val out = socket.getOutputStream()

        // Unbounded on purpose: the producer side (broadcast(), called from the USB
        // read thread) must never block or drop data. In practice this stays small -
        // it only grows if the TCP receiver momentarily can't keep up - and even a
        // full 4MB flash read sitting in memory for a moment is trivial on a phone.
        private val writeChannel = Channel<ByteArray>(capacity = Channel.UNLIMITED)

        private val rfc2217Session: Rfc2217Session? = rfc2217Control?.takeIf { mode == ServerMode.RFC2217 }?.let {
            Rfc2217Session(
                control = it,
                scope = scope,
                targetChip = targetChip,
                onDecodedData = { data -> onDataFromClient?.invoke(data) },
                sendToClient = { bytes -> send(bytes) },
                onPurge = { rx, _ -> if (rx) purgeOutboundQueue() }
            )
        }

        private val espBaudSniffer: EspBaudRateSniffer? = rfc2217Control?.takeIf { mode == ServerMode.RAW_AUTOBAUD }?.let { control ->
            EspBaudRateSniffer { newBaud ->
                control.reconfigure(baudRate = newBaud)
                onAutoBaudChanged?.invoke(newBaud)
            }
        }

        private val amebaBaudSniffer: AmebaBaudRateSniffer? = rfc2217Control?.takeIf { mode == ServerMode.RAW_AUTOBAUD }?.let { control ->
            AmebaBaudRateSniffer { newBaud ->
                control.reconfigure(baudRate = newBaud)
                onAutoBaudChanged?.invoke(newBaud)
            }
        }

        // Guards against a bootloader-entry pulse (on connect) and a hard-reset pulse (on
        // disconnect) overlapping if a client connects and disconnects again in rapid
        // succession - cancelling any still-running pulse before starting the next one,
        // same pattern as Rfc2217Session's own resetJob.
        private var resetJob: Job? = null

        /**
         * Automatic ESP32 bootloader-entry pulse, run right when this client
         * connects if [ServerMode.RAW_AUTOBAUD] + [TargetChip.ESP32] are both
         * selected. A plain socket has no control channel for esptool to
         * request this itself - that's the whole "reset the chip manually"
         * limitation esptool prints over `socket://` - so the app does it up
         * front instead, mirroring the auto-reset circuit a real dev board
         * would normally provide. Same timing as
         * [MainActivity.performEsp32BootloaderReset] / [Rfc2217Session]'s
         * bootloader sequence (esptool's ClassicReset: DTR before releasing
         * RTS, 100ms/50ms delays).
         */
        private fun autoEsp32BootloaderReset(control: Rfc2217ControlBridge) {
            resetJob?.cancel()
            resetJob = scope.launch {
                control.setDTR(false) // IO0 = HIGH
                control.setRTS(true) // EN = LOW, chip in reset
                delay(100)
                control.setDTR(true) // IO0 = LOW
                control.setRTS(false) // EN = HIGH, exits reset and samples IO0 = LOW -> bootloader
                delay(50)
                control.setDTR(false) // IO0 = HIGH, done
            }
        }

        /**
         * Automatic hard-reset pulse (boots into the just-flashed app, not
         * the bootloader), run when this client disconnects if
         * [ServerMode.RAW_AUTOBAUD] + [TargetChip.ESP32] are both selected -
         * closes the same "can't reset over a plain socket" gap on the way
         * out that [autoEsp32BootloaderReset] closes on the way in.
         */
        private fun autoEsp32HardReset(control: Rfc2217ControlBridge) {
            resetJob?.cancel()
            resetJob = scope.launch {
                control.setRTS(true) // EN = LOW
                delay(100)
                control.setRTS(false) // EN = HIGH, exits reset -> runs the flashed app
            }
        }

        /**
         * Automatic AmebaD/BW16 download-mode-entry pulse, run right when
         * this client connects if [ServerMode.RAW_AUTOBAUD] +
         * [TargetChip.AMEBAD] are both selected. Brought back after an
         * earlier round removed dedicated BW16 support in favor of the
         * manual RTS/DTR switches alone - testing showed that manually
         * flipping two switches by hand can't reliably reproduce this
         * sequence's precise 500ms/200ms/500ms timing, so this closes the
         * same "no control channel over a plain socket" gap that
         * [autoEsp32BootloaderReset] closes for ESP32, this time wired
         * properly into connect/disconnect instead of only a manual button.
         * Timing/pin-mapping reverse-engineered exactly from the
         * user-provided `upload_amebad.py`'s `enter_download_mode()` /
         * `set_dtr_rts()`:
         * ```
         * set_dtr_rts(0x2): rts = not(0x2 & 1) = True,  dtr = not(0x2 & 2) = False   (EN low / reset)
         * set_dtr_rts(0x1): rts = not(0x1 & 1) = False, dtr = not(0x1 & 2) = True    (download-mode select)
         * set_dtr_rts(0x3): rts = not(0x3 & 1) = False, dtr = not(0x3 & 2) = False   (release)
         * ```
         * with 500ms / 200ms / 500ms delays between steps.
         */
        private fun autoAmebaDownloadModeReset(control: Rfc2217ControlBridge) {
            resetJob?.cancel()
            resetJob = scope.launch {
                control.setRTS(true)
                control.setDTR(false)
                delay(500)
                control.setRTS(false)
                control.setDTR(true)
                delay(200)
                control.setRTS(false)
                control.setDTR(false)
                delay(500)
            }
        }

        /**
         * Automatic AmebaD/BW16 reset-to-normal-boot pulse, run when this
         * client disconnects if [ServerMode.RAW_AUTOBAUD] +
         * [TargetChip.AMEBAD] are both selected - the AmebaD counterpart to
         * [autoEsp32HardReset]. Timing reverse-engineered exactly from
         * `upload_amebad.py`'s `reset_to_boot()`: same EN-low reset pulse as
         * download-mode entry, but released without ever selecting download
         * mode, so the chip boots the flashed app normally.
         */
        private fun autoAmebaHardReset(control: Rfc2217ControlBridge) {
            resetJob?.cancel()
            resetJob = scope.launch {
                control.setRTS(true)
                control.setDTR(false)
                delay(500)
                control.setRTS(false)
                control.setDTR(false)
            }
        }

        fun start() {
            rfc2217Session?.sendInitialOffer()

            if (mode == ServerMode.RAW_AUTOBAUD) {
                rfc2217Control?.let { control ->
                    when (targetChip) {
                        TargetChip.ESP32 -> {
                            onAutoReset?.invoke("bootloader entry (before upload)")
                            autoEsp32BootloaderReset(control)
                        }
                        TargetChip.AMEBAD -> {
                            onAutoReset?.invoke("AmebaD download-mode entry (before upload)")
                            autoAmebaDownloadModeReset(control)
                        }
                        TargetChip.GENERIC -> Unit
                    }
                }
            }

            writeJob = scope.launch {
                try {
                    for (data in writeChannel) {
                        out.write(data)
                        out.flush()
                    }
                } catch (_: Exception) {
                    close(notify = true)
                }
            }

            readJob = scope.launch {
                try {
                    val input = socket.getInputStream()
                    val buffer = ByteArray(4096)
                    while (isActive) {
                        val len = input.read(buffer)
                        if (len == -1) break
                        val session = rfc2217Session
                        if (session != null) {
                            session.feed(buffer, len)
                        } else {
                            espBaudSniffer?.watchFromHost(buffer, len)
                            amebaBaudSniffer?.watchFromHost(buffer, len)
                            onDataFromClient?.invoke(buffer.copyOf(len))
                        }
                    }
                } catch (_: Exception) {
                    // connection dropped or reset - fall through to cleanup
                } finally {
                    close(notify = true)
                }
            }
        }

        /** Non-blocking: only ever enqueues. Safe to call from the USB read thread. */
        fun send(data: ByteArray) {
            espBaudSniffer?.watchFromChip(data, data.size)
            amebaBaudSniffer?.watchFromChip(data, data.size)
            writeChannel.trySend(data)
        }

        /**
         * Drops any bytes already queued to be written to this client but not
         * yet sent - see [Rfc2217Session]'s PURGE_DATA handling and the
         * proactive purges after a baud-rate change / reset pulse. There's an
         * inherent small race against [broadcast] enqueueing new bytes
         * concurrently from the USB read thread (a byte captured in the same
         * instant as the purge could be dropped too) - acceptable here since
         * the same race exists on a real UART purge, and the alternative
         * (leaving stale bytes queued for delivery right when esptool expects
         * a fresh response) is the actual bug being fixed.
         */
        fun purgeOutboundQueue() {
            while (writeChannel.tryReceive().isSuccess) {
                // drain
            }
        }

        fun close(notify: Boolean) {
            writeChannel.close()
            try {
                socket.close()
            } catch (_: Exception) {
            }
            readJob?.cancel()
            writeJob?.cancel()

            val wasConnected = clients.remove(this)
            // Gated on `notify` too, not just a natural per-client disconnect: stop() passes
            // notify=false and closes the USB port immediately afterwards, which would race
            // these coroutines and could cut a reset pulse off mid-sequence (leaving RTS/DTR
            // stuck in whatever state it was in when the port closed under it).
            if (wasConnected && notify && mode == ServerMode.RAW_AUTOBAUD) {
                rfc2217Control?.let { control ->
                    // Whatever baud esptool/upload_amebad.py left the port at, put it back to
                    // 115200 for the next session - that's what a fresh ROM/stub/download-mode
                    // loader always expects for its own initial sync, regardless of which chip
                    // or client connects next. See BridgeService.startBridge's matching
                    // "always open RAW_AUTOBAUD at 115200" for the same reasoning.
                    control.reconfigure(baudRate = 115200)
                    onAutoBaudReset?.invoke()
                    when (targetChip) {
                        TargetChip.ESP32 -> {
                            onAutoReset?.invoke("hard reset (after upload)")
                            autoEsp32HardReset(control)
                        }
                        TargetChip.AMEBAD -> {
                            onAutoReset?.invoke("AmebaD reset to normal boot (after upload)")
                            autoAmebaHardReset(control)
                        }
                        TargetChip.GENERIC -> Unit
                    }
                }
            }
            if (wasConnected && notify) {
                onClientDisconnected?.invoke(remoteAddress)
            }
        }
    }
}
