package com.tcpuartbridge.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Binder
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.hoho.android.usbserial.driver.UsbSerialDriver
import java.net.Inet4Address
import java.net.NetworkInterface

/**
 * Foreground service that owns the live [UsbSerialManager] and
 * [TcpServerManager] instances and pipes data between them. Runs
 * independently of the Activity so the bridge keeps working with the
 * screen off, per the "connectedDevice" foreground service type declared
 * in the manifest.
 */
class BridgeService : Service() {

    private val binder = LocalBinder()
    private lateinit var usbSerial: UsbSerialManager
    private lateinit var tcpServer: TcpServerManager
    private var listener: BridgeListener? = null
    private var status = BridgeStatus()

    private val rfc2217Control = object : Rfc2217ControlBridge {
        override fun setDTR(value: Boolean) = usbSerial.setDTR(value)
        override fun setRTS(value: Boolean) = usbSerial.setRTS(value)
        override fun reconfigure(baudRate: Int?, dataBits: Int?, stopBits: Int?, parity: Int?) {
            usbSerial.reconfigure(baudRate, dataBits, stopBits, parity)
        }
        override val currentBaudRate: Int get() = usbSerial.currentBaudRate
        override val currentDataBits: Int get() = usbSerial.currentDataBits
        override val currentStopBits: Int get() = usbSerial.currentStopBits
        override val currentParity: Int get() = usbSerial.currentParity
    }

    inner class LocalBinder : Binder() {
        fun getService(): BridgeService = this@BridgeService
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        usbSerial = UsbSerialManager(this)
        tcpServer = TcpServerManager()
        createNotificationChannel()

        usbSerial.onDataReceived = { data ->
            tcpServer.broadcast(data)
            listener?.onLog("RX ${data.size}B (UART -> TCP)")
        }
        usbSerial.onError = { e -> listener?.onLog("USB error: ${e.message}") }
        usbSerial.onLog = { msg -> listener?.onLog(msg) }

        tcpServer.onDataFromClient = { data ->
            usbSerial.write(data)
            listener?.onLog("TX ${data.size}B (TCP -> UART)")
        }
        tcpServer.onClientConnected = { addr ->
            status = status.copy(clientCount = tcpServer.clientCount)
            listener?.onLog("Client connected: $addr")
            refreshNotification()
            listener?.onStatusChanged(status)
        }
        tcpServer.onClientDisconnected = { addr ->
            status = status.copy(clientCount = tcpServer.clientCount)
            listener?.onLog("Client disconnected: $addr")
            refreshNotification()
            listener?.onStatusChanged(status)
        }
        tcpServer.onError = { e -> listener?.onLog("TCP error: ${e.message}") }
        tcpServer.onAutoBaudChanged = { newBaud ->
            status = status.copy(baudRate = newBaud)
            listener?.onLog("Auto-baud: detected a baud-rate change command on the wire -> UART switched to ${newBaud} baud")
            refreshNotification()
            listener?.onStatusChanged(status)
        }
        tcpServer.onAutoBaudReset = {
            status = status.copy(baudRate = 115200)
            listener?.onLog("Auto-baud: session ended, UART reset to 115200 baud for the next connection")
            refreshNotification()
            listener?.onStatusChanged(status)
        }
        tcpServer.onAutoReset = { description ->
            listener?.onLog("Auto-reset: $description")
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopBridge()
        }
        return START_STICKY
    }

    fun setListener(l: BridgeListener?) {
        listener = l
    }

    fun getStatus(): BridgeStatus = status

    /** Opens the USB serial port and starts the TCP server. Returns true on success. */
    fun startBridge(
        driver: UsbSerialDriver,
        baudRate: Int,
        dataBits: Int,
        stopBits: Int,
        parity: Int,
        tcpPort: Int,
        protocolMode: ServerMode = ServerMode.RAW,
        targetChip: TargetChip = TargetChip.ESP32
    ): Boolean {
        if (status.running) return true

        // Raw auto-baud always opens at 115200 - that's what the ESP ROM/stub loader
        // itself always expects for the initial SYNC handshake regardless of --baud
        // (esptool syncs at up to 115200, then requests a higher speed in-band via
        // CHANGE_BAUDRATE if you passed --baud - see EspBaudRateSniffer, which is what
        // then retunes this to match). Whatever the UART Settings baud spinner says is
        // ignored in this mode; data bits/stop bits/parity from it still apply as given.
        val effectiveBaud = if (protocolMode == ServerMode.RAW_AUTOBAUD) 115200 else baudRate

        val opened = usbSerial.open(driver, effectiveBaud, dataBits, stopBits, parity)
        if (!opened) {
            listener?.onLog("Failed to open USB serial port")
            return false
        }

        try {
            tcpServer.start(tcpPort, protocolMode, rfc2217Control, targetChip)
        } catch (e: Exception) {
            listener?.onLog("Failed to start TCP server on port $tcpPort: ${e.message}")
            usbSerial.close()
            return false
        }

        status = BridgeStatus(
            running = true,
            usbConnected = true,
            deviceName = usbSerial.deviceInfo(driver),
            baudRate = effectiveBaud,
            tcpPort = tcpPort,
            clientCount = 0,
            ipAddress = getLocalIpAddress(),
            protocolMode = protocolMode
        )

        startForeground(NOTIF_ID, buildNotification())
        val modeLabel = when (protocolMode) {
            ServerMode.RFC2217 -> "RFC2217"
            ServerMode.RAW_AUTOBAUD -> "raw, auto-baud"
            ServerMode.RAW -> "raw"
        }
        listener?.onLog("Bridge started: UART ${effectiveBaud}bps <-> TCP ${status.ipAddress}:$tcpPort ($modeLabel)")
        listener?.onStatusChanged(status)
        return true
    }

    fun stopBridge() {
        tcpServer.stop()
        usbSerial.close()
        status = status.copy(running = false, usbConnected = false, clientCount = 0)
        listener?.onLog("Bridge stopped")
        listener?.onStatusChanged(status)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    fun setRTS(value: Boolean) = usbSerial.setRTS(value)
    fun setDTR(value: Boolean) = usbSerial.setDTR(value)

    override fun onDestroy() {
        tcpServer.stop()
        usbSerial.close()
        super.onDestroy()
    }

    // ---- notification -------------------------------------------------

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Bridge Service",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Shows TCP UART Bridge status while running"
            setShowBadge(false)
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val mutabilityFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            PendingIntent.FLAG_MUTABLE
        } else {
            0
        }

        val contentIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or mutabilityFlag
        )

        val stopIntent = Intent(this, BridgeService::class.java).apply { action = ACTION_STOP }
        val stopPending = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or mutabilityFlag
        )

        val usbLine = if (status.usbConnected) "USB: ${status.deviceName}" else "USB: not connected"
        val uartLine = "UART: ${status.baudRate} baud"
        val modeLabel = when (status.protocolMode) {
            ServerMode.RFC2217 -> "RFC2217"
            ServerMode.RAW_AUTOBAUD -> "raw, auto-baud"
            ServerMode.RAW -> "raw"
        }
        val tcpLine = "TCP: ${status.ipAddress}:${status.tcpPort} ($modeLabel) - ${status.clientCount} client(s)"

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("TCP UART Bridge running")
            .setContentText("$usbLine  ·  $tcpLine")
            .setStyle(NotificationCompat.BigTextStyle().bigText("$usbLine\n$uartLine\n$tcpLine"))
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(contentIntent)
            .addAction(0, "Stop", stopPending)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun refreshNotification() {
        if (!status.running) return
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
    }

    // ---- helpers --------------------------------------------------------

    private fun getLocalIpAddress(): String {
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val iface = interfaces.nextElement()
                val addresses = iface.inetAddresses
                while (addresses.hasMoreElements()) {
                    val addr = addresses.nextElement()
                    if (!addr.isLoopbackAddress && addr is Inet4Address) {
                        return addr.hostAddress ?: "unknown"
                    }
                }
            }
        } catch (_: Exception) {
        }
        return "unknown"
    }

    companion object {
        const val NOTIF_ID = 1001
        const val CHANNEL_ID = "bridge_channel"
        const val ACTION_STOP = "com.tcpuartbridge.app.ACTION_STOP"
    }
}
