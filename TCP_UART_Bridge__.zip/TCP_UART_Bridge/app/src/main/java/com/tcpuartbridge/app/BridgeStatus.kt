package com.tcpuartbridge.app

/**
 * Immutable snapshot of the bridge's current state, shared between [BridgeService]
 * and [MainActivity] / the foreground notification.
 */
data class BridgeStatus(
    val running: Boolean = false,
    val usbConnected: Boolean = false,
    val deviceName: String = "",
    val baudRate: Int = 0,
    val tcpPort: Int = 3333,
    val clientCount: Int = 0,
    val ipAddress: String = "unknown",
    val protocolMode: ServerMode = ServerMode.RAW
)

/**
 * Callback interface used by [BridgeService] to push log lines and status
 * changes back to whatever UI is currently bound to it.
 */
interface BridgeListener {
    fun onLog(message: String)
    fun onStatusChanged(status: BridgeStatus)
}
