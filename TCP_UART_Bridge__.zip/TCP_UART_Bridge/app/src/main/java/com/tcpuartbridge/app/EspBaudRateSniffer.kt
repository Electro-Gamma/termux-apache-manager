package com.tcpuartbridge.app

/**
 * Passively watches the raw, unmodified byte streams flowing between an
 * esptool client and the UART (used for [ServerMode.RAW_AUTOBAUD]) for the
 * ESP ROM/stub loader's CHANGE_BAUDRATE command, and reports the moment
 * it's safe to retune the local UART's baud rate to match.
 *
 * Why this is possible at all: a plain TCP socket has no side-channel to
 * signal a baud-rate change the way RFC2217's SET_BAUDRATE subnegotiation
 * does - but esptool.py always negotiates a higher speed *in-band*, over
 * the same wire, using this exact SLIP-framed command, documented at
 * https://docs.espressif.com/projects/esptool/en/latest/esp32/advanced-topics/serial-protocol.html#commands
 * ("Esptool tries to sync at (maximum) 115200bps and then sends this
 * command to go to a higher baud rate, if requested."). So the same
 * information the RFC2217 path gets explicitly is already sitting in the
 * data that's flowing through this app unmodified either way - this just
 * reads it instead of relaying it blind.
 *
 * Packet format (verified against the doc above, all multi-byte fields
 * little-endian), SLIP-framed (0xC0-delimited, with 0xC0/0xDB byte-stuffed
 * as 0xDB 0xDC / 0xDB 0xDD inside the frame):
 * ```
 * Command  (host -> chip): [dir=0x00][cmd][size:u16][checksum:u32][data...]
 * Response (chip -> host): [dir=0x01][cmd][size:u16][value:u32   ][data...]
 * ```
 * CHANGE_BAUDRATE is command `0x0F`; its command-packet Data is two
 * little-endian u32 words - "new baud rate, 0 if we are talking to the ROM
 * loader or the current/old baud rate if we are talking to the stub
 * loader" (per the doc) - so the new baud is always the first 4 bytes of
 * Data, at frame offset 8, regardless of which loader is running.
 *
 * Timing: the command must reach the chip - and the chip's response must
 * be fully relayed back to the client - at the *old* baud rate, exactly
 * like a real cable; the chip itself only flips its own baud rate over
 * once it's finished sending that response. So this only fires
 * [onBaudChangeDetected] on seeing the *response* frame (by which point
 * the chip has, in real time, already sent its last old-baud byte and is
 * at or past its own switch-over), not on seeing the outgoing request.
 */
class EspBaudRateSniffer(private val onBaudChangeDetected: (Int) -> Unit) {

    private val hostToChip = SlipFrameCollector()
    private val chipToHost = SlipFrameCollector()

    @Volatile private var pendingBaud: Int? = null

    /** Feed bytes heading from the TCP client towards the UART. Read-only tap - never mutates [data]. */
    fun watchFromHost(data: ByteArray, len: Int) {
        for (i in 0 until len) hostToChip.feed(data[i], ::onHostFrame)
    }

    /** Feed bytes heading from the UART towards the TCP client. Read-only tap - never mutates [data]. */
    fun watchFromChip(data: ByteArray, len: Int) {
        for (i in 0 until len) chipToHost.feed(data[i], ::onChipFrame)
    }

    private fun onHostFrame(buf: ByteArray, len: Int) {
        if (len < 12) return // need dir+cmd+size+checksum (8) + at least the new-baud word (4)
        val direction = buf[0].toInt() and 0xFF
        val command = buf[1].toInt() and 0xFF
        if (direction != DIR_REQUEST || command != ESP_CHANGE_BAUDRATE) return
        val newBaud = leInt(buf, 8)
        if (newBaud > 0) pendingBaud = newBaud
    }

    private fun onChipFrame(buf: ByteArray, len: Int) {
        if (len < 2) return
        val direction = buf[0].toInt() and 0xFF
        val command = buf[1].toInt() and 0xFF
        if (direction != DIR_RESPONSE || command != ESP_CHANGE_BAUDRATE) return
        val baud = pendingBaud ?: return
        pendingBaud = null
        onBaudChangeDetected(baud)
    }

    private fun leInt(b: ByteArray, offset: Int): Int =
        (b[offset].toInt() and 0xFF) or
            ((b[offset + 1].toInt() and 0xFF) shl 8) or
            ((b[offset + 2].toInt() and 0xFF) shl 16) or
            ((b[offset + 3].toInt() and 0xFF) shl 24)

    companion object {
        private const val ESP_CHANGE_BAUDRATE = 0x0F
        private const val DIR_REQUEST = 0x00
        private const val DIR_RESPONSE = 0x01
    }

    /**
     * Minimal streaming SLIP de-framer. Reassembles 0xC0-delimited frames
     * and undoes 0xDB 0xDC/0xDB 0xDD byte-stuffing, calling back with each
     * complete frame's payload - but only ever captures the first
     * [CAPTURE_LIMIT] decoded bytes of any given frame into a small reused
     * buffer, silently dropping the rest (still tracking escape state so
     * the frame boundary itself isn't lost).
     *
     * This matters for performance, not just simplicity: FLASH_DATA frames
     * carry up to 16KB of payload, and this class watches *every* byte of
     * *every* frame in both directions for the life of the bridge. A
     * naive "append every byte to a growing buffer" implementation is
     * O(n^2) per frame; CHANGE_BAUDRATE's entire command is only 16 bytes
     * (8-byte header + two 4-byte words), so a small fixed capture window
     * is all that's ever needed to recognize it - everything else is
     * O(1) per byte, allocation-free, regardless of the frame it's inside.
     *
     * Unrelated to [TelnetIacDecoder] - this is the ESP ROM/stub loader's
     * own framing, which only happens to also be SLIP.
     */
    private class SlipFrameCollector {
        private val buffer = ByteArray(CAPTURE_LIMIT)
        private var count = 0
        private var inFrame = false
        private var inEscape = false

        fun feed(byte: Byte, onFrame: (ByteArray, Int) -> Unit) {
            val b = byte.toInt() and 0xFF
            when {
                b == 0xC0 -> {
                    if (inFrame && count > 0) onFrame(buffer, count)
                    count = 0
                    inFrame = true
                    inEscape = false
                }
                !inFrame -> Unit // stray byte outside a frame - ignore
                inEscape -> {
                    inEscape = false
                    val real = when (b) {
                        0xDC -> 0xC0
                        0xDD -> 0xDB
                        else -> b // malformed escape - best effort, keep the literal byte
                    }
                    if (count < CAPTURE_LIMIT) buffer[count++] = real.toByte()
                }
                b == 0xDB -> inEscape = true
                else -> if (count < CAPTURE_LIMIT) buffer[count++] = b.toByte()
            }
        }

        companion object {
            // dir(1) + cmd(1) + size(2) + checksum/value(4) + first 8 bytes of data
            // (CHANGE_BAUDRATE's whole command body) = 16 bytes; nothing we care about
            // ever needs more than this.
            private const val CAPTURE_LIMIT = 16
        }
    }
}
