package com.tcpuartbridge.app

import android.content.Context
import android.hardware.usb.UsbManager
import com.hoho.android.usbserial.driver.UsbSerialDriver
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.util.SerialInputOutputManager

/**
 * Maps a USB vendor id to a human readable chip name so the UI can show
 * something more useful than raw hex numbers.
 */
object UsbChipIdentifier {
    fun name(vendorId: Int, productId: Int): String = when (vendorId) {
        0x1A86 -> "CH340 (WCH)"
        0x10C4 -> "CP210x (Silicon Labs)"
        0x0403 -> "FTDI FT232"
        0x067B -> "PL2303 (Prolific)"
        0x303A -> "ESP32 Native USB (CDC-ACM)"
        else -> "CDC-ACM / Generic Serial"
    }
}

/**
 * Thin wrapper around usb-serial-for-android. Owns exactly one open port at a
 * time (this bridge only ever talks to one UART), and reports RX bytes /
 * errors / log lines back through callbacks so the service can wire them up
 * to the TCP side without this class knowing anything about sockets.
 */
class UsbSerialManager(context: Context) {

    private val usbManager = context.getSystemService(Context.USB_SERVICE) as UsbManager

    private var port: UsbSerialPort? = null
    private var ioManager: SerialInputOutputManager? = null

    var onDataReceived: ((ByteArray) -> Unit)? = null
    var onError: ((Exception) -> Unit)? = null
    var onLog: ((String) -> Unit)? = null

    var currentBaudRate: Int = 115200
        private set
    var currentDataBits: Int = 8
        private set
    var currentStopBits: Int = UsbSerialPort.STOPBITS_1
        private set
    var currentParity: Int = UsbSerialPort.PARITY_NONE
        private set

    fun listAvailableDrivers(): List<UsbSerialDriver> {
        return com.hoho.android.usbserial.driver.UsbSerialProber.getDefaultProber().findAllDrivers(usbManager)
    }

    fun hasPermission(driver: UsbSerialDriver): Boolean = usbManager.hasPermission(driver.device)

    /**
     * Opens the given driver's first port and applies the requested
     * parameters. Returns false (and logs why) instead of throwing, so
     * callers can just check a boolean.
     */
    fun open(driver: UsbSerialDriver, baudRate: Int, dataBits: Int, stopBits: Int, parity: Int): Boolean {
        return try {
            val connection = usbManager.openDevice(driver.device)
            if (connection == null) {
                onLog?.invoke("Unable to open USB device (no permission or device busy)")
                return false
            }
            val p = driver.ports[0]
            p.open(connection)
            p.setParameters(baudRate, dataBits, stopBits, parity)
            currentBaudRate = baudRate
            currentDataBits = dataBits
            currentStopBits = stopBits
            currentParity = parity

            val io = SerialInputOutputManager(p, object : SerialInputOutputManager.Listener {
                override fun onNewData(data: ByteArray) {
                    onDataReceived?.invoke(data)
                }

                override fun onRunError(e: Exception) {
                    onError?.invoke(e)
                }
            })
            io.start()

            port = p
            ioManager = io
            true
        } catch (e: Exception) {
            onLog?.invoke("USB open failed: ${e.message}")
            false
        }
    }

    /**
     * Changes UART parameters on an already-open port, e.g. when an RFC2217
     * client sends SET-BAUDRATE / SET-DATASIZE / SET-PARITY / SET-STOPSIZE
     * mid-session (esptool bumps the baud rate after uploading its stub).
     * Any parameter left null keeps its current value.
     */
    fun reconfigure(baudRate: Int? = null, dataBits: Int? = null, stopBits: Int? = null, parity: Int? = null): Boolean {
        val p = port ?: return false
        val newBaud = baudRate ?: currentBaudRate
        val newDataBits = dataBits ?: currentDataBits
        val newStopBits = stopBits ?: currentStopBits
        val newParity = parity ?: currentParity
        return try {
            p.setParameters(newBaud, newDataBits, newStopBits, newParity)
            currentBaudRate = newBaud
            currentDataBits = newDataBits
            currentStopBits = newStopBits
            currentParity = newParity
            true
        } catch (e: Exception) {
            onLog?.invoke("Reconfigure failed: ${e.message}")
            false
        }
    }


    fun write(data: ByteArray) {
        val p = port ?: return
        try {
            p.write(data, WRITE_TIMEOUT_MS)
        } catch (e: Exception) {
            onError?.invoke(e)
        }
    }

    /** RTS is wired to ESP32 EN/RESET on typical auto-program circuits. */
    fun setRTS(value: Boolean) {
        try {
            port?.setRTS(value)
        } catch (e: Exception) {
            onError?.invoke(e)
        }
    }

    /** DTR is wired to ESP32 GPIO0/BOOT on typical auto-program circuits. */
    fun setDTR(value: Boolean) {
        try {
            port?.setDTR(value)
        } catch (e: Exception) {
            onError?.invoke(e)
        }
    }

    fun close() {
        try {
            ioManager?.stop()
        } catch (_: Exception) {
        }
        try {
            port?.close()
        } catch (_: Exception) {
        }
        port = null
        ioManager = null
    }

    fun isOpen(): Boolean = port != null

    fun deviceInfo(driver: UsbSerialDriver): String {
        val d = driver.device
        return "${UsbChipIdentifier.name(d.vendorId, d.productId)} (VID:${d.vendorId} PID:${d.productId})"
    }

    companion object {
        private const val WRITE_TIMEOUT_MS = 2000
    }
}
