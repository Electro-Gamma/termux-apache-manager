package com.tcpuartbridge.app

import java.io.ByteArrayOutputStream

/**
 * Telnet command bytes (RFC 854) and the RFC 2217 "COM Port Control Option"
 * constants. Values cross-checked against Espressif's own esp_rfc2217_server
 * (which imports COM_PORT_OPTION / SET_CONTROL / SET_CONTROL_DTR_ON / etc.
 * from pySerial's serial.rfc2217 module) so this is wire-compatible with the
 * exact same client esptool uses.
 */
object Telnet {
    const val SE = 240
    const val SB = 250
    const val WILL = 251
    const val WONT = 252
    const val DO = 253
    const val DONT = 254
    const val IAC = 255

    // Options we actually negotiate
    const val BINARY = 0
    const val COM_PORT_OPTION = 44
}

object Rfc2217 {
    // COM-PORT-OPTION subnegotiation commands (client -> server)
    const val SIGNATURE = 0
    const val SET_BAUDRATE = 1
    const val SET_DATASIZE = 2
    const val SET_PARITY = 3
    const val SET_STOPSIZE = 4
    const val SET_CONTROL = 5
    const val NOTIFY_LINESTATE = 6
    const val NOTIFY_MODEMSTATE = 7
    const val FLOWCONTROL_SUSPEND = 8
    const val FLOWCONTROL_RESUME = 9
    const val SET_LINESTATE_MASK = 10
    const val SET_MODEMSTATE_MASK = 11
    const val PURGE_DATA = 12

    // Server -> client replies use the same command code + 100
    const val SERVER_OFFSET = 100

    // SET-CONTROL values
    const val SET_CONTROL_REQ_FLOW_SETTING_IN = 0
    const val SET_CONTROL_USE_NO_FLOW_CONTROL_IN = 1
    const val SET_CONTROL_USE_SW_FLOW_CONTROL_IN = 2
    const val SET_CONTROL_USE_HW_FLOW_CONTROL_IN = 3
    const val SET_CONTROL_BREAK_REQ = 4
    const val SET_CONTROL_BREAK_ON = 5
    const val SET_CONTROL_BREAK_OFF = 6
    const val SET_CONTROL_DTR_REQ = 7
    const val SET_CONTROL_DTR_ON = 8
    const val SET_CONTROL_DTR_OFF = 9
    const val SET_CONTROL_RTS_REQ = 10
    const val SET_CONTROL_RTS_ON = 11
    const val SET_CONTROL_RTS_OFF = 12
    const val SET_CONTROL_REQ_FLOW_SETTING_OUT = 13
    const val SET_CONTROL_USE_NO_FLOW_CONTROL_OUT = 14
    const val SET_CONTROL_USE_SW_FLOW_CONTROL_OUT = 15
    const val SET_CONTROL_USE_HW_FLOW_CONTROL_OUT = 16
    const val SET_CONTROL_USE_DCD_FLOW_CONTROL = 17
    const val SET_CONTROL_USE_DTR_FLOW_CONTROL = 18
    const val SET_CONTROL_USE_DSR_FLOW_CONTROL = 19

    // PURGE-DATA values
    const val PURGE_RECEIVE_BUFFER = 1
    const val PURGE_TRANSMIT_BUFFER = 2
    const val PURGE_BOTH_BUFFERS = 3
}

/**
 * Decodes a raw Telnet/RFC2217 byte stream arriving from a socket. Bytes may
 * arrive split across arbitrary chunk boundaries (TCP gives no message
 * framing), so this is a resumable state machine: feed() can be called
 * repeatedly with any-sized chunks and it picks up wherever it left off.
 *
 * - Plain data bytes (including an unescaped literal 0xFF, sent as two
 *   0xFF bytes back to back) are batched and delivered via [onData] in as
 *   few calls as possible, so callers can write them straight to the UART
 *   without per-byte overhead.
 * - IAC WILL/WONT/DO/DONT <option> negotiations go to [onNegotiation].
 * - IAC SB <payload, IAC-escaped> IAC SE subnegotiations go to [onSubnegotiation]
 *   with the payload already unescaped.
 */
class TelnetIacDecoder(
    private val onData: (ByteArray) -> Unit,
    private val onNegotiation: (verb: Int, option: Int) -> Unit,
    private val onSubnegotiation: (payload: ByteArray) -> Unit
) {
    private enum class State { DATA, IAC_SEEN, NEGOTIATE, SUBNEG, SUBNEG_IAC }

    private var state = State.DATA
    private var pendingVerb = -1
    private val subnegBuffer = ByteArrayOutputStream()
    private val dataAccum = ByteArrayOutputStream()

    private fun flushData() {
        if (dataAccum.size() > 0) {
            onData(dataAccum.toByteArray())
            dataAccum.reset()
        }
    }

    fun feed(bytes: ByteArray, length: Int = bytes.size) {
        for (i in 0 until length) {
            feedByte(bytes[i].toInt() and 0xFF)
        }
        flushData()
    }

    private fun feedByte(b: Int) {
        when (state) {
            State.DATA -> {
                if (b == Telnet.IAC) {
                    flushData()
                    state = State.IAC_SEEN
                } else {
                    dataAccum.write(b)
                }
            }

            State.IAC_SEEN -> {
                when (b) {
                    Telnet.IAC -> {
                        dataAccum.write(0xFF) // escaped literal 0xFF in the data stream
                        state = State.DATA
                    }
                    Telnet.WILL, Telnet.WONT, Telnet.DO, Telnet.DONT -> {
                        pendingVerb = b
                        state = State.NEGOTIATE
                    }
                    Telnet.SB -> {
                        subnegBuffer.reset()
                        state = State.SUBNEG
                    }
                    else -> {
                        // single-byte Telnet command (NOP, AYT, ...) - not used by RFC2217, ignore
                        state = State.DATA
                    }
                }
            }

            State.NEGOTIATE -> {
                onNegotiation(pendingVerb, b)
                pendingVerb = -1
                state = State.DATA
            }

            State.SUBNEG -> {
                if (b == Telnet.IAC) {
                    state = State.SUBNEG_IAC
                } else {
                    subnegBuffer.write(b)
                }
            }

            State.SUBNEG_IAC -> {
                when (b) {
                    Telnet.SE -> {
                        onSubnegotiation(subnegBuffer.toByteArray())
                        subnegBuffer.reset()
                        state = State.DATA
                    }
                    Telnet.IAC -> {
                        subnegBuffer.write(0xFF) // escaped literal 0xFF inside subneg payload
                        state = State.SUBNEG
                    }
                    else -> {
                        // malformed (bare IAC inside a subneg with no SE/IAC follow-up) - be
                        // lenient rather than dropping the connection: keep both bytes.
                        subnegBuffer.write(Telnet.IAC)
                        subnegBuffer.write(b)
                        state = State.SUBNEG
                    }
                }
            }
        }
    }
}

/** Encoder helpers for the server -> client direction. */
object Rfc2217Encoder {

    /** Escapes any 0xFF byte in plain UART data as 0xFF 0xFF before sending to a telnet peer. */
    fun escapeData(raw: ByteArray): ByteArray {
        var extra = 0
        for (b in raw) if (b == 0xFF.toByte()) extra++
        if (extra == 0) return raw
        val out = ByteArray(raw.size + extra)
        var i = 0
        for (b in raw) {
            out[i++] = b
            if (b == 0xFF.toByte()) out[i++] = b
        }
        return out
    }

    fun negotiation(verb: Int, option: Int): ByteArray =
        byteArrayOf(Telnet.IAC.toByte(), verb.toByte(), option.toByte())

    /** Wraps a COM-PORT-OPTION subnegotiation payload as IAC SB <escaped payload> IAC SE. */
    fun subnegotiation(payload: ByteArray): ByteArray {
        val out = ByteArrayOutputStream()
        out.write(Telnet.IAC)
        out.write(Telnet.SB)
        for (b in payload) {
            val v = b.toInt() and 0xFF
            out.write(v)
            if (v == Telnet.IAC) out.write(Telnet.IAC)
        }
        out.write(Telnet.IAC)
        out.write(Telnet.SE)
        return out.toByteArray()
    }

    /** Builds a COM_PORT_OPTION subneg: [COM_PORT_OPTION, command, ...valueBytes]. */
    fun comPortSubnegotiation(command: Int, vararg valueBytes: Int): ByteArray {
        val payload = ByteArray(2 + valueBytes.size)
        payload[0] = Telnet.COM_PORT_OPTION.toByte()
        payload[1] = command.toByte()
        for (i in valueBytes.indices) payload[2 + i] = valueBytes[i].toByte()
        return subnegotiation(payload)
    }

    fun baudRateBytes(baud: Int): IntArray = intArrayOf(
        (baud ushr 24) and 0xFF,
        (baud ushr 16) and 0xFF,
        (baud ushr 8) and 0xFF,
        baud and 0xFF
    )
}
