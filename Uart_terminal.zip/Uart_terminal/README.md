# Uart terminal — an Android serial console for the Banana Pi M2 Zero

A native Kotlin/Jetpack Compose Android app that turns a phone or tablet
into a serial terminal for talking to an embedded Linux board's UART
console over USB‑OTG — the same job PuTTY's serial backend does on a PC,
scoped down to what a phone needs. It does **not** include SSH, Telnet,
FTP/SFTP, or any other PuTTY feature; only serial-terminal behavior was
ported, as requested.

## What it does

Phone/tablet → USB‑OTG → USB‑to‑UART adapter (FTDI / CP210x / CH340 / PL2303
/ generic CDC‑ACM) → Banana Pi M2 Zero or M2 Zero W UART pins → the board's
Linux serial console (login prompt, shell, `dmesg`, etc.), rendered as a
real ANSI/VT100‑ish terminal with colors, cursor movement, scrollback,
selection/copy, and paste — not a raw log viewer.

## Banana Pi M2 Zero / M2 Zero W wiring (researched, not hard‑coded)

The M2 Zero and M2 Zero W share the same Allwinner H2+ SoC and 40‑pin
header, laid out pin‑compatible with the Raspberry Pi 3. Across Banana
Pi's own wiki/docs and board‑bring‑up threads on the Banana Pi forum, the
console UART is consistently the header's:

- **Pin 8 — UART TX** (board transmits, wire to your adapter's **RX**)
- **Pin 10 — UART RX** (board receives, wire to your adapter's **TX**)
- **Any GND pin** on the header (e.g. pin 6, 9, 14, 20, 25, 30, 34, 39) —
  common ground between the board and the adapter is required.

Some Banana Pi boards in the same family additionally break the console
UART out to its own small dedicated header (silkscreened `CON3`/`CON4` on
various models) instead of, or in addition to, the 40‑pin GPIO header —
check your specific board's silkscreen/manual, since Banana Pi's own docs
note this varies by model/revision.

**⚠️ Electrical warning:** this is a **3.3 V TTL/logic‑level UART**, the
same convention as a Raspberry Pi's GPIO header — **not RS‑232**. RS‑232
uses ±3–15 V signaling and *will* damage the board's UART pins if wired
directly. Use a **USB‑to‑TTL/UART adapter** (FTDI, CP2102, CH340, etc.),
never a USB‑to‑RS‑232 adapter, and double check the adapter is set/wired
for 3.3 V, not 5 V, since 5 V‑only adapters can also damage the 3.3 V‑only
GPIO pins.

**Default console settings** (also just the app's default — every field is
user‑changeable in Settings): **115200 baud, 8 data bits, no parity, 1 stop
bit, no flow control** — the standard Armbian/Linux serial‑console
configuration used across Allwinner‑based boards including this one.

## Architecture

Nothing lives in the Activity; it's a thin host. Everything else is split
by responsibility so each piece can be read/tested/changed independently:

| Package | Responsibility |
|---|---|
| `usb/` | `UsbSerialManager` — device discovery + attach/detach/permission broadcasts. `SerialPortController` — opens/configures a port, runs the read loop, software XON/XOFF pacing. |
| `serial/` | `SerialSettings` — baud/data bits/stop bits/parity/flow‑control/DTR/RTS model. Pure data, no Android/USB dependency. |
| `terminal/` | `TerminalEmulator` + `TerminalBuffer` — a from‑scratch ANSI/VT100‑ish byte‑stream parser and screen/scrollback grid, with zero Android dependency (feed it bytes from anywhere). `KeyEncoder` — special‑key‑to‑byte‑sequence mapping (arrows, Ctrl combos, function keys, ...). |
| `viewmodel/` | `TerminalViewModel` — wires USB + serial + terminal together behind `StateFlow`s; the only place that knows about all three. |
| `ui/` | Compose screens: `MainScreen`, `ConnectionBar` (status/device picker/connect), `TerminalView` (the rendered canvas + scroll + selection), `KeyToolbar`, `SerialSettingsDialog`. |

### What was (and wasn't) ported from PuTTY

PuTTY's serial backend (`unix/uxser.c`) and its config model were used as
the reference for *which* serial parameters matter and their standard
value sets (baud/data bits/stop bits/parity/flow‑control options, and
behaviors like DEC application‑cursor‑key mode toggling terminal.c
tracks). `TerminalEmulator` is an original implementation covering the
practical xterm/VT100 subset real shells use (colors via SGR, cursor
movement, screen/line erase, scroll regions, the alternate screen buffer
used by vim/htop/less, save/restore cursor, cursor‑position reports) —
it's not a line‑by‑line port of `terminal.c`, and PuTTY's SSH/Telnet/
proxy/GUI‑specific code was not touched at all, per the brief.

## Building

Use the provided `Build_Uart_terminal.ipynb` Colab notebook — unzip this project as `Uart_terminal/` and run the
notebook top to bottom. It installs JDK 17, the Android SDK platform 35 + build‑tools 35.0.0, and Gradle 8.7,
generates a signing key, then runs `gradle assembleDebug assembleRelease` and downloads the **release APK** (the one
to install and keep), the debug APK and the keystore.
This project targets **Android Gradle Plugin 8.6.1**, which is the AGP
line whose *minimum and default required Gradle version is 8.7* — i.e.
it matches what the notebook installs — while still supporting
`compileSdk 35` (AGP 8.6's maximum supported API level). Kotlin is pinned
to 1.9.24 with Compose compiler 1.5.14, the matching pair per Google's
Compose‑Kotlin compatibility map. The `usb-serial-for-android` library
(FTDI/CP210x/CH340/PL2303/CDC‑ACM drivers) is pulled from JitPack, which
`settings.gradle` already points at.

### Release signing

`app/build.gradle` signs the release build with your own key when `UART_TERMINAL_KEYSTORE` (path),
`UART_TERMINAL_KEYSTORE_PASSWORD`, `UART_TERMINAL_KEY_ALIAS` and `UART_TERMINAL_KEY_PASSWORD` are set (the notebook
sets them). Without them the release build falls back to the debug key, as it always did. The release type keeps R8
shrinking on (`minifyEnabled true`, `shrinkResources true`). An APK signed with a different key cannot upgrade an
existing install in place (uninstall first), so keep the keystore and its password if you want later builds to
upgrade over this one. The application id stays `com.uartbridge.terminal`; only the display name is "Uart terminal".

## Known limitations / simplifications

- **No local echo, by design** — a real serial console has the far end
  (getty/bash) echo your keystrokes back, exactly like PuTTY's serial
  backend and every other real terminal; the app doesn't duplicate typed
  characters itself.
- **No live remote resize signaling** — there's no side channel on a
  plain UART to tell the far end "the terminal is now NxM" the way an
  SSH pty does; this is a limitation of raw serial consoles in general
  (PuTTY's serial backend has the same limitation), not something this
  app regressed. If output looks wrapped wrong after rotating the
  screen, `stty rows R cols C` on the Banana Pi side fixes it for that
  session.
- **DEC line‑drawing character sets aren't remapped** — plain ASCII/UTF‑8
  rendering only; most modern shells default to UTF‑8 box‑drawing
  characters anyway, so this mostly matters for very old `TERM=vt100`
  configurations.
- **Hardware RTS/CTS** is requested from the underlying USB‑serial driver
  on a best‑effort basis (not every chip family in
  `usb-serial-for-android` implements it); DTR/RTS lines and software
  XON/XOFF pacing always work regardless. The Banana Pi's own console
  default is no flow control, so this mainly matters for other UART
  peripherals.
- **Text selection** uses long‑press to start and drag to extend, on the
  same touch stream used for scroll‑by‑drag; on some devices a very slow
  press‑and‑drift can be interpreted as a scroll instead of a selection —
  a firm long‑press before dragging is most reliable.
