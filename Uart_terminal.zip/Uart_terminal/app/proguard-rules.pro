# Add project specific ProGuard rules here.
# Rules for the minified (R8) release build.

# usb-serial-for-android uses reflection to enumerate driver classes.
-keep class com.hoho.android.usbserial.** { *; }

# Keep crash-report stack traces readable.
-keepattributes SourceFile,LineNumberTable
-keep class com.uartbridge.terminal.crash.** { *; }
