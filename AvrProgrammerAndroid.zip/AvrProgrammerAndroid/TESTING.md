# Testing

## What's covered today

| Area | Test file | What it checks |
|---|---|---|
| Intel HEX parsing/writing | `memory/IntelHexTest.kt` | Data records, EOF requirement, checksum validation, overlap detection, extended linear addressing, write→parse round trip, binary round trip, oversized-binary rejection |
| Device signature matching | `device/DeviceDatabaseTest.kt` | Correct part for a known signature, case-insensitive id lookup, unknown signature returns null (not a guess), no duplicate signatures in the table |
| USBasp protocol (packet encoding + full flow) | `protocol/usbasp/UsbaspProgrammerTest.kt` + `MockUsbaspTransport.kt` | Connect/program-enable sequence succeeds, signature read matches the simulated device, chip erase fills flash with 0xFF, a 512-byte flash write/read round-trips correctly across three 200-byte USB transfers (`USBASP_WRITEBLOCKSIZE`) |

`MockUsbaspTransport` is a from-scratch simulation of USBasp firmware
behavior (connect/capabilities/program-enable/ISP-passthrough/paged
read-write), built directly against the same function IDs `UsbaspProgrammer`
sends -- it's what makes the protocol testable without physical hardware
(brief section 21).

## Not yet covered (because the corresponding feature isn't implemented)

Per PROGRAMMERS.md/PROTOCOLS.md: STK500/v1/v2 packet tests, AVRISP/mkII
packet tests, fuse operation tests. Adding these makes sense once (and not
before) the corresponding protocol module is actually ported -- a test suite
for a protocol nothing implements would just be scaffolding around nothing.

## Running tests

Locally: `gradle test` (or via Android Studio's test runner). In the Colab
build notebook: the "Run unit tests" cell runs `gradle test` before the APK
build, and the build notebook is written to fail loudly (not silently
continue) if a test fails.

## Manual/hardware testing

Section 22 of the project brief calls for a hardware-test mode; that's what
`UsbHostManager.listDevices()` + `UsbDeviceInfo.endpointSummaries` are for --
plug in any USB device (not just a recognized programmer) and its
VID/PID/manufacturer/product/serial/interfaces/endpoints are all available
for display. `MainActivity`'s current "Detect USB Devices" button logs this
to the on-screen log view; a dedicated hardware-test screen is a reasonable
follow-up but isn't built as its own Activity yet.
