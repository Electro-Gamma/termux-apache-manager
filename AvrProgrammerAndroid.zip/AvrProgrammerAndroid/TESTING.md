# Testing

## What's covered

| Area | Test class | Notes |
|---|---|---|
| Intel HEX parsing/writing | `memory/IntelHexTest.kt` | Data records, checksum validation, missing-EOF rejection, overlap rejection, extended linear address, binary round-trip |
| Device database | `device/DeviceDatabaseTest.kt` | Signature lookup for known parts, unknown-signature returns null (never guesses), id lookup is case-insensitive, every entry has a unique id + 3-byte signature |
| USBasp protocol framing | `protocol/usbasp/UsbaspPacketTest.kt` | `open()` command ordering (capabilities -> SCK -> connect -> enable), signature read, chip erase (clears mock flash + re-enables), multi-block write/read round-trip, one `FUNC_SETLONGADDRESS` per USBasp 200-byte block |
| STK500v1 protocol framing | `protocol/stk500v1/Stk500v1PacketTest.kt` | `open()` command ordering (sync -> enter progmode), signature read, chip erase (clears mock flash + re-syncs), single- and multi-page flash write/read round-trip, EEPROM byte-addressing round-trip, extended addressing (`0x4d` load-ext-addr) for flash over 64K words (ATmega2560) |

All of the above run as plain JVM unit tests (`app/src/test/...`) via
`gradle test` -- no emulator or physical hardware required, because protocol
code depends only on the `UsbTransport` / `SerialTransport` interfaces
(`usb/UsbTransport.kt`, `usb/SerialTransport.kt`), not `android.hardware.usb.*`
or `usb-serial-for-android` directly. `protocol/usbasp/MockUsbTransport.kt`
and `protocol/stk500v1/MockStk500v1Transport.kt` are small in-memory firmware
simulators built only for these tests.

## What's not covered

```
FEATURE: Instrumented / on-device tests
STATUS: NOT IMPLEMENTED
REASON: androidTest dependencies (androidx.test.ext:junit, espresso-core) are declared in
        app/build.gradle.kts, but no androidTest sources exist yet -- UI flows (MainActivity)
        are exercised manually, not via Espresso.
AVRDUDE SOURCE REFERENCE: n/a

FEATURE: Real-hardware USBasp test
STATUS: NOT IMPLEMENTED
REASON: This sandbox has no physical USBasp device or Android device attached; UsbaspProgrammer
        has only been exercised against MockUsbTransport, not real USB traffic.
AVRDUDE SOURCE REFERENCE: n/a

FEATURE: Real-hardware STK500v1 test
STATUS: NOT IMPLEMENTED
REASON: This sandbox has no physical Android device or USB-serial adapter attached;
        Stk500v1Programmer has only been exercised against MockStk500v1Transport, not a real target.
AVRDUDE SOURCE REFERENCE: n/a

FEATURE: STK500v2/AVRISP mkII/JTAG packet parsing tests (brief section 21 asks for these)
STATUS: NOT IMPLEMENTED
REASON: These protocols themselves aren't implemented yet (see PROGRAMMERS.md); there is nothing
        to unit-test until the corresponding Programmer classes exist.
AVRDUDE SOURCE REFERENCE: src/stk500v2.c, src/jtagmkII.c, src/jtag3.c

FEATURE: Fuse operation tests
STATUS: NOT IMPLEMENTED
REASON: No fuse read/write implementation exists yet (see PROTOCOLS.md).
AVRDUDE SOURCE REFERENCE: n/a
```

## Running

```
cd AvrProgrammerAndroid
gradle test                       # all unit tests
gradle test --tests "*IntelHex*"  # one class
```

(Substitute `./gradlew` if you've generated a wrapper locally -- see
`BUILD.md`.) The Colab notebook (`build_avr_android.ipynb`) runs `gradle
test` automatically before `assembleDebug`, and its cell is expected to fail
loudly (not skip) if a test fails.
