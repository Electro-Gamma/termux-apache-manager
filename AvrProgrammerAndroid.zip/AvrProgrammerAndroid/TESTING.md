# Testing

## Running the tests

```
cd AvrProgrammerAndroid
gradle test                 # or ./gradlew test once the wrapper JAR is present, see BUILD.md
```

All tests are plain JVM unit tests (`app/src/test/`) -- no device, emulator,
or Robolectric required. That was a deliberate design constraint: see
`util/MiniJson.kt`'s doc comment for why the device database parser
specifically avoids `org.json` (which is a non-functional stub outside a real
Android runtime or Robolectric), so that "device signature matching" testing
doesn't silently become untestable.

## What's covered

| Area (per project brief section 21) | Test file |
|---|---|
| Intel HEX parsing, generation, checksums | `hex/IntelHexTest.kt` |
| Programmer command encoding / protocol packet parsing (opcode engine) | `device/OpcodeEngineTest.kt` |
| Device signature matching | `device/DeviceDatabaseTest.kt` |
| Memory addressing, page calculations | `memory/MemoryImageTest.kt` |
| USBasp packets | `programmer/usbasp/UsbaspProtocolTest.kt` |
| STK500 packets (v1) | `programmer/stk500v1/Stk500v1ProtocolTest.kt` |
| Fuse operations | Exercised via `OpcodeEngineTest`'s fuse-opcode cases (`write efuse only touches its 3 low bits`, etc.) |
| (JSON parsing, supporting infrastructure) | `util/MiniJsonTest.kt` |
| Verification / report format | `verify/VerifierTest.kt` |

**Not covered**: STK500v2/AVRISP mkII packet parsing, JTAG packet parsing --
these protocols aren't implemented (see PROTOCOLS.md), so there's nothing to
test.

## Mock transports

Per project brief section 21 ("create mock transports so protocols can be
tested without physical hardware"):

- **`MockUsbTransport`** (`app/src/main/java/.../transport/MockUsbTransport.kt`)
  -- a pure-Kotlin fake of `UsbTransport` with a caller-supplied control-transfer
  handler function, so a test can script exact request/response pairs and
  assert on exactly what bytes a programmer sent. Used by `UsbaspProtocolTest`.
  Deliberately shipped in `main/` rather than `test/` since it's a reusable
  test double for *any* future USB-based programmer's tests, not
  USBasp-specific.
- **`FakeSerialTransport`** (test-only, in `programmer/stk500v1/`) -- a
  responder-driven fake of `SerialTransport`: every `write()` call is
  immediately answered by a caller-supplied function, whose returned bytes
  feed subsequent `read()` calls. This is what makes it possible to correctly
  exercise STK500v1's "send GET_SYNC and drain twice, then loop" resync dance
  in a fast, deterministic, single-threaded test -- see its doc comment.

## How correctness was cross-checked, not just asserted

The riskiest correctness surface in this project is `Opcode.kt`'s bit-position
math (which physical bit of which byte a given address/input/output bit lands
on). Rather than trust a single derivation, every test-vector byte sequence in
`OpcodeEngineTest` was independently computed with a small standalone Python
script during development (reimplementing the same bit-math from scratch) and
matched byte-for-byte before being written into the Kotlin test file -- see
AVRDUDE_PORTING.md's testing notes. This caught a real bug (an inverted
byte/bit-index formula) before it reached the committed source; the derivation
comment at the top of `Opcode.kt` documents the corrected math.

Intel HEX test fixtures were likewise checksum-computed with a script rather
than hand-typed, since a wrong-by-one checksum byte is exactly the kind of
error that's easy to introduce by hand and easy to overlook by eye.

## What a real device/emulator run would additionally need

This project's test suite deliberately covers everything that doesn't require
actual hardware. Confirming the USB Host + real-chip path end-to-end (does a
genuine USBasp actually accept these exact control transfers; does a real
ATmega328P actually respond the way the mock assumes) needs physical hardware
and is out of scope for an automated test suite -- see BUILD.md's note on
verification.
