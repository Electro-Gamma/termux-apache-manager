# AVR Programmer for Android

A native Kotlin Android application that talks to AVR ISP/SPI programmers
(USBasp, USBtinyISP, STK500v1 / Arduino-as-ISP) over Android USB Host, using a
programming engine architecturally based on [AVRDUDE](https://github.com/avrdude/avrdude) --
same opcode-template mechanism, same device database provenance, same protocol
framing -- reimplemented from scratch in Kotlin rather than wrapping the AVRDUDE
binary or translating its C source line-by-line.

No root, no Termux, no bundled `avrdude` executable, no native code. Everything
runs directly inside the app.

## What actually works right now

| Programmer | Status |
|---|---|
| **USBasp** | Full SPI/ISP mode: signature, chip erase, flash/EEPROM read+write+verify, fuses, lock bits, calibration byte |
| **USBtinyISP** | Same, full SPI/ISP mode |
| **STK500 v1 / Arduino as ISP** | Same, over a USB CDC-ACM serial link (covers stock Arduino Uno/Nano/Mega boards) |

Everything else AVRDUDE supports -- STK500v2, AVRISP mkII, JTAGICE mkII/3,
Atmel-ICE, AVR Dragon, STK600, UPDI/PDI/TPI (modern tinyAVR/megaAVR-0/AVR
Dx/XMEGA), bit-bang/parallel programmers, vendor USB-serial chips (FTDI/CP210x/
CH340) -- is **not implemented**, and says so explicitly in the app (see
[PROGRAMMERS.md](PROGRAMMERS.md) and [PROTOCOLS.md](PROTOCOLS.md) for the full
list with reasons) rather than silently pretending to work. See
[AVRDUDE_PORTING.md](AVRDUDE_PORTING.md) for why this subset, and what a next
pass would tackle first.

The device database ships ~29 real AVR parts (ATmega328P/328/168/88/48/8/32/16/
64/128/2560/2561/32U4/32U2, the AT90USB family, several ATtiny parts) with
signatures, memory sizes, and ISP opcode templates extracted directly from
AVRDUDE's own `avrdude.conf.in` -- see [DEVICE_DATABASE.md](DEVICE_DATABASE.md).

## Building it

The project is a normal Android Studio project (`AvrProgrammerAndroid/`) -- open
it directly, or build headlessly with the bundled
[`build_avr_android.ipynb`](build_avr_android.ipynb) Google Colab notebook. See
[BUILD.md](BUILD.md) for both paths and exact toolchain versions.

## Using it

1. Launch the app, connect a USBasp/USBtinyISP/Arduino-running-ArduinoISP over
   USB OTG, tap **Detect USB Devices**.
2. Pick the programmer and target part (or leave **Auto Detect** -- the engine
   reads the chip's signature and matches it against the device database).
3. Pick a `.hex`/`.bin`/`.elf` firmware file, choose Erase/Write/Verify, tap
   **PROGRAM**.
4. The overflow menu has **Hardware Test** (raw USB device/interface/endpoint
   inspection, for debugging a programmer this app doesn't recognise), a
   **Fuse/Lock Editor** (every write requires an explicit confirmation dialog),
   a full **Log Viewer** with export, **Settings**, and **Third-Party
   Licenses**.

## Documentation map

- [AVRDUDE_PORTING.md](AVRDUDE_PORTING.md) -- which AVRDUDE source file maps to which Kotlin file, and the porting approach/licensing rationale
- [PROGRAMMERS.md](PROGRAMMERS.md) -- every programmer AVRDUDE supports, with implementation status
- [PROTOCOLS.md](PROTOCOLS.md) -- every protocol family, with implementation status
- [USB_SUPPORT.md](USB_SUPPORT.md) -- how Android USB Host is used, and its limits
- [DEVICE_DATABASE.md](DEVICE_DATABASE.md) -- device data provenance and how to extend it
- [BUILD.md](BUILD.md) -- Android Studio and Colab build instructions
- [TESTING.md](TESTING.md) -- what's unit-tested and how to run it
- [THIRD_PARTY_LICENSES.md](THIRD_PARTY_LICENSES.md) -- licensing (this project is GPLv2, see rationale)

## License

GNU General Public License v2 -- see [LICENSE](LICENSE) and
[THIRD_PARTY_LICENSES.md](THIRD_PARTY_LICENSES.md) for why.
