# AVR Programmer for Android

A native Kotlin/Android AVR programmer, built by studying and porting the
protocol/device-database logic of [AVRDUDE](https://github.com/avrdudes/avrdude)
(GPLv2). It talks to a programmer over Android's USB Host APIs and speaks the
real device-side protocol directly -- there is no `avrdude` binary anywhere in
this app, no shelling out, no Termux, no root.

## Status: Phase 1 + 2 of 6 (see project brief section 30)

This is **not** the full AVRDUDE feature set. It is a real, working, non-mocked
slice of it:

| Capability | Status |
|---|---|
| USB Host enumeration, permissions, control transfers | **Implemented** |
| Intel HEX + binary parsing/writing | **Implemented** |
| Device database (26 common classic-AVR parts) | **Implemented** (partial -- see DEVICE_DATABASE.md) |
| USBasp programmer (ISP mode: signature, erase, flash, EEPROM, verify) | **Implemented** |
| USBtinyISP, AVRISP mkII, JTAGICE mkII/3, STK500/v2, Arduino-as-ISP, SerialUPDI | **Not implemented** -- descriptors only, see PROGRAMMERS.md |
| Fuse/lock bit read-write, UPDI/PDI/TPI/JTAG programming | **Not implemented** -- see PROTOCOLS.md |

Why so scoped: the real AVRDUDE source tree this project was ported from is
~420,000 lines across 176 files in `src/`, implementing 50+ programmers across
half a dozen unrelated wire protocols (ISP, STK500v1/v2, JTAG mkI/II/3, UPDI,
PDI, TPI, debugWire, DFU...). Faithfully porting all of that, for real, is a
multi-month effort. This project ports one protocol completely and honestly
rather than faking many -- see the brief's own section 29/31 requirement to
never report unimplemented functionality as working.

## What's real here

- **USBasp is a faithful protocol port**, not a simplified stand-in. Every
  function ID, VID/PID, and command framing in
  `protocol/usbasp/UsbaspConstants.kt` and `UsbaspProgrammer.kt` was read
  directly out of AVRDUDE's `src/usbasp.h` / `src/usbasp.c`. See
  AVRDUDE_PORTING.md for the line-by-line mapping.
- **Device signatures and memory sizes** in `device/DeviceDatabase.kt` were
  read out of `src/avrdude.conf.in`'s `part` blocks (including resolving
  `parent` inheritance where needed) -- not guessed or approximated.
- **The USB Host layer** (`usb/`) does its own enumeration, permission
  handshake, and endpoint discovery against `android.hardware.usb.*` -- it
  does not assume a fixed interface/endpoint layout.
- **Unit tests** exercise the Intel HEX parser and the full USBasp protocol
  (connect → program-enable → chip-erase → paged flash write/read) against a
  `MockUsbaspTransport` that models real firmware responses, so the protocol
  logic is verified without needing physical hardware.

## Building an APK

See BUILD.md, or just run `build_avr_android.ipynb` in Google Colab -- same
upload-zip / run-cells / download-APK flow as your `Build_TCP_UART_Bridge.ipynb`
example, adapted for this project (Gradle 8.7, JDK 17, Android SDK 35).

## Project layout

```
app/src/main/java/com/avrprog/android/
  log/        Structured logging (ERROR..TRACE) + raw USB trace capture
  error/      AvrDudeException hierarchy (programmer/protocol/command/expected/received)
  memory/     MemoryImage, Intel HEX + binary parsing/writing
  device/     AvrDevice model + DeviceDatabase (ported avrdude.conf subset)
  usb/        UsbTransport interface, AndroidUsbTransport, UsbHostManager
  protocol/   Programmer interface, ProgrammerRegistry, protocol/usbasp/*
  engine/     AvrDudeEngine -- the -c/-p/-P/-U-style command model
  ui/         MainActivity (thin UI shell over the engine)
app/src/test/java/com/avrprog/android/   Unit tests + MockUsbaspTransport
```

## Documentation

- [AVRDUDE_PORTING.md](AVRDUDE_PORTING.md) -- source-module-to-Kotlin mapping
- [PROGRAMMERS.md](PROGRAMMERS.md) -- programmer status table
- [PROTOCOLS.md](PROTOCOLS.md) -- protocol status table
- [USB_SUPPORT.md](USB_SUPPORT.md) -- USB Host implementation notes
- [DEVICE_DATABASE.md](DEVICE_DATABASE.md) -- device database scope/sourcing
- [BUILD.md](BUILD.md) -- building locally or via Colab
- [TESTING.md](TESTING.md) -- what's tested and how
- [THIRD_PARTY_LICENSES.md](THIRD_PARTY_LICENSES.md) -- AVRDUDE (GPLv2) attribution

## License

This project incorporates protocol constants and device-database values
derived from AVRDUDE, which is licensed under the GNU GPL v2 (see `COPYING`).
As a derivative work, this project is distributed under the same license --
see THIRD_PARTY_LICENSES.md for what's derived and AVRDUDE_PORTING.md for
exactly where from.
