# AvrProgrammerAndroid

A native Kotlin Android app that speaks AVR programmer protocols directly,
modeled on [AVRDUDE](https://github.com/avrdude/avrdude)'s architecture:
USB Host-based transport, a protocol layer per programmer, a device database,
Intel HEX support, and a small internal command engine that mirrors AVRDUDE's
`-c/-p/-P/-U` CLI shape.

**Status: Phase 1 + 2 of the project's own six-phase plan (see
`AVRDUDE_PORTING.md`).** Two programmers are fully, really implemented
against real hardware protocol semantics ported from AVRDUDE's source:
**USBasp** (`src/usbasp.c`/`usbasp.h`, USB control transfers) and
**STK500 (v1)** (`src/stk500.c`, serial over any USB-UART adapter). Everything
else described in the original project brief (STK500v2, AVRISP mkII,
Arduino-as-ISP, JTAG, UPDI/PDI/TPI, ...) is scaffolded as a real, sourced
descriptor in `ProgrammerRegistry` but **not** implemented -- see
`PROGRAMMERS.md` for the exact status of each one. This is a deliberate
choice: a from-scratch, faithful reimplementation of AVRDUDE's full 50+
programmer / device family matrix is a multi-month effort even for AVRDUDE's
own maintainers (`src/` alone is ~176 files / ~420k lines); shipping that as
working code in one pass isn't achievable, and stubbing it out with fake
responses would violate the project brief's own rule against fake/mock
programmers. What's here is real and testable; what isn't is documented, not
faked.

## What works today

- USB Host device enumeration, permission handling, and connection lifecycle
  (`usb/UsbHostManager.kt`), with a generic (not hardcoded) interface/endpoint
  scan (`usb/AndroidUsbTransport.kt`).
- Full USBasp protocol: connect, program-enable, chip erase, signature read,
  paged flash/EEPROM read and write, SCK speed configuration
  (`protocol/usbasp/UsbaspProgrammer.kt`).
- Full STK500 (v1) protocol over any USB-UART adapter (CH340/CH341, CP210x,
  FTDI, PL2303, CDC-ACM -- via `usb-serial-for-android`): sync, program mode,
  chip erase, signature read, paged flash/EEPROM read and write with
  extended addressing for flash over 64K words
  (`protocol/stk500v1/Stk500v1Programmer.kt`, `usb/UsbSerialTransport.kt`,
  `usb/SerialDeviceScanner.kt`).
- A device database of ~26 common classic-AVR parts with real signatures and
  memory geometry sourced from AVRDUDE's `avrdude.conf.in` (`device/`).
- A robust Intel HEX parser/writer with checksum, overlap, and EOF validation,
  plus binary <-> memory-image conversion (`memory/IntelHex.kt`).
- A command-engine (`engine/AvrDudeEngine.kt`) the UI drives instead of
  touching USB/protocol code directly.
- A real Android UI: auto-detect or manually pick a programmer, read the
  signature, identify the part, erase, and write+verify a `.hex` file from
  the file picker.
- Structured, leveled logging with raw USB/serial frame tracing (`log/Logger.kt`).
- Structured exceptions carrying programmer/protocol/command/expected/
  received context (`error/AvrDudeException.kt`).
- Unit tests for the HEX parser, the device database, and USBasp + STK500v1
  packet framing against mock transports (no hardware required).

## What's explicitly not implemented yet

See `PROGRAMMERS.md` and `PROTOCOLS.md` for the full status tables. Briefly:
USBtinyISP, AVRISP/AVRISP mkII, STK500v2/600, Arduino-as-ISP, JTAG ICE
mkII/3, AVR Dragon, UPDI/PDI/TPI/XMEGA programming, fuse/lock-bit editing, and
ELF input are all unimplemented, along with STK500v1's bootloader/optiboot
and MIB510 variants. Each has a real `ProgrammerInfo` / documentation entry
rather than a fake button that does nothing.

## Building

See `BUILD.md`. Short version: open `build_avr_android.ipynb` in Google
Colab, run all cells, and it produces a debug APK the same way
`Build_TCP_UART_Bridge.ipynb` does (upload the project zip, build with
Gradle 8.7 + JDK 17 + Android SDK 35, download the APK).

## License

AVRDUDE is GPLv2 (`COPYING`). Because this project ports protocol constants
and device-database values directly out of AVRDUDE's source, it is a
derivative work and is therefore also distributed under GPLv2 -- see
`THIRD_PARTY_LICENSES.md`.

## Documentation index

- `AVRDUDE_PORTING.md` -- AVRDUDE source module -> Kotlin file mapping
- `PROGRAMMERS.md` -- per-programmer implementation status
- `PROTOCOLS.md` -- per-protocol implementation status
- `USB_SUPPORT.md` -- Android USB Host implementation notes
- `DEVICE_DATABASE.md` -- device table source mapping and how to extend it
- `BUILD.md` -- building locally or via Colab
- `TESTING.md` -- what's tested and how to run it
- `THIRD_PARTY_LICENSES.md` -- AVRDUDE and dependency licensing
