# Building

## Option A: Google Colab (recommended, no local Android toolchain needed)

Same pattern as the `Build_TCP_UART_Bridge.ipynb` reference notebook:

1. Zip this project folder (`AvrProgrammerAndroid.zip`) if it isn't already.
2. Open `build_avr_android.ipynb` in [Google Colab](https://colab.research.google.com).
3. Runtime -> Run all. The first cell asks you to upload the project zip.
4. The notebook installs JDK 17, the Android SDK (platform 35, build-tools
   35.0.0), and Gradle 8.7, then runs `gradle test` followed by
   `gradle assembleDebug`.
5. The resulting `app-debug.apk` is copied to `/content/output/` and offered
   as a browser download via `files.download()` -- on a phone browser this
   lands directly in Downloads, same as the TCP UART Bridge notebook.
6. Tap the downloaded APK to install (allow "install from this source" if
   prompted). It's a debug build, self-signed with Android's default debug
   key -- fine for sideloading on your own device.

## Option B: Android Studio

1. Open the `AvrProgrammerAndroid/` folder directly in Android Studio
   (Giraffe/2023.1 or newer, bundling AGP 8.5+ and JDK 17).
2. Let Gradle sync -- it will resolve `usb-serial-for-android` from JitPack
   (declared in `settings.gradle.kts`).
3. Build > Build Bundle(s) / APK(s) > Build APK(s), or `./gradlew assembleDebug`
   if you generate a Gradle wrapper locally (`gradle wrapper --gradle-version 8.7`
   from a system Gradle install -- this repo intentionally does not commit a
   wrapper jar; see the note below).

## Why there's no committed `gradlew`/wrapper jar

The Colab build pattern (mirroring `Build_TCP_UART_Bridge.ipynb`) downloads
Gradle 8.7 directly with `wget` and calls `gradle assembleDebug` rather than
`./gradlew assembleDebug`, so a wrapper jar isn't needed for that path. This
sandbox has no network access to fetch the real `gradle-wrapper.jar` binary,
so it's omitted rather than committed as a fake/placeholder file. If you want
`./gradlew` locally: install Gradle 8.7 once, then run
`gradle wrapper --gradle-version 8.7` inside the project root to generate a
real wrapper.

## Requirements

- JDK 17 (project's `compileOptions`/`kotlinOptions` target Java 17)
- Android SDK: platform 35, build-tools 35.0.0
- Gradle 8.7
- Network access to Google's Maven repo, Maven Central, and JitPack (for
  `usb-serial-for-android`)

## Running unit tests only

```
gradle test
```

Runs `IntelHexTest`, `DeviceDatabaseTest`, and `UsbaspPacketTest` -- see
`TESTING.md`. These are plain JVM unit tests (no Android device/emulator
needed) since the protocol and memory code depends only on the `UsbTransport`
interface, not `android.hardware.usb.*` directly.
