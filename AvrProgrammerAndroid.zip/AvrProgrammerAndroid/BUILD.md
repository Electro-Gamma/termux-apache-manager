# Building

## Toolchain versions (must match; see rationale below)

- JDK 17
- Android Gradle Plugin 8.5.2
- Gradle 8.7
- Kotlin 1.9.24
- compileSdk / targetSdk 35, minSdk 26

These are pinned together deliberately: AGP 8.5.x requires Gradle 8.7+, and
JDK 17 is AGP 8.5's minimum supported JDK. minSdk 26 (Android 8.0) was chosen
for solid USB Host + Kotlin coroutines support without excluding many real
devices.

## Option 1: Android Studio

1. Open the `AvrProgrammerAndroid/` folder directly in Android Studio
   (Iguana/2023.2+ recommended, for AGP 8.5 support).
2. Let Gradle sync. If Android Studio complains about the Gradle wrapper JAR
   being absent (see note below), either let it regenerate the wrapper
   (`File > Sync Project with Gradle Files` after pointing it at a local
   Gradle 8.7 install), or build with `gradle` directly as the Colab notebook
   does.
3. `Build > Make Project`, then `Run` on a connected device (USB Host /
   OTG-capable hardware required to actually use a programmer; the app
   installs and runs fine without it, it just can't talk to USB devices).

**Note on the Gradle wrapper**: `gradle/wrapper/gradle-wrapper.properties` is
present and points at Gradle 8.7, but the wrapper JAR binary itself
(`gradle/wrapper/gradle-wrapper.jar`) is not bundled in this source tree, since
it's a binary that needs to be fetched from a network Gradle isn't available
in this project's authoring environment to generate. Run `gradle wrapper`
once with a local Gradle 8.7+ install to generate it, or just use a system
Gradle install directly (`gradle assembleDebug`) as `build_avr_android.ipynb`
does -- both are equivalent for this project.

## Option 2: Google Colab (`build_avr_android.ipynb`)

For a from-scratch headless build with no local Android Studio install, run
[`build_avr_android.ipynb`](build_avr_android.ipynb) in Google Colab. It:

1. Reports the environment.
2. Installs JDK 17.
3. Downloads and installs the Android SDK command-line tools, platform 35,
   and build-tools 35.0.0.
4. Unpacks this project's source (uploaded as a zip -- see the notebook's
   first cell).
5. Downloads Gradle 8.7 directly (sidestepping the missing wrapper JAR noted
   above) and runs `gradle clean test assembleDebug` (unit tests, then the
   debug APK).
6. Copies the resulting APK to `/content/output/` and prints a clickable
   download link.

The notebook fails loudly (non-zero exit, visible in cell output) if any
dependency -- JDK, SDK components, Gradle, or the build itself -- can't be
installed or fails, per project brief section 26's "must fail clearly if a
required dependency is unavailable." See the notebook's own markdown cells
for exact commands and expected output at each step.

### A note on verification

This project was authored in an environment with no network access to
actually run `gradle assembleDebug` end-to-end, so **the Colab notebook (or a
local Android Studio build) is the real verification step**, not something
already confirmed successful during authoring. The Kotlin source was written
and cross-checked carefully (see AVRDUDE_PORTING.md's testing notes and the
opcode-engine bit-math derivation in `Opcode.kt`), and the unit test suite
(TESTING.md) runs under plain JVM JUnit without needing a device or emulator
-- but a first Colab/Android Studio run may still surface a Gradle
configuration or minor compile issue that only a real build environment would
catch. If it does, the fix is almost certainly local to one file, not
architectural.
