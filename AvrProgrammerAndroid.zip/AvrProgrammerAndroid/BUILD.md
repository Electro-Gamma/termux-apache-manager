# Building

## Option A: Google Colab (recommended, no local setup)

1. Download `AvrProgrammerAndroid.zip` (the whole project, zipped) from the
   chat.
2. Open `build_avr_android.ipynb` in [Google Colab](https://colab.research.google.com).
3. Runtime → Run all. The first cell asks you to upload
   `AvrProgrammerAndroid.zip`.
4. ~5-10 minutes later (mostly downloads: Android SDK, Gradle, dependencies)
   the notebook runs the unit tests, builds the debug APK, and downloads it
   straight to your device -- same flow as `Build_TCP_UART_Bridge.ipynb`.

This mirrors your existing notebook's structure deliberately: JDK 17 →
Android SDK cmdline-tools → licenses + platform/build-tools → Gradle 8.7 →
`gradle test` → `gradle assembleDebug` → locate + download the APK.

## Option B: Android Studio

1. Unzip `AvrProgrammerAndroid.zip`.
2. Open the folder in Android Studio (Giraffe/2023.1 or newer -- needs AGP
   8.5+ and JDK 17).
3. Let Gradle sync (it will resolve `usb-serial-for-android` from JitPack --
   `settings.gradle.kts` already declares that repository).
4. Run on a device with USB OTG support. The emulator cannot exercise the
   USB Host path -- you need a physical Android device and a USBasp
   programmer connected via an OTG adapter.

## Option C: Command-line Gradle

```
JAVA_HOME=/path/to/jdk-17 ANDROID_HOME=/path/to/android-sdk ./scripts/gradle -v
gradle test
gradle assembleDebug
```

(There is no committed `gradlew` wrapper JAR in this repo -- see the note in
`gradle/wrapper/gradle-wrapper.properties`. The Colab notebook installs
Gradle 8.7 directly instead, the same way `Build_TCP_UART_Bridge.ipynb`
does. If you want a committed wrapper for local/CI use, run
`gradle wrapper --gradle-version 8.7` once you have any Gradle available and
commit the generated `gradlew`/`gradlew.bat`/`gradle-wrapper.jar`.)

## Requirements

- JDK 17
- Android SDK: `platform-tools`, `platforms;android-35`, `build-tools;35.0.0`
- Gradle 8.7
- A physical Android device with USB Host (OTG) support to actually use the
  app -- the debug APK installs fine anywhere, but programming hardware
  needs real USB.

## Output

`app/build/outputs/apk/debug/app-debug.apk` -- self-signed with Android's
default debug key, fine for sideloading on your own device. A release build
needs your own signing keystore (not provided/generated here).
