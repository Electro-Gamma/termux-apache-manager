# USB Support

## Overview

The app uses Android's USB Host APIs directly (`android.hardware.usb.UsbManager`,
`UsbDevice`, `UsbInterface`, `UsbEndpoint`, `UsbDeviceConnection`) -- no native
code, no bundled driver, no root. See `<uses-feature android:name=
"android.hardware.usb.host" android:required="false"/>` in the manifest: the
app installs fine on devices without USB Host/OTG support, and reports that
clearly (`UsbHostTransport.isUsbHostSupported()`) rather than crashing when a
USB operation is attempted.

## What's implemented

- **Enumeration**: `UsbDeviceScanner.listAttachedDevices()` / `findByVidPid()`.
- **VID/PID detection**: `ProgrammerRegistry.findByVidPid()`, used both to
  auto-select a programmer implementation and to show a recognised-vs-unknown
  label in Hardware Test mode.
- **Interface detection**: `UsbDeviceScanner.pickPreferredInterface()` picks
  the vendor-specific interface for USBasp/USBtinyISP, or the CDC Data
  interface (not the CDC Communications control interface) for serial
  adapters -- see its doc comment for the full fallback order. The project
  brief explicitly warns not to assume every programmer uses the same
  interface/endpoint layout; this is why interface selection is a real
  decision point rather than a hardcoded `getInterface(0)`.
- **Endpoint detection**: `UsbHostTransport.buildDeviceInfo()` walks every
  interface's endpoints (address/direction/type/max packet size), surfaced
  directly in Hardware Test mode.
- **Permission handling**: `UsbPermissionManager` wraps Android's
  broadcast-based async permission flow behind a single `suspend fun
  requestPermission()`.
- **Control transfers**: `UsbTransport.controlTransfer()` -- used by USBasp
  and USBtinyISP for everything (both protocols are 100% control-transfer
  based; neither uses bulk endpoints at all, confirmed from their AVRDUDE
  source).
- **Bulk transfers**: `UsbTransport.bulkTransferIn/Out()` -- used by
  `CdcAcmSerialTransport` for the STK500v1/Arduino-as-ISP serial link.
- **Interrupt transfers**: `UsbTransport.interruptTransferIn()` is present in
  the transport interface (project brief section 3 asks for it explicitly),
  implemented via the same underlying `UsbDeviceConnection.bulkTransfer` call
  Android provides (the public API has no separate interrupt-transfer method;
  the endpoint's declared type is what makes a transfer an interrupt transfer
  at the USB protocol level, not a different host-side call). Not currently
  exercised by any implemented programmer -- USBasp/USBtinyISP/STK500v1 don't
  use interrupt endpoints -- but ready for one that does.
- **Attach/detach handling**: the manifest's `USB_DEVICE_ATTACHED` intent
  filter (backed by `res/xml/usb_device_filter.xml`, populated with real
  VID/PIDs from `usbdevs.h`) lets Android offer to launch the app directly
  when a known programmer is plugged in.
- **Connection cleanup**: every `Programmer.close()` implementation releases
  the claimed interface and closes the connection in a `finally` block, even
  if the protocol-level disconnect (USBasp `DISCONNECT`, USBtiny
  `POWERDOWN`, STK500 `LEAVE_PROGMODE`) itself fails.
- **USB reset**: `UsbHostTransport.softReset()` -- Android's public API has no
  raw port-reset call (unlike libusb's `usb_reset()`, which is what desktop
  AVRDUDE can use), so this is a close+reopen cycle, the closest portable
  equivalent, and documented as such in the code.

## What's NOT implemented, and why

- **Vendor USB-serial chips** (FTDI, CP210x, CH340/CH341): see
  PROGRAMMERS.md's explanation -- AVRDUDE itself relies on an OS kernel
  driver for these, which Android's USB Host framework doesn't provide an
  equivalent for. Only USB CDC-ACM (standards-based, no vendor driver needed)
  is implemented.
- **Bit-banged / parallel-port programmers**: no general-purpose USB-GPIO
  bit-banging surface exists in the Android USB Host API for arbitrary
  adapters.
- **Isochronous transfers**: not used by any AVR programmer protocol, so not
  implemented (the transport interface doesn't even declare a method for it).
