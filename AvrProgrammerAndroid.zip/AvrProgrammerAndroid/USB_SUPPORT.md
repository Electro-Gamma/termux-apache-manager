# USB Host support

## What's implemented

- **Enumeration**: `UsbHostManager.listDevices()` walks `UsbManager.deviceList`
  and returns vendor/product ID, manufacturer/product/serial strings, and a
  full interface/endpoint summary for every attached device (used by the
  hardware-test mode described in the brief section 22).
- **VID/PID detection**: `ProgrammerRegistry.matchByVidPid()` matches against
  real VID/PID pairs sourced from AVRDUDE (`AVRDUDE_PORTING.md`).
- **Permission handling**: `UsbHostManager.requestPermission()` wraps the
  `UsbManager.requestPermission()` + `ACTION_USB_PERMISSION` broadcast-receiver
  dance, targeting both pre- and post-Android-13 `registerReceiver` signatures
  and pre/post-Android-12 `PendingIntent` mutability flags.
- **Interface/endpoint detection**: `AndroidUsbTransport` scans every
  interface for bulk/interrupt endpoints rather than assuming interface 0 /
  endpoint 1 -- brief section 3 explicitly calls this out ("Do not assume
  that every programmer uses the same interface or endpoint layout").
- **Control transfers**: `AndroidUsbTransport.controlTransfer()` wraps
  `UsbDeviceConnection.controlTransfer()`; this is the only transfer type
  USBasp actually needs (it never claims a bulk endpoint).
- **Bulk transfers**: `AndroidUsbTransport.bulkTransfer()` is implemented and
  ready for programmers that need it (STK500v2-over-USB, AVRISP mkII), but
  nothing calls it yet since those protocols aren't implemented.
- **Cleanup**: `AndroidUsbTransport.close()` releases the claimed interface
  (if any) and closes the connection; `UsbHostManager.unregisterPermissionReceiver()`
  is called from `MainActivity.onDestroy()`.

## What's not implemented

```
FEATURE: USB device attach/detach live handling
STATUS: NOT IMPLEMENTED
REASON: The manifest declares a USB_DEVICE_ATTACHED intent-filter (auto-launch on plug-in), but there is
        no registered UsbManager.ACTION_USB_DEVICE_DETACHED receiver to gracefully close an in-progress
        session if the cable is pulled mid-operation.
AVRDUDE SOURCE REFERENCE: n/a (Android-specific gap, not an AVRDUDE porting gap)

FEATURE: USB reset
STATUS: NOT IMPLEMENTED
REASON: Android's UsbDeviceConnection has no public bus-reset API equivalent to libusb_reset_device();
        AVRDUDE's own USB reset handling (where present) relies on libusb, which has no Android analogue
        used here (this project deliberately avoids bundling libusb/native code per brief section 23).
AVRDUDE SOURCE REFERENCE: n/a

FEATURE: Interrupt transfers
STATUS: NOT IMPLEMENTED (endpoint detection is implemented; no programmer needing them is wired up yet)
REASON: No currently-implemented programmer (USBasp) uses interrupt endpoints; AndroidUsbTransport detects
        and would expose them, but nothing calls into that path.
AVRDUDE SOURCE REFERENCE: n/a

FEATURE: USB-UART chipset support (FTDI, CP210x, CH340/CH341, CDC-ACM)
STATUS: IMPLEMENTED (as a transport; used today by STK500 (v1))
REASON: app/build.gradle.kts depends on usb-serial-for-android, which supports all four chipset
        families. usb/UsbSerialTransport.kt wraps its UsbSerialPort as a SerialTransport, and
        usb/SerialDeviceScanner.kt asks the library's own prober whether an attached device is a
        recognized adapter at all (STK500v1 isn't identified by a fixed VID/PID the way USBasp is --
        any of these chipsets could be carrying it). Adapter *detection* (SerialDeviceScanner finding
        a CH340) has been confirmed on real hardware; the protocol implementation itself
        (Stk500v1Programmer) is unit-tested against a mock but not yet against a physical target --
        see TESTING.md.
AVRDUDE SOURCE REFERENCE: n/a (this is a host-OS driver concern; AVRDUDE relies on the kernel's own
        FTDI/CP210x/CH340 tty drivers on Linux/macOS/Windows, which Android does not expose the same way)
```

## Hardware-test / debug mode

`UsbHostManager.listDevices()` already returns everything the brief's
"hardware-test mode" (section 22) requires -- VID, PID, manufacturer,
product, serial, interface count, and a per-endpoint direction/type/max-packet-size
summary. A dedicated screen surfacing this list in the UI (rather than only
via the debug log) has not been built yet.
