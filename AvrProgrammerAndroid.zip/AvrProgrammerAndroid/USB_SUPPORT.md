# USB Support

## Host stack

`usb/UsbHostManager.kt` wraps `android.hardware.usb.UsbManager`:

- **Enumeration** -- `listDevices()` returns every attached device (not just
  recognized programmers), with manufacturer/product/serial and a
  per-endpoint summary (direction, type, max packet size), satisfying the
  hardware-test-mode requirement in brief section 22.
- **Permission handling** -- `requestPermission()` fires Android's USB
  permission dialog via a `PendingIntent` + dynamically registered
  `BroadcastReceiver`, and unregisters itself once resolved (or in
  `Activity.onDestroy()`) to avoid leaking the receiver.
- **Attach/detach** -- `AndroidManifest.xml` declares an intent filter for
  `USB_DEVICE_ATTACHED` against `res/xml/usb_device_filter.xml`, so plugging
  in a recognized programmer launches the app directly.
- **Connection cleanup** -- `AndroidUsbTransport.close()` releases any
  claimed interface and closes the `UsbDeviceConnection`; callers are
  expected to call it in a `finally`/`use`-style block (see `MainActivity`'s
  usage for the pattern; a stricter `Closeable` wrapper is a reasonable
  follow-up).

## Transfer types

- **Control transfers** -- fully implemented (`AndroidUsbTransport.controlTransfer`),
  and it's the only transfer type USBasp actually needs (it's an EP0-only
  protocol; see `UsbaspProgrammer`'s doc comment).
- **Bulk transfers** -- implemented (`AndroidUsbTransport.bulkTransfer`) for
  when a future serial-transport or bulk-endpoint programmer (AVRISP mkII,
  JTAGICE3) needs it; unused by USBasp today.
- **Interrupt transfers** -- the endpoint-discovery loop in
  `AndroidUsbTransport.init` recognizes `USB_ENDPOINT_XFER_INT` alongside
  bulk when picking an interface to claim, but no protocol in this phase
  issues interrupt transfers yet.

## Interface/endpoint layout

Per brief section 3 ("do not assume that every programmer uses the same
interface or endpoint layout"), `AndroidUsbTransport` scans every interface
on the device for the first one exposing bulk or interrupt endpoints, rather
than hardcoding e.g. "interface 0, endpoint 1". If no interface has any
(true for USBasp, which is control-transfer-only), the transport still works
-- it just never populates `inEndpoint`/`outEndpoint`.

## USB-UART chipsets (planned, not yet integrated)

`app/build.gradle.kts` already depends on
[usb-serial-for-android](https://github.com/mik3y/usb-serial-for-android)
(FTDI, CP210x, CH340/CH341, CDC-ACM) for the serial-transport programmers
listed as not-implemented in PROGRAMMERS.md (STK500v1/v2, Arduino as ISP,
SerialUPDI). No code in this phase uses it yet -- wiring a `UsbTransport`
adapter over that library's `UsbSerialPort` is the natural next step and is
called out as a limitation here rather than silently absent.
