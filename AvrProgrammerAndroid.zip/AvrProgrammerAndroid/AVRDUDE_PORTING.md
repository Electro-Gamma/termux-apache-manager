# AVRDUDE Porting Map

This document maps AVRDUDE C source modules (from the `avrdude-main.zip`
source tree analyzed for this project) to their Kotlin counterparts, per
project brief section 2 ("Create a source mapping document").

AVRDUDE source stats at the time of porting: 176 files, ~420,000 lines under
`src/`. This project ports a deliberately small slice of that in full fidelity
rather than a large slice superficially.

## Implemented mappings

| AVRDUDE source | Kotlin equivalent | Notes |
|---|---|---|
| `src/usbasp.h` (function IDs, VID/PID, SCK table) | `protocol/usbasp/UsbaspConstants.kt` | Constants copied 1:1 |
| `src/usbasp.c: usbasp_transmit()` | `UsbaspProgrammer.transmit()` | Same wValue/wIndex packing of a 4-byte "send" array |
| `src/usbasp.c: usbasp_initialize()` | `UsbaspProgrammer.open()` | get-capabilities → set SCK → connect → sleep(100ms) → program-enable |
| `src/usbasp.c: usbasp_spi_program_enable()` | `UsbaspProgrammer.programEnable()` | Same 1-byte/`0x00` success check |
| `src/usbasp.c: usbasp_spi_chip_erase()` | `UsbaspProgrammer.chipErase()` | Standard ISP chip-erase instruction (`0xAC 0x80 0x00 0x00`) + re-init |
| `src/usbasp.c: usbasp_spi_paged_load()` | `UsbaspProgrammer.readMemory()` | `FUNC_SETLONGADDRESS` + `FUNC_READFLASH`/`FUNC_READEEPROM`, 200-byte blocks |
| `src/usbasp.c: usbasp_spi_paged_write()` | `UsbaspProgrammer.writeMemory()` | Same block-flags-only-on-first-transfer behavior, `pageSize` packed into cmd[2]/cmd[3] |
| `src/usbasp.c: usbasp_spi_cmd()` | `UsbaspProgrammer.spiCmd()` | Generic 4-byte ISP command passthrough via `FUNC_TRANSMIT` |
| Standard AVR ISP "Read Signature Byte" instruction (every classic-AVR datasheet; also used by AVRDUDE's generic `stk500`/ISP paths, not `usbasp.c` specifically) | `UsbaspProgrammer.readSignature()` | `0x30 0x00 <index> 0x00` |
| `src/usbdevs.h` (`USBASP_SHARED_VID/PID`, `USBASP_OLD_VID/PID`, `USBASP_NIBOBEE_VID/PID`) | `UsbaspConstants.KNOWN_VID_PID` | All three pairs carried over; SHARED is primary |
| `src/avrdude.conf.in` (`part` blocks: `signature`, `memory "flash"/"eeprom" { size, page_size }`) | `device/DeviceDatabase.kt` | 26 parts, values read directly from the config (see DEVICE_DATABASE.md) |
| `src/avrdude.conf.in` (`programmer` blocks: `usbvid`/`usbpid`) | `protocol/ProgrammerRegistry.kt` descriptors | VID/PID for usbtiny, avrispmkII, jtagmkII, jtag3, dragon_isp/jtag, stk600 |

## Explicitly not ported (see PROTOCOLS.md / PROGRAMMERS.md for the required status format)

| AVRDUDE source | Why not yet |
|---|---|
| `src/usbasp.c` TPI functions (`usbasp_tpi_*`) | USBasp's TPI mode (ATtiny4/5/9/10-class parts) shares the transport but is a distinct command sequence; not wired into `Programmer` yet |
| `src/stk500.c`, `src/stk500v2.c`, `src/stk500generic.c` | STK500 v1/v2 are synchronous serial protocols requiring the USB-UART (usb-serial-for-android) integration this phase stops short of |
| `src/jtagmkI.c`, `src/jtagmkII.c`, `src/jtag3.c` | JTAG ICE mkI/II/3 framed command protocols -- separate, large modules |
| `src/serialupdi.c`, `src/updi_link.c`, `src/updi_nvm*.c` | UPDI link layer + NVM controller versions v0-v6 (megaAVR-0, AVR Dx families) |
| `src/butterfly.c`, `src/avr910.c` | Bootloader-resident serial protocols |
| `src/dfu.c` | USB DFU class driver for Xmega/others |
| `src/linuxspi.c` | Linux `/dev/spidev`-backed bit-bang programmer -- has no Android equivalent (documented limitation, not a missing feature to fake) |

## Licensing note

AVRDUDE is licensed under the GNU GPLv2 (`COPYING`, copied unmodified into
this project's root). The constants and device data ported above are a
derivative work under that license -- see THIRD_PARTY_LICENSES.md.
