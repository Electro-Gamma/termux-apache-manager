# AVRDUDE -> Kotlin source mapping

AVRDUDE source referenced: the `avrdude-main` tree supplied alongside this
project (176 files, ~420,000 lines under `src/`). This document maps the
AVRDUDE modules this project actually ported against to their Kotlin
counterparts, per the project brief's requirement to "create a source mapping
document."

## Implemented

| AVRDUDE source | What was ported | Kotlin file |
|---|---|---|
| `src/usbasp.h` (function IDs, SCK table, block sizes) | Constants, verbatim | `protocol/usbasp/UsbaspConstants.kt` |
| `src/usbdevs.h` (`USBASP_SHARED_VID/PID`, `USBASP_OLD_VID/PID`, `USBASP_NIBOBEE_VID/PID`) | VID/PID triples | `protocol/usbasp/UsbaspConstants.kt` |
| `src/usbasp.c: usbasp_transmit()` | 4-byte send array -> wValue/wIndex packing, IN/OUT direction bit | `UsbaspProgrammer.transmit()` |
| `src/usbasp.c: usbasp_initialize()` | getCapabilities -> set SCK -> connect -> sleep(100ms) -> program_enable sequence | `UsbaspProgrammer.open()` |
| `src/usbasp.c: usbasp_spi_program_enable()` | FUNC_ENABLEPROG framing + 1-byte/`res[0]==0` success check | `UsbaspProgrammer.programEnable()` |
| `src/usbasp.c: usbasp_spi_chip_erase()` | ISP chip-erase command dispatch + re-initialize afterward | `UsbaspProgrammer.chipErase()` |
| `src/usbasp.c: usbasp_spi_paged_load()` | FUNC_SETLONGADDRESS + FUNC_READFLASH/READEEPROM block loop, `USBASP_READBLOCKSIZE`=200 | `UsbaspProgrammer.readMemory()` |
| `src/usbasp.c: usbasp_spi_paged_write()` | FUNC_SETLONGADDRESS + FUNC_WRITEFLASH/WRITEEEPROM block loop, page-size/blockflags packing, `USBASP_WRITEBLOCKSIZE`=200 | `UsbaspProgrammer.writeMemory()` |
| `src/usbasp.c: usbaspSCKoptions[]` | SCK frequency identifier table | `UsbaspConstants` (`ISP_SCK_*`) |
| `src/avrdude.conf.in` (`part` blocks: `signature`, `memory "flash"/"eeprom" { size, page_size }`) | ~26 common classic-AVR device entries | `device/DeviceDatabase.kt` (see `DEVICE_DATABASE.md` for the per-part mapping) |
| `src/avrdude.conf.in` (`programmer` blocks: `usbvid`/`usbpid`) | VID/PID for USBasp, USBtinyISP, AVRISP mkII, JTAG ICE mkII, JTAGICE3, AVR Dragon, STK600 | `protocol/ProgrammerRegistry.kt` |
| Standard AVR ISP instruction set (documented identically in every classic-AVR datasheet, and used unmodified by AVRDUDE across all ISP programmers) | Read Signature Byte (`0x30 0x00 <i> 0x00`), Chip Erase (`0xAC 0x80 0x00 0x00`) | `UsbaspProgrammer.readSignature()`, `.chipErase()`, `Stk500v1Programmer.readSignature()`, `.chipErase()` |
| `src/fileio.c` (Intel HEX record types and validation rules, conceptually -- reimplemented independently in Kotlin, not transliterated) | Record types 00/01/02/03/04/05, checksum/overlap/EOF validation | `memory/IntelHex.kt` |
| `src/stk500_private.h` (command/response byte values) | Constants, verbatim (except `Cmnd_STK_CHIP_ERASE`, which the real driver doesn't use -- see below) | `protocol/stk500v1/Stk500v1Constants.kt` |
| `src/stk500.c: stk500_getsync()` | GET_SYNC retry loop (`MAX_SYNC_ATTEMPTS`=32), INSYNC/OK framing | `Stk500v1Programmer.getSync()` |
| `src/stk500.c: stk500_enter_progmode` (inline in `stk500_initialize`/`stk500_program_enable`) | ENTER_PROGMODE with NOSYNC retry-via-resync (33 tries) | `Stk500v1Programmer.enterProgMode()` |
| `src/stk500.c: stk500_cmd()` | Cmnd_STK_UNIVERSAL framing of a raw 4-byte ISP instruction | `Stk500v1Programmer.universalCmd()` |
| `src/stk500.c: stk500_chip_erase()` | Standard ISP chip-erase instruction via `stk500_cmd()`, not `Cmnd_STK_CHIP_ERASE` -- ported the actual behavior, not the unused header constant | `Stk500v1Programmer.chipErase()` |
| `src/stk500.c: stk500_loadaddr()` (non-bootloader / non-MIB510 branch) | LOAD_ADDRESS framing, `0x4d 00 ext 00` extended-address prefix for flash > 64K words | `Stk500v1Programmer.loadAddress()` |
| `src/stk500.c: stk500_paged_load()` / `stk500_paged_write()` (non-bootloader branch) | READ_PAGE/PROG_PAGE framing, `a_div` word/byte addressing (2 for flash, 1 for EEPROM), memtype char `'F'`/`'E'` | `Stk500v1Programmer.readMemory()` / `.writeMemory()` |
| `src/stk500.c: stk500_open()` (baud rate only; parity/stop-bit config is standard 8N1 for this protocol) | 115200 8N1 default | `usb/UsbSerialTransport.kt`, `Stk500v1Constants.DEFAULT_BAUD_RATE` |

## Explicitly not ported (see PROTOCOLS.md / PROGRAMMERS.md for status)

| AVRDUDE source | Why it's out of scope for this phase |
|---|---|
| `src/stk500v2.c`, `src/stk500generic.c` | STK500v2 is a distinct, CRC-framed protocol from v1 (see PROGRAMMERS.md) -- not yet ported, though the serial transport it would need (`usb-serial-for-android`) is already wired up for STK500v1 |
| `src/jtagmkI.c`, `src/jtagmkII.c`, `src/jtag3.c` | Atmel JTAG ICE command protocols, materially different framing from USBasp |
| `src/avr910.c` | avr910/butterfly bootloader protocol |
| `src/serialupdi.c`, `src/updi_link.c`, `src/updi_nvm*.c` | UPDI link layer + per-NVM-controller-version programming (tinyAVR 0/1/2, megaAVR 0, AVR Dx) |
| `usbasp.c`'s `USBASP_FUNC_TPI_*` path | TPI support for ATtiny4/5/9/10-class parts (constants exist in `UsbaspConstants`, unused) |
| `src/pickit5*.c`, Atmel-ICE-specific paths in `jtag3.c` | Newer Microchip debug-probe protocols |
| Fuse/lock-bit read-modify-write, calibration byte handling | Device database doesn't yet carry per-part fuse definitions |
| ELF input | Not implemented; only Intel HEX and raw binary are supported |

## Licensing note

AVRDUDE is licensed under the GNU GPL v2 (`COPYING`, copied unmodified from
the AVRDUDE source tree into this project's root). Because the files listed
under "Implemented" above copy protocol constants and device-database values
directly out of AVRDUDE's source, this project is a derivative work of
AVRDUDE and is distributed under GPLv2 as a whole -- see
`THIRD_PARTY_LICENSES.md`.
