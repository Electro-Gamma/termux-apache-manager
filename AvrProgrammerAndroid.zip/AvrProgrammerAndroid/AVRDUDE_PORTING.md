# AVRDUDE -> Kotlin source mapping

AVRDUDE source referenced: the `avrdude-main` tree supplied alongside this
project (176 files, ~420,000 lines under `src/`). This document maps the
AVRDUDE modules this project actually ported against to their Kotlin
counterparts, per the project brief's requirement to "create a source mapping
document."

## Implemented

| AVRDUDE source | What was ported | Kotlin file |
|---|---|---|
| `src/usbasp.h` (function IDs, SCK table, block sizes) | Constants, verbatim | `protocol/usbasp/UsbaspConstants.kt` |
| `src/usbdevs.h` (`USBASP_SHARED_VID/PID`, `USBASP_OLD_VID/PID`, `USBASP_NIBOBEE_VID/PID`) | VID/PID triples | `protocol/usbasp/UsbaspConstants.kt` |
| `src/usbasp.c: usbasp_transmit()` | 4-byte send array -> wValue/wIndex packing, IN/OUT direction bit | `UsbaspProgrammer.transmit()` |
| `src/usbasp.c: usbasp_initialize()` | getCapabilities -> set SCK -> connect -> sleep(100ms) -> program_enable sequence | `UsbaspProgrammer.open()` |
| `src/usbasp.c: usbasp_spi_program_enable()` | FUNC_ENABLEPROG framing + 1-byte/`res[0]==0` success check | `UsbaspProgrammer.programEnable()` |
| `src/usbasp.c: usbasp_spi_chip_erase()` | ISP chip-erase command dispatch + re-initialize afterward | `UsbaspProgrammer.chipErase()` |
| `src/usbasp.c: usbasp_spi_paged_load()` | FUNC_SETLONGADDRESS + FUNC_READFLASH/READEEPROM block loop, `USBASP_READBLOCKSIZE`=200 | `UsbaspProgrammer.readMemory()` |
| `src/usbasp.c: usbasp_spi_paged_write()` | FUNC_SETLONGADDRESS + FUNC_WRITEFLASH/WRITEEEPROM block loop, page-size/blockflags packing, `USBASP_WRITEBLOCKSIZE`=200 | `UsbaspProgrammer.writeMemory()` |
| `src/usbasp.c: usbaspSCKoptions[]` | SCK frequency identifier table | `UsbaspConstants` (`ISP_SCK_*`) |
| `src/avrdude.conf.in` (`part` blocks: `signature`, `memory "flash"/"eeprom" { size, page_size }`) | ~26 common classic-AVR device entries | `device/DeviceDatabase.kt` (see `DEVICE_DATABASE.md` for the per-part mapping) |
| `src/avrdude.conf.in` (`programmer` blocks: `usbvid`/`usbpid`) | VID/PID for USBasp, USBtinyISP, AVRISP mkII, JTAG ICE mkII, JTAGICE3, AVR Dragon, STK600 | `protocol/ProgrammerRegistry.kt` |
| Standard AVR ISP instruction set (documented identically in every classic-AVR datasheet, and used unmodified by AVRDUDE across all ISP programmers) | Read Signature Byte (`0x30 0x00 <i> 0x00`), Chip Erase (`0xAC 0x80 0x00 0x00`) | `UsbaspProgrammer.readSignature()`, `.chipErase()` |
| `src/fileio.c` (Intel HEX record types and validation rules, conceptually -- reimplemented independently in Kotlin, not transliterated) | Record types 00/01/02/03/04/05, checksum/overlap/EOF validation | `memory/IntelHex.kt` |

## Explicitly not ported (see PROTOCOLS.md / PROGRAMMERS.md for status)

| AVRDUDE source | Why it's out of scope for this phase |
|---|---|
| `src/stk500.c`, `src/stk500v2.c`, `src/stk500generic.c` | Separate synchronous/framed serial protocols; needs the USB-UART transport layer (usb-serial-for-android is a declared dependency but not wired up) |
| `src/jtagmkI.c`, `src/jtagmkII.c`, `src/jtag3.c` | Atmel JTAG ICE command protocols, materially different framing from USBasp |
| `src/avr910.c` | avr910/butterfly bootloader protocol |
| `src/serialupdi.c`, `src/updi_link.c`, `src/updi_nvm*.c` | UPDI link layer + per-NVM-controller-version programming (tinyAVR 0/1/2, megaAVR 0, AVR Dx) |
| `usbasp.c`'s `USBASP_FUNC_TPI_*` path | TPI support for ATtiny4/5/9/10-class parts (constants exist in `UsbaspConstants`, unused) |
| `src/pickit5*.c`, Atmel-ICE-specific paths in `jtag3.c` | Newer Microchip debug-probe protocols |
| Fuse/lock-bit read-modify-write, calibration byte handling | Device database doesn't yet carry per-part fuse definitions |
| ELF input | Not implemented; only Intel HEX and raw binary are supported |

## Licensing note

AVRDUDE is licensed under the GNU GPL v2 (`COPYING`, copied unmodified from
the AVRDUDE source tree into this project's root). Because the files listed
under "Implemented" above copy protocol constants and device-database values
directly out of AVRDUDE's source, this project is a derivative work of
AVRDUDE and is distributed under GPLv2 as a whole -- see
`THIRD_PARTY_LICENSES.md`.
