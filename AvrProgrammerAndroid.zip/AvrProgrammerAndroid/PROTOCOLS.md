# Protocols

| Protocol | Devices | Programmer(s) | Status |
|---|---|---|---|
| AVR ISP (SPI) | Classic AVR (ATmega/ATtiny/AT90 with PM_ISP) | USBasp | **Implemented** (via USBasp's `FUNC_TRANSMIT` passthrough + paged flash/EEPROM functions) |
| USBasp-native paged read/write | Classic AVR flash + EEPROM | USBasp | **Implemented** |
| TPI | ATtiny4/5/9/10-class parts | USBasp (firmware supports it), Arduino-as-ISP | Not implemented -- `FUNC_TPI_*` constants exist in `UsbaspConstants.kt` but are not wired to a `Programmer` |
| STK500 v1 | Classic AVR via Arduino bootloader / STK500 | STK500v1, Arduino as ISP | Not implemented |
| STK500 v2 | Classic + some Xmega | STK500v2, STK600, AVR ISP mkII | Not implemented |
| JTAG (mkI/mkII/JTAGICE3) | AVR parts with on-chip JTAG (PM_JTAG) | JTAG ICE mkI/II/3, AVR Dragon | Not implemented |
| PDI | ATxmega family | JTAGICE3 (PDI mode), Atmel-ICE | Not implemented |
| UPDI | tinyAVR 0/1/2, megaAVR 0, AVR Dx/DA/DB/DD/DU | SerialUPDI, JTAGICE3/PICkit4 (UPDI mode), USBasp+UPDI adapters | Not implemented |
| debugWire | Low-pin-count classic AVR in debug mode | JTAG ICE mkII/3 | Not implemented |
| HVSP / HVPP | Classic AVR fuse recovery when ISP is disabled | STK500, AVR Dragon | Not implemented -- also requires the 12V high-voltage supply hardware AVRDUDE's serial/parallel/Dragon programmers provide; a phone cannot source that itself |

## Why the gap between "designed for" and "implemented"

The project brief (sections 12 and 30) explicitly calls out that ISP,
TPI/PDI/UPDI, and JTAG are different protocol families and that ISP command
sequences must not be assumed to apply to UPDI/PDI/XMEGA devices. This
project takes that literally: rather than stub out a `Programmer`
implementation for each protocol that silently sends ISP-shaped commands to a
UPDI part (which would brick hardware, not "work"), only the protocol that
has been fully, correctly ported (classic-AVR ISP via USBasp) is wired up.

```
FEATURE: TPI / STK500v1 / STK500v2 / JTAG / PDI / UPDI / debugWire / HVSP / HVPP
STATUS: NOT IMPLEMENTED
REASON: Each is a structurally distinct protocol module (different framing,
        state machine, and in HVSP/HVPP's case different physical signals)
        that has not yet been ported from AVRDUDE's corresponding source file.
AVRDUDE SOURCE REFERENCE: src/stk500.c, src/stk500v2.c, src/jtagmkI.c,
        src/jtagmkII.c, src/jtag3.c, src/updi_link.c, src/updi_nvm_v*.c
        (see AVRDUDE_PORTING.md for the full list)
```
