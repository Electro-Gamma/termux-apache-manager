# Protocols

Per project brief section 25, this table must be
`Protocol | Devices | Programmer(s) | Status`.

| Protocol | Devices | Programmer(s) | Status |
|---|---|---|---|
| Generic classic-AVR ISP (opcode-template based) | Any classic ATmega/ATtiny/AT90 part with an ISP interface | USBasp, USBtinyISP, STK500v1/Arduino | **Implemented** -- `device/Opcode.kt` |
| USBasp control-transfer framing | (transport for the above) | USBasp | **Implemented** |
| USBtiny control-transfer framing | (transport for the above) | USBtinyISP | **Implemented** |
| STK500 v1 (`Cmnd_STK_*`) | (transport for the above) | STK500v1, Arduino as ISP | **Implemented** |
| Intel HEX | n/a (file format) | all | **Implemented**, full record-type support + validation |
| Raw BIN | n/a (file format) | all | **Implemented** |
| ELF (AVR, avr-gcc layout) | n/a (file format) | all | **Implemented, simplified** -- see below |
| STK500 v2 (`Cmnd_STK2_*`) | Same device set as v1, plus newer STK500-family hardware | AVRISP, AVRISP mkII, STK500v2, STK600 | **Not implemented** -- distinct, more complex framed protocol from v1 (sequence numbers, checksums, `START_TOKEN` framing); see `src/stk500v2.c` |
| JTAG ICE mkII packet protocol | Classic AVRs with JTAG/debugWIRE, via these debuggers | JTAGICE mkII, AVR Dragon (ISP sub-mode) | **Not implemented** |
| EDBG / CMSIS-DAP-style framed protocol | Broad modern Microchip/Atmel device support | JTAGICE3, Atmel-ICE | **Not implemented** |
| UPDI | tinyAVR 0/1/2, megaAVR 0, AVR Dx (DA/DB/DD/DU), AVR128DB | SerialUPDI, Atmel-ICE (UPDI mode) | **Not implemented** -- see below |
| PDI | XMEGA | Atmel-ICE, JTAGICE mkII/3 (PDI mode) | **Not implemented** |
| TPI | ATtiny4/5/9/10/20/40-class parts | USBasp (TPI mode) | **Not implemented** -- see PROGRAMMERS.md |
| HVSP / HVPP (high-voltage serial/parallel) | Classic AVRs when ISP is disabled by fuses, or for fuse recovery | STK500/STK600/AVR Dragon in HV mode | **Not implemented** |
| USB DFU (FLIP-compatible) | AT90USB/ATmega32U* bootloaders | Atmel DFU / FLIP | **Not implemented** |

## Why UPDI/PDI/TPI specifically are out of scope for this pass

These are NOT "classic ISP with different opcode numbers" -- they are
different programming architectures entirely:

- **UPDI** is a single-wire, NVM-controller-mediated protocol: the host writes
  to memory-mapped NVM controller registers over a UART-like physical layer
  with break-character resync, not a 4-byte SPI-shift-register instruction
  set. `device/Opcode.kt`'s bit-template engine (this project's core
  contribution) does not apply to it at all -- a UPDI implementation would be
  a parallel programming engine, not an extension of the ISP one.
- **PDI** (XMEGA) is similarly NVM-controller-based, over a different
  2-wire physical layer.
- **TPI** (tiny ATtiny4/5/9/10/20/40-class parts) is closer to ISP in spirit
  (still SPI-like, still bit-banged) but uses its own instruction set (`SLD`,
  `SST`, `SSTPR`, `SIN`, `SOUT`, NVM control/status registers) rather than the
  classic Programming-Enable/Chip-Erase/Read-Signature opcode set this
  project's device database and opcode engine are built around.

Implementing any of these properly means a second programming-engine core, a
second device-database shape (UPDI/PDI/TPI parts have a completely different
memory map story), and is honestly a similarly-sized project to the ISP engine
already built here. Rather than bolt on a half-working version, they are left
as explicit `NOT_IMPLEMENTED` entries in `ProgrammerRegistry.kt`.

## ELF support, specifically what's simplified

`hex/ElfReader.kt` implements a minimal ELF32 reader targeted at `avr-gcc`/
`avr-objcopy` output:

- Walks the section header table, pulls every `SHT_PROGBITS` section with the
  `SHF_ALLOC` flag into a flash image (the standard avr-gcc layout puts
  `.text`/`.data`/`.rodata`/`.vectors` etc. there), and separately collects any
  section literally named `.eeprom` into an EEPROM image.
- **Does not** perform relocation processing, symbol resolution, or support
  ELF64 (AVR toolchains never produce ELF64, so this isn't a real-world gap).
- This mirrors what `avr-objcopy -O ihex firmware.elf firmware.hex` does for
  the common case, without depending on `avr-objcopy`/`bfd`/`libelf` being
  available (none of which exist for Android).

This is "ELF input where practical" per project brief section 14 -- practical
here means the common avr-gcc build output, not arbitrary hand-linked ELF.
