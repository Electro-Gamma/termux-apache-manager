# Protocol status

| Protocol | Devices | Programmer(s) | Status |
|---|---|---|---|
| USBasp/ISP passthrough | Classic AVR (ATmega/ATtiny/AT90, ISP-capable) | USBasp | **Implemented** |
| Standard AVR ISP instruction set (program enable, chip erase, read/write flash+EEPROM, read signature) | Classic AVR, ISP-capable | USBasp, STK500 (v1) (both via passthrough); would also apply to any future ISP-capable programmer | **Implemented** |
| STK500 v1 | Classic AVR | STK500 (v1), Arduino as ISP | **Implemented for STK500 (v1)** (real-hardware ISP path; bootloader/optiboot and MIB510 variants are not). Arduino as ISP itself is still not implemented -- it needs DTR-auto-reset handling on top of this protocol; see PROGRAMMERS.md. |
| STK500 v2 | Classic AVR + some UPDI/TPI via AVRISP mkII | AVRISP mkII, STK500v2, STK600 | Not implemented |
| JTAG ICE mkI | Classic AVR (JTAG-capable) | JTAG ICE mkI | Not implemented |
| JTAG ICE mkII | Classic AVR (JTAG/debugWIRE-capable) | JTAG ICE mkII, AVR Dragon | Not implemented |
| JTAGICE3 / EDBG | megaAVR, tinyAVR, XMEGA, AVR Dx/Dx | JTAGICE3, Atmel-ICE, Xplained boards | Not implemented |
| TPI | ATtiny4/5/9/10-class parts | USBasp (TPI mode), JTAGICE3 | Not implemented (constants ported, state machine not) |
| PDI | XMEGA | JTAGICE3, Atmel-ICE | Not implemented |
| UPDI | tinyAVR 0/1/2, megaAVR 0, AVR Dx/Dx family | SerialUPDI, JTAGICE3, PICkit4 | Not implemented |
| HVSP / HVPP | Classic AVR (high-voltage recovery modes) | AVR Dragon, STK500 | Not implemented |
| debugWIRE | Classic AVR (single-wire debug) | JTAG ICE mkII, AVR Dragon | Not implemented |

## Memory operation status (within the implemented USBasp/ISP path)

| Operation | Status |
|---|---|
| Read signature | Implemented |
| Chip erase | Implemented |
| Read flash (paged) | Implemented |
| Write flash (paged) | Implemented |
| Read EEPROM (paged) | Implemented (same code path as flash, different function ID) |
| Write EEPROM (paged) | Implemented |
| Read/write fuse bits | **Not implemented** -- device database has no fuse definitions yet |
| Read/write lock bits | **Not implemented** -- same reason |
| Read/write calibration byte | **Not implemented** |
| Verify | Implemented (`AvrDudeEngine.verify()`; byte-by-byte against a re-read image) |

```
FEATURE: Fuse and lock-bit read/write
STATUS: NOT IMPLEMENTED
REASON: AVRDUDE's device definitions include a `memory "lfuse"/"hfuse"/"efuse"/"lock"` block per part with
        its own ISP instruction encoding; DeviceDatabase.kt only carries flash/EEPROM geometry so far.
AVRDUDE SOURCE REFERENCE: src/avrdude.conf.in (per-part `memory "lfuse"` etc. blocks), src/pgm_type.c
```
