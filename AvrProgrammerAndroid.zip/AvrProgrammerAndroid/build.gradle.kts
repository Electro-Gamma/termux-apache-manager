// Top-level build file. Individual module build files (app/build.gradle.kts)
// declare their own plugin versions; nothing project-wide is required here.
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}

tasks.register("clean", Delete::class) {
    delete(rootProject.layout.buildDirectory)
}
