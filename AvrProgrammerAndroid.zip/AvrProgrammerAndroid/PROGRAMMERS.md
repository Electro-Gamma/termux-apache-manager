# Programmers

VID/PID values are copied from AVRDUDE's `src/usbdevs.h` and
`src/avrdude.conf.in` (`usbvid`/`usbpid` fields) -- see AVRDUDE_PORTING.md.
None are invented; where AVRDUDE has no fixed VID/PID (serial-only
programmers), that's noted explicitly rather than guessed.

| Programmer | Protocol | Transport | Implemented | Tested |
|---|---|---|---|---|
| USBasp (VID 0x16C0 PID 0x05DC "shared"; also 0x03EB:0xC7B4 legacy, 0x16C0:0x092F NIBObee) | USBasp vendor control transfers over AVR ISP | USB (control transfers only) | **Yes** | Yes -- `UsbaspProgrammerTest.kt` against `MockUsbaspTransport` |
| USBtinyISP (0x1781:0x0C9F) | USBtiny vendor control transfers, bit-banged SPI in firmware | USB | No | No |
| AVR ISP mkII (0x03EB:0x2104) | STK500v2 command-response | USB | No | No |
| JTAG ICE mkII (0x03EB:0x2103) | JTAGICE mkII command protocol | USB | No | No |
| JTAGICE3 / Xplained family (0x03EB:0x2110, 0x2140) | EDBG/JTAGICE3 framed protocol (JTAG/PDI/UPDI/ISP modes) | USB | No | No |
| AVR Dragon, ISP + JTAG modes (0x03EB:0x2107) | JTAGICE mkII-derived command protocol | USB | No | No |
| STK600 (0x03EB:0x2106) | STK500v2 command-response | USB | No | No |
| STK500 v1 | STK500 synchronous serial protocol | Serial (USB-UART) | No | No |
| STK500 v2 (serial variant, distinct from AVR ISP mkII's USB transport) | STK500v2 command-response | Serial (USB-UART) | No | No |
| Arduino as ISP | STK500v1-derived protocol (ArduinoISP sketch) | USB-CDC serial | No | No |
| SerialUPDI | UPDI-over-UART link layer + NVM controller | Serial (USB-UART) | No | No |
| Atmel-ICE, JTAGICE mkI, PICkit4 (UPDI mode) | Various | USB | No | No -- AVRDUDE's own config lists these without a fixed `usbvid`/`usbpid` (matched by product string instead), so no VID/PID entry is fabricated here either |

For every "No" row:

```
FEATURE: <programmer name>
STATUS: NOT IMPLEMENTED
REASON: Distinct protocol module not yet ported (see AVRDUDE_PORTING.md "Explicitly not ported")
AVRDUDE SOURCE REFERENCE: see AVRDUDE_PORTING.md for the specific src/*.c file
```
