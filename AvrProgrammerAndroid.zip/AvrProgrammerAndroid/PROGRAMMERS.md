# Programmer status

Per the project brief's required format for unimplemented features:

```
FEATURE: <name>
STATUS: NOT IMPLEMENTED
REASON: <technical reason>
AVRDUDE SOURCE REFERENCE: <module/file>
```

## Status table

| Programmer | Protocol | Transport | Implemented | Tested |
|---|---|---|---|---|
| USBasp | USBasp vendor control transfers over AVR ISP | USB (control transfers only) | **Yes** | Yes (unit tests against a mock transport; not yet against physical hardware) |
| USBtinyISP | USBtiny vendor control transfers | USB | No | No |
| AVRISP / AVRISP mkII | STK500 / STK500v2 | Serial / USB | No | No |
| Arduino as ISP | STK500v1-derived | USB-CDC serial | No | No |
| STK500 (v1) | STK500 synchronous serial | Serial (USB-UART) | No | No |
| STK500v2 / STK600 | STK500v2 command-response | Serial / USB | No | No |
| AVR Dragon (ISP mode) | JTAGICE mkII-derived | USB | No | No |
| AVR Dragon (JTAG mode) | JTAGICE mkII-derived | USB | No | No |
| JTAG ICE mkI | JTAG ICE mkI protocol | Serial | No | No |
| JTAG ICE mkII | JTAG ICE mkII protocol | USB / Serial | No | No |
| JTAGICE3 / Atmel-ICE / EDBG family | JTAGICE3 framed protocol | USB | No | No |
| SerialUPDI | UPDI-over-UART | Serial (USB-UART) | No | No |
| PICkit4 (UPDI mode) | JTAGICE3-derived | USB | No | No |

## Not-implemented details

```
FEATURE: USBtinyISP
STATUS: NOT IMPLEMENTED
REASON: Different control-transfer command set and bit-banged-SPI timing model than USBasp; not yet ported.
AVRDUDE SOURCE REFERENCE: src/usbtiny.c, src/usbtiny.h

FEATURE: AVRISP mkII / STK500v2 family (also covers stk500v2, stk600, avrispmkII)
STATUS: NOT IMPLEMENTED
REASON: STK500v2 is a framed command-response protocol (STX/SEQNO/length/token + checksum) fundamentally
        different from USBasp's raw control-transfer model; needs its own state machine and, for the
        USB-attached variants, bulk-endpoint framing rather than EP0 control transfers.
AVRDUDE SOURCE REFERENCE: src/stk500v2.c, src/stk500v2_private.h

FEATURE: STK500 (v1)
STATUS: NOT IMPLEMENTED
REASON: Synchronous serial protocol requiring a UART transport; this project depends on
        usb-serial-for-android for USB-UART access but has not wired it into the engine yet.
AVRDUDE SOURCE REFERENCE: src/stk500.c, src/stk500_private.h

FEATURE: Arduino as ISP
STATUS: NOT IMPLEMENTED
REASON: Same STK500v1-derived protocol dependency as STK500 (v1) above, plus Arduino-specific
        auto-reset-over-DTR handling that has no direct Android USB-CDC equivalent yet.
AVRDUDE SOURCE REFERENCE: src/stk500.c (type "arduino" programmer definition in avrdude.conf.in)

FEATURE: JTAG ICE mkI / mkII / JTAGICE3 / Atmel-ICE / EDBG family
STATUS: NOT IMPLEMENTED
REASON: Distinct framed command protocols per generation, materially larger surface area
        (JTAG chain control, breakpoints, debugWIRE) than ISP programming alone.
AVRDUDE SOURCE REFERENCE: src/jtagmkI.c, src/jtagmkII.c, src/jtag3.c, src/jtag3_private.h

FEATURE: AVR Dragon
STATUS: NOT IMPLEMENTED
REASON: Built on the JTAGICE mkII protocol (see above) plus Dragon-specific mode switching (ISP/JTAG/HVSP/HVPP).
AVRDUDE SOURCE REFERENCE: src/jtagmkII.c (dragon_isp / dragon_jtag programmer types)

FEATURE: SerialUPDI / PICkit4 UPDI mode
STATUS: NOT IMPLEMENTED
REASON: UPDI is a completely different physical/link layer (single-wire, NVM-controller-version-specific
        programming) from classic AVR ISP; needs its own transport and per-NVM-version command set.
AVRDUDE SOURCE REFERENCE: src/serialupdi.c, src/updi_link.c, src/updi_nvm_v0.c..v6.c
```

## USBasp -- implemented, with caveats

USBasp's TPI function IDs (`FUNC_TPI_CONNECT` etc., for ATtiny4/5/9/10-class
parts) exist in `UsbaspConstants` but are not wired into `UsbaspProgrammer` --
only the classic-AVR ISP path is implemented.

```
FEATURE: USBasp TPI mode
STATUS: NOT IMPLEMENTED
REASON: TPI uses a different command sequence (TPI_CONNECT/raw read-write/block read-write) than the
        ISP path implemented here; the byte-level constants are ported but the state machine is not.
AVRDUDE SOURCE REFERENCE: src/usbasp.c (usbasp_tpi_* functions), src/usbasp.h (TPI_OP_* constants)
```
