# Programmers

Per project brief section 25, this table must be `Programmer | Protocol | Transport | Implemented | Tested`. Generated from [`ProgrammerRegistry.kt`](app/src/main/java/com/avrprogrammer/android/programmer/ProgrammerRegistry.kt) -- the app's Hardware Test / programmer-selection UI reads the same registry, so this table cannot drift from what the app actually offers.

| Programmer | Protocol | Transport | Implemented | Tested |
|---|---|---|---|---|
| USBasp | USBasp vendor-specific control transfers (SPI/ISP mode) | USB control transfers | Yes | Yes (`UsbaspProtocolTest`) |
| USBtinyISP | USBtiny vendor-specific control transfers | USB control transfers | Yes | Partial (protocol relies on the same opcode engine as USBasp/STK500v1, which is directly tested; USBtiny-specific framing is exercised manually, not yet unit tested) |
| STK500 v1 | STK500 v1 (AVR061 application note, Cmnd_STK_*) over a serial byte stream | USB CDC-ACM serial | Yes | Yes (`Stk500v1ProtocolTest`) |
| Arduino as ISP | Same STK500 v1 wire protocol (see src/arduino.c) | USB CDC-ACM serial | Yes | Yes (shares `Stk500v1Programmer`, same tests) |
| AVRISP (STK500v2 over serial) | STK500 v2 ("Cmnd_STK2_*", src/stk500v2.c) | Generic serial | No | No |
| AVRISP mkII | STK500 v2 over USB | USB bulk/serial-like | No | No |
| STK500 v2 (generic) | STK500 v2 | Generic serial | No | No |
| Atmel STK600 | STK500 v2 variant | USB bulk/serial-like | No | No |
| AVR Dragon (ISP mode) | JTAG ICE mkII packet protocol, ISP sub-mode | USB bulk/serial-like | No | No |
| JTAGICE mkII | JTAG ICE mkII packet protocol | USB bulk/serial-like | No | No |
| JTAGICE3 | EDBG/CMSIS-DAP-style framed protocol | USB bulk/serial-like | No | No |
| Atmel-ICE | EDBG protocol family | USB bulk/serial-like | No | No |
| USBasp (TPI mode) | USBasp TPI control requests | USB control transfers | No | No |
| Atmel DFU (FLIP-compatible bootloader) | USB DFU class | USB bulk/serial-like | No | No |
| SerialUPDI | UPDI over a plain UART | Generic serial | No | No |
| XMEGA (PDI) | PDI | Not supported on Android | No | No |
| Parallel-port / GPIO bit-bang programmers | Direct pin bit-banging | Not supported on Android | No | No |
| Bus Pirate | Bus Pirate binary SPI mode over serial | Generic serial | No | No |
| FTDI / CP210x / CH340-CH341 adapters | Vendor-specific USB-serial chip control | Not supported on Android | No | No |

## Why the "No" rows, specifically

- **STK500v2 family** (AVRISP, AVRISP mkII, STK500v2, STK600): a distinct,
  more complex framed protocol from STK500v1 -- sequence numbers, checksums,
  `START_TOKEN`/`TOKEN` framing (`src/stk500v2.c`). Not a drop-in extension of
  the STK500v1 work already done; deliberately scoped out of this pass.
- **JTAG ICE mkII / JTAGICE3 / Atmel-ICE / AVR Dragon**: real hardware
  debugger protocols (JTAG/debugWIRE/HVSP/HVPP-capable), substantially larger
  in scope than the ISP-only programmers implemented here.
- **USBasp TPI mode**: the SPI/ISP half of USBasp (this project's flagship
  implementation) is complete, but its separate TPI control requests
  (`usbasp_tpi_*` in `src/usbasp.c`) aren't wired up, and TPI-only parts
  (ATtiny4/5/9/10/20/40) aren't in the curated device database yet either.
- **DFU/FLIP**: a bootloader protocol, not an ISP programmer; different state
  machine entirely (`src/flip1.c`/`src/flip2.c`).
- **SerialUPDI / XMEGA PDI**: architecturally distinct from classic ISP --
  different instruction set, different addressing, NVM controller commands
  instead of ISP opcodes. See PROTOCOLS.md.
- **Bit-bang / parallel-port programmers**: rely on direct GPIO or
  parallel-port pin control from the host. The Android USB Host API has no
  general-purpose bit-bangable GPIO for arbitrary USB adapters -- this is a
  platform limitation, not just unported code.
- **FTDI/CP210x/CH340 vendor USB-serial chips**: AVRDUDE itself does not
  implement these chips' wire protocols either -- it relies on the host OS's
  kernel driver (`ftdi_sio`/`cp210x`/`ch341`) exposing a plain tty device.
  Android's USB Host framework has no equivalent built-in driver, so a
  from-scratch chip-specific reimplementation would be needed. Only the
  standards-based USB CDC-ACM class (no vendor driver required -- what stock
  Arduino boards' onboard USB-serial bridge speaks) is implemented, via
  `CdcAcmSerialTransport`.
