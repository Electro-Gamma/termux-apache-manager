# Programmer status

Per the project brief's required format for unimplemented features:

```
FEATURE: <name>
STATUS: NOT IMPLEMENTED
REASON: <technical reason>
AVRDUDE SOURCE REFERENCE: <module/file>
```

## Status table

| Programmer | Protocol | Transport | Implemented | Tested |
|---|---|---|---|---|
| USBasp | USBasp vendor control transfers over AVR ISP | USB (control transfers only) | **Yes** | Yes (unit tests against a mock transport; not yet against physical hardware) |
| USBtinyISP | USBtiny vendor control transfers | USB | No | No |
| AVRISP / AVRISP mkII | STK500 / STK500v2 | Serial / USB | No | No |
| Arduino as ISP (programming *other* chips with an Arduino) | STK500v1-derived | USB-CDC serial | No | No |
| STK500 (v1) -- real hardware | STK500 v1 synchronous serial | Serial (USB-UART) | **Yes** | Yes (unit tests against a mock transport; not yet against physical hardware) |
| Arduino board bootloader uploads (Uno, Nano, Mini, Ethernet, Fio, BT, LilyPad, Pro, NG, Balanduino, PocketDuino) | STK500v1 bootloader variant | Serial (USB-UART) | **Yes** | Yes (unit tests against a mock transport; not yet against physical hardware) |
| Arduino board bootloader uploads (Leonardo, Micro, Esplora, LilyPad USB) | AVR109 / Caterina bootloader | Serial (USB-CDC) | **Yes**, protocol only -- see caveat below | Yes (unit tests against a mock transport; not yet against physical hardware) |
| Arduino Mega 2560 / ADK bootloader upload | STK500v2 (not v1) | Serial (USB-UART) | No | No |
| STK500v2 / STK600 | STK500v2 command-response | Serial / USB | No | No |
| AVR Dragon (ISP mode) | JTAGICE mkII-derived | USB | No | No |
| AVR Dragon (JTAG mode) | JTAGICE mkII-derived | USB | No | No |
| JTAG ICE mkI | JTAG ICE mkI protocol | Serial | No | No |
| JTAG ICE mkII | JTAG ICE mkII protocol | USB / Serial | No | No |
| JTAGICE3 / Atmel-ICE / EDBG family | JTAGICE3 framed protocol | USB | No | No |
| SerialUPDI | UPDI-over-UART | Serial (USB-UART) | No | No |
| PICkit4 (UPDI mode) | JTAGICE3-derived | USB | No | No |

## Not-implemented details

```
FEATURE: USBtinyISP
STATUS: NOT IMPLEMENTED
REASON: Different control-transfer command set and bit-banged-SPI timing model than USBasp; not yet ported.
AVRDUDE SOURCE REFERENCE: src/usbtiny.c, src/usbtiny.h

FEATURE: AVRISP mkII / STK500v2 family (also covers stk500v2, stk600, avrispmkII)
STATUS: NOT IMPLEMENTED
REASON: STK500v2 is a framed command-response protocol (STX/SEQNO/length/token + checksum) fundamentally
        different from USBasp's raw control-transfer model; needs its own state machine and, for the
        USB-attached variants, bulk-endpoint framing rather than EP0 control transfers.
AVRDUDE SOURCE REFERENCE: src/stk500v2.c, src/stk500v2_private.h

FEATURE: Arduino as ISP (using an Arduino running the ArduinoISP sketch to program *other* chips over its ISP header)
STATUS: NOT IMPLEMENTED
REASON: The ArduinoISP sketch speaks genuine STK500v1 -- the same protocol "STK500 (v1) -- real
        hardware" above already implements -- so the remaining gap isn't the protocol itself, it's
        that this specific workflow needs its own baud rate (typically 19200, not the 115200
        default) and a DTR reset before connecting, neither of which the generic "stk500v1"
        registry entry currently exposes as configurable.
AVRDUDE SOURCE REFERENCE: src/stk500.c (ArduinoISP sketch implements the same protocol this driver speaks)

FEATURE: JTAG ICE mkI / mkII / JTAGICE3 / Atmel-ICE / EDBG family
STATUS: NOT IMPLEMENTED
REASON: Distinct framed command protocols per generation, materially larger surface area
        (JTAG chain control, breakpoints, debugWIRE) than ISP programming alone.
AVRDUDE SOURCE REFERENCE: src/jtagmkI.c, src/jtagmkII.c, src/jtag3.c, src/jtag3_private.h

FEATURE: AVR Dragon
STATUS: NOT IMPLEMENTED
REASON: Built on the JTAGICE mkII protocol (see above) plus Dragon-specific mode switching (ISP/JTAG/HVSP/HVPP).
AVRDUDE SOURCE REFERENCE: src/jtagmkII.c (dragon_isp / dragon_jtag programmer types)

FEATURE: SerialUPDI / PICkit4 UPDI mode
STATUS: NOT IMPLEMENTED
REASON: UPDI is a completely different physical/link layer (single-wire, NVM-controller-version-specific
        programming) from classic AVR ISP; needs its own transport and per-NVM-version command set.
AVRDUDE SOURCE REFERENCE: src/serialupdi.c, src/updi_link.c, src/updi_nvm_v0.c..v6.c
```

## STK500 (v1) -- implemented, with caveats

`Stk500v1Programmer` covers the classic "real STK500v1 hardware / genuine
ISP-mode serial programmer" path: get-sync, enter/leave program mode, paged
flash+EEPROM read/write with extended addressing for flash over 64K words,
chip erase and signature read via the generic ISP passthrough. Detection
works differently from USBasp: STK500v1 isn't identified by a VID/PID (any
USB-UART adapter could be running it), so picking it in Manual mode asks
`SerialDeviceScanner` (backed by usb-serial-for-android) whether any attached
device is a recognized USB-serial chipset -- CH340/CH341, CP210x, FTDI,
PL2303, or CDC-ACM -- rather than matching against `ProgrammerRegistry`'s
VID/PID list.

```
FEATURE: AVRDUDE's own STK500v1 bootloader/optiboot code path (the "is_spm" branches)
STATUS: NOT IMPLEMENTED -- but see "Arduino board bootloader uploads" below for a different,
        real, tested route to the same real-world goal (uploading to an Arduino's bootloader)
REASON: AVRDUDE's own is_spm address-division rules weren't ported directly. Instead, bootloader-
        mode STK500v1 uploads are implemented via Stk500v1Programmer's knownDevice/
        isBootloaderTarget constructor parameters, following the addressing/SET_DEVICE approach
        confirmed against a real working reference implementation (see AVRDUDE_PORTING.md's
        ArduinoSketchUploader section) rather than reimplementing avrdude's own variant.
AVRDUDE SOURCE REFERENCE: src/stk500.c (is_spm() branches in stk500_loadaddr(), set_memchr_a_div())

FEATURE: MIB510 programmer variant
STATUS: NOT IMPLEMENTED
REASON: Fixed 256-byte block size and an extra init/close handshake (mib510_isp()) not shared
        with the standard STK500v1 path.
AVRDUDE SOURCE REFERENCE: src/stk500.c (pgmid_is("mib510") branches)

FEATURE: Runtime SCK/bitclock adjustment for STK500v1
STATUS: NOT IMPLEMENTED
REASON: Real STK500 hardware and several serial clones (Arduino as ISP notably) either don't
        support or mishandle a runtime bitclock change; avrdude itself gates this on a
        HAS_BITCLOCK_ADJ capability flag per-programmer. This build always uses the
        device's own default rather than risk sending an unsupported command.
AVRDUDE SOURCE REFERENCE: src/stk500.c (stk500_set_sck_period(), HAS_BITCLOCK_ADJ check in stk500_open())
```

## Arduino board bootloader uploads -- implemented, with caveats

Uploading a compiled sketch directly to an Arduino board's own flash via its
resident bootloader -- what the Arduino IDE's Upload button and avrdude's
`-c arduino` do -- is a different thing from "Arduino as ISP" above (which
uses an Arduino to program *other* chips). `ProgrammerRegistry` exposes one
descriptor per real board (`arduino-uno`, `arduino-nano328`, `arduino-
leonardo`, ...) from `ArduinoBoards.kt`; picking one in Manual mode selects
its known chip, baud rate, protocol, and reset sequence automatically --
detection still goes through `SerialDeviceScanner` the same way as STK500
(v1) above, since these boards aren't identified by a fixed VID/PID either.

- **Uno, Nano, Mini, Ethernet, Fio, BT, LilyPad (328/168), Pro, NG,
  Balanduino, PocketDuino**: STK500v1 bootloader (Optiboot and similar),
  fully implemented -- DTR or DTR+RTS auto-reset into the bootloader, the
  real `CMND_STK_SET_DEVICE` handshake, paged flash write/read. Chip erase is
  intentionally disabled for these (see `Stk500v1Programmer.chipErase()`) --
  bootloaders erase each flash page automatically as it's written, so a
  separate erase step isn't meaningful.
- **Leonardo, Micro, Esplora, LilyPad USB**: AVR109/Caterina bootloader,
  protocol fully implemented (`Avr109Programmer.kt`). The caveat: entering
  the bootloader on these boards normally requires a 1200bps "touch reset"
  that makes the board's USB device disconnect and re-enumerate as a new
  one -- a signal Android's USB Host APIs don't expose the same way desktop
  OSes do. This isn't automated (`ArduinoResetBehavior.Manual1200BpsTouch`
  just logs instructions); **you need to manually double-tap the board's
  reset button** to drop it into the bootloader before connecting, exactly
  like the well-known real-world workaround Arduino users already use for
  these boards. Once in the bootloader, the rest of the upload is automatic.
- **Arduino Mega 2560/ADK**: listed but NOT implemented -- it uses STK500v2,
  a protocol this project doesn't have at all yet.

```
FEATURE: Automatic 1200bps touch-reset (Leonardo/Micro/Esplora/LilyPad USB auto-reset)
STATUS: NOT IMPLEMENTED
REASON: Requires detecting USB device detach/re-enumeration and re-requesting permission for
        the newly-appeared device -- Android's USB Host model doesn't expose the desktop-OS
        "virtual COM port disappeared/reappeared" signal this relies on. Manual double-tap
        reset (the standard real-world workaround for these boards anyway) works today.
AVRDUDE SOURCE REFERENCE: n/a (this is a host-OS/host-API concern, not an AVRDUDE protocol gap)
```

## USBasp -- implemented, with caveats

USBasp's TPI function IDs (`FUNC_TPI_CONNECT` etc., for ATtiny4/5/9/10-class
parts) exist in `UsbaspConstants` but are not wired into `UsbaspProgrammer` --
only the classic-AVR ISP path is implemented.

```
FEATURE: USBasp TPI mode
STATUS: NOT IMPLEMENTED
REASON: TPI uses a different command sequence (TPI_CONNECT/raw read-write/block read-write) than the
        ISP path implemented here; the byte-level constants are ported but the state machine is not.
AVRDUDE SOURCE REFERENCE: src/usbasp.c (usbasp_tpi_* functions), src/usbasp.h (TPI_OP_* constants)
```
