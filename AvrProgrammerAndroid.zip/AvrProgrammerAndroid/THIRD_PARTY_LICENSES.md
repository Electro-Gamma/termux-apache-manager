# Third-Party Licenses

## This project's license: GPLv2

This application is licensed under the **GNU General Public License, version
2** -- see [`LICENSE`](LICENSE) (a copy of `licenses/AVRDUDE_COPYING.txt`).

### Why

This project implements protocols and reuses device/programmer data derived
directly and extensively from [AVRDUDE](https://github.com/avrdude/avrdude),
which is itself GPLv2-licensed. Specifically, this project's source was
written against, and its bundled `devices.json` was extracted from:

- AVRDUDE's protocol constants (`usbasp.h`/`usbasp.c`, `usbtiny.h`/`usbtiny.c`,
  `stk500_private.h`/`stk500.c`): request/function IDs, packet layouts, command
  sequences.
- AVRDUDE's ISP "opcode bit-template" architecture (`avrpart.c`'s
  `avr_set_bits`/`avr_set_addr`/`avr_set_input`/`avr_get_output`;
  `config_gram.y`'s `parse_cmdbits`): the bit-numbering scheme and the
  technique of encoding ISP instructions as 32-bit templates.
- AVRDUDE's device database (`avrdude.conf.in`): chip signatures, flash/EEPROM
  sizes and page sizes, and the ISP opcode template strings themselves, for
  every part in this app's device database.
- AVRDUDE's USB VID/PID tables (`usbdevs.h`).

No AVRDUDE C source is copied or transliterated into this project's Kotlin
source -- every `.kt` file was newly written against AVRDUDE's documented
protocol behaviour and data (see [AVRDUDE_PORTING.md](AVRDUDE_PORTING.md) for
the full per-file mapping). But because that architecture and data trace so
directly back to a GPLv2 codebase, licensing this project under GPLv2 as well
is the conservative, defensible choice, rather than asserting an independent
license for a project this dependent on AVRDUDE's own design and published
data. This is not a legal determination -- if you plan to redistribute this
project, have it reviewed.

AVRDUDE's author list (`licenses/AVRDUDE_AUTHORS.txt`) is preserved and
reproduced in the in-app Third-Party Licenses screen, in accordance with the
license's attribution terms.

## In-app licenses screen

The app's **Third-Party Licenses** screen (accessible from the main screen's
overflow menu) renders `app/src/main/assets/third_party_licenses.txt` in
full, which includes:

- This same rationale.
- The complete GPLv2 license text.
- AVRDUDE's author list.
- The other open-source components below.

## Other open-source components (via Gradle dependencies)

| Component | License | Used for |
|---|---|---|
| Kotlin standard library, kotlinx.coroutines | Apache 2.0 | Language runtime, async USB/engine work |
| AndroidX (core-ktx, appcompat, constraintlayout, coordinatorlayout, lifecycle, activity, fragment, recyclerview, documentfile) | Apache 2.0 | UI framework |
| Material Components for Android | Apache 2.0 | UI theming/widgets |

Full Apache License 2.0 text: <https://www.apache.org/licenses/LICENSE-2.0>

No other third-party libraries are used -- notably, the device database
parser (`util/MiniJson.kt`) and everything else is original code with no
further dependencies, by design (see TESTING.md for why `org.json` was
avoided).

## Files in `licenses/`

- `AVRDUDE_COPYING.txt` -- AVRDUDE's GPLv2 license text, copied verbatim from
  the uploaded `avrdude-main.zip` source tree.
- `AVRDUDE_AUTHORS.txt` -- AVRDUDE's author list, copied verbatim.
