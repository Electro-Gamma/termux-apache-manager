# Third-Party Licenses

## AVRDUDE

- **License**: GNU General Public License v2.0 (see `COPYING`, copied
  unmodified from the AVRDUDE source tree into this project's root).
- **Copyright**: AVRDUDE was originally written by Brian S. Dean; maintained
  since 2006 by Jörg Wunsch and contributors. USBasp support specifically
  (`src/usbasp.c`/`usbasp.h`) is Copyright (C) 2006 Thomas Fischl, Copyright
  (C) 2007 Joerg Wunsch.
- **What was derived**: protocol constants (function IDs, VID/PID values,
  SCK speed table) and device database values (signatures, flash/EEPROM
  sizes and page sizes), ported into Kotlin. See AVRDUDE_PORTING.md for the
  exact source-to-Kotlin mapping.
- **What was NOT copied**: no AVRDUDE C source file is included, translated
  line-by-line, or shelled out to; this project's Kotlin implementation
  (protocol state machines, USB Host integration, UI, engine) is
  independently written, referencing AVRDUDE's documented behavior rather
  than reproducing its C code.
- **License obligations**: because constants and device data are derived
  from GPLv2-licensed source, this project is distributed under GPLv2too
  (see `COPYING`). Any redistribution of this project (including modified
  APKs) must preserve this attribution and make corresponding source
  available per GPLv2 section 3.
- **Upstream project**: <https://github.com/avrdudes/avrdude>

## usb-serial-for-android

- **License**: MIT / Apache 2.0 dual-licensed (see the library's own
  repository for the authoritative text -- not vendored into this project;
  it's a Gradle dependency resolved from JitPack, not embedded source).
- **What it's used for**: planned USB-UART chipset support (FTDI, CP210x,
  CH340/CH341, CDC-ACM) for the serial-transport programmers listed as not
  yet implemented in PROGRAMMERS.md. Declared as a dependency in
  `app/build.gradle.kts`; not yet called from any code in this phase.
- **Upstream project**: <https://github.com/mik3y/usb-serial-for-android>

## AndroidX / Material Components / Kotlin coroutines

Standard Google/JetBrains libraries (`androidx.*`, `com.google.android.material`,
`org.jetbrains.kotlinx:kotlinx-coroutines-*`), each under the Apache License
2.0. Resolved as normal Gradle dependencies; not vendored.

## In-app screen

Per project brief section 24.7 ("include a third-party licenses screen"):
not yet built as a UI screen in this phase (Phase 1+2 scope is USB/engine/
USBasp, not settings screens) -- this file is the source of truth until
that screen exists. Wiring an in-app "About / Licenses" screen that renders
this file is a reasonable, small follow-up.
