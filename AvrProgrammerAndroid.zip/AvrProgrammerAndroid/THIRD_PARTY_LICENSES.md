# Third-party licenses

## AVRDUDE (GPLv2) -- primary technical reference

This project's protocol constants (`protocol/usbasp/UsbaspConstants.kt`),
device database (`device/DeviceDatabase.kt`), and programmer VID/PID
descriptors (`protocol/ProgrammerRegistry.kt`) were read directly out of the
[AVRDUDE](https://github.com/avrdude/avrdude) source tree
(`src/usbasp.h`, `src/usbdevs.h`, `src/avrdude.conf.in`), which is licensed
under the **GNU General Public License, version 2** (see `COPYING` in this
project's root, copied unmodified from AVRDUDE's own `COPYING`).

Per project brief section 24:

1. **License identified**: GPLv2 (see `COPYING`).
2. **Copyright notices preserved**: `usbasp.c`/`usbasp.h` carry
   `Copyright (C) 2006 Thomas Fischl` and `Copyright (C) 2007 Joerg Wunsch`;
   these are preserved in the source-mapping comments at the top of
   `UsbaspConstants.kt` and `UsbaspProgrammer.kt`.
3. **License file preserved**: `COPYING` is included unmodified at the
   project root.
4. **Derived portions documented**: see `AVRDUDE_PORTING.md` for the
   complete module-by-module mapping of what was ported from where.
5. **Attribution not removed**: every file that ports AVRDUDE-derived values
   says so in its file-level doc comment.
6. **Not claimed as independently authored**: same as above.
7. **Third-party licenses screen**: not yet built into the Android UI itself
   (see the `NOT IMPLEMENTED` note below) -- this document is the
   authoritative source until that screen exists.

### What this means for this project's own license

Because this project incorporates GPLv2-licensed material (the ported
protocol/device data above) rather than merely being *inspired by* AVRDUDE,
it is a derivative work under GPLv2's terms and **this project as a whole is
distributed under the GNU GPL v2**. Anyone redistributing the built APK must
also make the corresponding source available under GPLv2 and preserve this
notice and `COPYING`.

```
FEATURE: In-app "Third-party licenses" screen
STATUS: NOT IMPLEMENTED
REASON: This document (THIRD_PARTY_LICENSES.md) exists and is accurate, but no Settings ->
        Licenses UI screen has been built yet to surface it inside the running app.
AVRDUDE SOURCE REFERENCE: n/a
```

## Android/Kotlin dependencies

| Dependency | License |
|---|---|
| AndroidX (`core-ktx`, `appcompat`, `constraintlayout`, `lifecycle-*`, `activity-ktx`, `documentfile`) | Apache License 2.0 |
| Material Components for Android | Apache License 2.0 |
| Kotlin / kotlinx.coroutines | Apache License 2.0 |
| [usb-serial-for-android](https://github.com/mik3y/usb-serial-for-android) (`com.github.mik3y:usb-serial-for-android`) | Dual-licensed MIT / LGPLv2.1 (project's own choice at consumption time) |
| JUnit 4 | Eclipse Public License 1.0 |
| AndroidX Test / Espresso | Apache License 2.0 |

None of the above are modified or vendored into this repository; they are
consumed as ordinary Gradle dependencies and retain their own upstream
licenses.
