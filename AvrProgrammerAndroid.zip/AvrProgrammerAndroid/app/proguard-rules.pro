# Add project specific ProGuard rules here.
# Release builds in this project ship with minifyEnabled false (see app/build.gradle.kts),
# so these rules are currently unused, but are kept ready for when a signed/minified
# release build type is introduced.
