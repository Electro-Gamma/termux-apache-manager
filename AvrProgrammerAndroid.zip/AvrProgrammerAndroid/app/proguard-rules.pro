# Minimal, deliberately empty beyond defaults -- isMinifyEnabled is false for
# the release build type in app/build.gradle.kts, so this file is not
# currently exercised. Kept present so a future minifyEnabled=true flip has
# somewhere to add USBasp/engine keep-rules (reflection isn't used anywhere
# in this codebase today, so none should be needed).
