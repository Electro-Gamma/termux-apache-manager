package com.avrprogrammer.android.device

import android.content.Context
import com.avrprogrammer.android.util.JsonValue
import com.avrprogrammer.android.util.MiniJson
import java.io.BufferedReader

/**
 * Loads the bundled `assets/devices.json` (see DEVICE_DATABASE.md) into [AvrDevice]
 * instances and provides lookup by declared id and by ISP-read signature bytes --
 * the latter being how the engine auto-detects a connected chip (project brief
 * section "Auto signature detection").
 *
 * Parses via [MiniJson] rather than `org.json` specifically so this class -- and its
 * "device signature matching" unit tests (project brief section 21) -- work under
 * plain JUnit with no Android runtime or Robolectric; see MiniJson.kt for why.
 */
class DeviceDatabase private constructor(val devices: List<AvrDevice>, val sourceNote: String) {

    fun byId(id: String): AvrDevice? = devices.firstOrNull { it.id.equals(id, ignoreCase = true) }

    fun bySignature(signature: IntArray): AvrDevice? =
        devices.firstOrNull { it.signature.contentEquals(signature) }

    fun search(query: String): List<AvrDevice> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return devices
        return devices.filter { it.id.lowercase().contains(q) || it.desc.lowercase().contains(q) }
    }

    companion object {
        private const val ASSET_PATH = "devices.json"

        fun load(context: Context): DeviceDatabase {
            val json = context.assets.open(ASSET_PATH).bufferedReader().use(BufferedReader::readText)
            return parse(json)
        }

        /** Parses from raw JSON text directly -- used by unit tests, which have no Android assets. */
        fun parse(json: String): DeviceDatabase {
            val root = MiniJson.parse(json) as JsonValue.JsonObject
            val sourceNote = root.stringOrNull("sourceNote") ?: ""
            val devices = root.array("devices").objects().map { parseDevice(it) }
            return DeviceDatabase(devices, sourceNote)
        }

        private fun parseDevice(o: JsonValue.JsonObject): AvrDevice {
            val signature = o.array("signature").ints().toIntArray()
            val progModes = o.array("progModes").strings()
            val fuses = o.array("fuses").objects().map { fo -> parseMemory(fo, fo.string("name")) }

            return AvrDevice(
                id = o.string("id"),
                desc = o.string("desc"),
                signature = signature,
                progModes = progModes,
                chipEraseDelayUs = o.intOrNull("chipEraseDelayUs"),
                pgmEnableTemplate = o.stringOrNull("pgmEnableOpcode"),
                chipEraseTemplate = o.stringOrNull("chipEraseOpcode"),
                flash = parseMemory(o.objectOrNull("flash") ?: JsonValue.JsonObject(emptyMap()), "flash"),
                eeprom = o.objectOrNull("eeprom")?.let { parseMemory(it, "eeprom") },
                fuses = fuses,
                lock = o.objectOrNull("lock")?.takeIf { it.entries.isNotEmpty() }?.let { parseMemory(it, "lock") },
                calibration = o.objectOrNull("calibration")?.takeIf { it.entries.isNotEmpty() }?.let { parseMemory(it, "calibration") },
                signatureReadTemplate = o.stringOrNull("signatureRead")
            )
        }

        private fun parseMemory(o: JsonValue.JsonObject, name: String): AvrMemoryDef = AvrMemoryDef(
            name = name,
            size = o.int("size"),
            pageSize = o.int("pageSize"),
            numPages = o.int("numPages"),
            initval = o.intOrNull("initval"),
            bitmask = o.intOrNull("bitmask"),
            readTemplate = o.stringOrNull("read"),
            writeTemplate = o.stringOrNull("write"),
            readLoTemplate = o.stringOrNull("readLo"),
            readHiTemplate = o.stringOrNull("readHi"),
            loadPageLoTemplate = o.stringOrNull("loadPageLo"),
            loadPageHiTemplate = o.stringOrNull("loadPageHi"),
            writePageTemplate = o.stringOrNull("writePage"),
            loadExtAddrTemplate = o.stringOrNull("loadExtAddr")
        )
    }
}
