package com.avrprogrammer.android.device

/**
 * Kotlin port of AVRDUDE's `OPCODE` / `CMDBIT` structures (src/libavrdude.h) and the
 * bit-manipulation functions in src/avrpart.c (`avr_set_bits`, `avr_set_addr`,
 * `avr_set_addr_mem`, `avr_set_input`, `avr_get_output`), and the opcode-template
 * parser in src/config_gram.y (`parse_cmdbits`).
 *
 * AVRDUDE represents every classic-AVR ISP instruction (Programming Enable, Chip
 * Erase, Read/Write Flash, Read/Write EEPROM, Read/Write Fuse/Lock, Read Signature,
 * Read Calibration, ...) as a 32-bit template: 4 command bytes, each bit tagged as
 * a fixed VALUE, an ADDRESS bit (with its own logical bit-number within the
 * address), an INPUT (data-to-write) bit, an OUTPUT (data-to-read) bit, or an
 * IGNORE ("don't care") bit. `avrdude.conf` writes these templates as 32-character
 * strings such as `"1010.1100--0101.0011--0000.0000--0000.0000"` (Programming
 * Enable) grouped in nibbles for readability, with `.` and `-` as pure formatting.
 *
 * This is the actual mechanism AVRDUDE uses to stay generic across the whole classic
 * AVR family instead of hand-coding a command table per chip -- so porting it
 * faithfully (rather than hand-writing per-device opcodes) is the difference between
 * "based on AVRDUDE's architecture" and "loosely inspired by it".
 *
 * A note on the port, for whoever reads this next to `avrpart.c`: AVRDUDE's C code
 * stores bits internally at array index `31 - pos` (its `parse_cmdbits` walks the
 * template with a counter that starts at 32 and decrements once per character, so
 * the *first* character lands at index 31), and its byte/bit formulas (`j = 3 -
 * i/8`, `bit = i % 8`) are written against that reversed index. Working directly in
 * string position `pos` (0 = first/left-most character, matching this file's `chars`
 * array) collapses that double-reversal to the much simpler `byteIndex = pos / 8`,
 * `bitInByte = 7 - (pos % 8)` -- i.e. read the string left to right, 8 characters per
 * byte, most-significant-bit first within each byte. Verified against the
 * well-known Programming Enable command
 * `"1010.1100--0101.0011--0000.0000--0000.0000"` -> bytes `AC 53 00 00`.
 */
enum class CmdBitType { VALUE, ADDRESS, INPUT, OUTPUT, IGNORE }

data class CmdBit(val type: CmdBitType, val value: Boolean = false, val bitno: Int = 0)

class Opcode(val bits: Array<CmdBit>) {
    init {
        require(bits.size == 32) { "an ISP opcode template is always exactly 32 bits (4 bytes)" }
    }

    private inline fun forEachPhysicalBit(action: (pos: Int, byteIndex: Int, mask: Int, bit: CmdBit) -> Unit) {
        for (pos in 0 until 32) {
            val byteIndex = pos / 8
            val bitInByte = 7 - (pos % 8)
            action(pos, byteIndex, 1 shl bitInByte, bits[pos])
        }
    }

    /** Port of avr_set_bits(): burns the fixed VALUE/IGNORE bits into a 4-byte command. */
    fun setBits(cmd: ByteArray) {
        forEachPhysicalBit { _, byteIndex, mask, bit ->
            if (bit.type == CmdBitType.VALUE || bit.type == CmdBitType.IGNORE) {
                cmd[byteIndex] = if (bit.value && bit.type == CmdBitType.VALUE) {
                    (cmd[byteIndex].toInt() or mask).toByte()
                } else {
                    (cmd[byteIndex].toInt() and mask.inv()).toByte()
                }
            }
        }
    }

    /** Port of avr_set_addr(): burns all address bits from [address] (word address for flash-style memories, byte address otherwise). */
    fun setAddress(cmd: ByteArray, address: Long) {
        forEachPhysicalBit { _, byteIndex, mask, bit ->
            if (bit.type == CmdBitType.ADDRESS) {
                val value = (address ushr bit.bitno) and 1L
                cmd[byteIndex] = if (value != 0L) (cmd[byteIndex].toInt() or mask).toByte() else (cmd[byteIndex].toInt() and mask.inv()).toByte()
            }
        }
    }

    /**
     * Port of avr_set_addr_mem(): like [setAddress] but clamps address bits whose
     * logical bit-number falls outside [lo, hi] to 0, matching AVRDUDE's handling of
     * e.g. an 18-bit flash address split across a normal opcode (bits 0-15) plus a
     * separate Load Extended Address opcode (bits 16+).
     */
    fun setAddressRanged(cmd: ByteArray, address: Long, lo: Int, hi: Int) {
        forEachPhysicalBit { _, byteIndex, mask, bit ->
            if (bit.type == CmdBitType.ADDRESS) {
                val inRange = bit.bitno in lo..hi
                val value = if (inRange) (address ushr bit.bitno) and 1L else 0L
                cmd[byteIndex] = if (value != 0L) (cmd[byteIndex].toInt() or mask).toByte() else (cmd[byteIndex].toInt() and mask.inv()).toByte()
            }
        }
    }

    /** Port of avr_set_input(): burns a data-to-write byte into the INPUT bits. */
    fun setInput(cmd: ByteArray, data: Int) {
        forEachPhysicalBit { _, byteIndex, mask, bit ->
            if (bit.type == CmdBitType.INPUT) {
                val value = (data ushr bit.bitno) and 1
                cmd[byteIndex] = if (value != 0) (cmd[byteIndex].toInt() or mask).toByte() else (cmd[byteIndex].toInt() and mask.inv()).toByte()
            }
        }
    }

    /** Port of avr_get_output(): extracts the data-read byte from the OUTPUT bits of a response. */
    fun getOutput(response: ByteArray): Int {
        var data = 0
        forEachPhysicalBit { _, byteIndex, mask, bit ->
            if (bit.type == CmdBitType.OUTPUT) {
                val bitValue = (response[byteIndex].toInt() and mask)
                if (bitValue != 0) data = data or (1 shl bit.bitno) else data = data and (1 shl bit.bitno).inv()
            }
        }
        return data and 0xFF
    }

    /** Builds a fresh 4-byte command with just the fixed VALUE bits set (no address/data yet). */
    fun newCommand(): ByteArray {
        val cmd = ByteArray(4)
        setBits(cmd)
        return cmd
    }
}

/**
 * Parses AVRDUDE's `avrdude.conf` opcode template strings, e.g.
 * `"0010.0000--00aa.aaaa--aaaa.aaaa--oooo.oooo"` (Read Flash Low Byte), into an
 * [Opcode]. `.` and `-` are pure formatting and ignored. Recognised characters:
 *
 *  - `0` / `1`  fixed VALUE bit
 *  - `x`        IGNORE ("don't care") bit
 *  - `a`        ADDRESS bit
 *  - `i`        INPUT (data to write) bit
 *  - `o`        OUTPUT (data to read) bit
 *
 * Bit numbering for `a`/`i`/`o` characters follows AVRDUDE's own convention
 * (`parse_cmdbits` in config_gram.y): within a contiguous run of the same character,
 * the right-most occurrence is logical bit 0, increasing by one for each occurrence
 * moving left -- i.e. most-significant-bit-first, matching the command bytes'
 * own left-to-right MSB-first layout. This is exactly equivalent to AVRDUDE's
 * position-based `bitno` assignment for every real template in avrdude.conf, all of
 * which use a single contiguous run per bit-type (verified against extracted
 * templates for every device in this project's database) -- the one case that is
 * *not* naturally contiguous, the single-address-bit Load Extended Address opcode,
 * is handled by [isLoadExtAddr] below rather than assumed to follow the same rule.
 */
object OpcodeTemplateParser {

    fun parse(template: String, isLoadExtAddr: Boolean = false): Opcode {
        val chars = template.filter { it == '0' || it == '1' || it.lowercaseChar() in "xaio" }
        require(chars.length == 32) {
            "opcode template '$template' does not resolve to exactly 32 bits (got ${chars.length})"
        }

        val addrCount = chars.count { it == 'a' }
        val inputCount = chars.count { it == 'i' }
        val outputCount = chars.count { it == 'o' }

        var addrCursor = addrCount - 1
        var inputCursor = inputCount - 1
        var outputCursor = outputCount - 1

        // AVR_OP_LOAD_EXT_ADDR's lone (or few) 'a' bit(s) represent address bits 16+
        // (the part of a flash address that doesn't fit in a normal 16-bit ISP
        // address field), not bits starting at 0 -- see avrpart.c/config_gram.y's
        // "opnum == AVR_OP_LOAD_EXT_ADDR ? bitno+8 : bitno-8" special case.
        val addrBitOffset = if (isLoadExtAddr) 16 else 0

        val bits = Array(32) { i ->
            when (val c = chars[i]) {
                '0' -> CmdBit(CmdBitType.VALUE, value = false)
                '1' -> CmdBit(CmdBitType.VALUE, value = true)
                'x' -> CmdBit(CmdBitType.IGNORE)
                'a' -> CmdBit(CmdBitType.ADDRESS, bitno = addrBitOffset + addrCursor--)
                'i' -> CmdBit(CmdBitType.INPUT, bitno = inputCursor--)
                'o' -> CmdBit(CmdBitType.OUTPUT, bitno = outputCursor--)
                else -> error("unreachable opcode template character '$c'")
            }
        }
        return Opcode(bits)
    }

    /** Convenience for opcodes with no template (AVRDUDE's chip_erase/pgm_enable = NULL, e.g. TPI-only parts). */
    fun parseOrNull(template: String?, isLoadExtAddr: Boolean = false): Opcode? = template?.let { parse(it, isLoadExtAddr) }
}
