package com.avrprogrammer.android.transport

import android.content.Context
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager

/**
 * Enumerates attached USB devices (project brief section 3: "USB device
 * enumeration", "VID/PID detection", "Interface detection", "Endpoint detection").
 */
class UsbDeviceScanner(private val context: Context) {

    private val usbManager: UsbManager by lazy { context.getSystemService(Context.USB_SERVICE) as UsbManager }

    fun listAttachedDevices(): List<UsbDevice> = usbManager.deviceList.values.toList()

    fun findByVidPid(vendorId: Int, productId: Int): UsbDevice? =
        listAttachedDevices().firstOrNull { it.vendorId == vendorId && it.productId == productId }

    /**
     * Picks the "programming" interface on a device: for the simple vendor-specific
     * programmers this project implements (USBasp, USBtinyISP) that is interface 0 of
     * class VENDOR_SPECIFIC; for CDC-ACM serial adapters it is the Data class
     * interface (the one with the bulk IN/OUT pair), not the Communications class
     * control interface. Falls back to the first interface exposing a bulk pair, then
     * simply interface 0, so an unrecognised device still gets *a* usable interface to
     * try rather than failing enumeration outright.
     */
    fun pickPreferredInterface(device: UsbDevice): UsbInterface? {
        if (device.interfaceCount == 0) return null

        for (i in 0 until device.interfaceCount) {
            val iface = device.getInterface(i)
            if (iface.interfaceClass == UsbConstants.USB_CLASS_VENDOR_SPEC) return iface
        }
        for (i in 0 until device.interfaceCount) {
            val iface = device.getInterface(i)
            if (iface.interfaceClass == UsbConstants.USB_CLASS_CDC_DATA) return iface
        }
        for (i in 0 until device.interfaceCount) {
            val iface = device.getInterface(i)
            var hasBulkIn = false
            var hasBulkOut = false
            for (e in 0 until iface.endpointCount) {
                val ep = iface.getEndpoint(e)
                if (ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK) {
                    if (ep.direction == UsbConstants.USB_DIR_IN) hasBulkIn = true else hasBulkOut = true
                }
            }
            if (hasBulkIn && hasBulkOut) return iface
        }
        return device.getInterface(0)
    }
}
