package com.avrprogrammer.android.ui

import com.avrprogrammer.android.programmer.Programmer
import com.avrprogrammer.android.programmer.stk500v1.Stk500v1Programmer
import com.avrprogrammer.android.programmer.usbasp.UsbaspProgrammer
import com.avrprogrammer.android.programmer.usbtiny.UsbTinyProgrammer
import com.avrprogrammer.android.transport.CdcAcmSerialTransport
import com.avrprogrammer.android.transport.UsbEndpointInfo
import com.avrprogrammer.android.transport.UsbHostTransport

/** The one place the UI layer maps a [com.avrprogrammer.android.programmer.ProgrammerDescriptor] id to a concrete implementation, shared by every activity that needs to open a connection. */
object ProgrammerFactory {

    fun build(programmerId: String, usb: UsbHostTransport): Programmer = when (programmerId) {
        "usbasp" -> UsbaspProgrammer(usb)
        "usbtiny" -> UsbTinyProgrammer(usb)
        "stk500v1" -> Stk500v1Programmer(serialOver(usb), isArduinoVariant = false)
        "arduino" -> Stk500v1Programmer(serialOver(usb), isArduinoVariant = true)
        else -> throw IllegalStateException("no concrete implementation wired up for '$programmerId' -- see ProgrammerRegistry for its status")
    }

    private fun serialOver(usb: UsbHostTransport): CdcAcmSerialTransport =
        CdcAcmSerialTransport(usb, outEndpoint = firstBulkEndpoint(usb, outbound = true), inEndpoint = firstBulkEndpoint(usb, outbound = false))

    private fun firstBulkEndpoint(usb: UsbHostTransport, outbound: Boolean): Int {
        val direction = if (outbound) UsbEndpointInfo.Direction.OUT else UsbEndpointInfo.Direction.IN
        val ep = usb.info.interfaces.flatMap { it.endpoints }.firstOrNull {
            it.type == UsbEndpointInfo.Type.BULK && it.direction == direction
        }
        return ep?.address ?: throw IllegalStateException("device has no ${if (outbound) "OUT" else "IN"} bulk endpoint (not a CDC-ACM serial device?)")
    }
}
