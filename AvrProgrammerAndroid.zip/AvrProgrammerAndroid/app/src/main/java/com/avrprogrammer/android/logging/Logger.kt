package com.avrprogrammer.android.logging

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Log levels the project brief (section 19) asks for. Ordered so that a numerically
 * higher level is "noisier" -- filtering keeps everything with level.ordinal <= current.
 */
enum class LogLevel { ERROR, WARNING, INFO, DEBUG, TRACE }

data class LogEntry(
    val timestampMs: Long,
    val level: LogLevel,
    val tag: String,
    val message: String
) {
    fun format(): String {
        val ts = SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date(timestampMs))
        return "$ts [${level.name}] $tag: $message"
    }
}

/**
 * In-memory ring-buffered log with listener support for the UI's live log view, plus
 * raw USB/protocol frame logging (section 19: "USB OUT: ..." / "USB IN: ...").
 *
 * This is intentionally a plain singleton object rather than a DI-provided instance:
 * the engine, transports and programmers are all plain Kotlin classes constructed
 * directly (see AvrdudeEngine), and a single shared log sink is the simplest way for
 * all of them -- and the UI -- to observe the same stream without threading a logger
 * reference through every constructor.
 */
object Logger {

    private const val MAX_ENTRIES = 5000

    private val entries = CopyOnWriteArrayList<LogEntry>()
    private val listeners = CopyOnWriteArrayList<(LogEntry) -> Unit>()

    @Volatile
    var minLevel: LogLevel = LogLevel.INFO

    fun addListener(listener: (LogEntry) -> Unit) {
        listeners.add(listener)
    }

    fun removeListener(listener: (LogEntry) -> Unit) {
        listeners.remove(listener)
    }

    fun clear() = entries.clear()

    fun all(): List<LogEntry> = entries.toList()

    private fun log(level: LogLevel, tag: String, message: String) {
        val entry = LogEntry(System.currentTimeMillis(), level, tag, message)
        entries.add(entry)
        while (entries.size > MAX_ENTRIES) {
            entries.removeAt(0)
        }
        if (level.ordinal <= minLevel.ordinal) {
            // Always store everything (export can contain full detail); only forward to
            // live listeners (the on-screen log view) up to the configured verbosity.
        }
        listeners.forEach { it(entry) }
    }

    fun error(tag: String, message: String) = log(LogLevel.ERROR, tag, message)
    fun warning(tag: String, message: String) = log(LogLevel.WARNING, tag, message)
    fun info(tag: String, message: String) = log(LogLevel.INFO, tag, message)
    fun debug(tag: String, message: String) = log(LogLevel.DEBUG, tag, message)
    fun trace(tag: String, message: String) = log(LogLevel.TRACE, tag, message)

    /** Renders a byte array as space-separated uppercase hex, e.g. "C9 03 00 00". */
    fun hex(bytes: ByteArray): String = bytes.joinToString(" ") { "%02X".format(it) }

    /** Raw protocol OUT frame, exactly in the "USB OUT:\n.." shape section 19 asks for. */
    fun rawOut(tag: String, bytes: ByteArray) = trace(tag, "USB OUT:\n${hex(bytes)}")

    /** Raw protocol IN frame. */
    fun rawIn(tag: String, bytes: ByteArray) = trace(tag, "USB IN:\n${hex(bytes)}")

    /** Plain-text export of everything currently buffered, newest last. */
    fun exportText(): String = buildString {
        for (e in entries) {
            appendLine(e.format())
        }
    }
}
