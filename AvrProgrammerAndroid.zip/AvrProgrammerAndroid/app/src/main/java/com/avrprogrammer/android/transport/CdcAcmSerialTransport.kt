package com.avrprogrammer.android.transport

import com.avrprogrammer.android.errors.TransportException
import com.avrprogrammer.android.logging.Logger

/**
 * Serial transport for standards-compliant USB CDC-ACM devices, layered on top of a
 * [UsbTransport] whose claimed interface is the CDC Data interface (bulk IN/OUT pair)
 * -- see [UsbDeviceScanner.pickPreferredInterface].
 *
 * This covers Arduino Uno/Nano/Mega/Leonardo-family boards out of the box, since
 * their onboard USB-serial bridge (an ATmega16U2/8U2 running Arduino's own firmware,
 * or the 32U4's native USB on Leonardo-class boards) implements the standard USB CDC
 * class -- no vendor driver needed, which is exactly why it was chosen as the
 * reference implementation for the generic "serial transport" requirement in project
 * brief section 10.
 *
 * Vendor-specific USB-serial chips (FTDI, CP210x, CH340/CH341) use their own
 * non-standard control protocols instead of CDC and are NOT implemented here --
 * AVRDUDE itself does not implement them either; it relies on the host OS's kernel
 * driver (ftdi_sio, cp210x, ch341) exposing a plain tty device, and Android's USB Host
 * framework has no equivalent built-in driver for any of them. See PROGRAMMERS.md.
 */
class CdcAcmSerialTransport(private val usb: UsbTransport, private val outEndpoint: Int, private val inEndpoint: Int) : SerialTransport {

    companion object {
        // USB CDC (PSTN subclass) class-specific requests, ECM/ACM spec table 4.
        private const val SET_LINE_CODING = 0x20
        private const val SET_CONTROL_LINE_STATE = 0x22
        private const val REQUEST_TYPE_CDC_CLASS_INTERFACE_OUT = 0x21 // host-to-device | class | interface
    }

    override val isOpen: Boolean get() = usb.isOpen

    override fun open() {
        usb.open()
    }

    override fun close() {
        usb.close()
    }

    override fun setLineCoding(baudRate: Int, dataBits: Int, stopBits: Int, parity: Int) {
        // CDC SetLineCoding data packet: dwDTERate(4) bCharFormat(1) bParityType(1) bDataBits(1)
        val payload = byteArrayOf(
            (baudRate and 0xFF).toByte(),
            ((baudRate shr 8) and 0xFF).toByte(),
            ((baudRate shr 16) and 0xFF).toByte(),
            ((baudRate shr 24) and 0xFF).toByte(),
            (if (stopBits == 2) 2 else 0).toByte(), // 0 = 1 stop bit, 2 = 2 stop bits
            parity.toByte(),                        // 0 = none
            dataBits.toByte()
        )
        usb.controlTransfer(REQUEST_TYPE_CDC_CLASS_INTERFACE_OUT, SET_LINE_CODING, 0, 0, payload, payload.size, 1000)
        Logger.debug("CdcAcmSerialTransport", "set line coding: $baudRate baud, $dataBits$parity${if (stopBits == 2) 2 else 1}")
    }

    override fun setDtrRts(dtr: Boolean, rts: Boolean) {
        val value = (if (dtr) 0x01 else 0) or (if (rts) 0x02 else 0)
        usb.controlTransfer(REQUEST_TYPE_CDC_CLASS_INTERFACE_OUT, SET_CONTROL_LINE_STATE, value, 0, ByteArray(0), 0, 1000)
    }

    override fun write(data: ByteArray, timeoutMs: Int) {
        var offset = 0
        while (offset < data.size) {
            val chunk = data.copyOfRange(offset, data.size)
            val written = usb.bulkTransferOut(outEndpoint, chunk, chunk.size, timeoutMs)
            if (written <= 0) {
                throw TransportException("serial write stalled after $offset/${data.size} bytes")
            }
            offset += written
        }
    }

    override fun read(buffer: ByteArray, length: Int, timeoutMs: Int): Int =
        try {
            usb.bulkTransferIn(inEndpoint, buffer, length, timeoutMs)
        } catch (e: TransportException) {
            0 // treat a read timeout as "0 bytes available" rather than a hard failure
        }
}
