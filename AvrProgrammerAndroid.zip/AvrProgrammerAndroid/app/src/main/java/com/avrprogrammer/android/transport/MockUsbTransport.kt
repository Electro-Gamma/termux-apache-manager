package com.avrprogrammer.android.transport

/**
 * Pure-Kotlin fake transport for protocol unit tests (project brief section 21:
 * "Create mock transports so protocols can be tested without physical hardware").
 * No dependency on android.hardware.usb, so it runs under plain JUnit.
 *
 * Responses are supplied by a caller-provided function so a test can script exact
 * request/response pairs (e.g. USBasp Programming Enable expecting the third command
 * byte to be echoed back) and assert on exactly what bytes the programmer sent.
 */
class MockUsbTransport(
    override val info: UsbDeviceInfo = UsbDeviceInfo(
        vendorId = 0x16C0, productId = 0x05DC,
        manufacturerName = "mock", productName = "mock", serialNumber = "0000000000",
        deviceName = "/mock", interfaces = emptyList()
    ),
    private val controlHandler: (requestType: Int, request: Int, value: Int, index: Int, outData: ByteArray, length: Int) -> ByteArray = { _, _, _, _, _, length -> ByteArray(length) },
    private val bulkOutHandler: (endpoint: Int, data: ByteArray) -> Unit = { _, _ -> },
    private val bulkInHandler: (endpoint: Int, length: Int) -> ByteArray = { _, length -> ByteArray(length) }
) : UsbTransport {

    /** Every control transfer this transport has seen, for assertions in tests. */
    val controlLog = mutableListOf<ControlCall>()
    val bulkOutLog = mutableListOf<Pair<Int, ByteArray>>()

    data class ControlCall(val requestType: Int, val request: Int, val value: Int, val index: Int, val outData: ByteArray)

    private var open = false

    override val isOpen: Boolean get() = open

    override fun open() { open = true }
    override fun close() { open = false }

    override fun controlTransfer(requestType: Int, request: Int, value: Int, index: Int, buffer: ByteArray, length: Int, timeoutMs: Int): Int {
        controlLog += ControlCall(requestType, request, value, index, buffer.copyOf(length.coerceAtMost(buffer.size)))
        val response = controlHandler(requestType, request, value, index, buffer, length)
        response.copyInto(buffer, 0, 0, minOf(response.size, buffer.size, length))
        return minOf(response.size, length)
    }

    override fun bulkTransferOut(endpointAddress: Int, data: ByteArray, length: Int, timeoutMs: Int): Int {
        val slice = data.copyOf(length)
        bulkOutLog += endpointAddress to slice
        bulkOutHandler(endpointAddress, slice)
        return length
    }

    override fun bulkTransferIn(endpointAddress: Int, buffer: ByteArray, length: Int, timeoutMs: Int): Int {
        val response = bulkInHandler(endpointAddress, length)
        response.copyInto(buffer, 0, 0, minOf(response.size, buffer.size, length))
        return minOf(response.size, length)
    }

    override fun interruptTransferIn(endpointAddress: Int, buffer: ByteArray, length: Int, timeoutMs: Int): Int =
        bulkTransferIn(endpointAddress, buffer, length, timeoutMs)
}
