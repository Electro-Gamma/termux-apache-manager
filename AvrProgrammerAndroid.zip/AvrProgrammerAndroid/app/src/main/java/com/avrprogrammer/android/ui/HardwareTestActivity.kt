package com.avrprogrammer.android.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.avrprogrammer.android.databinding.ActivityHardwareTestBinding
import com.avrprogrammer.android.databinding.ItemUsbDeviceBinding
import com.avrprogrammer.android.programmer.ProgrammerRegistry
import com.avrprogrammer.android.transport.UsbDeviceInfo
import com.avrprogrammer.android.transport.UsbDeviceScanner
import com.avrprogrammer.android.transport.UsbHostTransport

/**
 * Project brief section 22: a dedicated screen for inspecting exactly what Android
 * sees on a plugged-in USB device (VID/PID/manufacturer/product/serial/interfaces/
 * endpoints/direction/type/max packet size), independent of whether this project
 * recognises the device as a supported programmer -- the whole point is to help
 * debug an *unsupported* one.
 */
class HardwareTestActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHardwareTestBinding
    private lateinit var scanner: UsbDeviceScanner
    private val adapter = DeviceAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHardwareTestBinding.inflate(layoutInflater)
        setContentView(binding.root)

        scanner = UsbDeviceScanner(this)
        binding.recyclerDevices.layoutManager = LinearLayoutManager(this)
        binding.recyclerDevices.adapter = adapter
        binding.btnRescan.setOnClickListener { rescan() }
        rescan()
    }

    private fun rescan() {
        if (!UsbHostTransport.isUsbHostSupported(this)) {
            adapter.submit(emptyList())
            return
        }
        val infos = scanner.listAttachedDevices().map { UsbHostTransport.buildDeviceInfo(it) }
        adapter.submit(infos)
    }

    private class DeviceAdapter : RecyclerView.Adapter<DeviceAdapter.VH>() {
        private var items: List<UsbDeviceInfo> = emptyList()

        fun submit(newItems: List<UsbDeviceInfo>) {
            items = newItems
            notifyDataSetChanged()
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val binding = ItemUsbDeviceBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            return VH(binding)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            holder.bind(items[position])
        }

        override fun getItemCount(): Int = items.size

        class VH(private val binding: ItemUsbDeviceBinding) : RecyclerView.ViewHolder(binding.root) {
            fun bind(info: UsbDeviceInfo) {
                val matched = ProgrammerRegistry.findByVidPid(info.vendorId, info.productId)
                binding.txtDeviceDetails.text = buildString {
                    appendLine("${info.vidPidHex()}  ${info.deviceName}")
                    appendLine("Manufacturer: ${info.manufacturerName ?: "(unknown -- grant permission to see this)"}")
                    appendLine("Product: ${info.productName ?: "(unknown)"}")
                    appendLine("Serial: ${info.serialNumber ?: "(unknown / not readable without permission)"}")
                    appendLine("Recognised as: ${matched?.displayName ?: "not in ProgrammerRegistry (unknown device)"}")
                    for (iface in info.interfaces) {
                        appendLine("Interface ${iface.interfaceIndex}: class=0x%02X subclass=0x%02X protocol=0x%02X".format(iface.interfaceClass, iface.interfaceSubclass, iface.interfaceProtocol))
                        for (ep in iface.endpoints) {
                            append("  EP 0x%02X ${ep.direction} ${ep.type} maxPacket=${ep.maxPacketSize}".format(ep.address))
                            appendLine()
                        }
                    }
                }.trim()
            }
        }
    }
}
