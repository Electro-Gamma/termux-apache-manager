package com.avrprogrammer.android.programmer

import com.avrprogrammer.android.device.AvrDevice
import com.avrprogrammer.android.memory.MemoryImage

/** Which named memory a read/write/erase targets. Mirrors AVRDUDE's -U flash:.../eeprom:... memory names. */
enum class MemoryId { FLASH, EEPROM }

enum class ImplementationStatus { IMPLEMENTED, PARTIAL, NOT_IMPLEMENTED }

enum class TransportKind { USB_CONTROL, USB_BULK_SERIAL, SERIAL_GENERIC, USB_HID, UNSUPPORTED_ON_ANDROID }

/**
 * Static metadata about one AVRDUDE-supported programmer -- independent of whether
 * it's actually implemented, so [ProgrammerRegistry] can list (and honestly label)
 * every programmer the project brief asks about, per section 4's per-programmer
 * checklist (name / VID / PID / interfaces / endpoints / transport / protocol / ...).
 */
data class ProgrammerDescriptor(
    val id: String,                  // matches AVRDUDE's -c id, e.g. "usbasp", "stk500v1"
    val displayName: String,
    val protocol: String,
    val transportKind: TransportKind,
    val knownVidPids: List<Pair<Int, Int>>, // (vendorId, productId); empty if not USB or highly variable (e.g. generic serial/CDC boards)
    val status: ImplementationStatus,
    val notes: String
)

fun interface ProgressListener {
    fun onProgress(memory: MemoryId, bytesDone: Int, bytesTotal: Int)
}

/**
 * Common surface every real (IMPLEMENTED) programmer exposes to
 * [com.avrprogrammer.android.engine.AvrdudeEngine]. NOT_IMPLEMENTED programmers do
 * not get a Programmer instance at all -- see [com.avrprogrammer.android.programmer.NotImplementedProgrammer]
 * for how the engine reports that distinctly from a runtime failure.
 */
interface Programmer {
    val descriptor: ProgrammerDescriptor

    /** Opens the transport and puts the target into programming mode (ISP "enable programming" handshake). */
    fun open(device: AvrDevice)

    /** Leaves programming mode and closes the transport. Safe to call even if open() partially failed. */
    fun close()

    fun readSignature(device: AvrDevice): IntArray

    fun chipErase(device: AvrDevice)

    fun readMemory(device: AvrDevice, memory: MemoryId, progress: ProgressListener? = null): MemoryImage

    fun writeMemory(device: AvrDevice, memory: MemoryId, image: MemoryImage, progress: ProgressListener? = null)

    fun readFuse(device: AvrDevice, fuseName: String): Int

    fun writeFuse(device: AvrDevice, fuseName: String, value: Int)

    fun readLock(device: AvrDevice): Int

    fun writeLock(device: AvrDevice, value: Int)

    fun readCalibration(device: AvrDevice): Int

    /** SCK/ISP clock speed in Hz, where the programmer supports configuring it (USBasp does; not all do). */
    fun setSckFrequencyHz(hz: Int) { /* no-op unless overridden */ }
}
