package com.avrprogrammer.android.transport

import android.content.Context
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import com.avrprogrammer.android.errors.TransportException
import com.avrprogrammer.android.logging.Logger

/**
 * Real transport backed by Android's USB Host APIs (`UsbManager`, `UsbDevice`,
 * `UsbDeviceConnection`, `UsbInterface`, `UsbEndpoint` -- project brief section 3).
 *
 * A device can expose more than one interface with different endpoint layouts (the
 * brief explicitly warns "do not assume that every programmer uses the same
 * interface or endpoint layout"), so this transport claims a *specific* interface
 * chosen by the caller (see [UsbDeviceScanner]) rather than assuming interface 0.
 */
class UsbHostTransport(
    private val context: Context,
    private val device: UsbDevice,
    private val usbInterface: UsbInterface
) : UsbTransport {

    private val usbManager: UsbManager by lazy {
        context.getSystemService(Context.USB_SERVICE) as UsbManager
    }

    private var connection: UsbDeviceConnection? = null
    private var claimed = false

    override val info: UsbDeviceInfo = buildDeviceInfo(device)

    override val isOpen: Boolean get() = connection != null

    override fun open() {
        if (isOpen) return
        if (!usbManager.hasPermission(device)) {
            throw TransportException(
                "no USB permission granted for ${info.vidPidHex()}; call UsbPermissionManager.requestPermission first",
                usbError = "PERMISSION_DENIED"
            )
        }
        val conn = usbManager.openDevice(device)
            ?: throw TransportException("UsbManager.openDevice() returned null for ${info.vidPidHex()}", usbError = "OPEN_FAILED")

        // Some composite/CDC devices need the kernel driver detached before we can claim
        // the interface; forceClaim=true asks Android to do this for us where supported.
        val ok = conn.claimInterface(usbInterface, true)
        if (!ok) {
            conn.close()
            throw TransportException(
                "failed to claim USB interface ${usbInterface.id} on ${info.vidPidHex()}",
                usbError = "CLAIM_INTERFACE_FAILED"
            )
        }
        connection = conn
        claimed = true
        Logger.info("UsbHostTransport", "opened ${info.vidPidHex()} (${info.productName ?: "unknown product"}), interface ${usbInterface.id}")
    }

    override fun close() {
        val conn = connection ?: return
        try {
            if (claimed) {
                conn.releaseInterface(usbInterface)
                claimed = false
            }
        } finally {
            conn.close()
            connection = null
            Logger.info("UsbHostTransport", "closed ${info.vidPidHex()}")
        }
    }

    override fun controlTransfer(
        requestType: Int, request: Int, value: Int, index: Int, buffer: ByteArray, length: Int, timeoutMs: Int
    ): Int {
        val conn = requireOpen()
        Logger.rawOut("USB[ctrl]", byteArrayOf(requestType.toByte(), request.toByte(), value.toByte(), (value shr 8).toByte(), index.toByte(), (index shr 8).toByte()))
        val result = conn.controlTransfer(requestType, request, value, index, buffer, length, timeoutMs)
        if (result < 0) {
            throw TransportException(
                "control transfer failed (bRequest=0x%02X wValue=0x%04X wIndex=0x%04X len=%d)".format(request, value, index, length),
                usbError = "CONTROL_TRANSFER_FAILED"
            )
        }
        Logger.rawIn("USB[ctrl]", buffer.copyOf(result))
        return result
    }

    override fun bulkTransferOut(endpointAddress: Int, data: ByteArray, length: Int, timeoutMs: Int): Int {
        val conn = requireOpen()
        val ep = findEndpoint(endpointAddress, outbound = true)
        Logger.rawOut("USB[bulk]", data.copyOf(length))
        val result = conn.bulkTransfer(ep, data, length, timeoutMs)
        if (result < 0) {
            throw TransportException("bulk OUT transfer failed on endpoint 0x%02X".format(endpointAddress), usbError = "BULK_OUT_FAILED")
        }
        return result
    }

    override fun bulkTransferIn(endpointAddress: Int, buffer: ByteArray, length: Int, timeoutMs: Int): Int {
        val conn = requireOpen()
        val ep = findEndpoint(endpointAddress, outbound = false)
        val result = conn.bulkTransfer(ep, buffer, length, timeoutMs)
        if (result < 0) {
            throw TransportException("bulk IN transfer failed on endpoint 0x%02X".format(endpointAddress), usbError = "BULK_IN_FAILED")
        }
        Logger.rawIn("USB[bulk]", buffer.copyOf(result))
        return result
    }

    override fun interruptTransferIn(endpointAddress: Int, buffer: ByteArray, length: Int, timeoutMs: Int): Int {
        val conn = requireOpen()
        val ep = findEndpoint(endpointAddress, outbound = false)
        val result = conn.bulkTransfer(ep, buffer, length, timeoutMs) // Android has no separate interrupt call; same path as bulk.
        if (result < 0) {
            throw TransportException("interrupt IN transfer failed on endpoint 0x%02X".format(endpointAddress), usbError = "INTERRUPT_IN_FAILED")
        }
        Logger.rawIn("USB[intr]", buffer.copyOf(result))
        return result
    }

    /**
     * Resets the device at the USB level (project brief: "USB reset where Android
     * permits it"). Android only exposes this as a data-reset via `USBFS_IOCTL` under
     * the hood through the public `resetDevice()`-equivalent... in practice the public
     * API doesn't expose a raw port reset, only re-claiming after close/reopen, so this
     * performs a close+reopen cycle which is the closest portable equivalent.
     */
    fun softReset() {
        close()
        open()
    }

    private fun requireOpen(): UsbDeviceConnection =
        connection ?: throw TransportException("transport not open; call open() first", usbError = "NOT_OPEN")

    private fun findEndpoint(address: Int, outbound: Boolean): UsbEndpoint {
        for (i in 0 until usbInterface.endpointCount) {
            val ep = usbInterface.getEndpoint(i)
            if (ep.address == address) return ep
        }
        throw TransportException("no ${if (outbound) "OUT" else "IN"} endpoint at address 0x%02X on claimed interface".format(address), usbError = "ENDPOINT_NOT_FOUND")
    }

    companion object {
        fun isUsbHostSupported(context: Context): Boolean =
            context.packageManager.hasSystemFeature("android.hardware.usb.host")

        fun buildDeviceInfo(device: UsbDevice): UsbDeviceInfo {
            val interfaces = (0 until device.interfaceCount).map { i ->
                val iface = device.getInterface(i)
                val endpoints = (0 until iface.endpointCount).map { j ->
                    val ep = iface.getEndpoint(j)
                    UsbEndpointInfo(
                        address = ep.address,
                        direction = if (ep.direction == UsbConstants.USB_DIR_IN) UsbEndpointInfo.Direction.IN else UsbEndpointInfo.Direction.OUT,
                        type = when (ep.type) {
                            UsbConstants.USB_ENDPOINT_XFER_BULK -> UsbEndpointInfo.Type.BULK
                            UsbConstants.USB_ENDPOINT_XFER_INT -> UsbEndpointInfo.Type.INTERRUPT
                            UsbConstants.USB_ENDPOINT_XFER_ISOC -> UsbEndpointInfo.Type.ISOCHRONOUS
                            else -> UsbEndpointInfo.Type.CONTROL
                        },
                        maxPacketSize = ep.maxPacketSize
                    )
                }
                UsbInterfaceInfo(
                    interfaceIndex = iface.id,
                    interfaceClass = iface.interfaceClass,
                    interfaceSubclass = iface.interfaceSubclass,
                    interfaceProtocol = iface.interfaceProtocol,
                    endpoints = endpoints
                )
            }
            return UsbDeviceInfo(
                vendorId = device.vendorId,
                productId = device.productId,
                manufacturerName = safeOrNull { device.manufacturerName },
                productName = safeOrNull { device.productName },
                serialNumber = safeOrNull { device.serialNumber },
                deviceName = device.deviceName,
                interfaces = interfaces
            )
        }

        /**
         * `UsbDevice.manufacturerName`/`productName`/`serialNumber` throw
         * `SecurityException` on Android 12+ when the app does not yet hold permission
         * for the device (e.g. while just listing attached devices before the user has
         * granted anything) -- swallow that into a null rather than crashing enumeration.
         */
        private inline fun safeOrNull(block: () -> String?): String? =
            try { block() } catch (e: SecurityException) { null }
    }
}
