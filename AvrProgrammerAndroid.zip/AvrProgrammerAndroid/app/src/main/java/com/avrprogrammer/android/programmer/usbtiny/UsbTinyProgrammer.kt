package com.avrprogrammer.android.programmer.usbtiny

import com.avrprogrammer.android.device.AvrDevice
import com.avrprogrammer.android.device.AvrMemoryDef
import com.avrprogrammer.android.errors.MemoryOperationException
import com.avrprogrammer.android.errors.ProtocolException
import com.avrprogrammer.android.errors.TransportException
import com.avrprogrammer.android.memory.MemoryImage
import com.avrprogrammer.android.programmer.AbstractIspOpcodeProgrammer
import com.avrprogrammer.android.programmer.ImplementationStatus
import com.avrprogrammer.android.programmer.MemoryId
import com.avrprogrammer.android.programmer.ProgrammerDescriptor
import com.avrprogrammer.android.programmer.ProgressListener
import com.avrprogrammer.android.programmer.TransportKind
import com.avrprogrammer.android.transport.UsbTransport

/**
 * USBtinyISP (Limor Fried / Adafruit's design), ported from AVRDUDE's src/usbtiny.c
 * and src/usbtiny.h -- project brief section 6.
 *
 * Like USBasp, USBtinyISP's firmware exposes native bulk byte-stream read/write
 * requests for flash and EEPROM (FLASH_READ/FLASH_WRITE/EEPROM_READ/EEPROM_WRITE)
 * that are much faster than issuing one 4-byte SPI opcode per byte, so those are
 * implemented natively here rather than falling back to
 * [com.avrprogrammer.android.programmer.AbstractIspOpcodeProgrammer]'s generic
 * page-loop. Fuses/lock/signature/calibration/Programming-Enable/Chip-Erase all go
 * through the generic opcode path via [ispTransmit], which relays raw ISP
 * instructions through the SPI (USBTINY_SPI) request -- exactly like real USBtinyISP
 * firmware, which has no fuse/signature-specific requests of its own.
 */
class UsbTinyProgrammer(private val usb: UsbTransport) : AbstractIspOpcodeProgrammer() {

    companion object {
        // src/usbtiny.h
        private const val REQ_POWERUP = 5
        private const val REQ_POWERDOWN = 6
        private const val REQ_SPI = 7
        private const val REQ_FLASH_READ = 9
        private const val REQ_FLASH_WRITE = 10
        private const val REQ_EEPROM_READ = 11
        private const val REQ_EEPROM_WRITE = 12

        private const val RESET_LOW = 0
        private const val RESET_HIGH = 1

        private const val SCK_MIN_US = 1
        private const val SCK_MAX_US = 250
        private const val SCK_DEFAULT_US = 10

        private const val CHUNK_SIZE = 64 // conservative; real avrdude scales this by SCK period, see usbtiny_set_chunk_size

        // bmRequestType per usb_control()/usb_in()/usb_out() in src/usbtiny.c.
        private const val REQ_TYPE_IN = 0xC0  // USB_ENDPOINT_IN | VENDOR | DEVICE
        private const val REQ_TYPE_OUT = 0x40 // USB_ENDPOINT_OUT | VENDOR | DEVICE

        const val USBTINY_VID = 0x1781
        const val USBTINY_PID = 0x0C9F

        /** Flash addresses at/above this need the generic per-byte opcode fallback -- see usbtiny_paged_load()'s "byte access workaround". */
        private const val LARGE_FLASH_THRESHOLD = 0x10000

        fun descriptor(): ProgrammerDescriptor = ProgrammerDescriptor(
            id = "usbtiny",
            displayName = "USBtinyISP",
            protocol = "USBtiny vendor-specific control transfers",
            transportKind = TransportKind.USB_CONTROL,
            knownVidPids = listOf(USBTINY_VID to USBTINY_PID),
            status = ImplementationStatus.IMPLEMENTED,
            notes = "Full SPI/ISP mode per src/usbtiny.c. TPI relay (usbtiny_cmd_tpi) not implemented."
        )
    }

    private var sckPeriodUs = SCK_DEFAULT_US

    override val descriptor: ProgrammerDescriptor get() = Companion.descriptor()

    override fun open(device: AvrDevice) {
        usb.open()
        initializeSession(device)
    }

    override fun close() {
        try {
            controlOut(REQ_POWERDOWN, 0, 0)
        } finally {
            usb.close()
        }
    }

    /** Mirrors usbtiny_initialize(): power up with RESET low, let the target settle, then retry Programming Enable up to 4 times, toggling RESET between attempts. */
    private fun initializeSession(device: AvrDevice) {
        controlOut(REQ_POWERUP, sckPeriodUs, RESET_LOW)
        Thread.sleep(50) // usleep(50000)

        var enabled = false
        for (attempt in 0 until 4) {
            try {
                programEnable(device)
                enabled = true
                break
            } catch (e: ProtocolException) {
                controlOut(REQ_POWERUP, sckPeriodUs, RESET_HIGH)
                controlOut(REQ_POWERUP, sckPeriodUs, RESET_LOW)
                Thread.sleep(50)
            }
        }
        if (!enabled) {
            throw ProtocolException(
                "USBtinyISP: target did not respond to Programming Enable after 4 attempts",
                protocol = "USBtinyISP", command = "Programming Enable"
            )
        }
    }

    override fun chipErase(device: AvrDevice) {
        genericChipErase(device)
        initializeSession(device)
    }

    override fun setSckFrequencyHz(hz: Int) {
        // usbtiny_set_sck_period() works in a period (usec), not Hz; convert and clamp
        // exactly as src/usbtiny.c does.
        val periodUs = if (hz <= 0) SCK_DEFAULT_US else (1_000_000.0 / hz).toInt()
        sckPeriodUs = periodUs.coerceIn(SCK_MIN_US, SCK_MAX_US)
        controlOut(REQ_POWERUP, sckPeriodUs, RESET_LOW)
    }

    /** The one primitive AbstractIspOpcodeProgrammer needs: relay a raw 4-byte ISP instruction via USBTINY_SPI. */
    override fun ispTransmit(cmd: ByteArray): ByteArray {
        val res = ByteArray(4)
        // src/usbtiny.c usbtiny_cmd(): wValue = (cmd[1]<<8)|cmd[0], wIndex = (cmd[3]<<8)|cmd[2].
        val value = ((cmd[1].toInt() and 0xFF) shl 8) or (cmd[0].toInt() and 0xFF)
        val index = ((cmd[3].toInt() and 0xFF) shl 8) or (cmd[2].toInt() and 0xFF)
        val n = usb.controlTransfer(REQ_TYPE_IN, REQ_SPI, value, index, res, 4, 500 + 8 * sckPeriodUs)
        if (n != 4) {
            throw TransportException("USBtinyISP SPI relay returned $n bytes, expected 4")
        }
        return res
    }

    override fun readMemory(device: AvrDevice, memory: MemoryId, progress: ProgressListener?): MemoryImage {
        val mem = memoryDef(device, memory)
        val request = if (memory == MemoryId.FLASH) REQ_FLASH_READ else REQ_EEPROM_READ

        if (memory == MemoryId.FLASH && mem.size > LARGE_FLASH_THRESHOLD) {
            // usbtiny_paged_load()'s documented "byte access workaround" for flash above 64 KiB:
            // the firmware's FLASH_READ request only carries a 16-bit address, so addresses at or
            // beyond 0x10000 fall back to the generic per-byte opcode path (which itself issues
            // Load Extended Address as needed).
            return readMemoryGeneric(mem, progress?.let { p -> { done: Int, total: Int -> p.onProgress(memory, done, total) } })
        }

        val image = MemoryImage(mem.size)
        var addr = 0
        while (addr < mem.size) {
            val chunk = minOf(CHUNK_SIZE, mem.size - addr)
            val buffer = ByteArray(chunk)
            val n = usb.controlTransfer(REQ_TYPE_IN, request, 0, addr, buffer, chunk, 500 + 32 * sckPeriodUs * chunk / 8)
            if (n != chunk) {
                throw TransportException("USBtinyISP ${if (memory == MemoryId.FLASH) "FLASH_READ" else "EEPROM_READ"} returned $n of $chunk bytes at 0x%X".format(addr))
            }
            image.fillFrom(buffer, addr)
            addr += chunk
            progress?.onProgress(memory, addr, mem.size)
        }
        return image
    }

    override fun writeMemory(device: AvrDevice, memory: MemoryId, image: MemoryImage, progress: ProgressListener?) {
        val mem = memoryDef(device, memory)

        if (memory == MemoryId.FLASH && mem.size > LARGE_FLASH_THRESHOLD) {
            writeMemoryGeneric(mem, image, progress?.let { p -> { done: Int, total: Int -> p.onProgress(memory, done, total) } })
            return
        }

        val request = if (memory == MemoryId.FLASH) REQ_FLASH_WRITE else REQ_EEPROM_WRITE
        val pageSize = mem.pageSize.takeIf { it > 0 } ?: mem.size
        val writePage = mem.writePage

        var addr = 0
        while (addr < mem.size) {
            var chunk = minOf(CHUNK_SIZE, mem.size - addr)
            if (mem.isPaged && chunk > pageSize) chunk = pageSize
            val data = ByteArray(chunk) { image.get(addr + it).toByte() }

            // wValue = per-byte poll delay (0: paged memories are committed with an explicit
            // writepage + poll instead, matching usbtiny_paged_write()'s `if (!m->paged)` branch).
            val n = usb.controlTransfer(REQ_TYPE_OUT, request, 0, addr, data, chunk, 500 + 32 * sckPeriodUs * chunk / 8)
            if (n != chunk) {
                throw TransportException("USBtinyISP ${if (memory == MemoryId.FLASH) "FLASH_WRITE" else "EEPROM_WRITE"} accepted $n of $chunk bytes at 0x%X".format(addr))
            }

            val next = addr + chunk
            if (mem.isPaged && writePage != null && (next % pageSize == 0 || next == mem.size)) {
                val rem = next % pageSize
                val pageStart = next - (if (rem == 0) pageSize else rem)
                val pageCmd = writePage.newCommand()
                val pageAddr = if (mem.isWordOriented) pageStart / 2 else pageStart
                writePage.setAddress(pageCmd, pageAddr.toLong())
                ispTransmit(pageCmd)
                waitForCompletion(10_000)
            }
            addr = next
            progress?.onProgress(memory, addr, mem.size)
        }
    }

    private fun memoryDef(device: AvrDevice, memory: MemoryId): AvrMemoryDef = when (memory) {
        MemoryId.FLASH -> device.flash
        MemoryId.EEPROM -> device.eeprom ?: throw MemoryOperationException("device ${device.desc} has no EEPROM defined")
    }

    private fun controlOut(request: Int, value: Int, index: Int) {
        // usb_control() in usbtiny.c is IN-direction with a 0-length buffer (no data stage).
        usb.controlTransfer(REQ_TYPE_IN, request, value, index, ByteArray(0), 0, 500)
    }
}
