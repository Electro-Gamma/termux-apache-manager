package com.avrprogrammer.android.programmer.usbasp

import com.avrprogrammer.android.device.AvrDevice
import com.avrprogrammer.android.device.AvrMemoryDef
import com.avrprogrammer.android.errors.MemoryOperationException
import com.avrprogrammer.android.errors.ProtocolException
import com.avrprogrammer.android.errors.TransportException
import com.avrprogrammer.android.logging.Logger
import com.avrprogrammer.android.memory.MemoryImage
import com.avrprogrammer.android.programmer.AbstractIspOpcodeProgrammer
import com.avrprogrammer.android.programmer.ImplementationStatus
import com.avrprogrammer.android.programmer.MemoryId
import com.avrprogrammer.android.programmer.ProgrammerDescriptor
import com.avrprogrammer.android.programmer.ProgressListener
import com.avrprogrammer.android.programmer.TransportKind
import com.avrprogrammer.android.transport.UsbTransport

/**
 * USBasp (Thomas Fischl's design), SPI/ISP mode -- ported line-for-line in spirit
 * from AVRDUDE's src/usbasp.c and src/usbasp.h. This is the one programmer the
 * project brief mandates be "fully implemented" (section 5), so every control
 * request below matches the real firmware protocol exactly, including quirks (e.g.
 * ENABLEPROG's short 1-byte success response, the "set-address-twice" compatibility
 * dance for old vs new firmware) rather than a cleaned-up reinterpretation of them.
 *
 * TPI mode (ATtiny4/5/9/10/20/40-style parts) is a separate protocol in usbasp.c
 * (usbasp_tpi_*) and is NOT implemented here -- see PROGRAMMERS.md. Everything in
 * this class is the SPI/classic-ISP path (usbasp_spi_*).
 */
class UsbaspProgrammer(private val usb: UsbTransport) : AbstractIspOpcodeProgrammer() {

    companion object {
        // src/usbasp.h
        private const val FUNC_CONNECT = 1
        private const val FUNC_DISCONNECT = 2
        private const val FUNC_TRANSMIT = 3
        private const val FUNC_READFLASH = 4
        private const val FUNC_ENABLEPROG = 5
        private const val FUNC_WRITEFLASH = 6
        private const val FUNC_READEEPROM = 7
        private const val FUNC_WRITEEEPROM = 8
        private const val FUNC_SETLONGADDRESS = 9
        private const val FUNC_SETISPSCK = 10
        private const val FUNC_GETCAPABILITIES = 127

        private const val BLOCKFLAG_FIRST = 1

        private const val READBLOCKSIZE = 200
        private const val WRITEBLOCKSIZE = 200

        private const val CAP_TPI = 0x01

        // bmRequestType per src/usbasp.c usbasp_transmit(): VENDOR | DEVICE, direction bit 7.
        private const val REQ_TYPE_IN = 0xC0  // device-to-host
        private const val REQ_TYPE_OUT = 0x40 // host-to-device

        const val USBASP_SHARED_VID = 0x16C0
        const val USBASP_SHARED_PID = 0x05DC
        const val USBASP_OLD_VID = 0x03EB
        const val USBASP_OLD_PID = 0xC7B4

        // src/usbasp.c usbaspSCKoptions[], id -> Hz
        private val SCK_TABLE = listOf(
            13 to 3_000_000, 12 to 1_500_000, 11 to 750_000, 10 to 375_000,
            9 to 187_500, 8 to 93_750, 7 to 32_000, 6 to 16_000,
            5 to 8_000, 4 to 4_000, 3 to 2_000, 2 to 1_000, 1 to 500
        )

        fun descriptor(): ProgrammerDescriptor = ProgrammerDescriptor(
            id = "usbasp",
            displayName = "USBasp",
            protocol = "USBasp vendor-specific control transfers (SPI/ISP mode)",
            transportKind = TransportKind.USB_CONTROL,
            knownVidPids = listOf(USBASP_SHARED_VID to USBASP_SHARED_PID, USBASP_OLD_VID to USBASP_OLD_PID),
            status = ImplementationStatus.IMPLEMENTED,
            notes = "Full SPI/ISP mode per src/usbasp.c. TPI mode (usbasp_tpi_*) not implemented."
        )
    }

    private var capabilities: Long = 0
    private var sckFreqHz: Int = 0 // 0 = auto, matches struct pdata.sckfreq_hz

    override val descriptor: ProgrammerDescriptor get() = Companion.descriptor()

    override fun open(device: AvrDevice) {
        usb.open()
        initializeSpiSession(device)
    }

    override fun close() {
        try {
            val temp = ByteArray(4)
            transmit(receive = true, function = FUNC_DISCONNECT, send = temp, buffer = temp, length = temp.size)
        } catch (e: Exception) {
            Logger.warning("UsbaspProgrammer", "DISCONNECT failed during close(): ${e.message}")
        } finally {
            usb.close()
        }
    }

    /** Mirrors usbasp_initialize(): capabilities -> set SCK -> CONNECT -> settle -> ENABLEPROG. */
    private fun initializeSpiSession(device: AvrDevice) {
        val temp = ByteArray(4)
        val res = ByteArray(4)
        val n = transmit(receive = true, function = FUNC_GETCAPABILITIES, send = temp, buffer = res, length = 4)
        capabilities = if (n == 4) {
            (res[0].toLong() and 0xFF) or ((res[1].toLong() and 0xFF) shl 8) or
                ((res[2].toLong() and 0xFF) shl 16) or ((res[3].toLong() and 0xFF) shl 24)
        } else 0

        applySckFrequency(sckFreqHz)

        transmit(receive = true, function = FUNC_CONNECT, send = ByteArray(4), buffer = res, length = 4)
        Thread.sleep(100) // usleep(100000) in usbasp_initialize()

        enableProgramming(device)
    }

    private fun enableProgramming(device: AvrDevice) {
        val cmd = ByteArray(4)
        val res = ByteArray(4)
        val n = transmit(receive = true, function = FUNC_ENABLEPROG, send = cmd, buffer = res, length = 4)
        if (n != 1 || res[0].toInt() != 0) {
            throw ProtocolException(
                "USBasp Programming Enable failed (target not responding / wrong wiring / device not powered)",
                protocol = "USBasp",
                command = "ENABLEPROG",
                expected = "1-byte response of 0x00",
                received = if (n >= 1) "0x%02X (%d bytes)".format(res[0], n) else "no response"
            )
        }
    }

    /** The one primitive AbstractIspOpcodeProgrammer needs: relay a raw 4-byte ISP instruction. */
    override fun ispTransmit(cmd: ByteArray): ByteArray {
        val res = ByteArray(4)
        val n = transmit(receive = true, function = FUNC_TRANSMIT, send = cmd, buffer = res, length = 4)
        if (n != 4) {
            throw ProtocolException("USBasp TRANSMIT returned $n bytes, expected 4", protocol = "USBasp", command = "TRANSMIT")
        }
        return res
    }

    override fun chipErase(device: AvrDevice) {
        genericChipErase(device)
        // usbasp_spi_chip_erase() re-runs pgm->initialize() after the erase delay.
        initializeSpiSession(device)
    }

    override fun setSckFrequencyHz(hz: Int) {
        sckFreqHz = hz
        applySckFrequency(hz)
    }

    private fun applySckFrequency(hz: Int) {
        val clockOption = if (hz <= 0) {
            0 // USBASP_ISP_SCK_AUTO
        } else {
            // Pick the fastest supported SCK that does not exceed the requested frequency,
            // mirroring usbasp_spi_set_sck_period()'s "find next possible sck period" search
            // (that function works from a period in seconds; here we work from Hz directly,
            // same ordering, same table).
            SCK_TABLE.firstOrNull { it.second <= hz }?.first
                ?: SCK_TABLE.last().first // slower than the slowest table entry -> use the slowest
        }
        val cmd = ByteArray(4)
        cmd[0] = clockOption.toByte()
        val res = ByteArray(4)
        transmit(receive = true, function = FUNC_SETISPSCK, send = cmd, buffer = res, length = 4)
    }

    override fun readMemory(device: AvrDevice, memory: MemoryId, progress: ProgressListener?): MemoryImage {
        val mem = memoryDef(device, memory)
        val function = if (memory == MemoryId.FLASH) FUNC_READFLASH else FUNC_READEEPROM
        val image = MemoryImage(mem.size)
        val blockSize = blockSizeFor(READBLOCKSIZE)

        var address = 0
        while (address < mem.size) {
            val thisBlock = minOf(blockSize, mem.size - address)
            setLongAddress(address)

            val cmd = ByteArray(4)
            cmd[0] = (address and 0xFF).toByte()
            cmd[1] = ((address shr 8) and 0xFF).toByte()
            // cmd[2]/cmd[3] left 0: compatibility fields for firmware predating SETLONGADDRESS.

            val buffer = ByteArray(thisBlock)
            val n = transmit(receive = true, function = function, send = cmd, buffer = buffer, length = thisBlock)
            if (n != thisBlock) {
                throw TransportException("USBasp read${if (memory == MemoryId.FLASH) "flash" else "eeprom"} returned $n of $thisBlock bytes at 0x%X".format(address))
            }
            image.fillFrom(buffer, address)
            address += thisBlock
            progress?.onProgress(memory, address, mem.size)
        }
        return image
    }

    override fun writeMemory(device: AvrDevice, memory: MemoryId, image: MemoryImage, progress: ProgressListener?) {
        val mem = memoryDef(device, memory)
        val function = if (memory == MemoryId.FLASH) FUNC_WRITEFLASH else FUNC_WRITEEEPROM
        val pageSize = mem.pageSize.takeIf { it > 0 } ?: mem.size
        val blockSize = blockSizeFor(WRITEBLOCKSIZE)

        var address = 0
        var blockFlags = BLOCKFLAG_FIRST
        while (address < mem.size) {
            val thisBlock = minOf(blockSize, mem.size - address)
            setLongAddress(address)

            val cmd = ByteArray(4)
            cmd[0] = (address and 0xFF).toByte()
            cmd[1] = ((address shr 8) and 0xFF).toByte()
            cmd[2] = (pageSize and 0xFF).toByte()
            cmd[3] = ((blockFlags and 0x0F) + ((pageSize and 0xF00) shr 4)).toByte()
            blockFlags = 0

            val data = ByteArray(thisBlock) { image.get(address + it).toByte() }
            val n = transmit(receive = false, function = function, send = cmd, buffer = data, length = thisBlock)
            if (n != thisBlock) {
                throw TransportException("USBasp write${if (memory == MemoryId.FLASH) "flash" else "eeprom"} accepted $n of $thisBlock bytes at 0x%X".format(address))
            }
            address += thisBlock
            progress?.onProgress(memory, address, mem.size)
        }
        // The firmware needs a moment after the last page's internal write cycle completes.
        waitForCompletion(mem.pageSize.let { if (it > 0) 10_000 else 4_500 })
    }

    private fun setLongAddress(address: Int) {
        val cmd = ByteArray(4)
        cmd[0] = (address and 0xFF).toByte()
        cmd[1] = ((address shr 8) and 0xFF).toByte()
        cmd[2] = ((address shr 16) and 0xFF).toByte()
        cmd[3] = ((address shr 24) and 0xFF).toByte()
        val temp = ByteArray(4)
        transmit(receive = true, function = FUNC_SETLONGADDRESS, send = cmd, buffer = temp, length = temp.size)
    }

    private fun blockSizeFor(base: Int): Int =
        if (sckFreqHz in 1 until 10_000) base / 10 else base

    private fun memoryDef(device: AvrDevice, memory: MemoryId): AvrMemoryDef = when (memory) {
        MemoryId.FLASH -> device.flash
        MemoryId.EEPROM -> device.eeprom ?: throw MemoryOperationException("device ${device.desc} has no EEPROM defined")
    }

    /**
     * Wire-level equivalent of usbasp_transmit(): a vendor control transfer where
     * wValue = send[0] | (send[1] << 8) and wIndex = send[2] | (send[3] << 8), exactly
     * as AVRDUDE packs its 4-byte "send" arrays.
     */
    private fun transmit(receive: Boolean, function: Int, send: ByteArray, buffer: ByteArray, length: Int): Int {
        val requestType = if (receive) REQ_TYPE_IN else REQ_TYPE_OUT
        val value = (send[0].toInt() and 0xFF) or ((send[1].toInt() and 0xFF) shl 8)
        val index = (send[2].toInt() and 0xFF) or ((send[3].toInt() and 0xFF) shl 8)
        return usb.controlTransfer(requestType, function, value, index, buffer, length, 5000)
    }
}
