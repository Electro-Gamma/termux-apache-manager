package com.avrprogrammer.android.ui

import android.os.Bundle
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import com.avrprogrammer.android.databinding.ActivitySettingsBinding
import com.avrprogrammer.android.logging.LogLevel
import com.avrprogrammer.android.logging.Logger

/** Project brief section 18: a Settings screen. Kept intentionally small -- log verbosity and a default SCK frequency are the only engine-visible knobs this project currently exposes. */
class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private val prefsName = "avr_programmer_settings"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val prefs = getSharedPreferences(prefsName, MODE_PRIVATE)
        val levels = LogLevel.values().map { it.name }
        binding.spinnerLogLevel.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, levels)
        binding.spinnerLogLevel.setSelection(levels.indexOf(prefs.getString("log_level", Logger.minLevel.name)))

        val savedSck = prefs.getInt("default_sck_hz", -1)
        if (savedSck > 0) binding.editDefaultSck.setText(savedSck.toString())

        binding.btnSave.setOnClickListener {
            val level = LogLevel.valueOf(levels[binding.spinnerLogLevel.selectedItemPosition])
            Logger.minLevel = level
            val sckText = binding.editDefaultSck.text.toString().trim()
            prefs.edit()
                .putString("log_level", level.name)
                .putInt("default_sck_hz", sckText.toIntOrNull() ?: -1)
                .apply()
            finish()
        }
    }
}
