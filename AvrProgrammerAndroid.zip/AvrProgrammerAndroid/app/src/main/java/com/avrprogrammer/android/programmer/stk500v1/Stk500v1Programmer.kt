package com.avrprogrammer.android.programmer.stk500v1

import com.avrprogrammer.android.device.AvrDevice
import com.avrprogrammer.android.device.AvrMemoryDef
import com.avrprogrammer.android.errors.MemoryOperationException
import com.avrprogrammer.android.errors.ProtocolException
import com.avrprogrammer.android.errors.TransportException
import com.avrprogrammer.android.logging.Logger
import com.avrprogrammer.android.memory.MemoryImage
import com.avrprogrammer.android.programmer.AbstractIspOpcodeProgrammer
import com.avrprogrammer.android.programmer.ImplementationStatus
import com.avrprogrammer.android.programmer.MemoryId
import com.avrprogrammer.android.programmer.ProgrammerDescriptor
import com.avrprogrammer.android.programmer.ProgressListener
import com.avrprogrammer.android.programmer.TransportKind
import com.avrprogrammer.android.transport.SerialTransport

/**
 * STK500 v1 (AVR061 application-note protocol, "Cmnd_STK_*"), ported from AVRDUDE's
 * src/stk500.c and src/stk500_private.h -- project brief section 7. This is a
 * byte-stream protocol over a plain serial link, so it also implements
 * "Arduino as ISP" (project brief section 9): an ArduinoISP sketch speaks this exact
 * protocol, only the framing differs from real STK500 hardware in that AVRDUDE's own
 * "arduino" programmer variant reads the signature with a small quirk for very old
 * bootloaders (see [readSignature] override below) -- everything else is identical,
 * confirmed against src/arduino.c which reuses stk500.c's functions directly.
 *
 * Deliberately kept separate from STK500v2 ("Cmnd_STK2_*"/protocol used by AVRISP
 * mkII and newer STK500 firmware): the project brief explicitly warns not to assume
 * these are interchangeable, and they are wire-incompatible.
 */
class Stk500v1Programmer(private val serial: SerialTransport, private val isArduinoVariant: Boolean = false) : AbstractIspOpcodeProgrammer() {

    companion object {
        // src/stk500_private.h
        private const val Resp_STK_OK = 0x10
        private const val Resp_STK_FAILED = 0x11
        private const val Resp_STK_NODEVICE = 0x13
        private const val Resp_STK_INSYNC = 0x14
        private const val Resp_STK_NOSYNC = 0x15

        private const val Sync_CRC_EOP = 0x20

        private const val Cmnd_STK_GET_SYNC = 0x30
        private const val Cmnd_STK_ENTER_PROGMODE = 0x50
        private const val Cmnd_STK_LEAVE_PROGMODE = 0x51
        private const val Cmnd_STK_LOAD_ADDRESS = 0x55
        private const val Cmnd_STK_UNIVERSAL = 0x56
        private const val Cmnd_STK_PROG_PAGE = 0x64
        private const val Cmnd_STK_READ_PAGE = 0x74

        private const val MAX_SYNC_ATTEMPTS = 10
        private const val DEFAULT_BAUD_RATE = 115200

        fun descriptor(): ProgrammerDescriptor = ProgrammerDescriptor(
            id = "stk500v1",
            displayName = "STK500 v1 / Arduino as ISP",
            protocol = "STK500 v1 (AVR061 application note, Cmnd_STK_*) over a serial byte stream",
            transportKind = TransportKind.USB_BULK_SERIAL,
            knownVidPids = emptyList(), // genuinely variable: any USB-CDC serial adapter or Arduino board
            status = ImplementationStatus.IMPLEMENTED,
            notes = "Full protocol per src/stk500.c. Serial transport currently limited to USB CDC-ACM (see CdcAcmSerialTransport); vendor USB-serial chips (FTDI/CP210x/CH340) not implemented."
        )

        fun arduinoDescriptor(): ProgrammerDescriptor = descriptor().copy(
            id = "arduino",
            displayName = "Arduino as ISP",
            notes = "Same STK500v1 wire protocol as stk500v1 (see src/arduino.c, which reuses stk500.c directly)."
        )
    }

    private var extAddrByte = -1 // my.ext_addr_byte in stk500.c: -1 forces the first LOAD_ADDRESS to also send Load Ext Addr

    override val descriptor: ProgrammerDescriptor get() = if (isArduinoVariant) arduinoDescriptor() else Companion.descriptor()

    override fun open(device: AvrDevice) {
        serial.open()
        serial.setLineCoding(DEFAULT_BAUD_RATE)
        serial.setDtrRts(dtr = true, rts = true)
        Thread.sleep(50)
        getSync()
        enterProgMode()
    }

    override fun close() {
        try {
            val buf = byteArrayOf(Cmnd_STK_LEAVE_PROGMODE.toByte(), Sync_CRC_EOP.toByte())
            serial.write(buf, 1000)
            recvExact(2, 1000) // INSYNC, OK -- best-effort, ignore mismatches on the way out
        } catch (e: Exception) {
            Logger.warning("Stk500v1Programmer", "LEAVE_PROGMODE failed during close(): ${e.message}")
        } finally {
            serial.close()
        }
    }

    private fun getSync() {
        val cmd = byteArrayOf(Cmnd_STK_GET_SYNC.toByte(), Sync_CRC_EOP.toByte())
        // "Send and drain a few times to get rid of line noise" (stk500_getsync()).
        serial.write(cmd, 1000)
        drain()
        serial.write(cmd, 1000)
        drain()

        for (attempt in 0 until MAX_SYNC_ATTEMPTS) {
            serial.write(cmd, 1000)
            val resp = ByteArray(1)
            val n = serial.read(resp, 1, 1000)
            if (n == 1 && (resp[0].toInt() and 0xFF) == Resp_STK_INSYNC) {
                val ok = recvExact(1, 1000)
                if ((ok[0].toInt() and 0xFF) != Resp_STK_OK) {
                    throw ProtocolException("STK500v1 sync: expected OK after INSYNC, got 0x%02X".format(ok[0]), protocol = "STK500v1")
                }
                return
            }
        }
        throw ProtocolException(
            "STK500v1: could not get in sync after $MAX_SYNC_ATTEMPTS attempts (check baud rate / wiring / that the board is running an ISP sketch or STK500 firmware)",
            protocol = "STK500v1", command = "GET_SYNC"
        )
    }

    private fun drain() {
        val buf = ByteArray(64)
        // Best-effort short-timeout flush; a real timeout (nothing left to read) is expected and not an error.
        while (serial.read(buf, buf.size, 20) > 0) { /* discard */ }
    }

    private fun enterProgMode() {
        var tries = 0
        while (true) {
            tries++
            serial.write(byteArrayOf(Cmnd_STK_ENTER_PROGMODE.toByte(), Sync_CRC_EOP.toByte()), 1000)
            val sync = recvExact(1, 1000)[0].toInt() and 0xFF
            if (sync == Resp_STK_NOSYNC) {
                if (tries > 33) throw ProtocolException("STK500v1: cannot get into sync entering programming mode", protocol = "STK500v1")
                getSync()
                continue
            }
            if (sync != Resp_STK_INSYNC) {
                throw ProtocolException("STK500v1: expected INSYNC, got 0x%02X".format(sync), protocol = "STK500v1", command = "ENTER_PROGMODE")
            }
            val status = recvExact(1, 1000)[0].toInt() and 0xFF
            when (status) {
                Resp_STK_OK -> return
                Resp_STK_NODEVICE -> throw ProtocolException("STK500v1: programmer reports no device attached", protocol = "STK500v1")
                Resp_STK_FAILED -> throw ProtocolException("STK500v1: unable to enter programming mode", protocol = "STK500v1")
                else -> throw ProtocolException("STK500v1: unknown ENTER_PROGMODE response 0x%02X".format(status), protocol = "STK500v1")
            }
        }
    }

    override fun chipErase(device: AvrDevice) {
        genericChipErase(device)
        getSync()
        enterProgMode()
    }

    override fun readSignature(device: AvrDevice): IntArray {
        // src/arduino.c: modern Arduino ISP sketches answer the generic ISP Read
        // Signature opcode fine, so the Arduino variant only differs in the rare case
        // of very old bootloaders that don't -- not distinguishable up front, so this
        // simply uses the same generic path as plain STK500v1; documented here rather
        // than silently assumed identical.
        return super.readSignature(device)
    }

    /** The one primitive AbstractIspOpcodeProgrammer needs: Cmnd_STK_UNIVERSAL relay. */
    override fun ispTransmit(cmd: ByteArray): ByteArray {
        val buf = byteArrayOf(Cmnd_STK_UNIVERSAL.toByte(), cmd[0], cmd[1], cmd[2], cmd[3], Sync_CRC_EOP.toByte())
        serial.write(buf, 1000)

        val sync = recvExact(1, 1000)[0].toInt() and 0xFF
        if (sync != Resp_STK_INSYNC) {
            throw ProtocolException("STK500v1: programmer out of sync (UNIVERSAL)", protocol = "STK500v1", command = "UNIVERSAL")
        }
        val res = ByteArray(4)
        res[0] = cmd[1]
        res[1] = cmd[2]
        res[2] = cmd[3]
        res[3] = recvExact(1, 1000)[0]

        val ok = recvExact(1, 1000)[0].toInt() and 0xFF
        if (ok != Resp_STK_OK) {
            throw ProtocolException("STK500v1: expected OK after UNIVERSAL response, got 0x%02X".format(ok), protocol = "STK500v1")
        }
        return res
    }

    /** Word address for flash (matches its ISP addressing), byte address for EEPROM -- mirrors set_memchr_a_div()'s a_div selection for a "genuine" (non-bootloader) STK500v1 target. */
    private fun addressDivisor(mem: AvrMemoryDef): Int = if (mem.isWordOriented) 2 else 1

    /** Port of stk500_loadaddr(): sends Load Extended Address (only when the 64K-word segment changed) then Cmnd_STK_LOAD_ADDRESS. */
    private fun loadAddress(mem: AvrMemoryDef, byteAddr: Int) {
        val addr = byteAddr / addressDivisor(mem)

        val lext = mem.loadExtAddr
        if (lext != null) {
            val extByte = (addr ushr 16) and 0xFF
            if (extByte != extAddrByte) {
                val cmd = lext.newCommand()
                lext.setAddress(cmd, addr.toLong())
                ispTransmit(cmd)
                extAddrByte = extByte
            }
        }

        var tries = 0
        while (true) {
            tries++
            val buf = byteArrayOf(
                Cmnd_STK_LOAD_ADDRESS.toByte(), (addr and 0xFF).toByte(), ((addr shr 8) and 0xFF).toByte(), Sync_CRC_EOP.toByte()
            )
            serial.write(buf, 1000)
            val sync = recvExact(1, 1000)[0].toInt() and 0xFF
            if (sync == Resp_STK_NOSYNC) {
                if (tries > 33) throw ProtocolException("STK500v1: cannot get into sync loading address", protocol = "STK500v1")
                getSync()
                continue
            }
            if (sync != Resp_STK_INSYNC) throw ProtocolException("STK500v1: expected INSYNC, got 0x%02X".format(sync), protocol = "STK500v1", command = "LOAD_ADDRESS")
            val status = recvExact(1, 1000)[0].toInt() and 0xFF
            if (status != Resp_STK_OK) throw ProtocolException("STK500v1: LOAD_ADDRESS not acknowledged (0x%02X)".format(status), protocol = "STK500v1")
            return
        }
    }

    override fun readMemory(device: AvrDevice, memory: MemoryId, progress: ProgressListener?): MemoryImage {
        val mem = memoryDef(device, memory)
        val memChar = if (memory == MemoryId.FLASH) 'F'.code else 'E'.code
        val pageSize = mem.pageSize.takeIf { it > 0 } ?: mem.size
        val image = MemoryImage(mem.size)

        var addr = 0
        while (addr < mem.size) {
            val blockSize = minOf(pageSize, mem.size - addr)
            loadAddress(mem, addr)

            serial.write(
                byteArrayOf(
                    Cmnd_STK_READ_PAGE.toByte(), ((blockSize shr 8) and 0xFF).toByte(), (blockSize and 0xFF).toByte(),
                    memChar.toByte(), Sync_CRC_EOP.toByte()
                ),
                2000
            )
            val sync = recvExact(1, 2000)[0].toInt() and 0xFF
            if (sync != Resp_STK_INSYNC) throw ProtocolException("STK500v1: expected INSYNC, got 0x%02X".format(sync), protocol = "STK500v1", command = "READ_PAGE")

            val data = recvExact(blockSize, 5000)
            image.fillFrom(data, addr)

            val status = recvExact(1, 2000)[0].toInt() and 0xFF
            if (status != Resp_STK_OK) throw ProtocolException("STK500v1: READ_PAGE not acknowledged (0x%02X)".format(status), protocol = "STK500v1")

            addr += blockSize
            progress?.onProgress(memory, addr, mem.size)
        }
        return image
    }

    override fun writeMemory(device: AvrDevice, memory: MemoryId, image: MemoryImage, progress: ProgressListener?) {
        val mem = memoryDef(device, memory)
        val memChar = if (memory == MemoryId.FLASH) 'F'.code else 'E'.code
        val pageSize = mem.pageSize.takeIf { it > 0 } ?: mem.size

        var addr = 0
        while (addr < mem.size) {
            val blockSize = minOf(pageSize, mem.size - addr)
            loadAddress(mem, addr)

            val header = byteArrayOf(
                Cmnd_STK_PROG_PAGE.toByte(), ((blockSize shr 8) and 0xFF).toByte(), (blockSize and 0xFF).toByte(), memChar.toByte()
            )
            val payload = ByteArray(blockSize) { image.get(addr + it).toByte() }
            val frame = header + payload + byteArrayOf(Sync_CRC_EOP.toByte())
            serial.write(frame, 5000)

            val sync = recvExact(1, 2000)[0].toInt() and 0xFF
            if (sync != Resp_STK_INSYNC) throw ProtocolException("STK500v1: expected INSYNC, got 0x%02X".format(sync), protocol = "STK500v1", command = "PROG_PAGE")
            val status = recvExact(1, 5000)[0].toInt() and 0xFF
            if (status != Resp_STK_OK) throw ProtocolException("STK500v1: PROG_PAGE not acknowledged (0x%02X)".format(status), protocol = "STK500v1")

            addr += blockSize
            progress?.onProgress(memory, addr, mem.size)
        }
    }

    private fun memoryDef(device: AvrDevice, memory: MemoryId): AvrMemoryDef = when (memory) {
        MemoryId.FLASH -> device.flash
        MemoryId.EEPROM -> device.eeprom ?: throw MemoryOperationException("device ${device.desc} has no EEPROM defined")
    }

    /** Blocking read of exactly [length] bytes, looping over partial serial reads, matching serial_recv()'s exact-count semantics. */
    private fun recvExact(length: Int, timeoutMs: Int): ByteArray {
        val out = ByteArray(length)
        var got = 0
        val deadline = System.currentTimeMillis() + timeoutMs
        while (got < length) {
            val remaining = (deadline - System.currentTimeMillis()).toInt()
            if (remaining <= 0) {
                throw TransportException("STK500v1: serial read timed out ($got/$length bytes received)")
            }
            val chunk = ByteArray(length - got)
            val n = serial.read(chunk, chunk.size, remaining)
            if (n <= 0) continue
            chunk.copyInto(out, got, 0, n)
            got += n
        }
        return out
    }
}
