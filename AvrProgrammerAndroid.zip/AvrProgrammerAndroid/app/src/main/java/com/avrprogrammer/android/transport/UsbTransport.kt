package com.avrprogrammer.android.transport

/**
 * Snapshot of a USB device's identity and topology, used both by the hardware-test
 * screen (project brief section 22: VID/PID/manufacturer/product/serial/interfaces/
 * endpoints/...) and by [com.avrprogrammer.android.programmer.ProgrammerRegistry] to
 * match a plugged-in device against known programmers.
 */
data class UsbEndpointInfo(
    val address: Int,
    val direction: Direction,
    val type: Type,
    val maxPacketSize: Int
) {
    enum class Direction { IN, OUT }
    enum class Type { CONTROL, ISOCHRONOUS, BULK, INTERRUPT }
}

data class UsbInterfaceInfo(
    val interfaceIndex: Int,
    val interfaceClass: Int,
    val interfaceSubclass: Int,
    val interfaceProtocol: Int,
    val endpoints: List<UsbEndpointInfo>
)

data class UsbDeviceInfo(
    val vendorId: Int,
    val productId: Int,
    val manufacturerName: String?,
    val productName: String?,
    val serialNumber: String?,
    val deviceName: String,
    val interfaces: List<UsbInterfaceInfo>
) {
    fun vidPidHex(): String = "%04X:%04X".format(vendorId, productId)
}

/**
 * Transport-level operations a [com.avrprogrammer.android.programmer.Programmer]
 * needs, abstracted away from `android.hardware.usb.*` so protocol implementations
 * (and their unit tests, via [MockUsbTransport]) don't depend on the Android
 * framework being present. [UsbHostTransport] is the real implementation backed by
 * `UsbManager`/`UsbDeviceConnection`.
 *
 * Every method throws [com.avrprogrammer.android.errors.TransportException] on
 * failure rather than returning a sentinel, so callers get a structured, loggable
 * error instead of having to remember to check a magic negative return value --
 * unlike the raw Android USB APIs this wraps, which do exactly that.
 */
interface UsbTransport {
    val info: UsbDeviceInfo

    fun open()
    fun close()
    val isOpen: Boolean

    /**
     * A standard USB control transfer. [requestType] follows the USB spec's bmRequestType
     * byte layout (direction | type | recipient) exactly as passed to
     * `UsbDeviceConnection.controlTransfer`.
     */
    fun controlTransfer(requestType: Int, request: Int, value: Int, index: Int, buffer: ByteArray, length: Int, timeoutMs: Int): Int

    /** Bulk OUT transfer on the given endpoint address. Returns bytes written. */
    fun bulkTransferOut(endpointAddress: Int, data: ByteArray, length: Int, timeoutMs: Int): Int

    /** Bulk IN transfer on the given endpoint address. Returns bytes read. */
    fun bulkTransferIn(endpointAddress: Int, buffer: ByteArray, length: Int, timeoutMs: Int): Int

    /** Interrupt IN transfer (some CDC status endpoints, a few debuggers). Returns bytes read. */
    fun interruptTransferIn(endpointAddress: Int, buffer: ByteArray, length: Int, timeoutMs: Int): Int
}
