package com.avrprogrammer.android

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Process
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Catches any exception that would otherwise crash the app with nothing but Android's
 * generic "keeps stopping" dialog to go on. Deliberately depends on nothing else in
 * this app (no Logger, no DI, no app-specific classes) -- if the crash is somewhere
 * deep in this app's own code, the handler still needs to run cleanly, so it's built
 * entirely from plain JDK/Android framework calls, each wrapped defensively so a
 * failure while *handling* the crash can't itself throw and lose the report.
 *
 * On an uncaught exception this:
 *  1. Builds a text report (exception, full cause chain, stack trace, basic device info).
 *  2. Writes it to a file under [Context.getFilesDir] (internal storage, no permissions needed).
 *  3. Starts [CrashActivity] with the report text (and file path) as intent extras.
 *  4. Kills the process immediately, before returning control to Android's own
 *     default handler -- otherwise the OS's own "keeps stopping" dialog can still
 *     race CrashActivity's launch and show on top of it.
 */
class CrashHandler(private val appContext: Context) : Thread.UncaughtExceptionHandler {

    private val previousHandler: Thread.UncaughtExceptionHandler? = Thread.getDefaultUncaughtExceptionHandler()

    override fun uncaughtException(thread: Thread, throwable: Throwable) {
        try {
            val report = buildReport(thread, throwable)
            val logFile = writeReportToFile(report)
            launchCrashActivity(report, logFile)
        } catch (handlerFailure: Throwable) {
            // The crash handler itself must never be the reason a crash goes unreported.
            // Fall through to whatever Android would have done anyway.
        } finally {
            Process.killProcess(Process.myPid())
            System.exit(10)
        }
    }

    private fun buildReport(thread: Thread, throwable: Throwable): String {
        val sw = StringWriter()
        throwable.printStackTrace(PrintWriter(sw))

        val timestamp = try {
            SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date())
        } catch (e: Throwable) {
            System.currentTimeMillis().toString()
        }

        val versionInfo = try {
            val pInfo = appContext.packageManager.getPackageInfo(appContext.packageName, 0)
            "versionName=${pInfo.versionName} versionCode=${
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) pInfo.longVersionCode else @Suppress("DEPRECATION") pInfo.versionCode
            }"
        } catch (e: Throwable) {
            "version=unknown"
        }

        return buildString {
            appendLine("AVR Programmer crash report")
            appendLine("Time: $timestamp")
            appendLine("Thread: ${thread.name}")
            appendLine("App: $versionInfo")
            appendLine("Device: ${Build.MANUFACTURER} ${Build.MODEL} (${Build.DEVICE})")
            appendLine("Android: ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})")
            appendLine()
            appendLine("--- Exception ---")
            append(sw.toString())
        }
    }

    private fun writeReportToFile(report: String): File? = try {
        val dir = File(appContext.filesDir, "crash_logs")
        if (!dir.exists()) dir.mkdirs()
        val fileName = "crash_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".txt"
        val file = File(dir, fileName)
        file.writeText(report)
        file
    } catch (e: Throwable) {
        null
    }

    private fun launchCrashActivity(report: String, logFile: File?) {
        val intent = Intent(appContext, CrashActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK)
            // Intent extras share a ~1MB transaction buffer with the rest of the
            // system; a stack trace should never get close to that, but truncate
            // defensively so a pathological cause chain can't blow the launch itself.
            putExtra(CrashActivity.EXTRA_REPORT_TEXT, report.take(200_000))
            putExtra(CrashActivity.EXTRA_LOG_FILE_PATH, logFile?.absolutePath)
        }
        appContext.startActivity(intent)
    }
}
