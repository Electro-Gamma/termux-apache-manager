package com.avrprogrammer.android.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.avrprogrammer.android.databinding.ActivityThirdPartyLicensesBinding

/** Project brief section 24.7: "Include a third-party licenses screen in the Android application." */
class ThirdPartyLicensesActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityThirdPartyLicensesBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.txtLicenses.text = assets.open("third_party_licenses.txt").bufferedReader().use { it.readText() }
    }
}
