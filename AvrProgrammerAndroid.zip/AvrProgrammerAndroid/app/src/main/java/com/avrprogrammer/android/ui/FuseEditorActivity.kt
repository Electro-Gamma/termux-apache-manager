package com.avrprogrammer.android.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.avrprogrammer.android.databinding.ActivityFuseEditorBinding
import com.avrprogrammer.android.databinding.ItemFuseRowBinding
import com.avrprogrammer.android.device.AvrDevice
import com.avrprogrammer.android.device.AvrMemoryDef
import com.avrprogrammer.android.device.DeviceDatabase
import com.avrprogrammer.android.errors.AvrProgrammerException
import com.avrprogrammer.android.programmer.Programmer
import com.avrprogrammer.android.programmer.ProgrammerRegistry
import com.avrprogrammer.android.transport.UsbDeviceScanner
import com.avrprogrammer.android.transport.UsbHostTransport
import com.avrprogrammer.android.transport.UsbPermissionManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Project brief section 16: read/write fuse and lock bits, show hex values, and
 * "require explicit user action for destructive fuse operations" -- every write here
 * goes through an AlertDialog confirmation (see [confirmAndWriteFuse]) before
 * touching hardware, and the screen never writes anything on its own initiative.
 */
class FuseEditorActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PART_ID = "part_id"
        const val EXTRA_PROGRAMMER_ID = "programmer_id"
    }

    private lateinit var binding: ActivityFuseEditorBinding
    private lateinit var deviceDatabase: DeviceDatabase
    private lateinit var scanner: UsbDeviceScanner
    private lateinit var permissionManager: UsbPermissionManager
    private lateinit var device: AvrDevice
    private lateinit var programmerId: String
    private val adapter = FuseAdapter { fuse, valueText -> onWriteRequested(fuse, valueText) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFuseEditorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        deviceDatabase = DeviceDatabase.load(this)
        scanner = UsbDeviceScanner(this)
        permissionManager = UsbPermissionManager(this)

        val partId = intent.getStringExtra(EXTRA_PART_ID)
        val resolved = partId?.let { deviceDatabase.byId(it) }
        if (resolved == null) {
            binding.txtPartName.text = "Select a specific target part on the main screen first (not Auto Detect)"
            binding.btnReadFuses.isEnabled = false
            return
        }
        device = resolved
        programmerId = intent.getStringExtra(EXTRA_PROGRAMMER_ID) ?: "usbasp"

        binding.txtPartName.text = device.desc
        binding.recyclerFuses.layoutManager = LinearLayoutManager(this)
        binding.recyclerFuses.adapter = adapter
        adapter.submit(device.fuses + listOfNotNull(device.lock))

        binding.btnReadFuses.setOnClickListener { readAll() }
    }

    private fun readAll() {
        lifecycleScope.launch {
            try {
                val programmer = openProgrammer()
                try {
                    val values = LinkedHashMap<String, Int>()
                    for (fuse in device.fuses) {
                        values[fuse.name] = withContext(Dispatchers.IO) { programmer.readFuse(device, fuse.name) }
                    }
                    device.lock?.let { values["lock"] = withContext(Dispatchers.IO) { programmer.readLock(device) } }
                    adapter.applyValues(values)
                } finally {
                    withContext(Dispatchers.IO) { programmer.close() }
                }
            } catch (e: AvrProgrammerException) {
                binding.txtPartName.text = "${device.desc}\n${e.message}"
            } catch (e: Exception) {
                binding.txtPartName.text = "${device.desc}\nError: ${e.message}"
            }
        }
    }

    private fun onWriteRequested(fuse: AvrMemoryDef, valueText: String) {
        val value = try {
            valueText.trim().removePrefix("0x").removePrefix("0X").toInt(16)
        } catch (e: NumberFormatException) {
            adapter.showError(fuse.name, "enter a hex value, e.g. E2"); return
        }
        confirmAndWriteFuse(fuse, value)
    }

    private fun confirmAndWriteFuse(fuse: AvrMemoryDef, value: Int) {
        AlertDialog.Builder(this)
            .setTitle(com.avrprogrammer.android.R.string.fuse_warning_title)
            .setMessage(getString(com.avrprogrammer.android.R.string.fuse_warning_message) + "\n\nWrite ${fuse.name} = 0x%02X on ${device.desc}?".format(value))
            .setPositiveButton("Write") { _, _ -> performWrite(fuse, value) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun performWrite(fuse: AvrMemoryDef, value: Int) {
        lifecycleScope.launch {
            try {
                val programmer = openProgrammer()
                try {
                    withContext(Dispatchers.IO) {
                        if (fuse.name == "lock") programmer.writeLock(device, value) else programmer.writeFuse(device, fuse.name, value)
                    }
                    val readBack = withContext(Dispatchers.IO) {
                        if (fuse.name == "lock") programmer.readLock(device) else programmer.readFuse(device, fuse.name)
                    }
                    adapter.applyValues(mapOf(fuse.name to readBack))
                } finally {
                    withContext(Dispatchers.IO) { programmer.close() }
                }
            } catch (e: AvrProgrammerException) {
                adapter.showError(fuse.name, e.message ?: "write failed")
            } catch (e: Exception) {
                adapter.showError(fuse.name, e.message ?: "write failed")
            }
        }
    }

    private suspend fun openProgrammer(): Programmer {
        val descriptor = ProgrammerRegistry.byId(programmerId) ?: error("unknown programmer '$programmerId'")
        val usbDevice = descriptor.knownVidPids.firstNotNullOfOrNull { (vid, pid) -> scanner.findByVidPid(vid, pid) }
            ?: error("No attached USB device matches ${descriptor.displayName}")
        if (!permissionManager.requestPermission(usbDevice)) error("USB permission denied")
        val iface = scanner.pickPreferredInterface(usbDevice) ?: error("device exposes no usable interface")
        val transport = UsbHostTransport(this, usbDevice, iface)
        val programmer = ProgrammerFactory.build(programmerId, transport)
        withContext(Dispatchers.IO) { programmer.open(device) }
        return programmer
    }

    private class FuseAdapter(private val onWrite: (AvrMemoryDef, String) -> Unit) : RecyclerView.Adapter<FuseAdapter.VH>() {
        private var items: List<AvrMemoryDef> = emptyList()
        private val currentValues = mutableMapOf<String, Int>()

        fun submit(newItems: List<AvrMemoryDef>) {
            items = newItems
            notifyDataSetChanged()
        }

        fun applyValues(values: Map<String, Int>) {
            currentValues.putAll(values)
            notifyDataSetChanged()
        }

        fun showError(fuseName: String, message: String) {
            val index = items.indexOfFirst { it.name == fuseName }
            if (index >= 0) notifyItemChanged(index, message)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
            VH(ItemFuseRowBinding.inflate(LayoutInflater.from(parent.context), parent, false))

        override fun onBindViewHolder(holder: VH, position: Int) {
            val fuse = items[position]
            holder.bind(fuse, currentValues[fuse.name])
            holder.binding.btnWriteFuse.setOnClickListener {
                onWrite(fuse, holder.binding.editFuseValue.text.toString())
            }
        }

        override fun getItemCount(): Int = items.size

        class VH(val binding: ItemFuseRowBinding) : RecyclerView.ViewHolder(binding.root) {
            fun bind(fuse: AvrMemoryDef, currentValue: Int?) {
                binding.txtFuseName.text = fuse.name
                binding.editFuseValue.hint = currentValue?.let { "0x%02X".format(it) } ?: (fuse.initval?.let { "0x%02X".format(it) } ?: "0xFF")
            }
        }
    }
}
