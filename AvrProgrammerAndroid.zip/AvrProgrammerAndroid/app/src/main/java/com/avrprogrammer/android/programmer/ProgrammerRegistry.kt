package com.avrprogrammer.android.programmer

import com.avrprogrammer.android.programmer.usbasp.UsbaspProgrammer
import com.avrprogrammer.android.programmer.usbtiny.UsbTinyProgrammer
import com.avrprogrammer.android.programmer.stk500v1.Stk500v1Programmer

/**
 * The full catalogue of programmers the project brief (section 4) asks about, each
 * with an honest [ImplementationStatus] and the AVRDUDE source file it comes from.
 * This is deliberately NOT limited to the implemented ones -- per section 29/31 of
 * the brief, unsupported functionality must be visible and explained, not hidden.
 *
 * VID/PIDs are taken from src/usbdevs.h; "why not implemented" notes cite the
 * concrete technical reason (protocol needs a driver/board Android's USB Host API
 * cannot provide, or the work is simply out of scope for this pass) rather than a
 * generic "TODO".
 */
object ProgrammerRegistry {

    val all: List<ProgrammerDescriptor> = listOf(
        UsbaspProgrammer.descriptor(),
        UsbTinyProgrammer.descriptor(),
        Stk500v1Programmer.descriptor(),
        Stk500v1Programmer.arduinoDescriptor(),

        ProgrammerDescriptor(
            id = "avrisp", displayName = "AVRISP (STK500v2 over serial)",
            protocol = "STK500 v2 (\"Cmnd_STK2_*\", src/stk500v2.c)",
            transportKind = TransportKind.SERIAL_GENERIC,
            knownVidPids = emptyList(),
            status = ImplementationStatus.NOT_IMPLEMENTED,
            notes = "STK500v2 is a distinct, more complex framed protocol (seq numbers, checksums, START_TOKEN/TOKEN framing) from STK500v1; not yet ported. See src/stk500v2.c."
        ),
        ProgrammerDescriptor(
            id = "avrispmkII", displayName = "AVRISP mkII",
            protocol = "STK500 v2 over USB (src/stk500v2.c usbtool transport)",
            transportKind = TransportKind.USB_BULK_SERIAL,
            knownVidPids = listOf(0x03EB to 0x2104),
            status = ImplementationStatus.NOT_IMPLEMENTED,
            notes = "Depends on STK500v2 (see 'avrisp' above) plus its USB HID-like bulk framing; not yet ported."
        ),
        ProgrammerDescriptor(
            id = "stk500v2", displayName = "STK500 v2 (generic)",
            protocol = "STK500 v2 (\"Cmnd_STK2_*\", src/stk500v2.c)",
            transportKind = TransportKind.SERIAL_GENERIC,
            knownVidPids = emptyList(),
            status = ImplementationStatus.NOT_IMPLEMENTED,
            notes = "Same protocol family as 'avrisp'/'avrispmkII'; not yet ported."
        ),
        ProgrammerDescriptor(
            id = "stk600", displayName = "Atmel STK600",
            protocol = "STK500 v2 variant with routing-card awareness (src/stk500v2.c)",
            transportKind = TransportKind.USB_BULK_SERIAL,
            knownVidPids = listOf(0x03EB to 0x2106),
            status = ImplementationStatus.NOT_IMPLEMENTED,
            notes = "Depends on STK500v2; not yet ported."
        ),
        ProgrammerDescriptor(
            id = "jtag2isp / avrdragon", displayName = "AVR Dragon (ISP mode)",
            protocol = "JTAG ICE mkII packet protocol, ISP sub-mode (src/jtagmkII.c)",
            transportKind = TransportKind.USB_BULK_SERIAL,
            knownVidPids = listOf(0x03EB to 0x2107),
            status = ImplementationStatus.NOT_IMPLEMENTED,
            notes = "JTAG ICE mkII framed packet protocol not ported (separate large protocol; also drives JTAG/debugWIRE/HVSP/HVPP sub-modes not in scope here). See src/jtagmkII.c."
        ),
        ProgrammerDescriptor(
            id = "jtagmkII", displayName = "JTAGICE mkII",
            protocol = "JTAG ICE mkII packet protocol (src/jtagmkII.c)",
            transportKind = TransportKind.USB_BULK_SERIAL,
            knownVidPids = listOf(0x03EB to 0x2103),
            status = ImplementationStatus.NOT_IMPLEMENTED,
            notes = "Not ported -- see src/jtagmkII.c. Real hardware debugger protocol, substantially larger than the ISP-only programmers implemented here."
        ),
        ProgrammerDescriptor(
            id = "jtagice3", displayName = "JTAGICE3",
            protocol = "EDBG/CMSIS-DAP-style framed protocol (src/jtagmkII.c / src/jtag3.c family)",
            transportKind = TransportKind.USB_BULK_SERIAL,
            knownVidPids = listOf(0x03EB to 0x2110),
            status = ImplementationStatus.NOT_IMPLEMENTED,
            notes = "Not ported -- see src/jtag3.c."
        ),
        ProgrammerDescriptor(
            id = "atmelice", displayName = "Atmel-ICE",
            protocol = "EDBG protocol family (src/jtag3.c / src/updi*.c for UPDI targets)",
            transportKind = TransportKind.USB_BULK_SERIAL,
            knownVidPids = listOf(0x03EB to 0x2141),
            status = ImplementationStatus.NOT_IMPLEMENTED,
            notes = "Not ported -- newest Microchip debugger protocol; also the natural path to UPDI (tinyAVR 0/1/2, megaAVR 0, AVR Dx) which this project does not yet implement."
        ),
        ProgrammerDescriptor(
            id = "usbasp-tpi", displayName = "USBasp (TPI mode)",
            protocol = "USBasp TPI control requests (src/usbasp.c usbasp_tpi_*)",
            transportKind = TransportKind.USB_CONTROL,
            knownVidPids = UsbaspProgrammer.descriptor().knownVidPids,
            status = ImplementationStatus.NOT_IMPLEMENTED,
            notes = "The USBasp SPI/ISP implementation in this project is complete, but its separate TPI mode (for ATtiny4/5/9/10/20/40-style parts) is not wired up, and none of those parts are in DEVICE_DATABASE.md's curated device set yet."
        ),
        ProgrammerDescriptor(
            id = "dfu / flip", displayName = "Atmel DFU (FLIP-compatible bootloader)",
            protocol = "USB DFU class (src/usb_libusb.c + src/flip1.c/flip2.c)",
            transportKind = TransportKind.USB_BULK_SERIAL,
            knownVidPids = emptyList(),
            status = ImplementationStatus.NOT_IMPLEMENTED,
            notes = "Not ported -- see src/flip1.c (FLIP protocol v1) and src/flip2.c (DFU class v2)."
        ),
        ProgrammerDescriptor(
            id = "serialupdi", displayName = "SerialUPDI",
            protocol = "UPDI over a plain UART with a 1-wire adapter (src/updi_*.c)",
            transportKind = TransportKind.SERIAL_GENERIC,
            knownVidPids = emptyList(),
            status = ImplementationStatus.NOT_IMPLEMENTED,
            notes = "UPDI (tinyAVR 0/1/2, megaAVR 0, AVR Dx/DA/DB/DD/DU, AVR128DB, ...) is architecturally distinct from classic ISP -- different instruction set, different addressing, NVM controller commands instead of ISP opcodes. Not implemented in this pass; see PROTOCOLS.md."
        ),
        ProgrammerDescriptor(
            id = "xmega / pdi", displayName = "XMEGA (PDI)",
            protocol = "PDI (src/jtagmkII.c / src/updi_*.c share some infrastructure)",
            transportKind = TransportKind.UNSUPPORTED_ON_ANDROID,
            knownVidPids = emptyList(),
            status = ImplementationStatus.NOT_IMPLEMENTED,
            notes = "PDI is a separate protocol family from classic ISP; not implemented."
        ),
        ProgrammerDescriptor(
            id = "ft245r / ch341a / bitbang", displayName = "Parallel-port / GPIO bit-bang programmers",
            protocol = "Direct pin bit-banging (src/bitbang.c, src/ft245r.c, src/linuxgpio.c, ...)",
            transportKind = TransportKind.UNSUPPORTED_ON_ANDROID,
            knownVidPids = emptyList(),
            status = ImplementationStatus.NOT_IMPLEMENTED,
            notes = "These rely on direct GPIO or parallel-port pin control from the host, which the Android USB Host API does not expose (Android has no general-purpose bit-bangable GPIO for arbitrary USB adapters). Structurally out of reach on this platform, not merely unported."
        ),
        ProgrammerDescriptor(
            id = "buspirate", displayName = "Bus Pirate",
            protocol = "Bus Pirate binary SPI mode over serial (src/buspirate.c)",
            transportKind = TransportKind.SERIAL_GENERIC,
            knownVidPids = emptyList(),
            status = ImplementationStatus.NOT_IMPLEMENTED,
            notes = "Not ported -- see src/buspirate.c."
        ),
        ProgrammerDescriptor(
            id = "usb-serial-vendor", displayName = "FTDI / CP210x / CH340-CH341 USB-serial adapters",
            protocol = "Vendor-specific USB-serial chip control (used as a transport for other programmers, e.g. plain STK500 hardware)",
            transportKind = TransportKind.UNSUPPORTED_ON_ANDROID,
            knownVidPids = listOf(0x0403 to 0x6001, 0x0403 to 0x6010),
            status = ImplementationStatus.NOT_IMPLEMENTED,
            notes = "AVRDUDE itself does not implement these chips' protocols either -- it relies on the host OS's kernel driver (ftdi_sio/cp210x/ch341) exposing a plain tty device. Android's USB Host framework has no equivalent built-in driver, so a from-scratch chip-specific implementation would be needed; only standards-based USB CDC-ACM (no vendor driver required) is implemented, via CdcAcmSerialTransport."
        ),
    )

    fun byId(id: String): ProgrammerDescriptor? = all.firstOrNull { it.id.equals(id, ignoreCase = true) }

    fun implemented(): List<ProgrammerDescriptor> = all.filter { it.status == ImplementationStatus.IMPLEMENTED }

    fun findByVidPid(vendorId: Int, productId: Int): ProgrammerDescriptor? =
        all.firstOrNull { d -> d.knownVidPids.any { it.first == vendorId && it.second == productId } }
}
