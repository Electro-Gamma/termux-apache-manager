package com.avrprogrammer.android.programmer

import com.avrprogrammer.android.device.AvrDevice
import com.avrprogrammer.android.device.AvrMemoryDef
import com.avrprogrammer.android.device.Opcode
import com.avrprogrammer.android.device.OpcodeTemplateParser
import com.avrprogrammer.android.errors.MemoryOperationException
import com.avrprogrammer.android.errors.ProtocolException
import com.avrprogrammer.android.logging.Logger
import com.avrprogrammer.android.memory.MemoryImage

/**
 * Implements the parts of [Programmer] that are the *same* for every classic-AVR ISP
 * programmer once you have a way to shove 4 bytes down SPI and get 4 bytes back --
 * i.e. everything except paged flash/eeprom read/write, which each subclass overrides
 * with whatever fast-path its hardware offers (USBasp has native paged read/write
 * commands; a plain SPI relay like USBtinyISP or STK500v1's UNIVERSAL command does
 * not, so [readMemoryGeneric]/[writeMemoryGeneric] below do it the way AVRDUDE's
 * "default" byte-wise fallback does: one ISP instruction per byte or page-load cycle).
 *
 * This mirrors AVRDUDE's own architecture: `pgm->cmd()` is exactly this 4-byte SPI
 * relay, and most programmer backends only supply `cmd()` plus optionally faster
 * `paged_load()`/`paged_write()` overrides (see src/avr.c `avr_read_byte_default` /
 * `avr_write_byte_default` / `avr_read_page_default`).
 */
abstract class AbstractIspOpcodeProgrammer : Programmer {

    /** Sends one 4-byte ISP instruction, returns the 4-byte response. The one method every subclass must provide. */
    protected abstract fun ispTransmit(cmd: ByteArray): ByteArray

    /**
     * Standard AVR "Poll RDY/BUSY" ISP instruction (present in every classic AVR
     * datasheet's serial programming instruction table): 0xF0 0x00 0x00 0x00, with bit
     * 0 of the returned 4th byte set to 1 while a write is still in progress. Not
     * every part's avrdude.conf entry lists this explicitly (AVRDUDE mostly relies on
     * a fixed delay instead), so it is kept here as a shared constant rather than
     * per-device data, and used as a bounded poll with a delay-based fallback.
     */
    private val pollReadyBusy: Opcode by lazy {
        OpcodeTemplateParser.parse("1111.0000--0000.0000--0000.0000--xxxx.xxxo")
    }

    protected fun programEnable(device: AvrDevice) {
        val opcode = device.pgmEnable ?: throw ProtocolException(
            "device ${device.desc} has no ISP Programming Enable opcode in the device database",
            protocol = "AVR ISP"
        )
        val cmd = opcode.newCommand()
        var response = ispTransmit(cmd)
        // Standard convention: byte 2 of the command (0x53) is echoed back in byte index 2
        // of the response when Programming Enable succeeds. A handful of real chips need one
        // extra SCK pulse before they echo correctly, so retry once with a re-issued command.
        if (response.size < 3 || response[2] != cmd[1]) {
            Logger.debug("AbstractIspOpcodeProgrammer", "Programming Enable echo mismatch on first try, retrying once")
            response = ispTransmit(cmd)
        }
        if (response.size < 3 || response[2] != cmd[1]) {
            throw ProtocolException(
                "target did not respond to Programming Enable (device not connected, wrong wiring, or SCK too fast)",
                protocol = "AVR ISP",
                command = "Programming Enable",
                expected = "0x%02X in response byte 3".format(cmd[1]),
                received = if (response.size >= 3) "0x%02X".format(response[2]) else "short response"
            )
        }
    }

    protected fun genericChipErase(device: AvrDevice) {
        val opcode = device.chipErase ?: throw ProtocolException(
            "device ${device.desc} has no Chip Erase opcode in the device database", protocol = "AVR ISP"
        )
        ispTransmit(opcode.newCommand())
        waitForCompletion(device.chipEraseDelayUs ?: 20_000)
    }

    override fun readSignature(device: AvrDevice): IntArray {
        val opcode = device.signatureRead ?: throw ProtocolException(
            "device ${device.desc} has no Read Signature opcode in the device database", protocol = "AVR ISP"
        )
        return IntArray(device.signature.size) { i ->
            val cmd = opcode.newCommand()
            opcode.setAddress(cmd, i.toLong())
            opcode.getOutput(ispTransmit(cmd))
        }
    }

    override fun readFuse(device: AvrDevice, fuseName: String): Int {
        val mem = device.fuseByName(fuseName) ?: throw MemoryOperationException("device ${device.desc} has no fuse named '$fuseName'")
        val opcode = mem.read ?: throw ProtocolException("fuse '$fuseName' has no read opcode for ${device.desc}", protocol = "AVR ISP")
        return opcode.getOutput(ispTransmit(opcode.newCommand()))
    }

    override fun writeFuse(device: AvrDevice, fuseName: String, value: Int) {
        val mem = device.fuseByName(fuseName) ?: throw MemoryOperationException("device ${device.desc} has no fuse named '$fuseName'")
        val opcode = mem.write ?: throw ProtocolException("fuse '$fuseName' has no write opcode for ${device.desc}", protocol = "AVR ISP")
        val cmd = opcode.newCommand()
        opcode.setInput(cmd, value)
        ispTransmit(cmd)
        waitForCompletion(device.chipEraseDelayUs?.coerceAtMost(10_000) ?: 4_500)
    }

    override fun readLock(device: AvrDevice): Int {
        val mem = device.lock ?: throw MemoryOperationException("device ${device.desc} has no lock byte defined")
        val opcode = mem.read ?: throw ProtocolException("no lock-read opcode for ${device.desc}", protocol = "AVR ISP")
        return opcode.getOutput(ispTransmit(opcode.newCommand()))
    }

    override fun writeLock(device: AvrDevice, value: Int) {
        val mem = device.lock ?: throw MemoryOperationException("device ${device.desc} has no lock byte defined")
        val opcode = mem.write ?: throw ProtocolException("no lock-write opcode for ${device.desc}", protocol = "AVR ISP")
        val cmd = opcode.newCommand()
        opcode.setInput(cmd, value)
        ispTransmit(cmd)
        waitForCompletion(4_500)
    }

    override fun readCalibration(device: AvrDevice): Int {
        val mem = device.calibration ?: throw MemoryOperationException("device ${device.desc} has no calibration byte defined")
        val opcode = mem.read ?: throw ProtocolException("no calibration-read opcode for ${device.desc}", protocol = "AVR ISP")
        return opcode.getOutput(ispTransmit(opcode.newCommand()))
    }

    /** Busy-polls up to ~[maxWaitUs] using the standard Poll RDY/BUSY instruction, falling back to a plain sleep if the target never clears the busy bit (some parts don't implement polling for every memory). */
    protected fun waitForCompletion(maxWaitUs: Int) {
        val deadline = System.nanoTime() + maxWaitUs.toLong() * 1000
        var polledOnce = false
        while (System.nanoTime() < deadline) {
            val response = try {
                ispTransmit(pollReadyBusy.newCommand())
            } catch (e: Exception) {
                break // target doesn't support polling on this line; fall through to sleep
            }
            polledOnce = true
            val busy = pollReadyBusy.getOutput(response) and 0x01
            if (busy == 0) return
            Thread.sleep(0, 200_000) // 0.2 ms
        }
        if (!polledOnce) {
            Thread.sleep((maxWaitUs / 1000).coerceAtLeast(1).toLong())
        }
    }

    /**
     * Issues AVR_OP_LOAD_EXT_ADDR when a device needs it and the extended-address
     * segment (word address bits 16+) has changed since the last call, mirroring how
     * AVRDUDE's usbtiny/stk500v1-style backends set it once per page/read call rather
     * than on every single byte. [wordAddr] is the *word* address about to be used
     * with a normal (16-bit-address) opcode. Returns the segment that is now loaded,
     * so the caller can pass it back in as [lastSegment] next time.
     */
    private fun maybeLoadExtAddr(mem: AvrMemoryDef, wordAddr: Int, lastSegment: Int): Int {
        val lext = mem.loadExtAddr ?: return lastSegment
        val segment = wordAddr ushr 16
        if (segment == lastSegment) return lastSegment
        val cmd = lext.newCommand()
        lext.setAddress(cmd, wordAddr.toLong())
        ispTransmit(cmd)
        return segment
    }

    /**
     * Generic byte-wise/page-wise flash or EEPROM read using only [ispTransmit] --
     * used as-is by USBtinyISP and STK500v1 (STK500v1 actually has a faster native
     * Program/Read Page command; see Stk500v1Programmer for the override) and by any
     * future SPI-relay-only backend. Handles both word-oriented (flash: read_lo/hi
     * pairs) and byte-oriented (eeprom: single read opcode) memories generically from
     * the [AvrMemoryDef] flags, exactly mirroring which template fields are non-null.
     */
    protected fun readMemoryGeneric(mem: AvrMemoryDef, progress: ((Int, Int) -> Unit)?): MemoryImage {
        val image = MemoryImage(mem.size)
        if (mem.isWordOriented) {
            val readLo = mem.readLo ?: throw ProtocolException("memory '${mem.name}' has no read_lo opcode")
            val readHi = mem.readHi ?: throw ProtocolException("memory '${mem.name}' has no read_hi opcode")
            var addr = 0
            var byteAddr = 0
            var lastExtSegment = -1
            while (byteAddr < mem.size) {
                lastExtSegment = maybeLoadExtAddr(mem, addr, lastExtSegment)
                val lo = readLo.newCommand().also { readLo.setAddress(it, addr.toLong()) }
                val hi = readHi.newCommand().also { readHi.setAddress(it, addr.toLong()) }
                image.set(byteAddr, readLo.getOutput(ispTransmit(lo)))
                if (byteAddr + 1 < mem.size) image.set(byteAddr + 1, readHi.getOutput(ispTransmit(hi)))
                addr++
                byteAddr += 2
                progress?.invoke(byteAddr.coerceAtMost(mem.size), mem.size)
            }
        } else {
            val read = mem.read ?: throw ProtocolException("memory '${mem.name}' has no read opcode")
            for (addr in 0 until mem.size) {
                val cmd = read.newCommand()
                read.setAddress(cmd, addr.toLong())
                image.set(addr, read.getOutput(ispTransmit(cmd)))
                progress?.invoke(addr + 1, mem.size)
            }
        }
        return image
    }

    /**
     * Generic byte-wise/page-wise write using only [ispTransmit]: loads each byte into
     * the target's on-chip page buffer via loadpage_lo/hi (flash) or a page-write
     * opcode (eeprom), then commits the page with writepage, polling for completion
     * between pages. For non-paged memories (page_size == 0) writes go straight
     * through the plain write opcode instead.
     */
    protected fun writeMemoryGeneric(mem: AvrMemoryDef, image: MemoryImage, progress: ((Int, Int) -> Unit)?) {
        if (!mem.isPaged) {
            val write = mem.write ?: throw ProtocolException("memory '${mem.name}' has no write opcode and is not paged")
            for (addr in 0 until mem.size) {
                if (!image.isTouched(addr)) continue
                val cmd = write.newCommand()
                write.setAddress(cmd, addr.toLong())
                write.setInput(cmd, image.get(addr))
                ispTransmit(cmd)
                waitForCompletion(10_000)
                progress?.invoke(addr + 1, mem.size)
            }
            return
        }

        val pageSize = mem.pageSize
        val writePage = mem.writePage ?: throw ProtocolException("memory '${mem.name}' is paged but has no writepage opcode")

        if (mem.isWordOriented) {
            val loadLo = mem.loadPageLo ?: throw ProtocolException("memory '${mem.name}' has no loadpage_lo opcode")
            val loadHi = mem.loadPageHi ?: throw ProtocolException("memory '${mem.name}' has no loadpage_hi opcode")
            var pageStart = 0
            var lastExtSegment = -1
            while (pageStart < mem.size) {
                lastExtSegment = maybeLoadExtAddr(mem, pageStart / 2, lastExtSegment)
                val pageEnd = minOf(pageStart + pageSize, mem.size)
                var wroteAnything = false
                var wordAddr = pageStart / 2
                var byteAddr = pageStart
                while (byteAddr < pageEnd) {
                    if (image.isTouched(byteAddr) || (byteAddr + 1 < pageEnd && image.isTouched(byteAddr + 1))) {
                        val lo = loadLo.newCommand().also { loadLo.setAddress(it, wordAddr.toLong()); loadLo.setInput(it, image.get(byteAddr)) }
                        ispTransmit(lo)
                        if (byteAddr + 1 < mem.size) {
                            val hi = loadHi.newCommand().also { loadHi.setAddress(it, wordAddr.toLong()); loadHi.setInput(it, image.get(byteAddr + 1)) }
                            ispTransmit(hi)
                        }
                        wroteAnything = true
                    }
                    wordAddr++
                    byteAddr += 2
                }
                if (wroteAnything) {
                    val pageCmd = writePage.newCommand()
                    writePage.setAddress(pageCmd, (pageStart / 2).toLong())
                    ispTransmit(pageCmd)
                    waitForCompletion(10_000)
                }
                pageStart = pageEnd
                progress?.invoke(pageStart, mem.size)
            }
        } else {
            // Byte-oriented paged memory (EEPROM on parts that page it).
            val loadByte = mem.loadPageLo ?: throw ProtocolException("memory '${mem.name}' has no eeprom loadpage opcode")
            var pageStart = 0
            while (pageStart < mem.size) {
                val pageEnd = minOf(pageStart + pageSize, mem.size)
                var wroteAnything = false
                for (addr in pageStart until pageEnd) {
                    if (image.isTouched(addr)) {
                        val cmd = loadByte.newCommand()
                        loadByte.setAddress(cmd, (addr % pageSize).toLong())
                        loadByte.setInput(cmd, image.get(addr))
                        ispTransmit(cmd)
                        wroteAnything = true
                    }
                }
                if (wroteAnything) {
                    val pageCmd = writePage.newCommand()
                    writePage.setAddress(pageCmd, pageStart.toLong())
                    ispTransmit(pageCmd)
                    waitForCompletion(10_000)
                }
                pageStart = pageEnd
                progress?.invoke(pageStart, mem.size)
            }
        }
    }
}
