package com.avrprogrammer.android.device

/**
 * One addressable memory region of a device (flash, eeprom, a fuse byte, lock,
 * calibration, signature). Mirrors the fields AVRDUDE's `AVRMEM` struct exposes that
 * this project actually needs; opcode templates are parsed lazily via [opcode] so a
 * device with hundreds of memories doesn't pay parsing cost for ones never touched.
 */
class AvrMemoryDef(
    val name: String,
    val size: Int,
    val pageSize: Int = 0,
    val numPages: Int = 0,
    val initval: Int? = null,
    val bitmask: Int? = null,
    private val readTemplate: String? = null,
    private val writeTemplate: String? = null,
    private val readLoTemplate: String? = null,
    private val readHiTemplate: String? = null,
    private val loadPageLoTemplate: String? = null,
    private val loadPageHiTemplate: String? = null,
    private val writePageTemplate: String? = null,
    private val loadExtAddrTemplate: String? = null
) {
    val isPaged: Boolean get() = pageSize > 0 && (writePageTemplate != null)

    val read: Opcode? by lazy { OpcodeTemplateParser.parseOrNull(readTemplate) }
    val write: Opcode? by lazy { OpcodeTemplateParser.parseOrNull(writeTemplate) }
    val readLo: Opcode? by lazy { OpcodeTemplateParser.parseOrNull(readLoTemplate) }
    val readHi: Opcode? by lazy { OpcodeTemplateParser.parseOrNull(readHiTemplate) }
    val loadPageLo: Opcode? by lazy { OpcodeTemplateParser.parseOrNull(loadPageLoTemplate) }
    val loadPageHi: Opcode? by lazy { OpcodeTemplateParser.parseOrNull(loadPageHiTemplate) }
    val writePage: Opcode? by lazy { OpcodeTemplateParser.parseOrNull(writePageTemplate) }

    /**
     * AVR_OP_LOAD_EXT_ADDR: only present on parts whose flash exceeds the 16-bit
     * word address a normal ISP opcode can carry (128 Kwords / 256 KiB), e.g.
     * ATmega2560/2561. Must be sent once before an address crossing the 64 Kword
     * boundary is used with [readLo]/[readHi]/[loadPageLo]/[loadPageHi]/[writePage].
     */
    val loadExtAddr: Opcode? by lazy { OpcodeTemplateParser.parseOrNull(loadExtAddrTemplate, isLoadExtAddr = true) }

    /** True for flash-style memories that use a 16-bit-word low/high byte pair per address. */
    val isWordOriented: Boolean get() = readLoTemplate != null || loadPageLoTemplate != null
}

/**
 * One AVR part, as resolved from AVRDUDE's device database (see DeviceDatabase /
 * DEVICE_DATABASE.md for provenance).
 */
class AvrDevice(
    val id: String,
    val desc: String,
    val signature: IntArray,
    val progModes: List<String>,
    val chipEraseDelayUs: Int?,
    private val pgmEnableTemplate: String?,
    private val chipEraseTemplate: String?,
    val flash: AvrMemoryDef,
    val eeprom: AvrMemoryDef?,
    val fuses: List<AvrMemoryDef>,
    val lock: AvrMemoryDef?,
    val calibration: AvrMemoryDef?,
    private val signatureReadTemplate: String?
) {
    val pgmEnable: Opcode? by lazy { OpcodeTemplateParser.parseOrNull(pgmEnableTemplate) }
    val chipErase: Opcode? by lazy { OpcodeTemplateParser.parseOrNull(chipEraseTemplate) }
    val signatureRead: Opcode? by lazy { OpcodeTemplateParser.parseOrNull(signatureReadTemplate) }

    val supportsIsp: Boolean get() = "ISP" in progModes

    fun signatureHex(): String = signature.joinToString(" ") { "%02X".format(it) }

    fun fuseByName(name: String): AvrMemoryDef? = fuses.firstOrNull { it.name == name }

    override fun toString(): String = "$desc (${signatureHex()})"
}
