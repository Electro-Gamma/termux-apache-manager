package com.avrprogrammer.android.verify

import com.avrprogrammer.android.errors.VerificationException
import com.avrprogrammer.android.memory.MemoryImage

data class VerifyMismatch(val address: Int, val expected: Int, val actual: Int)

data class VerifyResult(val memory: String, val bytesChecked: Int, val mismatches: List<VerifyMismatch>) {
    val passed: Boolean get() = mismatches.isEmpty()

    /** Renders in exactly the format project brief section 15 specifies. */
    fun report(): String {
        if (passed) return "Verification OK: $memory ($bytesChecked bytes checked, 0 mismatches)"
        return buildString {
            appendLine("Verification failed")
            appendLine("Memory: $memory")
            for (m in mismatches.take(20)) {
                appendLine("Address: 0x%04X".format(m.address))
                appendLine("Expected: 0x%02X".format(m.expected))
                appendLine("Read:     0x%02X".format(m.actual))
            }
            if (mismatches.size > 20) appendLine("... and ${mismatches.size - 20} more mismatches")
        }
    }
}

/**
 * Compares a just-written image against a fresh read-back (project brief section 15:
 * byte-by-byte verification, with "report exact failures" in the specified format).
 * Only addresses the source image actually touched are checked -- comparing untouched
 * (0xFF filler) regions would produce false positives against a chip that already had
 * different data there before this write.
 */
object Verifier {

    fun verify(memoryName: String, expected: MemoryImage, actual: MemoryImage): VerifyResult {
        val mismatches = mutableListOf<VerifyMismatch>()
        var checked = 0
        for (addr in 0 until expected.size) {
            if (!expected.isTouched(addr)) continue
            checked++
            val e = expected.get(addr)
            val a = if (addr < actual.size) actual.get(addr) else -1
            if (e != a) mismatches += VerifyMismatch(addr, e, a)
        }
        return VerifyResult(memoryName, checked, mismatches)
    }

    /** Throws on the first mismatch instead of collecting a full report -- used where the engine should stop immediately. */
    fun verifyOrThrow(memoryName: String, expected: MemoryImage, actual: MemoryImage) {
        val result = verify(memoryName, expected, actual)
        val first = result.mismatches.firstOrNull() ?: return
        throw VerificationException(memoryName, first.address, first.expected, first.actual)
    }
}
