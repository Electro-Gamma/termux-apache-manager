package com.avrprogrammer.android.util

/**
 * A small hand-written JSON parser with no dependencies.
 *
 * Why this exists instead of `org.json` (which ships with the Android platform and
 * would otherwise be the obvious choice, as used elsewhere in this project's
 * original design): `org.json` classes compiled against the Android SDK are stubs
 * with no real method bodies outside an actual Android runtime or Robolectric --
 * calling them from a plain JVM unit test (`src/test`, which is exactly where
 * project brief section 21's "device signature matching" tests need to run, with no
 * device/emulator and no Robolectric dependency) throws or silently no-ops. Rather
 * than pull in Robolectric just to parse a JSON asset, DeviceDatabase parses through
 * this instead, so its tests are plain, fast, dependency-free JUnit.
 *
 * Supports the full JSON grammar needed here: objects, arrays, strings (with the
 * standard backslash escapes and \\uXXXX), numbers, true/false/null. Not intended as
 * a general-purpose JSON library (no streaming, no custom number types) -- just
 * enough, correctly, for devices.json.
 */
sealed class JsonValue {
    data class JsonObject(val entries: Map<String, JsonValue>) : JsonValue() {
        operator fun get(key: String): JsonValue? = entries[key]
        fun string(key: String): String = (entries[key] as? JsonString)?.value ?: error("missing/invalid string field '$key'")
        fun stringOrNull(key: String): String? = (entries[key] as? JsonString)?.value
        fun int(key: String, default: Int = 0): Int = (entries[key] as? JsonNumber)?.value?.toInt() ?: default
        fun intOrNull(key: String): Int? = (entries[key] as? JsonNumber)?.value?.toInt()
        fun array(key: String): JsonArray = entries[key] as? JsonArray ?: JsonArray(emptyList())
        fun objectOrNull(key: String): JsonObject? = entries[key] as? JsonObject
    }

    data class JsonArray(val items: List<JsonValue>) : JsonValue() {
        val size: Int get() = items.size
        fun strings(): List<String> = items.mapNotNull { (it as? JsonString)?.value }
        fun objects(): List<JsonObject> = items.mapNotNull { it as? JsonObject }
        fun ints(): List<Int> = items.mapNotNull { (it as? JsonNumber)?.value?.toInt() }
    }

    data class JsonString(val value: String) : JsonValue()
    data class JsonNumber(val value: Double) : JsonValue()
    data class JsonBool(val value: Boolean) : JsonValue()
    object JsonNull : JsonValue()
}

class JsonParseException(message: String, val position: Int) : Exception("$message at position $position")

object MiniJson {

    fun parse(text: String): JsonValue {
        val parser = Parser(text)
        val value = parser.parseValue()
        parser.skipWhitespace()
        if (!parser.atEnd()) throw JsonParseException("trailing content after JSON value", parser.pos)
        return value
    }

    private class Parser(private val text: String) {
        var pos = 0

        fun atEnd() = pos >= text.length

        fun skipWhitespace() {
            while (pos < text.length && text[pos].isWhitespace()) pos++
        }

        fun parseValue(): JsonValue {
            skipWhitespace()
            if (atEnd()) throw JsonParseException("unexpected end of input", pos)
            return when (text[pos]) {
                '{' -> parseObject()
                '[' -> parseArray()
                '"' -> JsonValue.JsonString(parseString())
                't' -> parseLiteral("true", JsonValue.JsonBool(true))
                'f' -> parseLiteral("false", JsonValue.JsonBool(false))
                'n' -> parseLiteral("null", JsonValue.JsonNull)
                else -> parseNumber()
            }
        }

        private fun parseLiteral(literal: String, value: JsonValue): JsonValue {
            if (pos + literal.length > text.length || text.substring(pos, pos + literal.length) != literal) {
                throw JsonParseException("expected literal '$literal'", pos)
            }
            pos += literal.length
            return value
        }

        private fun parseObject(): JsonValue.JsonObject {
            expect('{')
            val entries = LinkedHashMap<String, JsonValue>()
            skipWhitespace()
            if (peek() == '}') { pos++; return JsonValue.JsonObject(entries) }
            while (true) {
                skipWhitespace()
                val key = parseString()
                skipWhitespace()
                expect(':')
                val value = parseValue()
                entries[key] = value
                skipWhitespace()
                when (peek()) {
                    ',' -> { pos++; continue }
                    '}' -> { pos++; break }
                    else -> throw JsonParseException("expected ',' or '}' in object", pos)
                }
            }
            return JsonValue.JsonObject(entries)
        }

        private fun parseArray(): JsonValue.JsonArray {
            expect('[')
            val items = mutableListOf<JsonValue>()
            skipWhitespace()
            if (peek() == ']') { pos++; return JsonValue.JsonArray(items) }
            while (true) {
                items += parseValue()
                skipWhitespace()
                when (peek()) {
                    ',' -> { pos++; continue }
                    ']' -> { pos++; break }
                    else -> throw JsonParseException("expected ',' or ']' in array", pos)
                }
            }
            return JsonValue.JsonArray(items)
        }

        private fun parseString(): String {
            expect('"')
            val sb = StringBuilder()
            while (true) {
                if (atEnd()) throw JsonParseException("unterminated string", pos)
                val c = text[pos++]
                when {
                    c == '"' -> return sb.toString()
                    c == '\\' -> {
                        if (atEnd()) throw JsonParseException("unterminated escape", pos)
                        when (val esc = text[pos++]) {
                            '"' -> sb.append('"')
                            '\\' -> sb.append('\\')
                            '/' -> sb.append('/')
                            'b' -> sb.append('\b')
                            'f' -> sb.append('\u000C')
                            'n' -> sb.append('\n')
                            'r' -> sb.append('\r')
                            't' -> sb.append('\t')
                            'u' -> {
                                if (pos + 4 > text.length) throw JsonParseException("truncated \\u escape", pos)
                                val code = text.substring(pos, pos + 4).toInt(16)
                                sb.append(code.toChar())
                                pos += 4
                            }
                            else -> throw JsonParseException("invalid escape '\\$esc'", pos)
                        }
                    }
                    else -> sb.append(c)
                }
            }
        }

        private fun parseNumber(): JsonValue.JsonNumber {
            val start = pos
            if (peek() == '-') pos++
            while (!atEnd() && text[pos].isDigit()) pos++
            if (!atEnd() && text[pos] == '.') {
                pos++
                while (!atEnd() && text[pos].isDigit()) pos++
            }
            if (!atEnd() && (text[pos] == 'e' || text[pos] == 'E')) {
                pos++
                if (!atEnd() && (text[pos] == '+' || text[pos] == '-')) pos++
                while (!atEnd() && text[pos].isDigit()) pos++
            }
            if (pos == start) throw JsonParseException("invalid number", pos)
            return JsonValue.JsonNumber(text.substring(start, pos).toDouble())
        }

        private fun peek(): Char = if (atEnd()) '\u0000' else text[pos]

        private fun expect(c: Char) {
            if (atEnd() || text[pos] != c) throw JsonParseException("expected '$c'", pos)
            pos++
        }
    }
}
