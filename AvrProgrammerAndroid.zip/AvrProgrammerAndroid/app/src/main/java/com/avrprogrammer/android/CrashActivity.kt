package com.avrprogrammer.android

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Process
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * Shows an uncaught exception's full report as selectable text, with a copy button,
 * instead of Android's generic "keeps stopping" dialog. Built entirely from plain
 * `android.widget`/`android.app` classes -- no Material Components, no Compose, no
 * ViewBinding, no reference to this app's own theme -- and declared in the manifest
 * to run in its own process (`android:process=":crash"`), so it can still open even
 * when whatever crashed the main app would prevent the main app's own UI stack
 * (themes, ViewBinding-generated classes, DI, ...) from initialising at all. See
 * [CrashHandler] for how this gets launched.
 */
class CrashActivity : Activity() {

    companion object {
        const val EXTRA_REPORT_TEXT = "report_text"
        const val EXTRA_LOG_FILE_PATH = "log_file_path"
        private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
        private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val reportText = intent.getStringExtra(EXTRA_REPORT_TEXT) ?: "(no crash report text was captured)"
        val logFilePath = intent.getStringExtra(EXTRA_LOG_FILE_PATH)

        setContentView(buildUi(reportText, logFilePath))
    }

    private fun buildUi(reportText: String, logFilePath: String?): ViewGroup {
        val density = resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            setPadding(dp(16), dp(24), dp(16), dp(16))
        }

        val title = TextView(this).apply {
            text = "AVR Programmer crashed \u2014 here's why"
            setTextColor(Color.BLACK)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            setTypeface(typeface, Typeface.BOLD)
        }
        root.addView(title)

        if (logFilePath != null) {
            val pathLabel = TextView(this).apply {
                text = "Also saved to: $logFilePath"
                setTextColor(Color.DKGRAY)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                setPadding(0, dp(8), 0, 0)
            }
            root.addView(pathLabel)
        }

        val buttonRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(12), 0, dp(12))
        }
        val copyButton = Button(this).apply {
            text = "Copy to clipboard"
            setOnClickListener { copyToClipboard(reportText) }
        }
        val closeButton = Button(this).apply {
            text = "Close"
            setOnClickListener { Process.killProcess(Process.myPid()) }
        }
        buttonRow.addView(copyButton)
        buttonRow.addView(closeButton, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = dp(8) })
        root.addView(buttonRow)

        val reportView = TextView(this).apply {
            text = reportText
            setTextColor(Color.BLACK)
            setTextIsSelectable(true)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.MONOSPACE
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }

        val scroll = ScrollView(this).apply {
            addView(reportView, ViewGroup.LayoutParams(MATCH, WRAP))
            setBackgroundColor(Color.parseColor("#F0F0F0"))
        }
        root.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))

        val hint = TextView(this).apply {
            text = "Screenshot this, or copy and paste the text back to continue debugging."
            setTextColor(Color.DKGRAY)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
        }
        root.addView(hint)

        return root
    }

    private fun copyToClipboard(text: String) {
        try {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("AVR Programmer crash report", text))
            Toast.makeText(this, "Copied crash report to clipboard", Toast.LENGTH_SHORT).show()
        } catch (e: Throwable) {
            Toast.makeText(this, "Could not copy: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}
