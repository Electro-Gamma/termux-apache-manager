package com.avrprogrammer.android

/**
 * Installs [CrashHandler] as the default uncaught-exception handler before any other
 * app code runs. This is a debugging aid, not a feature the project brief asked for:
 * the app was crashing on launch with only "keeps stopping" to go on, which isn't
 * enough to diagnose remotely. With this in place, a crash instead opens
 * [CrashActivity] with the full exception and stack trace, selectable/copyable, and
 * also written to a log file -- see CrashHandler's doc comment for why it's built to
 * survive crashes in the main app's own code.
 */
class AvrProgrammerApplication : android.app.Application() {
    override fun onCreate() {
        super.onCreate()
        Thread.setDefaultUncaughtExceptionHandler(CrashHandler(this))
    }
}
