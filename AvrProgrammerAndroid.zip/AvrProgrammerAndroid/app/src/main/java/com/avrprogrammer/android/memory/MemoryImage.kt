package com.avrprogrammer.android.memory

/**
 * A sparse-ish, byte-addressable image of one AVR memory (flash, EEPROM, a fuse byte,
 * etc). Internally backed by a flat ByteArray sized to [capacity] because every memory
 * this project targets (see DEVICE_DATABASE.md) is small enough -- at most a few
 * hundred KiB of flash -- that a flat array is simpler and faster than a real sparse
 * structure, while [touched] tracks which addresses were actually written so callers
 * (HEX writers, verifiers) can tell "explicitly set to 0xFF" apart from "never
 * mentioned".
 */
class MemoryImage(val capacity: Int, private val fillValue: Int = 0xFF) {

    private val data = ByteArray(capacity) { fillValue.toByte() }
    private val touched = BooleanArray(capacity)

    val size: Int get() = capacity

    fun get(address: Int): Int = data[requireInBounds(address)].toInt() and 0xFF

    fun set(address: Int, value: Int) {
        requireInBounds(address)
        data[address] = value.toByte()
        touched[address] = true
    }

    fun isTouched(address: Int): Boolean = touched[requireInBounds(address)]

    /** Lowest and highest touched addresses, or null if nothing was ever written. */
    fun touchedRange(): IntRange? {
        var lo = -1
        var hi = -1
        for (i in 0 until capacity) {
            if (touched[i]) {
                if (lo == -1) lo = i
                hi = i
            }
        }
        return if (lo == -1) null else lo..hi
    }

    fun toByteArray(): ByteArray = data.copyOf()

    fun fillFrom(bytes: ByteArray, offset: Int = 0) {
        for (i in bytes.indices) {
            set(offset + i, bytes[i].toInt() and 0xFF)
        }
    }

    private fun requireInBounds(address: Int): Int {
        require(address in 0 until capacity) {
            "address 0x${address.toString(16)} out of range for memory of size 0x${capacity.toString(16)}"
        }
        return address
    }

    companion object {
        fun ofSize(capacity: Int): MemoryImage = MemoryImage(capacity)
    }
}
