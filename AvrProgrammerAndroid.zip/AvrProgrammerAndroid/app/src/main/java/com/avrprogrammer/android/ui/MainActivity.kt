package com.avrprogrammer.android.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.ArrayAdapter
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.avrprogrammer.android.device.AvrDevice
import com.avrprogrammer.android.device.DeviceDatabase
import com.avrprogrammer.android.databinding.ActivityMainBinding
import com.avrprogrammer.android.engine.AvrdudeEngine
import com.avrprogrammer.android.engine.FileFormat
import com.avrprogrammer.android.engine.MemoryFileOp
import com.avrprogrammer.android.engine.MemoryOpMode
import com.avrprogrammer.android.engine.ProgrammerCommand
import com.avrprogrammer.android.errors.AvrProgrammerException
import com.avrprogrammer.android.logging.LogLevel
import com.avrprogrammer.android.logging.Logger
import com.avrprogrammer.android.programmer.ImplementationStatus
import com.avrprogrammer.android.programmer.MemoryId
import com.avrprogrammer.android.programmer.Programmer
import com.avrprogrammer.android.programmer.ProgrammerDescriptor
import com.avrprogrammer.android.programmer.ProgrammerRegistry
import com.avrprogrammer.android.transport.UsbDeviceScanner
import com.avrprogrammer.android.transport.UsbHostTransport
import com.avrprogrammer.android.transport.UsbPermissionManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var deviceDatabase: DeviceDatabase
    private lateinit var scanner: UsbDeviceScanner
    private lateinit var permissionManager: UsbPermissionManager

    private var targetOptions: List<AvrDevice?> = emptyList() // null = auto-detect
    private var selectedFirmwarePath: String? = null

    private val openDocumentLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { importFirmwareFile(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        scanner = UsbDeviceScanner(this)
        permissionManager = UsbPermissionManager(this)
        deviceDatabase = DeviceDatabase.load(this)

        setupProgrammerSpinner()
        setupTargetSpinner()
        attachLogListener()

        binding.btnDetectUsb.setOnClickListener { detectUsbDevices() }
        binding.btnSelectFile.setOnClickListener {
            openDocumentLauncher.launch(arrayOf("*/*"))
        }
        binding.btnProgram.setOnClickListener { runProgramFlow() }
        binding.btnReadBack.setOnClickListener { runReadBackFlow() }

        detectUsbDevices()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(com.avrprogrammer.android.R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            com.avrprogrammer.android.R.id.action_hardware_test -> startActivity(Intent(this, HardwareTestActivity::class.java))
            com.avrprogrammer.android.R.id.action_fuse_editor -> startActivity(
                Intent(this, FuseEditorActivity::class.java)
                    .putExtra(FuseEditorActivity.EXTRA_PART_ID, selectedDevice()?.id)
                    .putExtra(FuseEditorActivity.EXTRA_PROGRAMMER_ID, selectedProgrammer().id)
            )
            com.avrprogrammer.android.R.id.action_log_viewer -> startActivity(Intent(this, LogViewerActivity::class.java))
            com.avrprogrammer.android.R.id.action_settings -> startActivity(Intent(this, SettingsActivity::class.java))
            com.avrprogrammer.android.R.id.action_licenses -> startActivity(Intent(this, ThirdPartyLicensesActivity::class.java))
        }
        return true
    }

    private fun setupProgrammerSpinner() {
        val descriptors = ProgrammerRegistry.all
        val labels = descriptors.map {
            if (it.status == ImplementationStatus.IMPLEMENTED) it.displayName else "${it.displayName} (not implemented)"
        }
        binding.spinnerProgrammer.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        // Default-select the first fully implemented entry (USBasp) rather than index 0's
        // alphabetical-ish ordering, since that's the one the brief mandates be complete.
        val defaultIndex = descriptors.indexOfFirst { it.id == "usbasp" }.takeIf { it >= 0 } ?: 0
        binding.spinnerProgrammer.setSelection(defaultIndex)
    }

    private fun setupTargetSpinner() {
        val sorted = deviceDatabase.devices.sortedBy { it.desc }
        targetOptions = listOf(null) + sorted
        val labels = listOf(getString(com.avrprogrammer.android.R.string.auto_detect)) + sorted.map { it.desc }
        binding.spinnerTarget.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
    }

    private fun selectedProgrammer(): ProgrammerDescriptor = ProgrammerRegistry.all[binding.spinnerProgrammer.selectedItemPosition]
    private fun selectedDevice(): AvrDevice? = targetOptions.getOrNull(binding.spinnerTarget.selectedItemPosition)

    private fun attachLogListener() {
        Logger.addListener { entry ->
            if (entry.level.ordinal > LogLevel.DEBUG.ordinal) return@addListener // keep the on-screen log readable; full detail is in Log Viewer / export
            runOnUiThread {
                binding.txtLog.append(entry.format() + "\n")
            }
        }
    }

    private fun detectUsbDevices() {
        if (!UsbHostTransport.isUsbHostSupported(this)) {
            binding.txtUsbSummary.text = getString(com.avrprogrammer.android.R.string.usb_host_unsupported)
            return
        }
        val devices = scanner.listAttachedDevices()
        binding.txtUsbSummary.text = if (devices.isEmpty()) {
            "No USB devices attached"
        } else {
            devices.joinToString("\n") { d ->
                val known = ProgrammerRegistry.findByVidPid(d.vendorId, d.productId)
                "%04X:%04X %s%s".format(d.vendorId, d.productId, d.productName ?: "", known?.let { " -> ${it.displayName}" } ?: "")
            }
        }
    }

    private fun importFirmwareFile(uri: Uri) {
        val cacheFile = File(cacheDir, "firmware_import.hex")
        contentResolver.openInputStream(uri)?.use { input ->
            cacheFile.outputStream().use { output -> input.copyTo(output) }
        }
        selectedFirmwarePath = cacheFile.absolutePath
        binding.txtFirmwarePath.text = uri.lastPathSegment ?: cacheFile.name
    }

    private fun runProgramFlow() {
        val firmwarePath = selectedFirmwarePath
        if (binding.chkWriteFlash.isChecked && firmwarePath == null) {
            binding.txtStatus.text = "Select a firmware file first"
            return
        }
        val descriptor = selectedProgrammer()
        val device = selectedDevice()

        val memoryOps = buildList {
            if (binding.chkWriteFlash.isChecked && firmwarePath != null) {
                add(MemoryFileOp(MemoryId.FLASH, MemoryOpMode.WRITE, firmwarePath, FileFormat.IHEX))
            }
        }
        val command = ProgrammerCommand(
            programmerId = descriptor.id,
            partId = device?.id,
            chipErase = binding.chkErase.isChecked,
            memoryOps = memoryOps,
            verifyAfterWrite = binding.chkVerify.isChecked
        )
        executeCommand(descriptor, command)
    }

    private fun runReadBackFlow() {
        val descriptor = selectedProgrammer()
        val device = selectedDevice()
        if (device == null) {
            binding.txtStatus.text = "Select a specific target part to read back (not Auto Detect)"
            return
        }
        val outFile = File(cacheDir, "readback_${device.id}.hex").absolutePath
        val command = ProgrammerCommand(
            programmerId = descriptor.id,
            partId = device.id,
            memoryOps = listOf(MemoryFileOp(MemoryId.FLASH, MemoryOpMode.READ, outFile, FileFormat.IHEX)),
            verifyAfterWrite = false
        )
        executeCommand(descriptor, command)
    }

    private fun executeCommand(descriptor: ProgrammerDescriptor, command: ProgrammerCommand) {
        binding.txtLog.text = ""
        binding.txtStatus.text = "Connecting..."
        binding.progressBar.progress = 0

        lifecycleScope.launch {
            try {
                val usbDevice = descriptor.knownVidPids.firstNotNullOfOrNull { (vid, pid) -> scanner.findByVidPid(vid, pid) }
                    ?: throw IllegalStateException("No attached USB device matches ${descriptor.displayName}'s known VID/PID. Tap 'Detect USB Devices' and check wiring.")

                val granted = permissionManager.requestPermission(usbDevice)
                if (!granted) {
                    binding.txtStatus.text = getString(com.avrprogrammer.android.R.string.usb_permission_denied)
                    return@launch
                }

                val iface = scanner.pickPreferredInterface(usbDevice)
                    ?: throw IllegalStateException("Device exposes no usable USB interface")
                val usbTransport = UsbHostTransport(this@MainActivity, usbDevice, iface)

                val programmer = buildProgrammer(descriptor.id, usbTransport)
                val engine = AvrdudeEngine(programmer, deviceDatabase)

                val result = withContext(Dispatchers.IO) {
                    engine.run(command) { memory, done, total ->
                        runOnUiThread { binding.progressBar.progress = if (total > 0) (done * 100 / total) else 0 }
                    }
                }

                binding.txtStatus.text = "Connected\nDevice: ${result.device.desc}\nSignature: ${result.signatureRead.joinToString(" ") { "%02X".format(it) }}\n" +
                    if (result.success) "Success" else "Verification failed (see log)"
                binding.progressBar.progress = 100
            } catch (e: AvrProgrammerException) {
                binding.txtStatus.text = e.detailLines().joinToString("\n")
            } catch (e: Exception) {
                binding.txtStatus.text = "Error: ${e.message}"
            }
        }
    }

    /** Maps a programmer id to its concrete implementation over the given transport. */
    private fun buildProgrammer(programmerId: String, usb: UsbHostTransport): Programmer =
        ProgrammerFactory.build(programmerId, usb)
}
