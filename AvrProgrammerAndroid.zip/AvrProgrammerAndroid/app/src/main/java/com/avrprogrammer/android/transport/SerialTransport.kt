package com.avrprogrammer.android.transport

/**
 * A plain byte-stream serial port, as used by STK500v1 and (over the same protocol)
 * Arduino-as-ISP. Kept separate from [UsbTransport] because serial programmers are
 * conceptually a byte stream with flow control, not a set of USB request types -- the
 * protocol layer (Stk500v1Programmer) should not need to know whether the bytes
 * travel over USB CDC-ACM, a Bluetooth SPP link, or (outside what Android exposes) a
 * real UART.
 */
interface SerialTransport {
    fun open()
    fun close()
    val isOpen: Boolean

    fun setLineCoding(baudRate: Int, dataBits: Int = 8, stopBits: Int = 1, parity: Int = 0)
    fun setDtrRts(dtr: Boolean, rts: Boolean)

    /** Writes all of [data]; throws TransportException on failure/timeout. */
    fun write(data: ByteArray, timeoutMs: Int)

    /** Reads up to [length] bytes, blocking until at least one byte arrives or timeout elapses. Returns bytes read (0 on timeout). */
    fun read(buffer: ByteArray, length: Int, timeoutMs: Int): Int
}
