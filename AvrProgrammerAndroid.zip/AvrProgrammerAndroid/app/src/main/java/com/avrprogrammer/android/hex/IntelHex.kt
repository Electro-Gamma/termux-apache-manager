package com.avrprogrammer.android.hex

import com.avrprogrammer.android.memory.MemoryImage

/**
 * Intel HEX record types (see hex/INTEL-HEX.txt style references, and AVRDUDE's
 * src/fileio.c ihex reader/writer which this mirrors at the record-type level).
 */
object IHexRecordType {
    const val DATA = 0x00
    const val EOF = 0x01
    const val EXTENDED_SEGMENT_ADDRESS = 0x02
    const val START_SEGMENT_ADDRESS = 0x03
    const val EXTENDED_LINEAR_ADDRESS = 0x04
    const val START_LINEAR_ADDRESS = 0x05
}

class IntelHexParseException(message: String, val lineNumber: Int) :
    Exception("line $lineNumber: $message")

data class IntelHexParseResult(
    val image: MemoryImage,
    val warnings: List<String>,
    val startSegmentAddress: Long? = null,
    val startLinearAddress: Long? = null
)

/**
 * Robust Intel HEX reader/writer.
 *
 * Supports all six standard record types (00 Data, 01 EOF, 02 Extended Segment
 * Address, 03 Start Segment Address, 04 Extended Linear Address, 05 Start Linear
 * Address) and validates record length, address, record type, and checksum on every
 * line, as required by the project brief section 14. Overlapping records are allowed
 * (last write wins, like AVRDUDE/objcopy) but are reported back as a warning so the
 * caller can decide whether that's suspicious for their use case. A missing EOF
 * record is likewise reported as a warning rather than a hard failure, since some
 * toolchains still emit files without one.
 */
object IntelHexParser {

    fun parse(text: String, capacity: Int): IntelHexParseResult {
        val image = MemoryImage(capacity)
        val warnings = mutableListOf<String>()
        var extendedAddress = 0L // set by record type 02 (<<4) or 04 (<<16)
        var sawEof = false
        var startSegmentAddress: Long? = null
        var startLinearAddress: Long? = null
        val writtenAddresses = HashSet<Int>()

        val lines = text.lines()
        for ((idx, rawLine) in lines.withIndex()) {
            val lineNumber = idx + 1
            val line = rawLine.trim()
            if (line.isEmpty()) continue
            if (!line.startsWith(":")) {
                throw IntelHexParseException("record does not start with ':'", lineNumber)
            }
            if (sawEof) {
                warnings += "line $lineNumber: data found after EOF record; ignoring"
                continue
            }

            val hexBody = line.substring(1)
            if (hexBody.length < 10 || hexBody.length % 2 != 0) {
                throw IntelHexParseException("record has invalid length", lineNumber)
            }
            val bytes = try {
                ByteArray(hexBody.length / 2) { i ->
                    hexBody.substring(i * 2, i * 2 + 2).toInt(16).toByte()
                }
            } catch (e: NumberFormatException) {
                throw IntelHexParseException("record contains non-hex characters", lineNumber)
            }

            val byteCount = bytes[0].toInt() and 0xFF
            val addressField = ((bytes[1].toInt() and 0xFF) shl 8) or (bytes[2].toInt() and 0xFF)
            val recordType = bytes[3].toInt() and 0xFF
            val expectedLength = 4 + byteCount + 1 // byteCount + addr(2) + type(1) + data + checksum
            if (bytes.size != expectedLength) {
                throw IntelHexParseException(
                    "byte count field ($byteCount) does not match record length", lineNumber
                )
            }

            val checksum = bytes.last().toInt() and 0xFF
            var sum = 0
            for (i in 0 until bytes.size - 1) sum += (bytes[i].toInt() and 0xFF)
            val computed = (0x100 - (sum and 0xFF)) and 0xFF
            if (computed != checksum) {
                throw IntelHexParseException(
                    "checksum mismatch (expected 0x%02X, got 0x%02X)".format(computed, checksum),
                    lineNumber
                )
            }

            when (recordType) {
                IHexRecordType.DATA -> {
                    val base = extendedAddress + addressField
                    for (i in 0 until byteCount) {
                        val addr = (base + i)
                        if (addr < 0 || addr >= capacity) {
                            throw IntelHexParseException(
                                "data address 0x%X is outside the target memory (capacity 0x%X)"
                                    .format(addr, capacity),
                                lineNumber
                            )
                        }
                        val addrInt = addr.toInt()
                        if (!writtenAddresses.add(addrInt)) {
                            warnings += "line $lineNumber: address 0x%04X overlaps a previous record".format(addrInt)
                        }
                        image.set(addrInt, bytes[4 + i].toInt() and 0xFF)
                    }
                }

                IHexRecordType.EOF -> {
                    if (byteCount != 0) {
                        warnings += "line $lineNumber: EOF record has non-zero byte count"
                    }
                    sawEof = true
                }

                IHexRecordType.EXTENDED_SEGMENT_ADDRESS -> {
                    if (byteCount != 2) {
                        throw IntelHexParseException("extended segment address record must carry 2 data bytes", lineNumber)
                    }
                    val segment = ((bytes[4].toInt() and 0xFF) shl 8) or (bytes[5].toInt() and 0xFF)
                    extendedAddress = segment.toLong() shl 4
                }

                IHexRecordType.START_SEGMENT_ADDRESS -> {
                    if (byteCount != 4) {
                        throw IntelHexParseException("start segment address record must carry 4 data bytes", lineNumber)
                    }
                    startSegmentAddress = bytesToU32(bytes, 4)
                }

                IHexRecordType.EXTENDED_LINEAR_ADDRESS -> {
                    if (byteCount != 2) {
                        throw IntelHexParseException("extended linear address record must carry 2 data bytes", lineNumber)
                    }
                    val upper = ((bytes[4].toInt() and 0xFF) shl 8) or (bytes[5].toInt() and 0xFF)
                    extendedAddress = upper.toLong() shl 16
                }

                IHexRecordType.START_LINEAR_ADDRESS -> {
                    if (byteCount != 4) {
                        throw IntelHexParseException("start linear address record must carry 4 data bytes", lineNumber)
                    }
                    startLinearAddress = bytesToU32(bytes, 4)
                }

                else -> {
                    warnings += "line $lineNumber: unknown record type 0x%02X; ignoring".format(recordType)
                }
            }
        }

        if (!sawEof) {
            warnings += "file has no EOF (:00000001FF) record"
        }

        return IntelHexParseResult(image, warnings, startSegmentAddress, startLinearAddress)
    }

    private fun bytesToU32(bytes: ByteArray, offset: Int): Long =
        ((bytes[offset].toInt() and 0xFF).toLong() shl 24) or
            ((bytes[offset + 1].toInt() and 0xFF).toLong() shl 16) or
            ((bytes[offset + 2].toInt() and 0xFF).toLong() shl 8) or
            (bytes[offset + 3].toInt() and 0xFF).toLong()
}

/**
 * Writes a MemoryImage back out as Intel HEX. Emits Extended Linear Address records
 * (type 04) as needed for images larger than 64 KiB, and only emits records that
 * cover addresses the image actually marked as written (see MemoryImage.isTouched) --
 * matching AVRDUDE's default behaviour of not re-emitting untouched 0xFF filler.
 */
object IntelHexWriter {

    private const val BYTES_PER_RECORD = 16

    fun write(image: MemoryImage): String = buildString {
        var lastUpperAddress = -1
        var addr = 0
        while (addr < image.size) {
            // Find the next touched byte to avoid emitting long runs of untouched filler.
            if (!image.isTouched(addr)) {
                addr++
                continue
            }
            val chunkLen = minOf(BYTES_PER_RECORD, image.size - addr)
            val chunkBytes = ByteArray(chunkLen) { image.get(addr + it).toByte() }

            val upperAddress = (addr ushr 16) and 0xFFFF
            if (upperAddress != lastUpperAddress) {
                appendLine(extendedLinearAddressRecord(upperAddress))
                lastUpperAddress = upperAddress
            }

            val lowAddress = addr and 0xFFFF
            appendLine(dataRecord(lowAddress, chunkBytes))
            addr += chunkLen
        }
        appendLine(eofRecord())
    }

    private fun dataRecord(address: Int, data: ByteArray): String {
        val body = mutableListOf<Int>()
        body += data.size
        body += (address shr 8) and 0xFF
        body += address and 0xFF
        body += IHexRecordType.DATA
        for (b in data) body += (b.toInt() and 0xFF)
        return renderRecord(body)
    }

    private fun extendedLinearAddressRecord(upperAddress: Int): String {
        val body = mutableListOf(2, 0, 0, IHexRecordType.EXTENDED_LINEAR_ADDRESS, (upperAddress shr 8) and 0xFF, upperAddress and 0xFF)
        return renderRecord(body)
    }

    private fun eofRecord(): String = renderRecord(mutableListOf(0, 0, 0, IHexRecordType.EOF))

    private fun renderRecord(fieldsWithoutChecksum: List<Int>): String {
        val sum = fieldsWithoutChecksum.sumOf { it and 0xFF }
        val checksum = (0x100 - (sum and 0xFF)) and 0xFF
        val allBytes = fieldsWithoutChecksum + checksum
        return ":" + allBytes.joinToString("") { "%02X".format(it) }
    }
}

/** Trivial BIN <-> MemoryImage conversion (section 14: "BIN -> memory image / memory image -> BIN"). */
object BinFileIo {
    fun read(bytes: ByteArray, capacity: Int): MemoryImage {
        val image = MemoryImage(capacity)
        image.fillFrom(bytes)
        return image
    }

    fun write(image: MemoryImage): ByteArray {
        val range = image.touchedRange() ?: return ByteArray(0)
        return ByteArray(range.last - range.first + 1) { image.get(range.first + it).toByte() }
    }
}
