package com.avrprogrammer.android.engine

import com.avrprogrammer.android.device.AvrDevice
import com.avrprogrammer.android.verify.VerifyResult

data class EngineRunResult(
    val device: AvrDevice,
    val signatureRead: IntArray,
    val eraseDone: Boolean,
    val verifyResults: List<VerifyResult>,
    val log: List<String>
) {
    val success: Boolean get() = verifyResults.all { it.passed }
}
