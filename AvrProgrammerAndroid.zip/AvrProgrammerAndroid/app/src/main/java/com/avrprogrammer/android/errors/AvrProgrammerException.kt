package com.avrprogrammer.android.errors

/**
 * Base of the engine's structured exception hierarchy.
 *
 * AVRDUDE_PORTING.md section 20 of the project brief requires every error to carry
 * enough structured context (programmer / protocol / command / expected vs received
 * response / USB error) to be useful without re-running with extra verbosity. Each
 * field below is optional because not every failure has all of them (a HEX parse
 * error has no programmer or USB context, for instance) but implementations should
 * fill in as many as are known.
 */
sealed class AvrProgrammerException(
    message: String,
    cause: Throwable? = null,
    val programmer: String? = null,
    val protocol: String? = null,
    val command: String? = null,
    val expected: String? = null,
    val received: String? = null,
    val usbError: String? = null
) : Exception(message, cause) {

    /** Renders every populated structured field, one per line, for the log/UI. */
    fun detailLines(): List<String> {
        val out = mutableListOf("Error: $message")
        programmer?.let { out += "Programmer: $it" }
        protocol?.let { out += "Protocol: $it" }
        command?.let { out += "Command: $it" }
        expected?.let { out += "Expected: $it" }
        received?.let { out += "Received: $it" }
        usbError?.let { out += "USB error: $it" }
        return out
    }
}

/** USB enumeration, permission, or transfer-level failure (below the protocol layer). */
class TransportException(
    message: String,
    cause: Throwable? = null,
    programmer: String? = null,
    usbError: String? = null
) : AvrProgrammerException(message, cause, programmer = programmer, usbError = usbError)

/** A protocol handshake, sync, or response did not match what the programmer's protocol requires. */
class ProtocolException(
    message: String,
    cause: Throwable? = null,
    programmer: String? = null,
    protocol: String? = null,
    command: String? = null,
    expected: String? = null,
    received: String? = null
) : AvrProgrammerException(
    message, cause,
    programmer = programmer, protocol = protocol, command = command,
    expected = expected, received = received
)

/** Chip signature did not match any known part, or no chip responded at all. */
class DeviceDetectionException(
    message: String,
    expected: String? = null,
    received: String? = null
) : AvrProgrammerException(message, expected = expected, received = received)

/** A read/write/erase against a memory region (flash, EEPROM, fuses, ...) failed. */
class MemoryOperationException(
    message: String,
    cause: Throwable? = null,
    programmer: String? = null,
    command: String? = null
) : AvrProgrammerException(message, cause, programmer = programmer, command = command)

/** Read-back after a write did not match the image that was written. */
class VerificationException(
    val memory: String,
    val address: Int,
    val expectedByte: Int,
    val actualByte: Int
) : AvrProgrammerException(
    "Verification failed\nMemory: %s\nAddress: 0x%04X\nExpected: 0x%02X\nRead:     0x%02X"
        .format(memory, address, expectedByte, actualByte),
    expected = "0x%02X".format(expectedByte),
    received = "0x%02X".format(actualByte)
)

/**
 * Raised for functionality that is intentionally not implemented rather than silently
 * faked. Carries the same structured fields the project brief's section 31 template
 * asks for (FEATURE / STATUS / REASON / AVRDUDE SOURCE REFERENCE) so the UI and logs
 * can render it directly instead of pretending the operation happened.
 */
class FeatureNotImplementedException(
    val feature: String,
    val reason: String,
    val avrdudeSourceReference: String
) : AvrProgrammerException(
    "FEATURE: $feature\nSTATUS: NOT IMPLEMENTED\nREASON: $reason\nAVRDUDE SOURCE REFERENCE: $avrdudeSourceReference"
)
