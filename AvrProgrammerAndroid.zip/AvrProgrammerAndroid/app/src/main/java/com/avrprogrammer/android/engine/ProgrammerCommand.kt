package com.avrprogrammer.android.engine

import com.avrprogrammer.android.programmer.MemoryId

enum class FileFormat { IHEX, BIN, ELF }
enum class MemoryOpMode { READ, WRITE }

/** One `-U memory:r|w:file[:format]` entry. */
data class MemoryFileOp(
    val memory: MemoryId,
    val mode: MemoryOpMode,
    val filePath: String,
    val format: FileFormat = FileFormat.IHEX
)

/** One fuse/lock write, applied after erase+flash/eeprom ops, before verify -- matches AVRDUDE applying -U fuse-writes in command order. */
data class FuseWriteOp(val fuseName: String, val value: Int)

/**
 * The engine's command model -- deliberately shaped like AVRDUDE's own command line
 * (project brief section 17: "internally implement an AVRDUDE-like command model"),
 * e.g.
 * ```
 * -c usbasp -p atmega328p -P usb -U flash:w:firmware.hex -U eeprom:r:eeprom.hex
 * ```
 * maps onto:
 * ```
 * ProgrammerCommand(programmerId = "usbasp", partId = "atmega328p", port = "usb",
 *   memoryOps = listOf(MemoryFileOp(FLASH, WRITE, "firmware.hex"), MemoryFileOp(EEPROM, READ, "eeprom.hex")))
 * ```
 * The Android UI (MainActivity et al.) builds one of these from its form fields and
 * hands it to [AvrdudeEngine.run] -- the UI never talks to a [com.avrprogrammer.android.programmer.Programmer]
 * directly (section 17: "Do not place programming logic directly inside UI code").
 */
data class ProgrammerCommand(
    val programmerId: String,       // -c
    val partId: String?,            // -p; null = auto-detect from signature
    val port: String = "usb",       // -P (currently informational; USB device selection happens via UsbDeviceScanner)
    val chipErase: Boolean = false,
    val memoryOps: List<MemoryFileOp> = emptyList(),
    val fuseWrites: List<FuseWriteOp> = emptyList(),
    val verifyAfterWrite: Boolean = true,
    val sckFrequencyHz: Int? = null
) {
    /** Renders back to an avrdude-style command line, for logs and the raw/debug log view. */
    fun toCommandLineString(): String = buildString {
        append("-c $programmerId ")
        if (partId != null) append("-p $partId ") else append("-p auto ")
        append("-P $port")
        if (chipErase) append(" -e")
        for (op in memoryOps) {
            val memName = if (op.memory == MemoryId.FLASH) "flash" else "eeprom"
            val rw = if (op.mode == MemoryOpMode.WRITE) "w" else "r"
            append(" -U $memName:$rw:${op.filePath}")
        }
        for (f in fuseWrites) append(" -U ${f.fuseName}:w:0x%02X:m".format(f.value))
        if (!verifyAfterWrite) append(" -V")
        if (sckFrequencyHz != null) append(" -B ${sckFrequencyHz}Hz")
    }
}
