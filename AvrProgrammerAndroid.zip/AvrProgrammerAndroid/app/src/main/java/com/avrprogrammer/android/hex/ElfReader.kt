package com.avrprogrammer.android.hex

import com.avrprogrammer.android.memory.MemoryImage
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Result of pulling an AVR firmware image out of an ELF file: separate flash and
 * EEPROM images, since a single .elf can contain both (avr-gcc puts EEPROM-resident
 * data in a section literally named ".eeprom").
 */
data class ElfExtractResult(val flash: MemoryImage?, val eeprom: MemoryImage?, val warnings: List<String>)

/**
 * Minimal ELF32 (little-endian) reader targeted at avr-gcc/avr-objcopy output, per
 * project brief section 14 ("Supporting ELF input where practical").
 *
 * This intentionally does NOT implement a general-purpose ELF loader: no relocation
 * processing, no symbol resolution, no support for 64-bit ELF (AVR toolchains do not
 * produce ELF64). It walks the section header table and pulls the bytes of every
 * SHT_PROGBITS section with the SHF_ALLOC flag set into a flash image (the standard
 * avr-gcc layout puts .text/.data/.rodata/.vectors etc. there, all addressed within
 * the flash address space), and separately collects any section literally named
 * ".eeprom" (the convention avr-libc's <avr/eeprom.h> attribute puts data under) into
 * an EEPROM image. This mirrors what `avr-objcopy -O ihex firmware.elf firmware.hex`
 * effectively does for the common case, without depending on objcopy being present.
 */
object ElfReader {

    private const val SHT_PROGBITS = 1
    private const val SHF_ALLOC = 0x2L
    private const val SHF_EXECINSTR = 0x4L

    fun extract(bytes: ByteArray, flashCapacity: Int, eepromCapacity: Int): ElfExtractResult {
        val warnings = mutableListOf<String>()
        if (bytes.size < 52 || bytes[0] != 0x7F.toByte() || bytes[1] != 'E'.code.toByte() ||
            bytes[2] != 'L'.code.toByte() || bytes[3] != 'F'.code.toByte()
        ) {
            throw IllegalArgumentException("not an ELF file (bad magic)")
        }
        val elfClass = bytes[4].toInt()
        if (elfClass != 1) {
            throw IllegalArgumentException("only 32-bit ELF (ELFCLASS32) is supported for AVR firmware; got class $elfClass")
        }
        val dataEncoding = bytes[5].toInt()
        if (dataEncoding != 1) {
            throw IllegalArgumentException("only little-endian ELF (ELFDATA2LSB) is supported; AVR toolchains do not emit big-endian ELF")
        }

        val buf = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)

        val machine = buf.getShort(18).toInt() and 0xFFFF
        if (machine != 83) { // EM_AVR = 83
            warnings += "ELF e_machine=$machine is not EM_AVR (83); this may not be an AVR firmware image"
        }

        val shoff = buf.getInt(32).toLong() and 0xFFFFFFFFL
        val shentsize = buf.getShort(46).toInt() and 0xFFFF
        val shnum = buf.getShort(48).toInt() and 0xFFFF
        val shstrndx = buf.getShort(50).toInt() and 0xFFFF

        if (shoff == 0L || shnum == 0) {
            throw IllegalArgumentException("ELF file has no section header table")
        }

        fun sectionHeader(index: Int): SectionHeader {
            val off = (shoff + index.toLong() * shentsize).toInt()
            return SectionHeader(
                nameOffset = buf.getInt(off),
                type = buf.getInt(off + 4),
                flags = buf.getInt(off + 8).toLong() and 0xFFFFFFFFL,
                addr = buf.getInt(off + 12).toLong() and 0xFFFFFFFFL,
                offset = buf.getInt(off + 16).toLong() and 0xFFFFFFFFL,
                size = buf.getInt(off + 20).toLong() and 0xFFFFFFFFL
            )
        }

        val strTabHeader = sectionHeader(shstrndx)
        fun sectionName(nameOffset: Int): String {
            val start = (strTabHeader.offset + nameOffset).toInt()
            var end = start
            while (end < bytes.size && bytes[end] != 0.toByte()) end++
            return String(bytes, start, end - start, Charsets.US_ASCII)
        }

        val flashImage = MemoryImage(flashCapacity)
        val eepromImage = MemoryImage(eepromCapacity)
        var sawFlashData = false
        var sawEepromData = false

        for (i in 0 until shnum) {
            val sh = sectionHeader(i)
            if (sh.type != SHT_PROGBITS || sh.size == 0L) continue
            val name = sectionName(sh.nameOffset)
            val fileStart = sh.offset.toInt()
            val fileEnd = (sh.offset + sh.size).toInt()
            if (fileStart < 0 || fileEnd > bytes.size) {
                warnings += "section $name has an out-of-range file offset; skipped"
                continue
            }

            if (name == ".eeprom") {
                // avr-libc EEPROM sections are typically linked at a high virtual address
                // (e.g. 0x81xxxxxx) that is only meaningful to the linker; the actual
                // EEPROM byte address is the low bits, mirroring `--change-section-lma
                // .eeprom=0` in a normal avr-objcopy invocation.
                val eepromAddr = (sh.addr and 0xFFFFFL).toInt()
                if (eepromAddr + sh.size > eepromCapacity) {
                    warnings += "section .eeprom (${sh.size} bytes at 0x${eepromAddr.toString(16)}) does not fit the target's EEPROM; truncated"
                }
                for (b in 0 until sh.size.toInt()) {
                    val addr = eepromAddr + b
                    if (addr in 0 until eepromCapacity) {
                        eepromImage.set(addr, bytes[fileStart + b].toInt() and 0xFF)
                        sawEepromData = true
                    }
                }
                continue
            }

            if (sh.flags and SHF_ALLOC == 0L) continue // debug/comment sections etc: not part of the firmware image
            if (sh.addr >= 0x800000L) continue // RAM-mapped (.bss/.data's VMA); not flash content by address convention

            val flashAddr = sh.addr.toInt()
            if (flashAddr + sh.size > flashCapacity) {
                warnings += "section $name (${sh.size} bytes at 0x${flashAddr.toString(16)}) does not fit the target's flash; truncated"
            }
            for (b in 0 until sh.size.toInt()) {
                val addr = flashAddr + b
                if (addr in 0 until flashCapacity) {
                    flashImage.set(addr, bytes[fileStart + b].toInt() and 0xFF)
                    sawFlashData = true
                }
            }
        }

        return ElfExtractResult(
            flash = if (sawFlashData) flashImage else null,
            eeprom = if (sawEepromData) eepromImage else null,
            warnings = warnings
        )
    }

    private data class SectionHeader(
        val nameOffset: Int,
        val type: Int,
        val flags: Long,
        val addr: Long,
        val offset: Long,
        val size: Long
    )
}
