package com.avrprogrammer.android.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.avrprogrammer.android.databinding.ActivityLogViewerBinding
import com.avrprogrammer.android.logging.Logger
import java.io.File

/** Project brief section 19: full raw log view, exportable, never hiding protocol errors. */
class LogViewerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLogViewerBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLogViewerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        refresh()
        Logger.addListener { refresh() }

        binding.btnExportLog.setOnClickListener { exportLog() }
        binding.btnClearLog.setOnClickListener { Logger.clear(); refresh() }
    }

    private fun refresh() {
        binding.txtFullLog.text = Logger.exportText()
    }

    private fun exportLog() {
        val dir = File(cacheDir, "logs").apply { mkdirs() }
        val file = File(dir, "avr-programmer-log-${System.currentTimeMillis()}.txt")
        file.writeText(Logger.exportText())

        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "Export log"))
    }
}
