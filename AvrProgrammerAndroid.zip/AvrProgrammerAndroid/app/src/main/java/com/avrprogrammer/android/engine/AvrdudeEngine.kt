package com.avrprogrammer.android.engine

import com.avrprogrammer.android.device.AvrDevice
import com.avrprogrammer.android.device.AvrMemoryDef
import com.avrprogrammer.android.device.DeviceDatabase
import com.avrprogrammer.android.errors.DeviceDetectionException
import com.avrprogrammer.android.errors.FeatureNotImplementedException
import com.avrprogrammer.android.hex.BinFileIo
import com.avrprogrammer.android.hex.ElfReader
import com.avrprogrammer.android.hex.IntelHexParser
import com.avrprogrammer.android.hex.IntelHexWriter
import com.avrprogrammer.android.logging.Logger
import com.avrprogrammer.android.memory.MemoryImage
import com.avrprogrammer.android.programmer.ImplementationStatus
import com.avrprogrammer.android.programmer.MemoryId
import com.avrprogrammer.android.programmer.Programmer
import com.avrprogrammer.android.programmer.ProgrammerRegistry
import com.avrprogrammer.android.programmer.ProgressListener
import com.avrprogrammer.android.verify.VerifyResult
import com.avrprogrammer.android.verify.Verifier
import java.io.File

/**
 * The command-line-style engine every UI screen goes through (project brief section
 * 17). Takes a [Programmer] the caller has already constructed (USB permission and
 * device/interface selection are Android-framework concerns the engine deliberately
 * knows nothing about -- see [com.avrprogrammer.android.transport.UsbDeviceScanner] /
 * [com.avrprogrammer.android.transport.UsbPermissionManager] for that layer) plus the
 * [DeviceDatabase], and executes a [ProgrammerCommand] the same way `avrdude -c ... -p
 * ... -U ...` would: connect, detect/verify signature, erase if asked, run memory
 * file operations in order, write any fuse changes, verify writes, disconnect.
 */
class AvrdudeEngine(private val programmer: Programmer, private val deviceDatabase: DeviceDatabase) {

    companion object {
        /**
         * Programming Enable / Chip Erase / Read Signature are encoded identically for
         * essentially every classic AVR ISP part (all inherit from avrdude.conf's
         * ".classic" base -- see AVRDUDE_PORTING.md) so a connection can be opened and a
         * signature read *before* the exact target part is known, to support "Auto
         * Detect" in the UI. This bootstrap device carries only those three opcodes; it
         * is discarded as soon as the real part is identified from the device database.
         */
        private fun bootstrapDevice(): AvrDevice = AvrDevice(
            id = "_bootstrap", desc = "(auto-detecting)", signature = IntArray(3),
            progModes = listOf("ISP"), chipEraseDelayUs = 20_000,
            pgmEnableTemplate = "1010.1100--0101.0011--0000.0000--0000.0000",
            chipEraseTemplate = null,
            flash = AvrMemoryDef("flash", 0), eeprom = null, fuses = emptyList(), lock = null, calibration = null,
            signatureReadTemplate = "0011.0000--0000.0000--0000.00aa--oooo.oooo"
        )
    }

    /**
     * Runs [command] end to end. [resolveFile] maps a `MemoryFileOp.filePath` to
     * actual bytes/write-target -- kept as a caller-supplied function rather than
     * `java.io.File` directly so the Android UI can back it with SAF `content://`
     * URIs (via a cached copy) without the engine needing an Android `Context`.
     */
    fun run(command: ProgrammerCommand, progress: ProgressListener? = null): EngineRunResult {
        val log = mutableListOf<String>()
        fun step(msg: String) {
            log += msg
            Logger.info("AvrdudeEngine", msg)
        }

        step("Command: ${command.toCommandLineString()}")

        val descriptor = ProgrammerRegistry.byId(command.programmerId)
            ?: throw FeatureNotImplementedException(
                feature = command.programmerId, reason = "unknown programmer id",
                avrdudeSourceReference = "src/avrdude.conf.in programmer definitions"
            )
        if (descriptor.status != ImplementationStatus.IMPLEMENTED) {
            throw FeatureNotImplementedException(
                feature = descriptor.displayName, reason = descriptor.notes,
                avrdudeSourceReference = "see PROGRAMMERS.md"
            )
        }

        var device = command.partId?.let {
            deviceDatabase.byId(it) ?: throw DeviceDetectionException("unknown part id '$it' -- not in the bundled device database (see DEVICE_DATABASE.md)")
        } ?: bootstrapDevice()

        step("Opening ${descriptor.displayName}...")
        programmer.open(device)
        try {
            command.sckFrequencyHz?.let { programmer.setSckFrequencyHz(it) }

            step("Reading device signature...")
            val signature = programmer.readSignature(device)
            step("Signature: " + signature.joinToString(" ") { "%02X".format(it) })

            if (command.partId == null) {
                val matched = deviceDatabase.bySignature(signature)
                    ?: throw DeviceDetectionException(
                        "no part in the device database matches this signature -- the chip may not be in the curated device set (see DEVICE_DATABASE.md)",
                        expected = "a known signature", received = signature.joinToString(" ") { "%02X".format(it) }
                    )
                device = matched
                step("Auto-detected part: ${device.desc}")
            } else {
                if (!signature.contentEquals(device.signature)) {
                    throw DeviceDetectionException(
                        "signature read from target does not match ${device.desc}",
                        expected = device.signatureHex(),
                        received = signature.joinToString(" ") { "%02X".format(it) }
                    )
                }
            }

            var eraseDone = false
            if (command.chipErase) {
                step("Erasing chip...")
                programmer.chipErase(device)
                eraseDone = true
            }

            val verifyResults = mutableListOf<VerifyResult>()
            val writtenImages = mutableMapOf<MemoryId, MemoryImage>()

            for (op in command.memoryOps) {
                val memName = if (op.memory == MemoryId.FLASH) "flash" else "eeprom"
                when (op.mode) {
                    MemoryOpMode.WRITE -> {
                        step("Writing $memName from ${op.filePath}...")
                        val mem = memoryOf(device, op.memory)
                        val image = loadImage(op, mem.size)
                        programmer.writeMemory(device, op.memory, image, progress)
                        writtenImages[op.memory] = image
                        if (command.verifyAfterWrite) {
                            step("Verifying $memName...")
                            val readBack = programmer.readMemory(device, op.memory, progress)
                            val result = Verifier.verify(memName, image, readBack)
                            verifyResults += result
                            step(result.report().lines().first())
                        }
                    }
                    MemoryOpMode.READ -> {
                        step("Reading $memName to ${op.filePath}...")
                        val image = programmer.readMemory(device, op.memory, progress)
                        saveImage(op, image)
                    }
                }
            }

            for (fuseOp in command.fuseWrites) {
                step("Writing fuse '${fuseOp.fuseName}' = 0x%02X...".format(fuseOp.value))
                programmer.writeFuse(device, fuseOp.fuseName, fuseOp.value)
                val readBack = programmer.readFuse(device, fuseOp.fuseName)
                if (readBack != fuseOp.value) {
                    step("WARNING: fuse '${fuseOp.fuseName}' read back as 0x%02X, expected 0x%02X".format(readBack, fuseOp.value))
                }
            }

            step(if (verifyResults.all { it.passed }) "Done." else "Done with verification failures.")
            return EngineRunResult(device, signature, eraseDone, verifyResults, log)
        } finally {
            programmer.close()
        }
    }

    private fun memoryOf(device: AvrDevice, memory: MemoryId): AvrMemoryDef = when (memory) {
        MemoryId.FLASH -> device.flash
        MemoryId.EEPROM -> device.eeprom ?: error("device ${device.desc} has no EEPROM")
    }

    private fun loadImage(op: MemoryFileOp, capacity: Int): MemoryImage {
        val file = File(op.filePath)
        return when (op.format) {
            FileFormat.IHEX -> IntelHexParser.parse(file.readText(), capacity).also { result ->
                result.warnings.forEach { Logger.warning("AvrdudeEngine", "hex: $it") }
            }.image
            FileFormat.BIN -> BinFileIo.read(file.readBytes(), capacity)
            FileFormat.ELF -> {
                val extract = ElfReader.extract(file.readBytes(), flashCapacity = capacity, eepromCapacity = capacity)
                extract.warnings.forEach { Logger.warning("AvrdudeEngine", "elf: $it") }
                val selected = if (op.memory == MemoryId.FLASH) extract.flash else extract.eeprom
                selected ?: throw IllegalArgumentException("ELF file contained no ${if (op.memory == MemoryId.FLASH) "flash" else "EEPROM"} data")
            }
        }
    }

    private fun saveImage(op: MemoryFileOp, image: MemoryImage) {
        val file = File(op.filePath)
        when (op.format) {
            FileFormat.IHEX -> file.writeText(IntelHexWriter.write(image))
            FileFormat.BIN, FileFormat.ELF -> file.writeBytes(BinFileIo.write(image))
        }
    }
}
