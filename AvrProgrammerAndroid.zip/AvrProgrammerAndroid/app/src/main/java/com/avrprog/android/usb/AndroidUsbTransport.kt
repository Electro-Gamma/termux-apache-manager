package com.avrprog.android.usb

import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import com.avrprog.android.error.UsbTransportException
import com.avrprog.android.log.Logger

/**
 * Real android.hardware.usb-backed [UsbTransport]. Per brief section 3, this
 * does NOT assume a fixed interface/endpoint layout: it scans every interface
 * for bulk/interrupt endpoints and claims the first one that has any. Some
 * programmers (USBasp in particular) only ever use EP0 control transfers and
 * never need a claimed data interface at all -- that's a valid, supported state.
 */
class AndroidUsbTransport(
    private val device: UsbDevice,
    private val connection: UsbDeviceConnection
) : UsbTransport {

    override val vendorId: Int = device.vendorId
    override val productId: Int = device.productId

    private var claimedInterface: UsbInterface? = null
    val inEndpoint: UsbEndpoint?
    val outEndpoint: UsbEndpoint?

    init {
        var foundIface: UsbInterface? = null
        var foundIn: UsbEndpoint? = null
        var foundOut: UsbEndpoint? = null
        for (i in 0 until device.interfaceCount) {
            val iface = device.getInterface(i)
            var inEp: UsbEndpoint? = null
            var outEp: UsbEndpoint? = null
            for (e in 0 until iface.endpointCount) {
                val ep = iface.getEndpoint(e)
                if (ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK || ep.type == UsbConstants.USB_ENDPOINT_XFER_INT) {
                    if (ep.direction == UsbConstants.USB_DIR_IN) inEp = ep else outEp = ep
                }
            }
            if (inEp != null || outEp != null) {
                foundIface = iface; foundIn = inEp; foundOut = outEp
                break
            }
        }
        if (foundIface != null) {
            if (!connection.claimInterface(foundIface, true)) {
                Logger.warning("USB", "Could not claim interface ${foundIface.id}; continuing with control transfers only")
                foundIface = null
            }
        }
        claimedInterface = foundIface
        inEndpoint = foundIn
        outEndpoint = foundOut
    }

    override fun controlTransfer(
        requestType: Int, request: Int, value: Int, index: Int,
        buffer: ByteArray?, length: Int, timeoutMs: Int
    ): Int {
        val result = connection.controlTransfer(requestType, request, value, index, buffer, length, timeoutMs)
        if (result < 0) {
            throw UsbTransportException(
                "USB control transfer failed",
                usbError = "controlTransfer(reqType=0x${requestType.toString(16)}, req=0x${request.toString(16)}, " +
                    "val=0x${value.toString(16)}, idx=0x${index.toString(16)}) returned $result"
            )
        }
        val direction = if (requestType and UsbConstants.USB_DIR_IN != 0) "IN" else "OUT"
        Logger.rawUsb("$direction ctrl req=0x${request.toString(16)}", buffer?.copyOf(minOf(result.coerceAtLeast(0), buffer.size)) ?: ByteArray(0))
        return result
    }

    override fun bulkTransfer(endpointAddress: Int, buffer: ByteArray, length: Int, timeoutMs: Int): Int {
        val ep = listOfNotNull(inEndpoint, outEndpoint).firstOrNull { it.address == endpointAddress }
            ?: throw UsbTransportException("No claimed endpoint at address 0x${endpointAddress.toString(16)}")
        val result = connection.bulkTransfer(ep, buffer, length, timeoutMs)
        if (result < 0) {
            throw UsbTransportException("USB bulk transfer failed on endpoint 0x${endpointAddress.toString(16)}: returned $result")
        }
        Logger.rawUsb("bulk ep=0x${endpointAddress.toString(16)}", buffer.copyOf(minOf(result, buffer.size)))
        return result
    }

    override fun close() {
        claimedInterface?.let { connection.releaseInterface(it) }
        connection.close()
    }
}
