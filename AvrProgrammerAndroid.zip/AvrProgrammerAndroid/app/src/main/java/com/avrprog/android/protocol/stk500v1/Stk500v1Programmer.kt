package com.avrprog.android.protocol.stk500v1

import com.avrprog.android.device.AvrDevice
import com.avrprog.android.error.ProtocolException
import com.avrprog.android.log.Logger
import com.avrprog.android.memory.MemoryImage
import com.avrprog.android.protocol.Programmer
import com.avrprog.android.protocol.ProgrammerInfo
import com.avrprog.android.usb.SerialTransport
import com.avrprog.android.protocol.stk500v1.Stk500v1Constants as K

/**
 * Real STK500v1 protocol implementation, ported from AVRDUDE src/stk500.c
 * (synchronous serial protocol, GPLv2) -- see AVRDUDE_PORTING.md for the
 * function-by-function mapping.
 *
 * Covers the classic "real STK500v1 hardware / ISP-mode programmer" path:
 * get-sync, enter/leave program mode, paged flash+EEPROM read/write with
 * extended addressing for flash over 64K words, chip erase and signature
 * read via the generic ISP passthrough. Two things AVRDUDE's stk500.c also
 * handles are NOT covered here, and are called out rather than silently
 * mishandled:
 * - The "is_spm" bootloader-target variant (optiboot and friends), which
 *   uses different address division and extended-addressing rules.
 * - MIB510's fixed 256-byte block size quirk.
 * Both are documented as out of scope in PROTOCOLS.md.
 */
class Stk500v1Programmer(private val transport: SerialTransport) : Programmer {

    override val info = ProgrammerInfo(
        id = "stk500v1",
        name = "STK500 (v1)",
        vendorIds = emptyList(),
        productIds = emptyList(),
        protocol = "STK500 v1 synchronous serial protocol",
        transport = "Serial (USB-UART, 115200 8N1)",
        implemented = true
    )

    /** Tracks the last-sent extended address byte (my.ext_addr_byte in avrdude), so it's only re-sent when it changes. */
    private var extAddrByte: Int = -1

    override fun open() {
        transport.open(K.DEFAULT_BAUD_RATE)
        getSync()
        enterProgMode()
    }

    override fun close() {
        try {
            send(byteArrayOf(K.CMND_STK_LEAVE_PROGMODE.toByte(), K.SYNC_CRC_EOP.toByte()))
            recv(1); recv(1) // best-effort INSYNC + OK; ignored on the way out
        } catch (e: Exception) {
            Logger.warning("STK500v1", "LEAVE_PROGMODE on close() failed (device likely already gone): ${e.message}")
        }
        transport.close()
    }

    override fun readSignature(): ByteArray {
        // Standard AVR ISP "Read Signature Byte" instruction, same as every
        // other cmd()-based AVRDUDE programmer: 0x30 0x00 <index> 0x00.
        val sig = ByteArray(3)
        for (i in 0..2) {
            val res = universalCmd(byteArrayOf(0x30, 0x00, i.toByte(), 0x00))
            sig[i] = res[3]
        }
        return sig
    }

    override fun chipErase() {
        // Matches stk500_chip_erase(): standard ISP chip-erase instruction via
        // the universal passthrough, NOT a dedicated STK command.
        universalCmd(byteArrayOf(0xAC.toByte(), 0x80.toByte(), 0x00, 0x00))
        Thread.sleep(20) // conservative default; see AvrDevice.chipEraseDelayMs
        extAddrByte = -1
        // Matches avrdude's pgm->initialize(pgm, p) call after chip erase.
        getSync()
        enterProgMode()
    }

    override fun readMemory(memoryName: String, device: AvrDevice, onProgress: (Int, Int) -> Unit): MemoryImage {
        val memory = device.memories.firstOrNull { it.name == memoryName }
            ?: throw ProtocolException("Device ${device.description} has no memory named '$memoryName'")
        val memChar = if (memoryName == "flash") K.MEMCHAR_FLASH else K.MEMCHAR_EEPROM
        val aDiv = if (memoryName == "flash") 2 else 1
        val needsExt = memoryName == "flash" && memory.sizeBytes / aDiv > 0x10000

        val image = MemoryImage(memory.sizeBytes)
        var address = 0
        val blockSize = memory.pageSize.coerceIn(1, 0xFFFF)
        Logger.info("STK500v1", "Reading $memoryName (${memory.sizeBytes} bytes) from ${device.description}")
        while (address < memory.sizeBytes) {
            val thisBlock = minOf(blockSize, memory.sizeBytes - address)
            loadAddress(address / aDiv, needsExt)

            val cmd = byteArrayOf(
                K.CMND_STK_READ_PAGE.toByte(),
                ((thisBlock shr 8) and 0xFF).toByte(),
                (thisBlock and 0xFF).toByte(),
                memChar,
                K.SYNC_CRC_EOP.toByte()
            )
            send(cmd)
            expectInSync("READ_PAGE @0x${address.toString(16)}")
            val data = recv(thisBlock)
            expectOk("READ_PAGE @0x${address.toString(16)}")

            for (i in 0 until thisBlock) image.set(address + i, data[i])
            address += thisBlock
            onProgress(address, memory.sizeBytes)
        }
        return image
    }

    override fun writeMemory(memoryName: String, device: AvrDevice, image: MemoryImage, onProgress: (Int, Int) -> Unit) {
        val memory = device.memories.firstOrNull { it.name == memoryName }
            ?: throw ProtocolException("Device ${device.description} has no memory named '$memoryName'")
        val memChar = if (memoryName == "flash") K.MEMCHAR_FLASH else K.MEMCHAR_EEPROM
        val aDiv = if (memoryName == "flash") 2 else 1
        val needsExt = memoryName == "flash" && memory.sizeBytes / aDiv > 0x10000

        val range = image.writtenRange() ?: run {
            Logger.warning("STK500v1", "writeMemory($memoryName) called with an empty image; nothing to do")
            return
        }
        val end = range.last + 1
        var address = 0
        val blockSize = memory.pageSize.coerceIn(1, 0xFFFF)
        Logger.info("STK500v1", "Writing $memoryName (up to byte 0x${end.toString(16)}) to ${device.description}")
        while (address < end) {
            val thisBlock = minOf(blockSize, end - address)
            loadAddress(address / aDiv, needsExt)

            val cmd = ByteArray(4 + thisBlock + 1)
            cmd[0] = K.CMND_STK_PROG_PAGE.toByte()
            cmd[1] = ((thisBlock shr 8) and 0xFF).toByte()
            cmd[2] = (thisBlock and 0xFF).toByte()
            cmd[3] = memChar
            for (i in 0 until thisBlock) cmd[4 + i] = image.data[address + i]
            cmd[4 + thisBlock] = K.SYNC_CRC_EOP.toByte()
            send(cmd)
            expectInSync("PROG_PAGE @0x${address.toString(16)}")
            expectOk("PROG_PAGE @0x${address.toString(16)}")

            address += thisBlock
            onProgress(address, end)
        }
    }

    override fun setSckOption(id: Int) {
        // Real STK500 hardware and several serial-transport clones (notably
        // Arduino as ISP) either don't support or actively mishandle a
        // runtime bitclock change -- avrdude itself warns and skips it when
        // the programmer lacks HAS_BITCLOCK_ADJ. This build always uses the
        // device's own default rather than risk sending an unsupported command.
        Logger.warning("STK500v1", "Bitclock/SCK adjustment isn't implemented for STK500v1 in this build; using the device's default")
    }

    // --- Low-level STK500v1 protocol plumbing --------------------------------------------

    private fun getSync() {
        val cmd = byteArrayOf(K.CMND_STK_GET_SYNC.toByte(), K.SYNC_CRC_EOP.toByte())
        var inSync = false
        for (attempt in 0 until K.MAX_SYNC_ATTEMPTS) {
            send(cmd)
            val resp = try {
                recv(1)
            } catch (e: Exception) {
                Logger.debug("STK500v1", "getSync attempt ${attempt + 1}/${K.MAX_SYNC_ATTEMPTS}: ${e.message}")
                continue
            }
            if (resp[0] == K.RESP_STK_INSYNC.toByte()) {
                inSync = true
                break
            }
        }
        if (!inSync) {
            throw ProtocolException(
                "Could not get into sync with the STK500v1 device after ${K.MAX_SYNC_ATTEMPTS} attempts",
                protocol = "STK500v1", command = "GET_SYNC"
            )
        }
        expectOk("GET_SYNC")
    }

    private fun enterProgMode() {
        var tries = 0
        while (true) {
            tries++
            send(byteArrayOf(K.CMND_STK_ENTER_PROGMODE.toByte(), K.SYNC_CRC_EOP.toByte()))
            val b = recv(1)
            if (b[0] == K.RESP_STK_NOSYNC.toByte()) {
                if (tries > 33) {
                    throw ProtocolException("Cannot get into sync entering program mode", protocol = "STK500v1", command = "ENTER_PROGMODE")
                }
                getSync()
                continue
            }
            if (b[0] != K.RESP_STK_INSYNC.toByte()) {
                throw ProtocolException(
                    "Expected sync byte entering program mode", protocol = "STK500v1", command = "ENTER_PROGMODE",
                    expected = "0x${K.RESP_STK_INSYNC.toString(16)}", received = "0x${(b[0].toInt() and 0xFF).toString(16)}"
                )
            }
            val status = recv(1)
            when (status[0]) {
                K.RESP_STK_OK.toByte() -> return
                K.RESP_STK_NODEVICE.toByte() -> throw ProtocolException("No device found", protocol = "STK500v1", command = "ENTER_PROGMODE")
                K.RESP_STK_FAILED.toByte() -> throw ProtocolException("Target did not accept programming mode", protocol = "STK500v1", command = "ENTER_PROGMODE")
                else -> throw ProtocolException(
                    "Unknown response entering program mode", protocol = "STK500v1", command = "ENTER_PROGMODE",
                    received = "0x${(status[0].toInt() and 0xFF).toString(16)}"
                )
            }
        }
    }

    /** Direct port of stk500_cmd(): wraps a raw 4-byte ISP instruction in the Cmnd_STK_UNIVERSAL frame. */
    private fun universalCmd(cmd4: ByteArray): ByteArray {
        val out = byteArrayOf(K.CMND_STK_UNIVERSAL.toByte(), cmd4[0], cmd4[1], cmd4[2], cmd4[3], K.SYNC_CRC_EOP.toByte())
        send(out)
        expectInSync("UNIVERSAL " + cmd4.joinToString(" ") { "%02X".format(it) })
        val respByte = recv(1)
        expectOk("UNIVERSAL " + cmd4.joinToString(" ") { "%02X".format(it) })
        return byteArrayOf(cmd4[0], cmd4[1], cmd4[2], respByte[0])
    }

    /** Direct port of stk500_loadaddr() for the non-bootloader (real ISP programmer) path. */
    private fun loadAddress(wordOrByteAddr: Int, needsExt: Boolean) {
        if (needsExt) {
            val extByte = (wordOrByteAddr ushr 16) and 0xFF
            if (extByte != extAddrByte) {
                universalCmd(K.LOAD_EXT_ADDR_CMD_PREFIX + byteArrayOf(extByte.toByte(), 0x00))
                extAddrByte = extByte
            }
        }
        val cmd = byteArrayOf(
            K.CMND_STK_LOAD_ADDRESS.toByte(),
            (wordOrByteAddr and 0xFF).toByte(),
            ((wordOrByteAddr shr 8) and 0xFF).toByte(),
            K.SYNC_CRC_EOP.toByte()
        )
        var tries = 0
        while (true) {
            tries++
            send(cmd)
            val b = recv(1)
            if (b[0] == K.RESP_STK_NOSYNC.toByte()) {
                if (tries > 33) throw ProtocolException("Cannot get into sync loading address", protocol = "STK500v1", command = "LOAD_ADDRESS")
                getSync()
                continue
            }
            if (b[0] != K.RESP_STK_INSYNC.toByte()) {
                throw ProtocolException(
                    "Expected sync byte loading address", protocol = "STK500v1", command = "LOAD_ADDRESS",
                    expected = "0x${K.RESP_STK_INSYNC.toString(16)}", received = "0x${(b[0].toInt() and 0xFF).toString(16)}"
                )
            }
            expectOk("LOAD_ADDRESS")
            return
        }
    }

    private fun expectInSync(what: String) {
        val b = recv(1)
        if (b[0] != K.RESP_STK_INSYNC.toByte()) {
            throw ProtocolException(
                "STK500v1 out of sync", protocol = "STK500v1", command = what,
                expected = "INSYNC (0x${K.RESP_STK_INSYNC.toString(16)})", received = "0x${(b[0].toInt() and 0xFF).toString(16)}"
            )
        }
    }

    private fun expectOk(what: String) {
        val b = recv(1)
        if (b[0] != K.RESP_STK_OK.toByte()) {
            throw ProtocolException(
                "STK500v1 protocol expected OK byte", protocol = "STK500v1", command = what,
                expected = "OK (0x${K.RESP_STK_OK.toString(16)})", received = "0x${(b[0].toInt() and 0xFF).toString(16)}"
            )
        }
    }

    private fun send(bytes: ByteArray) = transport.write(bytes, 2000)

    private fun recv(length: Int): ByteArray {
        val buf = ByteArray(length)
        transport.readExactly(buf, length, 2000)
        return buf
    }
}
