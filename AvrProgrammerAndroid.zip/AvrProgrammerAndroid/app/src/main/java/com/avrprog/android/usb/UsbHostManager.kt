package com.avrprog.android.usb

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbManager
import android.os.Build
import com.avrprog.android.error.UsbTransportException
import com.avrprog.android.log.Logger

const val ACTION_USB_PERMISSION = "com.avrprog.android.USB_PERMISSION"

data class UsbDeviceInfo(
    val device: UsbDevice,
    val vendorId: Int,
    val productId: Int,
    val manufacturer: String?,
    val product: String?,
    val serial: String?,
    val interfaceCount: Int,
    val endpointSummaries: List<String>
)

/**
 * Wraps android.hardware.usb.UsbManager: device enumeration, permission
 * handling and connection open/close (brief section 3). Individual programmer
 * protocol classes never touch UsbManager directly -- they receive an
 * [AndroidUsbTransport] built from an already-permitted, already-open
 * UsbDeviceConnection.
 */
class UsbHostManager(private val context: Context) {

    private val usbManager = context.getSystemService(Context.USB_SERVICE) as UsbManager
    private var permissionReceiver: BroadcastReceiver? = null

    /** Hardware-test mode data per brief section 22: every attached USB device with full interface/endpoint detail. */
    fun listDevices(): List<UsbDeviceInfo> = usbManager.deviceList.values.map { it.toInfo() }

    fun hasPermission(device: UsbDevice): Boolean = usbManager.hasPermission(device)

    fun requestPermission(device: UsbDevice, onResult: (granted: Boolean) -> Unit) {
        if (usbManager.hasPermission(device)) {
            onResult(true)
            return
        }
        unregisterPermissionReceiver()
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0
        val pendingIntent = PendingIntent.getBroadcast(context, 0, Intent(ACTION_USB_PERMISSION), flags)
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context, intent: Intent) {
                if (intent.action != ACTION_USB_PERMISSION) return
                val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
                Logger.info("USB", "Permission ${if (granted) "granted" else "denied"} for ${device.deviceName}")
                unregisterPermissionReceiver()
                onResult(granted)
            }
        }
        permissionReceiver = receiver
        val filter = IntentFilter(ACTION_USB_PERMISSION)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            context.registerReceiver(receiver, filter)
        }
        usbManager.requestPermission(device, pendingIntent)
    }

    fun unregisterPermissionReceiver() {
        permissionReceiver?.let {
            try { context.unregisterReceiver(it) } catch (_: IllegalArgumentException) { /* already unregistered */ }
        }
        permissionReceiver = null
    }

    fun open(device: UsbDevice): UsbDeviceConnection {
        if (!usbManager.hasPermission(device)) {
            throw UsbTransportException("No USB permission for device ${device.deviceName}")
        }
        val connection = usbManager.openDevice(device)
            ?: throw UsbTransportException("UsbManager.openDevice() returned null for ${device.deviceName}")
        Logger.info("USB", "Opened ${device.deviceName} (${device.vendorId.toUsbHex()}:${device.productId.toUsbHex()})")
        return connection
    }

    private fun UsbDevice.toInfo(): UsbDeviceInfo {
        val endpoints = mutableListOf<String>()
        for (i in 0 until interfaceCount) {
            val iface = getInterface(i)
            for (e in 0 until iface.endpointCount) {
                val ep = iface.getEndpoint(e)
                val dir = if (ep.direction == android.hardware.usb.UsbConstants.USB_DIR_IN) "IN" else "OUT"
                val type = when (ep.type) {
                    android.hardware.usb.UsbConstants.USB_ENDPOINT_XFER_BULK -> "BULK"
                    android.hardware.usb.UsbConstants.USB_ENDPOINT_XFER_INT -> "INTERRUPT"
                    android.hardware.usb.UsbConstants.USB_ENDPOINT_XFER_ISOC -> "ISOCHRONOUS"
                    android.hardware.usb.UsbConstants.USB_ENDPOINT_XFER_CONTROL -> "CONTROL"
                    else -> "UNKNOWN"
                }
                endpoints += "if${i}.ep${ep.address.toUsbHex()} $type $dir maxPacket=${ep.maxPacketSize}"
            }
        }
        return UsbDeviceInfo(
            device = this,
            vendorId = vendorId,
            productId = productId,
            manufacturer = manufacturerName,
            product = productName,
            serial = try { serialNumber } catch (_: SecurityException) { null },
            interfaceCount = interfaceCount,
            endpointSummaries = endpoints
        )
    }
}

fun Int.toUsbHex(): String = "0x" + this.toString(16).uppercase().padStart(4, '0')
