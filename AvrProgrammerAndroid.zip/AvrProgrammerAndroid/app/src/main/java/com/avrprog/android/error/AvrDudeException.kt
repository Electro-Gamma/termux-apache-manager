package com.avrprog.android.error

/**
 * Exception hierarchy per project brief section 20: every thrown error carries
 * enough structured context (programmer/protocol/command/expected/received/
 * usbError) to render a meaningful diagnostic, not just a message string.
 */
sealed class AvrDudeException(
    message: String,
    val programmer: String? = null,
    val protocol: String? = null,
    val command: String? = null,
    val expected: String? = null,
    val received: String? = null,
    val usbError: String? = null,
    cause: Throwable? = null
) : Exception(message, cause) {

    fun detailedMessage(): String = buildString {
        append(message)
        programmer?.let { append("\n  programmer: $it") }
        protocol?.let { append("\n  protocol: $it") }
        command?.let { append("\n  command: $it") }
        expected?.let { append("\n  expected: $it") }
        received?.let { append("\n  received: $it") }
        usbError?.let { append("\n  usbError: $it") }
    }
}

class UsbTransportException(message: String, usbError: String? = null, cause: Throwable? = null) :
    AvrDudeException(message, usbError = usbError, cause = cause)

class ProgrammerException(
    message: String,
    programmer: String? = null,
    command: String? = null,
    cause: Throwable? = null
) : AvrDudeException(message, programmer = programmer, command = command, cause = cause)

class ProtocolException(
    message: String,
    protocol: String? = null,
    command: String? = null,
    expected: String? = null,
    received: String? = null
) : AvrDudeException(message, protocol = protocol, command = command, expected = expected, received = received)

class DeviceDetectionException(message: String, expected: String? = null, received: String? = null) :
    AvrDudeException(message, expected = expected, received = received)

/** Formatted exactly per brief section 15's required verification-failure report. */
class VerificationException(val memory: String, val address: Int, val expectedByte: Int, val actualByte: Int) :
    AvrDudeException(
        "Verification failed\n" +
            "Memory: $memory\n" +
            "Address: 0x${address.toString(16).uppercase()}\n" +
            "Expected: 0x${expectedByte.toString(16).uppercase().padStart(2, '0')}\n" +
            "Read:     0x${actualByte.toString(16).uppercase().padStart(2, '0')}"
    )

class MemoryOperationException(message: String, cause: Throwable? = null) : AvrDudeException(message, cause = cause)
