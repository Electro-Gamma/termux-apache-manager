package com.avrprog.android.protocol.usbasp

/**
 * Ported verbatim from AVRDUDE src/usbasp.h and src/usbdevs.h (USBasp by
 * Thomas Fischl, http://www.fischl.de/usbasp/; AVRDUDE is GPLv2 -- see
 * AVRDUDE_PORTING.md and THIRD_PARTY_LICENSES.md).
 */
object UsbaspConstants {
    // VID/PID. SHARED is the current, default USBasp identity -- "VOTI" is
    // the vendor ID owner (Objective Development) and 0x05DC is, per AVRDUDE's
    // own comment, "Obdev's free shared PID". Virtually every USBasp and
    // USBasp-clone board in circulation today enumerates as SHARED_VID:SHARED_PID;
    // it is the primary/default match. OLD_* is the legacy pre-2006
    // Atmel-assigned pair some very old fischl.de firmware still reports.
    // NIBOBEE_* is a specific board (nicai-systems NIBObee) that reuses the
    // USBasp protocol under its own PID.
    const val USBASP_SHARED_VID = 0x16C0
    const val USBASP_SHARED_PID = 0x05DC
    const val USBASP_OLD_VID = 0x03EB
    const val USBASP_OLD_PID = 0xC7B4
    const val USBASP_NIBOBEE_VID = 0x16C0
    const val USBASP_NIBOBEE_PID = 0x092F

    /** SHARED is listed first deliberately -- it's tried/matched first. */
    val KNOWN_VID_PID: List<Pair<Int, Int>> = listOf(
        USBASP_SHARED_VID to USBASP_SHARED_PID,
        USBASP_OLD_VID to USBASP_OLD_PID,
        USBASP_NIBOBEE_VID to USBASP_NIBOBEE_PID
    )

    // USB function call identifiers (bRequest values), from usbasp.h.
    const val FUNC_CONNECT = 1
    const val FUNC_DISCONNECT = 2
    const val FUNC_TRANSMIT = 3
    const val FUNC_READFLASH = 4
    const val FUNC_ENABLEPROG = 5
    const val FUNC_WRITEFLASH = 6
    const val FUNC_READEEPROM = 7
    const val FUNC_WRITEEEPROM = 8
    const val FUNC_SETLONGADDRESS = 9
    const val FUNC_SETISPSCK = 10
    const val FUNC_TPI_CONNECT = 11
    const val FUNC_TPI_DISCONNECT = 12
    const val FUNC_TPI_RAWREAD = 13
    const val FUNC_TPI_RAWWRITE = 14
    const val FUNC_TPI_READBLOCK = 15
    const val FUNC_TPI_WRITEBLOCK = 16
    const val FUNC_GETCAPABILITIES = 127

    const val CAP_TPI = 0x01

    const val BLOCKFLAG_FIRST = 1
    const val BLOCKFLAG_LAST = 2

    const val READBLOCKSIZE = 200
    const val WRITEBLOCKSIZE = 200

    // ISP SCK speed identifiers and their frequency, from usbaspSCKoptions[] in usbasp.c.
    const val ISP_SCK_AUTO = 0
    const val ISP_SCK_0_5 = 1     // 500 Hz
    const val ISP_SCK_1 = 2       // 1 kHz
    const val ISP_SCK_2 = 3       // 2 kHz
    const val ISP_SCK_4 = 4       // 4 kHz
    const val ISP_SCK_8 = 5       // 8 kHz
    const val ISP_SCK_16 = 6      // 16 kHz
    const val ISP_SCK_32 = 7      // 32 kHz
    const val ISP_SCK_93_75 = 8   // 93.75 kHz
    const val ISP_SCK_187_5 = 9   // 187.5 kHz
    const val ISP_SCK_375 = 10    // 375 kHz
    const val ISP_SCK_750 = 11    // 750 kHz
    const val ISP_SCK_1500 = 12   // 1.5 MHz -- AVRDUDE's default on connect
    const val ISP_SCK_3000 = 13   // 3 MHz, UsbAsp-flash firmware only
}
