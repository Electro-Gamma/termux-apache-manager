package com.avrprog.android.log

/** Log levels per project brief section 19 (ERROR..TRACE), ordered most to least severe. */
enum class LogLevel(val priority: Int) { ERROR(0), WARNING(1), INFO(2), DEBUG(3), TRACE(4) }

data class LogEntry(
    val level: LogLevel,
    val tag: String,
    val message: String,
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * Process-wide log sink. The UI (MainActivity) subscribes via [addListener] to
 * mirror entries into the on-screen log view; raw USB traffic goes through
 * [rawUsb] at TRACE level so it can be toggled on/off without code changes
 * (brief section 19: "Allow raw USB/protocol logging").
 */
object Logger {
    private val entries = mutableListOf<LogEntry>()
    var minLevel: LogLevel = LogLevel.INFO
    private val listeners = mutableListOf<(LogEntry) -> Unit>()

    @Synchronized
    fun addListener(listener: (LogEntry) -> Unit) { listeners.add(listener) }

    @Synchronized
    fun removeListener(listener: (LogEntry) -> Unit) { listeners.remove(listener) }

    @Synchronized
    fun log(level: LogLevel, tag: String, message: String) {
        val entry = LogEntry(level, tag, message)
        entries.add(entry)
        if (level.priority <= minLevel.priority) {
            listeners.toList().forEach { it(entry) }
        }
    }

    fun error(tag: String, msg: String) = log(LogLevel.ERROR, tag, msg)
    fun warning(tag: String, msg: String) = log(LogLevel.WARNING, tag, msg)
    fun info(tag: String, msg: String) = log(LogLevel.INFO, tag, msg)
    fun debug(tag: String, msg: String) = log(LogLevel.DEBUG, tag, msg)
    fun trace(tag: String, msg: String) = log(LogLevel.TRACE, tag, msg)

    /** Formats a raw USB transfer as "DIRECTION:\nAA BB CC ..." at TRACE level. */
    fun rawUsb(direction: String, bytes: ByteArray) {
        log(LogLevel.TRACE, "USB", "$direction:\n" + bytes.joinToString(" ") { "%02X".format(it) })
    }

    @Synchronized
    fun exportText(): String = entries.joinToString("\n") { "[${it.level}] ${it.tag}: ${it.message}" }

    @Synchronized
    fun all(): List<LogEntry> = entries.toList()

    @Synchronized
    fun clear() = entries.clear()
}
