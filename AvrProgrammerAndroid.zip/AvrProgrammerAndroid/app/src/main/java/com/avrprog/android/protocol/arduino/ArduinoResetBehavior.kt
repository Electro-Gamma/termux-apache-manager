package com.avrprog.android.protocol.arduino

import com.avrprog.android.log.Logger
import com.avrprog.android.usb.SerialTransport

/**
 * Auto-reset sequences used to drop an Arduino-style board into its
 * bootloader before talking protocol to it. Ported from the reset-behavior
 * classes of the reference Kotlin/Java "arduino-hex-upload" library (itself
 * a port of the well-known C# ArduinoUploader project), which in turn mirror
 * what the Arduino IDE / avrdude's "arduino" programmer type does.
 *
 * [Manual1200BpsTouch] is intentionally NOT auto-performed: on desktop OSes
 * this behavior closes the port, briefly reopens it at 1200 baud, closes it
 * again, and waits for a *new* virtual COM port to enumerate (the 32U4
 * disconnecting and re-enumerating as its bootloader). Android's USB Host
 * model doesn't expose that COM-port-appears/disappears signal the same way,
 * and doing it wrong risks leaving the connection in a confusing half-reset
 * state. Boards that need it are marked so the UI can show a clear
 * instruction (manually double-tap the board's reset button) instead.
 */
sealed class ArduinoResetBehavior {
    object None : ArduinoResetBehavior()

    /** Ported from ResetThroughTogglingDtrBehavior: sets DTR to a fixed level and leaves it. */
    data class DtrToggle(val enabled: Boolean) : ArduinoResetBehavior()

    /** Ported from ResetThroughTogglingDtrRtsBehavior: pulse DTR+RTS low (or high, if [invert]) then back, with two wait times. */
    data class DtrRtsPulse(val wait1Ms: Long, val wait2Ms: Long, val invert: Boolean = false) : ArduinoResetBehavior()

    /** Boards whose bootloader entry needs a manual double-tap of the reset button (see class doc). */
    object Manual1200BpsTouch : ArduinoResetBehavior()

    fun apply(transport: SerialTransport) {
        when (this) {
            is None -> { /* nothing to do */ }
            is DtrToggle -> {
                Logger.debug("Arduino", "Reset: DTR=$enabled")
                transport.setDtr(enabled)
            }
            is DtrRtsPulse -> {
                Logger.debug("Arduino", "Reset: DTR/RTS pulse (invert=$invert, ${wait1Ms}ms/${wait2Ms}ms)")
                transport.setDtr(invert)
                transport.setRts(invert)
                Thread.sleep(wait1Ms)
                transport.setDtr(!invert)
                transport.setRts(!invert)
                Thread.sleep(wait2Ms)
            }
            is Manual1200BpsTouch -> {
                Logger.warning("Arduino", "This board needs a manual double-tap of its reset button before connecting -- automatic 1200bps touch-reset isn't implemented on Android (see ArduinoBoards.kt)")
            }
        }
    }
}
