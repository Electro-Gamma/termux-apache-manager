package com.avrprog.android.usb

import android.hardware.usb.UsbDeviceConnection
import com.avrprog.android.error.UsbTransportException
import com.avrprog.android.log.Logger
import com.hoho.android.usbserial.driver.UsbSerialPort

/**
 * Real [SerialTransport] backed by usb-serial-for-android's [UsbSerialPort]
 * (already resolved to a driver -- CH340/CH341, CP210x, FTDI, PL2303, or
 * CDC-ACM -- by [SerialDeviceScanner] before this is constructed).
 */
class UsbSerialTransport(
    private val port: UsbSerialPort,
    private val connection: UsbDeviceConnection
) : SerialTransport {

    override fun open(baudRate: Int) {
        port.open(connection)
        try {
            port.setParameters(baudRate, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)
        } catch (e: Exception) {
            port.close()
            throw UsbTransportException("Failed to configure serial port at $baudRate 8N1", cause = e)
        }
    }

    override fun setDtr(enabled: Boolean) {
        try {
            port.setDTR(enabled)
        } catch (e: Exception) {
            throw UsbTransportException("Failed to set DTR", cause = e)
        }
    }

    override fun setRts(enabled: Boolean) {
        try {
            port.setRTS(enabled)
        } catch (e: Exception) {
            throw UsbTransportException("Failed to set RTS", cause = e)
        }
    }

    override fun write(bytes: ByteArray, timeoutMs: Int) {
        Logger.rawUsb("serial OUT", bytes)
        try {
            port.write(bytes, timeoutMs)
        } catch (e: Exception) {
            throw UsbTransportException("Serial write failed", cause = e)
        }
    }

    override fun readExactly(buffer: ByteArray, length: Int, timeoutMs: Int) {
        var received = 0
        val deadline = System.currentTimeMillis() + timeoutMs
        while (received < length) {
            val remaining = deadline - System.currentTimeMillis()
            if (remaining <= 0) {
                throw UsbTransportException("Serial read timed out ($received/$length bytes received)")
            }
            val chunk = ByteArray(length - received)
            val n = try {
                port.read(chunk, remaining.toInt().coerceAtLeast(1))
            } catch (e: Exception) {
                throw UsbTransportException("Serial read failed", cause = e)
            }
            if (n > 0) {
                System.arraycopy(chunk, 0, buffer, received, n)
                received += n
            }
        }
        Logger.rawUsb("serial IN", buffer.copyOf(length))
    }

    override fun close() {
        try {
            port.close()
        } catch (_: Exception) {
            // already closed / device detached -- nothing further to do
        }
    }
}
