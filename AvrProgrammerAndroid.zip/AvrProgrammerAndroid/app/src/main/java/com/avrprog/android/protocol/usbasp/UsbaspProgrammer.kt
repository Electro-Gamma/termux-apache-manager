package com.avrprog.android.protocol.usbasp

import com.avrprog.android.device.AvrDevice
import com.avrprog.android.error.ProtocolException
import com.avrprog.android.log.Logger
import com.avrprog.android.memory.MemoryImage
import com.avrprog.android.protocol.Programmer
import com.avrprog.android.protocol.ProgrammerInfo
import com.avrprog.android.usb.UsbTransport

/**
 * Real USBasp protocol implementation, ported from AVRDUDE src/usbasp.c
 * (Thomas Fischl / Joerg Wunsch, GPLv2) -- see AVRDUDE_PORTING.md for the
 * function-by-function source mapping.
 *
 * Implements the classic-AVR ISP command path: connect, program-enable, chip
 * erase, paged flash/EEPROM read+write, signature read, SCK configuration.
 * USBasp's TPI functions (ATtiny4/5/9/10-class parts, FUNC_TPI_*) are defined
 * in [UsbaspConstants] but not wired up here yet -- see PROTOCOLS.md, which is
 * required to state that explicitly rather than silently pretend TPI works.
 */
class UsbaspProgrammer(private val transport: UsbTransport) : Programmer {

    override val info = ProgrammerInfo(
        id = "usbasp",
        name = "USBasp",
        vendorIds = UsbaspConstants.KNOWN_VID_PID.map { it.first },
        productIds = UsbaspConstants.KNOWN_VID_PID.map { it.second },
        protocol = "USBasp vendor-specific control transfers wrapping AVR ISP",
        transport = "USB (EP0 control transfers only; no bulk endpoint required)",
        implemented = true
    )

    override fun open() {
        getCapabilities()
        setSckOption(UsbaspConstants.ISP_SCK_1500)
        connect()
        Thread.sleep(100) // usbasp_initialize(): "wait, so device is ready to receive commands"
        if (!programEnable()) {
            throw ProtocolException(
                "Program enable failed -- target not responding to AVR ISP program-enable sequence",
                protocol = "USBasp/ISP", command = "USBASP_FUNC_ENABLEPROG"
            )
        }
    }

    override fun close() {
        // AVRDUDE's usbasp_disable() is a no-op; there is no USBasp "disconnect"
        // needed for correctness. The transport owns USB interface/connection teardown.
        transport.close()
    }

    override fun readSignature(): ByteArray {
        // Standard AVR ISP "Read Signature Byte" instruction: 0x30 0x00 <addr> 0x00,
        // response's 4th byte holds the signature byte. Documented in every
        // classic-AVR datasheet's Serial Programming Instruction Set table.
        val sig = ByteArray(3)
        for (i in 0..2) {
            val res = spiCmd(byteArrayOf(0x30, 0x00, i.toByte(), 0x00))
            sig[i] = res[3]
        }
        return sig
    }

    override fun chipErase() {
        // Standard AVR ISP chip-erase instruction (0xAC 0x80 0x00 0x00).
        spiCmd(byteArrayOf(0xAC.toByte(), 0x80.toByte(), 0x00, 0x00))
        Thread.sleep(30)
        connect()
        Thread.sleep(100)
        if (!programEnable()) {
            throw ProtocolException("Re-enabling programming mode after chip erase failed", protocol = "USBasp/ISP")
        }
    }

    override fun readMemory(memoryName: String, device: AvrDevice, onProgress: (Int, Int) -> Unit): MemoryImage {
        val memory = device.memories.firstOrNull { it.name == memoryName }
            ?: throw ProtocolException("Device ${device.description} has no memory named '$memoryName'")
        val function = when (memoryName) {
            "flash" -> UsbaspConstants.FUNC_READFLASH
            "eeprom" -> UsbaspConstants.FUNC_READEEPROM
            else -> throw ProtocolException("USBasp only supports paged reads of flash/eeprom, not '$memoryName'")
        }
        val image = MemoryImage(memory.sizeBytes)
        var address = 0
        val blockSize = UsbaspConstants.READBLOCKSIZE
        Logger.info("USBasp", "Reading $memoryName (${memory.sizeBytes} bytes) from ${device.description}")
        while (address < memory.sizeBytes) {
            val thisBlock = minOf(blockSize, memory.sizeBytes - address)
            setLongAddress(address)
            // Compatibility-mode address bytes for firmware predating FUNC_SETLONGADDRESS.
            val cmd = byteArrayOf((address and 0xFF).toByte(), ((address shr 8) and 0xFF).toByte(), 0, 0)
            val buffer = ByteArray(thisBlock)
            val n = transmit(function, cmd, receive = true, buffer = buffer, length = thisBlock)
            if (n != thisBlock) {
                throw ProtocolException(
                    "Unexpected read length from USBasp", protocol = "USBasp",
                    command = "0x${function.toString(16)} @0x${address.toString(16)}",
                    expected = "$thisBlock bytes", received = "$n bytes"
                )
            }
            for (i in 0 until thisBlock) image.set(address + i, buffer[i])
            address += thisBlock
            onProgress(address, memory.sizeBytes)
        }
        return image
    }

    override fun writeMemory(memoryName: String, device: AvrDevice, image: MemoryImage, onProgress: (Int, Int) -> Unit) {
        val memory = device.memories.firstOrNull { it.name == memoryName }
            ?: throw ProtocolException("Device ${device.description} has no memory named '$memoryName'")
        val function = when (memoryName) {
            "flash" -> UsbaspConstants.FUNC_WRITEFLASH
            "eeprom" -> UsbaspConstants.FUNC_WRITEEEPROM
            else -> throw ProtocolException("USBasp only supports paged writes of flash/eeprom, not '$memoryName'")
        }
        val range = image.writtenRange() ?: run {
            Logger.warning("USBasp", "writeMemory($memoryName) called with an empty image; nothing to do")
            return
        }
        val end = range.last + 1
        var address = 0
        val blockSize = UsbaspConstants.WRITEBLOCKSIZE
        var blockFlags = UsbaspConstants.BLOCKFLAG_FIRST
        Logger.info("USBasp", "Writing $memoryName (up to byte 0x${end.toString(16)}) to ${device.description}")
        while (address < end) {
            val thisBlock = minOf(blockSize, end - address)
            setLongAddress(address)
            val pageSize = memory.pageSize
            val cmd = byteArrayOf(
                (address and 0xFF).toByte(),
                ((address shr 8) and 0xFF).toByte(),
                (pageSize and 0xFF).toByte(),
                (((blockFlags and 0x0F) + ((pageSize and 0xF00) shr 4))).toByte()
            )
            blockFlags = 0 // only the first USB transfer of the whole write carries BLOCKFLAG_FIRST, matching usbasp_spi_paged_write()
            val buffer = ByteArray(thisBlock) { image.data[address + it] }
            val n = transmit(function, cmd, receive = false, buffer = buffer, length = thisBlock)
            if (n != thisBlock) {
                throw ProtocolException(
                    "Unexpected write length to USBasp", protocol = "USBasp",
                    command = "0x${function.toString(16)} @0x${address.toString(16)}",
                    expected = "$thisBlock bytes", received = "$n bytes"
                )
            }
            address += thisBlock
            onProgress(address, end)
        }
    }

    override fun setSckOption(id: Int) {
        val res = ByteArray(4)
        transmit(UsbaspConstants.FUNC_SETISPSCK, byteArrayOf(id.toByte(), 0, 0, 0), receive = true, buffer = res, length = res.size)
    }

    // --- Low-level USBasp control-transfer plumbing -------------------------------------

    private fun connect() {
        val res = ByteArray(4)
        transmit(UsbaspConstants.FUNC_CONNECT, ByteArray(4), receive = true, buffer = res, length = res.size)
    }

    private fun programEnable(): Boolean {
        val res = ByteArray(4)
        val n = transmit(UsbaspConstants.FUNC_ENABLEPROG, ByteArray(4), receive = true, buffer = res, length = res.size)
        // Matches usbasp_spi_program_enable(): firmware replies with exactly 1 byte, 0x00 on success.
        return n == 1 && res[0] == 0.toByte()
    }

    private fun getCapabilities(): Int {
        val res = ByteArray(4)
        val n = transmit(UsbaspConstants.FUNC_GETCAPABILITIES, ByteArray(4), receive = true, buffer = res, length = res.size)
        return if (n == 4) {
            (res[0].toInt() and 0xFF) or ((res[1].toInt() and 0xFF) shl 8) or
                ((res[2].toInt() and 0xFF) shl 16) or ((res[3].toInt() and 0xFF) shl 24)
        } else 0
    }

    private fun setLongAddress(address: Int) {
        val cmd = byteArrayOf(
            (address and 0xFF).toByte(),
            ((address shr 8) and 0xFF).toByte(),
            ((address shr 16) and 0xFF).toByte(),
            ((address shr 24) and 0xFF).toByte()
        )
        val res = ByteArray(4)
        transmit(UsbaspConstants.FUNC_SETLONGADDRESS, cmd, receive = true, buffer = res, length = res.size)
    }

    private fun spiCmd(cmd4: ByteArray): ByteArray {
        val res = ByteArray(4)
        val n = transmit(UsbaspConstants.FUNC_TRANSMIT, cmd4, receive = true, buffer = res, length = 4)
        if (n != 4) {
            throw ProtocolException(
                "USBasp ISP passthrough command returned the wrong response size",
                protocol = "USBasp/ISP", command = cmd4.joinToString(" ") { "%02X".format(it) },
                expected = "4 bytes", received = "$n bytes"
            )
        }
        return res
    }

    /**
     * Direct port of AVRDUDE's usbasp_transmit(): a 4-byte "send" array is
     * split into wValue = send[1]<<8|send[0] and wIndex = send[3]<<8|send[2];
     * functionId becomes bRequest; [receive] selects the USB_DIR_IN bit.
     */
    private fun transmit(functionId: Int, send: ByteArray, receive: Boolean, buffer: ByteArray?, length: Int): Int {
        val requestType = if (receive) 0xC0 else 0x40 // (VENDOR|RECIPIENT_DEVICE) | (IN if receive else OUT)
        val s0 = send.getOrElse(0) { 0 }.toInt() and 0xFF
        val s1 = send.getOrElse(1) { 0 }.toInt() and 0xFF
        val s2 = send.getOrElse(2) { 0 }.toInt() and 0xFF
        val s3 = send.getOrElse(3) { 0 }.toInt() and 0xFF
        val wValue = (s1 shl 8) or s0
        val wIndex = (s3 shl 8) or s2
        return transport.controlTransfer(requestType, functionId, wValue, wIndex, buffer, length, timeoutMs = 5000)
    }
}
