package com.avrprog.android.device

enum class ProgrammingInterface { ISP, UPDI, TPI, PDI, JTAG, HVSP, HVPP, DEBUGWIRE }

data class AvrMemory(
    val name: String,
    val sizeBytes: Int,
    val pageSize: Int
)

/**
 * One entry from AVRDUDE's device database (src/avrdude.conf.in `part` blocks).
 * Signature bytes and flash/EEPROM size/page-size are copied from the actual
 * config -- see DEVICE_DATABASE.md for the source line each entry was taken from.
 */
data class AvrDevice(
    val id: String,
    val description: String,
    val signature: IntArray,
    val flashSize: Int,
    val flashPageSize: Int,
    val eepromSize: Int,
    val eepromPageSize: Int,
    val supportedInterfaces: Set<ProgrammingInterface>,
    /** Conservative default; per-part avrdude.conf `chip_erase_delay` (microseconds) is not yet fully ported -- see PROTOCOLS.md. */
    val chipEraseDelayMs: Int = 30
) {
    val memories: List<AvrMemory>
        get() = listOf(
            AvrMemory("flash", flashSize, flashPageSize),
            AvrMemory("eeprom", eepromSize, eepromPageSize)
        )

    fun signatureMatches(bytes: ByteArray): Boolean =
        bytes.size >= 3 &&
            signature[0] == (bytes[0].toInt() and 0xFF) &&
            signature[1] == (bytes[1].toInt() and 0xFF) &&
            signature[2] == (bytes[2].toInt() and 0xFF)

    fun signatureHex(): String = signature.joinToString(" ") { "%02X".format(it) }

    override fun equals(other: Any?): Boolean = other is AvrDevice && other.id == id
    override fun hashCode(): Int = id.hashCode()
}
