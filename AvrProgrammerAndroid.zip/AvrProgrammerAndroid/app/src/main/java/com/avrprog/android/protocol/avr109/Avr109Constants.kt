package com.avrprog.android.protocol.avr109

/**
 * Ported from the AVR109/Butterfly bootloader protocol constants in the
 * reference "arduino-hex-upload" library (`Protocols/AVR109/Constants.java`,
 * itself a faithful implementation of Atmel Application Note AVR109). This
 * is the protocol used by the Caterina bootloader on ATmega32U4-based boards
 * (Leonardo, Micro, Esplora, LilyPad USB) -- a different, ASCII-command-based
 * protocol from STK500v1, not a variant of it. See AVRDUDE_PORTING.md.
 */
object Avr109Constants {
    const val CARRIAGE_RETURN: Byte = 0x0d
    const val NUL: Byte = 0x00

    const val CMD_SET_ADDRESS = 0x41       // 'A'
    const val CMD_START_BLOCK_LOAD = 0x42  // 'B'
    const val CMD_EXIT_BOOTLOADER = 0x45   // 'E'
    const val CMD_LEAVE_PROGRAMMING_MODE = 0x4c // 'L'
    const val CMD_ENTER_PROGRAMMING_MODE = 0x50 // 'P'
    const val CMD_RETURN_SOFTWARE_IDENTIFIER = 0x53 // 'S'
    const val CMD_SELECT_DEVICE_TYPE = 0x54 // 'T'
    const val CMD_RETURN_SOFTWARE_VERSION = 0x56 // 'V'
    const val CMD_CHECK_BLOCK_SUPPORT = 0x62 // 'b'
    const val CMD_START_BLOCK_READ = 0x67   // 'g'
    const val CMD_RETURN_PROGRAMMER_TYPE = 0x70 // 'p'
    const val CMD_READ_SIGNATURE_BYTES = 0x73   // 's'
    const val CMD_RETURN_SUPPORTED_DEVICE_CODES = 0x74 // 't'

    const val MEMCHAR_FLASH: Byte = 'F'.code.toByte()
    const val MEMCHAR_EEPROM: Byte = 'E'.code.toByte()

    /** avrdude / the reference library default for AVR109-protocol boards. */
    const val DEFAULT_BAUD_RATE = 57600
}
