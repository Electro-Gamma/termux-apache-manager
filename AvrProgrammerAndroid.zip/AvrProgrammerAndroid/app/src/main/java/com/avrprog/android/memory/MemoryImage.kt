package com.avrprog.android.memory

/**
 * An in-memory byte image of one AVR memory space (flash, EEPROM, ...), with
 * per-byte "was this address actually written" tracking so sparse Intel HEX
 * files round-trip correctly and partial images can be verified byte-by-byte.
 */
class MemoryImage(val size: Int, fill: Int = 0xFF) {
    val data = ByteArray(size) { fill.toByte() }
    val written = BooleanArray(size)

    fun set(address: Int, value: Byte) {
        require(address in 0 until size) {
            "Address 0x${address.toString(16)} is out of range for a memory of size 0x${size.toString(16)}"
        }
        data[address] = value
        written[address] = true
    }

    fun get(address: Int): Byte = data[address]

    /** Inclusive range spanning the lowest to highest written address, or null if nothing was written. */
    fun writtenRange(): IntRange? {
        val first = written.indexOfFirst { it }
        if (first < 0) return null
        val last = written.indexOfLast { it }
        return first..last
    }
}
