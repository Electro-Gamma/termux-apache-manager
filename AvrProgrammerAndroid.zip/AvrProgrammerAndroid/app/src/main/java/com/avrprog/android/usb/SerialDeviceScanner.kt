package com.avrprog.android.usb

import android.content.Context
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import com.hoho.android.usbserial.driver.UsbSerialDriver
import com.hoho.android.usbserial.driver.UsbSerialProber

/**
 * Wraps usb-serial-for-android's built-in device probing (CH340/CH341,
 * CP210x, FTDI, PL2303, CDC-ACM). Unlike USBasp, a serial-transport
 * programmer (STK500v1, Arduino as ISP, ...) isn't identified by a fixed
 * VID/PID -- any of those chipsets could be carrying the protocol -- so
 * "is this attached device a USB-UART adapter at all" has to be answered
 * by the serial library's own driver table, not [ProgrammerRegistry]'s
 * VID/PID list.
 */
object SerialDeviceScanner {

    fun findDrivers(context: Context): List<UsbSerialDriver> {
        val manager = context.getSystemService(Context.USB_SERVICE) as UsbManager
        return UsbSerialProber.getDefaultProber().findAllDrivers(manager)
    }

    fun driverFor(context: Context, device: UsbDevice): UsbSerialDriver? =
        findDrivers(context).firstOrNull { it.device.deviceId == device.deviceId }
}
