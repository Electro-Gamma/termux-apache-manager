package com.avrprog.android.engine

import com.avrprog.android.device.AvrDevice
import com.avrprog.android.device.DeviceDatabase
import com.avrprog.android.error.DeviceDetectionException
import com.avrprog.android.error.ProgrammerException
import com.avrprog.android.error.VerificationException
import com.avrprog.android.log.Logger
import com.avrprog.android.memory.IntelHex
import com.avrprog.android.memory.MemoryImage
import com.avrprog.android.protocol.Programmer

enum class MemOp { READ, WRITE, VERIFY }
enum class FileFormat { IHEX, BIN }

/** One `-U memtype:op:file` style operation (brief section 17). */
data class MemoryOperation(
    val memory: String,
    val op: MemOp,
    val fileText: String? = null,
    val format: FileFormat = FileFormat.IHEX
)

/**
 * Internal command-model engine mirroring AVRDUDE's `-c/-p/-P/-U` CLI shape.
 * The Android UI (ui/MainActivity.kt) drives this engine instead of talking
 * to Programmer/UsbTransport directly -- brief section 17: "Do not place
 * programming logic directly inside UI code."
 */
class AvrDudeEngine(private val programmer: Programmer) {

    fun detectDevice(): AvrDevice {
        val sig = programmer.readSignature()
        Logger.info("ENGINE", "Signature: " + sig.joinToString(" ") { "%02X".format(it) })
        return DeviceDatabase.findBySignature(sig)
            ?: throw DeviceDetectionException(
                "Signature not found in the current (partial) device database -- see DEVICE_DATABASE.md",
                received = sig.joinToString(" ") { "%02X".format(it) }
            )
    }

    fun erase(device: AvrDevice) {
        Logger.info("ENGINE", "Erasing ${device.description}")
        programmer.chipErase()
    }

    /** Runs a sequence of -U style operations in order, exactly like avrdude does on its command line. */
    fun run(device: AvrDevice, operations: List<MemoryOperation>, onProgress: (memory: String, done: Int, total: Int) -> Unit = { _, _, _ -> }) {
        for (opSpec in operations) {
            val memory = device.memories.firstOrNull { it.name == opSpec.memory }
                ?: throw ProgrammerException("Device ${device.description} has no memory named '${opSpec.memory}'")
            when (opSpec.op) {
                MemOp.READ -> {
                    Logger.info("ENGINE", "Reading ${opSpec.memory}")
                    programmer.readMemory(opSpec.memory, device) { done, total -> onProgress(opSpec.memory, done, total) }
                }
                MemOp.WRITE -> {
                    Logger.info("ENGINE", "Writing ${opSpec.memory}")
                    val image = parseInput(opSpec, memory.sizeBytes)
                    programmer.writeMemory(opSpec.memory, device, image) { done, total -> onProgress(opSpec.memory, done, total) }
                }
                MemOp.VERIFY -> {
                    Logger.info("ENGINE", "Verifying ${opSpec.memory}")
                    val expected = parseInput(opSpec, memory.sizeBytes)
                    val actual = programmer.readMemory(opSpec.memory, device) { done, total -> onProgress(opSpec.memory, done, total) }
                    verify(opSpec.memory, expected, actual)
                }
            }
        }
    }

    private fun parseInput(opSpec: MemoryOperation, memorySize: Int): MemoryImage {
        val text = opSpec.fileText ?: throw ProgrammerException("${opSpec.op} of '${opSpec.memory}' requires file content")
        return when (opSpec.format) {
            FileFormat.IHEX -> IntelHex.parse(text, memorySize)
            FileFormat.BIN -> IntelHex.fromBinary(text.toByteArray(Charsets.ISO_8859_1), memorySize)
        }
    }

    private fun verify(memoryName: String, expected: MemoryImage, actual: MemoryImage) {
        val range = expected.writtenRange() ?: return
        var checked = 0
        for (addr in range) {
            if (!expected.written[addr]) continue
            val exp = expected.get(addr).toInt() and 0xFF
            val act = actual.get(addr).toInt() and 0xFF
            if (exp != act) throw VerificationException(memoryName, addr, exp, act)
            checked++
        }
        Logger.info("ENGINE", "Verify OK: $memoryName ($checked bytes matched)")
    }
}
