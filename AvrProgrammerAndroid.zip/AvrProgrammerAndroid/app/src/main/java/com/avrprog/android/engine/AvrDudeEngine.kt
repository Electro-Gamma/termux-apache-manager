package com.avrprog.android.engine

import com.avrprog.android.device.AvrDevice
import com.avrprog.android.device.DeviceDatabase
import com.avrprog.android.error.DeviceDetectionException
import com.avrprog.android.error.ProgrammerException
import com.avrprog.android.error.VerificationException
import com.avrprog.android.log.Logger
import com.avrprog.android.memory.IntelHex
import com.avrprog.android.memory.MemoryImage
import com.avrprog.android.protocol.Programmer

enum class MemOp { READ, WRITE, VERIFY }
enum class FileFormat { IHEX, BIN }

/** One `-U memtype:op:file` style operation (project brief section 17). */
data class MemoryOperation(
    val memory: String,
    val op: MemOp,
    val fileText: String? = null,
    val binaryBytes: ByteArray? = null,
    val format: FileFormat = FileFormat.IHEX
)

/**
 * Internal command-model engine mirroring AVRDUDE's `-c/-p/-P/-U` CLI shape.
 * The Android UI (ui/MainActivity.kt) drives this engine instead of talking
 * to [Programmer] or the USB transport directly -- brief section 17: "Do not
 * place programming logic directly inside UI code."
 */
class AvrDudeEngine(private val programmer: Programmer) {

    fun detectDevice(): AvrDevice {
        val sig = programmer.readSignature()
        Logger.info("ENGINE", "Signature: " + sig.joinToString(" ") { "%02X".format(it) })
        return DeviceDatabase.findBySignature(sig)
            ?: throw DeviceDetectionException(
                "Unrecognized device signature -- not present in this project's (partial) device database. " +
                    "See DEVICE_DATABASE.md to add it.",
                received = sig.joinToString(" ") { "%02X".format(it) }
            )
    }

    fun erase(device: AvrDevice) {
        Logger.info("ENGINE", "Erasing ${device.description}")
        programmer.chipErase()
    }

    /** Runs a sequence of memory operations, in order, exactly like avrdude processes its -U flags. */
    fun run(device: AvrDevice, operations: List<MemoryOperation>, onProgress: (memory: String, done: Int, total: Int) -> Unit = { _, _, _ -> }) {
        for (spec in operations) {
            val memory = device.memories.firstOrNull { it.name == spec.memory }
                ?: throw ProgrammerException("Device ${device.description} has no memory named '${spec.memory}'")
            when (spec.op) {
                MemOp.READ -> {
                    Logger.info("ENGINE", "Reading ${spec.memory}")
                    programmer.readMemory(spec.memory, device) { done, total -> onProgress(spec.memory, done, total) }
                }
                MemOp.WRITE -> {
                    Logger.info("ENGINE", "Writing ${spec.memory}")
                    val image = loadImage(spec, memory.sizeBytes)
                    programmer.writeMemory(spec.memory, device, image) { done, total -> onProgress(spec.memory, done, total) }
                }
                MemOp.VERIFY -> {
                    Logger.info("ENGINE", "Verifying ${spec.memory}")
                    val expected = loadImage(spec, memory.sizeBytes)
                    val actual = programmer.readMemory(spec.memory, device) { done, total -> onProgress(spec.memory, done, total) }
                    verify(spec.memory, expected, actual)
                }
            }
        }
    }

    private fun loadImage(spec: MemoryOperation, memorySize: Int): MemoryImage = when (spec.format) {
        FileFormat.IHEX -> IntelHex.parse(
            spec.fileText ?: throw ProgrammerException("${spec.op} of ${spec.memory} requires Intel HEX file content"),
            memorySize
        )
        FileFormat.BIN -> IntelHex.fromBinary(
            spec.binaryBytes ?: throw ProgrammerException("${spec.op} of ${spec.memory} requires binary file content"),
            memorySize
        )
    }

    private fun verify(memoryName: String, expected: MemoryImage, actual: MemoryImage) {
        val range = expected.writtenRange() ?: return
        var checked = 0
        for (addr in range) {
            if (!expected.written[addr]) continue
            val exp = expected.get(addr).toInt() and 0xFF
            val act = actual.get(addr).toInt() and 0xFF
            if (exp != act) throw VerificationException(memoryName, addr, exp, act)
            checked++
        }
        Logger.info("ENGINE", "Verify OK: $memoryName ($checked bytes matched)")
    }
}
