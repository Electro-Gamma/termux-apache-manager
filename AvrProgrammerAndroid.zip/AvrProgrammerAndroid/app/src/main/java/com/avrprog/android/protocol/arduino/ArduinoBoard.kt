package com.avrprog.android.protocol.arduino

enum class ArduinoProtocol { STK500V1, AVR109 }

/**
 * One entry from the reference "arduino-hex-upload" library's board catalog
 * (`Boards.kt`), ported with its real baud rates, protocols, and reset
 * sequences -- see AVRDUDE_PORTING.md for exactly which fields map from
 * where. [deviceId] links to [com.avrprog.android.device.DeviceDatabase].
 */
data class ArduinoBoard(
    val id: String,
    val displayName: String,
    val deviceId: String,
    val protocol: ArduinoProtocol,
    val baudRate: Int,
    val openReset: ArduinoResetBehavior,
    val closeReset: ArduinoResetBehavior,
    val sleepAfterOpenMs: Long = if (protocol == ArduinoProtocol.AVR109) 0L else 250L,
    /** True if this exact board has been exercised against real hardware or at minimum a full protocol-level mock test. */
    val implemented: Boolean = true
)
