package com.avrprog.android.protocol.avr109

import com.avrprog.android.device.AvrDevice
import com.avrprog.android.error.ProtocolException
import com.avrprog.android.log.Logger
import com.avrprog.android.memory.MemoryImage
import com.avrprog.android.protocol.Programmer
import com.avrprog.android.protocol.ProgrammerInfo
import com.avrprog.android.protocol.arduino.ArduinoResetBehavior
import com.avrprog.android.usb.SerialTransport
import com.avrprog.android.protocol.avr109.Avr109Constants as K

/**
 * Real AVR109 (Butterfly/Caterina) bootloader protocol implementation,
 * ported from the reference "arduino-hex-upload" library's
 * `Avr109BootloaderProgrammer` -- a distinct, ASCII-command-based protocol
 * from STK500v1, used by the Caterina bootloader on ATmega32U4-based Arduino
 * boards (Leonardo, Micro, Esplora, LilyPad USB). See AVRDUDE_PORTING.md.
 *
 * Deliberately NOT ported: the reference's `Close()` waits for the board's
 * virtual COM port to disappear after a 1200bps touch-reset, which relies on
 * desktop-OS COM-port enumeration semantics Android's USB Host model doesn't
 * expose the same way -- see [ArduinoResetBehavior.Manual1200BpsTouch]. This
 * class assumes the board is already in bootloader mode (reached via manual
 * double-tap reset) by the time [open] is called.
 */
class Avr109Programmer(
    private val transport: SerialTransport,
    private val baudRate: Int = K.DEFAULT_BAUD_RATE,
    private val avr109DeviceCode: Int = 0x44, // ATmega32U4 -- the only AVR109 chip in this project's board catalog; see AVRDUDE_PORTING.md
    private val closeResetBehavior: ArduinoResetBehavior = ArduinoResetBehavior.None
) : Programmer {

    override val info = ProgrammerInfo(
        id = "avr109",
        name = "AVR109 (Caterina bootloader)",
        vendorIds = emptyList(),
        productIds = emptyList(),
        protocol = "AVR109 / Butterfly ASCII command protocol",
        transport = "Serial (USB-CDC, 57600 8N1)",
        implemented = true
    )

    override fun open() {
        transport.open(baudRate)
        // Real 1200bps touch-reset isn't automated (see class doc) --
        // ArduinoResetBehavior.Manual1200BpsTouch just logs instructions.
        ArduinoResetBehavior.Manual1200BpsTouch.apply(transport)

        readAndLogAscii("software identifier", K.CMD_RETURN_SOFTWARE_IDENTIFIER, 7)
        val ver = recvAfter(K.CMD_RETURN_SOFTWARE_VERSION, 2)
        Logger.info("AVR109", "Software version: ${ver[0].toInt().toChar()}${ver[1].toInt().toChar()}")
        recvAfter(K.CMD_RETURN_PROGRAMMER_TYPE, 1)

        val blockSupport = recvAfter(K.CMD_CHECK_BLOCK_SUPPORT, 3)
        if (blockSupport[0] != 'Y'.code.toByte()) {
            throw ProtocolException("Bootloader does not report paged/block programming support", protocol = "AVR109")
        }
        val bufferSize = ((blockSupport[1].toInt() and 0xFF) shl 8) or (blockSupport[2].toInt() and 0xFF)
        Logger.info("AVR109", "Block support confirmed, buffer size $bufferSize bytes")

        send(byteArrayOf(K.CMD_SELECT_DEVICE_TYPE.toByte(), avr109DeviceCode.toByte()))
        expectCr("SELECT_DEVICE_TYPE")

        send(byteArrayOf(K.CMD_ENTER_PROGRAMMING_MODE.toByte()))
        expectCr("ENTER_PROGRAMMING_MODE")
    }

    override fun close() {
        try {
            send(byteArrayOf(K.CMD_LEAVE_PROGRAMMING_MODE.toByte()))
            recv(1)
            send(byteArrayOf(K.CMD_EXIT_BOOTLOADER.toByte()))
            recv(1)
        } catch (e: Exception) {
            Logger.warning("AVR109", "Leaving programming mode on close() failed (device likely already gone): ${e.message}")
        }
        if (closeResetBehavior != ArduinoResetBehavior.None) {
            try {
                closeResetBehavior.apply(transport)
            } catch (e: Exception) {
                Logger.warning("AVR109", "Close reset behavior failed: ${e.message}")
            }
        }
        transport.close()
    }

    override fun readSignature(): ByteArray {
        send(byteArrayOf(K.CMD_READ_SIGNATURE_BYTES.toByte()))
        val raw = recv(3)
        // AVR109 returns signature bytes in reverse order vs ISP/STK500 -- ported
        // as-is from ReadSignatureBytesResponse in the reference library.
        return byteArrayOf(raw[2], raw[1], raw[0])
    }

    override fun chipErase() {
        // AVR109 bootloaders have no erase command at all -- flash pages are
        // erased automatically as each block is written.
        throw ProtocolException(
            "Chip erase isn't supported by the AVR109 bootloader protocol -- flash pages are erased automatically on write",
            protocol = "AVR109"
        )
    }

    override fun readMemory(memoryName: String, device: AvrDevice, onProgress: (Int, Int) -> Unit): MemoryImage {
        val memory = device.memories.firstOrNull { it.name == memoryName }
            ?: throw ProtocolException("Device ${device.description} has no memory named '$memoryName'")
        val memChar = if (memoryName == "flash") K.MEMCHAR_FLASH else K.MEMCHAR_EEPROM
        val image = MemoryImage(memory.sizeBytes)
        var address = 0
        val blockSize = memory.pageSize.coerceIn(1, 0xFFFF)
        Logger.info("AVR109", "Reading $memoryName (${memory.sizeBytes} bytes) from ${device.description}")
        while (address < memory.sizeBytes) {
            val thisBlock = minOf(blockSize, memory.sizeBytes - address)
            loadAddress(address)
            send(
                byteArrayOf(
                    K.CMD_START_BLOCK_READ.toByte(),
                    ((thisBlock shr 8) and 0xFF).toByte(),
                    (thisBlock and 0xFF).toByte(),
                    memChar
                )
            )
            val data = recv(thisBlock)
            for (i in 0 until thisBlock) image.set(address + i, data[i])
            address += thisBlock
            onProgress(address, memory.sizeBytes)
        }
        return image
    }

    override fun writeMemory(memoryName: String, device: AvrDevice, image: MemoryImage, onProgress: (Int, Int) -> Unit) {
        val memory = device.memories.firstOrNull { it.name == memoryName }
            ?: throw ProtocolException("Device ${device.description} has no memory named '$memoryName'")
        val memChar = if (memoryName == "flash") K.MEMCHAR_FLASH else K.MEMCHAR_EEPROM
        val range = image.writtenRange() ?: run {
            Logger.warning("AVR109", "writeMemory($memoryName) called with an empty image; nothing to do")
            return
        }
        val end = range.last + 1
        var address = 0
        val blockSize = memory.pageSize.coerceIn(1, 0xFFFF)
        Logger.info("AVR109", "Writing $memoryName (up to byte 0x${end.toString(16)}) to ${device.description}")
        while (address < end) {
            val thisBlock = minOf(blockSize, end - address)
            loadAddress(address)
            val cmd = ByteArray(4 + thisBlock)
            cmd[0] = K.CMD_START_BLOCK_LOAD.toByte()
            cmd[1] = ((thisBlock shr 8) and 0xFF).toByte()
            cmd[2] = (thisBlock and 0xFF).toByte()
            cmd[3] = memChar
            for (i in 0 until thisBlock) cmd[4 + i] = image.data[address + i]
            send(cmd)
            expectCr("START_BLOCK_LOAD @0x${address.toString(16)}")
            address += thisBlock
            onProgress(address, end)
        }
    }

    override fun setSckOption(id: Int) {
        Logger.warning("AVR109", "Bitclock/SCK adjustment isn't applicable to the AVR109 bootloader protocol")
    }

    // --- Low-level AVR109 protocol plumbing ---------------------------------------------

    /** AVR109 addresses are always given as word offsets, for both flash and EEPROM -- ported from LoadAddress() in the reference. */
    private fun loadAddress(byteAddress: Int) {
        val wordAddress = byteAddress / 2
        send(
            byteArrayOf(
                K.CMD_SET_ADDRESS.toByte(),
                ((wordAddress shr 8) and 0xFF).toByte(),
                (wordAddress and 0xFF).toByte()
            )
        )
        expectCr("SET_ADDRESS @0x${byteAddress.toString(16)}")
    }

    private fun readAndLogAscii(label: String, cmd: Int, length: Int) {
        val bytes = recvAfter(cmd, length)
        val text = bytes.joinToString("") { (it.toInt() and 0xFF).toChar().toString() }
        Logger.info("AVR109", "$label: '$text'")
    }

    private fun recvAfter(cmd: Int, length: Int): ByteArray {
        send(byteArrayOf(cmd.toByte()))
        return recv(length)
    }

    private fun expectCr(what: String) {
        val b = recv(1)
        if (b[0] != K.CARRIAGE_RETURN) {
            throw ProtocolException(
                "AVR109 command did not acknowledge", protocol = "AVR109", command = what,
                expected = "CR (0x0D)", received = "0x${(b[0].toInt() and 0xFF).toString(16)}"
            )
        }
    }

    private fun send(bytes: ByteArray) = transport.write(bytes, 2000)

    private fun recv(length: Int): ByteArray {
        val buf = ByteArray(length)
        transport.readExactly(buf, length, 2000)
        return buf
    }
}
