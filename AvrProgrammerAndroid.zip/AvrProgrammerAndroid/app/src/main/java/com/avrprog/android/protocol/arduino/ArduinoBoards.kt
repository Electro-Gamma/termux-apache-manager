package com.avrprog.android.protocol.arduino

import com.avrprog.android.protocol.arduino.ArduinoProtocol.AVR109
import com.avrprog.android.protocol.arduino.ArduinoProtocol.STK500V1

/**
 * Board catalog ported from the reference "arduino-hex-upload" library's
 * `Boards.kt` (itself matching the Arduino IDE's `boards.txt` upload
 * parameters) -- baud rates, protocols, and DTR/RTS reset sequences are
 * copied as-is, not guessed. See AVRDUDE_PORTING.md.
 *
 * STK500v1-protocol boards use [ArduinoResetBehavior.DtrToggle] /
 * [ArduinoResetBehavior.DtrRtsPulse], both fully implemented here. AVR109
 * boards (the 32U4/native-USB family) need a 1200bps touch-reset that isn't
 * automated on Android -- see [ArduinoResetBehavior.Manual1200BpsTouch].
 * "Arduino Mega 2560" is listed for completeness but marked NOT implemented:
 * it uses STK500v2, a protocol this project doesn't have yet (see
 * PROTOCOLS.md).
 */
object ArduinoBoards {

    private val dtrOpen = ArduinoResetBehavior.DtrToggle(true)
    private val dtrRtsClose = ArduinoResetBehavior.DtrRtsPulse(250, 50)
    private val dtrRtsCloseUno = ArduinoResetBehavior.DtrRtsPulse(50, 250, invert = false)

    val boards: List<ArduinoBoard> = listOf(
        ArduinoBoard("uno", "Arduino Uno", "atmega328p", STK500V1, 115_200, dtrOpen, dtrRtsCloseUno),
        ArduinoBoard("duemilanove328", "Arduino Duemilanove (ATmega328)", "atmega328p", STK500V1, 57_600, dtrOpen, dtrRtsClose),
        ArduinoBoard("duemilanove168", "Arduino Diecimila / Duemilanove (ATmega168)", "atmega168", STK500V1, 19_200, dtrOpen, dtrRtsClose),
        ArduinoBoard("nano328", "Arduino Nano (ATmega328)", "atmega328p", STK500V1, 57_600, dtrOpen, dtrRtsClose),
        ArduinoBoard("nano168", "Arduino Nano (ATmega168)", "atmega168", STK500V1, 57_600, dtrOpen, dtrRtsClose),
        ArduinoBoard("mega2560", "Arduino Mega 2560 / ADK", "atmega2560", STK500V1, 115_200, dtrOpen, dtrRtsClose, implemented = false), // real protocol is STK500v2, not implemented
        ArduinoBoard("leonardo", "Arduino Leonardo", "atmega32u4", AVR109, 57_600, ArduinoResetBehavior.Manual1200BpsTouch, ArduinoResetBehavior.None),
        ArduinoBoard("esplora", "Arduino Esplora", "atmega32u4", AVR109, 57_600, ArduinoResetBehavior.Manual1200BpsTouch, ArduinoResetBehavior.None),
        ArduinoBoard("micro", "Arduino Micro", "atmega32u4", AVR109, 57_600, ArduinoResetBehavior.Manual1200BpsTouch, ArduinoResetBehavior.None),
        ArduinoBoard("mini328", "Arduino Mini (ATmega328)", "atmega328p", STK500V1, 57_600, dtrOpen, dtrRtsClose),
        ArduinoBoard("mini168", "Arduino Mini (ATmega168)", "atmega168", STK500V1, 57_600, dtrOpen, dtrRtsClose),
        ArduinoBoard("ethernet", "Arduino Ethernet", "atmega328p", STK500V1, 115_200, dtrOpen, dtrRtsCloseUno),
        ArduinoBoard("fio", "Arduino Fio", "atmega328p", STK500V1, 57_600, dtrOpen, dtrRtsClose),
        ArduinoBoard("bt328", "Arduino BT (ATmega328)", "atmega328p", STK500V1, 19_200, dtrOpen, dtrRtsClose),
        ArduinoBoard("bt168", "Arduino BT (ATmega168)", "atmega168", STK500V1, 19_200, dtrOpen, dtrRtsClose),
        ArduinoBoard("lilypadUsb", "LilyPad Arduino USB", "atmega32u4", AVR109, 57_600, ArduinoResetBehavior.Manual1200BpsTouch, ArduinoResetBehavior.None),
        ArduinoBoard("lilypad328", "LilyPad Arduino (ATmega328)", "atmega328p", STK500V1, 57_600, dtrOpen, dtrRtsClose),
        ArduinoBoard("lilypad168", "LilyPad Arduino (ATmega168)", "atmega168", STK500V1, 19_200, dtrOpen, dtrRtsClose),
        ArduinoBoard("pro5v328", "Arduino Pro / Pro Mini 5V (ATmega328)", "atmega328p", STK500V1, 57_600, dtrOpen, dtrRtsClose),
        ArduinoBoard("pro5v168", "Arduino Pro / Pro Mini 5V (ATmega168)", "atmega168", STK500V1, 19_200, dtrOpen, dtrRtsClose),
        ArduinoBoard("pro33v328", "Arduino Pro / Pro Mini 3.3V (ATmega328)", "atmega328p", STK500V1, 57_600, dtrOpen, dtrRtsClose),
        ArduinoBoard("pro33v168", "Arduino Pro / Pro Mini 3.3V (ATmega168)", "atmega168", STK500V1, 19_200, dtrOpen, dtrRtsClose),
        ArduinoBoard("ng168", "Arduino NG or older (ATmega168)", "atmega168", STK500V1, 19_200, dtrOpen, dtrRtsClose),
        ArduinoBoard("balanduino", "Balanduino", "atmega1284", STK500V1, 115_200, dtrOpen, dtrRtsClose),
        ArduinoBoard("pocketduino", "PocketDuino", "atmega328p", STK500V1, 57_600, dtrOpen, dtrRtsClose)
    )

    fun findById(id: String): ArduinoBoard? = boards.firstOrNull { it.id == id }
}
