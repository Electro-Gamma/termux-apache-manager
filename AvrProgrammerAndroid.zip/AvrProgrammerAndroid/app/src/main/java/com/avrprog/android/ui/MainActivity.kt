package com.avrprog.android.ui

import android.graphics.drawable.GradientDrawable
import android.hardware.usb.UsbDevice
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.avrprog.android.R
import com.avrprog.android.databinding.ActivityMainBinding
import com.avrprog.android.device.AvrDevice
import com.avrprog.android.engine.AvrDudeEngine
import com.avrprog.android.engine.FileFormat
import com.avrprog.android.engine.MemOp
import com.avrprog.android.engine.MemoryOperation
import com.avrprog.android.error.AvrDudeException
import com.avrprog.android.log.LogLevel
import com.avrprog.android.log.Logger
import com.avrprog.android.protocol.NotYetImplementedProgrammer
import com.avrprog.android.protocol.ProgrammerInfo
import com.avrprog.android.protocol.ProgrammerRegistry
import com.avrprog.android.usb.AndroidUsbTransport
import com.avrprog.android.usb.UsbHostManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private enum class SelectionMode { AUTO, MANUAL }

/**
 * Thin UI shell over [AvrDudeEngine] -- per brief section 18. Every button
 * here calls into the same engine the Colab/CLI-style code path would use;
 * no protocol logic lives in this class.
 *
 * Adds a programmer picker on top of the original auto-only flow:
 * - **Auto-detect**: scans attached USB devices for any *implemented*
 *   programmer (the original behavior).
 * - **Manual**: pick any programmer this project knows about (implemented
 *   or not, per PROGRAMMERS.md) from a dropdown. Picking one that isn't
 *   implemented yet, or one that isn't USB-VID/PID-matchable at all (the
 *   serial-transport programmers), gives an immediate, honest message
 *   instead of silently failing or pretending it works.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var usbHostManager: UsbHostManager

    private var selectedDevice: UsbDevice? = null
    private var detectedPart: AvrDevice? = null
    private var mode: SelectionMode = SelectionMode.AUTO
    private var manualSelection: ProgrammerInfo? = null

    /** Which ProgrammerRegistry id to instantiate on connect/erase/write. Defaults to the one implemented programmer. */
    private var activeProgrammerId: String = "usbasp"

    private val filePicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) writeFlashFromUri(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        usbHostManager = UsbHostManager(this)

        Logger.minLevel = LogLevel.DEBUG
        Logger.addListener { entry ->
            runOnUiThread {
                binding.logView.append("[${entry.level}] ${entry.tag}: ${entry.message}\n")
            }
        }

        setupProgrammerDropdown()

        binding.modeToggleGroup.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            mode = if (checkedId == binding.manualModeButton.id) SelectionMode.MANUAL else SelectionMode.AUTO
            binding.programmerDropdownLayout.visibility = if (mode == SelectionMode.MANUAL) View.VISIBLE else View.GONE
            if (mode == SelectionMode.AUTO) {
                manualSelection = null
                activeProgrammerId = "usbasp"
                binding.programmerLabel.text = "Programmer: (none detected)"
            } else {
                binding.programmerLabel.text = "Programmer: pick one from the dropdown below"
            }
            resetConnectionState()
        }

        binding.detectButton.setOnClickListener { detectUsbDevices() }
        binding.connectButton.setOnClickListener { connectAndReadSignature() }
        binding.eraseButton.setOnClickListener { eraseChip() }
        binding.pickFileButton.setOnClickListener { filePicker.launch("*/*") }
    }

    override fun onDestroy() {
        usbHostManager.unregisterPermissionReceiver()
        super.onDestroy()
    }

    private fun setupProgrammerDropdown() {
        val descriptors = ProgrammerRegistry.descriptors
        val labels = descriptors.map { d -> "${d.name}  \u00b7  ${if (d.implemented) "implemented" else "not yet implemented"}" }
        binding.programmerDropdown.setAdapter(ArrayAdapter(this, android.R.layout.simple_list_item_1, labels))
        binding.programmerDropdown.setOnItemClickListener { _, _, position, _ ->
            val chosen = descriptors[position]
            manualSelection = chosen
            activeProgrammerId = chosen.id
            resetConnectionState()
            binding.programmerLabel.text = "Programmer: ${chosen.name} selected -- press Detect USB Devices"
        }
    }

    private fun resetConnectionState() {
        selectedDevice = null
        detectedPart = null
        binding.connectButton.isEnabled = false
        binding.eraseButton.isEnabled = false
        binding.pickFileButton.isEnabled = false
        binding.deviceLabel.text = "Device: (unknown)"
        setStatus(R.color.status_gray)
    }

    private fun setStatus(colorRes: Int) {
        (binding.statusDot.background as? GradientDrawable)?.setColor(ContextCompat.getColor(this, colorRes))
    }

    private fun detectUsbDevices() {
        if (mode == SelectionMode.MANUAL) {
            val target = manualSelection
            if (target == null) {
                Toast.makeText(this, "Pick a programmer from the dropdown first", Toast.LENGTH_SHORT).show()
                return
            }
            if (!target.implemented) {
                binding.programmerLabel.text = "Programmer: ${target.name} is not implemented in this build yet"
                setStatus(R.color.status_gray)
                Logger.warning("UI", "${target.name}: ${target.protocol} over ${target.transport} -- see PROGRAMMERS.md")
                Toast.makeText(this, "${target.name} isn't implemented yet -- see PROGRAMMERS.md", Toast.LENGTH_LONG).show()
                return
            }
            if (target.vendorIds.isEmpty()) {
                binding.programmerLabel.text = "Programmer: ${target.name} uses ${target.transport}, not USB VID/PID matching"
                setStatus(R.color.status_gray)
                Toast.makeText(this, "${target.name} needs a serial/USB-UART connection this build doesn't support yet", Toast.LENGTH_LONG).show()
                return
            }
        }

        val devices = usbHostManager.listDevices()
        if (devices.isEmpty()) {
            Toast.makeText(this, "No USB devices found -- check an OTG adapter is in use", Toast.LENGTH_LONG).show()
            binding.programmerLabel.text = "Programmer: (none detected)"
            setStatus(R.color.status_gray)
            return
        }
        for (d in devices) {
            Logger.debug(
                "USB",
                "Found ${d.manufacturer ?: "?"} ${d.product ?: "?"} " +
                    "(${d.vendorId.toString(16)}:${d.productId.toString(16)}), ${d.interfaceCount} interface(s)"
            )
        }

        val match = devices.firstOrNull { info ->
            val known = ProgrammerRegistry.matchByVidPid(info.vendorId, info.productId)
            if (mode == SelectionMode.MANUAL) known?.id == manualSelection?.id else known?.implemented == true
        }

        if (match == null) {
            val label = if (mode == SelectionMode.MANUAL) manualSelection?.name ?: "selected programmer" else "a supported programmer"
            binding.programmerLabel.text = "Programmer: $label not found (${devices.size} USB device(s) seen)"
            setStatus(R.color.status_gray)
            if (mode == SelectionMode.AUTO) {
                Toast.makeText(this, "See PROGRAMMERS.md -- only USBasp is implemented so far", Toast.LENGTH_LONG).show()
            }
            return
        }

        val descriptor = ProgrammerRegistry.matchByVidPid(match.vendorId, match.productId)!!
        selectedDevice = match.device
        activeProgrammerId = descriptor.id
        binding.programmerLabel.text = "Programmer: ${descriptor.name} (${match.product ?: match.device.deviceName})"
        setStatus(R.color.accent_green)
        binding.connectButton.isEnabled = true
    }

    private fun connectAndReadSignature() {
        val device = selectedDevice ?: return
        usbHostManager.requestPermission(device) { granted ->
            if (!granted) {
                Toast.makeText(this, "USB permission denied", Toast.LENGTH_SHORT).show()
                setStatus(R.color.accent_red)
                return@requestPermission
            }
            lifecycleScope.launch {
                try {
                    val part = withContext(Dispatchers.IO) {
                        val connection = usbHostManager.open(device)
                        val transport = AndroidUsbTransport(device, connection)
                        val programmer = ProgrammerRegistry.create(activeProgrammerId, transport)
                        programmer.open()
                        val engine = AvrDudeEngine(programmer)
                        val part = engine.detectDevice()
                        programmer.close()
                        part
                    }
                    detectedPart = part
                    binding.deviceLabel.text = "Device: ${part.description} (signature ${part.signatureHex()})"
                    binding.eraseButton.isEnabled = true
                    binding.pickFileButton.isEnabled = true
                } catch (e: AvrDudeException) {
                    Logger.error("UI", e.detailedMessage())
                    setStatus(R.color.accent_red)
                    Toast.makeText(this@MainActivity, e.message, Toast.LENGTH_LONG).show()
                } catch (e: NotYetImplementedProgrammer) {
                    Logger.error("UI", e.message ?: "Programmer not implemented")
                    setStatus(R.color.accent_red)
                    Toast.makeText(this@MainActivity, e.message, Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun eraseChip() {
        val device = selectedDevice ?: return
        val part = detectedPart ?: return
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    val connection = usbHostManager.open(device)
                    val transport = AndroidUsbTransport(device, connection)
                    val programmer = ProgrammerRegistry.create(activeProgrammerId, transport)
                    programmer.open()
                    AvrDudeEngine(programmer).erase(part)
                    programmer.close()
                }
                Toast.makeText(this@MainActivity, "Chip erased", Toast.LENGTH_SHORT).show()
            } catch (e: AvrDudeException) {
                Logger.error("UI", e.detailedMessage())
                Toast.makeText(this@MainActivity, e.message, Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun writeFlashFromUri(uri: Uri) {
        val device = selectedDevice ?: return
        val part = detectedPart ?: return
        lifecycleScope.launch {
            try {
                val text = withContext(Dispatchers.IO) {
                    contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                } ?: throw IllegalStateException("Could not read the selected file")

                withContext(Dispatchers.IO) {
                    val connection = usbHostManager.open(device)
                    val transport = AndroidUsbTransport(device, connection)
                    val programmer = ProgrammerRegistry.create(activeProgrammerId, transport)
                    programmer.open()
                    val engine = AvrDudeEngine(programmer)
                    engine.run(
                        part,
                        listOf(
                            MemoryOperation("flash", MemOp.WRITE, text, FileFormat.IHEX),
                            MemoryOperation("flash", MemOp.VERIFY, text, FileFormat.IHEX)
                        )
                    ) { _, done, total ->
                        runOnUiThread { binding.progressBar.progress = if (total > 0) (done * 100 / total) else 0 }
                    }
                    programmer.close()
                }
                Toast.makeText(this@MainActivity, "Flash written and verified", Toast.LENGTH_SHORT).show()
            } catch (e: AvrDudeException) {
                Logger.error("UI", e.detailedMessage())
                Toast.makeText(this@MainActivity, e.message, Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Logger.error("UI", e.message ?: "Unknown error")
                Toast.makeText(this@MainActivity, e.message, Toast.LENGTH_LONG).show()
            }
        }
    }
}
