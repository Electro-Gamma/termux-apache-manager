package com.avrprog.android.ui

import android.hardware.usb.UsbDevice
import android.net.Uri
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.avrprog.android.device.AvrDevice
import com.avrprog.android.engine.AvrDudeEngine
import com.avrprog.android.engine.FileFormat
import com.avrprog.android.engine.MemOp
import com.avrprog.android.engine.MemoryOperation
import com.avrprog.android.error.AvrDudeException
import com.avrprog.android.log.LogLevel
import com.avrprog.android.log.Logger
import com.avrprog.android.protocol.ProgrammerRegistry
import com.avrprog.android.usb.AndroidUsbTransport
import com.avrprog.android.usb.UsbHostManager
import com.avrprog.android.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Thin UI shell over [AvrDudeEngine]. Every USB/protocol call runs on
 * Dispatchers.IO; the engine and protocol layer contain no Android UI
 * dependencies at all (brief section 17).
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var usbHostManager: UsbHostManager

    private var selectedDevice: UsbDevice? = null
    private var detectedPart: AvrDevice? = null
    private var pendingFlashPick = false

    private val filePicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) handleFirmwarePicked(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        usbHostManager = UsbHostManager(this)
        Logger.minLevel = LogLevel.TRACE
        Logger.addListener { entry ->
            runOnUiThread {
                binding.logView.append("[${entry.level}] ${entry.tag}: ${entry.message}\n")
            }
        }

        binding.detectButton.setOnClickListener { detectUsbDevices() }
        binding.connectButton.setOnClickListener { connectAndReadSignature() }
        binding.eraseButton.setOnClickListener { eraseChip() }
        binding.pickFileButton.setOnClickListener {
            pendingFlashPick = true
            filePicker.launch("*/*")
        }
    }

    override fun onDestroy() {
        usbHostManager.unregisterPermissionReceiver()
        super.onDestroy()
    }

    private fun detectUsbDevices() {
        val devices = usbHostManager.listDevices()
        Logger.info("UI", "Found ${devices.size} USB device(s)")
        val match = devices.firstOrNull { info ->
            ProgrammerRegistry.matchByVidPid(info.vendorId, info.productId)?.implemented == true
        }
        devices.forEach { info ->
            val known = ProgrammerRegistry.matchByVidPid(info.vendorId, info.productId)
            Logger.info(
                "UI",
                "  ${info.vendorId.toHex4()}:${info.productId.toHex4()} ${info.manufacturer ?: "?"} ${info.product ?: "?"} " +
                    (known?.let { " -> ${it.name} (${if (it.implemented) "implemented" else "NOT YET IMPLEMENTED"})" } ?: " -> unrecognized")
            )
        }
        if (match == null) {
            binding.programmerLabel.text = "Programmer: none recognized (${devices.size} USB device(s) seen)"
            binding.connectButton.isEnabled = false
            return
        }
        selectedDevice = match.device
        binding.programmerLabel.text = "Programmer: USBasp detected, requesting permission..."
        usbHostManager.requestPermission(selectedDevice!!) { granted ->
            runOnUiThread {
                if (granted) {
                    binding.programmerLabel.text = "Programmer: USBasp (permission granted)"
                    binding.connectButton.isEnabled = true
                } else {
                    binding.programmerLabel.text = "Programmer: USBasp (permission denied)"
                }
            }
        }
    }

    private fun connectAndReadSignature() {
        val device = selectedDevice ?: return
        lifecycleScope.launch {
            try {
                val part = withContext(Dispatchers.IO) {
                    val connection = usbHostManager.open(device)
                    val transport = AndroidUsbTransport(device, connection)
                    val programmer = ProgrammerRegistry.create("usbasp", transport)
                    programmer.open()
                    val engine = AvrDudeEngine(programmer)
                    engine.detectDevice()
                }
                detectedPart = part
                binding.deviceLabel.text = "Device: ${part.description}  (signature ${part.signatureHex()})"
                binding.eraseButton.isEnabled = true
                binding.pickFileButton.isEnabled = true
            } catch (e: AvrDudeException) {
                Logger.error("UI", e.detailedMessage())
                binding.deviceLabel.text = "Device: detection failed -- see log"
            }
        }
    }

    private fun eraseChip() {
        val device = selectedDevice ?: return
        val part = detectedPart ?: return
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    val connection = usbHostManager.open(device)
                    val transport = AndroidUsbTransport(device, connection)
                    val programmer = ProgrammerRegistry.create("usbasp", transport)
                    programmer.open()
                    AvrDudeEngine(programmer).erase(part)
                    programmer.close()
                }
                Logger.info("UI", "Erase complete")
            } catch (e: AvrDudeException) {
                Logger.error("UI", e.detailedMessage())
            }
        }
    }

    private fun handleFirmwarePicked(uri: Uri) {
        if (!pendingFlashPick) return
        pendingFlashPick = false
        val device = selectedDevice ?: return
        val part = detectedPart ?: return
        lifecycleScope.launch {
            try {
                val hexText = withContext(Dispatchers.IO) {
                    contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                        ?: throw IllegalStateException("Could not open selected file")
                }
                withContext(Dispatchers.IO) {
                    val connection = usbHostManager.open(device)
                    val transport = AndroidUsbTransport(device, connection)
                    val programmer = ProgrammerRegistry.create("usbasp", transport)
                    programmer.open()
                    val engine = AvrDudeEngine(programmer)
                    engine.run(
                        part,
                        listOf(
                            MemoryOperation("flash", MemOp.WRITE, fileText = hexText, format = FileFormat.IHEX),
                            MemoryOperation("flash", MemOp.VERIFY, fileText = hexText, format = FileFormat.IHEX)
                        )
                    ) { memory, done, total ->
                        runOnUiThread { binding.progressBar.progress = if (total > 0) (done * 100 / total) else 0 }
                        Logger.debug("UI", "$memory: $done/$total")
                    }
                    programmer.close()
                }
                Logger.info("UI", "Write + verify complete")
            } catch (e: AvrDudeException) {
                Logger.error("UI", e.detailedMessage())
            } catch (e: Exception) {
                Logger.error("UI", "Unexpected error: ${e.message}")
            }
        }
    }

    private fun Int.toHex4(): String = "0x" + this.toString(16).uppercase().padStart(4, '0')
}
