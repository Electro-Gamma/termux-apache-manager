package com.avrprog.android.ui

import android.graphics.drawable.GradientDrawable
import android.hardware.usb.UsbDevice
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.avrprog.android.R
import com.avrprog.android.databinding.ActivityMainBinding
import com.avrprog.android.device.AvrDevice
import com.avrprog.android.engine.AvrDudeEngine
import com.avrprog.android.engine.FileFormat
import com.avrprog.android.engine.MemOp
import com.avrprog.android.engine.MemoryOperation
import com.avrprog.android.error.AvrDudeException
import com.avrprog.android.log.LogLevel
import com.avrprog.android.log.Logger
import com.avrprog.android.protocol.NotYetImplementedProgrammer
import com.avrprog.android.protocol.Programmer
import com.avrprog.android.protocol.ProgrammerInfo
import com.avrprog.android.protocol.ProgrammerRegistry
import com.avrprog.android.usb.AndroidUsbTransport
import com.avrprog.android.usb.SerialDeviceScanner
import com.avrprog.android.usb.UsbHostManager
import com.avrprog.android.usb.UsbSerialTransport
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private enum class SelectionMode { AUTO, MANUAL }
private enum class TransportKind { USB, SERIAL }

/**
 * Thin UI shell over [AvrDudeEngine] -- per brief section 18. Every button
 * here calls into the same engine the Colab/CLI-style code path would use;
 * no protocol logic lives in this class.
 *
 * - **Auto-detect**: scans attached USB devices for any *implemented*
 *   USB-control-transfer programmer (currently USBasp).
 * - **Manual**: pick any programmer this project knows about from a
 *   dropdown. For USB-control-transfer programmers, detection matches by
 *   VID/PID same as auto mode. For serial-transport programmers (currently
 *   STK500v1), detection instead asks [SerialDeviceScanner] whether any
 *   attached device is a recognized USB-UART adapter (CH340/FTDI/CP210x/...)
 *   -- those don't have a fixed VID/PID of their own. Picking a programmer
 *   that isn't implemented yet gives an immediate, honest message instead of
 *   silently failing or pretending it works.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var usbHostManager: UsbHostManager

    private var selectedDevice: UsbDevice? = null
    private var detectedPart: AvrDevice? = null
    private var mode: SelectionMode = SelectionMode.AUTO
    private var manualSelection: ProgrammerInfo? = null

    /** Which ProgrammerRegistry id to instantiate on connect/erase/write. Defaults to the one always-available USB programmer. */
    private var activeProgrammerId: String = "usbasp"
    private var activeTransportKind: TransportKind = TransportKind.USB

    private val filePicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) writeFlashFromUri(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        usbHostManager = UsbHostManager(this)

        Logger.minLevel = LogLevel.DEBUG
        Logger.addListener { entry ->
            runOnUiThread {
                binding.logView.append("[${entry.level}] ${entry.tag}: ${entry.message}\n")
            }
        }

        setupProgrammerDropdown()

        binding.modeToggleGroup.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            mode = if (checkedId == binding.manualModeButton.id) SelectionMode.MANUAL else SelectionMode.AUTO
            binding.programmerDropdownLayout.visibility = if (mode == SelectionMode.MANUAL) View.VISIBLE else View.GONE
            if (mode == SelectionMode.AUTO) {
                manualSelection = null
                activeProgrammerId = "usbasp"
                activeTransportKind = TransportKind.USB
                binding.programmerLabel.text = "Programmer: (none detected)"
            } else {
                binding.programmerLabel.text = "Programmer: pick one from the dropdown below"
            }
            resetConnectionState()
        }

        binding.detectButton.setOnClickListener { detectUsbDevices() }
        binding.connectButton.setOnClickListener { connectAndReadSignature() }
        binding.eraseButton.setOnClickListener { eraseChip() }
        binding.pickFileButton.setOnClickListener { filePicker.launch("*/*") }
    }

    override fun onDestroy() {
        usbHostManager.unregisterPermissionReceiver()
        super.onDestroy()
    }

    private fun setupProgrammerDropdown() {
        val descriptors = ProgrammerRegistry.descriptors
        val labels = descriptors.map { d -> "${d.name}  \u00b7  ${if (d.implemented) "implemented" else "not yet implemented"}" }
        binding.programmerDropdown.setAdapter(ArrayAdapter(this, android.R.layout.simple_list_item_1, labels))
        binding.programmerDropdown.setOnItemClickListener { _, _, position, _ ->
            val chosen = descriptors[position]
            manualSelection = chosen
            activeProgrammerId = chosen.id
            activeTransportKind = if (ProgrammerRegistry.isSerialTransport(chosen.id)) TransportKind.SERIAL else TransportKind.USB
            resetConnectionState()
            binding.programmerLabel.text = "Programmer: ${chosen.name} selected -- press Detect USB Devices"
        }
    }

    private fun resetConnectionState() {
        selectedDevice = null
        detectedPart = null
        binding.connectButton.isEnabled = false
        binding.eraseButton.isEnabled = false
        binding.pickFileButton.isEnabled = false
        binding.deviceLabel.text = "Device: (unknown)"
        setStatus(R.color.status_gray)
    }

    private fun setStatus(colorRes: Int) {
        (binding.statusDot.background as? GradientDrawable)?.setColor(ContextCompat.getColor(this, colorRes))
    }

    private fun detectUsbDevices() {
        if (mode == SelectionMode.MANUAL) {
            val target = manualSelection
            if (target == null) {
                Toast.makeText(this, "Pick a programmer from the dropdown first", Toast.LENGTH_SHORT).show()
                return
            }
            if (!target.implemented) {
                binding.programmerLabel.text = "Programmer: ${target.name} is not implemented in this build yet"
                setStatus(R.color.status_gray)
                Logger.warning("UI", "${target.name}: ${target.protocol} over ${target.transport} -- see PROGRAMMERS.md")
                Toast.makeText(this, "${target.name} isn't implemented yet -- see PROGRAMMERS.md", Toast.LENGTH_LONG).show()
                return
            }
            if (ProgrammerRegistry.isSerialTransport(target.id)) {
                detectSerialProgrammer(target)
                return
            }
        }

        val devices = usbHostManager.listDevices()
        if (devices.isEmpty()) {
            Toast.makeText(this, "No USB devices found -- check an OTG adapter is in use", Toast.LENGTH_LONG).show()
            binding.programmerLabel.text = "Programmer: (none detected)"
            setStatus(R.color.status_gray)
            return
        }
        for (d in devices) {
            Logger.debug(
                "USB",
                "Found ${d.manufacturer ?: "?"} ${d.product ?: "?"} " +
                    "(${d.vendorId.toString(16)}:${d.productId.toString(16)}), ${d.interfaceCount} interface(s)"
            )
        }

        val match = devices.firstOrNull { info ->
            val known = ProgrammerRegistry.matchByVidPid(info.vendorId, info.productId)
            if (mode == SelectionMode.MANUAL) known?.id == manualSelection?.id else known?.implemented == true
        }

        if (match == null) {
            val label = if (mode == SelectionMode.MANUAL) manualSelection?.name ?: "selected programmer" else "a supported programmer"
            binding.programmerLabel.text = "Programmer: $label not found (${devices.size} USB device(s) seen)"
            setStatus(R.color.status_gray)
            if (mode == SelectionMode.AUTO) {
                Toast.makeText(this, "See PROGRAMMERS.md -- only USBasp is implemented so far", Toast.LENGTH_LONG).show()
            }
            return
        }

        val descriptor = ProgrammerRegistry.matchByVidPid(match.vendorId, match.productId)!!
        selectedDevice = match.device
        activeProgrammerId = descriptor.id
        activeTransportKind = TransportKind.USB
        binding.programmerLabel.text = "Programmer: ${descriptor.name} (${match.product ?: match.device.deviceName})"
        setStatus(R.color.accent_green)
        binding.connectButton.isEnabled = true
    }

    /** Detection path for serial-transport programmers: any recognized USB-UART adapter counts as a candidate, not a fixed VID/PID. */
    private fun detectSerialProgrammer(target: ProgrammerInfo) {
        val drivers = SerialDeviceScanner.findDrivers(this)
        if (drivers.isEmpty()) {
            binding.programmerLabel.text = "Programmer: no USB-serial adapter found for ${target.name}"
            setStatus(R.color.status_gray)
            Toast.makeText(this, "No CH340/FTDI/CP210x/CDC-ACM adapter detected", Toast.LENGTH_LONG).show()
            return
        }
        val driver = drivers.first()
        Logger.debug(
            "USB",
            "Found ${driver.device.manufacturerName ?: "?"} ${driver.device.productName ?: "?"} " +
                "(${driver.device.vendorId.toString(16)}:${driver.device.productId.toString(16)}) via ${driver.javaClass.simpleName}"
        )
        selectedDevice = driver.device
        activeProgrammerId = target.id
        activeTransportKind = TransportKind.SERIAL
        binding.programmerLabel.text = "Programmer: ${target.name} (${driver.device.productName ?: driver.device.deviceName})"
        setStatus(R.color.accent_green)
        binding.connectButton.isEnabled = true
    }

    /** Builds the right [Programmer] for the active transport kind against an already-permitted [device]. */
    private fun buildProgrammer(device: UsbDevice): Programmer {
        val connection = usbHostManager.open(device)
        return if (activeTransportKind == TransportKind.SERIAL) {
            val driver = SerialDeviceScanner.driverFor(this, device)
                ?: throw IllegalStateException("No compatible USB-serial driver found for this device anymore")
            val port = driver.ports.first()
            val transport = UsbSerialTransport(port, connection)
            ProgrammerRegistry.createSerial(activeProgrammerId, transport)
        } else {
            val transport = AndroidUsbTransport(device, connection)
            ProgrammerRegistry.create(activeProgrammerId, transport)
        }
    }

    private fun connectAndReadSignature() {
        val device = selectedDevice ?: return
        usbHostManager.requestPermission(device) { granted ->
            if (!granted) {
                Toast.makeText(this, "USB permission denied", Toast.LENGTH_SHORT).show()
                setStatus(R.color.accent_red)
                return@requestPermission
            }
            lifecycleScope.launch {
                try {
                    val part = withContext(Dispatchers.IO) {
                        val programmer = buildProgrammer(device)
                        programmer.open()
                        val engine = AvrDudeEngine(programmer)
                        val part = engine.detectDevice()
                        programmer.close()
                        part
                    }
                    detectedPart = part
                    binding.deviceLabel.text = "Device: ${part.description} (signature ${part.signatureHex()})"
                    binding.eraseButton.isEnabled = true
                    binding.pickFileButton.isEnabled = true
                } catch (e: AvrDudeException) {
                    Logger.error("UI", e.detailedMessage())
                    setStatus(R.color.accent_red)
                    Toast.makeText(this@MainActivity, e.message, Toast.LENGTH_LONG).show()
                } catch (e: NotYetImplementedProgrammer) {
                    Logger.error("UI", e.message ?: "Programmer not implemented")
                    setStatus(R.color.accent_red)
                    Toast.makeText(this@MainActivity, e.message, Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Logger.error("UI", e.message ?: "Unexpected error")
                    setStatus(R.color.accent_red)
                    Toast.makeText(this@MainActivity, e.message, Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun eraseChip() {
        val device = selectedDevice ?: return
        val part = detectedPart ?: return
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    val programmer = buildProgrammer(device)
                    programmer.open()
                    AvrDudeEngine(programmer).erase(part)
                    programmer.close()
                }
                Toast.makeText(this@MainActivity, "Chip erased", Toast.LENGTH_SHORT).show()
            } catch (e: AvrDudeException) {
                Logger.error("UI", e.detailedMessage())
                Toast.makeText(this@MainActivity, e.message, Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Logger.error("UI", e.message ?: "Unexpected error")
                Toast.makeText(this@MainActivity, e.message, Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun writeFlashFromUri(uri: Uri) {
        val device = selectedDevice ?: return
        val part = detectedPart ?: return
        lifecycleScope.launch {
            try {
                val text = withContext(Dispatchers.IO) {
                    contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                } ?: throw IllegalStateException("Could not read the selected file")

                withContext(Dispatchers.IO) {
                    val programmer = buildProgrammer(device)
                    programmer.open()
                    val engine = AvrDudeEngine(programmer)
                    engine.run(
                        part,
                        listOf(
                            MemoryOperation("flash", MemOp.WRITE, text, FileFormat.IHEX),
                            MemoryOperation("flash", MemOp.VERIFY, text, FileFormat.IHEX)
                        )
                    ) { _, done, total ->
                        runOnUiThread { binding.progressBar.progress = if (total > 0) (done * 100 / total) else 0 }
                    }
                    programmer.close()
                }
                Toast.makeText(this@MainActivity, "Flash written and verified", Toast.LENGTH_SHORT).show()
            } catch (e: AvrDudeException) {
                Logger.error("UI", e.detailedMessage())
                Toast.makeText(this@MainActivity, e.message, Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Logger.error("UI", e.message ?: "Unknown error")
                Toast.makeText(this@MainActivity, e.message, Toast.LENGTH_LONG).show()
            }
        }
    }
}
