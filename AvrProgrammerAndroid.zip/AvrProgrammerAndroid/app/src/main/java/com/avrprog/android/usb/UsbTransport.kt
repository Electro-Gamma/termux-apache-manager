package com.avrprog.android.usb

/**
 * Abstraction over a USB control/bulk transport so protocol implementations
 * (see protocol/) depend on this interface instead of android.hardware.usb.*
 * directly. This is what makes protocol unit tests possible without physical
 * hardware or an Android runtime (brief section 21: "mock transports").
 */
interface UsbTransport {
    val vendorId: Int
    val productId: Int

    /** Mirrors android.hardware.usb.UsbDeviceConnection#controlTransfer. Returns bytes transferred; throws on failure. */
    fun controlTransfer(
        requestType: Int,
        request: Int,
        value: Int,
        index: Int,
        buffer: ByteArray?,
        length: Int,
        timeoutMs: Int
    ): Int

    /** Mirrors UsbDeviceConnection#bulkTransfer against a specific endpoint address. */
    fun bulkTransfer(endpointAddress: Int, buffer: ByteArray, length: Int, timeoutMs: Int): Int

    fun close()
}
