package com.avrprog.android.memory

import com.avrprog.android.error.MemoryOperationException

/**
 * Intel HEX reader/writer (project brief section 14). Supports data (00),
 * EOF (01), extended segment address (02), start segment address (03),
 * extended linear address (04) and start linear address (05) records, with
 * validation of record length, address range, checksum, record overlap and
 * a required EOF record.
 */
object IntelHex {

    private const val TYPE_DATA = 0x00
    private const val TYPE_EOF = 0x01
    private const val TYPE_EXT_SEGMENT = 0x02
    private const val TYPE_START_SEGMENT = 0x03
    private const val TYPE_EXT_LINEAR = 0x04
    private const val TYPE_START_LINEAR = 0x05

    fun parse(text: String, memorySize: Int): MemoryImage {
        val image = MemoryImage(memorySize)
        var extendedLinearBase = 0
        var extendedSegmentBase = 0
        var sawEof = false
        val touchedRanges = mutableListOf<IntRange>()

        text.lineSequence().forEachIndexed { zeroIdx, rawLine ->
            val lineNo = zeroIdx + 1
            val line = rawLine.trim()
            if (line.isEmpty()) return@forEachIndexed
            if (sawEof) return@forEachIndexed // ignore trailing blank/garbage after EOF
            if (!line.startsWith(":")) {
                throw MemoryOperationException("Intel HEX line $lineNo: record does not start with ':'")
            }

            val bytes = try {
                hexToBytes(line.substring(1))
            } catch (e: Exception) {
                throw MemoryOperationException("Intel HEX line $lineNo: invalid hex characters", e)
            }
            if (bytes.size < 5) {
                throw MemoryOperationException("Intel HEX line $lineNo: record shorter than the minimum 5 bytes")
            }

            val byteCount = bytes[0].toInt() and 0xFF
            val addr16 = ((bytes[1].toInt() and 0xFF) shl 8) or (bytes[2].toInt() and 0xFF)
            val type = bytes[3].toInt() and 0xFF
            if (bytes.size != 4 + byteCount + 1) {
                throw MemoryOperationException(
                    "Intel HEX line $lineNo: length mismatch (byte count field says $byteCount, " +
                        "record actually has ${bytes.size - 5} data bytes)"
                )
            }
            val checksum = bytes.fold(0) { acc, b -> acc + (b.toInt() and 0xFF) } and 0xFF
            if (checksum != 0) {
                throw MemoryOperationException("Intel HEX line $lineNo: checksum failed")
            }
            val payload = bytes.copyOfRange(4, 4 + byteCount)

            when (type) {
                TYPE_DATA -> {
                    val base = if (extendedLinearBase != 0) extendedLinearBase else extendedSegmentBase
                    val start = base + addr16
                    val end = start + byteCount - 1
                    if (end >= memorySize) {
                        throw MemoryOperationException(
                            "Intel HEX line $lineNo: address 0x${end.toString(16)} exceeds target memory size " +
                                "0x${memorySize.toString(16)}"
                        )
                    }
                    for (existing in touchedRanges) {
                        if (start <= existing.last && end >= existing.first) {
                            throw MemoryOperationException(
                                "Intel HEX line $lineNo: record at 0x${start.toString(16)}-0x${end.toString(16)} " +
                                    "overlaps a previously seen record"
                            )
                        }
                    }
                    touchedRanges += start..end
                    for (i in 0 until byteCount) image.set(start + i, payload[i])
                }
                TYPE_EOF -> sawEof = true
                TYPE_EXT_SEGMENT -> {
                    if (byteCount != 2) throw MemoryOperationException("Intel HEX line $lineNo: malformed extended segment address record")
                    extendedSegmentBase = (((payload[0].toInt() and 0xFF) shl 8) or (payload[1].toInt() and 0xFF)) shl 4
                    extendedLinearBase = 0
                }
                TYPE_START_SEGMENT -> { /* CS:IP start address -- not meaningful for AVR targets, accepted and ignored */ }
                TYPE_EXT_LINEAR -> {
                    if (byteCount != 2) throw MemoryOperationException("Intel HEX line $lineNo: malformed extended linear address record")
                    extendedLinearBase = (((payload[0].toInt() and 0xFF) shl 8) or (payload[1].toInt() and 0xFF)) shl 16
                    extendedSegmentBase = 0
                }
                TYPE_START_LINEAR -> { /* EIP start address -- not meaningful for AVR targets, accepted and ignored */ }
                else -> throw MemoryOperationException("Intel HEX line $lineNo: unsupported record type 0x${type.toString(16)}")
            }
        }

        if (!sawEof) throw MemoryOperationException("Intel HEX input is missing its EOF record (:00000001FF)")
        return image
    }

    fun write(image: MemoryImage, bytesPerLine: Int = 16): String {
        val range = image.writtenRange() ?: return ":00000001FF\n"
        val sb = StringBuilder()
        var lastLinearBase = -1
        var addr = range.first - (range.first % bytesPerLine)
        while (addr <= range.last) {
            val chunkEnd = minOf(addr + bytesPerLine, image.size)
            val anyWritten = (addr until chunkEnd).any { image.written[it] }
            if (anyWritten) {
                val linearBase = addr ushr 16
                if (linearBase != lastLinearBase) {
                    sb.append(extLinearRecord(linearBase)).append('\n')
                    lastLinearBase = linearBase
                }
                val count = chunkEnd - addr
                val payload = ByteArray(count) { image.data[addr + it] }
                sb.append(dataRecord(addr and 0xFFFF, payload)).append('\n')
            }
            addr += bytesPerLine
        }
        sb.append(":00000001FF\n")
        return sb.toString()
    }

    fun toBinary(image: MemoryImage): ByteArray {
        val range = image.writtenRange() ?: return ByteArray(0)
        return image.data.copyOfRange(0, range.last + 1)
    }

    fun fromBinary(bytes: ByteArray, memorySize: Int): MemoryImage {
        if (bytes.size > memorySize) {
            throw MemoryOperationException("Binary image is ${bytes.size} bytes, larger than the target memory ($memorySize bytes)")
        }
        val image = MemoryImage(memorySize)
        for (i in bytes.indices) image.set(i, bytes[i])
        return image
    }

    private fun dataRecord(addr16: Int, payload: ByteArray): String {
        val bytes = mutableListOf<Int>()
        bytes += payload.size
        bytes += (addr16 ushr 8) and 0xFF
        bytes += addr16 and 0xFF
        bytes += TYPE_DATA
        payload.forEach { bytes += it.toInt() and 0xFF }
        val checksum = (0x100 - (bytes.sum() and 0xFF)) and 0xFF
        bytes += checksum
        return ":" + bytes.joinToString("") { "%02X".format(it) }
    }

    private fun extLinearRecord(linearBase16: Int): String {
        val hi = (linearBase16 ushr 8) and 0xFF
        val lo = linearBase16 and 0xFF
        val bytes = listOf(2, 0, 0, TYPE_EXT_LINEAR, hi, lo)
        val checksum = (0x100 - (bytes.sum() and 0xFF)) and 0xFF
        return ":" + (bytes + checksum).joinToString("") { "%02X".format(it) }
    }

    private fun hexToBytes(hex: String): ByteArray {
        if (hex.length % 2 != 0) throw IllegalArgumentException("odd-length hex string")
        return ByteArray(hex.length / 2) { i -> hex.substring(i * 2, i * 2 + 2).toInt(16).toByte() }
    }
}
