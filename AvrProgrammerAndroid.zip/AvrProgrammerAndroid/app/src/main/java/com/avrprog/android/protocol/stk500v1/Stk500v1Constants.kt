package com.avrprog.android.protocol.stk500v1

/**
 * Ported from AVRDUDE src/stk500_private.h (command/response byte values)
 * and the actual protocol behavior in src/stk500.c -- see AVRDUDE_PORTING.md.
 *
 * Note: stk500_private.h also defines Cmnd_STK_CHIP_ERASE (0x52), but the
 * real stk500_chip_erase() in stk500.c does NOT use it -- it sends the
 * standard AVR ISP chip-erase instruction (0xAC 0x80 0x00 0x00) through the
 * generic Cmnd_STK_UNIVERSAL passthrough instead, same mechanism as
 * signature reads. [Stk500v1Programmer.chipErase] follows the actual code
 * path, not the unused header constant.
 */
object Stk500v1Constants {
    /** avrdude's stk500_open() default when no -b baud rate is given. */
    const val DEFAULT_BAUD_RATE = 115200

    const val RESP_STK_OK = 0x10
    const val RESP_STK_FAILED = 0x11
    const val RESP_STK_NODEVICE = 0x13
    const val RESP_STK_INSYNC = 0x14
    const val RESP_STK_NOSYNC = 0x15

    const val SYNC_CRC_EOP = 0x20

    const val CMND_STK_GET_SYNC = 0x30
    const val CMND_STK_ENTER_PROGMODE = 0x50
    const val CMND_STK_LEAVE_PROGMODE = 0x51
    const val CMND_STK_LOAD_ADDRESS = 0x55
    const val CMND_STK_UNIVERSAL = 0x56
    const val CMND_STK_PROG_PAGE = 0x64
    const val CMND_STK_READ_PAGE = 0x74

    /** avrdude's MAX_SYNC_ATTEMPTS default. */
    const val MAX_SYNC_ATTEMPTS = 32

    /** ASCII 'F' / 'E' memtype byte used in PROG_PAGE / READ_PAGE commands. */
    const val MEMCHAR_FLASH: Byte = 'F'.code.toByte()
    const val MEMCHAR_EEPROM: Byte = 'E'.code.toByte()

    /** Standard AVR ISP "Load Extended Address Byte" instruction prefix, for flash > 64K words. */
    val LOAD_EXT_ADDR_CMD_PREFIX = byteArrayOf(0x4d, 0x00)
}
