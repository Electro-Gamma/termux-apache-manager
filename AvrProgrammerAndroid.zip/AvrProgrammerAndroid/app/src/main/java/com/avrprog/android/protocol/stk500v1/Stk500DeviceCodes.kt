package com.avrprog.android.protocol.stk500v1

/**
 * `stk500_devcode` values from AVRDUDE's src/avrdude.conf.in `part` blocks
 * (resolved through `parent` inheritance where a part doesn't set its own),
 * used in the CMND_STK_SET_DEVICE parameter block that stk500_initialize()
 * sends before entering programming mode -- see AVRDUDE_PORTING.md and
 * [Stk500v1Programmer.setDevice].
 *
 * Devices not in this table (e.g. ATmega32U2, whose devcode isn't set
 * anywhere in its avrdude.conf.in parent chain) get 0x00, matching what
 * avrdude itself would send for an unset field. Real hardware may care about
 * getting the exact value; bootloaders (Optiboot and similar) typically ACK
 * SET_DEVICE regardless of its contents.
 */
object Stk500DeviceCodes {
    private val codes: Map<String, Int> = mapOf(
        "attiny13" to 0x14,
        "attiny2313" to 0x23,
        "attiny25" to 0x14,
        "attiny45" to 0x14,
        "attiny85" to 0x14,
        "atmega8" to 0x70,
        "atmega8515" to 0x63,
        "atmega8535" to 0x64,
        "atmega16" to 0x82,
        "atmega32" to 0x91,
        "atmega48" to 0x59,
        "atmega48pb" to 0x59,
        "atmega88" to 0x73,
        "atmega88pb" to 0x73,
        "atmega168" to 0x86,
        "atmega168pb" to 0x86,
        "atmega328" to 0x86,
        "atmega328p" to 0x86,
        "atmega328pb" to 0x86,
        "atmega64" to 0xA0,
        "atmega1284" to 0xB2,
        "atmega128" to 0xB2,
        "atmega2560" to 0xB2,
        "atmega2561" to 0xB2,
        "atmega32u4" to 0xB2,
        "at90usb1286" to 0xB2
    )

    fun forDeviceId(id: String): Int = codes[id] ?: 0x00
}
