package com.avrprog.android.protocol

import com.avrprog.android.device.DeviceDatabase
import com.avrprog.android.protocol.arduino.ArduinoBoards
import com.avrprog.android.protocol.arduino.ArduinoProtocol
import com.avrprog.android.protocol.avr109.Avr109Programmer
import com.avrprog.android.protocol.stk500v1.Stk500v1Programmer
import com.avrprog.android.protocol.usbasp.UsbaspConstants
import com.avrprog.android.protocol.usbasp.UsbaspProgrammer
import com.avrprog.android.usb.SerialTransport
import com.avrprog.android.usb.UsbTransport

/**
 * Registry of programmers this project targets, per the brief's "port as many
 * AVRDUDE-supported programmers as possible" requirement. USB vendor/product
 * IDs below are copied from AVRDUDE's src/avrdude.conf.in `usbvid`/`usbpid`
 * fields (see AVRDUDE_PORTING.md) -- none are invented. "usbasp" (control-
 * transfer USB), "stk500v1" (genuine STK500 hardware, serial), and the
 * per-board `arduino-*` entries (Arduino bootloader uploads, serial -- see
 * ArduinoBoards.kt) have working implementations; everything else is a real,
 * sourced descriptor for a programmer this project does not implement yet --
 * see PROGRAMMERS.md for the authoritative status table.
 */
object ProgrammerRegistry {

    val descriptors: List<ProgrammerInfo> = buildList {
        add(
            ProgrammerInfo(
                "usbasp", "USBasp", UsbaspConstants.KNOWN_VID_PID.map { it.first }, UsbaspConstants.KNOWN_VID_PID.map { it.second },
                "USBasp vendor-specific control transfers wrapping AVR ISP", "USB", implemented = true
            )
        )
        add(
            ProgrammerInfo(
                "usbtiny", "USBtinyISP", listOf(0x1781), listOf(0x0C9F),
                "USBtiny vendor control transfers (bit-banged SPI in AVR firmware)", "USB", implemented = false
            )
        )
        add(
            ProgrammerInfo(
                "avrispmkII", "AVR ISP mkII", listOf(0x03EB), listOf(0x2104),
                "STK500v2 command-response protocol over USB", "USB", implemented = false
            )
        )
        add(
            ProgrammerInfo(
                "jtagmkII", "JTAG ICE mkII", listOf(0x03EB), listOf(0x2103),
                "JTAGICE mkII command protocol", "USB", implemented = false
            )
        )
        add(
            ProgrammerInfo(
                "jtag3", "JTAGICE3 / Xplained (JTAG/PDI/UPDI/ISP modes)", listOf(0x03EB), listOf(0x2110, 0x2140),
                "EDBG/JTAGICE3 framed command protocol", "USB", implemented = false
            )
        )
        add(
            ProgrammerInfo(
                "dragon_isp", "AVR Dragon (ISP mode)", listOf(0x03EB), listOf(0x2107),
                "JTAGICE mkII-derived command protocol", "USB", implemented = false
            )
        )
        add(
            ProgrammerInfo(
                "dragon_jtag", "AVR Dragon (JTAG mode)", listOf(0x03EB), listOf(0x2107),
                "JTAGICE mkII-derived command protocol", "USB", implemented = false
            )
        )
        add(
            ProgrammerInfo(
                "stk600", "STK600", listOf(0x03EB), listOf(0x2106),
                "STK500v2 command-response protocol", "USB", implemented = false
            )
        )
        // Serial-only programmers: reached over any USB-UART adapter (CH340,
        // FTDI, CP210x, CDC-ACM...), not a fixed VID/PID -- see
        // SerialDeviceScanner / USB_SUPPORT.md.
        add(
            ProgrammerInfo(
                "stk500v1", "STK500 (v1) -- real hardware", emptyList(), emptyList(),
                "STK500 v1 synchronous serial protocol", "Serial (USB-UART, 115200 8N1)", implemented = true
            )
        )
        add(ProgrammerInfo("stk500v2", "STK500 v2", emptyList(), emptyList(), "STK500v2 command-response protocol", "Serial (USB-UART)", implemented = false))
        add(
            ProgrammerInfo(
                "arduino-as-isp", "Arduino as ISP (programming other chips)", emptyList(), emptyList(),
                "STK500v1-derived protocol used by the ArduinoISP sketch", "USB-CDC serial", implemented = false
            )
        )
        add(ProgrammerInfo("serialupdi", "SerialUPDI", emptyList(), emptyList(), "UPDI-over-UART link layer + NVM controller protocol", "Serial (USB-UART)", implemented = false))

        // Arduino board bootloader uploads (uploading TO the board's own
        // flash via its resident bootloader -- a different thing from
        // "Arduino as ISP" above, which uses an Arduino to program OTHER
        // chips). One descriptor per real board from ArduinoBoards.kt.
        addAll(
            ArduinoBoards.boards.map { board ->
                val protocolName = when (board.protocol) {
                    ArduinoProtocol.STK500V1 -> "STK500v1 bootloader (Optiboot and similar)"
                    ArduinoProtocol.AVR109 -> "AVR109 / Caterina bootloader"
                }
                ProgrammerInfo(
                    id = "arduino-${board.id}",
                    name = board.displayName,
                    vendorIds = emptyList(),
                    productIds = emptyList(),
                    protocol = protocolName,
                    transport = "Serial (USB-UART, ${board.baudRate} baud)",
                    implemented = board.implemented
                )
            }
        )
    }

    fun matchByVidPid(vid: Int, pid: Int): ProgrammerInfo? =
        descriptors.firstOrNull { d -> d.vendorIds.zip(d.productIds).any { (v, p) -> v == vid && p == pid } }

    /** True for programmers reached over a USB-UART adapter rather than USB control transfers -- see [SerialTransport]/[create]. */
    fun isSerialTransport(id: String): Boolean = id in SERIAL_IDS || id.startsWith("arduino-")

    /** True for programmers that talk to a bootloader rather than a dedicated ISP programmer -- chip erase isn't a meaningful operation for these (see Stk500v1Programmer/Avr109Programmer.chipErase()). */
    fun isBootloaderTarget(id: String): Boolean = id.startsWith("arduino-")

    fun create(id: String, transport: UsbTransport): Programmer = when (id) {
        "usbasp" -> UsbaspProgrammer(transport)
        else -> throw NotYetImplementedProgrammer(id)
    }

    fun createSerial(id: String, transport: SerialTransport): Programmer {
        if (id == "stk500v1") return Stk500v1Programmer(transport)
        if (id.startsWith("arduino-")) {
            val boardId = id.removePrefix("arduino-")
            val board = ArduinoBoards.findById(boardId) ?: throw NotYetImplementedProgrammer(id)
            if (!board.implemented) throw NotYetImplementedProgrammer(id)
            val device = DeviceDatabase.findById(board.deviceId)
                ?: throw IllegalStateException("Board '${board.displayName}' references unknown device id '${board.deviceId}'")
            return when (board.protocol) {
                ArduinoProtocol.STK500V1 -> Stk500v1Programmer(
                    transport = transport,
                    baudRate = board.baudRate,
                    openResetBehavior = board.openReset,
                    closeResetBehavior = board.closeReset,
                    knownDevice = device,
                    isBootloaderTarget = true
                )
                ArduinoProtocol.AVR109 -> Avr109Programmer(
                    transport = transport,
                    baudRate = board.baudRate,
                    closeResetBehavior = board.closeReset
                )
            }
        }
        throw NotYetImplementedProgrammer(id)
    }

    private val SERIAL_IDS = setOf("stk500v1", "stk500v2", "arduino-as-isp", "serialupdi")
}

class NotYetImplementedProgrammer(id: String) :
    IllegalStateException("Programmer '$id' is a recognized descriptor but has no implementation yet -- see PROGRAMMERS.md")
