package com.avrprog.android.protocol

import com.avrprog.android.protocol.usbasp.UsbaspConstants
import com.avrprog.android.protocol.usbasp.UsbaspProgrammer
import com.avrprog.android.usb.UsbTransport

/**
 * Registry of programmers this project targets, per the brief's "port as many
 * AVRDUDE-supported programmers as possible" requirement. USB vendor/product
 * IDs below are copied from AVRDUDE's src/avrdude.conf.in `usbvid`/`usbpid`
 * fields (see AVRDUDE_PORTING.md) -- none are invented. Only "usbasp" has a
 * working [create] path today; everything else is a real, sourced descriptor
 * for a programmer this project does not implement yet -- see PROGRAMMERS.md
 * for the authoritative status table and the brief's required
 * FEATURE/STATUS/REASON/AVRDUDE-SOURCE-REFERENCE format for why.
 */
object ProgrammerRegistry {

    val descriptors: List<ProgrammerInfo> = listOf(
        ProgrammerInfo(
            "usbasp", "USBasp", UsbaspConstants.KNOWN_VID_PID.map { it.first }, UsbaspConstants.KNOWN_VID_PID.map { it.second },
            "USBasp vendor-specific control transfers wrapping AVR ISP", "USB", implemented = true
        ),
        ProgrammerInfo(
            "usbtiny", "USBtinyISP", listOf(0x1781), listOf(0x0C9F),
            "USBtiny vendor control transfers (bit-banged SPI in AVR firmware)", "USB", implemented = false
        ),
        ProgrammerInfo(
            "avrispmkII", "AVR ISP mkII", listOf(0x03EB), listOf(0x2104),
            "STK500v2 command-response protocol over USB", "USB", implemented = false
        ),
        ProgrammerInfo(
            "jtagmkII", "JTAG ICE mkII", listOf(0x03EB), listOf(0x2103),
            "JTAGICE mkII command protocol", "USB", implemented = false
        ),
        ProgrammerInfo(
            "jtag3", "JTAGICE3 / Xplained (JTAG/PDI/UPDI/ISP modes)", listOf(0x03EB), listOf(0x2110, 0x2140),
            "EDBG/JTAGICE3 framed command protocol", "USB", implemented = false
        ),
        ProgrammerInfo(
            "dragon_isp", "AVR Dragon (ISP mode)", listOf(0x03EB), listOf(0x2107),
            "JTAGICE mkII-derived command protocol", "USB", implemented = false
        ),
        ProgrammerInfo(
            "dragon_jtag", "AVR Dragon (JTAG mode)", listOf(0x03EB), listOf(0x2107),
            "JTAGICE mkII-derived command protocol", "USB", implemented = false
        ),
        ProgrammerInfo(
            "stk600", "STK600", listOf(0x03EB), listOf(0x2106),
            "STK500v2 command-response protocol", "USB", implemented = false
        ),
        // Serial-only programmers: AVRDUDE reaches these over a UART/USB-UART
        // adapter, not a fixed VID/PID -- see USB_SUPPORT.md for the planned
        // usb-serial-for-android integration (FTDI/CP210x/CH340/CDC-ACM).
        ProgrammerInfo("stk500v1", "STK500 (v1)", emptyList(), emptyList(), "STK500 v1 synchronous serial protocol", "Serial (USB-UART)", implemented = false),
        ProgrammerInfo("stk500v2", "STK500 v2", emptyList(), emptyList(), "STK500v2 command-response protocol", "Serial (USB-UART)", implemented = false),
        ProgrammerInfo("arduino", "Arduino as ISP", emptyList(), emptyList(), "STK500v1-derived protocol used by the ArduinoISP sketch", "USB-CDC serial", implemented = false),
        ProgrammerInfo("serialupdi", "SerialUPDI", emptyList(), emptyList(), "UPDI-over-UART link layer + NVM controller protocol", "Serial (USB-UART)", implemented = false)
    )

    fun matchByVidPid(vid: Int, pid: Int): ProgrammerInfo? =
        descriptors.firstOrNull { d -> d.vendorIds.zip(d.productIds).any { (v, p) -> v == vid && p == pid } }

    fun create(id: String, transport: UsbTransport): Programmer = when (id) {
        "usbasp" -> UsbaspProgrammer(transport)
        else -> throw NotYetImplementedProgrammer(id)
    }
}

class NotYetImplementedProgrammer(id: String) :
    IllegalStateException("Programmer '$id' is a recognized descriptor but has no implementation yet -- see PROGRAMMERS.md")
