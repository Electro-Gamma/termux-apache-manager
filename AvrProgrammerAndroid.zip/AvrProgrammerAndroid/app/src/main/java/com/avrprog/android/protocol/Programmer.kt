package com.avrprog.android.protocol

import com.avrprog.android.device.AvrDevice
import com.avrprog.android.memory.MemoryImage

data class ProgrammerInfo(
    val id: String,
    val name: String,
    val vendorIds: List<Int>,
    val productIds: List<Int>,
    val protocol: String,
    val transport: String,
    val implemented: Boolean
)

/**
 * Common interface every AVRDUDE-style programmer backend implements. The
 * engine (engine/AvrDudeEngine.kt) and UI only ever talk to this interface --
 * see project brief section 17 ("Do not place programming logic directly
 * inside UI code").
 */
interface Programmer {
    val info: ProgrammerInfo

    fun open()
    fun close()

    fun readSignature(): ByteArray
    fun chipErase()
    fun readMemory(memoryName: String, device: AvrDevice, onProgress: (done: Int, total: Int) -> Unit = { _, _ -> }): MemoryImage
    fun writeMemory(memoryName: String, device: AvrDevice, image: MemoryImage, onProgress: (done: Int, total: Int) -> Unit = { _, _ -> })
    fun setSckOption(id: Int)
}
