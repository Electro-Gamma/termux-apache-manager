package com.avrprog.android.usb

/**
 * Abstraction over a byte-stream serial connection (USB-UART adapter), so
 * serial-transport programmer protocols (STK500v1, and future STK500v2/
 * Arduino-as-ISP/SerialUPDI) depend on this interface instead of a specific
 * USB-serial library -- exactly the same reason [UsbTransport] exists for
 * the control-transfer-based programmers. Makes protocol logic testable
 * with a mock, no physical adapter required.
 */
interface SerialTransport {
    /** Opens the underlying port at the given baud rate, 8 data bits, 1 stop bit, no parity. */
    fun open(baudRate: Int)

    fun write(bytes: ByteArray, timeoutMs: Int)

    /** Blocks until exactly [length] bytes have been read into [buffer], or throws on timeout. */
    fun readExactly(buffer: ByteArray, length: Int, timeoutMs: Int)

    fun close()
}
