package com.avrprog.android.device

/**
 * A curated subset of AVRDUDE's device database (src/avrdude.conf.in), covering
 * common classic-AVR ISP-programmable parts. Every signature and flash/EEPROM
 * size below was read directly out of avrdude.conf.in's `part` blocks (or their
 * `parent` chain) -- none are invented. See DEVICE_DATABASE.md for the full
 * source mapping and for how to extend this table with more parts (there are
 * 300+ in the full AVRDUDE config, including the UPDI/PDI/TPI/XMEGA families
 * this phase does not yet cover -- see PROTOCOLS.md).
 */
object DeviceDatabase {
    private val ISP = setOf(ProgrammingInterface.ISP)

    val devices: List<AvrDevice> = listOf(
        AvrDevice("attiny13",    "ATtiny13",    intArrayOf(0x1E, 0x90, 0x07),   1_024,  32,    64, 4, ISP),
        AvrDevice("attiny2313",  "ATtiny2313",  intArrayOf(0x1E, 0x91, 0x0A),   2_048,  32,   128, 4, ISP),
        AvrDevice("attiny25",    "ATtiny25",    intArrayOf(0x1E, 0x91, 0x08),   2_048,  32,   128, 4, ISP),
        AvrDevice("attiny45",    "ATtiny45",    intArrayOf(0x1E, 0x92, 0x06),   4_096,  64,   256, 4, ISP),
        AvrDevice("attiny85",    "ATtiny85",    intArrayOf(0x1E, 0x93, 0x0B),   8_192,  64,   512, 4, ISP),
        AvrDevice("atmega8",     "ATmega8",     intArrayOf(0x1E, 0x93, 0x07),   8_192,  64,   512, 4, ISP),
        AvrDevice("atmega8515",  "ATmega8515",  intArrayOf(0x1E, 0x93, 0x06),   8_192,  64,   512, 4, ISP),
        AvrDevice("atmega8535",  "ATmega8535",  intArrayOf(0x1E, 0x93, 0x08),   8_192,  64,   512, 4, ISP),
        AvrDevice("atmega16",    "ATmega16",    intArrayOf(0x1E, 0x94, 0x03),  16_384, 128,   512, 4, ISP),
        AvrDevice("atmega32",    "ATmega32",    intArrayOf(0x1E, 0x95, 0x02),  32_768, 128, 1_024, 4, ISP),
        AvrDevice("atmega48",    "ATmega48",    intArrayOf(0x1E, 0x92, 0x05),   4_096,  64,   256, 4, ISP, chipEraseDelayMs = 45),
        AvrDevice("atmega48pb",  "ATmega48PB",  intArrayOf(0x1E, 0x92, 0x10),   4_096,  64,   256, 4, ISP, chipEraseDelayMs = 11),
        AvrDevice("atmega88",    "ATmega88",    intArrayOf(0x1E, 0x93, 0x0A),   8_192,  64,   512, 4, ISP),
        AvrDevice("atmega88pb",  "ATmega88PB",  intArrayOf(0x1E, 0x93, 0x16),   8_192,  64,   512, 4, ISP, chipEraseDelayMs = 11),
        AvrDevice("atmega168",   "ATmega168",   intArrayOf(0x1E, 0x94, 0x06),  16_384, 128,   512, 4, ISP),
        AvrDevice("atmega168pb", "ATmega168PB", intArrayOf(0x1E, 0x94, 0x15),  16_384, 128,   512, 4, ISP, chipEraseDelayMs = 11),
        AvrDevice("atmega328",   "ATmega328",   intArrayOf(0x1E, 0x95, 0x14),  32_768, 128, 1_024, 4, ISP),
        AvrDevice("atmega328p",  "ATmega328P",  intArrayOf(0x1E, 0x95, 0x0F),  32_768, 128, 1_024, 4, ISP),
        AvrDevice("atmega328pb", "ATmega328PB", intArrayOf(0x1E, 0x95, 0x16),  32_768, 128, 1_024, 4, ISP, chipEraseDelayMs = 11),
        AvrDevice("atmega64",    "ATmega64",    intArrayOf(0x1E, 0x96, 0x02),  65_536, 256, 2_048, 8, ISP),
        AvrDevice("atmega1284",  "ATmega1284",  intArrayOf(0x1E, 0x97, 0x06), 131_072, 256, 4_096, 8, ISP),
        AvrDevice("atmega128",   "ATmega128",   intArrayOf(0x1E, 0x97, 0x02), 131_072, 256, 4_096, 8, ISP),
        AvrDevice("atmega2560",  "ATmega2560",  intArrayOf(0x1E, 0x98, 0x01), 262_144, 256, 4_096, 8, ISP),
        AvrDevice("atmega2561",  "ATmega2561",  intArrayOf(0x1E, 0x98, 0x02), 262_144, 256, 4_096, 8, ISP),
        AvrDevice("atmega32u4",  "ATmega32U4",  intArrayOf(0x1E, 0x95, 0x87),  32_768, 128, 1_024, 4, ISP),
        AvrDevice("atmega32u2",  "ATmega32U2",  intArrayOf(0x1E, 0x95, 0x8A),  32_768, 128, 1_024, 4, ISP),
        AvrDevice("at90usb1286", "AT90USB1286", intArrayOf(0x1E, 0x97, 0x82), 131_072, 256, 4_096, 8, ISP)
    )

    fun findBySignature(sig: ByteArray): AvrDevice? = devices.firstOrNull { it.signatureMatches(sig) }
    fun findById(id: String): AvrDevice? = devices.firstOrNull { it.id.equals(id, ignoreCase = true) }
}
