package com.avrprogrammer.android.verify

import com.avrprogrammer.android.memory.MemoryImage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class VerifierTest {

    @Test
    fun `passes when actual matches expected on every touched byte`() {
        val expected = MemoryImage(16).apply { set(0, 0xAA); set(1, 0xBB) }
        val actual = MemoryImage(16).apply { set(0, 0xAA); set(1, 0xBB); set(5, 0x99) } // extra untouched-by-expected data is fine
        val result = Verifier.verify("flash", expected, actual)
        assertTrue(result.passed)
        assertEquals(2, result.bytesChecked)
    }

    @Test
    fun `fails and reports the exact mismatching address`() {
        val expected = MemoryImage(16).apply { set(4, 0xAA) }
        val actual = MemoryImage(16).apply { set(4, 0xFF) }
        val result = Verifier.verify("flash", expected, actual)
        assertFalse(result.passed)
        assertEquals(1, result.mismatches.size)
        assertEquals(4, result.mismatches[0].address)
        assertEquals(0xAA, result.mismatches[0].expected)
        assertEquals(0xFF, result.mismatches[0].actual)
    }

    @Test
    fun `report format matches the spec's Address Expected Read layout`() {
        val expected = MemoryImage(16).apply { set(0x1234 and 0xF, 0xAA) } // keep in bounds for a 16-byte test image
        val actual = MemoryImage(16).apply { set(0x1234 and 0xF, 0xFF) }
        val report = Verifier.verify("flash", expected, actual).report()
        assertTrue(report.contains("Verification failed"))
        assertTrue(report.contains("Memory: flash"))
        assertTrue(report.contains("Expected: 0xAA"))
        assertTrue(report.contains("Read:     0xFF"))
    }

    @Test
    fun `untouched-in-expected bytes are never compared`() {
        val expected = MemoryImage(16) // nothing touched
        val actual = MemoryImage(16).apply { set(0, 0x00) } // chip has different data, but we never asked to write byte 0
        val result = Verifier.verify("flash", expected, actual)
        assertTrue(result.passed)
        assertEquals(0, result.bytesChecked)
    }
}
