package com.avrprogrammer.android.programmer.stk500v1

import com.avrprogrammer.android.transport.SerialTransport
import java.util.ArrayDeque

/**
 * A scripted [SerialTransport] for testing STK500v1 without hardware (project brief
 * section 21: "Create mock transports so protocols can be tested without physical
 * hardware"). Every [write] is recorded, and immediately answered by [responder] --
 * whatever bytes it returns are appended to a FIFO queue that subsequent [read]
 * calls drain from. This mirrors how a real STK500 target behaves closely enough for
 * protocol testing (every command gets an immediate, deterministic reply) while
 * staying a plain synchronous fake with no threading.
 *
 * Modelling the fake this way (respond-per-write rather than a blind pre-loaded byte
 * queue) is what makes it possible to correctly exercise stk500_getsync()'s "send
 * and drain twice, then loop" dance: the two throwaway drain() flushes and the real
 * synchronising read both go through the same responder, so a single canned
 * GET_SYNC -> INSYNC+OK mapping is correct for all of them.
 */
class FakeSerialTransport(private val responder: (ByteArray) -> ByteArray) : SerialTransport {
    val writes = mutableListOf<ByteArray>()
    private val pending = ArrayDeque<Byte>()

    override val isOpen: Boolean = true
    override fun open() {}
    override fun close() {}
    override fun setLineCoding(baudRate: Int, dataBits: Int, stopBits: Int, parity: Int) {}
    override fun setDtrRts(dtr: Boolean, rts: Boolean) {}

    override fun write(data: ByteArray, timeoutMs: Int) {
        val copy = data.copyOf()
        writes += copy
        for (b in responder(copy)) pending.add(b)
    }

    override fun read(buffer: ByteArray, length: Int, timeoutMs: Int): Int {
        if (pending.isEmpty()) return 0
        var n = 0
        while (n < length && pending.isNotEmpty()) {
            buffer[n++] = pending.poll()
        }
        return n
    }
}
