package com.avrprogrammer.android.memory

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MemoryImageTest {

    @Test
    fun `unwritten bytes read as 0xFF fill value`() {
        val image = MemoryImage(16)
        assertEquals(0xFF, image.get(0))
        assertFalse(image.isTouched(0))
    }

    @Test
    fun `set marks a byte as touched`() {
        val image = MemoryImage(16)
        image.set(5, 0x42)
        assertEquals(0x42, image.get(5))
        assertTrue(image.isTouched(5))
        assertFalse(image.isTouched(4))
    }

    @Test
    fun `touchedRange reflects the lowest and highest written addresses`() {
        val image = MemoryImage(1024)
        assertNull(image.touchedRange())
        image.set(100, 1)
        image.set(500, 2)
        val range = image.touchedRange()!!
        assertEquals(100, range.first)
        assertEquals(500, range.last)
    }

    @Test(expected = IllegalArgumentException::class)
    fun `rejects out-of-bounds address`() {
        val image = MemoryImage(16)
        image.get(16)
    }

    @Test
    fun `page boundary arithmetic matches a 32768-byte flash with 128-byte pages`() {
        val flashSize = 32768
        val pageSize = 128
        val numPages = flashSize / pageSize
        assertEquals(256, numPages)

        // Verify every byte address maps to exactly one page, with no gaps/overlaps.
        var pageStart = 0
        var pageCount = 0
        while (pageStart < flashSize) {
            val pageEnd = minOf(pageStart + pageSize, flashSize)
            assertEquals(pageSize, pageEnd - pageStart)
            pageStart = pageEnd
            pageCount++
        }
        assertEquals(numPages, pageCount)
    }

    @Test
    fun `page boundary arithmetic handles a final short page`() {
        // e.g. a 1024-byte EEPROM with a 6-byte "page size" that doesn't divide evenly.
        val size = 1024
        val pageSize = 6
        var pageStart = 0
        var lastPageLen = 0
        while (pageStart < size) {
            val pageEnd = minOf(pageStart + pageSize, size)
            lastPageLen = pageEnd - pageStart
            pageStart = pageEnd
        }
        assertEquals(size % pageSize, lastPageLen)
    }
}
