package com.avrprogrammer.android.device

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class DeviceDatabaseTest {

    private fun loadRealDatabase(): DeviceDatabase {
        val text = requireNotNull(javaClass.classLoader?.getResourceAsStream("devices.json")) {
            "devices.json not found on test classpath -- see app/src/test/resources/devices.json"
        }.bufferedReader().readText()
        return DeviceDatabase.parse(text)
    }

    @Test
    fun `loads every device in the bundled database without throwing`() {
        val db = loadRealDatabase()
        assertTrue("expected a non-trivial curated device set", db.devices.size >= 20)
    }

    @Test
    fun `finds ATmega328P by id`() {
        val db = loadRealDatabase()
        val part = db.byId("m328p")
        assertNotNull(part)
        assertEquals("ATmega328P", part!!.desc)
        assertEquals(32768, part.flash.size)
        assertEquals(1024, part.eeprom!!.size)
    }

    @Test
    fun `finds ATmega328P by signature`() {
        val db = loadRealDatabase()
        val part = db.bySignature(intArrayOf(0x1E, 0x95, 0x0F))
        assertNotNull(part)
        assertEquals("m328p", part!!.id)
    }

    @Test
    fun `unknown signature returns null rather than throwing`() {
        val db = loadRealDatabase()
        assertNull(db.bySignature(intArrayOf(0xDE, 0xAD, 0xBE)))
    }

    @Test
    fun `every device exposes a working pgm enable and signature read opcode`() {
        val db = loadRealDatabase()
        for (device in db.devices) {
            assertNotNull("${device.id} has no pgmEnable opcode", device.pgmEnable)
            assertNotNull("${device.id} has no signatureRead opcode", device.signatureRead)
        }
    }

    @Test
    fun `large-flash parts expose a load extended address opcode`() {
        val db = loadRealDatabase()
        val m2560 = db.byId("m2560")
        assertNotNull(m2560)
        assertTrue(m2560!!.flash.size > 0x10000)
        assertNotNull("ATmega2560 flash should have a loadExtAddr opcode", m2560.flash.loadExtAddr)
    }

    @Test
    fun `search matches partial id and description case-insensitively`() {
        val db = loadRealDatabase()
        val results = db.search("tiny13")
        assertTrue(results.isNotEmpty())
        assertTrue(results.all { it.id.contains("t13") || it.desc.contains("13", ignoreCase = true) })
    }
}
