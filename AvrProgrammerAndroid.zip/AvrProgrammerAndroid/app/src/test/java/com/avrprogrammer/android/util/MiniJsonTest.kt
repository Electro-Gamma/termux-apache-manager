package com.avrprogrammer.android.util

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MiniJsonTest {

    @Test
    fun `parses nested object with array and escapes`() {
        val json = """{"a": 1, "b": [1,2,3], "c": {"d": "hi\n\"there\""}, "e": true, "f": null}"""
        val root = MiniJson.parse(json) as JsonValue.JsonObject
        assertEquals(1, root.int("a"))
        assertEquals(listOf(1, 2, 3), root.array("b").ints())
        assertEquals("hi\n\"there\"", root.objectOrNull("c")!!.string("d"))
    }

    @Test
    fun `parses numbers including negative and exponent`() {
        val json = """{"a": -3.5, "b": 1e3, "c": 42}"""
        val root = MiniJson.parse(json) as JsonValue.JsonObject
        assertEquals(-3.5, (root["a"] as JsonValue.JsonNumber).value, 0.0001)
        assertEquals(1000.0, (root["b"] as JsonValue.JsonNumber).value, 0.0001)
        assertEquals(42, root.int("c"))
    }

    @Test(expected = JsonParseException::class)
    fun `rejects malformed json`() {
        MiniJson.parse("{\"a\": }")
    }

    @Test
    fun `round trips a devices json shaped document`() {
        val json = """
            {
              "sourceNote": "test",
              "devices": [
                {"id": "m328p", "desc": "ATmega328P", "signature": [30, 149, 15], "progModes": ["ISP"],
                 "flash": {"size": 32768, "pageSize": 128}}
              ]
            }
        """.trimIndent()
        val root = MiniJson.parse(json) as JsonValue.JsonObject
        val devices = root.array("devices").objects()
        assertEquals(1, devices.size)
        assertEquals("m328p", devices[0].string("id"))
        assertEquals(listOf(30, 149, 15), devices[0].array("signature").ints())
        assertTrue(devices[0].objectOrNull("flash")!!.int("size") == 32768)
    }
}
