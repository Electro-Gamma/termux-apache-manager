package com.avrprogrammer.android.hex

import com.avrprogrammer.android.memory.MemoryImage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * All hex string literals below were independently computed and checksum-verified
 * with a small Python script (see AVRDUDE_PORTING.md's testing notes) rather than
 * hand-typed, since Intel HEX checksums are exactly the kind of detail that's easy
 * to get subtly wrong by hand.
 */
class IntelHexTest {

    @Test
    fun `parses simple data record`() {
        val hex = ":020000000102FB\n:00000001FF\n"
        val result = IntelHexParser.parse(hex, 256)
        assertEquals(0x01, result.image.get(0))
        assertEquals(0x02, result.image.get(1))
        assertTrue(result.warnings.isEmpty())
    }

    @Test
    fun `round trips through writer and parser`() {
        val original = MemoryImage(64)
        for (i in 0 until 32) original.set(i, (i * 3) and 0xFF)
        val hex = IntelHexWriter.write(original)
        val parsed = IntelHexParser.parse(hex, 64).image
        for (i in 0 until 32) assertEquals(original.get(i), parsed.get(i))
    }

    @Test(expected = IntelHexParseException::class)
    fun `detects checksum mismatch`() {
        // Same record as the valid test above but with the checksum byte corrupted (FB -> FF).
        IntelHexParser.parse(":020000000102FF\n:00000001FF\n", 256)
    }

    @Test
    fun `checksum mismatch message mentions checksum`() {
        try {
            IntelHexParser.parse(":020000000102FF\n:00000001FF\n", 256)
            throw AssertionError("expected IntelHexParseException")
        } catch (e: IntelHexParseException) {
            assertTrue(e.message!!.contains("checksum"))
        }
    }

    @Test
    fun `detects address out of range via extended linear address`() {
        // Extended Linear Address selects segment 1 (byte offset 0x10000), then a data
        // record there -- out of range for a 256-byte target memory.
        val hex = ":020000040001F9\n:02000000AABB99\n:00000001FF\n"
        try {
            IntelHexParser.parse(hex, 256)
            throw AssertionError("expected IntelHexParseException")
        } catch (e: IntelHexParseException) {
            assertTrue(e.message!!.contains("outside"))
        }
    }

    @Test
    fun `reports missing EOF as warning not error`() {
        val hex = ":020000000102FB\n"
        val result = IntelHexParser.parse(hex, 256)
        assertTrue(result.warnings.any { it.contains("EOF") })
    }

    @Test
    fun `reports overlapping records as warning`() {
        val hex = ":020000000102FB\n:020000000304F7\n:00000001FF\n"
        val result = IntelHexParser.parse(hex, 256)
        assertTrue(result.warnings.any { it.contains("overlaps") })
    }

    @Test(expected = IntelHexParseException::class)
    fun `rejects record not starting with colon`() {
        IntelHexParser.parse("020000000102FB\n", 256)
    }

    @Test
    fun `bin round trip`() {
        val bytes = byteArrayOf(1, 2, 3, 4, 5)
        val image = BinFileIo.read(bytes, 16)
        val out = BinFileIo.write(image)
        assertEquals(5, out.size)
        assertEquals(3, out[2].toInt())
    }

    @Test
    fun `untouched bytes are not emitted as hex records`() {
        val image = MemoryImage(1024)
        image.set(500, 0xAB)
        val hex = IntelHexWriter.write(image)
        val lineCount = hex.trim().lines().size
        assertTrue("expected a small number of records, got $lineCount", lineCount <= 3)
    }
}
