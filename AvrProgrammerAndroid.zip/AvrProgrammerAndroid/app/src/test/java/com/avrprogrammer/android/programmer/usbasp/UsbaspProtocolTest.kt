package com.avrprogrammer.android.programmer.usbasp

import com.avrprogrammer.android.device.AvrDevice
import com.avrprogrammer.android.device.AvrMemoryDef
import com.avrprogrammer.android.programmer.MemoryId
import com.avrprogrammer.android.transport.MockUsbTransport
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class UsbaspProtocolTest {

    /** A minimal ATmega328P-shaped device, built the same way DeviceDatabase would, for protocol-level tests that don't need the full JSON asset. */
    private fun atmega328p(): AvrDevice = AvrDevice(
        id = "m328p", desc = "ATmega328P", signature = intArrayOf(0x1E, 0x95, 0x0F),
        progModes = listOf("ISP"), chipEraseDelayUs = 9000,
        pgmEnableTemplate = "1010.1100--0101.0011--0000.0000--0000.0000",
        chipEraseTemplate = "1010.1100--1000.0000--0000.0000--0000.0000",
        flash = AvrMemoryDef(
            "flash", size = 32768, pageSize = 128, numPages = 256,
            readLoTemplate = "0010.0000--00aa.aaaa--aaaa.aaaa--oooo.oooo",
            readHiTemplate = "0010.1000--00aa.aaaa--aaaa.aaaa--oooo.oooo",
            loadPageLoTemplate = "0100.0000--000x.xxxx--xxaa.aaaa--iiii.iiii",
            loadPageHiTemplate = "0100.1000--000x.xxxx--xxaa.aaaa--iiii.iiii",
            writePageTemplate = "0100.1100--00aa.aaaa--aaxx.xxxx--xxxx.xxxx"
        ),
        eeprom = AvrMemoryDef(
            "eeprom", size = 1024, pageSize = 4,
            readTemplate = "1010.0000--0000.00aa--aaaa.aaaa--oooo.oooo",
            loadPageLoTemplate = "1100.0001--0000.0000--0000.00aa--iiii.iiii",
            writePageTemplate = "1100.0010--0000.00aa--aaaa.aaxx--xxxx.xxxx"
        ),
        fuses = emptyList(), lock = null, calibration = null,
        signatureReadTemplate = "0011.0000--0000.0000--0000.00aa--oooo.oooo"
    )

    @Test
    fun `open sends GETCAPABILITIES then CONNECT then ENABLEPROG and succeeds on a 1-byte OK response`() {
        val calls = mutableListOf<Int>()
        val transport = MockUsbTransport(controlHandler = { _, request, _, _, _, length ->
            calls += request
            when (request) {
                5 -> byteArrayOf(0) // ENABLEPROG: real firmware returns exactly 1 byte, value 0
                else -> ByteArray(length)
            }
        })
        val programmer = UsbaspProgrammer(transport)
        programmer.open(atmega328p())

        assertTrue("expected GETCAPABILITIES (127) among the open() calls", calls.contains(127))
        assertTrue("expected CONNECT (1) among the open() calls", calls.contains(1))
        assertTrue("expected ENABLEPROG (5) among the open() calls", calls.contains(5))
        assertTrue("ENABLEPROG must be the last call (comes after CONNECT)", calls.indexOf(5) > calls.indexOf(1))
    }

    @Test
    fun `readSignature issues three TRANSMIT calls with the correct address bytes`() {
        val transmittedCommands = mutableListOf<ByteArray>()
        val sigBytes = listOf(0x1E, 0x95, 0x0F)
        val transport = MockUsbTransport(controlHandler = { _, request, value, index, _, length ->
            when (request) {
                5 -> byteArrayOf(0)
                3 -> { // TRANSMIT
                    val cmd = byteArrayOf((value and 0xFF).toByte(), ((value shr 8) and 0xFF).toByte(), (index and 0xFF).toByte(), ((index shr 8) and 0xFF).toByte())
                    transmittedCommands += cmd
                    val addr = cmd[2].toInt()
                    byteArrayOf(cmd[0], cmd[1], cmd[2], sigBytes[addr].toByte())
                }
                else -> ByteArray(length)
            }
        })
        val programmer = UsbaspProgrammer(transport)
        val device = atmega328p()
        programmer.open(device)
        val signature = programmer.readSignature(device)

        assertArrayEquals(intArrayOf(0x1E, 0x95, 0x0F), signature)
        assertEquals(3, transmittedCommands.size)
        assertArrayEquals(byteArrayOf(0x30, 0x00, 0x00, 0x00), transmittedCommands[0])
        assertArrayEquals(byteArrayOf(0x30, 0x00, 0x01, 0x00), transmittedCommands[1])
        assertArrayEquals(byteArrayOf(0x30, 0x00, 0x02, 0x00), transmittedCommands[2])
    }

    @Test
    fun `readMemory FLASH issues SETLONGADDRESS before each block and reassembles the image`() {
        val flashData = ByteArray(32768) { (it and 0xFF).toByte() }
        var lastLongAddress = -1
        val transport = MockUsbTransport(controlHandler = { _, request, value, index, _, length ->
            when (request) {
                5 -> byteArrayOf(0)
                9 -> { // SETLONGADDRESS
                    lastLongAddress = (value and 0xFFFF) or ((index and 0xFFFF) shl 16)
                    ByteArray(length)
                }
                4 -> { // READFLASH
                    val addr = lastLongAddress
                    flashData.copyOfRange(addr, addr + length)
                }
                else -> ByteArray(length)
            }
        })
        val programmer = UsbaspProgrammer(transport)
        val device = atmega328p()
        programmer.open(device)
        val image = programmer.readMemory(device, MemoryId.FLASH)

        for (i in 0 until 32768 step 4096) {
            assertEquals("mismatch at byte $i", flashData[i], image.get(i).toByte())
        }
    }
}
