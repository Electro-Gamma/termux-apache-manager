package com.avrprogrammer.android.device

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * Every expected byte sequence here is a well-known AVR ISP instruction (present in
 * any classic AVR datasheet's serial programming instruction table / AVRDUDE's
 * avrdude.conf), used as ground truth for the opcode bit-template engine -- see the
 * derivation notes in Opcode.kt for how these were cross-checked against AVRDUDE's
 * own config_gram.y/avrpart.c bit-numbering before this test was written.
 */
class OpcodeEngineTest {

    @Test
    fun `programming enable encodes to AC 53 00 00`() {
        val op = OpcodeTemplateParser.parse("1010.1100--0101.0011--0000.0000--0000.0000")
        assertArrayEquals(byteArrayOf(0xAC.toByte(), 0x53, 0x00, 0x00), op.newCommand())
    }

    @Test
    fun `chip erase encodes to AC 80 00 00`() {
        val op = OpcodeTemplateParser.parse("1010.1100--1000.0000--0000.0000--0000.0000")
        assertArrayEquals(byteArrayOf(0xAC.toByte(), 0x80.toByte(), 0x00, 0x00), op.newCommand())
    }

    @Test
    fun `read signature byte encodes address into low bits of byte 2`() {
        val op = OpcodeTemplateParser.parse("0011.0000--0000.0000--0000.00aa--oooo.oooo")
        val cmd = op.newCommand()
        op.setAddress(cmd, 1)
        assertArrayEquals(byteArrayOf(0x30, 0x00, 0x01, 0x00), cmd)
    }

    @Test
    fun `read flash low byte encodes a 14-bit word address across bytes 1 and 2`() {
        val op = OpcodeTemplateParser.parse("0010.0000--00aa.aaaa--aaaa.aaaa--oooo.oooo")
        val cmd = op.newCommand()
        op.setAddress(cmd, 0x1234)
        assertArrayEquals(byteArrayOf(0x20, 0x12, 0x34, 0x00), cmd)
    }

    @Test
    fun `write fuse low burns a full data byte into byte 3`() {
        val op = OpcodeTemplateParser.parse("1010.1100--1010.0000--xxxx.xxxx--iiii.iiii")
        val cmd = op.newCommand()
        op.setInput(cmd, 0xE2)
        assertArrayEquals(byteArrayOf(0xAC.toByte(), 0xA0.toByte(), 0x00, 0xE2.toByte()), cmd)
    }

    @Test
    fun `write efuse only touches its 3 low bits`() {
        val op = OpcodeTemplateParser.parse("1010.1100--1010.0100--xxxx.xxxx--xxxx.xiii")
        val cmd = op.newCommand()
        op.setInput(cmd, 0x05) // 0b101
        assertArrayEquals(byteArrayOf(0xAC.toByte(), 0xA4.toByte(), 0x00, 0x05), cmd)
    }

    @Test
    fun `getOutput extracts a full data byte from a response`() {
        val op = OpcodeTemplateParser.parse("0011.0000--0000.0000--0000.00aa--oooo.oooo")
        val response = byteArrayOf(0x30, 0x00, 0x01, 0x1E)
        assertEquals(0x1E, op.getOutput(response))
    }

    @Test
    fun `load extended address sets bit 16 of a word address`() {
        val op = OpcodeTemplateParser.parse("0100.1101--0000.0000--0000.000a--0000.0000", isLoadExtAddr = true)

        val cmdHigh = op.newCommand()
        op.setAddress(cmdHigh, 0x10000) // bit 16 set
        assertArrayEquals(byteArrayOf(0x4D, 0x00, 0x01, 0x00), cmdHigh)

        val cmdLow = op.newCommand()
        op.setAddress(cmdLow, 0x0FFFF) // bit 16 clear
        assertArrayEquals(byteArrayOf(0x4D, 0x00, 0x00, 0x00), cmdLow)
    }

    @Test
    fun `ignore bits do not affect fixed command bytes`() {
        val op = OpcodeTemplateParser.parse("0101.0000--0000.0000--xxxx.xxxx--oooo.oooo") // read lfuse
        val cmd = op.newCommand()
        assertArrayEquals(byteArrayOf(0x50, 0x00, 0x00, 0x00), cmd)
    }

    @Test(expected = IllegalArgumentException::class)
    fun `rejects a template that is not exactly 32 bits`() {
        OpcodeTemplateParser.parse("0000.0000--0000.0000")
    }
}
