package com.avrprogrammer.android.programmer.stk500v1

import com.avrprogrammer.android.device.AvrDevice
import com.avrprogrammer.android.device.AvrMemoryDef
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class Stk500v1ProtocolTest {

    private fun atmega328p(): AvrDevice = AvrDevice(
        id = "m328p", desc = "ATmega328P", signature = intArrayOf(0x1E, 0x95, 0x0F),
        progModes = listOf("ISP"), chipEraseDelayUs = 9000,
        pgmEnableTemplate = "1010.1100--0101.0011--0000.0000--0000.0000",
        chipEraseTemplate = "1010.1100--1000.0000--0000.0000--0000.0000",
        flash = AvrMemoryDef("flash", size = 32768, pageSize = 128,
            readLoTemplate = "0010.0000--00aa.aaaa--aaaa.aaaa--oooo.oooo",
            readHiTemplate = "0010.1000--00aa.aaaa--aaaa.aaaa--oooo.oooo",
            loadPageLoTemplate = "0100.0000--000x.xxxx--xxaa.aaaa--iiii.iiii",
            loadPageHiTemplate = "0100.1000--000x.xxxx--xxaa.aaaa--iiii.iiii",
            writePageTemplate = "0100.1100--00aa.aaaa--aaxx.xxxx--xxxx.xxxx"),
        eeprom = null, fuses = emptyList(), lock = null, calibration = null,
        signatureReadTemplate = "0011.0000--0000.0000--0000.00aa--oooo.oooo"
    )

    /** Simulates a well-behaved STK500v1 target: GET_SYNC/ENTER_PROGMODE/LEAVE_PROGMODE always succeed, and UNIVERSAL (0x56) relays a Read Signature Byte opcode against [signature]. */
    private fun happyPathResponder(signature: IntArray): (ByteArray) -> ByteArray = { written ->
        when {
            written.contentEquals(byteArrayOf(0x30, 0x20)) -> byteArrayOf(0x14, 0x10)          // GET_SYNC -> INSYNC, OK
            written.contentEquals(byteArrayOf(0x50, 0x20)) -> byteArrayOf(0x14, 0x10)          // ENTER_PROGMODE -> INSYNC, OK
            written.contentEquals(byteArrayOf(0x51, 0x20)) -> byteArrayOf(0x14, 0x10)          // LEAVE_PROGMODE -> INSYNC, OK
            written.size == 6 && written[0] == 0x56.toByte() && written[5] == 0x20.toByte() -> {
                val cmd0 = written[1].toInt() and 0xFF
                val cmd2 = written[3].toInt() and 0xFF
                val dataByte = if (cmd0 == 0x30 && cmd2 in signature.indices) signature[cmd2] else 0x00
                byteArrayOf(0x14, dataByte.toByte(), 0x10) // INSYNC, data, OK
            }
            else -> ByteArray(0)
        }
    }

    @Test
    fun `open performs GET_SYNC then ENTER_PROGMODE`() {
        val serial = FakeSerialTransport(happyPathResponder(intArrayOf(0x1E, 0x95, 0x0F)))
        val programmer = Stk500v1Programmer(serial)
        programmer.open(atmega328p())

        assertTrue("expected at least one GET_SYNC frame", serial.writes.any { it.contentEquals(byteArrayOf(0x30, 0x20)) })
        assertTrue("expected an ENTER_PROGMODE frame", serial.writes.any { it.contentEquals(byteArrayOf(0x50, 0x20)) })
        val syncIndex = serial.writes.indexOfLast { it.contentEquals(byteArrayOf(0x30, 0x20)) }
        val progIndex = serial.writes.indexOfFirst { it.contentEquals(byteArrayOf(0x50, 0x20)) }
        assertTrue("ENTER_PROGMODE must come after the last GET_SYNC", progIndex > syncIndex)
    }

    @Test
    fun `readSignature relays three UNIVERSAL commands and decodes the response`() {
        val signature = intArrayOf(0x1E, 0x95, 0x0F)
        val serial = FakeSerialTransport(happyPathResponder(signature))
        val programmer = Stk500v1Programmer(serial)
        val device = atmega328p()
        programmer.open(device)

        val readSignature = programmer.readSignature(device)
        assertArrayEquals(signature, readSignature)

        val universalFrames = serial.writes.filter { it.size == 6 && it[0] == 0x56.toByte() }
        assertTrue("expected 3 UNIVERSAL frames for a 3-byte signature", universalFrames.size == 3)
        // cmd bytes for Read Signature at addr 0,1,2: 30 00 0X 00
        assertArrayEquals(byteArrayOf(0x56, 0x30, 0x00, 0x00, 0x00, 0x20), universalFrames[0])
        assertArrayEquals(byteArrayOf(0x56, 0x30, 0x00, 0x01, 0x00, 0x20), universalFrames[1])
        assertArrayEquals(byteArrayOf(0x56, 0x30, 0x00, 0x02, 0x00, 0x20), universalFrames[2])
    }

    @Test
    fun `close sends LEAVE_PROGMODE`() {
        val serial = FakeSerialTransport(happyPathResponder(intArrayOf(0x1E, 0x95, 0x0F)))
        val programmer = Stk500v1Programmer(serial)
        val device = atmega328p()
        programmer.open(device)
        programmer.close()

        assertTrue(serial.writes.any { it.contentEquals(byteArrayOf(0x51, 0x20)) })
    }

    @Test(expected = com.avrprogrammer.android.errors.ProtocolException::class)
    fun `open fails cleanly when the target never syncs`() {
        val serial = FakeSerialTransport { ByteArray(0) } // never responds
        val programmer = Stk500v1Programmer(serial)
        programmer.open(atmega328p())
    }
}
