package com.avrprog.android.protocol.avr109

import com.avrprog.android.device.DeviceDatabase
import com.avrprog.android.error.ProtocolException
import com.avrprog.android.memory.MemoryImage
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class Avr109PacketTest {

    @Test
    fun `open() runs the full handshake then enters programming mode`() {
        val mock = MockAvr109Transport()
        val programmer = Avr109Programmer(mock)
        programmer.open()

        // S(identifier), V(version), p(programmer type), b(block support), T(select device), P(enter prog mode)
        assertEquals(listOf('S'.code, 'V'.code, 'p'.code, 'b'.code, 'T'.code, 'P'.code), mock.calls)
    }

    @Test
    fun `select device type sends this project's ATmega32U4 device code`() {
        val mock = MockAvr109Transport()
        val programmer = Avr109Programmer(mock)
        programmer.open()

        assertEquals(0x44, mock.deviceCode)
    }

    @Test
    fun `readSignature reverses the wire byte order back to standard order`() {
        val mock = MockAvr109Transport(signature = byteArrayOf(0x1E, 0x95.toByte(), 0x87.toByte())) // ATmega32U4
        val programmer = Avr109Programmer(mock)
        programmer.open()

        assertArrayEquals(byteArrayOf(0x1E, 0x95.toByte(), 0x87.toByte()), programmer.readSignature())
    }

    @Test
    fun `chip erase always throws -- AVR109 bootloaders have no erase command`() {
        val mock = MockAvr109Transport()
        val programmer = Avr109Programmer(mock)
        programmer.open()

        assertThrows(ProtocolException::class.java) { programmer.chipErase() }
    }

    @Test
    fun `write then read flash round-trips using word addressing`() {
        val device = DeviceDatabase.findById("atmega32u4")!!
        val mock = MockAvr109Transport(flashSize = device.flashSize)
        val programmer = Avr109Programmer(mock)
        programmer.open()

        val image = MemoryImage(device.flashSize)
        for (i in 0 until 300) image.set(i, ((i * 3) and 0xFF).toByte()) // spans multiple 128-byte pages

        programmer.writeMemory("flash", device, image)
        val readBack = programmer.readMemory("flash", device)

        for (i in 0 until 300) assertEquals("byte at $i", image.get(i), readBack.get(i))
    }
}
