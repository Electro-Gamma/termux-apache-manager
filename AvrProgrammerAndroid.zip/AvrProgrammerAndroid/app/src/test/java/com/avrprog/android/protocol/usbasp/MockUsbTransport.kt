package com.avrprog.android.protocol.usbasp

import com.avrprog.android.usb.UsbTransport

data class RecordedTransfer(val requestType: Int, val request: Int, val value: Int, val index: Int, val length: Int)

/**
 * Minimal in-memory USBasp firmware simulator, used only by unit tests (brief
 * section 21: "mock transports so protocols can be tested without physical
 * hardware"). It understands just enough of the real command set to exercise
 * UsbaspProgrammer's request framing -- it is NOT a model of real firmware
 * timing/edge-case behaviour.
 */
class MockUsbTransport(private val memSize: Int = 32_768, private val signature: ByteArray = byteArrayOf(0x1E, 0x95.toByte(), 0x0F)) : UsbTransport {
    override val vendorId = UsbaspConstants.USBASP_SHARED_VID
    override val productId = UsbaspConstants.USBASP_SHARED_PID

    val calls = mutableListOf<RecordedTransfer>()
    val flash = ByteArray(memSize) { 0xFF.toByte() }
    private var longAddress = 0

    override fun controlTransfer(requestType: Int, request: Int, value: Int, index: Int, buffer: ByteArray?, length: Int, timeoutMs: Int): Int {
        calls += RecordedTransfer(requestType, request, value, index, length)
        return when (request) {
            UsbaspConstants.FUNC_GETCAPABILITIES -> { fill(buffer, byteArrayOf(0, 0, 0, 0)); 4 }
            UsbaspConstants.FUNC_CONNECT -> 0
            UsbaspConstants.FUNC_SETISPSCK -> 0
            UsbaspConstants.FUNC_ENABLEPROG -> { fill(buffer, byteArrayOf(0)); 1 }
            UsbaspConstants.FUNC_SETLONGADDRESS -> {
                longAddress = (value and 0xFFFF) or ((index and 0xFFFF) shl 16)
                0
            }
            UsbaspConstants.FUNC_TRANSMIT -> {
                val cmd = byteArrayOf(
                    (value and 0xFF).toByte(), ((value shr 8) and 0xFF).toByte(),
                    (index and 0xFF).toByte(), ((index shr 8) and 0xFF).toByte()
                )
                fill(buffer, handleSpiCmd(cmd))
                4
            }
            UsbaspConstants.FUNC_READFLASH -> {
                for (i in 0 until length) buffer?.set(i, flash[(longAddress + i) % memSize])
                length
            }
            UsbaspConstants.FUNC_WRITEFLASH -> {
                buffer?.let { for (i in 0 until length) flash[(longAddress + i) % memSize] = it[i] }
                length
            }
            else -> length
        }
    }

    override fun bulkTransfer(endpointAddress: Int, buffer: ByteArray, length: Int, timeoutMs: Int): Int = length
    override fun close() {}

    private fun handleSpiCmd(cmd: ByteArray): ByteArray {
        if (cmd[0] == 0x30.toByte() && cmd[1] == 0x00.toByte()) { // Read Signature Byte
            val idx = cmd[2].toInt()
            val sigByte: Byte = if (idx in 0..2) signature[idx] else 0
            return byteArrayOf(cmd[0], cmd[1], cmd[2], sigByte)
        }
        if (cmd[0] == 0xAC.toByte() && cmd[1] == 0x80.toByte()) { // Chip Erase
            for (i in flash.indices) flash[i] = 0xFF.toByte()
            return byteArrayOf(cmd[0], cmd[1], cmd[2], cmd[3])
        }
        return byteArrayOf(0, 0, 0, 0)
    }

    private fun fill(buffer: ByteArray?, data: ByteArray) {
        buffer ?: return
        for (i in data.indices) if (i < buffer.size) buffer[i] = data[i]
    }
}
