package com.avrprog.android.protocol.stk500v1

import com.avrprog.android.usb.SerialTransport

/**
 * A software model of an STK500v1-speaking target, built directly against
 * the same command bytes Stk500v1Programmer sends, so the real protocol
 * class can be exercised end-to-end (sync -> program mode -> chip erase ->
 * extended-address-aware paged flash/EEPROM read+write) without physical
 * hardware -- brief section 21.
 */
class MockStk500v1Transport(flashSize: Int = 32_768) : SerialTransport {

    val flash = ByteArray(flashSize) { 0xFF.toByte() }
    var signature = byteArrayOf(0x1E, 0x95.toByte(), 0x0F) // ATmega328P by default
    var erased = false
        private set

    /** Every command byte-0 seen, in order -- lets tests assert call sequence/counts like MockUsbTransport does for USBasp. */
    val calls = mutableListOf<Int>()

    private var loadedAddr16 = 0
    private var extAddrByte = 0
    private val rx = ArrayDeque<Byte>()

    override fun open(baudRate: Int) { /* nothing to simulate */ }

    override fun write(bytes: ByteArray, timeoutMs: Int) {
        val opcode = bytes[0].toInt() and 0xFF
        calls += opcode
        when (opcode) {
            0x30, 0x50, 0x51 -> respond(INSYNC, OK) // GET_SYNC, ENTER_PROGMODE, LEAVE_PROGMODE
            0x55 -> { // LOAD_ADDRESS
                loadedAddr16 = (bytes[1].toInt() and 0xFF) or ((bytes[2].toInt() and 0xFF) shl 8)
                respond(INSYNC, OK)
            }
            0x56 -> { // UNIVERSAL (generic ISP passthrough)
                val cmd0 = bytes[1].toInt() and 0xFF
                val cmd1 = bytes[2].toInt() and 0xFF
                val respByte = when {
                    cmd0 == 0x30 -> { // read signature byte
                        val idx = bytes[3].toInt() and 0xFF
                        signature.getOrElse(idx) { 0 }.toInt() and 0xFF
                    }
                    cmd0 == 0xAC && cmd1 == 0x80 -> { // chip erase
                        erased = true
                        for (i in flash.indices) flash[i] = 0xFF.toByte()
                        0
                    }
                    cmd0 == 0x4d -> { // load extended address byte
                        extAddrByte = bytes[3].toInt() and 0xFF
                        0
                    }
                    else -> 0
                }
                respond(INSYNC, respByte, OK)
            }
            0x64 -> { // PROG_PAGE
                val blockSize = ((bytes[1].toInt() and 0xFF) shl 8) or (bytes[2].toInt() and 0xFF)
                val memChar = bytes[3].toInt() and 0xFF
                val aDiv = if (memChar == 'F'.code) 2 else 1
                val byteAddr = (((extAddrByte shl 16) or loadedAddr16) * aDiv)
                for (i in 0 until blockSize) {
                    val a = byteAddr + i
                    if (a < flash.size) flash[a] = bytes[4 + i]
                }
                respond(INSYNC, OK)
            }
            0x74 -> { // READ_PAGE
                val blockSize = ((bytes[1].toInt() and 0xFF) shl 8) or (bytes[2].toInt() and 0xFF)
                val memChar = bytes[3].toInt() and 0xFF
                val aDiv = if (memChar == 'F'.code) 2 else 1
                val byteAddr = (((extAddrByte shl 16) or loadedAddr16) * aDiv)
                rx.addLast(INSYNC.toByte())
                for (i in 0 until blockSize) {
                    val a = byteAddr + i
                    rx.addLast(if (a < flash.size) flash[a] else 0xFF.toByte())
                }
                rx.addLast(OK.toByte())
            }
            else -> respond(INSYNC, OK)
        }
    }

    override fun readExactly(buffer: ByteArray, length: Int, timeoutMs: Int) {
        for (i in 0 until length) {
            buffer[i] = rx.removeFirstOrNull()
                ?: throw IllegalStateException("MockStk500v1Transport: no more simulated response bytes available")
        }
    }

    override fun close() { /* nothing to simulate */ }

    private fun respond(vararg values: Int) {
        for (v in values) rx.addLast(v.toByte())
    }

    companion object {
        const val INSYNC = 0x14
        const val OK = 0x10
    }
}
