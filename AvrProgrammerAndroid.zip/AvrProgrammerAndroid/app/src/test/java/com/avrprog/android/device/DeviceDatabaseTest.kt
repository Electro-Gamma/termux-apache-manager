package com.avrprog.android.device

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class DeviceDatabaseTest {

    @Test
    fun `finds ATmega328P by its real signature`() {
        val device = DeviceDatabase.findBySignature(byteArrayOf(0x1E, 0x95.toByte(), 0x0F))
        assertNotNull(device)
        assertEquals("atmega328p", device!!.id)
        assertEquals(32_768, device.flashSize)
        assertEquals(1_024, device.eepromSize)
    }

    @Test
    fun `finds ATtiny85 by its real signature`() {
        val device = DeviceDatabase.findBySignature(byteArrayOf(0x1E, 0x93.toByte(), 0x0B))
        assertNotNull(device)
        assertEquals("attiny85", device!!.id)
        assertEquals(8_192, device.flashSize)
    }

    @Test
    fun `unknown signature returns null rather than a guess`() {
        assertNull(DeviceDatabase.findBySignature(byteArrayOf(0x00, 0x00, 0x00)))
    }

    @Test
    fun `findById is case-insensitive`() {
        assertEquals(DeviceDatabase.findById("ATmega328P"), DeviceDatabase.findById("atmega328p"))
    }

    @Test
    fun `every device has a unique id and a 3-byte signature`() {
        val ids = DeviceDatabase.devices.map { it.id }
        assertEquals(ids.size, ids.toSet().size)
        DeviceDatabase.devices.forEach { assertEquals(3, it.signature.size) }
    }
}
