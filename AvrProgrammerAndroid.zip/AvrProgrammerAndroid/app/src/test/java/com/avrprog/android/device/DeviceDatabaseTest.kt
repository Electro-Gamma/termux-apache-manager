package com.avrprog.android.device

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class DeviceDatabaseTest {

    @Test
    fun `finds ATmega328P by its real signature`() {
        val device = DeviceDatabase.findBySignature(byteArrayOf(0x1E, 0x95.toByte(), 0x0F))
        assertNotNull(device)
        assertEquals("atmega328p", device!!.id)
        assertEquals(32_768, device.flashSize)
        assertEquals(1_024, device.eepromSize)
    }

    @Test
    fun `finds device case-insensitively by id`() {
        assertNotNull(DeviceDatabase.findById("ATmega328P"))
        assertNotNull(DeviceDatabase.findById("attiny85"))
    }

    @Test
    fun `unknown signature returns null rather than a fabricated match`() {
        assertNull(DeviceDatabase.findBySignature(byteArrayOf(0xDE.toByte(), 0xAD.toByte(), 0xBE.toByte())))
    }

    @Test
    fun `every entry has a distinct 3-byte signature`() {
        val signatures = DeviceDatabase.devices.map { it.signatureHex() }
        assertEquals(signatures.size, signatures.toSet().size)
    }
}
