package com.avrprog.android.protocol.stk500v1

import com.avrprog.android.device.DeviceDatabase
import com.avrprog.android.error.ProtocolException
import com.avrprog.android.memory.MemoryImage
import com.avrprog.android.protocol.arduino.ArduinoResetBehavior
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test

class Stk500v1PacketTest {

    @Test
    fun `open() gets sync then enters program mode in order`() {
        val mock = MockStk500v1Transport()
        val programmer = Stk500v1Programmer(mock)
        programmer.open()

        assertEquals(listOf(0x30, 0x50), mock.calls) // CMND_STK_GET_SYNC, CMND_STK_ENTER_PROGMODE
    }

    @Test
    fun `board-aware open() applies reset, gets sync, sends SET_DEVICE with the real device's sizes, then enters program mode`() {
        val mock = MockStk500v1Transport()
        val device = DeviceDatabase.findById("atmega328p")!!
        val programmer = Stk500v1Programmer(
            mock,
            baudRate = 115_200,
            openResetBehavior = ArduinoResetBehavior.DtrToggle(true),
            knownDevice = device,
            isBootloaderTarget = true
        )
        programmer.open()

        assertEquals(listOf(true), mock.dtrHistory) // reset behavior applied before protocol talk
        assertEquals(listOf(0x30, 0x41, 0x41, 0x42, 0x50), mock.calls) // sync, 2x GET_PARAMETER, SET_DEVICE, ENTER_PROGMODE

        val setDeviceBuf = mock.lastSetDeviceBuf!!
        val flashPageSize = ((setDeviceBuf[13].toInt() and 0xFF) shl 8) or (setDeviceBuf[14].toInt() and 0xFF)
        val flashSize = ((setDeviceBuf[17].toInt() and 0xFF) shl 24) or ((setDeviceBuf[18].toInt() and 0xFF) shl 16) or
            ((setDeviceBuf[19].toInt() and 0xFF) shl 8) or (setDeviceBuf[20].toInt() and 0xFF)
        assertEquals(device.flashPageSize, flashPageSize)
        assertEquals(device.flashSize, flashSize)
    }

    @Test
    fun `chip erase on a bootloader target throws instead of sending a meaningless command`() {
        val mock = MockStk500v1Transport()
        val device = DeviceDatabase.findById("atmega328p")!!
        val programmer = Stk500v1Programmer(mock, knownDevice = device, isBootloaderTarget = true)
        programmer.open()

        assertThrows(ProtocolException::class.java) { programmer.chipErase() }
    }

    @Test
    fun `readSignature returns the mock device's configured signature`() {
        val mock = MockStk500v1Transport(signature = byteArrayOf(0x1E, 0x95.toByte(), 0x0F)) // ATmega328P
        val programmer = Stk500v1Programmer(mock)
        programmer.open()

        assertArrayEquals(byteArrayOf(0x1E, 0x95.toByte(), 0x0F), programmer.readSignature())
    }

    @Test
    fun `chip erase clears flash to 0xFF and re-syncs`() {
        val mock = MockStk500v1Transport()
        for (i in 0 until 100) mock.flash[i] = 0x42
        val programmer = Stk500v1Programmer(mock)
        programmer.open()
        mock.calls.clear()

        programmer.chipErase()

        assertTrue(mock.flash.all { it == 0xFF.toByte() })
        assertTrue("expected a UNIVERSAL command (the 0xAC 0x80 erase instruction)", mock.calls.contains(0x56))
        assertTrue("expected re-sync after erase", mock.calls.contains(0x30))
        assertTrue("expected re-entering program mode after erase", mock.calls.contains(0x50))
    }

    @Test
    fun `write then read flash round-trips within a single page-sized block`() {
        val device = DeviceDatabase.findById("atmega328p")!!
        val mock = MockStk500v1Transport(flashSize = device.flashSize)
        val programmer = Stk500v1Programmer(mock)
        programmer.open()

        val image = MemoryImage(device.flashSize)
        for (i in 0 until 100) image.set(i, (i and 0xFF).toByte())

        programmer.writeMemory("flash", device, image)
        val readBack = programmer.readMemory("flash", device)

        for (i in 0 until 100) assertEquals(image.get(i), readBack.get(i))
    }

    @Test
    fun `write then read flash round-trips across multiple pages`() {
        val device = DeviceDatabase.findById("atmega328p")!! // 128-byte flash page
        val mock = MockStk500v1Transport(flashSize = device.flashSize)
        val programmer = Stk500v1Programmer(mock)
        programmer.open()

        val image = MemoryImage(device.flashSize)
        for (i in 0 until 300) image.set(i, ((i * 7) and 0xFF).toByte()) // spans 3 pages of 128 bytes

        programmer.writeMemory("flash", device, image)
        val readBack = programmer.readMemory("flash", device)

        for (i in 0 until 300) assertEquals("byte at $i", image.get(i), readBack.get(i))
    }

    @Test
    fun `eeprom uses byte addressing, independent of flash's word addressing`() {
        val device = DeviceDatabase.findById("atmega328p")!!
        val mock = MockStk500v1Transport(flashSize = device.flashSize)
        val programmer = Stk500v1Programmer(mock)
        programmer.open()

        val image = MemoryImage(device.eepromSize)
        for (i in 0 until device.eepromSize) image.set(i, (i and 0xFF).toByte())

        programmer.writeMemory("eeprom", device, image)
        // MockStk500v1Transport only models one physical byte array (`flash`); write/read against
        // the same mock and device is enough to confirm round-tripping and address math don't throw
        // or silently corrupt data for the byte-addressed (a_div=1) path.
        val readBack = programmer.readMemory("eeprom", device)
        for (i in 0 until device.eepromSize) assertEquals("byte at $i", image.get(i), readBack.get(i))
    }

    @Test
    fun `extended addressing kicks in for flash over 64K words`() {
        val device = DeviceDatabase.findById("atmega2560")!! // 256KB flash -- needs LOAD_EXT_ADDR
        val mock = MockStk500v1Transport(flashSize = device.flashSize)
        val programmer = Stk500v1Programmer(mock)
        programmer.open()

        val image = MemoryImage(device.flashSize)
        val highAddress = 0x20000 // beyond the first 64K word-addressed segment
        for (i in 0 until 50) image.set(highAddress + i, (i and 0xFF).toByte())

        programmer.writeMemory("flash", device, image)
        val readBack = programmer.readMemory("flash", device)

        for (i in 0 until 50) assertEquals("byte at ${highAddress + i}", image.get(highAddress + i), readBack.get(highAddress + i))
        assertTrue("expected a 0x4d load-extended-address UNIVERSAL command", mock.calls.contains(0x56))
    }
}
