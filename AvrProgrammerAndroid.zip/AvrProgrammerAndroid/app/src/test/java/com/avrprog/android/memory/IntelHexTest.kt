package com.avrprog.android.memory

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class IntelHexTest {

    // Two data bytes (0xDE 0xAD) at address 0, correct checksum, plus EOF.
    private val simpleHex = ":02000000DEAD73\n:00000001FF\n"

    @Test
    fun `parses a simple data record`() {
        val image = IntelHex.parse(simpleHex, 1024)
        assertEquals(0xDE.toByte(), image.get(0))
        assertEquals(0xAD.toByte(), image.get(1))
        assertEquals(0..1, image.writtenRange())
    }

    @Test
    fun `round-trips write then parse`() {
        val original = MemoryImage(64)
        original.set(0, 0x11)
        original.set(1, 0x22)
        original.set(40, 0x33)
        val text = IntelHex.write(original)
        val parsed = IntelHex.parse(text, 64)
        assertEquals(original.get(0), parsed.get(0))
        assertEquals(original.get(1), parsed.get(1))
        assertEquals(original.get(40), parsed.get(40))
        assertEquals(false, parsed.written[2])
    }

    @Test
    fun `rejects bad checksum`() {
        val bad = ":02000000DEAD00\n:00000001FF\n" // wrong checksum byte (correct is 0x73)
        assertThrows(com.avrprog.android.error.MemoryOperationException::class.java) {
            IntelHex.parse(bad, 1024)
        }
    }

    @Test
    fun `rejects missing EOF record`() {
        assertThrows(com.avrprog.android.error.MemoryOperationException::class.java) {
            IntelHex.parse(":02000000DEAD73\n", 1024)
        }
    }

    @Test
    fun `rejects overlapping records`() {
        val overlapping = ":02000000DEAD73\n:0200000011FFEE\n:00000001FF\n"
        assertThrows(com.avrprog.android.error.MemoryOperationException::class.java) {
            IntelHex.parse(overlapping, 1024)
        }
    }

    @Test
    fun `honors extended linear address records`() {
        // :02000004 0001 F9  -- set upper 16 bits of address to 0x0001 (i.e. base 0x10000)
        // :02000000 CAFE 34 -- two bytes at 0x10000/0x10001
        val hex = ":020000040001F9\n:02000000CAFE36\n:00000001FF\n"
        val image = IntelHex.parse(hex, 0x20000)
        assertEquals(0xCA.toByte(), image.get(0x10000))
        assertEquals(0xFE.toByte(), image.get(0x10001))
    }

    @Test
    fun `binary conversion round-trips`() {
        val original = MemoryImage(16)
        for (i in 0 until 8) original.set(i, (i * 3).toByte())
        val bin = IntelHex.toBinary(original)
        val restored = IntelHex.fromBinary(bin, 16)
        assertArrayEquals(bin, IntelHex.toBinary(restored))
    }
}
