package com.avrprog.android.memory

import com.avrprog.android.error.MemoryOperationException
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class IntelHexTest {

    // Fixtures below were generated from first principles (byte-count, address,
    // record type, payload, then two's-complement checksum of all bytes) --
    // see the comment on each record for what it encodes.

    @Test
    fun `parses simple data record`() {
        // 16 data bytes (1..16) at address 0
        val hex = ":100000000102030405060708090A0B0C0D0E0F1068\n:00000001FF\n"
        val image = IntelHex.parse(hex, 256)
        assertEquals(1, image.get(0).toInt())
        assertEquals(16, image.get(15).toInt())
        assertEquals(0..15, image.writtenRange())
    }

    @Test
    fun `round trips through write then parse`() {
        val image = MemoryImage(1024)
        for (i in 0 until 40) image.set(i, (i * 3).toByte())
        val hex = IntelHex.write(image)
        val reparsed = IntelHex.parse(hex, 1024)
        for (i in 0 until 40) assertEquals(image.get(i), reparsed.get(i))
    }

    @Test
    fun `rejects bad checksum`() {
        // Same record as above but with the checksum byte corrupted to FF.
        val hex = ":100000000102030405060708090A0B0C0D0E0F10FF\n:00000001FF\n"
        assertThrows(MemoryOperationException::class.java) { IntelHex.parse(hex, 256) }
    }

    @Test
    fun `rejects missing EOF record`() {
        val hex = ":100000000102030405060708090A0B0C0D0E0F1068\n"
        assertThrows(MemoryOperationException::class.java) { IntelHex.parse(hex, 256) }
    }

    @Test
    fun `rejects overlapping records`() {
        // First record covers bytes 0-15, second covers 4-19 -- they overlap.
        val hex = ":100000000102030405060708090A0B0C0D0E0F1068\n" +
            ":100004000102030405060708090A0B0C0D0E0F1064\n" +
            ":00000001FF\n"
        assertThrows(MemoryOperationException::class.java) { IntelHex.parse(hex, 256) }
    }

    @Test
    fun `honours extended linear address records`() {
        // Extended linear address record sets the upper 16 bits to 0x0001, so
        // the following data record's 16 bytes land at 0x10000, not 0x0000.
        val hex = ":020000040001F9\n:100000000102030405060708090A0B0C0D0E0F1068\n:00000001FF\n"
        val image = IntelHex.parse(hex, 0x20000)
        assertEquals(1, image.get(0x10000).toInt())
        assertEquals(2, image.get(0x10001).toInt())
        assertEquals(false, image.written[0])
    }

    @Test
    fun `binary round trip`() {
        val bytes = byteArrayOf(1, 2, 3, 4, 5)
        val image = IntelHex.fromBinary(bytes, 32)
        assertArrayEquals(bytes, IntelHex.toBinary(image))
    }

    @Test
    fun `rejects binary larger than target memory`() {
        assertThrows(MemoryOperationException::class.java) { IntelHex.fromBinary(ByteArray(100), 32) }
    }
}
