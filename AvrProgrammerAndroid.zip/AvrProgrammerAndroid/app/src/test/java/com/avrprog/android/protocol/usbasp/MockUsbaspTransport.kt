package com.avrprog.android.protocol.usbasp

import com.avrprog.android.usb.UsbTransport

/**
 * A software model of USBasp firmware, built directly against the same
 * function IDs and framing UsbaspProgrammer sends, so the real protocol
 * class can be exercised end-to-end (connect -> program enable -> chip
 * erase -> paged flash read/write) without physical hardware or an Android
 * runtime -- brief section 21: "Create mock transports so protocols can be
 * tested without physical hardware."
 */
class MockUsbaspTransport(flashSize: Int) : UsbTransport {
    override val vendorId = UsbaspConstants.USBASP_SHARED_VID
    override val productId = UsbaspConstants.USBASP_SHARED_PID

    val flash = ByteArray(flashSize) { 0xFF.toByte() }
    private var longAddress = 0
    var signature = byteArrayOf(0x1E, 0x95.toByte(), 0x0F) // ATmega328P by default
    var erased = false
        private set

    override fun controlTransfer(
        requestType: Int, request: Int, value: Int, index: Int,
        buffer: ByteArray?, length: Int, timeoutMs: Int
    ): Int {
        // Undo UsbaspProgrammer.transmit()'s packing: wValue = send[1]<<8|send[0], wIndex = send[3]<<8|send[2].
        val send = byteArrayOf(
            (value and 0xFF).toByte(), ((value shr 8) and 0xFF).toByte(),
            (index and 0xFF).toByte(), ((index shr 8) and 0xFF).toByte()
        )
        return when (request) {
            UsbaspConstants.FUNC_GETCAPABILITIES -> { fill(buffer, byteArrayOf(0, 0, 0, 0)); 4 }
            UsbaspConstants.FUNC_SETISPSCK -> 4
            UsbaspConstants.FUNC_CONNECT -> 4
            UsbaspConstants.FUNC_ENABLEPROG -> { fill(buffer, byteArrayOf(0)); 1 }
            UsbaspConstants.FUNC_SETLONGADDRESS -> {
                longAddress = (send[0].toInt() and 0xFF) or ((send[1].toInt() and 0xFF) shl 8) or
                    ((send[2].toInt() and 0xFF) shl 16) or ((send[3].toInt() and 0xFF) shl 24)
                4
            }
            UsbaspConstants.FUNC_TRANSMIT -> { fill(buffer, simulateIspCommand(send)); 4 }
            UsbaspConstants.FUNC_READFLASH -> {
                for (i in 0 until length) buffer!![i] = flash.getOrElse(longAddress + i) { 0xFF.toByte() }
                length
            }
            UsbaspConstants.FUNC_WRITEFLASH -> {
                for (i in 0 until length) if (longAddress + i < flash.size) flash[longAddress + i] = buffer!![i]
                length
            }
            else -> length
        }
    }

    private fun simulateIspCommand(cmd: ByteArray): ByteArray {
        val b0 = cmd[0].toInt() and 0xFF
        val b1 = cmd[1].toInt() and 0xFF
        return when {
            b0 == 0x30 -> { // Read Signature Byte: 0x30 0x00 <index> 0x00
                val idx = cmd[2].toInt() and 0xFF
                byteArrayOf(0, 0, 0, signature.getOrElse(idx) { 0 })
            }
            b0 == 0xAC && b1 == 0x80 -> { // Chip Erase: 0xAC 0x80 0x00 0x00
                erased = true
                for (i in flash.indices) flash[i] = 0xFF.toByte()
                byteArrayOf(0, 0, 0, 0)
            }
            else -> byteArrayOf(0, 0, 0, 0)
        }
    }

    private fun fill(buffer: ByteArray?, data: ByteArray) {
        buffer ?: return
        for (i in data.indices) if (i < buffer.size) buffer[i] = data[i]
    }

    override fun bulkTransfer(endpointAddress: Int, buffer: ByteArray, length: Int, timeoutMs: Int): Int = length
    override fun close() {}
}
