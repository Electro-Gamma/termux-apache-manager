package com.avrprog.android.protocol.avr109

import com.avrprog.android.usb.SerialTransport

/**
 * A software model of an AVR109/Caterina-speaking bootloader target, built
 * directly against the same command bytes Avr109Programmer sends, so the
 * real protocol class can be exercised end-to-end (handshake -> select
 * device -> program mode -> paged flash read/write) without physical
 * hardware -- brief section 21.
 */
class MockAvr109Transport(flashSize: Int = 32_768) : SerialTransport {

    val flash = ByteArray(flashSize) { 0xFF.toByte() }
    var signature = byteArrayOf(0x1E, 0x95.toByte(), 0x87.toByte()) // ATmega32U4 by default
    var deviceCode = 0x44

    /** Every command byte seen, in order. */
    val calls = mutableListOf<Int>()

    private var wordAddress = 0
    private val rx = ArrayDeque<Byte>()

    override fun open(baudRate: Int) { /* nothing to simulate */ }
    override fun setDtr(enabled: Boolean) { /* AVR109 boards use manual reset -- nothing to simulate */ }
    override fun setRts(enabled: Boolean) { /* nothing to simulate */ }

    override fun write(bytes: ByteArray, timeoutMs: Int) {
        val opcode = bytes[0].toInt() and 0xFF
        calls += opcode
        when (opcode) {
            'S'.code -> respondAscii("AVRBOOT") // RETURN_SOFTWARE_IDENTIFIER (7 bytes)
            'V'.code -> respondAscii("10") // RETURN_SOFTWARE_VERSION (2 bytes)
            'p'.code -> respond('S'.code) // RETURN_PROGRAMMER_TYPE (1 byte)
            'b'.code -> { // CHECK_BLOCK_SUPPORT
                respond('Y'.code, (flash.size shr 8) and 0xFF, flash.size and 0xFF)
            }
            'T'.code -> { // SELECT_DEVICE_TYPE
                deviceCode = bytes[1].toInt() and 0xFF
                respond(CR)
            }
            'P'.code -> respond(CR) // ENTER_PROGRAMMING_MODE
            'L'.code -> respond(CR) // LEAVE_PROGRAMMING_MODE
            'E'.code -> respond(CR) // EXIT_BOOTLOADER
            's'.code -> { // READ_SIGNATURE_BYTES -- returned in reverse order, matching the real protocol
                respond(
                    signature[2].toInt() and 0xFF,
                    signature[1].toInt() and 0xFF,
                    signature[0].toInt() and 0xFF
                )
            }
            'A'.code -> { // SET_ADDRESS (word address)
                wordAddress = ((bytes[1].toInt() and 0xFF) shl 8) or (bytes[2].toInt() and 0xFF)
                respond(CR)
            }
            'B'.code -> { // START_BLOCK_LOAD
                val blockSize = ((bytes[1].toInt() and 0xFF) shl 8) or (bytes[2].toInt() and 0xFF)
                val byteAddr = wordAddress * 2
                for (i in 0 until blockSize) {
                    val a = byteAddr + i
                    if (a < flash.size) flash[a] = bytes[4 + i]
                }
                respond(CR)
            }
            'g'.code -> { // START_BLOCK_READ
                val blockSize = ((bytes[1].toInt() and 0xFF) shl 8) or (bytes[2].toInt() and 0xFF)
                val byteAddr = wordAddress * 2
                for (i in 0 until blockSize) {
                    val a = byteAddr + i
                    rx.addLast(if (a < flash.size) flash[a] else 0xFF.toByte())
                }
            }
            else -> respond(CR)
        }
    }

    override fun readExactly(buffer: ByteArray, length: Int, timeoutMs: Int) {
        for (i in 0 until length) {
            buffer[i] = rx.removeFirstOrNull()
                ?: throw IllegalStateException("MockAvr109Transport: no more simulated response bytes available")
        }
    }

    override fun close() { /* nothing to simulate */ }

    private fun respond(vararg values: Int) {
        for (v in values) rx.addLast(v.toByte())
    }

    private fun respondAscii(text: String) {
        for (c in text) rx.addLast(c.code.toByte())
    }

    companion object {
        const val CR = 0x0d
    }
}
