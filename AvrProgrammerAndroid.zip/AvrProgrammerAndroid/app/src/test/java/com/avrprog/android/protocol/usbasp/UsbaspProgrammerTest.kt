package com.avrprog.android.protocol.usbasp

import com.avrprog.android.device.AvrDevice
import com.avrprog.android.device.ProgrammingInterface
import com.avrprog.android.memory.MemoryImage
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class UsbaspProgrammerTest {

    private val testPart = AvrDevice(
        id = "test328p", description = "ATmega328P (test)",
        signature = intArrayOf(0x1E, 0x95, 0x0F),
        flashSize = 512, flashPageSize = 128, // small size so the test exercises >1 USBASP_WRITEBLOCKSIZE (200) block
        eepromSize = 64, eepromPageSize = 4,
        supportedInterfaces = setOf(ProgrammingInterface.ISP)
    )

    @Test
    fun `open connects and enables programming without throwing`() {
        val transport = MockUsbaspTransport(testPart.flashSize)
        val programmer = UsbaspProgrammer(transport)
        programmer.open() // should not throw
    }

    @Test
    fun `reads signature matching the simulated device`() {
        val transport = MockUsbaspTransport(testPart.flashSize)
        val programmer = UsbaspProgrammer(transport)
        programmer.open()
        assertArrayEquals(byteArrayOf(0x1E, 0x95.toByte(), 0x0F), programmer.readSignature())
    }

    @Test
    fun `chip erase fills flash with 0xFF`() {
        val transport = MockUsbaspTransport(testPart.flashSize)
        transport.flash.fill(0x42)
        val programmer = UsbaspProgrammer(transport)
        programmer.open()
        programmer.chipErase()
        assertTrue(transport.erased)
        assertTrue(transport.flash.all { it == 0xFF.toByte() })
    }

    @Test
    fun `flash write then read round trips across multiple USB blocks`() {
        val transport = MockUsbaspTransport(testPart.flashSize)
        val programmer = UsbaspProgrammer(transport)
        programmer.open()

        val image = MemoryImage(testPart.flashSize)
        for (i in 0 until testPart.flashSize) image.set(i, (i and 0xFF).toByte())

        var writeProgressCalls = 0
        programmer.writeMemory("flash", testPart, image) { _, _ -> writeProgressCalls++ }
        // 512 bytes / 200-byte USBASP_WRITEBLOCKSIZE = 3 USB transfers (200+200+112)
        assertEquals(3, writeProgressCalls)

        val readBack = programmer.readMemory("flash", testPart) { _, _ -> }
        for (i in 0 until testPart.flashSize) {
            assertEquals("byte at $i", image.get(i), readBack.get(i))
        }
    }
}
