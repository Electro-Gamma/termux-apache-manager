package com.avrprog.android.protocol.usbasp

import com.avrprog.android.device.DeviceDatabase
import com.avrprog.android.memory.MemoryImage
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class UsbaspPacketTest {

    @Test
    fun `open() runs getCapabilities, sets SCK, connects, then enables programming in order`() {
        val mock = MockUsbTransport()
        val programmer = UsbaspProgrammer(mock)
        programmer.open()

        val order = mock.calls.map { it.request }
        assertEquals(UsbaspConstants.FUNC_GETCAPABILITIES, order[0])
        assertEquals(UsbaspConstants.FUNC_SETISPSCK, order[1])
        assertEquals(UsbaspConstants.FUNC_CONNECT, order[2])
        assertEquals(UsbaspConstants.FUNC_ENABLEPROG, order[3])
    }

    @Test
    fun `readSignature returns the mock device's configured signature`() {
        val mock = MockUsbTransport(signature = byteArrayOf(0x1E, 0x95.toByte(), 0x0F)) // ATmega328P
        val programmer = UsbaspProgrammer(mock)
        programmer.open()

        assertArrayEquals(byteArrayOf(0x1E, 0x95.toByte(), 0x0F), programmer.readSignature())
    }

    @Test
    fun `chip erase clears flash to 0xFF and re-runs connect + program enable`() {
        val mock = MockUsbTransport()
        for (i in 0 until 100) mock.flash[i] = 0x42
        val programmer = UsbaspProgrammer(mock)
        programmer.open()
        mock.calls.clear()

        programmer.chipErase()

        assertTrue(mock.flash.all { it == 0xFF.toByte() })
        val order = mock.calls.map { it.request }
        assertTrue("expected a FUNC_TRANSMIT (the 0xAC 0x80 erase command)", order.contains(UsbaspConstants.FUNC_TRANSMIT))
        assertTrue("expected re-connect after erase", order.contains(UsbaspConstants.FUNC_CONNECT))
        assertTrue("expected re-enable after erase", order.contains(UsbaspConstants.FUNC_ENABLEPROG))
    }

    @Test
    fun `write then read flash round-trips across multiple 200-byte USBasp blocks`() {
        val device = DeviceDatabase.findById("atmega328p")!!
        val mock = MockUsbTransport(memSize = device.flashSize)
        val programmer = UsbaspProgrammer(mock)
        programmer.open()

        // 300 bytes spans two USBASP_WRITEBLOCKSIZE=200 blocks.
        val image = MemoryImage(device.flashSize)
        for (i in 0 until 300) image.set(i, (i and 0xFF).toByte())

        programmer.writeMemory("flash", device, image)
        val readBack = programmer.readMemory("flash", device)

        for (i in 0 until 300) assertEquals(image.get(i), readBack.get(i))
    }

    @Test
    fun `setLongAddress is issued once per USBasp block during a multi-block write`() {
        val device = DeviceDatabase.findById("atmega328p")!!
        val mock = MockUsbTransport(memSize = device.flashSize)
        val programmer = UsbaspProgrammer(mock)
        programmer.open()
        mock.calls.clear()

        val image = MemoryImage(device.flashSize)
        for (i in 0 until 450) image.set(i, 0x55) // 450 bytes -> 3 blocks of <=200

        programmer.writeMemory("flash", device, image)

        val longAddrCalls = mock.calls.count { it.request == UsbaspConstants.FUNC_SETLONGADDRESS }
        assertEquals(3, longAddrCalls)
    }
}
