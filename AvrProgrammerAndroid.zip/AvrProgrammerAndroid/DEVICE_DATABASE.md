# Device Database

## What's in it

`app/src/main/assets/devices.json` currently ships **29 real AVR parts**,
extracted directly from AVRDUDE's `src/avrdude.conf.in` (see below for how):

ATmega328P, ATmega328, ATmega168, ATmega168P, ATmega88, ATmega88P, ATmega48,
ATmega48P, ATmega8, ATmega32, ATmega16, ATmega64, ATmega128, ATmega2560,
ATmega2561, ATmega32U4, ATmega32U2, AT90USB1287, AT90USB162, AT90USB646,
ATtiny13, ATtiny13A, ATtiny25, ATtiny45, ATtiny85, ATtiny2313, ATtiny84,
ATtiny44, ATtiny4313.

This is a **curated subset** of AVRDUDE's 400+ defined parts -- covering the
parts explicitly named in the project brief's device-list example plus the
most common ATtiny/AT90USB parts -- not the full database. Extending it is
mechanical (see below), not a design change.

## What each device entry carries

Per device: `id` (AVRDUDE's part id, e.g. `"m328p"`), `desc` (display name),
`signature` (3 bytes), `progModes`, `chipEraseDelayUs`, the Programming
Enable/Chip Erase/Read Signature opcode templates, and per-memory entries for
`flash`, `eeprom`, each defined fuse (`lfuse`/`hfuse`/`efuse`, or a single
`fuse` byte on simpler parts), `lock`, and `calibration` -- each with its
`size`/`pageSize`/`initval`/`bitmask` and whichever of
`read`/`write`/`readLo`/`readHi`/`loadPageLo`/`loadPageHi`/`writePage`/
`loadExtAddr` opcode templates that memory actually uses. All of this maps
directly onto AVRDUDE's own `AVRMEM` struct fields.

`ATmega2560`/`ATmega2561` additionally carry a `loadExtAddr` template on their
`flash` memory, since their 256 KiB flash exceeds what a 16-bit ISP address
field can reach (see `Opcode.kt`'s Load Extended Address handling).

## Provenance: how this was extracted

`avrdude.conf.in` is not JSON or any standard config format -- it's a custom
grammar (`part [parent "X"] { key = value; memory "name" { key = value; }; };`)
compiled by a bespoke yacc parser (`config_gram.y`) at AVRDUDE's build time.
To pull real data out of it without reimplementing that whole grammar, a
one-off Python script:

1. Splits the file into `part { ... }` blocks by tracking the
   `part`/closing-`;` indentation convention the format actually uses.
2. For each wanted part id, resolves `id`/`desc`/`signature`/`prog_modes`/
   `chip_erase_delay`/`pgm_enable`/`chip_erase`, and each named `memory`
   block's fields, by walking the `parent` chain when a field isn't set
   directly on the part itself (mirroring how AVRDUDE's own config loader
   applies inheritance).
3. Emits the resolved fields as `devices.json`.

This script is not part of the Android build (it's a data-preparation step
that already ran) but its logic is straightforward to redo for more parts --
see below.

## Extending the database with more parts

To add another part from AVRDUDE's `avrdude.conf.in`:

1. Find its part `id` in `avrdude.conf.in` (e.g. `"m4809"` for ATmega4809).
2. Resolve its `signature`, `flash`/`eeprom` `size`/`page_size`, and the
   opcode template strings (`read_lo`/`read_hi`/`loadpage_lo`/`loadpage_hi`/
   `writepage` for flash; `read`/`write`/`loadpage_lo`/`writepage` for
   eeprom; `read`/`write`/`initval`/`bitmask` for each fuse/lock/calibration)
   by reading the part's block and walking up its `parent` chain for any
   field not set directly -- the same process the extraction script above
   automates.
3. Add the resolved fields as a new entry in `devices.json`'s `devices` array,
   matching the shape of an existing entry.
4. No Kotlin code changes needed -- `DeviceDatabase`/`AvrDevice`/`AvrMemoryDef`
   are already fully data-driven from this JSON.

Parts using UPDI/PDI/TPI programming (tinyAVR 0/1/2, megaAVR 0, AVR Dx, XMEGA,
ATtiny4/5/9/10/20/40-class) are **not** meaningfully addable this way even
though AVRDUDE's `avrdude.conf.in` defines them -- their opcode/memory model
is fundamentally different from classic ISP's 4-byte bit-template opcodes
(see PROTOCOLS.md), so `AvrMemoryDef`'s opcode-template fields don't apply to
them at all.

## Fabrication policy

Every signature, size, page size, and opcode template string in `devices.json`
was extracted from AVRDUDE's source as described above -- none of it was
guessed, approximated, or written from general AVR knowledge without
verification, per project brief section 10/11's "do not fabricate support for
devices AVRDUDE does not define."
