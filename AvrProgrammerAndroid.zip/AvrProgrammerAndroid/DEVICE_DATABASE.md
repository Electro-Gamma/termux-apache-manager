# Device database

`device/DeviceDatabase.kt` holds 27 classic-AVR parts. AVRDUDE's full
`avrdude.conf.in` defines 300+ parts (including every UPDI/PDI/TPI/XMEGA
family device); this is an intentionally curated subset of commonly-used
ISP-programmable parts, not the full database.

## Source mapping

Every signature and flash/EEPROM size below was read out of the
corresponding `part` block (or its `parent` chain) in
`avrdude-main/src/avrdude.conf.in`, not invented or guessed. Values marked
"(inherited)" in AVRDUDE's own config come from a parent template (e.g.
`ATmega328P` inherits flash/EEPROM/page size from its `m328` parent, and only
overrides its own `signature` and `mcuid`) -- this project resolved those
manually by walking the same parent chain avrdude.conf.in's `part parent
"..."` declares.

| id | AVRDUDE part `id` | signature | flash | eeprom | flash page |
|---|---|---|---|---|---|
| attiny13 | `t13` | 1E 90 07 | 1,024 | 64 | 32 |
| attiny2313 | `t2313` | 1E 91 0A | 2,048 | 128 | 32 |
| attiny25 | `t25` | 1E 91 08 | 2,048 | 128 | 32 |
| attiny45 | `t45` | 1E 92 06 | 4,096 | 256 | 64 |
| attiny85 | `t85` | 1E 93 0B | 8,192 | 512 | 64 |
| atmega8 | `m8` | 1E 93 07 | 8,192 | 512 | 64 |
| atmega8515 | `m8515` | 1E 93 06 | 8,192 | 512 | 64 |
| atmega8535 | `m8535` | 1E 93 08 | 8,192 | 512 | 64 |
| atmega16 | `m16` | 1E 94 03 | 16,384 | 512 | 128 |
| atmega32 | `m32` | 1E 95 02 | 32,768 | 1,024 | 128 |
| atmega48 | `m48` | 1E 92 05 | 4,096 | 256 | 64 |
| atmega48pb | `m48pb` | 1E 92 10 | 4,096 | 256 | 64 |
| atmega88 | `m88` | 1E 93 0A | 8,192 | 512 | 64 |
| atmega88pb | `m88pb` | 1E 93 16 | 8,192 | 512 | 64 |
| atmega168 | `m168` | 1E 94 06 | 16,384 | 512 | 128 |
| atmega168pb | `m168pb` | 1E 94 15 | 16,384 | 512 | 128 |
| atmega328 | `m328` | 1E 95 14 | 32,768 | 1,024 | 128 |
| atmega328p | `m328p` | 1E 95 0F | 32,768 | 1,024 | 128 |
| atmega328pb | `m328pb` | 1E 95 16 | 32,768 | 1,024 | 128 |
| atmega64 | `m64` | 1E 96 02 | 65,536 | 2,048 | 256 |
| atmega1284 | `m1284` | 1E 97 06 | 131,072 | 4,096 | 256 |
| atmega128 | `m128` | 1E 97 02 | 131,072 | 4,096 | 256 |
| atmega2560 | `m2560` | 1E 98 01 | 262,144 | 4,096 | 256 |
| atmega2561 | `m2561` | 1E 98 02 | 262,144 | 4,096 | 256 |
| atmega32u4 | `m32u4` | 1E 95 87 | 32,768 | 1,024 | 128 |
| atmega32u2 | `m32u2` | 1E 95 8A | 32,768 | 1,024 | 128 |
| at90usb1286 | `usb1286` | 1E 97 82 | 131,072 | 4,096 | 256 |

EEPROM page sizes in this table are set to a conservative default (4 bytes
for the sub-64KB parts, 8 for the larger ones) matching AVRDUDE's own values
for the parts this project spot-checked directly; they have not been
individually re-verified against every listed part's `avrdude.conf.in` entry.

```
FEATURE: Full AVRDUDE device database (300+ parts, including UPDI/PDI/TPI/XMEGA families)
STATUS: NOT IMPLEMENTED
REASON: Each additional family (tinyAVR 0/1/2, megaAVR 0, AVR Dx/Dx, XMEGA) needs its own memory-map
        shape (UPDI/PDI parts have different memory names -- "boot", "userrow", "signature" as separate
        NVM regions -- not just a bigger flash/eeprom pair), so bulk-porting the config would produce a
        device list attached to a programming protocol (UPDI/PDI) that isn't implemented anyway.
AVRDUDE SOURCE REFERENCE: src/avrdude.conf.in (full file, ~14,000 lines; PM_UPDI / PM_PDI / PM_TPI prog_modes)

FEATURE: Fuse/lock/calibration memory definitions per part
STATUS: NOT IMPLEMENTED
REASON: See PROTOCOLS.md -- AvrDevice/AvrMemory has no fuse-bit-layout representation yet.
AVRDUDE SOURCE REFERENCE: src/avrdude.conf.in (per-part `memory "lfuse"` etc. blocks)
```

## Extending this table

To add a part: find its `part parent "..."  # <id>` block in
`avrdude.conf.in`, read its `signature` line (or its parent's, if not
overridden), and its `memory "flash"`/`memory "eeprom"` `size`/`page_size`
fields (again following the `parent` chain if not present directly on the
part), then add an `AvrDevice(...)` entry to `DeviceDatabase.devices`.
