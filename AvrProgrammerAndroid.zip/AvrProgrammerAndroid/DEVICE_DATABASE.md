# Device Database

26 classic-AVR, ISP-programmable parts, ported from `src/avrdude.conf.in`'s
`part` blocks (resolving `parent` inheritance for flash/EEPROM size and page
size where the child block doesn't repeat them). This is a curated subset --
AVRDUDE's full config has 300+ parts, including the UPDI/PDI/TPI/XMEGA
families this project doesn't program yet (see PROTOCOLS.md).


## Table

| id | Description | Signature | Flash | Flash page | EEPROM | EEPROM page | avrdude.conf.in source |
|---|---|---|---|---|---|---|---|
| `attiny13` | ATtiny13 | 1E 90 07 | 1,024 B | 32 B | 64 B | 4 B | src/avrdude.conf.in, part id="t13" |
| `attiny2313` | ATtiny2313 | 1E 91 0A | 2,048 B | 32 B | 128 B | 4 B | part id="t2313" |
| `attiny25` | ATtiny25 | 1E 91 08 | 2,048 B | 32 B | 128 B | 4 B | part id="t25" |
| `attiny45` | ATtiny45 | 1E 92 06 | 4,096 B | 64 B | 256 B | 4 B | part id="t45" |
| `attiny85` | ATtiny85 | 1E 93 0B | 8,192 B | 64 B | 512 B | 4 B | part id="t85" |
| `atmega8` | ATmega8 | 1E 93 07 | 8,192 B | 64 B | 512 B | 4 B | part id="m8" |
| `atmega8515` | ATmega8515 | 1E 93 06 | 8,192 B | 64 B | 512 B | 4 B | part id="m8515" |
| `atmega8535` | ATmega8535 | 1E 93 08 | 8,192 B | 64 B | 512 B | 4 B | part id="m8535" |
| `atmega16` | ATmega16 | 1E 94 03 | 16,384 B | 128 B | 512 B | 4 B | part id="m16" |
| `atmega32` | ATmega32 | 1E 95 02 | 32,768 B | 128 B | 1,024 B | 4 B | part id="m32" |
| `atmega48` | ATmega48 | 1E 92 05 | 4,096 B | 64 B | 256 B | 4 B | part id="m48" (base of m48p/m48pb parent chain) |
| `atmega48pb` | ATmega48PB | 1E 92 10 | 4,096 B | 64 B | 256 B | 4 B | part parent "m48" id="m48pb" |
| `atmega88` | ATmega88 | 1E 93 0A | 8,192 B | 64 B | 512 B | 4 B | part id="m88" |
| `atmega88pb` | ATmega88PB | 1E 93 16 | 8,192 B | 64 B | 512 B | 4 B | part parent "m88" id="m88pb" |
| `atmega168` | ATmega168 | 1E 94 06 | 16,384 B | 128 B | 512 B | 4 B | part id="m168" |
| `atmega168pb` | ATmega168PB | 1E 94 15 | 16,384 B | 128 B | 512 B | 4 B | part parent "m168" id="m168pb" |
| `atmega328` | ATmega328 | 1E 95 14 | 32,768 B | 128 B | 1,024 B | 4 B | part id="m328" |
| `atmega328p` | ATmega328P | 1E 95 0F | 32,768 B | 128 B | 1,024 B | 4 B | part parent "m328" id="m328p" |
| `atmega328pb` | ATmega328PB | 1E 95 16 | 32,768 B | 128 B | 1,024 B | 4 B | part parent "m328" id="m328pb" |
| `atmega64` | ATmega64 | 1E 96 02 | 65,536 B | 256 B | 2,048 B | 8 B | part id="m64" |
| `atmega128` | ATmega128 | 1E 97 02 | 131,072 B | 256 B | 4,096 B | 8 B | part id="m128" |
| `atmega2560` | ATmega2560 | 1E 98 01 | 262,144 B | 256 B | 4,096 B | 8 B | part id="m2560" |
| `atmega2561` | ATmega2561 | 1E 98 02 | 262,144 B | 256 B | 4,096 B | 8 B | part id="m2561" |
| `atmega32u4` | ATmega32U4 | 1E 95 87 | 32,768 B | 128 B | 1,024 B | 4 B | part id="m32u4" |
| `atmega32u2` | ATmega32U2 | 1E 95 8A | 32,768 B | 128 B | 1,024 B | 4 B | part id="m32u2" |
| `at90usb1286` | AT90USB1286 | 1E 97 82 | 131,072 B | 256 B | 4,096 B | 8 B | part id="usb1286" |

## Notes

- EEPROM page size for most classic AVRs is small (2-8 bytes) and is not
  critical to USBasp's block-write protocol, which packs it into the write
  command directly; the values above come from the same `memory "eeprom"`
  blocks as the size field where present, otherwise a conservative 4-byte
  default consistent with the ATmega48/88/168/328 family.
- Per-part `chip_erase_delay` (microseconds, from avrdude.conf.in) has only been
  ported for the handful of parts in `DeviceDatabase.kt` that set an explicit
  `chipEraseDelayMs`; everything else uses a conservative 30ms default. See
  `AvrDevice.chipEraseDelayMs`'s doc comment.
- Adding a part: find its `part` block in `src/avrdude.conf.in` (following the
  `parent "..."` chain if `signature`/`memory` fields aren't repeated), then
  add one line to `DeviceDatabase.devices`. No other code changes needed for
  ISP-mode classic AVRs -- `UsbaspProgrammer` is generic over `AvrDevice`.
- Devices requiring UPDI/PDI/TPI/JTAG programming (tinyAVR 0/1/2, megaAVR 0,
  AVR Dx family, ATxmega, and any part with `PM_ISP` absent from its
  `prog_modes`) are intentionally excluded from this table -- adding their
  signatures here without a working programmer for them would misrepresent
  what this app can actually do.
