# VncViewer

A small, VNC-only remote desktop client for Android (Kotlin + Jetpack Compose).
Derived from RemMobile with RDP, SSH, SFTP, web console, SPICE, the credential vault,
sync/diagnostics and all unused dependencies removed.

## Features
- RFB 3.3 / 3.7 / 3.8; security: None and VNC password. Encodings: ZRLE, Hextile, CopyRect, RRE, Raw, DesktopSize, plus the RichCursor and XCursor pseudo-encodings: the server sends the pointer as a shape (not painted into the screen) and the app draws it locally at your finger position, instantly. "Dot for an invisible cursor" (General settings) shows a dot when the server hides it.
- Several sessions at once (tabs); sessions stay alive while you browse the connection list.
- Saved connections (passwords encrypted with an Android Keystore AES-256-GCM key) and Quick connect
  (`host`, `host:1` = port 5901, `host:5901`, `host::5901`, `vnc://host:port`, `[ipv6]:port`).
- Mouse: Touch mode (tap/long-press/drag) and Trackpad mode, pinch-zoom, two-finger scroll,
  pan toggle, physical mouse support (3 buttons + wheel), click menu (left/double/right/middle).
- Keyboard: Android soft keyboard, physical keyboard, key bar (Esc, Tab, sticky Ctrl/Alt/Shift/Win,
  arrows, Home/End/PgUp/PgDn, Del, Ins, F1-F12, Ctrl+Alt+Del).
- Clipboard: remote -> phone automatic; phone -> remote as clipboard or as typed text.
- Fit / 1:1 / Stretch scaling, fullscreen, view-only mode, keeps the screen on while connected.

## RealVNC engine (optional)
Each connection can run on the **built-in** client or on **RealVNC's own viewer core**
(encrypted connections, UDP, ZRLE2, RealVNC authentication, remote cursor shape, picture-quality
presets, connection info). Pick the engine per connection (or next to Quick connect).

The RealVNC core is a proprietary native library that is *not* in this project. To enable it,
upload `arm64-v8a.zip` (containing `libvncviewer.so` and `libc++_shared.so` from RealVNC Viewer
4.9.3.60175) in the Colab notebook; they are verified against pinned SHA-256 hashes and bundled
as `app/src/main/jniLibs/arm64-v8a/`. Requirements: arm64 phone, Android 8.0+. Without the
libraries the app builds and works normally; choosing RealVNC then shows an explanation.

Not supported on the RealVNC engine: RealVNC cloud sign-in / address book, multi-factor sign-in
prompts, client-certificate identities.

## Session settings (from Vento / VncViewerDual)
Settings (button on the connections screen, or More... in a session) has Vento's tree:

- **General** - session timeout, debug overlay, keep screen on, full screen, treat the desktop as a
  password field, reset IME on modifiers, two-row extension keyboard, additional modifiers
  (Option/CMD), session controls (toolbar / touch regions / both) and the first-frame controls hint,
  send/receive clipboard, release keys when losing focus.
- **Touch and cursor** - all 22 input tunables: pointer acceleration, adaptive acceleration, axis
  locking, hover assist, momentum, raw motion, edge scrolling, natural scrolling, recenter on zoom,
  pan margins, solid keyboard info bar, keyboard haptics, physical mouse capture/speed/wheel step,
  click hold, two-finger scroll step and the four scroll-bar gearing numbers. Defaults are Vento's
  ("improved") defaults; only values you change are stored.
- **Restore defaults**.

Rows are drawn as in VncViewerDual: grouped on rounded containers, radio-style choice dialogs, OK/Cancel number dialogs (no playground).

The behaviour behind them is a Kotlin port of Vento's input stack (`input/`): relative touchpad
cursor with RealVNC-style acceleration and flick momentum, tap / tap-then-drag / two- and
three-finger taps, pinch zoom and scroll, mouse overlay (buttons + wheel strip), draggable toolbar,
tap regions, physical-mouse support. "Mouse: Direct touch" keeps the older tap-where-you-click mode.

## Layout
```
app/src/main/java/com/vncviewer/app/
  MainActivity.kt          activity, hardware-key hook
  vnc/VncClient.kt         built-in RFB protocol engine (sockets, decoders, input)
  vnc/RemoteBackend.kt     the interface both engines implement
  vnc/RemotePrompt.kt      sign-in / trust / message prompts from the RealVNC engine
  realvnc/                 RealVNC engine: core thread + init, prompt bridge, backend
realvnc-jni/               Java declarations of the RealVNC JNI surface (CC0, from Vento)
  vnc/Keysyms.kt           Android key codes / Unicode -> X11 keysyms
  session/VncSession.kt    one connection: viewport, mouse, keyboard, clipboard state
  data/                    profile model, encrypted JSON store, address parser
  input/                   Vento's input stack + settings tables (Config, AppSettings, InputSettings, ...)
  ui/                      Compose screens, canvas + gestures, soft-keyboard capture view
```

## Build
Use the Colab notebook `VncViewer_APK_Release.ipynb`, or locally (JDK 17, Android SDK 36, Gradle 9.3.1):
```
gradle assembleDebug assembleRelease
```
