# JSch resolves algorithm implementations by class name at runtime.
-keep class com.jcraft.jsch.** { *; }
-dontwarn org.bouncycastle.**
-dontwarn com.sun.jna.**
-dontwarn org.apache.logging.log4j.**
-dontwarn org.ietf.jgss.**
-dontwarn org.newsclub.net.unix.**
-dontwarn org.slf4j.**

# usb-serial-for-android finds its drivers by reflection, and UART mode reaches an optional
# setFlowControl API by name.
-keep class com.hoho.android.usbserial.** { *; }

# termlib uses JNI callbacks into libvterm.
-keep class org.connectbot.terminal.** { *; }

# WebView bridge of the built-in file editor: the page calls these by name.
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# VNC tab. Shipped unminified as a standalone app: the RealVNC native library resolves these
# classes by name, and the input settings read their own fields reflectively.
-keep class com.realvnc.vncviewer.jni.** { *; }
-keep class com.vncviewer.app.** { *; }

# Archives (Commons Compress): the codecs for zstd, brotli, Pack200 and OSGi it can use are not
# bundled, and nothing here asks for them.
-dontwarn org.apache.commons.compress.**
-dontwarn com.github.luben.zstd.**
-dontwarn org.brotli.dec.**
-dontwarn org.objectweb.asm.**
-dontwarn org.osgi.**
-dontwarn org.tukaani.xz.**
