package app.terminalssh.secure.sftp

import kotlin.test.AfterTest
import kotlin.test.Test
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertSame

class ClipboardHubTest {

    private class FakeSource : SftpSource {
        override fun openSftp(): SftpClient? = null
    }

    private val entry = RemoteEntry(
        name = "a.txt", path = "/home/a.txt", isDirectory = false, isSymlink = false,
        sizeBytes = 1, modifiedEpochSeconds = 0, permissions = "-rw-r--r--",
    )

    @AfterTest
    fun reset() = ClipboardHub.clear()

    @Test
    fun clipboardIsSharedAndRemembersItsSource() {
        val a = FakeSource()
        ClipboardHub.set(Clipboard(ClipboardMode.COPY, listOf(entry), a, "host-a"))
        val seen = ClipboardHub.state.value
        assertNotNull(seen)
        assertSame(a, seen!!.source)
    }

    @Test
    fun disconnectingTheSourceDropsItsClipboard() {
        val a = FakeSource()
        ClipboardHub.set(Clipboard(ClipboardMode.CUT, listOf(entry), a, "host-a"))
        ClipboardHub.dropSource(a)
        assertNull(ClipboardHub.state.value)
    }

    @Test
    fun disconnectingAnotherHostKeepsTheClipboard() {
        val a = FakeSource()
        ClipboardHub.set(Clipboard(ClipboardMode.COPY, listOf(entry), a, "host-a"))
        ClipboardHub.dropSource(FakeSource())
        assertNotNull(ClipboardHub.state.value)
    }
}
