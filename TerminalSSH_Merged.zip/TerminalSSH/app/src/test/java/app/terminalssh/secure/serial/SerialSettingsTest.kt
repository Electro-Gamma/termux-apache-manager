package app.terminalssh.secure.serial

import kotlin.test.Test
import kotlin.test.assertEquals

class SerialSettingsTest {

    @Test
    fun `defaults are the usual console 115200 8N1`() {
        assertEquals("115200 8N1", SerialSettings().summary)
    }

    @Test
    fun `summary follows every line setting`() {
        val settings = SerialSettings(
            baudRate = 9600,
            dataBits = DataBits.SEVEN,
            parity = Parity.EVEN,
            stopBits = StopBits.TWO,
        )
        assertEquals("9600 7E2", settings.summary)
    }
}
