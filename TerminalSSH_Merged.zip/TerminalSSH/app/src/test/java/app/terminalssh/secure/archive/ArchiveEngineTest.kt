package app.terminalssh.secure.archive

import org.apache.commons.compress.archivers.tar.TarArchiveEntry
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry
import org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream
import java.io.ByteArrayInputStream
import java.io.File
import java.io.InputStream
import java.nio.file.Files
import kotlin.test.Test
import kotlin.test.assertContentEquals
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertFalse
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

class ArchiveEngineTest {

    private val formats = ArchiveFormat.entries

    /** LZMA2 needs the xz library; every build has it, a bare classpath may not. */
    private fun levelsFor(format: ArchiveFormat): List<CompressionLevel> {
        val lzma = runCatching { Class.forName("org.tukaani.xz.XZ"); true }.getOrDefault(false)
        return if (format == ArchiveFormat.SEVEN_Z && !lzma) listOf(CompressionLevel.STORE) else CompressionLevel.entries
    }

    private fun tempDir(): File = Files.createTempDirectory("archive-test").toFile()

    private val text = "hello archive ".repeat(500).toByteArray()
    private val binary = ByteArray(70_000) { (it * 31 % 251).toByte() }

    private fun build(dir: File, format: ArchiveFormat, level: CompressionLevel): File {
        val out = File(dir, "sample-${level.name}${format.suffix}")
        val a = File(dir, "a.txt").apply { writeBytes(text) }
        val b = File(dir, "b.bin").apply { writeBytes(binary) }
        ArchiveEngine.create(out, format, level).use { w ->
            w.directory("docs", 1_700_000_000L, 493)
            w.file("docs/a.txt", a.length(), 1_700_000_000L, 420, a.inputStream())
            w.file("docs/sub/b.bin", b.length(), 1_700_000_100L, 493, b.inputStream())
            w.file("empty.txt", 0L, 1_700_000_200L, 0, ByteArrayInputStream(ByteArray(0)))
        }
        return out
    }

    private fun paths(file: File, format: ArchiveFormat): Set<String> =
        ArchiveIndex(ArchiveEngine.list(file, format)).entries.map { it.path }.toSet()

    @Test
    fun formatDetectionByName() {
        assertEquals(ArchiveFormat.ZIP, ArchiveFormat.fromFileName("A.ZIP"))
        assertEquals(ArchiveFormat.TAR, ArchiveFormat.fromFileName("backup.tar"))
        assertEquals(ArchiveFormat.SEVEN_Z, ArchiveFormat.fromFileName("x.7z"))
        assertNull(ArchiveFormat.fromFileName("x.tar.gz"))
        assertNull(ArchiveFormat.fromFileName(".zip"))
        assertNull(ArchiveFormat.fromFileName("notes.txt"))
        assertEquals("backup", ArchiveFormat.baseName("backup.tar"))
    }

    @Test
    fun createListAndReadBackEveryFormat() {
        for (format in formats) for (level in levelsFor(format)) {
            val dir = tempDir()
            val file = build(dir, format, level)
            val index = ArchiveIndex(ArchiveEngine.list(file, format))
            val label = "$format/$level"
            // The folder docs/sub was never added explicitly: it must appear anyway.
            assertEquals(
                setOf("docs", "docs/a.txt", "docs/sub", "docs/sub/b.bin", "empty.txt"),
                index.entries.map { it.path }.toSet(),
                label,
            )
            assertTrue(index.isDirectory("docs/sub"), label)
            assertEquals(listOf("a.txt", "sub"), index.children("docs").map { it.name }.sorted(), label)
            assertEquals(text.size.toLong(), index["docs/a.txt"]!!.size, label)
            assertContentEquals(text, ArchiveEngine.readEntryBytes(file, format, index["docs/a.txt"]!!, 1 shl 20), label)
            assertContentEquals(binary, ArchiveEngine.readEntryBytes(file, format, index["docs/sub/b.bin"]!!, 1 shl 20), label)
            assertEquals(0, ArchiveEngine.readEntryBytes(file, format, index["empty.txt"]!!, 1 shl 20).size, label)
            assertEquals(1_700_000_000L, index["docs/a.txt"]!!.modifiedEpochSeconds, label)
            assertEquals(420, index["docs/a.txt"]!!.mode, label)
            assertEquals(493, index["docs/sub/b.bin"]!!.mode, label)
        }
    }

    @Test
    fun compressionActuallyShrinksCompressibleData() {
        for (format in listOf(ArchiveFormat.ZIP, ArchiveFormat.SEVEN_Z)) {
            val levels = levelsFor(format)
            if (levels.size < 2) continue
            val dir = tempDir()
            val stored = build(dir, format, CompressionLevel.STORE).length()
            val packed = build(dir, format, CompressionLevel.NORMAL).length()
            assertTrue(packed < stored, "$format: $packed should be below $stored")
        }
    }

    @Test
    fun readEntryRefusesTooLarge() {
        for (format in formats) {
            val dir = tempDir()
            val file = build(dir, format, CompressionLevel.STORE)
            val index = ArchiveIndex(ArchiveEngine.list(file, format))
            assertFailsWith<ArchiveEngine.TooLargeException>("$format") {
                ArchiveEngine.readEntryBytes(file, format, index["docs/sub/b.bin"]!!, 1000)
            }
        }
    }

    private class Recorder : ExtractSink {
        val dirs = ArrayList<String>()
        val files = LinkedHashMap<String, ByteArray>()
        val skipped = ArrayList<Pair<String, ArchiveProblem>>()
        override fun directory(relativePath: String, entry: ArchiveEntry) { dirs.add(relativePath) }
        override fun file(relativePath: String, entry: ArchiveEntry, content: InputStream) {
            files[relativePath] = content.readBytes()
        }
        override fun skipped(entry: ArchiveEntry, problem: ArchiveProblem) { skipped.add(entry.path to problem) }
    }

    @Test
    fun extractWholeArchiveAndASubset() {
        for (format in formats) {
            val dir = tempDir()
            val file = build(dir, format, CompressionLevel.STORE)
            val index = ArchiveIndex(ArchiveEngine.list(file, format))

            val everything = Recorder()
            val all = index.entries.filter { it.ordinal >= 0 }.associate { it.ordinal to it.path }
            ArchiveEngine.extract(file, format, all, everything) { false }
            assertContentEquals(text, everything.files["docs/a.txt"], "$format")
            assertContentEquals(binary, everything.files["docs/sub/b.bin"], "$format")
            assertEquals(0, everything.files["empty.txt"]!!.size, "$format")

            // Pull one file out and rename it on the way, as "copy to clipboard, paste" does.
            val subset = Recorder()
            ArchiveEngine.extract(file, format, mapOf(index["docs/sub/b.bin"]!!.ordinal to "renamed.bin"), subset) { false }
            assertEquals(setOf("renamed.bin"), subset.files.keys, "$format")
            assertContentEquals(binary, subset.files["renamed.bin"], "$format")
        }
    }

    @Test
    fun extractStopsWhenCancelled() {
        for (format in formats) {
            val dir = tempDir()
            val file = build(dir, format, CompressionLevel.STORE)
            val index = ArchiveIndex(ArchiveEngine.list(file, format))
            val plan = index.entries.filter { it.ordinal >= 0 }.associate { it.ordinal to it.path }
            assertFailsWith<ArchiveCancelled>("$format") {
                ArchiveEngine.extract(file, format, plan, Recorder()) { true }
            }
        }
    }

    @Test
    fun rewriteRemovesFilesAndWholeFolders() {
        for (format in formats) for (level in levelsFor(format)) {
            val dir = tempDir()
            val file = build(dir, format, level)
            val label = "$format/$level"

            val noFile = File(dir, "one-less${format.suffix}")
            ArchiveEngine.rewrite(file, format, noFile, setOf("docs/a.txt"), emptyList(), level)
            assertEquals(setOf("docs", "docs/sub", "docs/sub/b.bin", "empty.txt"), paths(noFile, format), label)

            val noFolder = File(dir, "no-docs${format.suffix}")
            ArchiveEngine.rewrite(file, format, noFolder, setOf("docs"), emptyList(), level)
            assertEquals(setOf("empty.txt"), paths(noFolder, format), label)

            // What stayed must still read back byte for byte.
            val index = ArchiveIndex(ArchiveEngine.list(noFile, format))
            assertContentEquals(binary, ArchiveEngine.readEntryBytes(noFile, format, index["docs/sub/b.bin"]!!, 1 shl 20), label)
        }
    }

    @Test
    fun rewriteReplacesAnEntryAndAddsNewOnes() {
        for (format in formats) for (level in levelsFor(format)) {
            val dir = tempDir()
            val file = build(dir, format, level)
            val label = "$format/$level"
            val edited = "edited content\n".toByteArray()
            val editedFile = File(dir, "edited.bin").apply { writeBytes(edited) }
            val added = File(dir, "added.bin").apply { writeBytes(byteArrayOf(1, 2, 3)) }

            val out = File(dir, "out${format.suffix}")
            ArchiveEngine.rewrite(
                file, format, out, emptySet(),
                listOf(
                    ArchivePut("docs/a.txt", editedFile, 1_800_000_000L, 420),
                    ArchivePut("new/added.bin", added, 1_800_000_100L, 0),
                    ArchivePut("new/folder", null, 1_800_000_100L, 0),
                ),
                level,
            )
            val index = ArchiveIndex(ArchiveEngine.list(out, format))
            assertContentEquals(edited, ArchiveEngine.readEntryBytes(out, format, index["docs/a.txt"]!!, 1 shl 20), label)
            assertEquals(edited.size.toLong(), index["docs/a.txt"]!!.size, label)
            assertContentEquals(byteArrayOf(1, 2, 3), ArchiveEngine.readEntryBytes(out, format, index["new/added.bin"]!!, 1 shl 20), label)
            assertTrue(index["new/folder"]!!.isDirectory, label)
            // The replaced name exists exactly once, and nothing else moved.
            assertEquals(1, ArchiveEngine.list(out, format).count { it.path == "docs/a.txt" }, label)
            assertContentEquals(binary, ArchiveEngine.readEntryBytes(out, format, index["docs/sub/b.bin"]!!, 1 shl 20), label)
        }
    }

    @Test
    fun rewriteLeavesTheSourceUntouched() {
        for (format in formats) {
            val dir = tempDir()
            val file = build(dir, format, CompressionLevel.STORE)
            val before = file.readBytes()
            ArchiveEngine.rewrite(file, format, File(dir, "x${format.suffix}"), setOf("docs"), emptyList())
            assertContentEquals(before, file.readBytes(), "$format")
        }
    }

    @Test
    fun cancelledRewriteThrows() {
        val dir = tempDir()
        val file = build(dir, ArchiveFormat.ZIP, CompressionLevel.STORE)
        assertFailsWith<ArchiveCancelled> {
            ArchiveEngine.rewrite(file, ArchiveFormat.ZIP, File(dir, "x.zip"), setOf("docs"), emptyList(), cancelled = { true })
        }
    }

    @Test
    fun unicodeAndLongNamesSurvive() {
        val longName = "d/" + "n".repeat(150) + ".txt"
        val names = listOf("ünïcödé/файл-文件.txt", longName)
        for (format in formats) {
            val dir = tempDir()
            val out = File(dir, "u${format.suffix}")
            ArchiveEngine.create(out, format, CompressionLevel.STORE).use { w ->
                for (n in names) w.file(n, 3, 1_700_000_000L, 0, ByteArrayInputStream(byteArrayOf(7, 8, 9)))
            }
            val index = ArchiveIndex(ArchiveEngine.list(out, format))
            for (n in names) {
                val e = assertNotNull(index[n], "$format $n")
                assertContentEquals(byteArrayOf(7, 8, 9), ArchiveEngine.readEntryBytes(out, format, e, 100))
            }
        }
    }

    @Test
    fun pathsThatClimbOutAreFlaggedAndNeverExtracted() {
        val dir = tempDir()
        val zip = File(dir, "evil.zip")
        ZipArchiveOutputStream(zip).use { z ->
            val e = ZipArchiveEntry("../../evil.txt")
            z.putArchiveEntry(e); z.write(byteArrayOf(1)); z.closeArchiveEntry()
            val ok = ZipArchiveEntry("fine.txt")
            z.putArchiveEntry(ok); z.write(byteArrayOf(2)); z.closeArchiveEntry()
        }
        val entries = ArchiveEngine.list(zip, ArchiveFormat.ZIP)
        val evil = entries.first { it.name == "evil.txt" }
        assertTrue(evil.unsafe)
        assertFalse(evil.isExtractable)
        val sink = Recorder()
        ArchiveEngine.extract(zip, ArchiveFormat.ZIP, entries.associate { it.ordinal to it.path }, sink) { false }
        assertEquals(listOf("fine.txt"), sink.files.keys.toList())
        assertEquals(listOf("evil.txt" to ArchiveProblem.SKIPPED_ENTRY), sink.skipped)
    }

    @Test
    fun tarLinksAreSkippedNotFollowed() {
        val dir = tempDir()
        val tar = File(dir, "links.tar")
        TarArchiveOutputStream(tar.outputStream()).use { t ->
            val data = TarArchiveEntry("real.txt").apply { size = 2 }
            t.putArchiveEntry(data); t.write(byteArrayOf(1, 2)); t.closeArchiveEntry()
            val link = TarArchiveEntry("link", TarArchiveEntry.LF_SYMLINK).apply { linkName = "/etc/passwd" }
            t.putArchiveEntry(link); t.closeArchiveEntry()
        }
        val entries = ArchiveEngine.list(tar, ArchiveFormat.TAR)
        assertEquals(ArchiveEntryKind.LINK, entries.first { it.path == "link" }.kind)
        val sink = Recorder()
        ArchiveEngine.extract(tar, ArchiveFormat.TAR, entries.associate { it.ordinal to it.path }, sink) { false }
        assertEquals(listOf("real.txt"), sink.files.keys.toList())
        assertEquals(listOf("link" to ArchiveProblem.SKIPPED_ENTRY), sink.skipped)
        // A rewrite must keep the link as a link.
        val out = File(dir, "out.tar")
        ArchiveEngine.rewrite(tar, ArchiveFormat.TAR, out, setOf("real.txt"), emptyList())
        assertEquals(ArchiveEntryKind.LINK, ArchiveEngine.list(out, ArchiveFormat.TAR).single().kind)
    }

    @Test
    fun garbageIsReportedAsCorruptNotCrashed() {
        val dir = tempDir()
        for (format in listOf(ArchiveFormat.ZIP, ArchiveFormat.SEVEN_Z)) {
            val bad = File(dir, "bad${format.suffix}").apply { writeBytes(ByteArray(200) { 7 }) }
            val failure = assertFailsWith<ArchiveException>("$format") { ArchiveEngine.list(bad, format) }
            assertEquals(ArchiveProblem.CORRUPT, failure.problem, "$format")
        }
    }

    @Test
    fun indexHandlesDuplicatesAndShadowing() {
        val a1 = ArchiveEntry("x/f", ArchiveEntryKind.FILE, 1, 0, ordinal = 0)
        val a2 = ArchiveEntry("x/f", ArchiveEntryKind.FILE, 9, 0, ordinal = 1)
        val index = ArchiveIndex(listOf(a1, a2))
        assertEquals(9L, index["x/f"]!!.size)
        assertEquals(1, index.children("x").size)
        assertEquals(listOf("x", "x/f"), index.subtree("x").map { it.path }.sorted())
        assertEquals(1, index.fileCount)
    }
}
