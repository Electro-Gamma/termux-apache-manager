package app.terminalssh.secure.sftp

import app.terminalssh.secure.archive.ArchiveEntry
import app.terminalssh.secure.archive.ArchiveEntryKind
import app.terminalssh.secure.archive.ArchiveIndex
import kotlin.test.Test
import kotlin.test.assertEquals

class ArchivePlannerTest {

    private fun file(path: String, ordinal: Int, size: Long = 10) =
        ArchiveEntry(path, ArchiveEntryKind.FILE, size, 0, ordinal = ordinal)

    private val index = ArchiveIndex(
        listOf(
            file("src/main.c", 0),
            file("src/util/a.c", 1),
            file("README", 2, 5),
        ),
    )

    @Test
    fun wholeArchiveKeepsItsLayout() {
        val plan = ArchivePlanner.plan(index, null, HashSet())
        assertEquals(setOf("src/main.c", "src/util/a.c", "README"), plan.outputs.values.toSet())
        assertEquals(25L, plan.totalBytes)
    }

    @Test
    fun existingTopLevelNamesAreNeverOverwritten() {
        val plan = ArchivePlanner.plan(index, null, hashSetOf("src", "README"))
        assertEquals(setOf("src (copy)/main.c", "src (copy)/util/a.c", "README (copy)"), plan.outputs.values.toSet())
    }

    @Test
    fun pickedItemsLandAtTheTopOfTheDestination() {
        val plan = ArchivePlanner.plan(index, listOf("src/util", "README"), HashSet())
        assertEquals(setOf("util/a.c", "README"), plan.outputs.values.toSet())
    }

    @Test
    fun aFolderPickedWithItsOwnContentsIsExtractedOnce() {
        val plan = ArchivePlanner.plan(index, listOf("src", "src/main.c"), HashSet())
        assertEquals(setOf("src/main.c", "src/util/a.c"), plan.outputs.values.toSet())
    }

    @Test
    fun twoPickedItemsWithTheSameNameGetDifferentNames() {
        val idx = ArchiveIndex(listOf(file("a/x.txt", 0), file("b/x.txt", 1)))
        val plan = ArchivePlanner.plan(idx, listOf("a/x.txt", "b/x.txt"), HashSet())
        assertEquals(setOf("x.txt", "x (copy).txt"), plan.outputs.values.toSet())
    }

    @Test
    fun permissionTextBecomesBits() {
        assertEquals(493, ArchivePlanner.modeFromPermissionString("drwxr-xr-x"))
        assertEquals(420, ArchivePlanner.modeFromPermissionString("-rw-r--r--"))
        assertEquals(0, ArchivePlanner.modeFromPermissionString("garbage"))
    }

    @Test
    fun onlyExecutableFilesKeepTheirMode() {
        assertEquals(0, ArchivePlanner.extractedFileMode(420))
        assertEquals(493, ArchivePlanner.extractedFileMode(493))
        assertEquals(493, ArchivePlanner.extractedFileMode(511)) // group/other write dropped
        assertEquals(0, ArchivePlanner.extractedFileMode(0))
    }
}
