package app.terminalssh.secure.ssh

import org.junit.Assert.assertEquals
import org.junit.Test

class TranscriptBufferTest {
    private fun TranscriptBuffer.feed(s: String) = append(s.encodeToByteArray())

    @Test fun keepsMoreThanOneScreen() {
        val t = TranscriptBuffer()
        repeat(500) { t.feed("line $it\r\n") }
        val lines = t.text().lines()
        assertEquals(500, lines.size)
        assertEquals("line 0", lines.first())
        assertEquals("line 499", lines.last())
    }

    @Test fun stripsColourAndTitleSequences() {
        val t = TranscriptBuffer()
        t.feed("\u001b]0;title\u0007\u001b[1;32mok\u001b[0m done\r\n")
        assertEquals("ok done", t.text())
    }

    @Test fun appliesBackspaceEditing() {
        val t = TranscriptBuffer()
        t.feed("ls -x\b\u001b[K\r\n")
        assertEquals("ls -", t.text())
    }

    @Test fun carriageReturnOverwrites() {
        val t = TranscriptBuffer()
        t.feed("10%\r50%\r100%\r\n")
        assertEquals("100%", t.text())
    }

    @Test fun joinsMultiByteCharactersSplitAcrossChunks() {
        val t = TranscriptBuffer()
        val bytes = "é\r\n".encodeToByteArray()
        t.append(bytes.copyOfRange(0, 1)); t.append(bytes.copyOfRange(1, bytes.size))
        assertEquals("é", t.text())
    }

    @Test fun dropsOldestLinesPastTheLimit() {
        val t = TranscriptBuffer(maxChars = 50)
        repeat(100) { t.feed("row $it\r\n") }
        assert(t.text().lines().last() == "row 99")
        assert(t.text().length <= 60)
    }
}
