package app.terminalssh.secure.serial

import kotlin.test.Test
import kotlin.test.assertContentEquals
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class ControlKeyLatchTest {

    @Test
    fun `without a latch the bytes pass through unchanged`() {
        val latch = ControlKeyLatch()
        assertContentEquals(byteArrayOf('c'.code.toByte()), latch.apply(byteArrayOf('c'.code.toByte())))
    }

    @Test
    fun `ctrl turns a letter into its control character and then releases`() {
        val latch = ControlKeyLatch()
        latch.toggleCtrl()
        assertTrue(latch.ctrl.value)
        assertContentEquals(byteArrayOf(0x03), latch.apply(byteArrayOf('c'.code.toByte())))
        assertFalse(latch.ctrl.value)
        // The next key is plain again.
        assertContentEquals(byteArrayOf('c'.code.toByte()), latch.apply(byteArrayOf('c'.code.toByte())))
    }

    @Test
    fun `ctrl handles upper case and the punctuation controls`() {
        assertEquals(0x04, ControlKeyLatch.controlCode('D'))
        assertEquals(0, ControlKeyLatch.controlCode('@'))
        assertEquals(27, ControlKeyLatch.controlCode('['))
        assertEquals(127, ControlKeyLatch.controlCode('?'))
        assertEquals(-1, ControlKeyLatch.controlCode('1'))
    }

    @Test
    fun `alt prefixes escape, but not to a sequence that already starts with it`() {
        val latch = ControlKeyLatch()
        latch.toggleAlt()
        assertContentEquals(byteArrayOf(0x1B, 'x'.code.toByte()), latch.apply(byteArrayOf('x'.code.toByte())))
        latch.toggleAlt()
        val arrowUp = byteArrayOf(0x1B, '['.code.toByte(), 'A'.code.toByte())
        assertContentEquals(arrowUp, latch.apply(arrowUp))
    }

    @Test
    fun `ctrl and alt are mutually exclusive`() {
        val latch = ControlKeyLatch()
        latch.toggleCtrl()
        latch.toggleAlt()
        assertFalse(latch.ctrl.value)
        assertTrue(latch.alt.value)
    }

    @Test
    fun `a ctrl latch is consumed even when the key has no control form`() {
        val latch = ControlKeyLatch()
        latch.toggleCtrl()
        assertContentEquals(byteArrayOf('1'.code.toByte()), latch.apply(byteArrayOf('1'.code.toByte())))
        assertFalse(latch.ctrl.value)
    }
}
