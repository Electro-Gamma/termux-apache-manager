package com.vncviewer.app.vnc

/**
 * What a session needs from a VNC engine. Implemented by the built-in RFB client
 * ([VncClient]) and by the RealVNC engine ([com.vncviewer.app.realvnc.RealVncBackend]).
 * All methods may be called from the main thread and must not block.
 */
interface RemoteBackend {
    fun start()
    fun close()

    /** Ask for / redraw the whole screen. */
    fun refresh()

    fun sendPointer(x: Int, y: Int, buttonMask: Int)
    fun sendPointerMove(x: Int, y: Int, buttonMask: Int)
    fun sendKey(keySym: Int, down: Boolean)
    fun sendClipboard(text: String)

    /** The app went to / came back from the background. */
    fun setFocused(focused: Boolean) {
    }

    /** Picture quality preset (RealVNC engine only): Auto, High, Medium, Low. */
    fun setQuality(quality: String) {
    }

    /** Reconnect on its own when the link drops (RealVNC engine only). */
    fun setAutoReconnect(enabled: Boolean) {
    }

    /** Label/value rows for the "Connection info" dialog; delivered on the main thread. */
    fun connectionInfo(callback: (List<Pair<String, String>>) -> Unit) {
        callback(emptyList())
    }
}
