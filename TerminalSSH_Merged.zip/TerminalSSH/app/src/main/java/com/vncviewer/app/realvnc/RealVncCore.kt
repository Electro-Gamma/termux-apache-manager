// SPDX-License-Identifier: GPL-3.0-or-later
//
// Kotlin port of the RealVNC backend of Vento (https://github.com/pgaskin/vento,
// (C) 2026 Patrick Gaskin, GPL-3.0-or-later): RealVncCore.java.
package com.vncviewer.app.realvnc

import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import com.realvnc.vncviewer.jni.AuthkeyStoreAndroid
import com.realvnc.vncviewer.jni.Bindings
import com.realvnc.vncviewer.jni.ConfigurationBindings
import java.io.File
import java.util.concurrent.CountDownLatch

/**
 * The process-wide half of the RealVNC engine: load the native library, start the one
 * thread that is allowed to talk to it, and initialise it - once.
 *
 * The single thread is not a style choice. The core registers its socket on whichever
 * thread called createSession and delivers every callback there, so that thread must run
 * a Looper and must not be the main one.
 */
object RealVncCore {

    const val TAG = "RealVnc"

    /** Our own namespace: the core makes a data directory with this name under filesDir. */
    private const val APP_NAME = "com.vncviewer.app"

    @Volatile
    private var handler: Handler? = null
    private var initialised = false
    private var loaded = false
    private var loadError: String? = null

    /** Null when the RealVNC engine can run on this phone, otherwise a human-readable reason. */
    fun unavailableReason(): String? {
        if (Build.VERSION.SDK_INT < 26) {
            return "The RealVNC engine needs Android 8.0 or newer."
        }
        var arm64 = false
        for (abi in Build.SUPPORTED_ABIS) {
            if (abi == "arm64-v8a") arm64 = true
        }
        if (!arm64) {
            return "The RealVNC engine only runs on 64-bit ARM (arm64-v8a) phones."
        }
        return ensureLoaded()
    }

    @Synchronized
    private fun ensureLoaded(): String? {
        if (loaded) return null
        val previous = loadError
        if (previous != null) return previous
        return try {
            // libvncviewer.so needs libc++_shared.so; load that first.
            System.loadLibrary("c++_shared")
            System.loadLibrary("vncviewer")
            loaded = true
            null
        } catch (e: UnsatisfiedLinkError) {
            val msg = "The RealVNC native library is not included in this build of the app " +
                "(rebuild with arm64-v8a.zip uploaded). Details: ${e.message}"
            loadError = msg
            msg
        }
    }

    /** The core's directory (the core creates it; its contents are its own business). */
    fun dataDir(context: Context): File = File(context.applicationContext.filesDir, APP_NAME)

    /** Idempotent. Blocks for a few milliseconds the first time. */
    @Synchronized
    fun start(context: Context): Handler {
        val existing = handler
        if (initialised && existing != null) return existing

        val app = context.applicationContext
        val problem = ensureLoaded()
        if (problem != null) throw IllegalStateException(problem)

        // No client certificates are enrolled, so identity authentication has nothing to
        // choose from and falls back to asking for a password.
        AuthkeyStoreAndroid.configure(app, emptySet<String>())

        val thread = HandlerThread("VncCore")
        thread.start()
        val h = Handler(thread.looper)
        handler = h

        try {
            runBlocking {
                val logDir = File(app.filesDir, "vnclog")
                logDir.mkdirs()

                val global = HashMap<String, String>()
                // The cursor is drawn by us, over a desktop the viewport may be magnifying.
                global["UseLocalCursor"] = "true"
                global["Locale"] = "en_US"
                global["SctpMaxMtu"] = "1200"

                Bindings.initApp(
                    APP_NAME,
                    "1",
                    app.filesDir.absolutePath,
                    logDir.absolutePath,
                    "vncviewer",
                    app,
                    global,
                    true,
                    Bindings.LogMode.LOG_DEBUG
                )
                // Everything this wants is about RealVNC cloud accounts, which we do not use.
                Bindings.initViewer()
                RealVncPrompts.registerFactories()
                Log.i(TAG, "core initialised on " + Thread.currentThread().name)
            }
        } catch (t: Throwable) {
            thread.quitSafely()
            handler = null
            throw t
        }
        initialised = true
        return h
    }

    /** Run on the core thread, whether or not we are already on it. */
    fun post(block: () -> Unit) {
        val h = handler ?: return
        if (Thread.currentThread() === h.looper.thread) {
            block()
        } else {
            h.post(Runnable { block() })
        }
    }

    fun postDelayed(r: Runnable, delayMs: Long) {
        handler?.postDelayed(r, delayMs)
    }

    fun cancel(r: Runnable) {
        handler?.removeCallbacks(r)
    }

    /** Run on the core thread and wait; a throw comes back to the caller. */
    fun runBlocking(block: () -> Unit) {
        val h = handler ?: throw IllegalStateException("RealVNC core is not started")
        if (Thread.currentThread() === h.looper.thread) {
            block()
            return
        }
        val latch = CountDownLatch(1)
        var failure: Throwable? = null
        h.post(Runnable {
            try {
                block()
            } catch (t: Throwable) {
                failure = t
            } finally {
                latch.countDown()
            }
        })
        latch.await()
        val f = failure
        if (f != null) throw f
    }

    /** Set any parameter in the core's registry (including ones no UI offers). */
    fun setParameter(name: String, value: String) {
        post { ConfigurationBindings.set(name, value, 10, false) }
    }
}
