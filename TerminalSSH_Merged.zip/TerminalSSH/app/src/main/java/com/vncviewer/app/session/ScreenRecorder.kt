package com.vncviewer.app.session

import android.content.ClipData
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.provider.MediaStore
import android.util.Log
import android.view.Surface
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** The pointer at one instant: its shape, hot spot, and where it is on the desktop (desktop pixels). */
class CursorFrame(val bitmap: Bitmap, val hotX: Int, val hotY: Int, val x: Float, val y: Float)

/**
 * Records the remote desktop to an MP4, the video counterpart of [Screenshot].
 *
 * What is filmed is the desktop itself (the framebuffer, at the size the far end has it, capped at
 * 1080p), not the phone's screen, so no screen-capture permission or dialog is involved and
 * nothing of the phone's own UI ends up in the video. Frames are drawn onto a hardware encoder's
 * input surface at a steady rate, so a desktop that is not changing still produces a video of the
 * right length. The pointer is drawn onto every frame, at the remote cursor's shape and position,
 * at twice its desktop size so it stays easy to follow at video scale.
 *
 * Optionally the phone's microphone is recorded too (a second, AAC track). The microphone is only
 * ever opened when [start] is asked for it; a recording without it never touches the audio
 * hardware and needs no permission.
 *
 * Android 10+: the file goes into the shared Movies/VncViewer folder (it shows up in the gallery).
 * Older versions: it is written to the cache and handed to the share sheet when it ends.
 */
class ScreenRecorder(
    context: Context,
    private val source: () -> Bitmap?,
    private val cursor: () -> CursorFrame?,
    private val title: String
) {
    private val app = context.applicationContext
    private val main = Handler(Looper.getMainLooper())

    @Volatile
    private var running = false
    private var worker: Thread? = null
    private var audioWorker: Thread? = null

    /** When the first frame was posted (monotonic microseconds), the zero of the audio's clock. */
    @Volatile
    private var videoStartWallUs = 0L

    val isRecording: Boolean get() = running

    /**
     * Begin recording; false if there is no picture yet, the device has no usable encoder, or the
     * microphone was asked for and could not be opened (no permission, or in use).
     */
    fun start(withMic: Boolean = false): Boolean {
        if (running) return true
        val first = source() ?: return false
        if (first.isRecycled || first.width <= 0 || first.height <= 0) return false

        // Even sides, and no bigger than 1920 on the long edge: what every AVC encoder takes.
        val k = Math.min(1f, MAX_SIDE.toFloat() / Math.max(first.width, first.height))
        val w = Math.max(2, (first.width * k).toInt() and 1.inv())
        val h = Math.max(2, (first.height * k).toInt() and 1.inv())

        val out = try {
            Output.open(app, fileName())
        } catch (e: Exception) {
            Log.w(TAG, "opening the output", e)
            return false
        }

        val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            // A desktop is mostly flat colour and text: modest bits go a long way.
            setInteger(MediaFormat.KEY_BIT_RATE, (w * h * FPS * 0.12f).toInt().coerceIn(1_000_000, 10_000_000))
            setInteger(MediaFormat.KEY_FRAME_RATE, FPS)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
        }
        val codec: MediaCodec
        val surface: Surface
        try {
            codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            surface = codec.createInputSurface()
            codec.start()
        } catch (e: Exception) {
            Log.w(TAG, "starting the encoder", e)
            out.discard()
            return false
        }

        var mic: Mic? = null
        if (withMic) {
            mic = try {
                Mic.open()
            } catch (e: Exception) {
                Log.w(TAG, "opening the microphone", e)
                null
            }
            if (mic == null) {
                try { codec.stop() } catch (_: Exception) {}
                codec.release()
                surface.release()
                out.discard()
                return false
            }
        }

        val mux = Mux(out, if (mic != null) 2 else 1)
        running = true
        if (mic != null) {
            audioWorker = Thread({ runAudio(mic, mux) }, "screen-recorder-audio").also {
                it.isDaemon = true
                it.start()
            }
        }
        worker = Thread({ run(codec, surface, mux, w, h) }, "screen-recorder").also {
            it.isDaemon = true
            it.start()
        }
        return true
    }

    /** Stop and finish the file; it is saved on the recorder's own thread. */
    fun stop() {
        running = false
    }

    private fun run(codec: MediaCodec, surface: Surface, mux: Mux, w: Int, h: Int) {
        val info = MediaCodec.BufferInfo()
        val sink = Drain(codec, mux, info, rebase = true)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG)
        val src = Rect()
        val dst = Rect(0, 0, w, h)
        val cursorDst = RectF()
        var failed = false
        try {
            val step = 1000L / FPS
            var next = SystemClock.elapsedRealtime()
            while (running) {
                val bmp = source()
                if (bmp != null && !bmp.isRecycled) {
                    src.set(0, 0, bmp.width, bmp.height)
                    if (videoStartWallUs == 0L) videoStartWallUs = System.nanoTime() / 1000
                    val canvas = surface.lockHardwareCanvas()
                    try {
                        canvas.drawBitmap(bmp, src, dst, paint)
                        val cur = cursor()
                        if (cur != null && !cur.bitmap.isRecycled) {
                            // Desktop pixels to video pixels, then the pointer a little larger.
                            val sx = w.toFloat() / bmp.width
                            val sy = h.toFloat() / bmp.height
                            val longest = Math.max(cur.bitmap.width, cur.bitmap.height)
                            val cs = Math.min(sx * 2f, 64f / longest)
                            val px = cur.x * sx - cur.hotX * cs
                            val py = cur.y * sy - cur.hotY * cs
                            cursorDst.set(px, py, px + cur.bitmap.width * cs, py + cur.bitmap.height * cs)
                            canvas.drawBitmap(cur.bitmap, null, cursorDst, paint)
                        }
                    } finally {
                        surface.unlockCanvasAndPost(canvas)
                    }
                }
                sink.drain(false)
                next += step
                val wait = next - SystemClock.elapsedRealtime()
                if (wait > 0) SystemClock.sleep(wait) else next = SystemClock.elapsedRealtime()
            }
            codec.signalEndOfInputStream()
            sink.drain(true)
        } catch (e: Exception) {
            Log.w(TAG, "recording", e)
            failed = true
        } finally {
            running = false
            try { codec.stop() } catch (_: Exception) {}
            codec.release()
            surface.release()
        }
        // The audio thread stops on the same flag; wait for its last samples before closing the file.
        audioWorker?.let { try { it.join(3000) } catch (_: InterruptedException) {} }
        mux.finish()
        val saved = if (failed && !mux.wrote) null else mux.out.finish(mux.wrote)
        main.post { announce(saved, mux.wrote) }
    }

    private fun announce(saved: Saved?, wrote: Boolean) {
        if (!wrote || saved == null) {
            Toast.makeText(app, "Nothing was recorded.", Toast.LENGTH_SHORT).show()
            return
        }
        if (saved.shareUri != null) {
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "video/mp4"
                putExtra(Intent.EXTRA_STREAM, saved.shareUri)
                clipData = ClipData.newUri(app.contentResolver, "recording", saved.shareUri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            app.startActivity(Intent.createChooser(send, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } else {
            Toast.makeText(app, if (StorageAccess.has(app)) "Recording saved to VncViewer/recorded" else "Recording saved to Movies/VncViewer", Toast.LENGTH_LONG).show()
        }
    }

    private fun fileName(): String {
        val b = StringBuilder()
        for (c in title) {
            if (b.length >= 40) break
            if (c in 'a'..'z' || c in 'A'..'Z' || c in '0'..'9') b.append(c)
            else if (b.isNotEmpty() && b.last() != '-') b.append('-')
        }
        while (b.isNotEmpty() && b.last() == '-') b.setLength(b.length - 1)
        if (b.isEmpty()) b.append("desktop")
        val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
        return "$b-$stamp.mp4"
    }

    /**
     * The file's muxer, shared by the video and audio threads. It can only start once every track
     * has said what it is, so samples that arrive earlier (the video's first key frame) wait here.
     */
    private class Mux(val out: Output, private val tracksWanted: Int) {
        private class Pending(val track: Int, val data: ByteBuffer, val info: MediaCodec.BufferInfo)

        private var added = 0
        private var started = false
        private val pending = ArrayList<Pending>()
        @Volatile
        var wrote = false

        @Synchronized
        fun addTrack(format: MediaFormat): Int {
            val t = out.muxer.addTrack(format)
            added++
            if (added == tracksWanted) {
                out.muxer.start()
                started = true
                for (p in pending) put(p.track, p.data, p.info)
                pending.clear()
            }
            return t
        }

        @Synchronized
        fun write(track: Int, buf: ByteBuffer, info: MediaCodec.BufferInfo) {
            if (started) {
                buf.position(info.offset)
                buf.limit(info.offset + info.size)
                put(track, buf, info)
            } else {
                buf.position(info.offset)
                buf.limit(info.offset + info.size)
                val copy = ByteBuffer.allocate(info.size)
                copy.put(buf)
                copy.flip()
                val i = MediaCodec.BufferInfo()
                i.set(0, info.size, info.presentationTimeUs, info.flags)
                pending.add(Pending(track, copy, i))
            }
        }

        private fun put(track: Int, buf: ByteBuffer, info: MediaCodec.BufferInfo) {
            out.muxer.writeSampleData(track, buf, info)
            wrote = true
        }

        @Synchronized
        fun finish() {
            if (started) {
                try { out.muxer.stop() } catch (e: Exception) { Log.w(TAG, "closing the file", e) }
            }
            try { out.muxer.release() } catch (_: Exception) {}
        }
    }

    /**
     * One encoder's output into the muxer. The video's clock starts at its first sample; the
     * audio's is already relative to the video's first frame.
     */
    private class Drain(
        val codec: MediaCodec,
        val mux: Mux,
        val info: MediaCodec.BufferInfo,
        val rebase: Boolean
    ) {
        private var track = -1
        private var baseUs = -1L

        fun drain(end: Boolean) {
            var idle = 0
            while (true) {
                val i = codec.dequeueOutputBuffer(info, if (end) 10_000L else 0L)
                when {
                    i == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                        if (!end || ++idle > 300) return
                    }
                    i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        track = mux.addTrack(codec.outputFormat)
                    }
                    i >= 0 -> {
                        val buf = codec.getOutputBuffer(i)
                        if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                        if (buf != null && info.size > 0 && track >= 0) {
                            if (rebase) {
                                if (baseUs < 0) baseUs = info.presentationTimeUs
                                info.presentationTimeUs = Math.max(0L, info.presentationTimeUs - baseUs)
                            }
                            mux.write(track, buf, info)
                        }
                        val eos = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                        codec.releaseOutputBuffer(i, false)
                        if (eos) return
                    }
                }
            }
        }
    }

    /** The microphone and the AAC encoder that goes with it. */
    private class Mic(val record: AudioRecord, val encoder: MediaCodec, val bufferSize: Int) {
        companion object {
            fun open(): Mic? {
                val min = AudioRecord.getMinBufferSize(
                    AUDIO_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
                )
                if (min <= 0) return null
                val size = Math.max(min * 2, 8192)
                // Throws SecurityException without the permission: the caller turns that into "no".
                val rec = AudioRecord(
                    MediaRecorder.AudioSource.MIC, AUDIO_RATE,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, size
                )
                if (rec.state != AudioRecord.STATE_INITIALIZED) {
                    rec.release()
                    return null
                }
                val format = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, AUDIO_RATE, 1).apply {
                    setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                    setInteger(MediaFormat.KEY_BIT_RATE, 96_000)
                    setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, size)
                }
                val enc: MediaCodec
                try {
                    enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
                    enc.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                    enc.start()
                } catch (e: Exception) {
                    rec.release()
                    throw e
                }
                return Mic(rec, enc, size)
            }
        }
    }

    /** Microphone to AAC to the muxer, on a clock that starts with the video's first frame. */
    private fun runAudio(mic: Mic, mux: Mux) {
        val info = MediaCodec.BufferInfo()
        val drain = Drain(mic.encoder, mux, info, rebase = false)
        val pcm = ByteArray(mic.bufferSize / 2)
        var samples = 0L
        var offsetUs = -1L
        try {
            // Nothing is heard before there is something to see.
            while (running && videoStartWallUs == 0L) SystemClock.sleep(5)
            if (!running) return
            mic.record.startRecording()
            while (running) {
                val n = mic.record.read(pcm, 0, pcm.size)
                if (n <= 0) {
                    if (n < 0) break
                    continue
                }
                if (offsetUs < 0) {
                    val readUs = n / 2L * 1_000_000L / AUDIO_RATE
                    offsetUs = Math.max(0L, System.nanoTime() / 1000 - videoStartWallUs - readUs)
                }
                var off = 0
                while (off < n && running) {
                    val i = mic.encoder.dequeueInputBuffer(10_000L)
                    if (i < 0) {
                        drain.drain(false)
                        continue
                    }
                    val ib = mic.encoder.getInputBuffer(i) ?: continue
                    ib.clear()
                    val len = Math.min(ib.remaining(), n - off)
                    ib.put(pcm, off, len)
                    mic.encoder.queueInputBuffer(i, 0, len, offsetUs + samples * 1_000_000L / AUDIO_RATE, 0)
                    samples += len / 2
                    off += len
                }
                drain.drain(false)
            }
        } catch (e: Exception) {
            Log.w(TAG, "recording the microphone", e)
        } finally {
            try {
                // End the stream so the encoder flushes its last buffers into the file.
                var tries = 0
                while (tries++ < 50) {
                    val i = mic.encoder.dequeueInputBuffer(10_000L)
                    if (i >= 0) {
                        mic.encoder.queueInputBuffer(
                            i, 0, 0, Math.max(0L, offsetUs) + samples * 1_000_000L / AUDIO_RATE,
                            MediaCodec.BUFFER_FLAG_END_OF_STREAM
                        )
                        break
                    }
                }
                drain.drain(true)
            } catch (e: Exception) {
                Log.w(TAG, "finishing the microphone track", e)
            }
            try { mic.record.stop() } catch (_: Exception) {}
            mic.record.release()
            try { mic.encoder.stop() } catch (_: Exception) {}
            mic.encoder.release()
        }
    }

    private class Saved(val shareUri: Uri?)

    /** Where the video goes: the gallery on Android 10+, the cache (then the share sheet) before. */
    private class Output private constructor(
        val muxer: MediaMuxer,
        private val app: Context,
        private val pfd: ParcelFileDescriptor?,
        private val uri: Uri?,
        private val file: File?,
        private val persistent: Boolean = false
    ) {
        fun discard() {
            try { muxer.release() } catch (_: Exception) {}
            close()
            if (uri != null) app.contentResolver.delete(uri, null, null)
            file?.delete()
        }

        /** Called after the muxer is finished; null shareUri means it is already in the gallery. */
        fun finish(wrote: Boolean): Saved? {
            close()
            if (!wrote) {
                if (uri != null) app.contentResolver.delete(uri, null, null)
                file?.delete()
                return null
            }
            if (uri != null) {
                val v = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                app.contentResolver.update(uri, v, null, null)
                return Saved(null)
            }
            val f = file ?: return null
            if (persistent) {
                android.media.MediaScannerConnection.scanFile(app, arrayOf(f.absolutePath), arrayOf("video/mp4"), null)
                return Saved(null)
            }
            return Saved(FileProvider.getUriForFile(app, app.packageName + ".files", f))
        }

        private fun close() {
            try { pfd?.close() } catch (_: Exception) {}
        }

        companion object {
            fun open(app: Context, name: String): Output {
                // With all-files access: a plain folder, <storage>/VncViewer/recorded.
                if (StorageAccess.has(app)) {
                    val dir = StorageAccess.folder("recorded")
                    if (dir != null) {
                        val f = File(dir, name)
                        return Output(MediaMuxer(f.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4), app, null, null, f, true)
                    }
                }
                Handler(Looper.getMainLooper()).post { StorageAccess.request(app) }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val v = ContentValues().apply {
                        put(MediaStore.Video.Media.DISPLAY_NAME, name)
                        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                        put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/VncViewer")
                        put(MediaStore.Video.Media.IS_PENDING, 1)
                    }
                    val uri = app.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)
                        ?: throw IllegalStateException("no MediaStore entry")
                    val pfd = app.contentResolver.openFileDescriptor(uri, "rw")
                        ?: throw IllegalStateException("no file descriptor")
                    return Output(MediaMuxer(pfd.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4), app, pfd, uri, null)
                }
                val dir = File(app.cacheDir, "recordings")
                dir.listFiles()?.forEach { it.delete() }
                if (!dir.isDirectory && !dir.mkdirs()) throw IllegalStateException("no cache folder")
                val f = File(dir, name)
                return Output(MediaMuxer(f.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4), app, null, null, f)
            }
        }
    }

    companion object {
        private const val TAG = "ScreenRecorder"
        private const val FPS = 15
        private const val MAX_SIDE = 1920
        private const val AUDIO_RATE = 44100
    }
}
