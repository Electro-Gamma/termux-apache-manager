package com.vncviewer.app.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import com.vncviewer.app.input.AppSettings
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.concurrent.Executors

/**
 * The desktop preview on a home card: the last screenful of a session, written when the
 * session is left or closed, sealed with the keystore key, and read back off the main thread.
 *
 * One thread does all the reading and writing, so a read queued behind a write sees it and two
 * quick writes never touch the same file at once.
 */
object Thumbnails {
    private const val MAX_SIDE = 640

    private val io = Executors.newSingleThreadExecutor { r ->
        Thread(r, "previews").apply { isDaemon = true }
    }
    private val dispatcher = io.asCoroutineDispatcher()

    /** Bumped when a preview changes, so a card showing the old picture re-reads it. */
    private val versions = mutableStateMapOf<String, Int>()
    private val epoch = mutableIntStateOf(0)

    fun version(id: String): Int = epoch.intValue + (versions[id] ?: 0)

    private fun dir(ctx: Context): File {
        val d = File(ctx.applicationContext.filesDir, "thumbnails")
        if (!d.isDirectory) d.mkdirs()
        return d
    }

    private fun file(ctx: Context, id: String) = File(dir(ctx), "${id.filter { it.isLetterOrDigit() || it == '-' }}.sealed")

    /** A small copy of a live framebuffer, taken on the calling thread so the session may go on drawing. */
    fun snapshot(src: Bitmap?): Bitmap? {
        if (src == null || src.isRecycled || src.width <= 0 || src.height <= 0) return null
        return try {
            val scale = MAX_SIDE.toFloat() / maxOf(src.width, src.height)
            if (scale >= 1f) {
                src.copy(Bitmap.Config.ARGB_8888, false)
            } else {
                Bitmap.createScaledBitmap(
                    src,
                    maxOf(1, Math.round(src.width * scale)),
                    maxOf(1, Math.round(src.height * scale)),
                    true
                )
            }
        } catch (e: Exception) {
            null
        }
    }

    /** Encode, seal and write [bmp] (already a [snapshot]) on the preview thread. */
    fun save(ctx: Context, id: String, bmp: Bitmap?) {
        if (bmp == null || !AppSettings.previews(ctx)) return
        val app = ctx.applicationContext
        // Before the write is queued: a card recomposing now will then read behind it.
        versions[id] = (versions[id] ?: 0) + 1
        io.execute {
            try {
                val png = ByteArrayOutputStream()
                bmp.compress(Bitmap.CompressFormat.PNG, 100, png)
                // No key, no preview: never a plain PNG as a consolation.
                val sealed = SecretBox.sealBytes(png.toByteArray()) ?: return@execute
                file(app, id).writeBytes(sealed)
            } catch (_: Exception) {
            }
        }
    }

    /** The preview, or null when the connection has never been opened (or it cannot be opened). */
    suspend fun read(ctx: Context, id: String): Bitmap? {
        val app = ctx.applicationContext
        return withContext(dispatcher) {
            try {
                val f = file(app, id)
                if (!f.isFile) return@withContext null
                val png = SecretBox.openBytes(f.readBytes()) ?: return@withContext null
                BitmapFactory.decodeByteArray(png, 0, png.size)
            } catch (e: Exception) {
                null
            }
        }
    }

    fun delete(ctx: Context, id: String) {
        val app = ctx.applicationContext
        versions[id] = (versions[id] ?: 0) + 1
        io.execute { try { file(app, id).delete() } catch (_: Exception) { } }
    }
}
