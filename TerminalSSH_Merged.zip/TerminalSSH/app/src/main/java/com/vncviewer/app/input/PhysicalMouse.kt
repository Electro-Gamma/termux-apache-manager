// SPDX-License-Identifier: MIT
//
// Kotlin port of Vento's PhysicalMouse.java (https://github.com/pgaskin/vento, control/
// module, (C) 2026 Patrick Gaskin, MIT).
package com.vncviewer.app.input

import android.view.MotionEvent

/**
 * A real mouse (USB, Bluetooth, DeX). Captured, it reports relative motion; uncaptured,
 * deltas are derived from the local pointer's position. It has a button source of its own
 * so releasing it cannot let go of a button something else is holding.
 */
class PhysicalMouse(private val cfg: Config, private val sink: MouseSink) {

    interface Listener {
        fun mouseActivity()
    }

    private var listener: Listener? = null
    private var held = 0
    private val wheel = WheelSteps(sink)
    private var lastX = 0f
    private var lastY = 0f
    private var havePosition = false
    private var seen = false

    fun setListener(l: Listener?) {
        listener = l
    }

    fun heldMask(): Int = held
    fun seen(): Boolean = seen

    fun motion(dx: Float, dy: Float) {
        if (dx == 0f && dy == 0f) return
        seen = true
        sink.mouseMove(dx * cfg.mouseSpeed, dy * cfg.mouseSpeed)
    }

    /** Android button-state bits (primary 1, secondary 2, tertiary 4, back 8, forward 16). */
    fun buttonState(androidButtons: Int) {
        val now = toRfbMask(androidButtons)
        if (now == held) return
        seen = true
        val pressed = now and held.inv()
        val released = held and now.inv()
        held = now
        if (released != 0) sink.mouseUp(released)
        if (pressed != 0) sink.mouseDown(pressed)
        listener?.mouseActivity()
    }

    fun scroll(hscroll: Float, vscroll: Float) {
        if (hscroll == 0f && vscroll == 0f) return
        seen = true
        val sign = if (cfg.naturalScrolling) -1.0f else 1.0f
        wheel.add(hscroll * sign, -vscroll * sign, cfg.mouseWheelStep)
    }

    fun cancel() {
        havePosition = false
        wheel.reset()
        if (held != 0) {
            sink.mouseUp(held)
            held = 0
            listener?.mouseActivity()
        }
    }

    /** An uncaptured pointer moved to (x, y): turn the position into a delta. */
    fun moveTo(x: Float, y: Float) {
        if (havePosition) motion(x - lastX, y - lastY)
        lastX = x
        lastY = y
        havePosition = true
    }

    fun leave() {
        havePosition = false
    }

    /** Events delivered while the pointer is captured: relative motion, buttons and wheel. */
    fun onCapturedPointerEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_MOVE, MotionEvent.ACTION_HOVER_MOVE -> {
                for (h in 0 until ev.historySize) motion(ev.getHistoricalX(h), ev.getHistoricalY(h))
                motion(ev.x, ev.y)
            }
            MotionEvent.ACTION_BUTTON_PRESS, MotionEvent.ACTION_BUTTON_RELEASE,
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_UP -> buttonState(ev.buttonState)
            MotionEvent.ACTION_SCROLL -> scroll(
                ev.getAxisValue(MotionEvent.AXIS_HSCROLL),
                ev.getAxisValue(MotionEvent.AXIS_VSCROLL)
            )
            else -> return false
        }
        return true
    }

    companion object {
        fun toRfbMask(androidButtons: Int): Int {
            var m = 0
            if ((androidButtons and 1) != 0) m = m or Button.LEFT.mask
            if ((androidButtons and 2) != 0) m = m or Button.RIGHT.mask
            if ((androidButtons and 4) != 0) m = m or Button.MIDDLE.mask
            if ((androidButtons and 8) != 0) m = m or Button.BACK.mask
            if ((androidButtons and 16) != 0) m = m or Button.FORWARD.mask
            return m
        }
    }
}
