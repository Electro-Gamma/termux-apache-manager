// SPDX-License-Identifier: GPL-3.0-or-later
//
// Kotlin port of the RealVNC backend of Vento (https://github.com/pgaskin/vento,
// (C) 2026 Patrick Gaskin, GPL-3.0-or-later): RealVncPrompts.java.
package com.vncviewer.app.realvnc

import android.util.Log
import com.realvnc.vncviewer.jni.AuthkeyChoiceDlgBindings
import com.realvnc.vncviewer.jni.InteractiveTextDlgBindings
import com.realvnc.vncviewer.jni.MsgBoxBindings
import com.realvnc.vncviewer.jni.PasswdDlgBindings
import com.realvnc.vncviewer.jni.ReconnectorBindings
import com.realvnc.vncviewer.jni.SaveCredentialsBindings
import com.realvnc.vncviewer.jni.SaveIdentityBindings
import com.realvnc.vncviewer.jni.SecurityDlgBindings
import com.realvnc.vncviewer.jni.SecurityNotificationBindings
import com.realvnc.vncviewer.jni.SessionBindings
import com.realvnc.vncviewer.jni.StatusNotificationBindings
import com.vncviewer.app.vnc.CredentialsPrompt
import com.vncviewer.app.vnc.MessagePrompt
import com.vncviewer.app.vnc.MessageSeverity
import com.vncviewer.app.vnc.TrustEncryption
import com.vncviewer.app.vnc.TrustIdentity
import com.vncviewer.app.vnc.TrustPrompt
import java.util.IdentityHashMap

/**
 * The prompt families of the RealVNC core, bridged onto our own prompt types.
 *
 * The factories are process-wide, so this is where the Session a prompt carries is turned
 * back into the backend that owns it. A prompt can arrive during createSession, before the
 * handle it is keyed on exists; every createSession happens on the one core thread, so a
 * single "pending" slot covers that window.
 */
internal object RealVncPrompts {

    private val owners = IdentityHashMap<SessionBindings.Session, RealVncBackend>()
    private val tokenOwners = HashMap<Long, RealVncBackend>()

    /** The backend whose createSession has not returned yet. */
    @Volatile
    private var pending: RealVncBackend? = null

    @Synchronized
    fun attach(session: SessionBindings.Session, backend: RealVncBackend) {
        owners[session] = backend
        val t = session.token
        if (t != 0L) tokenOwners[t] = backend
    }

    @Synchronized
    fun detach(session: SessionBindings.Session) {
        owners.remove(session)
        val t = session.token
        if (t != 0L) tokenOwners.remove(t)
    }

    fun connecting(backend: RealVncBackend) {
        pending = backend
    }

    fun connected(backend: RealVncBackend) {
        if (pending === backend) pending = null
    }

    @Synchronized
    private fun owner(session: SessionBindings.Session?): RealVncBackend? {
        if (session != null) {
            val byIdentity = owners[session]
            if (byIdentity != null) return byIdentity
            val t = session.token
            if (t != 0L) {
                val byToken = tokenOwners[t]
                if (byToken != null) return byToken
            }
        }
        return pending
    }

    /** Every answer: tell the backend a dialog is gone, then post the result to the core thread. */
    private fun answered(backend: RealVncBackend, result: () -> Unit) {
        backend.promptAnswered()
        RealVncCore.post(result)
    }

    fun registerFactories() {
        PasswdDlgBindings.setPasswdDlgFactory(object : PasswdDlgBindings.PasswdDlgFactory {
            override fun createPasswdDlg(
                session: SessionBindings.Session?,
                cookie: Long,
                address: String?
            ): PasswdDlgBindings.PasswdDlg = createPasswd(session, cookie)
        })

        SecurityDlgBindings.setSecurityDlgFactory(object : SecurityDlgBindings.SecurityDlgFactory {
            override fun createSecurityDlg(
                session: SessionBindings.Session?,
                cookie: Long
            ): SecurityDlgBindings.SecurityDlg = createSecurity(session, cookie)
        })

        MsgBoxBindings.setMsgBoxFactory(object : MsgBoxBindings.MsgBoxFactory {
            override fun createMsgBox(
                session: SessionBindings.Session?,
                cookie: Long,
                message: String?,
                flags: Int,
                customButton: String?
            ): MsgBoxBindings.MsgBox = buildMsgBox(session, cookie, message ?: "", flags, customButton)
        })

        // Interactive (multi-factor) sign-in needs a form UI we do not have: decline rather
        // than hang, which is the difference between "not supported" and "the app froze".
        InteractiveTextDlgBindings.setInteractiveTextDlgFactory(
            object : InteractiveTextDlgBindings.InteractiveTextDlgFactory {
                override fun createInteractiveTextDlg(
                    session: SessionBindings.Session?,
                    cookie: Long
                ): InteractiveTextDlgBindings.InteractiveTextDlg {
                    return object : InteractiveTextDlgBindings.InteractiveTextDlg {
                        override fun promptInteractive(
                            elements: List<InteractiveTextDlgBindings.UiElement>?,
                            userNameFixed: Boolean
                        ) {
                            Log.w(RealVncCore.TAG, "declining interactive prompt")
                            owner(session)?.status(
                                "This server asks for a sign-in method the app does not support."
                            )
                            RealVncCore.post {
                                InteractiveTextDlgBindings.promptResult(cookie, false, null)
                            }
                        }

                        override fun close() {
                        }
                    }
                }
            }
        )

        // Client-certificate identities are never enrolled, so there is nothing to choose.
        AuthkeyChoiceDlgBindings.setAuthkeyChoiceDlgFactory(
            object : AuthkeyChoiceDlgBindings.AuthkeyChoiceDlgFactory {
                override fun createAuthkeyChoiceDlg(
                    session: SessionBindings.Session?,
                    cookie: Long
                ): AuthkeyChoiceDlgBindings.AuthkeyChoiceDlg {
                    return object : AuthkeyChoiceDlgBindings.AuthkeyChoiceDlg {
                        override fun show(identities: Array<String>?) {
                            Log.w(RealVncCore.TAG, "declining identity choice")
                            RealVncCore.post {
                                AuthkeyChoiceDlgBindings.identityChosen(cookie, false, null)
                            }
                        }

                        override fun close() {
                        }
                    }
                }
            }
        )

        ReconnectorBindings.setDlgFactory(object : ReconnectorBindings.DlgFactory {
            override fun createReconnectDlg(
                session: SessionBindings.Session?
            ): ReconnectorBindings.ReconnectDlg {
                return object : ReconnectorBindings.ReconnectDlg {
                    override fun show(message: String?, detail: String?) {
                        owner(session)?.reconnecting(message ?: "Reconnecting\u2026")
                    }

                    override fun hide() {
                        owner(session)?.reconnected()
                    }

                    override fun close() {
                    }
                }
            }
        })

        // Notifications, not questions: the core has already acted.
        SaveCredentialsBindings.setCredentialsStore(object : SaveCredentialsBindings.CredentialsStore {
            override fun saveCredentials(
                session: SessionBindings.Session?,
                userName: String?,
                password: String?
            ) {
                Log.i(RealVncCore.TAG, "server asked to save credentials")
            }
        })
        SaveIdentityBindings.setIdentityStore(object : SaveIdentityBindings.IdentityStore {
            override fun saveIdentity(session: SessionBindings.Session?, identity: String?) {
                if (identity != null) owner(session)?.saveIdentity(identity)
            }
        })
        StatusNotificationBindings.setStatusNotifier(object : StatusNotificationBindings.StatusNotifier {
            override fun update(session: SessionBindings.Session?, text: String?) {
                owner(session)?.status(text ?: "")
            }
        })
        SecurityNotificationBindings.setSecurityNotifier(
            object : SecurityNotificationBindings.SecurityNotifier {
                override fun show(
                    session: SessionBindings.Session?,
                    text: String?,
                    background: String?,
                    flags: Int
                ) {
                    Log.i(RealVncCore.TAG, "security banner: $text ($background)")
                }
            }
        )
    }

    // ---- the three prompts we actually ask ---------------------------------------------

    private fun createPasswd(
        session: SessionBindings.Session?,
        cookie: Long
    ): PasswdDlgBindings.PasswdDlg {
        val backend = owner(session)
        return object : PasswdDlgBindings.PasswdDlg {
            override fun getUserPasswd(
                unused: String?,
                serverName: String?,
                userName: String?,
                wantsPassword: Boolean,
                catchphrase: String?,
                signature: String?,
                instructions: String?
            ) {
                if (backend == null) {
                    RealVncCore.post { PasswdDlgBindings.passwdResult(cookie, false, null, null) }
                    return
                }
                // userName is null when the scheme has none (VNC password only).
                backend.ask(
                    CredentialsPrompt(
                        serverName ?: "",
                        instructions ?: "",
                        userName != null,
                        userName ?: "",
                        wantsPassword,
                        catchphrase ?: "",
                        signature ?: ""
                    ) { ok, user, pass ->
                        answered(backend) { PasswdDlgBindings.passwdResult(cookie, ok, user, pass) }
                    }
                )
            }

            override fun close() {
            }
        }
    }

    private fun createSecurity(
        session: SessionBindings.Session?,
        cookie: Long
    ): SecurityDlgBindings.SecurityDlg {
        val backend = owner(session)
        return object : SecurityDlgBindings.SecurityDlg {
            override fun promptSecurity(
                identityState: Int,
                encryptionState: Int,
                signature: String?,
                catchphrase: String?,
                name: String?,
                matchingName: String?,
                hint: String?
            ) {
                if (backend == null) {
                    RealVncCore.post { SecurityDlgBindings.securityResult(cookie, false, false, false) }
                    return
                }
                Log.i(RealVncCore.TAG, "promptSecurity id=$identityState enc=$encryptionState")
                backend.ask(
                    TrustPrompt(
                        name ?: "",
                        encryption(encryptionState),
                        identity(identityState),
                        signature ?: "",
                        catchphrase ?: "",
                        matchingName ?: ""
                    ) { accept, remember ->
                        // Only the identity is offered to be remembered, not the encryption choice.
                        answered(backend) {
                            SecurityDlgBindings.securityResult(cookie, accept, remember, false)
                        }
                    }
                )
            }

            override fun close() {
            }
        }
    }

    private fun buildMsgBox(
        session: SessionBindings.Session?,
        cookie: Long,
        message: String,
        flags: Int,
        customButton: String?
    ): MsgBoxBindings.MsgBox {
        val backend = owner(session)
        val yesNo = (flags and MsgBoxBindings.MB_YESNO) != 0
        val question = (flags and MsgBoxBindings.MB_OKCANCEL) != 0 || yesNo
        if (backend != null) {
            val custom = if ((flags and MsgBoxBindings.MB_CUSTOM) != 0) customButton else null
            backend.ask(
                MessagePrompt(
                    backend.addressText(),
                    message,
                    severity(flags),
                    question,
                    yesNo,
                    custom
                ) { ok ->
                    answered(backend) { MsgBoxBindings.msgBoxResult(cookie, ok) }
                }
            )
        } else {
            RealVncCore.post { MsgBoxBindings.msgBoxResult(cookie, false) }
        }
        return object : MsgBoxBindings.MsgBox {
            override fun close() {
            }
        }
    }

    private fun encryption(state: Int): TrustEncryption {
        return when (state) {
            SecurityDlgBindings.ENC_ENCRYPTED -> TrustEncryption.ENCRYPTED
            SecurityDlgBindings.ENC_UNENCRYPTED_NO_WARN -> TrustEncryption.UNENCRYPTED_QUIET
            else -> TrustEncryption.UNENCRYPTED_WARN
        }
    }

    private fun identity(state: Int): TrustIdentity {
        return when (state) {
            SecurityDlgBindings.ID_OK -> TrustIdentity.OK
            SecurityDlgBindings.ID_NEW -> TrustIdentity.NEW
            SecurityDlgBindings.ID_MATCHES_ANOTHER_SERVER -> TrustIdentity.MATCHES_ANOTHER
            SecurityDlgBindings.ID_CHANGED -> TrustIdentity.CHANGED
            SecurityDlgBindings.ID_PRESHARED -> TrustIdentity.PRESHARED
            SecurityDlgBindings.ID_ARD -> TrustIdentity.ARD
            else -> TrustIdentity.MISSING
        }
    }

    private fun severity(flags: Int): MessageSeverity {
        // The icon bits are a small enum, not independent flags: WARNING (48) is ERROR | QUESTION.
        return when (flags and MsgBoxBindings.MB_ICON_MASK) {
            MsgBoxBindings.MB_ICONERROR -> MessageSeverity.ERROR
            MsgBoxBindings.MB_ICONQUESTION -> MessageSeverity.QUESTION
            MsgBoxBindings.MB_ICONWARNING -> MessageSeverity.WARNING
            else -> MessageSeverity.INFORMATION
        }
    }
}
