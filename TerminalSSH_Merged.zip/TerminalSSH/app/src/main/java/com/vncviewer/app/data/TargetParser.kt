package com.vncviewer.app.data

data class VncTarget(val host: String, val port: Int)

/**
 * Parses what people actually type into a "server" box:
 *   192.168.1.10            -> port 5900
 *   192.168.1.10:1          -> display :1  = port 5901
 *   192.168.1.10:5901       -> port 5901
 *   192.168.1.10::5901      -> port 5901 (TigerVNC style)
 *   vnc://user@host:5902    -> port 5902
 *   [fe80::1]:5900          -> IPv6
 */
object TargetParser {

    fun parse(input: String): VncTarget? {
        var s = input.trim()
        if (s.isEmpty()) return null
        val scheme = s.indexOf("://")
        if (scheme >= 0) s = s.substring(scheme + 3)
        val slash = s.indexOf('/')
        if (slash >= 0) s = s.substring(0, slash)
        val at = s.lastIndexOf('@')
        if (at >= 0) s = s.substring(at + 1)
        if (s.isEmpty()) return null

        val host: String
        var portSpec: String? = null
        var absolute = false

        if (s.startsWith("[")) {
            val end = s.indexOf(']')
            if (end < 2) return null
            host = s.substring(1, end)
            val rest = s.substring(end + 1)
            if (rest.startsWith("::")) {
                portSpec = rest.substring(2)
                absolute = true
            } else if (rest.startsWith(":")) {
                portSpec = rest.substring(1)
            } else if (rest.isNotEmpty()) {
                return null
            }
        } else {
            val colonCount = s.count { it == ':' }
            val dbl = s.indexOf("::")
            if (colonCount == 0) {
                host = s
            } else if (colonCount == 2 && dbl > 0 && s.substring(dbl + 2).all { it.isDigit() } &&
                s.substring(dbl + 2).isNotEmpty()
            ) {
                host = s.substring(0, dbl)
                portSpec = s.substring(dbl + 2)
                absolute = true
            } else if (colonCount == 1) {
                val idx = s.indexOf(':')
                host = s.substring(0, idx)
                portSpec = s.substring(idx + 1)
            } else {
                // Bare IPv6 literal such as fe80::1 -> default port.
                host = s
            }
        }

        if (host.isBlank() || host.any { it.isWhitespace() }) return null

        var port = 5900
        if (portSpec != null) {
            val n = portSpec.toIntOrNull() ?: return null
            port = if (!absolute && n in 0..99) 5900 + n else n
        }
        if (port !in 1..65535) return null
        return VncTarget(host, port)
    }
}
