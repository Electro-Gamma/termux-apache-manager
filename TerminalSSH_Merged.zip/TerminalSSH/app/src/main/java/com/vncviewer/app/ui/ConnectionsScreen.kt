package com.vncviewer.app.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.vncviewer.app.data.Engine
import com.vncviewer.app.data.TargetParser
import com.vncviewer.app.data.VncProfile
import com.vncviewer.app.realvnc.RealVncCore

/** The home screen is [HomeScreen]; the editor it opens from a long press or the + button lives here. */
@Composable
fun ConnectionsScreen(vm: VncViewModel) = HomeScreen(vm)

@Composable
internal fun ProfileEditorDialog(
    initial: VncProfile,
    isNew: Boolean,
    onSave: (VncProfile) -> Unit,
    onDelete: (() -> Unit)?,
    onDismiss: () -> Unit,
    onImport: (() -> Unit)? = null,
    onExport: (() -> Unit)? = null,
    exportEnabled: Boolean = true
) {
    var name by remember(initial.id) { mutableStateOf(initial.name) }
    var server by remember(initial.id) { mutableStateOf(if (initial.host.isEmpty()) "" else initial.address) }
    var password by remember(initial.id) { mutableStateOf(initial.password) }
    var savePassword by remember(initial.id) { mutableStateOf(isNew || initial.password.isNotEmpty()) }
    var viewOnly by remember(initial.id) { mutableStateOf(initial.viewOnly) }
    var errorText by remember(initial.id) { mutableStateOf<String?>(null) }
    var engine by remember(initial.id) { mutableStateOf(initial.engine) }
    var userName by remember(initial.id) { mutableStateOf(initial.userName) }
    var quality by remember(initial.id) { mutableStateOf(initial.quality) }
    var pinned by remember(initial.id) { mutableStateOf(initial.favorite) }
    val engineProblem: String? = if (engine == Engine.REALVNC) RealVncCore.unavailableReason() else null

    AlertDialog(
        containerColor = androidx.compose.material3.MaterialTheme.colorScheme.surface,
        onDismissRequest = onDismiss,
        title = { Text(if (isNew) "New connection" else "Edit connection") },
        text = {
          Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(
                modifier = Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    singleLine = true,
                    label = { Text("Name (optional)") }
                )
                Text("Engine", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (e in Engine.values()) {
                        ToolChip(e.label, engine == e, compact = true) { engine = e }
                    }
                }
                if (engine == Engine.BUILTIN) {
                    Text(
                        "Plain VNC client built into the app. Works with most servers; the connection is not encrypted.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    Text(
                        "RealVNC's own viewer core: encrypted connections, UDP, ZRLE2 and RealVNC authentication. Best with RealVNC Server.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (engineProblem != null) {
                        Text(engineProblem, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    }
                }
                OutlinedTextField(
                    value = server,
                    onValueChange = {
                        server = it
                        errorText = null
                    },
                    singleLine = true,
                    label = { Text("Server") },
                    placeholder = { Text("192.168.1.10:1  or  host:5901") },
                    supportingText = { Text("host, host:display (e.g. :1 = port 5901) or host:port") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri)
                )
                if (engine == Engine.REALVNC) {
                    OutlinedTextField(
                        value = userName,
                        onValueChange = { userName = it },
                        singleLine = true,
                        label = { Text("User name (optional)") },
                        supportingText = { Text("Only for servers that sign in with user name + password") }
                    )
                    Text("Picture quality", style = MaterialTheme.typography.labelLarge)
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        for (q in listOf("Auto", "High", "Medium", "Low")) {
                            ToolChip(q, quality == q, compact = true) { quality = q }
                        }
                    }
                }
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    singleLine = true,
                    label = { Text(if (engine == Engine.REALVNC) "Password" else "VNC password") },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Save password (encrypted)", modifier = Modifier.weight(1f))
                    Switch(checked = savePassword, onCheckedChange = { savePassword = it })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("View only", modifier = Modifier.weight(1f))
                    Switch(checked = viewOnly, onCheckedChange = { viewOnly = it })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Pinned to the top", modifier = Modifier.weight(1f))
                    Switch(checked = pinned, onCheckedChange = { pinned = it })
                }
                if (onDelete != null) {
                    TextButton(onClick = onDelete) {
                        Text("Delete connection", color = MaterialTheme.colorScheme.error)
                    }
                }
                val err = errorText
                if (err != null) {
                    Text(err, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }

            // Import / Export (only from the + sheet), then Save / Cancel: each pair is one line,
            // two equal halves, styled like Save on the New Host Connection screen.
            if (isNew && onImport != null && onExport != null) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = onImport,
                        modifier = Modifier.weight(1f).height(48.dp)
                    ) { Text("Import") }
                    Button(
                        onClick = onExport,
                        enabled = exportEnabled,
                        modifier = Modifier.weight(1f).height(48.dp)
                    ) { Text("Export") }
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        val target = TargetParser.parse(server)
                        if (target == null) {
                            errorText = "Enter a valid server address."
                        } else {
                            onSave(
                                initial.copy(
                                    name = name.trim().ifEmpty { target.host },
                                    host = target.host,
                                    port = target.port,
                                    password = if (savePassword) password else "",
                                    viewOnly = viewOnly,
                                    engine = engine,
                                    userName = userName.trim(),
                                    quality = quality,
                                    favorite = pinned
                                )
                            )
                        }
                    },
                    modifier = Modifier.weight(1f).height(48.dp)
                ) { Text("Save") }
                Button(
                    onClick = onDismiss,
                    modifier = Modifier.weight(1f).height(48.dp)
                ) { Text("Cancel") }
            }
          }
        },
        confirmButton = {},
        dismissButton = null
    )
}
