package com.vncviewer.app.ui

import androidx.compose.runtime.Composable
import app.terminalssh.secure.ui.theme.AppPalette

/**
 * The VNC tab lives inside Terminal SSH, so there is only one theme and one "appearance"
 * setting: Terminal SSH's. [AppPalette.dark] is written by TerminalTheme (in MainActivity)
 * before any child composes, so reading it here always matches what the rest of the app shows.
 */
@Composable
fun appIsDark(): Boolean = AppPalette.dark

/** Kept for callers: everything already sits inside the app's TerminalTheme. */
@Composable
fun VncViewerTheme(content: @Composable () -> Unit) = content()

/** Kept for callers: the home and settings screens share the one app theme. */
@Composable
fun VncHomeTheme(content: @Composable () -> Unit) = content()
