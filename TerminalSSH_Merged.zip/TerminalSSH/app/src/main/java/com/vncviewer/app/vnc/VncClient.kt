package com.vncviewer.app.vnc

import android.graphics.Bitmap
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.EOFException
import java.io.IOException
import java.net.ConnectException
import java.net.InetSocketAddress
import java.net.NoRouteToHostException
import java.net.Socket
import java.net.SocketException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.ThreadFactory
import java.util.concurrent.atomic.AtomicBoolean
import java.util.zip.DataFormatException
import java.util.zip.Inflater
import javax.crypto.Cipher
import javax.crypto.spec.SecretKeySpec

/**
 * Callbacks from the VNC engine. They are invoked on the engine's reader thread, so
 * implementations must hop to the main thread before touching UI objects.
 */
interface VncListener {
    fun onStatus(text: String)

    /** The server needs a (new) VNC password. The connection has already been closed. */
    fun onPasswordRequired(wasRejected: Boolean)

    /** A framebuffer is ready (first connect, or the remote desktop was resized). */
    fun onFramebufferReady(bitmap: Bitmap, desktopName: String)

    /** Part of the bitmap changed; request a redraw. */
    fun onFrameUpdated()

    fun onServerCutText(text: String)

    fun onBell()

    /** The session ended. [error] is null when the user closed it. */
    fun onDisconnected(error: String?)

    /** Remote cursor shape. The bitmap is a private copy. */
    fun onCursor(bitmap: Bitmap?, hotX: Int, hotY: Int) {
    }

    /** The server hid its cursor (an empty cursor shape). */
    fun onCursorHidden() {
    }

    /** The engine needs an answer from the person (RealVNC engine only). */
    fun onPrompt(prompt: RemotePrompt) {
    }

    /** A temporary banner such as "Reconnecting..."; null clears it. */
    fun onBanner(text: String?) {
    }
}

/**
 * A compact RFB 3.3 / 3.7 / 3.8 client.
 *
 * Security : None, VNC Authentication (DES challenge/response).
 * Encodings: ZRLE, Hextile, CopyRect, RRE, Raw, DesktopSize.
 * Pixel format requested from the server is always 32-bit true colour
 * (wire bytes B, G, R, X) so every decoder works on one format.
 */
class VncClient(
    private val host: String,
    private val port: Int,
    private val password: String,
    private val listener: VncListener
) : RemoteBackend {
    @Volatile
    private var socket: Socket? = null

    @Volatile
    private var out: DataOutputStream? = null

    @Volatile
    private var running: Boolean = false

    @Volatile
    private var closedByUser: Boolean = false

    private val notifiedEnd = AtomicBoolean(false)
    private val writeLock = Any()

    private val sender: ExecutorService = Executors.newSingleThreadExecutor(
        ThreadFactory { r ->
            val t = Thread(r, "vnc-sender")
            t.isDaemon = true
            t
        }
    )

    // Framebuffer state (written by the reader thread only).
    @Volatile
    private var fbWidth: Int = 0

    @Volatile
    private var fbHeight: Int = 0
    private var pixels: IntArray = IntArray(0)
    private var bitmap: Bitmap? = null
    private var desktopName: String = ""

    // Dirty rectangle accumulated during one FramebufferUpdate.
    private var dirtyL = Int.MAX_VALUE
    private var dirtyT = Int.MAX_VALUE
    private var dirtyR = -1
    private var dirtyB = -1

    // Scratch buffers.
    private val inflater = Inflater()
    private val inflateBuf = ByteArray(65536)
    private var rowBuf = ByteArray(0)
    private val skipBuf = ByteArray(4096)

    // Coalesced pointer-move state.
    @Volatile
    private var pendingPointer: Long = -1L
    private val moveScheduled = AtomicBoolean(false)

    val isRunning: Boolean get() = running

    override fun start() {
        val t = Thread({ runSession() }, "vnc-reader")
        t.isDaemon = true
        t.start()
    }

    override fun close() {
        closedByUser = true
        running = false
        try {
            socket?.close()
        } catch (_: Exception) {
        }
        try {
            sender.shutdownNow()
        } catch (_: Exception) {
        }
    }

    // ------------------------------------------------------------------------------------
    // Session
    // ------------------------------------------------------------------------------------

    private fun runSession() {
        var error: String? = null
        try {
            listener.onStatus("Connecting to $host:$port\u2026")
            val sock = Socket()
            socket = sock
            sock.connect(InetSocketAddress(host, port), 8000)
            sock.tcpNoDelay = true
            sock.keepAlive = true
            sock.soTimeout = 15000

            val input = DataInputStream(BufferedInputStream(sock.getInputStream(), 1 shl 16))
            val output = DataOutputStream(BufferedOutputStream(sock.getOutputStream(), 1 shl 14))
            out = output

            if (!handshake(input, output)) {
                // Password dialog requested; nothing more to do on this socket.
                notifiedEnd.set(true)
                return
            }

            sock.soTimeout = 0
            running = true
            listener.onStatus("Connected")
            requestUpdate(false)

            while (running) {
                val type = input.readUnsignedByte()
                when (type) {
                    0 -> readFramebufferUpdate(input)
                    1 -> { // SetColourMapEntries (unused: we always use true colour)
                        input.readUnsignedByte()
                        input.readUnsignedShort()
                        val n = input.readUnsignedShort()
                        skipFully(input, n * 6L)
                    }
                    2 -> listener.onBell()
                    3 -> { // ServerCutText
                        skipFully(input, 3)
                        val len = input.readInt()
                        if (len < 0 || len > 4 * 1024 * 1024) throw IOException("Invalid clipboard length")
                        val bytes = ByteArray(len)
                        input.readFully(bytes)
                        listener.onServerCutText(String(bytes, Charsets.ISO_8859_1))
                    }
                    else -> throw IOException("Unsupported server message type $type")
                }
            }
        } catch (e: OutOfMemoryError) {
            error = "Out of memory: the remote screen is too large for this device."
        } catch (e: Exception) {
            if (!closedByUser) {
                error = describe(e)
            }
        } finally {
            running = false
            try {
                socket?.close()
            } catch (_: Exception) {
            }
            try {
                inflater.end()
            } catch (_: Exception) {
            }
            try {
                sender.shutdownNow()
            } catch (_: Exception) {
            }
            if (notifiedEnd.compareAndSet(false, true)) {
                listener.onDisconnected(if (closedByUser) null else (error ?: "Connection closed"))
            }
        }
    }

    /** Returns false when the server wants a password we do not have / that was rejected. */
    private fun handshake(input: DataInputStream, output: DataOutputStream): Boolean {
        val greeting = ByteArray(12)
        input.readFully(greeting)
        val greetingText = String(greeting, Charsets.US_ASCII)
        if (!greetingText.startsWith("RFB ")) {
            throw IOException("This is not a VNC server (unexpected greeting)")
        }
        val major = greetingText.substring(4, 7).toIntOrNull() ?: 3
        val minor = greetingText.substring(8, 11).toIntOrNull() ?: 3
        val useMinor = when {
            major > 3 || (major == 3 && minor >= 8) -> 8
            major == 3 && minor == 7 -> 7
            else -> 3
        }
        output.write("RFB 003.00$useMinor\n".toByteArray(Charsets.US_ASCII))
        output.flush()
        listener.onStatus("Negotiating security\u2026")

        // --- Security type -------------------------------------------------------------
        val secType: Int
        if (useMinor == 3) {
            secType = input.readInt()
            if (secType == 0) throw IOException(readReason(input))
        } else {
            val count = input.readUnsignedByte()
            if (count == 0) throw IOException(readReason(input))
            val offered = IntArray(count)
            for (i in 0 until count) offered[i] = input.readUnsignedByte()
            val hasNone = offered.contains(1)
            val hasVnc = offered.contains(2)
            secType = when {
                hasVnc && (password.isNotEmpty() || !hasNone) -> 2
                hasNone -> 1
                else -> throw IOException(
                    "This server only offers security types the app does not support " +
                        "(${offered.joinToString(", ")}). Enable \"VNC password\" authentication " +
                        "on the server, or tunnel the connection."
                )
            }
            output.writeByte(secType)
            output.flush()
        }

        when (secType) {
            1 -> {
                if (useMinor >= 8) {
                    val result = input.readInt()
                    if (result != 0) throw IOException(readReason(input))
                }
            }
            2 -> {
                if (password.isEmpty()) {
                    listener.onPasswordRequired(false)
                    return false
                }
                val challenge = ByteArray(16)
                input.readFully(challenge)
                output.write(desResponse(challenge, password))
                output.flush()
                val result = input.readInt()
                if (result != 0) {
                    listener.onPasswordRequired(true)
                    return false
                }
            }
            else -> throw IOException("Unsupported VNC security type $secType")
        }

        // --- ClientInit / ServerInit ---------------------------------------------------
        output.writeByte(1) // shared session
        output.flush()

        val w = input.readUnsignedShort()
        val h = input.readUnsignedShort()
        skipFully(input, 16) // server pixel format (we override it below)
        val nameLen = input.readInt()
        if (nameLen < 0 || nameLen > 65536) throw IOException("Invalid desktop name length")
        val nameBytes = ByteArray(nameLen)
        input.readFully(nameBytes)
        desktopName = String(nameBytes, Charsets.UTF_8)

        if (w < 1 || h < 1) throw IOException("Server reported an empty screen")
        allocateFramebuffer(w, h)

        // --- SetPixelFormat + SetEncodings --------------------------------------------
        synchronized(writeLock) {
            output.writeByte(0) // SetPixelFormat
            output.write(byteArrayOf(0, 0, 0))
            output.writeByte(32) // bits per pixel
            output.writeByte(24) // depth
            output.writeByte(0) // big endian = false
            output.writeByte(1) // true colour = true
            output.writeShort(255)
            output.writeShort(255)
            output.writeShort(255)
            output.writeByte(16) // red shift
            output.writeByte(8) // green shift
            output.writeByte(0) // blue shift
            output.write(byteArrayOf(0, 0, 0))

            // The cursor pseudo-encodings make the server send the pointer as a shape instead of painting it
            // into the screen, so it can be drawn locally at the finger position without a round trip.
            val encodings = intArrayOf(
                ENC_ZRLE, ENC_HEXTILE, ENC_COPYRECT, ENC_RRE, ENC_RAW,
                ENC_RICH_CURSOR, ENC_X_CURSOR, ENC_DESKTOP_SIZE
            )
            output.writeByte(2) // SetEncodings
            output.writeByte(0)
            output.writeShort(encodings.size)
            for (e in encodings) output.writeInt(e)
            output.flush()
        }

        publishFramebuffer()
        return true
    }

    private fun readReason(input: DataInputStream): String {
        return try {
            val len = input.readInt()
            if (len < 0 || len > 4096) {
                "Connection refused by the server"
            } else {
                val b = ByteArray(len)
                input.readFully(b)
                val text = String(b, Charsets.UTF_8).trim()
                if (text.isEmpty()) "Connection refused by the server" else text
            }
        } catch (_: Exception) {
            "Connection refused by the server"
        }
    }

    private fun desResponse(challenge: ByteArray, pass: String): ByteArray {
        val key = ByteArray(8)
        val pw = pass.toByteArray(Charsets.ISO_8859_1)
        for (i in 0 until 8) {
            val b = if (i < pw.size) pw[i].toInt() and 0xFF else 0
            var rev = 0
            for (bit in 0 until 8) {
                if ((b and (1 shl bit)) != 0) rev = rev or (1 shl (7 - bit))
            }
            key[i] = rev.toByte()
        }
        val cipher = Cipher.getInstance("DES/ECB/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "DES"))
        return cipher.doFinal(challenge)
    }

    // ------------------------------------------------------------------------------------
    // Framebuffer
    // ------------------------------------------------------------------------------------

    private fun allocateFramebuffer(w: Int, h: Int) {
        if (w.toLong() * h.toLong() > 80_000_000L) {
            throw IOException("The remote screen is too large (${w}x$h)")
        }
        fbWidth = w
        fbHeight = h
        pixels = IntArray(w * h)
        java.util.Arrays.fill(pixels, OPAQUE_BLACK)
        bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bitmap?.setPixels(pixels, 0, w, 0, 0, w, h)
        resetDirty()
    }

    private fun publishFramebuffer() {
        val bmp = bitmap ?: return
        listener.onFramebufferReady(bmp, desktopName)
    }

    private fun resetDirty() {
        dirtyL = Int.MAX_VALUE
        dirtyT = Int.MAX_VALUE
        dirtyR = -1
        dirtyB = -1
    }

    private fun markDirty(x: Int, y: Int, w: Int, h: Int) {
        val l = if (x < 0) 0 else x
        val t = if (y < 0) 0 else y
        val r = if (x + w > fbWidth) fbWidth else x + w
        val b = if (y + h > fbHeight) fbHeight else y + h
        if (r <= l || b <= t) return
        if (l < dirtyL) dirtyL = l
        if (t < dirtyT) dirtyT = t
        if (r > dirtyR) dirtyR = r
        if (b > dirtyB) dirtyB = b
    }

    private fun flushDirty() {
        val bmp = bitmap
        if (bmp != null && dirtyR > dirtyL && dirtyB > dirtyT) {
            val w = dirtyR - dirtyL
            val h = dirtyB - dirtyT
            bmp.setPixels(pixels, dirtyT * fbWidth + dirtyL, fbWidth, dirtyL, dirtyT, w, h)
        }
        resetDirty()
    }

    private fun readFramebufferUpdate(input: DataInputStream) {
        input.readUnsignedByte() // padding
        val rects = input.readUnsignedShort()
        var resized = false
        var i = 0
        while (i < rects) {
            i++
            val rx = input.readUnsignedShort()
            val ry = input.readUnsignedShort()
            val rw = input.readUnsignedShort()
            val rh = input.readUnsignedShort()
            val enc = input.readInt()
            if (enc == ENC_LAST_RECT) break
            when (enc) {
                ENC_RAW -> decodeRaw(input, rx, ry, rw, rh)
                ENC_COPYRECT -> decodeCopyRect(input, rx, ry, rw, rh)
                ENC_RRE -> decodeRre(input, rx, ry, rw, rh)
                ENC_HEXTILE -> decodeHextile(input, rx, ry, rw, rh)
                ENC_ZRLE -> decodeZrle(input, rx, ry, rw, rh)
                ENC_RICH_CURSOR -> decodeRichCursor(input, rx, ry, rw, rh)
                ENC_X_CURSOR -> decodeXCursor(input, rx, ry, rw, rh)
                ENC_DESKTOP_SIZE -> {
                    flushDirty()
                    if (rw < 1 || rh < 1) throw IOException("Invalid desktop size")
                    allocateFramebuffer(rw, rh)
                    publishFramebuffer()
                    resized = true
                }
                else -> throw IOException("Unsupported encoding $enc")
            }
        }
        flushDirty()
        listener.onFrameUpdated()
        requestUpdate(!resized)
    }

    // ------------------------------------------------------------------------------------
    // Decoders
    // ------------------------------------------------------------------------------------

    private fun decodeRaw(input: DataInputStream, rx: Int, ry: Int, rw: Int, rh: Int) {
        if (rw == 0 || rh == 0) return
        if (rowBuf.size < rw * 4) rowBuf = ByteArray(rw * 4)
        val buf = rowBuf
        for (y in 0 until rh) {
            input.readFully(buf, 0, rw * 4)
            val dy = ry + y
            if (dy < 0 || dy >= fbHeight) continue
            val base = dy * fbWidth
            var s = 0
            for (x in 0 until rw) {
                val dx = rx + x
                if (dx in 0 until fbWidth) {
                    pixels[base + dx] = OPAQUE_BLACK or
                        ((buf[s + 2].toInt() and 0xFF) shl 16) or
                        ((buf[s + 1].toInt() and 0xFF) shl 8) or
                        (buf[s].toInt() and 0xFF)
                }
                s += 4
            }
        }
        markDirty(rx, ry, rw, rh)
    }

    // ------------------------------------------------------------------------------------
    // Cursor shapes (pseudo-encodings): the rectangle's x/y are the hotspot, w/h the shape size.
    // ------------------------------------------------------------------------------------

    /** RichCursor: w*h pixels in the session pixel format, then a 1-bit-per-pixel mask (MSB first). */
    private fun decodeRichCursor(input: DataInputStream, hotX: Int, hotY: Int, w: Int, h: Int) {
        if (w == 0 || h == 0) {
            listener.onCursorHidden()
            return
        }
        val maskStride = (w + 7) / 8
        if (w > MAX_CURSOR || h > MAX_CURSOR) {
            skipFully(input, w.toLong() * h * 4 + maskStride.toLong() * h)
            return
        }
        val px = IntArray(w * h)
        val row = ByteArray(w * 4)
        for (y in 0 until h) {
            input.readFully(row, 0, w * 4)
            var s = 0
            for (x in 0 until w) {
                px[y * w + x] = ((row[s + 2].toInt() and 0xFF) shl 16) or
                    ((row[s + 1].toInt() and 0xFF) shl 8) or
                    (row[s].toInt() and 0xFF)
                s += 4
            }
        }
        val mask = ByteArray(maskStride * h)
        input.readFully(mask)
        for (y in 0 until h) {
            for (x in 0 until w) {
                val on = (mask[y * maskStride + (x shr 3)].toInt() shr (7 - (x and 7))) and 1 != 0
                px[y * w + x] = if (on) px[y * w + x] or OPAQUE_BLACK else 0
            }
        }
        deliverCursor(px, w, h, hotX, hotY)
    }

    /** XCursor: foreground and background RGB, then a 1-bit bitmap and a 1-bit mask (MSB first). */
    private fun decodeXCursor(input: DataInputStream, hotX: Int, hotY: Int, w: Int, h: Int) {
        if (w == 0 || h == 0) {
            listener.onCursorHidden()
            return
        }
        val stride = (w + 7) / 8
        if (w > MAX_CURSOR || h > MAX_CURSOR) {
            skipFully(input, 6L + 2L * stride * h)
            return
        }
        val c = ByteArray(6)
        input.readFully(c)
        val fg = OPAQUE_BLACK or ((c[0].toInt() and 0xFF) shl 16) or
            ((c[1].toInt() and 0xFF) shl 8) or (c[2].toInt() and 0xFF)
        val bg = OPAQUE_BLACK or ((c[3].toInt() and 0xFF) shl 16) or
            ((c[4].toInt() and 0xFF) shl 8) or (c[5].toInt() and 0xFF)
        val bits = ByteArray(stride * h)
        val mask = ByteArray(stride * h)
        input.readFully(bits)
        input.readFully(mask)
        val px = IntArray(w * h)
        for (y in 0 until h) {
            for (x in 0 until w) {
                val i = y * stride + (x shr 3)
                val sh = 7 - (x and 7)
                if ((mask[i].toInt() shr sh) and 1 != 0) {
                    px[y * w + x] = if ((bits[i].toInt() shr sh) and 1 != 0) fg else bg
                }
            }
        }
        deliverCursor(px, w, h, hotX, hotY)
    }

    private fun deliverCursor(px: IntArray, w: Int, h: Int, hotX: Int, hotY: Int) {
        val bmp = try {
            Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
        } catch (_: Throwable) {
            return
        }
        listener.onCursor(bmp, hotX, hotY)
    }

    private fun decodeCopyRect(input: DataInputStream, rx: Int, ry: Int, rw: Int, rh: Int) {
        val sx = input.readUnsignedShort()
        val sy = input.readUnsignedShort()
        if (rw == 0 || rh == 0) return
        if (sx + rw > fbWidth || sy + rh > fbHeight || rx + rw > fbWidth || ry + rh > fbHeight) return
        if (sy < ry) {
            var row = rh - 1
            while (row >= 0) {
                System.arraycopy(pixels, (sy + row) * fbWidth + sx, pixels, (ry + row) * fbWidth + rx, rw)
                row--
            }
        } else {
            for (row in 0 until rh) {
                System.arraycopy(pixels, (sy + row) * fbWidth + sx, pixels, (ry + row) * fbWidth + rx, rw)
            }
        }
        markDirty(rx, ry, rw, rh)
    }

    private fun decodeRre(input: DataInputStream, rx: Int, ry: Int, rw: Int, rh: Int) {
        val count = input.readInt()
        val bg = readPixel(input)
        fillRect(rx, ry, rw, rh, bg)
        for (i in 0 until count) {
            val color = readPixel(input)
            val x = input.readUnsignedShort()
            val y = input.readUnsignedShort()
            val w = input.readUnsignedShort()
            val h = input.readUnsignedShort()
            fillRect(rx + x, ry + y, w, h, color)
        }
        markDirty(rx, ry, rw, rh)
    }

    private fun decodeHextile(input: DataInputStream, rx: Int, ry: Int, rw: Int, rh: Int) {
        var bg = OPAQUE_BLACK
        var fg = OPAQUE_BLACK or 0xFFFFFF
        var ty = ry
        while (ty < ry + rh) {
            val th = minOf(16, ry + rh - ty)
            var tx = rx
            while (tx < rx + rw) {
                val tw = minOf(16, rx + rw - tx)
                val sub = input.readUnsignedByte()
                if ((sub and 0x01) != 0) {
                    decodeRaw(input, tx, ty, tw, th)
                } else {
                    if ((sub and 0x02) != 0) bg = readPixel(input)
                    if ((sub and 0x04) != 0) fg = readPixel(input)
                    fillRect(tx, ty, tw, th, bg)
                    if ((sub and 0x08) != 0) {
                        val n = input.readUnsignedByte()
                        val coloured = (sub and 0x10) != 0
                        for (k in 0 until n) {
                            val color = if (coloured) readPixel(input) else fg
                            val xy = input.readUnsignedByte()
                            val wh = input.readUnsignedByte()
                            fillRect(
                                tx + (xy shr 4),
                                ty + (xy and 0x0F),
                                (wh shr 4) + 1,
                                (wh and 0x0F) + 1,
                                color
                            )
                        }
                    }
                }
                tx += 16
            }
            ty += 16
        }
        markDirty(rx, ry, rw, rh)
    }

    private fun decodeZrle(input: DataInputStream, rx: Int, ry: Int, rw: Int, rh: Int) {
        val length = input.readInt()
        if (length < 0 || length > 128 * 1024 * 1024) throw IOException("Invalid ZRLE length")
        val compressed = ByteArray(length)
        input.readFully(compressed)
        inflater.setInput(compressed, 0, length)
        val data = inflateAll()

        var p = 0
        var ty = ry
        while (ty < ry + rh) {
            val th = minOf(64, ry + rh - ty)
            var tx = rx
            while (tx < rx + rw) {
                val tw = minOf(64, rx + rw - tx)
                val sub = data[p++].toInt() and 0xFF
                val rle = (sub and 0x80) != 0
                val palSize = sub and 0x7F
                val total = tw * th

                if (!rle) {
                    if (palSize == 0) {
                        // Raw CPIXELs
                        for (yy in 0 until th) {
                            for (xx in 0 until tw) {
                                setPixel(tx + xx, ty + yy, cpixel(data, p))
                                p += 3
                            }
                        }
                    } else if (palSize == 1) {
                        val c = cpixel(data, p)
                        p += 3
                        fillRect(tx, ty, tw, th, c)
                    } else {
                        val palette = IntArray(palSize)
                        for (k in 0 until palSize) {
                            palette[k] = cpixel(data, p)
                            p += 3
                        }
                        val bits = if (palSize == 2) 1 else if (palSize <= 4) 2 else 4
                        val mask = (1 shl bits) - 1
                        for (yy in 0 until th) {
                            var cur = 0
                            var left = 0
                            for (xx in 0 until tw) {
                                if (left == 0) {
                                    cur = data[p++].toInt() and 0xFF
                                    left = 8
                                }
                                left -= bits
                                val idx = (cur shr left) and mask
                                setPixel(tx + xx, ty + yy, palette[if (idx < palSize) idx else 0])
                            }
                        }
                    }
                } else if (palSize == 0) {
                    // Plain RLE
                    var pos = 0
                    while (pos < total) {
                        val c = cpixel(data, p)
                        p += 3
                        var run = 1
                        var b: Int
                        do {
                            b = data[p++].toInt() and 0xFF
                            run += b
                        } while (b == 255)
                        pos = fillRun(tx, ty, tw, total, pos, run, c)
                    }
                } else {
                    // Palette RLE
                    val palette = IntArray(palSize)
                    for (k in 0 until palSize) {
                        palette[k] = cpixel(data, p)
                        p += 3
                    }
                    var pos = 0
                    while (pos < total) {
                        val indexByte = data[p++].toInt() and 0xFF
                        val idx = indexByte and 0x7F
                        var run = 1
                        if ((indexByte and 0x80) != 0) {
                            var b: Int
                            do {
                                b = data[p++].toInt() and 0xFF
                                run += b
                            } while (b == 255)
                        }
                        pos = fillRun(tx, ty, tw, total, pos, run, palette[if (idx < palSize) idx else 0])
                    }
                }
                tx += 64
            }
            ty += 64
        }
        markDirty(rx, ry, rw, rh)
    }

    private fun inflateAll(): ByteArray {
        val bos = ByteArrayOutputStream(64 * 1024)
        while (true) {
            val n = try {
                inflater.inflate(inflateBuf)
            } catch (e: DataFormatException) {
                throw IOException("Corrupt ZRLE stream: ${e.message}")
            }
            if (n > 0) {
                bos.write(inflateBuf, 0, n)
                continue
            }
            if (inflater.finished() || inflater.needsInput()) break
            if (inflater.needsDictionary()) throw IOException("ZRLE stream needs a dictionary")
        }
        return bos.toByteArray()
    }

    /** Fills [run] pixels of a tile (row-major) starting at linear position [pos]; returns the new position. */
    private fun fillRun(tx: Int, ty: Int, tw: Int, total: Int, pos: Int, run: Int, color: Int): Int {
        var k = pos
        val end = if (pos + run > total) total else pos + run
        while (k < end) {
            setPixel(tx + (k % tw), ty + (k / tw), color)
            k++
        }
        return end
    }

    private fun cpixel(d: ByteArray, p: Int): Int {
        return OPAQUE_BLACK or
            ((d[p + 2].toInt() and 0xFF) shl 16) or
            ((d[p + 1].toInt() and 0xFF) shl 8) or
            (d[p].toInt() and 0xFF)
    }

    private fun readPixel(input: DataInputStream): Int {
        val b = input.readUnsignedByte()
        val g = input.readUnsignedByte()
        val r = input.readUnsignedByte()
        input.readUnsignedByte()
        return OPAQUE_BLACK or (r shl 16) or (g shl 8) or b
    }

    private fun setPixel(x: Int, y: Int, color: Int) {
        if (x >= 0 && y >= 0 && x < fbWidth && y < fbHeight) {
            pixels[y * fbWidth + x] = color
        }
    }

    private fun fillRect(x: Int, y: Int, w: Int, h: Int, color: Int) {
        val x0 = if (x < 0) 0 else x
        val y0 = if (y < 0) 0 else y
        val x1 = if (x + w > fbWidth) fbWidth else x + w
        val y1 = if (y + h > fbHeight) fbHeight else y + h
        if (x1 <= x0 || y1 <= y0) return
        for (yy in y0 until y1) {
            val base = yy * fbWidth
            java.util.Arrays.fill(pixels, base + x0, base + x1, color)
        }
    }

    private fun skipFully(input: DataInputStream, count: Long) {
        var remaining = count
        while (remaining > 0) {
            val chunk = if (remaining > skipBuf.size) skipBuf.size else remaining.toInt()
            input.readFully(skipBuf, 0, chunk)
            remaining -= chunk
        }
    }

    // ------------------------------------------------------------------------------------
    // Output (client -> server)
    // ------------------------------------------------------------------------------------

    private fun requestUpdate(incremental: Boolean) {
        val o = out ?: return
        try {
            synchronized(writeLock) {
                o.writeByte(3)
                o.writeByte(if (incremental) 1 else 0)
                o.writeShort(0)
                o.writeShort(0)
                o.writeShort(fbWidth)
                o.writeShort(fbHeight)
                o.flush()
            }
        } catch (_: IOException) {
            // The reader thread will notice the broken socket.
        }
    }

    private fun submit(block: () -> Unit) {
        try {
            sender.execute {
                try {
                    block()
                } catch (_: Exception) {
                    try {
                        socket?.close()
                    } catch (_: Exception) {
                    }
                }
            }
        } catch (_: Exception) {
            // Executor already shut down.
        }
    }

    /** Ask the server to resend the whole screen. */
    override fun refresh() {
        submit { requestUpdate(false) }
    }

    /** Pointer event at remote pixel coordinates; ordered, never dropped. */
    override fun sendPointer(x: Int, y: Int, buttonMask: Int) {
        submit { writePointer(x, y, buttonMask) }
    }

    /** Pointer motion; intermediate positions may be dropped when the link is slow. */
    override fun sendPointerMove(x: Int, y: Int, buttonMask: Int) {
        pendingPointer = (buttonMask.toLong() shl 40) or (x.toLong() shl 20) or y.toLong()
        if (moveScheduled.compareAndSet(false, true)) {
            submit {
                moveScheduled.set(false)
                val v = pendingPointer
                if (v >= 0) {
                    val mask = ((v shr 40) and 0xFF).toInt()
                    val px = ((v shr 20) and 0xFFFFF).toInt()
                    val py = (v and 0xFFFFF).toInt()
                    writePointer(px, py, mask)
                }
            }
        }
    }

    private fun writePointer(x: Int, y: Int, mask: Int) {
        val o = out ?: return
        val maxX = if (fbWidth > 0) fbWidth - 1 else 0
        val maxY = if (fbHeight > 0) fbHeight - 1 else 0
        synchronized(writeLock) {
            o.writeByte(5)
            o.writeByte(mask and 0xFF)
            o.writeShort(x.coerceIn(0, maxX))
            o.writeShort(y.coerceIn(0, maxY))
            o.flush()
        }
    }

    override fun sendKey(keySym: Int, down: Boolean) {
        submit {
            val o = out
            if (o != null) {
                synchronized(writeLock) {
                    o.writeByte(4)
                    o.writeByte(if (down) 1 else 0)
                    o.writeShort(0)
                    o.writeInt(keySym)
                    o.flush()
                }
            }
        }
    }

    /** Send local clipboard text to the server (Latin-1 only, per the RFB specification). */
    override fun sendClipboard(text: String) {
        submit {
            val o = out
            if (o != null) {
                val bytes = text.toByteArray(Charsets.ISO_8859_1)
                synchronized(writeLock) {
                    o.writeByte(6)
                    o.write(byteArrayOf(0, 0, 0))
                    o.writeInt(bytes.size)
                    o.write(bytes)
                    o.flush()
                }
            }
        }
    }

    override fun connectionInfo(callback: (List<Pair<String, String>>) -> Unit) {
        callback(
            listOf(
                Pair("Engine", "Built-in RFB client"),
                Pair("Desktop", desktopName),
                Pair("Screen", "${fbWidth} x ${fbHeight}"),
                Pair("Security", "VNC password / none (not encrypted)"),
                Pair("Encodings", "ZRLE, Hextile, CopyRect, RRE, Raw, RichCursor, XCursor"),
                Pair("Pixel format", "32-bit true colour")
            )
        )
    }

    // ------------------------------------------------------------------------------------

    private fun describe(e: Throwable): String {
        return when (e) {
            is UnknownHostException -> "Unknown host \"$host\". Check the address."
            is ConnectException -> "Connection refused by $host:$port. Is a VNC server running on that port?"
            is NoRouteToHostException -> "No route to $host. Is the device on the same network / VPN?"
            is SocketTimeoutException -> "Timed out talking to $host:$port."
            is EOFException -> "The server closed the connection."
            is SocketException -> "Network error: ${e.message ?: "connection reset"}"
            is IOException -> e.message ?: "I/O error"
            else -> "${e.javaClass.simpleName}: ${e.message ?: "unexpected error"}"
        }
    }

    companion object {
        private const val ENC_RAW = 0
        private const val ENC_COPYRECT = 1
        private const val ENC_RRE = 2
        private const val ENC_HEXTILE = 5
        private const val ENC_ZRLE = 16
        private const val ENC_RICH_CURSOR = -239
        private const val ENC_X_CURSOR = -240
        private const val ENC_DESKTOP_SIZE = -223
        /** Larger cursor shapes are read and dropped rather than turned into a bitmap. */
        private const val MAX_CURSOR = 512
        private const val ENC_LAST_RECT = -224

        /** 0xFF000000 as a signed Int. */
        private const val OPAQUE_BLACK = -0x1000000
    }
}
