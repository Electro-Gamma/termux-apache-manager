// SPDX-License-Identifier: MIT
//
// Kotlin port of Vento's MouseOverlay.java (https://github.com/pgaskin/vento, control/ module,
// (C) 2026 Patrick Gaskin, MIT): the on-screen mouse buttons and wheel strip.
package com.vncviewer.app.input

/**
 * The mouse overlay: a row of Left / Middle / Right buttons across the bottom, a dismiss
 * button, and a wheel strip up the right-hand edge whose handle sets a scroll rate.
 */
class MouseOverlay(
    private val cfg: Config,
    private val sink: MouseSink,
    private val scheduler: Scheduler
) : TouchRouter.Claim {

    interface Listener {
        fun overlayChanged()
    }

    enum class Part(val button: Button?) {
        LEFT(Button.LEFT), MIDDLE(Button.MIDDLE), RIGHT(Button.RIGHT), DISMISS(null), SCROLL(null)
    }

    class Bounds(val part: Part, val left: Float, val top: Float, val right: Float, val bottom: Float) {
        fun contains(x: Float, y: Float): Boolean = x >= left && x < right && y >= top && y < bottom
        fun width(): Float = right - left
        fun height(): Float = bottom - top
        fun centreY(): Float = (top + bottom) / 2.0f
    }

    private var listener: Listener? = null
    private var viewW = 0
    private var viewH = 0

    /** How much of the view's bottom something else (the Keys row) is sitting on. */
    private var bottomOffset = 0f
    private val parts = ArrayList<Bounds>()
    private var visible = false
    private val ptrId = IntArray(10)
    private val ptrPart = arrayOfNulls<Part>(10)
    private var ptrCount = 0
    private var heldMask = 0
    private var scrollPtr = -1
    private var rate = 0f
    private var ticks = 0
    private var ticking = false
    private var handleY = 0f
    private val wheelTick: Runnable = object : Runnable {
        override fun run() {
            ticking = false
            if (rate == 0.0f) return
            ticks++
            if (ticks >= cfg.overlayWheelTicksPerClick / Math.abs(rate)) {
                click(rate)
                ticks = 0
            }
            schedule()
        }
    }

    fun setListener(l: Listener?) {
        listener = l
    }

    fun setViewSize(w: Int, h: Int) {
        if (w == viewW && h == viewH) return
        viewW = w
        viewH = h
        layout()
        changed()
    }

    /**
     * The controls float over the picture and never move it: the only thing that can move them is
     * another widget at the bottom (the Keys row), which they stand on rather than sit under.
     */
    fun setBottomOffset(px: Float) {
        val v = Math.max(px, 0f)
        if (v == bottomOffset) return
        bottomOffset = v
        layout()
        changed()
    }

    fun visible(): Boolean = visible
    fun toggle() = setVisible(!visible)

    fun setVisible(v: Boolean) {
        if (visible == v) return
        visible = v
        if (!visible) releaseAll()
        changed()
    }

    fun parts(): List<Bounds> = parts

    fun bounds(p: Part): Bounds? {
        for (b in parts) if (b.part == p) return b
        return null
    }

    fun pressed(p: Part): Boolean {
        for (i in 0 until ptrCount) if (ptrPart[i] == p) return true
        return false
    }

    fun heldMask(): Int = heldMask
    fun scrollRate(): Float = rate

    /** The wheel handle: a fixed-size outlined box, as RealVNC's. */
    fun handleHeight(): Float = cfg.dp(52f)

    fun handleWidth(): Float = cfg.dp(46f)

    fun handleTop(): Float = handleY - handleHeight() / 2.0f
    fun handleBottom(): Float = handleY + handleHeight() / 2.0f

    private fun layout() {
        parts.clear()
        if (viewW <= 0 || viewH <= 0) return
        // RealVNC's layout: a row of three buttons along the bottom (a wide left one, a narrow middle,
        // a wide right), the wheel strip up the right edge above the corner, and the close button
        // centred in that corner.
        val bottom = Math.max(viewH - bottomOffset, 0f)
        val rowTop = Math.max(bottom - cfg.overlayRowHeightPx, 0f)
        val strip = Math.min(cfg.overlayStripWidthPx, viewW.toFloat())
        val row = viewW - strip
        parts.add(Bounds(Part.SCROLL, row, 0f, viewW.toFloat(), rowTop))
        val leftEnd = row * 0.42f
        val midEnd = row * 0.626f
        parts.add(Bounds(Part.LEFT, 0f, rowTop, leftEnd, bottom))
        parts.add(Bounds(Part.MIDDLE, leftEnd, rowTop, midEnd, bottom))
        parts.add(Bounds(Part.RIGHT, midEnd, rowTop, row, bottom))
        val dcx = row + strip / 2.0f
        val dcy = bottom - cfg.overlayRowHeightPx / 2.0f
        val half = cfg.overlayDismissPx / 2.0f
        parts.add(Bounds(Part.DISMISS, dcx - half, dcy - half, dcx + half, dcy + half))
        centreHandle()
    }

    private fun centreHandle() {
        val s = bounds(Part.SCROLL)
        handleY = if (s == null) 0f else s.centreY()
    }

    override fun claimTouch(id: Int, x: Float, y: Float, t: Long): Boolean {
        if (!visible || ptrCount == ptrId.size) return false
        val hit = hit(x, y) ?: return false
        ptrId[ptrCount] = id
        ptrPart[ptrCount] = hit
        ptrCount++
        val b = hit.button
        if (b != null) {
            press(b)
        } else if (hit == Part.SCROLL && scrollPtr < 0) {
            scrollPtr = id
            drag(y)
        }
        changed()
        return true
    }

    override fun claimMoved(id: Int, x: Float, y: Float, t: Long) {
        val i = indexOf(id)
        if (i < 0) return
        if (ptrPart[i] == Part.SCROLL && id == scrollPtr) {
            drag(y)
            changed()
        }
    }

    override fun claimEnded(id: Int, x: Float, y: Float, t: Long) {
        val i = indexOf(id)
        if (i < 0) return
        val part = ptrPart[i]
        forget(i)
        val b = part?.button
        if (b != null) {
            release(b)
        } else if (part == Part.SCROLL && id == scrollPtr) {
            stopScrolling()
        } else if (part == Part.DISMISS) {
            val d = bounds(Part.DISMISS)
            if (d != null && d.contains(x, y)) setVisible(false)
        }
        changed()
    }

    override fun claimCancelled(t: Long) {
        releaseAll()
        changed()
    }

    private fun hit(x: Float, y: Float): Part? {
        for (b in parts) if (b.contains(x, y)) return b.part
        return null
    }

    private fun press(b: Button) {
        if ((heldMask and b.mask) == 0) {
            heldMask = heldMask or b.mask
            sink.mouseDown(b.mask)
        }
    }

    private fun release(b: Button) {
        for (i in 0 until ptrCount) if (ptrPart[i]?.button == b) return
        if ((heldMask and b.mask) != 0) {
            heldMask = heldMask and b.mask.inv()
            sink.mouseUp(b.mask)
        }
    }

    private fun releaseAll() {
        ptrCount = 0
        stopScrolling()
        if (heldMask != 0) {
            val m = heldMask
            heldMask = 0
            sink.mouseUp(m)
        }
    }

    private fun drag(y: Float) {
        val s = bounds(Part.SCROLL) ?: return
        if (s.height() <= 0) return
        handleY = clamp(y, s.top + handleHeight() / 2.0f, s.bottom - handleHeight() / 2.0f)
        val half = s.height() / 2.0f
        setRate(clamp((y - s.centreY()) / half, -1.0f, 1.0f) * cfg.overlayWheelMaxRate)
    }

    private fun setRate(r: Float) {
        if (rate == 0.0f && r != 0.0f) {
            click(r)
            ticks = -cfg.overlayWheelStartDelayTicks
            rate = r
            schedule()
        } else if (r == 0.0f) {
            pauseScrolling()
        } else {
            rate = r
        }
    }

    private fun stopScrolling() {
        scrollPtr = -1
        pauseScrolling()
    }

    private fun pauseScrolling() {
        rate = 0f
        ticks = 0
        if (ticking) {
            ticking = false
            scheduler.removeCallbacks(wheelTick)
        }
        centreHandle()
    }

    private fun schedule() {
        if (!ticking) {
            ticking = true
            scheduler.postDelayed(wheelTick, cfg.overlayWheelTickMs)
        }
    }

    private fun click(r: Float) {
        val b = if (r < 0) Button.WHEEL_UP else Button.WHEEL_DOWN
        sink.mouseDown(b.mask)
        sink.mouseUp(b.mask)
    }

    private fun indexOf(id: Int): Int {
        for (i in 0 until ptrCount) if (ptrId[i] == id) return i
        return -1
    }

    private fun forget(i: Int) {
        ptrCount--
        ptrId[i] = ptrId[ptrCount]
        ptrPart[i] = ptrPart[ptrCount]
    }

    private fun changed() {
        listener?.overlayChanged()
    }

    private fun clamp(v: Float, lo: Float, hi: Float): Float = if (v < lo) lo else if (v > hi) hi else v
}
