package com.vncviewer.app.ui

import androidx.compose.ui.graphics.toArgb
import app.terminalssh.secure.ui.theme.Amber
import app.terminalssh.secure.ui.theme.Cyan
import app.terminalssh.secure.ui.theme.Danger
import app.terminalssh.secure.ui.theme.Ink
import app.terminalssh.secure.ui.theme.Stroke
import app.terminalssh.secure.ui.theme.Surface1
import app.terminalssh.secure.ui.theme.Surface2
import app.terminalssh.secure.ui.theme.TextPrimary
import app.terminalssh.secure.ui.theme.TextSecondary
import app.terminalssh.secure.ui.theme.Turquoise

/**
 * The app palette (see ui/theme/Theme.kt) as ARGB ints, for the chrome that is drawn straight
 * onto an Android Canvas (toolbar, mouse controls, extension keyboard). Read at draw time, so a
 * light/dark switch repaints it.
 */
object ChromeColors {
    @JvmStatic fun ink(): Int = Ink.toArgb()
    @JvmStatic fun surface1(): Int = Surface1.toArgb()
    @JvmStatic fun surface2(): Int = Surface2.toArgb()
    @JvmStatic fun stroke(): Int = Stroke.toArgb()
    @JvmStatic fun textPrimary(): Int = TextPrimary.toArgb()
    @JvmStatic fun textSecondary(): Int = TextSecondary.toArgb()
    @JvmStatic fun accent(): Int = Turquoise.toArgb()
    @JvmStatic fun progress(): Int = Cyan.toArgb()
    @JvmStatic fun waiting(): Int = Amber.toArgb()
    @JvmStatic fun danger(): Int = Danger.toArgb()

    /** [argb] with its alpha replaced by [alpha] (0..255). */
    @JvmStatic fun withAlpha(argb: Int, alpha: Int): Int = (argb and 0x00FFFFFF) or ((alpha and 0xFF) shl 24)

    /** The primary text colour at [alpha] (0..255). */
    @JvmStatic fun text(alpha: Int): Int = withAlpha(textPrimary(), alpha)
}
