// SPDX-FileCopyrightText: 2026 Patrick Gaskin
// SPDX-License-Identifier: MIT

package com.vncviewer.app.ui;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;

import com.vncviewer.app.input.Config;
import com.vncviewer.app.input.ExtensionKeyboard;

/**
 * The extension keyboard's drawing, taken as it is from Vento's {@code Chrome}
 * (https://github.com/pgaskin/vento, control/ui/Chrome.java): the key row, its
 * info bar, the ripple and the icon painter, and nothing of the rest of that class (the
 * mouse overlay and toolbar are drawn by {@link ChromeDraw}).
 */
public final class KeyboardChrome {

    private static final float RIPPLE_NANOS = 260e6f; // a key's ripple, start to finish
    private static final float BAR_FADE_DP = 40f;     // where the cursor starts pushing the bar out
    private static final float BAR_FADE_MIN = 0.1f;   // what is left of it: a hint, not a panel

    private final Config cfg;

    private final Paint panel = new Paint(Paint.ANTI_ALIAS_FLAG);
    // keyPaint is also the label measurer, so its size must not change elsewhere.
    private final Paint keyPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint barPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint iconPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private final RectF box = new RectF();
    private final Rect bounds = new Rect();

    // The ripple: what was pressed, from where, and when.
    private Object lastPressed;
    private Object rippleOwner;
    private long rippleStartNanos;
    private float rippleX, rippleY;

    public KeyboardChrome(Config cfg) {
        this.cfg = cfg;
        keyPaint.setTextSize(cfg.dp(12.5f));
        keyPaint.setTextAlign(Paint.Align.CENTER);
        barPaint.setTextAlign(Paint.Align.CENTER);
    }

    /** The keyboard measures its labels with our font, so it must be ours. */
    public void attach(ExtensionKeyboard keyboard) {
        keyboard.setLabelWidth(keyPaint::measureText);
    }

    /**
     * Call from the keyboard's own change notification: a new press starts a
     * ripple, and the press is the only moment its origin is known.
     */
    public void keyboardChanged(ExtensionKeyboard keyboard) {
        final ExtensionKeyboard.Key pressed = keyboard.pressedKey();
        if (pressed == lastPressed) {
            return;
        }
        lastPressed = pressed;
        if (pressed == null) {
            return;
        }
        startRipple(pressed, keyboard.pressedX(), keyboard.pressedY());
    }

    private void startRipple(Object owner, float x, float y) {
        rippleOwner = owner;
        rippleStartNanos = System.nanoTime();
        rippleX = x;
        rippleY = y;
    }

    /**
     * The key row and its info bar.
     *
     * @param cursorY where the cursor is on screen; the info bar gets out of
     *                its way (see {@link #barFade})
     * @return whether another frame is wanted — a ripple is mid-flight
     */
    public boolean drawKeyboard(Canvas c, ExtensionKeyboard keyboard, int viewWidth,
                                float cursorY) {
        final float barTop = keyboard.infoBarTop();
        final float rowTop = keyboard.keyRowTop();
        final float rowBottom = keyboard.keyRowBottom();
        final float barMid = (barTop + rowTop) / 2;
        // Solid means the desktop is inset by the bar, so there is no cursor
        // under it to get out of the way of and nothing to see through it.
        final float fade = cfg.keyboardInfoSolid ? 1f
                : barFade(0, barTop, viewWidth, rowTop, 0, cursorY);

        // ---- the info bar --------------------------------------------------
        // A step lighter than the key row below it, which is black: the two are
        // one widget and the readout is the part that is not a key.
        box.set(0, barTop, viewWidth, rowTop);
        panel.setColor(cfg.keyboardInfoSolid ? ChromeColors.surface2()
                : alpha(ChromeColors.withAlpha(ChromeColors.surface2(), 0xe6), fade));
        c.drawRect(box, panel);

        // Status lights, one per modifier: dim is off, bright is armed, an
        // underline means locked.
        final float cell = keyboard.lightCell();
        final float ink = cfg.dp(13);
        barPaint.setTextSize(cfg.dp(14));
        float x = keyboard.lightsLeft();
        for (ExtensionKeyboard.Key m : keyboard.modifiers()) {
            final ExtensionKeyboard.Sticky s = keyboard.sticky(m);
            final int colour = alpha(s == ExtensionKeyboard.Sticky.OFF ? ChromeColors.text(0x4d) : ChromeColors.text(0xff),
                    fade);
            barPaint.setColor(colour);
            final KeyIcons.Icon icon = KeyIcons.of(m.icon());
            if (icon != null) {
                drawIcon(c, icon, x + (cell - ink) / 2, barMid - ink / 2, ink, colour);
            } else {
                // The original's info bar draws Ctrl and Alt as a bare C and A —
                // the initial is all the room there is, and all that is needed.
                final String initial = m.label().substring(0, 1);
                barPaint.getTextBounds(initial, 0, initial.length(), bounds);
                c.drawText(initial, x + cell / 2, barMid - bounds.exactCenterY(), barPaint);
            }
            if (s == ExtensionKeyboard.Sticky.LOCKED) {
                final float uy = barMid + ink / 2 + cfg.dp(2.5f);
                panel.setColor(colour);
                c.drawRect(x + (cell - ink) / 2, uy,
                        x + (cell + ink) / 2, uy + cfg.dp(1.2f), panel);
            }
            x += cell;
        }

        // The line being typed, ellipsized from the start: the tail is the part
        // you are still working on.
        barPaint.setTextAlign(Paint.Align.LEFT);
        barPaint.setTextSize(keyboard.masked() ? cfg.dp(10) : cfg.dp(11));
        barPaint.setColor(alpha(ChromeColors.text(0x99), fade));
        final String info = keyboard.infoText();
        final float avail = keyboard.textRight() - keyboard.textLeft();
        int from = 0;
        while (from < info.length() && barPaint.measureText(info, from, info.length()) > avail) {
            from++;
        }
        c.drawText(info.substring(from), keyboard.textLeft(), barMid + cfg.dp(4), barPaint);
        barPaint.setTextAlign(Paint.Align.CENTER);

        barPaint.setTextSize(cfg.dp(12));
        barPaint.setColor(alpha(ChromeColors.text(0x99), fade));
        for (ExtensionKeyboard.Part p : ExtensionKeyboard.Part.values()) {
            final ExtensionKeyboard.Bounds b = keyboard.part(p);
            c.drawText(p == ExtensionKeyboard.Part.DISMISS
                            ? "✕" : (keyboard.masked() ? "•••" : "abc"),
                    b.centreX(), b.centreY() + cfg.dp(4), barPaint);
        }

        // ---- the key row ---------------------------------------------------
        // Solid, unlike the info bar above it. The eye reads a key's face against
        // its background, and desktop content showing through turns forty faint
        // glyphs into forty ambiguities — worst over a light window, where the
        // labels vanish altogether. The bar above is a readout with nothing to
        // aim at, so letting the desktop through there costs nothing.
        box.set(0, rowTop, viewWidth, rowBottom);
        panel.setColor(ChromeColors.ink());
        c.drawRect(box, panel);

        boolean animating = false;
        for (ExtensionKeyboard.Bounds b : keyboard.keys()) {
            if (b.right() < 0 || b.left() > viewWidth) {
                continue;
            }
            final boolean down = keyboard.pressedKey() == b.key();
            final ExtensionKeyboard.Sticky s = keyboard.sticky(b.key());
            // The key's own bounds, not the row's: a list of more than one line
            // puts them on different lines, and the two are the same rectangle
            // only while there is one.
            box.set(b.left(), b.top(), b.right(), b.bottom());

            // Flush rectangles with no chrome of their own, as the original draws
            // them: borders and margins turn forty keys into forty slabs, and
            // the group gaps are the only division the row needs.
            if (s != ExtensionKeyboard.Sticky.OFF) {
                panel.setColor(s == ExtensionKeyboard.Sticky.LOCKED ? ChromeColors.text(0x38) : ChromeColors.text(0x20));
                c.drawRect(box, panel);
            }
            if (down) {
                panel.setColor(ChromeColors.text(0x1a));
                c.drawRect(box, panel);
            }

            animating |= drawRipple(c, b.key(), b.left(), b.top(), b.right(), b.bottom());

            final int colour = s == ExtensionKeyboard.Sticky.OFF ? ChromeColors.text(0xa3) : ChromeColors.text(0xf2);
            final KeyIcons.Icon icon = KeyIcons.of(b.key().icon());
            final float underlineHalf;
            if (icon != null) {
                final float size = cfg.keyboardIconWidthPx;
                drawIcon(c, icon, b.centreX() - size / 2, b.centreY() - size / 2, size, colour);
                underlineHalf = size / 2;
            } else {
                keyPaint.setColor(colour);
                c.drawText(b.key().label(), b.centreX(), b.centreY() + cfg.dp(4.5f), keyPaint);
                underlineHalf = keyPaint.measureText(b.key().label()) / 2;
            }
            if (s == ExtensionKeyboard.Sticky.LOCKED) {
                panel.setColor(colour);
                c.drawRect(b.centreX() - underlineHalf, b.centreY() + cfg.dp(8),
                        b.centreX() + underlineHalf, b.centreY() + cfg.dp(9.2f), panel);
            }
        }
        return animating;
    }

    /**
     * How opaque a thing floating over the desktop should be, given how far the
     * cursor is from it.
     *
     * <p>The desktop insets above the whole keyboard, so the info bar covers no
     * remote pixels — but it does cover the <em>cursor</em>: the viewport clamps
     * the desktop into the content rect, so a cursor at the bottom edge sits on
     * the bar's top edge and an arrow drawn from its hotspot extends into it.
     * The chrome is drawn after the cursor, so the bar would swallow it exactly
     * while the pointer was being pushed downwards. Fading rather than
     * reordering, because only one of them can be on top; ramped rather than
     * switched, so it does not blink as the cursor grazes the boundary.
     *
     * <p>The toolbar wants the same thing for a stronger version of the same
     * reason — the desktop runs under it, not merely the cursor — so the ramp is
     * one piece of code and the distance is to a rectangle. The info bar is the
     * degenerate case of a rect that spans the window, where the horizontal
     * distance is never positive and this is {@code barTop - cursorY} exactly.
     */
    private float barFade(float l, float t, float r, float b, float cursorX, float cursorY) {
        final float d = Math.max(Math.max(l - cursorX, cursorX - r),
                Math.max(t - cursorY, cursorY - b));
        if (d <= 0) {
            return BAR_FADE_MIN;
        }
        final float ramp = cfg.dp(BAR_FADE_DP);
        if (d >= ramp) {
            return 1f;
        }
        return BAR_FADE_MIN + (1f - BAR_FADE_MIN) * (d / ramp);
    }

    /** {@code argb} with its alpha scaled by {@code f}. */
    private static int alpha(int argb, float f) {
        final int a = Math.round(((argb >>> 24) & 0xff) * f);
        return (a << 24) | (argb & 0xffffff);
    }

    /**
     * A material-style ripple from where the finger landed, on the one thing it
     * belongs to. Hand-drawn because neither widget is a view per target — which
     * is the whole point of the claim-based routing — so there is no
     * {@code Drawable} to hang a {@code RippleDrawable} on.
     *
     * <p>Keyed on the object rather than on a key, so a toolbar button and an
     * extension key are the same case: whoever last reported a press owns it.
     */
    private boolean drawRipple(Canvas c, Object owner,
                               float left, float top, float right, float bottom) {
        if (rippleStartNanos == 0 || rippleOwner == null || rippleOwner != owner) {
            return false;
        }
        final float t = (System.nanoTime() - rippleStartNanos) / RIPPLE_NANOS;
        if (t >= 1f) {
            rippleStartNanos = 0;
            return false;
        }
        // Fast out, slow in on the radius; linear fade, so a quick tap still
        // leaves a visible mark and a long hold does not glow for ever.
        final float grow = 1f - (1f - t) * (1f - t);
        final float max = Math.max(right - left, bottom - top);
        final int save = c.save();
        box.set(left, top, right, bottom);
        c.clipRect(box);
        panel.setColor((int) (0x2e * (1f - t)) << 24 | 0xffffff);
        c.drawCircle(rippleX, rippleY, max * (0.35f + 0.65f * grow), panel);
        c.restoreToCount(save);
        return true;
    }

    /**
     * A {@link KeyIcons} glyph, scaled from its unit box into a {@code size}
     * square at {@code (left, top)}. Stroked icons keep their weight relative to
     * the box, so ⇧ at 13 px and ⇧ at 18 px look like the same glyph.
     */
    private void drawIcon(Canvas c, KeyIcons.Icon icon, float left, float top,
                          float size, int colour) {
        final int save = c.save();
        c.translate(left, top);
        c.scale(size, size);
        if (icon.stroke() > 0) {
            iconPaint.setStyle(Paint.Style.STROKE);
            iconPaint.setStrokeWidth(icon.stroke());
            // Round ends and corners: these are line drawings at 13–18 dp, where
            // a mitred corner on a 2 px stroke is a spike.
            iconPaint.setStrokeCap(Paint.Cap.ROUND);
            iconPaint.setStrokeJoin(Paint.Join.ROUND);
        } else {
            iconPaint.setStyle(Paint.Style.FILL);
        }
        iconPaint.setColor(colour);
        c.drawPath(icon.path(), iconPaint);
        c.restoreToCount(save);
    }
}
