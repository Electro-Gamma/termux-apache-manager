package com.vncviewer.app.ui

import android.graphics.Bitmap
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.terminalssh.secure.R
import com.vncviewer.app.data.Engine
import com.vncviewer.app.data.Thumbnails
import com.vncviewer.app.data.VncProfile
import com.vncviewer.app.input.AppSettings
import com.vncviewer.app.session.Phase

// The home screen's measurements, from Vento's dimens.xml.
private val GROUP_RADIUS = 16.dp
private val GROUP_RADIUS_INNER = 4.dp
private val GROUP_INSET = 16.dp
private val GROUP_GAP = 2.dp
private val GROUP_SPACING = 20.dp
private val CARD_MARGIN = 8.dp
private val BAR_HEIGHT = 64.dp
private const val PREVIEW_RATIO = 0.72f // height as a fraction of width
private val BADGE_SCRIM = Color(0x99000000)
private val ON_SCRIM = Color(0xE8FFFFFF)

/**
 * The home screen: one saved connection per item, as a card or as a row (the bar chooses, and the
 * choice is remembered), with a bar of three buttons and the one that adds a connection.
 *
 * Cards are how somebody recognises a machine by what was on its screen; rows are how somebody
 * finds one among twenty. Pressing opens the machine, holding edits it.
 */
@Composable
fun HomeScreen(vm: VncViewModel) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val listView = AppSettings.listView(ctx)
    val gridState = rememberLazyGridState()
    // Inside Terminal SSH the status bar and side insets are already applied by the root screen and
    // the navigation bar is cleared by its bottom dock, so none of them is added again here.
    val statusTop = 0.dp
    val left = 0.dp
    val right = 0.dp
    val bottom = 0.dp
    var reordering by remember { mutableStateOf(false) }
    val snackbar = remember { SnackbarHostState() }

    val message = vm.listMessage
    LaunchedEffect(message) {
        if (message != null) {
            snackbar.showSnackbar(message)
            vm.listMessage = null
        }
    }

    val pinnedCount = vm.profiles.count { it.favorite }

    Box(Modifier.fillMaxSize()) {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            // As many columns of about 240 dp as fit and never fewer than two for cards; a row is
            // read left to right, so it wants twice that and is alone across a phone.
            val span = if (listView) maxOf(1, Math.round(maxWidth.value / 480f))
            else maxOf(2, Math.round(maxWidth.value / 240f))
            val side = if (listView) 0.dp else CARD_MARGIN
            val top = if (listView) CARD_MARGIN else 0.dp

            LazyVerticalGrid(
                columns = GridCells.Fixed(span),
                state = gridState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(
                    start = left + side,
                    top = statusTop + BAR_HEIGHT + top,
                    end = right + side,
                    bottom = bottom + 72.dp
                )
            ) {
                itemsIndexed(vm.profiles, key = { _, p -> p.id }) { index, profile ->
                    val live = vm.sessions.firstOrNull { it.profile.id == profile.id }
                    val liveLabel = when {
                        live == null || live.phase == Phase.FAILED -> null
                        live.phase == Phase.CONNECTED -> "Connected"
                        else -> "Connecting…"
                    }
                    if (listView) {
                        val last = vm.profiles.size - 1
                        val atBottom = index >= last - last % span
                        ConnectionRow(
                            profile = profile,
                            liveLabel = liveLabel,
                            first = index < span,
                            last = atBottom,
                            onClick = { vm.openProfile(profile) },
                            onLongClick = { vm.startEditProfile(profile) }
                        )
                    } else {
                        ConnectionCard(
                            profile = profile,
                            liveLabel = liveLabel,
                            onClick = { vm.openProfile(profile) },
                            onLongClick = { vm.startEditProfile(profile) }
                        )
                    }
                }
            }
        }

        if (vm.profiles.isEmpty()) EmptyState(Modifier.align(Alignment.Center))

        // The bar is the page's own colour rather than transparent; it takes its shadow the
        // moment a card has scrolled under it.
        val lift by animateDpAsState(if (gridState.canScrollBackward) 4.dp else 0.dp, label = "lift")
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(lift)
                .background(if (gridState.canScrollBackward) cs.background else Color.Transparent)
                .padding(top = statusTop, start = left, end = right + 8.dp)
                .height(BAR_HEIGHT),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "VNC Viewer",
                style = MaterialTheme.typography.titleLarge,
                color = cs.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f).padding(start = 24.dp)
            )
            // Only while there is an order to change: two pins are the fewest that can be in the
            // wrong one, and the button is hidden below that rather than opening an empty sheet.
            if (pinnedCount > 1) {
                BarButton(R.drawable.hm_ic_low_priority, "Reorder pinned") { reordering = true }
            }
            // The icon and the label are the shape being switched *to*.
            BarButton(
                if (listView) R.drawable.hm_ic_view_grid else R.drawable.hm_ic_view_list,
                if (listView) "Grid view" else "List view"
            ) { AppSettings.setListView(ctx, !listView) }
            BarButton(R.drawable.hm_ic_settings, "Settings") { vm.openSettings() }
        }

        FloatingActionButton(
            onClick = { vm.startNewProfile() },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = right + 16.dp, bottom = bottom + 16.dp)
        ) {
            Icon(painterResource(R.drawable.hm_ic_add), contentDescription = "Add connection")
        }

        SnackbarHost(
            snackbar,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = bottom + 80.dp)
        )
    }

    if (reordering) {
        PinnedOrderSheet(vm, onDismiss = { reordering = false })
    }

    val editing = vm.editorProfile
    if (editing != null) {
        ProfileEditorDialog(
            initial = editing,
            isNew = vm.editorIsNew,
            onSave = { saved ->
                vm.saveProfile(saved)
                vm.editorProfile = null
            },
            onDelete = if (vm.editorIsNew) null else ({
                vm.deleteCandidate = editing
                vm.editorProfile = null
            }),
            onDismiss = { vm.editorProfile = null }
        )
    }

    val toDelete = vm.deleteCandidate
    if (toDelete != null) {
        androidx.compose.material3.AlertDialog(
        containerColor = androidx.compose.material3.MaterialTheme.colorScheme.surface,
            onDismissRequest = { vm.deleteCandidate = null },
            title = { Text("Delete " + toDelete.name.ifBlank { toDelete.address } + "?") },
            text = { Text("The connection, saved credentials, and preview will be permanently deleted.") },
            confirmButton = {
                androidx.compose.material3.TextButton(onClick = {
                    vm.deleteProfile(toDelete)
                    vm.deleteCandidate = null
                }) { Text("Delete") }
            },
            dismissButton = {
                androidx.compose.material3.TextButton(onClick = { vm.deleteCandidate = null }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun BarButton(icon: Int, description: String, onClick: () -> Unit) {
    IconButton(onClick = onClick, modifier = Modifier.size(48.dp)) {
        Icon(painterResource(icon), contentDescription = description, tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/** Nothing saved yet, which is what this screen looks like exactly once. */
@Composable
private fun EmptyState(modifier: Modifier) {
    Column(
        modifier = modifier.fillMaxWidth().padding(horizontal = 48.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            painterResource(R.drawable.hm_ic_desktop),
            contentDescription = null,
            modifier = Modifier.size(56.dp).padding(bottom = 0.dp),
            tint = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            "No connections",
            style = MaterialTheme.typography.titleLarge,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 16.dp)
        )
        Text(
            "Press the + button to add a connection.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 8.dp)
        )
    }
}

// ---- one connection ---------------------------------------------------------------------

private fun VncProfile.title(): String = name.ifBlank { address }
private fun VncProfile.subtitle(): String = if (name.isBlank()) "" else address
private fun VncProfile.badge(): String = if (engine == Engine.REALVNC) "RealVNC" else "VNC"

/** The preview if there is one and it is current; null while it is being read, or never taken. */
@Composable
private fun rememberPreview(profile: VncProfile): Bitmap? {
    val ctx = LocalContext.current
    val version = Thumbnails.version(profile.id)
    val bmp by produceState<Bitmap?>(null, profile.id, version) {
        value = Thumbnails.read(ctx, profile.id)
    }
    return bmp
}

@Composable
private fun PreviewPicture(profile: VncProfile, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    val bmp = rememberPreview(profile)
    Box(modifier.background(cs.surfaceVariant), contentAlignment = Alignment.Center) {
        if (bmp != null) {
            Image(
                bitmap = bmp.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            // Nothing has been connected to yet: one faint icon at its natural size, not cropped
            // to fill the band.
            Icon(
                painterResource(R.drawable.hm_ic_desktop),
                contentDescription = null,
                modifier = Modifier.size(48.dp),
                tint = cs.onSurface.copy(alpha = 0.20f)
            )
        }
    }
}

@Composable
private fun Badge(text: String, background: Color, color: Color) {
    Text(
        text = text,
        style = MaterialTheme.typography.labelSmall,
        color = color,
        modifier = Modifier
            .background(background, RoundedCornerShape(6.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    )
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ConnectionCard(
    profile: VncProfile,
    liveLabel: String?,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    Column(
        modifier = Modifier
            .padding(CARD_MARGIN)
            .fillMaxWidth()
            .clip(RoundedCornerShape(GROUP_RADIUS))
            .background(cs.surface)
            .border(1.dp, app.terminalssh.secure.ui.theme.Stroke, RoundedCornerShape(GROUP_RADIUS))
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
    ) {
        Box(Modifier.fillMaxWidth()) {
            PreviewPicture(profile, Modifier.fillMaxWidth().aspectRatio(1f / PREVIEW_RATIO))
            // Which backend this connection is on, over the preview: a property of the card.
            Box(Modifier.align(Alignment.TopStart).padding(CARD_MARGIN)) {
                Badge(profile.badge(), BADGE_SCRIM, ON_SCRIM)
            }
            // Live right now: the one thing on a card that is not a property of what was saved.
            if (liveLabel != null) {
                Box(Modifier.align(Alignment.BottomStart).padding(CARD_MARGIN)) {
                    Badge(liveLabel, cs.primary, cs.onPrimary)
                }
            }
            if (profile.favorite) {
                Icon(
                    painterResource(R.drawable.hm_ic_pin),
                    contentDescription = "Pinned",
                    tint = ON_SCRIM,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(CARD_MARGIN)
                        .background(BADGE_SCRIM, RoundedCornerShape(6.dp))
                        .padding(3.dp)
                        .size(18.dp)
                )
            }
        }
        // The inset is the block's padding, not the labels' margins: a connection with no name
        // hides its subtitle and must not lose the bottom inset with it.
        Column(Modifier.fillMaxWidth().padding(start = 12.dp, top = 10.dp, end = 12.dp, bottom = 10.dp)) {
            Text(
                profile.title(),
                style = MaterialTheme.typography.titleMedium,
                color = cs.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            // Invisible, not gone: cards in one grid row stay the same height.
            Text(
                profile.subtitle().ifEmpty { " " },
                style = MaterialTheme.typography.bodyMedium,
                color = cs.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.alpha(if (profile.subtitle().isEmpty()) 0f else 1f)
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ConnectionRow(
    profile: VncProfile,
    liveLabel: String?,
    first: Boolean,
    last: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    // A run of rows is one group: large corners at its ends, small ones between.
    val topR = if (first) GROUP_RADIUS else GROUP_RADIUS_INNER
    val bottomR = if (last) GROUP_RADIUS else GROUP_RADIUS_INNER
    val shape = RoundedCornerShape(topStart = topR, topEnd = topR, bottomStart = bottomR, bottomEnd = bottomR)
    Row(
        modifier = Modifier
            .padding(start = GROUP_INSET, end = GROUP_INSET, bottom = if (last) 0.dp else GROUP_GAP)
            .fillMaxWidth()
            .clip(shape)
            .background(cs.surface)
            .border(1.dp, app.terminalssh.secure.ui.theme.Stroke, shape)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(start = 8.dp, top = 8.dp, end = 16.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        PreviewPicture(profile, Modifier.size(width = 76.dp, height = 64.dp).clip(RoundedCornerShape(8.dp)))
        Column(Modifier.weight(1f).padding(start = 12.dp)) {
            Text(
                profile.title(),
                style = MaterialTheme.typography.titleMedium,
                color = cs.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                profile.subtitle().ifEmpty { " " },
                style = MaterialTheme.typography.bodyMedium,
                color = cs.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Row(Modifier.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                if (profile.favorite) {
                    Icon(
                        painterResource(R.drawable.hm_ic_pin),
                        contentDescription = "Pinned",
                        tint = cs.onSurfaceVariant,
                        modifier = Modifier.size(14.dp)
                    )
                    Box(Modifier.width(6.dp))
                }
                Badge(profile.badge(), cs.surfaceVariant, cs.onSurfaceVariant)
                if (liveLabel != null) {
                    Box(Modifier.width(6.dp))
                    Badge(liveLabel, cs.primary, cs.onPrimary)
                }
            }
        }
    }
}
