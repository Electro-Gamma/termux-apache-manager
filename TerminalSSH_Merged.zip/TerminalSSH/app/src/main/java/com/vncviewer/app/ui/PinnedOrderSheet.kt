package com.vncviewer.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.semantics.customActions
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import app.terminalssh.secure.R
import com.vncviewer.app.data.VncProfile
import kotlin.math.roundToInt

/**
 * The pinned connections, in the order they sit in at the top of the home screen, to be dragged
 * past one another. A sheet of its own rather than a mode over the list, because on the list a
 * press opens a machine and a long press edits it. Written whenever a move finishes.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PinnedOrderSheet(vm: VncViewModel, onDismiss: () -> Unit) {
    val items = remember { mutableStateListOf<VncProfile>().apply { addAll(vm.profiles.filter { it.favorite }) } }
    var dragId by remember { mutableStateOf<String?>(null) }
    var dragOffset by remember { mutableFloatStateOf(0f) }
    var rowStep by remember { mutableIntStateOf(0) } // a row's height plus the gap under it
    val gap = with(LocalDensity.current) { 8.dp.toPx() }

    fun commit() = vm.reorderPinned(items.map { it.id })

    fun move(id: String, by: Int): Boolean {
        val from = items.indexOfFirst { it.id == id }
        val to = from + by
        if (from < 0 || to !in items.indices) return false
        val moved = items.removeAt(from)
        items.add(to, moved)
        commit()
        return true
    }

    ModalBottomSheet(
        containerColor = androidx.compose.material3.MaterialTheme.colorScheme.surface,
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ) {
        Column(Modifier.navigationBarsPadding().padding(bottom = 20.dp)) {
            Row(
                Modifier.fillMaxWidth().padding(start = 24.dp, end = 20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Reorder pinned",
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.weight(1f).padding(vertical = 12.dp)
                )
                IconButton(onClick = onDismiss, modifier = Modifier.size(48.dp)) {
                    Icon(painterResource(R.drawable.hm_ic_close), contentDescription = "Close")
                }
            }
            Column(Modifier.verticalScroll(rememberScrollState())) {
                for (p in items.toList()) {
                    key(p.id) {
                        val dragging = dragId == p.id
                        Row(
                            modifier = Modifier
                                .zIndex(if (dragging) 1f else 0f)
                                .offset { IntOffset(0, if (dragging) dragOffset.roundToInt() else 0) }
                                .padding(start = 16.dp, end = 16.dp, bottom = 8.dp)
                                .fillMaxWidth()
                                .onSizeChanged { rowStep = it.height + gap.roundToInt() }
                                .background(MaterialTheme.colorScheme.surfaceBright, RoundedCornerShape(16.dp))
                                .semantics {
                                    customActions = listOf(
                                        CustomAccessibilityAction("Move up") { move(p.id, -1) },
                                        CustomAccessibilityAction("Move down") { move(p.id, 1) }
                                    )
                                }
                                .padding(start = 16.dp, top = 8.dp, end = 8.dp, bottom = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(0.dp)
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    p.name.ifBlank { p.address },
                                    style = MaterialTheme.typography.titleMedium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (p.name.isNotBlank()) {
                                    Text(
                                        p.address,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                            Icon(
                                painterResource(R.drawable.hm_ic_drag),
                                contentDescription = "Drag to reorder",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier
                                    .size(48.dp)
                                    .pointerInput(p.id) {
                                        var moved = false
                                        detectDragGestures(
                                            onDragStart = {
                                                dragId = p.id
                                                dragOffset = 0f
                                                moved = false
                                            },
                                            onDrag = { change, amount ->
                                                change.consume()
                                                dragOffset += amount.y
                                                val at = items.indexOfFirst { it.id == p.id }
                                                val step = rowStep.toFloat()
                                                if (at >= 0 && step > 0f) {
                                                    // Swap once the row is past half of its neighbour, and take the
                                                    // distance the swap covered off the offset so the row stays under
                                                    // the finger.
                                                    if (dragOffset > step / 2 && at < items.lastIndex) {
                                                        items.add(at + 1, items.removeAt(at))
                                                        dragOffset -= step
                                                        moved = true
                                                    } else if (dragOffset < -step / 2 && at > 0) {
                                                        items.add(at - 1, items.removeAt(at))
                                                        dragOffset += step
                                                        moved = true
                                                    }
                                                }
                                            },
                                            onDragEnd = {
                                                dragId = null
                                                dragOffset = 0f
                                                if (moved) commit()
                                            },
                                            onDragCancel = {
                                                dragId = null
                                                dragOffset = 0f
                                                if (moved) commit()
                                            }
                                        )
                                    }
                                    .padding(12.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
