package com.vncviewer.app.session

import android.content.ClipData
import android.content.Context
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Log
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/**
 * The desktop, photographed and handed to the share sheet (Vento's Screenshot).
 *
 * What is captured is the *desktop*, whole and at the size the far end has it - not the phone's
 * viewport with a locally drawn cursor on top. The PNG goes to this app's cache and is shared as a
 * read grant on one URI (FileProvider), so it reaches the app that was chosen and nothing else;
 * the previous screenshot is deleted the next time this runs.
 */
object Screenshot {
    private const val TAG = "Screenshot"
    private const val DIR = "screenshots"

    private val writer = Executors.newSingleThreadExecutor { r ->
        Thread(r, "screenshot-writer").apply { isDaemon = true }
    }
    private val main = Handler(Looper.getMainLooper())

    fun share(context: Context, session: VncSession) {
        val app = context.applicationContext
        val shot = session.desktopSnapshot()
        if (shot == null) {
            Toast.makeText(app, "The desktop could not be captured.", Toast.LENGTH_SHORT).show()
            return
        }
        val name = fileName(session)
        writer.execute {
            val file = write(app, shot, name)
            shot.recycle()
            main.post {
                if (file == null) {
                    Toast.makeText(app, "The desktop could not be captured.", Toast.LENGTH_SHORT).show()
                } else {
                    send(app, file, name)
                }
            }
        }
    }

    /**
     * Save the desktop straight to the gallery, no share sheet: Pictures/VncViewer/screenshots
     * (Android 10+, through MediaStore, so no storage permission is needed). Older Android keeps
     * them in the app's own pictures folder, which needs no permission either.
     */
    fun save(context: Context, session: VncSession) {
        val app = context.applicationContext
        val shot = session.desktopSnapshot()
        if (shot == null) {
            Toast.makeText(app, "The desktop could not be captured.", Toast.LENGTH_SHORT).show()
            return
        }
        val name = fileName(session)
        writer.execute {
            val where = try {
                store(app, shot, name)
            } catch (e: Exception) {
                Log.w(TAG, "saving the screenshot", e)
                null
            }
            shot.recycle()
            main.post {
                val msg = if (where == null) "The screenshot could not be saved." else "Screenshot saved to $where"
                Toast.makeText(app, msg, Toast.LENGTH_SHORT).show()
            }
        }
    }

    /** Returns a short description of where it went, or null on failure. */
    private fun store(ctx: Context, shot: Bitmap, name: String): String? {
        // With all-files access: a plain folder, <storage>/VncViewer/screenshots.
        if (StorageAccess.has(ctx)) {
            val dir = StorageAccess.folder("screenshots")
            if (dir != null) {
                val file = File(dir, name)
                val ok = FileOutputStream(file).use { shot.compress(Bitmap.CompressFormat.PNG, 100, it) }
                if (ok) {
                    android.media.MediaScannerConnection.scanFile(ctx, arrayOf(file.absolutePath), arrayOf("image/png"), null)
                    return "VncViewer/screenshots"
                }
                file.delete()
                return null
            }
        }
        // No access yet: ask for it, and keep this one in the gallery meanwhile.
        main.post { StorageAccess.request(ctx) }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val v = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/VncViewer/screenshots")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v) ?: return null
            val ok = try {
                ctx.contentResolver.openOutputStream(uri)?.use { shot.compress(Bitmap.CompressFormat.PNG, 100, it) } == true
            } catch (e: Exception) {
                Log.w(TAG, "writing the screenshot", e)
                false
            }
            if (!ok) {
                ctx.contentResolver.delete(uri, null, null)
                return null
            }
            ctx.contentResolver.update(uri, ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }, null, null)
            return "Pictures/VncViewer/screenshots"
        }
        val base = ctx.getExternalFilesDir(android.os.Environment.DIRECTORY_PICTURES) ?: return null
        val dir = File(base, "VncViewer/screenshots")
        if (!dir.isDirectory && !dir.mkdirs()) return null
        val file = File(dir, name)
        val ok = FileOutputStream(file).use { shot.compress(Bitmap.CompressFormat.PNG, 100, it) }
        if (!ok) { file.delete(); return null }
        return dir.absolutePath
    }

    private fun write(ctx: Context, shot: Bitmap, name: String): File? {
        val dir = File(ctx.cacheDir, DIR)
        dir.listFiles()?.forEach { it.delete() }
        if (!dir.isDirectory && !dir.mkdirs()) return null
        val file = File(dir, name)
        return try {
            // PNG, not JPEG: a desktop is mostly text, which chroma subsampling ruins.
            val ok = FileOutputStream(file).use { shot.compress(Bitmap.CompressFormat.PNG, 100, it) }
            if (ok) file else { file.delete(); null }
        } catch (e: Exception) {
            Log.w(TAG, "writing the screenshot", e)
            file.delete()
            null
        }
    }

    private fun send(ctx: Context, file: File, name: String) {
        val uri = try {
            FileProvider.getUriForFile(ctx, ctx.packageName + ".files", file)
        } catch (e: IllegalArgumentException) {
            Log.w(TAG, "the screenshot is not under a shared path", e)
            Toast.makeText(ctx, "The desktop could not be captured.", Toast.LENGTH_SHORT).show()
            return
        }
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            clipData = ClipData.newUri(ctx.contentResolver, name, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(send, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(chooser)
    }

    /** The machine and when, safe in a file name. */
    private fun fileName(session: VncSession): String {
        val title = session.desktopName.ifEmpty { session.profile.host }
        val b = StringBuilder()
        for (c in title) {
            if (b.length >= 40) break
            if (c in 'a'..'z' || c in 'A'..'Z' || c in '0'..'9') {
                b.append(c)
            } else if (b.isNotEmpty() && b.last() != '-') {
                b.append('-')
            }
        }
        while (b.isNotEmpty() && b.last() == '-') b.setLength(b.length - 1)
        if (b.isEmpty()) b.append("desktop")
        val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
        return "$b-$stamp.png"
    }
}
