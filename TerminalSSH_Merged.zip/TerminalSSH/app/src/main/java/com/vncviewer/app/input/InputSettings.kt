// SPDX-License-Identifier: GPL-3.0-or-later
//
// Kotlin port of Vento's InputSettings.java (https://github.com/pgaskin/vento,
// (C) 2026 Patrick Gaskin): the input stack's tunables, as preferences.
package com.vncviewer.app.input

import android.content.Context
import android.content.SharedPreferences

/**
 * The part of [Config] a person can have an opinion about, plus the four wheel numbers.
 * The table is read twice - once to build the screen and once to build a [Config] - which
 * is what keeps a preference that does nothing from existing. A preference that has never
 * been touched is absent, and [defaults] answers for it.
 */
object InputSettings {
    const val FILE = "settings_input"

    enum class Kind { BOOL, NUMBER }

    class Tunable(
        val key: String,
        val label: String,
        val summary: String,
        val kind: Kind,
        /** Its value in a given config, as a preference string (the default shown when nothing is stored). */
        val read: (Config) -> String,
        /** Parse a stored string back into the config. */
        val write: (Config, String) -> Unit
    )

    private fun bool(
        key: String, label: String, summary: String,
        get: (Config) -> Boolean, set: (Config, Boolean) -> Unit
    ): Tunable = Tunable(key, label, summary, Kind.BOOL,
        { c -> get(c).toString() },
        { c, v -> set(c, v.toBoolean()) })

    private fun number(
        key: String, label: String, summary: String,
        get: (Config) -> Float, set: (Config, Float) -> Unit
    ): Tunable = Tunable(key, label, summary, Kind.NUMBER,
        { c -> trim(get(c)) },
        { c, v ->
            // A field left empty or full of nonsense keeps the default value.
            val f = v.trim().toFloatOrNull()
            if (f != null) set(c, f)
        })

    /** "3" rather than "3.0", since these end up in a text box someone edits. */
    fun trim(v: Float): String =
        if (v == Math.rint(v.toDouble()).toFloat()) v.toInt().toString() else v.toString()

    val TUNABLES: List<Tunable> = listOf(
        bool("accelEnabled", "Pointer acceleration",
            "Scale cursor movement by the speed of the gesture.",
            { c -> c.accelEnabled }, { c, v -> c.accelEnabled = v }),
        bool("accelAdaptive", "Adaptive acceleration",
            "Reduce acceleration at low speeds for better precision.",
            { c -> c.accelAdaptive }, { c, v -> c.accelAdaptive = v }),
        bool("axisLockEnabled", "Axis locking",
            "Snap slow straight movements to the horizontal or vertical axis.",
            { c -> c.axisLockEnabled }, { c, v -> c.axisLockEnabled = v }),
        bool("hoverAssistEnabled", "Hover assist",
            "Slow the pointer briefly when the remote cursor changes shape.",
            { c -> c.hoverAssistEnabled }, { c, v -> c.hoverAssistEnabled = v }),
        bool("inertiaEnabled", "Momentum",
            "Keep moving the cursor after a flick.",
            { c -> c.inertiaEnabled }, { c, v -> c.inertiaEnabled = v }),
        bool("rawMotionWhenRelative", "Raw motion for remote cursors",
            "Skip acceleration, axis locking, and momentum when the remote cursor is relative.",
            { c -> c.rawMotionWhenRelative }, { c, v -> c.rawMotionWhenRelative = v }),
        bool("bumpScrollEnabled", "Edge scrolling",
            "Pan the desktop while dragging against the edge of the screen.",
            { c -> c.bumpScrollEnabled }, { c, v -> c.bumpScrollEnabled = v }),
        bool("naturalScrolling", "Natural scrolling",
            "Invert the scroll direction of gestures and the mouse wheel.",
            { c -> c.naturalScrolling }, { c, v -> c.naturalScrolling = v }),
        bool("recentreCursorOnZoom", "Recenter cursor when zooming",
            "Move the cursor to the center of the view when the zoom changes.",
            { c -> c.recentreCursorOnZoom }, { c, v -> c.recentreCursorOnZoom = v }),
        bool("panMarginInsets", "Pan margin (display)",
            "Additional panning space so the edges stay away from the rounded corners, camera cutout, and system bars.",
            { c -> c.panMarginInsets }, { c, v -> c.panMarginInsets = v }),
        number("panMarginPx", "Pan margin (px)",
            "Additional panning space to add to desktop edges, whether or not anything is over them.",
            { c -> c.panMarginPx }, { c, v -> c.panMarginPx = v }),
        bool("keyboardInfoSolid", "Solid extension keyboard bar",
            "Inset the desktop above the extension keyboard bar instead of fading it over the desktop.",
            { c -> c.keyboardInfoSolid }, { c, v -> c.keyboardInfoSolid = v }),
        bool("keyboardHaptics", "Extension keyboard haptics",
            "Vibrate when pressing extension keyboard keys.",
            { c -> c.keyboardHaptics }, { c, v -> c.keyboardHaptics = v }),
        bool("mouseCapture", "Capture physical mouse",
            "Capture the pointer while connected to send relative motion instead of using the local cursor.",
            { c -> c.mouseCapture }, { c, v -> c.mouseCapture = v }),
        number("mouseSpeed", "Physical mouse speed",
            "Multiplier for captured mouse motion.",
            { c -> c.mouseSpeed }, { c, v -> c.mouseSpeed = v }),
        number("mouseWheelStep", "Physical mouse wheel step",
            "Wheel detents per scroll event sent. Increase for high-resolution wheels.",
            { c -> c.mouseWheelStep }, { c, v -> c.mouseWheelStep = v }),
        number("clickHoldMs", "Click hold (ms)",
            "Button hold time for taps, and the window for double-taps and tap-then-drag.",
            { c -> c.clickHoldMs.toFloat() }, { c, v -> c.clickHoldMs = v.toLong() }),
        number("wheelStepPx", "Two-finger scroll step (px)",
            "Finger travel per scroll event sent.",
            { c -> c.wheelStepPx }, { c, v -> c.wheelStepPx = v }),
        number("overlayWheelTicksPerClick", "Scroll bar gearing (ticks per click)",
            "Ticks between scroll events at rate 1, scaling down towards the ends of the bar.",
            { c -> c.overlayWheelTicksPerClick }, { c, v -> c.overlayWheelTicksPerClick = v }),
        number("overlayWheelMaxRate", "Scroll bar maximum rate (clicks per tick)",
            "Scroll rate at the ends of the bar, scaling to zero at the middle.",
            { c -> c.overlayWheelMaxRate }, { c, v -> c.overlayWheelMaxRate = v }),
        number("overlayWheelTickMs", "Scroll bar tick (ms)",
            "Interval the two settings above are counted in.",
            { c -> c.overlayWheelTickMs.toFloat() }, { c, v -> c.overlayWheelTickMs = v.toLong() }),
        number("overlayWheelStartDelayTicks", "Scroll bar repeat delay (ticks)",
            "Ticks before the first scroll event repeats, so a tap is a single scroll.",
            { c -> c.overlayWheelStartDelayTicks.toFloat() }, { c, v -> c.overlayWheelStartDelayTicks = v.toInt() })
    )

    fun prefs(ctx: Context): SharedPreferences =
        ctx.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    /** What the stack runs on before any override. */
    fun defaults(density: Float): Config = Config.improved(density)

    /** The defaults with the stored overrides applied: what a session runs on. */
    fun config(ctx: Context, density: Float): Config {
        val c = defaults(density)
        val p = prefs(ctx)
        for (t in TUNABLES) {
            val v = p.getString(t.key, null)
            if (v != null && v.isNotEmpty()) t.write(c, v)
        }
        return c
    }

    /** "Solid extension keyboard bar", read live (and subscribed to) for the session layout. */
    fun solidInfo(ctx: Context): Boolean {
        AppSettings.changeTick.intValue
        return prefs(ctx).getString("keyboardInfoSolid", null)?.toBoolean() ?: false
    }

    /** Forget every override, so the defaults answer for all of them again. */
    fun clearOverrides(ctx: Context) {
        val e = prefs(ctx).edit()
        for (t in TUNABLES) e.remove(t.key)
        e.apply()
        AppSettings.changeTick.intValue = AppSettings.changeTick.intValue + 1
    }
}
