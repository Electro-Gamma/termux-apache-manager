package com.vncviewer.app.ui

import android.app.Application
import android.content.ClipboardManager
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.KeyEvent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import com.vncviewer.app.data.ProfileStore
import com.vncviewer.app.data.Thumbnails
import com.vncviewer.app.session.Phase
import com.vncviewer.app.session.SessionStore
import com.vncviewer.app.data.Engine
import com.vncviewer.app.data.TargetParser
import com.vncviewer.app.input.AppSettings
import com.vncviewer.app.data.VncProfile
import com.vncviewer.app.session.VncSession
import java.util.UUID

enum class Screen { LIST, SESSION, SETTINGS }

class VncViewModel(application: Application) : AndroidViewModel(application), SessionStore.Listener {

    private val store = ProfileStore(application)

    val profiles = mutableStateListOf<VncProfile>()
    /** The process-wide sessions: they carry on when this screen goes away (see SessionService). */
    val sessions get() = SessionStore.sessions

    var screen by mutableStateOf(Screen.LIST)
    var activeSessionId by mutableStateOf<String?>(null)
    var fullscreen by mutableStateOf(false)

    /**
     * True while the VNC tab is the one on screen. This used to be implied (the VNC viewer was the
     * whole app); inside Terminal SSH the tab can be left with a session still open, and then the
     * keyboard, the clipboard and the session timeout must not behave as if it were being watched.
     */
    var hostVisible by mutableStateOf(false)

    // Connections screen state
    var quickText by mutableStateOf("")
    var quickEngine by mutableStateOf(Engine.BUILTIN)
    var listMessage by mutableStateOf<String?>(null)
    var editorProfile by mutableStateOf<VncProfile?>(null)
    var editorIsNew by mutableStateOf(false)
    var deleteCandidate by mutableStateOf<VncProfile?>(null)

    val activeSession: VncSession?
        get() = sessions.firstOrNull { it.id == activeSessionId }

    /** Where Settings returns to. */
    private var settingsReturn = Screen.LIST
    private var foreground = true
    private val hiddenSince = HashMap<String, Long>()
    private val handler = Handler(Looper.getMainLooper())
    private val ticker: Runnable = object : Runnable {
        override fun run() {
            checkTimeouts()
            handler.postDelayed(this, 15_000)
        }
    }
    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener {
        if (screen == Screen.SESSION && foreground && hostVisible) activeSession?.autoSendClipboard()
    }

    init {
        // Sessions may already be open (the screen was closed and reopened): pick them up.
        SessionStore.listener = this
        SessionStore.screenShown()
        for (s in sessions) s.onDisconnectRequest = { closeSession(s.id) }
        activeSessionId = sessions.lastOrNull { it.phase != Phase.FAILED }?.id ?: sessions.lastOrNull()?.id
        profiles.addAll(sorted(store.load()))
        handler.postDelayed(ticker, 15_000)
        try {
            val cm = application.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.addPrimaryClipChangedListener(clipListener)
        } catch (_: Exception) {
        }
    }

    // ---- settings -----------------------------------------------------------------------

    fun openSettings() {
        settingsReturn = if (screen == Screen.SETTINGS) settingsReturn else screen
        screen = Screen.SETTINGS
    }

    fun closeSettings() {
        screen = if (settingsReturn == Screen.SESSION && activeSession != null) Screen.SESSION else Screen.LIST
    }

    /**
     * "Session timeout": a session nothing has been looking at for that long is disconnected.
     * Looked at means: on screen, with the app in front.
     */
    fun checkTimeouts() {
        val now = SystemClock.elapsedRealtime()
        val minutes = AppSettings.sessionTimeout(getApplication<Application>())
        val expired = ArrayList<VncSession>()
        for (s in sessions) {
            val visible = foreground && hostVisible && screen == Screen.SESSION && s.id == activeSessionId
            if (visible) {
                hiddenSince.remove(s.id)
                continue
            }
            val since = hiddenSince.getOrPut(s.id) { now }
            if (minutes > 0 && now - since >= minutes * 60_000L) expired.add(s)
        }
        for (s in expired) {
            hiddenSince.remove(s.id)
            closeSession(s.id)
            listMessage = "Closed after " + AppSettings.timeoutLabel(minutes) + " timeout"
        }
    }

    // ---- saved profiles ----------------------------------------------------------------

    /**
     * Pinned first, and otherwise the order they were saved in (or dragged into): a stable sort,
     * so a new connection lands at the end of its group and pinning one puts it after the pins.
     */
    private fun sorted(list: List<VncProfile>): List<VncProfile> {
        return list.filter { it.favorite } + list.filter { !it.favorite }
    }

    private fun persist() {
        store.save(profiles.toList())
    }

    fun isSaved(id: String): Boolean = profiles.any { it.id == id }

    fun saveProfile(profile: VncProfile) {
        val i = profiles.indexOfFirst { it.id == profile.id }
        if (i >= 0) profiles[i] = profile else profiles.add(profile)
        val ordered = sorted(profiles.toList())
        profiles.clear()
        profiles.addAll(ordered)
        persist()
    }

    fun deleteProfile(profile: VncProfile) {
        profiles.removeAll { it.id == profile.id }
        Thumbnails.delete(getApplication<Application>(), profile.id)
        persist()
    }

    /** Put the pinned connections in this order, leaving every other one where it is. */
    fun reorderPinned(idsInOrder: List<String>) {
        val byId = profiles.associateBy { it.id }
        val pinned = idsInOrder.mapNotNull { byId[it] }.filter { it.favorite }
        if (pinned.size != profiles.count { it.favorite }) return
        val ordered = pinned + profiles.filter { !it.favorite }
        profiles.clear()
        profiles.addAll(ordered)
        persist()
    }

    /** The session open on this saved connection, if there is one. */
    fun liveSession(profileId: String): VncSession? =
        sessions.firstOrNull { it.profile.id == profileId }

    /**
     * A card was pressed: go back to the session already open on it, or start one. A session that
     * has dropped is replaced rather than returned to.
     */
    fun openProfile(profile: VncProfile) {
        val live = liveSession(profile.id)
        if (live != null) {
            if (live.phase != Phase.FAILED) {
                selectSession(live.id)
                return
            }
            closeSession(live.id)
        }
        connect(profile)
    }

    /** Keep the desktop's last screenful as the picture on its home card. */
    fun captureThumbnail(session: VncSession) {
        if (!isSaved(session.profile.id) || session.phase != Phase.CONNECTED) return
        Thumbnails.save(getApplication<Application>(), session.profile.id, Thumbnails.snapshot(session.bitmap))
    }

    fun toggleFavorite(profile: VncProfile) {
        saveProfile(profile.copy(favorite = !profile.favorite))
    }

    fun startNewProfile() {
        editorIsNew = true
        editorProfile = VncProfile(id = UUID.randomUUID().toString(), name = "", host = "")
    }

    fun startEditProfile(profile: VncProfile) {
        editorIsNew = false
        editorProfile = profile
    }

    // ---- connecting ---------------------------------------------------------------------

    fun connect(profile: VncProfile) {
        var p = profile
        if (isSaved(profile.id)) {
            p = profile.copy(lastUsed = System.currentTimeMillis())
            saveProfile(p)
        }
        val session = VncSession(getApplication<Application>(), UUID.randomUUID().toString(), p)
        session.onDisconnectRequest = { closeSession(session.id) }
        SessionStore.add(getApplication<Application>(), session)
        activeSessionId = session.id
        screen = Screen.SESSION
        session.connect(p.password)
    }

    fun quickConnect() {
        val target = TargetParser.parse(quickText)
        if (target == null) {
            listMessage = "Enter a server such as 192.168.1.10:1 or myhost:5901"
            return
        }
        listMessage = null
        connect(
            VncProfile(
                id = "quick-" + UUID.randomUUID().toString(),
                name = target.host,
                host = target.host,
                port = target.port,
                engine = quickEngine
            )
        )
    }

    fun submitPassword(session: VncSession, password: String, remember: Boolean) {
        if (remember && isSaved(session.profile.id)) {
            val updated = session.profile.copy(password = password)
            saveProfile(updated)
            session.profile = updated
        }
        session.submitPassword(password)
    }

    /** The RealVNC engine's sign-in prompt was answered with "remember". */
    fun rememberCredentials(session: VncSession, userName: String, password: String) {
        if (!isSaved(session.profile.id)) return
        val updated = session.profile.copy(
            password = password,
            userName = if (userName.isNotEmpty()) userName else session.profile.userName
        )
        saveProfile(updated)
        session.profile = updated
    }

    fun saveSessionAsProfile(session: VncSession) {
        if (isSaved(session.profile.id)) return
        val saved = session.profile.copy(id = UUID.randomUUID().toString())
        saveProfile(saved)
        session.profile = saved
        session.showNotice("Saved to your connections")
    }

    // ---- sessions -----------------------------------------------------------------------

    fun selectSession(id: String) {
        activeSessionId = id
        screen = Screen.SESSION
    }

    fun closeSession(id: String) {
        val s = sessions.firstOrNull { it.id == id } ?: return
        captureThumbnail(s)
        SessionStore.close(id)
    }

    /** A session went away (closed here, or from the notification's "Disconnect all"). */
    override fun sessionRemoved(id: String) {
        hiddenSince.remove(id)
        if (activeSessionId == id) {
            activeSessionId = sessions.lastOrNull()?.id
        }
        if (sessions.isEmpty()) {
            screen = Screen.LIST
            fullscreen = false
        }
    }

    /** Called from MainActivity.dispatchKeyEvent. Returns true if the key went to the remote. */
    fun handleKeyEvent(event: KeyEvent): Boolean {
        if (!hostVisible || screen != Screen.SESSION) return false
        val s = activeSession ?: return false
        return s.onKeyEvent(event)
    }

    fun onAppStopped() {
        foreground = false
        if (screen == Screen.SESSION) activeSession?.let { captureThumbnail(it) }
        val release = AppSettings.releaseKeys(getApplication<Application>())
        for (s in sessions) {
            s.input.suspendInput()
            if (release) s.releaseAllKeys()
            s.setFocused(false)
        }
        checkTimeouts()
    }

    fun onAppStarted() {
        foreground = true
        for (s in sessions) s.setFocused(hostVisible)
        checkTimeouts()
    }

    /** The VNC tab came to the front. */
    fun onTabShown() {
        hostVisible = true
        if (foreground) for (s in sessions) s.setFocused(true)
        checkTimeouts()
    }

    /** The VNC tab was left (another tab, or the app went away). Sessions stay connected. */
    fun onTabHidden() {
        hostVisible = false
        if (screen == Screen.SESSION) activeSession?.let { captureThumbnail(it) }
        val release = AppSettings.releaseKeys(getApplication<Application>())
        for (s in sessions) {
            s.input.suspendInput()
            if (release) s.releaseAllKeys()
            s.setFocused(false)
        }
        checkTimeouts()
    }

    override fun onCleared() {
        handler.removeCallbacks(ticker)
        try {
            val cm = getApplication<Application>().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.removePrimaryClipChangedListener(clipListener)
        } catch (_: Exception) {
        }
        // The sessions are not closed: they belong to the process, and keep running in the
        // background until they are disconnected (or SessionService is told to disconnect them all).
        if (SessionStore.listener === this) SessionStore.listener = null
        for (s in sessions) s.onDisconnectRequest = { SessionStore.close(s.id) }
        super.onCleared()
    }
}
