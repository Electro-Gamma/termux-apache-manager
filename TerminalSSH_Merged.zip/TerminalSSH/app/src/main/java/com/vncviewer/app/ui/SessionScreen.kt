package com.vncviewer.app.ui

import android.content.Context
import android.view.HapticFeedbackConstants
import android.view.inputmethod.InputMethodManager
import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.PointerInputScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.vncviewer.app.input.AppSettings
import com.vncviewer.app.input.InputSettings
import com.vncviewer.app.session.MouseMode
import com.vncviewer.app.session.Phase
import com.vncviewer.app.session.VncSession
import com.vncviewer.app.vnc.CredentialsPrompt
import com.vncviewer.app.vnc.Keysyms
import com.vncviewer.app.vnc.MessagePrompt
import com.vncviewer.app.vnc.MessageSeverity
import com.vncviewer.app.vnc.RemotePrompt
import com.vncviewer.app.vnc.TrustEncryption
import com.vncviewer.app.vnc.TrustIdentity
import com.vncviewer.app.vnc.TrustPrompt
import kotlinx.coroutines.delay

@Composable
fun SessionScreen(vm: VncViewModel) {
    val session = vm.activeSession
    if (session == null) {
        LaunchedEffect(Unit) { vm.screen = Screen.LIST }
        return
    }
    val fullscreen = vm.fullscreen
    val connected = session.phase == Phase.CONNECTED
    val ctx = LocalContext.current

    // Preferences changed in Settings reach a session that is already running.
    LaunchedEffect(AppSettings.changeTick.intValue) {
        session.input.applySettings()
    }
    // The first frame explains the session controls (and offers the choice), unless told not to.
    LaunchedEffect(session.firstFrame) {
        if (session.firstFrame && !session.hintsHandled) {
            session.hintsHandled = true
            if (AppSettings.regionHints(ctx)) session.showHints = true
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        if (!fullscreen) {
            SessionTabs(vm)
            ToolbarBar(session)
        }
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            key(session.id) {
                RemoteCanvas(session)
                KeyCaptureHost(session)
            }

            when (session.phase) {
                Phase.CONNECTING -> ConnectingOverlay(vm, session)
                Phase.FAILED -> FailedOverlay(vm, session)
                Phase.AUTH_REQUIRED -> PasswordDialog(vm, session)
                Phase.CONNECTED -> {}
            }

            val banner = session.banner
            if (banner != null) {
                Surface(
                    color = app.terminalssh.secure.ui.theme.Amber.copy(alpha = 0.9f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(12.dp)
                ) {
                    Text(
                        text = banner,
                        color = app.terminalssh.secure.ui.theme.Ink,
                        style = MaterialTheme.typography.labelLarge,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                    )
                }
            }

            if (session.showHints) {
                ControlsDialog(session)
            }

            val prompt = session.prompts.firstOrNull()
            if (prompt != null) {
                PromptDialog(vm, session, prompt)
            }
            if (session.infoOpen) {
                ConnectionSheet(session)
            }
            if (session.recordChoiceOpen) {
                RecordChoiceDialog(session)
            }

            if (fullscreen) {
                FullscreenControls(vm, session, Modifier.align(Alignment.TopEnd))
            }

            val notice = session.notice
            if (notice != null) {
                LaunchedEffect(notice) {
                    delay(2400)
                    if (session.notice == notice) session.notice = null
                }
                Surface(
                    color = app.terminalssh.secure.ui.theme.Surface2.copy(alpha = 0.9f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(16.dp)
                ) {
                    Text(
                        text = notice,
                        color = Color.White,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Chips / small building blocks
// ---------------------------------------------------------------------------------------------

@Composable
fun ToolChip(label: String, selected: Boolean = false, compact: Boolean = false, onClick: () -> Unit) {
    Surface(
        color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
        contentColor = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            maxLines = 1,
            modifier = Modifier.padding(
                horizontal = if (compact) 10.dp else 12.dp,
                vertical = if (compact) 6.dp else 8.dp
            )
        )
    }
}

@Composable
private fun SessionTabs(vm: VncViewModel) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .horizontalScroll(rememberScrollState())
            .padding(6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ToolChip("\u2039 Connections") { vm.screen = Screen.LIST }
        for (s in vm.sessions) {
            val selected = s.id == vm.activeSessionId
            Surface(
                color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.clickable { vm.activeSessionId = s.id }
            ) {
                Row(
                    modifier = Modifier.padding(start = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val dot = when (s.phase) {
                        Phase.CONNECTED -> app.terminalssh.secure.ui.theme.Turquoise
                        Phase.CONNECTING -> app.terminalssh.secure.ui.theme.Cyan
                        else -> app.terminalssh.secure.ui.theme.Danger
                    }
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(dot, RoundedCornerShape(4.dp))
                    )
                    Text(
                        text = (if (s.isRealVnc) "RV \u00B7 " else "") + s.title,
                        style = MaterialTheme.typography.labelLarge,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(start = 8.dp)
                    )
                    Text(
                        text = "\u00D7",
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier
                            .clickable { vm.closeSession(s.id) }
                            .padding(horizontal = 12.dp, vertical = 4.dp)
                    )
                }
            }
        }
    }
}

/**
 * What Record asks first: with the microphone or without it. The microphone permission is asked
 * for here, and only if "With microphone" is the answer; recording without it needs none.
 */
@Composable
private fun RecordChoiceDialog(session: VncSession) {
    val context = LocalContext.current
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            session.startRecording(true)
        } else {
            session.recordChoiceOpen = false
            session.showNotice("Microphone permission was not granted")
        }
    }
    AlertDialog(
        containerColor = androidx.compose.material3.MaterialTheme.colorScheme.surface,
        onDismissRequest = { session.recordChoiceOpen = false },
        title = { Text("Record the desktop") },
        text = { Text("Record the desktop video with sound from your microphone, or without any sound?") },
        confirmButton = {
            TextButton(onClick = {
                val have = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                    PackageManager.PERMISSION_GRANTED
                if (have) session.startRecording(true) else permission.launch(Manifest.permission.RECORD_AUDIO)
            }) { Text("With microphone") }
        },
        dismissButton = {
            Row {
                TextButton(onClick = { session.recordChoiceOpen = false }) { Text("Cancel") }
                TextButton(onClick = { session.startRecording(false) }) { Text("Without microphone") }
            }
        }
    )
}

/**
 * The session's control bar, where the header bar used to be: six icon buttons (Mouse, Keyboard,
 * Keys, Clipboard, Info, Exit). It is the input stack's own [com.vncviewer.app.input.Toolbar]
 * (model, hit-testing, press/active state) drawn by [ChromeDraw]; only the host moved, from a
 * column over the picture to a row above it.
 */
@Composable
private fun ToolbarBar(session: VncSession) {
    val density = LocalContext.current.resources.displayMetrics.density
    val chrome = remember { ChromeDraw(density) }
    val toolbar = session.input.toolbar
    // Reading the tick keeps the bar in step with its model (press, active states, item list).
    if (session.inputTick < 0 || !toolbar.visible()) return
    val height = with(LocalDensity.current) { session.input.cfg.toolbarButtonPx.toDp() }
    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(height)
            .onSizeChanged { toolbar.setViewSize(it.width, it.height) }
            .pointerInput(session) { toolbarTouches(session) }
    ) {
        val tick = session.inputTick
        if (tick >= 0) {
            drawIntoCanvas { canvas -> chrome.drawToolbar(canvas.nativeCanvas, toolbar) }
        }
    }
}

/** One finger at a time on the bar, through the toolbar's own claim methods. */
private suspend fun PointerInputScope.toolbarTouches(session: VncSession) {
    val toolbar = session.input.toolbar
    awaitEachGesture {
        val down = awaitFirstDown(requireUnconsumed = false)
        if (!toolbar.claimTouch(0, down.position.x, down.position.y, down.uptimeMillis)) return@awaitEachGesture
        down.consume()
        var ended = false
        try {
            while (true) {
                val ev = awaitPointerEvent()
                val c = ev.changes.firstOrNull { it.id == down.id } ?: break
                if (!c.pressed) {
                    ended = true
                    toolbar.claimEnded(0, c.position.x, c.position.y, c.uptimeMillis)
                    c.consume()
                    break
                }
                if (c.position != c.previousPosition) {
                    toolbar.claimMoved(0, c.position.x, c.position.y, c.uptimeMillis)
                }
                c.consume()
            }
        } finally {
            if (!ended) toolbar.claimCancelled(android.os.SystemClock.uptimeMillis())
        }
    }
}

@Composable
private fun FullscreenControls(vm: VncViewModel, session: VncSession, modifier: Modifier) {
    var expanded by remember { mutableStateOf(false) }
    Row(
        modifier = modifier.padding(8.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (expanded) {
            val view = LocalView.current
            ToolChip("Keyboard", compact = true) {
                val visible = ViewCompat.getRootWindowInsets(view)
                    ?.isVisible(WindowInsetsCompat.Type.ime()) == true
                session.requestIme(!visible)
            }
            ToolChip("Keys", session.inputTick >= 0 && session.input.keyboard.visible(), compact = true) {
                session.input.toggleKeys()
            }
            ToolChip("Exit fullscreen", compact = true) { vm.fullscreen = false }
        }
        Surface(
            color = app.terminalssh.secure.ui.theme.Surface2.copy(alpha = 0.6f),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.clickable { expanded = !expanded }
        ) {
            Text(
                text = if (expanded) "Hide" else "Menu",
                color = Color.White,
                style = MaterialTheme.typography.labelMedium,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
            )
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Overlays and dialogs
// ---------------------------------------------------------------------------------------------

@Composable
private fun ConnectingOverlay(vm: VncViewModel, session: VncSession) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xCC000000)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.padding(24.dp)
        ) {
            CircularProgressIndicator()
            Text(session.title, style = MaterialTheme.typography.titleMedium, color = Color.White)
            Text(session.status, style = MaterialTheme.typography.bodyMedium, color = Color(0xFF9AA4AC))
            TextButton(onClick = { vm.closeSession(session.id) }) { Text("Cancel") }
        }
    }
}

@Composable
private fun FailedOverlay(vm: VncViewModel, session: VncSession) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xCC000000)),
        contentAlignment = Alignment.Center
    ) {
        Card(modifier = Modifier.padding(24.dp)) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Disconnected", style = MaterialTheme.typography.titleMedium)
                Text(
                    session.error ?: "The connection ended.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = { session.reconnect() }) { Text("Reconnect") }
                    TextButton(onClick = { vm.closeSession(session.id) }) { Text("Close") }
                }
            }
        }
    }
}

@Composable
private fun PasswordDialog(vm: VncViewModel, session: VncSession) {
    var password by remember { mutableStateOf("") }
    var save by remember { mutableStateOf(true) }
    AlertDialog(
        containerColor = androidx.compose.material3.MaterialTheme.colorScheme.surface,
        onDismissRequest = { vm.closeSession(session.id) },
        title = { Text("VNC password") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = if (session.passwordRejected) {
                        "That password was rejected. Try again."
                    } else {
                        session.title + " requires a password."
                    },
                    color = if (session.passwordRejected) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                )
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    singleLine = true,
                    label = { Text("Password") },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                )
                if (vm.isSaved(session.profile.id)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = save, onCheckedChange = { save = it })
                        Text("Remember password")
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { vm.submitPassword(session, password, save) }) { Text("Connect") }
        },
        dismissButton = {
            TextButton(onClick = { vm.closeSession(session.id) }) { Text("Cancel") }
        }
    )
}

// ---------------------------------------------------------------------------------------------
// Soft keyboard host
// ---------------------------------------------------------------------------------------------

@Composable
private fun KeyCaptureHost(session: VncSession) {
    val context = LocalContext.current
    val holder = remember { arrayOfNulls<KeyCaptureView>(1) }

    AndroidView(
        factory = { ctx ->
            val v = KeyCaptureView(ctx)
            holder[0] = v
            v
        },
        update = { v ->
            v.textSink = { text -> session.imeText(text) }
            v.keySink = { event -> session.onKeyEvent(event) }
            v.capturedSink = { ev -> session.input.mouse.onCapturedPointerEvent(ev) }
            v.privateIme = AppSettings.privateIme(context)
            val capture = session.phase == Phase.CONNECTED && session.input.cfg.mouseCapture
            if (capture) v.requestFocus()
            v.wantCapture = capture
        },
        modifier = Modifier.size(1.dp)
    )

    LaunchedEffect(session.imeRestartTick) {
        if (session.imeRestartTick == 0) return@LaunchedEffect
        val v = holder[0] ?: return@LaunchedEffect
        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        if (imm.isActive(v)) imm.restartInput(v)
    }

    LaunchedEffect(session.imeCommandTick) {
        if (session.imeCommandTick == 0) return@LaunchedEffect
        delay(60)
        val v = holder[0] ?: return@LaunchedEffect
        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        if (session.imeCommandShow) {
            v.requestFocus()
            imm.restartInput(v)
            imm.showSoftInput(v, InputMethodManager.SHOW_IMPLICIT)
        } else {
            imm.hideSoftInputFromWindow(v.windowToken, 0)
        }
    }
}


// ---------------------------------------------------------------------------------------------
// RealVNC engine prompts and connection info
// ---------------------------------------------------------------------------------------------

@Composable
private fun PromptDialog(vm: VncViewModel, session: VncSession, prompt: RemotePrompt) {
    when (prompt) {
        is CredentialsPrompt -> CredentialsDialog(vm, session, prompt)
        is TrustPrompt -> TrustDialog(session, prompt)
        is MessagePrompt -> MessageDialog(session, prompt)
    }
}

@Composable
private fun CredentialsDialog(vm: VncViewModel, session: VncSession, p: CredentialsPrompt) {
    var user by remember(p) { mutableStateOf(p.userName.ifEmpty { session.profile.userName }) }
    var pass by remember(p) { mutableStateOf("") }
    var save by remember(p) { mutableStateOf(true) }
    AlertDialog(
        containerColor = androidx.compose.material3.MaterialTheme.colorScheme.surface,
        onDismissRequest = {
            p.cancel()
            session.dismissPrompt(p)
        },
        title = { Text("Sign in") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (p.serverName.isNotEmpty()) Text(p.serverName, style = MaterialTheme.typography.titleSmall)
                if (p.instructions.isNotEmpty()) Text(p.instructions, style = MaterialTheme.typography.bodyMedium)
                if (p.askUserName) {
                    OutlinedTextField(
                        value = user,
                        onValueChange = { user = it },
                        singleLine = true,
                        label = { Text("User name") }
                    )
                }
                if (p.askPassword) {
                    OutlinedTextField(
                        value = pass,
                        onValueChange = { pass = it },
                        singleLine = true,
                        label = { Text("Password") },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                    )
                }
                if (p.catchphrase.isNotEmpty()) {
                    Text(
                        "Catchphrase: " + p.catchphrase,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (vm.isSaved(session.profile.id)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = save, onCheckedChange = { save = it })
                        Text("Remember")
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (save) vm.rememberCredentials(session, user, pass)
                p.answer(true, if (p.askUserName) user else null, if (p.askPassword) pass else null)
                session.dismissPrompt(p)
            }) { Text("Sign in") }
        },
        dismissButton = {
            TextButton(onClick = {
                p.cancel()
                session.dismissPrompt(p)
            }) { Text("Cancel") }
        }
    )
}

@Composable
private fun TrustDialog(session: VncSession, p: TrustPrompt) {
    var rememberServer by remember(p) { mutableStateOf(p.identity == TrustIdentity.NEW) }
    val identityText = when (p.identity) {
        TrustIdentity.OK -> "This server's identity matches one you accepted before."
        TrustIdentity.NEW ->
            "You have not connected to this server before. Check that the catchphrase below matches the one the server shows."
        TrustIdentity.MATCHES_ANOTHER -> "This identity is already known as \"" + p.matchingName + "\"."
        TrustIdentity.CHANGED ->
            "WARNING: this server's identity has CHANGED since you last connected. Someone may be impersonating it. Only continue if you expected this."
        TrustIdentity.MISSING -> "The server did not provide an identity, so it cannot be verified."
        TrustIdentity.PRESHARED -> "Authenticated with a pre-shared key."
        TrustIdentity.ARD -> "Apple Remote Desktop authentication."
    }
    val encryptionText = when (p.encryption) {
        TrustEncryption.ENCRYPTED -> "The connection is encrypted."
        TrustEncryption.UNENCRYPTED_WARN ->
            "WARNING: the connection is NOT encrypted. Anyone on the network could read your screen and password."
        TrustEncryption.UNENCRYPTED_QUIET -> "The connection is not encrypted."
    }
    val danger = p.identity == TrustIdentity.CHANGED || p.encryption == TrustEncryption.UNENCRYPTED_WARN
    AlertDialog(
        containerColor = androidx.compose.material3.MaterialTheme.colorScheme.surface,
        onDismissRequest = {
            p.cancel()
            session.dismissPrompt(p)
        },
        title = { Text("Verify server") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (p.serverName.isNotEmpty()) Text(p.serverName, style = MaterialTheme.typography.titleSmall)
                Text(
                    identityText,
                    color = if (p.identity == TrustIdentity.CHANGED) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                )
                Text(
                    encryptionText,
                    color = if (p.encryption == TrustEncryption.UNENCRYPTED_WARN) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                )
                if (p.catchphrase.isNotEmpty()) Text("Catchphrase: " + p.catchphrase, style = MaterialTheme.typography.bodyMedium)
                if (p.signature.isNotEmpty()) {
                    Text(
                        "Signature: " + p.signature,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = rememberServer, onCheckedChange = { rememberServer = it })
                    Text("Remember this server")
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                p.answer(true, rememberServer)
                session.dismissPrompt(p)
            }) { Text(if (danger) "Continue anyway" else "Continue") }
        },
        dismissButton = {
            TextButton(onClick = {
                p.cancel()
                session.dismissPrompt(p)
            }) { Text("Cancel") }
        }
    )
}

@Composable
private fun MessageDialog(session: VncSession, p: MessagePrompt) {
    val title = when (p.severity) {
        MessageSeverity.ERROR -> "Error"
        MessageSeverity.WARNING -> "Warning"
        MessageSeverity.QUESTION -> "Question"
        MessageSeverity.INFORMATION -> "Message"
    }
    val positive = p.customButton ?: if (p.yesNo) "Yes" else "OK"
    AlertDialog(
        containerColor = androidx.compose.material3.MaterialTheme.colorScheme.surface,
        onDismissRequest = {
            p.cancel()
            session.dismissPrompt(p)
        },
        title = { Text(title) },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                if (p.serverName.isNotEmpty()) {
                    Text(p.serverName, style = MaterialTheme.typography.titleSmall)
                }
                Text(p.message)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                p.answer(true)
                session.dismissPrompt(p)
            }) { Text(positive) }
        },
        dismissButton = {
            if (p.isQuestion) {
                TextButton(onClick = {
                    p.answer(false)
                    session.dismissPrompt(p)
                }) { Text(if (p.yesNo) "No" else "Cancel") }
            }
        }
    )
}

/** The first-frame "Controls" explanation: pick toolbar, tap regions or both. */
@Composable
private fun ControlsDialog(session: VncSession) {
    val ctx = LocalContext.current
    var doNotAsk by remember { mutableStateOf(false) }
    val current = AppSettings.controls(ctx)
    AlertDialog(
        containerColor = androidx.compose.material3.MaterialTheme.colorScheme.surface,
        onDismissRequest = {
            session.showHints = false
            if (doNotAsk) AppSettings.setBool(ctx, AppSettings.KEY_REGION_HINTS, false)
        },
        title = { Text("Controls") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Choose how to reach disconnect, connection info, the keyboard and the mouse. The rest of the screen controls the desktop.")
                for (v in listOf(AppSettings.CONTROLS_TOOLBAR, AppSettings.CONTROLS_REGIONS, AppSettings.CONTROLS_BOTH)) {
                    ToolChip(AppSettings.controlsLabel(v), current == v) {
                        AppSettings.setText(ctx, AppSettings.KEY_CONTROLS, v)
                        session.input.applyControls()
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = doNotAsk, onCheckedChange = { doNotAsk = it })
                    Text("Do not ask again")
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                session.showHints = false
                if (doNotAsk) AppSettings.setBool(ctx, AppSettings.KEY_REGION_HINTS, false)
            }) { Text("OK") }
        }
    )
}
