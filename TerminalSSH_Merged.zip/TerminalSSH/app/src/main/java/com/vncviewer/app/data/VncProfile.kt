package com.vncviewer.app.data

/** Which VNC implementation runs a connection. */
enum class Engine(val label: String) {
    /** The app's own RFB client: no native code, no encryption. */
    BUILTIN("Built-in"),

    /** RealVNC's viewer core (native library supplied separately): encryption, UDP, ZRLE2. */
    REALVNC("RealVNC")
}

/** A saved VNC connection. [password] is empty when the user chose not to save it. */
data class VncProfile(
    val id: String,
    val name: String,
    val host: String,
    val port: Int = 5900,
    val password: String = "",
    val viewOnly: Boolean = false,
    val favorite: Boolean = false,
    val lastUsed: Long = 0L,
    val engine: Engine = Engine.BUILTIN,
    /** RealVNC engine: user name for servers that use user + password sign-in. */
    val userName: String = "",
    /** RealVNC engine: Auto, High, Medium or Low. */
    val quality: String = "Auto"
) {
    val address: String
        get() = if (host.contains(':')) "[$host]:$port" else "$host:$port"

    /** The address string handed to the RealVNC core ("host:port", or "host::port" for ports below 100). */
    val realVncAddress: String
        get() {
            val h = if (host.contains(':')) "[$host]" else host
            return if (port >= 100) "$h:$port" else "$h::$port"
        }
}
