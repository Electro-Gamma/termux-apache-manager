package com.vncviewer.app.data

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * Export / import of saved VNC connections as a small JSON file, the way the Hosts tab exports
 * its server list. Passwords are never written (the same as the SSH config export); everything
 * else about a connection is.
 */
object ProfileTransfer {
    private const val FORMAT = "terminalssh-vnc-connections"

    fun toJson(profiles: List<VncProfile>): String {
        val array = JSONArray()
        for (p in profiles) {
            array.put(
                JSONObject()
                    .put("name", p.name)
                    .put("host", p.host)
                    .put("port", p.port)
                    .put("viewOnly", p.viewOnly)
                    .put("favorite", p.favorite)
                    .put("engine", if (p.engine == Engine.REALVNC) "realvnc" else "builtin")
                    .put("user", p.userName)
                    .put("quality", p.quality)
            )
        }
        return JSONObject().put("format", FORMAT).put("version", 1).put("connections", array).toString(2)
    }

    /** The connections in [raw] (new ids, no password), or null if it is not a connections file. */
    fun fromJson(raw: String): List<VncProfile>? {
        return try {
            val trimmed = raw.trim()
            val array = if (trimmed.startsWith("[")) JSONArray(trimmed)
            else JSONObject(trimmed).getJSONArray("connections")
            val result = ArrayList<VncProfile>()
            for (i in 0 until array.length()) {
                val o = array.getJSONObject(i)
                val host = o.optString("host", "").trim()
                if (host.isEmpty()) continue
                result.add(
                    VncProfile(
                        id = UUID.randomUUID().toString(),
                        name = o.optString("name", "").ifEmpty { host },
                        host = host,
                        port = o.optInt("port", 5900),
                        viewOnly = o.optBoolean("viewOnly", false),
                        favorite = o.optBoolean("favorite", false),
                        engine = if (o.optString("engine", "") == "realvnc") Engine.REALVNC else Engine.BUILTIN,
                        userName = o.optString("user", ""),
                        quality = o.optString("quality", "Auto")
                    )
                )
            }
            result
        } catch (e: Exception) {
            null
        }
    }
}
