// SPDX-License-Identifier: MIT
//
// Kotlin port of Vento's TouchRouter.java (https://github.com/pgaskin/vento, control/ module,
// (C) 2026 Patrick Gaskin, MIT), driven by explicit begin/move/end calls instead of MotionEvents.
package com.vncviewer.app.input

/** Offers every new touch to the on-screen controls first; whatever they decline goes to the gestures. */
class TouchRouter(private val listener: TouchListener) {

    interface Claim {
        fun claimTouch(id: Int, x: Float, y: Float, t: Long): Boolean
        fun claimMoved(id: Int, x: Float, y: Float, t: Long)
        fun claimEnded(id: Int, x: Float, y: Float, t: Long)
        fun claimCancelled(t: Long)
    }

    private val claims = ArrayList<Claim>(2)
    private val owner = arrayOfNulls<Claim>(64)
    private val lastId = IntArray(MAX_POINTERS)
    private val lastX = FloatArray(MAX_POINTERS)
    private val lastY = FloatArray(MAX_POINTERS)
    private var lastCount = 0

    fun addClaim(c: Claim) {
        claims.add(c)
    }

    private fun trackable(id: Int): Boolean = id >= 0 && id < 64

    fun down(id: Int, x: Float, y: Float, t: Long) {
        if (trackable(id)) {
            for (c in claims) {
                if (c.claimTouch(id, x, y, t)) {
                    owner[id] = c
                    return
                }
            }
        }
        remember(id, x, y)
        listener.touchBegan(id, x, y, t)
    }

    /** Offer a touch to the on-screen controls only (direct-touch mode has its own gestures). */
    fun claimDown(id: Int, x: Float, y: Float, t: Long): Boolean {
        if (!trackable(id)) return false
        for (c in claims) {
            if (c.claimTouch(id, x, y, t)) {
                owner[id] = c
                return true
            }
        }
        return false
    }

    fun move(id: Int, x: Float, y: Float, t: Long) {
        if (trackable(id)) {
            val o = owner[id]
            if (o != null) {
                o.claimMoved(id, x, y, t)
                return
            }
        }
        val k = indexOf(id)
        if (k < 0) return
        val px = lastX[k]
        val py = lastY[k]
        lastX[k] = x
        lastY[k] = y
        listener.touchMoved(id, px, py, x, y, t)
    }

    fun up(id: Int, x: Float, y: Float, t: Long) {
        if (trackable(id)) {
            val o = owner[id]
            if (o != null) {
                owner[id] = null
                o.claimEnded(id, x, y, t)
                return
            }
        }
        val k = indexOf(id)
        val px = if (k >= 0) lastX[k] else x
        val py = if (k >= 0) lastY[k] else y
        forget(id)
        listener.touchEnded(id, px, py, x, y, t)
    }

    fun cancel(time: Long) {
        lastCount = 0
        java.util.Arrays.fill(owner, null)
        for (c in claims) c.claimCancelled(time)
        listener.touchCancelled(time)
    }

    private fun indexOf(id: Int): Int {
        for (i in 0 until lastCount) if (lastId[i] == id) return i
        return -1
    }

    private fun remember(id: Int, x: Float, y: Float) {
        var k = indexOf(id)
        if (k < 0) {
            if (lastCount == MAX_POINTERS) return
            k = lastCount++
            lastId[k] = id
        }
        lastX[k] = x
        lastY[k] = y
    }

    private fun forget(id: Int) {
        val k = indexOf(id)
        if (k < 0) return
        lastCount--
        lastId[k] = lastId[lastCount]
        lastX[k] = lastX[lastCount]
        lastY[k] = lastY[lastCount]
    }

    private companion object {
        const val MAX_POINTERS = 10
    }
}
