package com.vncviewer.app.session

import android.content.Context
import android.os.SystemClock
import androidx.compose.runtime.mutableStateListOf
import com.vncviewer.app.input.AppSettings

/**
 * Every open session, owned by the process rather than by the screen. The activity (and its
 * view model) can be closed, swiped away or recreated and the connections carry on; what keeps
 * them alive is [SessionService], which runs for as long as any of them is.
 */
object SessionStore {

    /** The screen's side of a session going away, so it can pick another one or go back to the list. */
    interface Listener {
        fun sessionRemoved(id: String)
    }

    val sessions = mutableStateListOf<VncSession>()

    /** The view model currently showing these sessions; null while there is no screen. */
    var listener: Listener? = null

    private val hiddenSince = HashMap<String, Long>()

    fun add(app: Context, session: VncSession) {
        sessions.add(session)
        SessionService.ensureRunning(app.applicationContext)
    }

    fun close(id: String) {
        val s = sessions.firstOrNull { it.id == id } ?: return
        s.close()
        sessions.remove(s)
        hiddenSince.remove(id)
        listener?.sessionRemoved(id)
    }

    fun closeAll() {
        for (s in sessions.toList()) close(s.id)
    }

    /** Sessions still worth keeping the app alive for: everything that has not dropped. */
    fun liveCount(): Int = sessions.count { it.phase != Phase.FAILED }

    /**
     * "Session timeout" while nothing is on screen (no activity at all): every session counts
     * as not being looked at. While the screen exists, its view model decides.
     */
    fun expireHidden(ctx: Context) {
        val minutes = AppSettings.sessionTimeout(ctx)
        val now = SystemClock.elapsedRealtime()
        for (s in sessions.toList()) {
            val since = hiddenSince.getOrPut(s.id) { now }
            if (minutes > 0 && now - since >= minutes * 60_000L) close(s.id)
        }
    }

    /** A screen came back: nothing has been hidden since this moment. */
    fun screenShown() {
        hiddenSince.clear()
    }
}
