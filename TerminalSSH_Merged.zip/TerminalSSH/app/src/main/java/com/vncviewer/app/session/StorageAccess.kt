package com.vncviewer.app.session

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import androidx.core.content.ContextCompat
import java.io.File

/**
 * "All files access": lets screenshots and recordings go to plain folders on shared storage,
 * <storage>/VncViewer/screenshots and <storage>/VncViewer/recorded.
 */
object StorageAccess {
    fun has(ctx: Context): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) Environment.isExternalStorageManager()
        else ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
            PackageManager.PERMISSION_GRANTED

    /** Open the system screen where the person grants it (Android 11+), or app settings before that. */
    fun request(ctx: Context) {
        val app = ctx.applicationContext
        val uri = Uri.parse("package:" + app.packageName)
        val i = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R)
            Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, uri)
        else Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri)
        try {
            app.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            try {
                app.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) {}
        }
    }

    /** <storage>/VncViewer/<sub>, created; null if it cannot be. */
    fun folder(sub: String): File? {
        val dir = File(Environment.getExternalStorageDirectory(), "VncViewer/$sub")
        return if (dir.isDirectory || dir.mkdirs()) dir else null
    }
}
