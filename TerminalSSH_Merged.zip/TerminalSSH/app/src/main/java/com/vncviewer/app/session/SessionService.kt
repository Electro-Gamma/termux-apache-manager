package com.vncviewer.app.session

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import app.terminalssh.secure.ui.MainActivity
import app.terminalssh.secure.R

/**
 * What lets sessions run with the app in the background: a foreground service, so Android keeps
 * the process (and its sockets) alive, plus a CPU wake lock and a Wi-Fi lock so the connections
 * keep flowing with the screen off. It runs while any session is connected and stops itself
 * when the last one ends.
 */
class SessionService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private var wake: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null

    private val tick: Runnable = object : Runnable {
        override fun run() {
            if (SessionStore.listener == null) SessionStore.expireHidden(this@SessionService)
            if (SessionStore.liveCount() == 0) {
                stopSelfCleanly()
                return
            }
            notifyNow()
            handler.postDelayed(this, TICK_MS)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Remote desktop sessions", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "Shown while remote desktop sessions are connected in the background"
                    setShowBadge(false)
                }
            )
        }
        acquireLocks()
        handler.postDelayed(tick, TICK_MS)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_DISCONNECT_ALL) {
            SessionStore.closeAll()
            stopSelfCleanly()
            return START_NOT_STICKY
        }
        // Within a few seconds of startForegroundService(), or Android stops the app.
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, NOTIFICATION_ID, build(), type)
        // Nothing to keep alive (the session ended before we got here).
        if (SessionStore.liveCount() == 0) stopSelfCleanly()
        // If the process is killed the sessions are gone with it: nothing to restart for.
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        releaseLocks()
        super.onDestroy()
    }

    private fun stopSelfCleanly() {
        handler.removeCallbacks(tick)
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun notifyNow() {
        try {
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIFICATION_ID, build())
        } catch (e: Exception) {
            Log.w(TAG, "updating the notification", e)
        }
    }

    private fun build(): Notification {
        val live = SessionStore.sessions.filter { it.phase != Phase.FAILED }
        val title = "Remote desktop connected"
        val text = when (live.size) {
            0 -> "Closing\u2026"
            1 -> live[0].let { s -> s.desktopName.ifEmpty { s.profile.name.ifEmpty { s.profile.host } } }
            else -> "${live.size} sessions connected"
        }
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java)
                .putExtra(EXTRA_OPEN_VNC, true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            flags
        )
        val disconnect = PendingIntent.getService(
            this, 1,
            Intent(this, SessionService::class.java).setAction(ACTION_DISCONNECT_ALL),
            flags
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_session)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(open)
            .addAction(0, "Disconnect all", disconnect)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
    }

    private fun acquireLocks() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "VncViewer:sessions").apply {
                setReferenceCounted(false)
                acquire()
            }
        } catch (e: Exception) {
            Log.w(TAG, "wake lock", e)
        }
        try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val mode = if (Build.VERSION.SDK_INT >= 29) WifiManager.WIFI_MODE_FULL_LOW_LATENCY
            else WifiManager.WIFI_MODE_FULL_HIGH_PERF
            wifi = wm.createWifiLock(mode, "VncViewer:sessions").apply {
                setReferenceCounted(false)
                acquire()
            }
        } catch (e: Exception) {
            Log.w(TAG, "wifi lock", e)
        }
    }

    private fun releaseLocks() {
        try { wake?.let { if (it.isHeld) it.release() } } catch (_: Exception) {}
        try { wifi?.let { if (it.isHeld) it.release() } } catch (_: Exception) {}
        wake = null
        wifi = null
    }

    companion object {
        /** Tapping the notification asks MainActivity to land on the VNC tab. */
        const val EXTRA_OPEN_VNC = "app.terminalssh.secure.OPEN_VNC_TAB"
        private const val TAG = "SessionService"
        /** Its own channel: Terminal SSH already owns the one called "sessions". */
        private const val CHANNEL = "vnc_sessions"
        private const val NOTIFICATION_ID = 2001
        private const val TICK_MS = 10_000L
        private const val ACTION_DISCONNECT_ALL = "com.vncviewer.app.DISCONNECT_ALL"

        /** Start (or keep) the service; called when a session is added, while the app is in front. */
        fun ensureRunning(ctx: Context) {
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, SessionService::class.java))
            } catch (e: Exception) {
                Log.w(TAG, "starting the service", e)
            }
        }
    }
}
