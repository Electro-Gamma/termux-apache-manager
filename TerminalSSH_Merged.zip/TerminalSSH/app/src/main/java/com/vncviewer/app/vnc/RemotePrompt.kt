package com.vncviewer.app.vnc

/**
 * A question the engine needs a person to answer (RealVNC engine). The engine waits until
 * [cancel] or one of the answer methods is called; each prompt can be answered only once.
 */
sealed class RemotePrompt {
    abstract fun cancel()
}

/** Ask for a user name and/or password. */
class CredentialsPrompt(
    val serverName: String,
    val instructions: String,
    val askUserName: Boolean,
    val userName: String,
    val askPassword: Boolean,
    val catchphrase: String,
    val signature: String,
    private val sink: (ok: Boolean, user: String?, pass: String?) -> Unit
) : RemotePrompt() {
    private var answered = false

    fun answer(ok: Boolean, user: String?, pass: String?) {
        if (answered) return
        answered = true
        sink(ok, user, pass)
    }

    override fun cancel() = answer(false, null, null)
}

enum class TrustIdentity { OK, NEW, MATCHES_ANOTHER, CHANGED, MISSING, PRESHARED, ARD }

enum class TrustEncryption { ENCRYPTED, UNENCRYPTED_WARN, UNENCRYPTED_QUIET }

/** "Is this server who it says it is, and is the line encrypted?" */
class TrustPrompt(
    val serverName: String,
    val encryption: TrustEncryption,
    val identity: TrustIdentity,
    val signature: String,
    val catchphrase: String,
    val matchingName: String,
    private val sink: (accept: Boolean, remember: Boolean) -> Unit
) : RemotePrompt() {
    private var answered = false

    fun answer(accept: Boolean, remember: Boolean) {
        if (answered) return
        answered = true
        sink(accept, remember)
    }

    override fun cancel() = answer(false, false)
}

enum class MessageSeverity { INFORMATION, QUESTION, WARNING, ERROR }

/** A message box; [isQuestion] means it has a negative button too. */
class MessagePrompt(
    val serverName: String,
    val message: String,
    val severity: MessageSeverity,
    val isQuestion: Boolean,
    val yesNo: Boolean,
    val customButton: String?,
    private val sink: (ok: Boolean) -> Unit
) : RemotePrompt() {
    private var answered = false

    fun answer(ok: Boolean) {
        if (answered) return
        answered = true
        sink(ok)
    }

    override fun cancel() = answer(false)
}
