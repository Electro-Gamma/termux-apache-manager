package com.vncviewer.app.ui

import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.ui.graphics.Brush
import app.terminalssh.secure.ui.theme.Cyan
import app.terminalssh.secure.ui.theme.Ink
import app.terminalssh.secure.ui.theme.Turquoise
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.foundation.layout.fillMaxSize
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.vncviewer.app.input.AppSettings
import com.vncviewer.app.session.Phase

@Composable
fun VncViewerApp(vm: VncViewModel) {
    val view = LocalView.current
    val context = LocalContext.current

    // The tab is composed only while it is on screen, so entering and leaving the composition is
    // exactly "shown" and "hidden": the view model uses it to stop sending keys and clipboard to a
    // remote desktop while another tab is in front, and the system bars come back on leaving.
    DisposableEffect(Unit) {
        vm.onTabShown()
        onDispose {
            vm.onTabHidden()
            (context as? Activity)?.window?.let { w ->
                WindowCompat.getInsetsController(w, view).show(WindowInsetsCompat.Type.systemBars())
            }
        }
    }

    val inSession = vm.screen == Screen.SESSION
    val connected = vm.activeSession?.phase == Phase.CONNECTED
    // "Full screen" hides the system bars while connected; the Fullscreen chip also hides our own chrome.
    val immersive = inSession && (vm.fullscreen || (AppSettings.immersive(context) && connected))
    val keepAwake = inSession && connected && AppSettings.keepAwake(context)

    BackHandler(enabled = inSession) {
        if (vm.fullscreen) {
            vm.fullscreen = false
        } else {
            vm.screen = Screen.LIST
        }
    }

    LaunchedEffect(immersive) {
        val window = (context as? Activity)?.window ?: return@LaunchedEffect
        val controller = WindowCompat.getInsetsController(window, view)
        if (immersive) {
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            controller.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    // One theme for every screen: TerminalSSH's palette, in the chosen appearance.
    val homeStyle = vm.screen != Screen.SESSION
    val lightBars = !appIsDark()
    DisposableEffect(keepAwake) {
        view.keepScreenOn = keepAwake
        onDispose { if (keepAwake) view.keepScreenOn = false }
    }
    SideEffect {
        val window = (context as? Activity)?.window ?: return@SideEffect
        val controller = WindowCompat.getInsetsController(window, view)
        controller.isAppearanceLightStatusBars = lightBars
        controller.isAppearanceLightNavigationBars = lightBars
    }

    val body: @Composable () -> Unit = {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
          // TerminalSSH's page background: Ink with a faint turquoise-to-cyan wash from the top.
          Box(
            Modifier.fillMaxSize().then(
                if (homeStyle) Modifier.background(
                    Brush.verticalGradient(
                        listOf(Turquoise.copy(alpha = 0.055f), Cyan.copy(alpha = 0.018f), Ink, Ink)
                    )
                ) else Modifier
            )
          ) {
            when (vm.screen) {
                Screen.SESSION -> {
                    val session = vm.activeSession
                    // Leaving a session, by any road, keeps its last screenful for the home card.
                    DisposableEffect(session?.id) {
                        onDispose { if (session != null && vm.sessions.contains(session)) vm.captureThumbnail(session) }
                    }
                    SessionScreen(vm)
                }
                Screen.SETTINGS -> SettingsScreen(vm)
                Screen.LIST -> ConnectionsScreen(vm)
            }
          }
        }
    }
    body()
}
