// SPDX-License-Identifier: MIT
//
// Kotlin port of Vento's input stack (https://github.com/pgaskin/vento, control/ module,
// (C) 2026 Patrick Gaskin, MIT): Button, MouseSink, Scheduler, WheelSteps, HoverAssist,
// PointerAccel, PointerInertia, TapRegions, GestureRecognizer.
package com.vncviewer.app.input

import android.os.Handler
import android.os.Looper
import android.view.Choreographer

enum class Button(val mask: Int) {
    LEFT(1), MIDDLE(2), RIGHT(4), WHEEL_UP(8), WHEEL_DOWN(16), WHEEL_LEFT(32), WHEEL_RIGHT(64),
    BACK(128), FORWARD(256);

    companion object {
        const val DRAG_MASK = 1 or 2 or 4
        const val CLICK_MASK = DRAG_MASK or 128 or 256

        fun maskName(mask: Int): String {
            if (mask == 0) return "-"
            val sb = StringBuilder()
            for (b in values()) {
                if ((mask and b.mask) != 0) {
                    if (sb.isNotEmpty()) sb.append('+')
                    sb.append(b.name)
                }
            }
            return sb.toString()
        }
    }
}

/** Where relative motion and button changes go. */
interface MouseSink {
    fun mouseMove(dx: Float, dy: Float)
    fun mouseDown(mask: Int)
    fun mouseUp(mask: Int)
}

interface ZoomSink {
    fun zoomBegan()
    fun zoomChanged(factor: Float)
    fun zoomPanned(screenDx: Float, screenDy: Float)
    fun zoomEnded()
    fun scaleCentre(screenX: Float, screenY: Float)
}

interface RegionSink {
    fun regionTapped(region: TapRegions.Region, x: Float, y: Float): Boolean
}

/** Time, so the stack can be driven from the main thread without owning a Handler. */
interface Scheduler {
    fun postDelayed(r: Runnable, delayMs: Long)
    fun removeCallbacks(r: Runnable)
    fun postFrame(r: Runnable)
    fun removeFrame(r: Runnable)
}

class AndroidScheduler : Scheduler {
    private val handler = Handler(Looper.getMainLooper())
    private val choreographer: Choreographer = Choreographer.getInstance()
    private val frames = HashMap<Runnable, Choreographer.FrameCallback>()

    override fun postDelayed(r: Runnable, delayMs: Long) {
        handler.postDelayed(r, delayMs)
    }

    override fun removeCallbacks(r: Runnable) {
        handler.removeCallbacks(r)
    }

    override fun postFrame(r: Runnable) {
        if (frames.containsKey(r)) return
        val cb = Choreographer.FrameCallback {
            frames.remove(r)
            r.run()
        }
        frames[r] = cb
        choreographer.postFrameCallback(cb)
    }

    override fun removeFrame(r: Runnable) {
        val cb = frames.remove(r)
        if (cb != null) choreographer.removeFrameCallback(cb)
    }
}

/** Turns an accumulated distance into whole wheel clicks. */
class WheelSteps(private val sink: MouseSink) {
    private var accX = 0f
    private var accY = 0f

    fun add(dx: Float, dy: Float, stepPx: Float) {
        accY += dy
        accX += dx
        val vsteps = (accY / stepPx).toInt()
        val hsteps = (accX / stepPx).toInt()
        var i = 0
        while (i < vsteps) { click(Button.WHEEL_DOWN); i++ }
        i = 0
        while (i > vsteps) { click(Button.WHEEL_UP); i-- }
        i = 0
        while (i < hsteps) { click(Button.WHEEL_RIGHT); i++ }
        i = 0
        while (i > hsteps) { click(Button.WHEEL_LEFT); i-- }
        accY %= stepPx
        accX %= stepPx
    }

    fun reset() {
        accX = 0f
        accY = 0f
    }

    private fun click(b: Button) {
        sink.mouseDown(b.mask)
        sink.mouseUp(b.mask)
    }
}

/**
 * Loses a little distance just after the far end changes the cursor's shape, so that whatever
 * it changed shape over is easier to stop on.
 */
class HoverAssist(private val cfg: Config) {
    private var budget = 0f
    private var armX = 0f
    private var armY = 0f
    private var lastDx = 0f
    private var lastDy = 0f
    private var travel = 0f
    private var lastMoveTime = -1L
    private var gain = 1.0f
    private var gestureEnd = -1L
    private var lag = 0f
    private var burstStart = -1L
    private var burst = 0
    private var lockoutUntil = -1L

    fun reset() {
        budget = 0f
        travel = 0f
        lastMoveTime = -1
        gestureEnd = -1
        gain = 1.0f
        burstStart = -1
        burst = 0
        lockoutUntil = -1
    }

    fun gain(): Float = gain
    fun lagMs(): Float = lag
    fun lockedOut(now: Long): Boolean = now < lockoutUntil

    /** Called for every finger delta; returns the factor to apply to it. */
    fun gain(dx: Float, dy: Float, t: Long): Float {
        lastMoveTime = t
        gestureEnd = -1
        lastDx = dx
        lastDy = dy
        val dist = Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
        travel += dist
        if (budget <= 0) {
            gain = 1.0f
            return gain
        }
        if (dx * armX + dy * armY < 0) {
            budget = 0f
            gain = 1.0f
            return gain
        }
        val span = Math.max(cfg.hoverAssistSpanPx, 1e-3f)
        var u = (span - budget) / span
        u = if (u < 0) 0f else if (u > 1) 1f else u
        budget -= dist
        val s = u * u * (3 - 2 * u)
        gain = cfg.hoverAssistGain + (1 - cfg.hoverAssistGain) * s
        return gain
    }

    fun gestureEnded() {
        if (lastMoveTime >= 0) gestureEnd = lastMoveTime
    }

    fun changed(speed: Float, t: Long, gliding: Boolean) {
        if (!cfg.hoverAssistEnabled || gliding) return
        if (gestureEnd >= 0 && t - gestureEnd <= LAG_WINDOW_MS) {
            lag += ((t - gestureEnd) - lag) * LAG_ALPHA
        }
        if (t < lockoutUntil) return
        if (speed >= cfg.hoverAssistMaxSpeedPx) return
        if (lastMoveTime < 0 || t - lastMoveTime > cfg.hoverAssistIdleMs) return
        if (travel < cfg.hoverAssistMinTravelPx) return
        if (lag > cfg.hoverAssistMaxLagMs) return
        if (burstStart < 0 || t - burstStart > cfg.hoverAssistBurstMs) {
            burstStart = t
            burst = 0
        }
        burst++
        if (burst > cfg.hoverAssistBurstCount) {
            lockoutUntil = t + cfg.hoverAssistLockoutMs
            budget = 0f
            return
        }
        val len = Math.sqrt((lastDx * lastDx + lastDy * lastDy).toDouble()).toFloat()
        if (len <= 0) return
        armX = lastDx / len
        armY = lastDy / len
        budget = cfg.hoverAssistSpanPx
        travel = 0f
    }

    private companion object {
        const val LAG_WINDOW_MS = 600L
        const val LAG_ALPHA = 0.3f
    }
}

/**
 * Pointer acceleration, ported from RealVNC Viewer's. The input is jerk (the change in
 * per-event displacement), not speed: factor = clamp((sqrt(1.1) + jerk/dt) ^ 2.6, 1.1, 5.0).
 * Adaptive gating and axis locking are Vento's own additions.
 */
class PointerAccel(private val cfg: Config, private val sink: MouseSink) {
    enum class Axis(val label: String) { NONE("-"), X("X"), Y("Y") }

    private val hover = HoverAssist(cfg)
    private val dx = FloatArray(3)
    private val dy = FloatArray(3)
    private val time = LongArray(3)
    private var size = 0
    private var lastDt = 1.0f
    private var lastFactor = 1.0f
    private var lastTime = -1L
    private var lastGapMs = NOMINAL_GAP_MS
    private var speed = 0f
    private var magX = 0f
    private var magY = 0f
    private var lock = Axis.NONE
    private var fastX = 0f
    private var fastY = 0f
    private var slowX = 0f
    private var slowY = 0f

    fun reset() {
        size = 0
        lastTime = -1
        lastGapMs = NOMINAL_GAP_MS
        lastDt = 1.0f
        lastFactor = 1.0f
        speed = 0f
        magX = 0f
        magY = 0f
        lock = Axis.NONE
        fastX = 0f; fastY = 0f; slowX = 0f; slowY = 0f
        hover.reset()
    }

    fun remoteCursorChanged(t: Long, gliding: Boolean) = hover.changed(speed, t, gliding)
    fun gestureEnded() = hover.gestureEnded()
    fun hoverGain(): Float = hover.gain()
    fun hoverLagMs(): Float = hover.lagMs()
    fun hoverLockedOut(now: Long): Boolean = hover.lockedOut(now)
    fun lastFactor(): Float = lastFactor
    fun speed(): Float = speed
    fun axisLock(): Axis = lock

    fun turnDegrees(): Float {
        val cross = fastX * slowY - fastY * slowX
        val dot = fastX * slowX + fastY * slowY
        if (cross == 0f && dot == 0f) return 0f
        return Math.abs(Math.toDegrees(Math.atan2(cross.toDouble(), dot.toDouble()))).toFloat()
    }

    fun move(axIn: Float, ayIn: Float, t: Long) {
        var ax = axIn
        var ay = ayIn
        track(ax, ay, t)
        val hoverGain = hover.gain(ax, ay, t)

        if (cfg.axisLockEnabled) {
            lock = nextLock()
            if (lock == Axis.X) ay = 0f else if (lock == Axis.Y) ax = 0f
        } else {
            lock = Axis.NONE
        }

        var factor = 1.0f
        if (cfg.accelEnabled) {
            factor = cfg.accelMin
            push(ax, ay, t)
            if (size == 3) {
                val jx = dx[1] - dx[0]
                val jy = dy[1] - dy[0]
                val jerk = Math.sqrt((jx * jx + jy * jy).toDouble()).toFloat()
                var dt = Math.abs(time[2] - time[0]).toFloat()
                if (dt == 0.0f) dt = lastDt else lastDt = dt
                val f = Math.pow((cfg.accelBase + jerk / dt).toDouble(), cfg.accelExponent.toDouble()).toFloat()
                if (f >= cfg.accelMin) factor = Math.min(f, cfg.accelMax)
                if (cfg.accelAdaptive) factor = gate(factor)
                if (cfg.accelDrainHistory) {
                    size = 0
                } else {
                    System.arraycopy(dx, 1, dx, 0, 2)
                    System.arraycopy(dy, 1, dy, 0, 2)
                    System.arraycopy(time, 1, time, 0, 2)
                    size = 2
                }
            }
        }
        factor *= hoverGain
        lastFactor = factor
        sink.mouseMove(ax * factor, ay * factor)
    }

    private fun track(ax: Float, ay: Float, t: Long) {
        var gap = if (lastTime < 0) 0f else (t - lastTime).toFloat()
        lastTime = t
        if (gap <= 0) gap = lastGapMs else lastGapMs = gap
        val dist = Math.sqrt((ax * ax + ay * ay).toDouble()).toFloat()
        val inst = dist / gap
        speed += (inst - speed) * EMA_ALPHA
        magX += (Math.abs(ax) - magX) * EMA_ALPHA
        magY += (Math.abs(ay) - magY) * EMA_ALPHA

        val span = Math.max(cfg.axisLockTurnSpanPx, 1e-3f)
        val wSlow = Math.min(1.0f, dist / span)
        val wFast = Math.min(1.0f, dist / (span * TURN_FAST_FRACTION))
        slowX += (ax - slowX) * wSlow
        slowY += (ay - slowY) * wSlow
        fastX += (ax - fastX) * wFast
        fastY += (ay - fastY) * wFast
        if (turnDegrees() > cfg.axisLockCornerDeg) {
            slowX = ax; fastX = ax
            slowY = ay; fastY = ay
        }
    }

    private fun gate(factor: Float): Float {
        if (factor <= cfg.accelMin) return factor
        val lo = cfg.accelSlowSpeedPx
        val hi = cfg.accelFullSpeedPx
        var g = if (hi > lo) (speed - lo) / (hi - lo) else 1.0f
        if (g <= 0) return cfg.accelMin
        g = if (g < 1) g * g * (3 - 2 * g) else 1f
        return cfg.accelMin + (factor - cfg.accelMin) * g
    }

    private fun nextLock(): Axis {
        if (speed >= cfg.axisLockMaxSpeedPx) return Axis.NONE
        if (turnDegrees() > cfg.axisLockMaxTurnDeg) return Axis.NONE
        val major = Math.max(magX, magY)
        if (major <= 0) return lock
        val ratio = Math.min(magX, magY) / major
        val locked = if (lock == Axis.NONE) ratio <= cfg.axisLockEnterRatio else ratio <= cfg.axisLockExitRatio
        if (!locked) return Axis.NONE
        return if (magX >= magY) Axis.X else Axis.Y
    }

    private fun push(ax: Float, ay: Float, t: Long) {
        if (size == 3) {
            System.arraycopy(dx, 1, dx, 0, 2)
            System.arraycopy(dy, 1, dy, 0, 2)
            System.arraycopy(time, 1, time, 0, 2)
            size = 2
        }
        dx[size] = ax
        dy[size] = ay
        time[size] = t
        size++
    }

    private companion object {
        const val EMA_ALPHA = 0.5f
        const val NOMINAL_GAP_MS = 8.0f
        const val TURN_FAST_FRACTION = 0.25f
    }
}

/** Flick momentum, ported from RealVNC Viewer's. */
class PointerInertia(
    private val cfg: Config,
    private val sink: MouseSink,
    private val handler: Scheduler
) {
    private val dx = FloatArray(3)
    private val dy = FloatArray(3)
    private val time = LongArray(3)
    private var size = 0
    private var state = IDLE
    private var speed = 0.0
    private var dirX = 0f
    private var dirY = 0f
    private val startTask = Runnable { startGlide() }
    private val tickTask = Runnable { tick() }

    fun isGliding(): Boolean = state == GLIDING
    fun speed(): Double = if (state == GLIDING) speed else 0.0

    fun sample(ax: Float, ay: Float, t: Long) {
        handler.removeCallbacks(startTask)
        if (state != SAMPLING) {
            handler.removeCallbacks(tickTask)
            state = SAMPLING
            if (cfg.inertiaResetOnDown) size = 0
        }
        push(ax, ay, t)
    }

    fun flick() {
        if (!cfg.inertiaEnabled) return
        handler.removeCallbacks(startTask)
        handler.postDelayed(startTask, cfg.inertiaStartDelayMs)
    }

    fun cancel() {
        handler.removeCallbacks(startTask)
        handler.removeCallbacks(tickTask)
        state = IDLE
        speed = 0.0
    }

    private fun startGlide() {
        if (size != 3) return
        state = GLIDING
        val vx = dx[0] + dx[1]
        val vy = dy[0] + dy[1]
        val mag = Math.sqrt((vx * vx + vy * vy).toDouble())
        if (mag != 0.0) {
            dirX = (vx / mag).toFloat()
            dirY = (vy / mag).toFloat()
        }
        speed = if (time[0] == time[2]) 0.0
        else Math.min(mag * cfg.inertiaSpeedScale / (time[2] - time[0]), cfg.inertiaSpeedMax)
        if (speed > 0) {
            handler.postDelayed(tickTask, cfg.inertiaTickMs)
        } else {
            state = IDLE
        }
    }

    private fun tick() {
        sink.mouseMove((dirX * speed).toFloat(), (dirY * speed).toFloat())
        speed *= cfg.inertiaDecay
        if (speed > cfg.inertiaStopSpeed) {
            handler.postDelayed(tickTask, cfg.inertiaTickMs)
        } else {
            speed = 0.0
            state = IDLE
        }
    }

    private fun push(ax: Float, ay: Float, t: Long) {
        if (size == 3) {
            System.arraycopy(dx, 1, dx, 0, 2)
            System.arraycopy(dy, 1, dy, 0, 2)
            System.arraycopy(time, 1, time, 0, 2)
            size = 2
        }
        dx[size] = ax
        dy[size] = ay
        time[size] = t
        size++
    }

    private companion object {
        const val IDLE = 0
        const val SAMPLING = 1
        const val GLIDING = 2
    }
}

/** The screen-edge tap zones (fractions of the view) that stand in for a toolbar. */
class TapRegions(val regions: List<Region>) {
    class Region(val name: String, val left: Float, val top: Float, val right: Float, val bottom: Float) {
        fun contains(fx: Float, fy: Float): Boolean = fx >= left && fx <= right && fy >= top && fy <= bottom
    }

    fun hit(x: Float, y: Float, viewW: Int, viewH: Int): Region? {
        if (viewW <= 0 || viewH <= 0) return null
        val fx = x / viewW
        val fy = y / viewH
        for (r in regions) if (r.contains(fx, fy)) return r
        return null
    }

    companion object {
        const val DISCONNECT = "disconnect"
        const val INFORMATION = "information"
        const val KEYBOARD = "keyboard"
        const val MOUSE = "mouse"

        fun standard(): TapRegions {
            val top = 2f / 22f
            val bottom = 19f / 22f
            return TapRegions(
                listOf(
                    Region(DISCONNECT, 0f, 0f, 1f / 5f, top),
                    Region(INFORMATION, 1f / 5f, 0f, 1f, top),
                    Region(KEYBOARD, 0f, bottom, 4f / 5f, 1f),
                    Region(MOUSE, 4f / 5f, bottom, 1f, 1f)
                )
            )
        }
    }
}

interface TouchListener {
    fun touchBegan(id: Int, x: Float, y: Float, t: Long)
    fun touchMoved(id: Int, prevX: Float, prevY: Float, x: Float, y: Float, t: Long)
    fun touchEnded(id: Int, prevX: Float, prevY: Float, x: Float, y: Float, t: Long)
    fun touchCancelled(t: Long)
}

/**
 * Touch gestures: one finger moves the cursor (accelerated, with momentum), a tap clicks,
 * tap-then-drag drags, two fingers scroll or pinch-zoom, two/three-finger taps right/middle-click.
 */
class GestureRecognizer(
    private val cfg: Config,
    private val sink: MouseSink,
    private val zoomSink: ZoomSink?,
    private val handler: Scheduler
) : TouchListener {

    enum class Mode(val label: String) { NONE("-"), ZOOM("ZOOM"), SCROLL("SCROLL"), MULTI("MULTI") }

    private val accel = PointerAccel(cfg, sink)
    private val inertia = PointerInertia(cfg, sink, handler)
    private val wheel = WheelSteps(sink)

    private val slotId = intArrayOf(-1, -1)
    private val startX = FloatArray(2)
    private val startY = FloatArray(2)
    private val curX = FloatArray(2)
    private val curY = FloatArray(2)
    private val slotMoved = BooleanArray(2)
    private val slotMoves = IntArray(2)
    private val slotPath = FloatArray(2)
    private val slotDownTime = LongArray(2)

    private var down = 0
    private var maxDown = 0
    private var mode = Mode.NONE
    private var relative = false
    private var pinchStartDist = 0f
    private var midX = 0f
    private var midY = 0f
    private var heldButton: Button? = null
    private var pendingRelease: Runnable? = null
    private var regions: TapRegions? = null
    private var regionSink: RegionSink? = null

    private var bumpArmed = false
    private var externalHold = false
    private var bumpDx = 0f
    private var bumpDy = 0f
    private var bumpRunning = false
    private val bumpTask: Runnable = object : Runnable {
        override fun run() {
            if (down != 1) {
                stopBumpScroll()
                return
            }
            sink.mouseMove(bumpDx, bumpDy)
            handler.postDelayed(this, cfg.bumpPeriodMs)
        }
    }

    private val flickX = FloatArray(2)
    private val flickY = FloatArray(2)
    private var flickCount = 0
    private var viewW = 0
    private var viewH = 0

    fun setViewSize(w: Int, h: Int) {
        viewW = w
        viewH = h
    }

    fun setRegions(regions: TapRegions?, sink: RegionSink?) {
        this.regions = regions
        this.regionSink = sink
    }

    fun setRelative(relative: Boolean) {
        this.relative = relative
    }

    /** The far end changed the cursor shape (time is the arrival, not the crossing). */
    fun remoteCursorChanged(t: Long) {
        if (relative && cfg.rawMotionWhenRelative) return
        accel.remoteCursorChanged(t, inertia.speed() > 0)
    }

    fun setExternalButtonHeld(held: Boolean) {
        externalHold = held
    }

    fun downCount(): Int = down
    fun mode(): Mode = mode
    fun heldButton(): Button? = heldButton
    fun accelFactor(): Float = accel.lastFactor()
    fun accelSpeed(): Float = accel.speed()
    fun axisLock(): PointerAccel.Axis = accel.axisLock()
    fun turnDegrees(): Float = accel.turnDegrees()
    fun hoverGain(): Float = accel.hoverGain()
    fun hoverLagMs(): Float = accel.hoverLagMs()
    fun hoverLockedOut(now: Long): Boolean = accel.hoverLockedOut(now)
    fun glideSpeed(): Double = inertia.speed()

    override fun touchBegan(id: Int, x: Float, y: Float, t: Long) {
        val secondFinger = down == 1
        if (down < 2) {
            val s = if (slotId[0] < 0) 0 else 1
            slotId[s] = id
            startX[s] = x; curX[s] = x
            startY[s] = y; curY[s] = y
            slotMoves[s] = 0
            slotPath[s] = 0f
            slotDownTime[s] = t
        }
        if (secondFinger) {
            setMode(Mode.NONE)
            pinchStartDist = dist(curX[0], curY[0], curX[1], curY[1])
            midX = (curX[0] + curX[1]) / 2.0f
            midY = (curY[0] + curY[1]) / 2.0f
            zoomSink?.scaleCentre(midX, midY)
        } else if (down == 0) {
            val pending = pendingRelease
            val resumed = pending != null
            if (pending != null) {
                handler.removeCallbacks(pending)
                pendingRelease = null
            }
            bumpArmed = cfg.bumpScrollEnabled && (resumed || externalHold)
            if (cfg.accelResetOnDown) accel.reset()
            if (cfg.inertiaCancelOnDown) inertia.cancel()
        }
        down++
        slotMoved[0] = false
        slotMoved[1] = false
        maxDown = Math.max(maxDown, down)
    }

    override fun touchMoved(id: Int, prevX: Float, prevY: Float, x: Float, y: Float, t: Long) {
        if (maxDown == 1) pushFlick(x, y)
        val s = slotOf(id)
        if (s >= 0) {
            curX[s] = x
            curY[s] = y
            slotMoves[s]++
            slotPath[s] += dist(prevX, prevY, x, y)
            if (!slotMoved[s]) slotMoved[s] = hasMoved(s, t)
        }
        if (!isMoving()) return
        if (down == 1) {
            if (s < 0) return
            updateBumpScroll(x, y)
            val dx = x - prevX
            val dy = y - prevY
            if (relative && cfg.rawMotionWhenRelative) {
                sink.mouseMove(dx, dy)
            } else {
                accel.move(dx, dy, t)
                inertia.sample(dx, dy, t)
            }
        } else if (down == 2) {
            twoFingerMoved()
        } else {
            setMode(Mode.MULTI)
        }
    }

    override fun touchEnded(id: Int, prevX: Float, prevY: Float, x: Float, y: Float, t: Long) {
        val s = slotOf(id)
        if (s >= 0) {
            curX[s] = x
            curY[s] = y
            slotId[s] = -1
        }
        release(false)
    }

    override fun touchCancelled(t: Long) {
        while (down > 0) release(true)
    }

    /** Abandon everything: fingers, momentum, a held button. */
    fun cancelAll(t: Long) {
        touchCancelled(t)
        stopBumpScroll()
        bumpArmed = false
        inertia.cancel()
        val pending = pendingRelease
        if (pending != null) {
            handler.removeCallbacks(pending)
            pendingRelease = null
        }
        val held = heldButton
        if (held != null) {
            sink.mouseUp(held.mask)
            heldButton = null
        }
        reset()
    }

    private fun slotOf(id: Int): Int = if (slotId[0] == id) 0 else if (slotId[1] == id) 1 else -1

    private fun isMoving(): Boolean {
        if (down == 1) {
            if (slotId[0] >= 0) return slotMoved[0]
            if (slotId[1] >= 0) return slotMoved[1]
            return false
        }
        return slotMoved[0] && slotMoved[1]
    }

    private fun hasMoved(s: Int, t: Long): Boolean {
        if (Math.abs(curX[s] - startX[s]) >= cfg.moveThresholdPx ||
            Math.abs(curY[s] - startY[s]) >= cfg.moveThresholdPx
        ) return true
        if (cfg.tapPathThresholdPx > 0 && slotPath[s] >= cfg.tapPathThresholdPx) return true
        if (cfg.moveCountTest && slotMoves[s] > cfg.moveCountLimit) return true
        return cfg.tapMaxDurationMs > 0 && (t - slotDownTime[s]) > cfg.tapMaxDurationMs
    }

    private fun setMode(m: Mode) {
        if (mode == m) return
        if (mode == Mode.ZOOM) zoomSink?.zoomEnded()
        mode = m
        if (mode == Mode.ZOOM) zoomSink?.zoomBegan()
    }

    private fun twoFingerMoved() {
        val travel = dist(startX[0], startY[0], curX[0], curY[0]) + dist(startX[1], startY[1], curX[1], curY[1])
        val spread = Math.abs(
            dist(startX[0], startY[0], startX[1], startY[1]) - dist(curX[0], curY[0], curX[1], curY[1])
        )
        if (travel == 0.0f) return
        if (mode == Mode.NONE) {
            val ratio = spread / travel
            if (ratio > cfg.zoomRatio) setMode(Mode.ZOOM) else if (ratio < cfg.scrollRatio) setMode(Mode.SCROLL)
        }
        if (mode == Mode.ZOOM) {
            val mx = (curX[0] + curX[1]) / 2.0f
            val my = (curY[0] + curY[1]) / 2.0f
            if (zoomSink != null) {
                if (pinchStartDist > 0) zoomSink.zoomChanged(dist(curX[0], curY[0], curX[1], curY[1]) / pinchStartDist)
                zoomSink.zoomPanned(mx - midX, my - midY)
            }
            midX = mx
            midY = my
        } else if (mode == Mode.SCROLL) {
            val mx = (curX[0] + curX[1]) / 2.0f
            val my = (curY[0] + curY[1]) / 2.0f
            val sign = if (cfg.naturalScrolling) -1.0f else 1.0f
            wheel.add((mx - midX) * sign, (my - midY) * sign, cfg.wheelStepPx)
            midX = mx
            midY = my
        }
    }

    private fun click(b: Button) {
        sink.mouseDown(b.mask)
        sink.mouseUp(b.mask)
    }

    private fun updateBumpScroll(x: Float, y: Float) {
        if (!bumpArmed) {
            stopBumpScroll()
            return
        }
        bumpDx = 0f
        bumpDy = 0f
        if (y < cfg.bumpBorderPx) bumpDy = -cfg.bumpDeltaPx
        if (y > viewH - cfg.bumpBorderPx) bumpDy = cfg.bumpDeltaPx
        if (x < cfg.bumpBorderPx) bumpDx = -cfg.bumpDeltaPx
        if (x > viewW - cfg.bumpBorderPx) bumpDx = cfg.bumpDeltaPx
        if (bumpDx == 0f && bumpDy == 0f && cfg.bumpStopOutsideBorder) {
            stopBumpScroll()
            return
        }
        sink.mouseMove(bumpDx, bumpDy)
        if (!bumpRunning) {
            bumpRunning = true
            handler.postDelayed(bumpTask, cfg.bumpPeriodMs)
        }
    }

    private fun stopBumpScroll() {
        if (bumpRunning) {
            bumpRunning = false
            handler.removeCallbacks(bumpTask)
        }
    }

    private fun release(cancelled: Boolean) {
        if (down == 0) return
        down--
        if (down != 0) return
        bumpArmed = false
        stopBumpScroll()
        accel.gestureEnded()
        val held = heldButton
        if (held != null) {
            sink.mouseUp(held.mask)
            heldButton = null
        }
        if (slotMoved[0] || slotMoved[1] || cancelled) {
            if (!cancelled && !(relative && cfg.rawMotionWhenRelative) && flickCount >= 2 &&
                dist(flickX[0], flickY[0], flickX[1], flickY[1]) > cfg.flickMinDistPx
            ) {
                inertia.flick()
            }
        } else if (!regionTapped()) {
            val button: Button? = when (maxDown) {
                1 -> Button.LEFT
                2 -> Button.RIGHT
                3 -> Button.MIDDLE
                else -> null
            }
            if (button != null) press(button)
        }
        reset()
    }

    private fun regionTapped(): Boolean {
        val r = regions
        val rs = regionSink
        if (r == null || rs == null || maxDown != 1) return false
        val hit = r.hit(startX[0], startY[0], viewW, viewH)
        return hit != null && rs.regionTapped(hit, startX[0], startY[0])
    }

    /** A tap holds its button for clickHoldMs: a touch inside that window leaves it held (tap-then-drag). */
    private fun press(button: Button) {
        sink.mouseDown(button.mask)
        heldButton = button
        val release = Runnable {
            pendingRelease = null
            val h = heldButton
            if (h != null) {
                sink.mouseUp(h.mask)
                heldButton = null
            }
        }
        pendingRelease = release
        handler.postDelayed(release, cfg.clickHoldMs)
    }

    private fun reset() {
        down = 0
        maxDown = 0
        slotId[0] = -1; slotId[1] = -1
        slotMoved[0] = false; slotMoved[1] = false
        slotMoves[0] = 0; slotMoves[1] = 0
        slotPath[0] = 0f; slotPath[1] = 0f
        wheel.reset()
        flickCount = 0
        setMode(Mode.NONE)
    }

    private fun pushFlick(x: Float, y: Float) {
        if (flickCount < 2) {
            flickX[flickCount] = x
            flickY[flickCount] = y
            flickCount++
        } else {
            flickX[0] = flickX[1]
            flickY[0] = flickY[1]
            flickX[1] = x
            flickY[1] = y
        }
    }

    private fun dist(ax: Float, ay: Float, bx: Float, by: Float): Float {
        val dx = bx - ax
        val dy = by - ay
        return Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
    }
}
