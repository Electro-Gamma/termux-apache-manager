// SPDX-License-Identifier: MIT
//
// Kotlin port of Vento's Toolbar.java (https://github.com/pgaskin/vento, control/ module,
// (C) 2026 Patrick Gaskin, MIT). Vento's is a draggable column over the picture; here the same
// model is a row of equal buttons that sits where the session's header bar was.
package com.vncviewer.app.input

/** A thin horizontal toolbar: one square-ish button per item, side by side across the width. */
class Toolbar(private val cfg: Config) : TouchRouter.Claim {

    class Item(val name: String)

    interface Listener {
        fun toolbarChanged()
        fun toolbarAction(name: String)
    }

    class Bounds(val item: Item?, val left: Float, val top: Float, val right: Float, val bottom: Float) {
        fun contains(x: Float, y: Float): Boolean = x >= left && x < right && y >= top && y < bottom
        fun width(): Float = right - left
        fun height(): Float = bottom - top
        fun centreX(): Float = (left + right) / 2.0f
        fun centreY(): Float = (top + bottom) / 2.0f
    }

    private var listener: Listener? = null
    private var defs: List<Item> = emptyList()
    private val items = ArrayList<Bounds>()
    private val active = LinkedHashSet<String>()
    private var viewW = 0
    private var visible = false
    private var activeId = NONE
    private var activeItem: Item? = null
    private var spare = 0L

    fun setListener(l: Listener?) {
        listener = l
    }

    /** Replace the buttons; an identical list is ignored so a press under the finger survives. */
    fun setItems(names: List<String>) {
        val same = defs.size == names.size && defs.indices.all { defs[it].name == names[it] }
        if (same) return
        defs = names.map { Item(it) }
        release()
        layout()
        changed()
    }

    /** The bar's own width; its height is one button. */
    fun setViewSize(w: Int, h: Int) {
        if (w == viewW) return
        viewW = w
        layout()
        changed()
    }

    fun visible(): Boolean = visible

    fun setVisible(v: Boolean) {
        if (visible == v) return
        visible = v
        if (!visible) release()
        changed()
    }

    fun setActive(name: String, on: Boolean) {
        val changedSet = if (on) active.add(name) else active.remove(name)
        if (changedSet) changed()
    }

    fun isActive(item: Item?): Boolean = item != null && active.contains(item.name)

    fun items(): List<Bounds> = items
    fun pressedItem(): Item? = activeItem
    fun touched(): Boolean = activeId != NONE
    fun left(): Float = 0f
    fun right(): Float = viewW.toFloat()
    fun top(): Float = 0f
    fun bottom(): Float = cfg.toolbarButtonPx
    fun height(): Float = if (defs.isEmpty()) 0f else cfg.toolbarButtonPx

    private fun layout() {
        items.clear()
        if (viewW <= 0 || defs.isEmpty()) return
        val w = viewW.toFloat() / defs.size
        var x = 0f
        for (d in defs) {
            items.add(Bounds(d, x, 0f, x + w, cfg.toolbarButtonPx))
            x += w
        }
    }

    override fun claimTouch(id: Int, x: Float, y: Float, t: Long): Boolean {
        if (!visible || defs.isEmpty() || x < left() || x >= right() || y < top() || y >= bottom()) return false
        if (activeId != NONE) {
            spare = spare or bit(id)
            return true
        }
        activeId = id
        activeItem = itemAt(x, y)
        changed()
        return true
    }

    override fun claimMoved(id: Int, x: Float, y: Float, t: Long) {
        // A press that slides off its button is a cancelled press, as on any button.
        if (id != activeId) return
        val now = itemAt(x, y)
        if (now !== activeItem) {
            activeItem = null
            changed()
        }
    }

    override fun claimEnded(id: Int, x: Float, y: Float, t: Long) {
        if (spare != 0L && (spare and bit(id)) != 0L) {
            spare = spare and bit(id).inv()
            return
        }
        if (id != activeId) return
        val item = activeItem
        activeId = NONE
        activeItem = null
        if (item != null && item === itemAt(x, y)) {
            listener?.toolbarAction(item.name)
        }
        changed()
    }

    override fun claimCancelled(t: Long) {
        release()
        changed()
    }

    private fun release() {
        activeId = NONE
        activeItem = null
        spare = 0
    }

    private fun itemAt(x: Float, y: Float): Item? {
        for (b in items) if (b.contains(x, y)) return b.item
        return null
    }

    private fun bit(id: Int): Long = if (id in 0..62) 1L shl id else 0L

    private fun changed() {
        listener?.toolbarChanged()
    }

    companion object {
        private const val NONE = Int.MIN_VALUE

        /** The two buttons Vento's toolbar does not have; the rest reuse the tap-region names. */
        const val KEYS = "keys"
        const val CLIPBOARD = "clipboard"
        const val RECORD = "record"
        const val SCREENSHOT = "screenshot"
    }
}
