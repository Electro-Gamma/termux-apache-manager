package app.terminalssh.secure.sftp

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * The one File Manager clipboard for the whole app.
 *
 * Each connected host has its own controller, but copy and cut must outlive a switch between
 * them: copy in one host's Files tab, open another host's, paste. Keeping the clipboard here
 * rather than per controller is what allows that. The entries carry the connection they came
 * from (see [Clipboard.source]), so the paste knows where to read.
 */
object ClipboardHub {
    private val _state = MutableStateFlow<Clipboard?>(null)
    val state: StateFlow<Clipboard?> = _state.asStateFlow()

    fun set(clipboard: Clipboard) {
        _state.value = clipboard
    }

    fun clear() {
        _state.value = null
    }

    /** A disconnected host's entries can no longer be read, so they must not stay pasteable. */
    fun dropSource(source: SftpSource) {
        if (_state.value?.source === source) _state.value = null
    }
}
