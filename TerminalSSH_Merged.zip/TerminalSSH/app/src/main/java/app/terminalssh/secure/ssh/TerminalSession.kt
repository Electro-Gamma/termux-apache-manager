package app.terminalssh.secure.ssh

import app.terminalssh.secure.ui.theme.TerminalPalette
import kotlinx.coroutines.flow.StateFlow
import org.connectbot.terminal.TerminalEmulator

/**
 * What the Terminal tab needs from a session, whatever carries the bytes: an SSH shell
 * ([SshSession]) or a USB serial port ([app.terminalssh.secure.serial.SerialSession]).
 *
 * The screen, the tab strip, the key bar, paste, snippets and the foreground service all
 * work against this, so a new transport only has to implement it. Connection state reuses
 * [SshSessionState] on purpose: a serial port connects, fails and closes in the same ways,
 * and every status dot and label already speaks that vocabulary.
 */
interface TerminalSession {
    val id: String

    /**
     * Identifies the thing this session is connected to. For SSH it is the saved host's id;
     * for serial it is the adapter. Used to reuse a running session instead of opening a
     * second one, and to show a host as live in the list.
     */
    val hostId: String

    /** Tab title. */
    val title: String

    /** The small line under the tab strip (`user@host:port`, or `115200 8N1`). */
    val subtitle: String

    val state: StateFlow<SshSessionState>
    val emulator: TerminalEmulator

    val ctrlLatched: StateFlow<Boolean>
    val altLatched: StateFlow<Boolean>
    fun toggleCtrl()
    fun toggleAlt()

    fun send(bytes: ByteArray)
    fun send(text: String)

    /** A key press from the keyboard or the bar; applies a latched Ctrl/Alt once. */
    fun sendKey(bytes: ByteArray)
    fun sendKey(text: String)

    fun requestPaste()
    fun applyPalette(palette: TerminalPalette)
    fun applyCursorStyle(style: String, blink: Boolean)
    fun clearScreen()

    /** Everything the session has shown, as plain text — the whole scrollback, not one screen. */
    fun transcriptText(): String

    /** Ends the connection but leaves the tab, so its output stays readable. */
    fun disconnect()

    /** Ends the connection and releases every resource. The session is unusable afterwards. */
    fun destroy()
}
