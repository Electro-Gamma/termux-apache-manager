package app.terminalssh.secure.serial

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbManager
import android.os.Build
import com.hoho.android.usbserial.driver.UsbSerialDriver
import com.hoho.android.usbserial.driver.UsbSerialProber
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withTimeoutOrNull

sealed class UsbEvent {
    data class Attached(val device: UsbDevice) : UsbEvent()
    data class Detached(val device: UsbDevice) : UsbEvent()
    data class PermissionResult(val device: UsbDevice, val granted: Boolean) : UsbEvent()
}

/** A USB-to-UART adapter that is plugged in right now and has a driver. */
data class SerialCandidate(val driver: UsbSerialDriver, val name: String) {
    val device: UsbDevice get() = driver.device

    /** Stable for as long as the adapter stays plugged in. */
    val deviceName: String get() = driver.device.deviceName

    /** `0403:6001`: lets the user tell two similar adapters apart. */
    val usbId: String get() = "%04X:%04X".format(driver.device.vendorId, driver.device.productId)

    /** FTDI, CP210x, CH34x, PL2303 or CDC-ACM, from the driver that matched. */
    val chip: String
        get() = driver.javaClass.simpleName.removeSuffix("SerialDriver").removeSuffix("Driver")
}

/**
 * USB device discovery (through usb-serial-for-android's prober), Android's asynchronous
 * permission dialog, and attach/detach broadcasts, behind one event stream.
 *
 * It belongs to the Application, like the sessions it serves: a serial session has to hear
 * that its adapter was unplugged even when no screen is showing. The receiver is therefore
 * registered once for the life of the process.
 */
class UsbSerialManager(private val context: Context) {

    private val usbManager = context.getSystemService(Context.USB_SERVICE) as UsbManager
    private val permissionAction = "${context.packageName}.USB_PERMISSION"

    private val _events = MutableSharedFlow<UsbEvent>(extraBufferCapacity = 8)
    val events: SharedFlow<UsbEvent> = _events

    @Volatile private var registered = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            val device: UsbDevice? = if (Build.VERSION.SDK_INT >= 33) {
                intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)
            }
            when (intent.action) {
                permissionAction -> {
                    val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
                    device?.let { _events.tryEmit(UsbEvent.PermissionResult(it, granted)) }
                }
                UsbManager.ACTION_USB_DEVICE_ATTACHED -> device?.let { _events.tryEmit(UsbEvent.Attached(it)) }
                UsbManager.ACTION_USB_DEVICE_DETACHED -> device?.let { _events.tryEmit(UsbEvent.Detached(it)) }
            }
        }
    }

    /** Safe to call more than once. */
    fun register() {
        if (registered) return
        val filter = IntentFilter().apply {
            addAction(permissionAction)
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            context.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            context.registerReceiver(receiver, filter)
        }
        registered = true
    }

    /** Every USB-serial adapter currently plugged in, from any supported chip family. */
    fun candidates(): List<SerialCandidate> =
        UsbSerialProber.getDefaultProber().findAllDrivers(usbManager)
            .map { SerialCandidate(it, displayName(it.device)) }

    fun displayName(device: UsbDevice): String {
        val manufacturer = device.manufacturerName?.takeIf { it.isNotBlank() }
        val product = device.productName?.takeIf { it.isNotBlank() }
        val name = listOfNotNull(manufacturer, product).joinToString(" ")
        return name.ifBlank { "USB %04X:%04X".format(device.vendorId, device.productId) }
    }

    fun hasPermission(device: UsbDevice): Boolean = usbManager.hasPermission(device)

    private fun requestPermission(device: UsbDevice) {
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
        val pendingIntent = PendingIntent.getBroadcast(
            context, 0, Intent(permissionAction).setPackage(context.packageName), flags,
        )
        usbManager.requestPermission(device, pendingIntent)
    }

    /**
     * True once the app may talk to [device]. Shows Android's permission dialog when it
     * does not yet, and waits for the answer (or [PERMISSION_TIMEOUT_MS], which counts as
     * a refusal so a dialog the user walked away from cannot hang a connect forever).
     */
    suspend fun ensurePermission(device: UsbDevice): Boolean {
        if (hasPermission(device)) return true
        return withTimeoutOrNull(PERMISSION_TIMEOUT_MS) {
            coroutineScope {
                // Subscribe before asking: the shared flow has no replay, so an answer that
                // arrives before collection starts would be lost.
                val answer = async(start = CoroutineStart.UNDISPATCHED) {
                    events.first {
                        it is UsbEvent.PermissionResult && it.device.deviceName == device.deviceName
                    } as UsbEvent.PermissionResult
                }
                requestPermission(device)
                answer.await().granted
            }
        } ?: false
    }

    fun openConnection(device: UsbDevice): UsbDeviceConnection? = usbManager.openDevice(device)

    fun isUsbHostSupported(): Boolean =
        context.packageManager.hasSystemFeature(PackageManager.FEATURE_USB_HOST)

    private companion object {
        const val PERMISSION_TIMEOUT_MS = 120_000L
    }
}
