package app.terminalssh.secure.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Deselect
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.SelectAll
import androidx.compose.material.icons.outlined.SortByAlpha
import androidx.compose.material.icons.outlined.Storage
import androidx.compose.material.icons.outlined.SwapVert
import androidx.compose.material.icons.outlined.Unarchive
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.terminalssh.secure.R
import app.terminalssh.secure.sftp.ArchiveState
import app.terminalssh.secure.sftp.ListingView
import app.terminalssh.secure.sftp.SftpController
import app.terminalssh.secure.sftp.SortKey
import app.terminalssh.secure.sftp.innerPath
import app.terminalssh.secure.ui.theme.Danger
import app.terminalssh.secure.ui.theme.Stroke
import app.terminalssh.secure.ui.theme.TextSecondary
import app.terminalssh.secure.ui.theme.Turquoise
import app.terminalssh.secure.vm.AppViewModel

/**
 * The File Manager while an archive is open: the contents of a `.zip`, `.tar` or `.7z` listed
 * like a folder, with the same look, selection and three-dot menu as the server's folders.
 *
 * Nothing is extracted to browse: items are read out of the archive's staged copy, and a change
 * (delete, an edited file saved) is written back to the archive on the server. Back steps up
 * through the archive's folders and leaves the archive at its top.
 */
@Composable
fun ArchiveScreen(
    sftp: SftpController,
    viewModel: AppViewModel,
    state: ArchiveState,
    /** False while another tab is showing: stays alive but must not take Back. */
    active: Boolean,
) {
    val selection by sftp.archiveSelection.collectAsStateWithLifecycle()
    val batch by sftp.batch.collectAsStateWithLifecycle()
    val viewOptions by viewModel.sftpViewOptions.collectAsStateWithLifecycle()
    var confirmDelete by remember { mutableStateOf(false) }
    var showReport by remember { mutableStateOf(false) }

    val ready = state.handle != null
    val busy = batch?.isFinished == false
    val raw = remember(state.handle, state.dir) { state.entries() }
    val entries = remember(raw, viewOptions) { ListingView.apply(raw, viewOptions) }
    val hiddenCount = remember(raw, viewOptions) { ListingView.hiddenCount(raw, viewOptions) }
    val allHereSelected = selection.coversAll(entries)

    // Later handler wins: leaving selection mode comes before stepping up a folder.
    BackHandler(enabled = active) { sftp.archiveUp() }
    BackHandler(enabled = active && selection.isActive) { sftp.archiveClearSelection() }

    Column(Modifier.fillMaxSize()) {
        FileManagerTopBar(
            selection = selection,
            currentPath = state.displayPath,
            canGoUp = true,
            onGoUp = sftp::archiveUp,
            onExitSelection = sftp::archiveClearSelection,
            title = state.name,
        ) { closeMenu ->
            if (selection.isActive) {
                val only = selection.single
                val openable = only != null && !only.isDirectory && !only.isSymlink
                MenuEntry(
                    Icons.Outlined.Description,
                    stringResource(R.string.sftp_action_open),
                    closeMenu,
                    enabled = openable,
                ) {
                    only?.let {
                        sftp.archiveClearSelection()
                        sftp.openArchiveEntry(it, edit = false)
                    }
                }
                MenuEntry(
                    Icons.Outlined.Edit,
                    stringResource(R.string.sftp_action_edit),
                    closeMenu,
                    enabled = openable && !busy,
                ) {
                    only?.let {
                        sftp.archiveClearSelection()
                        sftp.openArchiveEntry(it, edit = true)
                    }
                }
                MenuEntry(Icons.Outlined.ContentCopy, stringResource(R.string.sftp_action_copy), closeMenu) {
                    sftp.copyArchiveSelection()
                }
                MenuEntry(
                    Icons.Outlined.Unarchive,
                    stringResource(R.string.sftp_action_extract_here),
                    closeMenu,
                    enabled = !busy,
                ) {
                    sftp.extractArchive(intoFolder = false)
                }
                MenuEntry(
                    Icons.Outlined.Unarchive,
                    stringResource(R.string.sftp_action_extract_folder),
                    closeMenu,
                    enabled = !busy,
                ) {
                    sftp.extractArchive(intoFolder = true)
                }
                MenuEntry(
                    Icons.Outlined.Delete,
                    stringResource(R.string.sftp_action_delete),
                    closeMenu,
                    enabled = !busy,
                    tint = Danger,
                ) {
                    confirmDelete = true
                }
                HorizontalDivider()
                MenuEntry(
                    if (allHereSelected) Icons.Outlined.Deselect else Icons.Outlined.SelectAll,
                    stringResource(if (allHereSelected) R.string.sftp_deselect_all else R.string.sftp_select_all),
                    closeMenu,
                ) {
                    if (allHereSelected) sftp.archiveClearSelection() else sftp.archiveSelectAll(entries)
                }
            } else {
                MenuEntry(
                    Icons.Outlined.Refresh,
                    stringResource(R.string.sftp_archive_reload),
                    closeMenu,
                    enabled = !busy,
                ) {
                    sftp.reloadArchive()
                }
                MenuEntry(
                    Icons.Outlined.Unarchive,
                    stringResource(R.string.sftp_archive_extract_all_here),
                    closeMenu,
                    enabled = ready && !busy,
                ) {
                    sftp.extractArchive(intoFolder = false)
                }
                MenuEntry(
                    Icons.Outlined.Unarchive,
                    stringResource(R.string.sftp_archive_extract_all_folder),
                    closeMenu,
                    enabled = ready && !busy,
                ) {
                    sftp.extractArchive(intoFolder = true)
                }
                MenuEntry(
                    if (viewOptions.showHidden) Icons.Outlined.VisibilityOff else Icons.Outlined.Visibility,
                    stringResource(
                        if (viewOptions.showHidden) R.string.sftp_menu_hide_hidden else R.string.sftp_menu_show_hidden,
                    ),
                    closeMenu,
                ) {
                    viewModel.updateSftpViewOptions { it.copy(showHidden = !it.showHidden) }
                }
                MenuEntry(
                    Icons.Outlined.SelectAll,
                    stringResource(R.string.sftp_select_all),
                    closeMenu,
                    enabled = entries.isNotEmpty(),
                ) {
                    sftp.archiveSelectAll(entries)
                }
                HorizontalDivider()
                MenuEntry(
                    Icons.Outlined.SortByAlpha,
                    stringResource(R.string.sftp_menu_sort_name),
                    closeMenu,
                    checked = viewOptions.sortKey == SortKey.NAME,
                ) {
                    viewModel.updateSftpViewOptions { it.copy(sortKey = SortKey.NAME) }
                }
                MenuEntry(
                    Icons.Outlined.Storage,
                    stringResource(R.string.sftp_menu_sort_size),
                    closeMenu,
                    checked = viewOptions.sortKey == SortKey.SIZE,
                ) {
                    viewModel.updateSftpViewOptions { it.copy(sortKey = SortKey.SIZE) }
                }
                MenuEntry(
                    Icons.Outlined.Schedule,
                    stringResource(R.string.sftp_menu_sort_date),
                    closeMenu,
                    checked = viewOptions.sortKey == SortKey.MODIFIED,
                ) {
                    viewModel.updateSftpViewOptions { it.copy(sortKey = SortKey.MODIFIED) }
                }
                MenuEntry(
                    Icons.Outlined.SwapVert,
                    stringResource(R.string.sftp_menu_sort_reverse),
                    closeMenu,
                    checked = viewOptions.descending,
                ) {
                    viewModel.updateSftpViewOptions { it.copy(descending = !it.descending) }
                }
                HorizontalDivider()
                MenuEntry(Icons.Outlined.Close, stringResource(R.string.sftp_archive_close), closeMenu) {
                    sftp.closeArchive()
                }
            }
        }

        batch?.let { current ->
            BatchCard(
                state = current,
                onCancel = sftp::cancelBatch,
                onDismiss = sftp::dismissBatch,
                onDetails = { showReport = true },
            )
        }

        Box(Modifier.weight(1f)) {
            val error = state.errorKind
            when {
                error != null -> Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                    Text(
                        stringResource(error.stringRes),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.error,
                        textAlign = TextAlign.Center,
                    )
                }
                !ready -> Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        LinearProgressIndicator(color = Turquoise, trackColor = Stroke)
                        Text(
                            if (state.loadedBytes > 0L) {
                                stringResource(R.string.sftp_archive_loading_progress, FileSize.format(state.loadedBytes))
                            } else {
                                stringResource(R.string.sftp_archive_loading)
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary,
                            textAlign = TextAlign.Center,
                        )
                    }
                }
                else -> SftpBrowser(
                    state = SftpController.BrowserState(path = state.displayPath, entries = entries),
                    onNavigate = { sftp.archiveNavigate(innerPath(it)) },
                    onOpenFile = { sftp.openArchiveEntry(it, edit = false) },
                    selection = selection,
                    onToggleSelect = sftp::archiveToggle,
                    hiddenCount = hiddenCount,
                    rootLabel = state.name,
                    modifier = Modifier.fillMaxSize(),
                )
            }
        }
    }

    if (confirmDelete && selection.isActive) {
        DeleteConfirmDialog(
            selection = selection,
            onConfirm = {
                confirmDelete = false
                sftp.deleteArchiveSelection()
            },
            onDismiss = { confirmDelete = false },
            bodyRes = R.string.sftp_archive_delete_body,
        )
    }

    // A report belongs to one operation: a new or dismissed batch closes it.
    LaunchedEffect(batch?.id) { showReport = false }
    val finished = batch
    if (showReport && finished != null && finished.failureCount > 0) {
        BatchReportDialog(state = finished, onDismiss = { showReport = false })
    }
}
