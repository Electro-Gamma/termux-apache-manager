package app.terminalssh.secure.sftp

import android.content.ContentResolver
import android.net.Uri
import android.provider.DocumentsContract
import app.terminalssh.secure.archive.ArchiveCancelled
import app.terminalssh.secure.archive.ArchiveEngine
import app.terminalssh.secure.archive.ArchiveEntry
import app.terminalssh.secure.archive.ArchiveException
import app.terminalssh.secure.archive.ArchiveFormat
import app.terminalssh.secure.archive.ArchiveIndex
import app.terminalssh.secure.archive.ArchivePaths
import app.terminalssh.secure.archive.ArchiveProblem
import app.terminalssh.secure.archive.ArchivePut
import app.terminalssh.secure.archive.CompressionLevel
import app.terminalssh.secure.archive.ExtractSink
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID

/**
 * Runs the multi-item operations: recursive download, delete, copy, move and rename.
 *
 * One operation at a time, on its own SFTP client, so a long batch never shares a channel
 * with folder listings or with the single-file transfer queue (which is untouched).
 * Every operation first walks the selected folders to learn the total work, then does it;
 * individual failures are collected and reported rather than aborting the run.
 */
class BatchRunner(
    private val session: SftpSource,
    private val contentResolver: ContentResolver,
    private val scope: CoroutineScope,
    /** Where archives are staged while they are packed, unpacked or edited. */
    private val cacheDir: File,
    /** An archive was rewritten on the server: the first handle is the old copy, the second the new one. */
    private val onArchiveCommitted: (ArchiveHandle, ArchiveHandle) -> Unit,
    private val onFinished: (BatchKind) -> Unit,
) {
    private val _state = MutableStateFlow<BatchState?>(null)
    val state: StateFlow<BatchState?> = _state.asStateFlow()

    val isBusy: Boolean get() = _state.value?.let { !it.isFinished } ?: false

    @Volatile
    private var cancelRequested = false
    private var job: Job? = null

    fun download(items: List<RemoteEntry>, treeUri: Uri): Boolean =
        start(BatchKind.DOWNLOAD) { sftp, rep -> runDownload(sftp, rep, items, treeUri) }

    fun delete(items: List<RemoteEntry>): Boolean =
        start(BatchKind.DELETE) { sftp, rep -> runDelete(sftp, rep, items) }

    fun copy(items: List<RemoteEntry>, destination: String): Boolean =
        start(BatchKind.COPY) { sftp, rep -> runCopy(sftp, rep, items, destination) }

    fun move(items: List<RemoteEntry>, destination: String): Boolean =
        start(BatchKind.MOVE) { sftp, rep -> runMove(sftp, rep, items, destination) }

    /**
     * Copies [items], which live on [source], into [destination] on this runner's own host.
     * Folders are copied with everything inside them; the bytes stream from one host to the
     * other through this device.
     */
    fun copyFrom(source: SftpSource, items: List<RemoteEntry>, destination: String): Boolean =
        start(BatchKind.COPY) { dst, rep -> runAcross(source, dst, rep, items, destination, deleteSource = false) }

    /**
     * Like [copyFrom], then removes each item from [source], but only an item whose copy
     * finished completely: a failure leaves the original in place. [onSourceChanged] runs
     * afterwards so the source's listing can be refreshed.
     */
    fun moveFrom(
        source: SftpSource,
        items: List<RemoteEntry>,
        destination: String,
        onSourceChanged: (() -> Unit)?,
    ): Boolean = start(BatchKind.MOVE, onSourceChanged) { dst, rep ->
        runAcross(source, dst, rep, items, destination, deleteSource = true)
    }

    fun rename(entry: RemoteEntry, newName: String): Boolean =
        start(BatchKind.RENAME) { sftp, rep -> runRename(sftp, rep, entry, newName) }

    fun createFolder(parent: String, name: String): Boolean =
        start(BatchKind.NEW_FOLDER) { sftp, rep -> runCreateFolder(sftp, rep, parent, name) }

    fun createFile(parent: String, name: String): Boolean =
        start(BatchKind.NEW_FILE) { sftp, rep -> runCreateFile(sftp, rep, parent, name) }

    fun cancel() {
        cancelRequested = true
    }

    /** Hides a finished operation's card. A running one is left alone. */
    fun dismiss() {
        if (_state.value?.isFinished == true) _state.value = null
    }

    /** Session gone or screen left: stop, and make sure the card never stays "running". */
    fun close() {
        cancelRequested = true
        job?.cancel()
        _state.update { s ->
            if (s != null && !s.isFinished) s.copy(phase = BatchPhase.CANCELLED, current = "") else s
        }
    }

    private fun start(
        kind: BatchKind,
        afterFinish: (() -> Unit)? = null,
        /** Runs when the operation ends however it ends (done, failed, cancelled, never connected). */
        cleanup: (() -> Unit)? = null,
        work: (SftpClient, Reporter) -> Unit,
    ): Boolean {
        if (isBusy) return false
        val id = UUID.randomUUID().toString()
        _state.value = BatchState(id = id, kind = kind)
        cancelRequested = false
        val reporter = Reporter(id)
        job = scope.launch {
          try {
            val outcome = runCatching {
                withContext(Dispatchers.IO) {
                    val sftp = session.openSftp() ?: throw java.io.IOException("connection is not available")
                    try {
                        work(sftp, reporter)
                    } finally {
                        sftp.close()
                    }
                }
            }
            val failure = outcome.exceptionOrNull()
            if (failure is CancellationException) {
                reporter.finish(cancelled = true)
                return@launch
            }
            if (failure != null) reporter.fail("", failure)
            reporter.finish(cancelled = cancelRequested)
            onFinished(kind)
            afterFinish?.invoke()
          } finally {
            cleanup?.invoke()
          }
        }
        return true
    }

    // ---- reporting ----

    /** Mutated only by the single worker thread; published to the UI at a throttled rate. */
    private inner class Reporter(private val id: String) {
        var phase = BatchPhase.PREPARING
        var totalItems = 0
        var doneItems = 0
        var totalBytes = 0L
        var doneBytes = 0L
        var current = ""
        var skipped = 0
        var aborted = false
        private val failures = ArrayList<BatchFailure>()
        private val failedPaths = HashSet<String>()
        private var notListed = 0
        private var lastPublishedAt = 0L

        /** True once the user cancelled or the connection dropped. */
        val stopped: Boolean get() = cancelRequested || aborted

        fun fail(path: String, kind: TransferErrorKind, problem: BatchProblem? = null) {
            // The same path can fail twice (unreadable folder, then its removal): report once.
            if (path.isNotEmpty() && !failedPaths.add(path)) return
            if (failures.size < BatchState.MAX_FAILURES_KEPT) {
                failures.add(BatchFailure(path, kind, problem))
            } else {
                notListed++
            }
            if (kind == TransferErrorKind.CONNECTION_LOST) aborted = true
            publish()
        }

        fun fail(path: String, error: Throwable): Unit = fail(path, SftpClient.classify(error))

        fun startRunning(fixedItems: Int = -1) {
            if (fixedItems >= 0) totalItems = fixedItems
            phase = BatchPhase.RUNNING
            publish()
        }

        /** Back to the indeterminate phase (fetching an archive between two extractions). */
        fun preparing() {
            phase = BatchPhase.PREPARING
            publish()
        }

        /** A new stretch of byte-counted work: the bar starts over against [total]. */
        fun resetBytes(total: Long) {
            totalBytes = total.coerceAtLeast(0L)
            doneBytes = 0L
            publish()
        }

        fun begin(name: String) {
            current = name
            publishThrottled()
        }

        fun itemDone() {
            doneItems++
            publishThrottled()
        }

        fun bytes(delta: Long) {
            if (delta > 0L) doneBytes += delta
            publishThrottled()
        }

        fun finish(cancelled: Boolean) {
            phase = if (cancelled) BatchPhase.CANCELLED else BatchPhase.FINISHED
            current = ""
            publish()
        }

        fun publishThrottled() {
            val now = System.nanoTime() / 1_000_000L
            if (now - lastPublishedAt >= PUBLISH_INTERVAL_MS) publish()
        }

        fun publish() {
            lastPublishedAt = System.nanoTime() / 1_000_000L
            val snapshot = failures.toList()
            _state.update { s ->
                if (s == null || s.id != id) {
                    s
                } else {
                    s.copy(
                        phase = phase,
                        totalItems = totalItems,
                        doneItems = doneItems,
                        totalBytes = totalBytes,
                        doneBytes = doneBytes,
                        current = current,
                        failures = snapshot,
                        failuresNotListed = notListed,
                        skipped = skipped,
                        aborted = aborted,
                    )
                }
            }
        }
    }

    /** Thrown from a progress callback to unwind a blocking transfer after a cancel. */
    private class StopRequested : RuntimeException("stopped by the user")

    // ---- planning ----

    /** One file or folder to process; [parentIndex] points at its folder in the same plan, -1 for a selected root. */
    private class PlanItem(val entry: RemoteEntry, val parentIndex: Int)

    private fun scan(
        sftp: SftpClient,
        rep: Reporter,
        roots: List<RemoteEntry>,
        skipLinkedFolders: Boolean,
    ): List<PlanItem> {
        val plan = ArrayList<PlanItem>()
        for (root in roots) {
            if (rep.stopped) break
            scanInto(sftp, rep, root, -1, 0, skipLinkedFolders, plan)
        }
        return plan
    }

    private fun scanInto(
        sftp: SftpClient,
        rep: Reporter,
        entry: RemoteEntry,
        parentIndex: Int,
        depth: Int,
        skipLinkedFolders: Boolean,
        plan: MutableList<PlanItem>,
    ) {
        if (rep.stopped) return
        // A link to a folder is never followed: it could point back up the tree and
        // turn a download into an endless loop.
        if (skipLinkedFolders && entry.isSymlink && sftp.isDirectoryFollowingLinks(entry.path)) {
            rep.skipped++
            return
        }
        val index = plan.size
        plan.add(PlanItem(entry, parentIndex))
        rep.totalItems++
        if (!entry.isDirectory && entry.sizeBytes > 0L) rep.totalBytes += entry.sizeBytes
        rep.publishThrottled()
        if (!entry.isDirectory) return
        if (depth >= MAX_DEPTH) {
            rep.fail(entry.path, TransferErrorKind.UNKNOWN)
            return
        }
        val children = try {
            sftp.list(entry.path)
        } catch (e: Exception) {
            rep.fail(entry.path, e)
            return
        }
        for (child in children) {
            scanInto(sftp, rep, child, index, depth + 1, skipLinkedFolders, plan)
        }
    }

    private fun existingNames(sftp: SftpClient, rep: Reporter, directory: String): MutableSet<String>? =
        try {
            sftp.list(directory).mapTo(HashSet<String>()) { it.name }
        } catch (e: Exception) {
            rep.fail(directory, e)
            null
        }

    /** Drops folders that would be put inside themselves, reporting each one. */
    private fun withoutIntoItself(rep: Reporter, items: List<RemoteEntry>, destination: String): List<RemoteEntry> =
        items.filter { entry ->
            val bad = entry.isDirectory && RemotePath.isSameOrInside(destination, entry.path)
            if (bad) rep.fail(entry.path, TransferErrorKind.UNKNOWN, BatchProblem.INTO_ITSELF)
            !bad
        }

    // ---- download ----

    private fun runDownload(sftp: SftpClient, rep: Reporter, items: List<RemoteEntry>, treeUri: Uri) {
        val plan = scan(sftp, rep, items, skipLinkedFolders = true)
        if (rep.stopped) return
        val rootDocument = try {
            DocumentsContract.buildDocumentUriUsingTree(treeUri, DocumentsContract.getTreeDocumentId(treeUri))
        } catch (e: Exception) {
            rep.fail("", TransferErrorKind.LOCAL_UNAVAILABLE)
            return
        }
        rep.startRunning()
        val folders = HashMap<Int, Uri>()
        for (index in plan.indices) {
            if (rep.stopped) break
            val item = plan[index]
            val entry = item.entry
            val parent: Uri? = if (item.parentIndex < 0) rootDocument else folders[item.parentIndex]
            if (parent == null) {
                // Its folder could not be created; that failure is already on the report.
                rep.itemDone()
                continue
            }
            val name = RemotePath.sanitizeDownloadName(entry.name)
            rep.begin(entry.name)
            if (entry.isDirectory) {
                try {
                    folders[index] = createLocal(parent, DocumentsContract.Document.MIME_TYPE_DIR, name)
                } catch (e: Exception) {
                    rep.fail(entry.path, TransferErrorKind.LOCAL_UNAVAILABLE)
                }
            } else {
                downloadFile(sftp, rep, entry, parent, name)
            }
            rep.itemDone()
        }
    }

    private fun createLocal(parent: Uri, mimeType: String, name: String): Uri =
        DocumentsContract.createDocument(contentResolver, parent, mimeType, name)
            ?: throw IllegalStateException("cannot create $name")

    private fun discardLocal(uri: Uri?) {
        if (uri != null) runCatching { DocumentsContract.deleteDocument(contentResolver, uri) }
    }

    private fun downloadFile(sftp: SftpClient, rep: Reporter, entry: RemoteEntry, parent: Uri, name: String) {
        val target = try {
            createLocal(parent, "application/octet-stream", name)
        } catch (e: Exception) {
            rep.fail(entry.path, TransferErrorKind.LOCAL_UNAVAILABLE)
            return
        }
        val sink = try {
            contentResolver.openOutputStream(target, "wt")
        } catch (e: Exception) {
            null
        }
        if (sink == null) {
            discardLocal(target)
            rep.fail(entry.path, TransferErrorKind.LOCAL_UNAVAILABLE)
            return
        }
        try {
            var last = 0L
            sink.use { out ->
                sftp.download(entry.path, out, resumeFrom = 0L) { total ->
                    if (cancelRequested) throw StopRequested()
                    rep.bytes(total - last)
                    last = total
                }
            }
        } catch (e: Exception) {
            // Never leave a half-written file that looks like a finished one.
            discardLocal(target)
            if (!cancelRequested) rep.fail(entry.path, e)
        }
    }

    // ---- delete ----

    private fun runDelete(sftp: SftpClient, rep: Reporter, items: List<RemoteEntry>) {
        // Links are removed as links, never followed, so nothing outside the selection is touched.
        val plan = scan(sftp, rep, items, skipLinkedFolders = false)
        // A scan cut short must not turn into a partial delete the user never confirmed.
        if (rep.stopped) return
        rep.startRunning()
        deletePlan(sftp, rep, plan, countProgress = true)
    }

    private fun deletePlan(sftp: SftpClient, rep: Reporter, plan: List<PlanItem>, countProgress: Boolean): Boolean {
        // Children precede their folder in the plan's reverse order, so folders are empty when reached.
        var ok = true
        val blocked = HashSet<Int>()
        for (index in plan.indices.reversed()) {
            if (rep.stopped) return false
            val item = plan[index]
            val entry = item.entry
            if (index in blocked) {
                // Something inside failed, so this folder cannot be removed; do not pile on.
                if (item.parentIndex >= 0) blocked.add(item.parentIndex)
                ok = false
                if (countProgress) rep.itemDone()
                continue
            }
            rep.begin(entry.name)
            try {
                sftp.delete(entry.path, entry.isDirectory)
            } catch (e: Exception) {
                rep.fail(entry.path, e)
                if (item.parentIndex >= 0) blocked.add(item.parentIndex)
                ok = false
            }
            if (countProgress) rep.itemDone()
        }
        return ok
    }

    // ---- copy ----

    private fun runCopy(sftp: SftpClient, rep: Reporter, items: List<RemoteEntry>, destination: String) {
        val dest = RemotePath.normalize(destination)
        val valid = withoutIntoItself(rep, items, dest)
        val plan = scan(sftp, rep, valid, skipLinkedFolders = true)
        if (rep.stopped) return
        val existing = existingNames(sftp, rep, dest) ?: return
        rep.startRunning()
        copyPlan(sftp, rep, plan, dest, existing, forcedTopName = null)
    }

    /** Returns true when everything in [plan] was copied without a failure. */
    private fun copyPlan(
        sftp: SftpClient,
        rep: Reporter,
        plan: List<PlanItem>,
        destination: String,
        existing: MutableSet<String>,
        forcedTopName: String?,
    ): Boolean {
        var ok = true
        val targets = HashMap<Int, String>()
        for (index in plan.indices) {
            if (rep.stopped) return false
            val item = plan[index]
            val entry = item.entry
            val parentPath: String?
            val name: String
            if (item.parentIndex < 0) {
                parentPath = destination
                name = forcedTopName ?: RemotePath.uniqueName(existing, entry.name)
                existing.add(name)
            } else {
                parentPath = targets[item.parentIndex]
                name = entry.name
            }
            if (parentPath == null) {
                // The folder this belongs in could not be created; already reported.
                rep.itemDone()
                continue
            }
            val targetPath = RemotePath.join(parentPath, name)
            rep.begin(entry.name)
            if (entry.isDirectory) {
                try {
                    sftp.makeDirectory(targetPath)
                    targets[index] = targetPath
                } catch (e: Exception) {
                    rep.fail(entry.path, e)
                    ok = false
                }
            } else {
                try {
                    var last = 0L
                    sftp.copyFile(entry.path, targetPath) { total ->
                        if (cancelRequested) throw StopRequested()
                        rep.bytes(total - last)
                        last = total
                    }
                } catch (e: Exception) {
                    if (!cancelRequested) rep.fail(entry.path, e)
                    ok = false
                    // Remove the partial copy rather than leave a truncated file behind.
                    runCatching { sftp.delete(targetPath, false) }
                }
            }
            rep.itemDone()
        }
        return ok
    }

    // ---- copy / move between hosts ----

    /**
     * Copies [items] from [source] (a different connection) into [destination] on [dst].
     * With [deleteSource] it is a move: afterwards every selected item whose whole subtree
     * copied without a single failure is removed from the source; the rest stay put.
     */
    private fun runAcross(
        source: SftpSource,
        dst: SftpClient,
        rep: Reporter,
        items: List<RemoteEntry>,
        destination: String,
        deleteSource: Boolean,
    ) {
        val src = source.openSftp()
        if (src == null) {
            // The host the items came from is no longer connected.
            rep.fail("", TransferErrorKind.CONNECTION_LOST)
            return
        }
        try {
            val dest = RemotePath.normalize(destination)
            val plan = scan(src, rep, items, skipLinkedFolders = true)
            if (rep.stopped) return
            val existing = existingNames(dst, rep, dest) ?: return
            rep.startRunning()

            // Which selected item each plan entry belongs to, so a failure deep inside a
            // folder keeps that one item (and only it) from being deleted afterwards.
            val rootOf = IntArray(plan.size)
            for (i in plan.indices) {
                rootOf[i] = if (plan[i].parentIndex < 0) i else rootOf[plan[i].parentIndex]
            }
            val failedRoots = HashSet<Int>()
            copyPlanAcross(src, dst, rep, plan, dest, existing, rootOf, failedRoots)
            if (!deleteSource || rep.stopped) return

            val remap = IntArray(plan.size) { -1 }
            val doomed = ArrayList<PlanItem>()
            for (i in plan.indices) {
                if (rootOf[i] in failedRoots) continue
                remap[i] = doomed.size
                val parent = plan[i].parentIndex
                doomed.add(PlanItem(plan[i].entry, if (parent < 0) -1 else remap[parent]))
            }
            if (doomed.isNotEmpty()) deletePlan(src, rep, doomed, countProgress = false)
        } finally {
            src.close()
        }
    }

    private fun copyPlanAcross(
        src: SftpClient,
        dst: SftpClient,
        rep: Reporter,
        plan: List<PlanItem>,
        destination: String,
        existing: MutableSet<String>,
        rootOf: IntArray,
        failedRoots: MutableSet<Int>,
    ) {
        val targets = HashMap<Int, String>()
        for (index in plan.indices) {
            if (rep.stopped) return
            val item = plan[index]
            val entry = item.entry
            val root = rootOf[index]
            val parentPath: String?
            val name: String
            if (item.parentIndex < 0) {
                parentPath = destination
                name = RemotePath.uniqueName(existing, entry.name)
                existing.add(name)
            } else {
                parentPath = targets[item.parentIndex]
                name = entry.name
            }
            if (parentPath == null) {
                // Its folder could not be created; already reported.
                failedRoots.add(root)
                rep.itemDone()
                continue
            }
            val targetPath = RemotePath.join(parentPath, name)
            rep.begin(entry.name)
            if (entry.isDirectory) {
                try {
                    dst.makeDirectory(targetPath)
                    targets[index] = targetPath
                } catch (e: Exception) {
                    rep.fail(entry.path, e)
                    failedRoots.add(root)
                }
            } else {
                try {
                    var last = 0L
                    src.copyFileTo(entry.path, dst, targetPath) { total ->
                        if (cancelRequested) throw StopRequested()
                        rep.bytes(total - last)
                        last = total
                    }
                } catch (e: Exception) {
                    if (!cancelRequested) rep.fail(entry.path, e)
                    failedRoots.add(root)
                    // Remove the partial copy rather than leave a truncated file behind.
                    runCatching { dst.delete(targetPath, false) }
                }
            }
            rep.itemDone()
        }
    }

    // ---- move ----

    private fun runMove(sftp: SftpClient, rep: Reporter, items: List<RemoteEntry>, destination: String) {
        val dest = RemotePath.normalize(destination)
        val valid = withoutIntoItself(rep, items, dest)
        val existing = existingNames(sftp, rep, dest) ?: return
        rep.startRunning(fixedItems = valid.size)
        for (entry in valid) {
            if (rep.stopped) break
            rep.begin(entry.name)
            if (RemotePath.parent(entry.path) == dest) {
                // Already in that folder; nothing to move.
                rep.itemDone()
                continue
            }
            val name = RemotePath.uniqueName(existing, entry.name)
            val target = RemotePath.join(dest, name)
            try {
                sftp.rename(entry.path, target)
                existing.add(name)
                rep.itemDone()
            } catch (renameFailure: Exception) {
                val kind = SftpClient.classify(renameFailure)
                val hopeless = kind == TransferErrorKind.PERMISSION_DENIED ||
                    kind == TransferErrorKind.NOT_FOUND ||
                    kind == TransferErrorKind.CONNECTION_LOST
                if (hopeless) {
                    rep.fail(entry.path, kind)
                    rep.itemDone()
                } else {
                    moveByCopying(sftp, rep, entry, dest, name, existing)
                }
            }
        }
    }

    /**
     * Rename can fail across filesystems. Fall back to copy-then-delete, and delete the
     * original only if every byte of the copy succeeded.
     */
    private fun moveByCopying(
        sftp: SftpClient,
        rep: Reporter,
        entry: RemoteEntry,
        destination: String,
        name: String,
        existing: MutableSet<String>,
    ) {
        // This one counted as a single item; its expansion replaces it.
        rep.totalItems--
        val plan = scan(sftp, rep, listOf(entry), skipLinkedFolders = true)
        if (rep.stopped) return
        val copied = copyPlan(sftp, rep, plan, destination, existing, forcedTopName = name)
        if (copied && !rep.stopped) {
            deletePlan(sftp, rep, plan, countProgress = false)
        }
    }

    // ---- rename ----

    private fun runRename(sftp: SftpClient, rep: Reporter, entry: RemoteEntry, newName: String) {
        rep.startRunning(fixedItems = 1)
        rep.begin(entry.name)
        if (!RemotePath.isValidEntryName(newName)) {
            rep.fail(entry.path, TransferErrorKind.UNKNOWN, BatchProblem.INVALID_NAME)
            return
        }
        if (newName == entry.name) {
            rep.itemDone()
            return
        }
        val parent = RemotePath.parent(entry.path)
        val existing = existingNames(sftp, rep, parent) ?: return
        if (newName in existing) {
            rep.fail(entry.path, TransferErrorKind.UNKNOWN, BatchProblem.ALREADY_EXISTS)
            return
        }
        try {
            sftp.rename(entry.path, RemotePath.join(parent, newName))
        } catch (e: Exception) {
            rep.fail(entry.path, e)
        }
        rep.itemDone()
    }

    // ---- new folder ----

    private fun runCreateFolder(sftp: SftpClient, rep: Reporter, parent: String, name: String) {
        val folderName = name.trim()
        rep.startRunning(fixedItems = 1)
        rep.begin(folderName)
        if (!RemotePath.isValidEntryName(folderName)) {
            rep.fail(parent, TransferErrorKind.UNKNOWN, BatchProblem.INVALID_NAME)
            return
        }
        val target = RemotePath.join(parent, folderName)
        val existing = existingNames(sftp, rep, parent) ?: return
        if (folderName in existing) {
            rep.fail(target, TransferErrorKind.UNKNOWN, BatchProblem.ALREADY_EXISTS)
            return
        }
        try {
            sftp.makeDirectory(target)
        } catch (e: Exception) {
            rep.fail(target, e)
        }
        rep.itemDone()
    }

    private fun runCreateFile(sftp: SftpClient, rep: Reporter, parent: String, name: String) {
        val fileName = name.trim()
        rep.startRunning(fixedItems = 1)
        rep.begin(fileName)
        if (!RemotePath.isValidEntryName(fileName)) {
            rep.fail(parent, TransferErrorKind.UNKNOWN, BatchProblem.INVALID_NAME)
            return
        }
        val target = RemotePath.join(parent, fileName)
        val existing = existingNames(sftp, rep, parent) ?: return
        if (fileName in existing) {
            rep.fail(target, TransferErrorKind.UNKNOWN, BatchProblem.ALREADY_EXISTS)
            return
        }
        try {
            sftp.createEmptyFile(target)
        } catch (e: Exception) {
            rep.fail(target, e)
        }
        rep.itemDone()
    }

    // ---- archives ----

    /**
     * Packs [items] into a new `<name>.<format>` in [destination]. The archive is built in the
     * cache and uploaded in one piece under a temporary name, so a failure never leaves a broken
     * archive on the server.
     */
    fun compress(
        items: List<RemoteEntry>,
        destination: String,
        name: String,
        format: ArchiveFormat,
        level: CompressionLevel,
    ): Boolean = start(BatchKind.COMPRESS) { sftp, rep -> runCompress(sftp, rep, items, destination, name, format, level) }

    /** Unpacks each of [archives] next to itself, straight into its folder or into a new folder named after it. */
    fun extractArchives(archives: List<RemoteEntry>, intoFolder: Boolean): Boolean =
        start(BatchKind.EXTRACT) { sftp, rep -> runExtractArchives(sftp, rep, archives, intoFolder) }

    /**
     * Unpacks [roots] (inner paths; null for everything) of an already opened archive into
     * [destination]. Used by "Extract" inside the archive view and by pasting items copied there.
     */
    fun extractFromHandle(handle: ArchiveHandle, roots: List<String>?, destination: String, intoFolder: Boolean): Boolean {
        val held = handle.retain()
        val folder = if (intoFolder) ArchiveFormat.baseName(held.name) else null
        val started = start(BatchKind.EXTRACT, cleanup = { held.release() }) { sftp, rep ->
            runExtractHandle(sftp, rep, held, roots, RemotePath.normalize(destination), folder)
        }
        if (!started) held.release()
        return started
    }

    /** Removes [paths] (files, or folders with everything inside) from the archive, on the server. */
    fun archiveDelete(handle: ArchiveHandle, paths: List<String>): Boolean {
        val held = handle.retain()
        val started = start(BatchKind.ARCHIVE_EDIT, cleanup = { held.release() }) { sftp, rep ->
            runArchiveEdit(sftp, rep, held, remove = paths.toSet(), put = null, items = paths.size)
        }
        if (!started) held.release()
        return started
    }

    /** Stores [data] as the entry [path] (replacing it, or adding it), on the server. */
    fun archiveSave(handle: ArchiveHandle, path: String, data: ByteArray): Boolean {
        val held = handle.retain()
        val started = start(BatchKind.ARCHIVE_EDIT, cleanup = { held.release() }) { sftp, rep ->
            runArchiveEdit(sftp, rep, held, remove = emptySet(), put = path to data, items = 1)
        }
        if (!started) held.release()
        return started
    }

    private fun runCompress(
        sftp: SftpClient,
        rep: Reporter,
        items: List<RemoteEntry>,
        destination: String,
        baseName: String,
        format: ArchiveFormat,
        level: CompressionLevel,
    ) {
        val dest = RemotePath.normalize(destination)
        val plan = scan(sftp, rep, items, skipLinkedFolders = true)
        if (rep.stopped) return
        val existing = existingNames(sftp, rep, dest) ?: return
        val outName = RemotePath.uniqueName(existing, baseName + format.suffix)
        val work = ArchiveHandle.workDir(cacheDir)
        try {
            // Worst case the data does not shrink at all.
            ArchiveHandle.requireSpace(work, rep.totalBytes)
        } catch (e: Exception) {
            rep.fail("", e)
            return
        }
        val packed = File.createTempFile("pack", format.suffix, work)
        try {
            rep.startRunning()
            if (!buildArchive(sftp, rep, plan, packed, format, level) || rep.stopped) return
            rep.resetBytes(packed.length())
            uploadNew(sftp, rep, packed, RemotePath.join(dest, outName))
        } finally {
            packed.delete()
        }
    }

    /** Streams every planned file into [target]. False when it could not be completed. */
    private fun buildArchive(
        sftp: SftpClient,
        rep: Reporter,
        plan: List<PlanItem>,
        target: File,
        format: ArchiveFormat,
        level: CompressionLevel,
    ): Boolean {
        val topNames = HashSet<String>()
        val paths = arrayOfNulls<String>(plan.size)
        val work = target.parentFile
        val writer = ArchiveEngine.create(target, format, level, cancelled = { rep.stopped })
        try {
            for (index in plan.indices) {
                if (rep.stopped) break
                val item = plan[index]
                val entry = item.entry
                val parentPath: String? = if (item.parentIndex < 0) "" else paths[item.parentIndex]
                if (parentPath == null) {
                    // Its folder was skipped or failed; already reported.
                    rep.itemDone()
                    continue
                }
                val path = if (item.parentIndex < 0) {
                    RemotePath.uniqueName(topNames, entry.name).also { topNames.add(it) }
                } else {
                    ArchivePaths.join(parentPath, entry.name)
                }
                rep.begin(entry.name)
                val mode = ArchivePlanner.modeFromPermissionString(entry.permissions)
                if (entry.isDirectory) {
                    writer.directory(path, entry.modifiedEpochSeconds, mode)
                    paths[index] = path
                } else {
                    // Each file is fetched whole before it is added, so a read that fails halfway
                    // costs that one file and never leaves a half-written entry in the archive.
                    val stage = File.createTempFile("stage", ".tmp", work)
                    try {
                        val fetched = try {
                            FileOutputStream(stage).use { out ->
                                var last = 0L
                                sftp.download(entry.path, out, resumeFrom = 0L) { total ->
                                    if (cancelRequested) throw StopRequested()
                                    rep.bytes(total - last)
                                    last = total
                                }
                            }
                            true
                        } catch (e: Exception) {
                            if (!cancelRequested) rep.fail(entry.path, e)
                            false
                        }
                        if (fetched) {
                            FileInputStream(stage).use {
                                writer.file(path, stage.length(), entry.modifiedEpochSeconds, mode, it)
                            }
                        }
                    } finally {
                        stage.delete()
                    }
                }
                rep.itemDone()
            }
        } catch (e: ArchiveCancelled) {
            return false
        } finally {
            // A stopped build is thrown away, so a complaint while closing it does not matter.
            if (rep.stopped) runCatching { writer.close() } else writer.close()
        }
        return !rep.stopped
    }

    /** Uploads [local] as [remoteFinal] through a temporary name, so the final name only ever holds a whole file. */
    private fun uploadNew(sftp: SftpClient, rep: Reporter, local: File, remoteFinal: String) {
        val temp = partName(remoteFinal)
        try {
            uploadFile(sftp, rep, local, temp)
            sftp.rename(temp, remoteFinal)
        } catch (e: Exception) {
            runCatching { sftp.delete(temp, false) }
            if (!cancelRequested) rep.fail(remoteFinal, e)
        }
    }

    private fun partName(remoteFinal: String): String =
        RemotePath.join(
            RemotePath.parent(remoteFinal),
            ".${RemotePath.name(remoteFinal)}.${UUID.randomUUID().toString().take(8)}.part",
        )

    /** Uploads [local] to [remote] and checks the server ended up with every byte. Throws on any problem. */
    private fun uploadFile(sftp: SftpClient, rep: Reporter, local: File, remote: String) {
        FileInputStream(local).use { input ->
            var last = 0L
            sftp.upload(input, remote, 0L) { total ->
                if (cancelRequested) throw StopRequested()
                rep.bytes(total - last)
                last = total
            }
        }
        if (sftp.size(remote) != local.length()) throw TransferFailure(TransferErrorKind.UNKNOWN, "upload incomplete")
    }

    private fun runExtractArchives(sftp: SftpClient, rep: Reporter, archives: List<RemoteEntry>, intoFolder: Boolean) {
        for (archive in archives) {
            if (rep.stopped) break
            val format = ArchiveFormat.fromFileName(archive.name) ?: continue
            rep.preparing()
            rep.begin(archive.name)
            val handle = try {
                ArchiveHandle.fetch(sftp, archive.path, format, cacheDir) {
                    if (cancelRequested) throw StopRequested()
                }
            } catch (e: Exception) {
                if (!cancelRequested) rep.fail(archive.path, e)
                continue
            }
            try {
                val folder = if (intoFolder) ArchiveFormat.baseName(archive.name) else null
                runExtractHandle(sftp, rep, handle, null, RemotePath.parent(archive.path), folder)
            } finally {
                handle.release()
            }
        }
    }

    private fun runExtractHandle(
        sftp: SftpClient,
        rep: Reporter,
        handle: ArchiveHandle,
        roots: List<String>?,
        destination: String,
        folderName: String?,
    ) {
        val existing = existingNames(sftp, rep, destination) ?: return
        var base = destination
        val taken: MutableSet<String>
        if (folderName != null) {
            val folder = RemotePath.uniqueName(existing, folderName)
            base = RemotePath.join(destination, folder)
            try {
                sftp.makeDirectory(base)
            } catch (e: Exception) {
                rep.fail(base, e)
                return
            }
            taken = HashSet()
        } else {
            taken = existing
        }
        val plan = ArchivePlanner.plan(handle.index, roots, taken)
        rep.totalItems = rep.doneItems + plan.itemCount
        rep.resetBytes(plan.totalBytes)
        rep.startRunning()
        try {
            ArchiveEngine.extract(handle.file, handle.format, plan.outputs, RemoteSink(sftp, rep, base)) { rep.stopped }
        } catch (e: ArchiveCancelled) {
            // The user stopped it, or the connection went; the report already says which.
        } catch (e: Exception) {
            if (!rep.stopped) rep.fail(handle.remotePath, e)
        }
    }

    /** Writes what the engine unpacks straight to the server, one file at a time. */
    private inner class RemoteSink(
        private val sftp: SftpClient,
        private val rep: Reporter,
        private val base: String,
    ) : ExtractSink {
        private val made = HashSet<String>().apply { add(base) }

        private fun ensureDir(path: String) {
            if (path in made) return
            ensureDir(RemotePath.parent(path))
            try {
                sftp.makeDirectory(path)
            } catch (e: Exception) {
                // Already there (a folder entry after its files, or a folder from an earlier run) is fine.
                if (!sftp.isDirectoryFollowingLinks(path)) throw e
            }
            made.add(path)
        }

        override fun directory(relativePath: String, entry: ArchiveEntry) {
            rep.begin(entry.name)
            try {
                ensureDir(RemotePath.join(base, relativePath))
            } catch (e: Exception) {
                if (!rep.stopped) rep.fail(entry.path, e)
            }
            rep.itemDone()
        }

        override fun file(relativePath: String, entry: ArchiveEntry, content: java.io.InputStream) {
            rep.begin(entry.name)
            val target = RemotePath.join(base, relativePath)
            try {
                ensureDir(RemotePath.parent(target))
                var last = 0L
                sftp.upload(content, target, 0L) { total ->
                    rep.bytes(total - last)
                    last = total
                }
                val mode = ArchivePlanner.extractedFileMode(entry.mode)
                if (mode != 0) runCatching { sftp.setPermissions(target, mode) }
                if (entry.modifiedEpochSeconds > 0L) runCatching { sftp.setModified(target, entry.modifiedEpochSeconds) }
            } catch (e: Exception) {
                // Never leave a truncated file that looks like a finished one.
                runCatching { sftp.delete(target, false) }
                if (!rep.stopped) rep.fail(entry.path, e)
            }
            rep.itemDone()
        }

        override fun skipped(entry: ArchiveEntry, problem: ArchiveProblem) {
            rep.fail(entry.path, ArchiveException(problem))
            rep.itemDone()
        }
    }

    /**
     * Rewrites the archive without [remove] and/or with [put] added, then swaps it onto the
     * server. The original is only touched once the whole new file is up and checked.
     */
    private fun runArchiveEdit(
        sftp: SftpClient,
        rep: Reporter,
        handle: ArchiveHandle,
        remove: Set<String>,
        put: Pair<String, ByteArray>?,
        items: Int,
    ) {
        rep.resetBytes(handle.file.length())
        rep.startRunning(fixedItems = items)
        rep.begin(handle.name)
        val work = ArchiveHandle.workDir(cacheDir)
        var edited: File? = null
        var rewritten: File? = null
        var committed = false
        try {
            ArchiveHandle.requireSpace(work, handle.file.length() + (put?.second?.size ?: 0))
            val puts = if (put != null) {
                val data = File.createTempFile("entry", ".tmp", work).also { edited = it }
                data.writeBytes(put.second)
                listOf(ArchivePut(put.first, data, System.currentTimeMillis() / 1000L, handle.index[put.first]?.mode ?: 0))
            } else {
                emptyList()
            }
            val out = File.createTempFile("edit", handle.format.suffix, work).also { rewritten = it }
            ArchiveEngine.rewrite(
                handle.file, handle.format, out, remove, puts, CompressionLevel.NORMAL,
                cancelled = { rep.stopped },
                onBytes = { rep.bytes(it) },
            )
            committed = commitArchive(sftp, rep, handle, out)
            if (committed) rep.doneItems = items
        } catch (e: ArchiveCancelled) {
            // stopped on request
        } catch (e: Exception) {
            if (!rep.stopped) rep.fail(handle.remotePath, e)
        } catch (e: OutOfMemoryError) {
            rep.fail(handle.remotePath, TransferErrorKind.OUT_OF_SPACE)
        } finally {
            edited?.delete()
            if (!committed) rewritten?.delete()
        }
    }

    /**
     * Puts [newLocal] in place of the archive on the server and hands the new copy to the
     * controller. False (nothing changed on the server) when the archive changed meanwhile or
     * the upload failed.
     */
    private fun commitArchive(sftp: SftpClient, rep: Reporter, handle: ArchiveHandle, newLocal: File): Boolean {
        val remote = handle.remotePath
        val before = try {
            sftp.statDetailed(remote)
        } catch (e: Exception) {
            rep.fail(remote, e)
            return false
        }
        if (before.sizeBytes != handle.remoteSize || before.modifiedEpochSeconds != handle.remoteModified) {
            rep.fail(remote, TransferErrorKind.ARCHIVE_CHANGED)
            return false
        }
        val temp = partName(remote)
        rep.resetBytes(newLocal.length())
        try {
            uploadFile(sftp, rep, newLocal, temp)
        } catch (e: Exception) {
            runCatching { sftp.delete(temp, false) }
            if (!cancelRequested) rep.fail(remote, e)
            return false
        }
        if (cancelRequested) {
            runCatching { sftp.delete(temp, false) }
            return false
        }
        // SFTP will not rename over an existing file, so the old one goes first. Until the rename
        // lands, the complete new archive is safe under the temporary name.
        try {
            sftp.delete(remote, false)
        } catch (e: Exception) {
            runCatching { sftp.delete(temp, false) }
            rep.fail(remote, e)
            return false
        }
        try {
            try {
                sftp.rename(temp, remote)
            } catch (first: Exception) {
                sftp.rename(temp, remote)
            }
        } catch (e: Exception) {
            rep.fail(remote, e)
            rep.fail(temp, TransferErrorKind.UNKNOWN)
            return false
        }
        runCatching { sftp.setPermissions(remote, before.permissionsOctal.toInt(8)) }
        return try {
            val after = sftp.statDetailed(remote)
            val index = ArchiveIndex(ArchiveEngine.list(newLocal, handle.format))
            onArchiveCommitted(
                handle,
                ArchiveHandle(remote, handle.format, newLocal, after.sizeBytes, after.modifiedEpochSeconds, index),
            )
            true
        } catch (e: Exception) {
            rep.fail(remote, e)
            false
        }
    }

    private companion object {
        const val PUBLISH_INTERVAL_MS = 150L
        const val MAX_DEPTH = 64
    }
}
