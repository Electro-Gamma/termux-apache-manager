package app.terminalssh.secure.serial

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * The Ctrl / Alt latches of the extra-keys bar: tap CTRL, then press `c` on the soft
 * keyboard to send ^C. A latch applies to exactly one following key and then releases.
 *
 * Pure Kotlin, so the mapping can be unit-tested without a device. The SSH session carries
 * its own copy of this logic; this one serves the serial session.
 */
class ControlKeyLatch {
    private val _ctrl = MutableStateFlow(false)
    val ctrl: StateFlow<Boolean> = _ctrl.asStateFlow()
    private val _alt = MutableStateFlow(false)
    val alt: StateFlow<Boolean> = _alt.asStateFlow()

    fun toggleCtrl() { _ctrl.value = !_ctrl.value; _alt.value = false }
    fun toggleAlt() { _alt.value = !_alt.value; _ctrl.value = false }

    /** Returns [bytes] with a latched modifier applied, and releases the latches. */
    fun apply(bytes: ByteArray): ByteArray {
        val ctrl = _ctrl.value
        val alt = _alt.value
        if (!ctrl && !alt) return bytes
        _ctrl.value = false
        _alt.value = false
        if (ctrl && bytes.size == 1) {
            val code = controlCode(bytes[0].toInt().toChar())
            if (code >= 0) return byteArrayOf(code.toByte())
        } else if (alt && bytes.isNotEmpty() && bytes[0] != ESC) {
            return byteArrayOf(ESC) + bytes
        }
        return bytes
    }

    companion object {
        private const val ESC: Byte = 0x1B

        /** The control character for [c] (`c` -> 0x03), or -1 when there is none. */
        fun controlCode(c: Char): Int = when (c) {
            in 'a'..'z' -> c - 'a' + 1
            in 'A'..'Z' -> c - 'A' + 1
            '@', ' ' -> 0
            '[' -> 27
            '\\' -> 28
            ']' -> 29
            '^' -> 30
            '_', '/' -> 31
            '?' -> 127
            else -> -1
        }
    }
}
