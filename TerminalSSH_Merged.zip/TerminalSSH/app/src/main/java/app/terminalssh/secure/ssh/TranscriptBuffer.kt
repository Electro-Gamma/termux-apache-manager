package app.terminalssh.secure.ssh

import java.nio.ByteBuffer
import java.nio.CharBuffer
import java.nio.charset.CodingErrorAction

/**
 * A plain-text record of everything a terminal session has shown, with no limit of one
 * screen.
 *
 * The terminal component's own selection only reaches the rows it is drawing. This keeps the
 * whole output as text — control sequences removed, carriage returns, backspaces and the
 * common erase/cursor-move sequences applied so a shell prompt being edited reads as the
 * user saw it — so "copy all" and "select all" cover the whole session.
 *
 * Full-screen programs (vim, top) repaint with cursor addressing, which a line transcript
 * cannot reproduce; their output is kept as readable text but is not a faithful picture.
 *
 * Oldest lines are dropped once [maxChars] is exceeded.
 */
class TranscriptBuffer(private val maxChars: Int = DEFAULT_MAX_CHARS) {

    private enum class Mode { TEXT, ESC, CSI, STRING, STRING_ESC, SKIP_ONE }

    private val lock = Any()
    private val lines = ArrayDeque<String>()
    private var storedChars = 0L
    private val current = StringBuilder()
    private var column = 0
    private var mode = Mode.TEXT
    private val params = StringBuilder()

    private val decoder = Charsets.UTF_8.newDecoder()
        .onMalformedInput(CodingErrorAction.REPLACE)
        .onUnmappableCharacter(CodingErrorAction.REPLACE)
    private var carry = ByteArray(0)

    fun append(bytes: ByteArray, length: Int = bytes.size) {
        if (length <= 0) return
        synchronized(lock) {
            val input = ByteBuffer.wrap(carry + bytes.copyOf(length))
            val out = CharBuffer.allocate(input.remaining() + 1)
            decoder.reset()
            decoder.decode(input, out, false)
            carry = ByteArray(input.remaining()).also { input.get(it) }
            out.flip()
            while (out.hasRemaining()) feed(out.get())
        }
    }

    /** Everything recorded so far, oldest first. */
    fun text(): String = synchronized(lock) {
        val all = StringBuilder(storedChars.toInt() + current.length + 16)
        for (line in lines) all.append(line).append('\n')
        all.append(current.toString().trimEnd())
        all.toString().trimEnd('\n', ' ')
    }

    fun clear() = synchronized(lock) {
        lines.clear()
        storedChars = 0
        current.setLength(0)
        column = 0
        mode = Mode.TEXT
        params.setLength(0)
        carry = ByteArray(0)
    }

    private fun feed(c: Char) {
        when (mode) {
            Mode.TEXT -> text(c)
            Mode.ESC -> when (c) {
                '[' -> { mode = Mode.CSI; params.setLength(0) }
                ']', 'P', '^', '_', 'X' -> mode = Mode.STRING
                '(', ')', '*', '+', '#', '%' -> mode = Mode.SKIP_ONE
                else -> mode = Mode.TEXT
            }
            Mode.SKIP_ONE -> mode = Mode.TEXT
            Mode.CSI -> when (c) {
                in '\u0020'..'\u003F' -> if (params.length < 32) params.append(c)
                in '\u0040'..'\u007E' -> { csi(c); mode = Mode.TEXT }
                else -> mode = Mode.TEXT
            }
            Mode.STRING -> when (c) {
                '\u0007' -> mode = Mode.TEXT
                '\u001b' -> mode = Mode.STRING_ESC
            }
            Mode.STRING_ESC -> mode = if (c == '\\') Mode.TEXT else Mode.STRING
        }
    }

    private fun text(c: Char) {
        when {
            c == '\u001b' -> mode = Mode.ESC
            c == '\n' -> commitLine()
            c == '\r' -> column = 0
            c == '\b' -> if (column > 0) column--
            c == '\t' -> {
                val next = (column / TAB + 1) * TAB
                while (column < next) put(' ')
            }
            c < ' ' || c == '\u007f' -> Unit
            else -> put(c)
        }
    }

    private fun put(c: Char) {
        while (current.length < column) current.append(' ')
        if (column < current.length) current.setCharAt(column, c) else current.append(c)
        column++
    }

    private fun csi(final: Char) {
        val p = params.toString()
        if (p.startsWith("?") || p.startsWith(">") || p.startsWith("<") || p.startsWith("=")) return
        val n = p.substringBefore(';').toIntOrNull()
        when (final) {
            'K' -> when (n ?: 0) {
                0 -> if (column < current.length) current.setLength(column)
                1 -> for (i in 0 until minOf(column + 1, current.length)) current.setCharAt(i, ' ')
                2 -> current.setLength(0)
            }
            'C' -> column += (n ?: 1).coerceIn(1, 500)
            'D' -> column = (column - (n ?: 1).coerceIn(1, 500)).coerceAtLeast(0)
            'G' -> column = ((n ?: 1) - 1).coerceIn(0, 500)
            'P' -> {
                val count = (n ?: 1).coerceAtLeast(1)
                if (column < current.length) current.delete(column, minOf(column + count, current.length))
            }
            '@' -> {
                val count = (n ?: 1).coerceIn(1, 500)
                while (current.length < column) current.append(' ')
                current.insert(column, " ".repeat(count))
            }
        }
    }

    private fun commitLine() {
        val line = current.toString().trimEnd()
        lines.addLast(line)
        storedChars += line.length + 1
        current.setLength(0)
        column = 0
        while (storedChars > maxChars && lines.size > 1) {
            storedChars -= lines.removeFirst().length + 1
        }
    }

    companion object {
        const val DEFAULT_MAX_CHARS = 4_000_000
        private const val TAB = 8
    }
}
