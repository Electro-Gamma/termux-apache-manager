package app.terminalssh.secure.serial

import android.content.Context
import org.json.JSONObject

/**
 * Remembers the serial settings used last, so the next connection starts from them.
 * Nothing here is secret: a baud rate and a few flags, kept in private SharedPreferences.
 */
class SerialSettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun load(): SerialSettings {
        val raw = prefs.getString(KEY, null) ?: return SerialSettings()
        val json = runCatching { JSONObject(raw) }.getOrNull() ?: return SerialSettings()
        val defaults = SerialSettings()
        return SerialSettings(
            baudRate = json.optInt("baud", defaults.baudRate).coerceAtLeast(SerialSettings.MIN_BAUD),
            dataBits = enumOr(json.optString("dataBits"), defaults.dataBits),
            stopBits = enumOr(json.optString("stopBits"), defaults.stopBits),
            parity = enumOr(json.optString("parity"), defaults.parity),
            flowControl = enumOr(json.optString("flow"), defaults.flowControl),
            dtrEnabled = json.optBoolean("dtr", defaults.dtrEnabled),
            rtsEnabled = json.optBoolean("rts", defaults.rtsEnabled),
        )
    }

    fun save(settings: SerialSettings) {
        val json = JSONObject().apply {
            put("baud", settings.baudRate)
            put("dataBits", settings.dataBits.name)
            put("stopBits", settings.stopBits.name)
            put("parity", settings.parity.name)
            put("flow", settings.flowControl.name)
            put("dtr", settings.dtrEnabled)
            put("rts", settings.rtsEnabled)
        }
        prefs.edit().putString(KEY, json.toString()).apply()
    }

    private inline fun <reified E : Enum<E>> enumOr(name: String, fallback: E): E =
        runCatching { enumValueOf<E>(name) }.getOrDefault(fallback)

    private companion object {
        const val PREFS = "serial_v1"
        const val KEY = "last_settings"
    }
}
