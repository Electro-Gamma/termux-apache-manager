package app.terminalssh.secure.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Usb
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import app.terminalssh.secure.R
import app.terminalssh.secure.serial.DataBits
import app.terminalssh.secure.serial.FlowControl
import app.terminalssh.secure.serial.Parity
import app.terminalssh.secure.serial.SerialSettings
import app.terminalssh.secure.serial.StopBits
import app.terminalssh.secure.ui.theme.Danger
import app.terminalssh.secure.ui.theme.Stroke
import app.terminalssh.secure.ui.theme.TextSecondary
import app.terminalssh.secure.ui.theme.Turquoise
import app.terminalssh.secure.vm.AppViewModel

/** The way into UART mode, shown inside the New connection sheet. */
@Composable
fun SerialEntryCard(onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, Stroke),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(role = Role.Button, onClick = onClick),
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
        ) {
            Icon(Icons.Outlined.Usb, contentDescription = null, tint = Turquoise, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    stringResource(R.string.serial_entry_title),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                )
                Text(
                    stringResource(R.string.serial_entry_hint),
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                )
            }
        }
    }
}

/**
 * Pick a plugged-in USB-to-UART adapter, check the line settings, connect. The list follows
 * the adapter being plugged in or pulled out while the dialog is open.
 */
@Composable
fun SerialConnectDialog(viewModel: AppViewModel, onDismiss: () -> Unit) {
    val usb = viewModel.usb
    var candidates by remember { mutableStateOf(usb.candidates()) }
    var selectedName by remember { mutableStateOf<String?>(null) }
    var settings by remember { mutableStateOf(viewModel.lastSerialSettings()) }
    val hostSupported = remember { usb.isUsbHostSupported() }

    LaunchedEffect(usb) { usb.events.collect { candidates = usb.candidates() } }

    val chosen = candidates.firstOrNull { it.deviceName == selectedName } ?: candidates.firstOrNull()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.serial_entry_title)) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                when {
                    !hostSupported -> Text(
                        stringResource(R.string.serial_no_usb_host),
                        style = MaterialTheme.typography.bodyMedium,
                        color = Danger,
                    )

                    candidates.isEmpty() -> {
                        Text(
                            stringResource(R.string.serial_no_device),
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary,
                        )
                        TextButton(onClick = { candidates = usb.candidates() }) {
                            Text(stringResource(R.string.serial_refresh))
                        }
                    }

                    else -> {
                        Text(stringResource(R.string.serial_adapter), style = MaterialTheme.typography.labelLarge)
                        candidates.forEach { candidate ->
                            val isSelected = candidate.deviceName == chosen?.deviceName
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable(role = Role.RadioButton) { selectedName = candidate.deviceName }
                                    .padding(vertical = 4.dp),
                            ) {
                                RadioButton(selected = isSelected, onClick = null)
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(ltr(candidate.name), style = MaterialTheme.typography.bodyMedium, maxLines = 1)
                                    Text(
                                        ltr("${candidate.chip} · ${candidate.usbId}"),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextSecondary,
                                        fontFamily = FontFamily.Monospace,
                                        maxLines = 1,
                                    )
                                }
                            }
                        }
                        SerialSettingsFields(settings) { settings = it }
                        Text(
                            stringResource(R.string.serial_ttl_hint),
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = chosen != null,
                onClick = {
                    chosen?.let { viewModel.openSerial(it, settings.normalized()) }
                    onDismiss()
                },
            ) { Text(stringResource(R.string.serial_connect)) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
        },
        containerColor = MaterialTheme.colorScheme.surface,
    )
}

/**
 * Line settings of a port that is already open, reached by tapping the settings line under
 * the tab strip. A wrong baud rate is the usual reason a console prints garbage, so it can be
 * fixed in place without disconnecting.
 */
@Composable
fun SerialSettingsDialog(
    title: String,
    initial: SerialSettings,
    confirmLabel: String,
    onDismiss: () -> Unit,
    onConfirm: (SerialSettings) -> Unit,
    /** Non-null while connected: shows a Disconnect button at the top. */
    onDisconnect: (() -> Unit)? = null,
) {
    var settings by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                if (onDisconnect != null) {
                    Button(
                        onClick = {
                            onDisconnect()
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.error,
                            contentColor = MaterialTheme.colorScheme.onError,
                        ),
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text(stringResource(R.string.serial_disconnect)) }
                }
                SerialSettingsFields(settings) { settings = it }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onConfirm(settings.normalized())
                onDismiss()
            }) { Text(confirmLabel) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
        },
        containerColor = MaterialTheme.colorScheme.surface,
    )
}

private fun SerialSettings.normalized(): SerialSettings =
    copy(baudRate = baudRate.coerceAtLeast(SerialSettings.MIN_BAUD))

/** The shared form: baud rate, data bits, parity, stop bits, flow control, DTR/RTS. */
@Composable
private fun SerialSettingsFields(value: SerialSettings, onChange: (SerialSettings) -> Unit) {
    var baudText by remember { mutableStateOf(value.baudRate.toString()) }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Column {
            Text(stringResource(R.string.serial_baud), style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.size(4.dp))
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                SerialSettings.COMMON_BAUD_RATES.forEach { rate ->
                    FilterChip(
                        selected = value.baudRate == rate,
                        onClick = {
                            baudText = rate.toString()
                            onChange(value.copy(baudRate = rate))
                        },
                        label = { Text(rate.toString()) },
                    )
                }
            }
            Spacer(Modifier.size(8.dp))
            OutlinedTextField(
                value = baudText,
                onValueChange = { text ->
                    val digits = text.filter { it.isDigit() }.take(8)
                    baudText = digits
                    digits.toIntOrNull()?.let { onChange(value.copy(baudRate = it)) }
                },
                label = { Text(stringResource(R.string.serial_custom_baud)) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth(),
            )
        }

        ChipGroup(stringResource(R.string.serial_data_bits), DataBits.entries, value.dataBits, { it.label }) {
            onChange(value.copy(dataBits = it))
        }
        ChipGroup(stringResource(R.string.serial_parity), Parity.entries, value.parity, { it.label }) {
            onChange(value.copy(parity = it))
        }
        ChipGroup(stringResource(R.string.serial_stop_bits), StopBits.entries, value.stopBits, { it.label }) {
            onChange(value.copy(stopBits = it))
        }
        ChipGroup(stringResource(R.string.serial_flow), FlowControl.entries, value.flowControl, { it.label }) {
            onChange(value.copy(flowControl = it))
        }

        Column {
            Text(stringResource(R.string.serial_handshake), style = MaterialTheme.typography.labelLarge)
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Text("DTR", modifier = Modifier.weight(1f))
                Switch(checked = value.dtrEnabled, onCheckedChange = { onChange(value.copy(dtrEnabled = it)) })
            }
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Text("RTS", modifier = Modifier.weight(1f))
                Switch(checked = value.rtsEnabled, onCheckedChange = { onChange(value.copy(rtsEnabled = it)) })
            }
        }
    }
}

@Composable
private fun <T> ChipGroup(
    title: String,
    options: List<T>,
    selected: T,
    label: (T) -> String,
    onSelect: (T) -> Unit,
) {
    Column {
        Text(title, style = MaterialTheme.typography.labelLarge)
        Spacer(Modifier.size(4.dp))
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            options.forEach { option ->
                FilterChip(
                    selected = option == selected,
                    onClick = { onSelect(option) },
                    label = { Text(label(option)) },
                )
            }
        }
    }
}
