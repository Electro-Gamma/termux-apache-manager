package app.terminalssh.secure.archive

import org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry
import org.apache.commons.compress.archivers.sevenz.SevenZFile
import org.apache.commons.compress.archivers.sevenz.SevenZMethod
import org.apache.commons.compress.archivers.sevenz.SevenZMethodConfiguration
import org.apache.commons.compress.archivers.sevenz.SevenZOutputFile
import org.apache.commons.compress.archivers.tar.TarArchiveEntry
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream
import org.apache.commons.compress.archivers.zip.UnixStat
import org.apache.commons.compress.archivers.zip.UnsupportedZipFeatureException
import org.apache.commons.compress.archivers.zip.Zip64Mode
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry
import org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream
import org.apache.commons.compress.archivers.zip.ZipFile
import org.apache.commons.compress.PasswordRequiredException
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorOutputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorOutputStream
import org.apache.commons.compress.compressors.gzip.GzipParameters
import org.apache.commons.compress.compressors.lzma.LZMACompressorInputStream
import org.apache.commons.compress.compressors.lzma.LZMACompressorOutputStream
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream
import org.apache.commons.compress.compressors.xz.XZCompressorOutputStream
import org.tukaani.xz.LZMA2Options
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.Closeable
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.Date
import java.util.zip.Deflater
import java.util.zip.ZipEntry

/** Why an archive, or one item in it, could not be handled. */
enum class ArchiveProblem {
    /** Password-protected: not supported. */
    ENCRYPTED,

    /** A compression method or feature this build cannot read. */
    UNSUPPORTED,

    /** Damaged, truncated, or not really an archive of that type. */
    CORRUPT,

    /** A link, device or a name that climbs out of the folder: never extracted. */
    SKIPPED_ENTRY,
}

class ArchiveException(val problem: ArchiveProblem, message: String? = null, cause: Throwable? = null) :
    IOException(message ?: problem.name, cause)

/** Thrown from inside a copy loop when the caller asked to stop. */
class ArchiveCancelled : RuntimeException("archive operation cancelled")

/** Receives what [ArchiveEngine.extract] unpacks. Paths are relative and already safe. */
interface ExtractSink {
    fun directory(relativePath: String, entry: ArchiveEntry)

    /** Consume [content] completely (or fail). Closing it is a no-op; do not keep it after returning. */
    fun file(relativePath: String, entry: ArchiveEntry, content: InputStream)

    /** [entry] was in the plan but cannot be extracted ([problem] says why). */
    fun skipped(entry: ArchiveEntry, problem: ArchiveProblem)
}

/** An item to add to an archive that is being rewritten. [source] is null for a folder. */
class ArchivePut(
    val path: String,
    val source: File?,
    val modifiedEpochSeconds: Long,
    val mode: Int = 0,
) {
    val isDirectory: Boolean get() = source == null
}

/**
 * Reads, creates and rewrites `.zip`, `.tar` and `.7z` files on local storage.
 *
 * Pure JVM and file based, with no knowledge of SFTP or of Android: the File Manager stages a
 * remote archive in the cache, uses this on the local copy, and uploads the result. Entries are
 * identified by their [ArchiveEntry.ordinal] (position in the archive), so duplicate names and
 * odd spellings never confuse a lookup.
 */
object ArchiveEngine {

    private const val BUFFER_BYTES = 64 * 1024
    private const val DEFAULT_FILE_MODE = 420 // 0644
    private const val DEFAULT_DIR_MODE = 493 // 0755
    private const val UNIX_TYPE_MASK = 0xF000
    private const val UNIX_SYMLINK = 0xA000
    private const val SEVEN_Z_UNIX_EXTENSION = 0x8000

    // ------------------------------------------------------------------ listing

    /** Every entry of [file], in archive order. Reads headers only where the format allows it. */
    fun list(file: File, format: ArchiveFormat): List<ArchiveEntry> = guard {
        when (format) {
            ArchiveFormat.ZIP -> listZip(file)
            ArchiveFormat.SEVEN_Z -> listSevenZ(file)
            else -> listTar(file, format)
        }
    }

    private fun listZip(file: File): List<ArchiveEntry> {
        val out = ArrayList<ArchiveEntry>()
        openZip(file).use { zip ->
            var ordinal = 0
            val entries = zip.entries
            while (entries.hasMoreElements()) {
                out.add(zipEntry(entries.nextElement(), ordinal++))
            }
        }
        return out
    }

    private fun listTar(file: File, format: ArchiveFormat): List<ArchiveEntry> {
        val out = ArrayList<ArchiveEntry>()
        openTar(file, format).use { tar ->
            var ordinal = 0
            while (true) {
                val entry = tar.nextEntry ?: break
                out.add(tarEntry(entry, ordinal++))
            }
        }
        return out
    }

    private fun listSevenZ(file: File): List<ArchiveEntry> {
        val out = ArrayList<ArchiveEntry>()
        openSevenZ(file).use { sevenZ ->
            var ordinal = 0
            for (entry in sevenZ.entries) out.add(sevenZEntry(entry, ordinal++))
        }
        return out
    }

    // ------------------------------------------------------------------ openers

    private fun openZip(file: File): ZipFile =
        ZipFile.builder().setFile(file).setCharset(Charsets.UTF_8).get()

    /** The tar inside [file], decompressed on the fly for `.tar.gz`, `.tar.xz` and the like. */
    private fun openTar(file: File, format: ArchiveFormat): TarArchiveInputStream {
        val raw = BufferedInputStream(FileInputStream(file), BUFFER_BYTES)
        try {
            val plain: InputStream = when (format.tarCodec) {
                TarCodec.GZIP -> GzipCompressorInputStream(raw, true)
                TarCodec.BZIP2 -> BZip2CompressorInputStream(raw, true)
                TarCodec.XZ -> XZCompressorInputStream(raw, true)
                TarCodec.LZMA -> LZMACompressorInputStream(raw)
                else -> raw
            }
            return TarArchiveInputStream(BufferedInputStream(plain, BUFFER_BYTES), "UTF-8")
        } catch (e: Throwable) {
            raw.close()
            throw e
        }
    }

    private fun openSevenZ(file: File): SevenZFile = SevenZFile.builder().setFile(file).get()

    // ------------------------------------------------------------------ entry mapping

    private fun zipEntry(e: ZipArchiveEntry, ordinal: Int): ArchiveEntry {
        val (path, unsafe) = ArchivePaths.clean(e.name)
        val kind = when {
            e.isDirectory -> ArchiveEntryKind.DIRECTORY
            e.isUnixSymlink -> ArchiveEntryKind.LINK
            else -> ArchiveEntryKind.FILE
        }
        val millis = e.time
        return ArchiveEntry(
            path = path,
            kind = kind,
            size = if (e.size >= 0L) e.size else 0L,
            modifiedEpochSeconds = if (millis > 0L) millis / 1000L else 0L,
            mode = if (e.platform == ZipArchiveEntry.PLATFORM_UNIX) e.unixMode and 0xFFF else 0,
            unsafe = unsafe,
            ordinal = ordinal,
        )
    }

    private fun tarEntry(e: TarArchiveEntry, ordinal: Int): ArchiveEntry {
        val (path, unsafe) = ArchivePaths.clean(e.name)
        val kind = when {
            e.isDirectory -> ArchiveEntryKind.DIRECTORY
            e.isSymbolicLink || e.isLink -> ArchiveEntryKind.LINK
            e.isFile -> ArchiveEntryKind.FILE
            else -> ArchiveEntryKind.OTHER
        }
        val millis = e.modTime?.time ?: 0L
        return ArchiveEntry(
            path = path,
            kind = kind,
            size = if (kind == ArchiveEntryKind.FILE) e.size else 0L,
            modifiedEpochSeconds = if (millis > 0L) millis / 1000L else 0L,
            mode = e.mode and 0xFFF,
            unsafe = unsafe,
            ordinal = ordinal,
        )
    }

    private fun sevenZEntry(e: SevenZArchiveEntry, ordinal: Int): ArchiveEntry {
        val (path, unsafe) = ArchivePaths.clean(e.name ?: "")
        var mode = 0
        var link = false
        if (e.hasWindowsAttributes) {
            val attributes = e.windowsAttributes
            if (attributes and SEVEN_Z_UNIX_EXTENSION != 0) {
                val unixMode = attributes ushr 16
                mode = unixMode and 0xFFF
                link = unixMode and UNIX_TYPE_MASK == UNIX_SYMLINK
            }
        }
        val kind = when {
            e.isDirectory -> ArchiveEntryKind.DIRECTORY
            e.isAntiItem -> ArchiveEntryKind.OTHER
            link -> ArchiveEntryKind.LINK
            else -> ArchiveEntryKind.FILE
        }
        val millis = if (e.hasLastModifiedDate) e.lastModifiedDate.time else 0L
        return ArchiveEntry(
            path = path,
            kind = kind,
            size = if (kind == ArchiveEntryKind.FILE) e.size else 0L,
            modifiedEpochSeconds = if (millis > 0L) millis / 1000L else 0L,
            mode = mode,
            unsafe = unsafe,
            ordinal = ordinal,
        )
    }

    // ------------------------------------------------------------------ reading one entry

    /**
     * Runs [block] on the contents of [entry] without extracting anything to disk. The stream is
     * valid only inside [block]. Zip jumps straight to the entry; tar and 7z read up to it.
     */
    fun <T> readEntry(file: File, format: ArchiveFormat, entry: ArchiveEntry, block: (InputStream) -> T): T = guard {
        when (format) {
            ArchiveFormat.ZIP -> openZip(file).use { zip ->
                val target = nthZipEntry(zip, entry.ordinal)
                checkZipReadable(zip, target)
                zip.getInputStream(target).use(block)
            }
            ArchiveFormat.SEVEN_Z -> openSevenZ(file).use { sevenZ ->
                var ordinal = 0
                while (true) {
                    sevenZ.nextEntry ?: throw ArchiveException(ArchiveProblem.CORRUPT, "entry not found")
                    if (ordinal++ == entry.ordinal) break
                }
                block(SevenZStream(sevenZ))
            }
            else -> openTar(file, format).use { tar ->
                var ordinal = 0
                while (true) {
                    tar.nextEntry ?: throw ArchiveException(ArchiveProblem.CORRUPT, "entry not found")
                    if (ordinal++ == entry.ordinal) break
                }
                block(NonClosing(tar))
            }
        }
    }

    /** The whole content of [entry], refusing anything over [maxBytes] ([TooLargeException]). */
    fun readEntryBytes(file: File, format: ArchiveFormat, entry: ArchiveEntry, maxBytes: Int): ByteArray {
        if (entry.size > maxBytes) throw TooLargeException(entry.size)
        return readEntry(file, format, entry) { input ->
            val out = java.io.ByteArrayOutputStream(entry.size.coerceIn(0L, maxBytes.toLong()).toInt().coerceAtLeast(16))
            val buffer = ByteArray(BUFFER_BYTES)
            while (true) {
                val read = input.read(buffer)
                if (read < 0) break
                out.write(buffer, 0, read)
                if (out.size() > maxBytes) throw TooLargeException(out.size().toLong())
            }
            out.toByteArray()
        }
    }

    /** Streams [entry] to [target] (a cache file), stopping with [TooLargeException] past [maxBytes]. */
    fun readEntryToFile(
        file: File,
        format: ArchiveFormat,
        entry: ArchiveEntry,
        target: File,
        maxBytes: Long,
        onProgress: (Long) -> Unit = {},
    ) {
        if (entry.size > maxBytes) throw TooLargeException(entry.size)
        readEntry(file, format, entry) { input ->
            target.outputStream().use { out ->
                val buffer = ByteArray(BUFFER_BYTES)
                var total = 0L
                while (true) {
                    val read = input.read(buffer)
                    if (read < 0) break
                    out.write(buffer, 0, read)
                    total += read
                    if (total > maxBytes) throw TooLargeException(total)
                    onProgress(total)
                }
            }
        }
    }

    class TooLargeException(val sizeBytes: Long) : IOException("entry too large: $sizeBytes bytes")

    private fun nthZipEntry(zip: ZipFile, ordinal: Int): ZipArchiveEntry {
        val entries = zip.entries
        var i = 0
        while (entries.hasMoreElements()) {
            val next = entries.nextElement()
            if (i++ == ordinal) return next
        }
        throw ArchiveException(ArchiveProblem.CORRUPT, "entry not found")
    }

    private fun checkZipReadable(zip: ZipFile, entry: ZipArchiveEntry) {
        if (entry.generalPurposeBit.usesEncryption()) throw ArchiveException(ArchiveProblem.ENCRYPTED)
        if (!zip.canReadEntryData(entry)) throw ArchiveException(ArchiveProblem.UNSUPPORTED)
    }

    // ------------------------------------------------------------------ extracting

    /**
     * Unpacks the entries named by [plan] (archive ordinal to output-relative path) into [sink],
     * in one pass. Entries that cannot be recreated (links, devices, names that climb out) are
     * reported through [ExtractSink.skipped]. [cancelled] is polled between entries and between
     * buffers of a large one; when it turns true this throws [ArchiveCancelled].
     */
    fun extract(
        file: File,
        format: ArchiveFormat,
        plan: Map<Int, String>,
        sink: ExtractSink,
        cancelled: () -> Boolean,
    ) {
        if (plan.isEmpty()) return
        guard {
            when (format) {
                ArchiveFormat.ZIP -> extractZip(file, plan, sink, cancelled)
                ArchiveFormat.SEVEN_Z -> extractSevenZ(file, plan, sink, cancelled)
                else -> extractTar(file, format, plan, sink, cancelled)
            }
        }
    }

    private fun deliver(
        entry: ArchiveEntry,
        relativePath: String,
        sink: ExtractSink,
        cancelled: () -> Boolean,
        ownsStream: Boolean,
        open: () -> InputStream,
    ) {
        if (cancelled()) throw ArchiveCancelled()
        when {
            !entry.isExtractable -> sink.skipped(entry, ArchiveProblem.SKIPPED_ENTRY)
            entry.isDirectory -> sink.directory(relativePath, entry)
            else -> {
                val raw = try {
                    open()
                } catch (e: ArchiveException) {
                    sink.skipped(entry, e.problem)
                    return
                }
                try {
                    sink.file(relativePath, entry, CancellableStream(raw, cancelled))
                } finally {
                    // A zip entry's stream is its own object and must be released; tar and 7z hand
                    // out the one sequential stream, which the loop still needs.
                    if (ownsStream) runCatching { raw.close() }
                }
            }
        }
    }

    private fun extractZip(file: File, plan: Map<Int, String>, sink: ExtractSink, cancelled: () -> Boolean) {
        openZip(file).use { zip ->
            val entries = zip.entries
            var ordinal = 0
            var remaining = plan.size
            while (entries.hasMoreElements() && remaining > 0) {
                val raw = entries.nextElement()
                val at = ordinal++
                val relative = plan[at] ?: continue
                remaining--
                deliver(zipEntry(raw, at), relative, sink, cancelled, ownsStream = true) {
                    checkZipReadable(zip, raw)
                    zip.getInputStream(raw)
                }
            }
        }
    }

    private fun extractTar(file: File, format: ArchiveFormat, plan: Map<Int, String>, sink: ExtractSink, cancelled: () -> Boolean) {
        openTar(file, format).use { tar ->
            var ordinal = 0
            var remaining = plan.size
            while (remaining > 0) {
                val raw = tar.nextEntry ?: break
                val at = ordinal++
                val relative = plan[at] ?: continue
                remaining--
                deliver(tarEntry(raw, at), relative, sink, cancelled, ownsStream = false) { tar }
            }
        }
    }

    private fun extractSevenZ(file: File, plan: Map<Int, String>, sink: ExtractSink, cancelled: () -> Boolean) {
        openSevenZ(file).use { sevenZ ->
            var ordinal = 0
            var remaining = plan.size
            while (remaining > 0) {
                val raw = sevenZ.nextEntry ?: break
                val at = ordinal++
                val relative = plan[at] ?: continue
                remaining--
                deliver(sevenZEntry(raw, at), relative, sink, cancelled, ownsStream = false) { SevenZStream(sevenZ) }
            }
        }
    }

    // ------------------------------------------------------------------ writing

    /** A new archive being written to a local file. Close it to finish the archive. */
    interface Writer : Closeable {
        fun directory(path: String, modifiedEpochSeconds: Long, mode: Int = 0)

        /** [size] must be the exact number of bytes [content] will deliver (tar needs it up front). */
        fun file(path: String, size: Long, modifiedEpochSeconds: Long, mode: Int, content: InputStream)
    }

    /**
     * Starts a new archive at [target]. [level] picks the compression; plain tar has none, so
     * it ignores it. [cancelled] is polled while data is copied.
     */
    fun create(
        target: File,
        format: ArchiveFormat,
        level: CompressionLevel,
        cancelled: () -> Boolean = { false },
        onBytes: (Long) -> Unit = {},
    ): Writer = when (format) {
        ArchiveFormat.ZIP -> ZipWriter(ZipArchiveOutputStream(target), level, cancelled, onBytes)
        ArchiveFormat.SEVEN_Z -> SevenZWriter(newSevenZOutput(target, level), cancelled, onBytes)
        else -> TarWriter(newTarOutput(target, format, level), cancelled, onBytes)
    }

    private fun newTarOutput(target: File, format: ArchiveFormat, level: CompressionLevel): TarArchiveOutputStream {
        val file = BufferedOutputStream(FileOutputStream(target), BUFFER_BYTES)
        val packed: OutputStream = try {
            when (format.tarCodec) {
                TarCodec.GZIP -> GzipCompressorOutputStream(file, GzipParameters().apply {
                    compressionLevel = when (level) {
                        CompressionLevel.STORE -> Deflater.NO_COMPRESSION
                        CompressionLevel.FAST -> Deflater.BEST_SPEED
                        CompressionLevel.NORMAL -> 6
                        CompressionLevel.BEST -> Deflater.BEST_COMPRESSION
                    }
                })
                TarCodec.BZIP2 -> BZip2CompressorOutputStream(
                    file,
                    when (level) {
                        CompressionLevel.STORE, CompressionLevel.FAST -> 1
                        CompressionLevel.NORMAL -> 5
                        CompressionLevel.BEST -> 9
                    },
                )
                TarCodec.XZ -> XZCompressorOutputStream(
                    file,
                    when (level) {
                        CompressionLevel.STORE, CompressionLevel.FAST -> 1
                        CompressionLevel.NORMAL -> 3
                        CompressionLevel.BEST -> 6
                    },
                )
                TarCodec.LZMA -> LZMACompressorOutputStream(file)
                else -> file
            }
        } catch (e: Throwable) {
            file.close()
            throw e
        }
        val out = TarArchiveOutputStream(BufferedOutputStream(packed, BUFFER_BYTES), "UTF-8")
        out.setLongFileMode(TarArchiveOutputStream.LONGFILE_POSIX)
        out.setBigNumberMode(TarArchiveOutputStream.BIGNUMBER_POSIX)
        out.setAddPaxHeadersForNonAsciiNames(true)
        return out
    }

    private fun newSevenZOutput(target: File, level: CompressionLevel): SevenZOutputFile {
        val out = SevenZOutputFile(target)
        out.setContentMethods(sevenZMethods(level))
        return out
    }

    /**
     * LZMA2 with a preset kept modest on purpose: the compressor's memory grows quickly with the
     * preset (about 9 MB at 1, 32 MB at 3, 94 MB at 5), and a phone's heap is not a desktop's.
     */
    private fun sevenZMethods(level: CompressionLevel): List<SevenZMethodConfiguration> = when (level) {
        CompressionLevel.STORE -> listOf(SevenZMethodConfiguration(SevenZMethod.COPY))
        CompressionLevel.FAST -> listOf(SevenZMethodConfiguration(SevenZMethod.LZMA2, LZMA2Options(1)))
        CompressionLevel.NORMAL -> listOf(SevenZMethodConfiguration(SevenZMethod.LZMA2, LZMA2Options(3)))
        CompressionLevel.BEST -> listOf(SevenZMethodConfiguration(SevenZMethod.LZMA2, LZMA2Options(5)))
    }

    private fun deflaterLevel(level: CompressionLevel): Int = when (level) {
        CompressionLevel.STORE -> Deflater.NO_COMPRESSION
        CompressionLevel.FAST -> Deflater.BEST_SPEED
        CompressionLevel.NORMAL -> Deflater.DEFAULT_COMPRESSION
        CompressionLevel.BEST -> Deflater.BEST_COMPRESSION
    }

    private fun copy(input: InputStream, output: OutputStream, cancelled: () -> Boolean, onBytes: (Long) -> Unit) {
        val buffer = ByteArray(BUFFER_BYTES)
        while (true) {
            if (cancelled()) throw ArchiveCancelled()
            val read = input.read(buffer)
            if (read < 0) break
            output.write(buffer, 0, read)
            onBytes(read.toLong())
        }
    }

    private fun millis(epochSeconds: Long): Long = if (epochSeconds > 0L) epochSeconds * 1000L else System.currentTimeMillis()

    private class ZipWriter(
        val out: ZipArchiveOutputStream,
        level: CompressionLevel,
        val cancelled: () -> Boolean,
        val onBytes: (Long) -> Unit,
    ) : Writer {
        init {
            out.setEncoding("UTF-8")
            out.setUseZip64(Zip64Mode.AsNeeded)
            out.setMethod(ZipEntry.DEFLATED)
            out.setLevel(deflaterLevel(level))
        }

        override fun directory(path: String, modifiedEpochSeconds: Long, mode: Int) {
            val entry = ZipArchiveEntry("$path/")
            entry.time = millis(modifiedEpochSeconds)
            entry.unixMode = UnixStat.DIR_FLAG or (if (mode > 0) mode and 0xFFF else DEFAULT_DIR_MODE)
            out.putArchiveEntry(entry)
            out.closeArchiveEntry()
        }

        override fun file(path: String, size: Long, modifiedEpochSeconds: Long, mode: Int, content: InputStream) {
            val entry = ZipArchiveEntry(path)
            entry.time = millis(modifiedEpochSeconds)
            entry.unixMode = UnixStat.FILE_FLAG or (if (mode > 0) mode and 0xFFF else DEFAULT_FILE_MODE)
            out.putArchiveEntry(entry)
            copy(content, out, cancelled, onBytes)
            out.closeArchiveEntry()
        }

        override fun close() = out.close()
    }

    private class TarWriter(
        val out: TarArchiveOutputStream,
        val cancelled: () -> Boolean,
        val onBytes: (Long) -> Unit,
    ) : Writer {
        override fun directory(path: String, modifiedEpochSeconds: Long, mode: Int) {
            val entry = TarArchiveEntry("$path/")
            entry.setModTime(millis(modifiedEpochSeconds))
            entry.mode = if (mode > 0) mode and 0xFFF else DEFAULT_DIR_MODE
            out.putArchiveEntry(entry)
            out.closeArchiveEntry()
        }

        override fun file(path: String, size: Long, modifiedEpochSeconds: Long, mode: Int, content: InputStream) {
            val entry = TarArchiveEntry(path)
            entry.size = size
            entry.setModTime(millis(modifiedEpochSeconds))
            entry.mode = if (mode > 0) mode and 0xFFF else DEFAULT_FILE_MODE
            out.putArchiveEntry(entry)
            copy(content, out, cancelled, onBytes)
            out.closeArchiveEntry()
        }

        /** Copies a header and its data unchanged: used when rewriting, so links and owners survive. */
        fun passThrough(entry: TarArchiveEntry, content: InputStream) {
            out.putArchiveEntry(entry)
            if (entry.size > 0L) copy(content, out, cancelled, onBytes)
            out.closeArchiveEntry()
        }

        override fun close() = out.close()
    }

    private class SevenZWriter(
        val out: SevenZOutputFile,
        val cancelled: () -> Boolean,
        val onBytes: (Long) -> Unit,
    ) : Writer {
        private fun entry(path: String, directory: Boolean, modifiedEpochSeconds: Long, mode: Int): SevenZArchiveEntry {
            val e = SevenZArchiveEntry()
            e.name = path
            e.isDirectory = directory
            e.setHasStream(!directory)
            e.lastModifiedDate = Date(millis(modifiedEpochSeconds))
            // The attribute layout p7zip uses to keep Unix permissions: mode in the high 16 bits.
            val type = if (directory) UnixStat.DIR_FLAG else UnixStat.FILE_FLAG
            val perms = if (mode > 0) mode and 0xFFF else if (directory) DEFAULT_DIR_MODE else DEFAULT_FILE_MODE
            e.hasWindowsAttributes = true
            e.windowsAttributes = ((type or perms) shl 16) or SEVEN_Z_UNIX_EXTENSION or (if (directory) 0x10 else 0x20)
            return e
        }

        override fun directory(path: String, modifiedEpochSeconds: Long, mode: Int) {
            out.putArchiveEntry(entry(path, true, modifiedEpochSeconds, mode))
            out.closeArchiveEntry()
        }

        override fun file(path: String, size: Long, modifiedEpochSeconds: Long, mode: Int, content: InputStream) {
            out.putArchiveEntry(entry(path, false, modifiedEpochSeconds, mode))
            writeData(content)
            out.closeArchiveEntry()
        }

        fun passThrough(source: SevenZArchiveEntry, content: InputStream?) {
            val e = SevenZArchiveEntry()
            e.name = source.name
            e.isDirectory = source.isDirectory
            e.setHasStream(!source.isDirectory)
            if (source.hasLastModifiedDate) e.lastModifiedDate = source.lastModifiedDate
            if (source.hasWindowsAttributes) {
                e.hasWindowsAttributes = true
                e.windowsAttributes = source.windowsAttributes
            }
            out.putArchiveEntry(e)
            if (content != null && !source.isDirectory) writeData(content)
            out.closeArchiveEntry()
        }

        private fun writeData(content: InputStream) {
            val buffer = ByteArray(BUFFER_BYTES)
            while (true) {
                if (cancelled()) throw ArchiveCancelled()
                val read = content.read(buffer)
                if (read < 0) break
                out.write(buffer, 0, read)
                onBytes(read.toLong())
            }
        }

        override fun close() = out.close()
    }

    // ------------------------------------------------------------------ rewriting

    /**
     * Writes a copy of [source] to [target] without the entries under [remove] (a folder removes
     * everything inside it) and with [puts] added; a put replaces any entry of the same name.
     *
     * Zip copies the compressed bytes of untouched entries as they are, so deleting one file from
     * a big zip does not recompress the rest. Tar is a straight copy. 7z has to recompress: its
     * data lives in solid blocks that cannot be edited in place.
     */
    fun rewrite(
        source: File,
        format: ArchiveFormat,
        target: File,
        remove: Set<String>,
        puts: List<ArchivePut>,
        level: CompressionLevel = CompressionLevel.NORMAL,
        cancelled: () -> Boolean = { false },
        onBytes: (Long) -> Unit = {},
    ) {
        val replaced = HashSet<String>()
        for (put in puts) replaced.add(put.path)
        val dropped = { raw: String ->
            val (path, _) = ArchivePaths.clean(raw)
            path in replaced || isRemoved(path, remove)
        }
        guard {
            when (format) {
                ArchiveFormat.ZIP -> rewriteZip(source, target, dropped, puts, level, cancelled, onBytes)
                ArchiveFormat.SEVEN_Z -> rewriteSevenZ(source, target, dropped, puts, level, cancelled, onBytes)
                else -> rewriteTar(source, format, target, dropped, puts, level, cancelled, onBytes)
            }
        }
    }

    private fun isRemoved(path: String, remove: Set<String>): Boolean {
        if (remove.isEmpty()) return false
        var p = path
        while (p.isNotEmpty()) {
            if (p in remove) return true
            p = ArchivePaths.parent(p)
        }
        return false
    }

    private fun addPuts(writer: Writer, puts: List<ArchivePut>) {
        for (put in puts) {
            val file = put.source
            if (file == null) {
                writer.directory(put.path, put.modifiedEpochSeconds, put.mode)
            } else {
                FileInputStream(file).use { writer.file(put.path, file.length(), put.modifiedEpochSeconds, put.mode, it) }
            }
        }
    }

    private fun rewriteZip(
        source: File,
        target: File,
        dropped: (String) -> Boolean,
        puts: List<ArchivePut>,
        level: CompressionLevel,
        cancelled: () -> Boolean,
        onBytes: (Long) -> Unit,
    ) {
        val writer = ZipWriter(ZipArchiveOutputStream(target), level, cancelled, onBytes)
        writer.use {
            openZip(source).use { zip ->
                val entries = zip.entries
                while (entries.hasMoreElements()) {
                    if (cancelled()) throw ArchiveCancelled()
                    val entry = entries.nextElement()
                    if (dropped(entry.name)) continue
                    zip.getRawInputStream(entry).use { raw -> writer.out.addRawArchiveEntry(entry, raw) }
                    onBytes(entry.compressedSize.coerceAtLeast(0L))
                }
            }
            addPuts(writer, puts)
        }
    }

    private fun rewriteTar(
        source: File,
        format: ArchiveFormat,
        target: File,
        dropped: (String) -> Boolean,
        puts: List<ArchivePut>,
        level: CompressionLevel,
        cancelled: () -> Boolean,
        onBytes: (Long) -> Unit,
    ) {
        val writer = TarWriter(newTarOutput(target, format, level), cancelled, onBytes)
        writer.use {
            openTar(source, format).use { tar ->
                while (true) {
                    if (cancelled()) throw ArchiveCancelled()
                    val entry = tar.nextEntry ?: break
                    if (dropped(entry.name)) continue
                    writer.passThrough(entry, tar)
                }
            }
            addPuts(writer, puts)
        }
    }

    private fun rewriteSevenZ(
        source: File,
        target: File,
        dropped: (String) -> Boolean,
        puts: List<ArchivePut>,
        level: CompressionLevel,
        cancelled: () -> Boolean,
        onBytes: (Long) -> Unit,
    ) {
        val writer = SevenZWriter(newSevenZOutput(target, level), cancelled, onBytes)
        writer.use {
            openSevenZ(source).use { sevenZ ->
                while (true) {
                    if (cancelled()) throw ArchiveCancelled()
                    val entry = sevenZ.nextEntry ?: break
                    if (entry.isAntiItem || dropped(entry.name ?: "")) continue
                    writer.passThrough(entry, if (entry.isDirectory) null else SevenZStream(sevenZ))
                }
            }
            addPuts(writer, puts)
        }
    }

    // ------------------------------------------------------------------ plumbing

    /** Turns a library failure into an [ArchiveException] the UI can explain. */
    private inline fun <T> guard(block: () -> T): T = try {
        block()
    } catch (e: ArchiveException) {
        throw e
    } catch (e: ArchiveCancelled) {
        throw e
    } catch (e: TooLargeException) {
        throw e
    } catch (e: PasswordRequiredException) {
        throw ArchiveException(ArchiveProblem.ENCRYPTED, cause = e)
    } catch (e: UnsupportedZipFeatureException) {
        val encrypted = e.feature == UnsupportedZipFeatureException.Feature.ENCRYPTION
        throw ArchiveException(if (encrypted) ArchiveProblem.ENCRYPTED else ArchiveProblem.UNSUPPORTED, cause = e)
    } catch (e: org.apache.commons.compress.archivers.ArchiveException) {
        throw ArchiveException(ArchiveProblem.CORRUPT, e.message, e)
    } catch (e: java.util.zip.ZipException) {
        throw ArchiveException(ArchiveProblem.CORRUPT, e.message, e)
    } catch (e: java.io.EOFException) {
        throw ArchiveException(ArchiveProblem.CORRUPT, e.message, e)
    } catch (e: IOException) {
        // Anything else is a real I/O problem (disk full, unreadable file): let it through as is,
        // unless the library wrapped a format complaint in a plain IOException.
        val text = (e.message ?: "").lowercase()
        if ("unsupported" in text && ("method" in text || "compression" in text || "coder" in text)) {
            throw ArchiveException(ArchiveProblem.UNSUPPORTED, e.message, e)
        }
        if (listOf("truncated", "broken", "corrupt", "unexpected end", "signature", "checksum", "not in the", "crc").any { it in text }) {
            throw ArchiveException(ArchiveProblem.CORRUPT, e.message, e)
        }
        throw e
    } catch (e: IllegalArgumentException) {
        throw ArchiveException(ArchiveProblem.CORRUPT, e.message, e)
    }

    /** Lets a consumer read an entry without being able to close the archive underneath it. */
    private class NonClosing(input: InputStream) : FilterInputStream(input) {
        override fun close() = Unit
    }

    /** Polls the cancel flag on every read, so even one huge entry can be stopped. */
    private class CancellableStream(input: InputStream, val cancelled: () -> Boolean) : FilterInputStream(input) {
        override fun read(): Int {
            if (cancelled()) throw ArchiveCancelled()
            return super.read()
        }

        override fun read(b: ByteArray, off: Int, len: Int): Int {
            if (cancelled()) throw ArchiveCancelled()
            return super.read(b, off, len)
        }

        override fun close() = Unit
    }

    /** The data of the 7z entry the reader is positioned on. */
    private class SevenZStream(val sevenZ: SevenZFile) : InputStream() {
        override fun read(): Int = sevenZ.read()
        override fun read(b: ByteArray, off: Int, len: Int): Int = sevenZ.read(b, off, len)
        override fun close() = Unit
    }
}
