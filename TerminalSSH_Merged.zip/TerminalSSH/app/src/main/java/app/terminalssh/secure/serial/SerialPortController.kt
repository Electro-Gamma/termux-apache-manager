package app.terminalssh.secure.serial

import android.hardware.usb.UsbDeviceConnection
import com.hoho.android.usbserial.driver.UsbSerialDriver
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.util.SerialInputOutputManager
import java.io.ByteArrayOutputStream
import java.io.IOException

private const val WRITE_TIMEOUT_MS = 2000
private const val XOFF: Byte = 0x13
private const val XON: Byte = 0x11

/**
 * Owns one open [UsbSerialPort]: applies [SerialSettings], runs the background read loop
 * through [SerialInputOutputManager], and moves bytes both ways.
 *
 * Software XON/XOFF is done here, as plain pacing of the data stream that needs no driver
 * support. RTS/CTS is requested from the driver on a best-effort basis, since not every
 * chip family implements it.
 */
class SerialPortController {

    private var port: UsbSerialPort? = null
    private var ioManager: SerialInputOutputManager? = null

    private val queueLock = Any()
    private var xonXoffPaused = false
    private val pendingWrites = ArrayDeque<ByteArray>()

    /** Called on the read thread. */
    var onDataReceived: ((ByteArray) -> Unit)? = null

    /** Called on the read thread when the port fails, for example when the adapter is pulled. */
    var onError: ((Exception) -> Unit)? = null

    val isOpen: Boolean get() = port?.isOpen == true

    @Throws(IOException::class)
    fun open(driver: UsbSerialDriver, connection: UsbDeviceConnection, settings: SerialSettings) {
        val p = driver.ports.firstOrNull() ?: throw IOException("This device does not expose a serial port")
        p.open(connection)
        try {
            applySettings(p, settings)
        } catch (e: Exception) {
            runCatching { p.close() }
            throw e
        }
        port = p
        val manager = SerialInputOutputManager(p, object : SerialInputOutputManager.Listener {
            override fun onNewData(data: ByteArray) = handleIncoming(data, settings.flowControl)
            override fun onRunError(e: Exception) { onError?.invoke(e) }
        })
        ioManager = manager
        manager.start()
    }

    fun close() {
        runCatching { ioManager?.stop() }
        ioManager = null
        runCatching { port?.close() }
        port = null
        synchronized(queueLock) { xonXoffPaused = false; pendingWrites.clear() }
    }

    /** Re-applies settings to an open port, e.g. the user changed the baud rate mid-session. */
    fun updateSettings(settings: SerialSettings) {
        port?.let { applySettings(it, settings) }
    }

    fun write(bytes: ByteArray) {
        val p = port ?: return
        synchronized(queueLock) {
            if (xonXoffPaused) {
                pendingWrites.addLast(bytes)
                return
            }
        }
        writeNow(p, bytes)
    }

    private fun writeNow(p: UsbSerialPort, bytes: ByteArray) {
        try {
            p.write(bytes, WRITE_TIMEOUT_MS)
        } catch (e: Exception) {
            onError?.invoke(e)
        }
    }

    private fun handleIncoming(data: ByteArray, flowControl: FlowControl) {
        if (flowControl != FlowControl.XON_XOFF) {
            onDataReceived?.invoke(data)
            return
        }
        // Take XON/XOFF out of the stream before the terminal sees it, and use them to pace
        // our own writes.
        var sawXon = false
        val filtered = ByteArrayOutputStream(data.size)
        for (b in data) {
            when (b) {
                XOFF -> synchronized(queueLock) { xonXoffPaused = true }
                XON -> sawXon = true
                else -> filtered.write(b.toInt())
            }
        }
        if (filtered.size() > 0) onDataReceived?.invoke(filtered.toByteArray())
        if (sawXon) resumePendingWrites()
    }

    private fun resumePendingWrites() {
        val p = port ?: return
        val toFlush = synchronized(queueLock) {
            xonXoffPaused = false
            val list = pendingWrites.toList()
            pendingWrites.clear()
            list
        }
        toFlush.forEach { writeNow(p, it) }
    }

    private fun applySettings(p: UsbSerialPort, settings: SerialSettings) {
        p.setParameters(settings.baudRate, settings.dataBits.value, settings.stopBits.libValue, settings.parity.libValue)
        // Explicit method calls, not Kotlin's synthesized property syntax: the all-caps
        // "DTR"/"RTS" in the Java accessors makes the property name ambiguous across versions.
        runCatching { p.setDTR(settings.dtrEnabled) }
        runCatching { p.setRTS(settings.rtsEnabled) }
        applyFlowControl(p, settings.flowControl)
    }

    /**
     * usb-serial-for-android has a `setFlowControl` API on some drivers but not every chip
     * family implements it. It is reached by reflection so this still builds, and degrades
     * to the software pacing above, on versions that lack it.
     */
    private fun applyFlowControl(p: UsbSerialPort, flow: FlowControl) {
        runCatching {
            val flowControlClass = Class.forName("com.hoho.android.usbserial.driver.UsbSerialPort\$FlowControl")
            @Suppress("UNCHECKED_CAST")
            val constants = flowControlClass.enumConstants as? Array<Enum<*>> ?: return
            val wanted = when (flow) {
                FlowControl.NONE -> "NONE"
                FlowControl.XON_XOFF -> "XON_XOFF"
                FlowControl.RTS_CTS -> "RTS_CTS"
            }
            val constant = constants.firstOrNull { it.name == wanted } ?: return
            val method = p.javaClass.getMethod("setFlowControl", flowControlClass)
            method.invoke(p, constant)
        }
    }
}
