package app.terminalssh.secure.archive

/** The archive types the File Manager can create, open, edit and extract. */
enum class ArchiveFormat(val extension: String) {
    ZIP("zip"),
    TAR("tar"),
    SEVEN_Z("7z"),
    ;

    /** `.zip`, `.tar`, `.7z`: what is appended to a new archive's name. */
    val suffix: String get() = ".$extension"

    companion object {
        /** The format a file name says it is (by extension, case-insensitive), or null. */
        fun fromFileName(name: String): ArchiveFormat? {
            val lower = name.lowercase()
            return entries.firstOrNull { lower.endsWith(it.suffix) && lower.length > it.suffix.length }
        }

        fun isArchiveName(name: String): Boolean = fromFileName(name) != null

        /** `backup.tar` becomes `backup`; names that are not archives are returned unchanged. */
        fun baseName(name: String): String {
            val format = fromFileName(name) ?: return name
            return name.substring(0, name.length - format.suffix.length)
        }
    }
}

/** How hard to compress. Plain `.tar` has no compression, so the level does not apply to it. */
enum class CompressionLevel { STORE, FAST, NORMAL, BEST }

enum class ArchiveEntryKind { FILE, DIRECTORY, LINK, OTHER }

/**
 * One item inside an archive.
 *
 * [path] is always relative, `/`-separated, without a leading or trailing slash; the archive
 * root is the empty string. [mode] is the Unix permission bits when the archive recorded them
 * (0 when it did not). [unsafe] marks a name that would step outside the extraction folder
 * (`..`); such an entry is listed but never extracted. [ordinal] is how the engine finds the
 * entry again, so it keeps working when a name is duplicated or spelled oddly.
 */
data class ArchiveEntry(
    val path: String,
    val kind: ArchiveEntryKind,
    val size: Long,
    val modifiedEpochSeconds: Long,
    val mode: Int = 0,
    val unsafe: Boolean = false,
    /** Position among the archive's entries as the engine enumerates them; -1 for a synthesised folder. */
    val ordinal: Int = -1,
) {
    val isDirectory: Boolean get() = kind == ArchiveEntryKind.DIRECTORY
    val name: String get() = path.substringAfterLast('/')
    val parent: String get() = ArchivePaths.parent(path)

    /** Links, devices and the like are never recreated on extraction. */
    val isExtractable: Boolean
        get() = !unsafe && (kind == ArchiveEntryKind.FILE || kind == ArchiveEntryKind.DIRECTORY)
}

/** Path arithmetic for names inside an archive (always `/`, never absolute). */
object ArchivePaths {

    /**
     * Cleans a raw archive member name: backslashes are left alone (they are legal in names),
     * but leading `/` and `./`, doubled and trailing slashes are removed. Returns the cleaned
     * path and whether it tries to climb out with `..`.
     */
    fun clean(raw: String): Pair<String, Boolean> {
        val parts = ArrayList<String>()
        var unsafe = false
        for (segment in raw.split('/')) {
            when (segment) {
                "", "." -> Unit
                ".." -> unsafe = true
                else -> parts.add(segment)
            }
        }
        return parts.joinToString("/") to unsafe
    }

    fun parent(path: String): String {
        val cut = path.lastIndexOf('/')
        return if (cut < 0) "" else path.substring(0, cut)
    }

    fun join(base: String, child: String): String = if (base.isEmpty()) child else "$base/$child"

    /** True when [path] is [ancestor] itself or lies beneath it. The root contains everything. */
    fun isSameOrInside(path: String, ancestor: String): Boolean =
        ancestor.isEmpty() || path == ancestor || path.startsWith("$ancestor/")
}

/**
 * A folder view over an archive's flat entry list.
 *
 * Archives often omit the entries for their folders (a zip with only `a/b/c.txt` in it), so the
 * folders are synthesised from the file paths. Built once when an archive is opened; every
 * lookup afterwards is a map access.
 */
class ArchiveIndex(raw: List<ArchiveEntry>) {

    private val byPath = LinkedHashMap<String, ArchiveEntry>()
    private val childrenByDir = HashMap<String, MutableList<ArchiveEntry>>()

    /** Everything in the archive, folders included, in a stable order. */
    val entries: List<ArchiveEntry> get() = byPath.values.toList()

    val fileCount: Int get() = byPath.values.count { it.kind != ArchiveEntryKind.DIRECTORY }

    val totalSize: Long get() = byPath.values.sumOf { if (it.kind == ArchiveEntryKind.DIRECTORY) 0L else it.size.coerceAtLeast(0L) }

    init {
        for (entry in raw) {
            if (entry.path.isEmpty()) continue
            // A later entry with the same name replaces the earlier one, as extraction would.
            addWithParents(entry)
        }
    }

    private fun addWithParents(entry: ArchiveEntry) {
        var parent = entry.parent
        while (parent.isNotEmpty() && !byPath.containsKey(parent)) {
            put(ArchiveEntry(parent, ArchiveEntryKind.DIRECTORY, 0L, entry.modifiedEpochSeconds, 0, entry.unsafe))
            parent = ArchivePaths.parent(parent)
        }
        val existing = byPath[entry.path]
        if (existing != null && existing.isDirectory && !entry.isDirectory) {
            // A file shadowing a folder name: keep the folder, so the tree stays navigable.
            return
        }
        put(entry)
    }

    private fun put(entry: ArchiveEntry) {
        val previous = byPath.put(entry.path, entry)
        if (previous == null) {
            childrenByDir.getOrPut(entry.parent) { ArrayList() }.add(entry)
        } else {
            val siblings = childrenByDir.getValue(entry.parent)
            siblings[siblings.indexOfFirst { it.path == entry.path }] = entry
        }
    }

    operator fun get(path: String): ArchiveEntry? = byPath[path]

    fun contains(path: String): Boolean = byPath.containsKey(path)

    /** The items directly inside [dir] (`""` for the root). Unsorted. */
    fun children(dir: String): List<ArchiveEntry> = childrenByDir[dir].orEmpty()

    /** [path] and everything beneath it; for a plain file, just that file. */
    fun subtree(path: String): List<ArchiveEntry> {
        val self = byPath[path] ?: return emptyList()
        if (!self.isDirectory) return listOf(self)
        return byPath.values.filter { ArchivePaths.isSameOrInside(it.path, path) }
    }

    /** True when [dir] exists and is a folder (the root always is). */
    fun isDirectory(dir: String): Boolean = dir.isEmpty() || byPath[dir]?.isDirectory == true
}
