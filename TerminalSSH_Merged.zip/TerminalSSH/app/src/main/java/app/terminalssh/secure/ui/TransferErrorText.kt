package app.terminalssh.secure.ui

import app.terminalssh.secure.R
import app.terminalssh.secure.sftp.TransferErrorKind

/** The one place a [TransferErrorKind] becomes text a user reads. */
val TransferErrorKind.stringRes: Int
    get() = when (this) {
        TransferErrorKind.CONNECTION_LOST -> R.string.xfer_connection_lost
        TransferErrorKind.PERMISSION_DENIED -> R.string.xfer_permission_denied
        TransferErrorKind.NOT_FOUND -> R.string.xfer_not_found
        TransferErrorKind.OUT_OF_SPACE -> R.string.xfer_out_of_space
        TransferErrorKind.LOCAL_UNAVAILABLE -> R.string.xfer_local_unavailable
        TransferErrorKind.ARCHIVE_ENCRYPTED -> R.string.xfer_archive_encrypted
        TransferErrorKind.ARCHIVE_UNSUPPORTED -> R.string.xfer_archive_unsupported
        TransferErrorKind.ARCHIVE_CORRUPT -> R.string.xfer_archive_corrupt
        TransferErrorKind.ARCHIVE_ENTRY_SKIPPED -> R.string.xfer_archive_entry_skipped
        TransferErrorKind.ARCHIVE_CHANGED -> R.string.xfer_archive_changed
        TransferErrorKind.UNKNOWN -> R.string.xfer_unknown
    }
