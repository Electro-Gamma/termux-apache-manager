package app.terminalssh.secure.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import app.terminalssh.secure.R
import app.terminalssh.secure.TerminalApp
import app.terminalssh.secure.ui.MainActivity

/**
 * Keeps SSH sessions alive while the app is backgrounded, with a notification the
 * user can act on. Started when the first session connects, stopped when none remain.
 */
class SshForegroundService : Service() {

    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    /**
     * Keeps the CPU awake while sessions are up. Without it, a phone that sleeps with
     * the screen off stops servicing the sockets, keepalives go unanswered and the server
     * drops the connection, which is exactly the "left the app and everything restarted"
     * failure. Bounded, and refreshed on every state change, so it can never be held
     * forever by a bug.
     */
    private fun holdWakeLock() {
        val lock = wakeLock ?: (getSystemService(POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "terminalssh:sessions")
            .also {
                it.setReferenceCounted(false)
                wakeLock = it
            }
        lock.acquire(WAKE_LOCK_TIMEOUT_MS)
    }

    private fun releaseWakeLock() {
        wakeLock?.takeIf { it.isHeld }?.release()
        wakeLock = null
    }

    override fun onDestroy() {
        releaseWakeLock()
        super.onDestroy()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_DISCONNECT_ALL) {
            (application as TerminalApp).closeAllSessions()
            stopSelf()
            return START_NOT_STICKY
        }
        val count = intent?.getIntExtra(EXTRA_COUNT, 0) ?: 0
        if (count <= 0) {
            stopSelf()
            return START_NOT_STICKY
        }
        startForeground(NOTIFICATION_ID, buildNotification(count))
        holdWakeLock()
        return START_STICKY
    }

    /**
     * Android 15+ can time a foreground service out and will crash the app if the
     * service is still in the foreground when the grace period ends. specialUse is not
     * subject to the dataSync budget today, but the callback is cheap insurance against
     * a future policy change: shut the sessions down deliberately and tell the user,
     * rather than being killed mid-session with no explanation.
     */
    override fun onTimeout(startId: Int) {
        (application as TerminalApp).closeAllSessions()
        stopSelf()
    }

    private fun buildNotification(count: Int): Notification {
        ensureChannel()
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE,
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, SshForegroundService::class.java).setAction(ACTION_DISCONNECT_ALL),
            PendingIntent.FLAG_IMMUTABLE,
        )
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION") Notification.Builder(this)
        }
        return builder
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_sessions, count))
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    null, getString(R.string.notif_disconnect_all), stop,
                ).build(),
            )
            .build()
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(NotificationManager::class.java)
        if (manager.getNotificationChannel(CHANNEL_ID) != null) return
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW),
        )
    }

    companion object {
        private const val CHANNEL_ID = "sessions"
        private const val NOTIFICATION_ID = 1001
        private const val EXTRA_COUNT = "count"
        private const val WAKE_LOCK_TIMEOUT_MS = 12L * 60 * 60 * 1000
        const val ACTION_DISCONNECT_ALL = "app.terminalssh.secure.DISCONNECT_ALL"

        fun sync(context: Context, liveSessions: Int) {
            val intent = Intent(context, SshForegroundService::class.java).putExtra(EXTRA_COUNT, liveSessions)
            if (liveSessions > 0) {
                // Android refuses to start a foreground service from the background in some
                // situations; the sessions themselves must not die because of that.
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        context.startForegroundService(intent)
                    } else {
                        context.startService(intent)
                    }
                } catch (_: RuntimeException) {
                    // Retried on the next state change.
                }
            } else {
                context.stopService(Intent(context, SshForegroundService::class.java))
            }
        }
    }
}
