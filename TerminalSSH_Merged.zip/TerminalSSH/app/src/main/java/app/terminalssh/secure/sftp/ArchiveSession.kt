package app.terminalssh.secure.sftp

import app.terminalssh.secure.archive.ArchiveEngine
import app.terminalssh.secure.archive.ArchiveEntry
import app.terminalssh.secure.archive.ArchiveEntryKind
import app.terminalssh.secure.archive.ArchiveFormat
import app.terminalssh.secure.archive.ArchiveIndex
import java.io.File
import java.text.DateFormat
import java.util.Date
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

/**
 * A local copy of an archive that lives on the server, plus its table of contents.
 *
 * The copy is what lets an archive be browsed, read from and edited without extracting it: the
 * File Manager only ever opens entries out of this file. Several things can need it at once (the
 * open archive view, a running operation, the clipboard after "Copy"), so it is reference
 * counted: it starts with one reference, [retain] adds one, and the file is deleted when the
 * last holder calls [release].
 *
 * [remoteSize] and [remoteModified] are what the server reported when the copy was made. Before
 * anything is written back they are compared with the server again, so an archive that changed
 * in the meantime is never overwritten with an edit of the old version.
 */
class ArchiveHandle(
    /** Canonical path of the archive on the server. */
    val remotePath: String,
    val format: ArchiveFormat,
    val file: File,
    val remoteSize: Long,
    val remoteModified: Long,
    val index: ArchiveIndex,
) {
    val id: String = UUID.randomUUID().toString()
    val name: String get() = RemotePath.name(remotePath)

    private val refs = AtomicInteger(1)

    fun retain(): ArchiveHandle {
        refs.incrementAndGet()
        return this
    }

    fun release() {
        if (refs.decrementAndGet() == 0) runCatching { file.delete() }
    }

    companion object {
        private const val DIR = "archives"
        private const val MIN_FREE_BYTES = 32L * 1024 * 1024
        private val purged = AtomicBoolean(false)

        /** Where local copies and half-built archives live. Emptied once per process: nothing outlives the app. */
        fun workDir(cacheDir: File): File {
            val dir = File(cacheDir, DIR)
            if (purged.compareAndSet(false, true)) dir.listFiles()?.forEach { runCatching { it.deleteRecursively() } }
            dir.mkdirs()
            return dir
        }

        /** Throws [TransferFailure] (out of space) when [bytes] plus a safety margin will not fit in [dir]. */
        fun requireSpace(dir: File, bytes: Long) {
            if (bytes > 0 && dir.usableSpace < bytes + MIN_FREE_BYTES) {
                throw TransferFailure(TransferErrorKind.OUT_OF_SPACE, "not enough free storage")
            }
        }

        /**
         * Downloads [remote] into the work directory and reads its contents list. A damaged or
         * unsupported archive throws (and leaves nothing behind). [onProgress] may throw to stop.
         */
        fun fetch(
            sftp: SftpClient,
            remote: String,
            format: ArchiveFormat,
            cacheDir: File,
            onProgress: (Long) -> Unit,
        ): ArchiveHandle {
            val real = sftp.realPath(remote)
            val stat = sftp.statDetailed(real)
            val dir = workDir(cacheDir)
            requireSpace(dir, stat.sizeBytes)
            val target = File.createTempFile("arc", format.suffix, dir)
            try {
                sftp.readToFile(real, target, Long.MAX_VALUE, onProgress)
                val index = ArchiveIndex(ArchiveEngine.list(target, format))
                return ArchiveHandle(real, format, target, target.length(), stat.modifiedEpochSeconds, index)
            } catch (t: Throwable) {
                target.delete()
                throw t
            }
        }
    }
}

/**
 * What the File Manager shows while an archive is open. [handle] is null while it is still being
 * fetched ([loadedBytes] counts up) or after it failed ([errorKind]). [dir] is the folder inside
 * the archive, `""` for its top level.
 */
data class ArchiveState(
    val remote: RemoteEntry,
    val format: ArchiveFormat,
    val handle: ArchiveHandle? = null,
    val dir: String = "",
    val loadedBytes: Long = 0L,
    val errorKind: TransferErrorKind? = null,
) {
    val name: String get() = remote.name

    /** The folder being viewed as a path the existing breadcrumbs understand (`/` is the archive's top). */
    val displayPath: String get() = RemotePath.normalize("/$dir")

    /** The items of the current folder, shaped like server entries so the same list can draw them. */
    fun entries(): List<RemoteEntry> =
        handle?.index?.children(dir).orEmpty().map { it.toRemoteEntry() }
}

/**
 * An archive item as a [RemoteEntry]: its path is `/inner/path`, and the permissions column
 * carries the modified date instead, since archives have no meaningful POSIX string to show.
 */
fun ArchiveEntry.toRemoteEntry(): RemoteEntry = RemoteEntry(
    name = name,
    path = "/$path",
    isDirectory = isDirectory,
    isSymlink = kind == ArchiveEntryKind.LINK,
    sizeBytes = size,
    modifiedEpochSeconds = modifiedEpochSeconds,
    permissions = if (modifiedEpochSeconds > 0L) {
        DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(modifiedEpochSeconds * 1000L))
    } else {
        ""
    },
)

/** The path inside the archive that a listed archive item's `/path` stands for. */
fun innerPath(entryPath: String): String = entryPath.trimStart('/')
