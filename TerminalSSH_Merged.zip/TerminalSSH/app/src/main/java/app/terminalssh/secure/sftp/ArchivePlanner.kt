package app.terminalssh.secure.sftp

import app.terminalssh.secure.archive.ArchiveEntryKind
import app.terminalssh.secure.archive.ArchiveIndex
import app.terminalssh.secure.archive.ArchivePaths

/**
 * Decides where each archive entry lands when it is extracted. Pure, so the naming rules are
 * unit-tested without a server.
 *
 * Extraction never overwrites: a top-level name that already exists gets the same
 * "name (copy)" treatment as a paste. Names below the top level are kept as they are.
 */
object ArchivePlanner {

    /** [outputs] maps an entry's archive ordinal to its path relative to the destination. */
    class ExtractPlan(
        val outputs: Map<Int, String>,
        val itemCount: Int,
        val totalBytes: Long,
    )

    /**
     * @param roots inner paths picked by the user, each placed at the top of the destination; or
     *   null for the whole archive, which keeps its own layout.
     * @param taken names already used at the top of the destination; extended as names are claimed.
     */
    fun plan(index: ArchiveIndex, roots: List<String>?, taken: MutableSet<String>): ExtractPlan {
        val outputs = LinkedHashMap<Int, String>()
        var bytes = 0L

        fun add(ordinal: Int, relative: String, size: Long, kind: ArchiveEntryKind) {
            outputs[ordinal] = relative
            if (kind == ArchiveEntryKind.FILE && size > 0L) bytes += size
        }

        if (roots == null) {
            val renamed = HashMap<String, String>()
            for (entry in index.entries) {
                if (entry.ordinal < 0) continue
                val top = entry.path.substringBefore('/')
                val name = renamed.getOrPut(top) { RemotePath.uniqueName(taken, top).also { taken.add(it) } }
                add(entry.ordinal, name + entry.path.removePrefix(top), entry.size, entry.kind)
            }
        } else {
            // A folder picked together with something inside it would be extracted twice.
            val distinct = roots.distinct().filter { r -> roots.none { o -> o != r && ArchivePaths.isSameOrInside(r, o) } }
            for (root in distinct) {
                val name = RemotePath.uniqueName(taken, root.substringAfterLast('/'))
                taken.add(name)
                for (entry in index.subtree(root)) {
                    if (entry.ordinal < 0) continue
                    add(entry.ordinal, name + entry.path.removePrefix(root), entry.size, entry.kind)
                }
            }
        }
        return ExtractPlan(outputs, outputs.size, bytes)
    }

    /**
     * `rwxr-xr-x` style text (with the leading type character, as SFTP reports it) to permission
     * bits; 0 when it cannot be read.
     */
    fun modeFromPermissionString(text: String): Int {
        if (text.length != 10) return 0
        var mode = 0
        for (i in 0 until 9) {
            val c = text[i + 1]
            val on = when {
                c == '-' -> false
                i % 3 == 2 -> c == 'x' || c == 's' || c == 't' // setuid/setgid/sticky still imply execute
                else -> c == "rw"[i % 3]
            }
            if (on) mode = mode or (1 shl (8 - i))
        }
        return mode
    }

    /**
     * What to apply to an extracted file: only the rwx bits, minus group/other write (as a
     * normal `umask 022` extraction would), and only when there is an execute bit to preserve.
     * Everything else keeps the server's defaults. 0 means "leave it".
     */
    fun extractedFileMode(archiveMode: Int): Int {
        val masked = archiveMode and 0x1FF and 0x12.inv()
        return if (masked and 0x49 != 0) masked else 0
    }
}
