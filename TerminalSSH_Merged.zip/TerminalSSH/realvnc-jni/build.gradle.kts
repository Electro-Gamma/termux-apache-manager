// SPDX-License-Identifier: CC0-1.0
//
// The Java side of the JNI surface of RealVNC Viewer's libvncviewer.so, copied from
// the Vento project (realvnc/ module, CC0-1.0). Declarations only: the native library
// itself is NOT part of this module or of the project - see README-VncViewer.md ("RealVNC engine").
plugins {
    id("com.android.library")
}

android {
    namespace = "com.realvnc.vncviewer.jni"
    compileSdk = 36

    defaultConfig {
        minSdk = 26
        // The whole package is names the native side resolves at run time.
        consumerProguardFiles("consumer-rules.pro")
    }

    compileOptions {
        // The declarations use records and a sealed interface (Java 17).
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
