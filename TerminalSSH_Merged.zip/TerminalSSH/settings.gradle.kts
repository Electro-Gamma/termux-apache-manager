pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // usb-serial-for-android (UART mode) is published only on JitPack. Limited to its own
        // group so no other dependency is ever resolved from here.
        maven("https://jitpack.io") {
            content { includeGroup("com.github.mik3y") }
        }
    }
}
rootProject.name = "TerminalSSH"
include(":app")
// Java declarations of the RealVNC JNI surface used by the VNC tab (no native code inside).
include(":realvnc-jni")
