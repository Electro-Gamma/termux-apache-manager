# Third-party notices

This product includes software developed by third parties.

## mwiede/JSch — 2.28.6
BSD-style licence (JSch original licence, Atsuhiko Yamanaka / JCraft).
https://github.com/mwiede/jsch
Provides the SSH-2 transport, authentication and channel layer.

## usb-serial-for-android — 3.11.0
MIT licence, (c) Mike Wakerly and contributors.
https://github.com/mik3y/usb-serial-for-android
Provides the FTDI, CP210x, CH340, PL2303 and CDC-ACM drivers behind UART mode.

## usb-serial-for-android — 3.11.0
MIT licence, (c) Mike Wakerly and contributors.
https://github.com/mik3y/usb-serial-for-android
Provides the FTDI, CP210x, CH340, PL2303 and CDC-ACM drivers behind UART mode.

## ConnectBot termlib — 0.1.0
Apache License 2.0.
https://github.com/connectbot
Provides the terminal emulator and its Compose renderer.

## libvterm (bundled inside termlib as libjni_cb_term.so)
MIT licence, Paul "LeoNerd" Evans.
Provides VT100/ANSI parsing.

## AndroidX / Jetpack Compose
Apache License 2.0, The Android Open Source Project.

> Before publishing to any store, verify each licence text against the exact
> artifact version you ship and include the full licence files in the release.

## Highlight.js
The File Manager editor colours code with Highlight.js 11.12.0 (BSD-3-Clause,
(c) 2006 Ivan Sagalaev and contributors), bundled in
`app/src/main/assets/editor/highlight.min.js` (taken from the
android-compose-highlight 0.39.0 release). Its licence text must accompany releases.

## android-compose-highlight
The approach (Highlight.js in a hidden WebView, HTML converted to native text styles)
follows android-compose-highlight 0.39.0, MIT License, (c) 2026 Hossain Khan.

## VNC tab (formerly the standalone VncViewer app)
The VNC tab is the VncViewer project merged into this app (see `NOTICE-VncViewer.md` and
`README-VncViewer.md`). Its RealVNC engine and input stack are ports of the Vento project
(https://github.com/pgaskin/vento, (C) 2026 Patrick Gaskin, GPL-3.0-or-later; the JNI declarations in
`realvnc-jni/` are CC0-1.0). Because of that, a build that includes this code is covered by the
GNU GPL v3 or later, and the source must be provided to anyone you give the app to. RealVNC's
proprietary `libvncviewer.so` is added only by the build notebook, into your own APK: do not share that APK.
