package cc.iotdeck.server.acme;

/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 30.04.17.
 */
public class ContentHolder {

    public volatile String content;

}
