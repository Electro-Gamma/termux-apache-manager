/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 05.10.17.
 */
module cc.iotdeck.server.acme {
    requires org.apache.logging.log4j;
    requires org.shredzone.acme4j.utils;
    requires org.shredzone.acme4j;

    exports cc.iotdeck.server.acme;
}