/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 29.09.17.
 */
module cc.iotdeck.server.notifications.twitter {
    requires async.http.client;
    requires cc.iotdeck.utils;

    exports cc.iotdeck.server.notifications.twitter;
}