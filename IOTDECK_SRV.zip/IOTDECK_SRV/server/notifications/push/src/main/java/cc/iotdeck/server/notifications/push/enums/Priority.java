package cc.iotdeck.server.notifications.push.enums;

/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 03.11.15.
 */
public enum Priority {

    normal,
    high

}
