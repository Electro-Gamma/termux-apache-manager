/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 29.09.17.
 */
open module cc.iotdeck.server.notifications.push {
    requires org.apache.logging.log4j;
    requires com.fasterxml.jackson.annotation;
    requires com.fasterxml.jackson.core;
    requires com.fasterxml.jackson.databind;
    requires io.netty.codec.http;
    requires async.http.client;
    requires cc.iotdeck.utils;

    exports cc.iotdeck.server.notifications.push;
    exports cc.iotdeck.server.notifications.push.android;
    exports cc.iotdeck.server.notifications.push.enums;
    exports cc.iotdeck.server.notifications.push.ios;
}
