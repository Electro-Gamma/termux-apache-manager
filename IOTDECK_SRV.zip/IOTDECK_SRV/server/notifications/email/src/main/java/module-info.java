/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 17.05.18.
 */
module cc.iotdeck.server.notifications.mail {
    requires org.apache.logging.log4j;
    requires cc.iotdeck.utils;
    requires java.mail;
    requires java.activation;

    exports cc.iotdeck.server.notifications.mail;
}