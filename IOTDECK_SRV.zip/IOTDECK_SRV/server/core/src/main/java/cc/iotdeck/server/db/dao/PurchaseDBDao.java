package cc.iotdeck.server.db.dao;

import cc.iotdeck.server.db.model.Purchase;
import com.zaxxer.hikari.HikariDataSource;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.Connection;
import java.sql.PreparedStatement;

/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 09.03.16.
 */
public class PurchaseDBDao {

    private static final String insertPurchase =
            "INSERT INTO purchase (email, reward, transactionId, price) values (?, ?, ?, ?)";

    private static final Logger log = LogManager.getLogger(PurchaseDBDao.class);
    private final HikariDataSource ds;

    public PurchaseDBDao(HikariDataSource ds) {
        this.ds = ds;
    }

    public void insertPurchase(Purchase purchase) {
        try (Connection connection = ds.getConnection();
             PreparedStatement ps = connection.prepareStatement(insertPurchase)) {

            insert(ps, purchase);
            ps.executeUpdate();

            connection.commit();
        } catch (Throwable e) {
            log.error("Error inserting purchase data in DB. {}", e.getMessage());
        }
    }

    private static void insert(PreparedStatement ps, Purchase purchase) throws Exception {
        ps.setString(1, purchase.email);
        ps.setInt(2, purchase.reward);
        ps.setString(3, purchase.transactionId);
        ps.setDouble(4, purchase.price);
    }
}
