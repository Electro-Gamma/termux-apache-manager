package cc.iotdeck.server.core.model.widgets.others.eventor.model.action.notification;

import cc.iotdeck.server.core.model.widgets.others.eventor.model.action.BaseAction;

/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 23.08.16.
 */
public abstract class NotificationAction extends BaseAction {

    public final String message;

    NotificationAction(String message) {
        this.message = message;
    }

    @Override
    public boolean isValid() {
        return message != null && !message.isEmpty();
    }

}
