package cc.iotdeck.server.core.model.widgets;

public interface DeviceCleaner {

    void deleteDevice(int deviceId);

}
