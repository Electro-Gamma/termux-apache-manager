package cc.iotdeck.server.core.model.widgets.ui.tiles;

/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 02.10.17.
 */
public enum TileMode {

    PAGE, BUTTON, ICON, DIMMER

}
