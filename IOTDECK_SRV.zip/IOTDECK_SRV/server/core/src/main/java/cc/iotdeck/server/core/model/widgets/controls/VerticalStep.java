package cc.iotdeck.server.core.model.widgets.controls;

/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 01.04.15.
 */
public class VerticalStep extends Step {

}
