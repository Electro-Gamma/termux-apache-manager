package cc.iotdeck.server.core.model.widgets.sensors;

import cc.iotdeck.server.core.model.enums.PinMode;
import cc.iotdeck.server.core.model.widgets.OnePinWidget;
import io.netty.channel.ChannelHandlerContext;

/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 06.09.16.
 */
public class Accelerometer extends OnePinWidget {

    private int frequency;

    @Override
    public PinMode getModeType() {
        return PinMode.out;
    }

    @Override
    public void sendHardSync(ChannelHandlerContext ctx, int msgId, int deviceId) {
    }

    @Override
    public int getPrice() {
        return 400;
    }

}
