package cc.iotdeck.server.core.model.widgets.notifications;

import cc.iotdeck.server.core.model.widgets.NoPinWidget;

/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 21.03.15.
 */
public class SMS extends NoPinWidget {

    public String to;

    @Override
    public int getPrice() {
        return 100;
    }
}
