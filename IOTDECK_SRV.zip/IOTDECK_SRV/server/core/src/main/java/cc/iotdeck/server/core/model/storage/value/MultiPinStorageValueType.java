package cc.iotdeck.server.core.model.storage.value;

import cc.iotdeck.utils.structure.BaseLimitedQueue;
import cc.iotdeck.utils.structure.LCDLimitedQueue;
import cc.iotdeck.utils.structure.TableLimitedQueue;
import cc.iotdeck.utils.structure.TerminalLimitedQueue;

/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 27/04/2018.
 *
 */
public enum MultiPinStorageValueType {

    //WARNING: order change is not allowed!
    LCD,
    TERMINAL,
    TABLE;

    public BaseLimitedQueue<String> getQueue() {
        switch (this) {
            case LCD:
                return new LCDLimitedQueue<>();
            case TERMINAL:
                return new TerminalLimitedQueue<>();
            case TABLE:
                return new TableLimitedQueue<>();
            default:
                throw new RuntimeException("not supported");
        }
    }

}
