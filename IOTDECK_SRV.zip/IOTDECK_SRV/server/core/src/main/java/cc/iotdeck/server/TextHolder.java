package cc.iotdeck.server;

import cc.iotdeck.utils.properties.GCMProperties;

import static cc.iotdeck.utils.FileLoaderUtil.readAppResetEmailConfirmationTemplateAsString;
import static cc.iotdeck.utils.FileLoaderUtil.readAppResetEmailTemplateAsString;
import static cc.iotdeck.utils.FileLoaderUtil.readDynamicMailBody;
import static cc.iotdeck.utils.FileLoaderUtil.readRegisterEmailTemplate;
import static cc.iotdeck.utils.FileLoaderUtil.readResetPassLandingTemplateAsString;
import static cc.iotdeck.utils.FileLoaderUtil.readStaticMailBody;
import static cc.iotdeck.utils.FileLoaderUtil.readTemplateIdMailBody;
import static cc.iotdeck.utils.FileLoaderUtil.readTokenMailBody;

/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 27.03.18.
 */
public class TextHolder {

    public volatile String tokenBody;
    public final String dynamicMailBody;
    public final String staticMailBody;
    public final String templateIdMailBody;
    public final String pushNotificationBody;
    public final String resetPassLandingTemplate;
    public final String appResetEmailTemplate;
    public final String appResetEmailConfirmationTemplate;
    public final String registerEmailTemplate;

    TextHolder(GCMProperties gcmProperties) {
        this.tokenBody = readTokenMailBody();
        this.dynamicMailBody = readDynamicMailBody();
        this.staticMailBody = readStaticMailBody();
        this.templateIdMailBody = readTemplateIdMailBody();
        this.pushNotificationBody = gcmProperties.getNotificationBody();
        this.resetPassLandingTemplate = readResetPassLandingTemplateAsString();
        this.appResetEmailTemplate = readAppResetEmailTemplateAsString();
        this.appResetEmailConfirmationTemplate = readAppResetEmailConfirmationTemplateAsString();
        this.registerEmailTemplate = readRegisterEmailTemplate();
    }
}
