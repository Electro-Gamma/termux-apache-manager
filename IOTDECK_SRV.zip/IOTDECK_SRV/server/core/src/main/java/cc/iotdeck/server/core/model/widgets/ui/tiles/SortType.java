package cc.iotdeck.server.core.model.widgets.ui.tiles;

/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 02.10.17.
 */
public enum SortType {

    CUSTOM,
    DEVICE_NAME_ASC, DEVICE_NAME_DESC,
    TEMPLATE_NAME_ASC, TEMPLATE_NAME_DESC,
    STATUS_CRITICAL, STATUS_OK

}
