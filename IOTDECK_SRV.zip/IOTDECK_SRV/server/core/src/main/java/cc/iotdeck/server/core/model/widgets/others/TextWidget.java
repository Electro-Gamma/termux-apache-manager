package cc.iotdeck.server.core.model.widgets.others;

import cc.iotdeck.server.core.model.widgets.NoPinWidget;
import cc.iotdeck.server.core.model.widgets.outputs.TextAlignment;
import cc.iotdeck.server.core.model.widgets.outputs.graph.FontSize;

/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 31.05.19.
 */
public class TextWidget extends NoPinWidget {

    public FontSize textSize = FontSize.AUTO;

    public TextAlignment alignment;

    public String text;

    @Override
    public int getPrice() {
        return 100;
    }

}
