package cc.iotdeck.server.core.model.widgets.controls;

public enum ButtonStyle {

    SOLID, OUTLINE

}
