package cc.iotdeck.server.core.model.widgets.outputs;

import cc.iotdeck.server.core.model.enums.PinMode;
import cc.iotdeck.server.core.model.widgets.OnePinReadingWidget;

/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 21.03.15.
 */
public class LevelDisplay extends OnePinReadingWidget {

    public boolean isAxisFlipOn;

    public boolean showValueOn = true;

    @Override
    public PinMode getModeType() {
        return PinMode.in;
    }

    @Override
    public int getPrice() {
        return 200;
    }
}
