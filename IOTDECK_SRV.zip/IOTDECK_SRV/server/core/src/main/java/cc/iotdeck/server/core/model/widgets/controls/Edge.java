package cc.iotdeck.server.core.model.widgets.controls;

public enum Edge {

    ROUNDED, SHARP, PILL, TEXT

}
