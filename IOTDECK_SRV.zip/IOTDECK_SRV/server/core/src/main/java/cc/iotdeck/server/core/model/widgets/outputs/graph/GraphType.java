package cc.iotdeck.server.core.model.widgets.outputs.graph;

/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 21.06.17.
 */
public enum GraphType {

    LINE, FILLED_LINE, BAR, BINARY

}
