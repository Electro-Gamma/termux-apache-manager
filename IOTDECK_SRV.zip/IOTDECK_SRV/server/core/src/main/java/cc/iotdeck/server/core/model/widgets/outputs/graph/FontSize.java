package cc.iotdeck.server.core.model.widgets.outputs.graph;

/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 28.03.16.
 */
public enum FontSize {

    LARGE, MEDIUM, SMALL, AUTO

}
