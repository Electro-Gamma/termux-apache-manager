package cc.iotdeck.server.core.model.enums;

/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 20.03.17.
 */
public enum Theme {

    iotdeck,
    IOTDeck,
    IOTDeckLight,
    SparkFun,
    AppTheme, //should be removed in future
    CustomTheme, //should be removed in future
    AppExport //should be removed in future

}
