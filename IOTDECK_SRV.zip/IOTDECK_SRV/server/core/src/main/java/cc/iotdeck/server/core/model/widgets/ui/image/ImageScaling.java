package cc.iotdeck.server.core.model.widgets.ui.image;

public enum ImageScaling {

    NONE, FILL, FIT

}
