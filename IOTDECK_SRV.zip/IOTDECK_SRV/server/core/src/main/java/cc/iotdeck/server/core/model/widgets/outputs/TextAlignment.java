package cc.iotdeck.server.core.model.widgets.outputs;

/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 28.03.16.
 */
public enum TextAlignment {

    LEFT, RIGHT, MIDDLE

}
