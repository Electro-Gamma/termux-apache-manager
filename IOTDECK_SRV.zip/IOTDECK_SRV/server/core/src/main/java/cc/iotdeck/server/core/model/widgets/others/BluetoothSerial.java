package cc.iotdeck.server.core.model.widgets.others;

import cc.iotdeck.server.core.model.widgets.NoPinWidget;

/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 21.03.15.
 */
public class BluetoothSerial extends NoPinWidget {

    public String name;

    public int deviceId;

    @Override
    public int getPrice() {
        return 0;
    }
}
