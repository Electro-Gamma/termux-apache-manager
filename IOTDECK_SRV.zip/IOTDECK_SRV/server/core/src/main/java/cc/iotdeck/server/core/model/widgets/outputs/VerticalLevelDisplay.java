package cc.iotdeck.server.core.model.widgets.outputs;

/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 21.03.15.
 */
public class VerticalLevelDisplay extends LevelDisplay {

}
