package cc.iotdeck.server.core.model.widgets.ui.image;

public enum ImageSource {

    URL, ALBUM, PREDEFINED

}
