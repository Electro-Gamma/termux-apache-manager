package cc.iotdeck.server.core.model.widgets.others.webhook;

/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 05.09.16.
 */
public enum SupportedWebhookMethod {

    POST,
    GET,
    PUT,
    DELETE

}
