package cc.iotdeck.server.core.model.widgets.others.eventor.model.action;

/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 12.02.17.
 */
public enum SetPinActionType {

    ON, OFF, CUSTOM

}
