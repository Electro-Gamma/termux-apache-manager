package cc.iotdeck.server.core.model.widgets.others;

import cc.iotdeck.server.core.model.widgets.NoPinWidget;

/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 21.03.15.
 */
public class Bridge extends NoPinWidget {

    @Override
    public int getPrice() {
        return 100;
    }

}
