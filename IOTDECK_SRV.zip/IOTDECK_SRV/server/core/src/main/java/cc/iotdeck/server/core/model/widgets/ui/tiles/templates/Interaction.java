package cc.iotdeck.server.core.model.widgets.ui.tiles.templates;

public enum Interaction {

    BUTTON, PAGE, STEP

}
