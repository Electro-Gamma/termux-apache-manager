package cc.iotdeck.server.workers.timer;

import cc.iotdeck.server.core.dao.UserKey;
import cc.iotdeck.server.core.model.widgets.others.eventor.TimerTime;

/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 27.12.16.
 */
public class TimerKey {

    public final UserKey userKey;

    public final int dashId;

    public final int deviceId;

    public final long widgetId;

    public final int additionalId;

    public final long deviceTilesId;

    public final long templateId;

    public final TimerTime time;

    public TimerKey(UserKey userKey, int dashId, int deviceId, long widgetId,
                    int additionalId, long deviceTilesId, long templateId, TimerTime time) {
        this.userKey = userKey;
        this.dashId = dashId;
        this.deviceId = deviceId;
        this.widgetId = widgetId;
        this.additionalId = additionalId;
        this.deviceTilesId = deviceTilesId;
        this.templateId = templateId;
        this.time = time;
    }

    public boolean isTilesTimer() {
        return deviceTilesId != -1 && templateId != -1;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof TimerKey)) {
            return false;
        }

        TimerKey timerKey = (TimerKey) o;

        if (dashId != timerKey.dashId) {
            return false;
        }
        if (deviceId != timerKey.deviceId) {
            return false;
        }
        if (widgetId != timerKey.widgetId) {
            return false;
        }
        if (additionalId != timerKey.additionalId) {
            return false;
        }
        if (deviceTilesId != timerKey.deviceTilesId) {
            return false;
        }
        if (templateId != timerKey.templateId) {
            return false;
        }
        if (userKey != null ? !userKey.equals(timerKey.userKey) : timerKey.userKey != null) {
            return false;
        }
        return time != null ? time.equals(timerKey.time) : timerKey.time == null;
    }

    @Override
    public int hashCode() {
        int result = userKey != null ? userKey.hashCode() : 0;
        result = 31 * result + dashId;
        result = 31 * result + deviceId;
        result = 31 * result + (int) (widgetId ^ (widgetId >>> 32));
        result = 31 * result + additionalId;
        result = 31 * result + (int) (deviceTilesId ^ (deviceTilesId >>> 32));
        result = 31 * result + (int) (templateId ^ (templateId >>> 32));
        result = 31 * result + (time != null ? time.hashCode() : 0);
        return result;
    }
}
