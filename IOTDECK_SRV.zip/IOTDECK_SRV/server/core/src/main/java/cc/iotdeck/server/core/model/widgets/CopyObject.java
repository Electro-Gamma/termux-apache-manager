package cc.iotdeck.server.core.model.widgets;

/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 24.08.17.
 */
public interface CopyObject<T> {

    T copy();

}
