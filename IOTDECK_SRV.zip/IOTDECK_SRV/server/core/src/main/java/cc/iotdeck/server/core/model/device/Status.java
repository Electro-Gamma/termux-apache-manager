package cc.iotdeck.server.core.model.device;

/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 16.12.16.
 */
public enum Status {

    ONLINE,
    OFFLINE

}
