package cc.iotdeck.server.core.model.device;

/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 16.11.16.
 */
public enum ConnectionType {

    ETHERNET,
    WI_FI,
    USB,
    BLUETOOTH,
    BLE,
    GSM

}
