package cc.iotdeck.server.core.model.enums;

/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 20.03.17.
 */
public enum ProvisionType {

    STATIC,
    DYNAMIC

}
