package cc.iotdeck.server.core.model.widgets.ui;

import cc.iotdeck.server.core.model.widgets.NoPinWidget;

/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 07.02.16.
 */
public class Tabs extends NoPinWidget {

    public Tab[] tabs;

    public volatile int color;

    public int activeTxtColor;

    public int underlineColor;

    public int textColor;

    public Tabs() {
        this.tabId = -1;
    }

    @Override
    public int getPrice() {
        return 0;
    }

}
