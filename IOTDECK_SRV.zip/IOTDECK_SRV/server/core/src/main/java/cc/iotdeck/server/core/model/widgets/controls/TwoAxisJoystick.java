package cc.iotdeck.server.core.model.widgets.controls;

import cc.iotdeck.server.core.model.DataStream;
import cc.iotdeck.server.core.model.enums.PinMode;
import cc.iotdeck.server.core.model.widgets.HardwareSyncWidget;
import cc.iotdeck.server.core.model.widgets.MultiPinWidget;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;

import static cc.iotdeck.server.core.protocol.enums.Command.APP_SYNC;
import static cc.iotdeck.server.core.protocol.enums.Command.HARDWARE;
import static cc.iotdeck.server.internal.CommonByteBufUtil.makeUTF8StringMessage;
import static cc.iotdeck.utils.StringUtils.prependDashIdAndDeviceId;

/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 21.03.15.
 */
public class TwoAxisJoystick extends MultiPinWidget implements HardwareSyncWidget {

    public boolean split;

    public boolean autoReturnOn;

    public boolean portraitLocked;

    public int frequency;

    @Override
    public void sendHardSync(ChannelHandlerContext ctx, int msgId, int deviceId) {
        if (dataStreams == null || this.deviceId != deviceId) {
            return;
        }
        if (split) {
            for (DataStream dataStream : dataStreams) {
                if (dataStream.notEmptyAndIsValid()) {
                    ctx.write(makeUTF8StringMessage(HARDWARE, msgId,
                            dataStream.makeHardwareBody()), ctx.voidPromise());
                }
            }
        } else {
            if (dataStreams[0].notEmptyAndIsValid()) {
                ctx.write(makeUTF8StringMessage(HARDWARE, msgId,
                        dataStreams[0].makeHardwareBody()), ctx.voidPromise());
            }
        }
    }

    @Override
    public void sendAppSync(Channel appChannel, int dashId, int targetId) {
        if (dataStreams == null) {
            return;
        }
        if (targetId == ANY_TARGET || this.deviceId == targetId) {
            if (split) {
                for (DataStream dataStream : dataStreams) {
                    if (dataStream.notEmptyAndIsValid()) {
                        String body = prependDashIdAndDeviceId(dashId, deviceId, dataStream.makeHardwareBody());
                        appChannel.write(makeUTF8StringMessage(APP_SYNC, SYNC_DEFAULT_MESSAGE_ID, body),
                                appChannel.voidPromise());
                    }
                }
            } else {
                if (dataStreams[0].notEmptyAndIsValid()) {
                    String body = prependDashIdAndDeviceId(dashId, deviceId, dataStreams[0].makeHardwareBody());
                    appChannel.write(makeUTF8StringMessage(APP_SYNC, SYNC_DEFAULT_MESSAGE_ID, body),
                            appChannel.voidPromise());
                }
            }
        }
    }

    public boolean isSplitMode() {
        return split;
    }

    @Override
    public PinMode getModeType() {
        return PinMode.out;
    }


    @Override
    public int getPrice() {
        return 400;
    }
}
