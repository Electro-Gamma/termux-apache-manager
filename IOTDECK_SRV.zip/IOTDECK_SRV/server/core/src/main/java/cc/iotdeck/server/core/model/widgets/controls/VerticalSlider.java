package cc.iotdeck.server.core.model.widgets.controls;

/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 21.03.15.
 */
public class VerticalSlider extends Slider {

}
