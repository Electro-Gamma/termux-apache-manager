/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 17.05.18.
 */
module cc.iotdeck.core {
    exports cc.iotdeck.server.core.dao;
    exports cc.iotdeck.server;
    exports cc.iotdeck.server.core.dao.ota;
    exports cc.iotdeck.server.core.model.auth;
    exports cc.iotdeck.server.core.protocol.enums;
    exports cc.iotdeck.server.core.protocol.handlers;
    exports cc.iotdeck.server.core.model.serialization;
    exports cc.iotdeck.server.core.stats;
    exports cc.iotdeck.server.core.model;
    exports cc.iotdeck.server.core.stats.model;
    exports cc.iotdeck.server.core;
    exports cc.iotdeck.server.core.model.enums;
    exports cc.iotdeck.server.core.model.storage;
    exports cc.iotdeck.server.core.model.widgets;
    exports cc.iotdeck.server.core.model.widgets.notifications;
    exports cc.iotdeck.server.core.model.widgets.others.rtc;
    exports cc.iotdeck.server.core.model.widgets.outputs.graph;
    exports cc.iotdeck.server.core.model.widgets.ui.tiles;
    exports cc.iotdeck.server.core.model.widgets.ui.reporting;
    exports cc.iotdeck.server.core.processors;
    exports cc.iotdeck.server.core.protocol.exceptions;
    exports cc.iotdeck.server.db;
    exports cc.iotdeck.server.internal;
    exports cc.iotdeck.server.common;
    exports cc.iotdeck.server.core.model.device;
    exports cc.iotdeck.server.workers.timer;
    exports cc.iotdeck.server.core.model.widgets.others.eventor;
    exports cc.iotdeck.server.core.model.widgets.others.webhook;
    exports cc.iotdeck.server.core.reporting.average;
    exports cc.iotdeck.server.core.reporting.raw;
    exports cc.iotdeck.server.core.reporting;
    exports cc.iotdeck.server.db.model;
    exports cc.iotdeck.server.db.dao;
    exports cc.iotdeck.server.core.protocol.model.messages;
    exports cc.iotdeck.server.core.session;
    exports cc.iotdeck.server.core.model.widgets.controls;
    exports cc.iotdeck.server.transport;
    exports cc.iotdeck.server.workers;
    exports cc.iotdeck.server.core.model.storage.key;
    exports cc.iotdeck.server.core.model.storage.value;
    exports cc.iotdeck.server.core.model.widgets.ui;
    requires cc.iotdeck.server.notifications.mail;
    requires cc.iotdeck.server.notifications.push;
    requires cc.iotdeck.server.notifications.sms;
    requires cc.iotdeck.server.notifications.twitter;
    requires cc.iotdeck.server.acme;
    requires cc.iotdeck.utils;
    requires io.netty.transport.epoll;
    requires io.netty.common;
    requires io.netty.transport;
    requires io.netty.handler;
    requires io.netty.buffer;
    requires io.netty.codec;
    requires io.netty.codec.http;
    requires async.http.client;
    requires com.zaxxer.hikari;
    requires java.sql;
    requires com.fasterxml.jackson.databind;
    requires com.fasterxml.jackson.annotation;
    requires org.apache.logging.log4j;
    requires com.fasterxml.jackson.core;
}