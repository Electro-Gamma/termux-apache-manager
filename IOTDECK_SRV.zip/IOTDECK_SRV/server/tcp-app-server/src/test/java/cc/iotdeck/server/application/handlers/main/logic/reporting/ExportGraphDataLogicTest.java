package cc.iotdeck.server.application.handlers.main.logic.reporting;

/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 09.07.16.
 */
public class ExportGraphDataLogicTest {
}
