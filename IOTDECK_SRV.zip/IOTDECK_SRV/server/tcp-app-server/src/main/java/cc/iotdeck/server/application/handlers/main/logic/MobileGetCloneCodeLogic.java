package cc.iotdeck.server.application.handlers.main.logic;

import cc.iotdeck.server.Holder;
import cc.iotdeck.server.core.model.DashBoard;
import cc.iotdeck.server.core.model.auth.User;
import cc.iotdeck.server.core.model.serialization.CopyUtil;
import cc.iotdeck.server.core.model.serialization.JsonParser;
import cc.iotdeck.server.core.protocol.model.messages.MessageBase;
import cc.iotdeck.server.core.protocol.model.messages.StringMessage;
import cc.iotdeck.utils.TokenGeneratorUtil;
import io.netty.channel.ChannelHandlerContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import static cc.iotdeck.server.core.protocol.enums.Command.GET_CLONE_CODE;
import static cc.iotdeck.server.internal.CommonByteBufUtil.makeASCIIStringMessage;
import static cc.iotdeck.server.internal.CommonByteBufUtil.serverError;

/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 2/1/2015.
 *
 */
public final class MobileGetCloneCodeLogic {

    private static final Logger log = LogManager.getLogger(MobileGetCloneCodeLogic.class);

    private MobileGetCloneCodeLogic() {
    }

    public static void messageReceived(Holder holder, ChannelHandlerContext ctx,
                                       User user, StringMessage message) {
        int dashId = Integer.parseInt(message.body);

        //todo all this is very ugly, however takes 5 min for implementation, also this is rare feature
        DashBoard dash = user.profile.getDashByIdOrThrow(dashId);
        DashBoard copiedDash = CopyUtil.deepCopy(dash);
        copiedDash.eraseWidgetValues();

        String json = JsonParser.toJsonRestrictiveDashboard(copiedDash);
        String qrToken = TokenGeneratorUtil.generateNewToken();

        holder.blockingIOProcessor.executeDB(() -> {
            MessageBase result;
            try {
                boolean insertStatus = holder.dbManager.insertClonedProject(qrToken, json);
                if (insertStatus || holder.fileManager.writeCloneProjectToDisk(qrToken, json)) {
                    result = makeASCIIStringMessage(GET_CLONE_CODE, message.id, qrToken);
                } else {
                    log.error("Creating clone project failed for {}", user.email);
                    result = serverError(message.id);
                }
            } catch (Exception e) {
                log.error("Error cloning project.", e);
                result = serverError(message.id);
            }
            ctx.writeAndFlush(result, ctx.voidPromise());
        });
    }
}
