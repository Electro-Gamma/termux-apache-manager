package cc.iotdeck.server.application.handlers.main.logic;

import cc.iotdeck.server.Holder;
import cc.iotdeck.server.core.BlockingIOProcessor;
import cc.iotdeck.server.core.dao.FileManager;
import cc.iotdeck.server.core.dao.TokenManager;
import cc.iotdeck.server.core.dao.UserKey;
import cc.iotdeck.server.core.model.DashBoard;
import cc.iotdeck.server.core.model.auth.User;
import cc.iotdeck.server.core.model.device.Device;
import cc.iotdeck.server.core.model.serialization.JsonParser;
import cc.iotdeck.server.core.protocol.model.messages.MessageBase;
import cc.iotdeck.server.core.protocol.model.messages.StringMessage;
import cc.iotdeck.server.db.DBManager;
import cc.iotdeck.server.workers.timer.TimerWorker;
import cc.iotdeck.utils.ArrayUtil;
import cc.iotdeck.utils.ByteUtils;
import cc.iotdeck.utils.StringUtils;
import cc.iotdeck.utils.TokenGeneratorUtil;
import io.netty.channel.ChannelHandlerContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;

import static cc.iotdeck.server.core.protocol.enums.Command.GET_PROJECT_BY_CLONE_CODE;
import static cc.iotdeck.server.internal.CommonByteBufUtil.energyLimit;
import static cc.iotdeck.server.internal.CommonByteBufUtil.makeBinaryMessage;
import static cc.iotdeck.server.internal.CommonByteBufUtil.notAllowed;
import static cc.iotdeck.server.internal.CommonByteBufUtil.quotaLimit;
import static cc.iotdeck.server.internal.CommonByteBufUtil.serverError;
import static cc.iotdeck.utils.StringUtils.split2;

/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 2/1/2015.
 *
 */
public class MobileGetProjectByClonedTokenLogic {

    private static final Logger log = LogManager.getLogger(MobileGetProjectByClonedTokenLogic.class);

    private final BlockingIOProcessor blockingIOProcessor;
    private final DBManager dbManager;
    private final FileManager fileManager;
    private final TimerWorker timerWorker;
    private final TokenManager tokenManager;
    private final int dashMaxLimit;

    public MobileGetProjectByClonedTokenLogic(Holder holder) {
        this.blockingIOProcessor = holder.blockingIOProcessor;
        this.dbManager = holder.dbManager;
        this.fileManager = holder.fileManager;
        this.dashMaxLimit = holder.limits.dashboardsLimit;
        this.timerWorker = holder.timerWorker;
        this.tokenManager = holder.tokenManager;
    }

    public void messageReceived(ChannelHandlerContext ctx, User user, StringMessage message) {
        String token;
        boolean newFlow;
        if (message.body.contains(StringUtils.BODY_SEPARATOR_STRING)) {
            newFlow = true;
            token = split2(message.body)[0];
        } else {
            newFlow = false;
            token = message.body;
        }

        blockingIOProcessor.executeDB(() -> {
            MessageBase result;
            try {
                String json = dbManager.selectClonedProject(token);
                //no cloned project in DB, checking local storage on disk
                if (json == null) {
                    json = fileManager.readClonedProjectFromDisk(token);
                }
                if (json == null) {
                    log.debug("Cannot find request clone QR. {}", token);
                    result = serverError(message.id);
                } else {
                    if (newFlow) {
                        result = createDashboard(user, json, message.id);
                    } else {
                        byte[] data = ByteUtils.compress(json);
                        result = makeBinaryMessage(GET_PROJECT_BY_CLONE_CODE, message.id, data);
                    }
                }
            } catch (Exception e) {
                log.error("Error getting cloned project.", e);
                result = serverError(message.id);
            }
            ctx.writeAndFlush(result, ctx.voidPromise());
        });
    }

    private MessageBase createDashboard(User user, String dashString, int msgId) throws IOException {
        DashBoard newDash = JsonParser.parseDashboard(dashString, msgId);
        newDash.id = max(user.profile.dashBoards) + 1;
        newDash.isPreview = false;
        newDash.parentId = -1;
        newDash.isShared = false;

        if (user.profile.dashBoards.length >= dashMaxLimit) {
            log.debug("Dashboards limit reached.");
            return quotaLimit(msgId);
        }

        for (DashBoard dashBoard : user.profile.dashBoards) {
            if (dashBoard.id == newDash.id) {
                log.debug("Dashboard already exists.");
                return notAllowed(msgId);
            }
        }

        log.info("Creating new cloned dashboard.");

        if (newDash.createdAt == 0) {
            newDash.createdAt = System.currentTimeMillis();
        }

        int price = newDash.energySum();
        if (user.notEnoughEnergy(price)) {
            log.debug("Not enough energy.");
            return energyLimit(msgId);
        }
        user.subtractEnergy(price);
        user.profile.dashBoards = ArrayUtil.add(user.profile.dashBoards, newDash, DashBoard.class);

        if (newDash.devices != null) {
            for (Device device : newDash.devices) {
                String token = TokenGeneratorUtil.generateNewToken();
                tokenManager.assignToken(user, newDash, device, token);
            }
        }

        user.lastModifiedTs = System.currentTimeMillis();

        newDash.addTimers(timerWorker, new UserKey(user));

        byte[] data = ByteUtils.compress(newDash.toString());
        return makeBinaryMessage(GET_PROJECT_BY_CLONE_CODE, msgId, data);
    }

    private int max(DashBoard[] data) {
        int result = 0;
        for (DashBoard dash : data) {
            result = Math.max(result, dash.id);
        }
        return result;
    }
}
