package cc.iotdeck.server.application.handlers.main.logic;

import cc.iotdeck.server.core.model.auth.User;
import cc.iotdeck.server.core.protocol.model.messages.StringMessage;
import io.netty.channel.ChannelHandlerContext;

import static cc.iotdeck.server.core.protocol.enums.Command.GET_ENERGY;
import static cc.iotdeck.server.internal.CommonByteBufUtil.makeASCIIStringMessage;

/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 14.03.16.
 */
public final class MobileGetEnergyLogic {

    private MobileGetEnergyLogic() {
    }

    public static void messageReceived(ChannelHandlerContext ctx, User user, StringMessage message) {
        if (ctx.channel().isWritable()) {
            ctx.writeAndFlush(makeASCIIStringMessage(GET_ENERGY, message.id, "" + user.energy), ctx.voidPromise());
        }
    }

}
