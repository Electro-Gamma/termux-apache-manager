package cc.iotdeck.server.application.handlers.main.logic;

import cc.iotdeck.server.Holder;
import cc.iotdeck.server.application.handlers.main.auth.MobileStateHolder;
import cc.iotdeck.server.core.model.DashBoard;
import cc.iotdeck.server.core.model.auth.Session;
import cc.iotdeck.server.core.model.auth.User;
import cc.iotdeck.server.core.model.device.Device;
import cc.iotdeck.server.core.protocol.model.messages.StringMessage;
import cc.iotdeck.utils.StringUtils;
import io.netty.channel.ChannelHandlerContext;

import static cc.iotdeck.server.core.protocol.enums.Command.REFRESH_TOKEN;
import static cc.iotdeck.server.internal.CommonByteBufUtil.illegalCommandBody;
import static cc.iotdeck.server.internal.CommonByteBufUtil.makeUTF8StringMessage;

/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 2/1/2015.
 *
 */
public final class MobileRefreshTokenLogic {

    private MobileRefreshTokenLogic() {
    }

    public static void messageReceived(Holder holder, ChannelHandlerContext ctx,
                                       MobileStateHolder state, StringMessage message) {
        String[] split = StringUtils.split2(message.body);

        int dashId = Integer.parseInt(split[0]);
        int deviceId = 0;

        //new value for multi devices
        if (split.length == 2) {
            deviceId = Integer.parseInt(split[1]);
        }

        User user = state.user;

        DashBoard dash = user.profile.getDashByIdOrThrow(dashId);
        Device device = user.profile.getDeviceById(dash, deviceId);

        if (device == null) {
            ctx.writeAndFlush(illegalCommandBody(message.id), ctx.voidPromise());
            return;
        }

        String token = holder.tokenManager.refreshToken(user, dash, device);

        Session session = holder.sessionDao.get(state.userKey);
        session.closeHardwareChannelByDeviceId(dashId, deviceId);

        if (ctx.channel().isWritable()) {
            ctx.writeAndFlush(makeUTF8StringMessage(REFRESH_TOKEN, message.id, token), ctx.voidPromise());
        }
    }
}
