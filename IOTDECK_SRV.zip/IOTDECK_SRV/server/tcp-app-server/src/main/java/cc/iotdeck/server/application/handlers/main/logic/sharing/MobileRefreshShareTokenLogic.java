package cc.iotdeck.server.application.handlers.main.logic.sharing;

import cc.iotdeck.server.Holder;
import cc.iotdeck.server.application.handlers.main.auth.MobileStateHolder;
import cc.iotdeck.server.application.handlers.sharing.auth.MobileShareStateHolder;
import cc.iotdeck.server.core.model.DashBoard;
import cc.iotdeck.server.core.model.auth.Session;
import cc.iotdeck.server.core.model.auth.User;
import cc.iotdeck.server.core.protocol.exceptions.NotAllowedException;
import cc.iotdeck.server.core.protocol.model.messages.StringMessage;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;

import static cc.iotdeck.server.core.protocol.enums.Command.REFRESH_SHARE_TOKEN;
import static cc.iotdeck.server.internal.CommonByteBufUtil.makeUTF8StringMessage;
import static cc.iotdeck.server.internal.CommonByteBufUtil.notAllowed;
import static cc.iotdeck.utils.MobileStateHolderUtil.getShareState;

/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 2/1/2015.
 *
 */
public final class MobileRefreshShareTokenLogic {

    private MobileRefreshShareTokenLogic() {
    }

    public static void messageReceived(Holder holder, ChannelHandlerContext ctx,
                                       MobileStateHolder state, StringMessage message) {
        String dashBoardIdString = message.body;

        int dashId;
        try {
            dashId = Integer.parseInt(dashBoardIdString);
        } catch (NumberFormatException ex) {
            throw new NotAllowedException("Dash board id not valid. Id : " + dashBoardIdString, message.id);
        }

        User user = state.user;
        DashBoard dash = user.profile.getDashByIdOrThrow(dashId);

        String token = holder.tokenManager.refreshSharedToken(user, dash);

        //todo move to session class?
        Session session = holder.sessionDao.get(state.userKey);
        for (Channel appChannel : session.appChannels) {
            MobileShareStateHolder localState = getShareState(appChannel);
            if (localState != null && localState.dashId == dashId) {
                appChannel.writeAndFlush(notAllowed(message.id))
                          .addListener(ChannelFutureListener.CLOSE);
            }
        }

        if (ctx.channel().isWritable()) {
            ctx.writeAndFlush(makeUTF8StringMessage(REFRESH_SHARE_TOKEN, message.id, token), ctx.voidPromise());
        }
    }
}
