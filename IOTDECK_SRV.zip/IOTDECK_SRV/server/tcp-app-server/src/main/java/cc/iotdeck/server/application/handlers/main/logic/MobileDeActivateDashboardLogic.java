package cc.iotdeck.server.application.handlers.main.logic;

import cc.iotdeck.server.Holder;
import cc.iotdeck.server.application.handlers.main.auth.MobileStateHolder;
import cc.iotdeck.server.core.dao.SessionDao;
import cc.iotdeck.server.core.dao.SharedTokenManager;
import cc.iotdeck.server.core.model.DashBoard;
import cc.iotdeck.server.core.protocol.model.messages.StringMessage;
import io.netty.channel.ChannelHandlerContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import static cc.iotdeck.server.internal.CommonByteBufUtil.ok;

/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 2/1/2015.
 *
 */
public final class MobileDeActivateDashboardLogic {

    private static final Logger log = LogManager.getLogger(MobileActivateDashboardLogic.class);

    private MobileDeActivateDashboardLogic() {
    }

    public static void messageReceived(Holder holder, ChannelHandlerContext ctx,
                                       MobileStateHolder state, StringMessage message) {
        var user = state.user;

        String sharedToken;
        if (message.body.length() > 0) {
            log.debug("DeActivating dash {} for user {}", message.body, user.email);
            int dashId = Integer.parseInt(message.body);
            DashBoard dashBoard = user.profile.getDashByIdOrThrow(dashId);
            dashBoard.deactivate();
            sharedToken = dashBoard.sharedToken;
        } else {
            for (DashBoard dashBoard : user.profile.dashBoards) {
                dashBoard.deactivate();
            }
            sharedToken = SharedTokenManager.ALL;
        }
        user.lastModifiedTs = System.currentTimeMillis();

        SessionDao sessionDao = holder.sessionDao;
        var session = sessionDao.get(state.userKey);
        session.sendToSharedApps(ctx.channel(), sharedToken, message.command, message.id, message.body);
        ctx.writeAndFlush(ok(message.id), ctx.voidPromise());
    }

}
