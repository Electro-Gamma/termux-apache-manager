package cc.iotdeck.core.http.model;

/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 07.12.15.
 */
public class Filter {

    public String name;

}
