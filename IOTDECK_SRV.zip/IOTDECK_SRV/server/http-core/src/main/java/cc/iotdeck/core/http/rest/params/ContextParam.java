package cc.iotdeck.core.http.rest.params;

import cc.iotdeck.core.http.rest.URIDecoder;
import io.netty.channel.ChannelHandlerContext;

/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 09.12.15.
 */
public class ContextParam extends Param {

    public ContextParam(Class<?> type) {
        super(null, type);
    }

    @Override
    public Object get(ChannelHandlerContext ctx, URIDecoder uriDecoder) {
        return ctx;
    }

}
