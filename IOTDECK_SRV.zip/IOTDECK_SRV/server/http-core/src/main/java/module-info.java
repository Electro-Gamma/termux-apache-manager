/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 17.05.18.
 */
module cc.iotdeck.http.core {
    exports cc.iotdeck.core.http;
    exports cc.iotdeck.core.http.annotation;
    exports cc.iotdeck.core.http.utils;
    exports cc.iotdeck.core.http.model;
    requires io.netty.transport;
    requires io.netty.codec.http;
    requires cc.iotdeck.core;
    requires io.netty.common;
    requires org.apache.logging.log4j;
    requires cc.iotdeck.utils;
    requires io.netty.buffer;
    requires io.netty.handler;
    requires com.fasterxml.jackson.core;
    requires com.fasterxml.jackson.databind;
}