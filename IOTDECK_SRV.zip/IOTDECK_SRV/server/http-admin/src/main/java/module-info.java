/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 17.05.18.
 */
module http.admin {
    requires cc.iotdeck.http.core;
    requires cc.iotdeck.core;
    requires cc.iotdeck.utils;
    requires io.netty.transport;
    requires java.management;
    requires org.apache.logging.log4j;
}