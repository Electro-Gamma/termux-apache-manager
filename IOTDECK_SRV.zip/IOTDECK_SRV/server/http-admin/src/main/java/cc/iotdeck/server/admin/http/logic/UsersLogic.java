package cc.iotdeck.server.admin.http.logic;

import cc.iotdeck.core.http.CookiesBaseHttpHandler;
import cc.iotdeck.core.http.Response;
import cc.iotdeck.core.http.annotation.Consumes;
import cc.iotdeck.core.http.annotation.DELETE;
import cc.iotdeck.core.http.annotation.GET;
import cc.iotdeck.core.http.annotation.PUT;
import cc.iotdeck.core.http.annotation.Path;
import cc.iotdeck.core.http.annotation.PathParam;
import cc.iotdeck.core.http.annotation.QueryParam;
import cc.iotdeck.core.http.model.Filter;
import cc.iotdeck.server.Holder;
import cc.iotdeck.server.core.dao.FileManager;
import cc.iotdeck.server.core.dao.ReportingDiskDao;
import cc.iotdeck.server.core.dao.SessionDao;
import cc.iotdeck.server.core.dao.TokenManager;
import cc.iotdeck.server.core.dao.TokenValue;
import cc.iotdeck.server.core.dao.UserDao;
import cc.iotdeck.server.core.dao.UserKey;
import cc.iotdeck.server.core.model.DashBoard;
import cc.iotdeck.server.core.model.auth.Session;
import cc.iotdeck.server.core.model.auth.User;
import cc.iotdeck.server.core.model.device.Device;
import cc.iotdeck.server.core.model.serialization.JsonParser;
import cc.iotdeck.server.db.DBManager;
import cc.iotdeck.utils.SHA256Util;
import cc.iotdeck.utils.TokenGeneratorUtil;
import cc.iotdeck.utils.http.MediaType;
import cc.iotdeck.utils.validators.IOTDeckEmailValidator;
import io.netty.channel.ChannelHandler;

import java.util.List;

import static cc.iotdeck.core.http.Response.appendTotalCountHeader;
import static cc.iotdeck.core.http.Response.badRequest;
import static cc.iotdeck.core.http.Response.notFound;
import static cc.iotdeck.core.http.Response.ok;
import static cc.iotdeck.core.http.utils.AdminHttpUtil.sort;


/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 03.12.15.
 */
@Path("/users")
@ChannelHandler.Sharable
public class UsersLogic extends CookiesBaseHttpHandler {

    private final UserDao userDao;
    private final FileManager fileManager;
    private final DBManager dbManager;
    private final ReportingDiskDao reportingDao;

    public UsersLogic(Holder holder, String rootPath) {
        super(holder, rootPath);
        this.userDao = holder.userDao;
        this.fileManager = holder.fileManager;
        this.dbManager = holder.dbManager;
        this.reportingDao = holder.reportingDiskDao;
    }

    //for tests only
    public UsersLogic(UserDao userDao, SessionDao sessionDao, DBManager dbManager,
                      FileManager fileManager, TokenManager tokenManager,
                      ReportingDiskDao reportingDao, String rootPath) {
        super(tokenManager, sessionDao, null, rootPath);
        this.userDao = userDao;
        this.fileManager = fileManager;
        this.dbManager = dbManager;
        this.reportingDao = reportingDao;
    }

    @GET
    @Path("")
    public Response getUsers(@QueryParam("_filters") String filterParam,
                             @QueryParam("_page") int page,
                             @QueryParam("_perPage") int size,
                             @QueryParam("_sortField") String sortField,
                             @QueryParam("_sortDir") String sortOrder) {
        if (filterParam != null) {
            Filter filter = JsonParser.readAny(filterParam, Filter.class);
            filterParam = filter == null ? null : filter.name;
        }

        List<User> users = userDao.searchByUsername(filterParam, null);
        return appendTotalCountHeader(
                ok(sort(users, sortField, sortOrder), page, size), users.size()
        );
    }

    @GET
    @Path("/{id}")
    public Response getUserByName(@PathParam("id") String id) {
        String[] parts =  slitByLast(id);
        String email = parts[0];
        String appName = parts[1];
        User user = userDao.getByName(email, appName);
        if (user == null) {
            return notFound();
        }
        return ok(user);
    }

    @GET
    @Path("/names/getAll")
    public Response getAllUserNames() {
        return ok(userDao.users.keySet());
    }

    @GET
    @Path("/token/assign")
    public Response assignToken(@QueryParam("old") String oldToken, @QueryParam("new") String newToken) {
        TokenValue tokenValue = tokenManager.getTokenValueByToken(oldToken);

        if (tokenValue == null) {
            return badRequest("This token not exists.");
        }

        tokenManager.assignToken(tokenValue.user, tokenValue.dash, tokenValue.device, newToken);
        return ok();
    }

    @GET
    @Path("/token/force")
    public Response forceToken(@QueryParam("email") String email,
                               @QueryParam("app") String app,
                               @QueryParam("dashId") int dashId,
                               @QueryParam("deviceId") int deviceId,
                               @QueryParam("new") String newToken) {

        User user = userDao.getUsers().get(new UserKey(email, app));

        if (user == null) {
            return badRequest("No user with such email.");
        }

        DashBoard dash = user.profile.getDashByIdOrThrow(dashId);
        Device device = user.profile.getDeviceById(dash, deviceId);

        tokenManager.assignToken(user, dash, device, newToken);
        return ok();
    }

    @PUT
    @Consumes(value = MediaType.APPLICATION_JSON)
    @Path("/{id}")
    public Response updateUser(@PathParam("id") String id,
                               User updatedUser) {

        log.debug("Updating user {}", id);

        String[] parts =  slitByLast(id);
        String name = parts[0];
        String appName = parts[1];

        User oldUser = userDao.getByName(name, appName);

        //name was changed, but not password - do not allow this.
        //as name is used as salt for pass generation
        if (!updatedUser.email.equals(oldUser.email) && updatedUser.pass.equals(oldUser.pass)) {
            return badRequest("You need also change password when changing email.");
        }

        if (IOTDeckEmailValidator.isNotValidEmail(updatedUser.email)) {
            return badRequest("Wring email address.");
        }

        //user name was changed
        if (!updatedUser.email.equals(oldUser.email)) {
            deleteUserByName(id);
            for (DashBoard dashBoard : oldUser.profile.dashBoards) {
                for (Device device : dashBoard.devices) {
                    String token;
                    if (device.token == null) {
                        token = TokenGeneratorUtil.generateNewToken();
                    } else {
                        token = device.token;
                    }
                    tokenManager.assignToken(updatedUser, dashBoard, device, token);
                }
            }
        }

        //if pass was changed, call hash function.
        if (!updatedUser.pass.equals(oldUser.pass)) {
            log.debug("Updating pass for {}.", updatedUser.email);
            updatedUser.pass = SHA256Util.makeHash(updatedUser.pass, updatedUser.email);
        }

        userDao.add(updatedUser);

        for (DashBoard dash : updatedUser.profile.dashBoards) {
            for (Device device : dash.devices) {
                if (device.token != null) {
                    tokenManager.updateRegularCache(device.token, updatedUser, dash, device);
                }
            }
            if (dash.sharedToken != null) {
                tokenManager.updateSharedCache(dash.sharedToken, updatedUser, dash.id);
            }
        }

        updatedUser.lastModifiedTs = System.currentTimeMillis();
        log.debug("Adding new user {}", updatedUser.email);

        return ok(updatedUser);
    }

    @DELETE
    @Path("/{id}")
    public Response deleteUserByName(@PathParam("id") String id) {
        String[] parts =  slitByLast(id);
        String email = parts[0];
        String appName = parts[1];

        UserKey userKey = new UserKey(email, appName);
        User user = userDao.delete(userKey);
        if (user == null) {
            return notFound();
        }

        if (!fileManager.delete(email, appName)) {
            return notFound();
        }

        reportingDao.delete(user);

        dbManager.deleteUser(userKey);

        Session session = sessionDao.userSession.remove(userKey);
        if (session != null) {
            session.closeAll();
        }

        log.info("User {} successfully removed.", email);

        return ok();
    }

    private String[] slitByLast(String id) {
        int i = id.lastIndexOf("-");
        return new String[] {
                id.substring(0, i),
                id.substring(i + 1)
        };
    }

}
