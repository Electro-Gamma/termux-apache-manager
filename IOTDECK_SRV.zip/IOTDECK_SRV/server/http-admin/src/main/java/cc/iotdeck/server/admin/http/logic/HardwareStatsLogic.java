package cc.iotdeck.server.admin.http.logic;

import cc.iotdeck.core.http.CookiesBaseHttpHandler;
import cc.iotdeck.core.http.Response;
import cc.iotdeck.core.http.annotation.GET;
import cc.iotdeck.core.http.annotation.Path;
import cc.iotdeck.core.http.annotation.QueryParam;
import cc.iotdeck.server.Holder;
import cc.iotdeck.server.core.dao.UserDao;
import io.netty.channel.ChannelHandler;

import static cc.iotdeck.core.http.Response.ok;
import static cc.iotdeck.core.http.utils.AdminHttpUtil.convertMapToPair;
import static cc.iotdeck.core.http.utils.AdminHttpUtil.sort;
import static cc.iotdeck.core.http.utils.AdminHttpUtil.sortStringAsInt;

/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 09.12.15.
 */
@Path("/hardwareInfo")
@ChannelHandler.Sharable
public class HardwareStatsLogic extends CookiesBaseHttpHandler {

    private final UserDao userDao;

    public HardwareStatsLogic(Holder holder, String rootPath) {
        super(holder, rootPath);
        this.userDao = holder.userDao;
    }

    @GET
    @Path("/iotdeckVersion")
    public Response getLibraryVersion(@QueryParam("_sortField") String sortField,
                                      @QueryParam("_sortDir") String sortOrder) {
        return ok(sortStringAsInt(convertMapToPair(userDao.getLibraryVersion()), sortField, sortOrder));
    }

    @GET
    @Path("/cpuType")
    public Response getBoards(@QueryParam("_sortField") String sortField,
                              @QueryParam("_sortDir") String sortOrder) {
        return ok(sort(convertMapToPair(userDao.getCpuType()), sortField, sortOrder));
    }

    @GET
    @Path("/connectionType")
    public Response getFacebookLogins(@QueryParam("_sortField") String sortField,
                                      @QueryParam("_sortDir") String sortOrder) {
        return ok(sort(convertMapToPair(userDao.getConnectionType()), sortField, sortOrder));
    }

    @GET
    @Path("/boards")
    public Response getHardwareBoards(@QueryParam("_sortField") String sortField,
                                      @QueryParam("_sortDir") String sortOrder) {
        return ok(sort(convertMapToPair(userDao.getHardwareBoards()), sortField, sortOrder));
    }

}
