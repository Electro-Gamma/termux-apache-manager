## HOW TO 

### Configure

Just edit the Dockerfile and change ENV vars


### Build

```bash
docker build -t iotdeck .
```

### RUN

```bash
docker run --name iotdeck-server -v ~/iotdeck-server/server/Docker:/data -p 8440:8440 -p 8080:8080 -p 9443:9443 -d iotdeck 
```

Don't forget to change the port attribution if you change on the ENV vars in Dockerfile


## UPDATE IOTDeck version

## How to

Stop and remove your actual container

```bash
docker stop iotdeck-server && docker rm iotdeck-server
```

- Edit your IOTDeck server version on the ENV var in Dockerfile
- Build & Launch


Have Fun ! :v: :whale:

