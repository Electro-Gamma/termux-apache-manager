package cc.iotdeck.server.workers;

import cc.iotdeck.server.core.BlockingIOProcessor;
import cc.iotdeck.server.core.dao.FileManager;
import cc.iotdeck.server.core.dao.UserDao;
import cc.iotdeck.server.core.dao.UserKey;
import cc.iotdeck.server.core.model.auth.User;
import cc.iotdeck.server.core.stats.GlobalStats;
import cc.iotdeck.server.db.DBManager;
import cc.iotdeck.utils.AppNameUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import static org.mockito.Mockito.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 3/3/2015.
 */
@RunWith(MockitoJUnitRunner.Silent.class)
public class ProfileSaverWorkerTest {

    @Mock
    private UserDao userDao;

    @Mock
    private FileManager fileManager;

    @Mock
    private GlobalStats stats;

    private BlockingIOProcessor blockingIOProcessor = new BlockingIOProcessor(4, 1);

    @Test
    public void testCorrectProfilesAreSaved() throws IOException {
        ProfileSaverWorker profileSaverWorker = new ProfileSaverWorker(userDao, fileManager, new DBManager(blockingIOProcessor, true));

        User user1 = new User("1", "", AppNameUtil.IOTDECK, "local", "127.0.0.1", false, false);
        User user2 = new User("2", "", AppNameUtil.IOTDECK, "local", "127.0.0.1", false, false);
        User user3 = new User("3", "", AppNameUtil.IOTDECK, "local", "127.0.0.1", false, false);
        User user4 = new User("4", "", AppNameUtil.IOTDECK, "local", "127.0.0.1", false, false);

        ConcurrentMap<UserKey, User> userMap = new ConcurrentHashMap<>();
        userMap.put(new UserKey(user1), user1);
        userMap.put(new UserKey(user2), user2);
        userMap.put(new UserKey(user3), user3);
        userMap.put(new UserKey(user4), user4);

        when(userDao.getUsers()).thenReturn(userMap);
        profileSaverWorker.run();

        verify(fileManager, times(4)).overrideUserFile(any());
        verify(fileManager).overrideUserFile(user1);
        verify(fileManager).overrideUserFile(user2);
        verify(fileManager).overrideUserFile(user3);
        verify(fileManager).overrideUserFile(user4);
    }

    @Test
    public void testNoProfileChanges() throws Exception {
        User user1 = new User("1", "", AppNameUtil.IOTDECK, "local", "127.0.0.1", false, false);
        User user2 = new User("2", "", AppNameUtil.IOTDECK, "local", "127.0.0.1", false, false);
        User user3 = new User("3", "", AppNameUtil.IOTDECK, "local", "127.0.0.1", false, false);
        User user4 = new User("4", "", AppNameUtil.IOTDECK, "local", "127.0.0.1", false, false);

        Map<UserKey, User> userMap = new HashMap<>();
        userMap.put(new UserKey("1", AppNameUtil.IOTDECK), user1);
        userMap.put(new UserKey("2", AppNameUtil.IOTDECK), user2);
        userMap.put(new UserKey("3", AppNameUtil.IOTDECK), user3);
        userMap.put(new UserKey("4", AppNameUtil.IOTDECK), user4);

        Thread.sleep(1);

        ProfileSaverWorker profileSaverWorker = new ProfileSaverWorker(userDao, fileManager, new DBManager(blockingIOProcessor, true));

        when(userDao.getUsers()).thenReturn(userMap);
        profileSaverWorker.run();

        verifyNoMoreInteractions(fileManager);
    }

}
