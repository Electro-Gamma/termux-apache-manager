package cc.iotdeck.server.hardware.internal;

import cc.iotdeck.server.core.dao.TokenValue;
import cc.iotdeck.server.core.dao.UserKey;
import cc.iotdeck.server.core.protocol.model.messages.StringMessage;

/**
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 01.02.18.
 */
public class BridgeForwardMessage {

    public final StringMessage message;

    public final TokenValue tokenValue;

    public final UserKey userKey;

    public BridgeForwardMessage(StringMessage bridgeMessage, TokenValue tokenValue, UserKey userKey) {
        this.message = bridgeMessage;
        this.tokenValue = tokenValue;
        this.userKey = userKey;
    }
}

