package cc.iotdeck.server.hardware.handlers.hardware.logic;

import cc.iotdeck.server.Holder;
import cc.iotdeck.server.core.dao.ota.OTAManager;
import cc.iotdeck.server.core.model.DashBoard;
import cc.iotdeck.server.core.model.device.Device;
import cc.iotdeck.server.core.model.device.HardwareInfo;
import cc.iotdeck.server.core.model.widgets.others.rtc.RTC;
import cc.iotdeck.server.core.protocol.model.messages.StringMessage;
import cc.iotdeck.server.core.session.HardwareStateHolder;
import cc.iotdeck.utils.NumberUtil;
import cc.iotdeck.utils.StringUtils;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.timeout.IdleStateHandler;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import static cc.iotdeck.server.core.protocol.enums.Command.IOTDECK_INTERNAL;
import static cc.iotdeck.server.internal.CommonByteBufUtil.illegalCommand;
import static cc.iotdeck.server.internal.CommonByteBufUtil.makeASCIIStringMessage;
import static cc.iotdeck.server.internal.CommonByteBufUtil.ok;
import static cc.iotdeck.utils.StringUtils.BODY_SEPARATOR;

/**
 *
 * Simple handler that accepts info command from hardware.
 * At the moment only 1 param is used "h-beat".
 *
 * The IOTDeck Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 2/1/2015.
 *
 */
public final class IOTDeckInternalLogic {

    private static final Logger log = LogManager.getLogger(IOTDeckInternalLogic.class);

    private IOTDeckInternalLogic() {
    }

    public static void messageReceived(Holder holder, ChannelHandlerContext ctx,
                                       HardwareStateHolder state, StringMessage message) {
        String[] messageParts = message.body.split(StringUtils.BODY_SEPARATOR_STRING);

        if (messageParts.length == 0 || messageParts[0].length() == 0) {
            ctx.writeAndFlush(illegalCommand(message.id), ctx.voidPromise());
            return;
        }

        String cmd = messageParts[0];

        switch (cmd.charAt(0)) {
            case 'v' : //ver
            case 'f' : //fw
            case 'h' : //h-beat
            case 'b' : //buff-in
            case 'd' : //dev
            case 'c' : //cpu
            case 't' : //tmpl
                parseHardwareInfo(holder, ctx, messageParts, state, message.id);
                break;
            case 'r' : //rtc
                sendRTC(ctx, state, message.id);
                break;
            case 'a' :
            case 'o' :
                break;
        }

    }

    private static void sendRTC(ChannelHandlerContext ctx, HardwareStateHolder state, int msgId) {
        DashBoard dashBoard = state.dash;
        RTC rtc = dashBoard.getWidgetByType(RTC.class);
        if (rtc != null && ctx.channel().isWritable()) {
            ctx.writeAndFlush(makeASCIIStringMessage(IOTDECK_INTERNAL, msgId, "rtc" + BODY_SEPARATOR + rtc.getTime()),
                    ctx.voidPromise());
        }
    }

    private static void parseHardwareInfo(Holder holder, ChannelHandlerContext ctx,
                                          String[] messageParts,
                                          HardwareStateHolder state, int msgId) {
        HardwareInfo hardwareInfo = new HardwareInfo(messageParts);
        int newHardwareInterval = hardwareInfo.heartbeatInterval;

        log.trace("Info command. heartbeat interval {}", newHardwareInterval);
        OTAManager otaManager = holder.otaManager;
        int hardwareIdleTimeout = holder.limits.hardwareIdleTimeout;

        //no need to change IdleStateHandler if heartbeat interval wasn't changed or wasn't provided
        if (hardwareIdleTimeout != 0 && newHardwareInterval > 0 && newHardwareInterval != hardwareIdleTimeout) {
            int newReadTimeout = NumberUtil.calcHeartbeatTimeout(newHardwareInterval);
            log.debug("Changing read timeout interval to {}", newReadTimeout);
            ctx.pipeline().replace(IdleStateHandler.class,
                    "H_IdleStateHandler_Replaced", new IdleStateHandler(newReadTimeout, 0, 0));
        }

        DashBoard dashBoard = state.dash;
        Device device = state.device;

        if (device != null) {
            otaManager.initiateHardwareUpdate(ctx, state.userKey, hardwareInfo, dashBoard, device);
            device.hardwareInfo = hardwareInfo;
            dashBoard.updatedAt = System.currentTimeMillis();
        }

        ctx.writeAndFlush(ok(msgId), ctx.voidPromise());
    }

}
