package com.example.rtl8821cu.chip

import com.example.rtl8821cu.usb.RegisterIo

/**
 * Ports init_trx_cfg_8821c() (hal/halmac/halmac_88xx/halmac_8821c/halmac_init_8821c.c:355-390),
 * called from init_mac_flow() (hal/hal_halmac.c:3159) via
 * api->halmac_init_mac_cfg() — the step the real driver runs right after
 * a successful firmware download and before the first H2C command.
 *
 * Three things happen here:
 *  1. txdma_queue_mapping_8821c() — assign each 802.11 access-category
 *     queue (VO/VI/BE/BK/MGMT/HI) to a DMA priority (extra/low/normal/high),
 *     using the fixed table for a 3-bulkout-endpoint USB device (confirmed
 *     via UsbBridge.findBulkOutEndpoints() — this dongle has exactly 3).
 *  2. priority_queue_cfg_8821c() — compute the TX FIFO page budget (which
 *     also finally gives real, non-zero values for rsvdBoundary/h2cqAddr/
 *     fwTxBufAddr — during Phase 1 these were genuinely 0, since nothing
 *     had computed them yet; that wasn't a simplification, it was correct
 *     for that point in the sequence), write the resulting page-count
 *     registers, then trigger + poll the hardware's link-list-table
 *     auto-init.
 *  3. init_h2c_8821c() — carve out an 8-page circular buffer for H2C
 *     packets and point the hardware's head/tail/read-address registers
 *     at it.
 *
 * Only the USB, NORMAL-trx-mode, non-loopback path is implemented — the
 * SDIO/PCIe branches and other trx modes in the source are dead code for
 * this project.
 */
class MacInit(private val io: RegisterIo, private val log: (String) -> Unit) {

    class MacInitException(message: String) : Exception(message)

    /** Page-based TX FIFO layout, computed once and reused by later phases. */
    class TxFifoLayout(
        val rsvdBoundaryPages: Int,
        val h2cqAddrPages: Int,
        val fwTxBufAddrPages: Int
    )

    private val R = Rtl8821cRegs

    fun run(): TxFifoLayout {
        queueMapping()
        val layout = priorityQueueCfg()
        initH2cQueue(layout)
        log("MAC init complete (rsvd_boundary=${layout.rsvdBoundaryPages} pages, " +
                "h2cq_addr=${layout.h2cqAddrPages} pages, fw_txbuf_addr=${layout.fwTxBufAddrPages} pages)")
        return layout
    }

    /** txdma_queue_mapping_8821c(), halmac_init_8821c.c:400-442.
     *  HALMAC_RQPN_3BULKOUT_8821C[NORMAL] row (halmac_init_8821c.c:157-159). */
    private fun queueMapping() {
        val hi = R.DMA_MAPPING_HIGH
        val mg = R.DMA_MAPPING_HIGH
        val bk = R.DMA_MAPPING_LOW
        val be = R.DMA_MAPPING_LOW
        val vi = R.DMA_MAPPING_NORMAL
        val vo = R.DMA_MAPPING_NORMAL

        var value16 = 0
        value16 = value16 or (hi shl R.SHIFT_TXDMA_HIQ_MAP)
        value16 = value16 or (mg shl R.SHIFT_TXDMA_MGQ_MAP)
        value16 = value16 or (bk shl R.SHIFT_TXDMA_BKQ_MAP)
        value16 = value16 or (be shl R.SHIFT_TXDMA_BEQ_MAP)
        value16 = value16 or (vi shl R.SHIFT_TXDMA_VIQ_MAP)
        value16 = value16 or (vo shl R.SHIFT_TXDMA_VOQ_MAP)
        io.write16(R.REG_TXDMA_PQ_MAP, value16)
    }

    /** priority_queue_cfg_8821c() + set_trx_fifo_info_8821c(),
     *  halmac_init_8821c.c:444-567 and :569-620. */
    private fun priorityQueueCfg(): TxFifoLayout {
        // set_trx_fifo_info_8821c: compute the page budget
        val txFifoPgNum = R.TX_FIFO_SIZE shr R.TX_PAGE_SIZE_SHIFT // 512 pages
        val rsvdPgNum = R.RSVD_PG_DRV_NUM + R.RSVD_PG_H2C_EXTRAINFO_NUM +
                R.RSVD_PG_H2C_STATICINFO_NUM + R.RSVD_PG_H2CQ_NUM +
                R.RSVD_PG_CPU_INSTRUCTION_NUM + R.RSVD_PG_FW_TXBUF_NUM + R.RSVD_PG_CSIBUF_NUM
        if (rsvdPgNum > txFifoPgNum) throw MacInitException("Reserved page count exceeds TX FIFO size")

        val acqPgNum = txFifoPgNum - rsvdPgNum
        val rsvdBoundary = acqPgNum

        var curPgAddr = txFifoPgNum
        curPgAddr -= R.RSVD_PG_CSIBUF_NUM
        curPgAddr -= R.RSVD_PG_FW_TXBUF_NUM
        val fwTxBufAddr = curPgAddr
        curPgAddr -= R.RSVD_PG_CPU_INSTRUCTION_NUM
        curPgAddr -= R.RSVD_PG_H2CQ_NUM
        val h2cqAddr = curPgAddr

        // NORMAL-mode, 3-bulkout page counts: HALMAC_PG_NUM_3BULKOUT_8821C
        // {hq=16, nq=16, lq=16, exq=0, gap=1} (halmac_init_8821c.c:249)
        val highQueuePgNum = 16
        val lowQueuePgNum = 16
        val normalQueuePgNum = 16
        val extraQueuePgNum = 0
        val gapNum = 1
        val pubQueuePgNum = acqPgNum - highQueuePgNum - lowQueuePgNum - normalQueuePgNum -
                extraQueuePgNum - gapNum
        if (pubQueuePgNum < 0) throw MacInitException("Negative public-queue page count — page budget math is off")

        io.write16(R.REG_FIFOPAGE_INFO_1, highQueuePgNum)
        io.write16(R.REG_FIFOPAGE_INFO_2, lowQueuePgNum)
        io.write16(R.REG_FIFOPAGE_INFO_3, normalQueuePgNum)
        io.write16(R.REG_FIFOPAGE_INFO_4, extraQueuePgNum)
        io.write16(R.REG_FIFOPAGE_INFO_5, pubQueuePgNum)
        io.write32(R.REG_RQPN_CTRL_2, io.read32(R.REG_RQPN_CTRL_2).toInt() or (1 shl 31))

        io.write16(R.REG_FIFOPAGE_CTRL_2, rsvdBoundary)
        io.write8(R.REG_FWHW_TXQ_CTRL + 2, io.read8(R.REG_FWHW_TXQ_CTRL + 2) or (1 shl 4))
        io.write16(R.REG_BCNQ_BDNY_V1, rsvdBoundary)
        io.write16(R.REG_FIFOPAGE_CTRL_2 + 2, rsvdBoundary)
        io.write16(R.REG_BCNQ1_BDNY_V1, rsvdBoundary)

        io.write32(R.REG_RXFF_BNDY, RX_FIFO_SIZE - R.C2H_PKT_BUF - 1)

        // USB-only block: descriptor-count field + offset-check enable
        var autoLlt = io.read8(R.REG_AUTO_LLT_V1)
        autoLlt = (autoLlt and (0xF shl R.SHIFT_BLK_DESC_NUM).inv()) or (R.BLK_DESC_NUM shl R.SHIFT_BLK_DESC_NUM)
        io.write8(R.REG_AUTO_LLT_V1, autoLlt)
        io.write8(R.REG_AUTO_LLT_V1 + 3, R.BLK_DESC_NUM)
        io.write8(R.REG_TXDMA_OFFSET_CHK + 1, io.read8(R.REG_TXDMA_OFFSET_CHK + 1) or (1 shl 1))

        // Trigger + poll link-list-table auto-init
        io.write8(R.REG_AUTO_LLT_V1, io.read8(R.REG_AUTO_LLT_V1) or R.BIT_AUTO_INIT_LLT_V1)
        var cnt = 1000
        while ((io.read8(R.REG_AUTO_LLT_V1) and R.BIT_AUTO_INIT_LLT_V1) != 0) {
            cnt--
            if (cnt <= 0) throw MacInitException("LLT auto-init timeout (REG_AUTO_LLT_V1)")
        }

        // Normal transfer mode (not loopback) - REG_CR+3 = HALMAC_TRNSFER_NORMAL (0)
        io.write8(R.REG_CR + 3, 0)

        return TxFifoLayout(rsvdBoundary, h2cqAddr, fwTxBufAddr)
    }

    /** init_h2c_8821c(), halmac_init_8821c.c:692-732. */
    private fun initH2cQueue(layout: TxFifoLayout) {
        val h2cqAddrBytes = layout.h2cqAddrPages shl R.TX_PAGE_SIZE_SHIFT
        val h2cqSizeBytes = R.RSVD_PG_H2CQ_NUM shl R.TX_PAGE_SIZE_SHIFT
        val lowBitsMask = 0x0003FFFF.inv() // clears bits [17:0], i.e. 0xFFFC0000

        io.write32(R.REG_H2C_HEAD, (io.read32(R.REG_H2C_HEAD).toInt() and lowBitsMask) or h2cqAddrBytes)
        io.write32(R.REG_H2C_READ_ADDR, (io.read32(R.REG_H2C_READ_ADDR).toInt() and lowBitsMask) or h2cqAddrBytes)
        io.write32(
            R.REG_H2C_TAIL,
            (io.read32(R.REG_H2C_TAIL).toInt() and lowBitsMask) or (h2cqAddrBytes + h2cqSizeBytes)
        )

        io.write8(R.REG_H2C_INFO, (io.read8(R.REG_H2C_INFO) and 0xFC) or 0x01)
        io.write8(R.REG_H2C_INFO, (io.read8(R.REG_H2C_INFO) and 0xFB) or 0x04)
        io.write8(R.REG_TXDMA_OFFSET_CHK + 1, (io.read8(R.REG_TXDMA_OFFSET_CHK + 1) and 0x7F) or 0x80)
    }

    companion object {
        // RX_FIFO_SIZE_8821C (halmac_8821c_cfg.h) - kept separate from the TX
        // constant above since REG_RXFF_BNDY needs the RX fifo's own size.
        private const val RX_FIFO_SIZE = 16384
    }
}
