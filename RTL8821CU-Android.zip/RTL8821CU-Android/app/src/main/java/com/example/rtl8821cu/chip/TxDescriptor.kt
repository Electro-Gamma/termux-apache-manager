package com.example.rtl8821cu.chip

/**
 * Builds the 48-byte RTL8821C TX descriptor used to stage raw bytes into
 * the chip's on-chip TX buffer — the mechanism the driver reuses for
 * firmware-download chunks (there's no separate "just send raw bytes"
 * path; everything goes out as a TX-descriptor-wrapped packet).
 *
 * Bit layout transcribed from hal/halmac/halmac_tx_desc_nic.h, the
 * fields shared by every HALMAC_8821C_SUPPORT-tagged chip:
 *   Word0 bits [15:0]  = TXPKTSIZE           (line 114-116)
 *   Word0 bits [23:16] = OFFSET              (line 111-113)
 *   Word1 bits [12:8]  = QSEL                (line 233-235)
 *   Word1 bits [28:24] = PKT_OFFSET          (line 169-171)
 *   Word7 bits [15:0]  (byte 0x1C) = TXDESC_CHECKSUM (line 850-851)
 * TXDESC_SIZE = 48 for RTL8821C (include/rtw_xmit.h:193).
 *
 * Checksum algorithm ported verbatim from fill_txdesc_check_sum_8821c()
 * in hal/halmac/halmac_88xx/halmac_8821c/halmac_common_8821c.c:135-162.
 *
 * The "packet offset" padding path mirrors usb_write_data_not_xmitframe()
 * in hal/rtl8821c/usb/rtl8821cu_halmac.c:142-164 — needed only when the
 * descriptor+payload length lands on an exact multiple of the bulk
 * endpoint's max packet size (a USB zero-length-packet-termination
 * quirk), which is why buildPacket() takes that size as a parameter.
 */
object TxDescriptor {
    const val SIZE = 48
    const val QSEL_BEACON = 0x10   // HALMAC_TXDESC_QSEL_BEACON, halmac_type.h:576 - used for fw chunks
    const val QSEL_H2C_CMD = 0x13  // HALMAC_TXDESC_QSEL_H2C_CMD, halmac_type.h:579
    private const val PACKET_OFFSET_SZ = 8 // include/rtw_xmit.h:211

    /**
     * Builds a full packet ready for a bulk-OUT transfer:
     * [48-byte descriptor][optional 8-byte pad][payload].
     */
    fun buildPacket(payload: ByteArray, qsel: Int, bulkOutMaxPacketSize: Int): ByteArray {
        val needsPad = (SIZE + payload.size) % bulkOutMaxPacketSize == 0
        val headerLen = SIZE + if (needsPad) PACKET_OFFSET_SZ else 0

        val packet = ByteArray(headerLen + payload.size)
        payload.copyInto(packet, destinationOffset = headerLen)

        setBits(packet, 0x00, 0, 16, payload.size)   // TXPKTSIZE
        setBits(packet, 0x00, 16, 8, headerLen)      // OFFSET
        if (needsPad) setBits(packet, 0x04, 24, 5, 1) // PKT_OFFSET = 1
        setBits(packet, 0x04, 8, 5, qsel)            // QSEL
        fillChecksum(packet)

        return packet
    }

    private fun fillChecksum(d: ByteArray) {
        setBits(d, 0x1C, 0, 16, 0) // zero the checksum field before computing
        var chksum = 0
        // XOR-fold the 16 little-endian 16-bit words spanning bytes 0-31
        for (i in 0 until 16) {
            val word = (d[2 * i].toInt() and 0xFF) or ((d[2 * i + 1].toInt() and 0xFF) shl 8)
            chksum = chksum xor word
        }
        setBits(d, 0x1C, 0, 16, chksum and 0xFFFF)
    }

    /** Sets `width` bits at `bitOffset` within the little-endian 32-bit
     *  word starting at byte offset `byteOffset`. */
    private fun setBits(d: ByteArray, byteOffset: Int, bitOffset: Int, width: Int, value: Int) {
        var word = (d[byteOffset].toInt() and 0xFF) or
                ((d[byteOffset + 1].toInt() and 0xFF) shl 8) or
                ((d[byteOffset + 2].toInt() and 0xFF) shl 16) or
                ((d[byteOffset + 3].toInt() and 0xFF) shl 24)
        val mask = ((1L shl width) - 1).toInt() shl bitOffset
        word = (word and mask.inv()) or ((value shl bitOffset) and mask)
        d[byteOffset] = (word and 0xFF).toByte()
        d[byteOffset + 1] = ((word shr 8) and 0xFF).toByte()
        d[byteOffset + 2] = ((word shr 16) and 0xFF).toByte()
        d[byteOffset + 3] = ((word shr 24) and 0xFF).toByte()
    }
}
