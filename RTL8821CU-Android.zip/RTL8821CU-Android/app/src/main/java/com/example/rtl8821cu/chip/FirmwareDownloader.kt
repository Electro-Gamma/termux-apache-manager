package com.example.rtl8821cu.chip

import com.example.rtl8821cu.usb.BulkPipe
import com.example.rtl8821cu.usb.RegisterIo

/**
 * RTL8821C firmware download, ported from the call chain traced in the
 * uploaded driver:
 *
 *   rtw_halmac_dlfw()                          hal/hal_halmac.c:3644
 *     -> rtw_hal_power_on()                    hal/hal_halmac.c:3663 (see PowerSequence)
 *     -> download_fw()                         hal/hal_halmac.c:3057
 *        -> download_firmware_88xx()           halmac_fw_88xx.c:115
 *           -> start_dlfw_88xx()               halmac_fw_88xx.c:233
 *              -> dlfw_to_mem_88xx()  x2        halmac_fw_88xx.c:537 (DMEM, then IMEM)
 *                 -> send_fwpkt_88xx()          halmac_fw_88xx.c:690
 *                    -> dl_rsvd_page_88xx()     halmac_common_88xx.c:270 (stage via TX packet)
 *                 -> iddma_dlfw_88xx()          halmac_fw_88xx.c:723
 *                    -> iddma_en_88xx()         halmac_fw_88xx.c:753 (trigger + poll on-chip DMA)
 *                 -> check_fw_chksum_88xx()     halmac_fw_88xx.c:772
 *        -> dlfw_end_flow_88xx()                halmac_fw_88xx.c:618
 *
 * Firmware header layout (64 bytes, hal/halmac/halmac_fw_info.h):
 *   [24] mem_usage (bit4 = has EMEM)   [28] h2c_fmt_ver (u16, unused here)
 *   [32] dmem_addr (u32)               [36] dmem_size (u32)
 *   [48] imem_size (u32)               [52] emem_size (u32)
 *   [56] emem_addr (u32)               [60] imem_addr (u32)
 * Segment layout after the header: DMEM bytes, then IMEM bytes, then EMEM
 * bytes if present. Each segment's declared size gets +8 trailing bytes
 * (WLAN_FW_HDR_CHKSUM_SIZE) appended by the firmware build tool.
 *
 * assets/rtl8821c_fw_nic.bin (bundled in Phase 0) has no EMEM segment, so
 * that path is implemented but never exercised against real hardware yet.
 */
class FirmwareDownloader(
    private val io: RegisterIo,
    private val bulkOut: BulkPipe,
    private val log: (String) -> Unit
) {
    companion object {
        private const val HDR_SIZE = 64
        private const val CHKSUM_TRAILER = 8

        private const val OFF_MEM_USAGE = 24
        private const val OFF_DMEM_ADDR = 32
        private const val OFF_DMEM_SIZE = 36
        private const val OFF_IMEM_SIZE = 48
        private const val OFF_EMEM_SIZE = 52
        private const val OFF_EMEM_ADDR = 56
        private const val OFF_IMEM_ADDR = 60

        private const val CHUNK_SIZE = 8192           // DLFW_PKT_MAX_SIZE, halmac_init_88xx.c:50
        private const val DDMA_POLL_ITERATIONS = 1000  // HALMC_DDMA_POLLING_COUNT
        private const val TXDESC_SIZE = 48
    }

    class DownloadException(message: String) : Exception(message)

    private val R = Rtl8821cRegs

    /** Runs the full pipeline. Throws DownloadException / PowerSequence.PowerSequenceException on failure. */
    fun download(fw: ByteArray) {
        log("Firmware image: ${fw.size} bytes")
        val memUsage = fw[OFF_MEM_USAGE].toInt() and 0xFF
        val hasEmem = (memUsage and 0x10) != 0

        val dmemSize = readLeU32(fw, OFF_DMEM_SIZE) + CHKSUM_TRAILER
        val imemSize = readLeU32(fw, OFF_IMEM_SIZE) + CHKSUM_TRAILER
        val ememSize = if (hasEmem) readLeU32(fw, OFF_EMEM_SIZE) + CHKSUM_TRAILER else 0

        val expected = HDR_SIZE + dmemSize + imemSize + ememSize
        if (expected != fw.size) {
            throw DownloadException("FW size mismatch: header implies $expected bytes, got ${fw.size}")
        }
        log("Header OK: DMEM=${dmemSize}B IMEM=${imemSize}B EMEM=${ememSize}B (hasEmem=$hasEmem)")

        log("Powering on chip...")
        PowerSequence.runCardEnable(io, log)

        val backup = preDownloadSetup()
        try {
            var cur = HDR_SIZE
            val dmemAddr = readLeU32(fw, OFF_DMEM_ADDR) and 0x7FFFFFFF
            log("Downloading DMEM -> 0x${dmemAddr.toString(16)}")
            downloadSegment(fw, cur, dmemAddr, dmemSize)
            cur += dmemSize

            val imemAddr = readLeU32(fw, OFF_IMEM_ADDR) and 0x7FFFFFFF
            log("Downloading IMEM -> 0x${imemAddr.toString(16)}")
            downloadSegment(fw, cur, imemAddr, imemSize)
            cur += imemSize

            if (hasEmem) {
                val ememAddr = readLeU32(fw, OFF_EMEM_ADDR) and 0x7FFFFFFF
                log("Downloading EMEM -> 0x${ememAddr.toString(16)}")
                downloadSegment(fw, cur, ememAddr, ememSize)
            }
        } finally {
            restore(backup)
        }

        endFlow()
        log("Firmware is running (REG_MCUFW_CTRL == 0xC078)")
    }

    // --- Pre-download register setup: download_firmware_88xx, halmac_fw_88xx.c:144-194 ---

    private class Backup(
        val pqMap1: Int, val cr: Int, val h2cqCsr: Int,
        val fifoPageInfo1: Int, val rqpnCtrl2: Int, val bcnCtrl: Int
    )

    private fun preDownloadSetup(): Backup {
        // wlan_cpu_en_88xx(adapter, 0): disable CPU before touching firmware
        io.write8(R.REG_SYS_FUNC_EN + 1, io.read8(R.REG_SYS_FUNC_EN + 1) and (1 shl 2).inv())
        io.write8(R.REG_RSV_CTRL + 1, io.read8(R.REG_RSV_CTRL + 1) and 1.inv())

        val pqMap1 = io.read8(R.REG_TXDMA_PQ_MAP + 1)
        io.write8(R.REG_TXDMA_PQ_MAP + 1, R.HALMAC_DMA_MAPPING_HIGH shl 6)

        val cr = io.read8(R.REG_CR)
        io.write8(R.REG_CR, R.BIT_HCI_TXDMA_EN or R.BIT_TXDMA_EN)

        val h2cqCsr = io.read32(R.REG_H2CQ_CSR).toInt()
        io.write32(R.REG_H2CQ_CSR, 1 shl 31)

        val fifoPageInfo1 = io.read16(R.REG_FIFOPAGE_INFO_1)
        io.write16(R.REG_FIFOPAGE_INFO_1, 0x200)

        val rqpnCtrl2 = io.read32(R.REG_RQPN_CTRL_2).toInt()
        io.write32(R.REG_RQPN_CTRL_2, rqpnCtrl2 or (1 shl 31))

        val bcnCtrl = io.read8(R.REG_BCN_CTRL)
        io.write8(R.REG_BCN_CTRL, (bcnCtrl and (1 shl 3).inv()) or (1 shl 4))

        mcuReset()

        // start_dlfw_88xx: enable FWDL, preserving bits [14:11]
        val ctrl = io.read16(R.REG_MCUFW_CTRL) and 0x3800
        io.write16(R.REG_MCUFW_CTRL, ctrl or 0x01)

        return Backup(pqMap1, cr, h2cqCsr, fifoPageInfo1, rqpnCtrl2, bcnCtrl)
    }

    private fun restore(b: Backup) {
        io.write8(R.REG_TXDMA_PQ_MAP + 1, b.pqMap1)
        io.write8(R.REG_CR, b.cr)
        io.write32(R.REG_H2CQ_CSR, b.h2cqCsr)
        io.write16(R.REG_FIFOPAGE_INFO_1, b.fifoPageInfo1)
        io.write32(R.REG_RQPN_CTRL_2, b.rqpnCtrl2)
        io.write8(R.REG_BCN_CTRL, b.bcnCtrl)
    }

    /** pltfm_reset_88xx(), halmac_fw_88xx.c:387-411 (8821C/8822B clock-sync branch) */
    private fun mcuReset() {
        io.write8(R.REG_CPU_DMEM_CON + 2, io.read8(R.REG_CPU_DMEM_CON + 2) and 1.inv())
        io.write8(R.REG_SYS_CLK_CTRL + 1, io.read8(R.REG_SYS_CLK_CTRL + 1) and (1 shl 6).inv())
        io.write8(R.REG_CPU_DMEM_CON + 2, io.read8(R.REG_CPU_DMEM_CON + 2) or 1)
        io.write8(R.REG_SYS_CLK_CTRL + 1, io.read8(R.REG_SYS_CLK_CTRL + 1) or (1 shl 6))
    }

    // --- Per-segment download: dlfw_to_mem_88xx, halmac_fw_88xx.c:537-588 ---

    private fun downloadSegment(fw: ByteArray, srcOffset: Int, destAddr: Int, size: Int) {
        io.write32(R.REG_DDMA_CH0CTRL, io.read32(R.REG_DDMA_CH0CTRL).toInt() or R.BIT_DDMACH0_RESET_CHKSUM_STS)

        var memOffset = 0
        var firstChunk = true
        while (memOffset < size) {
            val chunkSize = minOf(CHUNK_SIZE, size - memOffset)
            val chunk = fw.copyOfRange(srcOffset + memOffset, srcOffset + memOffset + chunkSize)

            stageChunk(chunk)
            triggerDdma(destAddr + memOffset, chunkSize, firstChunk)

            firstChunk = false
            memOffset += chunkSize
        }

        checkSegmentChecksum(destAddr)
    }

    /** send_fwpkt_88xx() / dl_rsvd_page_88xx(), halmac_common_88xx.c:270-329.
     *
     * NOTE: the original restores REG_FIFOPAGE_CTRL_2 to
     * `adapter->txff_alloc.rsvd_boundary` afterwards — a value tracked
     * elsewhere in the driver's TX-FIFO page allocator that we don't
     * have (and don't need: it's overwritten again by the very next
     * chunk's stage call before anything else reads it). We restore to
     * 0 instead, which is a deliberate simplification, not a guess at
     * the "real" value. */
    private fun stageChunk(chunk: ByteArray) {
        io.write16(R.REG_FIFOPAGE_CTRL_2, 0x0000 or (1 shl 15))

        val crPlus1 = io.read8(R.REG_CR + 1)
        io.write8(R.REG_CR + 1, crPlus1 or 1)

        val txqCtrlPlus2 = io.read8(R.REG_FWHW_TXQ_CTRL + 2)
        io.write8(R.REG_FWHW_TXQ_CTRL + 2, txqCtrlPlus2 and (1 shl 6).inv())

        val packet = TxDescriptor.buildPacket(chunk, TxDescriptor.QSEL_BEACON, bulkOut.maxPacketSize)
        bulkOut.write(packet)

        var cnt = 1000
        while ((io.read8(R.REG_FIFOPAGE_CTRL_2 + 1) and (1 shl 7)) == 0) {
            cnt--
            if (cnt <= 0) throw DownloadException("Timed out waiting for FIFO page ready (0x206 bit7)")
            sleepMicros(10)
        }

        io.write16(R.REG_FIFOPAGE_CTRL_2, 0x0000 or (1 shl 15))
        io.write8(R.REG_FWHW_TXQ_CTRL + 2, txqCtrlPlus2)
        io.write8(R.REG_CR + 1, crPlus1)
    }

    /** iddma_dlfw_88xx() / iddma_en_88xx(), halmac_fw_88xx.c:723-770. */
    private fun triggerDdma(dest: Int, len: Int, first: Boolean) {
        waitDdmaIdle()

        var ctrl = R.BIT_DDMACH0_CHKSUM_EN or R.BIT_DDMACH0_OWN or (len and R.MASK_DDMACH0_DLEN)
        if (!first) ctrl = ctrl or R.BIT_DDMACH0_CHKSUM_CONT

        val src = R.OCPBASE_TXBUF + TXDESC_SIZE // pg_addr is always 0, so src offset is always 0
        io.write32(R.REG_DDMA_CH0SA, src)
        io.write32(R.REG_DDMA_CH0DA, dest)
        io.write32(R.REG_DDMA_CH0CTRL, ctrl)

        waitDdmaIdle()
    }

    private fun waitDdmaIdle() {
        var cnt = DDMA_POLL_ITERATIONS
        while ((io.read32(R.REG_DDMA_CH0CTRL).toInt() and R.BIT_DDMACH0_OWN) != 0) {
            cnt--
            if (cnt <= 0) throw DownloadException("DDMA channel-0 busy timeout")
        }
    }

    /** check_fw_chksum_88xx(), halmac_fw_88xx.c:772-802. */
    private fun checkSegmentChecksum(destAddr: Int) {
        var fwCtrl = io.read8(R.REG_MCUFW_CTRL)
        val isImem = destAddr < R.OCPBASE_DMEM

        if ((io.read32(R.REG_DDMA_CH0CTRL).toInt() and R.BIT_DDMACH0_CHKSUM_STS) != 0) {
            fwCtrl = if (isImem) {
                (fwCtrl or R.BIT_IMEM_DW_OK) and R.BIT_IMEM_CHKSUM_OK.inv()
            } else {
                (fwCtrl or R.BIT_DMEM_DW_OK) and R.BIT_DMEM_CHKSUM_OK.inv()
            }
            io.write8(R.REG_MCUFW_CTRL, fwCtrl)
            throw DownloadException("Firmware checksum failed for segment at 0x${destAddr.toString(16)}")
        }

        fwCtrl = if (isImem) {
            fwCtrl or R.BIT_IMEM_DW_OK or R.BIT_IMEM_CHKSUM_OK
        } else {
            fwCtrl or R.BIT_DMEM_DW_OK or R.BIT_DMEM_CHKSUM_OK
        }
        io.write8(R.REG_MCUFW_CTRL, fwCtrl)
    }

    // --- Final verification: dlfw_end_flow_88xx, halmac_fw_88xx.c:618-654 ---

    private fun endFlow() {
        io.write32(R.REG_TXDMA_STATUS, 1 shl 2)

        val fwCtrl = io.read16(R.REG_MCUFW_CTRL)
        if ((fwCtrl and 0x50) != 0x50) {
            throw DownloadException(
                "IMEM/DMEM checksum bits not set after download (REG_MCUFW_CTRL=0x${fwCtrl.toString(16)})"
            )
        }
        io.write16(R.REG_MCUFW_CTRL, (fwCtrl or R.BIT_FW_DW_RDY) and 1.inv())

        // wlan_cpu_en_88xx(adapter, 1)
        io.write8(R.REG_RSV_CTRL + 1, io.read8(R.REG_RSV_CTRL + 1) or 1)
        io.write8(R.REG_SYS_FUNC_EN + 1, io.read8(R.REG_SYS_FUNC_EN + 1) or (1 shl 2))

        var cnt = 5000
        while (io.read16(R.REG_MCUFW_CTRL) != 0xC078) {
            cnt--
            if (cnt <= 0) {
                throw DownloadException(
                    "Firmware not alive after download (REG_MCUFW_CTRL never reached 0xC078)"
                )
            }
            sleepMicros(50)
        }
    }

    private fun readLeU32(b: ByteArray, offset: Int): Int {
        return (b[offset].toInt() and 0xFF) or
                ((b[offset + 1].toInt() and 0xFF) shl 8) or
                ((b[offset + 2].toInt() and 0xFF) shl 16) or
                ((b[offset + 3].toInt() and 0xFF) shl 24)
    }

    private fun sleepMicros(us: Long) {
        Thread.sleep(us / 1000, ((us % 1000) * 1000).toInt())
    }
}
