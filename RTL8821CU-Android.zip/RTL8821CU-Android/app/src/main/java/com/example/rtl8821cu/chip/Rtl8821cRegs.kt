package com.example.rtl8821cu.chip

/**
 * Register addresses and bit-field definitions for the RTL8821C chip.
 *
 * These are transcribed *values*, not driver logic — hardware register
 * maps aren't copyrightable driver implementation, they're the contract
 * the silicon exposes. Sourced directly from the uploaded driver:
 *   - hal/halmac/halmac_reg_8821c.h  (register addresses)
 *   - hal/halmac/halmac_bit_8821c.h  (bit-field masks/shifts)
 *
 * Only the subset needed for chip-version identification (Phase 0) is
 * included here. Later phases will add the MAC/BB/RF init tables and
 * RX/TX descriptor field layouts from the same headers.
 */
object Rtl8821cRegs {

    // halmac_reg_8821c.h:82-83
    const val REG_SYS_CFG1 = 0x00F0
    const val REG_SYS_STATUS1 = 0x00F4

    // halmac_bit_8821c.h:2456-2510 (REG_SYS_CFG1 fields)
    const val BIT_RF_TYPE_ID = 1 shl 27
    const val BIT_SPSLDO_SEL = 1 shl 24
    const val BIT_RTL_ID = 1 shl 23

    const val SHIFT_VENDOR_ID = 16
    const val MASK_VENDOR_ID = 0xF

    const val SHIFT_CHIP_VER = 12
    const val MASK_CHIP_VER = 0xF

    // REG_SYS_STATUS1 fields
    const val SHIFT_RF_RL_ID = 28
    const val MASK_RF_RL_ID = 0xF
}
