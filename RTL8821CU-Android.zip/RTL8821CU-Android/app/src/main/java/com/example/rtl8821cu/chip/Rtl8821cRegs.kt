package com.example.rtl8821cu.chip

/**
 * Register addresses and bit-field definitions for the RTL8821C chip.
 *
 * These are transcribed *values*, not driver logic — hardware register
 * maps aren't copyrightable driver implementation, they're the contract
 * the silicon exposes. Sourced directly from the uploaded driver:
 *   - hal/halmac/halmac_reg_8821c.h  (register addresses)
 *   - hal/halmac/halmac_bit_8821c.h  (bit-field masks/shifts)
 *
 * Only the subset needed for chip-version identification (Phase 0) is
 * included here. Later phases will add the MAC/BB/RF init tables and
 * RX/TX descriptor field layouts from the same headers.
 */
object Rtl8821cRegs {

    // halmac_reg_8821c.h:82-83
    const val REG_SYS_CFG1 = 0x00F0
    const val REG_SYS_STATUS1 = 0x00F4

    // halmac_bit_8821c.h:2456-2510 (REG_SYS_CFG1 fields)
    const val BIT_RF_TYPE_ID = 1 shl 27
    const val BIT_SPSLDO_SEL = 1 shl 24
    const val BIT_RTL_ID = 1 shl 23

    const val SHIFT_VENDOR_ID = 16
    const val MASK_VENDOR_ID = 0xF

    const val SHIFT_CHIP_VER = 12
    const val MASK_CHIP_VER = 0xF

    // REG_SYS_STATUS1 fields
    const val SHIFT_RF_RL_ID = 28
    const val MASK_RF_RL_ID = 0xF

    // --- Phase 1: firmware download registers (hal/halmac/halmac_reg2.h) ---
    const val REG_SYS_FUNC_EN = 0x0002
    const val REG_SYS_PW_CTRL = 0x0004
    const val REG_SYS_CLK_CTRL = 0x0008
    const val REG_RSV_CTRL = 0x001C
    const val REG_MCUFW_CTRL = 0x0080
    const val REG_MCU_TST_CFG = 0x0084
    const val REG_CR = 0x0100
    const val REG_TXDMA_PQ_MAP = 0x010C
    const val REG_TXDMA_STATUS = 0x0210
    const val REG_FIFOPAGE_CTRL_2 = 0x0204
    const val REG_RQPN_CTRL_2 = 0x022C
    const val REG_FIFOPAGE_INFO_1 = 0x0230
    const val REG_FWHW_TXQ_CTRL = 0x0420
    const val REG_BCN_CTRL = 0x0550
    const val REG_CPU_DMEM_CON = 0x1080
    const val REG_SW_MDIO = 0x10C0
    const val REG_DDMA_CH0SA = 0x1200
    const val REG_DDMA_CH0DA = 0x1204
    const val REG_DDMA_CH0CTRL = 0x1208
    const val REG_H2CQ_CSR = 0x1330

    // DDMA channel-0 control bits (halmac_bit_8821c.h:6654-6664)
    const val BIT_DDMACH0_RESET_CHKSUM_STS = 1 shl 25
    const val BIT_DDMACH0_CHKSUM_CONT = 1 shl 24
    const val BIT_DDMACH0_CHKSUM_STS = 1 shl 27
    const val BIT_DDMACH0_CHKSUM_EN = 1 shl 29
    const val BIT_DDMACH0_OWN = 1 shl 31
    const val MASK_DDMACH0_DLEN = 0x3ffff

    // REG_MCUFW_CTRL bits (halmac_bit2.h)
    const val BIT_IMEM_DW_OK = 1 shl 3
    const val BIT_IMEM_CHKSUM_OK = 1 shl 4
    const val BIT_DMEM_DW_OK = 1 shl 5
    const val BIT_DMEM_CHKSUM_OK = 1 shl 6
    const val BIT_FW_DW_RDY = 1 shl 14

    // REG_CR bits (halmac_bit2.h:15351-15353)
    const val BIT_HCI_TXDMA_EN = 1
    const val BIT_TXDMA_EN = 1 shl 2

    // On-chip memory bases (halmac_88xx_cfg.h)
    const val OCPBASE_TXBUF = 0x18780000
    const val OCPBASE_DMEM = 0x00200000

    const val HALMAC_DMA_MAPPING_HIGH = 3
}

