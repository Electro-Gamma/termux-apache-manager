package com.example.rtl8821cu.usb

import android.hardware.usb.UsbDeviceConnection

/**
 * Register-access wire protocol, ported from usbctrl_vendorreq() in
 * os_dep/linux/usb_ops_linux.c and its usb_read8/16/32 / usb_write8
 * wrappers in hal/hal_hci/hal_usb.c.
 *
 * This is a hardware contract, not driver-internal logic — the chip
 * expects this exact sequence over the USB control endpoint no matter
 * what's issuing it:
 *
 *   bRequest      = 0x05    (REALTEK_USB_VENQT_CMD_REQ, include/usb_ops.h:21)
 *   bmRequestType = 0xC0 read / 0x40 write
 *                   (REALTEK_USB_VENQT_READ/WRITE, include/usb_ops.h:19-20)
 *   wValue        = 16-bit register address (usb_read32, hal_usb.c:391-396)
 *   wIndex        = 0x0000  (REALTEK_USB_VENQT_CMD_IDX, include/usb_ops.h:22)
 *   data          = 1/2/4 bytes, little-endian
 *
 * Android's UsbDeviceConnection.controlTransfer(requestType, request,
 * value, index, buffer, length, timeout) takes the same six wire fields
 * as usb_control_msg() in the original — the port here is close to
 * mechanical for this one primitive. Everything built on top of it
 * (firmware download, MAC/BB/RF bring-up, calibration) is NOT this
 * simple and is handled in later phases.
 */
class RegisterIo(private val connection: UsbDeviceConnection) {

    companion object {
        private const val REQUEST = 0x05
        private const val REQTYPE_READ = 0xC0
        private const val REQTYPE_WRITE = 0x40
        private const val INDEX = 0x0000
        private const val TIMEOUT_MS = 500
    }

    fun read8(address: Int): Int = readN(address, 1)[0].toInt() and 0xFF

    fun read16(address: Int): Int {
        val b = readN(address, 2)
        return (b[0].toInt() and 0xFF) or ((b[1].toInt() and 0xFF) shl 8)
    }

    fun read32(address: Int): Long {
        val b = readN(address, 4)
        return (b[0].toLong() and 0xFF) or
                ((b[1].toLong() and 0xFF) shl 8) or
                ((b[2].toLong() and 0xFF) shl 16) or
                ((b[3].toLong() and 0xFF) shl 24)
    }

    fun write8(address: Int, value: Int) {
        writeN(address, byteArrayOf(value.toByte()))
    }

    fun write16(address: Int, value: Int) {
        writeN(address, byteArrayOf((value and 0xFF).toByte(), ((value shr 8) and 0xFF).toByte()))
    }

    fun write32(address: Int, value: Int) = write32(address, value.toLong() and 0xFFFFFFFFL)

    fun write32(address: Int, value: Long) {
        val b = byteArrayOf(
            (value and 0xFF).toByte(),
            ((value shr 8) and 0xFF).toByte(),
            ((value shr 16) and 0xFF).toByte(),
            ((value shr 24) and 0xFF).toByte()
        )
        writeN(address, b)
    }

    private fun readN(address: Int, length: Int): ByteArray {
        val buffer = ByteArray(length)
        val wValue = address and 0xFFFF
        val result = connection.controlTransfer(
            REQTYPE_READ, REQUEST, wValue, INDEX, buffer, length, TIMEOUT_MS
        )
        check(result == length) {
            "Register read failed at 0x${address.toString(16)}: controlTransfer returned $result"
        }
        return buffer
    }

    private fun writeN(address: Int, data: ByteArray) {
        val wValue = address and 0xFFFF
        val result = connection.controlTransfer(
            REQTYPE_WRITE, REQUEST, wValue, INDEX, data, data.size, TIMEOUT_MS
        )
        check(result == data.size) {
            "Register write failed at 0x${address.toString(16)}: controlTransfer returned $result"
        }
    }
}
