package com.example.rtl8821cu.chip

import com.example.rtl8821cu.usb.RegisterIo

/**
 * Decoded chip identity. This is a direct port of read_chip_version()
 * in hal/rtl8821c/rtl8821c_ops.c (lines 34-64 of the uploaded source) —
 * same register, same bit-field math, same interpretation. The only
 * thing that changed is *how the register gets read*: a USB control
 * transfer issued by the Android USB Host API instead of one issued by
 * a Linux kernel driver. The chip doesn't know or care which one asked.
 */
data class ChipVersion(
    val isTestChip: Boolean,
    val cutVersion: Int,
    val vendor: String,
    val rfType: String,
    val regulator: String,
    val rawSysCfg1: Long
) {
    companion object {
        fun read(io: RegisterIo): ChipVersion {
            val v = io.read32(Rtl8821cRegs.REG_SYS_CFG1)

            // Original: BIT_GET_VENDOR_ID_8821C(value32) then >>= 2
            val vendorRaw =
                ((v shr Rtl8821cRegs.SHIFT_VENDOR_ID) and Rtl8821cRegs.MASK_VENDOR_ID.toLong()) shr 2
            val vendor = when (vendorRaw.toInt()) {
                0 -> "TSMC"
                1 -> "SMIC"
                2 -> "UMC"
                else -> "unknown ($vendorRaw)"
            }

            return ChipVersion(
                isTestChip = (v and Rtl8821cRegs.BIT_RTL_ID.toLong()) != 0L,
                cutVersion = ((v shr Rtl8821cRegs.SHIFT_CHIP_VER) and Rtl8821cRegs.MASK_CHIP_VER.toLong()).toInt(),
                vendor = vendor,
                rfType = if ((v and Rtl8821cRegs.BIT_RF_TYPE_ID.toLong()) != 0L) "2T2R" else "1T1R",
                regulator = if ((v and Rtl8821cRegs.BIT_SPSLDO_SEL.toLong()) != 0L) "LDO" else "Switching",
                rawSysCfg1 = v
            )
        }
    }
}
