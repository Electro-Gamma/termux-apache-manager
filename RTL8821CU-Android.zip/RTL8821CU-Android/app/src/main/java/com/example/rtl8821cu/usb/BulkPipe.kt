package com.example.rtl8821cu.usb

import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint

/**
 * Thin wrapper over a single USB bulk-OUT endpoint. Mirrors what the
 * driver does with a kernel URB in usb_write_port_not_xmitframe()
 * (os_dep/linux/usb_ops_linux.c: usb_fill_bulk_urb + usb_submit_urb) —
 * Android's synchronous bulkTransfer() plays the same role without
 * needing to manage a URB lifecycle ourselves.
 */
class BulkPipe(
    private val connection: UsbDeviceConnection,
    val endpoint: UsbEndpoint
) {
    val maxPacketSize: Int get() = endpoint.maxPacketSize

    fun write(data: ByteArray, timeoutMs: Int = 3000) {
        val sent = connection.bulkTransfer(endpoint, data, data.size, timeoutMs)
        check(sent == data.size) {
            "Bulk write failed/truncated: sent=$sent expected=${data.size}"
        }
    }
}
