package com.example.rtl8821cu.usb

import android.content.Context
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import android.app.PendingIntent

/**
 * Finds an RTL8811CU/RTL8821CU adapter among attached USB devices and
 * obtains an open, permitted connection to it — plain Android USB Host
 * API, no root, no kernel driver involved on either side.
 *
 * VID/PID list matches rtw_usb_id_tbl[] in os_dep/linux/usb_intf.c
 * (RTL8821C entries only) and res/xml/device_filter.xml.
 */
class UsbBridge(context: Context) {

    companion object {
        private const val VENDOR_REALTEK = 0x0BDA
        private const val VENDOR_DLINK = 0x2001

        private val REALTEK_PRODUCT_IDS = setOf(
            0xB82B, 0xB820, 0xC821, 0xC820, 0xC82A, 0xC82B, 0xC811, 0x8811, 0x2006
        )

        fun isSupported(device: UsbDevice): Boolean {
            return (device.vendorId == VENDOR_REALTEK && device.productId in REALTEK_PRODUCT_IDS) ||
                    (device.vendorId == VENDOR_DLINK && device.productId == 0x331D)
        }
    }

    private val usbManager = context.getSystemService(Context.USB_SERVICE) as UsbManager

    fun findSupportedDevice(): UsbDevice? =
        usbManager.deviceList.values.firstOrNull { isSupported(it) }

    fun hasPermission(device: UsbDevice): Boolean = usbManager.hasPermission(device)

    fun requestPermission(device: UsbDevice, permissionIntent: PendingIntent) {
        usbManager.requestPermission(device, permissionIntent)
    }

    /** Opens the device and claims its first interface. Null on failure. */
    fun open(device: UsbDevice): OpenedDevice? {
        val connection: UsbDeviceConnection = usbManager.openDevice(device) ?: return null
        val usbInterface: UsbInterface = device.getInterface(0)
        val claimed = connection.claimInterface(usbInterface, true)
        if (!claimed) {
            connection.close()
            return null
        }
        return OpenedDevice(device, usbInterface, connection)
    }

    class OpenedDevice(
        val device: UsbDevice,
        private val usbInterface: UsbInterface,
        val connection: UsbDeviceConnection
    ) {
        /**
         * Bulk-OUT endpoints in descriptor order. The driver fills its
         * RtOutPipe[] array (os_dep/linux/usb_ops_linux.c: ffaddr2pipehdl)
         * in the same enumeration order, and firmware-download packets
         * always resolve to bulkout_id=0 (HALMAC_QSEL_BCN -> DMA_MAPPING_HIGH
         * -> id 0, hal/halmac/halmac_88xx/halmac_usb_88xx.c:311-323) — i.e.
         * the FIRST bulk-out endpoint found here. Most single-function
         * dongles like the RTL8811CU only expose one anyway.
         */
        fun findBulkOutEndpoints(): List<UsbEndpoint> {
            val eps = mutableListOf<UsbEndpoint>()
            for (i in 0 until usbInterface.endpointCount) {
                val ep = usbInterface.getEndpoint(i)
                if (ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK &&
                    ep.direction == UsbConstants.USB_DIR_OUT
                ) {
                    eps.add(ep)
                }
            }
            return eps
        }

        fun close() {
            connection.releaseInterface(usbInterface)
            connection.close()
        }
    }
}
