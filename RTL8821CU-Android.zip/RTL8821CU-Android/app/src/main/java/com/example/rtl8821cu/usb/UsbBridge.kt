package com.example.rtl8821cu.usb

import android.content.Context
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import android.app.PendingIntent

/**
 * Finds an RTL8811CU/RTL8821CU adapter among attached USB devices and
 * obtains an open, permitted connection to it — plain Android USB Host
 * API, no root, no kernel driver involved on either side.
 *
 * VID/PID list matches rtw_usb_id_tbl[] in os_dep/linux/usb_intf.c
 * (RTL8821C entries only) and res/xml/device_filter.xml.
 */
class UsbBridge(context: Context) {

    companion object {
        private const val VENDOR_REALTEK = 0x0BDA
        private const val VENDOR_DLINK = 0x2001

        private val REALTEK_PRODUCT_IDS = setOf(
            0xB82B, 0xB820, 0xC821, 0xC820, 0xC82A, 0xC82B, 0xC811, 0x8811, 0x2006
        )

        fun isSupported(device: UsbDevice): Boolean {
            return (device.vendorId == VENDOR_REALTEK && device.productId in REALTEK_PRODUCT_IDS) ||
                    (device.vendorId == VENDOR_DLINK && device.productId == 0x331D)
        }
    }

    private val usbManager = context.getSystemService(Context.USB_SERVICE) as UsbManager

    fun findSupportedDevice(): UsbDevice? =
        usbManager.deviceList.values.firstOrNull { isSupported(it) }

    fun hasPermission(device: UsbDevice): Boolean = usbManager.hasPermission(device)

    fun requestPermission(device: UsbDevice, permissionIntent: PendingIntent) {
        usbManager.requestPermission(device, permissionIntent)
    }

    /** Opens the device and claims its first interface. Null on failure. */
    fun open(device: UsbDevice): OpenedDevice? {
        val connection: UsbDeviceConnection = usbManager.openDevice(device) ?: return null
        val usbInterface: UsbInterface = device.getInterface(0)
        val claimed = connection.claimInterface(usbInterface, true)
        if (!claimed) {
            connection.close()
            return null
        }
        return OpenedDevice(device, usbInterface, connection)
    }

    class OpenedDevice(
        val device: UsbDevice,
        private val usbInterface: UsbInterface,
        val connection: UsbDeviceConnection
    ) {
        fun close() {
            connection.releaseInterface(usbInterface)
            connection.close()
        }
    }
}
