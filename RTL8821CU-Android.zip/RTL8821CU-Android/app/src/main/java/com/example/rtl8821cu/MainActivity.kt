package com.example.rtl8821cu

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.rtl8821cu.chip.ChipVersion
import com.example.rtl8821cu.usb.RegisterIo
import com.example.rtl8821cu.usb.UsbBridge

/**
 * Phase 0 proof of concept: prove the app can reach the RTL8811CU/
 * RTL8821CU adapter directly over USB, with no root and no involvement
 * of the phone's own Wi-Fi stack, by reading and decoding the chip
 * version register (REG_SYS_CFG1, see ChipVersion.kt).
 *
 * If this works, the "can an unrooted Kotlin app talk to real silicon"
 * question is answered — everything after this (firmware download,
 * scanning, monitor mode) builds on the same RegisterIo primitive.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var usbBridge: UsbBridge
    private lateinit var logView: TextView
    private lateinit var scrollView: ScrollView

    private val actionUsbPermission = "com.example.rtl8821cu.USB_PERMISSION"

    private fun Intent.usbDeviceExtra(): UsbDevice? =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
        } else {
            @Suppress("DEPRECATION")
            getParcelableExtra(UsbManager.EXTRA_DEVICE)
        }

    private val permissionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action != actionUsbPermission) return
            val device: UsbDevice? = intent.usbDeviceExtra()
            val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
            if (granted && device != null) {
                connectAndReadChipVersion(device)
            } else {
                log("Permission denied for ${device?.deviceName}")
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        logView = findViewById(R.id.logView)
        scrollView = findViewById(R.id.scrollView)
        usbBridge = UsbBridge(this)

        val filter = IntentFilter(actionUsbPermission)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(permissionReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            registerReceiver(permissionReceiver, filter)
        }

        findViewById<Button>(R.id.scanButton).setOnClickListener { scanForDevice() }

        handleAttachIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleAttachIntent(intent)
    }

    private fun handleAttachIntent(intent: Intent?) {
        if (intent?.action == UsbManager.ACTION_USB_DEVICE_ATTACHED) {
            intent.usbDeviceExtra()?.let { requestOrConnect(it) }
        }
    }

    private fun scanForDevice() {
        val device = usbBridge.findSupportedDevice()
        if (device == null) {
            log("No RTL8811CU/RTL8821CU adapter found. Plug it in via USB-OTG.")
            return
        }
        log(
            "Found candidate: ${device.deviceName} " +
                    "(VID=0x${device.vendorId.toString(16)} PID=0x${device.productId.toString(16)})"
        )
        requestOrConnect(device)
    }

    private fun requestOrConnect(device: UsbDevice) {
        if (usbBridge.hasPermission(device)) {
            connectAndReadChipVersion(device)
            return
        }
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
            PendingIntent.FLAG_MUTABLE else 0
        val permissionIntent = PendingIntent.getBroadcast(
            this, 0, Intent(actionUsbPermission), flags
        )
        usbBridge.requestPermission(device, permissionIntent)
        log("Requested USB permission for ${device.deviceName} — approve the system dialog.")
    }

    private fun connectAndReadChipVersion(device: UsbDevice) {
        val opened = usbBridge.open(device)
        if (opened == null) {
            log("Failed to open device / claim interface.")
            return
        }
        try {
            val io = RegisterIo(opened.connection)
            val version = ChipVersion.read(io)
            log("--- Chip identified over USB, no root ---")
            log("Test chip:   ${version.isTestChip}")
            log("Cut version: ${version.cutVersion}")
            log("Vendor:      ${version.vendor}")
            log("RF type:     ${version.rfType}")
            log("Regulator:   ${version.regulator}")
            log("Raw REG_SYS_CFG1 (0x00F0) = 0x${version.rawSysCfg1.toString(16)}")
        } catch (e: Exception) {
            log("Register read failed: ${e.message}")
        } finally {
            opened.close()
        }
    }

    private fun log(message: String) {
        runOnUiThread {
            logView.append("$message\n")
            scrollView.post { scrollView.fullScroll(View.FOCUS_DOWN) }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(permissionReceiver)
    }
}
