package com.example.rtl8821cu.chip

import com.example.rtl8821cu.usb.RegisterIo

/**
 * The chip must be powered on before firmware download will do anything —
 * rtw_halmac_dlfw() calls rtw_hal_power_on() first (hal/hal_halmac.c:3663),
 * which for RTL8821C/USB resolves to mac_pwr_switch_usb_8821c() running two
 * declarative register-sequence tables through a generic interpreter
 * (pwr_seq_parser_88xx() / pwr_sub_seq_parser_88xx() in
 * hal/halmac/halmac_88xx/halmac_common_88xx.c:2472-2589).
 *
 * This is a straight port of that interpreter plus the USB-relevant rows
 * of TRANS_CARDDIS_TO_CARDEMU_8821C and TRANS_CARDEMU_TO_ACT_8821C
 * (hal/halmac/halmac_88xx/halmac_8821c/halmac_pwr_seq_8821c.c:20-162).
 * Entries whose interface_msk was PCI-only or SDIO-only in the source
 * tables are omitted entirely — they never fire on our USB code path,
 * so leaving them out changes nothing observable.
 */
object PowerSequence {

    private val BIT0 = 1
    private val BIT1 = 1 shl 1
    private val BIT2 = 1 shl 2
    private val BIT3 = 1 shl 3
    private val BIT4 = 1 shl 4
    private val BIT5 = 1 shl 5
    private val BIT7 = 1 shl 7

    private sealed class Op {
        data class Write8(val reg: Int, val mask: Int, val value: Int) : Op()
        data class Poll8(val reg: Int, val mask: Int, val expected: Int) : Op()
        data class DelayMs(val ms: Long) : Op()
    }

    // TRANS_CARDDIS_TO_CARDEMU_8821C, USB/ALL rows only (source lines 32-41)
    private val cardDisToCardEmu = listOf<Op>(
        Op.Write8(reg = 0x004A, mask = BIT0, value = 0x00),
        Op.Write8(reg = 0x0005, mask = BIT3 or BIT4 or BIT7, value = 0x00)
    )

    // TRANS_CARDEMU_TO_ACT_8821C, USB/ALL rows only (source lines 61-156).
    // PCI-only rows at offsets 0x0075/0x0074/0x0022/0x0062/0x0061 dropped.
    private val cardEmuToAct = listOf<Op>(
        Op.Write8(0x0020, BIT0, BIT0),
        Op.DelayMs(1),
        Op.Write8(0x0000, BIT5, 0x00),
        Op.Write8(0x0005, BIT4 or BIT3 or BIT2, 0x00),
        Op.Poll8(0x0006, BIT1, BIT1),
        Op.Write8(0x0006, BIT0, BIT0),
        Op.Write8(0x0005, BIT7, 0x00),
        Op.Write8(0x0005, BIT4 or BIT3, 0x00),
        Op.Write8(0x10C3, BIT0, BIT0),
        Op.Write8(0x0005, BIT0, BIT0),
        Op.Poll8(0x0005, BIT0, 0x00),
        Op.Write8(0x0020, BIT3, BIT3),
        Op.Write8(0x007C, BIT1, 0x00)
    )

    private const val POLL_ITERATIONS = 20_000
    private const val POLL_DELAY_US = 50L

    class PowerSequenceException(message: String) : Exception(message)

    /** Runs the USB card-enable power sequence. Throws on polling timeout. */
    fun runCardEnable(io: RegisterIo, log: (String) -> Unit) {
        log("Power sequence: CARDDIS -> CARDEMU (${cardDisToCardEmu.size} ops)")
        cardDisToCardEmu.forEach { run(io, it) }
        log("Power sequence: CARDEMU -> ACT (${cardEmuToAct.size} ops)")
        cardEmuToAct.forEach { run(io, it) }
        log("Power sequence complete")
    }

    private fun run(io: RegisterIo, op: Op) {
        when (op) {
            is Op.Write8 -> {
                val cur = io.read8(op.reg)
                io.write8(op.reg, (cur and op.mask.inv()) or (op.value and op.mask))
            }
            is Op.Poll8 -> {
                var n = POLL_ITERATIONS
                while ((io.read8(op.reg) and op.mask) != (op.expected and op.mask)) {
                    n--
                    if (n <= 0) {
                        throw PowerSequenceException(
                            "Power sequence poll timeout at reg 0x${op.reg.toString(16)}"
                        )
                    }
                    sleepMicros(POLL_DELAY_US)
                }
            }
            is Op.DelayMs -> Thread.sleep(op.ms)
        }
    }

    private fun sleepMicros(us: Long) {
        val ms = us / 1000
        val ns = ((us % 1000) * 1000).toInt()
        Thread.sleep(ms, ns)
    }
}
