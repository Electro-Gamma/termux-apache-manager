package com.example.rtl8821cu.chip

import com.example.rtl8821cu.usb.BulkPipe
import com.example.rtl8821cu.usb.RegisterIo

/**
 * H2C (host-to-chip) command transport for the now-running firmware.
 *
 * Distinct from firmware-chunk staging (FirmwareDownloader.stageChunk):
 * H2C packets go out with QSEL_H2C_CMD instead of QSEL_BEACON, and that
 * queue type is hardware-routed straight into the H2C ring buffer
 * (MacInit.initH2cQueue) — no REG_FIFOPAGE_CTRL_2 page-select dance is
 * needed here (that dance is specific to the "reserved page" queue type
 * firmware download uses). Confirmed by tracing usb_write_data_h2c() in
 * hal/rtl8821c/usb/rtl8821cu_halmac.c:301-316, which calls
 * usb_write_data_not_xmitframe() DIRECTLY — it never goes through
 * dl_rsvd_page_88xx() the way firmware chunks do.
 *
 * Every H2C packet is a fixed 32 bytes (H2C_PKT_SIZE_88XX) — an 8-byte
 * header (hal/halmac/halmac_fw_offload_h2c_nic.h:100-127) followed by up
 * to 24 bytes of command-specific content, zero-padded.
 *
 * send_h2c_pkt_88xx() (halmac_common_88xx.c:552-582) checks free space
 * against two registers before sending, retrying if the ring is full.
 */
class H2cTransport(
    private val io: RegisterIo,
    private val bulkOut: BulkPipe,
    private val txFifoLayout: MacInit.TxFifoLayout,
    private val log: (String) -> Unit
) {
    class H2cException(message: String) : Exception(message)

    private val R = Rtl8821cRegs
    private var seqNum = 0

    /**
     * Builds and sends one H2C packet. `content` is copied starting at
     * byte offset 8 of the 32-byte packet (zero-padded beyond that).
     */
    fun send(subCmdId: Int, content: ByteArray) {
        require(content.size <= R.H2C_PKT_SIZE - 8) { "H2C content too large: ${content.size} bytes" }

        val buf = ByteArray(R.H2C_PKT_SIZE)
        content.copyInto(buf, destinationOffset = 8)
        setHeader(buf, subCmdId, content.size)

        waitForFreeSpace()

        val packet = TxDescriptor.buildPacket(buf, TxDescriptor.QSEL_H2C_CMD, bulkOut.maxPacketSize)
        var attempts = 100
        while (true) {
            try {
                bulkOut.write(packet)
                break
            } catch (e: Exception) {
                attempts--
                if (attempts <= 0) throw H2cException("H2C send failed after retries: ${e.message}")
                sleepMicros(5)
            }
        }
    }

    /** FW_OFFLOAD_H2C_SET_* macros, halmac_fw_offload_h2c_nic.h:100-127.
     *  Word0: [6:0]=CATEGORY [7]=ACK [15:8]=CMD_ID [31:16]=SUB_CMD_ID
     *  Word1: [15:0]=TOTAL_LEN [31:16]=SEQ_NUM */
    private fun setHeader(buf: ByteArray, subCmdId: Int, contentSize: Int) {
        setBits(buf, 0x00, 0, 7, 0x01)          // CATEGORY = 1 (offload)
        setBits(buf, 0x00, 8, 8, 0xFF)          // CMD_ID = 0xFF (offload dispatch)
        setBits(buf, 0x00, 16, 16, subCmdId)
        setBits(buf, 0x04, 0, 16, 8 + contentSize) // TOTAL_LEN = header + content
        setBits(buf, 0x04, 16, 16, seqNum)
        seqNum = (seqNum + 1) and 0xFFFF
    }

    /** get_h2c_buf_free_space_88xx(), halmac_common_88xx.c:585-601. */
    private fun waitForFreeSpace() {
        val bufSize = R.RSVD_PG_H2CQ_NUM shl R.TX_PAGE_SIZE_SHIFT
        var attempts = 100
        while (true) {
            val hwWptr = io.read32(R.REG_H2C_PKT_WRITEADDR).toInt() and 0x3FFFF
            val fwRptr = io.read32(R.REG_H2C_PKT_READADDR).toInt() and 0x3FFFF
            val free = if (hwWptr >= fwRptr) bufSize - (hwWptr - fwRptr) else fwRptr - hwWptr
            if (free > R.H2C_PKT_SIZE) return
            attempts--
            if (attempts <= 0) throw H2cException("H2C ring buffer stayed full — no space for a new packet")
        }
    }

    /**
     * Reads back the first 4 bytes of the H2C ring buffer to confirm the
     * hardware actually delivered a packet header there. Every H2C header
     * this class writes has CATEGORY=0x01 and CMD_ID=0xFF, so this checks
     * (byte0 & 0x7F)==0x01 and byte1==0xFF — send_general_info_88xx's own
     * verification (halmac_fw_88xx.c:1042-1050), not a firmware-side ack.
     */
    fun verifyLastPacketLanded() {
        val addr = txFifoLayout.h2cqAddrPages shl R.TX_PAGE_SIZE_SHIFT
        val bytes = FifoDump.readTxFifo(io, addr, 4)
        val ok = (bytes[0].toInt() and 0x7F) == 0x01 && (bytes[1].toInt() and 0xFF) == 0xFF
        if (!ok) {
            throw H2cException(
                "H2C queue readback mismatch: got 0x${bytes[0].toString(16)} 0x${bytes[1].toString(16)}, " +
                        "expected category=0x01 cmd_id=0xFF"
            )
        }
        log("H2C queue readback OK — packet header landed correctly on-chip")
    }

    private fun setBits(d: ByteArray, byteOffset: Int, bitOffset: Int, width: Int, value: Int) {
        var word = (d[byteOffset].toInt() and 0xFF) or
                ((d[byteOffset + 1].toInt() and 0xFF) shl 8) or
                ((d[byteOffset + 2].toInt() and 0xFF) shl 16) or
                ((d[byteOffset + 3].toInt() and 0xFF) shl 24)
        val mask = ((1L shl width) - 1).toInt() shl bitOffset
        word = (word and mask.inv()) or ((value shl bitOffset) and mask)
        d[byteOffset] = (word and 0xFF).toByte()
        d[byteOffset + 1] = ((word shr 8) and 0xFF).toByte()
        d[byteOffset + 2] = ((word shr 16) and 0xFF).toByte()
        d[byteOffset + 3] = ((word shr 24) and 0xFF).toByte()
    }

    private fun sleepMicros(us: Long) {
        Thread.sleep(us / 1000, ((us % 1000) * 1000).toInt())
    }
}
