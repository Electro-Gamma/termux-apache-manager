package com.example.rtl8821cu.chip

import com.example.rtl8821cu.usb.RegisterIo

/**
 * Reads raw bytes back from the chip's on-chip TX FIFO memory — used to
 * verify an H2C packet actually landed after sending it.
 *
 * Ported from dump_fifo_88xx() + read_buf_88xx()
 * (hal/halmac/halmac_88xx/halmac_common_88xx.c:1580-1680). The mechanism:
 * select a 4KB page via REG_PKTBUF_DBG_CTRL, then read that page's
 * contents through a fixed 4KB register window at 0x8000-0x8FFF — plain
 * 32-bit register reads, nothing new needed beyond RegisterIo. RX clock
 * gating is disabled for the duration (REG_RCR+2 bit3) and restored after,
 * matching rx_clk_gate_88xx().
 */
object FifoDump {

    private val R = Rtl8821cRegs
    private const val TX_SEL_PAGE_BASE = 0x780

    fun readTxFifo(io: RegisterIo, offset: Int, size: Int): ByteArray {
        require(size % 4 == 0) { "FIFO reads must be 4-byte aligned (got $size)" }

        val rcrSaved = io.read8(R.REG_RCR + 2)
        io.write8(R.REG_RCR + 2, rcrSaved or R.BIT_RCR_DISABLE_RX_CLK_GATE)
        try {
            return readBuf(io, offset, size)
        } finally {
            io.write8(R.REG_RCR + 2, rcrSaved)
        }
    }

    private fun readBuf(io: RegisterIo, offset: Int, size: Int): ByteArray {
        var startPg = (offset ushr 12) + TX_SEL_PAGE_BASE
        var residue = offset and 0xFFF

        val preserved = io.read16(R.REG_PKTBUF_DBG_CTRL) and 0xF000
        val out = ByteArray(size)
        var count = 0

        try {
            while (true) {
                io.write16(R.REG_PKTBUF_DBG_CTRL, startPg or preserved)

                var addr = 0x8000 + residue
                while (addr <= 0x8FFF) {
                    val word = io.read32(addr).toInt()
                    out[count] = (word and 0xFF).toByte()
                    out[count + 1] = ((word shr 8) and 0xFF).toByte()
                    out[count + 2] = ((word shr 16) and 0xFF).toByte()
                    out[count + 3] = ((word shr 24) and 0xFF).toByte()
                    count += 4
                    if (count == size) return out
                    addr += 4
                }

                residue = 0
                startPg++
            }
        } finally {
            io.write16(R.REG_PKTBUF_DBG_CTRL, preserved)
        }
    }
}
