package com.example.rtl8821cu.chip

/**
 * Ports send_general_info_88xx() (hal/halmac/halmac_88xx/halmac_fw_88xx.c:1016-1065),
 * the function the real driver calls immediately after firmware download
 * to tell the now-running firmware basic chip configuration. Two fixed,
 * 32-byte H2C commands, back to back:
 *
 *  1. general_info (SUB_CMD_ID 0x0D): one field, FW_TX_BOUNDARY — where
 *     the firmware's own usable TX buffer starts, expressed as a page
 *     offset from the reserved-page boundary (both now known for real,
 *     computed by MacInit).
 *  2. phydm_info (SUB_CMD_ID 0x11): reports RFE type, RF type, silicon
 *     cut version, and antenna path status. NOTE: despite the name, this
 *     is metadata the driver reports TO the firmware — not the IQK/LCK
 *     RF calibration algorithms the driver runs separately. Sending this
 *     command doesn't require us to have implemented calibration.
 *
 * _send_general_info()'s caller in hal_halmac.c hardcodes rf_type=1T1R,
 * tx/rx antenna path=A for this chip family — matching what Phase 0
 * independently decoded from REG_SYS_CFG1 ("RF type: 1T1R"), which is a
 * reassuring cross-check that both readings agree.
 *
 * rfe_type (front-end module variant) is normally read from EEPROM/efuse,
 * which this project doesn't implement — defaulted to 0 here. Flagged as
 * a simplification, not silently assumed correct.
 */
class GeneralInfoSender(
    private val h2c: H2cTransport,
    private val txFifoLayout: MacInit.TxFifoLayout,
    private val chipCutVersion: Int,
    private val log: (String) -> Unit
) {
    companion object {
        private const val RFE_TYPE_DEFAULT = 0 // simplification: not read from EEPROM/efuse
    }

    fun send() {
        sendGeneralInfo()
        sendPhydmInfo()
        h2c.verifyLastPacketLanded()
        log("general_info + phydm_info sent and verified")
    }

    /** proc_send_general_info_88xx(), halmac_fw_88xx.c:1071-1096.
     *  GENERAL_INFO_SET_FW_TX_BOUNDARY: content byte 0, bits[23:16] of word @ +8. */
    private fun sendGeneralInfo() {
        val fwTxBoundary = txFifoLayout.fwTxBufAddrPages - txFifoLayout.rsvdBoundaryPages
        val content = ByteArray(4)
        setBits(content, 0, 16, 8, fwTxBoundary)
        h2c.send(Rtl8821cRegs.SUB_CMD_ID_GENERAL_INFO, content)
        log("Sent general_info (fw_tx_boundary=$fwTxBoundary pages)")
    }

    /** proc_send_phydm_info_88xx(), halmac_fw_88xx.c:1098-1126.
     *  Content word @ +8: [7:0]=REF_TYPE [15:8]=RF_TYPE [23:16]=CUT_VER
     *  [27:24]=RX_ANT_STATUS [31:28]=TX_ANT_STATUS. */
    private fun sendPhydmInfo() {
        val content = ByteArray(8)
        setBits(content, 0, 0, 8, RFE_TYPE_DEFAULT)
        setBits(content, 0, 8, 8, Rtl8821cRegs.HALMAC_RF_1T1R)
        setBits(content, 0, 16, 8, chipCutVersion)
        setBits(content, 0, 24, 4, Rtl8821cRegs.BB_PATH_A)
        setBits(content, 0, 28, 4, Rtl8821cRegs.BB_PATH_A)
        h2c.send(Rtl8821cRegs.SUB_CMD_ID_PHYDM_INFO, content)
        log("Sent phydm_info (rf_type=1T1R, cut_ver=$chipCutVersion)")
    }

    private fun setBits(d: ByteArray, byteOffset: Int, bitOffset: Int, width: Int, value: Int) {
        var word = (d[byteOffset].toInt() and 0xFF) or
                ((d[byteOffset + 1].toInt() and 0xFF) shl 8) or
                ((d[byteOffset + 2].toInt() and 0xFF) shl 16) or
                ((d[byteOffset + 3].toInt() and 0xFF) shl 24)
        val mask = ((1L shl width) - 1).toInt() shl bitOffset
        word = (word and mask.inv()) or ((value shl bitOffset) and mask)
        d[byteOffset] = (word and 0xFF).toByte()
        d[byteOffset + 1] = ((word shr 8) and 0xFF).toByte()
        d[byteOffset + 2] = ((word shr 16) and 0xFF).toByte()
        d[byteOffset + 3] = ((word shr 24) and 0xFF).toByte()
    }
}
