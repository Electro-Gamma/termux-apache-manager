plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.rtl8821cu"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.rtl8821cu"
        minSdk = 26        // USB Host API only needs API 12+; 26 is a safe modern floor
        targetSdk = 35
        versionCode = 1
        versionName = "0.1-phase0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    // The extracted RTL8821C firmware (Phase 1) ships as a raw asset.
    // Not read by any code yet in this Phase 0 drop — bundled for the next step.
    androidResources {
        noCompress += "bin"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
}
