# RTL8821CU Bridge — Phase 0 + Phase 1

An Android app (100% Kotlin, no root, no NDK/native code) that talks
directly to a Realtek RTL8811CU/RTL8821CU USB Wi-Fi adapter over
Android's USB Host API — completely independent of the phone's own
Wi-Fi radio, connection, or network stack. No `ACCESS_WIFI_STATE`, no
`INTERNET`, no location permission: check `AndroidManifest.xml`, the
only declared requirement is `android.hardware.usb.host`.

## Phase 0 — proven on real hardware

That an unrooted Android app can reach real RTL8821C silicon at the
register level: open the USB device, claim the interface, read/decode
the chip-version register. Confirmed working against a real RTL8811CU
dongle (VID 0x0BDA / PID 0xC811) — see the chat history for the actual
device log.

## Phase 1 — firmware download (traced end-to-end, not yet hardware-tested)

Powers the chip on and pushes its firmware into IMEM/DMEM, ending with
a poll for the chip's own "firmware alive" signal
(`REG_MCUFW_CTRL == 0xC078`). This turned out to be a real pipeline,
not a simple chunk-and-poll: raw firmware bytes get wrapped in a full
TX descriptor, pushed over the bulk endpoint into an on-chip staging
buffer, then the chip's internal DMA engine is triggered via registers
to copy that buffer into IMEM/DMEM, with a hardware-computed checksum
verified after each memory segment.

**This has not been run against real hardware yet** — it's a careful,
fully-traced port, but firmware download is exactly the kind of
timing/sequencing-sensitive code that benefits from an actual test
run before being trusted. Tap **Scan** first (leaves the USB
connection open), then **Download firmware (Phase 1)**, and watch the
log — it prints every stage (power sequence, per-segment progress,
checksum results) so a failure points at roughly where to look.

## Where everything came from (traceability)

| This project | Ported from (in your uploaded driver) |
|---|---|
| `RegisterIo.kt` | `usbctrl_vendorreq()` in `os_dep/linux/usb_ops_linux.c`, `usb_read8/16/32`/`usb_write8` in `hal/hal_hci/hal_usb.c` |
| `Rtl8821cRegs.kt` | `hal/halmac/halmac_reg2.h`, `halmac_bit2.h`, `halmac_bit_8821c.h`, `halmac_88xx_cfg.h` |
| `ChipVersion.kt` | `read_chip_version()` in `hal/rtl8821c/rtl8821c_ops.c` (lines 34-64) |
| `UsbBridge.kt` + `device_filter.xml` | `rtw_usb_id_tbl[]` in `os_dep/linux/usb_intf.c` (RTL8821C entries) |
| `PowerSequence.kt` | `mac_pwr_switch_usb_8821c()` (`halmac_usb_8821c.c`) + the generic interpreter `pwr_seq_parser_88xx()`/`pwr_sub_seq_parser_88xx()` (`halmac_common_88xx.c:2472-2589`) + the USB-relevant rows of `TRANS_CARDDIS_TO_CARDEMU_8821C`/`TRANS_CARDEMU_TO_ACT_8821C` (`halmac_pwr_seq_8821c.c:20-162`) |
| `TxDescriptor.kt` | Bit layout from `halmac_tx_desc_nic.h`; checksum from `fill_txdesc_check_sum_8821c()` (`halmac_common_8821c.c:135-162`) |
| `BulkPipe.kt` | `usb_write_port_not_xmitframe()` (`os_dep/linux/usb_ops_linux.c`) — Android's `bulkTransfer()` replaces the URB submit/wait cycle |
| `FirmwareDownloader.kt` | Full chain: `rtw_halmac_dlfw` → `download_fw` → `download_firmware_88xx` → `start_dlfw_88xx` → `dlfw_to_mem_88xx` → `send_fwpkt_88xx`/`dl_rsvd_page_88xx` (stage) → `iddma_dlfw_88xx`/`iddma_en_88xx` (on-chip DMA) → `check_fw_chksum_88xx` → `dlfw_end_flow_88xx`, all in `hal/hal_halmac.c` and `hal/halmac/halmac_88xx/*` |
| `assets/rtl8821c_fw_nic.bin` | `array_mp_8821c_fw_nic[]` in `hal/rtl8821c/hal8821c_fw.c` — 137,616 bytes, verified against the driver's own length constant |

## Known simplifications (flagged, not hidden)

- **`REG_FIFOPAGE_CTRL_2` restore value.** The original driver restores
  this register to `adapter->txff_alloc.rsvd_boundary` after staging
  each chunk — a value tracked by a whole separate TX-FIFO page
  allocator subsystem we don't have. We restore to `0` instead. This
  should be harmless for firmware download specifically (the value is
  overwritten again by the very next chunk before anything reads it),
  but it's a deliberate simplification worth knowing about if Phase 1
  fails in a way that points at FIFO page state.
- **Bulk-out endpoint selection.** Firmware chunks always resolve to
  `bulkout_id=0` in the driver, which we take to mean "the first
  bulk-OUT endpoint found on the claimed interface" (matching how the
  driver's own `RtOutPipe[]` gets populated during enumeration). True
  for single-endpoint dongles like the RTL8811CU; worth revisiting if
  you test against a dongle with multiple bulk-OUT endpoints.
- **DDMA polling has no inter-poll delay**, matching the source
  exactly (`iddma_en_88xx` polls in a tight loop) — each iteration is
  still a real USB control-transfer round trip, so it's not as tight
  as it sounds, but flagging it since 1000 rapid-fire control
  transfers is a reasonable thing to watch for in logcat if this phase
  is slow.

## What still doesn't port easily

- **`phydm` calibration** (IQK, LCK, thermal power tracking) — still
  the biggest remaining risk in the whole project. Firmware download
  succeeding doesn't mean the chip can actually transmit/receive well;
  that's what calibration is for, and it hasn't been touched yet.
- **RX/TX descriptor parsing** for real 802.11 frame data — needed for
  Phase 3 (scan) and Phase 4 (monitor mode), not yet started.

## Running this

Open the folder in Android Studio (Hedgehog or newer). Plug the
adapter in via USB-OTG; the app should auto-launch (or tap **Scan**),
approve the permission dialog, confirm the chip-version log looks
right, then tap **Download firmware (Phase 1)** and watch the log.

If Phase 1 fails, the log message tells you roughly which stage:
- Fails during "Power sequence" → a poll timeout on one of the ~15
  power-on register ops; worth double-checking against
  `halmac_pwr_seq_8821c.c` line by line.
- "FW size mismatch" → the firmware header parse disagrees with the
  actual asset file size; shouldn't happen since the asset was
  extracted and verified against the driver's own length constant,
  but worth re-checking `assets/rtl8821c_fw_nic.bin` wasn't corrupted
  in transit.
- "Timed out waiting for FIFO page ready" → the per-chunk bulk-OUT
  stage isn't landing; check the bulk-out endpoint selection.
- "DDMA channel-0 busy timeout" or "Firmware checksum failed" → the
  chunk staged, but the on-chip DMA copy or its checksum didn't go
  as expected — this is the most likely spot for a subtle porting bug
  given how little wiggle room the DDMA register sequence has.
- "Firmware not alive after download" → every earlier stage reported
  success but the final `0xC078` signal never showed up — worth
  checking `wlan_cpu_en_88xx`'s two register writes against
  `halmac_common_88xx.c`.

## Next steps (Phase 2+)

Once Phase 1 is confirmed working on real hardware: MAC/BB/RF register
bring-up (mostly static tables, mechanically portable), then `phydm`
calibration (the real remaining risk), then passive scanning (Phase 3)
and monitor mode (Phase 4).
