# RTL8821CU Bridge — Phase 0

An Android app (100% Kotlin, no root, no NDK/native code) that talks
directly to a Realtek RTL8811CU/RTL8821CU USB Wi-Fi adapter over
Android's USB Host API — completely independent of the phone's own
Wi-Fi radio, connection, or network stack. No `ACCESS_WIFI_STATE`, no
`INTERNET`, no location permission: check `AndroidManifest.xml`, the
only declared requirement is `android.hardware.usb.host`.

## What this phase proves

That an unrooted Android app can reach real RTL8821C silicon at the
register level. Concretely: it opens the USB device, claims the
interface, issues one 32-bit register read over a USB control
transfer, and decodes the result into a chip identity (test/normal
chip, silicon cut version, fab vendor, RF type, regulator mode) —
mirroring `read_chip_version()` from the driver you uploaded.

If this runs and prints sane values, the fundamental premise of the
whole project — "reach this chip from Kotlin app-space, no kernel
module" — is validated. Everything past this point is scope, not risk.

## Where everything came from (traceability)

| This project | Ported from (in your uploaded driver) |
|---|---|
| `RegisterIo.kt` | `usbctrl_vendorreq()` in `os_dep/linux/usb_ops_linux.c`, and `usb_read8/16/32`/`usb_write8` in `hal/hal_hci/hal_usb.c` |
| `Rtl8821cRegs.kt` | `hal/halmac/halmac_reg_8821c.h` + `hal/halmac/halmac_bit_8821c.h` |
| `ChipVersion.kt` | `read_chip_version()` in `hal/rtl8821c/rtl8821c_ops.c` (lines 34-64) |
| `UsbBridge.kt` + `device_filter.xml` | `rtw_usb_id_tbl[]` in `os_dep/linux/usb_intf.c` (RTL8821C entries, lines 226-236) |
| `assets/rtl8821c_fw_nic.bin` | Extracted from the embedded byte array `array_mp_8821c_fw_nic[]` in `hal/rtl8821c/hal8821c_fw.c` — 137,616 bytes, verified against the driver's own `array_length_mp_8821c_fw_nic` constant. Not used by any code yet; bundled for Phase 1. |

Nothing here is guessed or reverse-engineered blind — every register
address, bit position, and USB request code is transcribed from the
file you gave me. That matters, because it's also exactly where the
easy part of this project ends.

## The one wire-level primitive that ports (almost) mechanically

Every register access in the original driver funnels through a plain
USB control transfer: `bRequest=0x05`, `bmRequestType=0xC0` (read) or
`0x40` (write), `wValue`=register address, `wIndex`=0. Android's
`UsbDeviceConnection.controlTransfer(requestType, request, value,
index, buffer, length, timeout)` takes the same six fields. That's why
`RegisterIo.kt` is a close, confident port — it isn't reimplementing
anything, it's issuing the same bytes over the same kind of pipe.

## What does NOT port this easily (be honest with yourself about this)

- **Firmware download handshake** (`rtw_hal_fw_dl`) — sequencing and
  timeouts need to be preserved faithfully; finite but fiddly.
- **MAC/BB/RF bring-up tables** — mostly static `{address, value}`
  data, mechanically portable, just tedious.
- **`phydm` calibration** (IQK, LCK, thermal power tracking) — this is
  the real risk in the whole project. It's timing- and
  silicon-behavior-sensitive, and a subtly wrong port tends to produce
  a chip that half-initializes and silently won't RX/TX, not a clean
  error. Budget the most time and the most patience here.
- **RX/TX descriptor parsing** for real frame data — the field layouts
  already exist in `rtl8821cu_recv.c`/`rtl8821cu_xmit.c`, so this is
  translation work, not invention, but it's meticulous bit-twiddling
  that has to be exactly right.

## Running this

Open the folder in Android Studio (Hedgehog or newer) — it can
regenerate the Gradle wrapper on first sync if it's missing. Plug the
adapter in via a USB-OTG cable/hub; the app should auto-launch (or you
can tap **Scan**), approve the one-time system permission dialog, and
the log should print a decoded chip identity within a second.

If `controlTransfer` returns `-1` or the claimed values look wrong,
the most common causes are: the adapter is in the wrong USB
mode/needs `usb_modeswitch`-equivalent handling (some of these
dongles enumerate as a CD-ROM installer first), or `getInterface(0)`
isn't the right interface index on a particular dongle's descriptor
layout — worth dumping `device.interfaceCount` and each interface's
class/subclass to confirm.

## Next steps (Phase 1)

Port `rtw_hal_fw_dl()` using `assets/rtl8821c_fw_nic.bin`: enable
download mode, chunk-write the firmware via control/bulk transfers,
poll the ready bit, hand off execution. This is the next real
milestone — a chip that accepts and runs its firmware from an
unrooted Android app.
