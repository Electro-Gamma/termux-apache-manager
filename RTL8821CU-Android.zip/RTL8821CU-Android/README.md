# RTL8821CU Bridge — Phase 0 + Phase 1

An Android app (100% Kotlin, no root, no NDK/native code) that talks
directly to a Realtek RTL8811CU/RTL8821CU USB Wi-Fi adapter over
Android's USB Host API — completely independent of the phone's own
Wi-Fi radio, connection, or network stack. No `ACCESS_WIFI_STATE`, no
`INTERNET`, no location permission: check `AndroidManifest.xml`, the
only declared requirement is `android.hardware.usb.host`.

## Phase 0 — proven on real hardware

That an unrooted Android app can reach real RTL8821C silicon at the
register level: open the USB device, claim the interface, read/decode
the chip-version register. Confirmed working against a real RTL8811CU
dongle (VID 0x0BDA / PID 0xC811) — see the chat history for the actual
device log.

## Phase 1 — firmware download

**Confirmed working on real hardware as of the second test run.** The
first run correctly downloaded DMEM, then failed IMEM's checksum
check. The log pinpointed the segment; tracing `send_fwpkt_88xx()`
(`halmac_fw_88xx.c:689-711`) turned up a second, separate USB-framing
quirk that got missed in the initial port: if descriptor+payload lands
on an *exact* multiple of 512 bytes (hardcoded 512, independent of the
endpoint's actual max packet size — that's a different check, the
8-byte `PKT_OFFSET` one in `TxDescriptor.kt`), the driver appends one
throwaway byte to the staged transfer only, never to the DMA copy
length. IMEM's real firmware happened to have its *last* chunk
(65488 bytes ÷ 8192-byte chunks → 8144-byte remainder) land exactly on
that boundary (8144 + 48-byte descriptor = 8192 = 16×512); none of
DMEM's chunks did, which is exactly why DMEM passed and IMEM didn't.
Fixed in `FirmwareDownloader.stageChunk()`.

Also worth noting: this firmware image *does* have an EMEM segment
(`hasEmem=true`, 40,088 bytes) — the header-parsing and EMEM download
path get real exercise here, not just the DMEM/IMEM path originally
assumed most likely.

Powers the chip on and pushes firmware into IMEM/DMEM/EMEM, ending
with a poll for the chip's own "firmware alive" signal
(`REG_MCUFW_CTRL == 0xC078`). Tap **Scan** first (leaves the USB
connection open), then **Download firmware (Phase 1)** — the log
prints every stage so a failure points at roughly where to look.

## Where everything came from (traceability)

| This project | Ported from (in your uploaded driver) |
|---|---|
| `RegisterIo.kt` | `usbctrl_vendorreq()` in `os_dep/linux/usb_ops_linux.c`, `usb_read8/16/32`/`usb_write8` in `hal/hal_hci/hal_usb.c` |
| `Rtl8821cRegs.kt` | `hal/halmac/halmac_reg2.h`, `halmac_bit2.h`, `halmac_bit_8821c.h`, `halmac_88xx_cfg.h` |
| `ChipVersion.kt` | `read_chip_version()` in `hal/rtl8821c/rtl8821c_ops.c` (lines 34-64) |
| `UsbBridge.kt` + `device_filter.xml` | `rtw_usb_id_tbl[]` in `os_dep/linux/usb_intf.c` (RTL8821C entries) |
| `PowerSequence.kt` | `mac_pwr_switch_usb_8821c()` (`halmac_usb_8821c.c`) + the generic interpreter `pwr_seq_parser_88xx()`/`pwr_sub_seq_parser_88xx()` (`halmac_common_88xx.c:2472-2589`) + the USB-relevant rows of `TRANS_CARDDIS_TO_CARDEMU_8821C`/`TRANS_CARDEMU_TO_ACT_8821C` (`halmac_pwr_seq_8821c.c:20-162`) |
| `TxDescriptor.kt` | Bit layout from `halmac_tx_desc_nic.h`; checksum from `fill_txdesc_check_sum_8821c()` (`halmac_common_8821c.c:135-162`) |
| `BulkPipe.kt` | `usb_write_port_not_xmitframe()` (`os_dep/linux/usb_ops_linux.c`) — Android's `bulkTransfer()` replaces the URB submit/wait cycle |
| `FirmwareDownloader.kt` | Full chain: `rtw_halmac_dlfw` → `download_fw` → `download_firmware_88xx` → `start_dlfw_88xx` → `dlfw_to_mem_88xx` → `send_fwpkt_88xx`/`dl_rsvd_page_88xx` (stage) → `iddma_dlfw_88xx`/`iddma_en_88xx` (on-chip DMA) → `check_fw_chksum_88xx` → `dlfw_end_flow_88xx`, all in `hal/hal_halmac.c` and `hal/halmac/halmac_88xx/*` |
| `assets/rtl8821c_fw_nic.bin` | `array_mp_8821c_fw_nic[]` in `hal/rtl8821c/hal8821c_fw.c` — 137,616 bytes, verified against the driver's own length constant |
| `MacInit.kt` | `init_trx_cfg_8821c()` (`halmac_init_8821c.c:355-390`), `txdma_queue_mapping_8821c()`, `priority_queue_cfg_8821c()`, `set_trx_fifo_info_8821c()`, `init_h2c_8821c()` |
| `H2cTransport.kt` | `send_h2c_pkt_88xx()`, `get_h2c_buf_free_space_88xx()`, `set_h2c_pkt_hdr_88xx()` (`halmac_common_88xx.c`), header bit layout from `halmac_fw_offload_h2c_nic.h` |
| `FifoDump.kt` | `dump_fifo_88xx()` / `read_buf_88xx()` (`halmac_common_88xx.c:1580-1680`) |
| `GeneralInfoSender.kt` | `send_general_info_88xx()`, `proc_send_general_info_88xx()`, `proc_send_phydm_info_88xx()` (`halmac_fw_88xx.c:1016-1126`), and the caller values in `_send_general_info()` (`hal_halmac.c:2768`) |

## Known simplifications (flagged, not hidden)

- **`REG_FIFOPAGE_CTRL_2` restore value.** The original driver restores
  this register to `adapter->txff_alloc.rsvd_boundary` after staging
  each chunk — a value tracked by a whole separate TX-FIFO page
  allocator subsystem we don't have. We restore to `0` instead. This
  should be harmless for firmware download specifically (the value is
  overwritten again by the very next chunk before anything reads it),
  but it's a deliberate simplification worth knowing about if Phase 1
  fails in a way that points at FIFO page state.
- **Bulk-out endpoint selection.** Firmware chunks always resolve to
  `bulkout_id=0` in the driver, which we take to mean "the first
  bulk-OUT endpoint found on the claimed interface" (matching how the
  driver's own `RtOutPipe[]` gets populated during enumeration). True
  for single-endpoint dongles like the RTL8811CU; worth revisiting if
  you test against a dongle with multiple bulk-OUT endpoints.
- **DDMA polling has no inter-poll delay**, matching the source
  exactly (`iddma_en_88xx` polls in a tight loop) — each iteration is
  still a real USB control-transfer round trip, so it's not as tight
  as it sounds, but flagging it since 1000 rapid-fire control
  transfers is a reasonable thing to watch for in logcat if this phase
  is slow.

## Phase 2 — MAC bring-up + first H2C commands (traced, not yet hardware-tested)

Configures the chip's TX queue priority mapping and FIFO page layout,
triggers the hardware's link-list-table auto-init, carves out an H2C
ring buffer, then sends the firmware its first two commands
(`general_info`, `phydm_info`) and reads back on-chip memory to confirm
they landed. Tap **Init MAC + send info (Phase 2)** after a successful
firmware download.

Two things worth knowing before testing:
- The TX-FIFO-page arithmetic in `MacInit.kt` (which computes real,
  non-zero `rsvd_boundary`/`h2cq_addr`/`fw_txbuf_addr` values) is new —
  Phase 1 got away with treating these as `0` because, at that point in
  the real sequence, nothing had computed them yet. That wasn't a
  simplification so much as accurate timing. From Phase 2 onward the
  real values matter.
- `phydm_info` despite its name is not RF calibration — it's four bytes
  of chip metadata (RFE type, RF type, cut version, antenna paths)
  reported *to* the firmware. Real IQK/LCK calibration is a separate,
  still-untouched piece of work.
- `rfe_type` (front-end module variant) normally comes from EEPROM/efuse,
  which isn't implemented here — defaulted to `0`, flagged in
  `GeneralInfoSender.kt`.

## What still doesn't port easily

- **RF calibration** (IQK, LCK, thermal power tracking) — still the
  biggest remaining risk. Nothing built so far touches this.
- **RX/TX descriptor parsing** for real 802.11 frame data — needed for
  Phase 3 (scan) and Phase 4 (monitor mode), not yet started.

## Running this

Open the folder in Android Studio (Hedgehog or newer). Plug the
adapter in via USB-OTG; the app should auto-launch (or tap **Scan**),
approve the permission dialog, confirm the chip-version log looks
right, then tap **Download firmware (Phase 1)** and watch the log.

If Phase 1 fails, the log message tells you roughly which stage:
- Fails during "Power sequence" → a poll timeout on one of the ~15
  power-on register ops; worth double-checking against
  `halmac_pwr_seq_8821c.c` line by line.
- "FW size mismatch" → the firmware header parse disagrees with the
  actual asset file size; shouldn't happen since the asset was
  extracted and verified against the driver's own length constant,
  but worth re-checking `assets/rtl8821c_fw_nic.bin` wasn't corrupted
  in transit.
- "Timed out waiting for FIFO page ready" → the per-chunk bulk-OUT
  stage isn't landing; check the bulk-out endpoint selection.
- "DDMA channel-0 busy timeout" or "Firmware checksum failed" → the
  chunk staged, but the on-chip DMA copy or its checksum didn't go
  as expected — this is the most likely spot for a subtle porting bug
  given how little wiggle room the DDMA register sequence has.
- "Firmware not alive after download" → every earlier stage reported
  success but the final `0xC078` signal never showed up — worth
  checking `wlan_cpu_en_88xx`'s two register writes against
  `halmac_common_88xx.c`.

## Next steps (Phase 2+)

Once Phase 1 is confirmed working on real hardware: MAC/BB/RF register
bring-up (mostly static tables, mechanically portable), then `phydm`
calibration (the real remaining risk), then passive scanning (Phase 3)
and monitor mode (Phase 4).
