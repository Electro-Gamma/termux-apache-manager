// Top-level build file. Individual module build files apply these plugins.
plugins {
    // AGP 8.6.0 is the first version that supports compileSdk 35, and its
    // minimum required Gradle version is 8.7 — matching what this project's
    // build notebook installs. (developer.android.com/build/releases/gradle-plugin)
    id("com.android.application") version "8.6.0" apply false
    id("org.jetbrains.kotlin.android") version "2.0.20" apply false
}
