/*
 * Blynk Administration dashboard (vanilla JS, no dependencies).
 * Talks to the original admin REST API under the same root path (e.g. /admin/users, /admin/stats/realtime).
 * All dynamic text is inserted with textContent, never innerHTML, so user-controlled data cannot inject markup.
 */
(function () {
  'use strict';

  var BASE = location.pathname.replace(/\/+$/, '') + '/';
  var root = document.getElementById('root');

  /* ---------- helpers ---------- */
  function el(tag, attrs) {
    var n = document.createElement(tag);
    if (attrs) {
      Object.keys(attrs).forEach(function (k) {
        var v = attrs[k];
        if (v === null || v === undefined || v === false) return;
        if (k === 'class') n.className = v;
        else if (k === 'text') n.textContent = v;
        else if (k.slice(0, 2) === 'on') n.addEventListener(k.slice(2), v);
        else n.setAttribute(k, v === true ? '' : v);
      });
    }
    for (var i = 2; i < arguments.length; i++) add(n, arguments[i]);
    return n;
  }
  function add(parent, c) {
    if (c === null || c === undefined || c === false) return;
    if (Array.isArray(c)) { c.forEach(function (x) { add(parent, x); }); return; }
    parent.appendChild(typeof c === 'object' ? c : document.createTextNode(String(c)));
  }
  function clear(n) { while (n.firstChild) n.removeChild(n.firstChild); return n; }

  var ICONS = {
    logo: '<path d="M4 12a8 8 0 0 1 16 0M7 12a5 5 0 0 1 10 0M10 12a2 2 0 0 1 4 0"/><circle cx="12" cy="17" r="1.3"/>',
    dash: '<rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/>',
    users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0M16 4.5a3.5 3.5 0 0 1 0 7M18 14.5a6.5 6.5 0 0 1 3.5 5.5"/>',
    pulse: '<path d="M3 12h4l2.5-7 4 14L16 12h5"/>',
    chip: '<rect x="6" y="6" width="12" height="12" rx="2"/><path d="M9 2v4M15 2v4M9 18v4M15 18v4M2 9h4M2 15h4M18 9h4M18 15h4"/>',
    chart: '<path d="M4 20V10M10 20V4M16 20v-8M22 20H2"/>',
    globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>',
    cog: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
    menu: '<path d="M3 6h18M3 12h18M3 18h18"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
    moon: '<path d="M21 13.5A9 9 0 1 1 10.5 3a7 7 0 0 0 10.5 10.5z"/>',
    out: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>',
    refresh: '<path d="M21 12a9 9 0 1 1-3-6.7L21 8M21 3v5h-5"/>',
    server: '<rect x="3" y="4" width="18" height="7" rx="2"/><rect x="3" y="13" width="18" height="7" rx="2"/><path d="M7 7.5h.01M7 16.5h.01"/>',
    link: '<path d="M10 13a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-1 1M14 11a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l1-1"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    back: '<path d="M15 18l-6-6 6-6"/>',
    trash: '<path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14"/>',
    save: '<path d="M5 3h11l3 3v15H5zM8 3v5h7V3M8 21v-7h8v7"/>'
  };
  function icon(name) {
    var s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    s.setAttribute('class', 'i'); s.setAttribute('viewBox', '0 0 24 24');
    s.innerHTML = ICONS[name] || '';   // static, trusted strings only
    return s;
  }

  function fmtNum(n) { return (n === null || n === undefined || isNaN(n)) ? '–' : Number(n).toLocaleString(); }
  function fmtBytes(b) {
    if (b === null || b === undefined || b < 0) return '–';
    var u = ['B', 'KB', 'MB', 'GB', 'TB'], i = 0, v = Number(b);
    while (v >= 1024 && i < u.length - 1) { v /= 1024; i++; }
    return v.toFixed(i === 0 ? 0 : 1) + ' ' + u[i];
  }
  function fmtDuration(ms) {
    var s = Math.floor(ms / 1000), d = Math.floor(s / 86400); s -= d * 86400;
    var h = Math.floor(s / 3600); s -= h * 3600; var m = Math.floor(s / 60); s -= m * 60;
    var parts = [];
    if (d) parts.push(d + 'd'); if (d || h) parts.push(h + 'h'); if (d || h || m) parts.push(m + 'm'); parts.push(s + 's');
    return parts.join(' ');
  }
  function fmtDate(ts) { return ts ? new Date(ts).toLocaleString() : '–'; }

  function toast(msg, isErr) {
    var box = document.getElementById('toasts');
    var t = el('div', { class: 'toast' + (isErr ? ' err' : ''), text: msg });
    box.appendChild(t);
    setTimeout(function () { if (t.parentNode) t.parentNode.removeChild(t); }, isErr ? 6000 : 3000);
  }

  function confirmDialog(title, text, okLabel, onOk) {
    var bg = el('div', { class: 'modal-bg' });
    function close() { if (bg.parentNode) bg.parentNode.removeChild(bg); }
    bg.addEventListener('click', function (e) { if (e.target === bg) close(); });
    bg.appendChild(el('div', { class: 'modal', role: 'dialog' },
      el('h2', { text: title }), el('div', { class: 'muted', text: text }),
      el('div', { class: 'actions' },
        el('button', { class: 'btn', text: 'Cancel', onclick: close }),
        el('button', { class: 'btn danger solid', text: okLabel, onclick: function () { close(); onOk(); } }))));
    document.body.appendChild(bg);
  }

  /* ---------- API ---------- */
  function api(method, path, body) {
    var opts = { method: method, credentials: 'same-origin', headers: {} };
    if (body !== undefined) { opts.body = JSON.stringify(body); opts.headers['Content-Type'] = 'application/json'; }
    return fetch(BASE + path, opts).then(function (r) {
      var ct = r.headers.get('content-type') || '';
      if (r.status === 401 || r.status === 403 || (r.ok && ct.indexOf('text/html') === 0)) {
        location.reload(); throw new Error('Session expired');
      }
      if (!r.ok) {
        return r.text().then(function (t) { throw new Error(t || ('HTTP ' + r.status)); });
      }
      var total = r.headers.get('X-Total-Count');
      return r.text().then(function (t) {
        return { data: t ? JSON.parse(t) : null, total: total === null ? null : parseInt(total, 10) };
      });
    });
  }
  // user ids look like "me@example.com-Blynk"; keep '@' readable in the path exactly like the original panel did
  function pid(id) { return encodeURIComponent(id).replace(/%40/g, '@'); }
  function q(params) {
    return Object.keys(params).filter(function (k) { return params[k] !== undefined && params[k] !== null && params[k] !== ''; })
      .map(function (k) { return encodeURIComponent(k) + '=' + encodeURIComponent(params[k]); }).join('&');
  }

  /* ---------- generic UI pieces ---------- */
  function loading() { return el('div', { class: 'loader' }, el('span', { class: 'spin' }), 'Loading…'); }
  function failure(e) { return el('div', { class: 'notice', text: 'Could not load data: ' + e.message }); }

  function kpi(iconName, value, label, tone) {
    return el('div', { class: 'card kpi' },
      el('div', { class: 'ic ' + (tone || '') }, icon(iconName)),
      el('div', null, el('div', { class: 'v', text: value }), el('div', { class: 'l', text: label })));
  }

  // table: cols = [{key,label,num,sortable,render(row)}]; rows = array
  function table(cols, rows, opts) {
    opts = opts || {};
    var thead = el('tr');
    cols.forEach(function (c) {
      var th = el('th', { class: (c.num ? 'num ' : '') + (c.sortable ? 'sortable' : ''), text: c.label });
      if (c.sortable && opts.onSort) {
        if (opts.sortField === c.key) th.textContent = c.label + (opts.sortDir === 'ASC' ? ' ▲' : ' ▼');
        th.addEventListener('click', function () { opts.onSort(c.key); });
      }
      thead.appendChild(th);
    });
    var tbody = el('tbody');
    if (!rows.length) {
      tbody.appendChild(el('tr', null, el('td', { colspan: cols.length }, el('div', { class: 'empty', text: opts.empty || 'No data' }))));
    }
    rows.forEach(function (r) {
      var tr = el('tr', { class: opts.onRow ? 'click' : '' });
      if (opts.onRow) tr.addEventListener('click', function () { opts.onRow(r); });
      cols.forEach(function (c) {
        var td = el('td', { class: c.num ? 'num' : '' });
        var v = c.render ? c.render(r) : r[c.key];
        add(td, v === undefined || v === null ? '–' : v);
        tr.appendChild(td);
      });
      tbody.appendChild(tr);
    });
    return el('div', { class: 'table-wrap' }, el('table', null, el('thead', null, thead), tbody));
  }

  function pager(state, total, onChange) {
    var pages = Math.max(1, Math.ceil(total / state.perPage));
    var sel = el('select', { onchange: function () { state.perPage = parseInt(this.value, 10); state.page = 1; onChange(); }, style: 'width:auto' });
    [10, 25, 50, 100].forEach(function (n) { sel.appendChild(el('option', { value: n, selected: n === state.perPage, text: n + ' / page' })); });
    return el('div', { class: 'pager' },
      el('span', { class: 'muted', text: fmtNum(total) + ' total' }), el('span', { class: 'grow' }), sel,
      el('button', { class: 'btn', text: 'Prev', disabled: state.page <= 1, onclick: function () { state.page--; onChange(); } }),
      el('span', { text: 'Page ' + state.page + ' of ' + pages }),
      el('button', { class: 'btn', text: 'Next', disabled: state.page >= pages, onclick: function () { state.page++; onChange(); } }));
  }

  // name/count list with proportional bars
  function countTable(rows, labels, opts) {
    opts = opts || {};
    var max = rows.reduce(function (m, r) { return Math.max(m, Number(r.count) || 0); }, 0) || 1;
    var data = rows.slice().sort(function (a, b) { return (Number(b.count) || 0) - (Number(a.count) || 0); });
    if (opts.limit) data = data.slice(0, opts.limit);
    return table([
      { key: 'name', label: labels[0] },
      { key: 'count', label: labels[1], num: true, render: function (r) { return fmtNum(Number(r.count)); } },
      { key: 'bar', label: '', render: function (r) { return el('div', { class: 'bar' }, el('i', { style: 'width:' + Math.round(100 * (Number(r.count) || 0) / max) + '%' })); } }
    ], data, { empty: 'Nothing to show yet' });
  }

  /* ---------- pages ---------- */
  var timers = [];
  function stopTimers() { timers.forEach(clearInterval); timers = []; }

  var rateHistory = [];   // measured 1-minute request rates since this page was opened

  function sparkline(values) {
    var w = 300, h = 70, ns = 'http://www.w3.org/2000/svg';
    var svg = document.createElementNS(ns, 'svg');
    svg.setAttribute('class', 'spark'); svg.setAttribute('viewBox', '0 0 ' + w + ' ' + h); svg.setAttribute('preserveAspectRatio', 'none');
    if (values.length < 2) return svg;
    var max = Math.max.apply(null, values.concat([1])), step = w / (values.length - 1);
    var pts = values.map(function (v, i) { return (i * step).toFixed(1) + ',' + (h - 6 - (v / max) * (h - 12)).toFixed(1); });
    var area = document.createElementNS(ns, 'polygon');
    area.setAttribute('points', '0,' + h + ' ' + pts.join(' ') + ' ' + w + ',' + h);
    area.setAttribute('fill', 'var(--primary)'); area.setAttribute('opacity', '.15');
    var line = document.createElementNS(ns, 'polyline');
    line.setAttribute('points', pts.join(' ')); line.setAttribute('fill', 'none');
    line.setAttribute('stroke', 'var(--primary)'); line.setAttribute('stroke-width', '2'); line.setAttribute('vector-effect', 'non-scaling-stroke');
    svg.appendChild(area); svg.appendChild(line);
    return svg;
  }

  function meter(pct) {
    var cls = pct > 90 ? 'crit' : pct > 75 ? 'hi' : '';
    return el('div', { class: 'meter' }, el('i', { class: cls, style: 'width:' + Math.min(100, Math.max(0, pct)).toFixed(0) + '%' }));
  }

  function kvList(pairs) {
    var dl = el('dl', { class: 'kv' });
    pairs.forEach(function (p) { dl.appendChild(el('dt', { text: p[0] })); dl.appendChild(el('dd', { text: p[1] })); });
    return dl;
  }

  function pageOverview(c) {
    c.appendChild(loading());
    var auto = true;
    var holder = el('div', { class: 'stack' });
    var statusBadge = el('span', { class: 'badge live' }, el('span', { class: 'dot' }), 'Live');

    function render(stat, sys, perUser) {
      clear(holder);
      var mem = stat.memoryStat || {};
      var heapPct = sys.heapMaxBytes > 0 ? 100 * sys.heapUsedBytes / sys.heapMaxBytes : 0;
      holder.appendChild(el('div', { class: 'grid kpis' },
        kpi('server', 'Online', 'Server status · ' + fmtDate(sys.serverTime)),
        kpi('clock', fmtDuration(sys.uptimeMillis), 'Uptime · since ' + fmtDate(sys.startTime), 'blue'),
        kpi('users', fmtNum(stat.registrations), 'Registered users'),
        kpi('link', fmtNum(stat.connected), 'Sessions with app + hardware', 'blue'),
        kpi('globe', fmtNum(stat.onlineApps) + ' / ' + fmtNum(stat.totalOnlineApps), 'Users with app online / app connections'),
        kpi('chip', fmtNum(stat.onlineHards) + ' / ' + fmtNum(stat.totalOnlineHards), 'Users with hardware online / hardware connections', 'blue'),
        kpi('pulse', fmtNum(stat.oneMinRate), 'Messages per second (1 min rate)', 'warn')));
      holder.appendChild(el('div', { class: 'grid two' },
        el('div', { class: 'card' }, el('div', { class: 'card-h' }, el('h2', { text: 'Message rate' }), el('span', { class: 'muted', text: 'measured while this page is open' })),
          el('div', { class: 'card-b' }, rateHistory.length > 1 ? sparkline(rateHistory) : el('div', { class: 'muted', text: 'Collecting samples…' }), el('div', { class: 'muted', text: 'Latest: ' + fmtNum(stat.oneMinRate) + ' msg/s' }))),
        el('div', { class: 'card' }, el('div', { class: 'card-h' }, el('h2', { text: 'Activity' })),
          el('div', { class: 'card-b' }, kvList([
            ['Active in last 24 h', fmtNum(stat.active)], ['Active in last 7 days', fmtNum(stat.activeWeek)],
            ['Active in last 30 days', fmtNum(stat.activeMonth)], ['Total app messages', fmtNum(stat.commands && stat.commands.appTotal)],
            ['Total MQTT messages', fmtNum(stat.commands && stat.commands.mqttTotal)]])))));
      holder.appendChild(el('div', { class: 'grid two' },
        el('div', { class: 'card' }, el('div', { class: 'card-h' }, el('h2', { text: 'System' })),
          el('div', { class: 'card-b' }, kvList([
            ['Java', sys.javaVersion + ' (' + sys.vmName + ')'], ['OS', sys.osName + ' ' + sys.osVersion + ' · ' + sys.osArch],
            ['CPU cores', fmtNum(sys.availableProcessors)], ['Load average', sys.systemLoadAverage >= 0 ? sys.systemLoadAverage.toFixed(2) : 'n/a'],
            ['Threads', fmtNum(sys.liveThreads)], ['Time zone', sys.timeZone]]))),
        el('div', { class: 'card' }, el('div', { class: 'card-h' }, el('h2', { text: 'Memory' })),
          el('div', { class: 'card-b stack' },
            el('div', null, el('div', { class: 'muted', text: 'JVM heap: ' + fmtBytes(sys.heapUsedBytes) + ' used of ' + (sys.heapMaxBytes > 0 ? fmtBytes(sys.heapMaxBytes) : 'unlimited') }), sys.heapMaxBytes > 0 ? meter(heapPct) : null),
            kvList([['Heap committed', fmtBytes(sys.heapCommittedBytes)], ['Network buffers (heap)', fmtBytes(mem.heapBytes)], ['Network buffers (direct)', fmtBytes(mem.directBytes)]])))));
      holder.appendChild(el('div', { class: 'card' }, el('div', { class: 'card-h' }, el('h2', { text: 'Active sessions with traffic' }), el('a', { href: '#/monitoring', text: 'Open monitoring' })),
        table([{ key: 'name', label: 'User' }, { key: 'hardRate', label: 'Hardware req/s', num: true }, { key: 'appRate', label: 'App req/s', num: true }],
          perUser.slice(0, 8), { empty: 'No sessions are sending requests right now' })));
    }

    function load() {
      Promise.all([api('GET', 'stats/realtime'), api('GET', 'stats/system'), api('GET', 'stats/requestsPerUser?' + q({ _sortField: 'hardRate', _sortDir: 'DESC' }))])
        .then(function (r) {
          var stat = (r[0].data || [])[0] || {};
          rateHistory.push(stat.oneMinRate || 0); if (rateHistory.length > 60) rateHistory.shift();
          render(stat, r[1].data, r[2].data || []);
        }).catch(function (e) { clear(holder); holder.appendChild(failure(e)); });
    }
    clear(c);
    c.appendChild(el('div', { class: 'toolbar' }, statusBadge, el('span', { class: 'muted', text: 'Refreshes every 5 seconds' }), el('span', { class: 'grow' }),
      el('button', { class: 'btn', onclick: load }, icon('refresh'), 'Refresh now')));
    c.appendChild(holder);
    holder.appendChild(loading());
    load();
    timers.push(setInterval(function () { if (auto && !document.hidden) load(); }, 5000));
  }

  /* users */
  var usersState = { page: 1, perPage: 25, sortField: 'lastModifiedTs', sortDir: 'DESC', q: '' };

  function pageUsers(c) {
    var body = el('div');
    var input = el('input', { type: 'search', placeholder: 'Search by email', value: usersState.q });
    var tmr;
    input.addEventListener('input', function () { clearTimeout(tmr); tmr = setTimeout(function () { usersState.q = input.value.trim(); usersState.page = 1; load(); }, 300); });
    c.appendChild(el('div', { class: 'toolbar' }, el('div', { class: 'search' }, icon('search'), input), el('span', { class: 'grow' }),
      el('button', { class: 'btn', onclick: function () { load(); } }, icon('refresh'), 'Refresh')));
    c.appendChild(el('div', { class: 'card' }, body));

    function load() {
      clear(body).appendChild(loading());
      var params = { _page: usersState.page, _perPage: usersState.perPage, _sortField: usersState.sortField, _sortDir: usersState.sortDir };
      if (usersState.q) params._filters = JSON.stringify({ name: usersState.q });
      api('GET', 'users?' + q(params)).then(function (r) {
        var rows = r.data || [], total = r.total === null ? rows.length : r.total;
        clear(body);
        body.appendChild(table([
          { key: 'email', label: 'Email', sortable: true, render: function (u) { return el('strong', { text: u.email }); } },
          { key: 'appName', label: 'App', sortable: true },
          { key: 'projects', label: 'Projects', num: true, render: function (u) { return u.profile && u.profile.dashBoards ? u.profile.dashBoards.length : 0; } },
          { key: 'devices', label: 'Devices', num: true, render: function (u) { return countDevices(u); } },
          { key: 'region', label: 'Region' },
          { key: 'lastLoggedIP', label: 'Last IP', render: function (u) { return u.lastLoggedIP ? el('span', { class: 'mono', text: u.lastLoggedIP }) : '–'; } },
          { key: 'lastModifiedTs', label: 'Last modified', sortable: true, render: function (u) { return fmtDate(u.lastModifiedTs); } }
        ], rows, {
          sortField: usersState.sortField, sortDir: usersState.sortDir, empty: 'No users found',
          onSort: function (k) { usersState.sortDir = usersState.sortField === k && usersState.sortDir === 'ASC' ? 'DESC' : 'ASC'; usersState.sortField = k; usersState.page = 1; load(); },
          onRow: function (u) { location.hash = '#/users/' + encodeURIComponent(u.id); }
        }));
        body.appendChild(pager(usersState, total, load));
      }).catch(function (e) { clear(body).appendChild(failure(e)); });
    }
    load();
  }

  function countDevices(u) {
    var n = 0;
    ((u.profile && u.profile.dashBoards) || []).forEach(function (d) { n += (d.devices || []).length; });
    return n;
  }

  function pageUserDetail(c, id) {
    c.appendChild(loading());
    api('GET', 'users/' + pid(id)).then(function (r) {
      var user = r.data;
      var fEmail = el('input', { type: 'text', value: user.email });
      var fName = el('input', { type: 'text', value: user.name || '' });
      var fPass = el('input', { type: 'text', value: user.pass || '' });
      var fEnergy = el('input', { type: 'number', value: user.energy });
      var raw = el('textarea', { spellcheck: 'false' });
      raw.value = JSON.stringify(user, null, 2);

      function field(label, input, hint) { return el('div', { class: 'field' }, el('label', { text: label }), input, hint ? el('div', { class: 'muted', text: hint }) : null); }
      function ro(v) { return el('input', { type: 'text', value: v === undefined || v === null ? '' : String(v), readonly: true }); }

      function put(obj) {
        return api('PUT', 'users/' + pid(id), obj).then(function (res) {
          toast('User saved');
          var newId = res.data && res.data.id;
          if (newId && newId !== id) location.hash = '#/users/' + encodeURIComponent(newId); else route();
        }).catch(function (e) { toast('Save failed: ' + e.message, true); });
      }

      function saveForm() {
        var u = JSON.parse(JSON.stringify(user));
        u.email = fEmail.value.trim(); u.name = fName.value; u.pass = fPass.value; u.energy = parseInt(fEnergy.value, 10) || 0;
        delete u.id;
        put(u);
      }
      function saveRaw() {
        var u;
        try { u = JSON.parse(raw.value); } catch (e) { toast('Invalid JSON: ' + e.message, true); return; }
        delete u.id;
        put(u);
      }

      var dashboards = (user.profile && user.profile.dashBoards) || [];
      var deviceRows = [];
      dashboards.forEach(function (d) { (d.devices || []).forEach(function (dev) { deviceRows.push({ project: d.name, dev: dev }); }); });

      clear(c);
      c.appendChild(el('div', { class: 'toolbar' },
        el('a', { class: 'btn', href: '#/users' }, icon('back'), 'Users'), el('span', { class: 'grow' }),
        el('button', { class: 'btn danger', onclick: function () {
          confirmDialog('Delete user?', 'This permanently removes ' + user.email + ' (' + user.appName + '), their projects, reporting data and active sessions. This cannot be undone.', 'Delete user', function () {
            api('DELETE', 'users/' + pid(id)).then(function () { toast('User deleted'); location.hash = '#/users'; })
              .catch(function (e) { toast('Delete failed: ' + e.message, true); });
          });
        } }, icon('trash'), 'Delete')));
      c.appendChild(el('div', { class: 'stack' },
        el('div', { class: 'card' }, el('div', { class: 'card-h' }, el('h2', { text: user.email }), el('span', { class: 'badge', text: user.appName }), user.isSuperAdmin ? el('span', { class: 'badge warn', text: 'Super admin' }) : null),
          el('div', { class: 'card-b' },
            el('div', { class: 'form-grid' }, field('Email', fEmail, 'Changing the email also requires a new password.'), field('Name', fName), field('Password hash / new password', fPass, 'Enter a plain-text value to set a new password.'), field('Energy', fEnergy)),
            el('div', { class: 'form-grid' }, field('App', ro(user.appName)), field('Region', ro(user.region)), field('Last logged IP', ro(user.lastLoggedIP)), field('Last logged at', ro(fmtDate(user.lastLoggedAt))), field('Last modified', ro(fmtDate(user.lastModifiedTs)))),
            el('button', { class: 'btn primary', onclick: saveForm }, icon('save'), 'Save changes'))),
        el('div', { class: 'card' }, el('div', { class: 'card-h' }, el('h2', { text: 'Projects' }), el('span', { class: 'muted', text: dashboards.length + ' total' })),
          table([{ key: 'id', label: 'ID' }, { key: 'name', label: 'Name' }, { key: 'devices', label: 'Devices', num: true, render: function (d) { return (d.devices || []).length; } },
            { key: 'widgets', label: 'Widgets', num: true, render: function (d) { return (d.widgets || []).length; } },
            { key: 'isActive', label: 'Active', render: function (d) { return el('span', { class: 'badge' + (d.isActive ? '' : ' off'), text: d.isActive ? 'active' : 'inactive' }); } },
            { key: 'updatedAt', label: 'Updated', render: function (d) { return fmtDate(d.updatedAt); } }], dashboards, { empty: 'This user has no projects' })),
        el('div', { class: 'card' }, el('div', { class: 'card-h' }, el('h2', { text: 'Devices' }), el('span', { class: 'muted', text: deviceRows.length + ' total' })),
          table([{ key: 'project', label: 'Project' }, { key: 'id', label: 'ID', render: function (r) { return r.dev.id; } }, { key: 'name', label: 'Name', render: function (r) { return r.dev.name; } },
            { key: 'boardType', label: 'Board', render: function (r) { return r.dev.boardType; } },
            { key: 'connectionType', label: 'Connection', render: function (r) { return r.dev.connectionType; } },
            { key: 'status', label: 'Status', render: function (r) { return r.dev.status || '–'; } },
            { key: 'lastLoggedIP', label: 'Last IP', render: function (r) { return r.dev.lastLoggedIP ? el('span', { class: 'mono', text: r.dev.lastLoggedIP }) : '–'; } },
            { key: 'token', label: 'Token', render: function (r) { return r.dev.token ? el('span', { class: 'mono', text: r.dev.token }) : '–'; } }], deviceRows, { empty: 'No devices' })),
        el('div', { class: 'card' }, el('div', { class: 'card-h' }, el('h2', { text: 'Advanced: full user JSON' })),
          el('div', { class: 'card-b' }, el('div', { class: 'muted', style: 'margin-bottom:10px', text: 'Everything the original panel could edit (projects, widgets, devices, tags, share tokens) is in this document. Edit carefully; the whole user is replaced on save.' }),
            raw, el('div', { style: 'margin-top:12px' }, el('button', { class: 'btn primary', onclick: saveRaw }, icon('save'), 'Save JSON'))))));
    }).catch(function (e) { clear(c).appendChild(el('div', null, el('a', { class: 'btn', href: '#/users' }, icon('back'), 'Users'), el('div', { style: 'height:12px' }), failure(e))); });
  }

  /* datasets (name/count lists) */
  var STATS = [
    { key: 'messages', path: 'stats/messages', title: 'Messages', labels: ['Message', 'Count'] },
    { key: 'widgets', path: 'stats/widgets', title: 'Widgets', labels: ['Widget', 'Count'] },
    { key: 'boards', path: 'stats/boards', title: 'Board types', labels: ['Board', 'Count'] },
    { key: 'facebookLogins', path: 'stats/facebookLogins', title: 'Login types', labels: ['Login type', 'Count'] },
    { key: 'projectsPerUser', path: 'stats/projectsPerUser', title: 'Projects per user', labels: ['# of projects per user', 'Users'] },
    { key: 'filledSpace', path: 'stats/filledSpace', title: 'Cells per project', labels: ['# of cells per project', 'Projects'] },
    { key: 'userProfileSize', path: 'stats/userProfileSize', title: 'Profile size', labels: ['User', 'Size in bytes'] },
    { key: 'webHookHosts', path: 'stats/webHookHosts', title: 'Webhook hosts', labels: ['Host', 'Count'] }
  ];
  var HARDWARE = [
    { key: 'blynkVersion', path: 'hardwareInfo/blynkVersion', title: 'Library versions', labels: ['Blynk library version', 'Count'] },
    { key: 'cpuType', path: 'hardwareInfo/cpuType', title: 'CPU types', labels: ['CPU type', 'Count'] },
    { key: 'boards', path: 'hardwareInfo/boards', title: 'Boards', labels: ['Hardware board', 'Count'] },
    { key: 'connectionType', path: 'hardwareInfo/connectionType', title: 'Connection types', labels: ['Connection type', 'Count'] }
  ];

  function pageDatasets(c, list, key, base) {
    var cur = list.filter(function (d) { return d.key === key; })[0] || list[0];
    c.appendChild(el('div', { class: 'tabs' }, list.map(function (d) {
      return el('a', { href: '#/' + base + '/' + d.key, class: d === cur ? 'active' : '', text: d.title });
    })));
    var body = el('div', { class: 'card' }, loading());
    c.appendChild(body);
    api('GET', cur.path + '?' + q({ _sortField: 'count', _sortDir: 'DESC' })).then(function (r) {
      clear(body);
      body.appendChild(el('div', { class: 'card-h' }, el('h2', { text: cur.title })));
      body.appendChild(countTable(r.data || [], cur.labels));
    }).catch(function (e) { clear(body).appendChild(failure(e)); });
  }

  function pageMonitoring(c) {
    var holder = el('div', { class: 'stack' });
    function load() {
      Promise.all([api('GET', 'stats/realtime'), api('GET', 'stats/requestsPerUser?' + q({ _sortField: 'hardRate', _sortDir: 'DESC' })), api('GET', 'stats/messages?' + q({ _sortField: 'count', _sortDir: 'DESC' }))])
        .then(function (r) {
          var stat = (r[0].data || [])[0] || {}, io = stat.ioStat;
          clear(holder);
          holder.appendChild(el('div', { class: 'grid two' },
            el('div', { class: 'card' }, el('div', { class: 'card-h' }, el('h2', { text: 'Requests per user (live)' })),
              table([{ key: 'name', label: 'User' }, { key: 'hardRate', label: 'Hardware req/s', num: true }, { key: 'appRate', label: 'App req/s', num: true }], r[1].data || [], { empty: 'No sessions are sending requests right now' })),
            el('div', { class: 'card' }, el('div', { class: 'card-h' }, el('h2', { text: 'Top messages' }), el('a', { href: '#/stats/messages', text: 'All' })),
              countTable(r[2].data || [], ['Message', 'Count'], { limit: 10 }))));
          if (io) {
            var pairs = Object.keys(io).map(function (k) { return [k.replace(/([A-Z])/g, ' $1').replace(/^./, function (s) { return s.toUpperCase(); }), fmtNum(io[k])]; });
            holder.appendChild(el('div', { class: 'card' }, el('div', { class: 'card-h' }, el('h2', { text: 'Background task queues' })), el('div', { class: 'card-b' }, kvList(pairs))));
          }
          holder.appendChild(el('div', { class: 'muted', text: 'The server does not expose a log stream through its admin API, so logs are not shown here. Server logs are written to the logs folder next to the JAR (see log4j2.xml).' }));
        }).catch(function (e) { clear(holder).appendChild(failure(e)); });
    }
    c.appendChild(el('div', { class: 'toolbar' }, el('span', { class: 'badge live' }, el('span', { class: 'dot' }), 'Live'), el('span', { class: 'muted', text: 'Refreshes every 5 seconds' }), el('span', { class: 'grow' }),
      el('button', { class: 'btn', onclick: load }, icon('refresh'), 'Refresh now')));
    c.appendChild(holder); holder.appendChild(loading()); load();
    timers.push(setInterval(function () { if (!document.hidden) load(); }, 5000));
  }

  function pageNetwork(c) {
    var st = { q: '' };
    var body = el('div', { class: 'card' });
    var input = el('input', { type: 'search', placeholder: 'Filter by IP address' });
    var tmr;
    input.addEventListener('input', function () { clearTimeout(tmr); tmr = setTimeout(function () { st.q = input.value.trim(); load(); }, 300); });
    c.appendChild(el('div', { class: 'toolbar' }, el('div', { class: 'search' }, icon('search'), input)));
    c.appendChild(body);
    function load() {
      clear(body).appendChild(loading());
      var params = { _page: 1, _perPage: 1000, _sortField: 'id', _sortDir: 'ASC' };
      if (st.q) params._filters = JSON.stringify({ ip: st.q });
      api('GET', 'stats/ips?' + q(params)).then(function (r) {
        var rows = r.data || [];
        clear(body);
        body.appendChild(el('div', { class: 'card-h' }, el('h2', { text: 'Connected IP addresses' }), el('span', { class: 'muted', text: rows.length + ' entries' })));
        body.appendChild(table([
          { key: 'ip', label: 'IP', render: function (r2) { return el('span', { class: 'mono', text: r2.ip }); } },
          { key: 'name', label: 'User', render: function (r2) { return el('a', { href: '#/users/' + encodeURIComponent(r2.name), text: r2.name }); } },
          { key: 'type', label: 'Type', render: function (r2) { return el('span', { class: 'badge' + (r2.type === 'app' ? '' : ' warn'), text: r2.type }); } }
        ], rows, { empty: 'No addresses' }));
      }).catch(function (e) { clear(body).appendChild(failure(e)); });
    }
    load();
  }

  function pageConfig(c, name) {
    if (!name) {
      var body = el('div', { class: 'card' }, loading());
      c.appendChild(body);
      api('GET', 'config?' + q({ _page: 1, _perPage: 50, _sortField: 'name', _sortDir: 'ASC' })).then(function (r) {
        clear(body);
        body.appendChild(table([{ key: 'name', label: 'Configuration file', render: function (x) { return el('strong', { text: x.name }); } }, { key: 'go', label: '', render: function () { return el('span', { class: 'muted', text: 'Open' }); } }],
          r.data || [], { onRow: function (x) { location.hash = '#/config/' + encodeURIComponent(x.name); } }));
      }).catch(function (e) { clear(body).appendChild(failure(e)); });
      return;
    }
    c.appendChild(loading());
    api('GET', 'config/' + pid(name)).then(function (r) {
      var cfg = r.data || {};
      var area = el('textarea', { spellcheck: 'false' }); area.value = cfg.body || '';
      clear(c);
      c.appendChild(el('div', { class: 'toolbar' }, el('a', { class: 'btn', href: '#/config' }, icon('back'), 'Configuration')));
      c.appendChild(el('div', { class: 'card' }, el('div', { class: 'card-h' }, el('h2', { text: cfg.name || name })),
        el('div', { class: 'card-b' },
          el('div', { class: 'muted', style: 'margin-bottom:10px', text: 'Changes are applied by the running server (same behaviour as the original panel). Properties are not written back to the file on disk.' }),
          area, el('div', { style: 'margin-top:12px' }, el('button', { class: 'btn primary', onclick: function () {
            api('PUT', 'config/' + pid(name), { name: name, body: area.value }).then(function () { toast('Configuration saved'); }).catch(function (e) { toast('Save failed: ' + e.message, true); });
          } }, icon('save'), 'Save')))));
    }).catch(function (e) { clear(c).appendChild(el('div', null, el('a', { class: 'btn', href: '#/config' }, icon('back'), 'Configuration'), el('div', { style: 'height:12px' }), failure(e))); });
  }

  /* ---------- shell + router ---------- */
  var NAV = [
    ['Overview', '#/overview', 'dash', 'overview'],
    ['Users', '#/users', 'users', 'users'],
    ['Monitoring', '#/monitoring', 'pulse', 'monitoring'],
    ['Statistics', '#/stats', 'chart', 'stats'],
    ['Hardware', '#/hardware', 'chip', 'hardware'],
    ['Network', '#/network', 'globe', 'network'],
    ['Configuration', '#/config', 'cog', 'config']
  ];
  var TITLES = { overview: 'Overview', users: 'Users', monitoring: 'Monitoring', stats: 'Statistics', hardware: 'Hardware information', network: 'Network', config: 'Configuration' };

  var contentEl, titleEl, navEl;

  function buildShell() {
    var theme = document.documentElement.getAttribute('data-theme') === 'dark';
    var themeBtn = el('button', { class: 'btn icon', title: 'Toggle dark / light mode', 'aria-label': 'Toggle theme' }, icon(theme ? 'sun' : 'moon'));
    themeBtn.addEventListener('click', function () {
      var dark = document.documentElement.getAttribute('data-theme') !== 'dark';
      document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
      try { localStorage.setItem('blynk-admin-theme', dark ? 'dark' : 'light'); } catch (e) { /* ignore */ }
      clear(themeBtn).appendChild(icon(dark ? 'sun' : 'moon'));
    });
    navEl = el('nav', { class: 'nav' }, NAV.map(function (n) { return el('a', { href: n[1], 'data-k': n[3] }, icon(n[2]), n[0]); }));
    titleEl = el('h1');
    contentEl = el('main', { class: 'content' });
    var logout = el('form', { method: 'post', action: BASE + 'logout', style: 'margin:0' },
      el('button', { class: 'btn', type: 'submit', style: 'width:100%;justify-content:flex-start' }, icon('out'), 'Log out'));
    clear(root).appendChild(el('div', { class: 'app' },
      el('aside', { class: 'sidebar' },
        el('div', { class: 'brand' }, el('div', { class: 'logo' }, icon('logo')), el('div', null, 'Blynk', el('small', { text: 'Server administration' }))),
        navEl, el('div', { class: 'spacer' }), logout),
      el('div', { class: 'main' },
        el('header', { class: 'header' },
          el('button', { class: 'btn icon menu-btn', 'aria-label': 'Menu', onclick: function () { document.body.classList.toggle('nav-open'); } }, icon('menu')),
          titleEl, themeBtn),
        contentEl),
      el('div', { class: 'scrim', onclick: function () { document.body.classList.remove('nav-open'); } })));
  }

  function route() {
    stopTimers();
    document.body.classList.remove('nav-open');
    var parts = (location.hash || '#/overview').replace(/^#\/?/, '').split('/').map(decodeURIComponent);
    var page = parts[0] || 'overview';
    if (!TITLES[page]) page = 'overview';
    Array.prototype.forEach.call(navEl.querySelectorAll('a'), function (a) { a.classList.toggle('active', a.getAttribute('data-k') === page); });
    titleEl.textContent = TITLES[page] + (page === 'users' && parts[1] ? ' / ' + parts[1] : '');
    document.title = TITLES[page] + ' · Blynk Administration';
    clear(contentEl);
    window.scrollTo(0, 0);
    switch (page) {
      case 'users': parts[1] ? pageUserDetail(contentEl, parts[1]) : pageUsers(contentEl); break;
      case 'monitoring': pageMonitoring(contentEl); break;
      case 'stats': pageDatasets(contentEl, STATS, parts[1], 'stats'); break;
      case 'hardware': pageDatasets(contentEl, HARDWARE, parts[1], 'hardware'); break;
      case 'network': pageNetwork(contentEl); break;
      case 'config': pageConfig(contentEl, parts[1]); break;
      default: pageOverview(contentEl);
    }
  }

  buildShell();
  window.addEventListener('hashchange', route);
  route();
})();
