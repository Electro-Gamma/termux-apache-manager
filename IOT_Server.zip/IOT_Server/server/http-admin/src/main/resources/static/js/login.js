/* Login: hashes the password in the browser exactly as the original page did (SHA-256 of password + sha256(lower-case email), base64). */
function isFormValid() {
    var valid = true;
    var inputs = document.querySelectorAll('.form-control');
    for (var i = 0; i < inputs.length; i++) {
        inputs[i].classList.remove('has-error');
        if (!inputs[i].value) {
            inputs[i].classList.add('has-error');
            valid = false;
        }
    }
    return valid;
}

if (window.history && window.history.replaceState) {
    window.history.replaceState({}, "Blynk", location.pathname);
}

document.querySelector('.form-signin').addEventListener('submit', function (e) {
    if (!isFormValid()) {
        e.preventDefault();
        return false;
    }
    var email = document.getElementById('inputEmail').value;
    var password = document.getElementById('inputPassword').value;
    var hasher = CryptoJS.algo.SHA256.create();
    hasher.update(password, "utf-8");
    hasher.update(CryptoJS.SHA256(email.toLowerCase()), "utf-8");
    var hash = hasher.finalize();
    document.getElementById('finalPass').value = hash.toString(CryptoJS.enc.Base64);
});
