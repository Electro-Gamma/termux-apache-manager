package cc.blynk.server.admin.http.response;

import java.lang.management.ManagementFactory;
import java.lang.management.MemoryUsage;
import java.lang.management.RuntimeMXBean;

/**
 * Read-only snapshot of the JVM / host the server is running on.
 * Every value is taken from the JVM management beans, nothing is simulated.
 */
public class SystemInfoResponse {

    public final long startTime;
    public final long uptimeMillis;
    public final long serverTime;
    public final String javaVersion;
    public final String javaVendor;
    public final String vmName;
    public final String osName;
    public final String osVersion;
    public final String osArch;
    public final int availableProcessors;
    public final double systemLoadAverage;
    public final long heapUsedBytes;
    public final long heapCommittedBytes;
    public final long heapMaxBytes;
    public final int liveThreads;
    public final String timeZone;

    public SystemInfoResponse() {
        RuntimeMXBean runtime = ManagementFactory.getRuntimeMXBean();
        MemoryUsage heap = ManagementFactory.getMemoryMXBean().getHeapMemoryUsage();
        this.startTime = runtime.getStartTime();
        this.uptimeMillis = runtime.getUptime();
        this.serverTime = System.currentTimeMillis();
        this.javaVersion = System.getProperty("java.version");
        this.javaVendor = System.getProperty("java.vendor");
        this.vmName = runtime.getVmName();
        this.osName = System.getProperty("os.name");
        this.osVersion = System.getProperty("os.version");
        this.osArch = System.getProperty("os.arch");
        this.availableProcessors = Runtime.getRuntime().availableProcessors();
        this.systemLoadAverage = ManagementFactory.getOperatingSystemMXBean().getSystemLoadAverage();
        this.heapUsedBytes = heap.getUsed();
        this.heapCommittedBytes = heap.getCommitted();
        this.heapMaxBytes = heap.getMax();
        this.liveThreads = ManagementFactory.getThreadMXBean().getThreadCount();
        this.timeZone = java.util.TimeZone.getDefault().getID();
    }
}
