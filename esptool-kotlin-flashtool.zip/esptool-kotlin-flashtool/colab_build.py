# ============================================================
# Build the Kotlin esptool flash tool (Google Colab)
#
# Paste this into a Colab code cell and run it. It will:
#   1. Ask you to upload esptool-kotlin-flashtool.zip (the file from chat)
#   2. Install a JDK and the Kotlin compiler
#   3. Compile EsptoolFlashTool.kt into a single runnable jar
#   4. Run --selftest (SLIP framing / checksum / byte packing / JSON
#      parsing / deflate-inflate roundtrip / flash-write param packing --
#      NOT a substitute for testing against real hardware)
#   5. Package the jar + the stub data it needs, and download it back to you
#
# If step 3 (compiling) fails, copy the FULL error output back to the chat
# -- the write-flash/verify-flash code was written without a Kotlin
# compiler available, so this build is the first real check it compiles.
# ============================================================
import os
import subprocess

def run(cmd):
    print(f"$ {cmd}")
    result = subprocess.run(cmd, shell=True)
    if result.returncode != 0:
        raise RuntimeError(f"Command failed ({result.returncode}): {cmd}")

# 1) Upload esptool-kotlin-flashtool.zip
from google.colab import files
print("Select esptool-kotlin-flashtool.zip to upload...")
uploaded = files.upload()
zip_name = next(iter(uploaded))

# 2) Unpack it
run(f"rm -rf esptool-kotlin && mkdir esptool-kotlin && unzip -q -o '{zip_name}' -d esptool-kotlin")
os.chdir("esptool-kotlin")

# 3) Make sure a JDK, unzip, and curl are available
run("apt-get -qq update && apt-get -qq install -y openjdk-17-jdk-headless unzip curl > /dev/null")
run("java -version")

# 4) Install the Kotlin compiler if it isn't already on PATH
have_kotlinc = subprocess.run(
    "command -v kotlinc", shell=True,
    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
).returncode == 0
if not have_kotlinc and not os.path.exists("/opt/kotlinc/bin/kotlinc"):
    run(
        "KOTLIN_VERSION=$(curl -fsSL https://api.github.com/repos/JetBrains/kotlin/releases/latest "
        "| grep -Po '\"tag_name\": \"v\\K[^\"]*' || echo 2.4.0); "
        "echo \"Installing Kotlin $KOTLIN_VERSION\"; "
        "curl -fsSL \"https://github.com/JetBrains/kotlin/releases/download/v${KOTLIN_VERSION}"
        "/kotlin-compiler-${KOTLIN_VERSION}.zip\" -o /tmp/kotlinc.zip && "
        "unzip -q -o /tmp/kotlinc.zip -d /opt"
    )
os.environ["PATH"] = "/opt/kotlinc/bin:" + os.environ["PATH"]
run("kotlinc -version")

# 5) Compile the single Kotlin file into a runnable, self-contained jar
run("kotlinc EsptoolFlashTool.kt -include-runtime -d esptool_flashtool.jar")

# 6) Run the self-test -- checks SLIP framing, the checksum algorithm, byte
#    packing (including the flash-write parameter layout), zlib deflate/
#    inflate round-tripping, and JSON parsing against the real bundled stub
#    files. This is NOT a real-hardware test; it only proves these
#    building blocks work.
run("java -jar esptool_flashtool.jar --selftest")

print()
print("Build succeeded: esptool-kotlin/esptool_flashtool.jar")
print("Usage:")
print("  java -jar esptool_flashtool.jar --port socket://HOST:PORT [--chip auto] read-flash ADDRESS SIZE OUTPUT")
print("  java -jar esptool_flashtool.jar --port socket://HOST:PORT [--chip auto] write-flash ADDRESS FILE [ADDRESS FILE ...]")
print("  java -jar esptool_flashtool.jar --port socket://HOST:PORT [--chip auto] verify-flash [--diff] ADDRESS FILE [ADDRESS FILE ...]")

# 7) Package the jar + the stub data it needs alongside it, and download
run("zip -q -r ../esptool_flashtool_build.zip esptool_flashtool.jar targets")
os.chdir("..")
files.download("esptool_flashtool_build.zip")
