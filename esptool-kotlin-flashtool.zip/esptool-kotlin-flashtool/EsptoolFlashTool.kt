// EsptoolFlashTool.kt
//
// A from-scratch Kotlin/JVM port of esptool's `read-flash`, `write-flash`,
// and `verify-flash` commands with stub-loader support, talking to the chip
// over a TCP socket (the socket://host:port transport, i.e. the
// Termux-TCP-bridge scenario this whole tool has been built around).
//
// This is a REWRITE, not a mechanical repackaging like the earlier Python
// single-file bundle. Every protocol detail below (opcodes, packet layout,
// timeouts, the stub-upload sequence, and the flash read/write/verify wire
// protocols) was read directly out of the original esptool-5.3.1 Python
// source (esptool/loader.py, esptool/cmds.py, esptool/targets/*.py) while
// writing this file, not recalled from memory -- each piece below is
// commented with roughly where it came from.
//
// IMPORTANT -- this has NOT been compiled or run. `read-flash` was
// previously written, compiled, and self-tested by hand; `write-flash` and
// `verify-flash` were added afterwards in an environment with no JDK/Kotlin
// compiler and no hardware available, so they've only been checked by
// careful reading against the Python source and the (extended) --selftest
// below -- neither of which proves the code even compiles. Please run
// --selftest yourself after building, read any compiler errors back if the
// build fails, and test cautiously against a real board (ideally with
// read-flash and --diff verify-flash on a throwaway region first) before
// trusting write-flash with anything you can't afford to lose. Writing to
// flash is destructive, unlike read-flash: a protocol mistake here can
// corrupt or brick a device, not just fail to read.
//
// ---------------------------------------------------------------------
// SCOPE / WHAT'S DELIBERATELY NOT HERE (vs. the Python original):
//  - Only socket:// transport (no real serial/COM ports) -- matches the
//    Termux-TCP use case, and Python's own esptool ALSO disables chip
//    reset (DTR/RTS toggling) for socket:// ports, since that's not
//    possible over a plain TCP socket (loader.py connect(): "if
//    self._port.name.startswith('socket:'): mode = 'no-reset'"). So you
//    need to put the chip in bootloader/download mode yourself before
//    running this, exactly as with the Python version over socket://.
//  - No custom SPI pin configuration (--spi-connection). Fine for
//    standard boards: when the stub loader is running, its own startup
//    code attaches SPI flash with default pins already (see
//    esptool/cmds.py attach_flash(): the "elif not esp.IS_STUB:" branch
//    that calls flash_spi_attach() is skipped entirely once the stub is
//    up, which is always the case here).
//  - No flash-size auto-detect/bounds-check convenience (Python's
//    check_flash_size() / _set_flash_parameters() / detect_flash_size(),
//    which reads the SPI flash JEDEC ID by bit-banging chip-specific SPI
//    peripheral registers). write-flash/verify-flash here don't tell the
//    device the real flash size (SPI_SET_PARAMS is never sent) and don't
//    check your address+size fits -- you're responsible for that, same
//    as giving an explicit address+size to read-flash.
//  - No --flash-mode/--flash-freq/--flash-size header patching (Python's
//    _update_image_flash_params(), which also re-verifies and re-signs
//    the image's SHA256 if present). Only "keep" (the default) is
//    supported -- files are written/verified byte-for-byte as given.
//  - No flash encryption (--encrypt/--encrypt-files), no NAND flash
//    (--flash-type nand), no --erase-all, no --diff-with/--skip-flashed
//    fast partial reflashing, and none of the pre-flight safety checks
//    Python runs before writing (secure-boot-v1 bootloader-region guard,
//    flash-encryption-key-manager guard, image chip_id/chip-revision
//    validation against the connected device). Double-check by hand that
//    what you're writing actually matches the connected chip.
//  - No lost-connection retry/reconnect loop during a write (Python
//    retries the current block, or reconnects and restarts the whole
//    write, on a dropped connection). If the socket drops mid-write here,
//    this just fails -- rerun it.
//  - write-flash compresses with zlib level 9 by default (matching
//    Python's default whenever the stub is used, which here is always),
//    falling back to uncompressed if compression doesn't shrink the data.
//    Progress percentage during a compressed write is based on compressed
//    bytes sent, not decompressed bytes written -- a cosmetic difference
//    from Python's progress bar, not a protocol one.
//  - ESP32-E22 and ESP32-H21 are left out of chip detection: the
//    original project ships no stub_flasher JSON for either of them
//    either (checked: targets/stub_flasher/{1,2}/ has no esp32e22.json
//    or esp32h21.json), so stub-based read-flash can't work for them in
//    the Python version either.
//  - ESP32-P4's chip-revision-dependent stub selection (it has both
//    esp32p4.json and esp32p4-rev1.json upstream, picked by
//    self.get_chip_revision() -- see esp32p4.py stub_json_name()) is
//    simplified to always use esp32p4.json (the newer-silicon default).
//  - The ESP32-S3-with-secure-boot-enabled stub injection workaround
//    (loader.py run_stub(), the "secure_boot_workflow" branch that
//    pokes a ROM function pointer instead of a normal jump) isn't
//    implemented. Affects only ESP32-S3 boards with secure boot burned
//    in.
// ---------------------------------------------------------------------

import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.net.Socket
import java.net.SocketTimeoutException
import java.net.URI
import java.security.MessageDigest
import java.util.Base64
import java.util.zip.Deflater
import java.util.zip.Inflater
import kotlin.system.exitProcess

// ============================================================================
// Little-endian packing helpers
// (Python uses struct.pack("<...", ...) throughout loader.py; the JVM has
// no built-in little-endian primitive packing, so these are hand-rolled)
// ============================================================================

private fun le16(v: Int): ByteArray =
    byteArrayOf((v and 0xFF).toByte(), ((v ushr 8) and 0xFF).toByte())

private fun le32(v: Long): ByteArray = byteArrayOf(
    (v and 0xFF).toByte(),
    ((v ushr 8) and 0xFF).toByte(),
    ((v ushr 16) and 0xFF).toByte(),
    ((v ushr 24) and 0xFF).toByte(),
)

private fun le32(v: Int): ByteArray = le32(v.toLong() and 0xFFFFFFFFL)

private fun readLe16(b: ByteArray, off: Int): Int =
    (b[off].toInt() and 0xFF) or ((b[off + 1].toInt() and 0xFF) shl 8)

private fun readLe32(b: ByteArray, off: Int): Long =
    (b[off].toLong() and 0xFF) or
        ((b[off + 1].toLong() and 0xFF) shl 8) or
        ((b[off + 2].toLong() and 0xFF) shl 16) or
        ((b[off + 3].toLong() and 0xFF) shl 24)

private fun ByteArray.toHex(): String = joinToString("") { "%02x".format(it.toInt() and 0xFF) }

// ============================================================================
// Errors
// ============================================================================

class FatalError(message: String) : Exception(message)

// ============================================================================
// SLIP framing
// (Python: ESPLoader.write() around loader.py:542, and the slip_reader()
// generator around loader.py:2174 -- standard RFC 1055 SLIP: frames are
// delimited by 0xC0, and any literal 0xC0/0xDB byte inside the payload is
// escaped as 0xDB 0xDC / 0xDB 0xDD respectively)
// ============================================================================

private object Slip {
    const val END = 0xC0
    const val ESC = 0xDB
    const val ESC_END = 0xDC
    const val ESC_ESC = 0xDD

    fun encode(payload: ByteArray): ByteArray {
        val out = ByteArrayOutputStream(payload.size + 8)
        out.write(END)
        for (b in payload) {
            when (val u = b.toInt() and 0xFF) {
                END -> { out.write(ESC); out.write(ESC_END) }
                ESC -> { out.write(ESC); out.write(ESC_ESC) }
                else -> out.write(u)
            }
        }
        out.write(END)
        return out.toByteArray()
    }
}

/**
 * Reads one fully unescaped SLIP frame at a time from a blocking
 * [java.io.InputStream]. Relies on the underlying socket's SO_TIMEOUT for
 * the actual timeout (a blocking read() throws [SocketTimeoutException]
 * once it's exceeded), mirroring how the Python version relies on
 * pyserial's port.timeout.
 */
private class SlipReader(private val input: java.io.InputStream) {
    fun readPacket(): ByteArray {
        val out = ByteArrayOutputStream()
        var started = false
        var inEscape = false
        while (true) {
            val b = input.read()
            if (b == -1) throw FatalError("Connection closed while reading.")
            val u = b and 0xFF
            if (!started) {
                if (u == Slip.END) started = true
                continue
            }
            if (u == Slip.END) {
                if (out.size() == 0) continue // tolerate repeated/leading delimiters
                return out.toByteArray()
            }
            if (inEscape) {
                inEscape = false
                when (u) {
                    Slip.ESC_END -> out.write(Slip.END)
                    Slip.ESC_ESC -> out.write(Slip.ESC)
                    else -> out.write(u) // be lenient, same spirit as the original
                }
            } else if (u == Slip.ESC) {
                inEscape = true
            } else {
                out.write(u)
            }
        }
    }
}

// ============================================================================
// Command opcodes
// (Python: ESPLoader.ESP_CMDS dict, loader.py:310-349 -- only the subset
// this build actually uses)
// ============================================================================

private object Cmd {
    const val FLASH_BEGIN = 0x02
    const val FLASH_DATA = 0x03
    const val FLASH_END = 0x04
    const val MEM_BEGIN = 0x05
    const val MEM_END = 0x06
    const val MEM_DATA = 0x07
    const val SYNC = 0x08
    const val READ_REG = 0x0A
    const val FLASH_DEFL_BEGIN = 0x10
    const val FLASH_DEFL_DATA = 0x11
    const val FLASH_DEFL_END = 0x12
    const val SPI_FLASH_MD5 = 0x13
    const val GET_SECURITY_INFO = 0x14
    const val READ_FLASH = 0xD2 // stub-only
}

private const val CHIP_DETECT_MAGIC_REG_ADDR = 0x40001000L // loader.py:381
private const val FLASH_SECTOR_SIZE = 0x1000L // loader.py:367
private const val FLASH_WRITE_SIZE = 0x400 // loader.py:2172 FLASH_WRITE_SIZE
private const val ESP_RAM_BLOCK = 0x1800 // loader.py:358
private const val ESP_CHECKSUM_MAGIC = 0xEF // loader.py:365

/** loader.py:1201 timeout_per_mb(): scale a per-MB timeout, floored at 3s
 * (Python's DEFAULT_TIMEOUT). Used for flash_md5sum, whose device-side
 * compute time scales with region size. */
private fun timeoutPerMbMs(secondsPerMb: Double, sizeBytes: Long): Int {
    val seconds = secondsPerMb * (sizeBytes / 1_000_000.0)
    return (maxOf(3.0, seconds) * 1000).toInt()
}

// ============================================================================
// The connection: SLIP + command/response framing over a TCP socket
// (Python: ESPLoader.command()/checksum()/sync()/mem_begin()/mem_block()/
// mem_finish()/run_stub()/read_flash(), loader.py:542-1650 roughly)
// ============================================================================

class EspConnection(host: String, port: Int, connectTimeoutMs: Int = 5000) {
    private val socket = Socket().apply {
        connect(java.net.InetSocketAddress(host, port), connectTimeoutMs)
        tcpNoDelay = true
    }
    private val output = socket.getOutputStream()
    private val input = socket.getInputStream()
    private var slip = SlipReader(input)

    /** Discards whatever's currently sitting in the socket's read buffer
     * (Python: self._port.reset_input_buffer(), used before each connect
     * attempt to isolate the chip's own boot-log noise from a real reply). */
    fun drainInput() {
        val avail = input.available()
        if (avail > 0) input.skip(avail.toLong())
    }

    private fun writePacket(payload: ByteArray) {
        output.write(Slip.encode(payload))
        output.flush()
    }

    /** Raw SLIP write with no command envelope -- used for the read-flash
     * ACK, which is just a bare 4-byte little-endian count (loader.py
     * read_flash(): `self.write(struct.pack("<I", data_len))`). */
    fun writeRaw(payload: ByteArray) = writePacket(payload)

    private fun readPacket(timeoutMs: Int): ByteArray {
        socket.soTimeout = timeoutMs
        return try {
            slip.readPacket()
        } catch (e: SocketTimeoutException) {
            throw FatalError("Timed out waiting for a response.")
        }
    }

    /** Also exposed directly for the read-flash streaming loop, which reads
     * raw data frames rather than command-response frames. */
    fun readRaw(timeoutMs: Int): ByteArray = readPacket(timeoutMs)

    private fun checksum(data: ByteArray): Int {
        var state = ESP_CHECKSUM_MAGIC
        for (b in data) state = state xor (b.toInt() and 0xFF)
        return state
    }

    /**
     * Send a command and wait for its response. Mirrors ESPLoader.command()
     * (loader.py:571): 8-byte header (direction=0x00, op, len(data) u16,
     * checksum u32) + payload, response header is (direction=0x01, op,
     * len u16, value u32) + response payload. When [op] is null, nothing
     * is written and this just waits for and returns the next valid frame
     * (used to drain the extra SYNC acks some ROMs send).
     *
     * Returns (value, responseData).
     */
    fun command(
        op: Int?,
        data: ByteArray = ByteArray(0),
        chk: Int = 0,
        waitResponse: Boolean = true,
        timeoutMs: Int = 3000,
    ): Pair<Long, ByteArray> {
        if (op != null) {
            val header = byteArrayOf(0x00, op.toByte()) + le16(data.size) + le32(chk.toLong())
            writePacket(header + data)
        }
        if (!waitResponse) return Pair(0L, ByteArray(0))

        repeat(100) {
            val p = try {
                readPacket(timeoutMs)
            } catch (e: IOException) {
                throw FatalError("I/O error waiting for response: ${e.message}")
            }
            if (p.size < 8) return@repeat
            val resp = p[0].toInt() and 0xFF
            val opRet = p[1].toInt() and 0xFF
            val value = readLe32(p, 4)
            val respData = p.copyOfRange(8, p.size)
            if (resp != 1) return@repeat
            if (op == null || opRet == op) return Pair(value, respData)
            // Unsupported-command / mismatched-op replies are just retried
            // here rather than specially detected, unlike the Python
            // version's UnsupportedCommandError path -- callers that care
            // (chip detection) catch the eventual FatalError instead.
        }
        throw FatalError("Response doesn't match request.")
    }

    /** For commands where only success/failure + the header's numeric
     * "value" field matters (MEM_BEGIN/MEM_DATA/MEM_END/READ_REG/READ_FLASH
     * trigger). Mirrors ESPLoader.check_command() (loader.py:596) for the
     * resp_data_len == 0 case. */
    fun checkCommand(
        opDescription: String,
        op: Int,
        data: ByteArray = ByteArray(0),
        chk: Int = 0,
        timeoutMs: Int = 3000,
    ): Long {
        val (value, respData) = command(op, data, chk, timeoutMs = timeoutMs)
        if (respData.size < 2) {
            throw FatalError("Failed to $opDescription. Only got ${respData.size} byte status response.")
        }
        if (respData[0].toInt() != 0) {
            throw FatalError("Failed to $opDescription (status byte ${respData[1]}).")
        }
        return value
    }

    /** For commands that return actual payload data followed by status
     * bytes (e.g. GET_SECURITY_INFO). Mirrors check_command() for the
     * resp_data_len > 0 case. */
    fun checkCommandData(
        opDescription: String,
        op: Int,
        data: ByteArray = ByteArray(0),
        respDataLen: Int,
        timeoutMs: Int = 3000,
    ): ByteArray {
        val (_, respData) = command(op, data, timeoutMs = timeoutMs)
        if (respData.size < respDataLen + 2) {
            throw FatalError("Failed to $opDescription. Only got ${respData.size} byte status response.")
        }
        val statusBytes = respData.copyOfRange(respDataLen, respDataLen + 2)
        if (statusBytes[0].toInt() != 0) {
            throw FatalError("Failed to $opDescription (status byte ${statusBytes[1]}).")
        }
        return respData.copyOfRange(0, respDataLen)
    }

    /** loader.py:707 sync(): send the fixed SYNC pattern, then drain up to
     * 7 extra ack frames some ROMs send. */
    fun sync(timeoutMs: Int = 300) {
        val syncPayload = byteArrayOf(0x07, 0x07, 0x12, 0x20) + ByteArray(32) { 0x55.toByte() }
        command(Cmd.SYNC, syncPayload, timeoutMs = timeoutMs)
        repeat(7) {
            try {
                command(null, timeoutMs = timeoutMs)
            } catch (e: FatalError) {
                // fine if fewer than 7 extra acks show up
            }
        }
    }

    /** loader.py:1018 read_reg(). */
    fun readReg(addr: Long, timeoutMs: Int = 3000): Long =
        checkCommand("read target memory", Cmd.READ_REG, le32(addr), timeoutMs = timeoutMs)

    // ---- stub upload: mem_begin / mem_block / mem_finish (loader.py:1053-1103) ----

    private fun memBegin(size: Int, blocks: Int, blockSize: Int, offset: Long) {
        val data = le32(size) + le32(blocks) + le32(blockSize) + le32(offset)
        checkCommand("enter RAM download mode", Cmd.MEM_BEGIN, data)
    }

    private fun memBlock(data: ByteArray, seq: Int) {
        val header = le32(data.size) + le32(seq) + le32(0) + le32(0)
        checkCommand("write to target RAM", Cmd.MEM_DATA, header + data, checksum(data))
    }

    private fun memFinish(entrypoint: Long) {
        val data = le32(if (entrypoint == 0L) 1 else 0) + le32(entrypoint)
        try {
            checkCommand("leave RAM download mode", Cmd.MEM_END, data, timeoutMs = 500)
        } catch (e: FatalError) {
            // The ROM often resets/changes baud before acking this one
            // cleanly -- same leniency as the Python version's ROM-mode
            // MEM_END_ROM_TIMEOUT handling (loader.py:1122).
        }
    }

    private fun uploadSegment(data: ByteArray, offset: Long) {
        val blocks = (data.size + ESP_RAM_BLOCK - 1) / ESP_RAM_BLOCK
        memBegin(data.size, blocks, ESP_RAM_BLOCK, offset)
        for (seq in 0 until blocks) {
            val from = seq * ESP_RAM_BLOCK
            val to = minOf(from + ESP_RAM_BLOCK, data.size)
            memBlock(data.copyOfRange(from, to), seq)
        }
    }

    /** loader.py:1387 run_stub(): upload .text (+ .data if present), jump
     * to the entry point, and expect the stub's "OHAI" greeting back. */
    fun runStub(stub: StubData) {
        uploadSegment(stub.text, stub.textStart)
        if (stub.data != null && stub.dataStart != null) {
            uploadSegment(stub.data, stub.dataStart)
        }
        memFinish(stub.entry)
        val greeting = readPacket(3000)
        if (greeting.size != 4 || String(greeting, Charsets.US_ASCII) != "OHAI") {
            throw FatalError(
                "Failed to start stub flasher. Unexpected response: " +
                    String(greeting, Charsets.ISO_8859_1)
            )
        }
    }

    /** loader.py:1612 read_flash(), stub-based path. Issues READ_FLASH,
     * then reads raw (non-command-framed) SLIP data frames until [length]
     * bytes have arrived, ACKing the running total after each one, and
     * finally checks a trailing 16-byte MD5 digest frame. */
    fun readFlashStub(offset: Long, length: Long, onProgress: ((Long, Long) -> Unit)? = null): ByteArray {
        checkCommand(
            "read flash",
            Cmd.READ_FLASH,
            le32(offset) + le32(length) + le32(FLASH_SECTOR_SIZE) + le32(64),
        )
        val out = ByteArrayOutputStream()
        var total = 0L
        while (total < length) {
            val p = readRaw(5000)
            out.write(p)
            total += p.size
            if (total < length && p.size.toLong() < FLASH_SECTOR_SIZE) {
                throw FatalError(
                    "Corrupt data, expected ${FLASH_SECTOR_SIZE} bytes but received ${p.size} bytes."
                )
            }
            writeRaw(le32(total))
            onProgress?.invoke(total, length)
        }
        if (total > length) throw FatalError("Read more than expected.")

        val digestFrame = readRaw(5000)
        if (digestFrame.size != 16) {
            throw FatalError("Expected a 16-byte MD5 digest, got ${digestFrame.size} bytes.")
        }
        val actual = MessageDigest.getInstance("MD5").digest(out.toByteArray())
        if (!actual.contentEquals(digestFrame)) {
            throw FatalError(
                "Digest mismatch: expected ${digestFrame.toHex()}, got ${actual.toHex()}."
            )
        }
        return out.toByteArray()
    }

    // ---- flash write: flash_begin / flash_block / flash_finish
    // (loader.py:2168-2258), plus the FLASH_DEFL_* compressed variants
    // (loader.py:2518-2596). Always includes the trailing encrypted_write
    // field in *_begin's params since this build always runs the stub
    // (matches "if self.IS_STUB or self.CHIP_NAME not in (...)" always
    // being true here), and always uses erase_size = size directly rather
    // than the erase-block-rounded ROM variant, matching the stub-mode
    // behavior of the base ESPLoader.get_erase_size() (loader.py:3708:
    // "return size", not overridden for the stub) -- the stub erases as
    // it writes, so no pre-erase block rounding is needed. ----

    /** loader.py:2168 flash_begin(). */
    fun flashBegin(size: Long, offset: Long, encryptedWrite: Boolean = false) {
        val numBlocks = (size + FLASH_WRITE_SIZE - 1) / FLASH_WRITE_SIZE
        val params = le32(size) + le32(numBlocks) + le32(FLASH_WRITE_SIZE) + le32(offset) +
            le32(if (encryptedWrite) 1 else 0)
        checkCommand("enter flash download mode", Cmd.FLASH_BEGIN, params)
    }

    /** loader.py:2203 flash_block(). No retry-on-failure here (Python
     * retries WRITE_BLOCK_ATTEMPTS times) -- see file header scope notes. */
    fun flashBlock(data: ByteArray, seq: Int, timeoutMs: Int = 3000) {
        val header = le32(data.size) + le32(seq) + le32(0) + le32(0)
        checkCommand(
            "write to target flash after seq $seq", Cmd.FLASH_DATA,
            header + data, checksum(data), timeoutMs = timeoutMs,
        )
    }

    /** loader.py:2226 flash_finish(). */
    fun flashFinish(reboot: Boolean = false, timeoutMs: Int = 3000) {
        val pkt = le32(if (!reboot) 1 else 0)
        checkCommand("leave flash download mode", Cmd.FLASH_END, pkt, timeoutMs = timeoutMs)
    }

    /** loader.py:2518 flash_defl_begin(): compressed write, same params
     * layout as flash_begin() but write_size = size (uncompressed) rather
     * than compsize, and num_blocks is based on the compressed size. */
    fun flashDeflBegin(size: Long, compsize: Long, offset: Long, encryptedWrite: Boolean = false) {
        val numBlocks = (compsize + FLASH_WRITE_SIZE - 1) / FLASH_WRITE_SIZE
        val params = le32(size) + le32(numBlocks) + le32(FLASH_WRITE_SIZE) + le32(offset) +
            le32(if (encryptedWrite) 1 else 0)
        checkCommand("enter compressed flash mode", Cmd.FLASH_DEFL_BEGIN, params)
    }

    /** loader.py:2561 flash_defl_block(). */
    fun flashDeflBlock(data: ByteArray, seq: Int, timeoutMs: Int = 3000) {
        val header = le32(data.size) + le32(seq) + le32(0) + le32(0)
        checkCommand(
            "write compressed data to flash after seq $seq", Cmd.FLASH_DEFL_DATA,
            header + data, checksum(data), timeoutMs = timeoutMs,
        )
    }

    /** loader.py:2583 flash_defl_finish(). */
    fun flashDeflFinish(reboot: Boolean = false, timeoutMs: Int = 3000) {
        val pkt = le32(if (!reboot) 1 else 0)
        checkCommand("leave compressed flash mode", Cmd.FLASH_DEFL_END, pkt, timeoutMs = timeoutMs)
    }

    /** loader.py:2599 flash_md5sum(), stub response variant only (16 raw
     * MD5 bytes, hex-encoded here) -- the ROM-only variant (which returns
     * a pre-formatted 32-byte hex string) isn't needed since this build
     * always runs the stub. Timeout scales with region size, same as
     * Python's MD5_TIMEOUT_PER_MB. */
    fun flashMd5sum(addr: Long, size: Long): String {
        val data = le32(addr) + le32(size) + le32(0) + le32(0)
        val res = checkCommandData(
            "calculate md5sum", Cmd.SPI_FLASH_MD5, data,
            respDataLen = 16, timeoutMs = timeoutPerMbMs(8.0, size),
        )
        return res.toHex()
    }

    fun close() {
        try { socket.close() } catch (e: IOException) { /* ignore */ }
    }
}

// ============================================================================
// Chip identification
// (Python: ESPLoader.connect()'s detection block, loader.py:936-1006, plus
// each target's CHIP_NAME/IMAGE_CHIP_ID/MAGIC_VALUE in esptool/targets/*.py)
// ============================================================================

data class ChipDef(
    val name: String,       // e.g. "ESP32-C3", matches Python CHIP_NAME
    val slug: String,       // e.g. "esp32c3", matches --chip and the stub json filename stem
    val imageChipId: Int?,  // matched against GET_SECURITY_INFO's chip_id field, if present
    val magicValue: Long?,  // matched against CHIP_DETECT_MAGIC_REG_ADDR, if present
) {
    val jsonName get() = "$slug.json"
}

val CHIPS = listOf(
    ChipDef("ESP32", "esp32", imageChipId = 0, magicValue = 0x00F01D83L),
    ChipDef("ESP32-S2", "esp32s2", imageChipId = 2, magicValue = 0x000007C6L),
    ChipDef("ESP32-S3", "esp32s3", imageChipId = 9, magicValue = null),
    ChipDef("ESP32-C3", "esp32c3", imageChipId = 5, magicValue = null),
    ChipDef("ESP32-C2", "esp32c2", imageChipId = 12, magicValue = null),
    ChipDef("ESP32-C6", "esp32c6", imageChipId = 13, magicValue = null),
    ChipDef("ESP32-C61", "esp32c61", imageChipId = 20, magicValue = null),
    ChipDef("ESP32-C5", "esp32c5", imageChipId = 23, magicValue = null),
    ChipDef("ESP32-H2", "esp32h2", imageChipId = 16, magicValue = null),
    ChipDef("ESP32-H4", "esp32h4", imageChipId = 28, magicValue = null),
    ChipDef("ESP32-P4", "esp32p4", imageChipId = 18, magicValue = null),
    ChipDef("ESP32-S31", "esp32s31", imageChipId = 32, magicValue = null),
    ChipDef("ESP8266", "esp8266", imageChipId = null, magicValue = 0xFFF0C101L),
)
// Not included: ESP32-E22 (image_chip_id=31) and ESP32-H21 (image_chip_id=25)
// -- both USES_MAGIC_VALUE=False and neither ships stub_flasher JSON data in
// the original project either, so stub-based read-flash can't work for them
// regardless of language. See esp32e22.py / esp32h21.py.

/**
 * loader.py's connect() tries GET_SECURITY_INFO first (works on ESP32-S3
 * and later), and falls back to the classic magic-value register read for
 * older chips (ESP8266/ESP32) or ESP32-S2 (whose 12-byte security-info
 * reply doesn't include a chip_id, so this naturally falls through to the
 * magic-value path and finds it there instead -- see the file header notes
 * on why that's fine here).
 */
fun detectChip(conn: EspConnection): ChipDef {
    var chipIdFromSecurityInfo: Int? = null
    try {
        val resp = conn.checkCommandData(
            "get security info", Cmd.GET_SECURITY_INFO, respDataLen = 20, timeoutMs = 1000
        )
        // layout: flags(4) + flash_crypt_cnt(1) + 7*key_purposes(1 each) +
        // chip_id(4) + api_version(4) -- chip_id starts at byte offset 12
        chipIdFromSecurityInfo = readLe32(resp, 12).toInt()
    } catch (e: FatalError) {
        // GET_SECURITY_INFO unsupported (old ROM) or came back short (the
        // ESP32-S2 12-byte variant) -- fall back to magic-value below either way.
    }
    if (chipIdFromSecurityInfo != null) {
        return CHIPS.firstOrNull { it.imageChipId == chipIdFromSecurityInfo }
            ?: throw FatalError(
                "Connected, but chip_id $chipIdFromSecurityInfo doesn't match any " +
                    "chip this build knows about."
            )
    }
    val magic = conn.readReg(CHIP_DETECT_MAGIC_REG_ADDR)
    return CHIPS.firstOrNull { it.magicValue == magic }
        ?: throw FatalError(
            "Could not auto-detect chip type (magic value 0x${magic.toString(16)})."
        )
}

// ============================================================================
// Minimal JSON parsing, just for the stub_flasher/*.json files
// (their schema: {"text": "<base64>", "text_start": int, "entry": int,
//  "data": "<base64>", "data_start": int, "bss_start": int, ...extra
//  plugin-related fields we don't use}. A small real recursive-descent
// parser rather than a hand-rolled extractor, to avoid depending on any
// external JSON library.)
// ============================================================================

private sealed class Json {
    data class Obj(val map: Map<String, Json>) : Json()
    data class Arr(val items: List<Json>) : Json()
    data class Str(val value: String) : Json()
    data class Num(val value: Double) : Json()
    data class Bool(val value: Boolean) : Json()
    object Null : Json()
}

private class JsonParser(private val s: String) {
    private var i = 0

    fun parse(): Json {
        skipWs()
        val v = parseValue()
        skipWs()
        return v
    }

    private fun skipWs() { while (i < s.length && s[i].isWhitespace()) i++ }

    private fun parseValue(): Json {
        skipWs()
        return when (s[i]) {
            '{' -> parseObject()
            '[' -> parseArray()
            '"' -> Json.Str(parseStringRaw())
            't' -> { expect("true"); Json.Bool(true) }
            'f' -> { expect("false"); Json.Bool(false) }
            'n' -> { expect("null"); Json.Null }
            else -> parseNumber()
        }
    }

    private fun expect(lit: String) {
        if (!s.regionMatches(i, lit, 0, lit.length)) {
            error("Expected '$lit' at position $i")
        }
        i += lit.length
    }

    private fun parseObject(): Json.Obj {
        i++ // {
        val map = LinkedHashMap<String, Json>()
        skipWs()
        if (s[i] == '}') { i++; return Json.Obj(map) }
        while (true) {
            skipWs()
            val key = parseStringRaw()
            skipWs()
            if (s[i] != ':') error("Expected ':' at position $i")
            i++
            map[key] = parseValue()
            skipWs()
            when (s[i]) {
                ',' -> { i++; continue }
                '}' -> { i++; break }
                else -> error("Expected ',' or '}' at position $i")
            }
        }
        return Json.Obj(map)
    }

    private fun parseArray(): Json.Arr {
        i++ // [
        val items = mutableListOf<Json>()
        skipWs()
        if (s[i] == ']') { i++; return Json.Arr(items) }
        while (true) {
            items.add(parseValue())
            skipWs()
            when (s[i]) {
                ',' -> { i++; continue }
                ']' -> { i++; break }
                else -> error("Expected ',' or ']' at position $i")
            }
        }
        return Json.Arr(items)
    }

    private fun parseStringRaw(): String {
        if (s[i] != '"') error("Expected '\"' at position $i")
        i++
        val sb = StringBuilder()
        while (s[i] != '"') {
            if (s[i] == '\\') {
                i++
                when (s[i]) {
                    '"' -> sb.append('"')
                    '\\' -> sb.append('\\')
                    '/' -> sb.append('/')
                    'n' -> sb.append('\n')
                    't' -> sb.append('\t')
                    'r' -> sb.append('\r')
                    'b' -> sb.append('\b')
                    'f' -> sb.append('\u000C')
                    'u' -> {
                        val hex = s.substring(i + 1, i + 5)
                        sb.append(hex.toInt(16).toChar())
                        i += 4
                    }
                    else -> sb.append(s[i])
                }
                i++
            } else {
                sb.append(s[i]); i++
            }
        }
        i++ // closing quote
        return sb.toString()
    }

    private fun parseNumber(): Json.Num {
        val start = i
        if (s[i] == '-') i++
        while (i < s.length && s[i].isDigit()) i++
        if (i < s.length && s[i] == '.') {
            i++
            while (i < s.length && s[i].isDigit()) i++
        }
        if (i < s.length && (s[i] == 'e' || s[i] == 'E')) {
            i++
            if (s[i] == '+' || s[i] == '-') i++
            while (i < s.length && s[i].isDigit()) i++
        }
        return Json.Num(s.substring(start, i).toDouble())
    }
}

private fun Json.asObj(): Map<String, Json> = (this as Json.Obj).map
private fun Json.asStr(): String = (this as Json.Str).value
private fun Json.asLong(): Long = (this as Json.Num).value.toLong()

// ============================================================================
// Stub flasher payload (loader.py:185-260 StubFlasher.__init__)
// ============================================================================

data class StubData(
    val text: ByteArray,
    val textStart: Long,
    val entry: Long,
    val data: ByteArray?,
    val dataStart: Long?,
)

/**
 * Loads targets/stub_flasher/{2,1}/<chip>.json, same search order and same
 * file format as the Python version's StubFlasher (loader.py:187-260) --
 * this build re-uses the exact same JSON asset files, no stub bytecode was
 * re-implemented or ported, only the loader for it.
 */
fun loadStub(stubDir: File, chip: ChipDef): StubData {
    val candidates = listOf(File(stubDir, "2/${chip.jsonName}"), File(stubDir, "1/${chip.jsonName}"))
    val jsonFile = candidates.firstOrNull { it.exists() }
        ?: throw FatalError(
            "No stub flasher data for ${chip.name}. Looked for: " +
                candidates.joinToString(", ") { it.path }
        )
    val obj = JsonParser(jsonFile.readText(Charsets.UTF_8)).parse().asObj()
    val text = Base64.getDecoder().decode(obj.getValue("text").asStr())
    val textStart = obj.getValue("text_start").asLong()
    val entry = obj.getValue("entry").asLong()
    val data = obj["data"]?.let { Base64.getDecoder().decode(it.asStr()) }
    val dataStart = obj["data_start"]?.asLong()
    return StubData(text, textStart, entry, data, dataStart)
}

// ============================================================================
// write-flash / verify-flash shared helpers
// ============================================================================

private fun md5Hex(data: ByteArray): String = MessageDigest.getInstance("MD5").digest(data).toHex()

/** util.py pad_to(): pad to the next alignment boundary with 0xFF
 * (esptool's default pad_character) rather than zero bytes. */
private fun padTo(data: ByteArray, alignment: Int, padByte: Byte = 0xFF.toByte()): ByteArray {
    val rem = data.size % alignment
    return if (rem == 0) data else data + ByteArray(alignment - rem) { padByte }
}

/** zlib-format (RFC 1950) deflate at the maximum compression level, matching
 * Python's `zlib.compress(image, 9)` (cmds.py write_flash()). Java's
 * Deflater produces the same zlib container format Python's zlib module
 * does, so the compressed bytes are wire-compatible regardless of which
 * side compressed them -- the chip-side stub only needs a standards-
 * compliant zlib/DEFLATE decompressor, which is what it already has to
 * handle the Python tool's own compressed writes. */
private fun deflate(data: ByteArray): ByteArray {
    val deflater = Deflater(Deflater.BEST_COMPRESSION)
    deflater.setInput(data)
    deflater.finish()
    val out = ByteArrayOutputStream(maxOf(64, data.size / 2))
    val buf = ByteArray(8192)
    while (!deflater.finished()) {
        val n = deflater.deflate(buf)
        out.write(buf, 0, n)
    }
    deflater.end()
    return out.toByteArray()
}

/** Only used by --selftest to prove [deflate]'s output round-trips through
 * a standard zlib inflater -- not used on the write-flash path itself. */
private fun inflate(data: ByteArray, expectedSize: Int): ByteArray {
    val inflater = Inflater()
    inflater.setInput(data)
    val out = ByteArray(expectedSize)
    var off = 0
    while (!inflater.finished() && off < out.size) {
        off += inflater.inflate(out, off, out.size - off)
    }
    inflater.end()
    return out
}

// ============================================================================
// write-flash (Python: cmds.py write_flash(), core "keep" path only -- see
// the file header for everything deliberately not ported: encryption, NAND,
// --erase-all, --diff-with/--skip-flashed, flash_mode/freq/size header
// overrides, the pre-flight safety checks, and reconnect-on-drop)
// ============================================================================

data class WriteFlashOptions(val compress: Boolean = true, val noProgress: Boolean = false)

/**
 * Writes each (address, data) pair to flash and verifies it afterwards via
 * [EspConnection.flashMd5sum], mirroring the core of cmds.py write_flash():
 * pad to 4 bytes, optionally compress (falling back to uncompressed if that
 * doesn't shrink the data), FLASH_(DEFL_)BEGIN, stream FLASH_(DEFL_)DATA
 * blocks, FLASH_(DEFL_)END, then compare a device-side MD5 digest against
 * the local one (cmds.py write_flash():10260-10284, the "Verifying written
 * data..." block). Throws [FatalError] on the first verification failure,
 * distinguishing an all-0xFF (nothing-was-written) mismatch same as Python
 * does, for a clearer error message.
 */
fun writeFlash(conn: EspConnection, files: List<Pair<Long, ByteArray>>, opts: WriteFlashOptions) {
    for ((address, rawImage) in files) {
        if (rawImage.isEmpty()) {
            println("Input is empty, skipping.")
            continue
        }
        val image = padTo(rawImage, 4)
        val imageSize = image.size
        val imageMd5 = md5Hex(image)

        println("Writing $imageSize bytes at 0x${address.toString(16)}...")

        var compress = opts.compress
        var toSend = image
        if (compress) {
            val compressed = deflate(image)
            if (compressed.size < imageSize) {
                println("Compressed $imageSize bytes to ${compressed.size}...")
                toSend = compressed
            } else {
                println(
                    "Cannot compress data more than the original size " +
                        "(${compressed.size} >= $imageSize), flashing uncompressed."
                )
                compress = false
            }
        }

        if (compress) {
            conn.flashDeflBegin(imageSize.toLong(), toSend.size.toLong(), address)
        } else {
            conn.flashBegin(imageSize.toLong(), address)
        }

        var seq = 0
        var sent = 0
        var offset = 0
        while (offset < toSend.size) {
            val end = minOf(offset + FLASH_WRITE_SIZE, toSend.size)
            var block = toSend.copyOfRange(offset, end)
            if (!compress && block.size < FLASH_WRITE_SIZE) {
                // Pad the last uncompressed block up to a full block; the
                // compressed path sends the deflate stream's natural chunk
                // sizes as-is, same as Python (cmds.py write_flash():
                // "block = block + b'\xff' * (...)" only in the non-defl
                // branch).
                block = block + ByteArray(FLASH_WRITE_SIZE - block.size) { 0xFF.toByte() }
            }
            if (compress) conn.flashDeflBlock(block, seq) else conn.flashBlock(block, seq)
            sent += block.size
            offset = end
            seq += 1
            if (!opts.noProgress) {
                val pct = sent * 100.0 / toSend.size
                print("\rWriting... %.1f%%".format(pct))
                System.out.flush()
            }
        }
        if (!opts.noProgress) println()

        if (compress) conn.flashDeflFinish(reboot = false) else conn.flashFinish(reboot = false)

        println("Verifying written data...")
        val res = conn.flashMd5sum(address, imageSize.toLong())
        if (res != imageMd5) {
            if (res == md5Hex(ByteArray(imageSize) { 0xFF.toByte() })) {
                throw FatalError("Write failed, the written flash region is empty.")
            }
            throw FatalError(
                "MD5 of file does not match data in flash! " +
                    "expected $imageMd5, got $res"
            )
        }
        println("Hash of data verified.")
    }
}

// ============================================================================
// verify-flash (Python: cmds.py verify_flash(), core "keep" path -- MD5
// digest check against the device, falling back to a byte-by-byte re-read
// via the existing readFlashStub() when --diff is given and the digest
// doesn't match; cmds.py verify_flash():10989-11011)
// ============================================================================

data class VerifyFlashOptions(val diff: Boolean = false)

/** Returns true if every file verified successfully. Prints per-file
 * results as it goes, same as the Python command does, rather than
 * collecting them into a return value the Python version doesn't have
 * either (it just raises FatalError at the end if anything mismatched). */
fun verifyFlash(conn: EspConnection, files: List<Pair<Long, ByteArray>>, opts: VerifyFlashOptions): Boolean {
    var allOk = true
    for ((address, rawData) in files) {
        val image = padTo(rawData, 4)
        val imageSize = image.size
        val expected = md5Hex(image)
        println("Verifying $imageSize bytes at 0x${address.toString(16)} against flash...")

        val actual = conn.flashMd5sum(address, imageSize.toLong())
        if (actual == expected) {
            println("Verification successful (digest matched).")
            continue
        }
        allOk = false
        if (!opts.diff) {
            println("Verification failed (digest mismatch).")
            continue
        }

        val flash = conn.readFlashStub(address, imageSize.toLong())
        val differences = (0 until imageSize).filter { flash[it] != image[it] }
        if (differences.isEmpty()) {
            // Extremely unlikely (would mean an MD5 collision), but keep
            // the same "assert flash != image" spirit as the Python code.
            println("Digest mismatched but no byte differences found (MD5 collision?).")
            continue
        }
        println(
            "Verification failed: ${differences.size} differences, " +
                "first at 0x${(address + differences[0]).toString(16)}:"
        )
        for (d in differences) {
            println(
                "   0x${(address + d).toString(16)} " +
                    "%02x %02x".format(flash[d].toInt() and 0xFF, image[d].toInt() and 0xFF)
            )
        }
    }
    return allOk
}

// ============================================================================
// CLI
// ============================================================================

private fun parseIntArg(s: String): Long =
    if (s.startsWith("0x") || s.startsWith("0X")) s.substring(2).toLong(16) else s.toLong()

private fun parseSizeArg(s: String): Long {
    val trimmed = s.trim()
    val mult = when {
        trimmed.endsWith("K", ignoreCase = true) -> 1024L
        trimmed.endsWith("M", ignoreCase = true) -> 1024L * 1024L
        else -> 1L
    }
    val numPart = if (mult != 1L) trimmed.dropLast(1) else trimmed
    return parseIntArg(numPart) * mult
}

private fun jarDirectory(): File {
    val location = object {}.javaClass.protectionDomain.codeSource.location.toURI()
    val f = File(location)
    return if (f.isFile) f.parentFile else f
}

/** Parses ["addr1", "file1", "addr2", "file2", ...] pairs for write-flash
 * and verify-flash, reading each file eagerly (matching Python's own
 * upfront-read-then-process behavior in these commands). Exits with an
 * error message on a bad address or a missing file, same as the rest of
 * this CLI's argument handling. */
private fun parseAddrFilePairs(pairs: List<Pair<String, String>>): List<Pair<Long, ByteArray>> =
    pairs.map { (a, f) ->
        val addr = try {
            parseIntArg(a)
        } catch (e: NumberFormatException) {
            System.err.println("Couldn't parse ADDRESS '$a': ${e.message}")
            exitProcess(1)
        }
        val file = File(f)
        if (!file.exists()) {
            System.err.println("No such file: $f")
            exitProcess(1)
        }
        addr to file.readBytes()
    }

private fun printUsage() {
    System.err.println(
        """
        Usage: esptool_flashtool.jar --port socket://HOST:PORT [--chip auto|esp32|esp32c3|...] COMMAND ...

        Only socket:// (TCP bridge, e.g. Termux' TCPUART app) ports are supported -- put
        the chip in bootloader/download mode yourself first, since reset can't be done
        over a plain TCP socket.

        Commands:
          read-flash ADDRESS SIZE OUTPUT
              Read SIZE bytes of SPI flash starting at ADDRESS and write them to OUTPUT.

          write-flash [--no-compress] ADDRESS FILE [ADDRESS FILE ...]
              Write FILE to flash at ADDRESS (one or more address/file pairs), verifying
              each write against a device-side MD5 digest afterwards. Compressed by
              default; --no-compress sends raw data instead.

          verify-flash [--diff] ADDRESS FILE [ADDRESS FILE ...]
              Compare flash contents against FILE at ADDRESS (one or more pairs) without
              writing anything. --diff does a full byte-by-byte comparison and prints
              every differing byte if the digest doesn't match; without it, only a
              pass/fail per file is reported.

        ADDRESS and SIZE accept 0x-prefixed hex or decimal, and SIZE also accepts a
        trailing K or M suffix (e.g. 0x400000 or 4M).

        Examples:
          esptool_flashtool.jar --port socket://127.0.0.1:8080 --chip esp32 read-flash 0x0 0x400000 dump.bin
          esptool_flashtool.jar --port socket://127.0.0.1:8080 --chip esp32 write-flash 0x1000 bootloader.bin 0x10000 app.bin
          esptool_flashtool.jar --port socket://127.0.0.1:8080 --chip esp32 verify-flash --diff 0x10000 app.bin
        """.trimIndent()
    )
}

// ============================================================================
// Self-test: no real hardware was available while writing this, so this
// exercises what CAN be checked mechanically -- SLIP framing round-trips,
// the checksum algorithm against a hand-computed value, little-endian
// packing round-trips, and the JSON parser against a real, bundled
// stub_flasher JSON file. It does NOT prove the wire protocol is correct
// against an actual chip -- only that these building blocks behave as
// intended. Run with `--selftest [path-to-targets-dir]`.
// ============================================================================

private fun runSelfTest(stubDirArg: String?): Boolean {
    var ok = true
    fun check(name: String, pass: Boolean, detail: String = "") {
        println((if (pass) "PASS" else "FAIL") + " - $name" + if (detail.isNotEmpty()) " ($detail)" else "")
        if (!pass) ok = false
    }

    // SLIP round-trip, including bytes that need escaping (0xC0, 0xDB)
    run {
        val original = byteArrayOf(0x01, 0x02, 0x03, 0xC0.toByte(), 0xDB.toByte(), 0x00, 0xFF.toByte())
        val encoded = Slip.encode(original)
        val decoded = SlipReader(java.io.ByteArrayInputStream(encoded)).readPacket()
        check("SLIP round-trip", decoded.contentEquals(original), "got ${decoded.toHex()}")
    }

    // Checksum against a hand-computed expected value (XOR of 0xEF with each byte)
    run {
        val data = byteArrayOf(0x01, 0x02, 0x03, 0xC0.toByte(), 0xDB.toByte())
        var state = ESP_CHECKSUM_MAGIC
        for (b in data) state = state xor (b.toInt() and 0xFF)
        check("checksum algorithm", state == 0xF4, "got 0x${state.toString(16)}, expected 0xf4")
    }

    // little-endian pack/unpack round-trip
    run {
        val v = 0x12345678L
        val packed = le32(v)
        val expected = byteArrayOf(0x78, 0x56, 0x34.toByte(), 0x12)
        check("le32 byte order", packed.contentEquals(expected), "got ${packed.toHex()}")
        check("le32/readLe32 round-trip", readLe32(packed, 0) == v)
    }
    run {
        val v = 0xABCD
        val packed = le16(v)
        check("le16/readLe16 round-trip", readLe16(packed, 0) == v)
    }

    // toHex() on a byte with the high bit set -- this feeds every MD5
    // digest comparison in write-flash/verify-flash, so a regression here
    // would silently make every real write/verify report a false
    // mismatch. Deliberately includes 0xFF (would sign-extend if the
    // byte->Int conversion below were ever removed).
    run {
        val data = byteArrayOf(0xFF.toByte(), 0x00, 0x80.toByte(), 0x7F)
        check("toHex() byte-width (no sign extension)", data.toHex() == "ff00807f", "got ${data.toHex()}")
    }

    // deflate()/inflate() round-trip, and that compression actually
    // shrinks compressible data (write-flash's "did compression help"
    // check assumes this)
    run {
        val original = ByteArray(4096) { (it % 16).toByte() } // highly compressible
        val compressed = deflate(original)
        val decompressed = inflate(compressed, original.size)
        check(
            "deflate/inflate round-trip", decompressed.contentEquals(original),
            "compressed ${original.size} -> ${compressed.size} bytes"
        )
        check("deflate() shrinks compressible data", compressed.size < original.size)
    }

    // flash_begin() param packing against a hand-computed expected byte
    // sequence (loader.py:2185 struct.pack("<IIII", erase_size, num_blocks,
    // FLASH_WRITE_SIZE, offset) + struct.pack("<I", encrypted_write))
    run {
        // size=0x500 (2 blocks of FLASH_WRITE_SIZE=0x400), offset=0x1000
        val size = 0x500L
        val offset = 0x1000L
        val numBlocks = (size + FLASH_WRITE_SIZE - 1) / FLASH_WRITE_SIZE
        val params = le32(size) + le32(numBlocks) + le32(FLASH_WRITE_SIZE) + le32(offset) + le32(0)
        val expected = byteArrayOf(
            0x00, 0x05, 0x00, 0x00, // size = 0x500
            0x02, 0x00, 0x00, 0x00, // num_blocks = 2
            0x00, 0x04, 0x00, 0x00, // FLASH_WRITE_SIZE = 0x400
            0x00, 0x10, 0x00, 0x00, // offset = 0x1000
            0x00, 0x00, 0x00, 0x00, // encrypted_write = 0
        )
        check("flash_begin() param packing", params.contentEquals(expected), "got ${params.toHex()}")
    }

    // JSON parser against a real bundled stub file, if we can find one
    val stubDir = File(stubDirArg ?: File(jarDirectory(), "targets/stub_flasher").path)
    val sampleJson = File(stubDir, "2/esp32.json").let {
        if (it.exists()) it else File(stubDir, "1/esp32.json")
    }
    if (sampleJson.exists()) {
        try {
            val stub = loadStub(stubDir, CHIPS.first { it.slug == "esp32" })
            check(
                "JSON parse of ${sampleJson.path}",
                stub.text.isNotEmpty() && stub.textStart > 0 && stub.entry > 0,
                "text=${stub.text.size} bytes, textStart=0x${stub.textStart.toString(16)}, " +
                    "entry=0x${stub.entry.toString(16)}"
            )
        } catch (e: Exception) {
            check("JSON parse of ${sampleJson.path}", false, e.message ?: e.toString())
        }
    } else {
        println(
            "SKIP - JSON parse test (no targets/stub_flasher/{1,2}/esp32.json found near " +
                "the jar or at the given path; pass --selftest <path-to-targets-dir> if you " +
                "extracted the zip somewhere unusual)"
        )
    }

    return ok
}

fun main(args: Array<String>) {
    if (args.isNotEmpty() && args[0] == "--selftest") {
        val stubDirArg = args.getOrNull(1)
        val passed = runSelfTest(stubDirArg)
        exitProcess(if (passed) 0 else 1)
    }

    var port: String? = null
    var chipArg = "auto"
    var commandArg: String? = null
    var noCompress = false
    var diff = false
    val positional = mutableListOf<String>()
    var i = 0
    while (i < args.size) {
        when (args[i]) {
            "--port", "-p" -> { port = args.getOrNull(i + 1); i += 2 }
            "--chip", "-c" -> { chipArg = args.getOrNull(i + 1) ?: "auto"; i += 2 }
            "--help", "-h" -> { printUsage(); return }
            "--no-compress" -> { noCompress = true; i += 1 }
            "--diff" -> { diff = true; i += 1 }
            "read-flash", "write-flash", "verify-flash" -> { commandArg = args[i]; i += 1 }
            else -> { positional.add(args[i]); i += 1 }
        }
    }
    // Back-compat: earlier builds of this tool took no subcommand at all
    // and always did a read-flash. Keep that working if exactly 3
    // positional args are given with no command keyword.
    if (commandArg == null && positional.size == 3) commandArg = "read-flash"
    val command: String = commandArg ?: run {
        printUsage()
        exitProcess(1)
    }

    // read-flash: ADDRESS SIZE OUTPUT (unchanged from before)
    // write-flash / verify-flash: one or more ADDRESS FILE pairs
    var readFlashAddress = 0L
    var readFlashSize = 0L
    var readFlashOutput = ""
    var addrFilePairs: List<Pair<String, String>> = emptyList()
    if (command == "read-flash") {
        if (positional.size != 3) {
            printUsage()
            exitProcess(1)
        }
        try {
            readFlashAddress = parseIntArg(positional[0])
            readFlashSize = parseSizeArg(positional[1])
            readFlashOutput = positional[2]
        } catch (e: NumberFormatException) {
            System.err.println("Couldn't parse ADDRESS/SIZE: ${e.message}")
            exitProcess(1)
        }
    } else {
        if (positional.isEmpty() || positional.size % 2 != 0) {
            System.err.println("$command needs one or more ADDRESS FILE pairs.")
            printUsage()
            exitProcess(1)
        }
        addrFilePairs = positional.chunked(2).map { (a, f) -> a to f }
    }

    val portArg: String = port ?: run {
        printUsage()
        exitProcess(1)
    }

    val uri = try { URI(portArg) } catch (e: Exception) {
        System.err.println("Invalid --port value: $portArg")
        exitProcess(1)
    }
    val host: String = uri.host ?: run {
        System.err.println(
            "Only socket://HOST:PORT ports are supported by this build (got: $portArg)."
        )
        exitProcess(1)
    }
    val tcpPort = uri.port
    if (uri.scheme != "socket" || tcpPort == -1) {
        System.err.println(
            "Only socket://HOST:PORT ports are supported by this build (got: $portArg)."
        )
        exitProcess(1)
    }

    println("Connecting to $host:$tcpPort ...")
    println(
        "Note: this build can't reset the chip over TCP -- make sure it's already " +
            "in bootloader/download mode."
    )

    val conn = try {
        EspConnection(host, tcpPort)
    } catch (e: IOException) {
        System.err.println("Couldn't connect to $host:$tcpPort: ${e.message}")
        exitProcess(1)
    }

    var connected = false
    var lastError: Exception? = null
    for (attempt in 1..5) {
        try {
            conn.drainInput()
            conn.sync()
            connected = true
            break
        } catch (e: Exception) {
            lastError = e
            print(".")
            System.out.flush()
            Thread.sleep(50)
        }
    }
    println()
    if (!connected) {
        System.err.println("Failed to connect: ${lastError?.message}")
        conn.close()
        exitProcess(1)
    }

    try {
        val chip = if (chipArg == "auto") {
            detectChip(conn)
        } else {
            CHIPS.firstOrNull { it.slug.equals(chipArg, ignoreCase = true) }
                ?: run {
                    System.err.println(
                        "Unknown --chip '$chipArg'. Known: auto, " +
                            CHIPS.joinToString(", ") { it.slug }
                    )
                    exitProcess(1)
                }
        }
        println("Detected chip: ${chip.name}")

        val stubDir = File(jarDirectory(), "targets/stub_flasher")
        val stub = loadStub(stubDir, chip)

        println("Uploading stub flasher...")
        conn.runStub(stub)
        println("Stub flasher running.")

        when (command) {
            "read-flash" -> {
                println("Reading $readFlashSize bytes from 0x${readFlashAddress.toString(16)}...")
                val data = conn.readFlashStub(readFlashAddress, readFlashSize) { done, total ->
                    val pct = if (total > 0) done * 100.0 / total else 100.0
                    print("\rRead %d / %d bytes (%.1f%%)".format(done, total, pct))
                    System.out.flush()
                }
                println()
                File(readFlashOutput).writeBytes(data)
                println("Wrote ${data.size} bytes to $readFlashOutput")
            }
            "write-flash" -> {
                val files = parseAddrFilePairs(addrFilePairs)
                writeFlash(conn, files, WriteFlashOptions(compress = !noCompress))
                println("Done.")
            }
            "verify-flash" -> {
                val files = parseAddrFilePairs(addrFilePairs)
                val ok = verifyFlash(conn, files, VerifyFlashOptions(diff = diff))
                if (!ok) {
                    System.err.println("Verification failed.")
                    exitProcess(1)
                }
                println("All files verified.")
            }
        }
    } catch (e: FatalError) {
        println()
        System.err.println("Error: ${e.message}")
        exitProcess(1)
    } finally {
        conn.close()
    }
}
