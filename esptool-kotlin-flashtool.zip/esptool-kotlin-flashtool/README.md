# esptool-kotlin-flashtool

A from-scratch Kotlin/JVM port of esptool's `read-flash`, `write-flash`, and
`verify-flash` commands, talking to an ESP8266/ESP32-family chip over a TCP
socket (`socket://host:port` — the Termux-TCP-bridge scenario this was
built for). Single Kotlin file, compiles to a single runnable jar, no
runtime dependencies beyond the JDK.

## Status — please read before trusting this with real hardware

- **`read-flash`** was written, compiled, and self-tested earlier. Not
  destructive (it never writes to flash).
- **`write-flash`** and **`verify-flash`** were added afterwards, in an
  environment with **no JDK/Kotlin compiler and no hardware available**.
  They've only been checked by careful reading against the original esptool
  Python source and the extended `--selftest` below — neither of which
  proves the code even compiles, let alone works correctly against a real
  chip.
- **Writing to flash is destructive**, unlike reading. A protocol mistake
  in `write-flash` can corrupt or brick a device, not just fail to read.

Please: run `--selftest` right after building (step 4 of the Colab script
does this automatically); if the build itself fails, copy the compiler
error back to the chat; and test cautiously against a real board —
`read-flash` and `verify-flash --diff` on some region you don't care about
are good ways to sanity-check the connection and protocol before trusting
`write-flash` with anything you can't afford to lose.

## What's NOT implemented (vs. the Python esptool)

- Only `socket://` transport — no real serial ports. Python also disables
  chip reset over `socket://`, so you need to put the chip in
  bootloader/download mode yourself either way.
- No custom SPI pins (`--spi-connection`) — relies on the stub loader's
  own default-pin SPI attach.
- No flash-size auto-detect or bounds checking — you're responsible for
  addresses/sizes actually fitting on the chip.
- No `--flash-mode`/`--flash-freq`/`--flash-size` image-header patching —
  files are written/verified byte-for-byte, "keep" only.
- No flash encryption, no NAND flash, no `--erase-all`, no
  `--diff-with`/`--skip-flashed` fast partial reflashing, and none of
  Python's pre-flight safety checks (secure-boot-v1 bootloader guard,
  flash-encryption-key-manager guard, image chip-ID/chip-revision
  validation). Double check by hand that what you're writing matches the
  connected chip.
- No reconnect-on-dropped-connection during a write — it just fails, rerun
  it.
- ESP32-E22 and ESP32-H21 aren't in chip detection (upstream esptool ships
  no stub data for either).
- ESP32-P4's revision-dependent stub selection is simplified to always use
  the newer-silicon stub.
- The ESP32-S3-secure-boot-enabled stub injection workaround isn't
  implemented.

See the comment block at the top of `EsptoolFlashTool.kt` for the same
list with the exact Python source locations each decision was based on.

## Files

```
EsptoolFlashTool.kt                <- the whole tool, one file
colab_build.py                     <- paste into a Colab cell to build it
targets/stub_flasher/1/*.json      <- stub-loader payload data, protocol v1
targets/stub_flasher/2/*.json      <- stub-loader payload data, protocol v2
```

## Building

Easiest: open [Google Colab](https://colab.research.google.com), paste in
`colab_build.py`, run the cell, and upload this zip when prompted. It
installs a JDK and the Kotlin compiler, builds the jar, runs
`--selftest`, packages the jar with the `targets/` data, and downloads
`esptool_flashtool_build.zip` back to you.

Locally, with a JDK and Kotlin compiler already installed:

```bash
kotlinc EsptoolFlashTool.kt -include-runtime -d esptool_flashtool.jar
java -jar esptool_flashtool.jar --selftest
```

Keep the `targets/` folder next to the jar at runtime either way — it's
read at startup to find the right stub loader for the detected chip.

## Usage

```bash
# Read 4 MB of flash starting at 0x0 into dump.bin
java -jar esptool_flashtool.jar --port socket://127.0.0.1:8080 --chip esp32 \
    read-flash 0x0 0x400000 dump.bin

# Write a bootloader and app image (verified against a device-side MD5 after each write)
java -jar esptool_flashtool.jar --port socket://127.0.0.1:8080 --chip esp32 \
    write-flash 0x1000 bootloader.bin 0x10000 app.bin

# Verify flash content matches a local file without writing anything;
# --diff prints every differing byte if the digest doesn't match
java -jar esptool_flashtool.jar --port socket://127.0.0.1:8080 --chip esp32 \
    verify-flash --diff 0x10000 app.bin
```

`--chip auto` (the default) detects the chip automatically. ADDRESS and
SIZE accept `0x`-prefixed hex or plain decimal; SIZE also accepts a
trailing `K`/`M` suffix. `write-flash` compresses with zlib by default
(matching Python's own default whenever a stub loader is used, which is
always the case here) — pass `--no-compress` to send raw data instead.
