# AVRDUDE Frontend for Android

A Material 3, MVVM/Clean-Architecture Android app that drives the supplied
`libavrdude2.so` (an ArduinoDroid/`avrdude-arduinodroid2` build of AVRDUDE
for `arm64-v8a`) as its programming engine, over a custom JNI bridge, with
full USB Host API integration for talking to ISP/UPDI/JTAG programmers.

**Read `docs/ARCHITECTURE.md` before touching the native code.** The short
version: `libavrdude2.so` was inspected (`nm -D`, `readelf`) before writing
anything, and it turns out to export **zero symbols** — it's the actual
AVRDUDE command-line executable, packaged under the `lib*.so` naming
convention purely so Android extracts it with the executable bit set. There
is nothing to bind to at the symbol level. This project's JNI layer
(`libavrbridge.so`, built from `app/src/main/cpp`) is a real, fully-exported
JNI library that Kotlin calls directly; internally it runs `libavrdude2.so`
as a managed child process (`fork()`+`execve()`, no shell) and streams its output
back through JNI callbacks. That's not a workaround bolted on top of "the
real design" — given the artifact provided, it *is* the only architecture
that can work, and it's the same technique ArduinoDroid itself uses.

## Requirements

- Android Studio (latest stable) with NDK + CMake components installed.
- Min SDK 26, target/compile SDK 35.
- The device/emulator must be **arm64-v8a** (the only ABI `libavrdude2.so`
  was built for — `abiFilters` is set accordingly, so the app won't even
  install elsewhere).
- A copy of `avrdude.conf` matching this exact build (see below) — not
  included, see "avrdude.conf" section.

## Building

### Android Studio

1. Open the project root (this directory) in Android Studio.
2. Let it sync — it will prompt to install any missing NDK/CMake components.
3. Build & run on an arm64-v8a device or emulator.

### Command line / CI / Google Colab

A ready-to-run Colab notebook (`AvrdudeFrontend_Build.ipynb`, provided
alongside this project) installs the Android command-line tools + NDK,
generates the Gradle wrapper, and runs `./gradlew assembleDebug`, producing
a downloadable APK. Locally, the equivalent is:

```bash
sdkmanager "platform-tools" "platforms;android-35" "build-tools;35.0.0" "ndk;27.0.12077973" "cmake;3.22.1"
gradle wrapper --gradle-version 8.7   # if gradlew isn't already present
./gradlew assembleDebug
```

## `avrdude.conf`

AVRDUDE refuses to start without a usable `avrdude.conf` — it's the
compiled-in device/programmer database, not optional config. This project
deliberately does **not** bundle a guessed one (a version-mismatched file
fails in confusing ways). On first launch, go to **Settings → Import
avrdude.conf** and pick the file matching this exact build (from the
ArduinoDroid / `avrdude-arduinodroid2` source tree this `.so` came from).
Every operation checks for this first and fails with a clear, actionable
message if it's missing.

## In-app crash reporting

Since this app's own diagnostics (the Console panel) can't render for a
crash that happens during startup, `core/CrashHandler.kt` installs a
process-wide `Thread.UncaughtExceptionHandler` at the very start of
`AvrdudeApp.onCreate()`. Any uncaught crash, on any thread, is written to a
plain-text file (device/Android version, stack trace, everything) in
app-private storage before the process dies; the *next* launch shows it in
a dialog with Copy / Share / Dismiss, right from `MainActivity.onCreate()`,
before the normal UI even finishes setting up. No adb or PC required to get
a real stack trace off a device.

## Feature overview

- **Dashboard**: USB device detection + permission flow, programmer
  selection (any AVRDUDE `-c` id, with a curated quick-pick list),
  device info panel with signature auto-detect, HEX/ELF/BIN file selection
  via the Storage Access Framework, the full programming-operations button
  set, and a live progress panel.
- **Fuse Editor**: named, per-bit-field editing (not just raw hex) for
  parts covered by the built-in reference table, with plain-English
  explanations and a confirmation dialog before any change flagged
  dangerous (e.g. `RSTDISBL`, `SPIEN`, `DWEN`, `CKSEL` with no oscillator
  present). Parts not in the table still get full raw-byte editing.
- **Console**: every line AVRDUDE and the native bridge produce, with
  copy / save-to-file / clear / text+level filtering, color-coded by
  severity.
- **Settings**: dark mode, default programmer/MCU/baud, ISP clock, verify-
  after-write, chip-erase-before-write, safe mode, auto-reconnect, log
  saving, console font size, root-USB fallback, and the `avrdude.conf`
  importer.
- **Persistent bottom action toolbar**: Detect / Read / Write / Verify /
  Erase / EEPROM / Fuses / Stop, available from anywhere in the app.

## Project layout

```
app/src/main/cpp/          JNI bridge (C++): avrbridge.cpp, process_runner.*, jni_callback.*
app/src/main/jniLibs/      libavrdude2.so (as supplied) — arm64-v8a only
app/src/main/java/.../
  native/                  AvrdudeNativeBridge — the actual JNI boundary
  domain/                  Models + AvrdudeRepository interface (Clean Architecture)
  data/                    AvrdudeRepositoryImpl, argv builder, config/file/prefs, MCU reference DB
  usb/                     Android USB Host API integration
  presentation/            MVVM: Dashboard / Fuse Editor / Console / Settings
docs/ARCHITECTURE.md       Full design rationale (read this first)
docs/JNI_API.md            Every JNI function, both directions, documented
```

## What's verified vs. what needs real hardware

Verified by direct inspection of the supplied binary: that it has no
exported symbols, what it links against, and that it's genuinely AVRDUDE
(see `docs/ARCHITECTURE.md`). The process-spawning JNI mechanism
(`fork()`/`execve()`, pipe capture, JNI callback dispatch) is standard NDK
technique and doesn't depend on anything internal to this specific AVRDUDE
build. **Not** verified — because it requires the actual ARM64 binary
running against real programmer hardware, which wasn't available while
building this: the exact `-x`/env-var convention this fork's libusb backend
expects for fd-based USB access (see "USB access on unrooted Android" in
`docs/ARCHITECTURE.md`), and AVRDUDE's exact progress-meter text format
(the parser is heuristic and non-load-bearing — pass/fail is always the
process exit code, never parsed text). Start there if something doesn't
work on first run; the Console panel shows AVRDUDE's own raw output, which
is the fastest way to tell what's actually happening.
