# Architecture

## Start here: what `libavrdude2.so` actually is

Before writing any code, the supplied `libavrdude2.so` was inspected directly:

```
$ readelf -h libavrdude2.so | grep Type
  Type:                              DYN (Position-Independent Executable file)

$ nm -D --defined-only libavrdude2.so | wc -l
0

$ readelf -d libavrdude2.so | grep NEEDED
 (NEEDED) Shared library: [libm.so]
 (NEEDED) Shared library: [libdl.so]
 (NEEDED) Shared library: [libc.so]

$ strings libavrdude2.so | grep arduinodroid2
avrdude-arduinodroid2/...
```

Findings:

1. **It exports zero symbols.** `nm -D --defined-only` is empty. There is no
   `avrdude_init`, no `read_flash`, nothing a linker or `dlsym()` could bind
   to. A `.so` in the JNI sense — a library other code links against and
   calls functions in — needs exported symbols. This file has none.
2. **It only imports from libc/libm/libdl** and has a normal executable
   entry point (`main()`). In other words, it's a complete, statically-mostly
   linked command-line program (this build appears to statically link
   libusb, since there's no `NEEDED libusb*.so` entry, yet it does contain
   `libusb_*` strings).
3. **It's really AVRDUDE itself** — the embedded build paths trace back to
   `avrdude-arduinodroid2`, the ArduinoDroid project's AVRDUDE fork.

So why does it have a `.so` extension and live under `jniLibs/`? Because
Android's package installer extracts everything under `jniLibs/<abi>/` to
`ApplicationInfo.nativeLibraryDir` **with the executable bit set**, and
(unlike almost every other directory in an app's sandbox) that directory is
exempt from the W^X restrictions that otherwise block executing files an app
wrote itself. Naming a prebuilt CLI tool `lib<name>.so` and dropping it in
`jniLibs/` is a well-known, deliberate trick — including by ArduinoDroid
itself — to get a real executable onto disk, executable, without root. It
is not a JNI library in the technical sense at all.

**Practical consequence:** the spec asked for `readFlash()`, `writeFlash()`,
etc. to be individual native functions calling into `libavrdude2.so`. That
is not physically possible with this artifact — there is nothing to call.
What *is* possible, and what this project does, is described below.

## The real design

```
Kotlin (app code)
   │  calls AvrdudeRepository.readFlash(), .writeFlash(), .chipErase(), ...
   ▼
AvrdudeRepositoryImpl  (data/repository)
   │  builds an AVRDUDE argv for the operation (AvrdudeArgvBuilder)
   ▼
AvrdudeNativeBridge  (native/AvrdudeNativeBridge.kt)
   │  external fun nativeRunAvrdude(opId, args, envExtra, inheritFd, ...)
   ▼
================================ JNI boundary ================================
   ▼
libavrbridge.so   <-- OUR OWN compiled JNI library (app/src/main/cpp)
   │  avrbridge.cpp: real JNIEXPORT functions, actually exported, actually
   │  callable — unlike libavrdude2.so.
   │
   │  process_runner.cpp: fork()+execve()s libavrdude2.so as a child
   │  process (NOT dlopen — there's nothing to dlopen for; NOT posix_spawn()
   │  either — bionic didn't add that until API 34, and minSdk here is 26).
   │  No shell, no `sh -c`, argv passed directly. Captures the child's
   │  stdout/stderr via pipes on a dedicated reader thread.
   │
   │  jni_callback.cpp: attaches that reader thread to the JVM and calls
   │  back into Kotlin (AvrdudeNativeBridge's @JvmStatic on... methods) with
   │  each line, plus progress/warning/error classification and the final
   │  exit code.
   ▼
libavrdude2.so   <-- runs as an ordinary child process, exactly like the
                     real, standalone AVRDUDE program it is.
```

Every operation the app exposes (`readFlash`, `writeFlash`, `chipErase`,
`readFuse`, ...) is implemented as: build the right AVRDUDE command-line
arguments for that operation (`AvrdudeArgvBuilder`), then run that argv
through the one shared native execution primitive
(`AvrdudeNativeBridge.nativeRunAvrdude`). This isn't a shortcut — it reflects
reality: AVRDUDE's own architecture models every one of these operations as
`-U <memtype>:<op>:<file>[:format]` arguments to the same program entry
point, and the supplied binary has no finer-grained internal API to call
into even in principle.

The **native boundary** (`libavrbridge.so`) is intentionally small and
generic (`nativeInitialize`, `nativeRunAvrdude`, `nativeCancel`, ...) — see
`docs/JNI_API.md` for the full list. The **Kotlin API surface**
(`AvrdudeRepository`) is what actually exposes `initialize()`,
`readSignature()`, `chipErase()`, `readFlash()`, `writeFlash()`,
`verifyFlash()`, `readEEPROM()`, `writeEEPROM()`, `verifyEEPROM()`,
`readFuse()`, `writeFuse()`, `readLockBits()`, `writeLockBits()`,
`readCalibration()`, `cancelOperation()` — every one of the operations in
the spec — as distinct, real Kotlin functions with distinct behavior. The
app and its ViewModels never see the process-spawning detail; they only see
`Result<T>` and `Flow`/`StateFlow` updates.

## Why not `dlopen()` the AVRDUDE binary directly?

`dlopen()` loads a shared object and lets you resolve symbols in it via
`dlsym()`. Since `libavrdude2.so` exports none, there'd be nothing to
`dlsym()` afterward — `dlopen()` would (at best) map the file into memory
and do nothing useful, or fail outright since it isn't built as a proper
shared object (no meaningful `.dynamic` entries for library consumption,
just an executable's). Executing it as a **process**, the way any shell or
the OS process loader would, is the only mechanism that actually runs the
program the file contains. That's what `fork()` + `execve()` semantics
give us, and it's what `process_runner.cpp` does — `posix_spawn()` would
be the more modern equivalent, but it isn't available on bionic until
API 34, well above this project's minSdk 26.

## Threading and lifecycle

- Only **one AVRDUDE invocation runs at a time** (`ProcessRunner` rejects a
  second `start()` while one is in flight). This matches reality: a
  programmer connection — USB or serial — cannot be shared between two
  concurrent AVRDUDE processes.
- The reader thread that drains the child's stdout/stderr pipes is a plain
  `std::thread`, attached to the JVM only for the duration of each callback
  (`ThreadAttachGuard`), and detached again immediately after — it is never
  left permanently attached.
- `cancelOperation()` sends `SIGINT` first (giving AVRDUDE a chance to
  leave the programmer in a clean state), escalating to `SIGTERM` then
  `SIGKILL` if the child hasn't exited within a short grace period.
- `AvrdudeApp.onTerminate()` calls `shutdown()`, which cancels any running
  operation and joins the reader thread before the process state is
  cleared, so there are no dangling native threads or leaked fds across app
  restarts.

## `avrdude.conf`

AVRDUDE will not run without a usable `avrdude.conf` — it's not optional
configuration, it's the compiled-in device/programmer database AVRDUDE
parses every part and programmer definition from at startup. This project
deliberately does **not** bundle a guessed one: a version-mismatched
`avrdude.conf` fails in confusing ways (parse errors, or worse, silently
wrong part definitions) rather than a clean "file missing" error. Instead,
Settings → **Import avrdude.conf** copies a user-supplied file (obtained
from the same ArduinoDroid/`avrdude-arduinodroid2` source this binary was
built from) into app-private storage via the Storage Access Framework —
`AvrdudeConfigProvider` — since AVRDUDE needs a real filesystem path, not a
`content://` URI.

## USB access on unrooted Android

AVRDUDE's libusb backend normally opens a device by enumerating the USB bus
directly (`libusb_open()`), which requires root on Android. The standard
non-root workaround (used by ArduinoDroid and other similar tools) is
`libusb_wrap_sys_device()` (libusb ≥ 1.0.23), which lets libusb adopt an
**already-open** file descriptor — obtained the Android way, via
`UsbManager.requestPermission()` + `UsbDeviceConnection.getFileDescriptor()`
— instead of opening the device itself.

This project implements the Android-side half of that in full
(`UsbPermissionManager`): permission request flow, `UsbDeviceConnection`,
and handing the resulting fd down through `nativeRunAvrdude`'s `inheritFd`
parameter, which `process_runner.cpp` `dup2()`s into the child at a fixed
fd number (default 63) before `exec`, alongside an `AVRDUDE_USB_FD`
environment variable as a second, best-effort convention.

**What is not verified:** whether *this specific compiled fork* actually
honors either of those conventions, and if so under what exact flag/env-var
name — that depends on patches inside `avrdude-arduinodroid2`'s USB backend
that aren't visible from the outside of a stripped binary. If USB access
doesn't work out of the box, the console output (AVRDUDE's own libusb error
text) is the fastest way to tell whether it's a permission problem, a
port-string problem, or something this build genuinely doesn't support —
and `AvrdudeArgvBuilder`/`ConnectionParams.port` is the single place to
adjust the convention once you know it. The Settings → "Use root for USB
access" toggle is the unconditionally-correct fallback on a rooted device:
it addresses the programmer by its raw `/dev/bus/usb/BBB/DDD` path instead,
which any unpatched libusb build can open given root.

## Layering

- **`native/`** — the JNI boundary (`AvrdudeNativeBridge`) and its Kotlin
  callback surface. Deliberately low-level and process-shaped.
- **`domain/`** — pure Kotlin models and the `AvrdudeRepository` interface.
  No Android or JNI types leak in here except where genuinely part of the
  domain (e.g. `Flow`/`StateFlow`).
- **`data/`** — `AvrdudeRepositoryImpl` (the real implementation),
  `AvrdudeArgvBuilder` (AVRDUDE CLI construction), `AvrdudeConfigProvider`,
  `FileManager` (SAF), `AppPreferences` (DataStore), `McuDatabase` (offline
  reference data).
- **`presentation/`** — MVVM: one `ViewModel` + `Fragment` per screen
  (Dashboard, Fuse Editor, Console, Settings), all state exposed as
  `StateFlow`, all one-off UI events (dialogs, snackbars) as a separate
  `SharedFlow` so they aren't replayed on rotation.
- **`di/ServiceLocator`** — a small manual DI container. The object graph
  here is static and small enough that Hilt/Dagger would add ceremony
  without buying much; swapping one in later wouldn't require touching any
  `ViewModel`.

## Known limitations / what to verify on real hardware

- The exact `-x` extended-option names for retry count / timeout are
  backend-specific and not universally defined by AVRDUDE; Settings exposes
  them, but not every programmer backend honors them (see
  `docs/JNI_API.md`).
- Progress percentage parsing (both the native best-effort parse in
  `avrbridge.cpp` and the console text itself) is heuristic, since
  AVRDUDE's progress-meter text format has varied across versions. It is
  not load-bearing for correctness — the pass/fail result of every
  operation comes from the process exit code, not from parsed progress
  text.
- This was built and reasoned about without the ability to run the actual
  ARM64 binary (a sandboxed x86_64 environment with no Android device was
  used to develop it) — treat first-run behavior against real hardware as
  the real integration test, and check the Console panel's raw AVRDUDE
  output first if something doesn't work.
