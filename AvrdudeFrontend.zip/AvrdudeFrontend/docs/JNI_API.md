# JNI API Reference

This documents every function crossing the JNI boundary in both directions:
the `external fun`s Kotlin calls into native code with, and the `@JvmStatic`
callbacks native code calls back into Kotlin with. All of it lives in
`native/AvrdudeNativeBridge.kt` (Kotlin side) and `app/src/main/cpp/avrbridge.cpp`
+ `jni_callback.cpp` (native side). See `docs/ARCHITECTURE.md` first for why
the boundary is shaped this way (a small set of process-execution primitives,
not one native symbol per AVRDUDE operation).

Class: `com.avrdude.frontend.native.AvrdudeNativeBridge` (a Kotlin `object`;
every member below is `@JvmStatic`, so each resolves to a real static native
method / static callback method in the JVM sense — not an instance method on
a singleton).

---

## Kotlin → Native (`external fun`)

### `nativeInitialize(nativeLibDir: String, workDir: String): Boolean`

Resolves and validates the path to the extracted `libavrdude2.so`
(`nativeLibDir + "/libavrdude2.so"`), storing it for subsequent calls.

- `nativeLibDir` **must** be `context.applicationInfo.nativeLibraryDir` —
  the directory PackageManager actually extracted native libraries into.
  This only contains a real, executable file because the app manifest sets
  `android:extractNativeLibs="true"` (and `packaging.jniLibs.useLegacyPackaging
  = true` in `app/build.gradle.kts`) — without that, native libraries are
  mapped straight out of the APK zip and no standalone executable file
  exists on disk to run.
- `workDir` is a private, writable directory for temp files (pass
  `context.filesDir.absolutePath`).
- Returns `false` if the file is missing or not executable (checked via
  `access(path, X_OK)`), logging the reason through the debug-callback
  channel (`onDebugMessage`) rather than throwing.
- Idempotent — safe to call again (e.g. after importing `avrdude.conf`,
  which doesn't require re-initializing the bridge, but doesn't hurt).

### `nativeShutdown(): Unit`

Cancels any in-flight operation (see `nativeCancel`), blocks until its
reader thread has exited, then clears the resolved executable path. Called
from `AvrdudeApp.onTerminate()`.

### `nativeGetExecutablePath(): String`

Returns the path resolved by the last successful `nativeInitialize()` call,
or an empty string if not initialized. Mainly useful for diagnostics /
Settings display.

### `nativeRunAvrdude(opId: Int, args: Array<String>, envExtra: Array<String>, inheritFd: Int, inheritFdTarget: Int): Boolean`

The single generic execution primitive every AVRDUDE-backed operation in the
app funnels through. Spawns `libavrdude2.so` as a child process with
`argv = [executablePath] + args` via `fork()`+`execve()` (no shell —
posix_spawn() isn't available until bionic API 34, above this project's
minSdk 26).

- `opId` — an opaque token the Kotlin caller assigns (via
  `AvrdudeNativeBridge.nextOpId()`) so the asynchronous callbacks below can
  be correlated back to the right call site / coroutine. Not interpreted by
  native code beyond echoing it back in every callback.
- `args` — AVRDUDE command-line arguments (not including argv[0]); see
  `data/repository/AvrdudeArgvBuilder.kt` for how each high-level operation
  builds this.
- `envExtra` — additional `"KEY=VALUE"` environment entries appended to the
  child's environment (inherited from the app process otherwise). Used for
  `AVRDUDE_USB_FD=<n>` (see `inheritFd` below).
- `inheritFd` / `inheritFdTarget` — if `inheritFd >= 0`, that already-open,
  permission-granted file descriptor (from `UsbDeviceConnection.getFileDescriptor()`)
  is `dup2()`'d into the child at fd number `inheritFdTarget` (default 63)
  before `exec`, for libusb fd-based device access. Pass `-1` to skip this
  (serial-backed programmers, or root-based raw device-path access instead).
- **Return value** is whether the spawn itself started — *not* the
  eventual result. The actual outcome arrives asynchronously as an
  `onOperationFinished` callback for the same `opId`.
- Fails immediately (returns `false`, with an `onError` callback) if another
  operation is already running, or if `nativeInitialize()` hasn't succeeded.

### `nativeCancel(): Boolean`

Requests cancellation of whichever operation is currently running (`SIGINT`,
escalating to `SIGTERM` then `SIGKILL` if it doesn't exit within ~1s/~3s).
Returns `false` if nothing is running. Safe to call from any thread.

### `nativeIsRunning(): Boolean`

True while a child AVRDUDE process is active.

---

## Native → Kotlin (callbacks, `@JvmStatic fun on...`)

These are called *from* native code (`jni_callback.cpp`, via cached
`GetStaticMethodID` results) on the operation's dedicated reader thread —
**never on the main/UI thread**, and never on the thread that called
`nativeRunAvrdude`. Each simply pushes an `OperationEvent` into
`AvrdudeNativeBridge.events` (a `MutableSharedFlow`), which
`AvrdudeRepositoryImpl` collects and turns into `Result<T>` / `StateFlow`
updates for the rest of the app. `tryEmit` is used throughout since these
calls are not inside a coroutine.

Renaming, retyping, or reordering the parameters of any of these **must**
be mirrored exactly in `jni_callback.cpp`'s `GetStaticMethodID` signature
strings, or native → Kotlin calls will silently no-op (an error is logged
to logcat via `jniCallback_init`, but nothing crashes).

### `onConsoleLine(opId: Int, source: Int, line: String)`

One line of output from the AVRDUDE child process. `source` is `0` for
stdout, `1` for stderr (kept as a plain `Int` across the JNI boundary
rather than a Kotlin enum, to avoid an enum-marshaling layer for a two-value
tag). Every line AVRDUDE prints — its log messages, `avrdude: ...` status
lines, error text — arrives here.

### `onProgress(opId: Int, percent: Int, message: String)`

Best-effort progress extraction (native-side regex-free scan for digits
immediately followed by `%` in a console line — see `tryParsePercent` in
`avrbridge.cpp`). Fired in addition to, not instead of, `onConsoleLine` for
the same line — the underlying text still reaches the console too.

### `onWarning(opId: Int, message: String)` / `onError(opId: Int, message: String)`

Best-effort severity classification of a console line (case-insensitive
match for `"warning"` / `"error"`/`"fatal"`), fired alongside
`onConsoleLine` for lines that match. This is a convenience for UI styling
(e.g. tinting the Console panel) — it is **not** what determines
success/failure of an operation; that's the process exit code delivered via
`onOperationFinished`.

### `onOperationFinished(opId: Int, exitCode: Int, cancelled: Boolean)`

Fired exactly once per `nativeRunAvrdude` call, when the child process has
been fully reaped (`waitpid`). `exitCode` is the process's real exit code
(`0` = success, by AVRDUDE's own convention); `cancelled` is `true` if
`nativeCancel()` was called for this operation. This is the only signal
`AvrdudeRepositoryImpl` treats as authoritative for whether an operation
succeeded.

### `onDebugMessage(message: String)`

Bridge-level diagnostics not tied to any specific operation (e.g.
`nativeInitialize` failures). Surfaced separately from per-operation
console output via `AvrdudeNativeBridge.debugLog`.

---

## Kotlin-level operations built on top of this boundary

For reference, every operation named in the project spec — implemented in
`AvrdudeRepositoryImpl`, on top of the primitives above:

| Kotlin function | AVRDUDE argv shape (via `AvrdudeArgvBuilder`) |
|---|---|
| `initialize()` | *(native init only, no AVRDUDE invocation)* |
| `getVersion()` | `-v -c ?` (banner + programmer list) |
| `listSupportedProgrammers()` | `-c ?` |
| `listSupportedDevices()` | `-p ?` |
| `connect()` | connection flags only, `-n` (no-op dry run) |
| `readSignature()` | `-U signature:r:<tmpfile>:r`, `-F` forced |
| `chipErase()` | `-e` |
| `readFlash()` / `writeFlash()` / `verifyFlash()` | `-U flash:r\|w\|v:<file>:<fmt>` |
| `readEEPROM()` / `writeEEPROM()` / `verifyEEPROM()` | `-U eeprom:r\|w\|v:<file>:<fmt>` |
| `readFuse()` / `writeFuse()` | `-U lfuse\|hfuse\|efuse\|fuse:r:<tmpfile>:r` or `:w:<hex>:m` |
| `readLockBits()` / `writeLockBits()` | `-U lock:r:<tmpfile>:r` or `:w:<hex>:m` |
| `readCalibration()` | `-U calibration:r:<tmpfile>:r` |
| `cancelOperation()` | → `nativeCancel()` directly |

Every flag here is AVRDUDE's own public, documented command-line vocabulary
(see AVRDUDE's manual page) — nothing here is invented syntax.
