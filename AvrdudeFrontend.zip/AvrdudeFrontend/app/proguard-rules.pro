# Keep native bridge class + callback interfaces intact: their method signatures
# are referenced by name from JNI (avrbridge.cpp), so renaming/obfuscation would
# break the native <-> Kotlin binding silently at runtime instead of compile time.
-keep class com.avrdude.frontend.native.AvrdudeNativeBridge { *; }
-keep interface com.avrdude.frontend.native.NativeCallbacks { *; }
-keep class com.avrdude.frontend.native.** { *; }
-keepclasseswithmembernames class * {
    native <methods>;
}
