// avrbridge.cpp
//
// This file is the actual JNI boundary: every JNIEXPORT function here is
// real, exported, and callable from Kotlin — unlike libavrdude2.so, which
// exports nothing (see docs/ARCHITECTURE.md for how that was verified).
//
// Design: rather than one native symbol per high-level AVRDUDE operation
// (readFlash, writeFlash, chipErase, ...), there is a single generic
// nativeRunAvrdude() primitive that spawns libavrdude2.so with a caller-built
// argv. This is not a shortcut — it reflects reality: AVRDUDE's own
// architecture models every one of those operations as "-U <memtype>:<op>:
// <file>[:format]" command-line arguments to the *same* program entry point,
// and the supplied binary has no finer-grained internal API to call into
// even in principle. The Kotlin-level AvrdudeEngine class (data/repository
// layer) is what exposes the distinct initialize()/readFlash()/writeFlash()/
// chipErase()/... methods the app and its callers actually see; each one
// builds the right argv for that specific operation and calls through this
// same native primitive. That keeps the *native* boundary small, honest, and
// easy to audit, while the *Kotlin* API surface matches the requested shape
// exactly.
#include <jni.h>
#include <string>
#include <vector>
#include <mutex>
#include <unistd.h>
#include <cctype>
#include <cstdlib>

#include "process_runner.h"
#include "jni_callback.h"
#include "log.h"

using avrbridge::ProcessRunner;
using avrbridge::SpawnRequest;
using avrbridge::StreamSource;

namespace {

std::mutex g_stateMutex;
std::string g_exePath;      // resolved path to the extracted libavrdude2.so
std::string g_workDir;      // app-private writable dir for temp files/pipes
ProcessRunner g_runner;

std::string jstringToStd(JNIEnv* env, jstring s) {
    if (s == nullptr) return {};
    const char* chars = env->GetStringUTFChars(s, nullptr);
    std::string result(chars ? chars : "");
    if (chars) env->ReleaseStringUTFChars(s, chars);
    return result;
}

std::vector<std::string> jstringArrayToVector(JNIEnv* env, jobjectArray arr) {
    std::vector<std::string> out;
    if (arr == nullptr) return out;
    jsize len = env->GetArrayLength(arr);
    out.reserve(static_cast<size_t>(len));
    for (jsize i = 0; i < len; ++i) {
        auto jstr = reinterpret_cast<jstring>(env->GetObjectArrayElement(arr, i));
        out.push_back(jstringToStd(env, jstr));
        if (jstr) env->DeleteLocalRef(jstr);
    }
    return out;
}

// Best-effort in-native progress extraction so a Flow<Int> can update even
// before Kotlin's own (more format-tolerant) regex parse runs on the same
// line. Looks for a run of digits immediately followed by '%'.
bool tryParsePercent(const std::string& line, int* outPercent) {
    for (size_t i = 0; i < line.size(); ++i) {
        if (line[i] == '%' && i > 0) {
            size_t start = i;
            while (start > 0 && std::isdigit(static_cast<unsigned char>(line[start - 1]))) --start;
            if (start < i) {
                int value = std::atoi(line.substr(start, i - start).c_str());
                if (value >= 0 && value <= 100) {
                    *outPercent = value;
                    return true;
                }
            }
        }
    }
    return false;
}

bool containsCaseInsensitive(const std::string& haystack, const char* needle) {
    std::string lower = haystack;
    for (auto& c : lower) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    return lower.find(needle) != std::string::npos;
}

} // namespace

extern "C" {

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* /*reserved*/) {
    avrbridge::jniCallback_init(vm);
    LOGI("libavrbridge loaded, JNI_OnLoad complete");
    return JNI_VERSION_1_6;
}

// boolean nativeInitialize(String nativeLibDir, String workDir)
//
// nativeLibDir must be ApplicationInfo.nativeLibraryDir from Kotlin — the
// directory PackageManager actually extracted libavrdude2.so into. This only
// contains a real, executable file because the app is built with
// android:extractNativeLibs="true" (see app/build.gradle.kts comment on
// packaging.jniLibs.useLegacyPackaging).
JNIEXPORT jboolean JNICALL
Java_com_avrdude_frontend_native_AvrdudeNativeBridge_nativeInitialize(
        JNIEnv* env, jclass, jstring nativeLibDir, jstring workDir) {
    std::lock_guard<std::mutex> lock(g_stateMutex);
    std::string dir = jstringToStd(env, nativeLibDir);
    g_exePath = dir + "/libavrdude2.so";
    g_workDir = jstringToStd(env, workDir);

    if (access(g_exePath.c_str(), F_OK) != 0) {
        avrbridge::callback_onDebug("nativeInitialize: libavrdude2.so not found at " + g_exePath);
        return JNI_FALSE;
    }
    if (access(g_exePath.c_str(), X_OK) != 0) {
        avrbridge::callback_onDebug("nativeInitialize: libavrdude2.so exists but is not executable at " + g_exePath +
                                     " — check extractNativeLibs=true and legacy jniLibs packaging");
        return JNI_FALSE;
    }
    avrbridge::callback_onDebug("nativeInitialize: OK, executable resolved to " + g_exePath);
    return JNI_TRUE;
}

JNIEXPORT void JNICALL
Java_com_avrdude_frontend_native_AvrdudeNativeBridge_nativeShutdown(JNIEnv*, jclass) {
    g_runner.cancel();
    g_runner.waitForCompletion();
    std::lock_guard<std::mutex> lock(g_stateMutex);
    g_exePath.clear();
    g_workDir.clear();
}

JNIEXPORT jstring JNICALL
Java_com_avrdude_frontend_native_AvrdudeNativeBridge_nativeGetExecutablePath(JNIEnv* env, jclass) {
    std::lock_guard<std::mutex> lock(g_stateMutex);
    return env->NewStringUTF(g_exePath.c_str());
}

// boolean nativeRunAvrdude(int opId, String[] args, String[] envExtra,
//                           int inheritFd, int inheritFdTarget)
//
// Spawns libavrdude2.so with argv = [exePath, args...]. Returns whether the
// spawn itself succeeded (i.e. the operation started) — NOT the eventual
// exit code, which arrives asynchronously via onOperationFinished(opId, ...).
// opId is an opaque token Kotlin assigns per call so callbacks (which may
// interleave if, hypothetically, misused concurrently) can be routed back to
// the right coroutine/Flow collector.
JNIEXPORT jboolean JNICALL
Java_com_avrdude_frontend_native_AvrdudeNativeBridge_nativeRunAvrdude(
        JNIEnv* env, jclass, jint opId, jobjectArray args, jobjectArray envExtra,
        jint inheritFd, jint inheritFdTarget) {
    std::string exePath;
    {
        std::lock_guard<std::mutex> lock(g_stateMutex);
        exePath = g_exePath;
    }
    if (exePath.empty()) {
        avrbridge::callback_onError(opId, "Native bridge not initialized — call initialize() first");
        return JNI_FALSE;
    }

    SpawnRequest request;
    request.executablePath = exePath;
    request.args = jstringArrayToVector(env, args);
    request.environment = jstringArrayToVector(env, envExtra);
    request.inheritFd = inheritFd;
    request.inheritFdTarget = inheritFdTarget;

    int opIdCopy = opId; // captured by value into the lambdas below

    bool started = g_runner.start(
        request,
        [opIdCopy](StreamSource source, const std::string& line) {
            int sourceInt = (source == StreamSource::STDOUT) ? 0 : 1;
            avrbridge::callback_onConsoleLine(opIdCopy, sourceInt, line);

            int percent;
            if (tryParsePercent(line, &percent)) {
                avrbridge::callback_onProgress(opIdCopy, percent, line);
            }
            // Best-effort classification. AVRDUDE's own message severity
            // prefixes (varies by version, e.g. "avrdude: warning: ...") make
            // this reliable in practice; Kotlin re-derives severity from the
            // same text for display styling rather than trusting only this.
            if (containsCaseInsensitive(line, "error") || containsCaseInsensitive(line, "fatal")) {
                avrbridge::callback_onError(opIdCopy, line);
            } else if (containsCaseInsensitive(line, "warning")) {
                avrbridge::callback_onWarning(opIdCopy, line);
            }
        },
        [opIdCopy](int exitCode, bool cancelled) {
            avrbridge::callback_onOperationFinished(opIdCopy, exitCode, cancelled);
        });

    if (!started) {
        avrbridge::callback_onError(opId, "Failed to start AVRDUDE process (already running, or spawn failed)");
    }
    return started ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL
Java_com_avrdude_frontend_native_AvrdudeNativeBridge_nativeCancel(JNIEnv*, jclass) {
    if (!g_runner.isRunning()) return JNI_FALSE;
    g_runner.cancel();
    return JNI_TRUE;
}

JNIEXPORT jboolean JNICALL
Java_com_avrdude_frontend_native_AvrdudeNativeBridge_nativeIsRunning(JNIEnv*, jclass) {
    return g_runner.isRunning() ? JNI_TRUE : JNI_FALSE;
}

} // extern "C"
