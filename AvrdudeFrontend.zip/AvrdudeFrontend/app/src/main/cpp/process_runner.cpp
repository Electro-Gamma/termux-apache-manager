#include "process_runner.h"
#include "line_reader.h"
#include "log.h"

#include <cerrno>
#include <cstring>
#include <csignal>
#include <poll.h>
#include <spawn.h>
#include <sys/wait.h>
#include <unistd.h>
#include <fcntl.h>

extern char** environ;

namespace avrbridge {

namespace {

// Builds a NUL-terminated char* array from a vector<string>. The returned
// vector of pointers stays valid only as long as `storage` (the source
// strings) is not mutated/destroyed — the caller must keep `storage` alive
// for the lifetime of the returned pointer array.
std::vector<char*> toArgv(const std::vector<std::string>& storage) {
    std::vector<char*> argv;
    argv.reserve(storage.size() + 1);
    for (const auto& s : storage) {
        // posix_spawn's argv is declared char* const[] but does not modify
        // the strings; const_cast is the standard, safe workaround.
        argv.push_back(const_cast<char*>(s.c_str()));
    }
    argv.push_back(nullptr);
    return argv;
}

} // namespace

ProcessRunner::~ProcessRunner() {
    if (isRunning()) {
        cancel();
    }
    if (worker_.joinable()) {
        worker_.join();
    }
}

bool ProcessRunner::isRunning() const {
    return running_.load();
}

bool ProcessRunner::start(const SpawnRequest& request, LineCallback onLine, ExitCallback onExit) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (running_.load()) {
        LOGW("start() rejected: an AVRDUDE operation is already running (pid=%d)", childPid_.load());
        return false;
    }
    if (worker_.joinable()) {
        worker_.join(); // reap the previous run's reader thread before starting a new one
    }

    // --- Build argv: argv[0] is conventionally the program path itself ---
    std::vector<std::string> argvStorage;
    argvStorage.push_back(request.executablePath);
    for (const auto& a : request.args) argvStorage.push_back(a);
    std::vector<char*> argv = toArgv(argvStorage);

    // --- Build envp: start from the app process's own environment (so the
    //     dynamic linker's LD_LIBRARY_PATH etc. still applies) and append
    //     any caller-supplied overrides (e.g. AVRDUDE_USB_FD=63). ---
    std::vector<std::string> envStorage;
    for (char** e = environ; *e != nullptr; ++e) envStorage.emplace_back(*e);
    for (const auto& kv : request.environment) envStorage.push_back(kv);
    std::vector<char*> envp = toArgv(envStorage);

    // --- Pipes for capturing the child's stdout/stderr ---
    int outPipe[2];
    int errPipe[2];
    if (pipe(outPipe) != 0 || pipe(errPipe) != 0) {
        LOGE("pipe() failed: %s", strerror(errno));
        return false;
    }

    posix_spawn_file_actions_t actions;
    posix_spawn_file_actions_init(&actions);
    // Child's stdout/stderr -> write end of our pipes.
    posix_spawn_file_actions_adddup2(&actions, outPipe[1], STDOUT_FILENO);
    posix_spawn_file_actions_adddup2(&actions, errPipe[1], STDERR_FILENO);
    // Close the fds the child doesn't need (both pipes' original fds, and
    // the read ends specifically, since dup2 above already gave it what it
    // needs on fd 1/2).
    posix_spawn_file_actions_addclose(&actions, outPipe[0]);
    posix_spawn_file_actions_addclose(&actions, outPipe[1]);
    posix_spawn_file_actions_addclose(&actions, errPipe[0]);
    posix_spawn_file_actions_addclose(&actions, errPipe[1]);

    // Optionally hand down an already-permission-granted USB device fd
    // (see docs/ARCHITECTURE.md, "USB access on unrooted Android").
    if (request.inheritFd >= 0) {
        posix_spawn_file_actions_adddup2(&actions, request.inheritFd, request.inheritFdTarget);
    }

    pid_t pid = -1;
    int rc = posix_spawn(&pid, request.executablePath.c_str(), &actions, nullptr, argv.data(), envp.data());
    posix_spawn_file_actions_destroy(&actions);

    // Parent no longer needs the write ends (child holds its own dup'd copy).
    close(outPipe[1]);
    close(errPipe[1]);

    if (rc != 0) {
        LOGE("posix_spawn() failed for %s: %s", request.executablePath.c_str(), strerror(rc));
        close(outPipe[0]);
        close(errPipe[0]);
        return false;
    }

    LOGI("spawned AVRDUDE child pid=%d exe=%s", pid, request.executablePath.c_str());
    childPid_.store(pid);
    cancelRequested_.store(false);
    running_.store(true);

    worker_ = std::thread(&ProcessRunner::readerThreadMain, this, outPipe[0], errPipe[0], pid, onLine, onExit);
    return true;
}

void ProcessRunner::readerThreadMain(int stdoutFd, int stderrFd, pid_t childPid,
                                      LineCallback onLine, ExitCallback onExit) {
    LineReader outReader, errReader;
    bool outOpen = true, errOpen = true;
    char buf[4096];

    // Non-blocking so poll() timeouts let us notice a cancel() request even
    // if the child has gone silent (e.g. waiting on a USB timeout).
    fcntl(stdoutFd, F_SETFL, fcntl(stdoutFd, F_GETFL) | O_NONBLOCK);
    fcntl(stderrFd, F_SETFL, fcntl(stderrFd, F_GETFL) | O_NONBLOCK);

    while (outOpen || errOpen) {
        struct pollfd fds[2];
        int nfds = 0;
        int outIdx = -1, errIdx = -1;
        if (outOpen) { fds[nfds] = {stdoutFd, POLLIN, 0}; outIdx = nfds++; }
        if (errOpen) { fds[nfds] = {stderrFd, POLLIN, 0}; errIdx = nfds++; }

        int pr = poll(fds, nfds, 200 /* ms — also our cancel-check cadence */);
        if (pr < 0) {
            if (errno == EINTR) continue;
            LOGE("poll() failed: %s", strerror(errno));
            break;
        }

        if (outIdx >= 0 && (fds[outIdx].revents & (POLLIN | POLLHUP | POLLERR))) {
            ssize_t n = read(stdoutFd, buf, sizeof(buf));
            if (n > 0) {
                for (auto& line : outReader.feed(buf, static_cast<size_t>(n))) {
                    onLine(StreamSource::STDOUT, line);
                }
            } else {
                for (auto& line : outReader.flush()) onLine(StreamSource::STDOUT, line);
                outOpen = false;
            }
        }
        if (errIdx >= 0 && (fds[errIdx].revents & (POLLIN | POLLHUP | POLLERR))) {
            ssize_t n = read(stderrFd, buf, sizeof(buf));
            if (n > 0) {
                for (auto& line : errReader.feed(buf, static_cast<size_t>(n))) {
                    onLine(StreamSource::STDERR, line);
                }
            } else {
                for (auto& line : errReader.flush()) onLine(StreamSource::STDERR, line);
                errOpen = false;
            }
        }

        if (cancelRequested_.load()) {
            // Escalate: SIGINT first so AVRDUDE can attempt a clean
            // programmer disconnect (some backends re-enable RESET / leave
            // ISP mode gracefully on SIGINT), then SIGTERM, then SIGKILL.
            kill(childPid, SIGINT);
        }
    }

    close(stdoutFd);
    close(stderrFd);

    // Reap the child, escalating signals if cancel() was requested and it's
    // not exiting promptly on its own.
    int status = 0;
    bool cancelled = cancelRequested_.load();
    int waited = 0;
    while (true) {
        pid_t r = waitpid(childPid, &status, WNOHANG);
        if (r == childPid) break;
        if (r < 0) { LOGE("waitpid failed: %s", strerror(errno)); break; }
        usleep(50 * 1000);
        waited += 50;
        if (cancelled && waited == 1000) kill(childPid, SIGTERM);
        if (cancelled && waited == 3000) kill(childPid, SIGKILL);
    }

    int exitCode = WIFEXITED(status) ? WEXITSTATUS(status) : -1;
    LOGI("AVRDUDE child pid=%d exited, code=%d cancelled=%d", childPid, exitCode, cancelled);

    childPid_.store(-1);
    running_.store(false);
    onExit(exitCode, cancelled);
}

void ProcessRunner::cancel() {
    if (!running_.load()) return;
    LOGI("cancel() requested for pid=%d", childPid_.load());
    cancelRequested_.store(true);
}

void ProcessRunner::waitForCompletion() {
    if (worker_.joinable()) {
        worker_.join();
    }
}

} // namespace avrbridge
