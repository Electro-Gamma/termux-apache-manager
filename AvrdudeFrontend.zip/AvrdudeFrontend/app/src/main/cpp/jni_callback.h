// jni_callback.h
//
// The AVRDUDE child process's output is read on a native reader thread that
// the JVM knows nothing about. To call back into Kotlin (AvrdudeNativeBridge's
// @JvmStatic callback methods) from that thread, the thread must first
// AttachCurrentThread() to the JavaVM, and should DetachCurrentThread() when
// done to avoid leaking a permanently-attached JNIEnv.
//
// This header centralizes: caching the JavaVM* and method IDs in JNI_OnLoad,
// a RAII thread-attach guard, and the actual callback-dispatch functions used
// by process_runner's reader thread.
#pragma once
#include <jni.h>
#include <string>

namespace avrbridge {

// Call once from JNI_OnLoad.
void jniCallback_init(JavaVM* vm);

// RAII helper: attaches the calling native thread to the JVM for its
// lifetime, detaching automatically on scope exit. Safe to nest with an
// already-attached thread (e.g. calls made directly from a JNI-entry thread
// that the JVM attached itself) — in that case it is a no-op attach/detach.
class ThreadAttachGuard {
public:
    ThreadAttachGuard();
    ~ThreadAttachGuard();
    JNIEnv* env() const { return env_; }
    ThreadAttachGuard(const ThreadAttachGuard&) = delete;
    ThreadAttachGuard& operator=(const ThreadAttachGuard&) = delete;

private:
    JNIEnv* env_ = nullptr;
    bool didAttach_ = false;
};

// source: 0 = stdout, 1 = stderr (kept as a plain int across the JNI
// boundary to avoid needing a Kotlin enum <-> native enum marshaling layer).
void callback_onConsoleLine(int opId, int source, const std::string& line);
void callback_onProgress(int opId, int percent, const std::string& message);
void callback_onOperationFinished(int opId, int exitCode, bool cancelled);
void callback_onWarning(int opId, const std::string& message);
void callback_onError(int opId, const std::string& message);
void callback_onDebug(const std::string& message);

} // namespace avrbridge
