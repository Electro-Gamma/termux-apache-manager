// process_runner.h
//
// Manages exactly one AVRDUDE child process invocation at a time (AVRDUDE
// itself is exclusive about programmer access, so serializing operations is
// both simpler and correct). Responsible for:
//   - spawning libavrdude2.so as a child process with a caller-supplied argv,
//     using fork() + execve(). posix_spawn() would be the more modern choice,
//     but bionic (Android's libc) didn't add it until API 34, and this
//     project's minSdk is 26 — so classic fork()+execve() it is, which is
//     exactly what Android's own Runtime.exec()/ProcessBuilder used
//     internally for its entire history before posix_spawn existed. Safety
//     is preserved the standard way: argv/envp are fully built in the
//     parent *before* fork(), and the child calls nothing but
//     async-signal-safe functions (dup2/close/execve/_exit) between fork()
//     and exec(),
//   - streaming the child's stdout and stderr back line-by-line through a
//     caller-supplied callback, from a dedicated reader thread,
//   - tracking the child's pid so an in-flight operation can be cancelled,
//   - reporting the child's exit code once it terminates.
//
// Thread-safety: only one ProcessRunner instance is used app-wide (owned by
// the JNI layer), and start() rejects a new invocation while one is already
// running rather than allowing concurrent children — mirroring the fact a
// single programmer connection cannot be shared between two operations.
#pragma once

#include <atomic>
#include <cstdint>
#include <functional>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

namespace avrbridge {

enum class StreamSource { STDOUT, STDERR };

// Invoked (from the reader thread — NOT the caller's thread) once per
// complete line of output produced by the child process.
using LineCallback = std::function<void(StreamSource source, const std::string& line)>;

// Invoked once the child process has fully exited.
using ExitCallback = std::function<void(int exitCode, bool wasCancelled)>;

struct SpawnRequest {
    std::string executablePath;              // absolute path to libavrdude2.so on disk
    std::vector<std::string> args;            // argv[1..] (argv[0] is set to executablePath)
    std::vector<std::string> environment;     // "KEY=VALUE" entries appended to the child's env
    // If >= 0, this fd is duplicated into the child at inheritFdTarget and
    // left open (used to hand an already-permission-granted USB device fd,
    // obtained via UsbDeviceConnection.getFileDescriptor() in Kotlin, down to
    // the child process for libusb_wrap_sys_device()-style consumption).
    int inheritFd = -1;
    int inheritFdTarget = 63;
};

class ProcessRunner {
public:
    ProcessRunner() = default;
    ~ProcessRunner();

    // Returns true if a spawn was started. Fails fast (returns false) if an
    // operation is already running. onLine fires from a background thread;
    // onExit fires from a background thread once the child exits or is
    // reaped after cancellation. This call itself returns immediately.
    bool start(const SpawnRequest& request, LineCallback onLine, ExitCallback onExit);

    // True while a child process is currently running.
    bool isRunning() const;

    // Politely asks the running child to stop (SIGINT), escalating to
    // SIGTERM then SIGKILL if it hasn't exited within the given grace
    // periods. Safe to call from any thread, including from within onLine.
    void cancel();

    // Blocks the calling thread until the current operation (if any)
    // finishes. Used by the JNI layer to offer a synchronous call style to
    // Kotlin coroutines running on Dispatchers.IO.
    void waitForCompletion();

private:
    void readerThreadMain(int stdoutFd, int stderrFd, pid_t childPid,
                           LineCallback onLine, ExitCallback onExit);

    mutable std::mutex mutex_;
    std::thread worker_;
    std::atomic<pid_t> childPid_{-1};
    std::atomic<bool> running_{false};
    std::atomic<bool> cancelRequested_{false};
};

} // namespace avrbridge
