#include "jni_callback.h"
#include "log.h"

namespace avrbridge {

namespace {
JavaVM* g_vm = nullptr;
jclass g_bridgeClass = nullptr; // global ref to com/avrdude/frontend/native/AvrdudeNativeBridge

jmethodID g_onConsoleLine = nullptr;
jmethodID g_onProgress = nullptr;
jmethodID g_onOperationFinished = nullptr;
jmethodID g_onWarning = nullptr;
jmethodID g_onError = nullptr;
jmethodID g_onDebug = nullptr;

constexpr const char* kBridgeClassName = "com/avrdude/frontend/native/AvrdudeNativeBridge";
} // namespace

void jniCallback_init(JavaVM* vm) {
    g_vm = vm;
    JNIEnv* env = nullptr;
    if (vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) != JNI_OK) {
        LOGE("jniCallback_init: GetEnv failed");
        return;
    }

    jclass localClass = env->FindClass(kBridgeClassName);
    if (localClass == nullptr) {
        LOGE("jniCallback_init: could not find class %s", kBridgeClassName);
        env->ExceptionClear();
        return;
    }
    g_bridgeClass = reinterpret_cast<jclass>(env->NewGlobalRef(localClass));
    env->DeleteLocalRef(localClass);

    // All callback entry points are Kotlin `object AvrdudeNativeBridge`
    // members annotated @JvmStatic, so they resolve as static methods here.
    g_onConsoleLine = env->GetStaticMethodID(g_bridgeClass, "onConsoleLine", "(IILjava/lang/String;)V");
    g_onProgress = env->GetStaticMethodID(g_bridgeClass, "onProgress", "(IILjava/lang/String;)V");
    g_onOperationFinished = env->GetStaticMethodID(g_bridgeClass, "onOperationFinished", "(IIZ)V");
    g_onWarning = env->GetStaticMethodID(g_bridgeClass, "onWarning", "(ILjava/lang/String;)V");
    g_onError = env->GetStaticMethodID(g_bridgeClass, "onError", "(ILjava/lang/String;)V");
    g_onDebug = env->GetStaticMethodID(g_bridgeClass, "onDebugMessage", "(Ljava/lang/String;)V");

    if (!g_onConsoleLine || !g_onProgress || !g_onOperationFinished || !g_onWarning || !g_onError || !g_onDebug) {
        LOGE("jniCallback_init: one or more callback method IDs not found — check "
             "AvrdudeNativeBridge signatures match jni_callback.cpp exactly");
        env->ExceptionClear();
    }
}

ThreadAttachGuard::ThreadAttachGuard() {
    if (g_vm == nullptr) return;
    JNIEnv* env = nullptr;
    jint getEnvResult = g_vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6);
    if (getEnvResult == JNI_EDETACHED) {
        JavaVMAttachArgs args{JNI_VERSION_1_6, "avrbridge-reader", nullptr};
        if (g_vm->AttachCurrentThread(&env, &args) == JNI_OK) {
            didAttach_ = true;
        } else {
            LOGE("ThreadAttachGuard: AttachCurrentThread failed");
            env = nullptr;
        }
    } else if (getEnvResult != JNI_OK) {
        LOGE("ThreadAttachGuard: GetEnv failed (%d)", getEnvResult);
        env = nullptr;
    }
    env_ = env;
}

ThreadAttachGuard::~ThreadAttachGuard() {
    if (didAttach_ && g_vm != nullptr) {
        g_vm->DetachCurrentThread();
    }
}

namespace {
jstring toJString(JNIEnv* env, const std::string& s) {
    return env->NewStringUTF(s.c_str());
}
} // namespace

void callback_onConsoleLine(int opId, int source, const std::string& line) {
    ThreadAttachGuard guard;
    JNIEnv* env = guard.env();
    if (!env || !g_bridgeClass || !g_onConsoleLine) return;
    jstring jline = toJString(env, line);
    env->CallStaticVoidMethod(g_bridgeClass, g_onConsoleLine, opId, source, jline);
    env->DeleteLocalRef(jline);
}

void callback_onProgress(int opId, int percent, const std::string& message) {
    ThreadAttachGuard guard;
    JNIEnv* env = guard.env();
    if (!env || !g_bridgeClass || !g_onProgress) return;
    jstring jmsg = toJString(env, message);
    env->CallStaticVoidMethod(g_bridgeClass, g_onProgress, opId, percent, jmsg);
    env->DeleteLocalRef(jmsg);
}

void callback_onOperationFinished(int opId, int exitCode, bool cancelled) {
    ThreadAttachGuard guard;
    JNIEnv* env = guard.env();
    if (!env || !g_bridgeClass || !g_onOperationFinished) return;
    env->CallStaticVoidMethod(g_bridgeClass, g_onOperationFinished, opId, exitCode, static_cast<jboolean>(cancelled));
}

void callback_onWarning(int opId, const std::string& message) {
    ThreadAttachGuard guard;
    JNIEnv* env = guard.env();
    if (!env || !g_bridgeClass || !g_onWarning) return;
    jstring jmsg = toJString(env, message);
    env->CallStaticVoidMethod(g_bridgeClass, g_onWarning, opId, jmsg);
    env->DeleteLocalRef(jmsg);
}

void callback_onError(int opId, const std::string& message) {
    ThreadAttachGuard guard;
    JNIEnv* env = guard.env();
    if (!env || !g_bridgeClass || !g_onError) return;
    jstring jmsg = toJString(env, message);
    env->CallStaticVoidMethod(g_bridgeClass, g_onError, opId, jmsg);
    env->DeleteLocalRef(jmsg);
}

void callback_onDebug(const std::string& message) {
    ThreadAttachGuard guard;
    JNIEnv* env = guard.env();
    if (!env || !g_bridgeClass || !g_onDebug) return;
    jstring jmsg = toJString(env, message);
    env->CallStaticVoidMethod(g_bridgeClass, g_onDebug, jmsg);
    env->DeleteLocalRef(jmsg);
}

} // namespace avrbridge
