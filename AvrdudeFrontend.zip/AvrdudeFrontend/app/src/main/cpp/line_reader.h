// line_reader.h
//
// AVRDUDE writes progress and log output incrementally, and a single read()
// from a pipe can land in the middle of a line (or contain several lines).
// LineReader accumulates raw bytes per file descriptor and yields complete,
// newline-terminated lines as they become available, carrying any partial
// trailing fragment forward to the next feed() call.
//
// AVRDUDE's progress meter also uses '\r' (carriage return, no newline) to
// redraw a percentage in place on a real terminal. We treat '\r' as a line
// terminator too so that progress updates reach Kotlin as discrete events
// instead of being buffered forever waiting for a '\n' that never comes.
#pragma once
#include <string>
#include <vector>

namespace avrbridge {

class LineReader {
public:
    // Feed raw bytes read from the fd. Returns any newly-completed lines,
    // in order, with the terminator stripped.
    std::vector<std::string> feed(const char* data, size_t len) {
        std::vector<std::string> lines;
        for (size_t i = 0; i < len; ++i) {
            char c = data[i];
            if (c == '\n' || c == '\r') {
                if (!buffer_.empty()) {
                    lines.push_back(buffer_);
                    buffer_.clear();
                }
                // collapse "\r\n" into a single terminator
                if (c == '\r' && i + 1 < len && data[i + 1] == '\n') {
                    ++i;
                }
            } else {
                buffer_.push_back(c);
            }
        }
        return lines;
    }

    // Call once at EOF to flush any trailing partial line that was never
    // terminated (AVRDUDE's final status line sometimes has no trailing
    // newline before the process exits).
    std::vector<std::string> flush() {
        std::vector<std::string> lines;
        if (!buffer_.empty()) {
            lines.push_back(buffer_);
            buffer_.clear();
        }
        return lines;
    }

private:
    std::string buffer_;
};

} // namespace avrbridge
