// log.h — thin wrapper over Android's __android_log_print so native-side
// diagnostics show up in `adb logcat` under a single consistent tag, separate
// from the AVRDUDE child process's own stdout/stderr (which is streamed to
// Kotlin via callbacks, not logcat).
#pragma once
#include <android/log.h>

#define AVRBRIDGE_TAG "AvrBridgeNative"

#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, AVRBRIDGE_TAG, __VA_ARGS__)
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, AVRBRIDGE_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, AVRBRIDGE_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, AVRBRIDGE_TAG, __VA_ARGS__)
