package com.avrdude.frontend.data.files

import android.content.Context
import android.net.Uri
import java.io.File

/**
 * AVRDUDE refuses to start without a usable avrdude.conf (it contains the
 * entire device/programmer database this build knows about — this is not
 * optional config, it's the data AVRDUDE parses every part/programmer
 * definition from). Desktop installs ship one alongside the binary; this
 * project intentionally does NOT bundle a guessed one, because a
 * version-mismatched avrdude.conf fails in confusing ways (parse errors, or
 * worse, silently-wrong part definitions) rather than a clean "file
 * missing" error.
 *
 * Instead: the user imports the exact avrdude.conf that matches this
 * build (obtainable from the ArduinoDroid project / avrdude-arduinodroid2
 * source this .so was built from) via Settings > "Import avrdude.conf",
 * backed by the Storage Access Framework. We copy it into app-private
 * storage once (AVRDUDE needs a real filesystem path, not a content:// URI)
 * and remember that we've done so.
 */
class AvrdudeConfigProvider(private val context: Context) {

    private val destFile: File
        get() = File(context.filesDir, "avrdude.conf")

    fun isConfigured(): Boolean = destFile.exists() && destFile.length() > 0

    /** Absolute filesystem path to pass as AVRDUDE's `-C` argument. */
    fun requireConfPath(): String {
        check(isConfigured()) {
            "avrdude.conf has not been imported yet — go to Settings > Import avrdude.conf"
        }
        return destFile.absolutePath
    }

    /** Copies the user-picked file (from a SAF document picker result) into
     *  app-private storage. Returns true on success. */
    fun importFrom(sourceUri: Uri): Boolean {
        return try {
            context.contentResolver.openInputStream(sourceUri)?.use { input ->
                destFile.outputStream().use { output -> input.copyTo(output) }
            }
            isConfigured()
        } catch (e: Exception) {
            false
        }
    }

    fun clear() {
        if (destFile.exists()) destFile.delete()
    }
}
