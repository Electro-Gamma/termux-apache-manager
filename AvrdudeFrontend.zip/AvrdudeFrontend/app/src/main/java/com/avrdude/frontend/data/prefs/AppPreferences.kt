package com.avrdude.frontend.data.prefs

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "avrdude_settings")

/**
 * All user-configurable settings, backed by Jetpack DataStore. Every value
 * is exposed as a Flow so SettingsViewModel can drive its StateFlow directly
 * from these without any manual caching.
 */
class AppPreferences(private val context: Context) {

    private object Keys {
        val DARK_MODE = stringPreferencesKey("dark_mode")           // "system" | "light" | "dark"
        val DEFAULT_PROGRAMMER = stringPreferencesKey("default_programmer")
        val DEFAULT_MCU = stringPreferencesKey("default_mcu")
        val DEFAULT_BAUD = intPreferencesKey("default_baud")
        val ISP_CLOCK_KHZ = floatPreferencesKey("isp_clock_khz")
        val RETRY_COUNT = intPreferencesKey("retry_count")
        val TIMEOUT_MS = intPreferencesKey("timeout_ms")
        val VERIFY_AFTER_WRITE = booleanPreferencesKey("verify_after_write")
        val CHIP_ERASE_BEFORE_WRITE = booleanPreferencesKey("chip_erase_before_write")
        val SAFE_MODE = booleanPreferencesKey("safe_mode")
        val AUTO_RECONNECT = booleanPreferencesKey("auto_reconnect")
        val SAVE_LOGS = booleanPreferencesKey("save_logs")
        val CONSOLE_FONT_SIZE_SP = floatPreferencesKey("console_font_size_sp")
        // Stored as a single delimiter-joined string (not a Set) specifically
        // to preserve most-recent-first ORDER, which a Set cannot guarantee.
        val RECENT_FILES = stringPreferencesKey("recent_files_ordered")
        val USE_ROOT_USB = booleanPreferencesKey("use_root_usb")
    }

    val darkMode: Flow<String> = context.dataStore.data.map { it[Keys.DARK_MODE] ?: "system" }
    suspend fun setDarkMode(value: String) = context.dataStore.edit { it[Keys.DARK_MODE] = value }

    val defaultProgrammer: Flow<String?> = context.dataStore.data.map { it[Keys.DEFAULT_PROGRAMMER] }
    suspend fun setDefaultProgrammer(value: String) = context.dataStore.edit { it[Keys.DEFAULT_PROGRAMMER] = value }

    val defaultMcu: Flow<String?> = context.dataStore.data.map { it[Keys.DEFAULT_MCU] }
    suspend fun setDefaultMcu(value: String) = context.dataStore.edit { it[Keys.DEFAULT_MCU] = value }

    val defaultBaud: Flow<Int> = context.dataStore.data.map { it[Keys.DEFAULT_BAUD] ?: 19200 }
    suspend fun setDefaultBaud(value: Int) = context.dataStore.edit { it[Keys.DEFAULT_BAUD] = value }

    val ispClockKhz: Flow<Float> = context.dataStore.data.map { it[Keys.ISP_CLOCK_KHZ] ?: 1843.2f }
    suspend fun setIspClockKhz(value: Float) = context.dataStore.edit { it[Keys.ISP_CLOCK_KHZ] = value }

    /** Not a native AVRDUDE flag — see docs/ARCHITECTURE.md "Settings that
     *  don't map 1:1 to AVRDUDE flags" for how this is applied (as a
     *  backend-specific -x extended option, best-effort). */
    val retryCount: Flow<Int> = context.dataStore.data.map { it[Keys.RETRY_COUNT] ?: 3 }
    suspend fun setRetryCount(value: Int) = context.dataStore.edit { it[Keys.RETRY_COUNT] = value }

    val timeoutMs: Flow<Int> = context.dataStore.data.map { it[Keys.TIMEOUT_MS] ?: 5000 }
    suspend fun setTimeoutMs(value: Int) = context.dataStore.edit { it[Keys.TIMEOUT_MS] = value }

    val verifyAfterWrite: Flow<Boolean> = context.dataStore.data.map { it[Keys.VERIFY_AFTER_WRITE] ?: true }
    suspend fun setVerifyAfterWrite(value: Boolean) = context.dataStore.edit { it[Keys.VERIFY_AFTER_WRITE] = value }

    val chipEraseBeforeWrite: Flow<Boolean> = context.dataStore.data.map { it[Keys.CHIP_ERASE_BEFORE_WRITE] ?: true }
    suspend fun setChipEraseBeforeWrite(value: Boolean) = context.dataStore.edit { it[Keys.CHIP_ERASE_BEFORE_WRITE] = value }

    val safeMode: Flow<Boolean> = context.dataStore.data.map { it[Keys.SAFE_MODE] ?: true }
    suspend fun setSafeMode(value: Boolean) = context.dataStore.edit { it[Keys.SAFE_MODE] = value }

    val autoReconnect: Flow<Boolean> = context.dataStore.data.map { it[Keys.AUTO_RECONNECT] ?: true }
    suspend fun setAutoReconnect(value: Boolean) = context.dataStore.edit { it[Keys.AUTO_RECONNECT] = value }

    val saveLogs: Flow<Boolean> = context.dataStore.data.map { it[Keys.SAVE_LOGS] ?: false }
    suspend fun setSaveLogs(value: Boolean) = context.dataStore.edit { it[Keys.SAVE_LOGS] = value }

    val consoleFontSizeSp: Flow<Float> = context.dataStore.data.map { it[Keys.CONSOLE_FONT_SIZE_SP] ?: 13f }
    suspend fun setConsoleFontSizeSp(value: Float) = context.dataStore.edit { it[Keys.CONSOLE_FONT_SIZE_SP] = value }

    val useRootUsb: Flow<Boolean> = context.dataStore.data.map { it[Keys.USE_ROOT_USB] ?: false }
    suspend fun setUseRootUsb(value: Boolean) = context.dataStore.edit { it[Keys.USE_ROOT_USB] = value }

    private val recentFilesDelimiter = "\n"
    val recentFiles: Flow<List<String>> = context.dataStore.data.map { prefs ->
        prefs[Keys.RECENT_FILES]?.split(recentFilesDelimiter)?.filter { it.isNotBlank() } ?: emptyList()
    }
    suspend fun addRecentFile(path: String) = context.dataStore.edit { prefs ->
        val existing = prefs[Keys.RECENT_FILES]?.split(recentFilesDelimiter)?.filter { it.isNotBlank() } ?: emptyList()
        val updated = (listOf(path) + existing.filterNot { it == path }).take(10)
        prefs[Keys.RECENT_FILES] = updated.joinToString(recentFilesDelimiter)
    }
}
