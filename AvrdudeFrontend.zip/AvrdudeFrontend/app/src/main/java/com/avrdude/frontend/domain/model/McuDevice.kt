package com.avrdude.frontend.domain.model

/**
 * Summary info for one AVR part. AVRDUDE's own compiled-in device database
 * (inside avrdude.conf) is the authoritative source — see
 * data/devicedb/McuDatabase.kt — this model is just the shape the UI renders.
 */
data class McuDevice(
    val partId: String,          // avrdude -p id, e.g. "m328p"
    val displayName: String,     // e.g. "ATmega328P"
    val family: String,          // e.g. "megaAVR", "tinyAVR-0/1", "XMEGA"
    val signature: String,       // e.g. "1E-95-0F"
    val flashSizeBytes: Int,
    val eepromSizeBytes: Int,
    val fuseCount: Int,          // 1 (tiny parts), 2, or 3 (low/high/extended)
    val hasLockBits: Boolean,
    val supportedMemories: List<MemoryType>,
)
