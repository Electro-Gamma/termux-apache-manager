package com.avrdude.frontend.data.devicedb

import com.avrdude.frontend.domain.model.FuseByteDefinition
import com.avrdude.frontend.domain.model.FuseByteKind
import com.avrdude.frontend.domain.model.FuseBitField
import com.avrdude.frontend.domain.model.McuDevice
import com.avrdude.frontend.domain.model.MemoryType

/**
 * A small, curated, OFFLINE reference table for the handful of AVR parts
 * hobbyists use most often. This is a convenience layer only — it exists so
 * the Device Information panel and Fuse Editor have something to show
 * immediately and offline, and so the fuse editor can label bits by name
 * instead of just showing a raw byte.
 *
 * It is explicitly NOT a substitute for AVRDUDE's own device database: the
 * authoritative list of every part this build actually supports comes from
 * listSupportedDevices() (AVRDUDE's own `-p ?` output, driven by the
 * imported avrdude.conf). If a part typed/selected isn't in this table, the
 * app still lets the user proceed with AVRDUDE directly — this table only
 * enriches the UI, it never gates what operations are allowed.
 */
object McuDatabase {

    val KNOWN_DEVICES: List<McuDevice> = listOf(
        McuDevice(
            partId = "m328p", displayName = "ATmega328P", family = "megaAVR",
            signature = "1E-95-0F", flashSizeBytes = 32768, eepromSizeBytes = 1024,
            fuseCount = 3, hasLockBits = true,
            supportedMemories = listOf(MemoryType.FLASH, MemoryType.EEPROM, MemoryType.LFUSE, MemoryType.HFUSE, MemoryType.EFUSE, MemoryType.LOCK, MemoryType.SIGNATURE, MemoryType.CALIBRATION),
        ),
        McuDevice(
            partId = "m2560", displayName = "ATmega2560", family = "megaAVR",
            signature = "1E-98-01", flashSizeBytes = 262144, eepromSizeBytes = 4096,
            fuseCount = 3, hasLockBits = true,
            supportedMemories = listOf(MemoryType.FLASH, MemoryType.EEPROM, MemoryType.LFUSE, MemoryType.HFUSE, MemoryType.EFUSE, MemoryType.LOCK, MemoryType.SIGNATURE, MemoryType.CALIBRATION),
        ),
        McuDevice(
            partId = "m32u4", displayName = "ATmega32U4", family = "megaAVR (USB)",
            signature = "1E-95-87", flashSizeBytes = 32768, eepromSizeBytes = 1024,
            fuseCount = 3, hasLockBits = true,
            supportedMemories = listOf(MemoryType.FLASH, MemoryType.EEPROM, MemoryType.LFUSE, MemoryType.HFUSE, MemoryType.EFUSE, MemoryType.LOCK, MemoryType.SIGNATURE, MemoryType.CALIBRATION),
        ),
        McuDevice(
            partId = "t85", displayName = "ATtiny85", family = "tinyAVR (classic)",
            signature = "1E-93-0B", flashSizeBytes = 8192, eepromSizeBytes = 512,
            fuseCount = 3, hasLockBits = true,
            supportedMemories = listOf(MemoryType.FLASH, MemoryType.EEPROM, MemoryType.LFUSE, MemoryType.HFUSE, MemoryType.EFUSE, MemoryType.LOCK, MemoryType.SIGNATURE, MemoryType.CALIBRATION),
        ),
        McuDevice(
            partId = "t402", displayName = "ATtiny402", family = "tinyAVR-0 (UPDI)",
            signature = "1E-92-27", flashSizeBytes = 4096, eepromSizeBytes = 128,
            fuseCount = 1, hasLockBits = true,
            supportedMemories = listOf(MemoryType.FLASH, MemoryType.EEPROM, MemoryType.FUSE_SINGLE, MemoryType.LOCK, MemoryType.SIGNATURE),
        ),
    )

    fun findByPartId(partId: String): McuDevice? = KNOWN_DEVICES.find { it.partId == partId }
    fun findBySignature(signature: String): McuDevice? =
        KNOWN_DEVICES.find { it.signature.equals(signature, ignoreCase = true) }

    /**
     * Fuse bit-field definitions for classic (non-UPDI) parts sharing the
     * ATmega328P-style low/high/extended fuse layout — the most common
     * hobbyist case. Values and meanings are the part's public datasheet
     * fuse tables. For parts not covered here the Fuse Editor still shows
     * the raw byte and lets the user edit it directly, just without named
     * bit fields.
     */
    fun fuseDefinitionsFor(partId: String): List<FuseByteDefinition>? = when (partId) {
        "m328p" -> atmega328pFuses()
        else -> null
    }

    private fun atmega328pFuses(): List<FuseByteDefinition> = listOf(
        FuseByteDefinition(
            kind = FuseByteKind.LOW,
            displayName = "Low Fuse",
            fields = listOf(
                FuseBitField(
                    name = "CKSEL3:0", description = "Clock source select",
                    bitRange = 0..3,
                    valueMeanings = mapOf(
                        0b0010 to "Internal 8MHz RC oscillator",
                        0b1111 to "Low power crystal oscillator (default range)",
                        0b0000 to "External clock",
                    ),
                    isDangerous = true,
                    dangerExplanation = "Selecting a clock source with no oscillator present " +
                        "(e.g. an external crystal that isn't populated) will make the chip " +
                        "unresponsive to ISP programming until a working clock is restored — " +
                        "typically requiring a high-voltage programmer to recover.",
                ),
                FuseBitField(
                    name = "SUT1:0", description = "Start-up time select",
                    bitRange = 4..5,
                    valueMeanings = mapOf(0 to "Shortest", 3 to "Longest (recommended for crystals)"),
                    isDangerous = false,
                ),
                FuseBitField(
                    name = "CKOUT", description = "Clock output on PB0",
                    bitRange = 6..6,
                    valueMeanings = mapOf(1 to "Disabled (default)", 0 to "Enabled"),
                    isDangerous = false,
                ),
                FuseBitField(
                    name = "CKDIV8", description = "Divide clock by 8",
                    bitRange = 7..7,
                    valueMeanings = mapOf(0 to "Divided (default from factory)", 1 to "Not divided"),
                    isDangerous = true,
                    dangerExplanation = "If left programmed (0) the chip runs at 1/8 speed, which " +
                        "can make baud-rate-dependent bootloaders/programmers appear to stop responding.",
                ),
            ),
        ),
        FuseByteDefinition(
            kind = FuseByteKind.HIGH,
            displayName = "High Fuse",
            fields = listOf(
                FuseBitField("BOOTRST", "Boot reset vector enable", 0..0, mapOf(1 to "Reset vector = 0x0000 (default)", 0 to "Reset vector = boot loader"), false),
                FuseBitField("BOOTSZ1:0", "Boot size select", 1..2, mapOf(3 to "Smallest (256 words, default)", 0 to "Largest (2048 words)"), false),
                FuseBitField("EESAVE", "Preserve EEPROM on chip erase", 3..3, mapOf(1 to "EEPROM erased with chip erase (default)", 0 to "EEPROM preserved"), false),
                FuseBitField(
                    "WDTON", "Watchdog timer always on", 4..4,
                    mapOf(1 to "WDT controlled by software (default)", 0 to "WDT always on, cannot be disabled by software"),
                    isDangerous = true,
                    dangerExplanation = "Programming this (0) forces the watchdog on permanently — " +
                        "firmware that doesn't pet the watchdog will reset in a loop.",
                ),
                FuseBitField(
                    "SPIEN", "Enable serial (ISP) programming", 5..5,
                    mapOf(0 to "SPI programming enabled (default, must stay 0)", 1 to "SPI programming DISABLED"),
                    isDangerous = true,
                    dangerExplanation = "Clearing this bit's programmed state (setting SPIEN=1) " +
                        "disables ISP programming entirely — the chip can then only be recovered " +
                        "with parallel high-voltage programming. AVRDUDE will refuse to let ISP " +
                        "programmers set this bit for exactly this reason.",
                ),
                FuseBitField(
                    "DWEN", "debugWIRE enable", 6..6,
                    mapOf(1 to "debugWIRE disabled (default)", 0 to "debugWIRE enabled, RESET pin repurposed"),
                    isDangerous = true,
                    dangerExplanation = "Enabling debugWIRE repurposes the RESET pin, which will make " +
                        "the chip stop responding to normal ISP programming until debugWIRE is used " +
                        "to disable it again.",
                ),
                FuseBitField(
                    "RSTDISBL", "External reset disable", 7..7,
                    mapOf(1 to "RESET pin enabled (default)", 0 to "RESET pin repurposed as GPIO"),
                    isDangerous = true,
                    dangerExplanation = "Programming this disables the RESET pin, which ALSO disables " +
                        "ISP programming (ISP needs RESET). Recovery then requires a high-voltage " +
                        "parallel programmer. This is the single most common way to accidentally " +
                        "'brick' an AVR from ISP.",
                ),
            ),
        ),
        FuseByteDefinition(
            kind = FuseByteKind.EXTENDED,
            displayName = "Extended Fuse",
            fields = listOf(
                FuseBitField(
                    "BODLEVEL2:0", "Brown-out detector trigger level", 0..2,
                    mapOf(0b111 to "Disabled (default)", 0b101 to "~2.7V", 0b100 to "~4.3V"),
                    isDangerous = false,
                ),
            ),
        ),
    )
}
