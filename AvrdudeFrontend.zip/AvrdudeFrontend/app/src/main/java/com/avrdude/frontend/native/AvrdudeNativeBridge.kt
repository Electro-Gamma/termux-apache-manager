package com.avrdude.frontend.native

import com.avrdude.frontend.domain.model.ConsoleSource
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import java.util.concurrent.atomic.AtomicInteger

/**
 * One event emitted while an AVRDUDE-backed operation is in flight, tagged
 * with the opId that AvrdudeEngine assigned when it started that operation
 * (see AvrdudeRepositoryImpl — each public call filters `events` down to its
 * own opId so concurrent-looking suspend calls never cross-talk, even though
 * the native side actually serializes them one at a time).
 */
sealed class OperationEvent {
    abstract val opId: Int

    data class Console(override val opId: Int, val source: ConsoleSource, val line: String) : OperationEvent()
    data class Progress(override val opId: Int, val percent: Int, val message: String) : OperationEvent()
    data class Warning(override val opId: Int, val message: String) : OperationEvent()
    data class Error(override val opId: Int, val message: String) : OperationEvent()
    data class Finished(override val opId: Int, val exitCode: Int, val cancelled: Boolean) : OperationEvent()
}

/**
 * The real JNI boundary. `System.loadLibrary("avrbridge")` loads *our*
 * compiled bridge library (app/src/main/cpp), never libavrdude2.so directly
 * — that file has no exported symbols to load (see docs/ARCHITECTURE.md).
 * Everything below either calls into native code (the `external fun`s, real
 * JNI-registered native methods implemented in avrbridge.cpp) or is called
 * FROM native code (the `@JvmStatic fun on...` callbacks, invoked via
 * jni_callback.cpp using cached method IDs — their names and signatures are
 * load-bearing and must not change independently on one side only).
 *
 * This object is intentionally low-level and process-shaped (single opId at
 * a time, raw String argv). AvrdudeEngine / AvrdudeRepositoryImpl build on
 * top of it to expose the friendly initialize()/readFlash()/writeFlash()/...
 * API surface the rest of the app actually uses.
 */
object AvrdudeNativeBridge {

    /**
     * True once `libavrbridge.so` has been loaded successfully. `System.loadLibrary`
     * can throw `UnsatisfiedLinkError` — an `Error`, not an `Exception` — if the
     * library can't be loaded for any reason (wrong/missing ABI, an unresolved
     * native symbol, a missing runtime dependency). That's a real possibility on
     * a real device the first time this code ever runs there, and it must never
     * be allowed to propagate uncaught: the first thing that touches this object
     * is a background coroutine in AvrdudeApp.onCreate(), and an uncaught Error
     * there crashes the entire process before a single screen is even shown —
     * which is indistinguishable, from the user's side, from "the app just
     * doesn't work". [com.avrdude.frontend.data.repository.AvrdudeRepositoryImpl]
     * checks this flag before ever calling a native function, and fails
     * gracefully (a `Result.failure` carrying `NativeBridgeNotReadyException`)
     * instead of letting an `external fun` call blow up with the same error
     * for the same underlying reason.
     */
    val isLibraryLoaded: Boolean

    init {
        isLibraryLoaded = try {
            System.loadLibrary("avrbridge")
            true
        } catch (e: Throwable) {
            // Throwable, not just UnsatisfiedLinkError/Exception — a failed
            // native load can also surface as a plain LinkageError depending
            // on the exact failure mode, and this must catch all of them.
            android.util.Log.e("AvrdudeNativeBridge", "Failed to load libavrbridge.so", e)
            false
        }
    }

    private val opIdCounter = AtomicInteger(1)

    /** Every call into nativeRunAvrdude should be tagged with a fresh id from here. */
    fun nextOpId(): Int = opIdCounter.getAndIncrement()

    // Native callbacks land on an arbitrary reader thread, outside any
    // coroutine context, so the shared flow needs a healthy replay-free
    // buffer and non-suspending tryEmit from the callback methods below.
    private val _events = MutableSharedFlow<OperationEvent>(extraBufferCapacity = 512)
    val events = _events.asSharedFlow()

    // Bridge-level diagnostics not tied to any one operation (e.g.
    // initialization failures) — surfaced separately from per-operation
    // console output so Settings > "Native diagnostics" can show it even
    // when nothing is running.
    private val _debugLog = MutableSharedFlow<String>(extraBufferCapacity = 128)
    val debugLog = _debugLog.asSharedFlow()

    // ------------------------------------------------------------------
    // Native functions implemented in avrbridge.cpp
    // ------------------------------------------------------------------

    /**
     * Resolves and validates the extracted libavrdude2.so path.
     * @param nativeLibDir must be `context.applicationInfo.nativeLibraryDir`.
     * @param workDir a private, writable directory for temp files (e.g.
     *   `context.filesDir.absolutePath`).
     */
    @JvmStatic external fun nativeInitialize(nativeLibDir: String, workDir: String): Boolean

    /** Cancels any in-flight operation and clears native state. */
    @JvmStatic external fun nativeShutdown()

    /** Returns the resolved executable path, or an empty string if not initialized. */
    @JvmStatic external fun nativeGetExecutablePath(): String

    /**
     * Spawns libavrdude2.so with the given argv (NOT including argv[0], which
     * the native side fills in with the resolved executable path). Returns
     * whether the spawn itself started successfully — the eventual result
     * arrives asynchronously as an [OperationEvent.Finished] on [events].
     *
     * @param inheritFd an already `UsbDeviceConnection`-opened, permission-
     *   granted native file descriptor to hand down to the child process for
     *   libusb fd-based device access, or -1 if not applicable (serial-port
     *   backed programmers, or root-based /dev/bus/usb access instead).
     * @param inheritFdTarget which fd number the child should see it as.
     */
    @JvmStatic external fun nativeRunAvrdude(
        opId: Int,
        args: Array<String>,
        envExtra: Array<String>,
        inheritFd: Int,
        inheritFdTarget: Int,
    ): Boolean

    /** Requests cancellation of whatever operation is currently running. */
    @JvmStatic external fun nativeCancel(): Boolean

    @JvmStatic external fun nativeIsRunning(): Boolean

    // ------------------------------------------------------------------
    // PTY creation for USB-serial programmer support — see the matching
    // comment block in avrbridge.cpp and usb/SerialPtyBridge.kt.
    // ------------------------------------------------------------------

    /** Returns an open PTY master fd, or -1 on failure. Caller takes
     *  ownership (wrap with ParcelFileDescriptor.adoptFd()). */
    @JvmStatic external fun nativeOpenPtyMaster(): Int

    /** Returns the PTY slave's device path (e.g. "/dev/pts/3") for a master
     *  fd from [nativeOpenPtyMaster], or null on failure. */
    @JvmStatic external fun nativeGetPtySlavePath(masterFd: Int): String?

    // ------------------------------------------------------------------
    // Callback entry points invoked FROM native code (jni_callback.cpp).
    // Signatures are resolved there via GetStaticMethodID with an explicit
    // JNI type descriptor string — renaming or re-typing any of these must
    // be mirrored exactly in jni_callback.cpp or native->Kotlin calls will
    // silently no-op (jniCallback_init logs an error to logcat if a method
    // ID can't be resolved, but does not crash).
    // ------------------------------------------------------------------

    @JvmStatic
    fun onConsoleLine(opId: Int, source: Int, line: String) {
        val src = if (source == 0) ConsoleSource.STDOUT else ConsoleSource.STDERR
        _events.tryEmit(OperationEvent.Console(opId, src, line))
    }

    @JvmStatic
    fun onProgress(opId: Int, percent: Int, message: String) {
        _events.tryEmit(OperationEvent.Progress(opId, percent, message))
    }

    @JvmStatic
    fun onOperationFinished(opId: Int, exitCode: Int, cancelled: Boolean) {
        _events.tryEmit(OperationEvent.Finished(opId, exitCode, cancelled))
    }

    @JvmStatic
    fun onWarning(opId: Int, message: String) {
        _events.tryEmit(OperationEvent.Warning(opId, message))
    }

    @JvmStatic
    fun onError(opId: Int, message: String) {
        _events.tryEmit(OperationEvent.Error(opId, message))
    }

    @JvmStatic
    fun onDebugMessage(message: String) {
        _debugLog.tryEmit(message)
    }
}
