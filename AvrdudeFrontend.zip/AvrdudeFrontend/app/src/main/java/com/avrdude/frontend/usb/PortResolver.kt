package com.avrdude.frontend.usb

import com.avrdude.frontend.data.repository.ConnectionParams
import com.avrdude.frontend.domain.model.KnownProgrammers
import com.avrdude.frontend.domain.model.PortHint

/**
 * Decides whether the current target needs a [SerialPtyBridge] and, if so,
 * manages its lifecycle for exactly the duration of one operation. Shared
 * by DashboardViewModel and FuseEditorViewModel — both run operations
 * against whatever [com.avrdude.frontend.data.session.ConnectionSession]
 * currently holds, and a USB-serial target needs this same bridging logic
 * regardless of which screen triggered the operation.
 *
 * A fresh bridge is opened per call rather than held open across multiple
 * operations: opening the real USB-serial connection is what triggers
 * [SerialPtyBridge]'s DTR reset pulse, and Arduino-bootloader-style targets
 * expect that pulse on every session, the same way opening a real serial
 * port fresh does on a desktop OS.
 */
class PortResolver(private val usbManager: UsbPermissionManager) {

    suspend fun <T> withResolvedPort(
        params: ConnectionParams,
        selectedDevice: UsbDeviceInfo?,
        block: suspend (ConnectionParams) -> Result<T>,
    ): Result<T> {
        val needsBridge = selectedDevice != null &&
            KnownProgrammers.byId(params.programmerId)?.portHint == PortHint.USB_SERIAL
        if (!needsBridge) return block(params)

        val usbDevice = usbManager.findDeviceByName(selectedDevice!!.deviceName)
            ?: return Result.failure(IllegalStateException("Selected USB-serial device is no longer connected."))
        val bridge = usbManager.openSerialBridge(usbDevice)
            ?: return Result.failure(IllegalStateException("Could not open a connection to the USB-serial device."))

        val slavePath = bridge.start(params.baudRate ?: 19200)
        if (slavePath == null) {
            bridge.stop()
            return Result.failure(IllegalStateException("Could not bridge the USB-serial device — check Console for details."))
        }
        return try {
            block(params.copy(port = slavePath))
        } finally {
            bridge.stop()
        }
    }
}
