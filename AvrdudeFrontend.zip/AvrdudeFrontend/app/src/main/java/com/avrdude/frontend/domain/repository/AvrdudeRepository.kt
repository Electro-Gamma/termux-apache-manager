package com.avrdude.frontend.domain.repository

import com.avrdude.frontend.data.repository.ConnectionParams
import com.avrdude.frontend.domain.model.ConsoleEntry
import com.avrdude.frontend.domain.model.FileFormat
import com.avrdude.frontend.domain.model.FuseByteKind
import com.avrdude.frontend.domain.model.ProgressState
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow

enum class ConnectionState { DISCONNECTED, CONNECTING, CONNECTED, ERROR }

/**
 * The single point of contact between the app's UI/domain logic and
 * AVRDUDE. Every method here corresponds 1:1 to one of the operations
 * listed in the project spec. Internally (AvrdudeRepositoryImpl) each one
 * builds the appropriate argv via AvrdudeArgvBuilder and runs it through
 * AvrdudeNativeBridge, but nothing above this interface needs to know that
 * — ViewModels only see suspend functions returning Result<T> plus the two
 * always-on observable streams below.
 *
 * Concurrency note: AVRDUDE (and the physical programmer hardware it talks
 * to) can only do one thing at a time. Calling a second operation while one
 * is already running fails fast with an AvrdudeOperationException rather
 * than queueing silently — the UI is expected to disable action buttons
 * while [progress].isRunning is true (DashboardViewModel does this).
 */
interface AvrdudeRepository {

    /** Every console line from every operation, plus native bridge diagnostics. */
    val consoleEvents: Flow<ConsoleEntry>

    /** Live progress for whatever operation is currently running (or ProgressState.IDLE). */
    val progress: StateFlow<ProgressState>

    val connectionState: StateFlow<ConnectionState>

    suspend fun initialize(): Result<Unit>
    fun shutdown()

    suspend fun getVersion(): Result<String>
    suspend fun listSupportedProgrammers(): Result<List<String>>
    suspend fun listSupportedDevices(): Result<List<String>>

    suspend fun connect(params: ConnectionParams): Result<Unit>
    fun disconnect()

    /**
     * Hands an already permission-granted USB device file descriptor
     * (`UsbDeviceConnection.getFileDescriptor()`) down to subsequent
     * AVRDUDE invocations, for libusb-backed programmers on unrooted
     * Android. See docs/ARCHITECTURE.md "USB access on unrooted Android"
     * for why this is needed and what is/isn't verified about this exact
     * build's support for it.
     */
    fun attachUsbFileDescriptor(fd: Int)
    fun detachUsbFileDescriptor()

    /** Reads the 3-byte device signature and returns it as e.g. "1E-95-0F". */
    suspend fun readSignature(params: ConnectionParams): Result<String>

    suspend fun chipErase(params: ConnectionParams): Result<Unit>

    suspend fun readFlash(params: ConnectionParams, outFilePath: String, format: FileFormat): Result<Unit>
    suspend fun writeFlash(
        params: ConnectionParams, inFilePath: String, format: FileFormat,
        verifyAfterWrite: Boolean, chipEraseFirst: Boolean,
    ): Result<Unit>
    suspend fun verifyFlash(params: ConnectionParams, referenceFilePath: String, format: FileFormat): Result<Unit>

    suspend fun readEEPROM(params: ConnectionParams, outFilePath: String, format: FileFormat): Result<Unit>
    suspend fun writeEEPROM(
        params: ConnectionParams, inFilePath: String, format: FileFormat,
        verifyAfterWrite: Boolean,
    ): Result<Unit>
    suspend fun verifyEEPROM(params: ConnectionParams, referenceFilePath: String, format: FileFormat): Result<Unit>

    /** Reads one fuse byte (low/high/extended/single) and returns its raw value 0-255. */
    suspend fun readFuse(params: ConnectionParams, byte: FuseByteKind): Result<Int>
    suspend fun writeFuse(params: ConnectionParams, byte: FuseByteKind, value: Int): Result<Unit>

    suspend fun readLockBits(params: ConnectionParams): Result<Int>
    suspend fun writeLockBits(params: ConnectionParams, value: Int): Result<Unit>

    suspend fun readCalibration(params: ConnectionParams): Result<Int>

    /** Requests cancellation of whatever operation is currently in flight. Safe to call when idle (no-op). */
    fun cancelOperation()
}
