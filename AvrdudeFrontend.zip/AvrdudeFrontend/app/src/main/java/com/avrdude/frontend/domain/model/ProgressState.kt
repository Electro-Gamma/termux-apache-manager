package com.avrdude.frontend.domain.model

/**
 * Snapshot of an in-flight operation's progress, derived from AVRDUDE's
 * console output. bytesTransferred/totalBytes/speedBytesPerSec are best-effort:
 * AVRDUDE's classic progress meter reports percentage reliably but byte
 * counts and throughput are estimated from the known transfer size (from the
 * hex/bin file or the target memory's declared size in the device database)
 * combined with elapsed wall-clock time, not parsed verbatim from AVRDUDE
 * (whose own text format for this varies across backends/versions).
 */
data class ProgressState(
    val operation: OperationType?,
    val label: String,
    val percent: Int,
    val bytesTransferred: Long,
    val totalBytes: Long,
    val speedBytesPerSec: Double,
    val etaSeconds: Int?,
    val isRunning: Boolean,
) {
    companion object {
        val IDLE = ProgressState(
            operation = null,
            label = "Idle",
            percent = 0,
            bytesTransferred = 0,
            totalBytes = 0,
            speedBytesPerSec = 0.0,
            etaSeconds = null,
            isRunning = false,
        )
    }
}
