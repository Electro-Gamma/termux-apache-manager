package com.avrdude.frontend.presentation.settings

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.avrdude.frontend.data.files.AvrdudeConfigProvider
import com.avrdude.frontend.data.prefs.AppPreferences
import com.avrdude.frontend.di.ServiceLocator
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class SettingsUiState(
    val darkMode: String = "system",
    val defaultProgrammer: String = "",
    val defaultMcu: String = "",
    val defaultBaud: Int = 19200,
    val ispClockKhz: Float = 1843.2f,
    val retryCount: Int = 3,
    val timeoutMs: Int = 5000,
    val verifyAfterWrite: Boolean = true,
    val chipEraseBeforeWrite: Boolean = true,
    val safeMode: Boolean = true,
    val autoReconnect: Boolean = true,
    val saveLogs: Boolean = false,
    val consoleFontSizeSp: Float = 13f,
    val useRootUsb: Boolean = false,
    val isConfigConfigured: Boolean = false,
)

class SettingsViewModel(
    private val preferences: AppPreferences,
    private val configProvider: AvrdudeConfigProvider,
) : ViewModel() {

    private val _uiState = MutableStateFlow(SettingsUiState())
    val uiState: StateFlow<SettingsUiState> = _uiState.asStateFlow()

    private val _events = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val events: SharedFlow<String> = _events.asSharedFlow()

    init {
        combine(
            preferences.darkMode, preferences.defaultProgrammer, preferences.defaultMcu, preferences.defaultBaud,
        ) { dark, prog, mcu, baud -> Quad(dark, prog ?: "", mcu ?: "", baud) }
            .onEach { (dark, prog, mcu, baud) ->
                _uiState.update { it.copy(darkMode = dark, defaultProgrammer = prog, defaultMcu = mcu, defaultBaud = baud) }
            }.launchIn(viewModelScope)

        preferences.ispClockKhz.onEach { v -> _uiState.update { it.copy(ispClockKhz = v) } }.launchIn(viewModelScope)
        preferences.retryCount.onEach { v -> _uiState.update { it.copy(retryCount = v) } }.launchIn(viewModelScope)
        preferences.timeoutMs.onEach { v -> _uiState.update { it.copy(timeoutMs = v) } }.launchIn(viewModelScope)
        preferences.verifyAfterWrite.onEach { v -> _uiState.update { it.copy(verifyAfterWrite = v) } }.launchIn(viewModelScope)
        preferences.chipEraseBeforeWrite.onEach { v -> _uiState.update { it.copy(chipEraseBeforeWrite = v) } }.launchIn(viewModelScope)
        preferences.safeMode.onEach { v -> _uiState.update { it.copy(safeMode = v) } }.launchIn(viewModelScope)
        preferences.autoReconnect.onEach { v -> _uiState.update { it.copy(autoReconnect = v) } }.launchIn(viewModelScope)
        preferences.saveLogs.onEach { v -> _uiState.update { it.copy(saveLogs = v) } }.launchIn(viewModelScope)
        preferences.consoleFontSizeSp.onEach { v -> _uiState.update { it.copy(consoleFontSizeSp = v) } }.launchIn(viewModelScope)
        preferences.useRootUsb.onEach { v -> _uiState.update { it.copy(useRootUsb = v) } }.launchIn(viewModelScope)

        _uiState.update { it.copy(isConfigConfigured = configProvider.isConfigured()) }
    }

    fun setDarkMode(value: String) = viewModelScope.launch { preferences.setDarkMode(value) }
    fun setDefaultProgrammer(value: String) = viewModelScope.launch { preferences.setDefaultProgrammer(value) }
    fun setDefaultMcu(value: String) = viewModelScope.launch { preferences.setDefaultMcu(value) }
    fun setDefaultBaud(value: Int) = viewModelScope.launch { preferences.setDefaultBaud(value) }
    fun setIspClockKhz(value: Float) = viewModelScope.launch { preferences.setIspClockKhz(value) }
    fun setRetryCount(value: Int) = viewModelScope.launch { preferences.setRetryCount(value) }
    fun setTimeoutMs(value: Int) = viewModelScope.launch { preferences.setTimeoutMs(value) }
    fun setVerifyAfterWrite(value: Boolean) = viewModelScope.launch { preferences.setVerifyAfterWrite(value) }
    fun setChipEraseBeforeWrite(value: Boolean) = viewModelScope.launch { preferences.setChipEraseBeforeWrite(value) }
    fun setSafeMode(value: Boolean) = viewModelScope.launch { preferences.setSafeMode(value) }
    fun setAutoReconnect(value: Boolean) = viewModelScope.launch { preferences.setAutoReconnect(value) }
    fun setSaveLogs(value: Boolean) = viewModelScope.launch { preferences.setSaveLogs(value) }
    fun setConsoleFontSizeSp(value: Float) = viewModelScope.launch { preferences.setConsoleFontSizeSp(value) }
    fun setUseRootUsb(value: Boolean) = viewModelScope.launch { preferences.setUseRootUsb(value) }

    fun importConf(uri: Uri) = viewModelScope.launch {
        val ok = configProvider.importFrom(uri)
        _uiState.update { it.copy(isConfigConfigured = configProvider.isConfigured()) }
        _events.emit(if (ok) "avrdude.conf imported." else "Could not import that file.")
    }

    private data class Quad<A, B, C, D>(val a: A, val b: B, val c: C, val d: D)
}

class SettingsViewModelFactory(private val locator: ServiceLocator) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return SettingsViewModel(locator.appPreferences, locator.configProvider) as T
    }
}
