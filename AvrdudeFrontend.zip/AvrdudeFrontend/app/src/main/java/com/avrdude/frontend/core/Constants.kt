package com.avrdude.frontend.core

object Constants {
    const val NATIVE_LIBRARY_FILE_NAME = "libavrdude2.so"
    const val AVRDUDE_CONF_ASSET_HINT = "avrdude.conf"
    const val PREFS_NAME = "avrdude_frontend_prefs"
    const val ACTION_USB_PERMISSION = "com.avrdude.frontend.USB_PERMISSION"
    const val DEFAULT_INHERIT_FD_TARGET = 63
}
