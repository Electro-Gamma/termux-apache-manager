package com.avrdude.frontend.domain.model

/**
 * AVRDUDE memory type identifiers used in `-U <memtype>:<op>:<file>`. These
 * are AVRDUDE's own public vocabulary (documented in its man page), not an
 * invention of this app.
 */
enum class MemoryType(val avrdudeId: String, val displayName: String) {
    FLASH("flash", "Flash"),
    EEPROM("eeprom", "EEPROM"),
    LFUSE("lfuse", "Low Fuse"),
    HFUSE("hfuse", "High Fuse"),
    EFUSE("efuse", "Extended Fuse"),
    FUSE_SINGLE("fuse", "Fuse (single-fuse part)"),
    LOCK("lock", "Lock Bits"),
    SIGNATURE("signature", "Device Signature"),
    CALIBRATION("calibration", "Calibration Byte"),
}

/** File format codes accepted by AVRDUDE's -U :format suffix. */
enum class FileFormat(val code: Char, val displayName: String) {
    INTEL_HEX('i', "Intel HEX"),
    RAW_BINARY('r', "Raw Binary"),
    ELF('e', "ELF"),
    IMMEDIATE('m', "Immediate value (fuses/lock, e.g. 0xD9)"),
    HEX_DUMP('h', "Hex dump (stdout, read-only)"),
}
