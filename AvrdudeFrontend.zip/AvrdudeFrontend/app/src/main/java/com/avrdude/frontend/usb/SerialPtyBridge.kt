package com.avrdude.frontend.usb

import android.hardware.usb.UsbDeviceConnection
import android.os.ParcelFileDescriptor
import com.avrdude.frontend.native.AvrdudeNativeBridge
import com.hoho.android.usbserial.driver.UsbSerialDriver
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.util.SerialInputOutputManager
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException

/**
 * Bridges a real USB-serial connection (via the usb-serial-for-android
 * library — FTDI/CP210x/CH340/PL2303/CDC-ACM support) to a PTY, so AVRDUDE
 * — which expects to open() a path itself and configure it with termios,
 * the way a desktop serial port works — can talk to a USB-CDC/FTDI/CH340
 * adapter that Android does not expose as an openable device node to
 * unprivileged apps at all. AVRDUDE is handed the PTY slave's path as its
 * `-P` port and never knows the difference; this class relays raw bytes
 * (and one control signal) between the slave's master side and the actual
 * USB hardware. See docs/ARCHITECTURE.md, "USB-serial programmers".
 *
 * Lifecycle: create fresh, call [start], run exactly one AVRDUDE invocation
 * against the returned slave path, then [stop] — this class is not meant
 * to be held open across multiple operations. Opening the connection fresh
 * each time is what lets the DTR pulse below trigger the classic
 * Arduino-bootloader auto-reset on every operation, mirroring how opening
 * a real serial port behaves on a desktop OS.
 *
 * **Not verified against real hardware** — this is the newest and
 * least-tested part of this project (built and reasoned about without a
 * device to test against). If a serial-backed programmer misbehaves, the
 * most likely culprits, in rough order of likelihood, are: the DTR pulse
 * polarity/timing below not matching what a given board's bootloader
 * expects, a baud rate mismatch, or [SerialInputOutputManager]'s read
 * buffer chunking interacting badly with AVRDUDE's own read timing —
 * report back the exact Console output and this is very fixable.
 */
class SerialPtyBridge(
    private val driver: UsbSerialDriver,
    private val connection: UsbDeviceConnection,
) {
    private var port: UsbSerialPort? = null
    private var ioManager: SerialInputOutputManager? = null
    private var parcelFd: ParcelFileDescriptor? = null
    private var relayThread: Thread? = null

    @Volatile private var running = false

    /**
     * Opens the USB-serial connection, configures it, pulses DTR, and
     * creates the PTY pair. Returns the slave path to hand AVRDUDE as its
     * `-P` port, or null on any failure.
     */
    fun start(baudRate: Int): String? {
        val masterFd = AvrdudeNativeBridge.nativeOpenPtyMaster()
        if (masterFd < 0) {
            AvrdudeNativeBridge.onDebugMessage("SerialPtyBridge: failed to create PTY master")
            return null
        }
        val slavePath = AvrdudeNativeBridge.nativeGetPtySlavePath(masterFd)
        if (slavePath == null) {
            closeFdQuietly(masterFd)
            AvrdudeNativeBridge.onDebugMessage("SerialPtyBridge: failed to resolve PTY slave path")
            return null
        }

        val serialPort = driver.ports.firstOrNull()
        if (serialPort == null) {
            closeFdQuietly(masterFd)
            AvrdudeNativeBridge.onDebugMessage("SerialPtyBridge: selected USB-serial driver exposes no ports")
            return null
        }

        try {
            serialPort.open(connection)
            serialPort.setParameters(baudRate, UsbSerialPort.DATABITS_8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)
            // Classic Arduino bootloader auto-reset: opening a real serial
            // port on a desktop OS asserts DTR by default, and a low-then-
            // high transition pulses the RESET line through the
            // bootloader's usual 100nF cap-to-RESET circuit. A PTY's own
            // open()/close() on the slave side doesn't propagate to real
            // modem-control lines on its own, so it's pulsed explicitly
            // here instead, once, at bridge start.
            serialPort.setDTR(false)
            Thread.sleep(50)
            serialPort.setDTR(true)
        } catch (e: IOException) {
            AvrdudeNativeBridge.onDebugMessage("SerialPtyBridge: failed to open USB serial port: ${e.message}")
            closeFdQuietly(masterFd)
            return null
        }
        port = serialPort

        val pfd = ParcelFileDescriptor.adoptFd(masterFd)
        parcelFd = pfd
        val masterOut = FileOutputStream(pfd.fileDescriptor)
        val masterIn = FileInputStream(pfd.fileDescriptor)

        running = true

        // Direction 1: bytes arriving from the physical USB device -> PTY
        // master -> AVRDUDE reads them from the slave as if from a real
        // serial port.
        val manager = SerialInputOutputManager(serialPort, object : SerialInputOutputManager.Listener {
            override fun onNewData(data: ByteArray) {
                try {
                    masterOut.write(data)
                } catch (e: IOException) {
                    // Master side already closed — expected during stop().
                }
            }

            override fun onRunError(e: Exception) {
                AvrdudeNativeBridge.onDebugMessage("SerialPtyBridge: USB read error: ${e.message}")
            }
        })
        ioManager = manager
        manager.start()

        // Direction 2: bytes AVRDUDE writes to the slave -> PTY master ->
        // out over the real USB connection.
        val thread = Thread({
            val buf = ByteArray(256)
            try {
                while (running) {
                    val n = masterIn.read(buf)
                    if (n < 0) break
                    if (n > 0) serialPort.write(buf.copyOf(n), 1000)
                }
            } catch (e: Exception) {
                // Expected once stop() closes the master fd out from under this read().
            }
        }, "avrdude-pty-relay")
        thread.isDaemon = true
        relayThread = thread
        thread.start()

        return slavePath
    }

    /** Tears everything down: stops the relay, closes the PTY, closes the
     *  USB connection. Safe to call even if [start] failed partway. */
    fun stop() {
        running = false
        try { ioManager?.stop() } catch (_: Exception) { }
        try { parcelFd?.close() } catch (_: Exception) { } // unblocks the relay thread's blocking read()
        try { relayThread?.join(500) } catch (_: Exception) { }
        try { port?.close() } catch (_: Exception) { }
        ioManager = null
        relayThread = null
        parcelFd = null
        port = null
    }

    private fun closeFdQuietly(fd: Int) {
        try { ParcelFileDescriptor.adoptFd(fd).close() } catch (_: Exception) { }
    }
}
