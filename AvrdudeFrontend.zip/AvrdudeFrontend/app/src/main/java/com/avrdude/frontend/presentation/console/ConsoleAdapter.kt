package com.avrdude.frontend.presentation.console

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.avrdude.frontend.R
import com.avrdude.frontend.databinding.ItemConsoleLineBinding
import com.avrdude.frontend.domain.model.ConsoleEntry
import com.avrdude.frontend.domain.model.LogLevel

class ConsoleAdapter : ListAdapter<ConsoleEntry, ConsoleAdapter.ViewHolder>(DIFF) {

    inner class ViewHolder(val binding: ItemConsoleLineBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemConsoleLineBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val entry = getItem(position)
        holder.binding.textLine.text = entry.message
        val colorRes = when (entry.level) {
            LogLevel.ERROR -> R.color.console_text_error
            LogLevel.WARNING -> R.color.console_text_stderr
            LogLevel.DEBUG -> R.color.console_text_debug
            LogLevel.INFO -> R.color.console_text_default
        }
        holder.binding.textLine.setTextColor(ContextCompat.getColor(holder.binding.root.context, colorRes))
    }

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<ConsoleEntry>() {
            override fun areItemsTheSame(oldItem: ConsoleEntry, newItem: ConsoleEntry) =
                oldItem.timestampMs == newItem.timestampMs && oldItem.message == newItem.message

            override fun areContentsTheSame(oldItem: ConsoleEntry, newItem: ConsoleEntry) = oldItem == newItem
        }
    }
}
