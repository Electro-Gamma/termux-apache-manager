package com.avrdude.frontend.core

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Process
import com.avrdude.frontend.CrashActivity
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.system.exitProcess

/**
 * Installed as the process-wide default uncaught-exception handler
 * (JVM-global — catches a crash on ANY thread, including the main thread
 * during Activity setup, not just a background init coroutine).
 *
 * On a crash, this does two things, in order:
 *   1. Immediately launches [CrashActivity] with the full report as an
 *      intent extra, so the stack trace is visible on-screen right away —
 *      no need to relaunch the app and hope a later screen checks for it.
 *   2. Also writes the same report to a file in app-private storage, as a
 *      redundant fallback in case starting the activity itself fails for
 *      some reason (see MainActivity.checkForCrashReport(), which reads it
 *      on the next normal launch).
 *
 * It does NOT prevent the crash or try to keep the process alive in a
 * broken state — after both of the above, it hands off to whatever the
 * previous default handler was (or kills the process itself if there
 * wasn't one), so the OS's normal crash behavior still happens.
 *
 * IMPORTANT CAVEAT: this only catches JVM-level (Kotlin/Java) exceptions.
 * A crash originating in the native C++ layer (app/src/main/cpp) — a
 * segfault, an abort(), a JNI misuse that corrupts state — bypasses
 * Thread.UncaughtExceptionHandler entirely; the JVM never sees it, Android's
 * native crash handler (debuggerd) does, producing a tombstone that isn't
 * reachable without adb/root. If the app crashes and NEITHER this handler's
 * CrashActivity NOR the file-based fallback ever appears at all — the
 * screen just goes blank/restarts with nothing shown — that absence is
 * itself diagnostic: it points at a native-level crash rather than a Kotlin
 * exception, and needs a different investigation path.
 */
class CrashHandler private constructor(
    private val appContext: Context,
    private val previousHandler: Thread.UncaughtExceptionHandler?,
) : Thread.UncaughtExceptionHandler {

    override fun uncaughtException(thread: Thread, throwable: Throwable) {
        val report = try {
            buildReport(thread, throwable)
        } catch (e: Throwable) {
            "Failed to build full crash report ($e).\n\nOriginal throwable: $throwable"
        }

        try {
            crashLogFile(appContext).writeText(report)
        } catch (e: Throwable) {
            // Best-effort — the immediate CrashActivity launch below is the
            // primary path; this is just the redundant fallback.
        }

        try {
            val intent = Intent(appContext, CrashActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                putExtra(CrashActivity.EXTRA_REPORT, report)
            }
            appContext.startActivity(intent)
        } catch (e: Throwable) {
            // If even showing the crash screen fails, fall through to the
            // platform's default handler below so the OS still logs it.
        }

        if (previousHandler != null) {
            previousHandler.uncaughtException(thread, throwable)
        } else {
            Process.killProcess(Process.myPid())
            exitProcess(10)
        }
    }

    private fun buildReport(thread: Thread, throwable: Throwable): String {
        val sw = StringWriter()
        val pw = PrintWriter(sw)
        pw.println("AVRDUDE Frontend crash report")
        pw.println("Time: ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())}")
        pw.println("Thread: ${thread.name}")
        pw.println("App version: ${appVersionName()}")
        pw.println("Android: ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})")
        pw.println("Device: ${Build.MANUFACTURER} ${Build.MODEL}")
        pw.println("Supported ABIs: ${Build.SUPPORTED_ABIS.joinToString()}")
        pw.println()
        throwable.printStackTrace(pw)
        pw.flush()
        return sw.toString()
    }

    private fun appVersionName(): String = try {
        @Suppress("DEPRECATION")
        appContext.packageManager.getPackageInfo(appContext.packageName, 0).versionName ?: "unknown"
    } catch (e: Exception) {
        "unknown"
    }

    companion object {
        private const val FILE_NAME = "last_crash.txt"

        private fun crashLogFile(context: Context): File = File(context.filesDir, FILE_NAME)

        /** Call once, as early as possible in Application.onCreate(). */
        fun install(context: Context) {
            val existing = Thread.getDefaultUncaughtExceptionHandler()
            if (existing is CrashHandler) return // avoid double-installing
            Thread.setDefaultUncaughtExceptionHandler(CrashHandler(context.applicationContext, existing))
        }

        /** Null if the app didn't crash last run (or the report was already cleared). */
        fun readLastCrash(context: Context): String? {
            val file = crashLogFile(context)
            return if (file.exists()) file.readText() else null
        }

        fun clearLastCrash(context: Context) {
            crashLogFile(context).delete()
        }
    }
}
