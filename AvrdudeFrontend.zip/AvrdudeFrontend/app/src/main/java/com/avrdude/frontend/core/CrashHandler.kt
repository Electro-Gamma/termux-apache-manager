package com.avrdude.frontend.core

import android.content.Context
import android.os.Build
import android.os.Process
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.system.exitProcess

/**
 * Installed as the process-wide default uncaught-exception handler
 * (JVM-global — this catches crashes on ANY thread, including the main
 * thread during Activity setup, not just background coroutines) so that a
 * crash is captured to a plain-text file in app-private storage BEFORE the
 * process dies, and can be shown — with a Copy button — the next time the
 * app launches. See MainActivity.checkForCrashReport().
 *
 * This exists because this app's own diagnostics (the in-app Console) never
 * get a chance to render for a crash that happens during startup, which is
 * exactly the class of crash this is for. It does NOT prevent the crash or
 * try to keep the process alive in a broken state — it saves the report,
 * then hands off to whatever the previous default handler was (or kills the
 * process itself if there wasn't one), so the OS's normal crash behavior
 * still happens afterward.
 */
class CrashHandler private constructor(
    private val appContext: Context,
    private val previousHandler: Thread.UncaughtExceptionHandler?,
) : Thread.UncaughtExceptionHandler {

    override fun uncaughtException(thread: Thread, throwable: Throwable) {
        try {
            writeCrashReport(thread, throwable)
        } catch (e: Throwable) {
            // Must never let the crash handler itself throw — that would
            // replace the real crash report with a useless one, or worse,
            // recurse.
        }
        if (previousHandler != null) {
            previousHandler.uncaughtException(thread, throwable)
        } else {
            Process.killProcess(Process.myPid())
            exitProcess(10)
        }
    }

    private fun writeCrashReport(thread: Thread, throwable: Throwable) {
        val sw = StringWriter()
        val pw = PrintWriter(sw)
        pw.println("AVRDUDE Frontend crash report")
        pw.println("Time: ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())}")
        pw.println("Thread: ${thread.name}")
        pw.println("App version: ${appVersionName()}")
        pw.println("Android: ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})")
        pw.println("Device: ${Build.MANUFACTURER} ${Build.MODEL}")
        pw.println("Supported ABIs: ${Build.SUPPORTED_ABIS.joinToString()}")
        pw.println()
        throwable.printStackTrace(pw)
        pw.flush()

        crashLogFile(appContext).writeText(sw.toString())
    }

    private fun appVersionName(): String = try {
        @Suppress("DEPRECATION")
        appContext.packageManager.getPackageInfo(appContext.packageName, 0).versionName ?: "unknown"
    } catch (e: Exception) {
        "unknown"
    }

    companion object {
        private const val FILE_NAME = "last_crash.txt"

        private fun crashLogFile(context: Context): File = File(context.filesDir, FILE_NAME)

        /** Call once, as early as possible in Application.onCreate(). */
        fun install(context: Context) {
            val existing = Thread.getDefaultUncaughtExceptionHandler()
            if (existing is CrashHandler) return // avoid double-installing
            Thread.setDefaultUncaughtExceptionHandler(CrashHandler(context.applicationContext, existing))
        }

        /** Null if the app didn't crash last run (or the report was already cleared). */
        fun readLastCrash(context: Context): String? {
            val file = crashLogFile(context)
            return if (file.exists()) file.readText() else null
        }

        fun clearLastCrash(context: Context) {
            crashLogFile(context).delete()
        }
    }
}
