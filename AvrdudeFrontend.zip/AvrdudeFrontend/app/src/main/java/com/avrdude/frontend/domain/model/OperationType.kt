package com.avrdude.frontend.domain.model

/**
 * Every distinct action the GUI can ask AVRDUDE to perform. Kept as a single
 * enum (rather than a class hierarchy) because every one of these maps to
 * exactly one AVRDUDE CLI invocation shape — see AvrdudeArgvBuilder.
 */
enum class OperationType {
    GET_VERSION,
    LIST_PROGRAMMERS,
    LIST_DEVICES,
    CONNECT,
    READ_SIGNATURE,
    CHIP_ERASE,
    READ_FLASH,
    WRITE_FLASH,
    VERIFY_FLASH,
    DUMP_FLASH,
    READ_EEPROM,
    WRITE_EEPROM,
    VERIFY_EEPROM,
    DUMP_EEPROM,
    READ_FUSE_LOW,
    READ_FUSE_HIGH,
    READ_FUSE_EXTENDED,
    WRITE_FUSE_LOW,
    WRITE_FUSE_HIGH,
    WRITE_FUSE_EXTENDED,
    READ_LOCK_BITS,
    WRITE_LOCK_BITS,
    READ_CALIBRATION,
    READ_PRODUCTION_SIGNATURE,
}
