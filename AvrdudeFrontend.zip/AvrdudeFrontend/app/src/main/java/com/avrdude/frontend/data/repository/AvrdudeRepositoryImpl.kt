package com.avrdude.frontend.data.repository

import com.avrdude.frontend.core.AvrdudeOperationException
import com.avrdude.frontend.core.Constants
import com.avrdude.frontend.core.NativeBridgeNotReadyException
import com.avrdude.frontend.data.files.AvrdudeConfigProvider
import com.avrdude.frontend.domain.model.ConsoleEntry
import com.avrdude.frontend.domain.model.ConsoleSource
import com.avrdude.frontend.domain.model.FileFormat
import com.avrdude.frontend.domain.model.FuseByteKind
import com.avrdude.frontend.domain.model.LogLevel
import com.avrdude.frontend.domain.model.MemoryType
import com.avrdude.frontend.domain.model.ProgressState
import com.avrdude.frontend.domain.repository.AvrdudeRepository
import com.avrdude.frontend.domain.repository.ConnectionState
import com.avrdude.frontend.native.AvrdudeNativeBridge
import com.avrdude.frontend.native.OperationEvent
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.mapNotNull
import kotlinx.coroutines.flow.merge
import kotlinx.coroutines.flow.scan
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Concrete AvrdudeRepository. This is the class that actually understands
 * "an operation" as: assign an opId -> build argv -> nativeRunAvrdude() ->
 * collect events for that opId -> resolve a Result when Finished arrives.
 * Every public function below follows that exact shape via [runToCompletion].
 */
class AvrdudeRepositoryImpl(
    private val nativeLibDir: String,
    private val workDir: String,
    private val configProvider: AvrdudeConfigProvider,
) : AvrdudeRepository {

    private val repositoryScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var bridgeReady = false
    private var currentUsbFd: Int = -1

    private val _connectionState = MutableStateFlow(ConnectionState.DISCONNECTED)
    override val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    override val consoleEvents: Flow<ConsoleEntry> = merge(
        AvrdudeNativeBridge.events.mapNotNull(::toConsoleEntryOrNull),
        AvrdudeNativeBridge.debugLog.map { msg ->
            ConsoleEntry(System.currentTimeMillis(), ConsoleSource.BRIDGE_DEBUG, LogLevel.DEBUG, msg)
        },
    )

    override val progress: StateFlow<ProgressState> = AvrdudeNativeBridge.events
        .scan(ProgressState.IDLE) { acc, event -> reduceProgress(acc, event) }
        .stateIn(repositoryScope, SharingStarted.Eagerly, ProgressState.IDLE)

    private fun toConsoleEntryOrNull(event: OperationEvent): ConsoleEntry? {
        val now = System.currentTimeMillis()
        return when (event) {
            is OperationEvent.Console -> ConsoleEntry(now, event.source, LogLevel.INFO, event.line)
            is OperationEvent.Warning -> ConsoleEntry(now, ConsoleSource.STDERR, LogLevel.WARNING, event.message)
            is OperationEvent.Error -> ConsoleEntry(now, ConsoleSource.STDERR, LogLevel.ERROR, event.message)
            is OperationEvent.Finished -> ConsoleEntry(
                now, ConsoleSource.BRIDGE_DEBUG,
                if (event.exitCode == 0 && !event.cancelled) LogLevel.INFO else LogLevel.ERROR,
                if (event.cancelled) "Operation cancelled." else "AVRDUDE exited with code ${event.exitCode}.",
            )
            is OperationEvent.Progress -> null // surfaced via `progress`, not the console
        }
    }

    private fun reduceProgress(acc: ProgressState, event: OperationEvent): ProgressState = when (event) {
        is OperationEvent.Progress -> acc.copy(percent = event.percent, label = event.message, isRunning = true)
        is OperationEvent.Finished -> ProgressState.IDLE
        else -> acc
    }

    // ------------------------------------------------------------------
    // Lifecycle
    // ------------------------------------------------------------------

    override suspend fun initialize(): Result<Unit> = withContext(Dispatchers.IO) {
        val ok = AvrdudeNativeBridge.nativeInitialize(nativeLibDir, workDir)
        bridgeReady = ok
        if (ok) Result.success(Unit)
        else Result.failure(
            NativeBridgeNotReadyException(
                "Could not initialize native bridge. Expected ${Constants.NATIVE_LIBRARY_FILE_NAME} " +
                    "under $nativeLibDir — check that the app was built with extractNativeLibs=true."
            )
        )
    }

    override fun shutdown() {
        AvrdudeNativeBridge.nativeShutdown()
        bridgeReady = false
        _connectionState.value = ConnectionState.DISCONNECTED
    }

    override fun attachUsbFileDescriptor(fd: Int) {
        currentUsbFd = fd
    }

    override fun detachUsbFileDescriptor() {
        currentUsbFd = -1
    }

    // ------------------------------------------------------------------
    // Core execution primitive
    // ------------------------------------------------------------------

    /**
     * Runs one AVRDUDE invocation to completion and returns every line it
     * printed (stdout+stderr, in arrival order) on success, or a failure
     * carrying the exit code / cancellation flag / console tail.
     */
    private suspend fun runToCompletion(args: List<String>): Result<List<String>> = withContext(Dispatchers.IO) {
        if (!bridgeReady) {
            return@withContext Result.failure(NativeBridgeNotReadyException("initialize() has not completed successfully"))
        }
        if (!configProvider.isConfigured()) {
            return@withContext Result.failure(
                NativeBridgeNotReadyException("avrdude.conf has not been imported — see Settings > Import avrdude.conf")
            )
        }

        val opId = AvrdudeNativeBridge.nextOpId()
        val collected = mutableListOf<String>()
        val outcome = CompletableDeferred<Result<List<String>>>()

        val collectorJob = launch {
            AvrdudeNativeBridge.events.filter { it.opId == opId }.collect { event ->
                when (event) {
                    is OperationEvent.Console -> collected += event.line
                    is OperationEvent.Warning -> collected += "WARNING: ${event.message}"
                    is OperationEvent.Error -> collected += "ERROR: ${event.message}"
                    is OperationEvent.Finished -> outcome.complete(
                        if (event.exitCode == 0 && !event.cancelled) {
                            Result.success(collected.toList())
                        } else {
                            Result.failure(
                                AvrdudeOperationException(
                                    message = if (event.cancelled) "Operation cancelled"
                                              else "AVRDUDE exited with code ${event.exitCode}",
                                    exitCode = event.exitCode,
                                    wasCancelled = event.cancelled,
                                    consoleTail = collected.takeLast(25),
                                )
                            )
                        }
                    )
                    is OperationEvent.Progress -> { /* handled by `progress` StateFlow */ }
                }
            }
        }

        val envExtra = if (currentUsbFd >= 0) arrayOf("AVRDUDE_USB_FD=$currentUsbFd") else emptyArray()
        val inheritFd = currentUsbFd
        val started = AvrdudeNativeBridge.nativeRunAvrdude(
            opId, args.toTypedArray(), envExtra, inheritFd, Constants.DEFAULT_INHERIT_FD_TARGET,
        )

        val result = if (!started) {
            Result.failure(AvrdudeOperationException("Failed to start AVRDUDE (already busy, or spawn error)", -1, false))
        } else {
            outcome.await()
        }
        collectorJob.cancel()
        result
    }

    private fun confPath(): Result<String> = try {
        Result.success(configProvider.requireConfPath())
    } catch (e: IllegalStateException) {
        Result.failure(NativeBridgeNotReadyException(e.message ?: "avrdude.conf not configured"))
    }

    // ------------------------------------------------------------------
    // Query-style operations
    // ------------------------------------------------------------------

    override suspend fun getVersion(): Result<String> {
        val conf = confPath().getOrElse { return Result.failure(it) }
        return runToCompletion(AvrdudeArgvBuilder.versionProbe(conf)).map { lines ->
            lines.firstOrNull { it.contains("Version", ignoreCase = true) } ?: lines.joinToString("\n")
        }
    }

    override suspend fun listSupportedProgrammers(): Result<List<String>> {
        val conf = confPath().getOrElse { return Result.failure(it) }
        return runToCompletion(AvrdudeArgvBuilder.listProgrammers(conf)).map(::parseIdList)
    }

    override suspend fun listSupportedDevices(): Result<List<String>> {
        val conf = confPath().getOrElse { return Result.failure(it) }
        return runToCompletion(AvrdudeArgvBuilder.listParts(conf)).map(::parseIdList)
    }

    /** Parses AVRDUDE's `-c ?` / `-p ?` listing output. Both print one entry
     *  per line, typically "  id       = description" — we only need the id. */
    private fun parseIdList(lines: List<String>): List<String> {
        val idPattern = Regex("""^\s*([A-Za-z0-9_.\-]+)\s*=.*$""")
        val ids = lines.mapNotNull { idPattern.matchEntire(it)?.groupValues?.get(1) }
        return ids.ifEmpty { lines.map { it.trim() }.filter { it.isNotEmpty() } }
    }

    // ------------------------------------------------------------------
    // Connection
    // ------------------------------------------------------------------

    override suspend fun connect(params: ConnectionParams): Result<Unit> {
        _connectionState.value = ConnectionState.CONNECTING
        val conf = confPath().getOrElse { _connectionState.value = ConnectionState.ERROR; return Result.failure(it) }
        val result = runToCompletion(AvrdudeArgvBuilder.connectOnly(conf, params)).map {}
        _connectionState.value = if (result.isSuccess) ConnectionState.CONNECTED else ConnectionState.ERROR
        return result
    }

    override fun disconnect() {
        _connectionState.value = ConnectionState.DISCONNECTED
    }

    override suspend fun readSignature(params: ConnectionParams): Result<String> {
        val conf = confPath().getOrElse { return Result.failure(it) }
        val tmp = File(workDir, "signature_${System.nanoTime()}.bin")
        val result = runToCompletion(AvrdudeArgvBuilder.readSignature(conf, params, tmp.absolutePath))
        return result.mapCatching {
            val bytes = tmp.readBytes()
            tmp.delete()
            bytes.joinToString("-") { b -> "%02X".format(b) }
        }
    }

    // ------------------------------------------------------------------
    // Flash / EEPROM
    // ------------------------------------------------------------------

    override suspend fun chipErase(params: ConnectionParams): Result<Unit> {
        val conf = confPath().getOrElse { return Result.failure(it) }
        return runToCompletion(AvrdudeArgvBuilder.chipErase(conf, params)).map {}
    }

    override suspend fun readFlash(params: ConnectionParams, outFilePath: String, format: FileFormat): Result<Unit> {
        val conf = confPath().getOrElse { return Result.failure(it) }
        return runToCompletion(AvrdudeArgvBuilder.readMemory(conf, params, MemoryType.FLASH, outFilePath, format)).map {}
    }

    override suspend fun writeFlash(
        params: ConnectionParams, inFilePath: String, format: FileFormat,
        verifyAfterWrite: Boolean, chipEraseFirst: Boolean,
    ): Result<Unit> {
        val conf = confPath().getOrElse { return Result.failure(it) }
        return runToCompletion(
            AvrdudeArgvBuilder.writeMemory(conf, params, MemoryType.FLASH, inFilePath, format, verifyAfterWrite, chipEraseFirst)
        ).map {}
    }

    override suspend fun verifyFlash(params: ConnectionParams, referenceFilePath: String, format: FileFormat): Result<Unit> {
        val conf = confPath().getOrElse { return Result.failure(it) }
        return runToCompletion(AvrdudeArgvBuilder.verifyMemory(conf, params, MemoryType.FLASH, referenceFilePath, format)).map {}
    }

    override suspend fun readEEPROM(params: ConnectionParams, outFilePath: String, format: FileFormat): Result<Unit> {
        val conf = confPath().getOrElse { return Result.failure(it) }
        return runToCompletion(AvrdudeArgvBuilder.readMemory(conf, params, MemoryType.EEPROM, outFilePath, format)).map {}
    }

    override suspend fun writeEEPROM(
        params: ConnectionParams, inFilePath: String, format: FileFormat, verifyAfterWrite: Boolean,
    ): Result<Unit> {
        val conf = confPath().getOrElse { return Result.failure(it) }
        return runToCompletion(
            AvrdudeArgvBuilder.writeMemory(conf, params, MemoryType.EEPROM, inFilePath, format, verifyAfterWrite, chipEraseFirst = false)
        ).map {}
    }

    override suspend fun verifyEEPROM(params: ConnectionParams, referenceFilePath: String, format: FileFormat): Result<Unit> {
        val conf = confPath().getOrElse { return Result.failure(it) }
        return runToCompletion(AvrdudeArgvBuilder.verifyMemory(conf, params, MemoryType.EEPROM, referenceFilePath, format)).map {}
    }

    // ------------------------------------------------------------------
    // Fuses / lock / calibration — all single-byte memories
    // ------------------------------------------------------------------

    private fun fuseMemoryType(byte: FuseByteKind): MemoryType = when (byte) {
        FuseByteKind.LOW -> MemoryType.LFUSE
        FuseByteKind.HIGH -> MemoryType.HFUSE
        FuseByteKind.EXTENDED -> MemoryType.EFUSE
        FuseByteKind.SINGLE -> MemoryType.FUSE_SINGLE
        FuseByteKind.LOCK -> MemoryType.LOCK
    }

    private suspend fun readSingleByteMemory(params: ConnectionParams, memType: MemoryType): Result<Int> {
        val conf = confPath().getOrElse { return Result.failure(it) }
        val tmp = File(workDir, "${memType.avrdudeId}_${System.nanoTime()}.bin")
        val result = runToCompletion(AvrdudeArgvBuilder.readSingleByte(conf, params, memType, tmp.absolutePath))
        return result.mapCatching {
            val bytes = tmp.readBytes()
            tmp.delete()
            require(bytes.isNotEmpty()) { "AVRDUDE produced no output reading ${memType.displayName}" }
            bytes[0].toInt() and 0xFF
        }
    }

    private suspend fun writeSingleByteMemory(params: ConnectionParams, memType: MemoryType, value: Int): Result<Unit> {
        val conf = confPath().getOrElse { return Result.failure(it) }
        val hex = "0x" + (value and 0xFF).toString(16).uppercase().padStart(2, '0')
        return runToCompletion(AvrdudeArgvBuilder.writeImmediate(conf, params, memType, hex)).map {}
    }

    override suspend fun readFuse(params: ConnectionParams, byte: FuseByteKind): Result<Int> =
        readSingleByteMemory(params, fuseMemoryType(byte))

    override suspend fun writeFuse(params: ConnectionParams, byte: FuseByteKind, value: Int): Result<Unit> =
        writeSingleByteMemory(params, fuseMemoryType(byte), value)

    override suspend fun readLockBits(params: ConnectionParams): Result<Int> =
        readSingleByteMemory(params, MemoryType.LOCK)

    override suspend fun writeLockBits(params: ConnectionParams, value: Int): Result<Unit> =
        writeSingleByteMemory(params, MemoryType.LOCK, value)

    override suspend fun readCalibration(params: ConnectionParams): Result<Int> =
        readSingleByteMemory(params, MemoryType.CALIBRATION)

    // ------------------------------------------------------------------

    override fun cancelOperation() {
        AvrdudeNativeBridge.nativeCancel()
    }
}
