package com.avrdude.frontend.presentation.main

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.NavHostFragment
import com.avrdude.frontend.AvrdudeApp
import com.avrdude.frontend.R
import com.avrdude.frontend.core.CrashHandler
import com.avrdude.frontend.databinding.ActivityMainBinding
import com.avrdude.frontend.presentation.dashboard.DashboardViewModel
import com.avrdude.frontend.presentation.dashboard.DashboardViewModelFactory
import kotlinx.coroutines.launch

/**
 * Single-activity host. Owns the persistent bottom action toolbar (Detect /
 * Read / Write / Verify / Erase / EEPROM / Fuses / Stop) and the top app bar
 * menu (Dashboard / Console / Settings), and hosts the Navigation Component
 * graph for the four sections in between.
 *
 * DashboardViewModel is scoped to the ACTIVITY (not the fragment) precisely
 * so this toolbar — which lives outside the nav host — can drive the same
 * state DashboardFragment observes, regardless of which section is
 * currently visible.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val dashboardViewModel: DashboardViewModel by viewModels {
        DashboardViewModelFactory((application as AvrdudeApp).serviceLocator)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Checked FIRST, before touching the binding/layout/navigation setup
        // below — if last run crashed somewhere further down in this very
        // function, the report for it still needs to reach the screen even
        // if this run hits the same crash again a moment later. A Dialog
        // doesn't need setContentView() to have run first, so this is safe
        // to show right here.
        checkForCrashReport()

        // Android 15+ (API 35, which this app targets) forces edge-to-edge
        // drawing by default: content draws behind the status bar AND the
        // gesture-navigation area unless the app explicitly pads for them.
        // Without this, the bottom action toolbar sits partly underneath
        // the system gesture bar — visually squashed/clipped at the very
        // bottom edge, which is exactly what showed up in testing. We keep
        // edge-to-edge (nicer, and the modern default) but pad our own
        // content away from the system bars via insets instead of opting
        // out of it.
        WindowCompat.setDecorFitsSystemWindows(window, false)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        applyWindowInsets()

        setupToolbarMenu()
        setupBottomActionToolbar()
        observeRunningState()
    }

    /** Pads the top app bar below the status bar and the bottom action
     *  toolbar above the gesture-navigation area, using real-time system
     *  bar insets rather than a fixed guess (works across gesture-nav vs.
     *  3-button-nav, and across different device cutouts). */
    private fun applyWindowInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { _, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            binding.toolbar.updatePadding(top = systemBars.top, left = systemBars.left, right = systemBars.right)
            binding.bottomToolbarScroll.updatePadding(bottom = systemBars.bottom, left = systemBars.left, right = systemBars.right)
            insets
        }
    }

    /** Shows the previous run's crash report (if any), with Copy / Share /
     *  Dismiss actions, so a real stack trace is available without needing
     *  adb or a PC. See core/CrashHandler.kt. */
    private fun checkForCrashReport() {
        val report = CrashHandler.readLastCrash(this) ?: return

        val view = layoutInflater.inflate(R.layout.dialog_crash_report, null)
        view.findViewById<TextView>(R.id.textCrashLog).text = report

        AlertDialog.Builder(this)
            .setTitle("The app crashed last time")
            .setView(view)
            .setCancelable(false)
            .setPositiveButton("Copy") { _, _ ->
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("AVRDUDE Frontend crash report", report))
                Toast.makeText(this, "Copied to clipboard", Toast.LENGTH_SHORT).show()
            }
            .setNeutralButton("Share") { _, _ ->
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, report)
                }
                startActivity(Intent.createChooser(intent, "Share crash report"))
            }
            .setNegativeButton("Dismiss") { _, _ ->
                CrashHandler.clearLastCrash(this)
            }
            .show()
    }

    private fun navHostFragment(): NavHostFragment =
        supportFragmentManager.findFragmentById(R.id.navHostFragment) as NavHostFragment

    private fun setupToolbarMenu() {
        binding.toolbar.setOnMenuItemClickListener { item ->
            val navController = navHostFragment().navController
            when (item.itemId) {
                R.id.menuDashboard -> navController.navigate(R.id.dashboardFragment)
                R.id.menuConsole -> navController.navigate(R.id.consoleFragment)
                R.id.menuSettings -> navController.navigate(R.id.settingsFragment)
            }
            true
        }
    }

    private fun setupBottomActionToolbar() {
        val navController by lazy { navHostFragment().navController }

        binding.btnDetect.setOnClickListener {
            navController.navigate(R.id.dashboardFragment)
            dashboardViewModel.detectDevice()
        }
        binding.btnRead.setOnClickListener {
            navController.navigate(R.id.dashboardFragment)
            dashboardViewModel.readFlash()
        }
        binding.btnWrite.setOnClickListener {
            navController.navigate(R.id.dashboardFragment)
            dashboardViewModel.writeFlash()
        }
        binding.btnVerify.setOnClickListener {
            navController.navigate(R.id.dashboardFragment)
            dashboardViewModel.verifyFlash()
        }
        binding.btnErase.setOnClickListener {
            navController.navigate(R.id.dashboardFragment)
            dashboardViewModel.confirmAndChipErase()
        }
        binding.btnEeprom.setOnClickListener {
            navController.navigate(R.id.dashboardFragment)
            dashboardViewModel.requestFocusEepromSection()
        }
        binding.btnFuses.setOnClickListener {
            navController.navigate(R.id.fuseEditorFragment)
        }
        binding.btnStop.setOnClickListener {
            dashboardViewModel.cancelOperation()
        }
    }

    /** Disables the action buttons while an operation is running, since
     *  AVRDUDE / the physical programmer can only do one thing at a time. */
    private fun observeRunningState() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                dashboardViewModel.progress.collect { progress ->
                    val actionButtons = listOf(
                        binding.btnDetect, binding.btnRead, binding.btnWrite,
                        binding.btnVerify, binding.btnErase, binding.btnEeprom, binding.btnFuses,
                    )
                    actionButtons.forEach { it.isEnabled = !progress.isRunning }
                    binding.btnStop.isEnabled = progress.isRunning
                }
            }
        }
    }
}
