package com.avrdude.frontend.presentation.main

import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.NavHostFragment
import com.avrdude.frontend.AvrdudeApp
import com.avrdude.frontend.R
import com.avrdude.frontend.databinding.ActivityMainBinding
import com.avrdude.frontend.presentation.dashboard.DashboardViewModel
import com.avrdude.frontend.presentation.dashboard.DashboardViewModelFactory
import kotlinx.coroutines.launch

/**
 * Single-activity host. Owns the persistent bottom action toolbar (Detect /
 * Read / Write / Verify / Erase / EEPROM / Fuses / Stop) and the top app bar
 * menu (Dashboard / Console / Settings), and hosts the Navigation Component
 * graph for the four sections in between.
 *
 * DashboardViewModel is scoped to the ACTIVITY (not the fragment) precisely
 * so this toolbar — which lives outside the nav host — can drive the same
 * state DashboardFragment observes, regardless of which section is
 * currently visible.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val dashboardViewModel: DashboardViewModel by viewModels {
        DashboardViewModelFactory((application as AvrdudeApp).serviceLocator)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbarMenu()
        setupBottomActionToolbar()
        observeRunningState()
    }

    private fun navHostFragment(): NavHostFragment =
        supportFragmentManager.findFragmentById(R.id.navHostFragment) as NavHostFragment

    private fun setupToolbarMenu() {
        binding.toolbar.setOnMenuItemClickListener { item ->
            val navController = navHostFragment().navController
            when (item.itemId) {
                R.id.menuDashboard -> navController.navigate(R.id.dashboardFragment)
                R.id.menuConsole -> navController.navigate(R.id.consoleFragment)
                R.id.menuSettings -> navController.navigate(R.id.settingsFragment)
            }
            true
        }
    }

    private fun setupBottomActionToolbar() {
        val navController by lazy { navHostFragment().navController }

        binding.btnDetect.setOnClickListener {
            navController.navigate(R.id.dashboardFragment)
            dashboardViewModel.detectDevice()
        }
        binding.btnRead.setOnClickListener {
            navController.navigate(R.id.dashboardFragment)
            dashboardViewModel.readFlash()
        }
        binding.btnWrite.setOnClickListener {
            navController.navigate(R.id.dashboardFragment)
            dashboardViewModel.writeFlash()
        }
        binding.btnVerify.setOnClickListener {
            navController.navigate(R.id.dashboardFragment)
            dashboardViewModel.verifyFlash()
        }
        binding.btnErase.setOnClickListener {
            navController.navigate(R.id.dashboardFragment)
            dashboardViewModel.confirmAndChipErase()
        }
        binding.btnEeprom.setOnClickListener {
            navController.navigate(R.id.dashboardFragment)
            dashboardViewModel.requestFocusEepromSection()
        }
        binding.btnFuses.setOnClickListener {
            navController.navigate(R.id.fuseEditorFragment)
        }
        binding.btnStop.setOnClickListener {
            dashboardViewModel.cancelOperation()
        }
    }

    /** Disables the action buttons while an operation is running, since
     *  AVRDUDE / the physical programmer can only do one thing at a time. */
    private fun observeRunningState() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                dashboardViewModel.progress.collect { progress ->
                    val actionButtons = listOf(
                        binding.btnDetect, binding.btnRead, binding.btnWrite,
                        binding.btnVerify, binding.btnErase, binding.btnEeprom, binding.btnFuses,
                    )
                    actionButtons.forEach { it.isEnabled = !progress.isRunning }
                    binding.btnStop.isEnabled = progress.isRunning
                }
            }
        }
    }
}
