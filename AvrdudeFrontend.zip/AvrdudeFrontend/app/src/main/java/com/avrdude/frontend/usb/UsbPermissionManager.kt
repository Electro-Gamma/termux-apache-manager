package com.avrdude.frontend.usb

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbManager
import android.os.Build
import com.avrdude.frontend.core.Constants
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.callbackFlow

/**
 * Wraps Android's USB Host APIs: enumerates attached devices, requests
 * permission, and opens a UsbDeviceConnection so its raw file descriptor can
 * be handed down to the native layer (see AvrdudeRepository.attachUsbFileDescriptor).
 *
 * This class deliberately does NOT talk to AVRDUDE at all — it only manages
 * the Android-side USB permission dance. The Dashboard/USB ViewModel wires
 * its output into AvrdudeRepository.
 */
class UsbPermissionManager(private val context: Context) {

    private val usbManager: UsbManager =
        context.getSystemService(Context.USB_SERVICE) as UsbManager

    private val _devices = MutableStateFlow<List<UsbDeviceInfo>>(emptyList())
    val devices: StateFlow<List<UsbDeviceInfo>> = _devices.asStateFlow()

    private var openConnection: UsbDeviceConnection? = null
    private var openDevice: UsbDevice? = null

    fun refreshDeviceList() {
        _devices.value = usbManager.deviceList.values.map { toInfo(it) }
    }

    private fun toInfo(device: UsbDevice): UsbDeviceInfo {
        val hasPermission = usbManager.hasPermission(device)
        return UsbDeviceInfo(
            deviceName = device.deviceName,
            vendorId = device.vendorId,
            productId = device.productId,
            manufacturerName = if (hasPermission) device.manufacturerName else null,
            productName = if (hasPermission) device.productName else null,
            serialNumber = if (hasPermission) runCatching { device.serialNumber }.getOrNull() else null,
            hasPermission = hasPermission,
            guessedProgrammerId = SupportedProgrammers.guessProgrammerId(device.vendorId, device.productId),
        )
    }

    /**
     * Requests permission for [device], suspending (as a cold Flow the
     * caller collects once) until the user responds or the request fails.
     * Emits true/false exactly once then completes.
     */
    fun requestPermission(device: UsbDevice) = callbackFlow {
        if (usbManager.hasPermission(device)) {
            trySend(true)
            close()
            return@callbackFlow
        }

        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context, intent: Intent) {
                if (intent.action != Constants.ACTION_USB_PERMISSION) return
                val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
                trySend(granted)
                close()
            }
        }

        val filter = IntentFilter(Constants.ACTION_USB_PERMISSION)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            context.registerReceiver(receiver, filter)
        }

        val piFlags = PendingIntent.FLAG_UPDATE_CURRENT or
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0
        val permissionIntent = PendingIntent.getBroadcast(
            context, 0, Intent(Constants.ACTION_USB_PERMISSION), piFlags,
        )
        usbManager.requestPermission(device, permissionIntent)

        awaitClose { context.unregisterReceiver(receiver) }
    }

    /**
     * Opens the device and returns its raw native file descriptor (valid as
     * long as the returned connection is kept open — call closeConnection()
     * when the operation session ends, not after every single AVRDUDE
     * invocation, since re-opening resets the USB configuration each time).
     */
    fun openDeviceAndGetFd(device: UsbDevice): Int? {
        closeConnection()
        val connection = usbManager.openDevice(device) ?: return null
        openConnection = connection
        openDevice = device
        return connection.fileDescriptor
    }

    fun closeConnection() {
        openConnection?.close()
        openConnection = null
        openDevice = null
    }

    fun findDeviceByName(deviceName: String): UsbDevice? =
        usbManager.deviceList.values.find { it.deviceName == deviceName }
}
