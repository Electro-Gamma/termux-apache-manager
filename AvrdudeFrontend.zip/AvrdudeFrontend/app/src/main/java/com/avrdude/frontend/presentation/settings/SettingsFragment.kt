package com.avrdude.frontend.presentation.settings

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.widget.addTextChangedListener
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.avrdude.frontend.AvrdudeApp
import com.avrdude.frontend.data.devicedb.McuDatabase
import com.avrdude.frontend.databinding.FragmentSettingsBinding
import com.avrdude.frontend.domain.model.KnownProgrammers
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.launch

class SettingsFragment : Fragment() {

    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!

    private val viewModel: SettingsViewModel by viewModels {
        SettingsViewModelFactory((requireActivity().application as AvrdudeApp).serviceLocator)
    }

    private val pickConfFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) viewModel.importConf(uri)
    }

    private val darkModeOptions = listOf("system", "light", "dark")

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnImportConf.setOnClickListener { pickConfFile.launch(arrayOf("*/*")) }

        binding.dropdownDarkMode.setAdapter(ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, darkModeOptions))
        binding.dropdownDarkMode.setOnItemClickListener { _, _, position, _ ->
            val mode = darkModeOptions[position]
            viewModel.setDarkMode(mode)
            applyDarkMode(mode)
        }

        val programmerNames = KnownProgrammers.CATALOG.map { it.id }
        binding.dropdownDefaultProgrammer.setAdapter(ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, programmerNames))
        binding.dropdownDefaultProgrammer.setOnItemClickListener { _, _, position, _ ->
            viewModel.setDefaultProgrammer(programmerNames[position])
        }

        val mcuNames = McuDatabase.KNOWN_DEVICES.map { it.partId }
        binding.dropdownDefaultMcu.setAdapter(ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, mcuNames))
        binding.dropdownDefaultMcu.setOnItemClickListener { _, _, position, _ ->
            viewModel.setDefaultMcu(mcuNames[position])
        }

        binding.editDefaultBaud.addTextChangedListener { t -> t?.toString()?.toIntOrNull()?.let(viewModel::setDefaultBaud) }
        binding.editIspClock.addTextChangedListener { t -> t?.toString()?.toFloatOrNull()?.let(viewModel::setIspClockKhz) }
        binding.editRetryCount.addTextChangedListener { t -> t?.toString()?.toIntOrNull()?.let(viewModel::setRetryCount) }
        binding.editTimeout.addTextChangedListener { t -> t?.toString()?.toIntOrNull()?.let(viewModel::setTimeoutMs) }

        binding.switchVerifyAfterWrite.setOnCheckedChangeListener { _, c -> viewModel.setVerifyAfterWrite(c) }
        binding.switchChipEraseBeforeWrite.setOnCheckedChangeListener { _, c -> viewModel.setChipEraseBeforeWrite(c) }
        binding.switchSafeMode.setOnCheckedChangeListener { _, c -> viewModel.setSafeMode(c) }
        binding.switchAutoReconnect.setOnCheckedChangeListener { _, c -> viewModel.setAutoReconnect(c) }
        binding.switchSaveLogs.setOnCheckedChangeListener { _, c -> viewModel.setSaveLogs(c) }
        binding.switchUseRootUsb.setOnCheckedChangeListener { _, c -> viewModel.setUseRootUsb(c) }

        binding.sliderConsoleFontSize.addOnChangeListener { _, value, fromUser ->
            if (fromUser) viewModel.setConsoleFontSizeSp(value)
        }

        observeState()
    }

    private fun applyDarkMode(mode: String) {
        val nightMode = when (mode) {
            "light" -> AppCompatDelegate.MODE_NIGHT_NO
            "dark" -> AppCompatDelegate.MODE_NIGHT_YES
            else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
        }
        AppCompatDelegate.setDefaultNightMode(nightMode)
    }

    private fun observeState() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.uiState.collect { state ->
                        if (binding.dropdownDarkMode.text?.toString() != state.darkMode) {
                            binding.dropdownDarkMode.setText(state.darkMode, false)
                        }
                        if (binding.dropdownDefaultProgrammer.text?.toString() != state.defaultProgrammer) {
                            binding.dropdownDefaultProgrammer.setText(state.defaultProgrammer, false)
                        }
                        if (binding.dropdownDefaultMcu.text?.toString() != state.defaultMcu) {
                            binding.dropdownDefaultMcu.setText(state.defaultMcu, false)
                        }
                        setTextIfChanged(binding.editDefaultBaud, state.defaultBaud.toString())
                        setTextIfChanged(binding.editIspClock, state.ispClockKhz.toString())
                        setTextIfChanged(binding.editRetryCount, state.retryCount.toString())
                        setTextIfChanged(binding.editTimeout, state.timeoutMs.toString())
                        binding.switchVerifyAfterWrite.isChecked = state.verifyAfterWrite
                        binding.switchChipEraseBeforeWrite.isChecked = state.chipEraseBeforeWrite
                        binding.switchSafeMode.isChecked = state.safeMode
                        binding.switchAutoReconnect.isChecked = state.autoReconnect
                        binding.switchSaveLogs.isChecked = state.saveLogs
                        binding.switchUseRootUsb.isChecked = state.useRootUsb
                        if (binding.sliderConsoleFontSize.value != state.consoleFontSizeSp) {
                            binding.sliderConsoleFontSize.value = state.consoleFontSizeSp.coerceIn(10f, 20f)
                        }
                        binding.btnImportConf.text = if (state.isConfigConfigured) {
                            "avrdude.conf imported — tap to replace"
                        } else {
                            getString(com.avrdude.frontend.R.string.settings_import_conf)
                        }
                    }
                }
                launch {
                    viewModel.events.collect { message -> Snackbar.make(binding.root, message, Snackbar.LENGTH_SHORT).show() }
                }
            }
        }
    }

    private fun setTextIfChanged(field: com.google.android.material.textfield.TextInputEditText, value: String) {
        if (field.text?.toString() != value) field.setText(value)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
