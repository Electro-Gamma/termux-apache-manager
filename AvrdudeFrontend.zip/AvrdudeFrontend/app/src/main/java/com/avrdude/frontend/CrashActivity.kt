package com.avrdude.frontend

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * A deliberately bare-bones crash screen: plain android.widget views built
 * in code (no XML inflate, no ViewBinding, no Material components, no
 * custom app theme) so that whatever broke the main app can't also break
 * this screen. Runs in its own process (see the `android:process=":crashhandler"`
 * declaration in AndroidManifest.xml) so it survives independently of the
 * crashed main process too.
 *
 * Shown automatically by core/CrashHandler.kt's global uncaught-exception
 * handler whenever anything anywhere in the app throws — this puts the
 * exact exception and stack trace on the device screen itself, with no
 * adb/PC required. Tap "Copy to clipboard" and paste it wherever it's
 * needed.
 *
 * Only catches JVM-level exceptions — see the caveat in CrashHandler's doc
 * comment about native (C++) crashes, which never reach here at all.
 */
class CrashActivity : Activity() {

    companion object {
        const val EXTRA_REPORT = "report"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val report = intent.getStringExtra(EXTRA_REPORT) ?: "No crash details were captured."

        val scrollView = ScrollView(this)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 64, 32, 64)
        }

        val title = TextView(this).apply {
            text = "AVRDUDE Frontend crashed — here's why:"
            textSize = 18f
            setPadding(0, 0, 0, 24)
        }

        val copyButton = Button(this).apply {
            text = "Copy to clipboard"
            setOnClickListener {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("AVRDUDE Frontend crash report", report))
                Toast.makeText(this@CrashActivity, "Copied", Toast.LENGTH_SHORT).show()
            }
        }

        val shareButton = Button(this).apply {
            text = "Share"
            setOnClickListener {
                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, report)
                }
                startActivity(Intent.createChooser(sendIntent, "Share crash report").apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                })
            }
        }

        val buttonRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(copyButton)
            addView(shareButton)
        }

        val traceView = TextView(this).apply {
            text = report
            setTextIsSelectable(true)
            typeface = Typeface.MONOSPACE
            textSize = 12f
            setPadding(0, 24, 0, 0)
        }

        container.addView(title)
        container.addView(buttonRow)
        container.addView(
            traceView,
            ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT),
        )
        scrollView.addView(container)
        setContentView(scrollView)
    }
}
