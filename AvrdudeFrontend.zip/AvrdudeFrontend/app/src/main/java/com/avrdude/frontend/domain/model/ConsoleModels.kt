package com.avrdude.frontend.domain.model

/** Which stream a line of AVRDUDE output arrived on. */
enum class ConsoleSource { STDOUT, STDERR, BRIDGE_DEBUG }

/** Severity used purely for console filtering/coloring in the UI. */
enum class LogLevel { DEBUG, INFO, WARNING, ERROR }

data class ConsoleEntry(
    val timestampMs: Long,
    val source: ConsoleSource,
    val level: LogLevel,
    val message: String,
)
