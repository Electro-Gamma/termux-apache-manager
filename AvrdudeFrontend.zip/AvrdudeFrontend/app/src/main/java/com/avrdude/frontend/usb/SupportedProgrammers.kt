package com.avrdude.frontend.usb

/**
 * Maps known VID/PID pairs (mirrors res/xml/device_filter.xml) to a
 * best-guess AVRDUDE programmer id, purely to pre-select something sensible
 * in the Programmer Selection panel when a recognized device is plugged in.
 * The user can always override the selection — this is a convenience, not a
 * restriction (any of the programmer ids AVRDUDE itself supports can be
 * chosen manually regardless of what's detected here).
 */
object SupportedProgrammers {
    private data class Key(val vid: Int, val pid: Int)

    private val lookup: Map<Key, String> = mapOf(
        Key(0x16C0, 0x05DC) to "usbasp",
        Key(0x1781, 0x0C9F) to "usbtiny",
        Key(0x03EB, 0x2104) to "avrispmkii",
        Key(0x03EB, 0x2141) to "atmelice_isp",
        Key(0x03EB, 0x2140) to "jtagice3_isp",
        Key(0x03EB, 0x2101) to "jtagmkII",
        Key(0x03EB, 0x2107) to "dragon_isp",
        // USB-serial adapters are ambiguous (could carry stk500v1, avr109,
        // jtag2updi, or serialupdi depending on what's programmed onto the
        // far end / attached sketch) — guessed as the most common default.
        Key(0x0403, 0x6001) to "arduino",
        Key(0x0403, 0x6015) to "arduino",
        Key(0x10C4, 0xEA60) to "serialupdi",
        Key(0x1A86, 0x7523) to "arduino",
        Key(0x2341, 0x0043) to "arduino", // Arduino Uno
        Key(0x2341, 0x0042) to "stk500v2", // Arduino Mega 2560
        Key(0x2341, 0x8036) to "avr109",   // Arduino Leonardo
    )

    fun guessProgrammerId(vendorId: Int, productId: Int): String? = lookup[Key(vendorId, productId)]

    fun friendlyName(vendorId: Int, productId: Int): String? = when (guessProgrammerId(vendorId, productId)) {
        "usbasp" -> "USBasp"
        "usbtiny" -> "USBtinyISP"
        "avrispmkii" -> "AVRISP mkII"
        "atmelice_isp" -> "Atmel-ICE"
        "jtagice3_isp" -> "JTAGICE3"
        "jtagmkII" -> "JTAGICE mkII"
        "dragon_isp" -> "AVR Dragon"
        "arduino" -> "Arduino (USB-serial)"
        "serialupdi" -> "SerialUPDI adapter"
        "avr109" -> "Arduino (avr109 bootloader)"
        "stk500v2" -> "Arduino Mega (stk500v2)"
        else -> null
    }
}
