package com.avrdude.frontend.native

import com.avrdude.frontend.domain.model.ConsoleSource

/**
 * Callback contracts for the five categories of native-originated events the
 * spec calls out explicitly. AvrdudeNativeBridge is the only thing that
 * implements/dispatches these directly (native code calls into its
 * @JvmStatic methods); everything above that layer consumes the equivalent
 * Kotlin Flows exposed by AvrdudeNativeBridge instead of registering these
 * listeners by hand, which is the more idiomatic MVVM/StateFlow shape. They
 * are kept as real, separate functional interfaces (rather than folded into
 * one big listener) so a low-level Java/Kotlin caller that specifically
 * wants only e.g. progress, without pulling in console text at all, can do
 * that.
 */
fun interface ProgressCallback {
    fun onProgress(opId: Int, percent: Int, message: String)
}

fun interface ConsoleCallback {
    fun onConsole(opId: Int, source: ConsoleSource, line: String)
}

fun interface WarningCallback {
    fun onWarning(opId: Int, message: String)
}

fun interface ErrorCallback {
    fun onError(opId: Int, message: String)
}

fun interface DebugCallback {
    fun onDebug(message: String)
}
