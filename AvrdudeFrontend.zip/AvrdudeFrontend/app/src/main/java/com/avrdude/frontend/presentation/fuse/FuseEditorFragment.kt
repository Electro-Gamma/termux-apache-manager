package com.avrdude.frontend.presentation.fuse

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.avrdude.frontend.AvrdudeApp
import com.avrdude.frontend.R
import com.avrdude.frontend.core.toHexByte
import com.avrdude.frontend.databinding.FragmentFuseEditorBinding
import com.avrdude.frontend.databinding.ItemFuseBitBinding
import com.avrdude.frontend.domain.model.FuseByteDefinition
import com.avrdude.frontend.domain.model.FuseByteKind
import com.avrdude.frontend.domain.model.FuseBitField
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.launch

/**
 * Graphical Fuse Editor: shows Low/High/Extended (or single, for UPDI parts)
 * fuse bytes plus Lock Bits, both as a raw hex value and — for parts covered
 * by McuDatabase.fuseDefinitionsFor() — as named, individually-editable bit
 * fields with plain-English explanations. Dangerous fields prompt for
 * confirmation before being applied (see FuseEditorViewModel.requestFieldChange).
 */
class FuseEditorFragment : Fragment() {

    private var _binding: FragmentFuseEditorBinding? = null
    private val binding get() = _binding!!

    private val viewModel: FuseEditorViewModel by viewModels {
        FuseEditorViewModelFactory((requireActivity().application as AvrdudeApp).serviceLocator)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentFuseEditorBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.btnReadAllFuses.setOnClickListener { viewModel.readAllFuses() }
        binding.btnWriteAllFuses.setOnClickListener { viewModel.writeAllFuses() }

        bindRawEditor(binding.editLowFuseRaw, FuseByteKind.LOW)
        bindRawEditor(binding.editHighFuseRaw, FuseByteKind.HIGH)
        bindRawEditor(binding.editExtFuseRaw, FuseByteKind.EXTENDED)
        bindRawEditor(binding.editSingleFuseRaw, FuseByteKind.SINGLE)
        bindRawEditor(binding.editLockRaw, FuseByteKind.LOCK)

        observeState()
    }

    private fun bindRawEditor(field: com.google.android.material.textfield.TextInputEditText, kind: FuseByteKind) {
        field.setOnEditorActionListener { v, _, _ ->
            val parsed = parseHexOrDecimal(v.text?.toString())
            if (parsed != null) viewModel.setRawByteValue(kind, parsed)
            false
        }
    }

    private fun parseHexOrDecimal(text: String?): Int? {
        if (text.isNullOrBlank()) return null
        return try {
            if (text.startsWith("0x", ignoreCase = true)) text.substring(2).toInt(16) else text.toInt()
        } catch (e: NumberFormatException) {
            null
        }
    }

    private fun observeState() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.sessionParams.collect { params ->
                        binding.textConnectionSummary.text = if (params == null) {
                            "Not connected — configure a programmer, part, and port on the Dashboard first."
                        } else {
                            "Target: ${params.programmerId}  •  ${params.partId}  •  ${params.port}"
                        }
                    }
                }
                launch {
                    viewModel.uiState.collect { state -> renderState(state) }
                }
                launch {
                    viewModel.events.collect { event -> handleEvent(event) }
                }
            }
        }
    }

    private fun renderState(state: FuseEditorUiState) {
        val isSingleFuse = state.fuseCount < 3
        binding.cardLowFuse.visibility = if (isSingleFuse) View.GONE else View.VISIBLE
        binding.cardHighFuse.visibility = if (isSingleFuse) View.GONE else View.VISIBLE
        binding.cardExtFuse.visibility = if (isSingleFuse) View.GONE else View.VISIBLE
        binding.cardSingleFuse.visibility = if (isSingleFuse) View.VISIBLE else View.GONE

        setRawIfChanged(binding.editLowFuseRaw, state.lowValue)
        setRawIfChanged(binding.editHighFuseRaw, state.highValue)
        setRawIfChanged(binding.editExtFuseRaw, state.extValue)
        setRawIfChanged(binding.editSingleFuseRaw, state.singleValue)
        setRawIfChanged(binding.editLockRaw, state.lockValue)

        val lowDef = state.definitions.find { it.kind == FuseByteKind.LOW }
        val highDef = state.definitions.find { it.kind == FuseByteKind.HIGH }
        val extDef = state.definitions.find { it.kind == FuseByteKind.EXTENDED }

        renderFieldRows(binding.containerLowFuseFields, lowDef, state.lowValue, FuseByteKind.LOW)
        renderFieldRows(binding.containerHighFuseFields, highDef, state.highValue, FuseByteKind.HIGH)
        renderFieldRows(binding.containerExtFuseFields, extDef, state.extValue, FuseByteKind.EXTENDED)
    }

    private fun setRawIfChanged(field: com.google.android.material.textfield.TextInputEditText, value: Int?) {
        val text = value?.toHexByte() ?: ""
        if (field.text?.toString() != text) field.setText(text)
    }

    /** Rebuilds the named-bit-field rows for one fuse byte from scratch each
     *  time state changes. The row count per part is small (≤4), so a full
     *  rebuild is simpler and cheap enough to not need a RecyclerView here. */
    private fun renderFieldRows(container: android.widget.LinearLayout, definition: FuseByteDefinition?, byteValue: Int?, kind: FuseByteKind) {
        container.removeAllViews()
        if (definition == null || byteValue == null) return
        val inflater = LayoutInflater.from(container.context)
        for (field in definition.fields) {
            val rowBinding = ItemFuseBitBinding.inflate(inflater, container, false)
            rowBinding.textFieldName.text = field.name
            rowBinding.textFieldDescription.text = field.description
            rowBinding.imgDanger.visibility = if (field.isDangerous) View.VISIBLE else View.GONE

            val currentFieldValue = field.extractValue(byteValue)
            val options = field.valueMeanings.entries.toList()
            val labels = options.map { (value, meaning) -> "$meaning (${value})" }
            rowBinding.dropdownFieldValue.setAdapter(
                ArrayAdapter(container.context, android.R.layout.simple_list_item_1, labels)
            )
            val selectedIndex = options.indexOfFirst { it.key == currentFieldValue }
            if (selectedIndex >= 0) rowBinding.dropdownFieldValue.setText(labels[selectedIndex], false)

            rowBinding.dropdownFieldValue.setOnItemClickListener { _, _, position, _ ->
                val newFieldValue = options[position].key
                viewModel.requestFieldChange(kind, field, newFieldValue)
            }

            container.addView(rowBinding.root)
        }
    }

    private fun handleEvent(event: FuseEditorEvent) {
        when (event) {
            is FuseEditorEvent.ShowMessage -> Snackbar.make(binding.root, event.message, Snackbar.LENGTH_SHORT).show()
            is FuseEditorEvent.ShowError -> Snackbar.make(binding.root, event.message, Snackbar.LENGTH_LONG).show()
            is FuseEditorEvent.ConfirmDangerousChange -> showDangerConfirmation(event)
        }
    }

    private fun showDangerConfirmation(event: FuseEditorEvent.ConfirmDangerousChange) {
        val field = event.field
        AlertDialog.Builder(requireContext())
            .setTitle(R.string.fuse_warning_title)
            .setMessage("${field.name}: ${field.dangerExplanation}")
            .setPositiveButton(R.string.fuse_warning_proceed) { _, _ ->
                viewModel.confirmDangerousChange(event.byteKind, event.newByteValue)
            }
            .setNegativeButton(R.string.fuse_warning_cancel, null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
