package com.avrdude.frontend.di

import android.content.Context
import com.avrdude.frontend.data.files.AvrdudeConfigProvider
import com.avrdude.frontend.data.files.FileManager
import com.avrdude.frontend.data.prefs.AppPreferences
import com.avrdude.frontend.data.repository.AvrdudeRepositoryImpl
import com.avrdude.frontend.data.session.ConnectionSession
import com.avrdude.frontend.domain.repository.AvrdudeRepository
import com.avrdude.frontend.usb.PortResolver
import com.avrdude.frontend.usb.UsbPermissionManager

/**
 * Minimal manual dependency container. Kept intentionally simple (no
 * Hilt/Dagger) since the object graph here is small and static for the
 * lifetime of the process — every dependency is a plain singleton created
 * once from the Application context. Swap in Hilt later without touching
 * any ViewModel code if the graph grows.
 */
class ServiceLocator(context: Context) {
    private val appContext = context.applicationContext

    val appPreferences: AppPreferences by lazy { AppPreferences(appContext) }
    val configProvider: AvrdudeConfigProvider by lazy { AvrdudeConfigProvider(appContext) }
    val fileManager: FileManager by lazy { FileManager(appContext, appPreferences) }
    val usbPermissionManager: UsbPermissionManager by lazy { UsbPermissionManager(appContext) }
    val portResolver: PortResolver by lazy { PortResolver(usbPermissionManager) }
    val connectionSession: ConnectionSession by lazy { ConnectionSession() }

    val avrdudeRepository: AvrdudeRepository by lazy {
        AvrdudeRepositoryImpl(
            nativeLibDir = appContext.applicationInfo.nativeLibraryDir,
            workDir = appContext.filesDir.absolutePath,
            configProvider = configProvider,
        )
    }

    companion object {
        @Volatile private var instance: ServiceLocator? = null

        fun getInstance(context: Context): ServiceLocator =
            instance ?: synchronized(this) {
                instance ?: ServiceLocator(context).also { instance = it }
            }
    }
}
