package com.avrdude.frontend.core

/** Formats a byte count using AVR-appropriate units (bytes/KB, no binary-prefix pedantry needed for typical 1-512KB flash sizes). */
fun Long.toHumanBytes(): String = when {
    this < 1024 -> "$this B"
    else -> String.format("%.1f KB", this / 1024.0)
}

fun Double.toHumanSpeed(): String = when {
    this < 1024 -> String.format("%.0f B/s", this)
    else -> String.format("%.1f KB/s", this / 1024.0)
}

fun Int.toHexByte(): String = "0x" + this.toString(16).uppercase().padStart(2, '0')
