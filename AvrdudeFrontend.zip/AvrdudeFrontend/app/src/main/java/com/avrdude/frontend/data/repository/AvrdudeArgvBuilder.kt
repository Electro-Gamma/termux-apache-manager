package com.avrdude.frontend.data.repository

import com.avrdude.frontend.domain.model.FileFormat
import com.avrdude.frontend.domain.model.MemoryType

/**
 * Connection parameters shared by almost every AVRDUDE invocation. Grouped
 * into one type so every AvrdudeArgvBuilder function has an identical,
 * predictable first argument instead of five positional Strings.
 */
data class ConnectionParams(
    val programmerId: String,       // -c
    val partId: String,             // -p  (e.g. "m328p"). Use "?" only via listParts().
    val port: String,               // -P  (e.g. "usb", "/dev/bus/usb/001/004", "usb:fd:63")
    val baudRate: Int? = null,      // -b
    val bitclock: Double? = null,   // -B (ISP/JTAG clock period, microseconds)
    val extendedOptions: List<String> = emptyList(), // -x, one per entry (programmer-specific)
    val overrideSignatureCheck: Boolean = false, // -F
)

/**
 * Builds AVRDUDE argv arrays. Every flag used here is AVRDUDE's own public,
 * documented command-line vocabulary — this class does not invent any new
 * syntax, it only assembles it. `confPath` must point at an avrdude.conf
 * compatible with the exact version baked into libavrdude2.so (see
 * docs/ARCHITECTURE.md — this project cannot ship a verified-correct one).
 */
object AvrdudeArgvBuilder {

    private fun MutableList<String>.addConnection(p: ConnectionParams, confPath: String) {
        add("-C"); add(confPath)
        add("-c"); add(p.programmerId)
        add("-p"); add(p.partId)
        add("-P"); add(p.port)
        p.baudRate?.let { add("-b"); add(it.toString()) }
        p.bitclock?.let { add("-B"); add(it.toString()) }
        p.extendedOptions.forEach { add("-x"); add(it) }
        if (p.overrideSignatureCheck) add("-F")
    }

    /** `avrdude -C <conf> -v -c ?` — prints the version banner, then the
     *  programmer list, then exits 0. Used for getVersion(). */
    fun versionProbe(confPath: String): List<String> =
        listOf("-C", confPath, "-v", "-c", "?")

    /** `avrdude -C <conf> -c ?` — AVRDUDE's documented "list programmer ids and exit" mode. */
    fun listProgrammers(confPath: String): List<String> =
        listOf("-C", confPath, "-c", "?")

    /** `avrdude -C <conf> -p ?` — AVRDUDE's documented "list part ids and exit" mode. */
    fun listParts(confPath: String): List<String> =
        listOf("-C", confPath, "-p", "?")

    /**
     * Auto-detect entry point: connects using [p] (whatever best-guess
     * partId the caller has, e.g. a common default like "m328p") and reads
     * the signature without writing anything. See [readSignature], which
     * this is built on — the Dashboard calls repository.readSignature()
     * directly for this and looks the returned bytes up in McuDatabase.
     */
    fun connectOnly(confPath: String, p: ConnectionParams): List<String> {
        val args = mutableListOf<String>()
        args.addConnection(p, confPath)
        args += "-n"
        return args
    }

    fun chipErase(confPath: String, p: ConnectionParams): List<String> {
        val args = mutableListOf<String>()
        args.addConnection(p, confPath)
        args += "-e"
        return args
    }

    /** Reads any memory type to a local file. Binary format is used for
     *  fuses/lock/signature/calibration so Kotlin can parse exact byte
     *  values without depending on AVRDUDE's hex-dump text formatting. */
    fun readMemory(
        confPath: String, p: ConnectionParams,
        memType: MemoryType, outFilePath: String,
        format: FileFormat = FileFormat.INTEL_HEX,
    ): List<String> {
        val args = mutableListOf<String>()
        args.addConnection(p, confPath)
        args += listOf("-U", "${memType.avrdudeId}:r:$outFilePath:${format.code}")
        return args
    }

    fun writeMemory(
        confPath: String, p: ConnectionParams,
        memType: MemoryType, inFilePath: String,
        format: FileFormat = FileFormat.INTEL_HEX,
        verifyAfterWrite: Boolean = true,
        chipEraseFirst: Boolean = false,
    ): List<String> {
        val args = mutableListOf<String>()
        args.addConnection(p, confPath)
        if (chipEraseFirst) args += "-e"
        if (!verifyAfterWrite) args += "-V" // -V disables AVRDUDE's automatic post-write verify
        args += listOf("-U", "${memType.avrdudeId}:w:$inFilePath:${format.code}")
        return args
    }

    /** `<memtype>:v:<file>` — AVRDUDE's dedicated compare-only op; does not
     *  write anything, just reports mismatches against the given file. */
    fun verifyMemory(
        confPath: String, p: ConnectionParams,
        memType: MemoryType, referenceFilePath: String,
        format: FileFormat = FileFormat.INTEL_HEX,
    ): List<String> {
        val args = mutableListOf<String>()
        args.addConnection(p, confPath)
        args += listOf("-U", "${memType.avrdudeId}:v:$referenceFilePath:${format.code}")
        return args
    }

    /** Writes a fuse/lock byte from an immediate hex value, e.g. "0xD9". */
    fun writeImmediate(
        confPath: String, p: ConnectionParams,
        memType: MemoryType, hexValue: String,
    ): List<String> {
        val args = mutableListOf<String>()
        args.addConnection(p, confPath)
        args += listOf("-U", "${memType.avrdudeId}:w:$hexValue:m")
        return args
    }

    /** Reads a single-byte memory (fuse/lock/calibration) to a raw-binary temp file. */
    fun readSingleByte(
        confPath: String, p: ConnectionParams,
        memType: MemoryType, outFilePath: String,
    ): List<String> = readMemory(confPath, p, memType, outFilePath, FileFormat.RAW_BINARY)

    /**
     * Device signature is 3 bytes; same raw-binary-to-file approach.
     * Always forces `-F` (override signature check): reading the signature
     * is exactly the operation used for auto-detect, when [p.partId] is
     * only a best guess — a mismatch there must not abort the read, it's
     * the expected case. The Dashboard looks up the returned bytes against
     * McuDatabase to identify the real part afterward.
     */
    fun readSignature(confPath: String, p: ConnectionParams, outFilePath: String): List<String> =
        readMemory(confPath, p.copy(overrideSignatureCheck = true), MemoryType.SIGNATURE, outFilePath, FileFormat.RAW_BINARY)
}
