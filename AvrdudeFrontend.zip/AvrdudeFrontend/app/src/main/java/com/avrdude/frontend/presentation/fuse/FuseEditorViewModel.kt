package com.avrdude.frontend.presentation.fuse

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.avrdude.frontend.data.devicedb.McuDatabase
import com.avrdude.frontend.data.repository.ConnectionParams
import com.avrdude.frontend.data.session.ConnectionSession
import com.avrdude.frontend.di.ServiceLocator
import com.avrdude.frontend.domain.model.FuseByteDefinition
import com.avrdude.frontend.domain.model.FuseByteKind
import com.avrdude.frontend.domain.model.FuseBitField
import com.avrdude.frontend.domain.repository.AvrdudeRepository
import com.avrdude.frontend.usb.PortResolver
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class FuseEditorUiState(
    val partId: String? = null,
    val fuseCount: Int = 3,
    val lowValue: Int? = null,
    val highValue: Int? = null,
    val extValue: Int? = null,
    val singleValue: Int? = null,
    val lockValue: Int? = null,
    val definitions: List<FuseByteDefinition> = emptyList(),
    val isBusy: Boolean = false,
)

sealed class FuseEditorEvent {
    data class ConfirmDangerousChange(
        val byteKind: FuseByteKind, val field: FuseBitField, val newByteValue: Int,
    ) : FuseEditorEvent()
    data class ShowMessage(val message: String) : FuseEditorEvent()
    data class ShowError(val message: String) : FuseEditorEvent()
}

/**
 * Drives the Fuse Editor screen. Operates on whatever [ConnectionSession]
 * currently holds (set by the Dashboard) — this screen deliberately doesn't
 * duplicate programmer/part/port selection UI, it just uses the same target.
 */
class FuseEditorViewModel(
    private val repository: AvrdudeRepository,
    private val connectionSession: ConnectionSession,
    private val portResolver: PortResolver,
) : ViewModel() {

    val sessionParams: StateFlow<ConnectionParams?> = connectionSession.params

    private val _uiState = MutableStateFlow(FuseEditorUiState())
    val uiState: StateFlow<FuseEditorUiState> = _uiState.asStateFlow()

    private val _events = MutableSharedFlow<FuseEditorEvent>(extraBufferCapacity = 8)
    val events: SharedFlow<FuseEditorEvent> = _events.asSharedFlow()

    init {
        viewModelScope.launch {
            connectionSession.params.collect { params ->
                if (params != null) {
                    val device = McuDatabase.findByPartId(params.partId)
                    _uiState.update {
                        it.copy(
                            partId = params.partId,
                            fuseCount = device?.fuseCount ?: 3,
                            definitions = McuDatabase.fuseDefinitionsFor(params.partId) ?: emptyList(),
                        )
                    }
                }
            }
        }
    }

    fun readAllFuses() = viewModelScope.launch {
        val params = requireParams() ?: return@launch
        _uiState.update { it.copy(isBusy = true) }
        if (_uiState.value.fuseCount >= 3) {
            resolved(params) { repository.readFuse(it, FuseByteKind.LOW) }
                .onSuccess { v -> _uiState.update { it.copy(lowValue = v) } }.onFailure(::reportError)
            resolved(params) { repository.readFuse(it, FuseByteKind.HIGH) }
                .onSuccess { v -> _uiState.update { it.copy(highValue = v) } }.onFailure(::reportError)
            resolved(params) { repository.readFuse(it, FuseByteKind.EXTENDED) }
                .onSuccess { v -> _uiState.update { it.copy(extValue = v) } }.onFailure(::reportError)
        } else {
            resolved(params) { repository.readFuse(it, FuseByteKind.SINGLE) }
                .onSuccess { v -> _uiState.update { it.copy(singleValue = v) } }.onFailure(::reportError)
        }
        resolved(params) { repository.readLockBits(it) }
            .onSuccess { v -> _uiState.update { it.copy(lockValue = v) } }.onFailure(::reportError)
        _uiState.update { it.copy(isBusy = false) }
    }

    /** Called when the user picks a new value for one named bit field.
     *  Routes through a confirmation event first if that field is flagged
     *  dangerous. */
    fun requestFieldChange(byteKind: FuseByteKind, field: FuseBitField, newFieldValue: Int) {
        val currentByte = currentByteValue(byteKind) ?: return
        val newByteValue = field.applyValue(currentByte, newFieldValue)
        if (field.isDangerous) {
            viewModelScope.launch { _events.emit(FuseEditorEvent.ConfirmDangerousChange(byteKind, field, newByteValue)) }
        } else {
            applyByteChange(byteKind, newByteValue)
        }
    }

    fun confirmDangerousChange(byteKind: FuseByteKind, newByteValue: Int) = applyByteChange(byteKind, newByteValue)

    /** Called when the user edits a byte's raw hex text field directly. */
    fun setRawByteValue(byteKind: FuseByteKind, rawValue: Int) = applyByteChange(byteKind, rawValue)

    private fun applyByteChange(byteKind: FuseByteKind, newByteValue: Int) {
        when (byteKind) {
            FuseByteKind.LOW -> _uiState.update { it.copy(lowValue = newByteValue) }
            FuseByteKind.HIGH -> _uiState.update { it.copy(highValue = newByteValue) }
            FuseByteKind.EXTENDED -> _uiState.update { it.copy(extValue = newByteValue) }
            FuseByteKind.SINGLE -> _uiState.update { it.copy(singleValue = newByteValue) }
            FuseByteKind.LOCK -> _uiState.update { it.copy(lockValue = newByteValue) }
        }
    }

    private fun currentByteValue(kind: FuseByteKind): Int? = when (kind) {
        FuseByteKind.LOW -> _uiState.value.lowValue
        FuseByteKind.HIGH -> _uiState.value.highValue
        FuseByteKind.EXTENDED -> _uiState.value.extValue
        FuseByteKind.SINGLE -> _uiState.value.singleValue
        FuseByteKind.LOCK -> _uiState.value.lockValue
    }

    fun writeAllFuses() = viewModelScope.launch {
        val params = requireParams() ?: return@launch
        val s = _uiState.value
        _uiState.update { it.copy(isBusy = true) }
        var ok = true
        s.lowValue?.let { resolved(params) { p -> repository.writeFuse(p, FuseByteKind.LOW, it) }.onFailure { e -> ok = false; reportError(e) } }
        s.highValue?.let { resolved(params) { p -> repository.writeFuse(p, FuseByteKind.HIGH, it) }.onFailure { e -> ok = false; reportError(e) } }
        s.extValue?.let { resolved(params) { p -> repository.writeFuse(p, FuseByteKind.EXTENDED, it) }.onFailure { e -> ok = false; reportError(e) } }
        s.singleValue?.let { resolved(params) { p -> repository.writeFuse(p, FuseByteKind.SINGLE, it) }.onFailure { e -> ok = false; reportError(e) } }
        s.lockValue?.let { resolved(params) { p -> repository.writeLockBits(p, it) }.onFailure { e -> ok = false; reportError(e) } }
        _uiState.update { it.copy(isBusy = false) }
        if (ok) _events.emit(FuseEditorEvent.ShowMessage("Fuse/lock write complete."))
    }

    /** Delegates to the shared [PortResolver] — see its doc comment — so a
     *  USB-serial connection gets a fresh PTY bridge per call here too,
     *  exactly like every Dashboard operation. */
    private suspend fun <T> resolved(
        params: ConnectionParams,
        block: suspend (ConnectionParams) -> Result<T>,
    ): Result<T> = portResolver.withResolvedPort(params, connectionSession.selectedDevice.value, block)

    private fun requireParams(): ConnectionParams? {
        val p = connectionSession.params.value
        if (p == null) {
            viewModelScope.launch {
                _events.emit(FuseEditorEvent.ShowError("Connect on the Dashboard first (select programmer, part, and port)."))
            }
        }
        return p
    }

    private fun reportError(t: Throwable) {
        viewModelScope.launch { _events.emit(FuseEditorEvent.ShowError(t.message ?: "Operation failed")) }
    }
}

class FuseEditorViewModelFactory(private val locator: ServiceLocator) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return FuseEditorViewModel(locator.avrdudeRepository, locator.connectionSession, locator.portResolver) as T
    }
}
