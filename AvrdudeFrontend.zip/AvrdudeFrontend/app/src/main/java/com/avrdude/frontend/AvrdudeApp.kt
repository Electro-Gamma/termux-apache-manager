package com.avrdude.frontend

import android.app.Application
import com.avrdude.frontend.di.ServiceLocator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class AvrdudeApp : Application() {

    lateinit var serviceLocator: ServiceLocator
        private set

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onCreate() {
        super.onCreate()
        serviceLocator = ServiceLocator.getInstance(this)

        // Resolve + validate the extracted libavrdude2.so path once at
        // startup. Safe to call before avrdude.conf is imported — that's
        // checked separately, per-operation, in AvrdudeRepositoryImpl.
        appScope.launch {
            serviceLocator.avrdudeRepository.initialize()
        }
    }

    override fun onTerminate() {
        serviceLocator.avrdudeRepository.shutdown()
        super.onTerminate()
    }
}
