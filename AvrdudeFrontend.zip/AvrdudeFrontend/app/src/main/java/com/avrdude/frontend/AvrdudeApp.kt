package com.avrdude.frontend

import android.app.Application
import android.util.Log
import com.avrdude.frontend.di.ServiceLocator
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class AvrdudeApp : Application() {

    lateinit var serviceLocator: ServiceLocator
        private set

    // A background startup task must never be able to take the whole app
    // down. AvrdudeRepositoryImpl.initialize() already guards the specific,
    // foreseeable native-load failure mode (see AvrdudeNativeBridge.isLibraryLoaded)
    // and returns a normal failed Result for it — this handler is the backstop
    // for anything else unexpected, so "native bridge had a bad day" degrades
    // to "some app features won't work until you check Settings", never to a
    // full crash loop before the user even sees a screen.
    private val exceptionHandler = CoroutineExceptionHandler { _, throwable ->
        Log.e("AvrdudeApp", "Uncaught error during background initialization", throwable)
    }
    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default + exceptionHandler)

    override fun onCreate() {
        super.onCreate()
        serviceLocator = ServiceLocator.getInstance(this)

        // Resolve + validate the extracted libavrdude2.so path once at
        // startup. Safe to call before avrdude.conf is imported — that's
        // checked separately, per-operation, in AvrdudeRepositoryImpl.
        appScope.launch {
            serviceLocator.avrdudeRepository.initialize()
        }
    }

    override fun onTerminate() {
        serviceLocator.avrdudeRepository.shutdown()
        super.onTerminate()
    }
}
