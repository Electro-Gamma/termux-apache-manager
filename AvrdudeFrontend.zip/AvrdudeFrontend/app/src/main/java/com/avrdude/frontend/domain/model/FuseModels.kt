package com.avrdude.frontend.domain.model

/** Which physical fuse/lock byte a bit definition belongs to. */
enum class FuseByteKind { LOW, HIGH, EXTENDED, SINGLE, LOCK }

/**
 * Describes one named bit-field within a fuse or lock byte: its bit range,
 * the human-readable meaning of each possible value, and whether flipping it
 * is dangerous enough to warrant a confirmation dialog (e.g. RSTDISBL,
 * DWEN, SPIEN, or a wrong clock-source select that can effectively brick the
 * chip from ISP until a HV programmer is used).
 */
data class FuseBitField(
    val name: String,
    val description: String,
    val bitRange: IntRange,       // e.g. 0..0 for a single bit, 0..3 for CKSEL3:0
    val valueMeanings: Map<Int, String>, // raw field value -> human meaning
    val isDangerous: Boolean,
    val dangerExplanation: String = "",
) {
    fun extractValue(byteValue: Int): Int {
        val mask = (1 shl bitRange.count()) - 1
        return (byteValue shr bitRange.first) and mask
    }

    fun applyValue(byteValue: Int, fieldValue: Int): Int {
        val mask = (1 shl bitRange.count()) - 1
        val cleared = byteValue and (mask shl bitRange.first).inv()
        return cleared or ((fieldValue and mask) shl bitRange.first)
    }
}

data class FuseByteDefinition(
    val kind: FuseByteKind,
    val displayName: String,
    val fields: List<FuseBitField>,
    /** AVRDUDE reports/accepts fuses "unprogrammed = 1" — i.e. inverted logic
     *  versus a naive "1 = feature enabled" reading. Surfaced here so the UI
     *  can show a one-line reminder next to the byte. */
    val activeLowNote: String = "Note: AVR fuse bits are active-LOW — a cleared (0) bit means the feature IS programmed/enabled.",
)
