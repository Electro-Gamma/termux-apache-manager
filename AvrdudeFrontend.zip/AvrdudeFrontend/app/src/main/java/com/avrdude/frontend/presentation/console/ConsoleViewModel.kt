package com.avrdude.frontend.presentation.console

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.avrdude.frontend.data.files.FileManager
import com.avrdude.frontend.di.ServiceLocator
import com.avrdude.frontend.domain.model.ConsoleEntry
import com.avrdude.frontend.domain.model.LogLevel
import com.avrdude.frontend.domain.repository.AvrdudeRepository
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ConsoleFilterState(
    val query: String = "",
    val minLevel: LogLevel = LogLevel.DEBUG,
)

sealed class ConsoleUiEvent {
    data class ShowMessage(val message: String) : ConsoleUiEvent()
    data class OfferShare(val uri: Uri) : ConsoleUiEvent()
}

/** Backs the Console screen: an ever-growing (capped) log of every line
 *  AVRDUDE and the native bridge have produced, with copy/save/clear/filter. */
class ConsoleViewModel(
    repository: AvrdudeRepository,
    private val fileManager: FileManager,
) : ViewModel() {

    private val maxEntries = 5000

    private val _allEntries = MutableStateFlow<List<ConsoleEntry>>(emptyList())
    private val _filter = MutableStateFlow(ConsoleFilterState())
    val filter: StateFlow<ConsoleFilterState> = _filter.asStateFlow()

    val visibleEntries: StateFlow<List<ConsoleEntry>> = combine(_allEntries, _filter) { entries, filter ->
        entries.filter { entry ->
            entry.level.ordinal >= filter.minLevel.ordinal &&
                (filter.query.isBlank() || entry.message.contains(filter.query, ignoreCase = true))
        }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val _events = MutableSharedFlow<ConsoleUiEvent>(extraBufferCapacity = 4)
    val events: SharedFlow<ConsoleUiEvent> = _events.asSharedFlow()

    init {
        viewModelScope.launch {
            repository.consoleEvents.collect { entry ->
                _allEntries.update { current ->
                    val updated = current + entry
                    if (updated.size > maxEntries) updated.takeLast(maxEntries) else updated
                }
            }
        }
    }

    fun setQuery(query: String) = _filter.update { it.copy(query = query) }
    fun setMinLevel(level: LogLevel) = _filter.update { it.copy(minLevel = level) }

    fun clear() {
        _allEntries.value = emptyList()
    }

    fun copyText(): String = visibleEntries.value.joinToString("\n") { "[${it.level}] ${it.message}" }

    fun saveToFile() = viewModelScope.launch {
        val path = fileManager.allocateOutputPath("avrdude_console_${System.currentTimeMillis()}.log")
        java.io.File(path).writeText(copyText())
        val uri = fileManager.shareableUriFor(path)
        _events.emit(ConsoleUiEvent.OfferShare(uri))
    }
}

class ConsoleViewModelFactory(private val locator: ServiceLocator) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return ConsoleViewModel(locator.avrdudeRepository, locator.fileManager) as T
    }
}
