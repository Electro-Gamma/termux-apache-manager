package com.avrdude.frontend.data.session

import com.avrdude.frontend.data.repository.ConnectionParams
import com.avrdude.frontend.usb.UsbDeviceInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * The programmer/part/port combination the user has configured on the
 * Dashboard, shared with the Fuse Editor screen so it can operate on the
 * same target without re-asking for connection details. AVRDUDE itself has
 * no persistent "session" (see AvrdudeRepositoryImpl) — this class just
 * remembers the last-used [ConnectionParams] on the Kotlin side so every
 * screen builds its AVRDUDE invocations against the same target.
 *
 * [selectedDevice] is carried alongside [params] specifically so
 * [com.avrdude.frontend.usb.PortResolver] can tell, from any screen, when
 * the current target is a USB-serial device needing a fresh PTY bridge per
 * operation rather than a plain port string — see PortResolver's doc
 * comment.
 */
class ConnectionSession {
    private val _params = MutableStateFlow<ConnectionParams?>(null)
    val params: StateFlow<ConnectionParams?> = _params.asStateFlow()

    private val _selectedDevice = MutableStateFlow<UsbDeviceInfo?>(null)
    val selectedDevice: StateFlow<UsbDeviceInfo?> = _selectedDevice.asStateFlow()

    fun update(newParams: ConnectionParams) {
        _params.value = newParams
    }

    fun updateSelectedDevice(device: UsbDeviceInfo?) {
        _selectedDevice.value = device
    }

    fun clear() {
        _params.value = null
        _selectedDevice.value = null
    }
}
