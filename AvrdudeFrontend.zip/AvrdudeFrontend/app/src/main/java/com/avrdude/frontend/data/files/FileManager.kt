package com.avrdude.frontend.data.files

import android.content.Context
import android.net.Uri
import androidx.core.content.FileProvider
import com.avrdude.frontend.data.prefs.AppPreferences
import java.io.File

/**
 * Bridges Android's Storage Access Framework (content:// Uris, which is how
 * the OS hands back user-picked files from any provider — Drive, local
 * storage, SD card, etc.) to the plain filesystem paths AVRDUDE needs, since
 * the AVRDUDE child process cannot read a content:// Uri directly.
 *
 * Supported formats per the spec: Intel HEX (.hex), ELF (.elf), and raw
 * binary (.bin) — AVRDUDE's own -U :i / :e / :r format codes respectively
 * (see domain/model/MemoryType.kt FileFormat).
 */
class FileManager(private val context: Context, private val preferences: AppPreferences) {

    private val workingDir: File
        get() = File(context.filesDir, "firmware").apply { mkdirs() }

    /** Copies a SAF-picked input file into a real path AVRDUDE can read,
     *  remembers it in the recent-files list, and returns that path. */
    suspend fun importForRead(uri: Uri, suggestedName: String): String {
        val dest = File(workingDir, sanitize(suggestedName))
        context.contentResolver.openInputStream(uri)?.use { input ->
            dest.outputStream().use { output -> input.copyTo(output) }
        }
        preferences.addRecentFile(dest.absolutePath)
        return dest.absolutePath
    }

    /** Allocates a fresh local path for AVRDUDE to write a read/dump
     *  operation's output into (e.g. "Read Flash", "Dump Flash"). The
     *  caller exports it to a user-chosen SAF location afterward via
     *  exportToUri(). */
    fun allocateOutputPath(suggestedName: String): String {
        val dest = File(workingDir, sanitize(suggestedName))
        return dest.absolutePath
    }

    /** Copies a local result file out to a SAF-picked destination (e.g. the
     *  "Save As" flow after a Read Flash / Dump Flash operation) and
     *  remembers it in recent files. */
    suspend fun exportToUri(localPath: String, destUri: Uri) {
        File(localPath).inputStream().use { input ->
            context.contentResolver.openOutputStream(destUri)?.use { output -> input.copyTo(output) }
        }
        preferences.addRecentFile(localPath)
    }

    /** A content:// Uri for sharing/viewing a local result file (e.g. from
     *  a "Share log" action), via the app's FileProvider. */
    fun shareableUriFor(localPath: String): Uri =
        FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", File(localPath))

    fun recentFiles() = preferences.recentFiles

    private fun sanitize(name: String): String =
        name.replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "firmware_${System.nanoTime()}.bin" }
}
