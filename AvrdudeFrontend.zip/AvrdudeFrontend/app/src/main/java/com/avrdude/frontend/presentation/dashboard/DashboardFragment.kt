package com.avrdude.frontend.presentation.dashboard

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.avrdude.frontend.AvrdudeApp
import com.avrdude.frontend.R
import com.avrdude.frontend.core.toHumanBytes
import com.avrdude.frontend.core.toHumanSpeed
import com.avrdude.frontend.databinding.FragmentDashboardBinding
import com.avrdude.frontend.domain.model.McuDevice
import com.avrdude.frontend.data.devicedb.McuDatabase
import com.avrdude.frontend.domain.model.KnownProgrammers
import androidx.core.widget.addTextChangedListener
import androidx.navigation.fragment.findNavController
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.launch

/**
 * The main dashboard: USB Connection, Programmer Selection, Device
 * Information, File Selection, Programming Operations, and Progress panels
 * all live here as scrollable Material 3 cards. DashboardViewModel is
 * shared with MainActivity (activityViewModels) so the persistent bottom
 * toolbar drives the exact same state this fragment displays.
 */
class DashboardFragment : Fragment() {

    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!

    private val viewModel: DashboardViewModel by activityViewModels {
        DashboardViewModelFactory((requireActivity().application as AvrdudeApp).serviceLocator)
    }

    private lateinit var usbAdapter: com.avrdude.frontend.presentation.usbpicker.UsbDeviceAdapter

    private val pickFlashFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) viewModel.pickFlashFileForWrite(uri, uri.lastPathSegment ?: "flash.hex")
    }
    private val pickEepromFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) viewModel.pickEepromFileForWrite(uri, uri.lastPathSegment ?: "eeprom.hex")
    }
    private val pickConfFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) viewModel.importAvrdudeConf(uri)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupUsbList()
        setupDropdowns()
        setupFileSelection()
        setupOperationChips()
        setupSwitches()
        observeState()
    }

    private fun setupUsbList() {
        usbAdapter = com.avrdude.frontend.presentation.usbpicker.UsbDeviceAdapter { device ->
            viewModel.selectUsbDevice(device)
        }
        binding.recyclerUsbDevices.adapter = usbAdapter
        binding.recyclerUsbDevices.layoutManager = androidx.recyclerview.widget.LinearLayoutManager(requireContext())
        binding.btnRefreshUsb.setOnClickListener { viewModel.refreshUsbDevices() }
    }

    private fun setupDropdowns() {
        val programmerNames = KnownProgrammers.CATALOG.map { "${it.displayName} (${it.id})" }
        val programmerAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, programmerNames)
        binding.dropdownProgrammer.setAdapter(programmerAdapter)
        binding.dropdownProgrammer.setOnItemClickListener { _, _, position, _ ->
            viewModel.selectProgrammer(KnownProgrammers.CATALOG[position].id)
        }

        val partNames = McuDatabase.KNOWN_DEVICES.map { "${it.displayName} (${it.partId})" }
        val partAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, partNames)
        binding.dropdownPart.setAdapter(partAdapter)
        binding.dropdownPart.setOnItemClickListener { _, _, position, _ ->
            viewModel.selectPart(McuDatabase.KNOWN_DEVICES[position].partId)
        }

        binding.editPort.addTextChangedListener { text -> viewModel.setPort(text?.toString() ?: "") }
        binding.editBaud.addTextChangedListener { text -> viewModel.setBaudRate(text?.toString()?.toIntOrNull()) }
        binding.editBitclock.addTextChangedListener { text -> viewModel.setBitclock(text?.toString()?.toDoubleOrNull()) }

        binding.btnImportConfNow.setOnClickListener {
            pickConfFile.launch(arrayOf("*/*"))
        }
    }

    private fun setupFileSelection() {
        binding.btnPickFlashFile.setOnClickListener {
            pickFlashFile.launch(arrayOf("*/*")) // HEX/ELF/BIN don't have a single reliable MIME type on Android
        }
        binding.btnPickEepromFile.setOnClickListener {
            pickEepromFile.launch(arrayOf("*/*"))
        }
    }

    private fun setupOperationChips() = with(binding) {
        chipDetect.setOnClickListener { viewModel.detectDevice() }
        chipReadSignature.setOnClickListener { viewModel.readSignature() }
        chipChipErase.setOnClickListener { viewModel.confirmAndChipErase() }
        chipReadFlash.setOnClickListener { viewModel.readFlash() }
        chipWriteFlash.setOnClickListener { viewModel.writeFlash() }
        chipVerifyFlash.setOnClickListener { viewModel.verifyFlash() }
        chipDumpFlash.setOnClickListener { viewModel.dumpFlash() }
        chipReadEeprom.setOnClickListener { viewModel.readEeprom() }
        chipWriteEeprom.setOnClickListener { viewModel.writeEeprom() }
        chipVerifyEeprom.setOnClickListener { viewModel.verifyEeprom() }
        chipDumpEeprom.setOnClickListener { viewModel.dumpEeprom() }
        chipReadFuse.setOnClickListener { findNavController().navigate(R.id.fuseEditorFragment) }
        chipWriteFuse.setOnClickListener { findNavController().navigate(R.id.fuseEditorFragment) }
        chipReadLock.setOnClickListener { findNavController().navigate(R.id.fuseEditorFragment) }
        chipWriteLock.setOnClickListener { findNavController().navigate(R.id.fuseEditorFragment) }
        chipReadCalibration.setOnClickListener { viewModel.readCalibration() }
        chipReadProdSig.setOnClickListener { viewModel.readProductionSignature() }
        chipCancel.setOnClickListener { viewModel.cancelOperation() }
    }

    private fun setupSwitches() = with(binding) {
        switchVerifyAfterWrite.setOnCheckedChangeListener { _, checked -> viewModel.setVerifyAfterWrite(checked) }
        switchChipEraseBeforeWrite.setOnCheckedChangeListener { _, checked -> viewModel.setChipEraseBeforeWrite(checked) }
    }

    private fun observeState() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.usbDevices.collect { devices ->
                        usbAdapter.submitList(devices)
                        binding.textNoUsbDevices.visibility = if (devices.isEmpty()) View.VISIBLE else View.GONE
                    }
                }
                launch {
                    viewModel.uiState.collect { state ->
                        binding.cardConfigWarning.visibility = if (state.isConfigConfigured) View.GONE else View.VISIBLE
                        binding.switchVerifyAfterWrite.isChecked = state.verifyAfterWrite
                        binding.switchChipEraseBeforeWrite.isChecked = state.chipEraseBeforeWrite
                        binding.textFlashFile.text = "Flash file: ${state.flashFilePath ?: "(none selected)"}"
                        binding.textEepromFile.text = "EEPROM file: ${state.eepromFilePath ?: "(none selected)"}"
                        binding.textDeviceInfo.text = formatDeviceInfo(state.detectedDevice, state.detectedSignature)
                    }
                }
                launch {
                    viewModel.progress.collect { progress ->
                        binding.progressIndicator.setProgressCompat(progress.percent, true)
                        binding.textProgressLabel.text = if (progress.isRunning) progress.label else "Idle"
                        binding.textProgressDetail.text = if (progress.isRunning) {
                            "${progress.bytesTransferred.toHumanBytes()} / ${progress.totalBytes.toHumanBytes()}  •  " +
                                "${progress.speedBytesPerSec.toHumanSpeed()}" +
                                (progress.etaSeconds?.let { "  •  ETA ${it}s" } ?: "")
                        } else ""
                    }
                }
                launch {
                    viewModel.uiEvents.collect { event -> handleEvent(event) }
                }
            }
        }
    }

    private fun formatDeviceInfo(device: McuDevice?, signature: String?): String {
        if (device == null) {
            return if (signature != null) "Signature: $signature (not in local reference table)"
            else "No device detected yet — tap Detect."
        }
        return buildString {
            appendLine("Part: ${device.displayName}  (${device.partId})")
            appendLine("Family: ${device.family}")
            appendLine("Signature: ${signature ?: device.signature}")
            appendLine("Flash: ${device.flashSizeBytes} bytes   EEPROM: ${device.eepromSizeBytes} bytes")
            append("Fuses: ${device.fuseCount}   Lock bits: ${if (device.hasLockBits) "yes" else "no"}")
        }
    }

    private fun handleEvent(event: DashboardUiEvent) {
        when (event) {
            is DashboardUiEvent.ShowMessage -> Snackbar.make(binding.root, event.message, Snackbar.LENGTH_SHORT).show()
            is DashboardUiEvent.ShowError -> Snackbar.make(binding.root, event.message, Snackbar.LENGTH_LONG).show()
            DashboardUiEvent.RequestChipEraseConfirmation -> showChipEraseConfirmation()
            DashboardUiEvent.FocusEepromSection -> binding.scrollToEepromSection()
        }
    }

    private fun FragmentDashboardBinding.scrollToEepromSection() {
        (root as? androidx.core.widget.NestedScrollView)?.post {
            root.smoothScrollTo(0, layoutEepromFile.top)
        }
    }

    private fun showChipEraseConfirmation() {
        AlertDialog.Builder(requireContext())
            .setTitle(R.string.fuse_warning_title)
            .setMessage("Chip Erase will permanently erase Flash, EEPROM (unless EESAVE is set), and reset lock bits. This cannot be undone. Continue?")
            .setPositiveButton(R.string.fuse_warning_proceed) { _, _ -> viewModel.chipErase() }
            .setNegativeButton(R.string.fuse_warning_cancel, null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
