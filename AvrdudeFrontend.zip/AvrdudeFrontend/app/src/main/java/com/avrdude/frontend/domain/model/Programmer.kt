package com.avrdude.frontend.domain.model

/**
 * A programmer backend as AVRDUDE identifies it via `-c <id>`. The `id` values
 * here are AVRDUDE's own programmer ids (public, documented CLI vocabulary —
 * see `avrdude -c ?` for the authoritative list baked into this exact build,
 * which the Settings screen can fetch live via listSupportedProgrammers()).
 * This curated subset just gives the picker sensible defaults + friendly
 * names + a hint about the expected port type before that live list loads.
 */
data class Programmer(
    val id: String,
    val displayName: String,
    val portHint: PortHint,
    val notes: String = "",
)

enum class PortHint { USB_LIBUSB, USB_SERIAL, EITHER }

object KnownProgrammers {
    val CATALOG = listOf(
        Programmer("usbasp", "USBasp", PortHint.USB_LIBUSB, "Common low-cost ISP programmer"),
        Programmer("usbtiny", "USBtinyISP", PortHint.USB_LIBUSB, "V-USB based low-speed ISP"),
        Programmer("avrispmkii", "AVRISP mkII", PortHint.USB_LIBUSB, "Atmel/Microchip official ISP programmer"),
        Programmer("jtagmkII", "JTAGICE mkII", PortHint.USB_LIBUSB, "JTAG/debugWIRE"),
        Programmer("jtagice3_isp", "JTAGICE3 (ISP mode)", PortHint.USB_LIBUSB, ""),
        Programmer("atmelice_isp", "Atmel-ICE (ISP mode)", PortHint.USB_LIBUSB, ""),
        Programmer("atmelice_pdi", "Atmel-ICE (PDI mode)", PortHint.USB_LIBUSB, "XMEGA"),
        Programmer("atmelice_updi", "Atmel-ICE (UPDI mode)", PortHint.USB_LIBUSB, "modern tinyAVR/megaAVR-0"),
        Programmer("dragon_isp", "AVR Dragon (ISP mode)", PortHint.USB_LIBUSB, ""),
        Programmer("dragon_jtag", "AVR Dragon (JTAG mode)", PortHint.USB_LIBUSB, ""),
        Programmer("stk500v1", "STK500 (v1 protocol)", PortHint.USB_SERIAL, "Also matches Arduino-as-ISP sketch"),
        Programmer("stk500v2", "STK500 (v2 protocol)", PortHint.USB_SERIAL, ""),
        Programmer("arduino", "Arduino bootloader (stk500v1)", PortHint.USB_SERIAL, "Uno/Nano/etc via bootloader"),
        Programmer("avr109", "avr109 bootloader", PortHint.USB_SERIAL, "Leonardo/Micro/Caterina bootloader"),
        Programmer("jtag2updi", "jtag2updi", PortHint.USB_SERIAL, "Arduino-as-UPDI-programmer sketch"),
        Programmer("serialupdi", "SerialUPDI", PortHint.USB_SERIAL, "Direct UPDI over a USB-serial adapter"),
        Programmer("linuxspi", "Linux SPI (spidev)", PortHint.EITHER, "Not applicable without root SPI access"),
    )

    fun byId(id: String): Programmer? = CATALOG.find { it.id == id }
}
