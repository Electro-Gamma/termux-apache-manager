package com.avrdude.frontend.presentation.usbpicker

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.avrdude.frontend.databinding.ItemUsbDeviceBinding
import com.avrdude.frontend.usb.SupportedProgrammers
import com.avrdude.frontend.usb.UsbDeviceInfo

class UsbDeviceAdapter(
    private val onDeviceClicked: (UsbDeviceInfo) -> Unit,
) : ListAdapter<UsbDeviceInfo, UsbDeviceAdapter.ViewHolder>(DIFF) {

    inner class ViewHolder(val binding: ItemUsbDeviceBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemUsbDeviceBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val device = getItem(position)
        val friendlyName = SupportedProgrammers.friendlyName(device.vendorId, device.productId)
            ?: device.productName ?: "Unknown device"
        holder.binding.textDeviceName.text = "$friendlyName (${device.vidPidHex})"

        val permissionText = if (device.hasPermission) "granted" else "not granted"
        val mfr = device.manufacturerName ?: "—"
        holder.binding.textDeviceDetail.text = "Mfr: $mfr  •  Permission: $permissionText"

        holder.binding.btnDeviceAction.text = if (device.hasPermission) "Selected" else "Request"
        holder.binding.btnDeviceAction.isEnabled = !device.hasPermission
        holder.binding.root.setOnClickListener { onDeviceClicked(device) }
        holder.binding.btnDeviceAction.setOnClickListener { onDeviceClicked(device) }
    }

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<UsbDeviceInfo>() {
            override fun areItemsTheSame(oldItem: UsbDeviceInfo, newItem: UsbDeviceInfo) =
                oldItem.deviceName == newItem.deviceName

            override fun areContentsTheSame(oldItem: UsbDeviceInfo, newItem: UsbDeviceInfo) =
                oldItem == newItem
        }
    }
}
