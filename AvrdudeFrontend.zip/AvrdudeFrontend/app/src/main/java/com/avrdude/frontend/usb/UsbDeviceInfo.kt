package com.avrdude.frontend.usb

/** UI-friendly snapshot of a android.hardware.usb.UsbDevice, plus our best
 *  guess at which AVRDUDE programmer it corresponds to (if any). */
data class UsbDeviceInfo(
    val deviceName: String,       // e.g. "/dev/bus/usb/001/004"
    val vendorId: Int,
    val productId: Int,
    val manufacturerName: String?,
    val productName: String?,
    val serialNumber: String?,    // null until permission is granted (privacy-gated by Android)
    val hasPermission: Boolean,
    val guessedProgrammerId: String?, // AVRDUDE -c id, from SupportedProgrammers lookup
) {
    val vidPidHex: String get() = "%04X:%04X".format(vendorId, productId)
}
