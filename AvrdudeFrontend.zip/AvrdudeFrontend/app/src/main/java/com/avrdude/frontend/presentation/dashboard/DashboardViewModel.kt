package com.avrdude.frontend.presentation.dashboard

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.avrdude.frontend.data.devicedb.McuDatabase
import com.avrdude.frontend.data.files.AvrdudeConfigProvider
import com.avrdude.frontend.data.files.FileManager
import com.avrdude.frontend.data.prefs.AppPreferences
import com.avrdude.frontend.data.repository.ConnectionParams
import com.avrdude.frontend.data.session.ConnectionSession
import com.avrdude.frontend.di.ServiceLocator
import com.avrdude.frontend.domain.model.FileFormat
import com.avrdude.frontend.domain.model.McuDevice
import com.avrdude.frontend.domain.model.ProgressState
import com.avrdude.frontend.domain.repository.AvrdudeRepository
import com.avrdude.frontend.domain.repository.ConnectionState
import com.avrdude.frontend.usb.UsbDeviceInfo
import com.avrdude.frontend.usb.UsbPermissionManager
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class DashboardUiState(
    val programmerId: String = "",
    val partId: String = "",
    val port: String = "usb",
    val baudRate: Int? = null,
    val bitclockUs: Double? = null,
    val overrideSignatureCheck: Boolean = false,
    val selectedUsbDevice: UsbDeviceInfo? = null,
    val detectedDevice: McuDevice? = null,
    val detectedSignature: String? = null,
    val flashFilePath: String? = null,
    val flashFileFormat: FileFormat = FileFormat.INTEL_HEX,
    val eepromFilePath: String? = null,
    val eepromFileFormat: FileFormat = FileFormat.INTEL_HEX,
    val verifyAfterWrite: Boolean = true,
    val chipEraseBeforeWrite: Boolean = true,
    val isConfigConfigured: Boolean = false,
)

/** One-off UI events the Fragment/Activity should react to but that don't
 *  belong in persisted state (dialogs, scroll requests, toasts). */
sealed class DashboardUiEvent {
    object RequestChipEraseConfirmation : DashboardUiEvent()
    object FocusEepromSection : DashboardUiEvent()
    data class ShowMessage(val message: String) : DashboardUiEvent()
    data class ShowError(val message: String) : DashboardUiEvent()
}

class DashboardViewModel(
    private val repository: AvrdudeRepository,
    private val usbManager: UsbPermissionManager,
    private val fileManager: FileManager,
    private val preferences: AppPreferences,
    private val configProvider: AvrdudeConfigProvider,
    private val connectionSession: ConnectionSession,
) : ViewModel() {

    val progress: StateFlow<ProgressState> = repository.progress
    val connectionState: StateFlow<ConnectionState> = repository.connectionState
    val usbDevices: StateFlow<List<UsbDeviceInfo>> = usbManager.devices

    private val _uiState = MutableStateFlow(DashboardUiState())
    val uiState: StateFlow<DashboardUiState> = _uiState.asStateFlow()

    private val _uiEvents = MutableSharedFlow<DashboardUiEvent>(extraBufferCapacity = 8)
    val uiEvents: SharedFlow<DashboardUiEvent> = _uiEvents.asSharedFlow()

    init {
        viewModelScope.launch {
            preferences.defaultProgrammer.collect { id ->
                if (!id.isNullOrBlank() && _uiState.value.programmerId.isBlank()) {
                    _uiState.update { it.copy(programmerId = id) }
                }
            }
        }
        viewModelScope.launch {
            preferences.defaultMcu.collect { id ->
                if (!id.isNullOrBlank() && _uiState.value.partId.isBlank()) {
                    _uiState.update { it.copy(partId = id) }
                }
            }
        }
        viewModelScope.launch {
            preferences.verifyAfterWrite.collect { v -> _uiState.update { it.copy(verifyAfterWrite = v) } }
        }
        viewModelScope.launch {
            preferences.chipEraseBeforeWrite.collect { v -> _uiState.update { it.copy(chipEraseBeforeWrite = v) } }
        }
        _uiState.update { it.copy(isConfigConfigured = configProvider.isConfigured()) }
        refreshUsbDevices()
    }

    fun refreshConfigStatus() {
        _uiState.update { it.copy(isConfigConfigured = configProvider.isConfigured()) }
    }

    fun importAvrdudeConf(uri: Uri) = viewModelScope.launch {
        val ok = configProvider.importFrom(uri)
        refreshConfigStatus()
        if (ok) {
            repository.initialize() // re-resolve now that a conf is present
            _uiEvents.emit(DashboardUiEvent.ShowMessage("avrdude.conf imported."))
        } else {
            _uiEvents.emit(DashboardUiEvent.ShowError("Could not import that file as avrdude.conf."))
        }
    }

    // ------------------------------------------------------------------
    // USB
    // ------------------------------------------------------------------

    fun refreshUsbDevices() = usbManager.refreshDeviceList()

    fun selectUsbDevice(info: UsbDeviceInfo) {
        _uiState.update {
            it.copy(
                selectedUsbDevice = info,
                port = "usb", // libusb-backed programmers address by VID/PID via avrdude.conf + the
                              // handed-down fd, not a device path — "usb" is AVRDUDE's own generic
                              // port token for libusb programmers. Serial-backed programmers should
                              // set the /dev path manually via setPort() instead.
                programmerId = info.guessedProgrammerId ?: it.programmerId,
            )
        }
        val device = usbManager.findDeviceByName(info.deviceName) ?: return
        viewModelScope.launch {
            usbManager.requestPermission(device).collect { granted ->
                if (granted) {
                    val fd = usbManager.openDeviceAndGetFd(device)
                    if (fd != null) {
                        repository.attachUsbFileDescriptor(fd)
                        _uiEvents.emit(DashboardUiEvent.ShowMessage("USB permission granted, fd attached."))
                    }
                } else {
                    _uiEvents.emit(DashboardUiEvent.ShowError("USB permission was denied."))
                }
                refreshUsbDevices()
            }
        }
    }

    // ------------------------------------------------------------------
    // Programmer / part / port selection
    // ------------------------------------------------------------------

    fun selectProgrammer(id: String) = _uiState.update { it.copy(programmerId = id) }
    fun selectPart(id: String) = _uiState.update { it.copy(partId = id, detectedDevice = McuDatabase.findByPartId(id)) }
    fun setPort(port: String) = _uiState.update { it.copy(port = port) }
    fun setBaudRate(baud: Int?) = _uiState.update { it.copy(baudRate = baud) }
    fun setBitclock(us: Double?) = _uiState.update { it.copy(bitclockUs = us) }
    fun setVerifyAfterWrite(enabled: Boolean) = _uiState.update { it.copy(verifyAfterWrite = enabled) }
    fun setChipEraseBeforeWrite(enabled: Boolean) = _uiState.update { it.copy(chipEraseBeforeWrite = enabled) }

    // ------------------------------------------------------------------
    // File selection (SAF)
    // ------------------------------------------------------------------

    fun pickFlashFileForWrite(uri: Uri, displayName: String) = viewModelScope.launch {
        val path = fileManager.importForRead(uri, displayName)
        _uiState.update { it.copy(flashFilePath = path, flashFileFormat = guessFormat(displayName)) }
    }

    fun pickEepromFileForWrite(uri: Uri, displayName: String) = viewModelScope.launch {
        val path = fileManager.importForRead(uri, displayName)
        _uiState.update { it.copy(eepromFilePath = path, eepromFileFormat = guessFormat(displayName)) }
    }

    fun allocateFlashReadTarget(): String = fileManager.allocateOutputPath("flash_read_${System.currentTimeMillis()}.hex")
    fun allocateEepromReadTarget(): String = fileManager.allocateOutputPath("eeprom_read_${System.currentTimeMillis()}.hex")

    private fun guessFormat(name: String): FileFormat = when {
        name.endsWith(".hex", true) -> FileFormat.INTEL_HEX
        name.endsWith(".elf", true) -> FileFormat.ELF
        name.endsWith(".bin", true) -> FileFormat.RAW_BINARY
        else -> FileFormat.INTEL_HEX
    }

    // ------------------------------------------------------------------
    // Connection params helper
    // ------------------------------------------------------------------

    private fun currentParams(overridePartId: String? = null): ConnectionParams? {
        val s = _uiState.value
        val partId = overridePartId ?: s.partId
        if (s.programmerId.isBlank() || partId.isBlank() || s.port.isBlank()) {
            viewModelScope.launch { _uiEvents.emit(DashboardUiEvent.ShowError("Select a programmer, part, and port first.")) }
            return null
        }
        val params = ConnectionParams(
            programmerId = s.programmerId, partId = partId, port = s.port,
            baudRate = s.baudRate, bitclock = s.bitclockUs,
            overrideSignatureCheck = s.overrideSignatureCheck,
        )
        connectionSession.update(params)
        return params
    }

    private fun reportFailure(label: String, throwable: Throwable) = viewModelScope.launch {
        _uiEvents.emit(DashboardUiEvent.ShowError("$label: ${throwable.message}"))
    }

    // ------------------------------------------------------------------
    // Operations — each mirrors a bottom-toolbar / operations-panel button
    // ------------------------------------------------------------------

    /** "Detect Device": reads the signature using the currently selected
     *  (or a sensible default) part as a best guess, then looks the actual
     *  returned signature up in McuDatabase to identify the real part. */
    fun detectDevice() = viewModelScope.launch {
        val guessPart = _uiState.value.partId.ifBlank { "m328p" }
        val params = currentParams(overridePartId = guessPart) ?: return@launch
        repository.readSignature(params)
            .onSuccess { sig ->
                val device = McuDatabase.findBySignature(sig)
                _uiState.update {
                    it.copy(
                        detectedSignature = sig,
                        detectedDevice = device,
                        partId = device?.partId ?: it.partId,
                    )
                }
                _uiEvents.emit(
                    DashboardUiEvent.ShowMessage(
                        if (device != null) "Detected ${device.displayName} (sig $sig)"
                        else "Signature $sig — not in the local reference table, but AVRDUDE recognized it; check listSupportedDevices()."
                    )
                )
            }
            .onFailure { reportFailure("Detect failed", it) }
    }

    fun readSignature() = detectDevice()

    fun chipErase() = viewModelScope.launch {
        val params = currentParams() ?: return@launch
        repository.chipErase(params)
            .onSuccess { _uiEvents.emit(DashboardUiEvent.ShowMessage("Chip erase complete.")) }
            .onFailure { reportFailure("Chip erase failed", it) }
    }

    /** Chip erase is destructive — route through a confirmation event first. */
    fun confirmAndChipErase() = viewModelScope.launch {
        _uiEvents.emit(DashboardUiEvent.RequestChipEraseConfirmation)
    }

    fun readFlash() = viewModelScope.launch {
        val params = currentParams() ?: return@launch
        val target = allocateFlashReadTarget()
        repository.readFlash(params, target, FileFormat.INTEL_HEX)
            .onSuccess {
                _uiState.update { it.copy(flashFilePath = target, flashFileFormat = FileFormat.INTEL_HEX) }
                _uiEvents.emit(DashboardUiEvent.ShowMessage("Flash read to $target"))
            }
            .onFailure { reportFailure("Read flash failed", it) }
    }

    fun writeFlash() = viewModelScope.launch {
        val params = currentParams() ?: return@launch
        val s = _uiState.value
        val file = s.flashFilePath
        if (file == null) {
            _uiEvents.emit(DashboardUiEvent.ShowError("Select a HEX/ELF/BIN file to write first."))
            return@launch
        }
        repository.writeFlash(params, file, s.flashFileFormat, s.verifyAfterWrite, s.chipEraseBeforeWrite)
            .onSuccess { _uiEvents.emit(DashboardUiEvent.ShowMessage("Flash write complete.")) }
            .onFailure { reportFailure("Write flash failed", it) }
    }

    fun verifyFlash() = viewModelScope.launch {
        val params = currentParams() ?: return@launch
        val file = _uiState.value.flashFilePath
        if (file == null) {
            _uiEvents.emit(DashboardUiEvent.ShowError("Select a reference file to verify against first."))
            return@launch
        }
        repository.verifyFlash(params, file, _uiState.value.flashFileFormat)
            .onSuccess { _uiEvents.emit(DashboardUiEvent.ShowMessage("Flash verified OK.")) }
            .onFailure { reportFailure("Verify flash failed", it) }
    }

    fun dumpFlash() = readFlash() // "Dump" = read-to-file; same underlying operation, kept as a
                                  // distinct button per spec since users think of it separately.

    fun requestFocusEepromSection() = viewModelScope.launch { _uiEvents.emit(DashboardUiEvent.FocusEepromSection) }

    fun readEeprom() = viewModelScope.launch {
        val params = currentParams() ?: return@launch
        val target = allocateEepromReadTarget()
        repository.readEEPROM(params, target, FileFormat.INTEL_HEX)
            .onSuccess {
                _uiState.update { it.copy(eepromFilePath = target, eepromFileFormat = FileFormat.INTEL_HEX) }
                _uiEvents.emit(DashboardUiEvent.ShowMessage("EEPROM read to $target"))
            }
            .onFailure { reportFailure("Read EEPROM failed", it) }
    }

    fun writeEeprom() = viewModelScope.launch {
        val params = currentParams() ?: return@launch
        val s = _uiState.value
        val file = s.eepromFilePath
        if (file == null) {
            _uiEvents.emit(DashboardUiEvent.ShowError("Select an EEPROM image file to write first."))
            return@launch
        }
        repository.writeEEPROM(params, file, s.eepromFileFormat, s.verifyAfterWrite)
            .onSuccess { _uiEvents.emit(DashboardUiEvent.ShowMessage("EEPROM write complete.")) }
            .onFailure { reportFailure("Write EEPROM failed", it) }
    }

    fun verifyEeprom() = viewModelScope.launch {
        val params = currentParams() ?: return@launch
        val file = _uiState.value.eepromFilePath
        if (file == null) {
            _uiEvents.emit(DashboardUiEvent.ShowError("Select a reference EEPROM file to verify against first."))
            return@launch
        }
        repository.verifyEEPROM(params, file, _uiState.value.eepromFileFormat)
            .onSuccess { _uiEvents.emit(DashboardUiEvent.ShowMessage("EEPROM verified OK.")) }
            .onFailure { reportFailure("Verify EEPROM failed", it) }
    }

    fun dumpEeprom() = readEeprom()

    fun readCalibration() = viewModelScope.launch {
        val params = currentParams() ?: return@launch
        repository.readCalibration(params)
            .onSuccess { value -> _uiEvents.emit(DashboardUiEvent.ShowMessage("Calibration byte: 0x%02X".format(value))) }
            .onFailure { reportFailure("Read calibration failed", it) }
    }

    fun readProductionSignature() = readSignature() // AVRDUDE's "signature" memtype IS the production
                                                     // signature row read for classic AVRs; modern
                                                     // UPDI parts additionally expose a distinct
                                                     // "sigrow" memtype for extra factory-programmed
                                                     // data, not modeled separately here.

    fun cancelOperation() {
        repository.cancelOperation()
    }
}

class DashboardViewModelFactory(private val locator: ServiceLocator) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return DashboardViewModel(
            repository = locator.avrdudeRepository,
            usbManager = locator.usbPermissionManager,
            fileManager = locator.fileManager,
            preferences = locator.appPreferences,
            configProvider = locator.configProvider,
            connectionSession = locator.connectionSession,
        ) as T
    }
}
