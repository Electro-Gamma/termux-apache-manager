package com.avrdude.frontend.core

/**
 * Thrown (wrapped in a failed Kotlin Result<T>) when an AVRDUDE-backed
 * operation does not complete successfully. Carries the process exit code
 * and a tail of console output so the UI's error dialog can show something
 * more useful than "operation failed".
 */
class AvrdudeOperationException(
    message: String,
    val exitCode: Int,
    val wasCancelled: Boolean,
    val consoleTail: List<String> = emptyList(),
) : Exception(message)

/** Thrown when the native bridge failed to initialize — e.g. libavrdude2.so
 *  missing from nativeLibraryDir or not extracted with the executable bit
 *  set (see the extractNativeLibs manifest note). */
class NativeBridgeNotReadyException(message: String) : Exception(message)

/** Thrown when a USB device is opened/claimed but permission was denied or
 *  revoked mid-operation. */
class UsbPermissionException(message: String) : Exception(message)
