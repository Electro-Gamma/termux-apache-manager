package com.avrdude.frontend.presentation.console

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.core.widget.addTextChangedListener
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.avrdude.frontend.AvrdudeApp
import com.avrdude.frontend.databinding.FragmentConsoleBinding
import com.avrdude.frontend.domain.model.LogLevel
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.launch

class ConsoleFragment : Fragment() {

    private var _binding: FragmentConsoleBinding? = null
    private val binding get() = _binding!!

    private val viewModel: ConsoleViewModel by viewModels {
        ConsoleViewModelFactory((requireActivity().application as AvrdudeApp).serviceLocator)
    }

    private lateinit var adapter: ConsoleAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentConsoleBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter = ConsoleAdapter()
        binding.recyclerConsole.adapter = adapter
        binding.recyclerConsole.layoutManager = LinearLayoutManager(requireContext())

        val levelLabels = LogLevel.entries.map { it.name }
        binding.dropdownLevel.setAdapter(ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, levelLabels))
        binding.dropdownLevel.setText(LogLevel.DEBUG.name, false)
        binding.dropdownLevel.setOnItemClickListener { _, _, position, _ ->
            viewModel.setMinLevel(LogLevel.entries[position])
        }

        binding.editFilterQuery.addTextChangedListener { text -> viewModel.setQuery(text?.toString() ?: "") }

        binding.btnCopy.setOnClickListener {
            val clipboard = requireContext().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("AVRDUDE console", viewModel.copyText()))
            Snackbar.make(binding.root, "Copied to clipboard.", Snackbar.LENGTH_SHORT).show()
        }
        binding.btnSave.setOnClickListener { viewModel.saveToFile() }
        binding.btnClear.setOnClickListener { viewModel.clear() }

        observeState()
    }

    private fun observeState() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.visibleEntries.collect { entries ->
                        adapter.submitList(entries) {
                            if (entries.isNotEmpty()) binding.recyclerConsole.scrollToPosition(entries.size - 1)
                        }
                    }
                }
                launch {
                    viewModel.events.collect { event ->
                        when (event) {
                            is ConsoleUiEvent.ShowMessage -> Snackbar.make(binding.root, event.message, Snackbar.LENGTH_SHORT).show()
                            is ConsoleUiEvent.OfferShare -> {
                                val intent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_STREAM, event.uri)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                startActivity(Intent.createChooser(intent, "Share AVRDUDE log"))
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
