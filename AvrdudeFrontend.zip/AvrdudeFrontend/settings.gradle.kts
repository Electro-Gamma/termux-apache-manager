pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // usb-serial-for-android (FTDI/CP210x/CH340/PL2303/CDC-ACM support
        // for Arduino-class USB-serial adapters) is published via JitPack,
        // not Maven Central. See app/build.gradle.kts and
        // usb/SerialPtyBridge.kt.
        maven { url = uri("https://jitpack.io") }
    }
}

rootProject.name = "AvrdudeFrontend"
include(":app")
