package com.tcpuartbridge.app.ch341

/**
 * CH341A "SPI stream" command protocol - ported from flashrom's `ch341a_spi.c`
 * (GPLv2-or-later; see NOTICE.md at the repo root): `config_stream()`, `enable_pins()`,
 * `ch341a_spi_send_command()`, and the `swap_byte()` LSB/MSB bit-reversal it relies on
 * (the CH341A clocks the SPI stream LSB-first internally, so bytes are bit-reversed on the way
 * in and out to present normal MSB-first SPI semantics to callers).
 *
 * The CS/SCK/MOSI/MISO pins' *direction* is claimed once via [init] (called when a session
 * starts) and given back via [shutdown] (when it ends). CS *itself* toggles far more often than
 * that: every [transfer] call is its own independently CS-bracketed SPI transaction - i.e. every
 * call pulses "chip select low ... chip select high" around itself, exactly like one discrete SPI
 * command to a flash/EEPROM chip - see [transfer]'s own doc for why that per-call pulse is
 * essential and not just a nicety.
 */
class Ch341Spi(private val dev: Ch341UsbDevice) {

    fun configStream(speed: Int = SPEED_SINGLE_750K): Boolean =
        dev.bulkOut(byteArrayOf(CMD_I2C_STREAM.toByte(), (STM_SET or (speed and 0x07)).toByte(), STM_END.toByte()))

    /** Configures the UIO pins for SPI use (CS/SCK/MOSI as outputs) or releases them. Ported
     *  verbatim from flashrom's enable_pins() - see its comment there for the exact D0-D7 -> CS/
     *  SCK/MOSI/MISO pin mapping. */
    fun enablePins(enable: Boolean): Boolean {
        val buf = byteArrayOf(
            CMD_UIO_STREAM.toByte(),
            (UIO_OUT or 0x37).toByte(), // CS high (all), SCK=0, DOUT*=1
            (UIO_OUT or 0x37).toByte(),
            (UIO_OUT or 0x37).toByte(),
            (UIO_OUT or 0x37).toByte(),
            (UIO_OUT or 0x37).toByte(),
            (UIO_OUT or 0x36).toByte(), // CS low (all), SCK=0, DOUT*=1
            (UIO_DIR or (if (enable) 0x3F else 0x00)).toByte(),
            UIO_END.toByte()
        )
        return dev.bulkOut(buf)
    }

    fun init(speed: Int = SPEED_SINGLE_750K): Boolean = configStream(speed) && enablePins(true)

    fun shutdown(): Boolean = enablePins(false)

    /**
     * One CS-bracketed SPI transaction: pulses CS low, clocks [writeData] out on MOSI, then
     * clocks [readCount] more bytes (sending 0xFF filler on MOSI while doing so), pulses CS back
     * high, and returns just the response bytes.
     *
     * The data-phase framing is ported from `ch341a_spi_send_command()` verbatim - but that C
     * function, by itself, never touches CS at all. CH341A's CS pin (D0) is a plain GPIO output
     * that only changes when an explicit UIO command sets it; it is NOT pulsed automatically by
     * the SPI-stream (0xA8) command. Every call site in IMSProg's spi_nor_flash.c brackets its
     * SPI_CONTROLLER_Write_NByte/Read_NByte calls with SPI_CONTROLLER_Chip_Select_Low()/_High()
     * (which, for CH341A, are just `enable_pins(true)`/`enable_pins(false)`) - so [enablePins]
     * has to be called here, per transfer, to match. Skipping this means CS is only ever asserted
     * once (in [init]) and released once (in [shutdown]): the first SPI command after [init]
     * lands correctly, but every command after that just gets appended, from the chip's
     * perspective, onto whatever it thinks is still that first, never-terminated transaction -
     * which is exactly the "detect works, everything after it fails" failure mode this fixes.
     */
    fun transfer(writeData: ByteArray, readCount: Int): ByteArray? {
        val total = writeData.size + readCount
        if (total == 0) return ByteArray(0)

        if (!enablePins(true)) return null // CS low - SPI_CONTROLLER_Chip_Select_Low()
        val result = transferData(writeData, readCount, total)
        enablePins(false) // CS high - SPI_CONTROLLER_Chip_Select_High(); best-effort, like upstream,
        // so a hiccup on this trailing pulse doesn't throw away an otherwise-good read/write result.

        return result
    }

    private fun transferData(writeData: ByteArray, readCount: Int, total: Int): ByteArray? {
        // Leading all-zero 32-byte packet - matches the original's zeroed wbuf[0] header.
        val out = ArrayList<Byte>(32 + total + (total / SUBCHUNK + 2))
        repeat(32) { out.add(0.toByte()) }

        var writeLeft = writeData.size
        var readLeft = readCount
        var writeOff = 0
        val packets = (total + SUBCHUNK - 1) / SUBCHUNK
        for (p in 0 until packets) {
            val writeNow = minOf(SUBCHUNK, writeLeft)
            val readNow = minOf(SUBCHUNK - writeNow, readLeft)
            out.add(CMD_SPI_STREAM.toByte())
            for (i in 0 until writeNow) {
                out.add(swapByte(writeData[writeOff + i]).toByte())
            }
            writeOff += writeNow
            writeLeft -= writeNow
            if (readNow > 0) {
                repeat(readNow) { out.add(0xFF.toByte()) }
                readLeft -= readNow
            }
        }

        if (!dev.bulkOut(out.toByteArray())) return null
        if (readCount == 0) return ByteArray(0)

        val resp = dev.readExactly(total) ?: return null
        val result = ByteArray(readCount)
        for (i in 0 until readCount) {
            result[i] = swapByte(resp[writeData.size + i]).toByte()
        }
        return result
    }

    private fun swapByte(b: Byte): Int {
        var x = b.toInt() and 0xFF
        x = ((x shr 1) and 0x55) or ((x shl 1) and 0xAA)
        x = ((x shr 2) and 0x33) or ((x shl 2) and 0xCC)
        x = ((x shr 4) and 0x0F) or ((x shl 4) and 0xF0)
        return x and 0xFF
    }

    companion object {
        private const val CMD_I2C_STREAM = 0xAA // config_stream() shares the I2C stream command
        private const val CMD_SPI_STREAM = 0xA8
        private const val CMD_UIO_STREAM = 0xAB

        private const val STM_SET = 0x60
        private const val STM_END = 0x00

        private const val UIO_OUT = 0x80
        private const val UIO_DIR = 0x40
        private const val UIO_END = 0x20

        /** CH341_PACKET_LENGTH (32) minus 1 command byte, i.e. max data bytes per sub-packet. */
        private const val SUBCHUNK = 31

        /** CH341A_STM_SPI_DBL bit unset = single data-rate, matches flashrom's default. */
        const val SPEED_SINGLE_750K = 0x03
    }
}
