"""
TCP-backed drop-in replacement for the classic ioctl-based `smbus.py` (the one bundled with
Adafruit_PureIO, MIT-licensed - see NOTICE.md). Same public method surface, so
`smbus_ssd1306.py` and anything else written against that API keeps working unmodified -
only the transport changed, from local /dev/i2c-* ioctl calls to a TCP connection to a phone
running TCP UART Bridge's "Programmer" tab with its I2C-over-TCP server turned on.

The one behavioural difference callers need to know about: `bus` is now a "host:port" string
(or a (host, port) tuple) instead of a Linux bus number - see SMBus.open()'s docstring.

Wire protocol (must match I2cTcpServer.kt on the phone):
    Request:  [opcode:u8][addr7:u8][writeLen:u16][writeData...][readLen:u16]
    Response: [status:u8][dataLen:u16][data...]
    status: 0 = OK, 1 = I2C/USB failure, 2 = bad request. All integers big-endian.
"""

import socket
import struct

_OP_WRITE = 0x01
_OP_READ = 0x02
_OP_WRITE_THEN_READ = 0x03

_STATUS_OK = 0
_STATUS_I2C_ERROR = 1
_STATUS_BAD_REQUEST = 2

DEFAULT_PORT = 3334


class I2CTransferError(IOError):
    """Raised when the phone reports the I2C transaction itself failed - a bad status byte,
    as opposed to a socket-level error. Usually means: no device at that address, the wiring
    is wrong, or the phone's Programmer tab isn't connected in I2C EEPROM / SSD1306 Display
    mode (SPI Flash mode configures the CH341A's shared clock for SPI, not I2C)."""


class SMBus:
    """I2C interface that mimics the Python SMBus API, but forwards every transaction over
    TCP to a TCP UART Bridge phone instead of talking to a local Linux I2C bus via ioctl.
    """

    def __init__(self, bus=None, port=DEFAULT_PORT, timeout=5.0):
        """`bus`, if given, is connected to immediately via open(bus, port) - see open()'s
        docstring for the accepted formats. Pass None (the default) to defer connecting."""
        self._sock = None
        self._timeout = timeout
        if bus is not None:
            self.open(bus, port)

    def __del__(self):
        self.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False  # don't suppress exceptions

    def open(self, bus, port=DEFAULT_PORT):
        """Connect to the phone. `bus` (kept as the parameter name for drop-in compatibility
        with the original SMBus(bus) call signature, even though it's no longer a Linux bus
        number) can be:
          - a "host:port" string, e.g. "192.168.1.50:3334"
          - a bare host string, e.g. "192.168.1.50" (uses `port`, default 3334)
          - a (host, port) tuple
        """
        self.close()
        host, resolved_port = self._parse_target(bus, port)
        self._sock = socket.create_connection((host, resolved_port), timeout=self._timeout)
        self._sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)

    def close(self):
        """Close the TCP connection. You cannot make any other calls on the bus unless open()
        is called again!"""
        if self._sock is not None:
            try:
                self._sock.close()
            finally:
                self._sock = None

    @staticmethod
    def _parse_target(bus, default_port):
        if isinstance(bus, tuple):
            return bus[0], bus[1]
        text = str(bus)
        if ":" in text:
            host, port_str = text.rsplit(":", 1)
            return host, int(port_str)
        return text, default_port

    # ---- wire protocol ------------------------------------------------------

    def _transact(self, opcode, addr, write_data=b"", read_len=0):
        assert self._sock is not None, "Bus must be opened before operations are made against it!"
        write_data = bytes(write_data)
        request = (
            struct.pack(">BBH", opcode, addr & 0x7F, len(write_data))
            + write_data
            + struct.pack(">H", read_len)
        )
        self._sock.sendall(request)
        status, data_len = struct.unpack(">BH", self._recv_exact(3))
        data = self._recv_exact(data_len) if data_len else b""
        if status == _STATUS_BAD_REQUEST:
            raise I2CTransferError("phone rejected the request (bad opcode/length)")
        if status != _STATUS_OK:
            raise I2CTransferError(
                "I2C transaction failed for address 0x%02X - check wiring/address and that "
                "the phone's Programmer tab is connected in I2C EEPROM or SSD1306 Display mode"
                % (addr & 0x7F)
            )
        return data

    def _recv_exact(self, n):
        chunks = []
        remaining = n
        while remaining > 0:
            chunk = self._sock.recv(remaining)
            if not chunk:
                raise IOError("connection closed by phone")
            chunks.append(chunk)
            remaining -= len(chunk)
        return b"".join(chunks)

    # ---- SMBus-compatible API -------------------------------------------------

    def read_byte(self, addr):
        """Read a single byte from the specified device."""
        return self._transact(_OP_READ, addr, read_len=1)[0]

    def read_bytes(self, addr, number):
        """Read many bytes from the specified device."""
        return self._transact(_OP_READ, addr, read_len=number)

    def read_byte_data(self, addr, cmd):
        """Read a single byte from the specified cmd register of the device."""
        return self._transact(_OP_WRITE_THEN_READ, addr, bytes([cmd & 0xFF]), read_len=1)[0]

    def read_word_data(self, addr, cmd):
        """Read a word (2 bytes, little-endian on the wire - the standard SMBus word order)
        from the specified cmd register of the device."""
        data = self._transact(_OP_WRITE_THEN_READ, addr, bytes([cmd & 0xFF]), read_len=2)
        return struct.unpack("<H", data)[0]

    def read_block_data(self, addr, cmd):
        """Not implemented - same as the original ioctl smbus.py. The length-prefixed SMBus
        block-read convention isn't exposed by the phone's I2cTcpServer; use
        read_i2c_block_data() with an explicit length instead, which covers the common case."""
        raise NotImplementedError()

    def read_i2c_block_data(self, addr, cmd, length=32):
        """Read `length` bytes starting at the specified cmd register of the device."""
        if not isinstance(cmd, (bytes, bytearray)):
            cmd = bytes([cmd & 0xFF])
        return bytearray(self._transact(_OP_WRITE_THEN_READ, addr, cmd, read_len=length))

    def write_quick(self, addr):
        """Write a single byte to the specified device (an address-only write, no data)."""
        self._transact(_OP_WRITE, addr)

    def write_byte(self, addr, val):
        """Write a single byte to the specified device."""
        self._transact(_OP_WRITE, addr, bytes([val & 0xFF]))

    def write_bytes(self, addr, buf):
        """Write many bytes to the specified device. buf is a bytes/bytearray."""
        self._transact(_OP_WRITE, addr, bytes(buf))

    def write_byte_data(self, addr, cmd, val):
        """Write a byte of data to the specified cmd register of the device."""
        self._transact(_OP_WRITE, addr, bytes([cmd & 0xFF, val & 0xFF]))

    def write_word_data(self, addr, cmd, val):
        """Write a word (2 bytes, little-endian - the standard SMBus word order) of data to
        the specified cmd register of the device."""
        self._transact(_OP_WRITE, addr, struct.pack("<BH", cmd & 0xFF, val & 0xFFFF))

    def write_block_data(self, addr, cmd, vals):
        """Write a block of data to the specified cmd register of the device, with the byte
        count sent first (the SMBus block-write convention)."""
        vals = bytes(vals)
        self._transact(_OP_WRITE, addr, bytes([cmd & 0xFF, len(vals) & 0xFF]) + vals)

    def write_i2c_block_data(self, addr, cmd, vals):
        """Write a buffer of data to the specified cmd register of the device (no byte-count
        prefix - just cmd followed by vals, the plain I2C block-write convention)."""
        self._transact(_OP_WRITE, addr, bytes([cmd & 0xFF]) + bytes(vals))

    def process_call(self, addr, cmd, val):
        """Write a word value to the specified register, then read a word of response data
        back (which is returned)."""
        data = self._transact(
            _OP_WRITE_THEN_READ, addr, struct.pack("<BH", cmd & 0xFF, val & 0xFFFF), read_len=2
        )
        return struct.unpack("<H", data)[0]
