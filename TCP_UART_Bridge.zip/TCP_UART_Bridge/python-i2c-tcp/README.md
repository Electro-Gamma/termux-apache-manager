# python-i2c-tcp

A drop-in, TCP-backed replacement for the classic ioctl-based `smbus.py` (the one bundled with
Adafruit_PureIO), so `lib/smbus_ssd1306.py` - and anything else written against the same
`SMBus` API - can talk to a CH341A's I2C bus over the network instead of a local Linux
`/dev/i2c-*` device. The other end is the **Programmer** tab's **I2C-over-TCP** server in the
main Android app (see the top-level `README.md`'s "Programmer tab" section, and
`I2cTcpServer.kt`'s doc comment for the exact wire protocol).

```
python-i2c-tcp/
├── lib/
│   ├── __init__.py
│   ├── smbus.py           - TCP-backed SMBus (this is the actual replacement)
│   └── smbus_ssd1306.py   - unmodified SSD1306 driver logic; only docstrings changed
├── image.py                - example: draw an image to an SSD1306 over TCP
└── README.md                - this file
```

## Setup

1. **On the phone:** open the app's **Programmer** tab, pick **I2C EEPROM** or **SSD1306 OLED
   Display** mode (I2C-over-TCP needs one of those two - **SPI Flash** mode configures the
   CH341A's shared clock for SPI, not I2C), tap **Connect**, then in the **I2C-over-TCP** card
   tap **Start**. It'll show something like `Listening on 192.168.1.50:3334` - that's the
   address you'll use below.
2. **On your PC/Mac/Pi/etc:** make sure it can reach the phone's IP (same Wi-Fi network, no
   client-isolation on the AP). No extra Python packages needed for `lib/smbus.py` itself
   (standard library only); `image.py`'s example additionally needs `pip install pillow`.

## Quick test - read a byte

```python
from lib.smbus import SMBus

bus = SMBus("192.168.1.50:3334")   # <-- your phone's address from the app
value = bus.read_byte_data(0x50, 0x00)   # e.g. byte 0 of a 24C02 EEPROM at address 0x50
print(hex(value))
bus.close()
```

Or as a context manager:

```python
with SMBus("192.168.1.50:3334") as bus:
    bus.write_byte_data(0x50, 0x10, 0xAB)
```

## SSD1306 display

See `image.py` for a full example. The short version:

```python
from lib.smbus_ssd1306 import SSD1306_128_64

disp = SSD1306_128_64(bus="192.168.1.50:3334", address=0x3C)
disp.begin()
disp.clear()
disp.display()
```

`bus` is passed straight through to `SMBus(bus)` - it's the phone's `"host:port"`, not a Linux
bus number, despite the parameter name (kept as `bus` so the call signature matches the
original ioctl-based driver this was adapted from).

## What's supported

`lib/smbus.py` implements the same methods the original `smbus.py` did: `read_byte`,
`read_bytes`, `read_byte_data`, `read_word_data`, `read_i2c_block_data`, `write_quick`,
`write_byte`, `write_bytes`, `write_byte_data`, `write_word_data`, `write_block_data`,
`write_i2c_block_data`, `process_call`. `read_block_data` (the length-prefixed SMBus block-read
variant) still raises `NotImplementedError`, same as the original - use `read_i2c_block_data`
with an explicit length instead.

Every call is a single request/response round-trip over TCP, so there's more latency per
transaction than a local hardware I2C bus (network + the CH341A's own USB round-trip) - fine
for EEPROM dumps and refreshing a small OLED, not something to build a high-frequency sensor
polling loop on.

## Troubleshooting

- **`I2CTransferError`**: either nothing ACKed at that address (check wiring/address, and that
  you're not confusing a 7-bit address with its 8-bit-with-R/W-bit form - this API takes plain
  7-bit addresses like the original), or the phone's Programmer tab isn't connected in I2C
  EEPROM / SSD1306 Display mode.
- **Connection refused / times out**: the phone's I2C-over-TCP server isn't running, or a
  firewall/AP client-isolation is blocking the port - check the "Listening on ..." line in the
  app matches what you're connecting to.
- **Everything works locally but not over TCP**: double check `bus=` is a `"host:port"` string,
  not a bare integer like the old Linux bus-number convention (`bus=0`) - that's the one
  meaningful call-signature difference from the original ioctl-based driver.
