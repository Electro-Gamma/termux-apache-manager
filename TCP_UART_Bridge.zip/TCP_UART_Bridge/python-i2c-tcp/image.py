"""
Example: draw an image to an SSD1306 OLED wired to a CH341A, itself wired to a phone running
TCP UART Bridge's "Programmer" tab (I2C-over-TCP server turned on). Same shape as the original
local-I2C example this was adapted from - only the `bus` argument changed, from a Linux bus
number (e.g. 0) to the phone's "host:port".

Before running:
  1. On the phone: Programmer tab -> mode "SSD1306 OLED Display" -> Connect -> I2C-over-TCP
     card -> Start. Note the "Listening on <ip>:<port>" line.
  2. On this machine: `pip install pillow` (only needed for the image-loading part below;
     the driver itself has no other dependencies beyond the standard library).
  3. Edit PHONE_ADDR below to match what the phone showed.
"""
from lib.smbus_ssd1306 import SSD1306_128_64
from PIL import Image

PHONE_ADDR = "192.168.1.50:3334"  # <-- change to match the phone's Programmer tab

# 128x64 display, talking over TCP instead of a local hardware I2C bus:
disp = SSD1306_128_64(bus=PHONE_ADDR, address=0x3C)

# Initialize library.
disp.begin()

# Clear display.
disp.clear()
disp.display()

# Load an image, convert to 1-bit, and resize to the panel if it isn't already that size.
image = Image.open('happycat_oled_64.ppm').convert('1')
if image.size != (disp.width, disp.height):
    image = image.resize((disp.width, disp.height)).convert('1')

# Display image.
disp.image(image)
disp.display()
