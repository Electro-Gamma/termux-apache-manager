# NOTICE

This project is otherwise original work, but the **Programmer tab**
(CH341A I2C EEPROM / SPI flash support) includes protocol logic ported
from two GPL-licensed C projects. This file documents what was ported
from where, per those licenses' attribution expectations. It's a factual
provenance note, not a legal opinion — if you plan to redistribute this
app, check the actual license terms yourself.

## Ported code

**`app/src/main/java/com/tcpuartbridge/app/ch341/Ch341Spi.kt`**
Protocol logic (`config_stream()`, `enable_pins()`,
`ch341a_spi_send_command()`, `swap_byte()`, and the packet-framing
constants) ported from **flashrom**'s `ch341a_spi.c`
(https://github.com/flashrom/flashrom), licensed GPL-2.0-or-later.

**`app/src/main/java/com/tcpuartbridge/app/ch341/Ch341I2c.kt`** and
**`app/src/main/java/com/tcpuartbridge/app/eeprom/I2cEeprom.kt`**
I2C stream command-byte protocol and the 24Cxx device-address encoding
scheme (the `algorithm` byte, and how extra address bits fold into the
device-address byte for chips like 24C04/08/16) ported from **IMSProg**'s
`ch34x_i2c.c` (`ch34xi2cBlockRead`/`ch34xi2cBlockWrite`)
(https://github.com/inexbee/IMSProg — this project was built from
IMSProg 1.8.6), licensed GPL-3.0-or-later.

## Original code

Everything else in the Programmer tab is original to this project,
written from public/standard specifications rather than any GPL source:

- **`app/src/main/java/com/tcpuartbridge/app/ch341/Ch341UsbDevice.kt`** -
  the raw Android `UsbDeviceConnection` transport (bulk transfers,
  permission flow). IMSProg/flashrom talk to the same chip via `libusb`
  on desktop OSes; this uses Android's own USB host API instead, so
  there's no meaningful code to port at that layer.
- **`app/src/main/java/com/tcpuartbridge/app/eeprom/SpiFlash.kt`** - the
  SPI NOR flash command set (JEDEC ID, page program, sector/chip erase,
  status polling) is the industry-standard instruction set used
  identically across virtually every 25xx-series flash chip regardless
  of manufacturer, not something specific to either GPL source.
- **`app/src/main/java/com/tcpuartbridge/app/display/Ssd1306.kt`** - the
  SSD1306 init sequence is standard across the chip's datasheet and
  every SSD1306 driver library; the 5x7 text font is this project's own
  (see the file's doc comment).
- **`app/src/main/java/com/tcpuartbridge/app/programmer/ProgrammerController.kt`**
  and the Programmer-tab UI code in `MainActivity.kt` / `panel_programmer.xml`
  are original glue code specific to this app.

## Rest of the app

The rest of this app (the Bridge tab, RFC2217 implementation, TCP
server, etc.) is original work; see the doc comments on
`TcpServerManager`'s auto-reset methods for the one other small
GPL-adjacent borrowing (exact timing constants from avrdude's
`arduino_open()`, GPL-2.0-or-later) that predates this Programmer-tab
addition.
