# NOTICE

This project is otherwise original work, but the **Programmer tab**
(CH341A I2C EEPROM / SPI flash support) includes protocol logic ported
from two GPL-licensed C projects. This file documents what was ported
from where, per those licenses' attribution expectations. It's a factual
provenance note, not a legal opinion — if you plan to redistribute this
app, check the actual license terms yourself.

## Ported code

**`app/src/main/java/com/tcpuartbridge/app/ch341/Ch341Spi.kt`**
Protocol logic (`config_stream()`, `enable_pins()`,
`ch341a_spi_send_command()`, `swap_byte()`, and the packet-framing
constants) ported from **flashrom**'s `ch341a_spi.c`
(https://github.com/flashrom/flashrom), licensed GPL-2.0-or-later.

**`app/src/main/java/com/tcpuartbridge/app/ch341/Ch341I2c.kt`** and
**`app/src/main/java/com/tcpuartbridge/app/eeprom/I2cEeprom.kt`**
I2C stream command-byte protocol and the 24Cxx device-address encoding
scheme (the `algorithm` byte, and how extra address bits fold into the
device-address byte for chips like 24C04/08/16, plus the 24LC1025/24LC515
variants that fold their extra bit into device-address bit 2 instead of
bit 0) ported from **IMSProg**'s `ch34x_i2c.c`
(`ch34xi2cBlockRead`/`ch34xi2cBlockWrite`)
(https://github.com/inexbee/IMSProg — this project was built from
IMSProg 1.8.6), licensed GPL-3.0-or-later.

**`app/src/main/java/com/tcpuartbridge/app/eeprom/SpiFlash.kt`** (partial)
Most of this file is original (see below), but `unprotect()` (clearing
the status register's block-protect bits before erase/write) and the
4-byte-addressing enter/exit commands in `configureAddressing()` are
ported from IMSProg's `spi_nor_flash.c` (`snorUnprotect()` /
`snor_4byte_mode()`'s generic 0xB7/0xE9 path — the Winbond/Spansion
vendor-specific quirks in that function were not ported), licensed
GPL-3.0-or-later.

**`app/src/main/java/com/tcpuartbridge/app/eeprom/SpiFlashDatabase.kt`**
The manufacturer-ID table and the exact part names for the EON/XMC
"25QH" family, Winbond W25Q, and GigaDevice GD25Q chips are extracted
from IMSProg's chip database (`IMSProg.Dat`), licensed GPL-3.0-or-later.
The JEDEC size-code-to-bytes formula itself is a public JEDEC convention,
not IMSProg-specific.

## Original code

Everything else in the Programmer tab is original to this project,
written from public/standard specifications rather than any GPL source:

- **`app/src/main/java/com/tcpuartbridge/app/ch341/Ch341UsbDevice.kt`** -
  the raw Android `UsbDeviceConnection` transport (bulk transfers,
  permission flow). IMSProg/flashrom talk to the same chip via `libusb`
  on desktop OSes; this uses Android's own USB host API instead, so
  there's no meaningful code to port at that layer.
- **`app/src/main/java/com/tcpuartbridge/app/eeprom/SpiFlash.kt`** (the
  rest of it) - the SPI NOR flash command set (JEDEC ID, page program,
  sector/chip erase, status polling) is the industry-standard
  instruction set used identically across virtually every 25xx-series
  flash chip regardless of manufacturer, not something specific to
  either GPL source. `writeRandom()` is this project's own addition.
- **`app/src/main/java/com/tcpuartbridge/app/eeprom/I2cEeprom.kt`**'s
  `erase()`, `writeRandom()`, and `detectSize()` are this project's own
  additions, not ported from IMSProg (IMSProg has no equivalent
  capacity-detection feature for I2C EEPROMs - it relies on the user
  picking the chip from its database).
- **`app/src/main/java/com/tcpuartbridge/app/ui/HexDumpAdapter.kt`** -
  a plain offset/hex/ASCII text dump (the classic `xxd`-style format),
  not a port of IMSProg's Qt-based hex-editor widget.
- **`app/src/main/java/com/tcpuartbridge/app/display/Ssd1306.kt`** - the
  SSD1306 init sequence is standard across the chip's datasheet and
  every SSD1306 driver library; the 5x7 text font is this project's own
  (see the file's doc comment).
- **`app/src/main/java/com/tcpuartbridge/app/programmer/ProgrammerController.kt`**
  and the Programmer-tab UI code in `MainActivity.kt` / `panel_programmer.xml`
  are original glue code specific to this app.

## Rest of the app

The rest of this app (the Bridge tab, RFC2217 implementation, TCP
server, etc.) is original work; see the doc comments on
`TcpServerManager`'s auto-reset methods for the one other small
GPL-adjacent borrowing (exact timing constants from avrdude's
`arduino_open()`, GPL-2.0-or-later) that predates this Programmer-tab
addition.

## python-i2c-tcp/ (companion PC-side client)

**`python-i2c-tcp/lib/smbus.py`** is original code: a from-scratch TCP
client, matching the *public method names and signatures* of the
classic ioctl-based `smbus.py` (Tony DiCola / Adafruit Industries,
MIT-licensed) so existing code written against that API keeps working -
matching a function signature isn't copying its expression, so this
doesn't carry that file's license forward. `app/.../I2cTcpServer.kt`,
the Android-side counterpart, is also original code (see above).

**`python-i2c-tcp/lib/smbus_ssd1306.py`** is different: it's the user-
provided SSD1306 driver file with its logic unchanged (only docstrings
were edited, to note the new transport). That file as provided didn't
carry its own license header; the sibling `smbus.py` it was distributed
with did (MIT, Tony DiCola / Adafruit Industries - see the header this
project's replacement `smbus.py` doesn't copy but was informed by). If
you plan to redistribute `smbus_ssd1306.py`, confirm its actual license
yourself rather than assuming MIT by association.
