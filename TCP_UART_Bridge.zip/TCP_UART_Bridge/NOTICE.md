# NOTICE

This project is otherwise original work, but the **Programmer tab**
(CH341A I2C EEPROM / SPI flash support) includes protocol logic ported
from two GPL-licensed C projects. This file documents what was ported
from where, per those licenses' attribution expectations. It's a factual
provenance note, not a legal opinion — if you plan to redistribute this
app, check the actual license terms yourself.

## Ported code

**`app/src/main/java/com/tcpuartbridge/app/ch341/Ch341Spi.kt`**
Protocol logic (`config_stream()`, `enable_pins()`,
`ch341a_spi_send_command()`, `swap_byte()`, and the packet-framing
constants) ported from **flashrom**'s `ch341a_spi.c`
(https://github.com/flashrom/flashrom), licensed GPL-2.0-or-later.

**`app/src/main/java/com/tcpuartbridge/app/ch341/Ch341I2c.kt`** and
**`app/src/main/java/com/tcpuartbridge/app/eeprom/I2cEeprom.kt`**
I2C stream command-byte protocol and the 24Cxx device-address encoding
scheme (the `algorithm` byte, and how extra address bits fold into the
device-address byte for chips like 24C04/08/16, plus the 24LC1025/24LC515
variants that fold their extra bit into device-address bit 2 instead of
bit 0) ported from **IMSProg**'s `ch34x_i2c.c`
(`ch34xi2cBlockRead`/`ch34xi2cBlockWrite`)
(https://github.com/inexbee/IMSProg — this project was built from
IMSProg 1.8.6), licensed GPL-3.0-or-later.

**`app/src/main/java/com/tcpuartbridge/app/eeprom/SpiFlash.kt`** (partial)
Most of this file is original (see below), but `unprotect()` (clearing
the status register's block-protect bits before erase/write) and the
4-byte-addressing enter/exit commands in `configureAddressing()` are
ported from IMSProg's `spi_nor_flash.c` (`snorUnprotect()` /
`snor_4byte_mode()`'s generic 0xB7/0xE9 path — the Winbond/Spansion
vendor-specific quirks in that function were not ported), licensed
GPL-3.0-or-later.

**`app/src/main/java/com/tcpuartbridge/app/eeprom/SpiFlashDatabase.kt`**
The manufacturer-ID table and the exact part names for the EON/XMC
"25QH" family, Winbond W25Q, and GigaDevice GD25Q chips are extracted
from IMSProg's chip database (`IMSProg.Dat`), licensed GPL-3.0-or-later.
The JEDEC size-code-to-bytes formula itself is a public JEDEC convention,
not IMSProg-specific.

## Ported code (BSD-licensed)

**`app/src/main/java/com/tcpuartbridge/app/display/Ssd1306.kt`**
The SSD1306 init sequence itself is standard across the chip's datasheet
and every SSD1306 driver library, and the word-wrap/framebuffer/flush
logic is original. But the per-panel-size (width *and* height, not just
height) COM-pin/contrast table in `panelConfig()`, the 64-wide-panel
column-address offset in `flush()`, and the hardware scroll commands
(`startScrollRight`/`Left`/`DiagRight`/`DiagLeft`/`stopScroll`) were
pulled from **Adafruit's official SSD1306 Arduino library**
(`Adafruit_SSD1306.cpp`, https://github.com/adafruit/Adafruit_SSD1306),
and `FONT_5X7` is Adafruit_GFX's classic `glcdfont.c` "Standard ASCII 5x7
font" (https://github.com/adafruit/Adafruit-GFX-Library) - both
BSD-licensed, Copyright (c) 2012 Adafruit Industries, replacing this
file's earlier hand-rolled uppercase/digits-only font and height-only
contrast bucketing (which had a real bug: it silently gave 96x16 panels
128x32's contrast value instead of their own).

## Original code

Everything else in the Programmer tab is original to this project,
written from public/standard specifications rather than any GPL source:

- **`app/src/main/java/com/tcpuartbridge/app/ch341/Ch341UsbDevice.kt`** -
  the raw Android `UsbDeviceConnection` transport (bulk transfers,
  permission flow). IMSProg/flashrom talk to the same chip via `libusb`
  on desktop OSes; this uses Android's own USB host API instead, so
  there's no meaningful code to port at that layer.
- **`app/src/main/java/com/tcpuartbridge/app/eeprom/SpiFlash.kt`** (the
  rest of it) - the SPI NOR flash command set (JEDEC ID, page program,
  sector/chip erase, status polling) is the industry-standard
  instruction set used identically across virtually every 25xx-series
  flash chip regardless of manufacturer, not something specific to
  either GPL source.
- **`app/src/main/java/com/tcpuartbridge/app/eeprom/I2cEeprom.kt`**'s
  `erase()` and `detectSize()` are this project's own additions, not
  ported from IMSProg (IMSProg has no equivalent capacity-detection
  feature for I2C EEPROMs - it relies on the user picking the chip from
  its database). "Write Random" (for both the I2C and SPI panels) isn't
  a separate ported/original function at all - `MainActivity` just
  generates a random buffer and reuses the same write path as a normal
  write, which is also what makes the hex editor able to show exactly
  what got written afterward.
- **`app/src/main/java/com/tcpuartbridge/app/ui/HexEditorAdapter.kt`** -
  a plain offset/hex/ASCII grid (`RecyclerView`-backed, one row per 16
  bytes, tap a byte to edit it) built for this app's own UI toolkit, not
  a port of IMSProg's Qt-based `QHexEdit` widget - it's the same general
  idea (and the same layout convention: offset | hex | ASCII) but none
  of the widget code itself.
- **`app/src/main/java/com/tcpuartbridge/app/display/OledCompositor.kt`**
  and the clock/stats-dashboard/animation additions to
  `ProgrammerController.kt` - original code. The clock/stats screens are
  conceptually similar to the classic Python `clock.py`/`stats.py`
  reference scripts this project's SSD1306 support was originally
  cross-checked against (same idea: an analog clock face, a battery/RAM/
  storage dashboard), but nothing was ported from them - the graphics
  are drawn with Android's `Canvas`, the phone-stats readings come from
  Android's own `BatteryManager`/`ActivityManager`/`StatFs` APIs (a
  phone has no CPU-temperature sensor API the way the Pi scripts assumed),
  and the animation loop is this project's own take on the same idea as
  `pbm_gif_all.py` (loop over a folder of frames) adapted to
  Android-picked image files instead of a folder of `.pbm`s.
- **`app/src/main/java/com/tcpuartbridge/app/programmer/ProgrammerController.kt`**
  and the Programmer-tab UI code in `MainActivity.kt` / `panel_programmer.xml`
  are original glue code specific to this app.

## Bundled font assets

**`app/src/main/assets/fonts/alagard.ttf`** and
**`app/src/main/assets/fonts/PixelOperator.ttf`** are third-party font
files bundled as-is (not modified), offered as one-tap "Custom Font"
options alongside picking any font from the phone. They're commonly
distributed as free-for-personal-and-commercial-use pixel fonts -
Alagard by Brian Kent (Vault42) and PixelOperator by Jayvee Enaguas
(HarvettFox96) - but as with `smbus_ssd1306.py` above, this project
didn't originate them and isn't the place to take a license's exact
terms on faith: if you plan to redistribute this app, confirm the
license of the specific copies of these two files yourself.

## Rest of the app

The rest of this app (the Bridge tab, RFC2217 implementation, TCP
server, etc.) is original work; see the doc comments on
`TcpServerManager`'s auto-reset methods for the one other small
GPL-adjacent borrowing (exact timing constants from avrdude's
`arduino_open()`, GPL-2.0-or-later) that predates this Programmer-tab
addition.

## python-i2c-tcp/ (companion PC-side client)

**`python-i2c-tcp/lib/smbus.py`** is original code: a from-scratch TCP
client, matching the *public method names and signatures* of the
classic ioctl-based `smbus.py` (Tony DiCola / Adafruit Industries,
MIT-licensed) so existing code written against that API keeps working -
matching a function signature isn't copying its expression, so this
doesn't carry that file's license forward. `app/.../I2cTcpServer.kt`,
the Android-side counterpart, is also original code (see above).

**`python-i2c-tcp/lib/smbus_ssd1306.py`** is different: it's the user-
provided SSD1306 driver file with its logic unchanged (only docstrings
were edited, to note the new transport). That file as provided didn't
carry its own license header; the sibling `smbus.py` it was distributed
with did (MIT, Tony DiCola / Adafruit Industries - see the header this
project's replacement `smbus.py` doesn't copy but was informed by). If
you plan to redistribute `smbus_ssd1306.py`, confirm its actual license
yourself rather than assuming MIT by association.
