# TCP UART Bridge

Turns an Android phone into a non-root USB-Serial ↔ TCP bridge. Plug a
CH340 / CP2102 / FTDI FT232 / PL2303 adapter (or an ESP32 board with native
USB CDC-ACM) into the phone's USB-C/OTG port, start the bridge, and connect
to `phone_ip:3333` from anywhere on the same network — including
`esptool.py` for wireless ESP32 flashing.

**Note on this delivery:** this is a complete, ready-to-build Android
Studio project (Gradle config, manifest, Kotlin sources, resources). It was
generated in an environment with no Android SDK and no network access, so
no `.apk` binary is included — you'll need to build it with the steps
below. The Gradle config is set up so the built file is literally named
`TCP_UART_Bridge.apk`.

**On the RFC2217 implementation specifically:** the Telnet/RFC2217
byte-stream framing (option negotiation, IAC escaping, subnegotiation
parsing) was written and unit-tested standalone against a battery of
cases — negotiation handshakes, embedded 0xFF bytes, and arbitrary chunk
splitting — before being ported into this Kotlin project, and the reset
logic mirrors Espressif's own `esp_rfc2217_server.py` line for line. The
same no-SDK/no-network environment means none of this has been through an
actual Android build or real hardware, so treat each change below as
logically reviewed, not hardware-verified.

**Changes in this round**, based on real testing feedback:
- **Header simplified; proper day/night theming added.** The top bar's hamburger, gear-shortcut,
  and overflow-dots icons were decorative (none had a destination beyond what the bottom nav
  already provides), so they're removed, along with the bar's blue fill - the title/subtitle now
  sit directly on the screen background with no colored bar at all. Also added real dark-theme
  support: the app already used a `DayNight` base theme, but every custom color was a single
  light-mode hex value, so system dark mode previously would have left card/text colors
  unreadable rather than actually adapting. `values-night/colors.xml` now supplies dark
  equivalents for every background/text/border/icon token used in the UI (see the comment block
  at the top of that file for the reasoning), and `values(-night)/bools.xml` flips the status bar
  between dark and light icons to match. This follows the system's dark mode setting
  automatically - there's no in-app light/dark toggle (yet; easy to add in Settings if wanted).
  The bottom nav's **Files** tab is also back to its original name, **Examples**.
- **Visual redesign to match a supplied mockup, with no change to bridging/reset/TCP
  behavior.** The UI moved from a top TabLayout (Bridge/Examples) + spinner-heavy single
  screen to a bottom-navigation shell with four screens - **Bridge** (Connection Status,
  Bridge Mode and Reset Options as tappable cards instead of dropdowns, TCP Server
  Settings, Start/Stop), **Log** (the same live log, now full-screen), **Examples** (the old
  Examples tab, same cards/Copy behavior, briefly relabeled "Files" and now reverted), and
  **Settings** (USB device selection, UART Settings, and Manual Reset Control - the RTS/DTR
  switches, Reset to Bootloader button, and its explanatory note, all moved off the Bridge screen
  to keep it focused on the controls you use every run). A few adaptations were necessary and are
  worth knowing about: the mockup's "Server Address" field is shown read-only (this app is
  the TCP *server*, not a client dialing out to one, so there's no remote address to type
  in - it now displays the phone's own bound IP once the bridge is running); its "Connect"
  button became **Refresh** (the app doesn't have a separate USB-connect step - refreshing
  the device list is the equivalent real action); and Protocol/Target Chip went from
  `Spinner`s to a set of tappable, manually-styled card views (`SelectableChip` in
  `MainActivity.kt`) so they could look like the mockup's segmented selectors while driving
  the exact same `currentProtocolMode`/`currentTargetChip` variables the rest of the app
  already relied on.
- **Fixed a real race: `-c stk500v1` failed sync (`Device signature = 00 00
  00`) while `-c arduino` worked, on the same board/wiring.** Root cause:
  the app fired its auto-reset pulse (for ESP32/AmebaD/AVR alike) in the
  background and immediately started relaying client data in parallel,
  rather than waiting for the pulse to finish first. This didn't show up
  before because every client tested so far (esptool, `upload_amebad.py`,
  and avrdude's `-c arduino`) happens to have its *own* built-in delay
  before it starts syncing - `-c arduino` still sleeps ~300ms around its
  DTR/RTS ioctl attempt even though that ioctl fails on a network port and
  does nothing, and that accidental delay was enough to mask the race.
  `-c stk500v1` has no such delay - it starts syncing the instant the
  socket connects - so it lost the race outright. Fixed by making the
  connect-time reset pulses `suspend` and actually awaiting them before
  any client data is relayed, for all of ESP32/AmebaD/AVR - not just a
  timing coincidence anymore. See `autoEsp32BootloaderReset`'s doc in
  `TcpServerManager.kt` for the full explanation.
- **Confirmed `-c stk500v1` is still the right avrdude flag** for both
  flashing an Arduino directly through its bootloader *and* using an
  Arduino running the standard `ArduinoISP.ino` sketch as a programmer for
  another chip - both speak the same STK500v1-over-serial protocol, and
  multiple independent sources confirm `-c stk500v1`/`-c avrisp` (not the
  `arduinoisp` id, which - when defined at all - is inconsistently bound
  to direct-USB `usbtiny` in some avrdude.conf variants, not serial, so
  it's not a safe recommendation here). Same Target Chip = **Arduino / AVR
  (auto reset)** setting works for both.
- **Looked at how a working Android AVR flasher (ZFlasher AVR) supports
  USBasp, at the user's request, and it doesn't fit this app's
  architecture.** It bundles a real, natively-compiled `avrdude` +
  `libusb` via the Android NDK (JNI), and hands `libusb` a raw USB file
  descriptor through Android's USB Host API - direct on-device USB
  programming, no network, no serial port, no separate PC/Termux client
  at all. That's a fundamentally different app (native C toolchain,
  cross-compiled binaries, direct hardware access) from this one (a
  Kotlin serial-over-TCP bridge for a separate client to connect to) -
  not something addressable with source-level changes to this project,
  and not something to fake without real NDK tooling to build and test it
  against actual hardware. See "USBasp is a different, incompatible kind
  of programmer" below for the detail on why, unchanged from last round.

**Earlier rounds**, kept for history:
- **Found and fixed the actual AmebaD "stuck after re-init, just dots"
  hang.** The dots weren't write progress - they're `wait_sync()`
  printing a tick while it waits for a sync byte that was never coming.
  Root cause: `upload_amebad.py` changes baud rate two different ways -
  explicitly via `[0x05, sub_cmd]` (which `AmebaBaudRateSniffer` already
  caught), and *implicitly* by unconditionally setting `ser.baudrate =
  115200` right after the `EXECUTE` (`0x04`) command succeeds, with no
  `[0x05,...]` sent for that transition at all (it happens twice - after
  uploading the flashloader, and again after writing the full image). The
  sniffer only knew about the explicit case, so after flashloader
  execution the physical UART stayed at the flashloader's high baud while
  the script (and the chip itself) dropped to 115200 - total desync, and
  `wait_sync()`'s retry loop (5000 attempts × up to 2000ms) can take
  **up to ~2.7 hours** before ever printing a timeout, which is exactly
  what "stuck, nothing else" looked like. Fixed by having the sniffer also
  recognize `EXECUTE` as an implicit "switch to 115200" signal. See
  `AmebaBaudRateSniffer.kt`'s class doc and `CMD_EXECUTE`.
- **Confirmed Raw (manual reset) is untouched** - no auto-reset, no
  automatic DTR/RTS, nothing added to it this round or ever. It stays a
  plain, generic byte pipe that works with any UART device, by design -
  all the chip-specific automation lives in Raw (auto-baud) only, gated
  per [`ServerMode.RAW_AUTOBAUD`], never plain [`ServerMode.RAW`].
- **Added Arduino/AVR support** (`avrdude`, programmer type `arduino` -
  Optiboot and similar STK500v1-skeleton bootloaders). New **Target
  Chip**: **Arduino / AVR (auto reset)**. Real-world testing (a
  bridged-avrdude GitHub issue, linked in the code comment) shows
  avrdude's own `-c arduino` reset attempt actually *fails* over a
  network port - `ioctl("TIOCMGET"): Inappropriate ioctl for device`,
  since a plain socket file descriptor doesn't support the modem-control
  ioctls that programmer type expects - so the chip never gets reset and
  sync fails. The fix: use `-c stk500v1` instead (skips that ioctl
  entirely) and let the app drive the identical DTR/RTS pulse instead,
  copied exactly from avrdude's own `arduino_open()` (clear DTR+RTS,
  250ms, set DTR+RTS, 50ms). Only runs on connect - no disconnect pulse is
  needed, since Optiboot-style bootloaders jump to the flashed app on
  their own after a short idle timeout. See "Target Chip: Arduino / AVR"
  below.
- **USBasp is a different, incompatible kind of programmer** - worth
  naming explicitly since it was asked about. It's not a serial device at
  all: avrdude talks to it directly over USB via libusb (raw USB
  vendor/HID transfers), with no serial port, baud rate, or DTR/RTS
  concept anywhere in the picture. There's no "port" for this app to
  bridge over a network in the first place, so it's architecturally out
  of scope here - not a missing feature, a different category of tool.
- **Added an Examples tab** - a second tab (the app is back to having
  tabs, `TabLayout` + `FrameLayout`, same pattern as before) with a card
  per example command (esptool over each of the three protocols,
  erase-region, erase-flash, reading back a partition, `parttool.py`,
  `upload_amebad.py`, `avrdude`, and a plain `nc` example for any other
  UART device), each with a short explanation and a **Copy** button that
  puts the exact command on the clipboard via `ClipboardManager`. See
  "Examples tab" below.

- **Brought back an automatic AmebaD/BW16 reset sequence** - an earlier
  round removed dedicated BW16 support in favor of the manual RTS/DTR
  switches alone (see "Removed BW16/AmebaD-specific support" below), but
  testing showed that flipping two switches by hand can't reliably
  reproduce the precise 500ms/200ms/500ms timing
  `upload_amebad.py`'s `enter_download_mode()` needs, so entering download
  mode was unreliable. This time it's wired properly instead of only being
  a manual button: with **Target Chip** set to **AmebaD / BW16 (auto
  reset)** and **Protocol** set to **Raw (auto-baud)**, the app now runs
  the exact same timed sequence automatically when a client connects, and
  a reset-to-normal-boot pulse when it disconnects - the AmebaD
  counterpart to what ESP32 already got. The manual button and switches
  are still there too (for RFC2217/plain-Raw, or as a fallback), running
  the identical timed sequence in code rather than relying on manual
  timing. See "Using upload_amebad.py with this app" below for the full
  workflow, and `TcpServerManager.kt`'s `autoAmebaDownloadModeReset`/
  `autoAmebaHardReset` for the implementation.
- **Fixed `upload_amebad.py` itself to actually support `socket://`.**
  It was opening the port with `serial.Serial(port=port, ...)`, which
  only ever understands real device paths (`/dev/ttyUSB0`, `COM3`) - not
  `socket://host:port` URLs, which need `serial.serial_for_url()`
  instead (a drop-in replacement; same keyword arguments, identical
  behavior for plain device paths, but also understands `socket://`,
  `rfc2217://`, etc.). Passing `socket://...` to the unpatched script
  would fail immediately with "could not open port ... No such file or
  directory". One-line fix in `flash_image()`; see the attached corrected
  script.
- Related: `find_max_speed()` doesn't actually *probe* anything over
  `socket://` - setting `.baudrate` on a plain TCP socket connection never
  raises (pyserial's socket handler silently accepts and ignores it), so
  without an explicit `--baudrate`, the script always "picks" the fastest
  entry in `SPEED_TABLE` (`1500000`) on the very first try, regardless of
  whether your actual USB-serial adapter can reliably run that fast. This
  matches what you saw - it's expected, not a bug - but if `1500000` turns
  out to be unstable on your adapter, pass `--baudrate` explicitly with a
  lower value to skip the "probe".

- **Raw (auto-baud) confirmed working** - `esptool --baud 1500000` over a
  plain `socket://` connection, no RFC2217, flashed successfully. Three
  follow-ups from that test, below.
- **Fixed: the UART was left at the last negotiated baud rate after a
  flash finished** (e.g. still at `1500000` for the *next* `esptool`
  invocation, instead of back at `115200`). It happened to still work in
  testing only because neither the chip nor the local port had been reset
  in between, so both sides coincidentally still agreed on the same
  non-standard speed - if the chip is power-cycled or a different `--baud`
  is used next time, that coincidence breaks and the next session's sync
  would fail. Fixed: the UART is now reset back to `115200` as soon as the
  client disconnects, so every new session starts from the same clean
  state a fresh ROM/stub/download-mode loader always expects, regardless
  of where the last session left the baud. See `close()` in
  `TcpServerManager.kt`.
- **Added automatic bootloader-entry / hard-reset pulses for Raw
  (auto-baud) + Target Chip = ESP32.** A plain socket has no control
  channel for esptool to request a reset itself - that's the "reset the
  chip manually" limitation esptool prints over `socket://` - so this
  closes that gap the same way baud tracking already did: the classic
  ESP32 bootloader-entry pulse now runs automatically the moment a client
  connects (no more needing to tap **Reset to Bootloader** or flip the
  switches by hand before every flash), and a plain hard-reset pulse
  (boots the newly-flashed app) runs automatically when it disconnects.
  Only applies with **Target Chip** set to **ESP32** specifically - there's
  no equivalent auto-sequence for **Generic**, same reasoning as always
  (see "Target Chip: Generic" below); use the manual switches there. See
  `autoBootloaderReset`/`autoHardReset` in `TcpServerManager.kt`.
- **Raw (auto-baud) now also recognizes `upload_amebad.py`'s own
  baud-change command**, not just esptool's, using the AmebaD flashing
  script you shared - so this mode works for BW16/AmebaD boards too, not
  just ESP32/ESP8266. It's a completely different, unframed byte protocol
  from esptool's SLIP-based one (see `AmebaBaudRateSniffer.kt`'s class doc
  for the reverse-engineered format and, importantly, for why a naive
  byte-pattern match would misfire on raw firmware data and how that's
  avoided). Both sniffers run in parallel and don't interfere with each
  other. This added *baud-rate* auto-detection for AmebaD; automatic
  reset-pulse support for it followed in the next round, below, once
  testing showed the manual switches alone weren't reliable enough for it
  (see "Brought back an automatic AmebaD/BW16 reset sequence" above).

- **Removed BW16/AmebaD-specific support.** The dedicated `upload_amebad.py`
  reset sequence and its "BW16 / AmebaD" dropdown entry are gone. **Target
  Chip** is now just **ESP32 (auto reset)** or **Generic (manual
  RTS/DTR)** - Generic relays whatever DTR/RTS the client sends straight
  through with no canned timing, and is the fallback path (alongside the
  manual RTS/DTR switches, which are unchanged) for any board whose reset
  behavior doesn't match ESP32's. If the automatic ESP32 sequence fails on
  your hardware, switch to Generic or just drive the switches by hand -
  see "Target Chip: Generic (manual RTS/DTR) fallback" below.
- **The RFC2217 baud-change stall fix from an earlier round didn't
  resolve it in testing.** The `PURGE_DATA` fix (a few bullets down) is
  still in place - it was a genuine bug regardless - but since it didn't
  fix the actual stall, **Raw (auto-baud)** (above) sidesteps that code
  path entirely rather than continuing to chase it blind. If you can
  share an esptool `--trace` log next time (`esptool --trace --port ...
  write-flash ... 2>&1 | tee trace.log`), that would show exactly which
  command is stalling and make the RFC2217 path fixable for real instead
  of by inference.
- **Added a "Raw (auto-baud)" protocol mode.** Behaves like plain Raw
  (byte passthrough, no control channel) but watches the wire for
  esptool's own `CHANGE_BAUDRATE` command - the same in-band mechanism
  esptool always uses to actually change speed on the chip - and retunes
  the local UART to match, live, mid-session. So `--baud` works over a
  plain `socket://` connection without needing RFC2217 (or its option
  negotiation / SET_CONTROL / SET_BAUDRATE round-trips) at all. Always
  opens at 115200 (matches the ESP ROM/stub loader's fixed initial-sync
  speed) - see "Raw (auto-baud)" below for details and caveats.
- **Added higher baud rates**, up to `5000000` (5 Mbps), to the Baud Rate
  dropdown - useful for adapters that support it (FT232H, some CP2102N/
  CH9102 boards) regardless of which protocol mode you're using.
- **Fixed a long stall (many seconds) right after an RFC2217 baud-rate
  change** - e.g. esptool's "Changing baud rate to 921600... Changed."
  followed by a long pause before flashing actually starts, on any chip.
  Root cause: `PURGE_DATA` (RFC2217 section 3.7) was implemented as a fake
  acknowledgement that didn't actually discard anything. esptool/pyserial
  call the equivalent of this (`reset_input_buffer()`) right around a
  baud-rate change to get a clean slate; with the old no-op, whatever was
  still sitting in this app's per-client outbound queue at that moment
  (the tail of a burst captured at the old baud, or a stray byte from the
  reset pulse) got delivered right as esptool expected a fresh response,
  which desynced its sync/retry state machine and forced it to burn
  through several retry timeouts before recovering on its own - that's
  the ~20 second stall. Fixed by actually draining the queued backlog on
  `PURGE_DATA`, and proactively on every baud-rate change and reset pulse
  even when the client doesn't explicitly ask. See `handlePurgeData` /
  `handleSetBaudrate` in `Rfc2217Session.kt` and `purgeOutboundQueue()` in
  `TcpServerManager.kt`. **As noted above, this didn't fix the stall in
  testing** - it's still correct/worth keeping, but treat the RFC2217 path
  as still having an open, not-yet-diagnosed issue; see **Raw (auto-baud)**
  for a working alternative in the meantime.
- **Fixed data corruption on high-baud reads** (`read-flash` at 921600
  returning truncated/corrupt data). Root cause: incoming UART bytes were
  broadcast to the TCP socket directly from the USB driver's read-callback
  thread, so any momentary stall in the (blocking) socket write backed up
  into the USB hardware FIFO and silently dropped bytes. Fixed by routing
  all outgoing socket writes through a per-client queue drained by a
  separate coroutine, so the USB read thread never blocks on network I/O.
  See `TcpServerManager.kt`.
- **Moved the Start/Stop button** off the system nav bar using proper
  window-insets handling (the app targets Android 15, where edge-to-edge
  is enforced, so a fixed margin alone isn't reliable across devices).
- **Re-verified the ESP32 manual "Reset to Bootloader" sequence** byte-for-
  byte against `esptool/reset.py`'s `ClassicReset` again — it already
  matches exactly (DTR before releasing RTS, 100ms/50ms delays). Added
  timestamped step-by-step logging to the app's log panel so a mismatch
  between intended and actual behavior is visible if it still doesn't work
  - if it's still just doing a normal reset with this build, that most
    likely means a wiring/adapter-chip polarity difference on your
    specific hardware rather than a sequence bug; the log will help narrow
    it down (see "Troubleshooting the ESP32 reset button" below).

## Project layout

```
TCP_UART_Bridge/
├── build.gradle, settings.gradle, gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
└── app/
    ├── build.gradle
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/tcpuartbridge/app/
        │   ├── MainActivity.kt        — UI (Bridge/Log/Examples/Settings bottom-nav panels), USB permission flow, service binding
        │   ├── BridgeService.kt       — foreground service, notification, RTS/DTR
        │   ├── UsbSerialManager.kt    — usb-serial-for-android wrapper
        │   ├── TcpServerManager.kt    — multi-client TCP server (raw + RFC2217 modes)
        │   ├── Rfc2217Protocol.kt     — Telnet/RFC2217 byte-stream codec
        │   ├── Rfc2217Session.kt      — per-client RFC2217 session + reset-sequence logic
        │   ├── EspBaudRateSniffer.kt  — in-band esptool baud-change detection for Raw (auto-baud)
        │   ├── AmebaBaudRateSniffer.kt — in-band upload_amebad.py baud-change detection, same mode
        │   └── BridgeStatus.kt        — shared status model
        └── res/                       — layout (activity_main.xml: BottomNavigationView +
                                          Bridge/Log/Examples/Settings panels; item_example.xml: one
                                          Examples-tab card), strings, colors, vector icons, USB
                                          device filter
```

## Build instructions

### Option A — Android Studio (recommended)
1. Install **Android Studio Ladybug (2024.2) or newer**, with JDK 17 and
   Android SDK Platform 35 installed via the SDK Manager.
2. `File → Open`, select the `TCP_UART_Bridge` folder.
3. Android Studio will detect there's no Gradle wrapper jar and offer to
   generate one — accept it (or it will regenerate automatically on sync).
4. Let Gradle sync. It needs internet access once, to pull dependencies
   from Google's Maven, Maven Central, and **JitPack** (for
   `com.github.mik3y:usb-serial-for-android`).
5. `Build → Build App Bundle(s) / APK(s) → Build APK(s)`.
6. Output: `app/build/outputs/apk/debug/TCP_UART_Bridge.apk`.

For a release build (`Build → Generate Signed Bundle / APK → APK`),
you'll need to create/select a signing keystore — Android Studio walks
you through this.

### Option B — Command line
```bash
cd TCP_UART_Bridge
gradle wrapper --gradle-version 8.7   # only needed once, to create gradlew
./gradlew assembleDebug
# → app/build/outputs/apk/debug/TCP_UART_Bridge.apk
```
Requires JDK 17 and `ANDROID_HOME`/`ANDROID_SDK_ROOT` pointing at an SDK
with Platform 35 and Build-Tools installed.

## Using it

The app has four destinations in the bottom navigation bar:

- **Bridge** - the actual USB-serial ↔ TCP bridge screen (connection
  status, Bridge Mode, Reset Options, TCP Server Settings, Start/Stop).
  This is the screen you use every time.
- **Log** - the full live log output.
- **Examples** - reference CLI commands with a Copy button on each (see
  "Examples tab" below).
- **Settings** - USB device selection, UART Settings (baud/data
  bits/stop bits/parity), and Manual Reset Control (RTS/DTR switches +
  Reset to Bootloader button) - the lower-level, set-once-and-forget
  controls that used to share the Bridge screen with everything else.

The Bridge tab works like this:

1. Plug in a USB-serial adapter (with a USB-OTG cable/adapter if your
   phone doesn't have USB-C host support built in).
2. Open the app, grant the USB permission popup, and it appears in the
   device dropdown with its detected chip type (Connection Status card
   on the Bridge tab; tap **Refresh** to rescan).
3. On the Bridge tab, pick a **Bridge Mode** (RFC2217 for automatic
   esptool resets, Raw for a plain byte pipe, or Raw (auto-baud) for a
   plain byte pipe that still follows `--baud` and, with the right Reset
   Option, auto-resets too - see "ESP32 flashing over the network"
   below) and a **Reset Option** (**ESP32** for esptool's timed reset
   sequence, **AmebaD / BW16** for `upload_amebad.py`'s, **Arduino /
   AVR** for avrdude's, or **Generic** for direct RTS/DTR passthrough,
   set manually from the Settings tab). If you need non-default baud
   rate / data bits / stop bits / parity, set those under **Settings**
   first - Bridge mode defaults to 115200 8N1.
4. Set the TCP port (default `3333`) and tap **Start Bridge**. The IP
   address to connect to is shown in the Server Address box and in the
   persistent notification.
5. In either Raw mode, connect from a PC with `nc phone_ip 3333`, PuTTY
   (raw socket), or any TCP client - everything you send goes out the
   UART TX pin, everything the UART RX pin receives comes back to you. In
   RFC2217 mode, point esptool (or any RFC2217-capable client) at
   `rfc2217://phone_ip:3333?ign_set_control` instead - see below.

The service is declared as a `connectedDevice` foreground service, so it
keeps running with the screen off, and Android won't kill it for being in
the background.

## ESP32 flashing over the network

Wire the adapter's control lines the same way a standard ESP32 dev board's
auto-program circuit does:
- **RTS → EN / RESET**
- **DTR → GPIO0 / BOOT**

The app now supports three TCP protocols, picked from the **Protocol**
dropdown before you tap **Start Bridge**:

### RFC2217 (automatic reset - has a known unresolved stall issue)

The app speaks RFC 2217 (Telnet COM-Port-Control), the same protocol
Espressif's own `esp_rfc2217_server.py` uses. esptool's DTR/RTS reset
commands travel over the TCP connection and this app drives real,
correctly-timed reset pulses on the actual USB adapter - no manual
button-pressing needed.

```bash
esptool --port "rfc2217://PHONE_IP:PORT?ign_set_control" --baud 460800 write-flash 0x1000 firmware.bin
```

The `?ign_set_control` suffix tells esptool's RFC2217 client not to wait
for/require an acknowledgement on every single control-line command -
this app does send one, but keeping this flag matches Espressif's own
server's documented usage and avoids any edge-case stalls.

Why not just relay every DTR/RTS command as it arrives? esptool's reset
sequences need millisecond-precision timing between DTR and RTS
transitions, and relaying each command individually over Wi-Fi adds
unpredictable jitter that breaks it. Instead - mirroring
`esp_rfc2217_server.py`'s own approach - the app detects the *start* of a
reset sequence and then runs a precisely-timed sequence locally, ignoring
the redundant follow-up commands the client sends as part of the same
sequence. See the comment at the top of `Rfc2217Session.kt` for details.

**Known issue:** a long stall (~20s) right after the baud-rate change, in
testing, that a previous fix attempt (`PURGE_DATA`, still in the code -
see the changelog) didn't resolve. If you hit this, either try **Raw
(auto-baud)** below (works around it entirely, and - with Target Chip set
to ESP32 or AmebaD/BW16 - now auto-resets too), or - if you want RFC2217
specifically and are up for helping pin this down - capture `esptool
--trace ... 2>&1 | tee trace.log` next time and share it; that log shows
exactly which command/response is stalling, which is enough to fix it for
real.

### Raw (auto-baud)

Plain byte passthrough like Raw below, but this app watches the wire for
esptool's or `upload_amebad.py`'s own in-band baud-change command - the
same mechanism each of them always uses to actually change the chip's
speed, regardless of transport - and retunes the local UART to match,
live, mid-session. So `--baud` works over a plain socket without
RFC2217's option negotiation/SET_CONTROL/SET_BAUDRATE round-trips (and
without hitting the stall above).

```bash
esptool --port socket://PHONE_IP:PORT --baud 921600 write-flash 0x1000 firmware.bin
```

Always opens the port at 115200 - that's what the ESP ROM/stub loader
itself always expects for the initial SYNC handshake, matching what
esptool does on its end regardless of your `--baud` value (it syncs at
115200 first, then requests the higher speed in-band); `upload_amebad.py`
does the same. The **Baud Rate** spinner is ignored in this mode for that
reason; data bits/stop bits/parity from it still apply. The UART is reset
back to 115200 again as soon as the client disconnects, so the next
session - whatever baud it ends up wanting - starts from the same clean
115200 state, matching a fresh boot. See `EspBaudRateSniffer.kt` (esptool)
and `AmebaBaudRateSniffer.kt` (`upload_amebad.py`) for exactly how each is
detected, and the caveats there.

**With Target Chip set to ESP32, AmebaD/BW16, or Arduino/AVR**, this mode
also drives that chip's reset pulse(s) automatically, closing the same
"no control channel" gap for resets that it already closes for baud rate:
the chip-specific bootloader/download-mode-entry sequence runs the moment
a client connects (so you don't need to press **Reset to Bootloader** or
flip the switches before every flash), and - for ESP32/AmebaD, which have
a bootloader you need to explicitly leave - a plain reset-to-normal-boot
pulse also runs the moment it disconnects (AVR's Optiboot-style
bootloader doesn't need this: it times out and jumps to the app on its
own). You can flash repeatedly - run the tool, let it finish, run it
again - without touching the phone in between:

```bash
esptool --port socket://PHONE_IP:PORT --baud 921600 write-flash 0x1000 firmware.bin
esptool --port socket://PHONE_IP:PORT --baud 921600 write-flash 0x1000 firmware.bin  # no manual reset needed in between
```

This reset automation only exists for chips this app actually knows the
reset convention for - **ESP32**, **AmebaD/BW16**, and **Arduino/AVR** -
it doesn't apply with **Target Chip** set to **Generic**, which is the
fallback for any *other* board, since this app intentionally doesn't
guess at reset conventions it hasn't been taught (see "Target Chip:
Generic" below). Baud-rate auto-detection for esptool and
`upload_amebad.py`, above, works regardless of which Target Chip is
selected, since it's unrelated to which reset convention is in play (AVR
doesn't renegotiate baud mid-session, so there's nothing for either
sniffer to detect there either way).

### Raw (manual reset)

Plain byte passthrough - works with any TCP client (`nc`, PuTTY raw
socket), but a plain socket has no channel for control lines *or* baud
rate at all, so esptool can't reset the chip remotely over it, and the
UART stays at whatever you picked in **UART Settings** for the whole
session (see "Raw mode always flashes at your configured UART baud"
below). Use **Raw (auto-baud)** above instead if you want `--baud` to
actually take effect without switching to RFC2217.

```bash
esptool --port socket://PHONE_IP:PORT --baud 460800 --before no-reset --after no-reset write-flash 0x1000 firmware.bin
```

Use the **Reset to Bootloader** button (or the RTS/DTR switches) in the
app to put the board in bootloader mode before flashing in this mode.

### Troubleshooting the ESP32 reset button

The manual sequence (DTR low → RTS high → wait → DTR high + RTS low →
wait → DTR low) matches `esptool/reset.py`'s `ClassicReset` exactly - this
was re-checked byte-for-byte against your esptool source. Tapping the
button now logs each step with a timestamp, e.g.:
```
[+0ms] ESP32 reset: DTR=0 (IO0=HIGH), RTS=1 (EN=LOW, reset)
[+101ms] DTR=1 (IO0=LOW), RTS=0 (EN=HIGH, exits reset -> should sample IO0 LOW -> bootloader)
[+151ms] DTR=0 (IO0=HIGH, done)
```
If the board still just does a normal reset (boots the running app)
instead of entering the bootloader with this exact sequence, the most
likely explanations are hardware-side, not app logic:
- **Wiring**: confirm RTS→EN and DTR→GPIO0 specifically (not swapped).
- **Adapter chip driver quirk**: `usb-serial-for-android`'s DTR/RTS
  handling has historically had chip-specific quirks (particularly some
  CH340/CH341 clones). Worth testing: does the *same* adapter/board work
  with real esptool + a PC over an actual serial cable? If yes there but
  not through this app, it narrows the problem to the Android USB driver
  for that specific chip.
- If you can share which adapter chip you're using (CH340/CP210x/FTDI/
  PL2303) and whether the PC+cable path works, that'll help pin down
  whether this needs a driver-level workaround.

## Target Chip: AmebaD / BW16 (auto reset)

Select **AmebaD / BW16 (auto reset)** in the **Target Chip** dropdown for
BW16/RTL8720DN boards flashed with `upload_amebad.py`. The sequence
(reverse-engineered exactly from that script's `enter_download_mode()` /
`reset_to_boot()` / `set_dtr_rts()`) is different from ESP32's - a 3-step
RTS/DTR dance with 500ms/200ms/500ms delays, not ESP32's 2-step
100ms/50ms one - so it needs its own dedicated timing, same reasoning as
ESP32 gets its own:

- In **Raw (auto-baud)** mode specifically, this runs automatically: the
  download-mode-entry pulse fires the moment a client connects, and a
  reset-to-normal-boot pulse fires the moment it disconnects - see "Using
  upload_amebad.py with this app" below for the full workflow.
- In any mode, the **Reset to Bootloader** button runs the same timed
  sequence manually, with step-by-step timestamped logging like ESP32's
  button has.
- The **RTS**/**DTR** switches are still there too as a raw manual
  fallback, but flipping them by hand is very unlikely to hit the
  500ms/200ms/500ms timing precisely - prefer the button (or Raw
  auto-baud's automatic version) over the switches for this chip.

This was reintroduced after being removed in an earlier round in favor of
the switches alone (see "Removed BW16/AmebaD-specific support" in the
changelog) - testing showed the switches alone aren't reliable enough for
timing this precise.

## Using upload_amebad.py with this app

`upload_amebad.py` as originally written can't connect to `socket://` at
all - it opens the port with `serial.Serial()`, which only understands
real device paths, not URL schemes (that needs `serial.serial_for_url()`
instead). A corrected version with that one-line fix is included
alongside this app; the workflow below assumes you're using it.

1. In the app: **Protocol** = **Raw (auto-baud)**, **Target Chip** =
   **AmebaD / BW16 (auto reset)**, then **Start Bridge**.
2. Run the script **without** `--auto`:
   ```bash
   python upload_amebad.py path/to/RTL8720dn-firmware_x.y.z socket://PHONE_IP:PORT
   ```
   Don't add `--auto` - the script's own DTR/RTS toggle attempts (what
   `--auto` enables) are silent no-ops over a plain socket connection
   (pyserial's `socket://` handler has no control-line channel at all, so
   there's nothing for those calls to actually reach), so it wouldn't do
   anything even if you passed it. Leaving it off makes the script print a
   5-second "Please enter the upload mode" countdown instead - harmless
   dead time, since by the time that starts, the app has already run its
   own automatic download-mode-entry pulse (it fires the instant the
   socket connects, well under the 5 seconds) and the board is already
   waiting in download mode.
3. Baud rate: leave `--baudrate` off to let the script's own
   `find_max_speed()` pick one, or pass it explicitly for a specific
   speed - either way, the app's `AmebaBaudRateSniffer` detects whichever
   speed the script actually requests and retunes the UART to match, live.
   Note `find_max_speed()` doesn't really *probe* anything over
   `socket://` (see the changelog) - it just always picks the fastest
   table entry, `1500000` - so if that turns out unstable on your specific
   adapter, pass `--baudrate` explicitly with something lower.
4. When it's done, disconnect (the script closes the connection on its
   own at the end) and the app resets the UART back to 115200 baud and
   runs the reset-to-normal-boot pulse automatically - ready for the next
   `upload_amebad.py` run with no manual steps in between.

## Target Chip: Arduino / AVR (auto reset)

Select **Arduino / AVR (auto reset)** in the **Target Chip** dropdown for
AVR chips (ATmega328P/Uno, ATmega32U4/Leonardo, etc.) flashed with
`avrdude`'s `arduino` programmer type (Optiboot or any other STK500v1-
skeleton bootloader). The sequence is the classic "DTR through a
capacitor to RESET" auto-reset, timing copied exactly from avrdude's own
`arduino_open()` in `arduino.c` - clear DTR+RTS, wait 250ms, set DTR+RTS,
wait 50ms:

- In **Raw (auto-baud)** mode specifically, this runs automatically the
  moment a client connects - see "Using avrdude with this app" below for
  the full workflow (including why you need `-c stk500v1`, not `-c
  arduino`, on the avrdude side).
- No pulse is needed on disconnect: Optiboot-style bootloaders jump to
  the flashed application on their own after a short idle timeout with no
  further bootloader traffic.
- In any mode, the **Reset to Bootloader** button runs the same timed
  sequence manually, with step-by-step timestamped logging like ESP32's
  and AmebaD's buttons have. The **RTS**/**DTR** switches are also still
  there as a raw manual fallback.

## Using avrdude with this app

`avrdude -c arduino -P net:...` (the obvious thing to try) doesn't work:
that programmer type tries to toggle DTR/RTS itself on open, and a plain
network socket file descriptor doesn't support the modem-control ioctl
it uses for that - real-world testing of exactly this setup shows it
failing with `ioctl("TIOCMGET"): Inappropriate ioctl for device"`, after
which sync fails since the chip was never actually reset. The fix:

1. In the app: **Protocol** = **Raw (auto-baud)**, **Target Chip** =
   **Arduino / AVR (auto reset)**, then **Start Bridge**.
2. Use `-c stk500v1` instead of `-c arduino` - the raw STK500v1 protocol,
   without the DTR/RTS wrapper `arduino` adds, so avrdude never attempts
   that ioctl in the first place:
   ```bash
   avrdude -p atmega328p -c stk500v1 -P net:PHONE_IP:PORT -b 115200 -U flash:w:sketch.hex:i
   ```
   The app resets the chip into the bootloader automatically the instant
   the connection opens, well before avrdude gets far enough to need it.
3. Match `-b` to whatever baud your bootloader actually runs at (`115200`
   for stock Optiboot on most boards) - AVR/STK500v1 doesn't renegotiate
   baud mid-session the way esptool/`upload_amebad.py` do, so there's
   nothing for a baud sniffer to watch for here; the app just opens the
   port at 115200 (Raw (auto-baud)'s normal starting point) and leaves it
   there for the whole session.

**USBasp is a different, incompatible kind of programmer**, worth calling
out explicitly: it's not a serial device at all - avrdude talks to it
directly over USB via `libusb` (raw USB vendor/HID transfers), with no
serial port, baud rate, or DTR/RTS concept anywhere in the picture. There
is no "port" for this app - which is fundamentally a serial-over-TCP
bridge - to relay over a network for that kind of programmer. Not a
missing feature here, just a different category of tool than what this
app does.

## Target Chip: Generic (manual RTS/DTR) fallback

Boards that don't follow ESP32's, AmebaD's, or AVR's reset conventions
(different timing, different EN/BOOT polarity, or an entirely different
reset protocol) aren't given a dedicated auto-reset sequence by this app -
there's no board-specific logic to keep in sync as your hardware lineup
changes. Instead, select **Generic (manual RTS/DTR)** in the **Target
Chip** dropdown:

- In **RFC2217** mode, every DTR/RTS SET-CONTROL command from the client
  is relayed straight through to the hardware immediately, in the order
  it arrives, with no ESP32-style sequence detection/substitution. If your
  board's own flashing tool drives DTR/RTS with its own timing (the way
  `esptool` does for ESP32), that timing is preserved as-is. See the
  `TargetChip.GENERIC` comment in `Rfc2217Session.kt`.
- In **Raw** mode, or for a one-off manual reset in any mode, use the
  **RTS**/**DTR** switches (or the "Reset to Bootloader" button, which
  just logs a note in Generic mode - there's no canned sequence to run)
  to drive the lines by hand according to your board's own reset
  convention.

This is also the fallback if the **ESP32**, **AmebaD/BW16**, or
**Arduino/AVR** auto-reset sequences don't work on a given board or
adapter: switch to Generic, or just use the RTS/DTR switches directly,
without needing to restart the bridge.

## Raw mode always flashes at your configured UART baud

This applies to plain **Raw (manual reset)** specifically - see **Raw
(auto-baud)** above if you want `--baud` to actually work without RFC2217.

A plain TCP socket (`socket://`) has no control channel at all - not just
for DTR/RTS (see above), but for baud rate too. `esptool` can't ask a raw
socket to change speed mid-session the way it does over RFC2217, so in
plain Raw mode the UART stays at whatever baud you picked in **UART
Settings** before hitting **Start Bridge** for the entire session - that's
the "connects fast but uploads at 115200" behavior. To flash at a higher
speed over plain Raw, set the **Baud Rate** spinner itself to the speed
you want (e.g. `921600`) before starting the bridge, and pass a matching
`--baud` to esptool - or use **Raw (auto-baud)** or **RFC2217** instead,
where the speed change happens automatically.

## Examples tab

The **Examples** tab in the bottom nav - a scrollable reference list of the
CLI commands from this README (one card per tool/mode combination:
esptool over each of the three protocols, `erase-region`, `erase-flash`,
reading back a partition, ESP-IDF's `parttool.py`, `upload_amebad.py`,
`avrdude`, and a plain `nc` example for any other UART device), each with
a short explanation of what it does and which app settings it assumes,
and a **Copy** button that puts the exact command on the clipboard via
`ClipboardManager` - paste it into your terminal and swap in your phone's
actual IP and port. Purely a reference; it doesn't read anything from the
Bridge tab's current state (so it won't auto-fill your actual IP/port -
those still show up as the `PHONE_IP:PORT` placeholder used throughout
this README). The list lives as a plain Kotlin list in `MainActivity.kt`
(`cliExamples`) if you want to add your own.

## Permissions requested

| Permission | Why |
|---|---|
| USB host feature | Talk to the serial adapter over USB |
| `INTERNET` | Run the TCP server |
| `ACCESS_NETWORK_STATE` / `ACCESS_WIFI_STATE` | Show the phone's IP address |
| `FOREGROUND_SERVICE` / `FOREGROUND_SERVICE_CONNECTED_DEVICE` | Keep bridging with the screen off |
| `POST_NOTIFICATIONS` | Show the status notification (Android 13+) |

## Supported chips

CH340/CH341, CP2102/CP210x, FTDI FT232, PL2303, and CDC-ACM (including
ESP32-S2/S3/C3 native USB). `app/src/main/res/xml/device_filter.xml` lists
the known VID/PID pairs used for auto-launch-on-attach; add more there if
you have a specific adapter that isn't recognized automatically — the
underlying `usb-serial-for-android` prober will still find any of the five
supported chip families even if they're not listed there, that file only
controls whether Android auto-opens the app when the device is plugged in.

Target range: Android 8.0 (API 26) through current Android releases.
