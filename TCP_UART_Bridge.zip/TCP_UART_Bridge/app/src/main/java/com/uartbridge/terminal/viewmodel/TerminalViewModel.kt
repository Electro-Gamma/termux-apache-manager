package com.uartbridge.terminal.viewmodel

import android.app.Application
import androidx.compose.ui.input.key.KeyEvent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.hoho.android.usbserial.driver.UsbSerialDriver
import com.uartbridge.terminal.serial.SerialSettings
import com.uartbridge.terminal.terminal.KeyEncoder
import com.uartbridge.terminal.terminal.TerminalEmulator
import com.uartbridge.terminal.usb.SerialPortController
import com.uartbridge.terminal.usb.UsbEvent
import com.uartbridge.terminal.usb.UsbSerialManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

sealed class ConnectionState {
    data object Disconnected : ConnectionState()
    data object Connecting : ConnectionState()
    data object Connected : ConnectionState()
    data class ConnectionError(val message: String) : ConnectionState()
    data object DeviceDisconnected : ConnectionState()
}

data class DeviceInfo(val driver: UsbSerialDriver, val name: String) {
    val deviceId: Int get() = driver.device.deviceId
}

class TerminalViewModel(application: Application) : AndroidViewModel(application) {

    private val usbManager = UsbSerialManager(application)
    private val portController = SerialPortController()

    /** The parser + screen buffer. Read directly by the terminal canvas; [terminalRevision] signals when to redraw. */
    val emulator = TerminalEmulator(rows = 24, cols = 80)

    private val _connectionState = MutableStateFlow<ConnectionState>(ConnectionState.Disconnected)
    val connectionState: StateFlow<ConnectionState> = _connectionState

    private val _devices = MutableStateFlow<List<DeviceInfo>>(emptyList())
    val devices: StateFlow<List<DeviceInfo>> = _devices

    private val _selectedDeviceId = MutableStateFlow<Int?>(null)
    val selectedDeviceId: StateFlow<Int?> = _selectedDeviceId

    private val _settings = MutableStateFlow(SerialSettings.BANANA_PI_DEFAULT)
    val settings: StateFlow<SerialSettings> = _settings

    private val _terminalRevision = MutableStateFlow(0)
    val terminalRevision: StateFlow<Int> = _terminalRevision

    private val _toastEvents = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val toastEvents: SharedFlow<String> = _toastEvents

    private val _ctrlLocked = MutableStateFlow(false)
    val ctrlLocked: StateFlow<Boolean> = _ctrlLocked

    private val _altLocked = MutableStateFlow(false)
    val altLocked: StateFlow<Boolean> = _altLocked

    val usbHostSupported: Boolean get() = usbManager.isUsbHostSupported()

    init {
        emulator.onResponse = { bytes -> portController.write(bytes) }
        portController.onDataReceived = { bytes -> onSerialData(bytes) }
        portController.onError = { e -> onSerialError(e) }
        viewModelScope.launch { usbManager.events.collect { handleUsbEvent(it) } }
    }

    fun start() {
        usbManager.register()
        refreshDevices()
    }

    fun stop() {
        usbManager.unregister()
    }

    fun refreshDevices() {
        val found = usbManager.listDrivers().map { DeviceInfo(it, usbManager.displayName(it.device)) }
        _devices.value = found
        if (found.none { it.deviceId == _selectedDeviceId.value }) {
            _selectedDeviceId.value = found.firstOrNull()?.deviceId
        }
    }

    fun selectDevice(deviceId: Int) {
        _selectedDeviceId.value = deviceId
    }

    fun updateSettings(newSettings: SerialSettings) {
        _settings.value = newSettings
        if (portController.isOpen) portController.updateSettings(newSettings)
    }

    fun connect() {
        val target = _devices.value.firstOrNull { it.deviceId == _selectedDeviceId.value }
            ?: _devices.value.firstOrNull()
        val driver = target?.driver
        if (driver == null) {
            _connectionState.value = ConnectionState.ConnectionError("No USB serial adapter found")
            return
        }
        if (!usbManager.hasPermission(driver.device)) {
            _connectionState.value = ConnectionState.Connecting
            usbManager.requestPermission(driver.device)
            return // openDevice() runs once the PermissionResult event arrives
        }
        openDevice(driver)
    }

    fun disconnect() {
        portController.close()
        _connectionState.value = ConnectionState.Disconnected
    }

    private fun openDevice(driver: UsbSerialDriver) {
        _connectionState.value = ConnectionState.Connecting
        val connection = usbManager.openConnection(driver.device)
        if (connection == null) {
            _connectionState.value = ConnectionState.ConnectionError("Couldn't open a USB connection to this device")
            return
        }
        try {
            portController.open(driver, connection, _settings.value)
            emulator.buffer.cursorRow = 0
            emulator.buffer.cursorCol = 0
            _terminalRevision.value++
            _connectionState.value = ConnectionState.Connected
        } catch (e: Exception) {
            _connectionState.value = ConnectionState.ConnectionError(e.message ?: "Failed to open the serial port")
        }
    }

    private fun handleUsbEvent(event: UsbEvent) {
        when (event) {
            is UsbEvent.Attached -> refreshDevices()
            is UsbEvent.Detached -> {
                val wasOpen = portController.isOpen
                refreshDevices()
                if (wasOpen) {
                    portController.close()
                    _connectionState.value = ConnectionState.DeviceDisconnected
                }
            }
            is UsbEvent.PermissionResult -> {
                if (event.granted) {
                    val driver = usbManager.listDrivers().firstOrNull { it.device.deviceId == event.device.deviceId }
                    if (driver != null) {
                        openDevice(driver)
                    } else {
                        _connectionState.value = ConnectionState.ConnectionError("Device is no longer available")
                    }
                } else {
                    _connectionState.value = ConnectionState.ConnectionError("USB permission was denied")
                }
            }
        }
    }

    /** Called back from the serial read thread; hop to Main so buffer writes and Compose reads never race. */
    private fun onSerialData(bytes: ByteArray) {
        viewModelScope.launch(Dispatchers.Main.immediate) {
            emulator.feed(bytes)
            _terminalRevision.value++
        }
    }

    private fun onSerialError(e: Exception) {
        viewModelScope.launch(Dispatchers.Main.immediate) {
            portController.close()
            _connectionState.value = ConnectionState.ConnectionError(e.message ?: "Serial connection error")
        }
    }

    // ---- input from the UI --------------------------------------------

    /** Typed text from the on-screen keyboard's text field; applies any pending CTRL/ALT lock to the first character. */
    fun sendText(text: String) {
        if (text.isEmpty()) return
        var remaining = text
        if (_ctrlLocked.value) {
            val first = remaining.first()
            val code = KeyEncoder.ctrlByte(first)
            _ctrlLocked.value = false
            if (code >= 0) {
                portController.write(byteArrayOf(code.toByte()))
                remaining = remaining.drop(1)
                if (remaining.isEmpty()) return
            }
        }
        var payload = remaining.toByteArray(Charsets.UTF_8)
        if (_altLocked.value) {
            payload = byteArrayOf(0x1B) + payload
            _altLocked.value = false
        }
        portController.write(payload)
    }

    /** Hardware or IME key event; returns true if it was a "special" key this consumed. */
    fun sendKeyEvent(event: KeyEvent): Boolean {
        val bytes = KeyEncoder.bytesForKeyEvent(event, emulator.appCursorKeys, _ctrlLocked.value) ?: return false
        portController.write(bytes)
        if (_ctrlLocked.value) _ctrlLocked.value = false
        return true
    }

    fun sendEscape() = portController.write(KeyEncoder.escape())
    fun sendTab() = portController.write(KeyEncoder.tab())
    fun sendEnter() = portController.write(KeyEncoder.enter())
    fun sendBackspace() = portController.write(KeyEncoder.backspace())
    fun sendArrowUp() = portController.write(KeyEncoder.arrowUp(emulator.appCursorKeys))
    fun sendArrowDown() = portController.write(KeyEncoder.arrowDown(emulator.appCursorKeys))
    fun sendArrowLeft() = portController.write(KeyEncoder.arrowLeft(emulator.appCursorKeys))
    fun sendArrowRight() = portController.write(KeyEncoder.arrowRight(emulator.appCursorKeys))
    fun sendHome() = portController.write(KeyEncoder.home())
    fun sendEnd() = portController.write(KeyEncoder.end())
    fun sendPageUp() = portController.write(KeyEncoder.pageUp())
    fun sendPageDown() = portController.write(KeyEncoder.pageDown())

    fun toggleCtrlLock() { _ctrlLocked.value = !_ctrlLocked.value }
    fun toggleAltLock() { _altLocked.value = !_altLocked.value }

    fun pasteText(text: String) {
        if (text.isEmpty()) return
        val payload = if (emulator.bracketedPaste) "\u001b[200~$text\u001b[201~" else text
        portController.write(payload.toByteArray(Charsets.UTF_8))
    }

    override fun onCleared() {
        portController.close()
        usbManager.unregister()
        super.onCleared()
    }
}
