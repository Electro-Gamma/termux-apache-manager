package com.uartbridge.terminal.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.LinkOff
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.uartbridge.terminal.viewmodel.ConnectionState
import com.uartbridge.terminal.viewmodel.TerminalViewModel

@Composable
fun ConnectionBar(
    viewModel: TerminalViewModel,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val connectionState by viewModel.connectionState.collectAsState()
    val devices by viewModel.devices.collectAsState()
    val selectedId by viewModel.selectedDeviceId.collectAsState()
    var deviceMenuExpanded by remember { mutableStateOf(false) }

    // While connected the full header (status, device picker, Connect/Disconnect)
    // is hidden: only the settings icon remains, and Disconnect lives in the
    // settings dialog.
    if (connectionState is ConnectionState.Connected) {
        Surface(tonalElevation = 2.dp, modifier = modifier.fillMaxWidth()) {
            Row(
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth().padding(end = 4.dp),
            ) {
                IconButton(onClick = onOpenSettings) {
                    Icon(Icons.Filled.Settings, contentDescription = "Serial port settings")
                }
            }
        }
        return
    }

    Surface(tonalElevation = 2.dp, modifier = modifier.fillMaxWidth()) {
        Column {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp, top = 8.dp),
            ) {
                StatusIndicator(connectionState, Modifier.weight(1f))
                IconButton(onClick = onOpenSettings) {
                    Icon(Icons.Filled.Settings, contentDescription = "Serial port settings")
                }
            }
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            ) {
                Box(modifier = Modifier.weight(1f)) {
                    OutlinedButton(
                        onClick = { viewModel.refreshDevices(); deviceMenuExpanded = true },
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        val selectedName = devices.firstOrNull { it.deviceId == selectedId }?.name
                            ?: if (devices.isEmpty()) "No USB serial device found" else devices.first().name
                        Text(
                            text = selectedName,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f),
                        )
                        Icon(Icons.Filled.ArrowDropDown, contentDescription = null)
                    }
                    DropdownMenu(expanded = deviceMenuExpanded, onDismissRequest = { deviceMenuExpanded = false }) {
                        if (devices.isEmpty()) {
                            DropdownMenuItem(text = { Text("Plug in a USB-to-UART adapter") }, onClick = { }, enabled = false)
                        }
                        devices.forEach { device ->
                            DropdownMenuItem(
                                text = { Text(device.name) },
                                onClick = {
                                    viewModel.selectDevice(device.deviceId)
                                    deviceMenuExpanded = false
                                },
                            )
                        }
                    }
                }
                Spacer(Modifier.width(12.dp))
                val busyOrConnected = connectionState is ConnectionState.Connected || connectionState is ConnectionState.Connecting
                Button(
                    onClick = { if (busyOrConnected) viewModel.disconnect() else viewModel.connect() },
                    enabled = connectionState !is ConnectionState.Connecting,
                ) {
                    Text(if (busyOrConnected) "Disconnect" else "Connect")
                }
            }
        }
    }
}

@Composable
private fun StatusIndicator(state: ConnectionState, modifier: Modifier = Modifier) {
    val icon: androidx.compose.ui.graphics.vector.ImageVector
    val label: String
    val tint: Color
    when (state) {
        is ConnectionState.Disconnected -> {
            icon = Icons.Filled.LinkOff; label = "Disconnected"; tint = MaterialTheme.colorScheme.onSurfaceVariant
        }
        is ConnectionState.Connecting -> {
            icon = Icons.Filled.Sync; label = "Connecting…"; tint = MaterialTheme.colorScheme.tertiary
        }
        is ConnectionState.Connected -> {
            icon = Icons.Filled.Link; label = "Connected"; tint = MaterialTheme.colorScheme.primary
        }
        is ConnectionState.ConnectionError -> {
            icon = Icons.Filled.ErrorOutline; label = state.message; tint = MaterialTheme.colorScheme.error
        }
        is ConnectionState.DeviceDisconnected -> {
            icon = Icons.Filled.LinkOff; label = "USB device disconnected"; tint = MaterialTheme.colorScheme.error
        }
    }
    Row(verticalAlignment = Alignment.CenterVertically, modifier = modifier) {
        Icon(icon, contentDescription = null, tint = tint)
        Spacer(Modifier.width(8.dp))
        Text(label, style = MaterialTheme.typography.labelLarge, color = tint, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}
