package com.uartbridge.terminal.ui.theme

import androidx.compose.ui.graphics.Color

// A cool green/teal "terminal" brand, used when Material You dynamic color
// isn't available (pre-Android 12, or the user has it disabled).
val BrandPrimaryLight = Color(0xFF1B6E4F)
val BrandOnPrimaryLight = Color(0xFFFFFFFF)
val BrandPrimaryContainerLight = Color(0xFFA6F2CB)
val BrandSecondaryLight = Color(0xFF4C6358)
val BrandBackgroundLight = Color(0xFFFBFDF9)
val BrandSurfaceLight = Color(0xFFFBFDF9)
val BrandErrorLight = Color(0xFFBA1A1A)

val BrandPrimaryDark = Color(0xFF8BD5AC)
val BrandOnPrimaryDark = Color(0xFF00391F)
val BrandPrimaryContainerDark = Color(0xFF00522F)
val BrandSecondaryDark = Color(0xFFB3CCBF)
// True black background/surface for OLED panels.
val BrandBackgroundDark = Color(0xFF000000)
val BrandSurfaceDark = Color(0xFF000000)
val BrandErrorDark = Color(0xFFFFB4AB)
