package com.uartbridge.terminal.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.AssistChip
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.unit.dp
import com.uartbridge.terminal.viewmodel.TerminalViewModel

@Composable
fun KeyToolbar(viewModel: TerminalViewModel, modifier: Modifier = Modifier) {
    val ctrlLocked by viewModel.ctrlLocked.collectAsState()
    val altLocked by viewModel.altLocked.collectAsState()
    val clipboardManager = LocalClipboardManager.current

    Surface(tonalElevation = 1.dp, modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            ToolbarIconButton(Icons.Filled.ContentPaste, "Paste") {
                val clip = clipboardManager.getText()?.text
                if (!clip.isNullOrEmpty()) viewModel.pasteText(clip)
            }
            ToolbarChip("ESC") { viewModel.sendEscape() }
            ToolbarChip("TAB") { viewModel.sendTab() }
            ToolbarToggleChip("CTRL", ctrlLocked) { viewModel.toggleCtrlLock() }
            ToolbarToggleChip("ALT", altLocked) { viewModel.toggleAltLock() }
            ToolbarIconButton(Icons.Filled.KeyboardArrowUp, "Cursor up") { viewModel.sendArrowUp() }
            ToolbarIconButton(Icons.Filled.KeyboardArrowDown, "Cursor down") { viewModel.sendArrowDown() }
            ToolbarIconButton(Icons.Filled.KeyboardArrowLeft, "Cursor left") { viewModel.sendArrowLeft() }
            ToolbarIconButton(Icons.Filled.KeyboardArrowRight, "Cursor right") { viewModel.sendArrowRight() }
            ToolbarChip("HOME") { viewModel.sendHome() }
            ToolbarChip("END") { viewModel.sendEnd() }
            ToolbarChip("PGUP") { viewModel.sendPageUp() }
            ToolbarChip("PGDN") { viewModel.sendPageDown() }
        }
    }
}

@Composable
private fun ToolbarChip(label: String, onClick: () -> Unit) {
    AssistChip(onClick = onClick, label = { Text(label, style = MaterialTheme.typography.labelLarge) })
}

@Composable
private fun ToolbarToggleChip(label: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(selected = selected, onClick = onClick, label = { Text(label, style = MaterialTheme.typography.labelLarge) })
}

@Composable
private fun ToolbarIconButton(icon: ImageVector, description: String, onClick: () -> Unit) {
    FilledTonalIconButton(onClick = onClick, modifier = Modifier.size(36.dp)) {
        Icon(icon, contentDescription = description)
    }
}
