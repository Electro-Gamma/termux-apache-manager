package com.uartbridge.terminal.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.uartbridge.terminal.serial.DataBits
import com.uartbridge.terminal.serial.FlowControl
import com.uartbridge.terminal.serial.Parity
import com.uartbridge.terminal.serial.SerialSettings
import com.uartbridge.terminal.serial.StopBits

@Composable
fun SerialSettingsDialog(
    currentSettings: SerialSettings,
    onDismiss: () -> Unit,
    onApply: (SerialSettings) -> Unit,
    /** Non-null while connected: shows a Disconnect button at the top of the dialog. */
    onDisconnect: (() -> Unit)? = null,
) {
    var baudRate by remember { mutableStateOf(currentSettings.baudRate) }
    var baudRateText by remember { mutableStateOf(currentSettings.baudRate.toString()) }
    var dataBits by remember { mutableStateOf(currentSettings.dataBits) }
    var stopBits by remember { mutableStateOf(currentSettings.stopBits) }
    var parity by remember { mutableStateOf(currentSettings.parity) }
    var flowControl by remember { mutableStateOf(currentSettings.flowControl) }
    var dtrEnabled by remember { mutableStateOf(currentSettings.dtrEnabled) }
    var rtsEnabled by remember { mutableStateOf(currentSettings.rtsEnabled) }
    var baudMenuExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Serial port settings") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                if (onDisconnect != null) {
                    Button(
                        onClick = {
                            onDisconnect()
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.error,
                            contentColor = MaterialTheme.colorScheme.onError,
                        ),
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Disconnect") }
                }
                Column {
                    Text("Baud rate", style = MaterialTheme.typography.labelLarge)
                    Spacer(Modifier.height(4.dp))
                    Box {
                        OutlinedButton(onClick = { baudMenuExpanded = true }, modifier = Modifier.fillMaxWidth()) {
                            Text(baudRateText, modifier = Modifier.weight(1f))
                            Icon(Icons.Filled.ArrowDropDown, contentDescription = null)
                        }
                        DropdownMenu(expanded = baudMenuExpanded, onDismissRequest = { baudMenuExpanded = false }) {
                            SerialSettings.COMMON_BAUD_RATES.forEach { rate ->
                                DropdownMenuItem(
                                    text = { Text(rate.toString()) },
                                    onClick = {
                                        baudRate = rate
                                        baudRateText = rate.toString()
                                        baudMenuExpanded = false
                                    },
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = baudRateText,
                        onValueChange = { text ->
                            val digits = text.filter { it.isDigit() }
                            baudRateText = digits
                            digits.toIntOrNull()?.let { baudRate = it }
                        },
                        label = { Text("Custom baud rate") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                    )
                }

                ChipGroup("Data bits", DataBits.entries, dataBits, { it.label }) { dataBits = it }
                ChipGroup("Parity", Parity.entries, parity, { it.label }) { parity = it }
                ChipGroup("Stop bits", StopBits.entries, stopBits, { it.label }) { stopBits = it }
                ChipGroup("Flow control", FlowControl.entries, flowControl, { it.label }) { flowControl = it }

                Column {
                    Text("Handshake lines", style = MaterialTheme.typography.labelLarge)
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Text("DTR", modifier = Modifier.weight(1f))
                        Switch(checked = dtrEnabled, onCheckedChange = { dtrEnabled = it })
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Text("RTS", modifier = Modifier.weight(1f))
                        Switch(checked = rtsEnabled, onCheckedChange = { rtsEnabled = it })
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onApply(
                    SerialSettings(
                        baudRate = baudRate.coerceAtLeast(50),
                        dataBits = dataBits,
                        stopBits = stopBits,
                        parity = parity,
                        flowControl = flowControl,
                        dtrEnabled = dtrEnabled,
                        rtsEnabled = rtsEnabled,
                    ),
                )
                onDismiss()
            }) { Text("Apply") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        },
    )
}

@Composable
private fun <T> ChipGroup(
    title: String,
    options: List<T>,
    selected: T,
    label: (T) -> String,
    onSelect: (T) -> Unit,
) {
    Column {
        Text(title, style = MaterialTheme.typography.labelLarge)
        Spacer(Modifier.height(4.dp))
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            options.forEach { option ->
                FilterChip(selected = option == selected, onClick = { onSelect(option) }, label = { Text(label(option)) })
            }
        }
    }
}
