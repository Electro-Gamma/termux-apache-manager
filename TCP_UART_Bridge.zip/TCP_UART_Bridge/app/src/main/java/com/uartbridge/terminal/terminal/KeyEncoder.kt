package com.uartbridge.terminal.terminal

import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEvent
import androidx.compose.ui.input.key.isCtrlPressed
import androidx.compose.ui.input.key.key

/**
 * Turns "special" terminal keys (arrows, Home/End, function keys, Ctrl
 * combinations, ...) into the exact bytes a real serial console expects,
 * the same way xterm/PuTTY do. Ordinary printable characters are not
 * handled here - the text field forwards those as typed UTF-8 bytes.
 */
object KeyEncoder {

    fun escape(): ByteArray = byteArrayOf(0x1B)
    fun tab(): ByteArray = byteArrayOf(0x09)
    fun enter(): ByteArray = byteArrayOf(0x0D)
    fun backspace(): ByteArray = byteArrayOf(0x7F)
    fun delete(): ByteArray = csiTilde(3)

    fun arrowUp(appMode: Boolean): ByteArray = arrow('A', appMode)
    fun arrowDown(appMode: Boolean): ByteArray = arrow('B', appMode)
    fun arrowRight(appMode: Boolean): ByteArray = arrow('C', appMode)
    fun arrowLeft(appMode: Boolean): ByteArray = arrow('D', appMode)

    private fun arrow(letter: Char, appMode: Boolean): ByteArray =
        byteArrayOf(0x1B, (if (appMode) 'O' else '[').code.toByte(), letter.code.toByte())

    fun home(): ByteArray = byteArrayOf(0x1B, '['.code.toByte(), 'H'.code.toByte())
    fun end(): ByteArray = byteArrayOf(0x1B, '['.code.toByte(), 'F'.code.toByte())
    fun pageUp(): ByteArray = csiTilde(5)
    fun pageDown(): ByteArray = csiTilde(6)

    private fun csiTilde(n: Int): ByteArray = "\u001b[$n~".toByteArray(Charsets.US_ASCII)

    fun functionKey(n: Int): ByteArray = when (n) {
        1 -> "\u001bOP".toByteArray(Charsets.US_ASCII)
        2 -> "\u001bOQ".toByteArray(Charsets.US_ASCII)
        3 -> "\u001bOR".toByteArray(Charsets.US_ASCII)
        4 -> "\u001bOS".toByteArray(Charsets.US_ASCII)
        5 -> csiTilde(15)
        6 -> csiTilde(17)
        7 -> csiTilde(18)
        8 -> csiTilde(19)
        9 -> csiTilde(20)
        10 -> csiTilde(21)
        11 -> csiTilde(23)
        12 -> csiTilde(24)
        else -> ByteArray(0)
    }

    /** Maps a Ctrl-combination letter/symbol to its control-code byte, or -1 if not a recognised combination. */
    fun ctrlByte(letter: Char): Int {
        val u = letter.uppercaseChar()
        return when {
            u in 'A'..'Z' -> (u.code - 'A'.code + 1)
            u == '[' -> 0x1B
            u == '\\' -> 0x1C
            u == ']' -> 0x1D
            u == '^' -> 0x1E
            u == '_' -> 0x1F
            u == '?' -> 0x7F
            u == ' ' -> 0x00
            else -> -1
        }
    }

    /**
     * Translates a hardware or on-screen key event into the bytes to send.
     * Returns null for ordinary printable keys with no Ctrl held, meaning
     * the caller should fall back to forwarding the typed character(s).
     *
     * [ctrlLocked] lets the on-screen CTRL toggle behave like a sticky
     * modifier for keyboards that can't hold Ctrl themselves.
     */
    fun bytesForKeyEvent(event: KeyEvent, appCursorKeys: Boolean, ctrlLocked: Boolean): ByteArray? {
        val key = event.key
        if (event.isCtrlPressed || ctrlLocked) {
            val letter = KEY_TO_LETTER[key]
            if (letter != null) {
                val code = ctrlByte(letter)
                if (code >= 0) return byteArrayOf(code.toByte())
            }
        }
        return when (key) {
            Key.Escape -> escape()
            Key.Tab -> tab()
            Key.Enter -> enter()
            Key.Backspace -> backspace()
            Key.Delete -> delete()
            Key.DirectionUp -> arrowUp(appCursorKeys)
            Key.DirectionDown -> arrowDown(appCursorKeys)
            Key.DirectionLeft -> arrowLeft(appCursorKeys)
            Key.DirectionRight -> arrowRight(appCursorKeys)
            Key.MoveHome -> home()
            Key.MoveEnd -> end()
            Key.PageUp -> pageUp()
            Key.PageDown -> pageDown()
            Key.F1 -> functionKey(1)
            Key.F2 -> functionKey(2)
            Key.F3 -> functionKey(3)
            Key.F4 -> functionKey(4)
            Key.F5 -> functionKey(5)
            Key.F6 -> functionKey(6)
            Key.F7 -> functionKey(7)
            Key.F8 -> functionKey(8)
            Key.F9 -> functionKey(9)
            Key.F10 -> functionKey(10)
            Key.F11 -> functionKey(11)
            Key.F12 -> functionKey(12)
            else -> null
        }
    }

    private val KEY_TO_LETTER: Map<Key, Char> = buildMap {
        val keys = listOf(
            Key.A, Key.B, Key.C, Key.D, Key.E, Key.F, Key.G, Key.H, Key.I, Key.J, Key.K, Key.L, Key.M,
            Key.N, Key.O, Key.P, Key.Q, Key.R, Key.S, Key.T, Key.U, Key.V, Key.W, Key.X, Key.Y, Key.Z,
        )
        ('A'..'Z').zip(keys).forEach { (letter, k) -> put(k, letter) }
    }
}
