package com.uartbridge.terminal.serial

import com.hoho.android.usbserial.driver.UsbSerialPort

enum class DataBits(val value: Int, val label: String) {
    FIVE(5, "5"),
    SIX(6, "6"),
    SEVEN(7, "7"),
    EIGHT(8, "8"),
}

enum class StopBits(val libValue: Int, val label: String) {
    ONE(UsbSerialPort.STOPBITS_1, "1"),
    ONE_POINT_FIVE(UsbSerialPort.STOPBITS_1_5, "1.5"),
    TWO(UsbSerialPort.STOPBITS_2, "2"),
}

enum class Parity(val libValue: Int, val label: String) {
    NONE(UsbSerialPort.PARITY_NONE, "None"),
    ODD(UsbSerialPort.PARITY_ODD, "Odd"),
    EVEN(UsbSerialPort.PARITY_EVEN, "Even"),
}

enum class FlowControl(val label: String) {
    NONE("None"),
    XON_XOFF("XON/XOFF"),
    RTS_CTS("RTS/CTS"),
}

/**
 * Everything needed to configure a serial port, plus the two hardware
 * handshaking lines (DTR/RTS) some adapters and boards rely on.
 */
data class SerialSettings(
    val baudRate: Int = 115200,
    val dataBits: DataBits = DataBits.EIGHT,
    val stopBits: StopBits = StopBits.ONE,
    val parity: Parity = Parity.NONE,
    val flowControl: FlowControl = FlowControl.NONE,
    val dtrEnabled: Boolean = true,
    val rtsEnabled: Boolean = true,
) {
    companion object {
        /**
         * 115200 8N1, no flow control - the documented default Linux serial
         * console configuration on Allwinner-based Armbian boards such as
         * the Banana Pi M2 Zero / M2 Zero W. Not hard-coded elsewhere: the
         * settings dialog lets this be changed freely, since some images or
         * bootloader configs use a different console baud rate.
         */
        val BANANA_PI_DEFAULT = SerialSettings()

        val COMMON_BAUD_RATES = listOf(9600, 19200, 38400, 57600, 115200, 230400, 460800, 921600)
    }
}
