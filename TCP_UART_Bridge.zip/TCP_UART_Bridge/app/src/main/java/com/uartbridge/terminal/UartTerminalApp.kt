package com.uartbridge.terminal

import android.app.Application
import com.uartbridge.terminal.crash.GlobalCrashHandler

class UartTerminalApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // As early as possible, so any uncaught exception shows a readable crash screen.
        GlobalCrashHandler.install(this)
    }
}
