package com.uartbridge.terminal

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.uartbridge.terminal.ui.MainScreen
import com.uartbridge.terminal.ui.theme.UartTerminalTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        // Edge-to-edge on every Android version, so keyboard insets are delivered
        // to Compose consistently (Android 15+ forces it, and stops resizing the
        // window for the keyboard).
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            UartTerminalTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    MainScreen()
                }
            }
        }
    }
}
