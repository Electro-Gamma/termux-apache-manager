package com.uartbridge.terminal.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.uartbridge.terminal.viewmodel.ConnectionState
import com.uartbridge.terminal.viewmodel.TerminalViewModel
import kotlinx.coroutines.launch

@Composable
fun MainScreen() {
    val viewModel: TerminalViewModel = viewModel()
    var showSettings by remember { mutableStateOf(false) }
    val settings by viewModel.settings.collectAsState()
    val connectionState by viewModel.connectionState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    LaunchedEffect(viewModel) {
        viewModel.start()
    }
    LaunchedEffect(viewModel) {
        viewModel.toastEvents.collect { message -> snackbarHostState.showSnackbar(message) }
    }

    Scaffold(snackbarHost = { SnackbarHost(snackbarHostState) }) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            ConnectionBar(viewModel = viewModel, onOpenSettings = { showSettings = true })
            TerminalView(
                viewModel = viewModel,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                onCopied = { scope.launch { snackbarHostState.showSnackbar("Copied to clipboard") } },
            )
            KeyToolbar(viewModel = viewModel)
            InputBar(viewModel = viewModel, isConnected = connectionState is ConnectionState.Connected)
        }
    }

    if (showSettings) {
        SerialSettingsDialog(
            currentSettings = settings,
            onDismiss = { showSettings = false },
            onApply = { viewModel.updateSettings(it) },
        )
    }
}

private data class TextDiff(val removed: Int, val inserted: String)

private fun diffText(old: String, new: String): TextDiff {
    val minLen = minOf(old.length, new.length)
    var prefix = 0
    while (prefix < minLen && old[prefix] == new[prefix]) prefix++
    return TextDiff(removed = old.length - prefix, inserted = new.substring(prefix))
}

/**
 * The line the Android keyboard types into. Special keys (arrows, Enter,
 * Backspace, Escape, Tab, Ctrl combinations, ...) are caught in
 * [onPreviewKeyEvent] and sent immediately without ever touching the text
 * field; anything left over is ordinary typed text, forwarded to the
 * serial port as its content changes.
 */
@Composable
private fun InputBar(viewModel: TerminalViewModel, isConnected: Boolean) {
    var fieldValue by remember { mutableStateOf(TextFieldValue("")) }
    val clipboardManager = LocalClipboardManager.current
    val focusRequester = remember { FocusRequester() }

    LaunchedEffect(isConnected) {
        if (isConnected) focusRequester.requestFocus()
    }

    Surface(tonalElevation = 1.dp, modifier = Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp)) {
            IconButton(onClick = {
                val clip = clipboardManager.getText()?.text
                if (!clip.isNullOrEmpty()) viewModel.pasteText(clip)
            }) {
                Icon(Icons.Filled.ContentPaste, contentDescription = "Paste")
            }
            Box(modifier = Modifier.weight(1f)) {
                if (fieldValue.text.isEmpty()) {
                    Text(
                        text = if (isConnected) "Type to send…" else "Connect to a device to start typing",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
                BasicTextField(
                    value = fieldValue,
                    onValueChange = { newValue ->
                        val diff = diffText(fieldValue.text, newValue.text)
                        repeat(diff.removed) { viewModel.sendBackspace() }
                        if (diff.inserted.isNotEmpty()) viewModel.sendText(diff.inserted)
                        fieldValue = newValue
                    },
                    enabled = isConnected,
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(focusRequester)
                        .onPreviewKeyEvent { event ->
                            if (event.type == KeyEventType.KeyDown) {
                                val handled = viewModel.sendKeyEvent(event)
                                if (handled && event.key == Key.Enter) fieldValue = TextFieldValue("")
                                handled
                            } else {
                                false
                            }
                        },
                    textStyle = TextStyle(color = MaterialTheme.colorScheme.onSurface),
                    singleLine = true,
                    cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = {
                        viewModel.sendEnter()
                        fieldValue = TextFieldValue("")
                    }),
                )
            }
        }
    }
}
