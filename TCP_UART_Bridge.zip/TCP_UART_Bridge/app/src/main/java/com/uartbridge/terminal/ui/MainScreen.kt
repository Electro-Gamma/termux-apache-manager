package com.uartbridge.terminal.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.uartbridge.terminal.viewmodel.ConnectionState
import com.uartbridge.terminal.viewmodel.TerminalViewModel
import kotlinx.coroutines.launch

@Composable
fun MainScreen() {
    val viewModel: TerminalViewModel = viewModel()
    var showSettings by remember { mutableStateOf(false) }
    val settings by viewModel.settings.collectAsState()
    val connectionState by viewModel.connectionState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    LaunchedEffect(viewModel) {
        viewModel.start()
    }
    LaunchedEffect(viewModel) {
        viewModel.toastEvents.collect { message -> snackbarHostState.showSnackbar(message) }
    }

    // safeDrawing includes the on-screen keyboard (IME), so the whole column -
    // terminal AND key toolbar - is lifted above the keyboard whenever it's up.
    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        contentWindowInsets = WindowInsets.safeDrawing,
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            ConnectionBar(viewModel = viewModel, onOpenSettings = { showSettings = true })
            // The terminal itself is the input surface (tap it to bring up
            // the keyboard) - there's no separate typing bar, same as a
            // real serial terminal app.
            TerminalView(
                viewModel = viewModel,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                onCopied = { scope.launch { snackbarHostState.showSnackbar("Copied to clipboard") } },
            )
            KeyToolbar(viewModel = viewModel)
        }
    }

    if (showSettings) {
        SerialSettingsDialog(
            currentSettings = settings,
            onDismiss = { showSettings = false },
            onApply = { viewModel.updateSettings(it) },
            onDisconnect = if (connectionState is ConnectionState.Connected) {
                { viewModel.disconnect() }
            } else null,
        )
    }
}
