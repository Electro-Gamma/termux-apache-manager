package com.uartbridge.terminal.ui

import android.content.Context
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.input.key.KeyEvent as ComposeKeyEvent
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.uartbridge.terminal.terminal.Cell
import com.uartbridge.terminal.terminal.TerminalBuffer
import com.uartbridge.terminal.terminal.TerminalColors
import com.uartbridge.terminal.ui.theme.TerminalFontFamily
import com.uartbridge.terminal.viewmodel.ConnectionState
import com.uartbridge.terminal.viewmodel.TerminalViewModel
import kotlin.math.max
import kotlin.math.min

private data class CharMetrics(val width: Float, val height: Float)
private data class ViewportCell(val row: Int, val col: Int)
private data class Selection(val start: ViewportCell, val end: ViewportCell)

private const val DEFAULT_FONT_SIZE_SP = 14
private const val MIN_FONT_SIZE_SP = 6
private const val MAX_FONT_SIZE_SP = 40
private const val PREFS_NAME = "terminal_prefs"
private const val PREF_FONT_SIZE = "font_size_sp"

/**
 * Renders the terminal's screen + scrollback as one continuous, scrollable
 * page, and IS the input surface - like PuTTY or Termux, there is no
 * separate typing bar. Tapping anywhere in the terminal focuses a hidden
 * input view and brings up the keyboard; special keys (arrows, Enter,
 * Backspace, Escape, Tab, Ctrl combinations, ...) are sent immediately, and ordinary typed text is
 * forwarded as it's committed by [TerminalInputView], whose input connection
 * is stateless so no earlier input stays editable in the keyboard. Pinching with two fingers zooms the font (remembered between launches). A vertical drag scrolls through
 * history (auto-pinned to the live bottom until the user scrolls up); a
 * long-press followed by a drag selects text, and lifting the finger
 * copies the selection.
 */
@Composable
fun TerminalView(
    viewModel: TerminalViewModel,
    modifier: Modifier = Modifier,
    onCopied: () -> Unit = {},
) {
    val revision by viewModel.terminalRevision.collectAsState()
    val connectionState by viewModel.connectionState.collectAsState()
    val emulator = viewModel.emulator
    val buffer = emulator.buffer
    val clipboardManager = LocalClipboardManager.current
    val density = LocalDensity.current
    val textMeasurer = rememberTextMeasurer()
    val context = LocalContext.current
    val inputView = remember { TerminalInputView(context) }
    val imeInsets = WindowInsets.ime
    val imeVisible by remember { derivedStateOf { imeInsets.getBottom(density) > 0 } }

    var scrollOffset by remember { mutableIntStateOf(0) }
    var prevScrollbackSize by remember { mutableIntStateOf(0) }
    var dragAccumPx by remember { mutableFloatStateOf(0f) }
    var selection by remember { mutableStateOf<Selection?>(null) }
    val selecting = remember { mutableStateOf(false) }

    // Pinch-to-zoom font size, remembered between launches (like Termux).
    val prefs = remember { context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE) }
    var fontSizeValue by remember {
        mutableIntStateOf(prefs.getInt(PREF_FONT_SIZE, DEFAULT_FONT_SIZE_SP).coerceIn(MIN_FONT_SIZE_SP, MAX_FONT_SIZE_SP))
    }
    val fontSizeSp = fontSizeValue.sp
    val charMetrics = remember(density, fontSizeSp) {
        val layout = textMeasurer.measure(
            AnnotatedString("M"),
            style = TextStyle(fontFamily = TerminalFontFamily, fontSize = fontSizeSp),
        )
        CharMetrics(width = layout.size.width.toFloat(), height = layout.size.height.toFloat())
    }

    // If the user is scrolled up into history, keep their view stable as
    // new lines arrive instead of yanking them back down to the bottom.
    LaunchedEffect(revision) {
        val currentSize = buffer.scrollback.size
        val delta = currentSize - prevScrollbackSize
        if (scrollOffset > 0 && delta > 0) {
            scrollOffset = min(scrollOffset + delta, currentSize)
        }
        prevScrollbackSize = currentSize
        if (scrollOffset > currentSize) scrollOffset = currentSize
    }

    // Whenever the keyboard comes up, snap to the live bottom so the newest
    // output and the line being typed sit directly above it. (The terminal
    // area itself shrinks to fit above the keyboard - see MainScreen - and
    // TerminalBuffer.resize keeps the cursor line in view when it does.)
    LaunchedEffect(imeVisible) {
        if (imeVisible) scrollOffset = 0
    }

    // Auto-focus (and pop the keyboard) the moment a connection is made,
    // same as a real terminal app - no need to tap first.
    val isConnected = connectionState is ConnectionState.Connected
    LaunchedEffect(isConnected) {
        if (isConnected) inputView.post { inputView.showKeyboard() }
    }

    BoxWithConstraints(modifier = modifier.background(Color(TerminalColors.screenBackground))) {
        val widthPx = with(density) { maxWidth.toPx() }
        val heightPx = with(density) { maxHeight.toPx() }
        val cols = max(1, (widthPx / charMetrics.width).toInt())
        val rows = max(1, (heightPx / charMetrics.height).toInt())

        LaunchedEffect(rows, cols) {
            viewModel.resizeTerminal(rows, cols)
        }

        fun cellAt(offset: Offset): ViewportCell {
            val row = (offset.y / charMetrics.height).toInt().coerceIn(0, buffer.rows - 1)
            val col = (offset.x / charMetrics.width).toInt().coerceIn(0, buffer.cols - 1)
            return ViewportCell(row, col)
        }

        // Invisible keyboard receiver. Its input connection is stateless: typed
        // characters are forwarded to the serial port and immediately forgotten,
        // so nothing entered earlier stays editable in the keyboard. It also
        // makes the keyboard's action key a plain Return/Enter.
        AndroidView(
            factory = { inputView },
            update = { view ->
                view.onTextInput = { text ->
                    scrollOffset = 0
                    viewModel.sendText(text)
                }
                view.onBackspace = { count ->
                    scrollOffset = 0
                    repeat(count) { viewModel.sendBackspace() }
                }
                view.onEnter = {
                    scrollOffset = 0
                    viewModel.sendEnter()
                }
                view.onSpecialKey = { event ->
                    val handled = viewModel.sendKeyEvent(ComposeKeyEvent(event))
                    if (handled) scrollOffset = 0
                    handled
                }
            },
            modifier = Modifier.size(1.dp),
        )

        Canvas(
            modifier = Modifier
                .fillMaxSize()
                // Two-finger pinch zoom, Termux style: every ~10% change in finger
                // distance steps the font size by 1sp. Runs in the Initial pass and
                // consumes the touches once a second finger is down, so it never
                // also scrolls, selects or taps.
                .pointerInput(Unit) {
                    awaitEachGesture {
                        awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                        var lastSpan = 0f
                        var scale = 1f
                        var pinching = false
                        do {
                            val event = awaitPointerEvent(PointerEventPass.Initial)
                            val pressed = event.changes.filter { it.pressed }
                            if (pressed.size >= 2) {
                                pinching = true
                                val span = (pressed[0].position - pressed[1].position).getDistance()
                                if (lastSpan > 0f && span > 0f) {
                                    scale *= span / lastSpan
                                    val step = when {
                                        scale > 1.1f -> 1
                                        scale < 0.9f -> -1
                                        else -> 0
                                    }
                                    if (step != 0) {
                                        scale = 1f
                                        val newSize = (fontSizeValue + step).coerceIn(MIN_FONT_SIZE_SP, MAX_FONT_SIZE_SP)
                                        if (newSize != fontSizeValue) {
                                            fontSizeValue = newSize
                                            prefs.edit().putInt(PREF_FONT_SIZE, newSize).apply()
                                        }
                                    }
                                }
                                lastSpan = span
                            } else {
                                lastSpan = 0f
                            }
                            if (pinching) event.changes.forEach { it.consume() }
                        } while (event.changes.any { it.pressed })
                    }
                }
                .pointerInput(charMetrics) {
                    detectTapGestures(
                        onTap = { inputView.showKeyboard() },
                        onLongPress = { offset ->
                            val cell = cellAt(offset)
                            selecting.value = true
                            selection = Selection(cell, cell)
                        },
                    )
                }
                .pointerInput(charMetrics) {
                    detectDragGestures(
                        onDragEnd = {
                            if (selecting.value) {
                                selection?.let { sel ->
                                    val text = extractSelectedText(buffer, scrollOffset, sel)
                                    if (text.isNotEmpty()) {
                                        clipboardManager.setText(AnnotatedString(text))
                                        onCopied()
                                    }
                                }
                                selecting.value = false
                                selection = null
                            }
                        },
                        onDragCancel = { selecting.value = false; selection = null },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            if (selecting.value) {
                                selection = selection?.copy(end = cellAt(change.position))
                            } else {
                                dragAccumPx += dragAmount.y
                                val lineDelta = (dragAccumPx / charMetrics.height).toInt()
                                if (lineDelta != 0) {
                                    dragAccumPx -= lineDelta * charMetrics.height
                                    scrollOffset = (scrollOffset + lineDelta).coerceIn(0, buffer.scrollback.size)
                                }
                            }
                        },
                    )
                },
        ) {
            val visibleRows = buffer.rows
            val topAbsoluteIndex = buffer.scrollback.size - scrollOffset
            for (viewportRow in 0 until visibleRows) {
                val absoluteIndex = topAbsoluteIndex + viewportRow
                val line = lineAt(buffer, absoluteIndex) ?: continue
                val y = viewportRow * charMetrics.height
                // The buffer can briefly have more rows than the canvas while the
                // keyboard animates (the resize lands a frame later): don't draw
                // rows that are completely off the bottom of the canvas.
                if (y >= size.height) break

                drawBackgrounds(line, y, charMetrics)

                if (selecting.value) {
                    selection?.let { sel -> drawSelectionOverlay(sel, viewportRow, buffer.cols, y, charMetrics) }
                }

                val annotated = buildRowText(line)
                drawText(
                    textMeasurer,
                    annotated,
                    topLeft = Offset(0f, y),
                    // Explicit size: the default is "canvas size minus topLeft", which goes
                    // negative for a row partly/fully below the canvas and crashes.
                    size = Size(size.width.coerceAtLeast(1f), charMetrics.height),
                    style = TextStyle(fontFamily = TerminalFontFamily, fontSize = fontSizeSp),
                )
            }

            // Live block cursor - only meaningful when looking at the bottom (the live screen), not scrolled into history.
            if (scrollOffset == 0 && emulator.cursorVisible && connectionState is ConnectionState.Connected) {
                val cx = buffer.cursorCol * charMetrics.width
                val cy = buffer.cursorRow * charMetrics.height
                drawRect(
                    color = Color(TerminalColors.screenForeground).copy(alpha = 0.45f),
                    topLeft = Offset(cx, cy),
                    size = Size(charMetrics.width, charMetrics.height),
                )
            }
        }

        if (scrollOffset > 0) {
            FloatingActionButton(
                onClick = { scrollOffset = 0 },
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(16.dp)
                    .size(40.dp),
                containerColor = MaterialTheme.colorScheme.primaryContainer,
            ) {
                Icon(Icons.Filled.ArrowDownward, contentDescription = "Scroll to latest output")
            }
        }
    }
}

private fun lineAt(buffer: TerminalBuffer, absoluteIndex: Int): Array<Cell>? {
    val sbSize = buffer.scrollback.size
    return when {
        absoluteIndex < 0 -> null
        absoluteIndex < sbSize -> buffer.scrollback.getOrNull(absoluteIndex)
        else -> buffer.screen.getOrNull(absoluteIndex - sbSize)
    }
}

private fun resolveArgb(value: Int): Int = when (value) {
    TerminalColors.DEFAULT_FG -> TerminalColors.screenForeground
    TerminalColors.DEFAULT_BG -> TerminalColors.screenBackground
    else -> value
}

private fun DrawScope.drawBackgrounds(line: Array<Cell>, y: Float, metrics: CharMetrics) {
    var i = 0
    while (i < line.size) {
        val cell = line[i]
        val bgArgb = if (cell.reverse) resolveArgb(cell.fg) else resolveArgb(cell.bg)
        var j = i + 1
        while (j < line.size) {
            val other = line[j]
            val otherBg = if (other.reverse) resolveArgb(other.fg) else resolveArgb(other.bg)
            if (otherBg != bgArgb) break
            j++
        }
        if (bgArgb != TerminalColors.screenBackground) {
            drawRect(
                color = Color(bgArgb),
                topLeft = Offset(i * metrics.width, y),
                size = Size((j - i) * metrics.width, metrics.height),
            )
        }
        i = j
    }
}

private fun DrawScope.drawSelectionOverlay(sel: Selection, viewportRow: Int, cols: Int, y: Float, metrics: CharMetrics) {
    val (top, bottom) = normalizeSelection(sel)
    if (viewportRow < top.row || viewportRow > bottom.row) return
    val startCol = if (viewportRow == top.row) top.col else 0
    val endCol = if (viewportRow == bottom.row) bottom.col else cols - 1
    if (endCol < startCol) return
    drawRect(
        color = Color(0x552196F3),
        topLeft = Offset(startCol * metrics.width, y),
        size = Size((endCol - startCol + 1) * metrics.width, metrics.height),
    )
}

private fun normalizeSelection(sel: Selection): Pair<ViewportCell, ViewportCell> {
    val a = sel.start; val b = sel.end
    return if (a.row < b.row || (a.row == b.row && a.col <= b.col)) a to b else b to a
}

private fun extractSelectedText(buffer: TerminalBuffer, scrollOffset: Int, sel: Selection): String {
    val (top, bottom) = normalizeSelection(sel)
    val topAbsolute = buffer.scrollback.size - scrollOffset
    val lines = mutableListOf<String>()
    for (viewportRow in top.row..bottom.row) {
        val line = lineAt(buffer, topAbsolute + viewportRow) ?: continue
        val startCol = if (viewportRow == top.row) top.col else 0
        val endCol = if (viewportRow == bottom.row) bottom.col else buffer.cols - 1
        if (endCol < startCol) continue
        val text = buildString { for (c in startCol..endCol) append(line.getOrNull(c)?.ch ?: ' ') }
        lines.add(text.trimEnd())
    }
    return lines.joinToString("\n")
}

private fun buildRowText(line: Array<Cell>): AnnotatedString = buildAnnotatedString {
    var i = 0
    while (i < line.size) {
        val cell = line[i]
        var j = i + 1
        while (j < line.size && sameStyle(line[j], cell)) j++
        val fgArgb = if (cell.reverse) resolveArgb(cell.bg) else resolveArgb(cell.fg)
        withStyle(
            SpanStyle(
                color = Color(fgArgb),
                fontWeight = if (cell.bold) FontWeight.Bold else FontWeight.Normal,
                textDecoration = if (cell.underline) TextDecoration.Underline else TextDecoration.None,
            ),
        ) {
            for (k in i until j) append(line[k].ch)
        }
        i = j
    }
}

private fun sameStyle(a: Cell, b: Cell): Boolean =
    a.fg == b.fg && a.bg == b.bg && a.bold == b.bold && a.underline == b.underline && a.reverse == b.reverse
