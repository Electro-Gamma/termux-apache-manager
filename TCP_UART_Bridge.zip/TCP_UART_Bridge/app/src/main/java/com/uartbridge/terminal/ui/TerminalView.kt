package com.uartbridge.terminal.ui

import androidx.compose.foundation.BoxWithConstraints
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.uartbridge.terminal.terminal.Cell
import com.uartbridge.terminal.terminal.TerminalBuffer
import com.uartbridge.terminal.terminal.TerminalColors
import com.uartbridge.terminal.ui.theme.TerminalFontFamily
import com.uartbridge.terminal.viewmodel.ConnectionState
import com.uartbridge.terminal.viewmodel.TerminalViewModel
import kotlin.math.max
import kotlin.math.min

private data class CharMetrics(val width: Float, val height: Float)
private data class ViewportCell(val row: Int, val col: Int)
private data class Selection(val start: ViewportCell, val end: ViewportCell)

private const val TERMINAL_FONT_SIZE_SP = 14

/**
 * Renders the terminal's screen + scrollback as one continuous, scrollable
 * page. A vertical drag scrolls through history (auto-pinned to the live
 * bottom until the user scrolls up); a long-press followed by a drag
 * selects text, and lifting the finger copies the selection.
 */
@Composable
fun TerminalView(
    viewModel: TerminalViewModel,
    modifier: Modifier = Modifier,
    onCopied: () -> Unit = {},
) {
    val revision by viewModel.terminalRevision.collectAsState()
    val connectionState by viewModel.connectionState.collectAsState()
    val emulator = viewModel.emulator
    val buffer = emulator.buffer
    val clipboardManager = LocalClipboardManager.current
    val density = LocalDensity.current
    val textMeasurer = rememberTextMeasurer()

    var scrollOffset by remember { mutableIntStateOf(0) }
    var prevScrollbackSize by remember { mutableIntStateOf(0) }
    var dragAccumPx by remember { mutableFloatStateOf(0f) }
    var selection by remember { mutableStateOf<Selection?>(null) }
    val selecting = remember { mutableStateOf(false) }

    val fontSizeSp = TERMINAL_FONT_SIZE_SP.sp
    val charMetrics = remember(density, fontSizeSp) {
        val layout = textMeasurer.measure(
            AnnotatedString("M"),
            style = TextStyle(fontFamily = TerminalFontFamily, fontSize = fontSizeSp),
        )
        CharMetrics(width = layout.size.width.toFloat(), height = layout.size.height.toFloat())
    }

    // If the user is scrolled up into history, keep their view stable as
    // new lines arrive instead of yanking them back down to the bottom.
    LaunchedEffect(revision) {
        val currentSize = buffer.scrollback.size
        val delta = currentSize - prevScrollbackSize
        if (scrollOffset > 0 && delta > 0) {
            scrollOffset = min(scrollOffset + delta, currentSize)
        }
        prevScrollbackSize = currentSize
    }

    BoxWithConstraints(modifier = modifier.background(Color(TerminalColors.screenBackground))) {
        val widthPx = with(density) { maxWidth.toPx() }
        val heightPx = with(density) { maxHeight.toPx() }
        val cols = max(1, (widthPx / charMetrics.width).toInt())
        val rows = max(1, (heightPx / charMetrics.height).toInt())

        LaunchedEffect(rows, cols) {
            if (rows != buffer.rows || cols != buffer.cols) emulator.resize(rows, cols)
        }

        fun cellAt(offset: Offset): ViewportCell {
            val row = (offset.y / charMetrics.height).toInt().coerceIn(0, buffer.rows - 1)
            val col = (offset.x / charMetrics.width).toInt().coerceIn(0, buffer.cols - 1)
            return ViewportCell(row, col)
        }

        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(charMetrics) {
                    detectTapGestures(
                        onLongPress = { offset ->
                            val cell = cellAt(offset)
                            selecting.value = true
                            selection = Selection(cell, cell)
                        },
                    )
                }
                .pointerInput(charMetrics) {
                    detectDragGestures(
                        onDragEnd = {
                            if (selecting.value) {
                                selection?.let { sel ->
                                    val text = extractSelectedText(buffer, scrollOffset, sel)
                                    if (text.isNotEmpty()) {
                                        clipboardManager.setText(AnnotatedString(text))
                                        onCopied()
                                    }
                                }
                                selecting.value = false
                                selection = null
                            }
                        },
                        onDragCancel = { selecting.value = false; selection = null },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            if (selecting.value) {
                                selection = selection?.copy(end = cellAt(change.position))
                            } else {
                                dragAccumPx += dragAmount.y
                                val lineDelta = (dragAccumPx / charMetrics.height).toInt()
                                if (lineDelta != 0) {
                                    dragAccumPx -= lineDelta * charMetrics.height
                                    scrollOffset = (scrollOffset + lineDelta).coerceIn(0, buffer.scrollback.size)
                                }
                            }
                        },
                    )
                },
        ) {
            val visibleRows = buffer.rows
            val topAbsoluteIndex = buffer.scrollback.size - scrollOffset
            for (viewportRow in 0 until visibleRows) {
                val absoluteIndex = topAbsoluteIndex + viewportRow
                val line = lineAt(buffer, absoluteIndex) ?: continue
                val y = viewportRow * charMetrics.height

                drawBackgrounds(line, y, charMetrics)

                if (selecting.value) {
                    selection?.let { sel -> drawSelectionOverlay(sel, viewportRow, buffer.cols, y, charMetrics) }
                }

                val annotated = buildRowText(line)
                drawText(textMeasurer, annotated, topLeft = Offset(0f, y), style = TextStyle(fontFamily = TerminalFontFamily, fontSize = fontSizeSp))
            }

            // Live block cursor - only meaningful when looking at the bottom (the live screen), not scrolled into history.
            if (scrollOffset == 0 && emulator.cursorVisible && connectionState is ConnectionState.Connected) {
                val cx = buffer.cursorCol * charMetrics.width
                val cy = buffer.cursorRow * charMetrics.height
                drawRect(
                    color = Color(TerminalColors.screenForeground).copy(alpha = 0.45f),
                    topLeft = Offset(cx, cy),
                    size = Size(charMetrics.width, charMetrics.height),
                )
            }
        }

        if (scrollOffset > 0) {
            FloatingActionButton(
                onClick = { scrollOffset = 0 },
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(16.dp)
                    .size(40.dp),
                containerColor = MaterialTheme.colorScheme.primaryContainer,
            ) {
                Icon(Icons.Filled.ArrowDownward, contentDescription = "Scroll to latest output")
            }
        }
    }
}

private fun lineAt(buffer: TerminalBuffer, absoluteIndex: Int): Array<Cell>? {
    val sbSize = buffer.scrollback.size
    return when {
        absoluteIndex < 0 -> null
        absoluteIndex < sbSize -> buffer.scrollback.getOrNull(absoluteIndex)
        else -> buffer.screen.getOrNull(absoluteIndex - sbSize)
    }
}

private fun resolveArgb(value: Int): Int = when (value) {
    TerminalColors.DEFAULT_FG -> TerminalColors.screenForeground
    TerminalColors.DEFAULT_BG -> TerminalColors.screenBackground
    else -> value
}

private fun DrawScope.drawBackgrounds(line: Array<Cell>, y: Float, metrics: CharMetrics) {
    var i = 0
    while (i < line.size) {
        val cell = line[i]
        val bgArgb = if (cell.reverse) resolveArgb(cell.fg) else resolveArgb(cell.bg)
        var j = i + 1
        while (j < line.size) {
            val other = line[j]
            val otherBg = if (other.reverse) resolveArgb(other.fg) else resolveArgb(other.bg)
            if (otherBg != bgArgb) break
            j++
        }
        if (bgArgb != TerminalColors.screenBackground) {
            drawRect(
                color = Color(bgArgb),
                topLeft = Offset(i * metrics.width, y),
                size = Size((j - i) * metrics.width, metrics.height),
            )
        }
        i = j
    }
}

private fun DrawScope.drawSelectionOverlay(sel: Selection, viewportRow: Int, cols: Int, y: Float, metrics: CharMetrics) {
    val (top, bottom) = normalizeSelection(sel)
    if (viewportRow < top.row || viewportRow > bottom.row) return
    val startCol = if (viewportRow == top.row) top.col else 0
    val endCol = if (viewportRow == bottom.row) bottom.col else cols - 1
    if (endCol < startCol) return
    drawRect(
        color = Color(0x552196F3),
        topLeft = Offset(startCol * metrics.width, y),
        size = Size((endCol - startCol + 1) * metrics.width, metrics.height),
    )
}

private fun normalizeSelection(sel: Selection): Pair<ViewportCell, ViewportCell> {
    val a = sel.start; val b = sel.end
    return if (a.row < b.row || (a.row == b.row && a.col <= b.col)) a to b else b to a
}

private fun extractSelectedText(buffer: TerminalBuffer, scrollOffset: Int, sel: Selection): String {
    val (top, bottom) = normalizeSelection(sel)
    val topAbsolute = buffer.scrollback.size - scrollOffset
    val lines = mutableListOf<String>()
    for (viewportRow in top.row..bottom.row) {
        val line = lineAt(buffer, topAbsolute + viewportRow) ?: continue
        val startCol = if (viewportRow == top.row) top.col else 0
        val endCol = if (viewportRow == bottom.row) bottom.col else buffer.cols - 1
        if (endCol < startCol) continue
        val text = buildString { for (c in startCol..endCol) append(line[c].ch) }
        lines.add(text.trimEnd())
    }
    return lines.joinToString("\n")
}

private fun buildRowText(line: Array<Cell>): AnnotatedString = buildAnnotatedString {
    var i = 0
    while (i < line.size) {
        val cell = line[i]
        var j = i + 1
        while (j < line.size && sameStyle(line[j], cell)) j++
        val fgArgb = if (cell.reverse) resolveArgb(cell.bg) else resolveArgb(cell.fg)
        withStyle(
            SpanStyle(
                color = Color(fgArgb),
                fontWeight = if (cell.bold) FontWeight.Bold else FontWeight.Normal,
                textDecoration = if (cell.underline) TextDecoration.Underline else TextDecoration.None,
            ),
        ) {
            for (k in i until j) append(line[k].ch)
        }
        i = j
    }
}

private fun sameStyle(a: Cell, b: Cell): Boolean =
    a.fg == b.fg && a.bg == b.bg && a.bold == b.bold && a.underline == b.underline && a.reverse == b.reverse
