package com.uartbridge.terminal.terminal

/**
 * The standard 16-color ANSI palette (SGR 30-37 / 90-97 foreground,
 * 40-47 / 100-107 background), plus sentinel values for "use the
 * terminal's default foreground/background".
 *
 * Index layout matches xterm's default palette so output from real shells
 * (ls --color, prompts, vim, htop, etc.) looks the way people expect.
 */
object TerminalColors {
    // Resolved opaque ARGB colors below always look like 0xFFxxxxxx, i.e.
    // every value in [-16777216, -1] as a signed Int. These sentinels sit
    // well outside that range (Int.MIN_VALUE's magnitude is far larger) so
    // they can never collide with a real resolved color such as bright
    // white (0xFFFFFFFF, which as a signed Int equals -1).
    const val DEFAULT_FG = Int.MIN_VALUE
    const val DEFAULT_BG = Int.MIN_VALUE + 1

    // 0=black 1=red 2=green 3=yellow 4=blue 5=magenta 6=cyan 7=white,
    // then the bright variants 8..15 in the same order.
    val palette: IntArray = intArrayOf(
        0xFF1A1B26.toInt(), // 0 black
        0xFFF7768E.toInt(), // 1 red
        0xFF9ECE6A.toInt(), // 2 green
        0xFFE0AF68.toInt(), // 3 yellow
        0xFF7AA2F7.toInt(), // 4 blue
        0xFFBB9AF7.toInt(), // 5 magenta
        0xFF7DCFFF.toInt(), // 6 cyan
        0xFFC0CAF5.toInt(), // 7 white
        0xFF414868.toInt(), // 8 bright black (gray)
        0xFFFF899D.toInt(), // 9 bright red
        0xFFB9F27C.toInt(), // 10 bright green
        0xFFFF9E64.toInt(), // 11 bright yellow
        0xFF7DA6FF.toInt(), // 12 bright blue
        0xFFD0A9FF.toInt(), // 13 bright magenta
        0xFF9AEDFE.toInt(), // 14 bright cyan
        0xFFFFFFFF.toInt(), // 15 bright white
    )

    /** A 256-color xterm cube approximation for SGR "38;5;N" / "48;5;N". */
    fun color256(index: Int): Int {
        if (index < 16) return palette[index]
        if (index in 16..231) {
            val i = index - 16
            val r = i / 36
            val g = (i % 36) / 6
            val b = i % 6
            fun level(v: Int) = if (v == 0) 0 else 55 + v * 40
            return (0xFF shl 24) or (level(r) shl 16) or (level(g) shl 8) or level(b)
        }
        // grayscale ramp 232..255
        val gray = 8 + (index - 232) * 10
        return (0xFF shl 24) or (gray shl 16) or (gray shl 8) or gray
    }

    // Plain `val`, not `const val`: the .toInt() conversion below isn't a
    // constant expression as far as the compiler's `const` evaluator goes.
    val screenBackground: Int = 0xFF0D0F17.toInt()
    val screenForeground: Int = 0xFFC0CAF5.toInt()
}
