package com.uartbridge.terminal.terminal

/**
 * Interprets a stream of bytes from the serial device as an ANSI/VT100 /
 * xterm-ish terminal, mutating a [TerminalBuffer] as it goes. This class
 * has no Android or UI dependency - it is fed raw bytes and can be read
 * back by any renderer.
 *
 * Scope is deliberately the practical subset that real Linux shells and
 * common console tools (bash, vim, htop, less, dmesg) actually emit:
 * cursor movement, SGR colors/attributes, screen/line erasing, scrolling
 * regions, the alternate screen buffer, save/restore cursor, application
 * cursor-key mode, and cursor-position reports. It does not attempt to be
 * a byte-for-byte port of PuTTY's terminal.c; DEC line-drawing character
 * sets and true bidi/combining-character shaping are out of scope.
 *
 * Not thread-safe: [feed] must always be called from the same thread
 * (the ViewModel feeds it from the main thread so reads from Compose are
 * always consistent).
 */
class TerminalEmulator(rows: Int, cols: Int) {

    val buffer = TerminalBuffer(rows, cols)

    var appCursorKeys: Boolean = false
        private set
    var cursorVisible: Boolean = true
        private set
    var bracketedPaste: Boolean = false
        private set
    var windowTitle: String = ""
        private set

    /** Set by the caller; invoked when the emulator needs to talk back to the device (e.g. a cursor position report). */
    var onResponse: ((ByteArray) -> Unit)? = null

    private enum class State { GROUND, ESC, CSI, OSC, CHARSET }

    private var state = State.GROUND
    private val paramBuf = StringBuilder()
    private var privateMarker = false
    private val oscBuf = StringBuilder()
    private var oscEscPending = false

    private var curFg = TerminalColors.DEFAULT_FG
    private var curBg = TerminalColors.DEFAULT_BG
    private var curBold = false
    private var curUnderline = false
    private var curReverse = false

    private var savedCursorRow = 0
    private var savedCursorCol = 0
    private var pendingWrap = false

    private var utf8Remaining = 0
    private var utf8Codepoint = 0

    fun resize(rows: Int, cols: Int) = buffer.resize(rows, cols)

    fun feed(data: ByteArray, len: Int = data.size) {
        for (i in 0 until len) processByte(data[i].toInt() and 0xFF)
    }

    private fun processByte(b: Int) {
        when (state) {
            State.GROUND -> handleGround(b)
            State.ESC -> handleEsc(b)
            State.CSI -> handleCsi(b)
            State.OSC -> handleOsc(b)
            State.CHARSET -> { state = State.GROUND } // charset designators are accepted but not applied
        }
    }

    // ---- GROUND: plain text + UTF-8 decoding + C0 controls -------------

    private fun handleGround(b: Int) {
        if (utf8Remaining > 0) {
            if (b and 0xC0 == 0x80) {
                utf8Codepoint = (utf8Codepoint shl 6) or (b and 0x3F)
                utf8Remaining--
                if (utf8Remaining == 0) putChar(if (utf8Codepoint in 0..0xFFFF) utf8Codepoint.toChar() else '?')
                return
            } else {
                utf8Remaining = 0 // malformed sequence, fall through and reprocess b fresh
            }
        }
        when {
            b == 0x1B -> state = State.ESC
            b == 0x07 -> { /* BEL - no audible/visual bell wired up */ }
            b == 0x08 -> moveCursor(buffer.cursorRow, buffer.cursorCol - 1)
            b == 0x09 -> tab()
            b == 0x0D -> { buffer.cursorCol = 0; pendingWrap = false }
            b == 0x0A || b == 0x0B || b == 0x0C -> lineFeed()
            b < 0x20 -> { /* other C0 controls ignored */ }
            b < 0x80 -> putChar(b.toChar())
            b and 0xE0 == 0xC0 -> { utf8Codepoint = b and 0x1F; utf8Remaining = 1 }
            b and 0xF0 == 0xE0 -> { utf8Codepoint = b and 0x0F; utf8Remaining = 2 }
            b and 0xF8 == 0xF0 -> { utf8Codepoint = b and 0x07; utf8Remaining = 3 }
            else -> { /* stray continuation byte with no lead byte */ }
        }
    }

    private fun putChar(ch: Char) {
        if (pendingWrap) {
            buffer.cursorCol = 0
            advanceLine()
            pendingWrap = false
        }
        val cell = buffer.screen[buffer.cursorRow][buffer.cursorCol]
        cell.ch = ch
        cell.fg = curFg; cell.bg = curBg
        cell.bold = curBold; cell.underline = curUnderline; cell.reverse = curReverse
        if (buffer.cursorCol == buffer.cols - 1) {
            pendingWrap = true
        } else {
            buffer.cursorCol++
        }
    }

    private fun advanceLine() {
        if (buffer.cursorRow == buffer.scrollBottom) buffer.scrollUpWithinRegion() else buffer.cursorRow++
    }

    private fun reverseLine() {
        if (buffer.cursorRow == buffer.scrollTop) buffer.scrollDownWithinRegion() else buffer.cursorRow--
    }

    private fun lineFeed() = advanceLine()

    private fun tab() {
        val next = ((buffer.cursorCol / 8) + 1) * 8
        buffer.cursorCol = next.coerceAtMost(buffer.cols - 1)
    }

    private fun moveCursor(row: Int, col: Int) {
        buffer.cursorRow = row.coerceIn(0, buffer.rows - 1)
        buffer.cursorCol = col.coerceIn(0, buffer.cols - 1)
        pendingWrap = false
    }

    // ---- ESC ------------------------------------------------------------

    private fun handleEsc(b: Int) {
        when (b.toChar()) {
            '[' -> { state = State.CSI; paramBuf.clear(); privateMarker = false }
            ']' -> { state = State.OSC; oscBuf.clear(); oscEscPending = false }
            '(', ')' -> state = State.CHARSET
            '7' -> { savedCursorRow = buffer.cursorRow; savedCursorCol = buffer.cursorCol; state = State.GROUND }
            '8' -> { moveCursor(savedCursorRow, savedCursorCol); state = State.GROUND }
            'D' -> { advanceLine(); state = State.GROUND }
            'M' -> { reverseLine(); state = State.GROUND }
            'E' -> { buffer.cursorCol = 0; advanceLine(); state = State.GROUND }
            'c' -> { fullReset(); state = State.GROUND }
            else -> state = State.GROUND
        }
    }

    private fun fullReset() {
        buffer.exitAltScreen()
        buffer.clearScreen(2)
        buffer.scrollTop = 0
        buffer.scrollBottom = buffer.rows - 1
        curFg = TerminalColors.DEFAULT_FG; curBg = TerminalColors.DEFAULT_BG
        curBold = false; curUnderline = false; curReverse = false
        cursorVisible = true
        appCursorKeys = false
        moveCursor(0, 0)
    }

    // ---- CSI --------------------------------------------------------------

    private fun handleCsi(b: Int) {
        val c = b.toChar()
        when {
            c == '?' && paramBuf.isEmpty() -> privateMarker = true
            c in '0'..'9' || c == ';' -> paramBuf.append(c)
            c in '\u0020'..'\u002F' -> { /* intermediate bytes (rare); ignored */ }
            else -> {
                val params = if (paramBuf.isEmpty()) emptyList() else paramBuf.split(';').map { it.toIntOrNull() ?: 0 }
                dispatchCsi(c, params, privateMarker)
                state = State.GROUND
            }
        }
    }

    private fun countParam(params: List<Int>, idx: Int): Int = params.getOrNull(idx)?.takeIf { it > 0 } ?: 1
    private fun modeParam(params: List<Int>, idx: Int, default: Int): Int = params.getOrNull(idx) ?: default

    private fun dispatchCsi(finalChar: Char, params: List<Int>, isPrivate: Boolean) {
        when (finalChar) {
            'A' -> moveCursor(buffer.cursorRow - countParam(params, 0), buffer.cursorCol)
            'B' -> moveCursor(buffer.cursorRow + countParam(params, 0), buffer.cursorCol)
            'C' -> moveCursor(buffer.cursorRow, buffer.cursorCol + countParam(params, 0))
            'D' -> moveCursor(buffer.cursorRow, buffer.cursorCol - countParam(params, 0))
            'H', 'f' -> moveCursor(countParam(params, 0) - 1, countParam(params, 1) - 1)
            'G', '`' -> moveCursor(buffer.cursorRow, countParam(params, 0) - 1)
            'd' -> moveCursor(countParam(params, 0) - 1, buffer.cursorCol)
            'J' -> buffer.clearScreen(modeParam(params, 0, 0))
            'K' -> buffer.clearLine(buffer.cursorRow, modeParam(params, 0, 0))
            'L' -> buffer.insertLines(buffer.cursorRow, countParam(params, 0))
            'M' -> buffer.deleteLines(buffer.cursorRow, countParam(params, 0))
            '@' -> buffer.insertChars(buffer.cursorRow, buffer.cursorCol, countParam(params, 0))
            'P' -> buffer.deleteChars(buffer.cursorRow, buffer.cursorCol, countParam(params, 0))
            'S' -> repeat(countParam(params, 0)) { buffer.scrollUpWithinRegion() }
            'T' -> repeat(countParam(params, 0)) { buffer.scrollDownWithinRegion() }
            'r' -> {
                val top = (countParam(params, 0) - 1).coerceIn(0, buffer.rows - 1)
                val bottom = (if (params.size > 1) countParam(params, 1) - 1 else buffer.rows - 1).coerceIn(top, buffer.rows - 1)
                buffer.scrollTop = top; buffer.scrollBottom = bottom
                moveCursor(0, 0)
            }
            's' -> { savedCursorRow = buffer.cursorRow; savedCursorCol = buffer.cursorCol }
            'u' -> moveCursor(savedCursorRow, savedCursorCol)
            'm' -> applySgr(params)
            'n' -> if (modeParam(params, 0, 0) == 6) reportCursorPosition()
            'h' -> setMode(params, isPrivate, true)
            'l' -> setMode(params, isPrivate, false)
            else -> { /* final byte not implemented - safely ignored */ }
        }
    }

    private fun reportCursorPosition() {
        val report = "\u001b[${buffer.cursorRow + 1};${buffer.cursorCol + 1}R".toByteArray(Charsets.US_ASCII)
        onResponse?.invoke(report)
    }

    private fun setMode(params: List<Int>, isPrivate: Boolean, enable: Boolean) {
        if (!isPrivate) return // ANSI (non-DEC) modes such as IRM insert-mode are rarely relied on; skipped
        for (p in params) when (p) {
            1 -> appCursorKeys = enable
            25 -> cursorVisible = enable
            2004 -> bracketedPaste = enable
            47, 1047, 1049 -> if (enable) buffer.enterAltScreen() else buffer.exitAltScreen()
            else -> { /* other DEC private modes not implemented */ }
        }
    }

    private fun applySgr(rawParams: List<Int>) {
        val params = rawParams.ifEmpty { listOf(0) }
        var i = 0
        while (i < params.size) {
            when (val code = params[i]) {
                0 -> { curFg = TerminalColors.DEFAULT_FG; curBg = TerminalColors.DEFAULT_BG; curBold = false; curUnderline = false; curReverse = false }
                1 -> curBold = true
                4 -> curUnderline = true
                7 -> curReverse = true
                22 -> curBold = false
                24 -> curUnderline = false
                27 -> curReverse = false
                in 30..37 -> curFg = TerminalColors.palette[code - 30]
                39 -> curFg = TerminalColors.DEFAULT_FG
                in 40..47 -> curBg = TerminalColors.palette[code - 40]
                49 -> curBg = TerminalColors.DEFAULT_BG
                in 90..97 -> curFg = TerminalColors.palette[8 + (code - 90)]
                in 100..107 -> curBg = TerminalColors.palette[8 + (code - 100)]
                38, 48 -> {
                    val mode = params.getOrNull(i + 1)
                    val resolved: Int?
                    when (mode) {
                        5 -> { resolved = TerminalColors.color256(params.getOrNull(i + 2) ?: 0); i += 2 }
                        2 -> {
                            val r = params.getOrNull(i + 2) ?: 0
                            val g = params.getOrNull(i + 3) ?: 0
                            val bl = params.getOrNull(i + 4) ?: 0
                            resolved = (0xFF shl 24) or (r shl 16) or (g shl 8) or bl
                            i += 4
                        }
                        else -> resolved = null
                    }
                    if (resolved != null) { if (code == 38) curFg = resolved else curBg = resolved }
                }
                else -> { /* unsupported SGR code ignored */ }
            }
            i++
        }
    }

    // ---- OSC (window title etc., terminated by BEL or ESC \\) -----------

    private fun handleOsc(b: Int) {
        if (oscEscPending) {
            oscEscPending = false
            if (b.toChar() == '\\') { finalizeOsc(); return }
            state = State.ESC
            handleEsc(b)
            return
        }
        when (b) {
            0x07 -> finalizeOsc()
            0x1B -> oscEscPending = true
            else -> oscBuf.append(b.toChar())
        }
    }

    private fun finalizeOsc() {
        val text = oscBuf.toString()
        val parts = text.split(';', limit = 2)
        if (parts.size == 2 && (parts[0] == "0" || parts[0] == "2")) windowTitle = parts[1]
        oscBuf.clear()
        state = State.GROUND
    }
}
