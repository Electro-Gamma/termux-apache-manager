package com.uartbridge.terminal.terminal

/** One character cell on the screen, with the SGR attributes active when it was written. */
class Cell(
    var ch: Char = ' ',
    var fg: Int = TerminalColors.DEFAULT_FG,
    var bg: Int = TerminalColors.DEFAULT_BG,
    var bold: Boolean = false,
    var underline: Boolean = false,
    var reverse: Boolean = false,
) {
    fun copyFrom(other: Cell) {
        ch = other.ch; fg = other.fg; bg = other.bg
        bold = other.bold; underline = other.underline; reverse = other.reverse
    }

    fun reset() {
        ch = ' '; fg = TerminalColors.DEFAULT_FG; bg = TerminalColors.DEFAULT_BG
        bold = false; underline = false; reverse = false
    }

    fun clone(): Cell = Cell(ch, fg, bg, bold, underline, reverse)
}

/**
 * A mutable rows x cols grid of [Cell]s plus a capped scrollback history of
 * lines that have scrolled off the top. This is pure data/storage - the
 * escape-sequence interpretation lives in [TerminalEmulator].
 *
 * Supports a secondary "alternate screen" buffer (used by full-screen
 * programs such as vim/htop/less via DECSET 1049) which has no scrollback
 * of its own and is restored to exactly what it was when the program exits.
 */
class TerminalBuffer(var rows: Int, var cols: Int, private val maxScrollback: Int = 3000) {

    var screen: Array<Array<Cell>> = newGrid(rows, cols)
        private set

    private var altScreen: Array<Array<Cell>>? = null
    var usingAltScreen: Boolean = false
        private set

    /** Lines that have scrolled off the top of the primary screen, oldest first. */
    val scrollback: ArrayDeque<Array<Cell>> = ArrayDeque()

    var cursorRow = 0
    var cursorCol = 0

    /** DECSTBM scrolling region, inclusive, 0-based. */
    var scrollTop = 0
    var scrollBottom = rows - 1

    private fun newGrid(r: Int, c: Int): Array<Array<Cell>> =
        Array(r) { Array(c) { Cell() } }

    /**
     * Number of top rows that a shrinking resize pushed into scrollback and
     * that a later growing resize may pull back (so opening and closing the
     * on-screen keyboard restores exactly what was on screen).
     */
    private var pushedByResize = 0

    /**
     * Resizes the grid. When it gets shorter (e.g. the on-screen keyboard
     * opens) the bottom of the screen - the cursor line and the newest
     * output - is kept, and the rows that no longer fit are scrolled into
     * scrollback instead of being cut off. When it grows again those rows
     * are pulled back.
     */
    fun resize(newRows: Int, newCols: Int) {
        if (newRows == rows && newCols == cols) return

        val lines = ArrayList<Array<Cell>>(screen.asList())
        var newCursorRow = cursorRow

        if (newRows < rows) {
            val overflow = (cursorRow + 1 - newRows).coerceAtLeast(0)
            repeat(overflow) {
                val top = lines.removeAt(0)
                if (!usingAltScreen) {
                    scrollback.addLast(top)
                    pushedByResize++
                }
            }
            newCursorRow -= overflow
            while (lines.size > newRows) lines.removeAt(lines.size - 1)
            while (scrollback.size > maxScrollback) scrollback.removeFirst()
        } else if (newRows > rows) {
            var missing = newRows - rows
            if (!usingAltScreen) {
                while (missing > 0 && pushedByResize > 0 && scrollback.isNotEmpty()) {
                    lines.add(0, scrollback.removeLast())
                    newCursorRow++
                    missing--
                    pushedByResize--
                }
            }
            repeat(missing) { lines.add(Array(cols) { Cell() }) }
        }

        screen = Array(newRows) { r -> Array(newCols) { c -> lines[r].getOrNull(c) ?: Cell() } }
        rows = newRows
        cols = newCols
        scrollTop = 0
        scrollBottom = rows - 1
        cursorRow = newCursorRow.coerceIn(0, rows - 1)
        cursorCol = cursorCol.coerceIn(0, cols - 1)
        altScreen?.let {
            altScreen = Array(newRows) { r -> Array(newCols) { c -> if (r < it.size && c < it[0].size) it[r][c] else Cell() } }
        }
    }

    fun enterAltScreen() {
        if (usingAltScreen) return
        altScreen = newGrid(rows, cols)
        val tmp = screen
        screen = altScreen!!
        altScreen = tmp
        usingAltScreen = true
    }

    fun exitAltScreen() {
        if (!usingAltScreen) return
        val tmp = screen
        screen = altScreen!!
        altScreen = tmp
        usingAltScreen = false
    }

    /** Pushes the top row into scrollback (primary screen only) and shifts [scrollTop, scrollBottom] up by one. */
    fun scrollUpWithinRegion() {
        if (scrollTop == 0 && !usingAltScreen) {
            scrollback.addLast(screen[scrollTop])
            while (scrollback.size > maxScrollback) scrollback.removeFirst()
        }
        for (r in scrollTop until scrollBottom) {
            screen[r] = screen[r + 1]
        }
        screen[scrollBottom] = Array(cols) { Cell() }
    }

    fun scrollDownWithinRegion() {
        for (r in scrollBottom downTo scrollTop + 1) {
            screen[r] = screen[r - 1]
        }
        screen[scrollTop] = Array(cols) { Cell() }
    }

    fun insertLines(atRow: Int, count: Int) {
        repeat(count) {
            for (r in scrollBottom downTo atRow + 1) screen[r] = screen[r - 1]
            screen[atRow] = Array(cols) { Cell() }
        }
    }

    fun deleteLines(atRow: Int, count: Int) {
        repeat(count) {
            for (r in atRow until scrollBottom) screen[r] = screen[r + 1]
            screen[scrollBottom] = Array(cols) { Cell() }
        }
    }

    fun clearScreen(mode: Int) {
        when (mode) {
            0 -> { // cursor to end
                clearLine(cursorRow, 0)
                for (r in cursorRow + 1 until rows) clearFullLine(r)
            }
            1 -> { // start to cursor
                for (r in 0 until cursorRow) clearFullLine(r)
                clearLine(cursorRow, 1)
            }
            2, 3 -> { for (r in 0 until rows) clearFullLine(r); pushedByResize = 0 }
        }
    }

    fun clearFullLine(row: Int) {
        for (c in 0 until cols) screen[row][c].reset()
    }

    /** mode 0 = cursor..end of line, 1 = start..cursor, 2 = whole line. */
    fun clearLine(row: Int, mode: Int) {
        val range = when (mode) {
            0 -> cursorCol until cols
            1 -> 0..cursorCol
            else -> 0 until cols
        }
        for (c in range) screen[row][c].reset()
    }

    fun insertChars(row: Int, atCol: Int, count: Int) {
        for (i in 0 until count) {
            for (c in cols - 1 downTo atCol + 1) screen[row][c].copyFrom(screen[row][c - 1])
            if (atCol < cols) screen[row][atCol].reset()
        }
    }

    fun deleteChars(row: Int, atCol: Int, count: Int) {
        for (i in 0 until count) {
            for (c in atCol until cols - 1) screen[row][c].copyFrom(screen[row][c + 1])
            if (cols > 0) screen[row][cols - 1].reset()
        }
    }
}
