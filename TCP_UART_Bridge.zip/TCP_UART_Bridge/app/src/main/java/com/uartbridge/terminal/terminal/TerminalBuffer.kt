package com.uartbridge.terminal.terminal

/** One character cell on the screen, with the SGR attributes active when it was written. */
class Cell(
    var ch: Char = ' ',
    var fg: Int = TerminalColors.DEFAULT_FG,
    var bg: Int = TerminalColors.DEFAULT_BG,
    var bold: Boolean = false,
    var underline: Boolean = false,
    var reverse: Boolean = false,
) {
    fun copyFrom(other: Cell) {
        ch = other.ch; fg = other.fg; bg = other.bg
        bold = other.bold; underline = other.underline; reverse = other.reverse
    }

    fun reset() {
        ch = ' '; fg = TerminalColors.DEFAULT_FG; bg = TerminalColors.DEFAULT_BG
        bold = false; underline = false; reverse = false
    }

    fun clone(): Cell = Cell(ch, fg, bg, bold, underline, reverse)
}

/**
 * A mutable rows x cols grid of [Cell]s plus a capped scrollback history of
 * lines that have scrolled off the top. This is pure data/storage - the
 * escape-sequence interpretation lives in [TerminalEmulator].
 *
 * Supports a secondary "alternate screen" buffer (used by full-screen
 * programs such as vim/htop/less via DECSET 1049) which has no scrollback
 * of its own and is restored to exactly what it was when the program exits.
 */
class TerminalBuffer(var rows: Int, var cols: Int, private val maxScrollback: Int = 3000) {

    var screen: Array<Array<Cell>> = newGrid(rows, cols)
        private set

    private var altScreen: Array<Array<Cell>>? = null
    var usingAltScreen: Boolean = false
        private set

    /** Lines that have scrolled off the top of the primary screen, oldest first. */
    val scrollback: ArrayDeque<Array<Cell>> = ArrayDeque()

    var cursorRow = 0
    var cursorCol = 0

    /** DECSTBM scrolling region, inclusive, 0-based. */
    var scrollTop = 0
    var scrollBottom = rows - 1

    private fun newGrid(r: Int, c: Int): Array<Array<Cell>> =
        Array(r) { Array(c) { Cell() } }

    fun resize(newRows: Int, newCols: Int) {
        if (newRows == rows && newCols == cols) return
        val resized = Array(newRows) { r ->
            Array(newCols) { c ->
                if (r < rows && c < cols) screen[r][c] else Cell()
            }
        }
        screen = resized
        rows = newRows
        cols = newCols
        scrollTop = 0
        scrollBottom = rows - 1
        cursorRow = cursorRow.coerceIn(0, rows - 1)
        cursorCol = cursorCol.coerceIn(0, cols - 1)
        altScreen?.let {
            altScreen = Array(newRows) { r -> Array(newCols) { c -> if (r < it.size && c < it[0].size) it[r][c] else Cell() } }
        }
    }

    fun enterAltScreen() {
        if (usingAltScreen) return
        altScreen = newGrid(rows, cols)
        val tmp = screen
        screen = altScreen!!
        altScreen = tmp
        usingAltScreen = true
    }

    fun exitAltScreen() {
        if (!usingAltScreen) return
        val tmp = screen
        screen = altScreen!!
        altScreen = tmp
        usingAltScreen = false
    }

    /** Pushes the top row into scrollback (primary screen only) and shifts [scrollTop, scrollBottom] up by one. */
    fun scrollUpWithinRegion() {
        if (scrollTop == 0 && !usingAltScreen) {
            scrollback.addLast(screen[scrollTop])
            while (scrollback.size > maxScrollback) scrollback.removeFirst()
        }
        for (r in scrollTop until scrollBottom) {
            screen[r] = screen[r + 1]
        }
        screen[scrollBottom] = Array(cols) { Cell() }
    }

    fun scrollDownWithinRegion() {
        for (r in scrollBottom downTo scrollTop + 1) {
            screen[r] = screen[r - 1]
        }
        screen[scrollTop] = Array(cols) { Cell() }
    }

    fun insertLines(atRow: Int, count: Int) {
        repeat(count) {
            for (r in scrollBottom downTo atRow + 1) screen[r] = screen[r - 1]
            screen[atRow] = Array(cols) { Cell() }
        }
    }

    fun deleteLines(atRow: Int, count: Int) {
        repeat(count) {
            for (r in atRow until scrollBottom) screen[r] = screen[r + 1]
            screen[scrollBottom] = Array(cols) { Cell() }
        }
    }

    fun clearScreen(mode: Int) {
        when (mode) {
            0 -> { // cursor to end
                clearLine(cursorRow, 0)
                for (r in cursorRow + 1 until rows) clearFullLine(r)
            }
            1 -> { // start to cursor
                for (r in 0 until cursorRow) clearFullLine(r)
                clearLine(cursorRow, 1)
            }
            2, 3 -> for (r in 0 until rows) clearFullLine(r)
        }
    }

    fun clearFullLine(row: Int) {
        for (c in 0 until cols) screen[row][c].reset()
    }

    /** mode 0 = cursor..end of line, 1 = start..cursor, 2 = whole line. */
    fun clearLine(row: Int, mode: Int) {
        val range = when (mode) {
            0 -> cursorCol until cols
            1 -> 0..cursorCol
            else -> 0 until cols
        }
        for (c in range) screen[row][c].reset()
    }

    fun insertChars(row: Int, atCol: Int, count: Int) {
        for (i in 0 until count) {
            for (c in cols - 1 downTo atCol + 1) screen[row][c].copyFrom(screen[row][c - 1])
            if (atCol < cols) screen[row][atCol].reset()
        }
    }

    fun deleteChars(row: Int, atCol: Int, count: Int) {
        for (i in 0 until count) {
            for (c in atCol until cols - 1) screen[row][c].copyFrom(screen[row][c + 1])
            if (cols > 0) screen[row][cols - 1].reset()
        }
    }
}
