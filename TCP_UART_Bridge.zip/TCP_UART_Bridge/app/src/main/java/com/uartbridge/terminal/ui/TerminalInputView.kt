package com.uartbridge.terminal.ui

import android.content.Context
import android.text.InputType
import android.view.KeyCharacterMap
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.BaseInputConnection
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputMethodManager

/**
 * The terminal's keyboard receiver. It is an invisible view that talks to the
 * soft keyboard through a custom [InputConnection] which is deliberately
 * *stateless*: it never stores, exposes or lets the keyboard edit any text.
 *
 * Every character the keyboard commits is forwarded to the serial port
 * immediately and then forgotten. Nothing typed earlier (a username, a
 * password, a previous command) can therefore stay "editable" inside the
 * keyboard or be replayed/autocorrected by it - only the shell's own current
 * input line, which lives on the other end of the UART, can be edited.
 *
 * The keyboard is also told to show a plain Return/Enter key (no Send/Done/Go
 * action) and to turn off suggestions/autocorrect/composition.
 */
class TerminalInputView(context: Context) : View(context) {

    /** Printable text that should be written to the port. Never contains CR/LF. */
    var onTextInput: (String) -> Unit = {}

    /** Number of Backspace presses to send. */
    var onBackspace: (Int) -> Unit = {}

    /** Return/Enter was pressed (or a newline was committed). */
    var onEnter: () -> Unit = {}

    /** First chance for special keys (arrows, Ctrl combos, Enter, ...); return true if consumed. */
    var onSpecialKey: (KeyEvent) -> Boolean = { false }

    init {
        isFocusable = true
        isFocusableInTouchMode = true
    }

    fun showKeyboard() {
        if (!isAttachedToWindow) return
        requestFocus()
        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showSoftInput(this, 0)
    }

    override fun onCheckIsTextEditor(): Boolean = true

    override fun onCreateInputConnection(outAttrs: EditorInfo): InputConnection {
        // Visible-password + no-suggestions makes keyboards commit each key
        // straight away (no predictive/composing text, no autocorrect, no
        // auto-capitalisation). MULTI_LINE + NO_ENTER_ACTION + ACTION_NONE
        // makes the action key a plain Return/Enter instead of Send/Done/Go.
        outAttrs.inputType = InputType.TYPE_CLASS_TEXT or
            InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD or
            InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS or
            InputType.TYPE_TEXT_FLAG_MULTI_LINE
        outAttrs.imeOptions = EditorInfo.IME_ACTION_NONE or
            EditorInfo.IME_FLAG_NO_ENTER_ACTION or
            EditorInfo.IME_FLAG_NO_FULLSCREEN or
            EditorInfo.IME_FLAG_NO_EXTRACT_UI
        // Tell the keyboard there is no text before the cursor, so Backspace
        // arrives as a real DEL key event and it never tries to "re-edit"
        // earlier words.
        outAttrs.initialSelStart = 0
        outAttrs.initialSelEnd = 0
        return TerminalInputConnection()
    }

    // ---- hardware keyboards / IMEs that dispatch raw key events ---------

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean =
        if (handleKeyDown(event)) true else super.onKeyDown(keyCode, event)

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean =
        if (isTerminalKey(event)) true else super.onKeyUp(keyCode, event)

    private fun isTerminalKey(event: KeyEvent): Boolean =
        event.keyCode != KeyEvent.KEYCODE_BACK && (event.unicodeChar != 0 || isSpecialKeyCode(event.keyCode))

    private fun isSpecialKeyCode(code: Int): Boolean = when (code) {
        KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER, KeyEvent.KEYCODE_DEL,
        KeyEvent.KEYCODE_FORWARD_DEL, KeyEvent.KEYCODE_TAB, KeyEvent.KEYCODE_ESCAPE,
        KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_LEFT,
        KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_MOVE_HOME, KeyEvent.KEYCODE_MOVE_END,
        KeyEvent.KEYCODE_PAGE_UP, KeyEvent.KEYCODE_PAGE_DOWN -> true
        else -> code in KeyEvent.KEYCODE_F1..KeyEvent.KEYCODE_F12
    }

    private fun handleKeyDown(event: KeyEvent): Boolean {
        if (event.keyCode == KeyEvent.KEYCODE_BACK) return false
        if (onSpecialKey(event)) return true
        val unicode = event.unicodeChar
        if (unicode != 0 &&
            (unicode and KeyCharacterMap.COMBINING_ACCENT) == 0 &&
            !event.isCtrlPressed
        ) {
            emitText(StringBuilder().appendCodePoint(unicode).toString())
            return true
        }
        return false
    }

    /** Forwards text to the port, turning any CR/LF into an Enter press. */
    private fun emitText(text: String) {
        val chunk = StringBuilder()
        for (ch in text) {
            if (ch == '\n' || ch == '\r') {
                if (chunk.isNotEmpty()) {
                    onTextInput(chunk.toString())
                    chunk.setLength(0)
                }
                onEnter()
            } else {
                chunk.append(ch)
            }
        }
        if (chunk.isNotEmpty()) onTextInput(chunk.toString())
    }

    /**
     * Input connection that forwards and forgets. The only thing it tracks is
     * the keyboard's *current* composing word (if a keyboard insists on
     * composing) so that revisions of that one word are sent as
     * backspace + replacement; it is cleared as soon as the word is committed.
     */
    private inner class TerminalInputConnection : BaseInputConnection(this@TerminalInputView, false) {

        private var composing = ""

        private fun replaceComposing(newText: String) {
            val max = minOf(composing.length, newText.length)
            var prefix = 0
            while (prefix < max && composing[prefix] == newText[prefix]) prefix++
            if (composing.length > prefix) onBackspace(composing.length - prefix)
            if (newText.length > prefix) emitText(newText.substring(prefix))
        }

        override fun commitText(text: CharSequence?, newCursorPosition: Int): Boolean {
            replaceComposing(text?.toString().orEmpty())
            composing = ""
            return true
        }

        override fun setComposingText(text: CharSequence?, newCursorPosition: Int): Boolean {
            val newText = text?.toString().orEmpty()
            if (newText.any { it == '\n' || it == '\r' }) {
                // A newline can't be "composing" - treat it as committed input.
                replaceComposing(newText)
                composing = ""
            } else {
                replaceComposing(newText)
                composing = newText
            }
            return true
        }

        override fun finishComposingText(): Boolean {
            composing = ""
            return true
        }

        override fun setComposingRegion(start: Int, end: Int): Boolean = true

        override fun deleteSurroundingText(beforeLength: Int, afterLength: Int): Boolean {
            if (beforeLength > 0) onBackspace(beforeLength)
            composing = composing.dropLast(beforeLength)
            return true
        }

        override fun deleteSurroundingTextInCodePoints(beforeLength: Int, afterLength: Int): Boolean =
            deleteSurroundingText(beforeLength, afterLength)

        override fun sendKeyEvent(event: KeyEvent): Boolean {
            composing = ""
            when (event.action) {
                KeyEvent.ACTION_DOWN -> handleKeyDown(event)
                KeyEvent.ACTION_MULTIPLE ->
                    if (event.keyCode == KeyEvent.KEYCODE_UNKNOWN) event.characters?.let { emitText(it) }
            }
            return true
        }

        override fun performEditorAction(editorAction: Int): Boolean {
            composing = ""
            onEnter()
            return true
        }

        // The keyboard must never be shown any text, so it has nothing to edit.
        override fun getTextBeforeCursor(n: Int, flags: Int): CharSequence = ""
        override fun getTextAfterCursor(n: Int, flags: Int): CharSequence = ""
        override fun getSelectedText(flags: Int): CharSequence? = null
    }
}
