package com.tcpuartbridge.app.ch341

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import android.os.Build

/**
 * Raw USB transport for the CH341A chip running in its "parallel/EPP" (a.k.a. programmer) mode -
 * the mode used by the ubiquitous black/green "CH341A" USB EEPROM/SPI-flash programmer boards.
 *
 * This is a completely different USB personality from the CH340/CH341 *serial* mode that
 * [com.tcpuartbridge.app.UsbSerialManager] / usb-serial-for-android already talk to elsewhere in
 * this app: in programmer mode the chip enumerates at VID 0x1A86 / PID 0x5512 with a single
 * vendor-specific interface (no CDC-ACM at all), so it needs its own permission flow, its own
 * open/claim-interface dance, and its own bulk-transfer plumbing rather than a serial port.
 * (A CH340/CH341 wired for plain UART mode - the boards this app already bridges - enumerates as
 * PID 0x7523 and never shows up here; the two modes are mutually exclusive per physical chip.)
 *
 * This class only knows how to find the device, get permission, open it, and move raw bytes over
 * bulk endpoints 0x02 (OUT) / 0x82 (IN). The actual CH341A command protocol (SPI stream, I2C
 * stream, UIO stream) lives in [Ch341Spi] and [Ch341I2c], ported from flashrom's ch341a_spi.c and
 * IMSProg's ch34x_i2c.c (GPLv2/GPLv3 - see NOTICE.md at the repo root).
 */
class Ch341UsbDevice(private val context: Context) {

    private val usbManager: UsbManager =
        context.getSystemService(Context.USB_SERVICE) as UsbManager

    var device: UsbDevice? = null
        private set

    private var connection: UsbDeviceConnection? = null
    private var iface: UsbInterface? = null
    private var epOut: UsbEndpoint? = null
    private var epIn: UsbEndpoint? = null

    val isOpen: Boolean get() = connection != null

    /** The first attached CH341A running in programmer (not UART) mode, if any. */
    fun findDevice(): UsbDevice? =
        usbManager.deviceList.values.firstOrNull {
            it.vendorId == VENDOR_ID && it.productId == PRODUCT_ID_PROGRAMMER
        }

    fun hasPermission(dev: UsbDevice): Boolean = usbManager.hasPermission(dev)

    /**
     * Requests USB permission for [dev] and calls [callback] with the result. Mirrors
     * MainActivity's requestUsbPermission() for the serial path - same broadcast-receiver
     * dance, just against a plain [UsbDevice] instead of a usb-serial-for-android driver.
     */
    fun requestPermission(dev: UsbDevice, callback: (Boolean) -> Unit) {
        val action = "com.tcpuartbridge.app.CH341_USB_PERMISSION"
        val mutabilityFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0
        val permissionIntent = PendingIntent.getBroadcast(
            context, 0, Intent(action).setPackage(context.packageName), mutabilityFlag
        )
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context, intent: Intent) {
                if (intent.action == action) {
                    context.unregisterReceiver(this)
                    callback(intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false))
                }
            }
        }
        val filter = IntentFilter(action)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            context.registerReceiver(receiver, filter)
        }
        usbManager.requestPermission(dev, permissionIntent)
    }

    /** Opens [dev], claims interface 0, and locates the bulk IN/OUT endpoints. */
    fun open(dev: UsbDevice): Boolean {
        close()
        val conn = usbManager.openDevice(dev) ?: return false
        if (dev.interfaceCount == 0) {
            conn.close()
            return false
        }
        val intf = dev.getInterface(0)
        if (!conn.claimInterface(intf, true)) {
            conn.close()
            return false
        }
        var out: UsbEndpoint? = null
        var inn: UsbEndpoint? = null
        for (i in 0 until intf.endpointCount) {
            val ep = intf.getEndpoint(i)
            if (ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK) {
                if (ep.direction == UsbConstants.USB_DIR_OUT) out = ep
                if (ep.direction == UsbConstants.USB_DIR_IN) inn = ep
            }
        }
        if (out == null || inn == null) {
            conn.releaseInterface(intf)
            conn.close()
            return false
        }
        device = dev
        connection = conn
        iface = intf
        epOut = out
        epIn = inn
        return true
    }

    fun close() {
        try {
            iface?.let { connection?.releaseInterface(it) }
        } catch (_: Exception) {
        }
        try {
            connection?.close()
        } catch (_: Exception) {
        }
        connection = null
        iface = null
        epOut = null
        epIn = null
        device = null
    }

    /** Sends [data] as a single bulk OUT transfer. Returns true iff every byte was accepted. */
    fun bulkOut(data: ByteArray, timeoutMs: Int = USB_TIMEOUT_MS): Boolean {
        val conn = connection ?: return false
        val ep = epOut ?: return false
        if (data.isEmpty()) return true
        val n = conn.bulkTransfer(ep, data, data.size, timeoutMs)
        return n == data.size
    }

    /**
     * Reads exactly [total] bytes from the bulk IN endpoint, looping over as many physical
     * transfers as needed (the CH341A answers in chunks tied to its own internal packet framing,
     * not necessarily all at once). Returns null on error/timeout.
     */
    fun readExactly(total: Int, timeoutMs: Int = USB_TIMEOUT_MS): ByteArray? {
        if (total <= 0) return ByteArray(0)
        val conn = connection ?: return null
        val ep = epIn ?: return null
        val out = ByteArray(total)
        var received = 0
        val chunkSize = maxOf(ep.maxPacketSize, 1)
        val chunkBuf = ByteArray(chunkSize)
        var emptyReads = 0
        while (received < total) {
            val want = minOf(chunkSize, total - received)
            val n = conn.bulkTransfer(ep, chunkBuf, want, timeoutMs)
            if (n < 0) return null
            if (n == 0) {
                emptyReads++
                if (emptyReads > 20) return null
                continue
            }
            emptyReads = 0
            System.arraycopy(chunkBuf, 0, out, received, n)
            received += n
        }
        return out
    }

    fun deviceLabel(): String {
        val dev = device ?: return "CH341A"
        return "CH341A programmer (VID:${dev.vendorId} PID:${dev.productId})"
    }

    companion object {
        const val VENDOR_ID = 0x1A86
        const val PRODUCT_ID_PROGRAMMER = 0x5512
        const val USB_TIMEOUT_MS = 3000
    }
}
