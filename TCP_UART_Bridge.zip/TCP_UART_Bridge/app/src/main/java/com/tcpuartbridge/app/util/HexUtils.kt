package com.tcpuartbridge.app.util

import java.util.zip.CRC32

/**
 * Small, stateless helpers shared by the Hex Compare tab (CRC32 + byte-length formatting) and the
 * Find/Replace dialog (query parsing + byte-pattern search) - see [MainActivity]'s
 * `showFindReplaceDialog` / `refreshEepromCompare` / `refreshSpiCompare` for where these are used.
 * Kept out of [HexEditorAdapter] itself since none of this needs a live buffer or a RecyclerView.
 */
object HexUtils {

    /** 8-hex-digit CRC32 of [data], e.g. "0A1B2C3D" - matches the reference design's Compare tab. */
    fun crc32Hex(data: ByteArray): String {
        val crc = CRC32()
        crc.update(data)
        return "%08X".format(crc.value)
    }

    /** 32-hex-digit MD5 of [data], e.g. "0a1b2c3d...". The reference HTML hand-rolls MD5 in JS
     *  since browsers don't expose it via Web Crypto - the JVM has it built in, so this is just
     *  [java.security.MessageDigest], not a port of that JS. */
    fun md5Hex(data: ByteArray): String {
        val digest = java.security.MessageDigest.getInstance("MD5").digest(data)
        return digest.joinToString("") { "%02x".format(it) }
    }

    /** Shannon entropy of [data] in bits/byte (0 = all one value, 8 = perfectly uniform) - a quick
     *  "does this look like real firmware, or random/encrypted noise" signal for the File Info tab. */
    fun shannonEntropy(data: ByteArray): Double {
        if (data.isEmpty()) return 0.0
        val counts = IntArray(256)
        for (b in data) counts[b.toInt() and 0xFF]++
        var h = 0.0
        for (c in counts) {
            if (c == 0) continue
            val p = c.toDouble() / data.size
            h -= p * (Math.log(p) / Math.log(2.0))
        }
        return h
    }

    /** Qualitative label for an entropy value, shown next to the number in the File Info tab. */
    fun entropyLabel(entropy: Double): String = when {
        entropy < 2 -> "very low - repetitive/padded"
        entropy < 5 -> "low-medium"
        entropy < 7 -> "medium-high"
        else -> "high - likely encrypted"
    }

    /** One printable-ASCII run found in a buffer, and where it starts - like one line of output
     *  from the Unix `strings` command. */
    data class DetectedString(val text: String, val offset: Int)

    /** Every run of at least [minLen] consecutive printable-ASCII bytes (0x20-0x7E) in [data],
     *  in order - the same scan the reference HTML's `extractAsciiStrings()` does. */
    fun extractAsciiStrings(data: ByteArray, minLen: Int = 4): List<DetectedString> {
        val out = mutableListOf<DetectedString>()
        val cur = StringBuilder()
        var startOff = 0
        for (i in 0..data.size) {
            val b = if (i < data.size) data[i].toInt() and 0xFF else -1
            if (b in 0x20..0x7E) {
                if (cur.isEmpty()) startOff = i
                cur.append(b.toChar())
            } else {
                if (cur.length >= minLen) out.add(DetectedString(cur.toString(), startOff))
                cur.clear()
            }
        }
        return out
    }

    /** Result of [detectInfo]: the printable strings found in a buffer, sorted into the same
     *  categories the reference HTML's File Info tab shows - first match wins each category (in
     *  scan order), everything else falls into [other]. */
    data class DetectedInfo(
        val version: DetectedString?,
        val mac: DetectedString?,
        val ip: DetectedString?,
        val password: DetectedString?,
        val other: List<DetectedString>
    )

    private val MAC_RE = Regex("^[0-9A-Fa-f]{2}([:-][0-9A-Fa-f]{2}){5}$")
    private val IP_RE = Regex("^(?:(?:25[0-5]|2[0-4]\\d|1?\\d?\\d)\\.){3}(?:25[0-5]|2[0-4]\\d|1?\\d?\\d)$")
    private val VERSION_RE = Regex("\\bv?\\d+\\.\\d+(?:\\.\\d+)?\\b", RegexOption.IGNORE_CASE)
    private val PASSWORD_RE = Regex("pass\\w*|pwd|secret", RegexOption.IGNORE_CASE)

    /** Heuristically classifies every printable string in [data] - like a firmware-aware `strings`
     *  command - into a MAC address, IP address, password-looking value, version-looking value, or
     *  "other", same rules (and same priority order: MAC, then IP, then password, then version)
     *  as the reference HTML's `detectInfo()`. */
    fun detectInfo(data: ByteArray, minLen: Int = 4): DetectedInfo {
        var version: DetectedString? = null
        var mac: DetectedString? = null
        var ip: DetectedString? = null
        var password: DetectedString? = null
        val other = mutableListOf<DetectedString>()

        for (s in extractAsciiStrings(data, minLen)) {
            when {
                mac == null && MAC_RE.matches(s.text) -> mac = s
                ip == null && IP_RE.matches(s.text) -> ip = s
                password == null && PASSWORD_RE.containsMatchIn(s.text) -> password = s
                version == null && VERSION_RE.containsMatchIn(s.text) -> version = s
                else -> other.add(s)
            }
        }
        return DetectedInfo(version, mac, ip, password, other)
    }

    /** "0x" + [offset] as 8 uppercase hex digits (growing for a hypothetically larger offset),
     *  matching the Find/Replace dialog's status line ("Found @ 0x00000020"). */
    fun fmtAddr(offset: Int): String = "0x" + Integer.toHexString(offset).uppercase().padStart(8, '0')

    /** Result of [parseQueryBytes]: either the parsed pattern, or a short reason it failed - shown
     *  directly in the Find/Replace dialog's status line either way. */
    sealed class QueryResult {
        data class Ok(val bytes: ByteArray) : QueryResult()
        data class Err(val message: String) : QueryResult()
    }

    /**
     * Parses the Find/Replace dialog's query field into raw bytes, according to whichever encoding
     * is selected in that field's own dropdown ("UTF-8", "Hex", "ASCII", "Decimal") - the same four
     * encodings (and the same parsing rules) as the reference design's HTML tool.
     */
    fun parseQueryBytes(value: String, encoding: String): QueryResult {
        if (value.isBlank()) return QueryResult.Err("Enter query")
        return when (encoding) {
            "Hex" -> {
                val cleaned = value.replace(Regex("0x", RegexOption.IGNORE_CASE), "")
                    .replace(Regex("[^0-9a-fA-F]"), "")
                if (cleaned.isEmpty()) return QueryResult.Err("Invalid hex")
                if (cleaned.length % 2 != 0) return QueryResult.Err("Invalid hex (odd digits)")
                val bytes = ByteArray(cleaned.length / 2) { i ->
                    cleaned.substring(i * 2, i * 2 + 2).toInt(16).toByte()
                }
                QueryResult.Ok(bytes)
            }
            "Decimal" -> {
                val parts = value.trim().split(Regex("[\\s,]+")).filter { it.isNotEmpty() }
                val out = ByteArray(parts.size)
                for ((i, p) in parts.withIndex()) {
                    val n = p.toIntOrNull() ?: return QueryResult.Err("Invalid decimal (0-255)")
                    if (n < 0 || n > 255) return QueryResult.Err("Invalid decimal (0-255)")
                    out[i] = n.toByte()
                }
                QueryResult.Ok(out)
            }
            "ASCII" -> QueryResult.Ok(ByteArray(value.length) { i -> (value[i].code and 0xFF).toByte() })
            else -> QueryResult.Ok(value.toByteArray(Charsets.UTF_8)) // "UTF-8"
        }
    }

    /** First index at/after [fromIndex] where [pattern] occurs in [haystack], or -1. No wraparound -
     *  callers that want wraparound (see the Find dialog) retry once from 0 themselves. */
    fun indexOfBytes(haystack: ByteArray, pattern: ByteArray, fromIndex: Int): Int {
        val n = haystack.size
        val m = pattern.size
        if (m == 0 || fromIndex > n - m) return -1
        var i = maxOf(0, fromIndex)
        while (i <= n - m) {
            var match = true
            var j = 0
            while (j < m) {
                if (haystack[i + j] != pattern[j]) { match = false; break }
                j++
            }
            if (match) return i
            i++
        }
        return -1
    }

    /** Backwards counterpart of [indexOfBytes] - last index at/before [fromIndex] where [pattern]
     *  occurs. No wraparound, same convention as [indexOfBytes]. */
    fun lastIndexOfBytes(haystack: ByteArray, pattern: ByteArray, fromIndex: Int): Int {
        val n = haystack.size
        val m = pattern.size
        if (m == 0) return -1
        var i = minOf(fromIndex, n - m)
        while (i >= 0) {
            var match = true
            var j = 0
            while (j < m) {
                if (haystack[i + j] != pattern[j]) { match = false; break }
                j++
            }
            if (match) return i
            i--
        }
        return -1
    }
}
