package com.tcpuartbridge.app.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.tcpuartbridge.app.R

/**
 * Formats [data] as a classic offset/hex/ASCII dump - the same information IMSProg's hex editor
 * shows, just as a single scrollable text column rather than a grid widget, which is both
 * simpler to build and cheap to keep smooth on a phone for multi-megabyte SPI flash dumps: each
 * row's text is built lazily in [onBindViewHolder], so only the ~15-20 rows actually on screen
 * are ever formatted at once no matter how big [data] is.
 */
class HexDumpAdapter(private val data: ByteArray, private val bytesPerRow: Int = 8) :
    RecyclerView.Adapter<HexDumpAdapter.RowHolder>() {

    class RowHolder(val text: TextView) : RecyclerView.ViewHolder(text)

    override fun getItemCount(): Int = (data.size + bytesPerRow - 1) / bytesPerRow

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_hex_row, parent, false) as TextView
        return RowHolder(view)
    }

    override fun onBindViewHolder(holder: RowHolder, position: Int) {
        val offset = position * bytesPerRow
        val end = minOf(offset + bytesPerRow, data.size)
        val sb = StringBuilder(10 + bytesPerRow * 3 + 2 + bytesPerRow)

        sb.append(String.format("%08X", offset)).append("  ")
        for (i in offset until offset + bytesPerRow) {
            if (i < end) sb.append(String.format("%02X ", data[i])) else sb.append("   ")
        }
        sb.append(' ')
        for (i in offset until end) {
            val b = data[i].toInt() and 0xFF
            sb.append(if (b in 0x20..0x7E) b.toChar() else '.')
        }
        holder.text.text = sb.toString()
    }
}
