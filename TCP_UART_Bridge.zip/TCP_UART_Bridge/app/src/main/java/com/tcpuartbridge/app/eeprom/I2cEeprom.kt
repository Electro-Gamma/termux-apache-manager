package com.tcpuartbridge.app.eeprom

import com.tcpuartbridge.app.ch341.Ch341I2c

/**
 * Reads and writes 24Cxx-family I2C EEPROMs over a [Ch341I2c] bus. The device-address encoding
 * (the [Chip.algorithm] byte and how it folds extra address bits into the 7-bit device-address
 * byte) is ported from IMSProg's `ch34xi2cBlockRead`/`ch34xi2cBlockWrite` (GPLv3; see NOTICE.md
 * at the repo root) - it's the standard trick 24Cxx parts above 16Kbit use, since a 7-bit device
 * address plus a 1-2 byte word address can't otherwise reach every byte on the larger chips.
 */
class I2cEeprom(private val i2c: Ch341I2c) {

    /**
     * @param algorithm low nibble = number of word-address bytes (1 or 2); high nibble = bitmask
     *   of extra top address bits folded into the device-address byte (0 for chips whose word
     *   address alone covers the whole array).
     */
    data class Chip(
        val name: String,
        val totalBytes: Int,
        val pageSize: Int,
        val algorithm: Int,
        val baseAddr7: Int = 0x50 // standard 24Cxx base address (1010xxx)
    )

    /** Per-transaction cap: matches ch34xi2cBlockRead/Write's 16-byte cap for the CH341A. */
    private val stepSize = 16

    private fun addrBytesOf(algorithm: Int) = algorithm and 0x0F
    private fun blockMaskOf(algorithm: Int) = (algorithm shr 4) and 0x0F

    /** Builds the (deviceAddressByte, wordAddressBytes) pair for [address] per [chip]'s algorithm. */
    private fun addressFor(chip: Chip, address: Int): Pair<Int, ByteArray> {
        val addrBytes = addrBytesOf(chip.algorithm)
        val mask = blockMaskOf(chip.algorithm)
        return if (addrBytes <= 1) {
            val hiBits = (address ushr 8) and mask
            val devAddr = (hiBits shl 1) or (chip.baseAddr7 shl 1)
            devAddr to byteArrayOf((address and 0xFF).toByte())
        } else {
            val hiBits = (address ushr 16) and mask
            val devAddr = (hiBits shl 1) or (chip.baseAddr7 shl 1)
            devAddr to byteArrayOf(((address ushr 8) and 0xFF).toByte(), (address and 0xFF).toByte())
        }
    }

    /**
     * Reads [length] bytes starting at [startAddress]. [onProgress] is called after each
     * internal chunk with (bytesDoneSoFar, totalBytes). Returns null on the first USB failure.
     */
    fun read(chip: Chip, startAddress: Int, length: Int, onProgress: ((Int, Int) -> Unit)? = null): ByteArray? {
        val out = ByteArray(length)
        var offset = 0
        while (offset < length) {
            val n = minOf(stepSize, length - offset)
            val address = startAddress + offset
            val (devAddr, wordAddr) = addressFor(chip, address)
            val resp = i2c.transaction(
                listOf(
                    Ch341I2c.Phase.Write(byteArrayOf(devAddr.toByte()) + wordAddr),
                    Ch341I2c.Phase.RepeatStart,
                    Ch341I2c.Phase.Write(byteArrayOf((devAddr or 1).toByte())),
                    Ch341I2c.Phase.Read(n)
                )
            ) ?: return null
            System.arraycopy(resp, 0, out, offset, n)
            offset += n
            onProgress?.invoke(offset, length)
        }
        return out
    }

    /**
     * Writes [data] starting at [startAddress], respecting [Chip.pageSize] page boundaries (a
     * write may not cross one) and waiting out each chip's internal write cycle between chunks.
     * Returns false on the first USB failure.
     */
    fun write(chip: Chip, startAddress: Int, data: ByteArray, onProgress: ((Int, Int) -> Unit)? = null): Boolean {
        var offset = 0
        while (offset < data.size) {
            val address = startAddress + offset
            val bytesLeftInPage = chip.pageSize - (address % chip.pageSize)
            val n = minOf(stepSize, bytesLeftInPage, data.size - offset)
            val (devAddr, wordAddr) = addressFor(chip, address)
            val chunk = byteArrayOf(devAddr.toByte()) + wordAddr + data.copyOfRange(offset, offset + n)
            if (i2c.transaction(listOf(Ch341I2c.Phase.Write(chunk))) == null) return false
            // 24Cxx parts need a few ms to finish their internal write cycle before the next access.
            i2c.delayMs(10)
            offset += n
            onProgress?.invoke(offset, data.size)
        }
        return true
    }

    companion object {
        /** Common 24Cxx presets. Pick "Custom" in the UI for anything not listed here. */
        val COMMON_CHIPS = listOf(
            Chip("24C01 (128 B)", 128, 8, 0x01),
            Chip("24C02 (256 B)", 256, 8, 0x01),
            Chip("24C04 (512 B)", 512, 16, 0x11),
            Chip("24C08 (1 KB)", 1024, 16, 0x31),
            Chip("24C16 (2 KB)", 2048, 16, 0x71),
            Chip("24C32 (4 KB)", 4096, 32, 0x02),
            Chip("24C64 (8 KB)", 8192, 32, 0x02),
            Chip("24C128 (16 KB)", 16384, 64, 0x02),
            Chip("24C256 (32 KB)", 32768, 64, 0x02),
            Chip("24C512 (64 KB)", 65536, 128, 0x02),
            Chip("24C1024 (128 KB)", 131072, 128, 0x02)
        )
    }
}
