package com.tcpuartbridge.app.ui

import android.graphics.Paint
import android.graphics.Typeface
import android.util.TypedValue
import android.view.Gravity
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.tcpuartbridge.app.R

/**
 * An editable hex+ASCII grid over a mutable byte buffer - offset | hex bytes | ASCII, styled as a
 * black-background/green-text "hex matrix" viewport rather than picking up the surrounding card's
 * (possibly light, possibly dark) surface color. Both the hex cells and the ASCII cells are
 * individually tappable: [onByteTapped] fires for a hex cell (caller shows a 2-digit hex entry
 * dialog), [onAsciiTapped] fires for an ASCII cell (caller shows a single-character entry dialog);
 * either way the caller commits the edit via [setByte].
 *
 * [bytesPerRow] is fixed for the lifetime of one adapter instance - it's meant to be computed
 * once via [computeBytesPerRow] against the hosting RecyclerView's actual measured width (see
 * MainActivity), so the grid exactly fills the screen with no leftover and never needs horizontal
 * scrolling, and the adapter recreated (via [MainActivity]) rather than mutated if that width
 * ever changes, since every row's view holder is built with exactly [bytesPerRow] child cells.
 *
 * Rows are only ever built into views for what's on screen (RecyclerView recycling), so this
 * stays smooth over a multi-megabyte SPI flash buffer - creating per-byte TextViews happens once
 * per recycled row holder (~20-30 total on a typical screen), not once per row.
 */
class HexEditorAdapter(
    private var data: ByteArray,
    val bytesPerRow: Int,
    private val onByteTapped: (offset: Int) -> Unit,
    private val onAsciiTapped: (offset: Int) -> Unit
) : RecyclerView.Adapter<HexEditorAdapter.RowHolder>() {

    private var offsetDigits = offsetDigitsFor(data.size)

    class RowHolder(
        root: LinearLayout,
        val offset: TextView,
        val hexContainer: LinearLayout,
        val asciiContainer: LinearLayout
    ) : RecyclerView.ViewHolder(root) {
        val hexCells = mutableListOf<TextView>()
        val asciiCells = mutableListOf<TextView>()
    }

    override fun getItemCount(): Int = (data.size + bytesPerRow - 1) / bytesPerRow

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowHolder {
        val ctx = parent.context
        val root = LayoutInflater.from(ctx).inflate(R.layout.item_hex_row, parent, false) as LinearLayout
        val offset = root.findViewById<TextView>(R.id.tvHexOffset)
        val hexContainer = root.findViewById<LinearLayout>(R.id.llHexBytes)
        val asciiContainer = root.findViewById<LinearLayout>(R.id.llHexAscii)
        val holder = RowHolder(root, offset, hexContainer, asciiContainer)

        val density = ctx.resources.displayMetrics.density
        val hexCellWidthPx = (HEX_CELL_WIDTH_DP * density).toInt()
        val asciiCellWidthPx = (ASCII_CELL_WIDTH_DP * density).toInt()
        val hexColor = ctx.getColor(R.color.hex_byte)
        val asciiColor = ctx.getColor(R.color.hex_ascii)
        val bg = TypedValue()
        ctx.theme.resolveAttribute(android.R.attr.selectableItemBackground, bg, true)

        repeat(bytesPerRow) { i ->
            val hexCell = TextView(ctx).apply {
                layoutParams = LinearLayout.LayoutParams(hexCellWidthPx, LinearLayout.LayoutParams.WRAP_CONTENT)
                gravity = Gravity.CENTER
                typeface = Typeface.MONOSPACE
                textSize = HEX_TEXT_SIZE_SP
                setTextColor(hexColor)
                isClickable = true
                isFocusable = true
                if (bg.resourceId != 0) setBackgroundResource(bg.resourceId)
                setOnClickListener {
                    val pos = holder.bindingAdapterPosition
                    if (pos != RecyclerView.NO_POSITION) {
                        val byteOffset = pos * bytesPerRow + i
                        if (byteOffset < data.size) onByteTapped(byteOffset)
                    }
                }
            }
            hexContainer.addView(hexCell)
            holder.hexCells.add(hexCell)

            val asciiCell = TextView(ctx).apply {
                layoutParams = LinearLayout.LayoutParams(asciiCellWidthPx, LinearLayout.LayoutParams.WRAP_CONTENT)
                gravity = Gravity.CENTER
                typeface = Typeface.MONOSPACE
                textSize = HEX_TEXT_SIZE_SP
                setTextColor(asciiColor)
                isClickable = true
                isFocusable = true
                if (bg.resourceId != 0) setBackgroundResource(bg.resourceId)
                setOnClickListener {
                    val pos = holder.bindingAdapterPosition
                    if (pos != RecyclerView.NO_POSITION) {
                        val byteOffset = pos * bytesPerRow + i
                        if (byteOffset < data.size) onAsciiTapped(byteOffset)
                    }
                }
            }
            asciiContainer.addView(asciiCell)
            holder.asciiCells.add(asciiCell)
        }
        return holder
    }

    override fun onBindViewHolder(holder: RowHolder, position: Int) {
        val rowStart = position * bytesPerRow
        val rowEnd = minOf(rowStart + bytesPerRow, data.size)
        holder.offset.text = Integer.toHexString(rowStart).padStart(offsetDigits, '0').uppercase()

        for (i in 0 until bytesPerRow) {
            val idx = rowStart + i
            val hexCell = holder.hexCells[i]
            val asciiCell = holder.asciiCells[i]
            if (idx < rowEnd) {
                val b = data[idx].toInt() and 0xFF
                hexCell.text = String.format("%02X", b)
                hexCell.alpha = 1f
                asciiCell.text = if (b in 0x20..0x7E) b.toInt().toChar().toString() else "."
                asciiCell.alpha = 1f
            } else {
                hexCell.text = ""
                hexCell.alpha = 0.25f
                asciiCell.text = ""
                asciiCell.alpha = 0.25f
            }
        }
    }

    /** Commits a new value at [offset] in the underlying buffer and redraws just that one row. */
    fun setByte(offset: Int, value: Byte) {
        if (offset !in data.indices) return
        data[offset] = value
        notifyItemChanged(offset / bytesPerRow)
    }

    fun byteAt(offset: Int): Byte? = data.getOrNull(offset)

    /** Swaps in an entirely new buffer (a fresh read, or a loaded file) and redraws everything. */
    fun replaceData(newData: ByteArray) {
        data = newData
        offsetDigits = offsetDigitsFor(newData.size)
        notifyDataSetChanged()
    }

    /** The live buffer, edits included - what a "Write" or "Save File" action should act on. */
    fun currentData(): ByteArray = data

    companion object {
        const val HEX_TEXT_SIZE_SP = 13f
        const val HEX_CELL_WIDTH_DP = 20f
        const val ASCII_CELL_WIDTH_DP = 12f

        /** Assume up to a 6-digit offset (comfortably covers this app's realistic range - I2C
         *  EEPROMs top out around 128KB, SPI flash chips this app targets around 8-16MB) when
         *  fitting the grid to screen width, rather than the exact digit count of whatever's
         *  loaded *right now* - a buffer loaded later that needs more digits than assumed would
         *  otherwise push the row just wide enough to need scrolling after all. */
        const val ASSUMED_OFFSET_DIGITS = 6

        private fun offsetDigitsFor(size: Int) = maxOf(4, Integer.toHexString(maxOf(size - 1, 0)).length)

        /**
         * Picks how many bytes fit in one row of [availableWidthPx] with no leftover, using the
         * exact per-cell dimensions [onCreateViewHolder] builds rows with (so the fit is exact,
         * not a separate guess that could drift out of sync with the real rendering) and measuring
         * the real monospace character width at [textSizePx] rather than assuming a fixed dp/char.
         * Rounded down to a multiple of 4 for a tidy, conventional hex-dump grouping.
         */
        fun computeBytesPerRow(availableWidthPx: Int, density: Float, textSizePx: Float = HEX_TEXT_SIZE_SP * density): Int {
            val paint = Paint().apply {
                typeface = Typeface.MONOSPACE
                textSize = textSizePx
            }
            val offsetColumnPx = paint.measureText("0".repeat(ASSUMED_OFFSET_DIGITS)) + 8 * density
            val perBytePx = (HEX_CELL_WIDTH_DP + ASCII_CELL_WIDTH_DP) * density
            val asciiGapPx = 6 * density
            val n = ((availableWidthPx - offsetColumnPx - asciiGapPx) / perBytePx).toInt()
            return (n / 4 * 4).coerceIn(4, 32)
        }
    }
}
