package com.tcpuartbridge.app.ui

import android.graphics.Typeface
import android.util.TypedValue
import android.view.Gravity
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.tcpuartbridge.app.R

/**
 * An editable hex+ASCII grid over a mutable byte buffer, in the same 16-bytes-per-row layout
 * IMSProg's Qt hex editor uses (offset | hex bytes | ASCII). Tapping a hex byte cell calls
 * [onByteTapped] with its offset; the caller (MainActivity) is expected to show a small "enter
 * new hex value" dialog and then call [setByte] to commit the edit and redraw just that one row.
 * Keeping the edit dialog out of this class keeps it free of any dialog/theming logic of its own.
 *
 * Rows are only ever built into views for what's on screen (RecyclerView recycling), so this
 * stays smooth even over a multi-megabyte SPI flash buffer - creating 16 small per-byte TextViews
 * happens once per recycled row holder (~20-30 total on a typical screen), not once per row.
 */
class HexEditorAdapter(
    private var data: ByteArray,
    private val bytesPerRow: Int = 16,
    private val onByteTapped: (offset: Int) -> Unit
) : RecyclerView.Adapter<HexEditorAdapter.RowHolder>() {

    private var offsetDigits = offsetDigitsFor(data.size)

    class RowHolder(
        root: LinearLayout,
        val offset: TextView,
        val bytesContainer: LinearLayout,
        val ascii: TextView
    ) : RecyclerView.ViewHolder(root) {
        val byteCells = mutableListOf<TextView>()
    }

    override fun getItemCount(): Int = (data.size + bytesPerRow - 1) / bytesPerRow

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowHolder {
        val root = LayoutInflater.from(parent.context).inflate(R.layout.item_hex_row, parent, false) as LinearLayout
        val offset = root.findViewById<TextView>(R.id.tvHexOffset)
        val bytesContainer = root.findViewById<LinearLayout>(R.id.llHexBytes)
        val ascii = root.findViewById<TextView>(R.id.tvHexAscii)
        val holder = RowHolder(root, offset, bytesContainer, ascii)

        val density = parent.context.resources.displayMetrics.density
        val cellWidthPx = (22 * density).toInt()
        val bg = TypedValue()
        parent.context.theme.resolveAttribute(android.R.attr.selectableItemBackground, bg, true)

        repeat(bytesPerRow) { i ->
            val cell = TextView(parent.context).apply {
                layoutParams = LinearLayout.LayoutParams(cellWidthPx, LinearLayout.LayoutParams.WRAP_CONTENT)
                gravity = Gravity.CENTER
                typeface = Typeface.MONOSPACE
                textSize = 12f
                isClickable = true
                isFocusable = true
                if (bg.resourceId != 0) setBackgroundResource(bg.resourceId)
                setOnClickListener {
                    val pos = holder.bindingAdapterPosition
                    if (pos != RecyclerView.NO_POSITION) {
                        val byteOffset = pos * bytesPerRow + i
                        if (byteOffset < data.size) onByteTapped(byteOffset)
                    }
                }
            }
            bytesContainer.addView(cell)
            holder.byteCells.add(cell)
        }
        return holder
    }

    override fun onBindViewHolder(holder: RowHolder, position: Int) {
        val rowStart = position * bytesPerRow
        val rowEnd = minOf(rowStart + bytesPerRow, data.size)
        holder.offset.text = Integer.toHexString(rowStart).padStart(offsetDigits, '0').uppercase()

        val asciiBuilder = StringBuilder(bytesPerRow)
        for (i in 0 until bytesPerRow) {
            val idx = rowStart + i
            val cell = holder.byteCells[i]
            if (idx < rowEnd) {
                val b = data[idx].toInt() and 0xFF
                cell.text = String.format("%02X", b)
                cell.alpha = 1f
                asciiBuilder.append(if (b in 0x20..0x7E) b.toChar() else '.')
            } else {
                cell.text = ""
                cell.alpha = 0.3f
                asciiBuilder.append(' ')
            }
        }
        holder.ascii.text = asciiBuilder.toString()
    }

    /** Commits a new value at [offset] in the underlying buffer and redraws just that one row. */
    fun setByte(offset: Int, value: Byte) {
        if (offset !in data.indices) return
        data[offset] = value
        notifyItemChanged(offset / bytesPerRow)
    }

    fun byteAt(offset: Int): Byte? = data.getOrNull(offset)

    /** Swaps in an entirely new buffer (a fresh read, or a loaded file) and redraws everything. */
    fun replaceData(newData: ByteArray) {
        data = newData
        offsetDigits = offsetDigitsFor(newData.size)
        notifyDataSetChanged()
    }

    /** The live buffer, edits included - what a "Write" or "Save File" action should act on. */
    fun currentData(): ByteArray = data

    companion object {
        private fun offsetDigitsFor(size: Int) = maxOf(4, Integer.toHexString(maxOf(size - 1, 0)).length)
    }
}
