package com.tcpuartbridge.app.ui

import android.graphics.Paint
import android.graphics.Typeface
import android.util.TypedValue
import android.view.Gravity
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.tcpuartbridge.app.R

/**
 * An editable hex+ASCII grid over a mutable byte buffer - offset | hex bytes | ASCII, in the
 * layout and coloring from the supplied design mockup (screen_light_mode.html /
 * screen_night_mode.html): the offset, default byte, and highlighted-byte colors are all read
 * from `hex_*` resources ([R.color.hex_offset] etc.), which have separate values/ and
 * values-night/ definitions - light mode's `hex_byte_highlight` is defined equal to `hex_byte`,
 * which is what makes light mode show no per-byte highlighting at all (matching the mockup
 * exactly) without this class needing to know which mode is active. A byte gets the "highlighted"
 * color when it's printable ASCII *excluding space* (0x21-0x7E) - straight from the mockup's own
 * per-cell classes, where e.g. 0x20 stays dim even mid-word. Both the hex cells and the ASCII
 * cells are individually tappable: [onByteTapped] fires for a hex cell (caller shows a 2-digit
 * hex entry dialog), [onAsciiTapped] fires for an ASCII cell (caller shows a single-character
 * entry dialog); either way the caller commits the edit via [setByte].
 *
 * [BYTES_PER_ROW] is a fixed 16 (matching the mockup, and standard hex-dump convention) - never
 * fewer, regardless of screen width. What varies instead is [textSizeSp]/[hexCellWidthDp]/
 * [asciiCellWidthDp]: [computeFit] scales all three down together (or up, on a wide enough
 * screen) so exactly 16 bytes' worth of cells plus the offset column fit the hosting
 * RecyclerView's real measured width with no leftover - the same idea the mockup's own CSS uses
 * (a deliberately small ~7.5-8px monospace font to cram 16 bytes into a phone-width viewport),
 * just computed against the device's actual width instead of a fixed value. [MainActivity]
 * recreates the adapter (never mutates bytesPerRow/textSize in place) if that fit ever changes,
 * since every row's view holder is built with a fixed number of child cells at a fixed size.
 *
 * Rows are only ever built into views for what's on screen (RecyclerView recycling), so this
 * stays smooth over a multi-megabyte SPI flash buffer - creating per-byte TextViews happens once
 * per recycled row holder (~20-30 total on a typical screen), not once per row.
 */
class HexEditorAdapter(
    private var data: ByteArray,
    private val textSizeSp: Float,
    private val hexCellWidthDp: Float,
    private val asciiCellWidthDp: Float,
    private val onByteTapped: (offset: Int) -> Unit,
    private val onAsciiTapped: (offset: Int) -> Unit
) : RecyclerView.Adapter<HexEditorAdapter.RowHolder>() {

    val bytesPerRow: Int get() = BYTES_PER_ROW

    private var offsetDigits = offsetDigitsFor(data.size)

    class RowHolder(
        root: LinearLayout,
        val offset: TextView,
        val hexContainer: LinearLayout,
        val asciiContainer: LinearLayout
    ) : RecyclerView.ViewHolder(root) {
        val hexCells = mutableListOf<TextView>()
        val asciiCells = mutableListOf<TextView>()
    }

    override fun getItemCount(): Int = (data.size + BYTES_PER_ROW - 1) / BYTES_PER_ROW

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowHolder {
        val ctx = parent.context
        val root = LayoutInflater.from(ctx).inflate(R.layout.item_hex_row, parent, false) as LinearLayout
        val offset = root.findViewById<TextView>(R.id.tvHexOffset)
        val hexContainer = root.findViewById<LinearLayout>(R.id.llHexBytes)
        val asciiContainer = root.findViewById<LinearLayout>(R.id.llHexAscii)
        val holder = RowHolder(root, offset, hexContainer, asciiContainer)

        offset.textSize = textSizeSp

        val density = ctx.resources.displayMetrics.density
        val hexCellWidthPx = (hexCellWidthDp * density).toInt()
        val asciiCellWidthPx = (asciiCellWidthDp * density).toInt()
        val bg = TypedValue()
        ctx.theme.resolveAttribute(android.R.attr.selectableItemBackground, bg, true)

        repeat(BYTES_PER_ROW) { i ->
            val hexCell = TextView(ctx).apply {
                layoutParams = LinearLayout.LayoutParams(hexCellWidthPx, LinearLayout.LayoutParams.WRAP_CONTENT)
                gravity = Gravity.CENTER
                typeface = Typeface.MONOSPACE
                textSize = textSizeSp
                isClickable = true
                isFocusable = true
                if (bg.resourceId != 0) setBackgroundResource(bg.resourceId)
                setOnClickListener {
                    val pos = holder.bindingAdapterPosition
                    if (pos != RecyclerView.NO_POSITION) {
                        val byteOffset = pos * BYTES_PER_ROW + i
                        if (byteOffset < data.size) onByteTapped(byteOffset)
                    }
                }
            }
            hexContainer.addView(hexCell)
            holder.hexCells.add(hexCell)

            val asciiCell = TextView(ctx).apply {
                layoutParams = LinearLayout.LayoutParams(asciiCellWidthPx, LinearLayout.LayoutParams.WRAP_CONTENT)
                gravity = Gravity.CENTER
                typeface = Typeface.MONOSPACE
                textSize = textSizeSp
                isClickable = true
                isFocusable = true
                if (bg.resourceId != 0) setBackgroundResource(bg.resourceId)
                setOnClickListener {
                    val pos = holder.bindingAdapterPosition
                    if (pos != RecyclerView.NO_POSITION) {
                        val byteOffset = pos * BYTES_PER_ROW + i
                        if (byteOffset < data.size) onAsciiTapped(byteOffset)
                    }
                }
            }
            asciiContainer.addView(asciiCell)
            holder.asciiCells.add(asciiCell)
        }
        return holder
    }

    override fun onBindViewHolder(holder: RowHolder, position: Int) {
        val ctx = holder.itemView.context
        // Re-resolved per bind rather than cached: cheap, and stays correct even in the unlikely
        // case the day/night configuration changes without the adapter being recreated.
        val hexColor = ctx.getColor(R.color.hex_byte)
        val hexHighlightColor = ctx.getColor(R.color.hex_byte_highlight)
        val asciiColor = ctx.getColor(R.color.hex_ascii)
        val asciiHighlightColor = ctx.getColor(R.color.hex_ascii_highlight)

        val rowStart = position * BYTES_PER_ROW
        val rowEnd = minOf(rowStart + BYTES_PER_ROW, data.size)
        holder.offset.text = Integer.toHexString(rowStart).padStart(offsetDigits, '0').uppercase()

        for (i in 0 until BYTES_PER_ROW) {
            val idx = rowStart + i
            val hexCell = holder.hexCells[i]
            val asciiCell = holder.asciiCells[i]
            if (idx < rowEnd) {
                val b = data[idx].toInt() and 0xFF
                val highlighted = b in 0x21..0x7E // printable ASCII, excluding space
                hexCell.text = String.format("%02X", b)
                hexCell.setTextColor(if (highlighted) hexHighlightColor else hexColor)
                hexCell.alpha = 1f
                asciiCell.text = if (b in 0x20..0x7E) b.toChar().toString() else "."
                asciiCell.setTextColor(if (highlighted) asciiHighlightColor else asciiColor)
                asciiCell.alpha = 1f
            } else {
                hexCell.text = ""
                hexCell.alpha = 0.25f
                asciiCell.text = ""
                asciiCell.alpha = 0.25f
            }
        }
    }

    /** Commits a new value at [offset] in the underlying buffer and redraws just that one row. */
    fun setByte(offset: Int, value: Byte) {
        if (offset !in data.indices) return
        data[offset] = value
        notifyItemChanged(offset / BYTES_PER_ROW)
    }

    fun byteAt(offset: Int): Byte? = data.getOrNull(offset)

    /** Swaps in an entirely new buffer (a fresh read, or a loaded file) and redraws everything. */
    fun replaceData(newData: ByteArray) {
        data = newData
        offsetDigits = offsetDigitsFor(newData.size)
        notifyDataSetChanged()
    }

    /** The live buffer, edits included - what a "Write"/"Verify"/"Dump" action should act on. */
    fun currentData(): ByteArray = data

    companion object {
        const val BYTES_PER_ROW = 16

        // "Reference" design: at REFERENCE_TEXT_SIZE_SP, a hex cell needs HEX_CELL_WIDTH_DP and
        // an ASCII cell needs ASCII_CELL_WIDTH_DP. Every other size in [computeFit] is this
        // design uniformly scaled, so cell width and font size never drift out of proportion.
        private const val REFERENCE_TEXT_SIZE_SP = 13f
        private const val REFERENCE_HEX_CELL_WIDTH_DP = 20f
        private const val REFERENCE_ASCII_CELL_WIDTH_DP = 12f

        // However small a phone is, text below this stops being a usable tap target - beyond
        // this point [computeFit] can no longer guarantee 16-bytes-per-row without some overflow.
        private const val MIN_SCALE = 0.35f
        // Don't blow the grid up arbitrarily large on a tablet just because there's room.
        private const val MAX_SCALE = 1.4f

        /** Assume up to a 6-digit offset (comfortably covers this app's realistic range - I2C
         *  EEPROMs top out around 128KB, SPI flash chips this app targets around 8-16MB) when
         *  fitting the grid to screen width, rather than the exact digit count of whatever's
         *  loaded *right now* - a buffer loaded later that needs more digits than assumed would
         *  otherwise push the row just wide enough to need scrolling after all. */
        const val ASSUMED_OFFSET_DIGITS = 6

        private fun offsetDigitsFor(size: Int) = maxOf(4, Integer.toHexString(maxOf(size - 1, 0)).length)

        data class Fit(val textSizeSp: Float, val hexCellWidthDp: Float, val asciiCellWidthDp: Float)

        /**
         * Computes the (textSize, hexCellWidth, asciiCellWidth) that makes exactly
         * [BYTES_PER_ROW] (16) bytes fill [availableWidthPx] with no leftover - so the grid
         * always shows 16 bytes per row and never needs horizontal scrolling, on any screen.
         * Uses the *real* measured monospace character width at the reference size (not an
         * assumed dp-per-character) so the fit is exact rather than a rough guess.
         */
        fun computeFit(availableWidthPx: Int, density: Float): Fit {
            val paint = Paint().apply {
                typeface = Typeface.MONOSPACE
                textSize = REFERENCE_TEXT_SIZE_SP * density
            }
            val offsetColumnPx = paint.measureText("0".repeat(ASSUMED_OFFSET_DIGITS)) + 8 * density
            val asciiGapPx = 6 * density
            val perBytePx = (REFERENCE_HEX_CELL_WIDTH_DP + REFERENCE_ASCII_CELL_WIDTH_DP) * density
            val neededPx = offsetColumnPx + BYTES_PER_ROW * perBytePx + asciiGapPx

            val rawScale = availableWidthPx / neededPx
            val scale = rawScale.coerceIn(MIN_SCALE, MAX_SCALE)

            return Fit(
                textSizeSp = REFERENCE_TEXT_SIZE_SP * scale,
                hexCellWidthDp = REFERENCE_HEX_CELL_WIDTH_DP * scale,
                asciiCellWidthDp = REFERENCE_ASCII_CELL_WIDTH_DP * scale
            )
        }
    }
}
