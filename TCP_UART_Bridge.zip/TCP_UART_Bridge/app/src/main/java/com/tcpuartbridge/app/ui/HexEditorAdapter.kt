package com.tcpuartbridge.app.ui

import android.graphics.Typeface
import android.util.TypedValue
import android.view.Gravity
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.tcpuartbridge.app.R

/**
 * An editable hex+ASCII grid over a mutable byte buffer - offset | hex bytes | ASCII, styled as a
 * dedicated "hex matrix" viewport (its own background/text colors, from @color/hex_* - see
 * colors.xml / values-night/colors.xml) rather than picking up the surrounding card's surface
 * color; printable-ASCII bytes are highlighted in a brighter tone, non-printable ones dimmed, in
 * both light and dark mode. Both the hex cells and the ASCII cells are
 * individually tappable: [onByteTapped] fires for a hex cell (caller shows a 2-digit hex entry
 * dialog), [onAsciiTapped] fires for an ASCII cell (caller shows a single-character entry dialog);
 * either way the caller commits the edit via [setByte].
 *
 * [bytesPerRow] is fixed for the lifetime of one adapter instance (see [BYTES_PER_ROW] - this app
 * always uses 16, matching the reference CH341A Programmer design). Every hex/ASCII cell is laid
 * out with `width=0dp` + `layout_weight` (see [HEX_CELL_WEIGHT]/[ASCII_CELL_WEIGHT]) inside its
 * row's hex/ASCII container - see [OFFSET_COLUMN_WIDTH_DP]/[HEX_SECTION_WEIGHT]/[ASCII_SECTION_WEIGHT]
 * for how the row itself divides its width between the offset column and those two containers.
 * Because weighted children always exactly fill the space their container is given regardless of
 * their own measured/intrinsic width, the whole row always exactly fills the RecyclerView's width
 * with zero leftover and can never need horizontal scrolling, on any screen size - unlike an
 * approach that measures text and picks a fixed dp per cell, which only fits the device it was
 * tuned against. [HexHeaderView] (the static "Address / 00 01 .. 0F / ASCII" caption row) uses the
 * exact same weights so its columns line up with the scrolling data below it.
 *
 * Rows are only ever built into views for what's on screen (RecyclerView recycling), so this
 * stays smooth over a multi-megabyte SPI flash buffer - creating per-byte TextViews happens once
 * per recycled row holder (~20-30 total on a typical screen), not once per row.
 */
class HexEditorAdapter(
    private var data: ByteArray,
    val bytesPerRow: Int,
    private val onByteTapped: (offset: Int) -> Unit,
    private val onAsciiTapped: (offset: Int) -> Unit
) : RecyclerView.Adapter<HexEditorAdapter.RowHolder>() {

    private var offsetDigits = offsetDigitsFor(data.size)

    class RowHolder(
        root: LinearLayout,
        val offset: TextView,
        val hexContainer: LinearLayout,
        val asciiContainer: LinearLayout,
        val hexColor: Int,
        val asciiColor: Int,
        val hexHighlightColor: Int,
        val asciiHighlightColor: Int
    ) : RecyclerView.ViewHolder(root) {
        val hexCells = mutableListOf<TextView>()
        val asciiCells = mutableListOf<TextView>()
    }

    override fun getItemCount(): Int = (data.size + bytesPerRow - 1) / bytesPerRow

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowHolder {
        val ctx = parent.context
        val root = LayoutInflater.from(ctx).inflate(R.layout.item_hex_row, parent, false) as LinearLayout
        val offset = root.findViewById<TextView>(R.id.tvHexOffset)
        val hexContainer = root.findViewById<LinearLayout>(R.id.llHexBytes)
        val asciiContainer = root.findViewById<LinearLayout>(R.id.llHexAscii)
        val hexColor = ctx.getColor(R.color.hex_byte)
        val asciiColor = ctx.getColor(R.color.hex_ascii)
        val hexHighlightColor = ctx.getColor(R.color.hex_byte_highlight)
        val asciiHighlightColor = ctx.getColor(R.color.hex_ascii_highlight)
        val holder = RowHolder(root, offset, hexContainer, asciiContainer, hexColor, asciiColor, hexHighlightColor, asciiHighlightColor)

        val bg = TypedValue()
        ctx.theme.resolveAttribute(android.R.attr.selectableItemBackground, bg, true)

        repeat(bytesPerRow) { i ->
            val hexCell = TextView(ctx).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).also { lp ->
                    // A slightly wider gap before byte 8 - the classic hex-dump "8 bytes, gap, 8
                    // bytes" grouping (matches the reference design's border-l divider there).
                    if (i == 8) lp.marginStart = (GROUP_GAP_DP * ctx.resources.displayMetrics.density).toInt()
                }
                gravity = Gravity.CENTER
                typeface = Typeface.MONOSPACE
                textSize = HEX_TEXT_SIZE_SP
                setTextColor(hexColor)
                isClickable = true
                isFocusable = true
                if (bg.resourceId != 0) setBackgroundResource(bg.resourceId)
                setOnClickListener {
                    val pos = holder.bindingAdapterPosition
                    if (pos != RecyclerView.NO_POSITION) {
                        val byteOffset = pos * bytesPerRow + i
                        if (byteOffset < data.size) onByteTapped(byteOffset)
                    }
                }
            }
            hexContainer.addView(hexCell)
            holder.hexCells.add(hexCell)

            val asciiCell = TextView(ctx).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                gravity = Gravity.CENTER
                typeface = Typeface.MONOSPACE
                textSize = HEX_TEXT_SIZE_SP
                setTextColor(asciiColor)
                isClickable = true
                isFocusable = true
                if (bg.resourceId != 0) setBackgroundResource(bg.resourceId)
                setOnClickListener {
                    val pos = holder.bindingAdapterPosition
                    if (pos != RecyclerView.NO_POSITION) {
                        val byteOffset = pos * bytesPerRow + i
                        if (byteOffset < data.size) onAsciiTapped(byteOffset)
                    }
                }
            }
            asciiContainer.addView(asciiCell)
            holder.asciiCells.add(asciiCell)
        }
        return holder
    }

    override fun onBindViewHolder(holder: RowHolder, position: Int) {
        val rowStart = position * bytesPerRow
        val rowEnd = minOf(rowStart + bytesPerRow, data.size)
        holder.offset.text = Integer.toHexString(rowStart).padStart(offsetDigits, '0').uppercase()

        for (i in 0 until bytesPerRow) {
            val idx = rowStart + i
            val hexCell = holder.hexCells[i]
            val asciiCell = holder.asciiCells[i]
            if (idx < rowEnd) {
                val b = data[idx].toInt() and 0xFF
                val printable = b in 0x20..0x7E
                hexCell.text = String.format("%02X", b)
                hexCell.alpha = 1f
                hexCell.setTextColor(if (printable) holder.hexHighlightColor else holder.hexColor)
                asciiCell.text = if (printable) b.toInt().toChar().toString() else "."
                asciiCell.alpha = 1f
                asciiCell.setTextColor(if (printable) holder.asciiHighlightColor else holder.asciiColor)
            } else {
                hexCell.text = ""
                hexCell.alpha = 0.25f
                asciiCell.text = ""
                asciiCell.alpha = 0.25f
            }
        }
    }

    /** Commits a new value at [offset] in the underlying buffer and redraws just that one row. */
    fun setByte(offset: Int, value: Byte) {
        if (offset !in data.indices) return
        data[offset] = value
        notifyItemChanged(offset / bytesPerRow)
    }

    fun byteAt(offset: Int): Byte? = data.getOrNull(offset)

    /** Swaps in an entirely new buffer (a fresh read, or a loaded file) and redraws everything. */
    fun replaceData(newData: ByteArray) {
        data = newData
        offsetDigits = offsetDigitsFor(newData.size)
        notifyDataSetChanged()
    }

    /** The live buffer, edits included - what a "Write" or "Save File" action should act on. */
    fun currentData(): ByteArray = data

    companion object {
        /** Bytes shown per row, matching the reference CH341A Programmer design. Fixed (not
         *  computed from screen width) because every cell is weight-based - see the class doc. */
        const val BYTES_PER_ROW = 16

        const val HEX_TEXT_SIZE_SP = 9f
        const val GROUP_GAP_DP = 5f

        /** How the row (after the fixed-width offset column) splits its remaining width between
         *  the hex-byte section and the ASCII section - see [HexHeaderView], which must use the
         *  exact same numbers so its header columns line up with the data rows below it. */
        const val HEX_SECTION_WEIGHT = 3f
        const val ASCII_SECTION_WEIGHT = 1f

        /** Fixed width (dp) for the address/offset column, shared with [HexHeaderView]'s "Address"
         *  label so the two line up regardless of that label's own text width. */
        const val OFFSET_COLUMN_WIDTH_DP = 54

        /** Always at least 8 hex digits ("00000000"), matching the reference design's fixed-width
         *  addresses, but happy to grow for a hypothetically larger buffer than this app's real
         *  chips ever reach (SPI flash here tops out around 16 MB = 7 hex digits). */
        private fun offsetDigitsFor(size: Int) = maxOf(8, Integer.toHexString(maxOf(size - 1, 0)).length)
    }
}
