package com.tcpuartbridge.app

import android.Manifest
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.os.SystemClock
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.tabs.TabLayout
import com.hoho.android.usbserial.driver.UsbSerialDriver
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.driver.UsbSerialProber
import com.tcpuartbridge.app.databinding.ActivityMainBinding
import com.tcpuartbridge.app.eeprom.I2cEeprom
import com.tcpuartbridge.app.hexdump.HexDumpAdapter
import com.tcpuartbridge.app.programmer.ProgrammerController
import com.tcpuartbridge.app.programmer.ProgrammerMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Date
import java.util.Locale
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val progBinding get() = binding.includeProgrammer

    private var bridgeService: BridgeService? = null
    private var bound = false
    private var drivers: List<UsbSerialDriver> = emptyList()
    private var selectedDriver: UsbSerialDriver? = null

    private val baudRates = intArrayOf(
        9600, 19200, 38400, 57600, 115200, 230400, 380400, 460800,
        500000, 921600, 1000000, 1382400, 1444400, 1500000,
        2000000, 2500000, 3000000, 3500000, 4000000, 4500000, 5000000
    )
    private val dataBitsOptions = intArrayOf(5, 6, 7, 8)
    private val stopBitsLabels = arrayOf("1", "1.5", "2")
    private val stopBitsValues = intArrayOf(UsbSerialPort.STOPBITS_1, UsbSerialPort.STOPBITS_1_5, UsbSerialPort.STOPBITS_2)
    private val parityLabels = arrayOf("None", "Odd", "Even", "Mark", "Space")
    private val parityValues = intArrayOf(
        UsbSerialPort.PARITY_NONE,
        UsbSerialPort.PARITY_ODD,
        UsbSerialPort.PARITY_EVEN,
        UsbSerialPort.PARITY_MARK,
        UsbSerialPort.PARITY_SPACE
    )
    private val protocolLabels = arrayOf("RFC2217 (automatic reset)", "Raw (manual reset)", "Raw (auto-baud)")
    private val protocolValues = arrayOf(ServerMode.RFC2217, ServerMode.RAW, ServerMode.RAW_AUTOBAUD)
    // BW16/AmebaD-specific auto-reset support has been removed. "Generic" now just means direct,
    // immediate RTS/DTR passthrough with no canned sequence - the RTS/DTR switches (and this mode)
    // are the fallback path for any board whose reset behavior doesn't match ESP32's.
    // "Generic" is a plain, no-sequence RTS/DTR passthrough fallback for any board whose
    // reset convention isn't known to this app. "AmebaD / BW16" has its own known sequence
    // (see TcpServerManager's auto*AmebaD* methods and Rfc2217Session's SET_CONTROL passthrough).
    private val targetChipLabels = arrayOf(
        "ESP32 (auto reset)", "AmebaD / BW16 (auto reset)", "Arduino / AVR (auto reset)", "Generic (manual RTS/DTR)"
    )
    private val targetChipValues = arrayOf(TargetChip.ESP32, TargetChip.AMEBAD, TargetChip.AVR_ARDUINO, TargetChip.GENERIC)

    // ---- Programmer tab (CH341A I2C EEPROM / SPI flash / SSD1306) ---------------------------

    private val programmerController by lazy { ProgrammerController(applicationContext) }
    private var currentProgMode = ProgrammerMode.I2C_EEPROM
    private var progConnectedDevice: UsbDevice? = null

    private val progModeLabels = arrayOf("I2C EEPROM (24Cxx)", "SPI Flash (25xx)", "SSD1306 OLED Display")
    private val progModeValues = arrayOf(ProgrammerMode.I2C_EEPROM, ProgrammerMode.SPI_FLASH, ProgrammerMode.SSD1306_DISPLAY)

    private val eepromChipLabels = I2cEeprom.COMMON_CHIPS.map { it.name } + "Custom (enter size below)"
    private var selectedEepromChip: I2cEeprom.Chip = I2cEeprom.COMMON_CHIPS.first()

    private val oledSizeLabels = arrayOf("128 x 64", "128 x 32")
    private val oledSizeValues = arrayOf(128 to 64, 128 to 32)
    private var selectedOledSize = oledSizeValues.first()

    private var lastEepromDump: ByteArray? = null
    private var lastSpiDump: ByteArray? = null
    private lateinit var hexDumpAdapter: HexDumpAdapter

    private data class CliExample(val title: String, val explanation: String, val command: String)

    // Every command below uses PHONE_IP:PORT as a placeholder for whatever this app's
    // "IP: ... Port: ..." status line actually shows once the bridge is started.
    private val cliExamples = listOf(
        CliExample(
            "ESP32/ESP8266 - RFC2217 (automatic reset)",
            "App: Protocol = RFC2217, Target Chip = ESP32. esptool drives real, correctly-timed " +
                "DTR/RTS resets over the network - no manual button needed.",
            "esptool --port \"rfc2217://PHONE_IP:PORT?ign_set_control\" --baud 460800 write-flash 0x1000 firmware.bin"
        ),
        CliExample(
            "ESP32/ESP8266 - Raw (auto-baud)",
            "App: Protocol = Raw (auto-baud), Target Chip = ESP32. Plain socket, no RFC2217 - the app " +
                "watches for esptool's own baud-change command and follows it, and auto-resets the " +
                "board on connect/disconnect.",
            "esptool --port socket://PHONE_IP:PORT --baud 921600 write-flash 0x1000 firmware.bin"
        ),
        CliExample(
            "ESP32/ESP8266 - Raw (manual reset)",
            "App: Protocol = Raw (manual reset). Works with any TCP client, but no auto-reset - put the " +
                "board in bootloader mode yourself first (the app's Reset to Bootloader button or " +
                "RTS/DTR switches).",
            "esptool --port socket://PHONE_IP:PORT --baud 460800 --before no-reset --after no-reset write-flash 0x1000 firmware.bin"
        ),
        CliExample(
            "Erase one flash region",
            "Erases only the given address range - e.g. to clear saved WiFi/NVS settings without " +
                "touching the rest of flash. Offset and size must both be a multiple of 0x1000 (4096).",
            "esptool --port socket://PHONE_IP:PORT erase-region 0x9000 0x6000"
        ),
        CliExample(
            "Erase the entire flash chip",
            "Wipes everything - bootloader, partition table, app, all data. Good starting point for a " +
                "device that's in an unknown or corrupted state.",
            "esptool --port socket://PHONE_IP:PORT erase-flash"
        ),
        CliExample(
            "Read back a partition (e.g. SPIFFS)",
            "Dumps a region of flash to a local file - useful to back up or inspect a SPIFFS/LittleFS " +
                "partition before erasing it. Get the real offset/size for your device from the " +
                "parttool.py example below rather than guessing.",
            "esptool --port socket://PHONE_IP:PORT read-flash 0x290000 0x170000 spiffs_dump.bin"
        ),
        CliExample(
            "Query the partition table (ESP-IDF parttool.py)",
            "Reads a named partition's real offset/size straight from the device instead of guessing - " +
                "use its output for the read-flash example above.",
            "parttool.py --port socket://PHONE_IP:PORT get_partition_info --partition-name=spiffs"
        ),
        CliExample(
            "AmebaD / BW16 (upload_amebad.py)",
            "App: Protocol = Raw (auto-baud), Target Chip = AmebaD / BW16 (auto reset). Don't pass " +
                "--auto - the script's own DTR/RTS attempt is a no-op over a plain socket anyway; the " +
                "app handles reset automatically instead.",
            "python upload_amebad.py path/to/firmware_dir socket://PHONE_IP:PORT"
        ),
        CliExample(
            "Arduino / AVR (avrdude)",
            "App: Protocol = Raw (auto-baud), Target Chip = Arduino / AVR (auto reset). Use -c stk500v1, " +
                "not -c arduino - the latter tries its own DTR/RTS ioctl, which fails on a network port " +
                "(\"Inappropriate ioctl for device\") and never actually resets the chip; the app drives " +
                "the reset instead.",
            "avrdude -p atmega328p -c stk500v1 -P net:PHONE_IP:PORT -b 115200 -U flash:w:blink.ino.hex:i"
        ),
        CliExample(
            "Any other UART device (plain terminal)",
            "Raw (manual reset) is a plain byte pipe - works with anything that just talks over a TCP " +
                "socket, no ESP/AVR/AmebaD-specific tooling needed.",
            "nc PHONE_IP PORT"
        )
    )

    private val serviceConnection = object : android.content.ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val localBinder = service as BridgeService.LocalBinder
            bridgeService = localBinder.getService()
            bound = true
            bridgeService?.setListener(bridgeListener)
            bridgeService?.getStatus()?.let { updateStatusUi(it) }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            bound = false
            bridgeService = null
        }
    }

    private val bridgeListener = object : BridgeListener {
        override fun onLog(message: String) {
            runOnUiThread { appendLog(message) }
        }

        override fun onStatusChanged(status: BridgeStatus) {
            runOnUiThread { updateStatusUi(status) }
        }
    }

    private val usbAttachReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                UsbManager.ACTION_USB_DEVICE_ATTACHED,
                UsbManager.ACTION_USB_DEVICE_DETACHED -> refreshDeviceList()
            }
        }
    }

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* no-op either way */ }

    // ---- Programmer tab: Storage Access Framework pickers for dump files --------------------

    private val eepromSaveLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
            val data = lastEepromDump
            if (uri != null && data != null) writeBytesToUri(uri, data, "EEPROM dump")
        }

    private val eepromOpenLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) readBytesFromUri(uri) { bytes -> onEepromFileChosen(bytes) }
        }

    private val spiSaveLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
            val data = lastSpiDump
            if (uri != null && data != null) writeBytesToUri(uri, data, "SPI flash dump")
        }

    private val spiOpenLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) readBytesFromUri(uri) { bytes -> onSpiFileChosen(bytes) }
        }

    private val oledImageLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) onOledImageChosen(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupSpinners()
        setupTabs()
        populateExamples()
        setupProgrammerUi()
        refreshDeviceList()
        applyBottomInsets()

        binding.btnRefreshDevices.setOnClickListener { refreshDeviceList() }
        binding.btnStartStop.setOnClickListener { onStartStopClicked() }
        binding.switchRts.setOnCheckedChangeListener { _, checked -> bridgeService?.setRTS(checked) }
        binding.switchDtr.setOnCheckedChangeListener { _, checked -> bridgeService?.setDTR(checked) }
        binding.btnAutoReset.setOnClickListener { performAutoReset() }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        val filter = IntentFilter().apply {
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(usbAttachReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(usbAttachReceiver, filter)
        }

        bindService(Intent(this, BridgeService::class.java), serviceConnection, Context.BIND_AUTO_CREATE)
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(usbAttachReceiver)
        if (bound) {
            bridgeService?.setListener(null)
            unbindService(serviceConnection)
            bound = false
        }
        // Plain synchronous close (not the suspend disconnect()) - the activity is on its way
        // out, so there's no coroutine scope left to safely launch into.
        programmerController.stopI2cTcpServer()
        programmerController.usbDevice.close()
    }

    private var currentTargetChip = TargetChip.ESP32
    private var currentProtocolMode = ServerMode.RFC2217

    // ---- setup ------------------------------------------------------------

    // ---- tabs / examples ---------------------------------------------

    private fun setupTabs() {
        binding.tabLayout.addTab(binding.tabLayout.newTab().setText(R.string.tab_bridge))
        binding.tabLayout.addTab(binding.tabLayout.newTab().setText(R.string.tab_examples))
        binding.tabLayout.addTab(binding.tabLayout.newTab().setText(R.string.tab_programmer))
        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                binding.llBridgePanel.visibility = if (tab.position == 0) View.VISIBLE else View.GONE
                binding.llExamplesPanel.visibility = if (tab.position == 1) View.VISIBLE else View.GONE
                binding.includeProgrammer.root.visibility = if (tab.position == 2) View.VISIBLE else View.GONE
            }

            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })
    }

    /** Inflates one card per [cliExamples] entry into llExamplesContainer, each with a working Copy button. */
    private fun populateExamples() {
        val inflater = LayoutInflater.from(this)
        cliExamples.forEach { example ->
            val itemView = inflater.inflate(R.layout.item_example, binding.llExamplesContainer, false)
            itemView.findViewById<TextView>(R.id.tvExampleTitle).text = example.title
            itemView.findViewById<TextView>(R.id.tvExampleExplanation).text = example.explanation
            itemView.findViewById<TextView>(R.id.tvExampleCommand).text = example.command
            itemView.findViewById<Button>(R.id.btnCopyExample).setOnClickListener {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText(example.title, example.command))
                Toast.makeText(this, "Copied to clipboard", Toast.LENGTH_SHORT).show()
            }
            binding.llExamplesContainer.addView(itemView)
        }
    }

    private fun setupSpinners() {
        binding.spinnerBaud.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, baudRates.map { it.toString() }
        )
        binding.spinnerBaud.setSelection(baudRates.indexOf(115200))

        binding.spinnerDataBits.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, dataBitsOptions.map { it.toString() }
        )
        binding.spinnerDataBits.setSelection(dataBitsOptions.indexOf(8))

        binding.spinnerStopBits.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, stopBitsLabels
        )
        binding.spinnerStopBits.setSelection(0)

        binding.spinnerParity.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, parityLabels
        )
        binding.spinnerParity.setSelection(0)

        binding.spinnerTargetChip.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, targetChipLabels
        )
        binding.spinnerTargetChip.setSelection(0) // ESP32 by default
        binding.spinnerTargetChip.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                currentTargetChip = targetChipValues[position]
                refreshHints()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        binding.spinnerProtocol.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, protocolLabels
        )
        binding.spinnerProtocol.setSelection(0) // RFC2217 by default
        binding.spinnerProtocol.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                currentProtocolMode = protocolValues[position]
                refreshHints()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        refreshHints()
        binding.etTcpPort.setText("3333")
    }

    private fun refreshHints() {
        binding.tvProtocolHint.text = when (currentProtocolMode) {
            ServerMode.RFC2217 ->
                "RFC2217: esptool talks to this app directly and drives real, correctly-timed DTR/RTS resets. " +
                    "Use --port rfc2217://PHONE_IP:PORT?ign_set_control with esptool."
            ServerMode.RAW_AUTOBAUD ->
                "Raw (auto-baud): plain byte passthrough like Raw, but this app watches the wire for " +
                    "esptool's or upload_amebad.py's own baud-change command and follows it, so --baud works " +
                    "over a plain socket:// without RFC2217. Always opens at 115200 first (data bits/stop " +
                    "bits/parity below still apply - the Baud Rate value itself is ignored here), and resets " +
                    "back to 115200 when the connection closes, ready for the next session. With Target Chip " +
                    "set to ESP32, AmebaD/BW16, or Arduino/AVR, it also auto-resets the board into " +
                    "download/bootloader mode when a client connects (and, for ESP32/AmebaD, boots the " +
                    "flashed app when it disconnects too) - no manual button needed."
            else ->
                "Raw: plain byte passthrough, works with any TCP client " +
                    "(nc, PuTTY raw socket, esptool --port socket://...), but has no channel for remote reset control."
        }

        binding.tvEsp32Note.text = when {
            currentTargetChip == TargetChip.GENERIC && currentProtocolMode == ServerMode.RFC2217 ->
                "Generic mode: DTR/RTS commands from the client are relayed straight through with no " +
                    "sequence timing. Use this if the automatic ESP32/AmebaD/AVR reset sequences don't work " +
                    "on your board - or fall back to the RTS/DTR switches below to drive the lines by hand."
            currentTargetChip == TargetChip.GENERIC ->
                "Generic mode: no automatic sequence is applied here. Use the RTS/DTR switches below as a " +
                    "manual fallback to put the board in bootloader/download mode by hand - useful for boards " +
                    "whose reset conventions don't match ESP32's, AmebaD's, or AVR's."
            currentTargetChip == TargetChip.AMEBAD && currentProtocolMode == ServerMode.RAW_AUTOBAUD ->
                "Raw (auto-baud) automatically runs the AmebaD download-mode-entry sequence when a client " +
                    "connects, and resets to normal boot when it disconnects - you shouldn't need this button " +
                    "or the switches. They're still here as a fallback if that doesn't work on your board " +
                    "(manually flipping both switches by hand is unlikely to hit the required 500ms/200ms/500ms " +
                    "timing reliably, though - prefer this button, which runs the same timed sequence in code)."
            currentTargetChip == TargetChip.AMEBAD ->
                "AmebaD/BW16 download-mode sequence (500ms/200ms/500ms, from upload_amebad.py's " +
                    "enter_download_mode()). Only auto-runs on connect/disconnect in Raw (auto-baud) mode - " +
                    "elsewhere, use this button before flashing. Manually flipping the switches by hand is " +
                    "unlikely to hit the timing reliably; prefer this button."
            currentTargetChip == TargetChip.AVR_ARDUINO && currentProtocolMode == ServerMode.RAW_AUTOBAUD ->
                "Raw (auto-baud) automatically runs this reset sequence when a client connects - you " +
                    "shouldn't need this button or the switches. No pulse is needed on disconnect: Optiboot-" +
                    "style bootloaders jump to the flashed app on their own after a short idle timeout. Use " +
                    "avrdude's -c stk500v1, not -c arduino - the latter tries its own DTR/RTS ioctl, which " +
                    "fails on a network port and never actually resets the chip."
            currentTargetChip == TargetChip.AVR_ARDUINO ->
                "Arduino/AVR bootloader-entry sequence (250ms/50ms, copied from avrdude's own " +
                    "arduino_open()). Only auto-runs on connect in Raw (auto-baud) mode - elsewhere, use this " +
                    "button before flashing. Use avrdude's -c stk500v1, not -c arduino - the latter tries its " +
                    "own DTR/RTS ioctl, which fails on a network port and never actually resets the chip."
            currentProtocolMode == ServerMode.RAW_AUTOBAUD ->
                "Raw (auto-baud) automatically runs this sequence when a client connects, and a plain hard " +
                    "reset when it disconnects - you shouldn't need these manual switches. They're still here " +
                    "as a fallback if that doesn't work on your board."
            currentProtocolMode == ServerMode.RFC2217 ->
                "In RFC2217 mode, esptool resets the board automatically before/after flashing - you " +
                    "shouldn't need these manual switches. They're still here as a fallback: if the automatic " +
                    "sequence fails on your board, drive RTS/DTR by hand with the switches or this button."
            else ->
                "Note: a plain TCP socket has no control-line channel, so esptool.py cannot toggle RTS/DTR " +
                    "remotely over socket://. Use this button, or the RTS/DTR switches, to put the board in " +
                    "bootloader mode before flashing, then run esptool with --before no-reset --after no-reset."
        }
    }

    private fun refreshDeviceList() {
        val usbManager = getSystemService(Context.USB_SERVICE) as UsbManager
        drivers = UsbSerialProber.getDefaultProber().findAllDrivers(usbManager)

        if (drivers.isEmpty()) {
            binding.spinnerDevices.adapter = ArrayAdapter(
                this, android.R.layout.simple_spinner_dropdown_item, listOf("No USB serial device found")
            )
            binding.tvUsbStatus.text = "USB: not connected"
            selectedDriver = null
            return
        }

        val labels = drivers.map { d ->
            val dev = d.device
            "${UsbChipIdentifier.name(dev.vendorId, dev.productId)}  (VID:${dev.vendorId} PID:${dev.productId})"
        }
        binding.spinnerDevices.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        binding.spinnerDevices.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedDriver = drivers.getOrNull(position)
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        selectedDriver = drivers.first()
        binding.tvUsbStatus.text = "USB: ${drivers.size} device(s) found"
    }

    // ---- start / stop -------------------------------------------------

    private fun onStartStopClicked() {
        val svc = bridgeService
        if (svc == null) {
            appendLog("Service not ready yet, please try again")
            return
        }

        if (svc.getStatus().running) {
            svc.stopBridge()
            return
        }

        val driver = selectedDriver
        if (driver == null) {
            appendLog("No USB serial device selected")
            return
        }

        val port = binding.etTcpPort.text.toString().toIntOrNull()
        if (port == null || port !in 1..65535) {
            appendLog("Invalid TCP port")
            return
        }

        val baud = baudRates[binding.spinnerBaud.selectedItemPosition]
        val dataBits = dataBitsOptions[binding.spinnerDataBits.selectedItemPosition]
        val stopBits = stopBitsValues[binding.spinnerStopBits.selectedItemPosition]
        val parity = parityValues[binding.spinnerParity.selectedItemPosition]
        val protocolMode = currentProtocolMode
        val targetChip = currentTargetChip

        val usbManager = getSystemService(Context.USB_SERVICE) as UsbManager
        if (!usbManager.hasPermission(driver.device)) {
            requestUsbPermission(driver) { granted ->
                if (granted) {
                    launchBridge(driver, baud, dataBits, stopBits, parity, port, protocolMode, targetChip)
                } else {
                    appendLog("USB permission denied")
                }
            }
        } else {
            launchBridge(driver, baud, dataBits, stopBits, parity, port, protocolMode, targetChip)
        }
    }

    private fun launchBridge(
        driver: UsbSerialDriver,
        baud: Int,
        dataBits: Int,
        stopBits: Int,
        parity: Int,
        port: Int,
        protocolMode: ServerMode,
        targetChip: TargetChip
    ) {
        ContextCompat.startForegroundService(this, Intent(this, BridgeService::class.java))
        bridgeService?.startBridge(driver, baud, dataBits, stopBits, parity, port, protocolMode, targetChip)
    }

    private fun requestUsbPermission(driver: UsbSerialDriver, callback: (Boolean) -> Unit) {
        val usbManager = getSystemService(Context.USB_SERVICE) as UsbManager
        val action = "com.tcpuartbridge.app.USB_PERMISSION"
        val mutabilityFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0
        val permissionIntent = PendingIntent.getBroadcast(
            this, 0, Intent(action).setPackage(packageName), mutabilityFlag
        )

        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                if (intent.action == action) {
                    unregisterReceiver(this)
                    callback(intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false))
                }
            }
        }
        val filter = IntentFilter(action)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(receiver, filter)
        }
        usbManager.requestPermission(driver.device, permissionIntent)
    }

    private fun performAutoReset() {
        val svc = bridgeService ?: return
        when (currentTargetChip) {
            TargetChip.ESP32 -> performEsp32BootloaderReset(svc)
            TargetChip.AMEBAD -> performAmebaDownloadModeReset(svc)
            TargetChip.AVR_ARDUINO -> performArduinoReset(svc)
            TargetChip.GENERIC -> appendLog(
                "Generic mode has no built-in auto-reset sequence - use the RTS/DTR switches above " +
                    "as the manual fallback to drive the lines by hand for your board's reset convention."
            )
        }
    }

    /** Classic ESP32 auto-reset-to-bootloader pulse sequence (DTR=GPIO0, RTS=EN) - mirrors esptool's ClassicReset. */
    private fun performEsp32BootloaderReset(svc: BridgeService) {
        val t0 = SystemClock.elapsedRealtime()
        fun step(msg: String) = appendLog("[+${SystemClock.elapsedRealtime() - t0}ms] $msg")
        lifecycleScope.launch {
            step("ESP32 reset: DTR=0 (IO0=HIGH), RTS=1 (EN=LOW, reset)")
            svc.setDTR(false)
            svc.setRTS(true)
            delay(100)
            step("DTR=1 (IO0=LOW), RTS=0 (EN=HIGH, exits reset -> should sample IO0 LOW -> bootloader)")
            svc.setDTR(true)
            svc.setRTS(false)
            delay(50)
            step("DTR=0 (IO0=HIGH, done)")
            svc.setDTR(false)
            appendLog(
                "Sent bootloader reset sequence. If the board still boots normally instead of entering the " +
                    "bootloader, that's very likely a wiring/chip-driver polarity issue rather than sequence " +
                    "timing - the steps above match esptool's ClassicReset exactly."
            )
        }
    }

    /**
     * AmebaD/BW16 download-mode-entry pulse sequence - reverse-engineered exactly from
     * upload_amebad.py's enter_download_mode()/set_dtr_rts() (0x2 -> 0x1 -> 0x3, 500/200/500ms).
     * In Raw (auto-baud) mode this now also runs automatically on connect/disconnect (see
     * TcpServerManager) - this manual button remains as a fallback/for testing outside that mode.
     */
    private fun performAmebaDownloadModeReset(svc: BridgeService) {
        val t0 = SystemClock.elapsedRealtime()
        fun step(msg: String) = appendLog("[+${SystemClock.elapsedRealtime() - t0}ms] $msg")
        lifecycleScope.launch {
            step("AmebaD download mode: RTS=1, DTR=0 (EN low / reset)")
            svc.setRTS(true)
            svc.setDTR(false)
            delay(500)
            step("RTS=0, DTR=1 (download-mode select)")
            svc.setRTS(false)
            svc.setDTR(true)
            delay(200)
            step("RTS=0, DTR=0 (release)")
            svc.setRTS(false)
            svc.setDTR(false)
            delay(500)
            appendLog("Sent AmebaD/BW16 download-mode reset sequence.")
        }
    }

    /**
     * Arduino/AVR bootloader-entry pulse - the classic "DTR through a capacitor to RESET"
     * auto-reset, timing copied exactly from avrdude's own arduino_open() (clear DTR+RTS,
     * 250ms, set DTR+RTS, 50ms). In Raw (auto-baud) mode this now also runs automatically
     * on connect (see TcpServerManager) - this manual button remains as a fallback/for
     * testing outside that mode. Use avrdude's -c stk500v1 (not -c arduino) so avrdude
     * doesn't also attempt its own DTR/RTS ioctl, which fails over a network port anyway.
     */
    private fun performArduinoReset(svc: BridgeService) {
        val t0 = SystemClock.elapsedRealtime()
        fun step(msg: String) = appendLog("[+${SystemClock.elapsedRealtime() - t0}ms] $msg")
        lifecycleScope.launch {
            step("Arduino/AVR reset: DTR=0, RTS=0 (clear - discharges the reset capacitor)")
            svc.setDTR(false)
            svc.setRTS(false)
            delay(250)
            step("DTR=1, RTS=1 (set - the rising edge triggers reset)")
            svc.setDTR(true)
            svc.setRTS(true)
            delay(50)
            appendLog("Sent Arduino/AVR bootloader-entry reset sequence.")
        }
    }

    /**
     * Adds the system navigation bar's height on top of the button's base XML
     * margin, so it never sits flush against gesture-nav or 3-button-nav
     * controls on any device (the fixed XML margin alone isn't enough on
     * devices with a tall nav bar).
     */
    private fun applyBottomInsets() {
        val baseMarginPx = (binding.btnStartStop.layoutParams as ViewGroup.MarginLayoutParams).bottomMargin
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { _, insets ->
            val navBarInset = insets.getInsets(WindowInsetsCompat.Type.systemBars()).bottom
            val params = binding.btnStartStop.layoutParams as ViewGroup.MarginLayoutParams
            params.bottomMargin = baseMarginPx + navBarInset
            binding.btnStartStop.layoutParams = params
            insets
        }
        ViewCompat.requestApplyInsets(binding.root)
    }

    // ---- UI updates -----------------------------------------------------

    private fun updateStatusUi(status: BridgeStatus) {
        binding.tvUsbStatus.text = if (status.usbConnected) "USB: ${status.deviceName}" else "USB: not connected"
        val modeLabel = when (status.protocolMode) {
            ServerMode.RFC2217 -> "RFC2217"
            ServerMode.RAW_AUTOBAUD -> "raw, auto-baud"
            ServerMode.RAW -> "raw"
        }
        binding.tvIpPort.text = "IP: ${status.ipAddress}   Port: ${status.tcpPort}   Protocol: $modeLabel"
        binding.tvClientCount.text = "Clients connected: ${status.clientCount}"
        binding.btnStartStop.text = if (status.running) getString(R.string.stop_bridge) else getString(R.string.start_bridge)
    }

    private fun appendLog(message: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        binding.tvLog.append("[$time] $message\n")
        binding.scrollLog.post { binding.scrollLog.fullScroll(View.FOCUS_DOWN) }
    }

    // ==================== Programmer tab (CH341A I2C EEPROM / SPI flash / SSD1306) ====================
    //
    // This talks to a *separate* USB personality of the CH341/CH341A chip family from the Bridge
    // tab above - see Ch341UsbDevice's class doc. It has its own connect/disconnect lifecycle,
    // independent of bridgeService and the UsbSerialManager-based flow used everywhere else in
    // this file.

    private fun setupProgrammerUi() {
        val p = progBinding

        hexDumpAdapter = HexDumpAdapter(ByteArray(0)) { index, newValue -> onHexByteEdited(index, newValue) }
        p.recyclerHexDump.layoutManager = LinearLayoutManager(this)
        p.recyclerHexDump.adapter = hexDumpAdapter

        p.spinnerProgMode.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, progModeLabels)
        p.spinnerProgMode.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                currentProgMode = progModeValues[position]
                p.llI2cPanel.visibility = if (currentProgMode == ProgrammerMode.I2C_EEPROM) View.VISIBLE else View.GONE
                p.llSpiPanel.visibility = if (currentProgMode == ProgrammerMode.SPI_FLASH) View.VISIBLE else View.GONE
                p.llDisplayPanel.visibility = if (currentProgMode == ProgrammerMode.SSD1306_DISPLAY) View.VISIBLE else View.GONE
                p.llI2cTcpPanel.visibility = if (currentProgMode == ProgrammerMode.SPI_FLASH) View.GONE else View.VISIBLE
                p.llDumpTablePanel.visibility = if (currentProgMode == ProgrammerMode.SSD1306_DISPLAY) View.GONE else View.VISIBLE
                refreshHexDumpTable()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        p.spinnerEepromChip.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, eepromChipLabels)
        p.spinnerEepromChip.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val isCustom = position !in I2cEeprom.COMMON_CHIPS.indices
                p.etEepromCustomSize.visibility = if (isCustom) View.VISIBLE else View.GONE
                if (isCustom) {
                    p.tvEepromInfo.text = "Enter the size in bytes above - a 2-byte-address, 32-byte-page chip is assumed."
                } else {
                    selectedEepromChip = I2cEeprom.COMMON_CHIPS[position]
                    p.tvEepromInfo.text = "${selectedEepromChip.totalBytes} bytes total, ${selectedEepromChip.pageSize}-byte write pages."
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        p.spinnerOledSize.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, oledSizeLabels)
        p.spinnerOledSize.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedOledSize = oledSizeValues[position]
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        p.btnProgConnect.setOnClickListener { onProgConnectClicked() }
        p.btnEepromRead.setOnClickListener { onEepromReadClicked() }
        p.btnEepromLoadFile.setOnClickListener { onEepromLoadFileClicked() }
        p.btnEepromSave.setOnClickListener { onEepromSaveClicked() }
        p.btnEepromErase.setOnClickListener { onEepromEraseClicked() }
        p.btnEepromRandom.setOnClickListener { onEepromRandomClicked() }
        p.btnEepromWrite.setOnClickListener { onEepromWriteClicked() }
        p.btnSpiReadId.setOnClickListener { onSpiReadIdClicked() }
        p.btnSpiRead.setOnClickListener { onSpiReadClicked() }
        p.btnSpiLoadFile.setOnClickListener { onSpiLoadFileClicked() }
        p.btnSpiSave.setOnClickListener { onSpiSaveClicked() }
        p.btnSpiErase.setOnClickListener { onSpiEraseClicked() }
        p.btnSpiRandom.setOnClickListener { onSpiRandomClicked() }
        p.btnSpiWrite.setOnClickListener { onSpiWriteClicked() }
        p.btnOledInit.setOnClickListener { onOledInitClicked() }
        p.btnOledTest.setOnClickListener { onOledTestClicked() }
        p.btnOledClear.setOnClickListener { onOledClearClicked() }
        p.btnOledDrawText.setOnClickListener { onOledDrawTextClicked() }
        p.btnOledLoadImage.setOnClickListener { onOledLoadImageClicked() }
        p.btnI2cTcpToggle.setOnClickListener { onI2cTcpToggleClicked() }

        p.tvEepromInfo.text = "${selectedEepromChip.totalBytes} bytes total, ${selectedEepromChip.pageSize}-byte write pages."
        updateProgConnectionUi(false)
    }

    // ---- connect / disconnect ----------------------------------------------

    private fun updateProgConnectionUi(connected: Boolean) {
        progBinding.tvProgStatus.text = if (connected) {
            "Connected: ${programmerController.usbDevice.deviceLabel()}"
        } else {
            getString(R.string.prog_not_connected)
        }
        progBinding.btnProgConnect.text = getString(if (connected) R.string.prog_disconnect else R.string.prog_connect)
        progBinding.spinnerProgMode.isEnabled = !connected
        if (!connected) {
            // disconnect() always stops the I2C-over-TCP server too - reflect that here.
            progBinding.tvI2cTcpStatus.text = getString(R.string.prog_i2ctcp_not_running)
            progBinding.btnI2cTcpToggle.text = getString(R.string.prog_i2ctcp_start)
        }
    }

    private fun onProgConnectClicked() {
        if (programmerController.isConnected) {
            lifecycleScope.launch {
                programmerController.disconnect(currentProgMode)
                progConnectedDevice = null
                updateProgConnectionUi(false)
                progLog("Disconnected")
            }
            return
        }

        val dev = programmerController.findDevice()
        if (dev == null) {
            progLog("No CH341A programmer found - plug it in (VID 1A86 / PID 5512) and tap Connect again")
            return
        }

        if (programmerController.hasPermission(dev)) {
            connectToProgrammerDevice(dev)
        } else {
            programmerController.requestPermission(dev) { granted ->
                if (granted) connectToProgrammerDevice(dev) else progLog("USB permission denied")
            }
        }
    }

    private fun connectToProgrammerDevice(dev: UsbDevice) {
        lifecycleScope.launch {
            val ok = programmerController.connect(dev, currentProgMode)
            if (ok) {
                progConnectedDevice = dev
                updateProgConnectionUi(true)
                progLog("Connected: ${programmerController.usbDevice.deviceLabel()}")
            } else {
                progLog("Failed to open/initialize the CH341A")
            }
        }
    }

    // ---- I2C EEPROM ---------------------------------------------------------

    /** Reads the chip spinner, or builds a Chip from the custom-size field. Logs and returns null if invalid. */
    private fun currentEepromChip(): I2cEeprom.Chip? {
        val pos = progBinding.spinnerEepromChip.selectedItemPosition
        if (pos in I2cEeprom.COMMON_CHIPS.indices) return I2cEeprom.COMMON_CHIPS[pos]
        val size = progBinding.etEepromCustomSize.text.toString().toIntOrNull()
        if (size == null || size <= 0) {
            progLog("Enter a valid custom EEPROM size in bytes first")
            return null
        }
        progLog(
            "Custom chip: assuming 2-byte word addressing / 32-byte pages (typical for 32Kbit+ " +
                "EEPROMs) - pick the matching preset instead if your chip is smaller than that"
        )
        return I2cEeprom.Chip("Custom ($size B)", size, pageSize = 32, algorithm = 0x02)
    }

    private fun onEepromReadClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first")
            return
        }
        val chip = currentEepromChip() ?: return
        lifecycleScope.launch {
            setProgProgress(0)
            progLog("Reading ${chip.name}...")
            val data = programmerController.readEeprom(chip) { done, total ->
                runOnUiThread { setProgProgress(if (total > 0) done * 100 / total else 100) }
            }
            setProgProgress(null)
            if (data != null) {
                lastEepromDump = data
                refreshHexDumpTable()
                progLog("Read ${data.size} bytes into the table below")
            } else {
                progLog("EEPROM read failed - check wiring and that a chip is present")
            }
        }
    }

    private fun onEepromLoadFileClicked() {
        if (currentEepromChip() == null) return
        progLog("Choose a file to load into the table...")
        eepromOpenLauncher.launch(arrayOf("*/*"))
    }

    private fun onEepromFileChosen(bytes: ByteArray) {
        val chip = currentEepromChip() ?: return
        val data = if (bytes.size > chip.totalBytes) {
            progLog("File is ${bytes.size} B, larger than ${chip.name} (${chip.totalBytes} B) - truncating")
            bytes.copyOf(chip.totalBytes)
        } else {
            bytes
        }
        lastEepromDump = data
        refreshHexDumpTable()
        progLog("Loaded ${data.size} bytes into the table - tap Write to program the chip")
    }

    private fun onEepromSaveClicked() {
        val data = lastEepromDump
        if (data == null) {
            progLog("Nothing to save yet - Read, Load File, Erase, or Random first")
            return
        }
        progLog("Choose where to save...")
        eepromSaveLauncher.launch(suggestedFileName("eeprom_dump", data.size))
    }

    private fun onEepromEraseClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first")
            return
        }
        val chip = currentEepromChip() ?: return
        AlertDialog.Builder(this)
            .setTitle("Erase ${chip.name}?")
            .setMessage("This fills the entire chip with 0xFF and cannot be undone. Continue?")
            .setPositiveButton("Erase") { _, _ ->
                val blank = ByteArray(chip.totalBytes) { 0xFF.toByte() }
                writeEepromBuffer(chip, blank, "Erasing ${chip.name}...", "Erase complete", "Erase failed")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun onEepromRandomClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first")
            return
        }
        val chip = currentEepromChip() ?: return
        AlertDialog.Builder(this)
            .setTitle("Fill ${chip.name} with random data?")
            .setMessage("This overwrites the entire chip with random bytes and cannot be undone. Continue?")
            .setPositiveButton("Fill") { _, _ ->
                val random = ByteArray(chip.totalBytes) { Random.nextInt(256).toByte() }
                writeEepromBuffer(chip, random, "Writing random data to ${chip.name}...", "Random fill complete", "Random fill failed")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun onEepromWriteClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first")
            return
        }
        val chip = currentEepromChip() ?: return
        val data = lastEepromDump
        if (data == null) {
            progLog("Nothing to write yet - Read, Load File, Erase, or Random first")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Write ${data.size} bytes to ${chip.name}?")
            .setMessage("This overwrites the chip with what's currently in the table below. Continue?")
            .setPositiveButton("Write") { _, _ ->
                writeEepromBuffer(chip, data, "Writing ${data.size} bytes to ${chip.name}...", "EEPROM write complete", "EEPROM write failed")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    /** Shared by Erase/Random/Write: pushes [data] to [chip], then refreshes the table from it. */
    private fun writeEepromBuffer(chip: I2cEeprom.Chip, data: ByteArray, startMessage: String, doneMessage: String, failMessage: String) {
        lifecycleScope.launch {
            setProgProgress(0)
            progLog(startMessage)
            val ok = programmerController.writeEeprom(chip, data) { done, total ->
                runOnUiThread { setProgProgress(if (total > 0) done * 100 / total else 100) }
            }
            setProgProgress(null)
            if (ok) {
                lastEepromDump = data
                refreshHexDumpTable()
            }
            progLog(if (ok) doneMessage else failMessage)
        }
    }

    // ---- SPI flash ------------------------------------------------------------

    private fun onSpiReadIdClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first")
            return
        }
        lifecycleScope.launch {
            val id = programmerController.readSpiJedecId()
            if (id != null) {
                progBinding.tvSpiId.text = "Mfg 0x%02X   Type 0x%02X   Capacity code 0x%02X   (~%s)".format(
                    id.manufacturer, id.memoryType, id.capacityCode, formatSize(id.sizeBytes)
                )
                progLog("JEDEC ID read OK")
            } else {
                progBinding.tvSpiId.text = ""
                progLog("Failed to read JEDEC ID - check wiring/chip")
            }
        }
    }

    /** Reads the size field, in bytes. Logs and returns null if invalid. */
    private fun currentSpiSizeBytes(): Int? {
        val sizeKb = progBinding.etSpiSizeKb.text.toString().toIntOrNull()
        if (sizeKb == null || sizeKb <= 0) {
            progLog("Enter a valid size in KB")
            return null
        }
        return sizeKb * 1024
    }

    private fun currentSpiPageSize(): Int = progBinding.etSpiPageSize.text.toString().toIntOrNull() ?: 256

    private fun onSpiReadClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first")
            return
        }
        val length = currentSpiSizeBytes() ?: return
        lifecycleScope.launch {
            setProgProgress(0)
            progLog("Reading ${length / 1024} KB from SPI flash...")
            val data = programmerController.readSpiFlash(length) { done, total ->
                runOnUiThread { setProgProgress(if (total > 0) done * 100 / total else 100) }
            }
            setProgProgress(null)
            if (data != null) {
                lastSpiDump = data
                refreshHexDumpTable()
                progLog("Read ${data.size} bytes into the table below")
            } else {
                progLog("SPI flash read failed - check wiring and that a chip is present")
            }
        }
    }

    private fun onSpiLoadFileClicked() {
        progLog("Choose a file to load into the table...")
        spiOpenLauncher.launch(arrayOf("*/*"))
    }

    private fun onSpiFileChosen(bytes: ByteArray) {
        lastSpiDump = bytes
        refreshHexDumpTable()
        progLog("Loaded ${bytes.size} bytes into the table - tap Write to program the chip")
    }

    private fun onSpiSaveClicked() {
        val data = lastSpiDump
        if (data == null) {
            progLog("Nothing to save yet - Read, Load File, Erase, or Random first")
            return
        }
        progLog("Choose where to save...")
        spiSaveLauncher.launch(suggestedFileName("spi_flash_dump", data.size))
    }

    private fun onSpiEraseClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first")
            return
        }
        val size = currentSpiSizeBytes() ?: return
        AlertDialog.Builder(this)
            .setTitle("Erase entire SPI flash chip?")
            .setMessage("This wipes the whole chip and cannot be undone. Continue?")
            .setPositiveButton("Erase") { _, _ ->
                lifecycleScope.launch {
                    setProgProgress(0)
                    progLog("Erasing SPI flash chip - this can take a while...")
                    val ok = programmerController.eraseSpiFlashChip()
                    setProgProgress(null)
                    if (ok) {
                        lastSpiDump = ByteArray(size) { 0xFF.toByte() }
                        refreshHexDumpTable()
                    }
                    progLog(if (ok) "Chip erase complete" else "Chip erase failed")
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun onSpiRandomClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first")
            return
        }
        val size = currentSpiSizeBytes() ?: return
        AlertDialog.Builder(this)
            .setTitle("Fill $size bytes of SPI flash with random data?")
            .setMessage("This erases the covered sectors and writes random bytes, and cannot be undone. Continue?")
            .setPositiveButton("Fill") { _, _ ->
                val random = ByteArray(size) { Random.nextInt(256).toByte() }
                writeSpiBuffer(random, "Writing random data to SPI flash...", "Random fill complete", "Random fill failed")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun onSpiWriteClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first")
            return
        }
        val data = lastSpiDump
        if (data == null) {
            progLog("Nothing to write yet - Read, Load File, Erase, or Random first")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Write ${data.size} bytes to SPI flash?")
            .setMessage("This erases the covered sectors and overwrites them with what's currently in the table below. Continue?")
            .setPositiveButton("Write") { _, _ ->
                writeSpiBuffer(data, "Erasing + writing ${data.size} bytes to SPI flash...", "SPI flash write complete", "SPI flash write failed")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    /** Shared by Random/Write: pushes [data] to the chip (erase-first), then refreshes the table from it. */
    private fun writeSpiBuffer(data: ByteArray, startMessage: String, doneMessage: String, failMessage: String) {
        val pageSize = currentSpiPageSize()
        lifecycleScope.launch {
            setProgProgress(0)
            progLog(startMessage)
            val ok = programmerController.writeSpiFlash(data, pageSize) { done, total ->
                runOnUiThread { setProgProgress(if (total > 0) done * 100 / total else 100) }
            }
            setProgProgress(null)
            if (ok) {
                lastSpiDump = data
                refreshHexDumpTable()
            }
            progLog(if (ok) doneMessage else failMessage)
        }
    }

    // ---- Hex dump table (shared: I2C EEPROM + SPI Flash) -----------------------

    private fun refreshHexDumpTable() {
        val buffer = when (currentProgMode) {
            ProgrammerMode.I2C_EEPROM -> lastEepromDump
            ProgrammerMode.SPI_FLASH -> lastSpiDump
            ProgrammerMode.SSD1306_DISPLAY -> null
        }
        hexDumpAdapter.setBuffer(buffer ?: ByteArray(0))
        progBinding.tvDumpInfo.text = if (buffer == null) getString(R.string.prog_dump_empty) else "${buffer.size} bytes"
    }

    private fun onHexByteEdited(index: Int, newValue: Byte) {
        progLog("Byte at 0x%06X set to 0x%02X - tap Write to commit".format(index, newValue.toInt() and 0xFF))
        val buffer = if (currentProgMode == ProgrammerMode.I2C_EEPROM) lastEepromDump else lastSpiDump
        progBinding.tvDumpInfo.text = "${buffer?.size ?: 0} bytes (edited - tap Write to commit)"
    }

    // ---- SSD1306 OLED -----------------------------------------------------------

    private fun parseOledAddress(): Int =
        progBinding.etOledAddress.text.toString().trim()
            .removePrefix("0x").removePrefix("0X")
            .toIntOrNull(16) ?: 0x3C

    private fun onOledInitClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first")
            return
        }
        val (w, h) = selectedOledSize
        val addr = parseOledAddress()
        lifecycleScope.launch {
            val ok = programmerController.initDisplay(addr, w, h)
            progLog(
                if (ok) "SSD1306 initialized (${w}x$h @ 0x${addr.toString(16)})"
                else "SSD1306 init failed - check address/wiring"
            )
        }
    }

    private fun onOledTestClicked() {
        lifecycleScope.launch {
            val ok = programmerController.displayTestPattern()
            progLog(if (ok) "Test pattern sent" else "Init the display first")
        }
    }

    private fun onOledClearClicked() {
        lifecycleScope.launch {
            val ok = programmerController.displayClear()
            progLog(if (ok) "Display cleared" else "Init the display first")
        }
    }

    private fun onOledDrawTextClicked() {
        val text = progBinding.etOledText.text.toString()
        lifecycleScope.launch {
            val ok = programmerController.displayText(text)
            progLog(if (ok) "Text drawn" else "Init the display first")
        }
    }

    private fun onOledLoadImageClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first")
            return
        }
        progLog("Choose an image to display...")
        oledImageLauncher.launch(arrayOf("image/*"))
    }

    private fun onOledImageChosen(uri: Uri) {
        lifecycleScope.launch {
            val bitmap = try {
                withContext(Dispatchers.IO) {
                    contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it) }
                }
            } catch (e: Exception) {
                null
            }
            if (bitmap == null) {
                progLog("Failed to decode the selected image")
                return@launch
            }
            val ok = programmerController.displayBitmap(bitmap)
            bitmap.recycle()
            progLog(if (ok) "Image drawn (scaled + thresholded to 1-bit)" else "Init the display first")
        }
    }

    // ---- I2C-over-TCP -----------------------------------------------------------

    private fun onI2cTcpToggleClicked() {
        if (programmerController.isI2cTcpServerRunning) {
            programmerController.stopI2cTcpServer()
            progBinding.tvI2cTcpStatus.text = getString(R.string.prog_i2ctcp_not_running)
            progBinding.btnI2cTcpToggle.text = getString(R.string.prog_i2ctcp_start)
            progLog("I2C-over-TCP server stopped")
            return
        }
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first")
            return
        }
        if (currentProgMode == ProgrammerMode.SPI_FLASH) {
            progLog("I2C-over-TCP isn't available in SPI Flash mode - connect in I2C EEPROM or SSD1306 Display mode instead")
            return
        }
        val port = progBinding.etI2cTcpPort.text.toString().toIntOrNull()
        if (port == null || port !in 1..65535) {
            progLog("Enter a valid port number (1-65535)")
            return
        }
        try {
            programmerController.startI2cTcpServer(
                port = port,
                onClientConnected = { addr -> runOnUiThread { progLog("I2C-over-TCP client connected: $addr") } },
                onClientDisconnected = { addr -> runOnUiThread { progLog("I2C-over-TCP client disconnected: $addr") } },
                onError = { e -> runOnUiThread { progLog("I2C-over-TCP error: ${e.message}") } }
            )
            progBinding.tvI2cTcpStatus.text = "Listening on ${localIpAddress()}:$port"
            progBinding.btnI2cTcpToggle.text = getString(R.string.prog_i2ctcp_stop)
            progLog("I2C-over-TCP server started on port $port")
        } catch (e: Exception) {
            progLog("Failed to start I2C-over-TCP server: ${e.message}")
        }
    }

    private fun localIpAddress(): String {
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val iface = interfaces.nextElement()
                val addresses = iface.inetAddresses
                while (addresses.hasMoreElements()) {
                    val addr = addresses.nextElement()
                    if (!addr.isLoopbackAddress && addr is Inet4Address) {
                        return addr.hostAddress ?: "unknown"
                    }
                }
            }
        } catch (_: Exception) {
        }
        return "unknown"
    }

    // ---- file I/O (Storage Access Framework) -----------------------------------

    private fun suggestedFileName(prefix: String, sizeBytes: Int): String {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        return "${prefix}_${sizeBytes}B_$stamp.bin"
    }

    private fun writeBytesToUri(uri: Uri, data: ByteArray, label: String) {
        lifecycleScope.launch {
            val ok = try {
                withContext(Dispatchers.IO) {
                    contentResolver.openOutputStream(uri)?.use { it.write(data) }
                    true
                }
            } catch (e: Exception) {
                false
            }
            progLog(if (ok) "$label saved (${data.size} bytes)" else "Failed to save $label")
        }
    }

    private fun readBytesFromUri(uri: Uri, onLoaded: (ByteArray) -> Unit) {
        lifecycleScope.launch {
            val bytes = try {
                withContext(Dispatchers.IO) { contentResolver.openInputStream(uri)?.use { it.readBytes() } }
            } catch (e: Exception) {
                null
            }
            if (bytes != null) onLoaded(bytes) else progLog("Failed to read the selected file")
        }
    }

    private fun formatSize(bytes: Long): String = when {
        bytes <= 0 -> "unknown size"
        bytes >= 1024 * 1024 -> "%.0f MB".format(bytes / (1024.0 * 1024.0))
        else -> "%.0f KB".format(bytes / 1024.0)
    }

    // ---- shared progress/log helpers -------------------------------------------

    private fun setProgProgress(percent: Int?) {
        val bar = progBinding.progressProgrammer
        if (percent == null) {
            bar.visibility = View.INVISIBLE
        } else {
            bar.visibility = View.VISIBLE
            bar.progress = percent.coerceIn(0, 100)
        }
    }

    private fun progLog(message: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        progBinding.tvProgLog.append("[$time] $message\n")
        progBinding.scrollProgLog.post { progBinding.scrollProgLog.fullScroll(View.FOCUS_DOWN) }
    }
}
