package com.tcpuartbridge.app

import android.hardware.usb.UsbDevice
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.tcpuartbridge.app.databinding.ActivityMainBinding
import com.tcpuartbridge.app.databinding.DialogHexViewBinding
import com.tcpuartbridge.app.eeprom.I2cEeprom
import com.tcpuartbridge.app.eeprom.SpiFlashDatabase
import com.tcpuartbridge.app.programmer.ProgrammerController
import com.tcpuartbridge.app.programmer.ProgrammerMode
import com.tcpuartbridge.app.ui.HexDumpAdapter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Date
import java.util.Locale

/**
 * CH341A programmer app - I2C EEPROM (24Cxx) read/write, SPI NOR flash (25xx) read/erase/write,
 * and a small SSD1306 I2C OLED display driver, all over the CH341A's USB "parallel/EPP"
 * (programmer) mode. Also exposes an I2C-over-TCP server so another device on the network can run
 * I2C transactions against whatever's wired to the CH341A.
 *
 * This talks to the CH341A's programmer-mode USB personality via [Ch341UsbDevice] - see that
 * class's doc for why it needs its own connect/open/claim-interface flow rather than a standard
 * serial port.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val progBinding get() = binding.includeProgrammer

    private val programmerController by lazy { ProgrammerController(applicationContext) }
    private var currentProgMode = ProgrammerMode.I2C_EEPROM
    private var progConnectedDevice: UsbDevice? = null

    private val progModeLabels = arrayOf("I2C EEPROM (24Cxx)", "SPI Flash (25xx)", "SSD1306 OLED Display")
    private val progModeValues = arrayOf(ProgrammerMode.I2C_EEPROM, ProgrammerMode.SPI_FLASH, ProgrammerMode.SSD1306_DISPLAY)

    private val eepromChipLabels = I2cEeprom.COMMON_CHIPS.map { it.name } + "Custom (enter size below)"
    private var selectedEepromChip: I2cEeprom.Chip = I2cEeprom.COMMON_CHIPS.first()

    private val spiChipLabels = SpiFlashDatabase.COMMON_CHIPS.map { it.name } + "Custom (enter size below)"
    /** Null = "Custom" is selected, so the size comes from [ActivityMainBinding]'s etSpiSizeKb field instead. */
    private var selectedSpiChipSize: Long? = SpiFlashDatabase.COMMON_CHIPS.firstOrNull()?.sizeBytes

    private val oledSizeLabels = arrayOf("128 x 64", "128 x 32", "96 x 16")
    private val oledSizeValues = arrayOf(128 to 64, 128 to 32, 96 to 16)
    private var selectedOledSize = oledSizeValues.first()

    private var lastEepromDump: ByteArray? = null
    private var lastSpiDump: ByteArray? = null

    // ---- Storage Access Framework pickers for dump files --------------------

    private val eepromSaveLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
            val data = lastEepromDump
            if (uri != null && data != null) writeBytesToUri(uri, data, "EEPROM dump")
        }

    private val eepromOpenLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) readBytesFromUri(uri) { bytes -> onEepromWriteFileChosen(bytes) }
        }

    private val spiSaveLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
            val data = lastSpiDump
            if (uri != null && data != null) writeBytesToUri(uri, data, "SPI flash dump")
        }

    private val spiOpenLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) readBytesFromUri(uri) { bytes -> onSpiWriteFileChosen(bytes) }
        }

    private val oledImageLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) onOledImageChosen(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupProgrammerUi()
    }

    override fun onDestroy() {
        super.onDestroy()
        // Plain synchronous close (not the suspend disconnect()) - the activity is on its way
        // out, so there's no coroutine scope left to safely launch into.
        programmerController.stopI2cTcpServer()
        programmerController.usbDevice.close()
    }

    // ==================== CH341A: I2C EEPROM / SPI flash / SSD1306 ====================

    private fun setupProgrammerUi() {
        val p = progBinding

        p.spinnerProgMode.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, progModeLabels)
        p.spinnerProgMode.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                currentProgMode = progModeValues[position]
                p.llI2cPanel.visibility = if (currentProgMode == ProgrammerMode.I2C_EEPROM) View.VISIBLE else View.GONE
                p.llSpiPanel.visibility = if (currentProgMode == ProgrammerMode.SPI_FLASH) View.VISIBLE else View.GONE
                p.llDisplayPanel.visibility = if (currentProgMode == ProgrammerMode.SSD1306_DISPLAY) View.VISIBLE else View.GONE
                p.llI2cTcpPanel.visibility = if (currentProgMode == ProgrammerMode.SPI_FLASH) View.GONE else View.VISIBLE
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        p.spinnerEepromChip.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, eepromChipLabels)
        p.spinnerEepromChip.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val isCustom = position !in I2cEeprom.COMMON_CHIPS.indices
                p.etEepromCustomSize.visibility = if (isCustom) View.VISIBLE else View.GONE
                if (isCustom) {
                    p.tvEepromInfo.text = "Enter the size in bytes above - a 2-byte-address, 32-byte-page chip is assumed."
                } else {
                    selectedEepromChip = I2cEeprom.COMMON_CHIPS[position]
                    p.tvEepromInfo.text = "${selectedEepromChip.totalBytes} bytes total, ${selectedEepromChip.pageSize}-byte write pages."
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        p.spinnerOledSize.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, oledSizeLabels)
        p.spinnerOledSize.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedOledSize = oledSizeValues[position]
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        p.spinnerSpiChip.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, spiChipLabels)
        p.spinnerSpiChip.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val isCustom = position !in SpiFlashDatabase.COMMON_CHIPS.indices
                if (isCustom) {
                    selectedSpiChipSize = null
                } else {
                    val chip = SpiFlashDatabase.COMMON_CHIPS[position]
                    selectedSpiChipSize = chip.sizeBytes
                    p.etSpiSizeKb.setText((chip.sizeBytes / 1024).toString())
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        p.btnProgConnect.setOnClickListener { onProgConnectClicked() }
        p.btnEepromRead.setOnClickListener { onEepromReadClicked() }
        p.btnEepromWrite.setOnClickListener { onEepromWriteClicked() }
        p.btnEepromErase.setOnClickListener { onEepromEraseClicked() }
        p.btnEepromRandom.setOnClickListener { onEepromRandomClicked() }
        p.btnEepromDetect.setOnClickListener { onEepromDetectClicked() }
        p.btnEepromHexView.setOnClickListener { onEepromHexViewClicked() }
        p.btnSpiReadId.setOnClickListener { onSpiDetectClicked() }
        p.btnSpiRead.setOnClickListener { onSpiReadClicked() }
        p.btnSpiErase.setOnClickListener { onSpiEraseClicked() }
        p.btnSpiWrite.setOnClickListener { onSpiWriteClicked() }
        p.btnSpiRandom.setOnClickListener { onSpiRandomClicked() }
        p.btnSpiHexView.setOnClickListener { onSpiHexViewClicked() }
        p.btnOledInit.setOnClickListener { onOledInitClicked() }
        p.btnOledTest.setOnClickListener { onOledTestClicked() }
        p.btnOledClear.setOnClickListener { onOledClearClicked() }
        p.btnOledDrawText.setOnClickListener { onOledDrawTextClicked() }
        p.btnOledLoadImage.setOnClickListener { onOledLoadImageClicked() }
        p.btnI2cTcpToggle.setOnClickListener { onI2cTcpToggleClicked() }

        p.tvEepromInfo.text = "${selectedEepromChip.totalBytes} bytes total, ${selectedEepromChip.pageSize}-byte write pages."
        updateProgConnectionUi(false)
    }

    // ---- connect / disconnect ----------------------------------------------

    private fun updateProgConnectionUi(connected: Boolean) {
        progBinding.tvProgStatus.text = if (connected) {
            "Connected: ${programmerController.usbDevice.deviceLabel()}"
        } else {
            getString(R.string.prog_not_connected)
        }
        progBinding.btnProgConnect.text = getString(if (connected) R.string.prog_disconnect else R.string.prog_connect)
        progBinding.spinnerProgMode.isEnabled = !connected
        if (!connected) {
            // disconnect() always stops the I2C-over-TCP server too - reflect that here.
            progBinding.tvI2cTcpStatus.text = getString(R.string.prog_i2ctcp_not_running)
            progBinding.btnI2cTcpToggle.text = getString(R.string.prog_i2ctcp_start)
        }
    }

    private fun onProgConnectClicked() {
        if (programmerController.isConnected) {
            lifecycleScope.launch {
                programmerController.disconnect(currentProgMode)
                progConnectedDevice = null
                updateProgConnectionUi(false)
                progLog("Disconnected")
            }
            return
        }

        val dev = programmerController.findDevice()
        if (dev == null) {
            progLog("No CH341A programmer found - plug it in (VID 1A86 / PID 5512) and tap Connect again")
            return
        }

        if (programmerController.hasPermission(dev)) {
            connectToProgrammerDevice(dev)
        } else {
            programmerController.requestPermission(dev) { granted ->
                if (granted) connectToProgrammerDevice(dev) else progLog("USB permission denied")
            }
        }
    }

    private fun connectToProgrammerDevice(dev: UsbDevice) {
        lifecycleScope.launch {
            val ok = programmerController.connect(dev, currentProgMode)
            if (ok) {
                progConnectedDevice = dev
                updateProgConnectionUi(true)
                progLog("Connected: ${programmerController.usbDevice.deviceLabel()}")
            } else {
                progLog("Failed to open/initialize the CH341A")
            }
        }
    }

    // ---- I2C EEPROM ---------------------------------------------------------

    /** Reads the chip spinner, or builds a Chip from the custom-size field. Logs and returns null if invalid. */
    private fun currentEepromChip(): I2cEeprom.Chip? {
        val pos = progBinding.spinnerEepromChip.selectedItemPosition
        if (pos in I2cEeprom.COMMON_CHIPS.indices) return I2cEeprom.COMMON_CHIPS[pos]
        val size = progBinding.etEepromCustomSize.text.toString().toIntOrNull()
        if (size == null || size <= 0) {
            progLog("Enter a valid custom EEPROM size in bytes first")
            return null
        }
        progLog(
            "Custom chip: assuming 2-byte word addressing / 32-byte pages (typical for 32Kbit+ " +
                "EEPROMs) - pick the matching preset instead if your chip is smaller than that"
        )
        return I2cEeprom.Chip("Custom ($size B)", size, pageSize = 32, algorithm = 0x02)
    }

    private fun onEepromReadClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first")
            return
        }
        val chip = currentEepromChip() ?: return
        lifecycleScope.launch {
            setProgProgress(0)
            progLog("Reading ${chip.name}...")
            val data = programmerController.readEeprom(chip) { done, total ->
                runOnUiThread { setProgProgress(if (total > 0) done * 100 / total else 100) }
            }
            setProgProgress(null)
            if (data != null) {
                lastEepromDump = data
                progLog("Read ${data.size} bytes - choose where to save")
                eepromSaveLauncher.launch(suggestedFileName("eeprom_dump", data.size))
            } else {
                progLog("EEPROM read failed - check wiring and that a chip is present")
            }
        }
    }

    private fun onEepromWriteClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first")
            return
        }
        if (currentEepromChip() == null) return
        progLog("Choose a file to write to the EEPROM...")
        eepromOpenLauncher.launch(arrayOf("*/*"))
    }

    private fun onEepromWriteFileChosen(bytes: ByteArray) {
        val chip = currentEepromChip() ?: return
        val data = if (bytes.size > chip.totalBytes) {
            progLog("File is ${bytes.size} B, larger than ${chip.name} (${chip.totalBytes} B) - truncating")
            bytes.copyOf(chip.totalBytes)
        } else {
            bytes
        }
        lifecycleScope.launch {
            setProgProgress(0)
            progLog("Writing ${data.size} bytes to ${chip.name}...")
            val ok = programmerController.writeEeprom(chip, data) { done, total ->
                runOnUiThread { setProgProgress(if (total > 0) done * 100 / total else 100) }
            }
            setProgProgress(null)
            progLog(if (ok) "EEPROM write complete" else "EEPROM write failed")
        }
    }

    private fun onEepromEraseClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first")
            return
        }
        val chip = currentEepromChip() ?: return
        AlertDialog.Builder(this)
            .setTitle("Erase ${chip.name}?")
            .setMessage("Fills all ${chip.totalBytes} bytes with 0xFF. This cannot be undone. Continue?")
            .setPositiveButton("Erase") { _, _ ->
                lifecycleScope.launch {
                    setProgProgress(0)
                    progLog("Erasing ${chip.name}...")
                    val ok = programmerController.eraseEeprom(chip) { done, total ->
                        runOnUiThread { setProgProgress(if (total > 0) done * 100 / total else 100) }
                    }
                    setProgProgress(null)
                    progLog(if (ok) "Erase complete" else "Erase failed")
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun onEepromRandomClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first")
            return
        }
        val chip = currentEepromChip() ?: return
        AlertDialog.Builder(this)
            .setTitle("Write random data to ${chip.name}?")
            .setMessage("Overwrites all ${chip.totalBytes} bytes with random data. This cannot be undone. Continue?")
            .setPositiveButton("Write Random") { _, _ ->
                lifecycleScope.launch {
                    setProgProgress(0)
                    progLog("Writing random data to ${chip.name}...")
                    val ok = programmerController.writeRandomEeprom(chip) { done, total ->
                        runOnUiThread { setProgProgress(if (total > 0) done * 100 / total else 100) }
                    }
                    setProgProgress(null)
                    progLog(if (ok) "Random write complete" else "Random write failed")
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun onEepromDetectClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first")
            return
        }
        val chip = currentEepromChip() ?: return
        AlertDialog.Builder(this)
            .setTitle("Detect chip size?")
            .setMessage(
                "Briefly overwrites byte 0 to find where the chip's address wraps around, then " +
                    "restores it. Only tries chips with the same address-byte width as \"${chip.name}\" " +
                    "- pick roughly the right chip (small vs. large) first. Continue?"
            )
            .setPositiveButton("Detect") { _, _ ->
                lifecycleScope.launch {
                    progLog("Detecting size (probing against ${chip.name}'s address family)...")
                    val result = programmerController.detectEepromSize(chip)
                    if (result == null) {
                        progLog("Detection failed - check wiring, that a chip is present, or try a different starting chip")
                        return@launch
                    }
                    val detected = result.chip
                    val index = I2cEeprom.COMMON_CHIPS.indexOf(detected)
                    if (index >= 0) progBinding.spinnerEepromChip.setSelection(index)
                    progLog(
                        if (result.confirmed) "Detected: ${detected.name}"
                        else "Could only confirm it's at least ${detected.name} - larger sizes in this family can't be told apart this way"
                    )
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun onEepromHexViewClicked() {
        val data = lastEepromDump
        if (data == null) {
            progLog("Read the EEPROM first to view its contents")
            return
        }
        showHexDump("EEPROM dump", data)
    }

    // ---- SPI flash ------------------------------------------------------------

    /** Size in bytes implied by the chip spinner, or the manual KB field when "Custom" is selected. */
    private fun currentSpiSizeBytes(): Long {
        selectedSpiChipSize?.let { return it }
        val kb = progBinding.etSpiSizeKb.text.toString().toIntOrNull() ?: 0
        return kb.toLong() * 1024
    }

    private fun onSpiDetectClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first")
            return
        }
        lifecycleScope.launch {
            val chip = programmerController.detectSpiChip()
            if (chip == null) {
                progBinding.tvSpiId.text = ""
                progLog("Failed to read JEDEC ID - check wiring/chip")
                return@launch
            }
            progBinding.tvSpiId.text = "${chip.name}  (${formatSize(chip.sizeBytes)})"
            programmerController.configureSpiAddressing(chip.sizeBytes)
            val index = SpiFlashDatabase.COMMON_CHIPS.indexOfFirst { it.name == chip.name }
            if (index >= 0) {
                progBinding.spinnerSpiChip.setSelection(index)
            } else {
                // Not one of the exact-named parts - fall back to "Custom" and fill in the decoded size.
                progBinding.spinnerSpiChip.setSelection(spiChipLabels.size - 1)
                selectedSpiChipSize = null
                progBinding.etSpiSizeKb.setText((chip.sizeBytes / 1024).toString())
            }
            progLog("Detected: ${chip.name}")
        }
    }

    private fun onSpiRandomClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first")
            return
        }
        val sizeBytes = currentSpiSizeBytes()
        if (sizeBytes <= 0) {
            progLog("Pick a chip or enter a valid size in KB")
            return
        }
        val pageSize = progBinding.etSpiPageSize.text.toString().toIntOrNull() ?: 256
        AlertDialog.Builder(this)
            .setTitle("Write random data?")
            .setMessage("Erases and overwrites ${formatSize(sizeBytes)} with random data. This cannot be undone. Continue?")
            .setPositiveButton("Write Random") { _, _ ->
                lifecycleScope.launch {
                    programmerController.configureSpiAddressing(sizeBytes)
                    setProgProgress(0)
                    progLog("Writing random data to SPI flash...")
                    val ok = programmerController.writeRandomSpiFlash(sizeBytes.toInt(), pageSize) { done, total ->
                        runOnUiThread { setProgProgress(if (total > 0) done * 100 / total else 100) }
                    }
                    setProgProgress(null)
                    progLog(if (ok) "Random write complete" else "Random write failed")
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun onSpiHexViewClicked() {
        val data = lastSpiDump
        if (data == null) {
            progLog("Read the SPI flash first to view its contents")
            return
        }
        showHexDump("SPI flash dump", data)
    }

    private fun onSpiReadClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first")
            return
        }
        val sizeKb = progBinding.etSpiSizeKb.text.toString().toIntOrNull()
        if (sizeKb == null || sizeKb <= 0) {
            progLog("Enter a valid size in KB")
            return
        }
        val length = sizeKb * 1024
        lifecycleScope.launch {
            programmerController.configureSpiAddressing(length.toLong())
            setProgProgress(0)
            progLog("Reading $sizeKb KB from SPI flash...")
            val data = programmerController.readSpiFlash(length) { done, total ->
                runOnUiThread { setProgProgress(if (total > 0) done * 100 / total else 100) }
            }
            setProgProgress(null)
            if (data != null) {
                lastSpiDump = data
                progLog("Read ${data.size} bytes - choose where to save")
                spiSaveLauncher.launch(suggestedFileName("spi_flash_dump", data.size))
            } else {
                progLog("SPI flash read failed - check wiring and that a chip is present")
            }
        }
    }

    private fun onSpiEraseClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Erase entire SPI flash chip?")
            .setMessage("This wipes the whole chip and cannot be undone. Continue?")
            .setPositiveButton("Erase") { _, _ ->
                lifecycleScope.launch {
                    programmerController.configureSpiAddressing(currentSpiSizeBytes())
                    setProgProgress(0)
                    progLog("Erasing SPI flash chip - this can take a while...")
                    val ok = programmerController.eraseSpiFlashChip()
                    setProgProgress(null)
                    progLog(if (ok) "Chip erase complete" else "Chip erase failed")
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun onSpiWriteClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first")
            return
        }
        progLog("Choose a file to write to SPI flash...")
        spiOpenLauncher.launch(arrayOf("*/*"))
    }

    private fun onSpiWriteFileChosen(bytes: ByteArray) {
        val pageSize = progBinding.etSpiPageSize.text.toString().toIntOrNull() ?: 256
        lifecycleScope.launch {
            programmerController.configureSpiAddressing(maxOf(currentSpiSizeBytes(), bytes.size.toLong()))
            setProgProgress(0)
            progLog("Erasing + writing ${bytes.size} bytes to SPI flash (page size $pageSize B)...")
            val ok = programmerController.writeSpiFlash(bytes, pageSize) { done, total ->
                runOnUiThread { setProgProgress(if (total > 0) done * 100 / total else 100) }
            }
            setProgProgress(null)
            progLog(if (ok) "SPI flash write complete" else "SPI flash write failed")
        }
    }

    // ---- SSD1306 OLED -----------------------------------------------------------

    private fun parseOledAddress(): Int =
        progBinding.etOledAddress.text.toString().trim()
            .removePrefix("0x").removePrefix("0X")
            .toIntOrNull(16) ?: 0x3C

    private fun onOledInitClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first")
            return
        }
        val (w, h) = selectedOledSize
        val addr = parseOledAddress()
        lifecycleScope.launch {
            val ok = programmerController.initDisplay(addr, w, h)
            progLog(
                if (ok) "SSD1306 initialized (${w}x$h @ 0x${addr.toString(16)})"
                else "SSD1306 init failed - check address/wiring"
            )
        }
    }

    private fun onOledTestClicked() {
        lifecycleScope.launch {
            val ok = programmerController.displayTestPattern()
            progLog(if (ok) "Test pattern sent" else "Init the display first")
        }
    }

    private fun onOledClearClicked() {
        lifecycleScope.launch {
            val ok = programmerController.displayClear()
            progLog(if (ok) "Display cleared" else "Init the display first")
        }
    }

    private fun onOledDrawTextClicked() {
        val text = progBinding.etOledText.text.toString()
        lifecycleScope.launch {
            val ok = programmerController.displayText(text)
            progLog(if (ok) "Text drawn" else "Init the display first")
        }
    }

    private fun onOledLoadImageClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first")
            return
        }
        progLog("Choose an image to display...")
        oledImageLauncher.launch(arrayOf("image/*"))
    }

    private fun onOledImageChosen(uri: Uri) {
        lifecycleScope.launch {
            val bitmap = try {
                withContext(Dispatchers.IO) {
                    contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it) }
                }
            } catch (e: Exception) {
                null
            }
            if (bitmap == null) {
                progLog("Failed to decode the selected image")
                return@launch
            }
            val ok = programmerController.displayBitmap(bitmap)
            bitmap.recycle()
            progLog(if (ok) "Image drawn (scaled + thresholded to 1-bit)" else "Init the display first")
        }
    }

    // ---- I2C-over-TCP -----------------------------------------------------------

    private fun onI2cTcpToggleClicked() {
        if (programmerController.isI2cTcpServerRunning) {
            programmerController.stopI2cTcpServer()
            progBinding.tvI2cTcpStatus.text = getString(R.string.prog_i2ctcp_not_running)
            progBinding.btnI2cTcpToggle.text = getString(R.string.prog_i2ctcp_start)
            progLog("I2C-over-TCP server stopped")
            return
        }
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first")
            return
        }
        if (currentProgMode == ProgrammerMode.SPI_FLASH) {
            progLog("I2C-over-TCP isn't available in SPI Flash mode - connect in I2C EEPROM or SSD1306 Display mode instead")
            return
        }
        val port = progBinding.etI2cTcpPort.text.toString().toIntOrNull()
        if (port == null || port !in 1..65535) {
            progLog("Enter a valid port number (1-65535)")
            return
        }
        try {
            programmerController.startI2cTcpServer(
                port = port,
                onClientConnected = { addr -> runOnUiThread { progLog("I2C-over-TCP client connected: $addr") } },
                onClientDisconnected = { addr -> runOnUiThread { progLog("I2C-over-TCP client disconnected: $addr") } },
                onError = { e -> runOnUiThread { progLog("I2C-over-TCP error: ${e.message}") } }
            )
            progBinding.tvI2cTcpStatus.text = "Listening on ${localIpAddress()}:$port"
            progBinding.btnI2cTcpToggle.text = getString(R.string.prog_i2ctcp_stop)
            progLog("I2C-over-TCP server started on port $port")
        } catch (e: Exception) {
            progLog("Failed to start I2C-over-TCP server: ${e.message}")
        }
    }

    private fun localIpAddress(): String {
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val iface = interfaces.nextElement()
                val addresses = iface.inetAddresses
                while (addresses.hasMoreElements()) {
                    val addr = addresses.nextElement()
                    if (!addr.isLoopbackAddress && addr is Inet4Address) {
                        return addr.hostAddress ?: "unknown"
                    }
                }
            }
        } catch (_: Exception) {
        }
        return "unknown"
    }

    // ---- file I/O (Storage Access Framework) -----------------------------------

    private fun suggestedFileName(prefix: String, sizeBytes: Int): String {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        return "${prefix}_${sizeBytes}B_$stamp.bin"
    }

    private fun writeBytesToUri(uri: Uri, data: ByteArray, label: String) {
        lifecycleScope.launch {
            val ok = try {
                withContext(Dispatchers.IO) {
                    contentResolver.openOutputStream(uri)?.use { it.write(data) }
                    true
                }
            } catch (e: Exception) {
                false
            }
            progLog(if (ok) "$label saved (${data.size} bytes)" else "Failed to save $label")
        }
    }

    private fun readBytesFromUri(uri: Uri, onLoaded: (ByteArray) -> Unit) {
        lifecycleScope.launch {
            val bytes = try {
                withContext(Dispatchers.IO) { contentResolver.openInputStream(uri)?.use { it.readBytes() } }
            } catch (e: Exception) {
                null
            }
            if (bytes != null) onLoaded(bytes) else progLog("Failed to read the selected file")
        }
    }

    private fun formatSize(bytes: Long): String = when {
        bytes <= 0 -> "unknown size"
        bytes >= 1024 * 1024 -> "%.0f MB".format(bytes / (1024.0 * 1024.0))
        else -> "%.0f KB".format(bytes / 1024.0)
    }

    // ---- hex dump viewer (like IMSProg's hex editor, minus the editing) --------

    private fun showHexDump(title: String, data: ByteArray) {
        val dialogBinding = DialogHexViewBinding.inflate(layoutInflater)
        dialogBinding.tvHexDumpTitle.text = "$title - ${data.size} bytes"
        dialogBinding.rvHexDump.layoutManager = LinearLayoutManager(this)
        dialogBinding.rvHexDump.adapter = HexDumpAdapter(data)
        dialogBinding.rvHexDump.setHasFixedSize(true)

        val dialog = AlertDialog.Builder(this)
            .setView(dialogBinding.root)
            .create()
        dialogBinding.btnHexDumpClose.setOnClickListener { dialog.dismiss() }
        dialog.show()
        // Let the hex grid use nearly the full screen - the default AlertDialog width is cramped
        // for a 76-character-wide monospace grid even at 8 bytes/row.
        dialog.window?.setLayout(
            (resources.displayMetrics.widthPixels * 0.95).toInt(),
            (resources.displayMetrics.heightPixels * 0.85).toInt()
        )
    }

    // ---- shared progress/log helpers -------------------------------------------

    private fun setProgProgress(percent: Int?) {
        val bar = progBinding.progressProgrammer
        if (percent == null) {
            bar.visibility = View.INVISIBLE
        } else {
            bar.visibility = View.VISIBLE
            bar.progress = percent.coerceIn(0, 100)
        }
    }

    private fun progLog(message: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        progBinding.tvProgLog.append("[$time] $message\n")
        progBinding.scrollProgLog.post { progBinding.scrollProgLog.fullScroll(View.FOCUS_DOWN) }
    }
}
