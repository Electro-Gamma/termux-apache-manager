package com.tcpuartbridge.app

import android.hardware.usb.UsbDevice
import android.net.Uri
import android.os.Bundle
import android.text.InputFilter
import android.text.InputType
import android.view.LayoutInflater
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.tcpuartbridge.app.databinding.ActivityMainBinding
import com.tcpuartbridge.app.eeprom.I2cEeprom
import com.tcpuartbridge.app.eeprom.SpiFlashDatabase
import com.tcpuartbridge.app.programmer.ProgrammerController
import com.tcpuartbridge.app.programmer.ProgrammerMode
import com.tcpuartbridge.app.ui.HexEditorAdapter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.random.Random
import java.text.SimpleDateFormat
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Date
import java.util.Locale

/**
 * CH341A programmer app - I2C EEPROM (24Cxx) read/write, SPI NOR flash (25xx) read/erase/write,
 * and a small SSD1306 I2C OLED display driver, all over the CH341A's USB "parallel/EPP"
 * (programmer) mode. Also exposes an I2C-over-TCP server so another device on the network can run
 * I2C transactions against whatever's wired to the CH341A.
 *
 * The Programmer screen's visual design (top bar, cards, hex dump grid, log panel, colors for
 * both light and dark mode) is a direct implementation of a supplied design mockup
 * (screen_light_mode.html / screen_night_mode.html) - see values/colors.xml and
 * values-night/colors.xml for the token-for-token color mapping.
 *
 * This talks to the CH341A's programmer-mode USB personality via [Ch341UsbDevice] - see that
 * class's doc for why it needs its own connect/open/claim-interface flow rather than a standard
 * serial port.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val progBinding get() = binding.includeProgrammer

    private val programmerController by lazy { ProgrammerController(applicationContext) }
    private var currentProgMode = ProgrammerMode.I2C_EEPROM
    private var progConnectedDevice: UsbDevice? = null

    private val progModeLabels = arrayOf("I2C EEPROM (24Cxx)", "SPI Flash (25xx)", "SSD1306 OLED Display")
    private val progModeValues = arrayOf(ProgrammerMode.I2C_EEPROM, ProgrammerMode.SPI_FLASH, ProgrammerMode.SSD1306_DISPLAY)

    // ---- I2C EEPROM chip selection --------------------------------------------
    // Spinner layout: [0] "Detect Chip" (triggers the wraparound size probe against
    // lastEepromBaseChip) | [1..N] real presets | [last] "Custom size..." (prompts a dialog).
    private val eepromChipLabels = listOf("Detect Chip") + I2cEeprom.COMMON_CHIPS.map { it.name } + listOf("Custom size…")
    private var selectedEepromChip: I2cEeprom.Chip = I2cEeprom.COMMON_CHIPS.first()
    private var lastEepromBaseChip: I2cEeprom.Chip = I2cEeprom.COMMON_CHIPS.first()
    private var suppressEepromSpinnerCallback = false

    // ---- SPI flash chip selection ----------------------------------------------
    private val spiChipLabels = listOf("Detect Chip") + SpiFlashDatabase.COMMON_CHIPS.map { it.name } + listOf("Custom size…")
    private var selectedSpiChip: SpiFlashDatabase.ChipPreset = SpiFlashDatabase.COMMON_CHIPS.first()
    private var suppressSpiSpinnerCallback = false

    private val oledSizeLabels = arrayOf("128 x 64", "128 x 32", "96 x 16")
    private val oledSizeValues = arrayOf(128 to 64, 128 to 32, 96 to 16)
    private var selectedOledSize = oledSizeValues.first()

    /** Live, editable buffers backing each panel's embedded hex editor - populated by Read, Load
     *  File, Erase, or Write Random, edited in place by tapping a byte or ASCII character, and
     *  what Write/Verify/Dump act on. Seeded with [PLACEHOLDER_HEX_DATA] (not an empty buffer) so
     *  the grid is never blank on first launch, before any connection. `var` because
     *  [fitEepromHexToWidth]/[fitSpiHexToWidth] replace each with a freshly-fitted instance (same
     *  data, different text size/cell width) once the real screen width is known -
     *  [HexEditorAdapter] itself can't re-fit in place since its row holders are built with
     *  fixed-size child cells. */
    private var eepromHexAdapter = HexEditorAdapter(PLACEHOLDER_HEX_DATA.copyOf(), 13f, 20f, 12f,
        onByteTapped = { offset -> onEepromByteTapped(offset) },
        onAsciiTapped = { offset -> onEepromAsciiTapped(offset) })
    private var spiHexAdapter = HexEditorAdapter(PLACEHOLDER_HEX_DATA.copyOf(), 13f, 20f, 12f,
        onByteTapped = { offset -> onSpiByteTapped(offset) },
        onAsciiTapped = { offset -> onSpiAsciiTapped(offset) })

    private var logExpanded = true

    // ---- Storage Access Framework pickers for dump files --------------------

    private val eepromSaveLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
            if (uri != null) writeBytesToUri(uri, eepromHexAdapter.currentData(), "EEPROM dump")
        }

    private val eepromOpenLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) readBytesFromUri(uri) { bytes -> onEepromFileLoaded(bytes) }
        }

    private val spiSaveLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
            if (uri != null) writeBytesToUri(uri, spiHexAdapter.currentData(), "SPI flash dump")
        }

    private val spiOpenLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) readBytesFromUri(uri) { bytes -> onSpiFileLoaded(bytes) }
        }

    private val oledImageLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) onOledImageChosen(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupProgrammerUi()
    }

    override fun onDestroy() {
        super.onDestroy()
        // Plain synchronous close (not the suspend disconnect()) - the activity is on its way
        // out, so there's no coroutine scope left to safely launch into.
        programmerController.stopI2cTcpServer()
        programmerController.usbDevice.close()
    }

    // ==================== CH341A: I2C EEPROM / SPI flash / SSD1306 ====================

    private fun setupProgrammerUi() {
        val p = progBinding

        p.spinnerProgMode.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, progModeLabels)
        p.spinnerProgMode.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                currentProgMode = progModeValues[position]
                p.llI2cPanel.visibility = if (currentProgMode == ProgrammerMode.I2C_EEPROM) View.VISIBLE else View.GONE
                p.llSpiPanel.visibility = if (currentProgMode == ProgrammerMode.SPI_FLASH) View.VISIBLE else View.GONE
                p.llDisplayPanel.visibility = if (currentProgMode == ProgrammerMode.SSD1306_DISPLAY) View.VISIBLE else View.GONE
                p.llI2cTcpPanel.visibility = if (currentProgMode == ProgrammerMode.SPI_FLASH) View.GONE else View.VISIBLE
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        p.spinnerEepromChip.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, eepromChipLabels)
        p.spinnerEepromChip.setSelection(1) // default to the smallest real preset, not "Detect Chip"
        p.spinnerEepromChip.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (suppressEepromSpinnerCallback) return
                val presetIndex = position - 1
                when {
                    position == 0 -> onEepromDetectClicked()
                    presetIndex in I2cEeprom.COMMON_CHIPS.indices -> {
                        selectedEepromChip = I2cEeprom.COMMON_CHIPS[presetIndex]
                        lastEepromBaseChip = selectedEepromChip
                        populateEepromChipInfo(selectedEepromChip)
                    }
                    else -> showEepromCustomSizeDialog()
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        p.spinnerOledSize.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, oledSizeLabels)
        p.spinnerOledSize.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedOledSize = oledSizeValues[position]
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        p.spinnerSpiChip.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, spiChipLabels)
        p.spinnerSpiChip.setSelection(1)
        p.spinnerSpiChip.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (suppressSpiSpinnerCallback) return
                val presetIndex = position - 1
                when {
                    position == 0 -> onSpiDetectClicked()
                    presetIndex in SpiFlashDatabase.COMMON_CHIPS.indices -> {
                        selectedSpiChip = SpiFlashDatabase.COMMON_CHIPS[presetIndex]
                        lifecycleScope.launch { programmerController.configureSpiAddressing(selectedSpiChip.sizeBytes) }
                        populateSpiChipInfo(selectedSpiChip, jedecHex = null)
                    }
                    else -> showSpiCustomSizeDialog()
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        p.btnProgConnect.setOnClickListener { onProgConnectClicked() }

        p.btnEepromRead.setOnClickListener { onEepromReadClicked() }
        p.btnEepromWrite.setOnClickListener { onEepromWriteClicked() }
        p.btnEepromErase.setOnClickListener { onEepromEraseClicked() }
        p.btnEepromVerify.setOnClickListener { onEepromVerifyClicked() }
        p.btnEepromDump.setOnClickListener { onEepromSaveFileClicked() }
        p.btnEepromRandom.setOnClickListener { onEepromRandomClicked() }
        p.btnEepromDetect.setOnClickListener { onEepromDetectClicked() }
        p.btnEepromLoadFile.setOnClickListener { onEepromLoadFileClicked() }
        p.btnEepromSaveFile.setOnClickListener { onEepromSaveFileClicked() }
        p.tabEepromHexDump.setOnClickListener { setEepromTab(showHex = true) }
        p.tabEepromFileBuffer.setOnClickListener { setEepromTab(showHex = false) }

        p.btnSpiReadId.setOnClickListener { onSpiDetectClicked() }
        p.btnSpiRead.setOnClickListener { onSpiReadClicked() }
        p.btnSpiErase.setOnClickListener { onSpiEraseClicked() }
        p.btnSpiVerify.setOnClickListener { onSpiVerifyClicked() }
        p.btnSpiDump.setOnClickListener { onSpiSaveFileClicked() }
        p.btnSpiWrite.setOnClickListener { onSpiWriteClicked() }
        p.btnSpiRandom.setOnClickListener { onSpiRandomClicked() }
        p.btnSpiLoadFile.setOnClickListener { onSpiLoadFileClicked() }
        p.btnSpiSaveFile.setOnClickListener { onSpiSaveFileClicked() }
        p.tabSpiHexDump.setOnClickListener { setSpiTab(showHex = true) }
        p.tabSpiFileBuffer.setOnClickListener { setSpiTab(showHex = false) }

        p.btnOledInit.setOnClickListener { onOledInitClicked() }
        p.btnOledTest.setOnClickListener { onOledTestClicked() }
        p.btnOledClear.setOnClickListener { onOledClearClicked() }
        p.btnOledDrawText.setOnClickListener { onOledDrawTextClicked() }
        p.btnOledLoadImage.setOnClickListener { onOledLoadImageClicked() }
        p.btnI2cTcpToggle.setOnClickListener { onI2cTcpToggleClicked() }
        p.llLogHeader.setOnClickListener { toggleLogPanel() }

        p.rvEepromHex.layoutManager = LinearLayoutManager(this)
        p.rvEepromHex.adapter = eepromHexAdapter
        p.rvEepromHex.setHasFixedSize(true)
        p.rvEepromHex.post { fitEepromHexToWidth(p.rvEepromHex.width) }

        p.rvSpiHex.layoutManager = LinearLayoutManager(this)
        p.rvSpiHex.adapter = spiHexAdapter
        p.rvSpiHex.setHasFixedSize(true)
        p.rvSpiHex.post { fitSpiHexToWidth(p.rvSpiHex.width) }

        populateEepromChipInfo(selectedEepromChip)
        populateSpiChipInfo(selectedSpiChip, jedecHex = null)
        refreshEepromHexInfo("sample data, not from a chip")
        refreshSpiHexInfo("sample data, not from a chip")
        updateProgConnectionUi(false)
    }

    /** Swaps in a freshly-fitted [HexEditorAdapter] once [widthPx] (the RecyclerView's real,
     *  laid-out width) is known, so all 16 bytes/row exactly fill the screen with no leftover and
     *  never need horizontal scrolling - see [HexEditorAdapter.computeFit]. */
    private fun fitEepromHexToWidth(widthPx: Int) {
        if (widthPx <= 0) return
        val fit = HexEditorAdapter.computeFit(widthPx, resources.displayMetrics.density)
        eepromHexAdapter = HexEditorAdapter(
            eepromHexAdapter.currentData(), fit.textSizeSp, fit.hexCellWidthDp, fit.asciiCellWidthDp,
            onByteTapped = { offset -> onEepromByteTapped(offset) },
            onAsciiTapped = { offset -> onEepromAsciiTapped(offset) }
        )
        progBinding.rvEepromHex.adapter = eepromHexAdapter
    }

    private fun fitSpiHexToWidth(widthPx: Int) {
        if (widthPx <= 0) return
        val fit = HexEditorAdapter.computeFit(widthPx, resources.displayMetrics.density)
        spiHexAdapter = HexEditorAdapter(
            spiHexAdapter.currentData(), fit.textSizeSp, fit.hexCellWidthDp, fit.asciiCellWidthDp,
            onByteTapped = { offset -> onSpiByteTapped(offset) },
            onAsciiTapped = { offset -> onSpiAsciiTapped(offset) }
        )
        progBinding.rvSpiHex.adapter = spiHexAdapter
    }

    // ---- Hex Dump / File+Buffer tab switching ----------------------------------

    private fun setEepromTab(showHex: Boolean) {
        progBinding.panelEepromHexDump.visibility = if (showHex) View.VISIBLE else View.GONE
        progBinding.panelEepromFileBuffer.visibility = if (showHex) View.GONE else View.VISIBLE
        styleTab(progBinding.tabEepromHexDump, active = showHex)
        styleTab(progBinding.tabEepromFileBuffer, active = !showHex)
    }

    private fun setSpiTab(showHex: Boolean) {
        progBinding.panelSpiHexDump.visibility = if (showHex) View.VISIBLE else View.GONE
        progBinding.panelSpiFileBuffer.visibility = if (showHex) View.GONE else View.VISIBLE
        styleTab(progBinding.tabSpiHexDump, active = showHex)
        styleTab(progBinding.tabSpiFileBuffer, active = !showHex)
    }

    private fun styleTab(button: android.widget.Button, active: Boolean) {
        if (active) {
            button.setBackgroundResource(R.drawable.bg_prog_tab_active)
            button.setTextColor(getColor(android.R.color.white))
        } else {
            button.background = null
            button.setTextColor(getColor(R.color.prog_tab_inactive_text))
        }
    }

    // ---- connect / disconnect ----------------------------------------------

    private fun updateProgConnectionUi(connected: Boolean) {
        progBinding.tvProgStatus.text = if (connected) {
            getString(R.string.prog_connected)
        } else {
            getString(R.string.prog_not_connected)
        }
        progBinding.btnProgConnect.text = getString(if (connected) R.string.prog_disconnect else R.string.prog_connect)
        progBinding.spinnerProgMode.isEnabled = !connected
        if (!connected) {
            // disconnect() always stops the I2C-over-TCP server too - reflect that here.
            progBinding.tvI2cTcpStatus.text = getString(R.string.prog_i2ctcp_not_running)
            progBinding.btnI2cTcpToggle.text = getString(R.string.prog_i2ctcp_start)
        }
    }

    private fun onProgConnectClicked() {
        if (programmerController.isConnected) {
            lifecycleScope.launch {
                programmerController.disconnect(currentProgMode)
                progConnectedDevice = null
                updateProgConnectionUi(false)
                progLog("Disconnected")
            }
            return
        }

        val dev = programmerController.findDevice()
        if (dev == null) {
            progLog("No CH341A programmer found - plug it in (VID 1A86 / PID 5512) and tap Connect again", LogLevel.WARN)
            return
        }

        if (programmerController.hasPermission(dev)) {
            connectToProgrammerDevice(dev)
        } else {
            programmerController.requestPermission(dev) { granted ->
                if (granted) connectToProgrammerDevice(dev) else progLog("USB permission denied", LogLevel.ERROR)
            }
        }
    }

    private fun connectToProgrammerDevice(dev: UsbDevice) {
        lifecycleScope.launch {
            val ok = programmerController.connect(dev, currentProgMode)
            if (ok) {
                progConnectedDevice = dev
                updateProgConnectionUi(true)
                progLog("Connected: ${programmerController.usbDevice.deviceLabel()}")
            } else {
                progLog("Failed to open/initialize the CH341A", LogLevel.ERROR)
            }
        }
    }

    // ---- I2C EEPROM ---------------------------------------------------------

    private fun populateEepromChipInfo(chip: I2cEeprom.Chip) {
        progBinding.tvEepromManufacturer.text = getString(R.string.prog_value_placeholder)
        progBinding.tvEepromChipName.text = ": ${chip.name}"
        progBinding.tvEepromCapacity.text = ": ${formatSize(chip.totalBytes.toLong())}"
        progBinding.tvEepromPageSize.text = ": ${chip.pageSize} B"
        progBinding.tvEepromVcc.text = ": 3.3 V"
        progBinding.tvEepromFreq.text = ": 400 kHz" // Ch341I2c.SPEED_400K - the actual configured bus speed
    }

    private fun showEepromCustomSizeDialog() {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            hint = "Size in bytes"
            val pad = (20 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad / 2, pad, 0)
        }
        AlertDialog.Builder(this)
            .setTitle("Custom EEPROM size")
            .setMessage("Assumes 2-byte word addressing / 32-byte pages (typical for 32Kbit+ EEPROMs).")
            .setView(input)
            .setPositiveButton("OK") { _, _ ->
                val size = input.text.toString().toIntOrNull()
                if (size == null || size <= 0) {
                    progLog("Enter a valid size in bytes", LogLevel.WARN)
                    revertEepromSpinnerToPreset()
                } else {
                    selectedEepromChip = I2cEeprom.Chip("Custom ($size B)", size, pageSize = 32, algorithm = 0x02)
                    lastEepromBaseChip = selectedEepromChip
                    populateEepromChipInfo(selectedEepromChip)
                }
            }
            .setNegativeButton("Cancel") { _, _ -> revertEepromSpinnerToPreset() }
            .setOnCancelListener { revertEepromSpinnerToPreset() }
            .show()
    }

    private fun revertEepromSpinnerToPreset() {
        val index = I2cEeprom.COMMON_CHIPS.indexOf(selectedEepromChip)
        suppressEepromSpinnerCallback = true
        progBinding.spinnerEepromChip.setSelection(if (index >= 0) index + 1 else 1)
        suppressEepromSpinnerCallback = false
    }

    private fun onEepromReadClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first", LogLevel.WARN)
            return
        }
        val chip = selectedEepromChip
        lifecycleScope.launch {
            setProgProgress(0)
            progLog("Reading ${chip.name}...")
            val data = programmerController.readEeprom(chip) { done, total ->
                runOnUiThread { setProgProgress(if (total > 0) done * 100 / total else 100) }
            }
            setProgProgress(null)
            if (data != null) {
                eepromHexAdapter.replaceData(data)
                refreshEepromHexInfo("from chip")
                progLog("Read ${data.size} bytes")
            } else {
                progLog("EEPROM read failed - check wiring and that a chip is present", LogLevel.ERROR)
            }
        }
    }

    private fun onEepromWriteClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first", LogLevel.WARN)
            return
        }
        val chip = selectedEepromChip
        val live = eepromHexAdapter.currentData()
        if (live.isEmpty()) {
            progLog("Nothing to write - tap Read or Load File first", LogLevel.WARN)
            return
        }
        // Snapshot rather than write the adapter's live array directly - it stays editable by the
        // user (tapping a byte) while this write is streaming, and the two shouldn't race.
        val data = if (live.size > chip.totalBytes) {
            progLog("Hex editor has ${live.size} B, larger than ${chip.name} (${chip.totalBytes} B) - truncating", LogLevel.WARN)
            live.copyOf(chip.totalBytes).also { eepromHexAdapter.replaceData(it) }
        } else {
            live.copyOf()
        }
        lifecycleScope.launch {
            setProgProgress(0)
            progLog("Writing ${data.size} bytes to ${chip.name}...")
            val ok = programmerController.writeEeprom(chip, data) { done, total ->
                runOnUiThread { setProgProgress(if (total > 0) done * 100 / total else 100) }
            }
            setProgProgress(null)
            progLog(if (ok) "EEPROM write complete" else "EEPROM write failed", if (ok) LogLevel.INFO else LogLevel.ERROR)
        }
    }

    private fun onEepromVerifyClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first", LogLevel.WARN)
            return
        }
        val expected = eepromHexAdapter.currentData()
        if (expected.isEmpty()) {
            progLog("Nothing to verify against - tap Read or Load File first", LogLevel.WARN)
            return
        }
        val chip = selectedEepromChip
        lifecycleScope.launch {
            setProgProgress(0)
            progLog("Verifying ${expected.size} bytes against ${chip.name}...")
            val actual = programmerController.readEeprom(chip) { done, total ->
                runOnUiThread { setProgProgress(if (total > 0) done * 100 / total else 100) }
            }
            setProgProgress(null)
            reportVerifyResult(actual, expected)
        }
    }

    private fun onEepromLoadFileClicked() {
        progLog("Choose a file to load into the hex editor...")
        eepromOpenLauncher.launch(arrayOf("*/*"))
    }

    private fun onEepromFileLoaded(bytes: ByteArray) {
        eepromHexAdapter.replaceData(bytes)
        refreshEepromHexInfo("from file")
        progLog("Loaded ${bytes.size} bytes into the hex editor")
        setEepromTab(showHex = true)
    }

    private fun onEepromSaveFileClicked() {
        val data = eepromHexAdapter.currentData()
        if (data.isEmpty()) {
            progLog("Nothing to save - tap Read or Load File first", LogLevel.WARN)
            return
        }
        eepromSaveLauncher.launch(suggestedFileName("eeprom_dump", data.size))
    }

    private fun onEepromEraseClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first", LogLevel.WARN)
            return
        }
        val chip = selectedEepromChip
        AlertDialog.Builder(this)
            .setTitle("Erase ${chip.name}?")
            .setMessage("Fills all ${chip.totalBytes} bytes with 0xFF. This cannot be undone. Continue?")
            .setPositiveButton("Erase") { _, _ ->
                lifecycleScope.launch {
                    setProgProgress(0)
                    progLog("Erasing ${chip.name}...")
                    val ok = programmerController.eraseEeprom(chip) { done, total ->
                        runOnUiThread { setProgProgress(if (total > 0) done * 100 / total else 100) }
                    }
                    setProgProgress(null)
                    progLog(if (ok) "Erase complete" else "Erase failed", if (ok) LogLevel.INFO else LogLevel.ERROR)
                    if (ok) {
                        eepromHexAdapter.replaceData(ByteArray(chip.totalBytes) { 0xFF.toByte() })
                        refreshEepromHexInfo("from chip")
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun onEepromRandomClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first", LogLevel.WARN)
            return
        }
        val chip = selectedEepromChip
        AlertDialog.Builder(this)
            .setTitle("Write random data to ${chip.name}?")
            .setMessage("Overwrites all ${chip.totalBytes} bytes with random data. This cannot be undone. Continue?")
            .setPositiveButton("Write Random") { _, _ ->
                val randomData = ByteArray(chip.totalBytes)
                Random.nextBytes(randomData)
                lifecycleScope.launch {
                    setProgProgress(0)
                    progLog("Writing random data to ${chip.name}...")
                    val ok = programmerController.writeEeprom(chip, randomData) { done, total ->
                        runOnUiThread { setProgProgress(if (total > 0) done * 100 / total else 100) }
                    }
                    setProgProgress(null)
                    progLog(if (ok) "Random write complete" else "Random write failed", if (ok) LogLevel.INFO else LogLevel.ERROR)
                    if (ok) {
                        eepromHexAdapter.replaceData(randomData)
                        refreshEepromHexInfo("from chip")
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun onEepromDetectClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first", LogLevel.WARN)
            revertEepromSpinnerToPreset()
            return
        }
        val chip = lastEepromBaseChip
        AlertDialog.Builder(this)
            .setTitle("Detect chip size?")
            .setMessage(
                "Briefly overwrites byte 0 to find where the chip's address wraps around, then " +
                    "restores it. Only tries chips with the same address-byte width as \"${chip.name}\" " +
                    "- pick roughly the right chip (small vs. large) first. Continue?"
            )
            .setPositiveButton("Detect") { _, _ ->
                lifecycleScope.launch {
                    progLog("Detecting size (probing against ${chip.name}'s address family)...")
                    val result = programmerController.detectEepromSize(chip)
                    if (result == null) {
                        progLog("Detection failed - check wiring, that a chip is present, or try a different starting chip", LogLevel.ERROR)
                        revertEepromSpinnerToPreset()
                        return@launch
                    }
                    val detected = result.chip
                    selectedEepromChip = detected
                    lastEepromBaseChip = detected
                    populateEepromChipInfo(detected)
                    val index = I2cEeprom.COMMON_CHIPS.indexOf(detected)
                    suppressEepromSpinnerCallback = true
                    if (index >= 0) progBinding.spinnerEepromChip.setSelection(index + 1)
                    suppressEepromSpinnerCallback = false
                    progLog(
                        if (result.confirmed) "Detected: ${detected.name}"
                        else "Could only confirm it's at least ${detected.name} - larger sizes in this family can't be told apart this way",
                        if (result.confirmed) LogLevel.INFO else LogLevel.WARN
                    )
                }
            }
            .setNegativeButton("Cancel") { _, _ -> revertEepromSpinnerToPreset() }
            .setOnCancelListener { revertEepromSpinnerToPreset() }
            .show()
    }

    private fun onEepromByteTapped(offset: Int) {
        showByteEditDialog(eepromHexAdapter, offset) { refreshEepromHexInfo("edited, not written yet") }
    }

    private fun onEepromAsciiTapped(offset: Int) {
        showAsciiEditDialog(eepromHexAdapter, offset) { refreshEepromHexInfo("edited, not written yet") }
    }

    private fun refreshEepromHexInfo(source: String) {
        val n = eepromHexAdapter.currentData().size
        progBinding.tvEepromHexInfo.text = if (n == 0) getString(R.string.prog_hex_no_data) else "$n bytes - $source"
    }

    // ---- SPI flash ------------------------------------------------------------

    private fun populateSpiChipInfo(chip: SpiFlashDatabase.ChipPreset, jedecHex: String?) {
        progBinding.tvSpiManufacturer.text = ": ${chip.manufacturer}"
        progBinding.tvSpiChipName.text = ": ${chip.name}"
        progBinding.tvSpiJedecId.text = if (jedecHex != null) ": $jedecHex" else getString(R.string.prog_value_placeholder)
        progBinding.tvSpiCapacity.text = ": ${formatSize(chip.sizeBytes)}"
        progBinding.tvSpiPageSize.text = ": ${chip.pageSize} B"
        progBinding.tvSpiSectorSize.text = ": ${chip.sectorSize / 1024} KB"
        progBinding.tvSpiVcc.text = ": 3.3 V"
        progBinding.tvSpiFreq.text = getString(R.string.prog_value_placeholder) // not user-configurable in Ch341Spi
    }

    private fun showSpiCustomSizeDialog() {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            hint = "Size in KB"
            val pad = (20 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad / 2, pad, 0)
        }
        AlertDialog.Builder(this)
            .setTitle("Custom SPI flash size")
            .setView(input)
            .setPositiveButton("OK") { _, _ ->
                val kb = input.text.toString().toIntOrNull()
                if (kb == null || kb <= 0) {
                    progLog("Enter a valid size in KB", LogLevel.WARN)
                    revertSpiSpinnerToPreset()
                } else {
                    selectedSpiChip = SpiFlashDatabase.ChipPreset("Unknown", "Custom (${kb} KB)", kb.toLong() * 1024)
                    lifecycleScope.launch { programmerController.configureSpiAddressing(selectedSpiChip.sizeBytes) }
                    populateSpiChipInfo(selectedSpiChip, jedecHex = null)
                }
            }
            .setNegativeButton("Cancel") { _, _ -> revertSpiSpinnerToPreset() }
            .setOnCancelListener { revertSpiSpinnerToPreset() }
            .show()
    }

    private fun revertSpiSpinnerToPreset() {
        val index = SpiFlashDatabase.COMMON_CHIPS.indexOf(selectedSpiChip)
        suppressSpiSpinnerCallback = true
        progBinding.spinnerSpiChip.setSelection(if (index >= 0) index + 1 else 1)
        suppressSpiSpinnerCallback = false
    }

    private fun onSpiDetectClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first", LogLevel.WARN)
            revertSpiSpinnerToPreset()
            return
        }
        lifecycleScope.launch {
            val id = programmerController.readSpiJedecId()
            val chip = programmerController.detectSpiChip()
            if (chip == null || id == null) {
                progLog("Failed to read JEDEC ID - check wiring/chip", LogLevel.ERROR)
                revertSpiSpinnerToPreset()
                return@launch
            }
            val jedecHex = "%02X %02X %02X".format(id.manufacturer, id.memoryType, id.capacityCode)
            selectedSpiChip = chip
            populateSpiChipInfo(chip, jedecHex)
            programmerController.configureSpiAddressing(chip.sizeBytes)
            val index = SpiFlashDatabase.COMMON_CHIPS.indexOfFirst { it.name == chip.name }
            suppressSpiSpinnerCallback = true
            progBinding.spinnerSpiChip.setSelection(if (index >= 0) index + 1 else spiChipLabels.size - 1)
            suppressSpiSpinnerCallback = false
            progLog("Detected: ${chip.manufacturer} ${chip.name}")
        }
    }

    private fun onSpiRandomClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first", LogLevel.WARN)
            return
        }
        val chip = selectedSpiChip
        AlertDialog.Builder(this)
            .setTitle("Write random data?")
            .setMessage("Erases and overwrites ${formatSize(chip.sizeBytes)} with random data. This cannot be undone. Continue?")
            .setPositiveButton("Write Random") { _, _ ->
                val randomData = ByteArray(chip.sizeBytes.toInt())
                Random.nextBytes(randomData)
                lifecycleScope.launch {
                    programmerController.configureSpiAddressing(chip.sizeBytes)
                    setProgProgress(0)
                    progLog("Writing random data to SPI flash...")
                    val ok = programmerController.writeSpiFlash(randomData, chip.pageSize) { done, total ->
                        runOnUiThread { setProgProgress(if (total > 0) done * 100 / total else 100) }
                    }
                    setProgProgress(null)
                    progLog(if (ok) "Random write complete" else "Random write failed", if (ok) LogLevel.INFO else LogLevel.ERROR)
                    if (ok) {
                        spiHexAdapter.replaceData(randomData)
                        refreshSpiHexInfo("from chip")
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun onSpiReadClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first", LogLevel.WARN)
            return
        }
        val chip = selectedSpiChip
        lifecycleScope.launch {
            programmerController.configureSpiAddressing(chip.sizeBytes)
            setProgProgress(0)
            progLog("Reading ${formatSize(chip.sizeBytes)} from SPI flash...")
            val data = programmerController.readSpiFlash(chip.sizeBytes.toInt()) { done, total ->
                runOnUiThread { setProgProgress(if (total > 0) done * 100 / total else 100) }
            }
            setProgProgress(null)
            if (data != null) {
                spiHexAdapter.replaceData(data)
                refreshSpiHexInfo("from chip")
                progLog("Read ${data.size} bytes")
            } else {
                progLog("SPI flash read failed - check wiring and that a chip is present", LogLevel.ERROR)
            }
        }
    }

    private fun onSpiVerifyClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first", LogLevel.WARN)
            return
        }
        val expected = spiHexAdapter.currentData()
        if (expected.isEmpty()) {
            progLog("Nothing to verify against - tap Read or Load File first", LogLevel.WARN)
            return
        }
        lifecycleScope.launch {
            programmerController.configureSpiAddressing(maxOf(selectedSpiChip.sizeBytes, expected.size.toLong()))
            setProgProgress(0)
            progLog("Verifying ${expected.size} bytes against SPI flash...")
            val actual = programmerController.readSpiFlash(expected.size) { done, total ->
                runOnUiThread { setProgProgress(if (total > 0) done * 100 / total else 100) }
            }
            setProgProgress(null)
            reportVerifyResult(actual, expected)
        }
    }

    private fun onSpiEraseClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first", LogLevel.WARN)
            return
        }
        val chip = selectedSpiChip
        AlertDialog.Builder(this)
            .setTitle("Erase entire SPI flash chip?")
            .setMessage("This wipes the whole chip (${formatSize(chip.sizeBytes)}) and cannot be undone. Continue?")
            .setPositiveButton("Erase") { _, _ ->
                lifecycleScope.launch {
                    programmerController.configureSpiAddressing(chip.sizeBytes)
                    setProgProgress(0)
                    progLog("Erasing SPI flash chip - this can take a while...")
                    val ok = programmerController.eraseSpiFlashChip()
                    setProgProgress(null)
                    progLog(if (ok) "Chip erase complete" else "Chip erase failed", if (ok) LogLevel.INFO else LogLevel.ERROR)
                    if (ok && chip.sizeBytes in 1..Int.MAX_VALUE.toLong()) {
                        spiHexAdapter.replaceData(ByteArray(chip.sizeBytes.toInt()) { 0xFF.toByte() })
                        refreshSpiHexInfo("from chip")
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun onSpiWriteClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first", LogLevel.WARN)
            return
        }
        val live = spiHexAdapter.currentData()
        if (live.isEmpty()) {
            progLog("Nothing to write - tap Read or Load File first", LogLevel.WARN)
            return
        }
        val data = live.copyOf() // snapshot - the adapter's live array stays editable during the write
        val pageSize = selectedSpiChip.pageSize
        lifecycleScope.launch {
            programmerController.configureSpiAddressing(maxOf(selectedSpiChip.sizeBytes, data.size.toLong()))
            setProgProgress(0)
            progLog("Erasing + writing ${data.size} bytes to SPI flash (page size $pageSize B)...")
            val ok = programmerController.writeSpiFlash(data, pageSize) { done, total ->
                runOnUiThread { setProgProgress(if (total > 0) done * 100 / total else 100) }
            }
            setProgProgress(null)
            progLog(if (ok) "SPI flash write complete" else "SPI flash write failed", if (ok) LogLevel.INFO else LogLevel.ERROR)
        }
    }

    private fun onSpiLoadFileClicked() {
        progLog("Choose a file to load into the hex editor...")
        spiOpenLauncher.launch(arrayOf("*/*"))
    }

    private fun onSpiFileLoaded(bytes: ByteArray) {
        spiHexAdapter.replaceData(bytes)
        refreshSpiHexInfo("from file")
        progLog("Loaded ${bytes.size} bytes into the hex editor")
        setSpiTab(showHex = true)
    }

    private fun onSpiSaveFileClicked() {
        val data = spiHexAdapter.currentData()
        if (data.isEmpty()) {
            progLog("Nothing to save - tap Read or Load File first", LogLevel.WARN)
            return
        }
        spiSaveLauncher.launch(suggestedFileName("spi_flash_dump", data.size))
    }

    private fun onSpiByteTapped(offset: Int) {
        showByteEditDialog(spiHexAdapter, offset) { refreshSpiHexInfo("edited, not written yet") }
    }

    private fun onSpiAsciiTapped(offset: Int) {
        showAsciiEditDialog(spiHexAdapter, offset) { refreshSpiHexInfo("edited, not written yet") }
    }

    private fun refreshSpiHexInfo(source: String) {
        val n = spiHexAdapter.currentData().size
        progBinding.tvSpiHexInfo.text = if (n == 0) getString(R.string.prog_hex_no_data) else "$n bytes - $source"
    }

    // ---- Verify (shared by both EEPROM and SPI) --------------------------------

    private fun reportVerifyResult(actual: ByteArray?, expected: ByteArray) {
        if (actual == null) {
            progLog("Verify failed - could not read the chip", LogLevel.ERROR)
            return
        }
        if (actual.size != expected.size) {
            progLog("Verify failed - read back ${actual.size} bytes, expected ${expected.size}", LogLevel.ERROR)
            return
        }
        var firstMismatch = -1
        var mismatchCount = 0
        for (i in expected.indices) {
            if (actual[i] != expected[i]) {
                mismatchCount++
                if (firstMismatch < 0) firstMismatch = i
            }
        }
        if (mismatchCount == 0) {
            progLog("Verify OK - all ${expected.size} bytes match")
        } else {
            progLog(
                "Verify failed - $mismatchCount byte(s) differ, first at offset 0x%X".format(firstMismatch),
                LogLevel.ERROR
            )
        }
    }

    // ---- SSD1306 OLED -----------------------------------------------------------

    private fun parseOledAddress(): Int =
        progBinding.etOledAddress.text.toString().trim()
            .removePrefix("0x").removePrefix("0X")
            .toIntOrNull(16) ?: 0x3C

    private fun onOledInitClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first", LogLevel.WARN)
            return
        }
        val (w, h) = selectedOledSize
        val addr = parseOledAddress()
        lifecycleScope.launch {
            val ok = programmerController.initDisplay(addr, w, h)
            progLog(
                if (ok) "SSD1306 initialized (${w}x$h @ 0x${addr.toString(16)})"
                else "SSD1306 init failed - check address/wiring",
                if (ok) LogLevel.INFO else LogLevel.ERROR
            )
        }
    }

    private fun onOledTestClicked() {
        lifecycleScope.launch {
            val ok = programmerController.displayTestPattern()
            progLog(if (ok) "Test pattern sent" else "Init the display first", if (ok) LogLevel.INFO else LogLevel.WARN)
        }
    }

    private fun onOledClearClicked() {
        lifecycleScope.launch {
            val ok = programmerController.displayClear()
            progLog(if (ok) "Display cleared" else "Init the display first", if (ok) LogLevel.INFO else LogLevel.WARN)
        }
    }

    private fun onOledDrawTextClicked() {
        val text = progBinding.etOledText.text.toString()
        lifecycleScope.launch {
            val ok = programmerController.displayText(text)
            progLog(if (ok) "Text drawn" else "Init the display first", if (ok) LogLevel.INFO else LogLevel.WARN)
        }
    }

    private fun onOledLoadImageClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first", LogLevel.WARN)
            return
        }
        progLog("Choose an image to display...")
        oledImageLauncher.launch(arrayOf("image/*"))
    }

    private fun onOledImageChosen(uri: Uri) {
        lifecycleScope.launch {
            val bitmap = try {
                withContext(Dispatchers.IO) {
                    contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it) }
                }
            } catch (e: Exception) {
                null
            }
            if (bitmap == null) {
                progLog("Failed to decode the selected image", LogLevel.ERROR)
                return@launch
            }
            val ok = programmerController.displayBitmap(bitmap)
            bitmap.recycle()
            progLog(if (ok) "Image drawn (scaled + thresholded to 1-bit)" else "Init the display first", if (ok) LogLevel.INFO else LogLevel.WARN)
        }
    }

    // ---- I2C-over-TCP -----------------------------------------------------------

    private fun onI2cTcpToggleClicked() {
        if (programmerController.isI2cTcpServerRunning) {
            programmerController.stopI2cTcpServer()
            progBinding.tvI2cTcpStatus.text = getString(R.string.prog_i2ctcp_not_running)
            progBinding.btnI2cTcpToggle.text = getString(R.string.prog_i2ctcp_start)
            progLog("I2C-over-TCP server stopped")
            return
        }
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first", LogLevel.WARN)
            return
        }
        if (currentProgMode == ProgrammerMode.SPI_FLASH) {
            progLog("I2C-over-TCP isn't available in SPI Flash mode - connect in I2C EEPROM or SSD1306 Display mode instead", LogLevel.WARN)
            return
        }
        val port = progBinding.etI2cTcpPort.text.toString().toIntOrNull()
        if (port == null || port !in 1..65535) {
            progLog("Enter a valid port number (1-65535)", LogLevel.WARN)
            return
        }
        try {
            programmerController.startI2cTcpServer(
                port = port,
                onClientConnected = { addr -> runOnUiThread { progLog("I2C-over-TCP client connected: $addr") } },
                onClientDisconnected = { addr -> runOnUiThread { progLog("I2C-over-TCP client disconnected: $addr") } },
                onError = { e -> runOnUiThread { progLog("I2C-over-TCP error: ${e.message}", LogLevel.ERROR) } }
            )
            progBinding.tvI2cTcpStatus.text = "Listening on ${localIpAddress()}:$port"
            progBinding.btnI2cTcpToggle.text = getString(R.string.prog_i2ctcp_stop)
            progLog("I2C-over-TCP server started on port $port")
        } catch (e: Exception) {
            progLog("Failed to start I2C-over-TCP server: ${e.message}", LogLevel.ERROR)
        }
    }

    private fun localIpAddress(): String {
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val iface = interfaces.nextElement()
                val addresses = iface.inetAddresses
                while (addresses.hasMoreElements()) {
                    val addr = addresses.nextElement()
                    if (!addr.isLoopbackAddress && addr is Inet4Address) {
                        return addr.hostAddress ?: "unknown"
                    }
                }
            }
        } catch (_: Exception) {
        }
        return "unknown"
    }

    // ---- file I/O (Storage Access Framework) -----------------------------------

    private fun suggestedFileName(prefix: String, sizeBytes: Int): String {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        return "${prefix}_${sizeBytes}B_$stamp.bin"
    }

    private fun writeBytesToUri(uri: Uri, data: ByteArray, label: String) {
        lifecycleScope.launch {
            val ok = try {
                withContext(Dispatchers.IO) {
                    contentResolver.openOutputStream(uri)?.use { it.write(data) }
                    true
                }
            } catch (e: Exception) {
                false
            }
            progLog(if (ok) "$label saved (${data.size} bytes)" else "Failed to save $label", if (ok) LogLevel.INFO else LogLevel.ERROR)
        }
    }

    private fun readBytesFromUri(uri: Uri, onLoaded: (ByteArray) -> Unit) {
        lifecycleScope.launch {
            val bytes = try {
                withContext(Dispatchers.IO) { contentResolver.openInputStream(uri)?.use { it.readBytes() } }
            } catch (e: Exception) {
                null
            }
            if (bytes != null) onLoaded(bytes) else progLog("Failed to read the selected file", LogLevel.ERROR)
        }
    }

    private fun formatSize(bytes: Long): String = when {
        bytes <= 0 -> "unknown size"
        bytes >= 1024 * 1024 -> "%.0f MB".format(bytes / (1024.0 * 1024.0))
        else -> "%.0f KB".format(bytes / 1024.0)
    }

    // ---- hex editor byte-edit dialogs -------------------------------------------

    /** Shows a tiny "enter a new hex byte" dialog for [offset], committing via [adapter] on Save. */
    private fun showByteEditDialog(adapter: HexEditorAdapter, offset: Int, onCommitted: () -> Unit) {
        val current = adapter.byteAt(offset) ?: return
        val input = EditText(this).apply {
            setText(String.format("%02X", current.toInt() and 0xFF))
            filters = arrayOf(InputFilter.LengthFilter(2))
            inputType = InputType.TYPE_CLASS_TEXT
            setSelectAllOnFocus(true)
            val pad = (20 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad / 2, pad, 0)
        }
        AlertDialog.Builder(this)
            .setTitle("Edit byte at offset 0x%X".format(offset))
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val value = input.text.toString().trim().toIntOrNull(16)
                if (value == null || value !in 0..255) {
                    progLog("Enter a valid 2-digit hex value (00-FF)", LogLevel.WARN)
                } else {
                    adapter.setByte(offset, value.toByte())
                    onCommitted()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    /** Shows a tiny "enter a new character" dialog for [offset] - the ASCII-column counterpart
     *  of [showByteEditDialog], setting the byte to that character's code instead of a hex value. */
    private fun showAsciiEditDialog(adapter: HexEditorAdapter, offset: Int, onCommitted: () -> Unit) {
        val current = adapter.byteAt(offset) ?: return
        val currentChar = (current.toInt() and 0xFF).let { if (it in 0x20..0x7E) it.toChar().toString() else "" }
        val input = EditText(this).apply {
            setText(currentChar)
            filters = arrayOf(InputFilter.LengthFilter(1))
            inputType = InputType.TYPE_CLASS_TEXT
            setSelectAllOnFocus(true)
            val pad = (20 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad / 2, pad, 0)
        }
        AlertDialog.Builder(this)
            .setTitle("Edit character at offset 0x%X".format(offset))
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val text = input.text.toString()
                if (text.isEmpty()) {
                    progLog("Enter a single character", LogLevel.WARN)
                } else {
                    adapter.setByte(offset, (text[0].code and 0xFF).toByte())
                    onCommitted()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---- shared progress/log helpers -------------------------------------------

    private fun setProgProgress(percent: Int?) {
        val bar = progBinding.progressProgrammer
        if (percent == null) {
            bar.visibility = View.INVISIBLE
        } else {
            bar.visibility = View.VISIBLE
            bar.progress = percent.coerceIn(0, 100)
        }
    }

    private enum class LogLevel { INFO, WARN, ERROR }

    private fun toggleLogPanel() {
        logExpanded = !logExpanded
        // Toggle the wrapping ScrollView, not llLogBody directly - llLogBody is just the content
        // inside it now (it needs its own bounded-height scroll so a long log doesn't grow the
        // panel forever); hiding only the inner view would leave the fixed-height scroll area
        // visible but empty instead of actually collapsing.
        progBinding.scrollLogBody.visibility = if (logExpanded) View.VISIBLE else View.GONE
        progBinding.ivLogChevron.setImageResource(if (logExpanded) R.drawable.ic_prog_chevron_up else R.drawable.ic_prog_chevron_down)
    }

    /** Appends one structured row (timestamp + level icon/label + message) to the log panel,
     *  matching screen_light_mode.html / screen_night_mode.html's per-entry layout. Trims the
     *  oldest entries past [MAX_LOG_ENTRIES] so a long session doesn't grow the view tree forever. */
    private fun progLog(message: String, level: LogLevel = LogLevel.INFO) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        val body = progBinding.llLogBody
        val row = LayoutInflater.from(this).inflate(R.layout.item_log_entry, body, false)

        row.findViewById<TextView>(R.id.tvLogTimestamp).text = "[$time]"
        row.findViewById<TextView>(R.id.tvLogMessage).text = message

        val (levelText, levelColor, levelIcon) = when (level) {
            LogLevel.INFO -> Triple("INFO", R.color.log_info, R.drawable.ic_prog_info)
            LogLevel.WARN -> Triple("WARN", R.color.log_warn, R.drawable.ic_prog_warning)
            LogLevel.ERROR -> Triple("ERROR", R.color.log_error, R.drawable.ic_prog_error)
        }
        row.findViewById<TextView>(R.id.tvLogLevel).apply {
            text = levelText
            setTextColor(getColor(levelColor))
        }
        row.findViewById<ImageView>(R.id.ivLogLevelIcon).apply {
            setImageResource(levelIcon)
            imageTintList = android.content.res.ColorStateList.valueOf(getColor(levelColor))
        }

        body.addView(row)
        while (body.childCount > MAX_LOG_ENTRIES) {
            body.removeViewAt(0)
        }
        // New entries land below the fold in a 170dp-tall viewport otherwise - keep the latest
        // one in view automatically rather than making the user scroll down after every action.
        progBinding.scrollLogBody.post { progBinding.scrollLogBody.fullScroll(View.FOCUS_DOWN) }
    }

    companion object {
        private const val MAX_LOG_ENTRIES = 300

        /**
         * Exact 128-byte sample from the supplied design mockup's hex dump (the "Hello CH341A
         * Programmer !!!" text baked into a field of 0xFF/0x00) - shown on first launch, before
         * any connection, so the hex editor is never a blank page. Gets replaced the moment the
         * user does anything real (Read, Load File, Erase, Write Random).
         */
        private val PLACEHOLDER_HEX_DATA: ByteArray = intArrayOf(
            0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
            0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
            0x48, 0x65, 0x6C, 0x6C, 0x6F, 0x20, 0x43, 0x48, 0x33, 0x34, 0x31, 0x41, 0x20, 0x50, 0x72, 0x6F,
            0x67, 0x72, 0x61, 0x6D, 0x6D, 0x65, 0x72, 0x20, 0x21, 0x21, 0x21, 0x00, 0xFF, 0xFF, 0xFF, 0xFF,
            0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
            0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF
        ).map { it.toByte() }.toByteArray()
    }
}
