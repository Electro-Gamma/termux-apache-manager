package com.tcpuartbridge.app

import android.graphics.BitmapFactory
import android.hardware.usb.UsbDevice
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.tcpuartbridge.app.databinding.ActivityMainBinding
import com.tcpuartbridge.app.display.OledCompositor
import com.tcpuartbridge.app.eeprom.I2cEeprom
import com.tcpuartbridge.app.programmer.ProgrammerController
import com.tcpuartbridge.app.programmer.ProgrammerMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * CH341A programmer app - I2C EEPROM (24Cxx) read/write, SPI NOR flash (25xx) read/erase/write,
 * and a small SSD1306 I2C OLED display driver (including a clock, a phone-stats dashboard, a
 * custom TTF/OTF font, and a multi-image animation loop), all over the CH341A's USB
 * "parallel/EPP" (programmer) mode. Also exposes an I2C-over-TCP server so another device on the
 * network can run I2C transactions against whatever's wired to the CH341A.
 *
 * This talks to the CH341A's programmer-mode USB personality via [Ch341UsbDevice] - see that
 * class's doc for why it needs its own connect/open/claim-interface flow rather than a standard
 * serial port.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val progBinding get() = binding.includeProgrammer

    private val programmerController by lazy { ProgrammerController(applicationContext) }
    private var currentProgMode = ProgrammerMode.I2C_EEPROM
    private var progConnectedDevice: UsbDevice? = null

    private val progModeLabels = arrayOf("I2C EEPROM (24Cxx)", "SPI Flash (25xx)", "SSD1306 OLED Display")
    private val progModeValues = arrayOf(ProgrammerMode.I2C_EEPROM, ProgrammerMode.SPI_FLASH, ProgrammerMode.SSD1306_DISPLAY)

    private val eepromChipLabels = I2cEeprom.COMMON_CHIPS.map { it.name } + "Custom (enter size below)"
    private var selectedEepromChip: I2cEeprom.Chip = I2cEeprom.COMMON_CHIPS.first()

    private val oledSizeLabels = arrayOf("128 x 64", "128 x 32", "96 x 16", "64 x 32")
    private val oledSizeValues = arrayOf(128 to 64, 128 to 32, 96 to 16, 64 to 32)
    private var selectedOledSize = oledSizeValues.first()

    private var lastEepromDump: ByteArray? = null
    private var lastSpiDump: ByteArray? = null

    /** Which of the clock/stats/animation continuous-redraw loops (if any) is currently running -
     * mirrors [ProgrammerController.isContinuousRunning] but also tracks *which one*, so the
     * right button gets put back to its "Start" label when another one supersedes it. */
    private enum class ContinuousMode { CLOCK, STATS, ANIMATION }
    private var activeContinuousMode: ContinuousMode? = null
    private var animFrameUris: List<Uri> = emptyList()

    // ---- Storage Access Framework pickers for dump files --------------------

    private val eepromSaveLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
            val data = lastEepromDump
            if (uri != null && data != null) writeBytesToUri(uri, data, "EEPROM dump")
        }

    private val eepromOpenLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) readBytesFromUri(uri) { bytes -> onEepromWriteFileChosen(bytes) }
        }

    private val spiSaveLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
            val data = lastSpiDump
            if (uri != null && data != null) writeBytesToUri(uri, data, "SPI flash dump")
        }

    private val spiOpenLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) readBytesFromUri(uri) { bytes -> onSpiWriteFileChosen(bytes) }
        }

    private val oledImageLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) onOledImageChosen(uri)
        }

    private val fontPickerLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) onFontChosen(uri)
        }

    private val animFramesLauncher =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            if (uris.isNotEmpty()) onAnimFramesChosen(uris)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupProgrammerUi()
    }

    override fun onDestroy() {
        super.onDestroy()
        // Plain synchronous close (not the suspend disconnect()) - the activity is on its way
        // out, so there's no coroutine scope left to safely launch into.
        programmerController.stopContinuous()
        programmerController.stopI2cTcpServer()
        programmerController.usbDevice.close()
    }

    // ==================== CH341A: I2C EEPROM / SPI flash / SSD1306 ====================

    private fun setupProgrammerUi() {
        val p = progBinding

        p.spinnerProgMode.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, progModeLabels)
        p.spinnerProgMode.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                currentProgMode = progModeValues[position]
                p.llI2cPanel.visibility = if (currentProgMode == ProgrammerMode.I2C_EEPROM) View.VISIBLE else View.GONE
                p.llSpiPanel.visibility = if (currentProgMode == ProgrammerMode.SPI_FLASH) View.VISIBLE else View.GONE
                p.llDisplayPanel.visibility = if (currentProgMode == ProgrammerMode.SSD1306_DISPLAY) View.VISIBLE else View.GONE
                p.llI2cTcpPanel.visibility = if (currentProgMode == ProgrammerMode.SPI_FLASH) View.GONE else View.VISIBLE
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        p.spinnerEepromChip.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, eepromChipLabels)
        p.spinnerEepromChip.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val isCustom = position !in I2cEeprom.COMMON_CHIPS.indices
                p.etEepromCustomSize.visibility = if (isCustom) View.VISIBLE else View.GONE
                if (isCustom) {
                    p.tvEepromInfo.text = "Enter the size in bytes above - a 2-byte-address, 32-byte-page chip is assumed."
                } else {
                    selectedEepromChip = I2cEeprom.COMMON_CHIPS[position]
                    p.tvEepromInfo.text = "${selectedEepromChip.totalBytes} bytes total, ${selectedEepromChip.pageSize}-byte write pages."
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        p.spinnerOledSize.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, oledSizeLabels)
        p.spinnerOledSize.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedOledSize = oledSizeValues[position]
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        p.btnProgConnect.setOnClickListener { onProgConnectClicked() }
        p.btnEepromRead.setOnClickListener { onEepromReadClicked() }
        p.btnEepromWrite.setOnClickListener { onEepromWriteClicked() }
        p.btnSpiReadId.setOnClickListener { onSpiReadIdClicked() }
        p.btnSpiRead.setOnClickListener { onSpiReadClicked() }
        p.btnSpiErase.setOnClickListener { onSpiEraseClicked() }
        p.btnSpiWrite.setOnClickListener { onSpiWriteClicked() }
        p.btnOledInit.setOnClickListener { onOledInitClicked() }
        p.btnOledTest.setOnClickListener { onOledTestClicked() }
        p.btnOledClear.setOnClickListener { onOledClearClicked() }
        p.btnOledDrawText.setOnClickListener { onOledDrawTextClicked() }
        p.btnOledLoadImage.setOnClickListener { onOledLoadImageClicked() }
        p.btnI2cTcpToggle.setOnClickListener { onI2cTcpToggleClicked() }
        val fontLabels = listOf(getString(R.string.prog_font_builtin)) +
            ProgrammerController.BUNDLED_FONTS.map { it.displayName } +
            getString(R.string.prog_font_choose_phone)
        p.spinnerFont.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, fontLabels)
        p.spinnerFont.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                when (position) {
                    0 -> {
                        programmerController.clearCustomFont()
                        updateFontStatus()
                        progLog("Reverted to the built-in pixel font")
                    }
                    in 1..ProgrammerController.BUNDLED_FONTS.size -> {
                        val font = ProgrammerController.BUNDLED_FONTS[position - 1]
                        val ok = programmerController.loadBundledFont(this@MainActivity, font.assetPath, font.displayName)
                        updateFontStatus()
                        progLog(if (ok) "Font loaded: ${font.displayName}" else "Failed to load ${font.displayName} from assets")
                    }
                    else -> fontPickerLauncher.launch(arrayOf("*/*"))
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        p.btnClockToggle.setOnClickListener { onClockToggleClicked() }
        p.btnStatsToggle.setOnClickListener { onStatsToggleClicked() }
        p.btnAnimChoose.setOnClickListener { onAnimChooseClicked() }
        p.btnAnimToggle.setOnClickListener { onAnimToggleClicked() }

        p.tvEepromInfo.text = "${selectedEepromChip.totalBytes} bytes total, ${selectedEepromChip.pageSize}-byte write pages."
        updateProgConnectionUi(false)
    }

    // ---- connect / disconnect ----------------------------------------------

    private fun updateProgConnectionUi(connected: Boolean) {
        progBinding.tvProgStatus.text = if (connected) {
            "Connected: ${programmerController.usbDevice.deviceLabel()}"
        } else {
            getString(R.string.prog_not_connected)
        }
        progBinding.btnProgConnect.text = getString(if (connected) R.string.prog_disconnect else R.string.prog_connect)
        progBinding.spinnerProgMode.isEnabled = !connected
        if (!connected) {
            // disconnect() always stops the I2C-over-TCP server too - reflect that here.
            progBinding.tvI2cTcpStatus.text = getString(R.string.prog_i2ctcp_not_running)
            progBinding.btnI2cTcpToggle.text = getString(R.string.prog_i2ctcp_start)
            // ...and any running clock/stats/animation loop - reset that UI state too.
            activeContinuousMode = null
            resetContinuousButtons()
        }
    }

    private fun onProgConnectClicked() {
        if (programmerController.isConnected) {
            lifecycleScope.launch {
                programmerController.disconnect(currentProgMode)
                progConnectedDevice = null
                updateProgConnectionUi(false)
                progLog("Disconnected")
            }
            return
        }

        val dev = programmerController.findDevice()
        if (dev == null) {
            progLog("No CH341A programmer found - plug it in (VID 1A86 / PID 5512) and tap Connect again")
            return
        }

        if (programmerController.hasPermission(dev)) {
            connectToProgrammerDevice(dev)
        } else {
            programmerController.requestPermission(dev) { granted ->
                if (granted) connectToProgrammerDevice(dev) else progLog("USB permission denied")
            }
        }
    }

    private fun connectToProgrammerDevice(dev: UsbDevice) {
        lifecycleScope.launch {
            val ok = programmerController.connect(dev, currentProgMode)
            if (ok) {
                progConnectedDevice = dev
                updateProgConnectionUi(true)
                progLog("Connected: ${programmerController.usbDevice.deviceLabel()}")
            } else {
                progLog("Failed to open/initialize the CH341A")
            }
        }
    }

    // ---- I2C EEPROM ---------------------------------------------------------

    /** Reads the chip spinner, or builds a Chip from the custom-size field. Logs and returns null if invalid. */
    private fun currentEepromChip(): I2cEeprom.Chip? {
        val pos = progBinding.spinnerEepromChip.selectedItemPosition
        if (pos in I2cEeprom.COMMON_CHIPS.indices) return I2cEeprom.COMMON_CHIPS[pos]
        val size = progBinding.etEepromCustomSize.text.toString().toIntOrNull()
        if (size == null || size <= 0) {
            progLog("Enter a valid custom EEPROM size in bytes first")
            return null
        }
        progLog(
            "Custom chip: assuming 2-byte word addressing / 32-byte pages (typical for 32Kbit+ " +
                "EEPROMs) - pick the matching preset instead if your chip is smaller than that"
        )
        return I2cEeprom.Chip("Custom ($size B)", size, pageSize = 32, algorithm = 0x02)
    }

    private fun onEepromReadClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first")
            return
        }
        val chip = currentEepromChip() ?: return
        lifecycleScope.launch {
            setProgProgress(0)
            progLog("Reading ${chip.name}...")
            val data = programmerController.readEeprom(chip) { done, total ->
                runOnUiThread { setProgProgress(if (total > 0) done * 100 / total else 100) }
            }
            setProgProgress(null)
            if (data != null) {
                lastEepromDump = data
                progLog("Read ${data.size} bytes - choose where to save")
                eepromSaveLauncher.launch(suggestedFileName("eeprom_dump", data.size))
            } else {
                progLog("EEPROM read failed - check wiring and that a chip is present")
            }
        }
    }

    private fun onEepromWriteClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first")
            return
        }
        if (currentEepromChip() == null) return
        progLog("Choose a file to write to the EEPROM...")
        eepromOpenLauncher.launch(arrayOf("*/*"))
    }

    private fun onEepromWriteFileChosen(bytes: ByteArray) {
        val chip = currentEepromChip() ?: return
        val data = if (bytes.size > chip.totalBytes) {
            progLog("File is ${bytes.size} B, larger than ${chip.name} (${chip.totalBytes} B) - truncating")
            bytes.copyOf(chip.totalBytes)
        } else {
            bytes
        }
        lifecycleScope.launch {
            setProgProgress(0)
            progLog("Writing ${data.size} bytes to ${chip.name}...")
            val ok = programmerController.writeEeprom(chip, data) { done, total ->
                runOnUiThread { setProgProgress(if (total > 0) done * 100 / total else 100) }
            }
            setProgProgress(null)
            progLog(if (ok) "EEPROM write complete" else "EEPROM write failed")
        }
    }

    // ---- SPI flash ------------------------------------------------------------

    private fun onSpiReadIdClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first")
            return
        }
        lifecycleScope.launch {
            val id = programmerController.readSpiJedecId()
            if (id != null) {
                progBinding.tvSpiId.text = "Mfg 0x%02X   Type 0x%02X   Capacity code 0x%02X   (~%s)".format(
                    id.manufacturer, id.memoryType, id.capacityCode, formatSize(id.sizeBytes)
                )
                progLog("JEDEC ID read OK")
            } else {
                progBinding.tvSpiId.text = ""
                progLog("Failed to read JEDEC ID - check wiring/chip")
            }
        }
    }

    private fun onSpiReadClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first")
            return
        }
        val sizeKb = progBinding.etSpiSizeKb.text.toString().toIntOrNull()
        if (sizeKb == null || sizeKb <= 0) {
            progLog("Enter a valid size in KB")
            return
        }
        val length = sizeKb * 1024
        lifecycleScope.launch {
            setProgProgress(0)
            progLog("Reading $sizeKb KB from SPI flash...")
            val data = programmerController.readSpiFlash(length) { done, total ->
                runOnUiThread { setProgProgress(if (total > 0) done * 100 / total else 100) }
            }
            setProgProgress(null)
            if (data != null) {
                lastSpiDump = data
                progLog("Read ${data.size} bytes - choose where to save")
                spiSaveLauncher.launch(suggestedFileName("spi_flash_dump", data.size))
            } else {
                progLog("SPI flash read failed - check wiring and that a chip is present")
            }
        }
    }

    private fun onSpiEraseClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Erase entire SPI flash chip?")
            .setMessage("This wipes the whole chip and cannot be undone. Continue?")
            .setPositiveButton("Erase") { _, _ ->
                lifecycleScope.launch {
                    setProgProgress(0)
                    progLog("Erasing SPI flash chip - this can take a while...")
                    val ok = programmerController.eraseSpiFlashChip()
                    setProgProgress(null)
                    progLog(if (ok) "Chip erase complete" else "Chip erase failed")
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun onSpiWriteClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first")
            return
        }
        progLog("Choose a file to write to SPI flash...")
        spiOpenLauncher.launch(arrayOf("*/*"))
    }

    private fun onSpiWriteFileChosen(bytes: ByteArray) {
        val pageSize = progBinding.etSpiPageSize.text.toString().toIntOrNull() ?: 256
        lifecycleScope.launch {
            setProgProgress(0)
            progLog("Erasing + writing ${bytes.size} bytes to SPI flash (page size $pageSize B)...")
            val ok = programmerController.writeSpiFlash(bytes, pageSize) { done, total ->
                runOnUiThread { setProgProgress(if (total > 0) done * 100 / total else 100) }
            }
            setProgProgress(null)
            progLog(if (ok) "SPI flash write complete" else "SPI flash write failed")
        }
    }

    // ---- SSD1306 OLED -----------------------------------------------------------

    private fun parseOledAddress(): Int =
        progBinding.etOledAddress.text.toString().trim()
            .removePrefix("0x").removePrefix("0X")
            .toIntOrNull(16) ?: 0x3C

    private fun onOledInitClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first")
            return
        }
        val (w, h) = selectedOledSize
        val addr = parseOledAddress()
        lifecycleScope.launch {
            val ok = programmerController.initDisplay(addr, w, h)
            progLog(
                if (ok) "SSD1306 initialized (${w}x$h @ 0x${addr.toString(16)})"
                else "SSD1306 init failed - check address/wiring"
            )
        }
    }

    private fun onOledTestClicked() {
        lifecycleScope.launch {
            val ok = programmerController.displayTestPattern()
            progLog(if (ok) "Test pattern sent" else "Init the display first")
        }
    }

    private fun onOledClearClicked() {
        lifecycleScope.launch {
            val ok = programmerController.displayClear()
            progLog(if (ok) "Display cleared" else "Init the display first")
        }
    }

    private fun onOledDrawTextClicked() {
        val text = progBinding.etOledText.text.toString()
        lifecycleScope.launch {
            val ok = if (programmerController.customFontTypeface != null) {
                programmerController.displayCustomText(text)
            } else {
                programmerController.displayText(text)
            }
            progLog(if (ok) "Text drawn" else "Init the display first")
        }
    }

    private fun onOledLoadImageClicked() {
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first")
            return
        }
        progLog("Choose an image to display...")
        oledImageLauncher.launch(arrayOf("image/*"))
    }

    private fun onOledImageChosen(uri: Uri) {
        lifecycleScope.launch {
            val loaded = try {
                withContext(Dispatchers.IO) {
                    contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                }
            } catch (e: Exception) {
                null
            }
            if (loaded == null) {
                progLog("Failed to decode the selected image")
                return@launch
            }
            val ok = programmerController.displayBitmap(loaded)
            loaded.recycle()
            progLog(if (ok) "Image drawn (scaled + thresholded to 1-bit)" else "Init the display first")
        }
    }

    // ---- Custom font (buffer2.py/clock.py's alagard.ttf / PixelOperator.ttf, but any font file) --

    private fun updateFontStatus() {
        progBinding.tvFontStatus.text = programmerController.customFontName?.let { "Using: $it" }
            ?: getString(R.string.prog_font_none)
    }

    private fun onFontChosen(uri: Uri) {
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) { programmerController.loadCustomFont(this@MainActivity, uri) }
            updateFontStatus()
            progLog(
                if (ok) "Font loaded: ${programmerController.customFontName} - Draw Text and the Clock will use it"
                else "That file doesn't look like a valid font"
            )
        }
    }

    // ---- Clock / Stats / Animate - continuous redraw loops -----------------------

    private fun resetContinuousButtons() {
        progBinding.btnClockToggle.text = getString(R.string.prog_clock_start)
        progBinding.btnStatsToggle.text = getString(R.string.prog_stats_start)
        progBinding.btnAnimToggle.text = getString(R.string.prog_anim_start)
    }

    private fun onClockToggleClicked() {
        if (activeContinuousMode == ContinuousMode.CLOCK) {
            programmerController.stopContinuous()
            activeContinuousMode = null
            progBinding.btnClockToggle.text = getString(R.string.prog_clock_start)
            progLog("Clock stopped")
            return
        }
        if (!programmerController.isConnected) {
            progLog("Connect in SSD1306 Display mode first")
            return
        }
        resetContinuousButtons()
        activeContinuousMode = ContinuousMode.CLOCK
        progBinding.btnClockToggle.text = getString(R.string.prog_clock_stop)
        progLog("Clock started")
        programmerController.startClock(intervalMs = 1000L) { error ->
            runOnUiThread {
                progBinding.btnClockToggle.text = getString(R.string.prog_clock_start)
                if (activeContinuousMode == ContinuousMode.CLOCK) activeContinuousMode = null
                if (error != null) progLog(error)
            }
        }
    }

    private fun onStatsToggleClicked() {
        if (activeContinuousMode == ContinuousMode.STATS) {
            programmerController.stopContinuous()
            activeContinuousMode = null
            progBinding.btnStatsToggle.text = getString(R.string.prog_stats_start)
            progLog("Stats stopped")
            return
        }
        if (!programmerController.isConnected) {
            progLog("Connect in SSD1306 Display mode first")
            return
        }
        resetContinuousButtons()
        activeContinuousMode = ContinuousMode.STATS
        progBinding.btnStatsToggle.text = getString(R.string.prog_stats_stop)
        progLog("Stats started")
        programmerController.startStats(applicationContext, intervalMs = 1000L) { error ->
            runOnUiThread {
                progBinding.btnStatsToggle.text = getString(R.string.prog_stats_start)
                if (activeContinuousMode == ContinuousMode.STATS) activeContinuousMode = null
                if (error != null) progLog(error)
            }
        }
    }

    private fun onAnimChooseClicked() {
        animFramesLauncher.launch(arrayOf("image/*"))
    }

    private fun onAnimFramesChosen(uris: List<Uri>) {
        animFrameUris = sortUrisByDisplayName(uris)
        progBinding.tvAnimStatus.text = "${uris.size} frame(s) selected"
        progLog("${uris.size} animation frame(s) selected")
    }

    private fun sortUrisByDisplayName(uris: List<Uri>): List<Uri> = uris.sortedBy { uri ->
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0) else uri.toString()
            } ?: uri.toString()
        } catch (e: Exception) {
            uri.toString()
        }
    }

    private fun onAnimToggleClicked() {
        if (activeContinuousMode == ContinuousMode.ANIMATION) {
            programmerController.stopContinuous()
            activeContinuousMode = null
            progBinding.btnAnimToggle.text = getString(R.string.prog_anim_start)
            progLog("Animation stopped")
            return
        }
        if (!programmerController.isConnected) {
            progLog("Connect in SSD1306 Display mode first")
            return
        }
        if (animFrameUris.isEmpty()) {
            progLog("Choose frames first")
            return
        }
        val delayMs = progBinding.etAnimDelay.text.toString().toLongOrNull()
        if (delayMs == null || delayMs <= 0) {
            progLog("Enter a valid frame delay in ms")
            return
        }
        resetContinuousButtons()
        activeContinuousMode = ContinuousMode.ANIMATION
        progBinding.btnAnimToggle.text = getString(R.string.prog_anim_stop)
        progLog("Loading ${animFrameUris.size} frame(s)...")
        lifecycleScope.launch {
            val frames = withContext(Dispatchers.IO) {
                animFrameUris.mapNotNull { uri ->
                    try {
                        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                    } catch (e: Exception) {
                        null
                    }
                }
            }
            if (frames.isEmpty() || activeContinuousMode != ContinuousMode.ANIMATION) {
                if (frames.isEmpty()) {
                    progLog("Couldn't decode any of the selected frames")
                } else {
                    frames.forEach { it.recycle() } // superseded by another mode while decoding
                }
                if (activeContinuousMode == ContinuousMode.ANIMATION) {
                    activeContinuousMode = null
                    progBinding.btnAnimToggle.text = getString(R.string.prog_anim_start)
                }
                return@launch
            }
            progLog("Animating ${frames.size} frame(s) every ${delayMs}ms")
            programmerController.startAnimation(frames, delayMs) { error ->
                runOnUiThread {
                    progBinding.btnAnimToggle.text = getString(R.string.prog_anim_start)
                    if (activeContinuousMode == ContinuousMode.ANIMATION) activeContinuousMode = null
                    if (error != null) progLog(error)
                    frames.forEach { it.recycle() }
                }
            }
        }
    }

    // ---- I2C-over-TCP -----------------------------------------------------------

    private fun onI2cTcpToggleClicked() {
        if (programmerController.isI2cTcpServerRunning) {
            programmerController.stopI2cTcpServer()
            progBinding.tvI2cTcpStatus.text = getString(R.string.prog_i2ctcp_not_running)
            progBinding.btnI2cTcpToggle.text = getString(R.string.prog_i2ctcp_start)
            progLog("I2C-over-TCP server stopped")
            return
        }
        if (!programmerController.isConnected) {
            progLog("Connect to the CH341A first")
            return
        }
        if (currentProgMode == ProgrammerMode.SPI_FLASH) {
            progLog("I2C-over-TCP isn't available in SPI Flash mode - connect in I2C EEPROM or SSD1306 Display mode instead")
            return
        }
        val port = progBinding.etI2cTcpPort.text.toString().toIntOrNull()
        if (port == null || port !in 1..65535) {
            progLog("Enter a valid port number (1-65535)")
            return
        }
        try {
            programmerController.startI2cTcpServer(
                port = port,
                onClientConnected = { addr -> runOnUiThread { progLog("I2C-over-TCP client connected: $addr") } },
                onClientDisconnected = { addr -> runOnUiThread { progLog("I2C-over-TCP client disconnected: $addr") } },
                onError = { e -> runOnUiThread { progLog("I2C-over-TCP error: ${e.message}") } }
            )
            progBinding.tvI2cTcpStatus.text = "Listening on ${OledCompositor.wifiOrCellularIpAddress(this)}:$port"
            progBinding.btnI2cTcpToggle.text = getString(R.string.prog_i2ctcp_stop)
            progLog("I2C-over-TCP server started on port $port")
        } catch (e: Exception) {
            progLog("Failed to start I2C-over-TCP server: ${e.message}")
        }
    }

    // ---- file I/O (Storage Access Framework) -----------------------------------

    private fun suggestedFileName(prefix: String, sizeBytes: Int): String {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        return "${prefix}_${sizeBytes}B_$stamp.bin"
    }

    private fun writeBytesToUri(uri: Uri, data: ByteArray, label: String) {
        lifecycleScope.launch {
            val ok = try {
                withContext(Dispatchers.IO) {
                    contentResolver.openOutputStream(uri)?.use { it.write(data) }
                    true
                }
            } catch (e: Exception) {
                false
            }
            progLog(if (ok) "$label saved (${data.size} bytes)" else "Failed to save $label")
        }
    }

    private fun readBytesFromUri(uri: Uri, onLoaded: (ByteArray) -> Unit) {
        lifecycleScope.launch {
            val bytes = try {
                withContext(Dispatchers.IO) { contentResolver.openInputStream(uri)?.use { it.readBytes() } }
            } catch (e: Exception) {
                null
            }
            if (bytes != null) onLoaded(bytes) else progLog("Failed to read the selected file")
        }
    }

    private fun formatSize(bytes: Long): String = when {
        bytes <= 0 -> "unknown size"
        bytes >= 1024 * 1024 -> "%.0f MB".format(bytes / (1024.0 * 1024.0))
        else -> "%.0f KB".format(bytes / 1024.0)
    }

    // ---- shared progress/log helpers -------------------------------------------

    private fun setProgProgress(percent: Int?) {
        val bar = progBinding.progressProgrammer
        if (percent == null) {
            bar.visibility = View.INVISIBLE
        } else {
            bar.visibility = View.VISIBLE
            bar.progress = percent.coerceIn(0, 100)
        }
    }

    private fun progLog(message: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        progBinding.tvProgLog.append("[$time] $message\n")
        progBinding.scrollProgLog.post { progBinding.scrollProgLog.fullScroll(View.FOCUS_DOWN) }
    }
}
