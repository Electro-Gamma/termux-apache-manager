package com.tcpuartbridge.app.util

import java.security.GeneralSecurityException
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Crypto tab's cipher - real AES-256-GCM (the JVM's own `javax.crypto`, not a hand-rolled
 * implementation), with the key derived from a password via PBKDF2. Every parameter here (salt,
 * iteration count, key length, IV length, tag length) is byte-for-byte the same as the reference
 * HTML's Web Crypto implementation, so a buffer this encrypts can be decrypted there with the same
 * password, and vice versa - this isn't just a look-alike cipher.
 *
 * Buffer layout once encrypted, always exactly 256 bytes: [12-byte IV][228-byte
 * ciphertext][16-byte GCM auth tag]. Wrong password or non-encrypted data makes the GCM tag check
 * genuinely fail - [decryptGcm] returns null, not a canned "success".
 */
object CryptoUtils {
    private val SALT = "tcp-uart-bridge-demo-salt-v1".toByteArray(Charsets.UTF_8)
    private const val PBKDF2_ITERATIONS = 100_000
    private const val KEY_LENGTH_BITS = 256
    private const val GCM_IV_BYTES = 12
    private const val GCM_TAG_BITS = 128

    /** How much plaintext fits in one 256-byte encrypted block: 256 - 12 (IV) - 16 (GCM tag). */
    const val PLAIN_CAP = 256 - GCM_IV_BYTES - (GCM_TAG_BITS / 8)

    private fun deriveKey(password: String): SecretKeySpec {
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val spec = PBEKeySpec(password.toCharArray(), SALT, PBKDF2_ITERATIONS, KEY_LENGTH_BITS)
        val raw = factory.generateSecret(spec).encoded
        return SecretKeySpec(raw, "AES")
    }

    /** Encrypts [plaintext] (at most [PLAIN_CAP] bytes) with a fresh random IV, returning the
     *  full IV+ciphertext+tag blob ready to drop straight into a 256-byte buffer. */
    fun encryptGcm(plaintext: ByteArray, password: String): ByteArray {
        val key = deriveKey(password)
        val iv = ByteArray(GCM_IV_BYTES).also { SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(GCM_TAG_BITS, iv))
        val cipherWithTag = cipher.doFinal(plaintext)
        return iv + cipherWithTag
    }

    /** Reverses [encryptGcm]: [ivAndCipher] is the same IV+ciphertext+tag layout (IV first, 12
     *  bytes). Returns the recovered plaintext, or null if the password is wrong or the data
     *  wasn't actually encrypted this way (the GCM tag check fails) - never throws. */
    fun decryptGcm(ivAndCipher: ByteArray, password: String): ByteArray? {
        if (ivAndCipher.size <= GCM_IV_BYTES) return null
        return try {
            val key = deriveKey(password)
            val iv = ivAndCipher.copyOfRange(0, GCM_IV_BYTES)
            val cipherWithTag = ivAndCipher.copyOfRange(GCM_IV_BYTES, ivAndCipher.size)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(GCM_TAG_BITS, iv))
            cipher.doFinal(cipherWithTag)
        } catch (e: GeneralSecurityException) {
            null
        }
    }
}
