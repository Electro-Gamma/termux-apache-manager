package com.tcpuartbridge.app.display

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.os.BatteryManager
import android.os.StatFs
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import java.net.Inet4Address
import java.net.NetworkInterface
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Builds 1-bit-friendly [Bitmap] compositions for [Ssd1306.drawBitmap] - the Canvas/Paint
 * equivalent of "draw a PIL frame, then push it", which is what every one of the uploaded example
 * scripts does (clock.py, stats.py / data_analytic_display.py). Everything here draws with
 * anti-aliasing off in pure black/white, matching drawing into a PIL `Image.new('1', ...)`, which
 * has no gray levels either - callers should pass `dither = false` to [Ssd1306.drawBitmap] for
 * all of these, since dithering only helps photographic source images, not line art/text that's
 * already conceptually 1-bit.
 *
 * [renderStats] intentionally does not try to reproduce stats.py's CPU%/CPU-temperature gauges:
 * a phone has no accessible "CPU usage" or "CPU temperature" API without root. Battery
 * level/temperature stand in for both - the closest thing the platform actually exposes, and
 * conceptually the same kind of reading (the device's own power/thermal state).
 */
object OledCompositor {

    private fun blankCanvas(width: Int, height: Int): Pair<Bitmap, Canvas> {
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        canvas.drawColor(Color.BLACK)
        return bmp to canvas
    }

    private fun strokePaint(strokeWidth: Float = 1f): Paint = Paint().apply {
        isAntiAlias = false
        color = Color.WHITE
        style = Paint.Style.STROKE
        this.strokeWidth = strokeWidth
    }

    private fun fillPaint(): Paint = Paint().apply {
        isAntiAlias = false
        color = Color.WHITE
        style = Paint.Style.FILL
    }

    private fun textPaint(sizePx: Float, typeface: Typeface?): Paint = Paint().apply {
        isAntiAlias = false
        color = Color.WHITE
        textSize = sizePx
        this.typeface = typeface ?: Typeface.DEFAULT
    }

    private fun localIpAddress(): String {
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val addresses = interfaces.nextElement().inetAddresses
                while (addresses.hasMoreElements()) {
                    val addr = addresses.nextElement()
                    if (!addr.isLoopbackAddress && addr is Inet4Address) return addr.hostAddress ?: "?"
                }
            }
        } catch (_: Exception) {
        }
        return "no ip"
    }

    // ---- Custom-font text -----------------------------------------------------------------

    /** Renders [text] with [typeface] (system default if null) at [textSizePx], word-wrapped to
     * the panel width by Android's own line breaker (handles this far more robustly than
     * [Ssd1306]'s built-in pixel font's hand-rolled wrapping - this is a real TTF/OTF font). */
    fun renderText(width: Int, height: Int, text: String, typeface: Typeface?, textSizePx: Float): Bitmap {
        val (bmp, canvas) = blankCanvas(width, height)
        val tp = TextPaint().apply {
            isAntiAlias = false
            color = Color.WHITE
            textSize = textSizePx
            this.typeface = typeface ?: Typeface.DEFAULT
        }
        val layout = StaticLayout.Builder
            .obtain(text, 0, text.length, tp, width)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .build()
        layout.draw(canvas)
        return bmp
    }

    // ---- Clock ------------------------------------------------------------------------------

    /**
     * Analog clock face (circle + hour ticks + hands) plus a digital day/date/year readout,
     * matching clock.py's layout and hand-angle math, adapted to whatever panel size is
     * connected: the face is sized to fit the panel height, pinned to the right edge, with the
     * date text (using [dateTypeface] if given) filling the space to its left - and the numbers
     * and date text are dropped automatically on panels too small to fit them legibly.
     */
    fun renderClock(width: Int, height: Int, dateTypeface: Typeface?): Bitmap {
        val (bmp, canvas) = blankCanvas(width, height)
        val radius = min(width, height) / 2f - 2f
        val cx = width - radius - 2f
        val cy = height / 2f
        val dateAreaWidth = cx - radius - 4f

        canvas.drawCircle(cx, cy, radius, strokePaint())

        val now = Calendar.getInstance()
        val hours = now.get(Calendar.HOUR)
        val minutes = now.get(Calendar.MINUTE)
        val seconds = now.get(Calendar.SECOND)

        if (radius >= 18f) {
            val numPaint = textPaint(radius / 3.2f, dateTypeface)
            for (i in 0 until 12) {
                val angle = Math.toRadians((i * 30).toDouble())
                val nx = cx + (radius * 0.8f * sin(angle)).toFloat()
                val ny = cy - (radius * 0.8f * cos(angle)).toFloat()
                val label = if (i == 0) "12" else i.toString()
                canvas.drawText(label, nx - numPaint.measureText(label) / 2f, ny + numPaint.textSize / 3f, numPaint)
            }
        }

        fun hand(lengthRatio: Float, angleDeg: Double, strokeWidth: Float) {
            val angle = Math.toRadians(angleDeg)
            val hx = cx + (radius * lengthRatio * sin(angle)).toFloat()
            val hy = cy - (radius * lengthRatio * cos(angle)).toFloat()
            canvas.drawLine(cx, cy, hx, hy, strokePaint(strokeWidth))
        }
        hand(0.50f, (hours % 12) * 30.0 + minutes * 0.5, 2f)   // hour
        hand(0.67f, minutes * 6.0 + seconds * 0.1, 1.5f)       // minute
        hand(0.83f, seconds * 6.0, 1f)                          // second

        if (dateAreaWidth >= 20f) {
            val now2 = now.time
            val dayFmt = SimpleDateFormat("EEEE", Locale.getDefault())
            val dmFmt = SimpleDateFormat("dd-MM", Locale.getDefault())
            val yFmt = SimpleDateFormat("yyyy", Locale.getDefault())
            val dayPaint = textPaint(height / 6.5f, dateTypeface)
            val bigPaint = textPaint(height / 4f, dateTypeface)
            var ty = dayPaint.textSize
            canvas.drawText(dayFmt.format(now2), 2f, ty, dayPaint)
            ty += bigPaint.textSize + 2f
            canvas.drawText(dmFmt.format(now2), 2f, ty, bigPaint)
            ty += bigPaint.textSize + 2f
            if (ty <= height) canvas.drawText(yFmt.format(now2), 2f, ty, bigPaint)
        }

        return bmp
    }

    // ---- Phone stats dashboard ---------------------------------------------------------------

    /** Battery %, battery temperature, RAM used/total, storage used/total, and this device's IP -
     * see the class doc for why these replace stats.py's CPU%/CPU-temp readings. Falls back to a
     * plain two-line text summary on panels too small for the gauge layout (e.g. 96x16). */
    fun renderStats(width: Int, height: Int, context: Context): Bitmap {
        val (bmp, canvas) = blankCanvas(width, height)

        val battIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val battPct = battIntent?.let {
            val level = it.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = it.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
            if (level >= 0 && scale > 0) level * 100 / scale else -1
        } ?: -1
        val battTempC = (battIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1) / 10f

        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memInfo)
        val ramTotalMb = memInfo.totalMem / (1024 * 1024)
        val ramUsedMb = ramTotalMb - memInfo.availMem / (1024 * 1024)
        val ramPct = if (ramTotalMb > 0) (ramUsedMb * 100 / ramTotalMb).toInt() else 0

        val stat = StatFs(context.filesDir.absolutePath)
        val totalBytes = stat.totalBytes
        val freeBytes = stat.availableBytes
        val usedBytes = totalBytes - freeBytes
        val storagePct = if (totalBytes > 0) (usedBytes * 100 / totalBytes).toInt() else 0
        val totalGb = totalBytes / (1024.0 * 1024 * 1024)
        val usedGb = usedBytes / (1024.0 * 1024 * 1024)

        val ip = localIpAddress()

        if (width < 90 || height < 28) {
            val p = textPaint(height / 3f, null)
            canvas.drawText("BAT $battPct% RAM $ramPct%", 1f, p.textSize, p)
            if (height > p.textSize * 2) canvas.drawText(ip, 1f, p.textSize * 2 + 2f, p)
            return bmp
        }

        // Everything below is laid out for a 128x64 canvas, then scaled to whatever panel is
        // actually connected - same proportions stats.py used for its fixed 128x64 target.
        val s = height / 64f
        fun sx(v: Float) = v * s
        fun sy(v: Float) = v * s

        // Battery-level gauge - mirrors the CPU-usage half-circle gauge.
        val battOval = RectF(sx(0f), sy(12f), sx(30f), sy(42f))
        canvas.drawArc(battOval, 180f, 180f, true, strokePaint())
        canvas.drawArc(battOval, 180f, 180f * battPct.coerceIn(0, 100) / 100f, true, fillPaint())
        val labelPaint = textPaint(sy(9f), null)
        canvas.drawText("BAT", sx(6f), sy(9f), labelPaint)
        canvas.drawText("$battPct%", sx(2f), sy(27f), labelPaint)

        // Battery-temperature gauge - mirrors the CPU-temperature half-circle gauge (0-60C range).
        val tempOval = RectF(sx(0f), sy(33f), sx(30f), sy(63f))
        canvas.drawArc(tempOval, 0f, 180f, true, strokePaint())
        val tempPct = (battTempC / 60f * 100f).coerceIn(0f, 100f)
        canvas.drawArc(tempOval, 180f - 180f * tempPct / 100f, 180f * tempPct / 100f, true, fillPaint())
        canvas.drawText(String.format(Locale.US, "%.1fC", battTempC), sx(2f), sy(60f), labelPaint)

        // IP address, RAM bar, storage bar.
        canvas.drawText(ip, sx(46f), sy(9f), labelPaint)

        canvas.drawText("RAM:${ramUsedMb}/${ramTotalMb}MB", sx(46f), sy(24f), labelPaint)
        val ramBar = RectF(sx(46f), sy(26f), sx(127f), sy(36f))
        canvas.drawRect(ramBar, strokePaint())
        canvas.drawRect(RectF(ramBar.left, ramBar.top, ramBar.left + ramBar.width() * ramPct / 100f, ramBar.bottom), fillPaint())

        canvas.drawText(String.format(Locale.US, "ROM:%.1f/%.1fGB", usedGb, totalGb), sx(46f), sy(48f), labelPaint)
        val romBar = RectF(sx(46f), sy(50f), sx(127f), sy(60f))
        canvas.drawRect(romBar, strokePaint())
        canvas.drawRect(RectF(romBar.left, romBar.top, romBar.left + romBar.width() * storagePct / 100f, romBar.bottom), fillPaint())

        return bmp
    }
}
