package com.tcpuartbridge.app.display

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.os.BatteryManager
import android.os.StatFs
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import java.net.Inet4Address
import java.net.NetworkInterface
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Builds 1-bit-friendly [Bitmap] compositions for [Ssd1306.drawBitmap] - the Canvas/Paint
 * equivalent of "draw a PIL frame, then push it", which is what every one of the uploaded example
 * scripts does (clock.py, stats.py / data_analytic_display.py). Everything here draws with
 * anti-aliasing off in pure black/white, matching drawing into a PIL `Image.new('1', ...)`, which
 * has no gray levels either - callers should pass `dither = false` to [Ssd1306.drawBitmap] for
 * all of these, since dithering only helps photographic source images, not line art/text that's
 * already conceptually 1-bit.
 *
 * [renderClock] and [renderStats] favor legibility over information density: a real SSD1306 is
 * roughly an inch across, so anything that reads fine on a PC monitor (a dozen tiny clock-face
 * numerals, thin pie-slice gauges) can turn into an illegible smudge on the actual hardware. Both
 * use bold text sized as large as will fit (see [fitTextSize]), simple full-width bars instead of
 * pie slices, and drop detail on smaller panels rather than shrinking everything to fit.
 *
 * [renderStats] intentionally does not try to reproduce stats.py's CPU%/CPU-temperature gauges:
 * a phone has no accessible "CPU usage" or "CPU temperature" API without root. Battery
 * level/temperature stand in for both - the closest thing the platform actually exposes, and
 * conceptually the same kind of reading (the device's own power/thermal state).
 */
object OledCompositor {

    private fun blankCanvas(width: Int, height: Int): Pair<Bitmap, Canvas> {
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        canvas.drawColor(Color.BLACK)
        return bmp to canvas
    }

    private fun strokePaint(strokeWidth: Float = 1f): Paint = Paint().apply {
        isAntiAlias = false
        color = Color.WHITE
        style = Paint.Style.STROKE
        this.strokeWidth = strokeWidth
    }

    private fun fillPaint(): Paint = Paint().apply {
        isAntiAlias = false
        color = Color.WHITE
        style = Paint.Style.FILL
    }

    private fun textPaint(sizePx: Float, typeface: Typeface?): Paint = Paint().apply {
        isAntiAlias = false
        color = Color.WHITE
        textSize = sizePx
        this.typeface = typeface ?: Typeface.DEFAULT
    }

    /** Largest text size (down to [minSize]) at which [text] still measures within [maxWidth] -
     * a real font-metrics-based fit rather than a guessed character-width ratio, so labels of
     * varying length (an IP address, a translated day name, ...) never run off the panel. */
    private fun fitTextSize(text: String, maxWidth: Float, initialSize: Float, typeface: Typeface?, minSize: Float = 6f): Float {
        var size = initialSize.coerceAtLeast(minSize)
        val p = textPaint(size, typeface)
        while (size > minSize && p.measureText(text) > maxWidth) {
            size -= 1f
            p.textSize = size
        }
        return size
    }

    private fun localIpAddress(): String {
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val addresses = interfaces.nextElement().inetAddresses
                while (addresses.hasMoreElements()) {
                    val addr = addresses.nextElement()
                    if (!addr.isLoopbackAddress && addr is Inet4Address) return addr.hostAddress ?: "?"
                }
            }
        } catch (_: Exception) {
        }
        return "no ip"
    }

    // ---- Custom-font text -----------------------------------------------------------------

    /** Renders [text] with [typeface] (system default if null) at [textSizePx], word-wrapped to
     * the panel width by Android's own line breaker (handles this far more robustly than
     * [Ssd1306]'s built-in pixel font's hand-rolled wrapping - this is a real TTF/OTF font). */
    fun renderText(width: Int, height: Int, text: String, typeface: Typeface?, textSizePx: Float): Bitmap {
        val (bmp, canvas) = blankCanvas(width, height)
        val tp = TextPaint().apply {
            isAntiAlias = false
            color = Color.WHITE
            textSize = textSizePx
            this.typeface = typeface ?: Typeface.DEFAULT
        }
        val layout = StaticLayout.Builder
            .obtain(text, 0, text.length, tp, width)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .build()
        layout.draw(canvas)
        return bmp
    }

    // ---- Clock ------------------------------------------------------------------------------

    /**
     * Analog clock face (circle + 12/3/6/9 tick marks + hands) plus a digital HH:mm readout and a
     * day/date line, adapted to whatever panel size is connected: the face is sized to fit the
     * panel height, pinned to the right edge, with the time/date text (using [dateTypeface] if
     * given) filling the space to its left. Deliberately doesn't draw hour numerals - twelve
     * numbers around a 30px-radius circle reads as clutter, not information, on real hardware;
     * a big digital time readout is far more legible for actually telling the time at a glance.
     * Panels too short for a legible face (under 24px tall) get just the digital time, centered.
     */
    fun renderClock(width: Int, height: Int, dateTypeface: Typeface?): Bitmap {
        val (bmp, canvas) = blankCanvas(width, height)
        val now = Calendar.getInstance()

        if (height < 24) {
            val hm = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now.time)
            val size = fitTextSize(hm, width - 4f, height * 0.9f, dateTypeface)
            val p = textPaint(size, dateTypeface).apply { isFakeBoldText = true }
            canvas.drawText(hm, (width - p.measureText(hm)) / 2f, (height + size * 0.7f) / 2f, p)
            return bmp
        }

        val radius = min(width, height) / 2f - 3f
        val cx = width - radius - 3f
        val cy = height / 2f
        val dateAreaWidth = cx - radius - 4f

        canvas.drawCircle(cx, cy, radius, strokePaint(2f))

        if (radius >= 10f) {
            val tickPaint = strokePaint(2f)
            for (i in 0 until 4) {
                val angle = Math.toRadians((i * 90).toDouble())
                val ox = sin(angle).toFloat()
                val oy = -cos(angle).toFloat()
                canvas.drawLine(
                    cx + ox * radius * 0.78f, cy + oy * radius * 0.78f,
                    cx + ox * radius * 0.95f, cy + oy * radius * 0.95f,
                    tickPaint
                )
            }
        }

        val hours = now.get(Calendar.HOUR)
        val minutes = now.get(Calendar.MINUTE)
        val seconds = now.get(Calendar.SECOND)

        fun hand(lengthRatio: Float, angleDeg: Double, strokeWidth: Float) {
            val angle = Math.toRadians(angleDeg)
            val hx = cx + (radius * lengthRatio * sin(angle)).toFloat()
            val hy = cy - (radius * lengthRatio * cos(angle)).toFloat()
            canvas.drawLine(cx, cy, hx, hy, strokePaint(strokeWidth))
        }
        hand(0.50f, (hours % 12) * 30.0 + minutes * 0.5, 3f)   // hour - thick, unambiguous
        hand(0.70f, minutes * 6.0 + seconds * 0.1, 2.5f)       // minute
        hand(0.85f, seconds * 6.0, 1.5f)                        // second - thin, least important

        if (dateAreaWidth >= 18f) {
            val hm = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now.time)
            val dayDate = SimpleDateFormat("EEE dd/MM", Locale.getDefault()).format(now.time)

            if (height >= 44f) {
                val timeSize = fitTextSize(hm, dateAreaWidth, height * 0.42f, dateTypeface)
                val timePaint = textPaint(timeSize, dateTypeface).apply { isFakeBoldText = true }
                var ty = timeSize
                canvas.drawText(hm, 2f, ty, timePaint)

                val dateSize = fitTextSize(dayDate, dateAreaWidth, height * 0.20f, dateTypeface)
                val datePaint = textPaint(dateSize, dateTypeface).apply { isFakeBoldText = true }
                ty += dateSize + 4f
                if (ty <= height) canvas.drawText(dayDate, 2f, ty, datePaint)
            } else {
                val size = fitTextSize(dayDate, dateAreaWidth, height * 0.6f, dateTypeface)
                val p = textPaint(size, dateTypeface).apply { isFakeBoldText = true }
                canvas.drawText(dayDate, 2f, size, p)
            }
        }

        return bmp
    }

    // ---- Phone stats dashboard ---------------------------------------------------------------

    private data class StatRow(val label: String, val pct: Int?)

    /** Battery %, battery temperature, RAM used/total, storage used/total, and this device's IP -
     * see the class doc for why these replace stats.py's CPU%/CPU-temp readings. Bold, full-width
     * text with a plain fill bar under any row that has a percentage - no pie slices, since a
     * thin arc segment is hard to read at a glance on real hardware. Rows are dropped (not
     * shrunk) on shorter panels so nothing gets small enough to be illegible. */
    fun renderStats(width: Int, height: Int, context: Context): Bitmap {
        val (bmp, canvas) = blankCanvas(width, height)

        val battIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val battPct = battIntent?.let {
            val level = it.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = it.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
            if (level >= 0 && scale > 0) level * 100 / scale else -1
        } ?: -1
        val battTempC = (battIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1) / 10f

        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memInfo)
        val ramTotalMb = memInfo.totalMem / (1024 * 1024)
        val ramUsedMb = ramTotalMb - memInfo.availMem / (1024 * 1024)
        val ramPct = if (ramTotalMb > 0) (ramUsedMb * 100 / ramTotalMb).toInt() else 0

        val stat = StatFs(context.filesDir.absolutePath)
        val totalBytes = stat.totalBytes
        val usedBytes = totalBytes - stat.availableBytes
        val storagePct = if (totalBytes > 0) (usedBytes * 100 / totalBytes).toInt() else 0
        val totalGb = totalBytes / (1024.0 * 1024 * 1024)
        val usedGb = usedBytes / (1024.0 * 1024 * 1024)

        val ip = localIpAddress()

        if (width < 90 || height < 28) {
            val text = "BAT $battPct% RAM $ramPct%"
            val size = fitTextSize(text, width - 2f, height * 0.6f, null)
            val p = textPaint(size, null).apply { isFakeBoldText = true }
            canvas.drawText(text, 1f, size, p)
            return bmp
        }

        val rows = if (height >= 56) {
            listOf(
                StatRow("BAT ${battPct}%  ${battTempC.toInt()}C", battPct),
                StatRow("RAM ${ramUsedMb}/${ramTotalMb}MB", ramPct),
                StatRow(String.format(Locale.US, "ROM %.1f/%.1fGB", usedGb, totalGb), storagePct),
                StatRow(ip, null)
            )
        } else {
            // Medium/short panels: the two most useful readouts, no bars, bigger text.
            listOf(
                StatRow("BAT ${battPct}%  RAM ${ramPct}%", null),
                StatRow(ip, null)
            )
        }

        val rowH = height.toFloat() / rows.size
        rows.forEachIndexed { i, row ->
            val top = i * rowH
            val hasBar = row.pct != null
            val textH = fitTextSize(row.label, width - 4f, rowH * (if (hasBar) 0.55f else 0.65f), null)
            val labelPaint = textPaint(textH, null).apply { isFakeBoldText = true }
            canvas.drawText(row.label, 2f, top + textH, labelPaint)
            if (hasBar) {
                val barTop = top + textH + 3f
                val barBottom = (top + rowH - 2f).coerceAtLeast(barTop + 3f)
                val barRect = RectF(2f, barTop, width - 2f, barBottom)
                canvas.drawRect(barRect, strokePaint(1.5f))
                val pct = (row.pct ?: 0).coerceIn(0, 100)
                if (pct > 0) {
                    canvas.drawRect(
                        RectF(
                            barRect.left + 1.5f, barRect.top + 1.5f,
                            barRect.left + 1.5f + (barRect.width() - 3f) * pct / 100f, barRect.bottom - 1.5f
                        ),
                        fillPaint()
                    )
                }
            }
        }

        return bmp
    }
}
