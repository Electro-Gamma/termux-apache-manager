package com.tcpuartbridge.app.eeprom

import com.tcpuartbridge.app.ch341.Ch341Spi

/**
 * Standard SPI NOR flash ("25xx" family - Winbond W25Qxx, GigaDevice GD25Qxx, Macronix MX25Lxx,
 * EON/XMC 25QHxxx, etc.) operations built on top of [Ch341Spi]'s raw transfer primitive. The
 * command set here (JEDEC ID, READ, WREN, page program, sector/chip erase, status polling, 4-byte
 * addressing, status-register unprotect) is the industry-standard SPI NOR instruction set - de
 * facto identical across manufacturers - not anything specific to IMSProg or flashrom; only the
 * underlying byte-transport ([Ch341Spi]) was ported from GPL code. Chip *identification*
 * ([SpiFlashDatabase]) does draw on IMSProg's chip database - see that file's doc comment.
 */
class SpiFlash(private val spi: Ch341Spi) {

    data class JedecId(val manufacturer: Int, val memoryType: Int, val capacityCode: Int) {
        /** Standard JEDEC convention: capacity in bytes = 2^capacityCode (valid for most parts). */
        val sizeBytes: Long get() = if (capacityCode in 8..30) 1L shl capacityCode else 0L
    }

    /** Set by [configureAddressing] - chips over 16MB need a 4th address byte and an explicit mode switch. */
    private var use4ByteAddr = false

    fun readJedecId(): JedecId? {
        val r = spi.transfer(byteArrayOf(CMD_JEDEC_ID.toByte()), 3) ?: return null
        return JedecId(r[0].toInt() and 0xFF, r[1].toInt() and 0xFF, r[2].toInt() and 0xFF)
    }

    /** Reads the JEDEC ID and looks it up in [SpiFlashDatabase]. Returns null on a USB failure. */
    fun detectChip(): SpiFlashDatabase.ChipPreset? {
        val id = readJedecId() ?: return null
        return SpiFlashDatabase.identify(id.manufacturer, id.memoryType, id.capacityCode)
    }

    fun readStatus(): Int? {
        val r = spi.transfer(byteArrayOf(CMD_RDSR.toByte()), 1) ?: return null
        return r[0].toInt() and 0xFF
    }

    private fun writeEnable(): Boolean = spi.transfer(byteArrayOf(CMD_WREN.toByte()), 0) != null

    private fun waitWhileBusy(timeoutMs: Long): Boolean {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            val sr = readStatus() ?: return false
            if (sr and SR_WIP == 0) return true
            Thread.sleep(2)
        }
        return false
    }

    /**
     * Call once after picking/detecting a chip, before any read/write/erase, with the chip's
     * total size. Chips over 16MB (128Mbit) can't be addressed with the standard 3-byte SPI NOR
     * address, so above that this both flips every following [addr] call over to 4 bytes and
     * issues the generic "enter 4-byte mode" command (0xB7) the chip needs first. This covers the
     * common Winbond/GigaDevice/EON/XMC parts; a handful of Spansion/Cypress chips use bank-
     * register commands instead of 0xB7/0xE9 and aren't covered here - see CH341_IMSPROG_NOTES.md
     * for what IMSProg does for those.
     */
    fun configureAddressing(sizeBytes: Long): Boolean {
        val need4Byte = sizeBytes > 0x1000000L
        if (need4Byte == use4ByteAddr) return true
        use4ByteAddr = need4Byte
        return spi.transfer(byteArrayOf((if (need4Byte) CMD_EN4B else CMD_EX4B).toByte()), 0) != null
    }

    private fun addr(address: Int): ByteArray = if (use4ByteAddr) {
        byteArrayOf(
            ((address shr 24) and 0xFF).toByte(), ((address shr 16) and 0xFF).toByte(),
            ((address shr 8) and 0xFF).toByte(), (address and 0xFF).toByte()
        )
    } else {
        byteArrayOf(((address shr 16) and 0xFF).toByte(), ((address shr 8) and 0xFF).toByte(), (address and 0xFF).toByte())
    }

    /**
     * Clears the status register's block-protect bits (BP0-BP3). Some W25Q/GD25Q parts ship - or
     * get left by a previous tool - with these set, which silently turns program/erase into a
     * no-op. [eraseChip] and [write] (when erasing first) both call this automatically; exposed
     * separately in case a caller wants to unprotect without immediately erasing/writing.
     * Ported from IMSProg's `snorUnprotect()` (see NOTICE.md).
     */
    fun unprotect(): Boolean {
        val sr = readStatus() ?: return false
        val cleared = sr and 0xC3 // keep WIP/WEL (bits 0-1) and bits 6-7, clear BP0-BP3 (bits 2-5)
        if (cleared == sr) return true
        if (!writeEnable()) return false
        return spi.transfer(byteArrayOf(CMD_WRSR.toByte(), cleared.toByte()), 0) != null
    }

    /** Reads [length] bytes starting at [address]. Returns null on the first USB failure. */
    fun read(address: Int, length: Int, onProgress: ((Int, Int) -> Unit)? = null): ByteArray? {
        val out = ByteArray(length)
        var offset = 0
        while (offset < length) {
            val n = minOf(READ_CHUNK, length - offset)
            val cmd = byteArrayOf(CMD_READ.toByte()) + addr(address + offset)
            val r = spi.transfer(cmd, n) ?: return null
            System.arraycopy(r, 0, out, offset, n)
            offset += n
            onProgress?.invoke(offset, length)
        }
        return out
    }

    /** Erases the whole chip. Can take tens of seconds to minutes on larger parts. */
    fun eraseChip(timeoutMs: Long = 200_000): Boolean {
        if (!unprotect()) return false
        if (!writeEnable()) return false
        if (spi.transfer(byteArrayOf(CMD_CHIP_ERASE.toByte()), 0) == null) return false
        return waitWhileBusy(timeoutMs)
    }

    /** Erases one 4KB sector containing [address]. */
    fun eraseSector4k(address: Int): Boolean {
        if (!writeEnable()) return false
        val cmd = byteArrayOf(CMD_SECTOR_ERASE_4K.toByte()) + addr(address and 0xFFF000.toInt())
        if (spi.transfer(cmd, 0) == null) return false
        return waitWhileBusy(10_000)
    }

    /**
     * Erases every 4KB sector covering [address] until [address]+[length], then writes [data]
     * page-by-page (respecting [pageSize], default 256B which covers virtually all SPI NOR
     * parts). Pass [eraseFirst] = false to skip erasing (e.g. writing to already-erased space).
     */
    fun write(
        address: Int,
        data: ByteArray,
        pageSize: Int = 256,
        eraseFirst: Boolean = true,
        onProgress: ((Int, Int) -> Unit)? = null
    ): Boolean {
        if (eraseFirst) {
            if (!unprotect()) return false
            var sectorAddr = address - (address % 4096)
            val endAddr = address + data.size
            while (sectorAddr < endAddr) {
                if (!eraseSector4k(sectorAddr)) return false
                sectorAddr += 4096
            }
        }
        var offset = 0
        while (offset < data.size) {
            val addrNow = address + offset
            val bytesLeftInPage = pageSize - (addrNow % pageSize)
            val n = minOf(bytesLeftInPage, data.size - offset)
            if (!writeEnable()) return false
            val cmd = byteArrayOf(CMD_PAGE_PROGRAM.toByte()) + addr(addrNow) + data.copyOfRange(offset, offset + n)
            if (spi.transfer(cmd, 0) == null) return false
            if (!waitWhileBusy(3_000)) return false
            offset += n
            onProgress?.invoke(offset, data.size)
        }
        return true
    }

    companion object {
        private const val CMD_WREN = 0x06
        private const val CMD_RDSR = 0x05
        private const val CMD_WRSR = 0x01
        private const val CMD_READ = 0x03
        private const val CMD_PAGE_PROGRAM = 0x02
        private const val CMD_SECTOR_ERASE_4K = 0x20
        private const val CMD_CHIP_ERASE = 0xC7
        private const val CMD_JEDEC_ID = 0x9F
        private const val CMD_EN4B = 0xB7 // enter 4-byte address mode
        private const val CMD_EX4B = 0xE9 // exit 4-byte address mode
        private const val SR_WIP = 0x01 // write-in-progress bit

        /** Read chunk size. Deliberately small - matching the universal 256B SPI NOR page size,
         *  the same order of magnitude as the tiny JEDEC-ID read that always works - rather than
         *  the 4096 this used to be. A 4KB chunk means a single Ch341Spi.transfer() call needs its
         *  encoded SPI-stream buffer (command + address + ~4KB of 0xFF filler, ~4.1KB total)
         *  moved over USB; Ch341UsbDevice.bulkOut()/readExactly() then fragment that into dozens
         *  of separate small bulkTransfer() calls, and every one of those calls happens *inside*
         *  this single CS-low/CS-high bracket (see Ch341Spi.transfer()). Real hardware doesn't
         *  tolerate that: a gap between two of those fragments mid-command desyncs the CH341A's
         *  own packet parsing, which is what turned "Reading 8192 KB from SPI flash" into a
         *  failure that then broke every later command (even a fresh JEDEC-ID read) until
         *  reconnecting. Keeping each transfer() call's total byte count in the low hundreds keeps
         *  it within (usually exactly one, occasionally a small handful of) reliable single
         *  bulkTransfer() calls instead.
         */
        private const val READ_CHUNK = 256
    }
}
