package com.tcpuartbridge.app.eeprom

import com.tcpuartbridge.app.ch341.Ch341Spi

/**
 * Standard SPI NOR flash ("25xx" family - Winbond W25Qxx, GigaDevice GD25Qxx, Macronix MX25Lxx,
 * etc.) operations built on top of [Ch341Spi]'s raw transfer primitive. The command set here
 * (JEDEC ID, READ, WREN, page program, sector/chip erase, status polling) is the industry-
 * standard SPI NOR instruction set - de facto identical across manufacturers - not anything
 * specific to IMSProg or flashrom; only the underlying byte-transport ([Ch341Spi]) was ported
 * from GPL code.
 */
class SpiFlash(private val spi: Ch341Spi) {

    data class JedecId(val manufacturer: Int, val memoryType: Int, val capacityCode: Int) {
        /** Standard JEDEC convention: capacity in bytes = 2^capacityCode (valid for most parts). */
        val sizeBytes: Long get() = if (capacityCode in 8..30) 1L shl capacityCode else 0L
    }

    fun readJedecId(): JedecId? {
        val r = spi.transfer(byteArrayOf(CMD_JEDEC_ID.toByte()), 3) ?: return null
        return JedecId(r[0].toInt() and 0xFF, r[1].toInt() and 0xFF, r[2].toInt() and 0xFF)
    }

    fun readStatus(): Int? {
        val r = spi.transfer(byteArrayOf(CMD_RDSR.toByte()), 1) ?: return null
        return r[0].toInt() and 0xFF
    }

    private fun writeEnable(): Boolean = spi.transfer(byteArrayOf(CMD_WREN.toByte()), 0) != null

    private fun waitWhileBusy(timeoutMs: Long): Boolean {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            val sr = readStatus() ?: return false
            if (sr and SR_WIP == 0) return true
            Thread.sleep(2)
        }
        return false
    }

    private fun addr24(address: Int): ByteArray = byteArrayOf(
        ((address shr 16) and 0xFF).toByte(),
        ((address shr 8) and 0xFF).toByte(),
        (address and 0xFF).toByte()
    )

    /** Reads [length] bytes starting at [address]. Returns null on the first USB failure. */
    fun read(address: Int, length: Int, onProgress: ((Int, Int) -> Unit)? = null): ByteArray? {
        val out = ByteArray(length)
        var offset = 0
        while (offset < length) {
            val n = minOf(READ_CHUNK, length - offset)
            val cmd = byteArrayOf(CMD_READ.toByte()) + addr24(address + offset)
            val r = spi.transfer(cmd, n) ?: return null
            System.arraycopy(r, 0, out, offset, n)
            offset += n
            onProgress?.invoke(offset, length)
        }
        return out
    }

    /** Erases the whole chip. Can take tens of seconds to minutes on larger parts. */
    fun eraseChip(timeoutMs: Long = 200_000): Boolean {
        if (!writeEnable()) return false
        if (spi.transfer(byteArrayOf(CMD_CHIP_ERASE.toByte()), 0) == null) return false
        return waitWhileBusy(timeoutMs)
    }

    /** Erases one 4KB sector containing [address]. */
    fun eraseSector4k(address: Int): Boolean {
        if (!writeEnable()) return false
        val cmd = byteArrayOf(CMD_SECTOR_ERASE_4K.toByte()) + addr24(address and 0xFFF000.toInt())
        if (spi.transfer(cmd, 0) == null) return false
        return waitWhileBusy(10_000)
    }

    /**
     * Erases every 4KB sector covering [address] until [address]+[length], then writes [data]
     * page-by-page (respecting [pageSize], default 256B which covers virtually all SPI NOR
     * parts). Pass [eraseFirst] = false to skip erasing (e.g. writing to already-erased space).
     */
    fun write(
        address: Int,
        data: ByteArray,
        pageSize: Int = 256,
        eraseFirst: Boolean = true,
        onProgress: ((Int, Int) -> Unit)? = null
    ): Boolean {
        if (eraseFirst) {
            var sectorAddr = address - (address % 4096)
            val endAddr = address + data.size
            while (sectorAddr < endAddr) {
                if (!eraseSector4k(sectorAddr)) return false
                sectorAddr += 4096
            }
        }
        var offset = 0
        while (offset < data.size) {
            val addr = address + offset
            val bytesLeftInPage = pageSize - (addr % pageSize)
            val n = minOf(bytesLeftInPage, data.size - offset)
            if (!writeEnable()) return false
            val cmd = byteArrayOf(CMD_PAGE_PROGRAM.toByte()) + addr24(addr) + data.copyOfRange(offset, offset + n)
            if (spi.transfer(cmd, 0) == null) return false
            if (!waitWhileBusy(3_000)) return false
            offset += n
            onProgress?.invoke(offset, data.size)
        }
        return true
    }

    companion object {
        private const val CMD_WREN = 0x06
        private const val CMD_RDSR = 0x05
        private const val CMD_READ = 0x03
        private const val CMD_PAGE_PROGRAM = 0x02
        private const val CMD_SECTOR_ERASE_4K = 0x20
        private const val CMD_CHIP_ERASE = 0xC7
        private const val CMD_JEDEC_ID = 0x9F
        private const val SR_WIP = 0x01 // write-in-progress bit

        /** Read chunk size - arbitrary, just keeps individual USB transfers a reasonable size. */
        private const val READ_CHUNK = 4096
    }
}
