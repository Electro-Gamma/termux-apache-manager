package com.tcpuartbridge.app.programmer

import android.content.Context
import android.hardware.usb.UsbDevice
import com.tcpuartbridge.app.ch341.Ch341I2c
import com.tcpuartbridge.app.ch341.Ch341Spi
import com.tcpuartbridge.app.ch341.Ch341UsbDevice
import com.tcpuartbridge.app.display.Ssd1306
import com.tcpuartbridge.app.eeprom.I2cEeprom
import com.tcpuartbridge.app.eeprom.SpiFlash
import com.tcpuartbridge.app.eeprom.SpiFlashDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

enum class ProgrammerMode { I2C_EEPROM, SPI_FLASH, SSD1306_DISPLAY }

/**
 * Owns the CH341A (programmer-mode) USB connection for the "Programmer" tab and exposes one
 * suspend function per UI action, each hopping to [Dispatchers.IO] so a USB transfer never blocks
 * the UI thread - the same pattern [com.tcpuartbridge.app.BridgeService] uses for the serial
 * bridge, just for this separate, independent USB personality (see [Ch341UsbDevice]'s class doc
 * for why CH341A "programmer mode" needs its own connection instead of reusing
 * [com.tcpuartbridge.app.UsbSerialManager]).
 */
class ProgrammerController(context: Context) {

    val usbDevice = Ch341UsbDevice(context)
    private var i2cBus: Ch341I2c? = null
    private var spiBus: Ch341Spi? = null
    // One SpiFlash instance per connection, not one per call: it carries the 4-byte-addressing
    // flag set by configureSpiAddressing(), which needs to survive across the separate
    // read/write/erase calls that follow it - a fresh SpiFlash(spiBus) per call would forget it.
    private var spiFlash: SpiFlash? = null
    private var display: Ssd1306? = null

    val isConnected: Boolean get() = usbDevice.isOpen

    fun findDevice(): UsbDevice? = usbDevice.findDevice()
    fun hasPermission(dev: UsbDevice): Boolean = usbDevice.hasPermission(dev)
    fun requestPermission(dev: UsbDevice, callback: (Boolean) -> Unit) = usbDevice.requestPermission(dev, callback)

    suspend fun connect(dev: UsbDevice, mode: ProgrammerMode): Boolean = withContext(Dispatchers.IO) {
        if (!usbDevice.open(dev)) return@withContext false
        val i2c = Ch341I2c(usbDevice)
        val spi = Ch341Spi(usbDevice)
        i2cBus = i2c
        spiBus = spi
        spiFlash = SpiFlash(spi)
        when (mode) {
            ProgrammerMode.SPI_FLASH -> spi.init()
            ProgrammerMode.I2C_EEPROM, ProgrammerMode.SSD1306_DISPLAY -> i2c.configSpeed(Ch341I2c.SPEED_400K)
        }
    }

    suspend fun disconnect(mode: ProgrammerMode) = withContext(Dispatchers.IO) {
        stopI2cTcpServer()
        if (mode == ProgrammerMode.SPI_FLASH) spiBus?.shutdown()
        usbDevice.close()
        i2cBus = null
        spiBus = null
        spiFlash = null
        display = null
    }

    // ---- I2C EEPROM (24Cxx) ------------------------------------------------

    suspend fun readEeprom(chip: I2cEeprom.Chip, onProgress: (done: Int, total: Int) -> Unit): ByteArray? =
        withContext(Dispatchers.IO) {
            val bus = i2cBus ?: return@withContext null
            I2cEeprom(bus).read(chip, 0, chip.totalBytes, onProgress)
        }

    suspend fun writeEeprom(chip: I2cEeprom.Chip, data: ByteArray, onProgress: (done: Int, total: Int) -> Unit): Boolean =
        withContext(Dispatchers.IO) {
            val bus = i2cBus ?: return@withContext false
            I2cEeprom(bus).write(chip, 0, data, onProgress)
        }

    /** Fills the whole chip with [fillByte] (0xFF by default) - see [I2cEeprom.erase]. */
    suspend fun eraseEeprom(
        chip: I2cEeprom.Chip,
        fillByte: Byte = 0xFF.toByte(),
        onProgress: (done: Int, total: Int) -> Unit
    ): Boolean = withContext(Dispatchers.IO) {
        val bus = i2cBus ?: return@withContext false
        I2cEeprom(bus).erase(chip, fillByte, onProgress)
    }

    /** Address-wraparound capacity probe restricted to [baseChip]'s address-byte family - see [I2cEeprom.detectSize]. */
    suspend fun detectEepromSize(baseChip: I2cEeprom.Chip): I2cEeprom.SizeDetectionResult? = withContext(Dispatchers.IO) {
        val bus = i2cBus ?: return@withContext null
        I2cEeprom(bus).detectSize(baseChip)
    }

    // ---- SPI NOR flash (25xx) ----------------------------------------------

    suspend fun readSpiJedecId(): SpiFlash.JedecId? = withContext(Dispatchers.IO) {
        spiFlash?.readJedecId()
    }

    /** Reads the JEDEC ID and looks it up in [SpiFlashDatabase] - see [SpiFlash.detectChip]. */
    suspend fun detectSpiChip(): SpiFlashDatabase.ChipPreset? = withContext(Dispatchers.IO) {
        spiFlash?.detectChip()
    }

    /**
     * Call once after picking/detecting a chip, before read/write/erase, so chips over 16MB
     * switch to 4-byte addressing first - see [SpiFlash.configureAddressing].
     */
    suspend fun configureSpiAddressing(sizeBytes: Long): Boolean = withContext(Dispatchers.IO) {
        spiFlash?.configureAddressing(sizeBytes) ?: false
    }

    suspend fun readSpiFlash(length: Int, onProgress: (done: Int, total: Int) -> Unit): ByteArray? =
        withContext(Dispatchers.IO) {
            spiFlash?.read(0, length, onProgress = onProgress)
        }

    suspend fun eraseSpiFlashChip(): Boolean = withContext(Dispatchers.IO) {
        spiFlash?.eraseChip() ?: false
    }

    suspend fun writeSpiFlash(data: ByteArray, pageSize: Int, onProgress: (done: Int, total: Int) -> Unit): Boolean =
        withContext(Dispatchers.IO) {
            spiFlash?.write(0, data, pageSize, eraseFirst = true, onProgress = onProgress) ?: false
        }

    // ---- SSD1306 OLED -------------------------------------------------------

    suspend fun initDisplay(address7: Int, width: Int, height: Int): Boolean = withContext(Dispatchers.IO) {
        val bus = i2cBus ?: return@withContext false
        val d = Ssd1306(bus, address7, width, height)
        val ok = d.init()
        if (ok) display = d
        ok
    }

    suspend fun displayClear(): Boolean = withContext(Dispatchers.IO) {
        val d = display ?: return@withContext false
        d.clear()
        d.flush()
    }

    suspend fun displayTestPattern(): Boolean = withContext(Dispatchers.IO) {
        val d = display ?: return@withContext false
        d.testPattern()
        d.flush()
    }

    /** Clears the panel and draws [text] - see [Ssd1306.drawText] for the word-wrap/newline rules. */
    suspend fun displayText(text: String): Boolean = withContext(Dispatchers.IO) {
        val d = display ?: return@withContext false
        d.clear()
        d.drawText(0, 0, text)
        d.flush()
    }

    /** Scales/thresholds [bitmap] onto the panel and flushes it - see [Ssd1306.drawBitmap]. */
    suspend fun displayBitmap(bitmap: android.graphics.Bitmap): Boolean = withContext(Dispatchers.IO) {
        val d = display ?: return@withContext false
        d.drawBitmap(bitmap)
        d.flush()
    }

    // ---- I2C-over-TCP -----------------------------------------------------

    private var i2cTcpServer: I2cTcpServer? = null

    val isI2cTcpServerRunning: Boolean get() = i2cTcpServer?.isRunning == true

    /**
     * Starts forwarding I2C transactions from network clients to whichever I2C bus is currently
     * connected - see [I2cTcpServer]'s class doc for the wire protocol, and the repo's
     * `python-i2c-tcp/` folder for a Python client. Only meaningful in [ProgrammerMode.I2C_EEPROM]
     * or [ProgrammerMode.SSD1306_DISPLAY] (those are the modes that configure the shared CH341A
     * clock for I2C speed rather than SPI speed - see [connect]).
     */
    fun startI2cTcpServer(
        port: Int,
        onClientConnected: (String) -> Unit,
        onClientDisconnected: (String) -> Unit,
        onError: (Exception) -> Unit
    ) {
        stopI2cTcpServer()
        val server = I2cTcpServer { i2cBus }
        server.onClientConnected = onClientConnected
        server.onClientDisconnected = onClientDisconnected
        server.onError = onError
        server.start(port)
        i2cTcpServer = server
    }

    fun stopI2cTcpServer() {
        i2cTcpServer?.stop()
        i2cTcpServer = null
    }
}
