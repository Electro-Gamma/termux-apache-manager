package com.tcpuartbridge.app.programmer

import android.content.Context
import android.hardware.usb.UsbDevice
import com.tcpuartbridge.app.ch341.Ch341I2c
import com.tcpuartbridge.app.ch341.Ch341Spi
import com.tcpuartbridge.app.ch341.Ch341UsbDevice
import com.tcpuartbridge.app.display.Ssd1306
import com.tcpuartbridge.app.eeprom.I2cEeprom
import com.tcpuartbridge.app.eeprom.SpiFlash
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

enum class ProgrammerMode { I2C_EEPROM, SPI_FLASH, SSD1306_DISPLAY }

/**
 * Owns the CH341A (programmer-mode) USB connection for the "Programmer" tab and exposes one
 * suspend function per UI action, each hopping to [Dispatchers.IO] so a USB transfer never blocks
 * the UI thread - the same pattern [com.tcpuartbridge.app.BridgeService] uses for the serial
 * bridge, just for this separate, independent USB personality (see [Ch341UsbDevice]'s class doc
 * for why CH341A "programmer mode" needs its own connection instead of reusing
 * [com.tcpuartbridge.app.UsbSerialManager]).
 */
class ProgrammerController(context: Context) {

    val usbDevice = Ch341UsbDevice(context)
    private var i2cBus: Ch341I2c? = null
    private var spiBus: Ch341Spi? = null
    private var display: Ssd1306? = null

    val isConnected: Boolean get() = usbDevice.isOpen

    fun findDevice(): UsbDevice? = usbDevice.findDevice()
    fun hasPermission(dev: UsbDevice): Boolean = usbDevice.hasPermission(dev)
    fun requestPermission(dev: UsbDevice, callback: (Boolean) -> Unit) = usbDevice.requestPermission(dev, callback)

    suspend fun connect(dev: UsbDevice, mode: ProgrammerMode): Boolean = withContext(Dispatchers.IO) {
        if (!usbDevice.open(dev)) return@withContext false
        val i2c = Ch341I2c(usbDevice)
        val spi = Ch341Spi(usbDevice)
        i2cBus = i2c
        spiBus = spi
        when (mode) {
            ProgrammerMode.SPI_FLASH -> spi.init()
            ProgrammerMode.I2C_EEPROM, ProgrammerMode.SSD1306_DISPLAY -> i2c.configSpeed(Ch341I2c.SPEED_400K)
        }
    }

    suspend fun disconnect(mode: ProgrammerMode) = withContext(Dispatchers.IO) {
        if (mode == ProgrammerMode.SPI_FLASH) spiBus?.shutdown()
        usbDevice.close()
        i2cBus = null
        spiBus = null
        display = null
    }

    // ---- I2C EEPROM (24Cxx) ------------------------------------------------

    suspend fun readEeprom(chip: I2cEeprom.Chip, onProgress: (done: Int, total: Int) -> Unit): ByteArray? =
        withContext(Dispatchers.IO) {
            val bus = i2cBus ?: return@withContext null
            I2cEeprom(bus).read(chip, 0, chip.totalBytes, onProgress)
        }

    suspend fun writeEeprom(chip: I2cEeprom.Chip, data: ByteArray, onProgress: (done: Int, total: Int) -> Unit): Boolean =
        withContext(Dispatchers.IO) {
            val bus = i2cBus ?: return@withContext false
            I2cEeprom(bus).write(chip, 0, data, onProgress)
        }

    // ---- SPI NOR flash (25xx) ----------------------------------------------

    suspend fun readSpiJedecId(): SpiFlash.JedecId? = withContext(Dispatchers.IO) {
        spiBus?.let { SpiFlash(it).readJedecId() }
    }

    suspend fun readSpiFlash(length: Int, onProgress: (done: Int, total: Int) -> Unit): ByteArray? =
        withContext(Dispatchers.IO) {
            spiBus?.let { SpiFlash(it).read(0, length, onProgress = onProgress) }
        }

    suspend fun eraseSpiFlashChip(): Boolean = withContext(Dispatchers.IO) {
        spiBus?.let { SpiFlash(it).eraseChip() } ?: false
    }

    suspend fun writeSpiFlash(data: ByteArray, pageSize: Int, onProgress: (done: Int, total: Int) -> Unit): Boolean =
        withContext(Dispatchers.IO) {
            spiBus?.let { SpiFlash(it).write(0, data, pageSize, eraseFirst = true, onProgress = onProgress) } ?: false
        }

    // ---- SSD1306 OLED -------------------------------------------------------

    suspend fun initDisplay(address7: Int, width: Int, height: Int): Boolean = withContext(Dispatchers.IO) {
        val bus = i2cBus ?: return@withContext false
        val d = Ssd1306(bus, address7, width, height)
        val ok = d.init()
        if (ok) display = d
        ok
    }

    suspend fun displayClear(): Boolean = withContext(Dispatchers.IO) {
        val d = display ?: return@withContext false
        d.clear()
        d.flush()
    }

    suspend fun displayTestPattern(): Boolean = withContext(Dispatchers.IO) {
        val d = display ?: return@withContext false
        d.testPattern()
        d.flush()
    }

    /** Clears the panel and draws [text], word-wrapping across 6px-wide/8px-tall character cells. */
    suspend fun displayText(text: String): Boolean = withContext(Dispatchers.IO) {
        val d = display ?: return@withContext false
        d.clear()
        val charsPerLine = maxOf(1, d.width / 6)
        val lineHeight = 8
        text.chunked(charsPerLine).forEachIndexed { i, line -> d.drawText(0, i * lineHeight, line) }
        d.flush()
    }

    /** Scales/thresholds [bitmap] onto the panel and flushes it - see [Ssd1306.drawBitmap]. */
    suspend fun displayBitmap(bitmap: android.graphics.Bitmap): Boolean = withContext(Dispatchers.IO) {
        val d = display ?: return@withContext false
        d.drawBitmap(bitmap)
        d.flush()
    }
}
