package com.tcpuartbridge.app.programmer

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Typeface
import android.hardware.usb.UsbDevice
import android.net.Uri
import android.provider.OpenableColumns
import com.tcpuartbridge.app.ch341.Ch341I2c
import com.tcpuartbridge.app.ch341.Ch341Spi
import com.tcpuartbridge.app.ch341.Ch341UsbDevice
import com.tcpuartbridge.app.display.OledCompositor
import com.tcpuartbridge.app.display.Ssd1306
import com.tcpuartbridge.app.eeprom.I2cEeprom
import com.tcpuartbridge.app.eeprom.SpiFlash
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class ProgrammerMode { I2C_EEPROM, SPI_FLASH, SSD1306_DISPLAY }

/**
 * Owns the CH341A (programmer-mode) USB connection for the "Programmer" tab and exposes one
 * suspend function per one-shot UI action, each hopping to [Dispatchers.IO] so a USB transfer
 * never blocks the UI thread - the same pattern [com.tcpuartbridge.app.BridgeService] uses for
 * the serial bridge, just for this separate, independent USB personality (see
 * [Ch341UsbDevice]'s class doc for why CH341A "programmer mode" needs its own connection instead
 * of reusing [com.tcpuartbridge.app.UsbSerialManager]).
 *
 * The clock/stats/animation screens are different from everything else here: they redraw forever
 * until stopped, so they run as a cancellable [Job] on [continuousScope] instead of a plain
 * suspend function - see [startClock]/[startStats]/[startAnimation]/[stopContinuous].
 */
class ProgrammerController(context: Context) {

    val usbDevice = Ch341UsbDevice(context)
    private var i2cBus: Ch341I2c? = null
    private var spiBus: Ch341Spi? = null
    private var display: Ssd1306? = null

    val isConnected: Boolean get() = usbDevice.isOpen

    fun findDevice(): UsbDevice? = usbDevice.findDevice()
    fun hasPermission(dev: UsbDevice): Boolean = usbDevice.hasPermission(dev)
    fun requestPermission(dev: UsbDevice, callback: (Boolean) -> Unit) = usbDevice.requestPermission(dev, callback)

    suspend fun connect(dev: UsbDevice, mode: ProgrammerMode): Boolean = withContext(Dispatchers.IO) {
        if (!usbDevice.open(dev)) return@withContext false
        val i2c = Ch341I2c(usbDevice)
        val spi = Ch341Spi(usbDevice)
        i2cBus = i2c
        spiBus = spi
        when (mode) {
            ProgrammerMode.SPI_FLASH -> spi.init()
            ProgrammerMode.I2C_EEPROM, ProgrammerMode.SSD1306_DISPLAY -> i2c.configSpeed(Ch341I2c.SPEED_400K)
        }
    }

    suspend fun disconnect(mode: ProgrammerMode) = withContext(Dispatchers.IO) {
        continuousJob?.cancelAndJoin() // wait for any running clock/stats/animation loop to fully stop first
        continuousJob = null
        stopI2cTcpServer()
        if (mode == ProgrammerMode.SPI_FLASH) spiBus?.shutdown()
        usbDevice.close()
        i2cBus = null
        spiBus = null
        display = null
    }

    // ---- I2C EEPROM (24Cxx) ------------------------------------------------

    suspend fun readEeprom(chip: I2cEeprom.Chip, onProgress: (done: Int, total: Int) -> Unit): ByteArray? =
        withContext(Dispatchers.IO) {
            val bus = i2cBus ?: return@withContext null
            I2cEeprom(bus).read(chip, 0, chip.totalBytes, onProgress)
        }

    suspend fun writeEeprom(chip: I2cEeprom.Chip, data: ByteArray, onProgress: (done: Int, total: Int) -> Unit): Boolean =
        withContext(Dispatchers.IO) {
            val bus = i2cBus ?: return@withContext false
            I2cEeprom(bus).write(chip, 0, data, onProgress)
        }

    // ---- SPI NOR flash (25xx) ----------------------------------------------

    suspend fun readSpiJedecId(): SpiFlash.JedecId? = withContext(Dispatchers.IO) {
        spiBus?.let { SpiFlash(it).readJedecId() }
    }

    suspend fun readSpiFlash(length: Int, onProgress: (done: Int, total: Int) -> Unit): ByteArray? =
        withContext(Dispatchers.IO) {
            spiBus?.let { SpiFlash(it).read(0, length, onProgress = onProgress) }
        }

    suspend fun eraseSpiFlashChip(): Boolean = withContext(Dispatchers.IO) {
        spiBus?.let { SpiFlash(it).eraseChip() } ?: false
    }

    suspend fun writeSpiFlash(data: ByteArray, pageSize: Int, onProgress: (done: Int, total: Int) -> Unit): Boolean =
        withContext(Dispatchers.IO) {
            spiBus?.let { SpiFlash(it).write(0, data, pageSize, eraseFirst = true, onProgress = onProgress) } ?: false
        }

    // ---- SSD1306 OLED - one-shot actions ------------------------------------

    suspend fun initDisplay(address7: Int, width: Int, height: Int): Boolean = withContext(Dispatchers.IO) {
        val bus = i2cBus ?: return@withContext false
        val d = Ssd1306(bus, address7, width, height)
        val ok = d.init()
        if (ok) display = d
        ok
    }

    suspend fun displayClear(): Boolean = withContext(Dispatchers.IO) {
        val d = display ?: return@withContext false
        d.clear()
        d.flush()
    }

    suspend fun displayTestPattern(): Boolean = withContext(Dispatchers.IO) {
        val d = display ?: return@withContext false
        d.testPattern()
        d.flush()
    }

    /** Clears the panel and draws [text] with the built-in pixel font - see [Ssd1306.drawText]
     * for the word-wrap/newline rules, or [displayCustomText] to use a loaded TTF/OTF instead. */
    suspend fun displayText(text: String): Boolean = withContext(Dispatchers.IO) {
        val d = display ?: return@withContext false
        d.clear()
        d.drawText(0, 0, text)
        d.flush()
    }

    /** Same as [displayText] but rendered with [customFontTypeface] via Android's own text
     * layout/wrapping - only meaningful once [loadCustomFont] has loaded something. */
    suspend fun displayCustomText(text: String): Boolean = withContext(Dispatchers.IO) {
        val d = display ?: return@withContext false
        val frame = OledCompositor.renderText(d.width, d.height, text, customFontTypeface, textSizePx = d.height / 4f)
        d.clear()
        d.drawBitmap(frame, dither = false)
        val ok = d.flush()
        frame.recycle()
        ok
    }

    /** Scales/thresholds [bitmap] onto the panel and flushes it - see [Ssd1306.drawBitmap]. */
    suspend fun displayBitmap(bitmap: Bitmap, dither: Boolean = true): Boolean = withContext(Dispatchers.IO) {
        val d = display ?: return@withContext false
        d.drawBitmap(bitmap, dither = dither)
        d.flush()
    }

    // ---- Custom font (for Draw Text / the clock's date) ---------------------

    var customFontTypeface: Typeface? = null
        private set
    var customFontName: String? = null
        private set

    /** Loads [uri] as a [Typeface] - accepts any file the user picks rather than filtering by
     * MIME type, since SAF's MIME sniffing for .ttf/.otf is inconsistent across devices/vendors.
     * Returns false (and leaves any previously-loaded font in place) if it isn't a valid font. */
    fun loadCustomFont(context: Context, uri: Uri): Boolean {
        val typeface = try {
            context.contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
                Typeface.Builder(pfd.fileDescriptor).build()
            }
        } catch (e: Exception) {
            null
        }
        if (typeface == null) return false
        customFontTypeface = typeface
        customFontName = queryDisplayName(context, uri) ?: uri.lastPathSegment ?: "font"
        return true
    }

    fun clearCustomFont() {
        customFontTypeface = null
        customFontName = null
    }

    private fun queryDisplayName(context: Context, uri: Uri): String? = try {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(0) else null
        }
    } catch (e: Exception) {
        null
    }

    // ---- Clock / Stats / Animate - continuous redraw loops -------------------

    private val continuousScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var continuousJob: Job? = null

    val isContinuousRunning: Boolean get() = continuousJob?.isActive == true

    /** Stops whichever of [startClock]/[startStats]/[startAnimation] is currently running, if any. */
    fun stopContinuous() {
        continuousJob?.cancel()
        continuousJob = null
    }

    /** Redraws an analog clock + date once a second until [stopContinuous] is called or a write
     * fails. Uses [customFontTypeface] for the date text if one is loaded. [onStopped] fires
     * exactly once, off the main thread, whenever the loop ends for any reason. */
    fun startClock(intervalMs: Long = 1000L, onStopped: (error: String?) -> Unit = {}) {
        val d = display
        if (d == null) {
            onStopped("Connect in SSD1306 Display mode first")
            return
        }
        stopContinuous()
        continuousJob = continuousScope.launch {
            var error: String? = null
            try {
                while (isActive) {
                    val frame = OledCompositor.renderClock(d.width, d.height, customFontTypeface)
                    d.clear()
                    d.drawBitmap(frame, dither = false)
                    val ok = d.flush()
                    frame.recycle()
                    if (!ok) {
                        error = "Clock: display write failed"
                        break
                    }
                    delay(intervalMs)
                }
            } finally {
                onStopped(error)
            }
        }
    }

    /** Redraws a battery/RAM/storage/IP dashboard once a second - same lifecycle as [startClock]. */
    fun startStats(context: Context, intervalMs: Long = 1000L, onStopped: (error: String?) -> Unit = {}) {
        val d = display
        if (d == null) {
            onStopped("Connect in SSD1306 Display mode first")
            return
        }
        stopContinuous()
        continuousJob = continuousScope.launch {
            var error: String? = null
            try {
                while (isActive) {
                    val frame = OledCompositor.renderStats(d.width, d.height, context)
                    d.clear()
                    d.drawBitmap(frame, dither = false)
                    val ok = d.flush()
                    frame.recycle()
                    if (!ok) {
                        error = "Stats: display write failed"
                        break
                    }
                    delay(intervalMs)
                }
            } finally {
                onStopped(error)
            }
        }
    }

    /** Loops through [frames] (already-decoded, in display order), [frameDelayMs] apart, until
     * [stopContinuous] is called or a write fails - the same idea as `pbm_gif_all.py`'s
     * folder-of-PBM-frames loop, just from Android-picked image files instead of a PBM folder. */
    fun startAnimation(frames: List<Bitmap>, frameDelayMs: Long = 100L, onStopped: (error: String?) -> Unit = {}) {
        val d = display
        if (d == null) {
            onStopped("Connect in SSD1306 Display mode first")
            return
        }
        if (frames.isEmpty()) {
            onStopped("No frames to animate")
            return
        }
        stopContinuous()
        continuousJob = continuousScope.launch {
            var error: String? = null
            try {
                outer@ while (isActive) {
                    for (frame in frames) {
                        if (!isActive) break@outer
                        d.clear()
                        d.drawBitmap(frame, dither = false)
                        val ok = d.flush()
                        if (!ok) {
                            error = "Animation: display write failed"
                            break@outer
                        }
                        delay(frameDelayMs)
                    }
                }
            } finally {
                onStopped(error)
            }
        }
    }

    // ---- I2C-over-TCP -----------------------------------------------------

    private var i2cTcpServer: I2cTcpServer? = null

    val isI2cTcpServerRunning: Boolean get() = i2cTcpServer?.isRunning == true

    /**
     * Starts forwarding I2C transactions from network clients to whichever I2C bus is currently
     * connected - see [I2cTcpServer]'s class doc for the wire protocol, and the repo's
     * `python-i2c-tcp/` folder for a Python client. Only meaningful in [ProgrammerMode.I2C_EEPROM]
     * or [ProgrammerMode.SSD1306_DISPLAY] (those are the modes that configure the shared CH341A
     * clock for I2C speed rather than SPI speed - see [connect]).
     */
    fun startI2cTcpServer(
        port: Int,
        onClientConnected: (String) -> Unit,
        onClientDisconnected: (String) -> Unit,
        onError: (Exception) -> Unit
    ) {
        stopI2cTcpServer()
        val server = I2cTcpServer { i2cBus }
        server.onClientConnected = onClientConnected
        server.onClientDisconnected = onClientDisconnected
        server.onError = onError
        server.start(port)
        i2cTcpServer = server
    }

    fun stopI2cTcpServer() {
        i2cTcpServer?.stop()
        i2cTcpServer = null
    }
}
