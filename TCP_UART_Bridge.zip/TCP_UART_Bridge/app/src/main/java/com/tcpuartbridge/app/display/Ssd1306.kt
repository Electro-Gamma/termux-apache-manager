package com.tcpuartbridge.app.display

import com.tcpuartbridge.app.ch341.Ch341I2c

/**
 * Driver for SSD1306-based I2C OLED panels (the common 128x64 / 128x32 "0.96 inch" / "0.91 inch"
 * modules), talking over a [Ch341I2c] bus via the CH341A. The init sequence and command set are
 * the standard ones from Solomon Systech's SSD1306 datasheet (identical across every SSD1306
 * library); the 5x7 text font below is this file's own, generated from scratch (see
 * `gen_font.py` design notes in the repo) rather than copied from any particular library.
 *
 * I2C framing: every write is a `[control byte][payload...]` pair with no register address -
 * control byte 0x00 means "payload is command bytes", 0x40 means "payload is display-RAM data".
 * This class keeps an in-memory framebuffer ([fb]) and only touches the display when [flush] is
 * called, so callers can draw several things before paying for the I2C traffic.
 */
class Ssd1306(
    private val i2c: Ch341I2c,
    private val address7: Int = DEFAULT_ADDRESS,
    val width: Int = 128,
    val height: Int = 64
) {
    private val pages = height / 8
    val fb = ByteArray(width * pages)

    private fun cmd(vararg bytes: Int): Boolean =
        i2c.writeRaw(address7, byteArrayOf(0x00.toByte()) + bytes.map { it.toByte() }.toByteArray())

    /** Runs the standard SSD1306 power-on init sequence. Call once before drawing anything. */
    fun init(): Boolean {
        // 128x32 modules commonly ship with different COM-pin and contrast defaults than
        // 128x64 ones - matches known-good reference init sequences for both sizes.
        val comPins = if (height <= 32) 0x02 else 0x12
        val contrast = if (height <= 32) 0x8F else 0xCF
        val ok = cmd(0xAE) && // display off
            cmd(0xD5, 0x80) && // clock divide
            cmd(0xA8, height - 1) && // multiplex ratio
            cmd(0xD3, 0x00) && // display offset
            cmd(0x40) && // start line = 0
            cmd(0x8D, 0x14) && // charge pump on
            cmd(0x20, 0x00) && // horizontal addressing mode
            cmd(0xA1) && // segment remap
            cmd(0xC8) && // COM scan direction, remapped
            cmd(0xDA, comPins) &&
            cmd(0x81, contrast) &&
            cmd(0xD9, 0xF1) && // pre-charge
            cmd(0xDB, 0x40) && // VCOMH deselect level
            cmd(0xA4) && // resume RAM content display
            cmd(0xA6) && // normal (not inverted)
            cmd(0xAF)   // display on
        clear()
        return ok
    }

    fun setContrast(value: Int): Boolean = cmd(0x81, value and 0xFF)

    fun setInverted(inverted: Boolean): Boolean = cmd(if (inverted) 0xA7 else 0xA6)

    fun setDisplayOn(on: Boolean): Boolean = cmd(if (on) 0xAF else 0xAE)

    fun clear() = fb.fill(0.toByte())

    fun setPixel(x: Int, y: Int, on: Boolean) {
        if (x !in 0 until width || y !in 0 until height) return
        val idx = x + (y / 8) * width
        val bit = 1 shl (y % 8)
        fb[idx] = if (on) (fb[idx].toInt() or bit).toByte() else (fb[idx].toInt() and bit.inv()).toByte()
    }

    /** Draws 5x7 text with 1px spacing between glyphs, top-left at ([x], [y]). Unknown chars are skipped. */
    fun drawText(x: Int, y: Int, text: String) {
        var cx = x
        for (ch in text.uppercase()) {
            val glyph = FONT_5X7[ch] ?: FONT_5X7[' ']!!
            for (col in 0 until 5) {
                val bits = glyph[col]
                for (row in 0 until 7) {
                    if ((bits shr row) and 1 == 1) setPixel(cx + col, y + row, true)
                }
            }
            cx += 6
        }
    }

    /** Fills the framebuffer with a coarse checkerboard - useful as a hardware sanity check. */
    fun testPattern() {
        for (y in 0 until height) {
            for (x in 0 until width) {
                setPixel(x, y, ((x / 4) + (y / 4)) % 2 == 0)
            }
        }
    }

    /**
     * Sets the framebuffer from [bitmap] (scaled to the panel's resolution first if it isn't
     * already that size), thresholding each pixel's luminance against [threshold] (0-255,
     * ITU-R BT.601 weights). Mirrors the classic Python SSD1306 driver's `image()` method -
     * convert to 1-bit and copy pixel-by-pixel - just done with Android's own Bitmap APIs
     * instead of PIL.
     */
    fun drawBitmap(bitmap: android.graphics.Bitmap, threshold: Int = 128) {
        val scaled = if (bitmap.width != width || bitmap.height != height) {
            android.graphics.Bitmap.createScaledBitmap(bitmap, width, height, true)
        } else {
            bitmap
        }
        for (y in 0 until height) {
            for (x in 0 until width) {
                val pixel = scaled.getPixel(x, y)
                val r = (pixel shr 16) and 0xFF
                val g = (pixel shr 8) and 0xFF
                val b = pixel and 0xFF
                val luminance = (r * 299 + g * 587 + b * 114) / 1000
                setPixel(x, y, luminance >= threshold)
            }
        }
        if (scaled !== bitmap) scaled.recycle()
    }

    /** Sends the whole framebuffer to the panel's GDDRAM. */
    fun flush(): Boolean {
        if (!cmd(0x21, 0, width - 1)) return false // column address range
        if (!cmd(0x22, 0, pages - 1)) return false // page address range
        return i2c.writeRaw(address7, byteArrayOf(0x40.toByte()) + fb)
    }

    companion object {
        const val DEFAULT_ADDRESS = 0x3C

        /** 5 column bytes per glyph, bit0 = top row .. bit6 = bottom row of a 5x7 cell. */
        private val FONT_5X7: Map<Char, IntArray> = mapOf(
            ' ' to intArrayOf(0x00, 0x00, 0x00, 0x00, 0x00),
            '!' to intArrayOf(0x00, 0x00, 0x5F, 0x00, 0x00),
            '.' to intArrayOf(0x00, 0x60, 0x60, 0x00, 0x00),
            ',' to intArrayOf(0x00, 0x40, 0x30, 0x10, 0x00),
            ':' to intArrayOf(0x00, 0x36, 0x36, 0x00, 0x00),
            '%' to intArrayOf(0x43, 0x33, 0x08, 0x66, 0x61),
            '/' to intArrayOf(0x40, 0x30, 0x08, 0x06, 0x01),
            '-' to intArrayOf(0x08, 0x08, 0x08, 0x08, 0x08),
            '?' to intArrayOf(0x02, 0x01, 0x51, 0x09, 0x06),
            '0' to intArrayOf(0x3E, 0x51, 0x49, 0x45, 0x3E),
            '1' to intArrayOf(0x00, 0x42, 0x7F, 0x40, 0x00),
            '2' to intArrayOf(0x42, 0x61, 0x51, 0x49, 0x46),
            '3' to intArrayOf(0x21, 0x41, 0x45, 0x4B, 0x31),
            '4' to intArrayOf(0x18, 0x14, 0x12, 0x7F, 0x10),
            '5' to intArrayOf(0x27, 0x45, 0x45, 0x45, 0x39),
            '6' to intArrayOf(0x3E, 0x49, 0x49, 0x49, 0x30),
            '7' to intArrayOf(0x01, 0x71, 0x09, 0x05, 0x03),
            '8' to intArrayOf(0x36, 0x49, 0x49, 0x49, 0x36),
            '9' to intArrayOf(0x06, 0x49, 0x49, 0x49, 0x3E),
            'A' to intArrayOf(0x7E, 0x09, 0x09, 0x09, 0x7E),
            'B' to intArrayOf(0x7F, 0x49, 0x49, 0x49, 0x36),
            'C' to intArrayOf(0x3E, 0x41, 0x41, 0x41, 0x22),
            'D' to intArrayOf(0x7F, 0x41, 0x41, 0x41, 0x3E),
            'E' to intArrayOf(0x7F, 0x49, 0x49, 0x49, 0x41),
            'F' to intArrayOf(0x7F, 0x09, 0x09, 0x09, 0x01),
            'G' to intArrayOf(0x3E, 0x41, 0x49, 0x49, 0x7A),
            'H' to intArrayOf(0x7F, 0x08, 0x08, 0x08, 0x7F),
            'I' to intArrayOf(0x00, 0x41, 0x7F, 0x41, 0x00),
            'J' to intArrayOf(0x30, 0x40, 0x40, 0x40, 0x3F),
            'K' to intArrayOf(0x7F, 0x08, 0x14, 0x22, 0x41),
            'L' to intArrayOf(0x7F, 0x40, 0x40, 0x40, 0x40),
            'M' to intArrayOf(0x7F, 0x02, 0x0C, 0x02, 0x7F),
            'N' to intArrayOf(0x7F, 0x02, 0x04, 0x08, 0x7F),
            'O' to intArrayOf(0x3E, 0x41, 0x41, 0x41, 0x3E),
            'P' to intArrayOf(0x7F, 0x09, 0x09, 0x09, 0x06),
            'Q' to intArrayOf(0x3E, 0x41, 0x51, 0x21, 0x5E),
            'R' to intArrayOf(0x7F, 0x09, 0x19, 0x29, 0x46),
            'S' to intArrayOf(0x46, 0x49, 0x49, 0x49, 0x31),
            'T' to intArrayOf(0x01, 0x01, 0x7F, 0x01, 0x01),
            'U' to intArrayOf(0x3F, 0x40, 0x40, 0x40, 0x3F),
            'V' to intArrayOf(0x1F, 0x20, 0x40, 0x20, 0x1F),
            'W' to intArrayOf(0x7F, 0x20, 0x18, 0x20, 0x7F),
            'X' to intArrayOf(0x63, 0x14, 0x08, 0x14, 0x63),
            'Y' to intArrayOf(0x03, 0x04, 0x78, 0x04, 0x03),
            'Z' to intArrayOf(0x61, 0x51, 0x49, 0x45, 0x43)
        )
    }
}
