package com.tcpuartbridge.app.display

import com.tcpuartbridge.app.ch341.Ch341I2c

/**
 * Driver for SSD1306-based I2C OLED panels (128x64, 128x32, and 96x16 - the common "0.96 inch" /
 * "0.91 inch" / "0.69 inch" modules), talking over a [Ch341I2c] bus via the CH341A. The init
 * sequence and command set are the standard ones from Solomon Systech's SSD1306 datasheet
 * (identical across every SSD1306 library, and cross-checked here command-by-command against the
 * classic ioctl/SMBus-based Python reference driver this was ported from - the init order/values,
 * clear(), and framebuffer bit-packing all already matched that reference exactly); the 5x7 text
 * font below is this file's own, generated from scratch (see `gen_font.py` design notes in the
 * repo) rather than copied from any particular library.
 *
 * I2C framing: every write is a `[control byte, payload bytes...]` pair with no register
 * address - control byte 0x00 means "payload is command bytes", 0x40 means "payload is
 * display-RAM data". This class keeps an in-memory framebuffer ([fb]) and only touches the
 * display when [flush] is called, so callers can draw several things before paying for the I2C
 * traffic - [init] is the one exception, since it also flushes a blanked buffer so the panel
 * starts from a clean screen instead of showing stale/power-on GDDRAM noise until the caller's
 * next draw.
 *
 * Pass [externalVcc] = true only if your module's datasheet explicitly calls for an external
 * charge-pump supply - the vast majority of these boards (anything without a dedicated VCC pin
 * note) use the internal charge pump, which is the default here and in the Python reference.
 */
class Ssd1306(
    private val i2c: Ch341I2c,
    private val address7: Int = DEFAULT_ADDRESS,
    val width: Int = 128,
    val height: Int = 64,
    private val externalVcc: Boolean = false
) {
    private val pages = height / 8
    val fb = ByteArray(width * pages)

    private fun cmd(vararg bytes: Int): Boolean =
        i2c.writeRaw(address7, byteArrayOf(0x00.toByte()) + bytes.map { it.toByte() }.toByteArray())

    /** Contrast value for this panel's size/VCC combination - shared by [init] and [setDim]. */
    private fun normalContrast(): Int = when {
        height <= 32 -> 0x8F
        externalVcc -> 0x9F
        else -> 0xCF
    }

    /**
     * Runs the standard SSD1306 power-on init sequence, then blanks and flushes the display so
     * it starts from a clean screen rather than whatever was left in GDDRAM. Call once before
     * drawing anything.
     */
    fun init(): Boolean {
        // 128x32 and 96x16 modules commonly ship with different COM-pin/contrast/clock-divide
        // defaults than 128x64 ones - matches known-good reference init sequences for all three.
        val comPins = if (height <= 32) 0x02 else 0x12
        val clockDiv = if (height <= 16) 0x60 else 0x80
        val chargePump = if (externalVcc) 0x10 else 0x14
        val precharge = if (externalVcc) 0x22 else 0xF1
        val ok = cmd(0xAE) && // display off
            cmd(0xD5, clockDiv) && // clock divide
            cmd(0xA8, height - 1) && // multiplex ratio
            cmd(0xD3, 0x00) && // display offset
            cmd(0x40) && // start line = 0
            cmd(0x8D, chargePump) && // charge pump
            cmd(0x20, 0x00) && // horizontal addressing mode
            cmd(0xA1) && // segment remap
            cmd(0xC8) && // COM scan direction, remapped
            cmd(0xDA, comPins) &&
            cmd(0x81, normalContrast()) &&
            cmd(0xD9, precharge) &&
            cmd(0xDB, 0x40) && // VCOMH deselect level
            cmd(0xA4) && // resume RAM content display
            cmd(0xA6) && // normal (not inverted)
            cmd(0xAF)   // display on
        clear()
        return ok && flush()
    }

    fun setContrast(value: Int): Boolean = cmd(0x81, value and 0xFF)

    /** Dims the display to minimum contrast if [dim] is true, or restores this panel's normal
     * contrast if false - mirrors the classic Python driver's dim(). */
    fun setDim(dim: Boolean): Boolean = cmd(0x81, if (dim) 0x00 else normalContrast())

    fun setInverted(inverted: Boolean): Boolean = cmd(if (inverted) 0xA7 else 0xA6)

    fun setDisplayOn(on: Boolean): Boolean = cmd(if (on) 0xAF else 0xAE)

    fun clear() = fb.fill(0.toByte())

    fun setPixel(x: Int, y: Int, on: Boolean) {
        if (x !in 0 until width || y !in 0 until height) return
        val idx = x + (y / 8) * width
        val bit = 1 shl (y % 8)
        fb[idx] = if (on) (fb[idx].toInt() or bit).toByte() else (fb[idx].toInt() and bit.inv()).toByte()
    }

    /**
     * Word-wraps [text] to fit within [maxWidthPx] at [charAdvance] px/character, honoring
     * explicit '\n' line breaks. A single word longer than one line is hard-broken rather than
     * overflowing. Pure layout helper for [drawText] - has no display side effects of its own.
     */
    private fun wrapLines(text: String, maxWidthPx: Int, charAdvance: Int): List<String> {
        val maxChars = maxOf(1, maxWidthPx / charAdvance)
        val lines = mutableListOf<String>()
        for (paragraph in text.split("\n")) {
            var current = StringBuilder()
            for (word in paragraph.split(" ")) {
                if (word.length > maxChars) {
                    if (current.isNotEmpty()) {
                        lines.add(current.toString())
                        current = StringBuilder()
                    }
                    var remaining = word
                    while (remaining.length > maxChars) {
                        lines.add(remaining.substring(0, maxChars))
                        remaining = remaining.substring(maxChars)
                    }
                    current.append(remaining)
                    continue
                }
                val candidateLength = if (current.isEmpty()) word.length else current.length + 1 + word.length
                if (candidateLength > maxChars) {
                    lines.add(current.toString())
                    current = StringBuilder(word)
                } else {
                    if (current.isNotEmpty()) current.append(' ')
                    current.append(word)
                }
            }
            lines.add(current.toString())
        }
        return lines
    }

    /**
     * Draws 5x7 text with 1px spacing between glyphs (6px advance per character) and 8px line
     * height, top-left at ([x], [y]). Word-wraps to stay within the panel width and honors
     * explicit '\n' line breaks; unknown characters (and anything past the bottom edge) fall
     * back to blank, same as any other out-of-bounds draw - see [setPixel]. Letters are matched
     * case-insensitively (the font only has uppercase glyphs).
     */
    fun drawText(x: Int, y: Int, text: String) {
        val charAdvance = 6
        val lineHeight = 8
        val maxWidthPx = maxOf(charAdvance, width - x)
        var cy = y
        for (line in wrapLines(text.uppercase(), maxWidthPx, charAdvance)) {
            var cx = x
            for (ch in line) {
                val glyph = FONT_5X7[ch] ?: FONT_5X7[' ']!!
                for (col in 0 until 5) {
                    val bits = glyph[col]
                    for (row in 0 until 7) {
                        if ((bits shr row) and 1 == 1) setPixel(cx + col, cy + row, true)
                    }
                }
                cx += charAdvance
            }
            cy += lineHeight
        }
    }

    /** Fills the framebuffer with a coarse checkerboard - useful as a hardware sanity check. */
    fun testPattern() {
        for (y in 0 until height) {
            for (x in 0 until width) {
                setPixel(x, y, ((x / 4) + (y / 4)) % 2 == 0)
            }
        }
    }

    /**
     * Sets the framebuffer from [bitmap] (scaled to the panel's resolution first if it isn't
     * already that size). When [dither] is true (the default), applies Floyd-Steinberg error
     * diffusion while thresholding against [threshold] (0-255, ITU-R BT.601 luminance weights) -
     * the same algorithm and luminance weights PIL's `Image.convert('1')` uses by default, so
     * this matches what the classic Python driver's example (open an image, `.convert('1')`,
     * then display()) actually puts on screen, instead of the harsher look of a flat per-pixel
     * threshold. Pass `dither = false` for line art / already-1-bit images, where dithering just
     * adds noise.
     */
    fun drawBitmap(bitmap: android.graphics.Bitmap, threshold: Int = 128, dither: Boolean = true) {
        val scaled = if (bitmap.width != width || bitmap.height != height) {
            android.graphics.Bitmap.createScaledBitmap(bitmap, width, height, true)
        } else {
            bitmap
        }
        if (dither) {
            val lum = FloatArray(width * height)
            for (y in 0 until height) {
                for (x in 0 until width) {
                    val pixel = scaled.getPixel(x, y)
                    val r = (pixel shr 16) and 0xFF
                    val g = (pixel shr 8) and 0xFF
                    val b = pixel and 0xFF
                    lum[y * width + x] = (r * 299 + g * 587 + b * 114) / 1000f
                }
            }
            for (y in 0 until height) {
                for (x in 0 until width) {
                    val idx = y * width + x
                    val old = lum[idx]
                    val on = old >= threshold
                    setPixel(x, y, on)
                    val error = old - (if (on) 255f else 0f)
                    if (x + 1 < width) lum[idx + 1] += error * 7f / 16f
                    if (y + 1 < height) {
                        if (x > 0) lum[idx + width - 1] += error * 3f / 16f
                        lum[idx + width] += error * 5f / 16f
                        if (x + 1 < width) lum[idx + width + 1] += error * 1f / 16f
                    }
                }
            }
        } else {
            for (y in 0 until height) {
                for (x in 0 until width) {
                    val pixel = scaled.getPixel(x, y)
                    val r = (pixel shr 16) and 0xFF
                    val g = (pixel shr 8) and 0xFF
                    val b = pixel and 0xFF
                    val luminance = (r * 299 + g * 587 + b * 114) / 1000
                    setPixel(x, y, luminance >= threshold)
                }
            }
        }
        if (scaled !== bitmap) scaled.recycle()
    }

    /** Sends the whole framebuffer to the panel's GDDRAM. */
    fun flush(): Boolean {
        if (!cmd(0x21, 0, width - 1)) return false // column address range
        if (!cmd(0x22, 0, pages - 1)) return false // page address range
        return i2c.writeRaw(address7, byteArrayOf(0x40.toByte()) + fb)
    }

    companion object {
        const val DEFAULT_ADDRESS = 0x3C

        /** 5 column bytes per glyph, bit0 = top row .. bit6 = bottom row of a 5x7 cell. */
        private val FONT_5X7: Map<Char, IntArray> = mapOf(
            ' ' to intArrayOf(0x00, 0x00, 0x00, 0x00, 0x00),
            '!' to intArrayOf(0x00, 0x00, 0x5F, 0x00, 0x00),
            '"' to intArrayOf(0x03, 0x00, 0x03, 0x00, 0x00),
            '\'' to intArrayOf(0x00, 0x03, 0x00, 0x00, 0x00),
            '(' to intArrayOf(0x00, 0x3E, 0x41, 0x00, 0x00),
            ')' to intArrayOf(0x00, 0x00, 0x41, 0x3E, 0x00),
            '*' to intArrayOf(0x22, 0x14, 0x08, 0x14, 0x22),
            '+' to intArrayOf(0x08, 0x08, 0x7F, 0x08, 0x08),
            '.' to intArrayOf(0x00, 0x60, 0x60, 0x00, 0x00),
            ',' to intArrayOf(0x00, 0x40, 0x30, 0x10, 0x00),
            '-' to intArrayOf(0x08, 0x08, 0x08, 0x08, 0x08),
            '/' to intArrayOf(0x40, 0x30, 0x08, 0x06, 0x01),
            ':' to intArrayOf(0x00, 0x36, 0x36, 0x00, 0x00),
            '<' to intArrayOf(0x00, 0x08, 0x14, 0x22, 0x41),
            '=' to intArrayOf(0x14, 0x14, 0x14, 0x14, 0x14),
            '>' to intArrayOf(0x41, 0x22, 0x14, 0x08, 0x00),
            '?' to intArrayOf(0x02, 0x01, 0x51, 0x09, 0x06),
            '_' to intArrayOf(0x40, 0x40, 0x40, 0x40, 0x40),
            '%' to intArrayOf(0x43, 0x33, 0x08, 0x66, 0x61),
            '0' to intArrayOf(0x3E, 0x51, 0x49, 0x45, 0x3E),
            '1' to intArrayOf(0x00, 0x42, 0x7F, 0x40, 0x00),
            '2' to intArrayOf(0x42, 0x61, 0x51, 0x49, 0x46),
            '3' to intArrayOf(0x21, 0x41, 0x45, 0x4B, 0x31),
            '4' to intArrayOf(0x18, 0x14, 0x12, 0x7F, 0x10),
            '5' to intArrayOf(0x27, 0x45, 0x45, 0x45, 0x39),
            '6' to intArrayOf(0x3E, 0x49, 0x49, 0x49, 0x30),
            '7' to intArrayOf(0x01, 0x71, 0x09, 0x05, 0x03),
            '8' to intArrayOf(0x36, 0x49, 0x49, 0x49, 0x36),
            '9' to intArrayOf(0x06, 0x49, 0x49, 0x49, 0x3E),
            'A' to intArrayOf(0x7E, 0x09, 0x09, 0x09, 0x7E),
            'B' to intArrayOf(0x7F, 0x49, 0x49, 0x49, 0x36),
            'C' to intArrayOf(0x3E, 0x41, 0x41, 0x41, 0x22),
            'D' to intArrayOf(0x7F, 0x41, 0x41, 0x41, 0x3E),
            'E' to intArrayOf(0x7F, 0x49, 0x49, 0x49, 0x41),
            'F' to intArrayOf(0x7F, 0x09, 0x09, 0x09, 0x01),
            'G' to intArrayOf(0x3E, 0x41, 0x49, 0x49, 0x7A),
            'H' to intArrayOf(0x7F, 0x08, 0x08, 0x08, 0x7F),
            'I' to intArrayOf(0x00, 0x41, 0x7F, 0x41, 0x00),
            'J' to intArrayOf(0x30, 0x40, 0x40, 0x40, 0x3F),
            'K' to intArrayOf(0x7F, 0x08, 0x14, 0x22, 0x41),
            'L' to intArrayOf(0x7F, 0x40, 0x40, 0x40, 0x40),
            'M' to intArrayOf(0x7F, 0x02, 0x0C, 0x02, 0x7F),
            'N' to intArrayOf(0x7F, 0x02, 0x04, 0x08, 0x7F),
            'O' to intArrayOf(0x3E, 0x41, 0x41, 0x41, 0x3E),
            'P' to intArrayOf(0x7F, 0x09, 0x09, 0x09, 0x06),
            'Q' to intArrayOf(0x3E, 0x41, 0x51, 0x21, 0x5E),
            'R' to intArrayOf(0x7F, 0x09, 0x19, 0x29, 0x46),
            'S' to intArrayOf(0x46, 0x49, 0x49, 0x49, 0x31),
            'T' to intArrayOf(0x01, 0x01, 0x7F, 0x01, 0x01),
            'U' to intArrayOf(0x3F, 0x40, 0x40, 0x40, 0x3F),
            'V' to intArrayOf(0x1F, 0x20, 0x40, 0x20, 0x1F),
            'W' to intArrayOf(0x7F, 0x20, 0x18, 0x20, 0x7F),
            'X' to intArrayOf(0x63, 0x14, 0x08, 0x14, 0x63),
            'Y' to intArrayOf(0x03, 0x04, 0x78, 0x04, 0x03),
            'Z' to intArrayOf(0x61, 0x51, 0x49, 0x45, 0x43)
        )
    }
}
