package com.tcpuartbridge.app.display

import com.tcpuartbridge.app.ch341.Ch341I2c

/**
 * Driver for SSD1306-based I2C OLED panels (the common 128x64 / 128x32 "0.96 inch" / "0.91 inch"
 * modules, plus 96x16), talking over a [Ch341I2c] bus via the CH341A. The init sequence and
 * command set are the standard ones from Solomon Systech's SSD1306 datasheet and match the
 * `smbus_ssd1306.py` reference this class was checked against, byte-for-byte, across all three
 * of that file's documented panel sizes; the 5x7 text font below is this file's own, generated
 * from scratch rather than copied from any particular library.
 *
 * I2C framing: every write is a `[control byte, payload bytes...]` pair with no register
 * address - control byte 0x00 means "payload is command bytes", 0x40 means "payload is
 * display-RAM data". This class keeps an in-memory framebuffer ([fb]) and only touches the
 * display when [flush] is called (or [clear] is asked to push immediately), so callers can draw
 * several things before paying for the I2C traffic.
 */
class Ssd1306(
    private val i2c: Ch341I2c,
    private val address7: Int = DEFAULT_ADDRESS,
    val width: Int = 128,
    val height: Int = 64
) {
    private val pages = height / 8
    val fb = ByteArray(width * pages)

    private fun cmd(vararg bytes: Int): Boolean =
        i2c.writeRaw(address7, byteArrayOf(0x00.toByte()) + bytes.map { it.toByte() }.toByteArray())

    /**
     * Runs the standard SSD1306 power-on init sequence and leaves the panel showing a blank
     * (all-off) screen. Call once before drawing anything.
     *
     * A freshly power-on SSD1306's GDDRAM content is undefined, so the init command sequence
     * alone does not guarantee a blank screen - only that the panel is configured and on. This
     * pushes a cleared framebuffer as the last step so callers never see a screen full of noise
     * right after "successfully" initializing; that push's success is folded into the return
     * value, so a wiring problem that only shows up on the data write (not the command writes)
     * still reports as an init failure rather than a false "OK".
     */
    fun init(): Boolean {
        // 128x32 and 96x16 modules commonly ship with different COM-pin and contrast defaults
        // than 128x64 ones. 96x16 also uses a different clock-divide ratio. These three
        // combinations match the reference `smbus_ssd1306.py`'s SSD1306_128_64 / SSD1306_128_32
        // / SSD1306_96_16 classes exactly; any other (width, height) falls back to whichever of
        // the two COM-pin/contrast pairs its height is closer to, and the standard 0x80 clock
        // divide, which is correct for the overwhelming majority of other SSD1306 modules too.
        val clockDiv = if (width == 96 && height == 16) 0x60 else 0x80
        val comPins = if (height <= 32) 0x02 else 0x12
        val contrast = if (height <= 32) 0x8F else 0xCF
        val commandsOk = cmd(0xAE) && // display off
            cmd(0xD5, clockDiv) && // clock divide
            cmd(0xA8, height - 1) && // multiplex ratio
            cmd(0xD3, 0x00) && // display offset
            cmd(0x40) && // start line = 0
            cmd(0x8D, 0x14) && // charge pump on (internal Vcc)
            cmd(0x20, 0x00) && // horizontal addressing mode
            cmd(0xA1) && // segment remap
            cmd(0xC8) && // COM scan direction, remapped
            cmd(0xDA, comPins) &&
            cmd(0x81, contrast) &&
            cmd(0xD9, 0xF1) && // pre-charge
            cmd(0xDB, 0x40) && // VCOMH deselect level
            cmd(0xA4) && // resume RAM content display
            cmd(0xA6) && // normal (not inverted)
            cmd(0xAF)   // display on
        val blankOk = clear(push = true)
        return commandsOk && blankOk
    }

    fun setContrast(value: Int): Boolean = cmd(0x81, value and 0xFF)

    fun setInverted(inverted: Boolean): Boolean = cmd(if (inverted) 0xA7 else 0xA6)

    fun setDisplayOn(on: Boolean): Boolean = cmd(if (on) 0xAF else 0xAE)

    /**
     * Blanks the in-memory framebuffer. Matches the Python reference's `clear()`: by default this
     * touches only local memory, so the panel itself keeps showing whatever was last flushed
     * until you call [flush] yourself - pass [push] = true to flush the blank frame immediately
     * instead and get the combined result back.
     */
    fun clear(push: Boolean = false): Boolean {
        fb.fill(0.toByte())
        return if (push) flush() else true
    }

    fun setPixel(x: Int, y: Int, on: Boolean) {
        if (x !in 0 until width || y !in 0 until height) return
        val idx = x + (y / 8) * width
        val bit = 1 shl (y % 8)
        fb[idx] = if (on) (fb[idx].toInt() or bit).toByte() else (fb[idx].toInt() and bit.inv()).toByte()
    }

    /** Draws a straight line from ([x0], [y0]) to ([x1], [y1]) (Bresenham stepping). */
    fun drawLine(x0: Int, y0: Int, x1: Int, y1: Int) {
        var x = x0
        var y = y0
        val dx = kotlin.math.abs(x1 - x0)
        val dy = -kotlin.math.abs(y1 - y0)
        val sx = if (x0 < x1) 1 else -1
        val sy = if (y0 < y1) 1 else -1
        var err = dx + dy
        while (true) {
            setPixel(x, y, true)
            if (x == x1 && y == y1) break
            val e2 = 2 * err
            if (e2 >= dy) { err += dy; x += sx }
            if (e2 <= dx) { err += dx; y += sy }
        }
    }

    /** Draws the outline of a [w]x[h] rectangle with its top-left corner at ([x], [y]). */
    fun drawRect(x: Int, y: Int, w: Int, h: Int) {
        if (w <= 0 || h <= 0) return
        for (i in 0 until w) {
            setPixel(x + i, y, true)
            setPixel(x + i, y + h - 1, true)
        }
        for (j in 0 until h) {
            setPixel(x, y + j, true)
            setPixel(x + w - 1, y + j, true)
        }
    }

    /** Draws a filled [w]x[h] rectangle with its top-left corner at ([x], [y]). */
    fun fillRect(x: Int, y: Int, w: Int, h: Int) {
        for (j in 0 until h) {
            for (i in 0 until w) {
                setPixel(x + i, y + j, true)
            }
        }
    }

    /**
     * Draws 5x7 text with 1px spacing between glyphs (6px advance per character), top-left of
     * the first glyph at ([x], [y]). Only uppercase letters, digits, and a modest set of
     * punctuation are defined in [FONT_5X7] (lowercase is folded to uppercase first); anything
     * else falls back to a blank space so column alignment is preserved rather than characters
     * silently disappearing mid-string. An explicit `'\n'` in [text] starts a new line at
     * `x, y + lineHeight` instead of being looked up in the font. This does not wrap - see
     * [drawTextWrapped] for text that should fit the panel's width automatically.
     */
    fun drawText(x: Int, y: Int, text: String, lineHeight: Int = 8) {
        var cx = x
        var cy = y
        for (ch in text.uppercase()) {
            if (ch == '\n') {
                cx = x
                cy += lineHeight
                continue
            }
            val glyph = FONT_5X7[ch] ?: FONT_5X7[' ']!!
            for (col in 0 until 5) {
                val bits = glyph[col]
                for (row in 0 until 7) {
                    if ((bits shr row) and 1 == 1) setPixel(cx + col, cy + row, true)
                }
            }
            cx += 6
        }
    }

    /**
     * Draws [text] word-wrapped to fit the panel's width (a single "word" wider than the panel
     * is hard-broken rather than left overflowing), 8px per line by default, starting at
     * ([x], [y]). Existing `'\n'` characters in [text] force a paragraph break in addition to
     * the automatic wrapping. Lines that would start at or past the panel's bottom edge are
     * skipped rather than drawn off-screen or wrapped back around to the top.
     */
    fun drawTextWrapped(x: Int, y: Int, text: String, lineHeight: Int = 8) {
        val charWidth = 6
        val maxChars = maxOf(1, (width - x) / charWidth)
        var cy = y

        fun emit(line: String) {
            if (cy + 7 <= height) drawText(x, cy, line)
            cy += lineHeight
        }

        for (paragraph in text.split('\n')) {
            var line = ""
            for (rawWord in paragraph.split(' ')) {
                var word = rawWord
                while (word.length > maxChars) {
                    if (line.isNotEmpty()) {
                        emit(line)
                        line = ""
                    }
                    emit(word.substring(0, maxChars))
                    word = word.substring(maxChars)
                }
                val candidate = if (line.isEmpty()) word else "$line $word"
                if (candidate.length > maxChars) {
                    emit(line)
                    line = word
                } else {
                    line = candidate
                }
            }
            emit(line)
        }
    }

    /** Fills the framebuffer with a coarse checkerboard - useful as a hardware sanity check. */
    fun testPattern() {
        for (y in 0 until height) {
            for (x in 0 until width) {
                setPixel(x, y, ((x / 4) + (y / 4)) % 2 == 0)
            }
        }
    }

    /**
     * Sets the framebuffer from [bitmap] (scaled to the panel's resolution first if it isn't
     * already that size), thresholding each pixel's luminance against [threshold] (0-255,
     * ITU-R BT.601 weights). Mirrors the classic Python SSD1306 driver's `image()` method -
     * convert to 1-bit and copy pixel-by-pixel - just done with Android's own Bitmap APIs
     * instead of PIL.
     *
     * Alpha is composited onto black before thresholding, so transparent/semi-transparent
     * pixels (e.g. a PNG logo with a transparent background) count as dark instead of picking up
     * whatever incidental RGB values happen to be stored under a zero alpha channel - Android's
     * `getPixel()` returns those untouched, and some image editors leave non-black "garbage"
     * there for smoother downscaling, which would otherwise show up as unwanted noise once
     * thresholded.
     */
    fun drawBitmap(bitmap: android.graphics.Bitmap, threshold: Int = 128) {
        val scaled = if (bitmap.width != width || bitmap.height != height) {
            android.graphics.Bitmap.createScaledBitmap(bitmap, width, height, true)
        } else {
            bitmap
        }
        for (y in 0 until height) {
            for (x in 0 until width) {
                val pixel = scaled.getPixel(x, y)
                val a = (pixel ushr 24) and 0xFF
                val r = (pixel shr 16) and 0xFF
                val g = (pixel shr 8) and 0xFF
                val b = pixel and 0xFF
                val luminance = (r * 299 + g * 587 + b * 114) / 1000 * a / 255
                setPixel(x, y, luminance >= threshold)
            }
        }
        if (scaled !== bitmap) scaled.recycle()
    }

    /** Sends the whole framebuffer to the panel's GDDRAM. */
    fun flush(): Boolean {
        if (!cmd(0x21, 0, width - 1)) return false // column address range
        if (!cmd(0x22, 0, pages - 1)) return false // page address range
        return i2c.writeRaw(address7, byteArrayOf(0x40.toByte()) + fb)
    }

    companion object {
        const val DEFAULT_ADDRESS = 0x3C

        /** 5 column bytes per glyph, bit0 = top row .. bit6 = bottom row of a 5x7 cell. */
        private val FONT_5X7: Map<Char, IntArray> = mapOf(
            ' ' to intArrayOf(0x00, 0x00, 0x00, 0x00, 0x00),
            '!' to intArrayOf(0x00, 0x00, 0x5F, 0x00, 0x00),
            '"' to intArrayOf(0x00, 0x03, 0x00, 0x03, 0x00),
            '%' to intArrayOf(0x43, 0x33, 0x08, 0x66, 0x61),
            '\'' to intArrayOf(0x00, 0x00, 0x03, 0x00, 0x00),
            '(' to intArrayOf(0x1C, 0x22, 0x41, 0x00, 0x00),
            ')' to intArrayOf(0x00, 0x00, 0x41, 0x22, 0x1C),
            '+' to intArrayOf(0x00, 0x08, 0x3E, 0x08, 0x00),
            ',' to intArrayOf(0x00, 0x40, 0x30, 0x10, 0x00),
            '-' to intArrayOf(0x08, 0x08, 0x08, 0x08, 0x08),
            '.' to intArrayOf(0x00, 0x60, 0x60, 0x00, 0x00),
            '/' to intArrayOf(0x40, 0x30, 0x08, 0x06, 0x01),
            '0' to intArrayOf(0x3E, 0x51, 0x49, 0x45, 0x3E),
            '1' to intArrayOf(0x00, 0x42, 0x7F, 0x40, 0x00),
            '2' to intArrayOf(0x42, 0x61, 0x51, 0x49, 0x46),
            '3' to intArrayOf(0x21, 0x41, 0x45, 0x4B, 0x31),
            '4' to intArrayOf(0x18, 0x14, 0x12, 0x7F, 0x10),
            '5' to intArrayOf(0x27, 0x45, 0x45, 0x45, 0x39),
            '6' to intArrayOf(0x3E, 0x49, 0x49, 0x49, 0x30),
            '7' to intArrayOf(0x01, 0x71, 0x09, 0x05, 0x03),
            '8' to intArrayOf(0x36, 0x49, 0x49, 0x49, 0x36),
            '9' to intArrayOf(0x06, 0x49, 0x49, 0x49, 0x3E),
            ':' to intArrayOf(0x00, 0x36, 0x36, 0x00, 0x00),
            ';' to intArrayOf(0x00, 0x46, 0x36, 0x10, 0x00),
            '<' to intArrayOf(0x00, 0x08, 0x14, 0x22, 0x41),
            '=' to intArrayOf(0x14, 0x14, 0x14, 0x14, 0x14),
            '>' to intArrayOf(0x41, 0x22, 0x14, 0x08, 0x00),
            '?' to intArrayOf(0x02, 0x01, 0x51, 0x09, 0x06),
            'A' to intArrayOf(0x7E, 0x09, 0x09, 0x09, 0x7E),
            'B' to intArrayOf(0x7F, 0x49, 0x49, 0x49, 0x36),
            'C' to intArrayOf(0x3E, 0x41, 0x41, 0x41, 0x22),
            'D' to intArrayOf(0x7F, 0x41, 0x41, 0x41, 0x3E),
            'E' to intArrayOf(0x7F, 0x49, 0x49, 0x49, 0x41),
            'F' to intArrayOf(0x7F, 0x09, 0x09, 0x09, 0x01),
            'G' to intArrayOf(0x3E, 0x41, 0x49, 0x49, 0x7A),
            'H' to intArrayOf(0x7F, 0x08, 0x08, 0x08, 0x7F),
            'I' to intArrayOf(0x00, 0x41, 0x7F, 0x41, 0x00),
            'J' to intArrayOf(0x30, 0x40, 0x40, 0x40, 0x3F),
            'K' to intArrayOf(0x7F, 0x08, 0x14, 0x22, 0x41),
            'L' to intArrayOf(0x7F, 0x40, 0x40, 0x40, 0x40),
            'M' to intArrayOf(0x7F, 0x02, 0x0C, 0x02, 0x7F),
            'N' to intArrayOf(0x7F, 0x02, 0x04, 0x08, 0x7F),
            'O' to intArrayOf(0x3E, 0x41, 0x41, 0x41, 0x3E),
            'P' to intArrayOf(0x7F, 0x09, 0x09, 0x09, 0x06),
            'Q' to intArrayOf(0x3E, 0x41, 0x51, 0x21, 0x5E),
            'R' to intArrayOf(0x7F, 0x09, 0x19, 0x29, 0x46),
            'S' to intArrayOf(0x46, 0x49, 0x49, 0x49, 0x31),
            'T' to intArrayOf(0x01, 0x01, 0x7F, 0x01, 0x01),
            'U' to intArrayOf(0x3F, 0x40, 0x40, 0x40, 0x3F),
            'V' to intArrayOf(0x1F, 0x20, 0x40, 0x20, 0x1F),
            'W' to intArrayOf(0x7F, 0x20, 0x18, 0x20, 0x7F),
            'X' to intArrayOf(0x63, 0x14, 0x08, 0x14, 0x63),
            'Y' to intArrayOf(0x03, 0x04, 0x78, 0x04, 0x03),
            'Z' to intArrayOf(0x61, 0x51, 0x49, 0x45, 0x43),
            '_' to intArrayOf(0x40, 0x40, 0x40, 0x40, 0x40)
        )
    }
}
