package com.tcpuartbridge.app.eeprom

/**
 * SPI NOR flash ("25xx" family) identification for the chip picker and the "Detect Chip" action.
 *
 * The manufacturer-ID table and the exact part names below are extracted from IMSProg's chip
 * database (`IMSProg.Dat`, part of IMSProg 1.8.6, GPLv3 - see NOTICE.md at the repo root).
 * IMSProg ships ~170 "25Q"-family entries; this keeps the full manufacturer-ID table (useful for
 * *any* chip, known or not) plus exact part numbers for the families people actually put under a
 * CH341A clip most often - Winbond W25Q, GigaDevice GD25Q, and EON/XMC's "25QH" series.
 *
 * Anything not in [EXACT_NAMES] still gets identified: the JEDEC convention (third ID byte =
 * log2 of the capacity in bytes) is universal across vendors, so [identify] always returns a
 * size even for a part number this table has never heard of - just with a generic name instead
 * of an exact one.
 */
object SpiFlashDatabase {

    /** [pageSize]/[sectorSize] are the near-universal SPI NOR defaults (256B page, 4KB erase
     *  sector) - virtually every 25xx-family chip regardless of manufacturer uses these, so
     *  there's no need to track them per part number. */
    data class ChipPreset(
        val manufacturer: String,
        val name: String,
        val sizeBytes: Long,
        val pageSize: Int = 256,
        val sectorSize: Int = 4096
    ) {
        override fun toString(): String = name
    }

    /** manufacturer ID byte -> vendor name. Covers every vendor in IMSProg's SPI_FLASH database. */
    private val MANUFACTURERS = mapOf(
        0x01 to "Spansion/Cypress", 0x0B to "XTX", 0x0E to "ACE",
        0x1C to "EON", 0x1F to "Atmel/Adesto", 0x20 to "XMC",
        0x37 to "AMIC", 0x4A to "ExcelSemi", 0x54 to "Dosilicon/Douqi",
        0x5E to "Zbit", 0x62 to "onsemi", 0x68 to "Boya", 0x7F to "Pflash",
        0x85 to "Puya", 0x8C to "ESMT", 0x9D to "ISSI", 0xA1 to "Fudan Micro",
        0xB3 to "Ucundata", 0xBA to "Zetta", 0xBF to "PCT/SST",
        0xC2 to "Macronix", 0xC4 to "Giantec", 0xC8 to "GigaDevice",
        0xD5 to "Nantronix", 0xD8 to "Yuchuang", 0xE0 to "Paragon",
        0xEF to "Winbond", 0xF8 to "Fidelix"
    )

    /** (manufacturer, memoryType, capacityCode) -> exact part name, per IMSProg.Dat. */
    private val EXACT_NAMES: Map<Triple<Int, Int, Int>, String> = buildMap {
        // --- EON EN25QH family ---
        put(Triple(0x1C, 0x70, 0x15), "EN25QH16")
        put(Triple(0x1C, 0x70, 0x16), "EN25QH32B")
        put(Triple(0x1C, 0x70, 0x17), "EN25QH64A")
        put(Triple(0x1C, 0x70, 0x18), "EN25QH128A")
        // --- XMC XM25QH family (two ID generations coexist in the wild) ---
        put(Triple(0x20, 0x40, 0x11), "XM25QH10B")
        put(Triple(0x20, 0x40, 0x12), "XM25QH20B")
        put(Triple(0x20, 0x40, 0x13), "XM25QH40B")
        put(Triple(0x20, 0x40, 0x14), "XM25QH80B")
        put(Triple(0x20, 0x40, 0x15), "XM25QH16C")
        put(Triple(0x20, 0x40, 0x16), "XM25QH32B")
        put(Triple(0x20, 0x40, 0x17), "XM25QH64C")
        put(Triple(0x20, 0x40, 0x18), "XM25QH128C")
        put(Triple(0x20, 0x40, 0x19), "XM25QH256C") // needs 4-byte addressing, see SpiFlash.use4ByteAddr
        put(Triple(0x20, 0x40, 0x20), "XM25QH512C") // needs 4-byte addressing
        put(Triple(0x20, 0x70, 0x16), "XM25QH32A")
        put(Triple(0x20, 0x70, 0x17), "XM25QH64A")
        put(Triple(0x20, 0x70, 0x18), "XM25QH128A")
        // --- Winbond W25Q family (the most common chip on cheap boards) ---
        put(Triple(0xEF, 0x40, 0x15), "W25Q16DV")
        put(Triple(0xEF, 0x40, 0x16), "W25Q32BV")
        put(Triple(0xEF, 0x40, 0x17), "W25Q64BV")
        put(Triple(0xEF, 0x40, 0x18), "W25Q128BV")
        put(Triple(0xEF, 0x40, 0x19), "W25Q256FV") // needs 4-byte addressing
        // --- GigaDevice GD25Q family ---
        put(Triple(0xC8, 0x40, 0x12), "GD25Q20C")
        put(Triple(0xC8, 0x40, 0x13), "GD25Q40C")
        put(Triple(0xC8, 0x40, 0x14), "GD25Q80C")
        put(Triple(0xC8, 0x40, 0x15), "GD25Q16C")
        put(Triple(0xC8, 0x40, 0x16), "GD25Q32")
        put(Triple(0xC8, 0x40, 0x17), "GD25Q64CSIG")
        put(Triple(0xC8, 0x40, 0x18), "GD25Q128CSIG")
        put(Triple(0xC8, 0x40, 0x19), "GD25Q256CSIG") // needs 4-byte addressing
    }

    /** Chip picker presets - every exact part above, largest-first duplicates collapsed by name. */
    val COMMON_CHIPS: List<ChipPreset> = EXACT_NAMES.entries
        .map { (key, name) -> ChipPreset(MANUFACTURERS[key.first] ?: "Unknown", name, 1L shl key.third) }
        .distinctBy { it.name }
        .sortedWith(compareBy({ it.sizeBytes }, { it.name }))

    /**
     * Identifies a chip from its 3-byte JEDEC ID (manufacturer, memory type, capacity code).
     * Returns null only if the capacity byte isn't a plausible size (i.e. no chip answered, or
     * the read failed and came back all-0x00 / all-0xFF).
     */
    fun identify(manufacturer: Int, memoryType: Int, capacityCode: Int): ChipPreset? {
        if (capacityCode !in 8..30) return null // 256B..1GB is the entire sane range for SPI NOR
        val sizeBytes = 1L shl capacityCode
        val mfgName = MANUFACTURERS[manufacturer] ?: "Unknown mfg 0x%02X".format(manufacturer)
        val exact = EXACT_NAMES[Triple(manufacturer, memoryType, capacityCode)]
        return ChipPreset(mfgName, exact ?: "SPI NOR (generic)", sizeBytes)
    }
}
