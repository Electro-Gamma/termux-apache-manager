package com.tcpuartbridge.app.hexdump

import android.text.InputFilter
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.RecyclerView
import com.tcpuartbridge.app.R

/**
 * Renders [buffer] as a scrollable hex dump - address, 16 hex bytes, ASCII column per row -
 * and lets the user tap any byte to edit it in place, the same read/tweak/write workflow
 * IMSProg's own data table (a QHexEdit widget) supports. Edits mutate [buffer] directly (it's
 * the same array instance the caller holds - typically MainActivity's `lastEepromDump`/
 * `lastSpiDump`), so nothing needs to be copied back; [onByteEdited] just lets the caller show
 * a "buffer modified" hint. Call [setBuffer] when the caller swaps in a different array
 * (after a fresh Read, Load File, Erase, or Random fill).
 */
class HexDumpAdapter(
    private var buffer: ByteArray,
    private val onByteEdited: (index: Int, newValue: Byte) -> Unit
) : RecyclerView.Adapter<HexDumpAdapter.RowHolder>() {

    fun setBuffer(newBuffer: ByteArray) {
        buffer = newBuffer
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int =
        if (buffer.isEmpty()) 0 else (buffer.size + BYTES_PER_ROW - 1) / BYTES_PER_ROW

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowHolder {
        val row = LayoutInflater.from(parent.context).inflate(R.layout.item_hex_row, parent, false)
        return RowHolder(row)
    }

    override fun onBindViewHolder(holder: RowHolder, position: Int) {
        holder.bind(position * BYTES_PER_ROW, buffer, onByteEdited)
    }

    class RowHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvAddr: TextView = itemView.findViewById(R.id.tvHexAddr)
        private val tvAscii: TextView = itemView.findViewById(R.id.tvHexAscii)
        private val byteCells: List<TextView> = listOf(
            R.id.tvHexByte0, R.id.tvHexByte1, R.id.tvHexByte2, R.id.tvHexByte3,
            R.id.tvHexByte4, R.id.tvHexByte5, R.id.tvHexByte6, R.id.tvHexByte7,
            R.id.tvHexByte8, R.id.tvHexByte9, R.id.tvHexByte10, R.id.tvHexByte11,
            R.id.tvHexByte12, R.id.tvHexByte13, R.id.tvHexByte14, R.id.tvHexByte15
        ).map { itemView.findViewById<TextView>(it) }

        fun bind(rowStart: Int, buffer: ByteArray, onByteEdited: (Int, Byte) -> Unit) {
            tvAddr.text = String.format("%06X", rowStart)
            val ascii = StringBuilder(BYTES_PER_ROW)
            for (col in 0 until BYTES_PER_ROW) {
                val idx = rowStart + col
                val cell = byteCells[col]
                if (idx < buffer.size) {
                    val value = buffer[idx].toInt() and 0xFF
                    cell.text = String.format("%02X", value)
                    cell.visibility = View.VISIBLE
                    cell.setOnClickListener { showEditDialog(cell, idx, buffer, onByteEdited) }
                    ascii.append(if (value in 0x20..0x7E) value.toChar() else '.')
                } else {
                    cell.text = ""
                    cell.visibility = View.INVISIBLE
                    cell.setOnClickListener(null)
                    ascii.append(' ')
                }
            }
            tvAscii.text = ascii.toString()
        }

        private fun showEditDialog(
            cell: TextView,
            index: Int,
            buffer: ByteArray,
            onByteEdited: (Int, Byte) -> Unit
        ) {
            val context = cell.context
            val input = EditText(context)
            input.filters = arrayOf(InputFilter.LengthFilter(2))
            input.setText(String.format("%02X", buffer[index].toInt() and 0xFF))
            input.selectAll()
            AlertDialog.Builder(context)
                .setTitle(String.format("Byte at 0x%06X", index))
                .setView(input)
                .setPositiveButton("Set") { _, _ ->
                    val value = input.text.toString().trim().toIntOrNull(16)
                    if (value != null && value in 0..255) {
                        val newByte = value.toByte()
                        buffer[index] = newByte
                        // Re-bind the whole row (cheap - 16 cells) rather than just the tapped
                        // cell, so the ASCII column picks up the change too.
                        val rowStart = index - (index % BYTES_PER_ROW)
                        bind(rowStart, buffer, onByteEdited)
                        onByteEdited(index, newByte)
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    companion object {
        const val BYTES_PER_ROW = 16
    }
}
