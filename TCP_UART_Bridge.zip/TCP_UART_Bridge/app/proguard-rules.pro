# Add project specific ProGuard rules here.
# This app ships a debug build by default (see the build notebook), so these
# rules only matter if you later build a minified release variant.

# usb-serial-for-android uses reflection to enumerate driver classes.
-keep class com.hoho.android.usbserial.** { *; }
