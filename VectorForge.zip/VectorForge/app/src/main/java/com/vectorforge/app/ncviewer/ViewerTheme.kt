package com.vectorforge.app.ncviewer

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.View
import android.webkit.WebSettings
import android.webkit.WebView
import android.widget.TextView
import java.lang.ref.WeakReference

/**
 * Light / Dark styling for the NATIVE parts of the G-Code Viewer: the floating pills (Single/Split view,
 * Post-process, Open file, and every button of the remote control), the divider between the two panes, and the
 * native Replace / Append / Cancel dialogs.
 *
 * Before this existed, each of those hard-coded the same dark look (translucent #CC202124 pill, white text,
 * #3C3F44 divider, light dialog). They now all go through here, so one switch restyles them live.
 *
 *  - Dark: the values that were hard-coded before (pill fill, text, divider), plus a thin grey outline on the pills
 *    (they now sit on a dark page). The dialogs use the Material DARK dialog theme, so they match the dark app.
 *  - Light: a light teal-tinted pill with a thin teal outline and near-black text (clearly visible on the
 *    viewer's light canvas and consistent with the app's light theme), a light divider, light dialogs.
 *
 * The WebViews (the bundled NC Viewer site: G-code editor, toolpath canvas, its toolbars) have no theme of their
 * own: the site is fixed-light (backplot background #F2F2F2). In the dark theme the page is darkened by a CSS
 * filter (see AppAssetHandler.THEME_HOOK) that this class switches on and off through the class "ncv-dark" on the
 * page's <html> element, live, without reloading (so a loaded program and the editor text are untouched).
 * [styleWebView] also pins the platform's own auto-darkening off (Android 10-12), because stacking it on the
 * filter would flip the page back to light.
 *
 * Main-thread only (views are created and restyled on the UI thread). Views are held weakly so a destroyed
 * pane never leaks through this registry.
 */
object ViewerTheme {

    /** Current theme. Set by [setDark]; read when a pill is created or a dialog is shown. */
    @Volatile
    var dark: Boolean = true
        private set

    // -- dark (the original hard-coded values) --
    private val DARK_PILL_BG = Color.argb(204, 32, 33, 36)
    private val DARK_PILL_TEXT = Color.WHITE
    private val DARK_PILL_STROKE = Color.rgb(95, 99, 104) // the dark page behind the pills is near-black, so they need an edge
    private val DARK_DIVIDER = Color.rgb(60, 63, 68)

    // -- light --
    private val LIGHT_PILL_BG = Color.argb(240, 214, 243, 238) // #D6F3EE, a light tint of the light primary (#006B5F)
    private val LIGHT_PILL_TEXT = Color.rgb(0, 32, 28)         // #00201C (the light "on primary container")
    private val LIGHT_PILL_STROKE = Color.rgb(0, 107, 95)      // #006B5F
    private val LIGHT_DIVIDER = Color.rgb(188, 199, 211)       // #BCC7D3

    private class PillRef(val view: WeakReference<TextView>, val cornerPx: Float, val strokePx: Int)

    private val pills = ArrayList<PillRef>()
    private val dividers = ArrayList<WeakReference<View>>()
    private val webViews = ArrayList<WeakReference<WebView>>()

    /** Applies the current theme to [view] (text colour + rounded translucent background) and keeps it up to date. */
    fun stylePill(view: TextView, cornerPx: Float, strokePx: Int) {
        pills.removeAll { it.view.get() == null }
        pills.add(PillRef(WeakReference(view), cornerPx, strokePx))
        applyPill(view, cornerPx, strokePx)
    }

    /** Colours [view] as the divider between the two panes and keeps it up to date. */
    fun styleDivider(view: View) {
        dividers.removeAll { it.get() == null }
        dividers.add(WeakReference(view))
        view.setBackgroundColor(if (dark) DARK_DIVIDER else LIGHT_DIVIDER)
    }

    /** Puts [webView] in step with the theme (see the class comment) now, and again on every theme change. */
    fun styleWebView(webView: WebView) {
        webViews.removeAll { it.get() == null }
        webViews.add(WeakReference(webView))
        applyWebView(webView)
    }

    /** Switches theme and restyles every pill, divider and WebView that is already on screen. */
    fun setDark(isDark: Boolean) {
        if (dark == isDark) return
        dark = isDark
        pills.forEach { ref -> ref.view.get()?.let { applyPill(it, ref.cornerPx, ref.strokePx) } }
        dividers.forEach { ref -> ref.get()?.setBackgroundColor(if (dark) DARK_DIVIDER else LIGHT_DIVIDER) }
        webViews.forEach { ref -> ref.get()?.let { applyWebView(it) } }
    }

    /** Theme for the native AlertDialogs ([FileOpener]'s Replace / Append / Cancel, the site-missing alert). */
    fun dialogTheme(): Int =
        if (dark) android.R.style.Theme_Material_Dialog_Alert else android.R.style.Theme_Material_Light_Dialog_Alert

    // Dark mode is the page filter above, so the platform's own darkening must stay off (it would be applied on top and
    // flip the page back to light). Only Android 10-12 has the per-WebView switch: before 10 there is no force dark at
    // all, and from 13 on page darkening is off unless an app opts in (this app does not).
    @Suppress("DEPRECATION")
    private fun applyWebView(webView: WebView) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            webView.settings.forceDark = WebSettings.FORCE_DARK_OFF
        }
        webView.setBackgroundColor(if (dark) Color.BLACK else Color.WHITE) // no light flash around a dark page
        // No-op until a page exists; a page that loads later asks NCVNative.isDark() itself.
        webView.evaluateJavascript("document.documentElement.classList.toggle('ncv-dark', $dark);", null)
    }

    private fun applyPill(view: TextView, cornerPx: Float, strokePx: Int) {
        view.setTextColor(if (dark) DARK_PILL_TEXT else LIGHT_PILL_TEXT)
        // A GradientDrawable reports no padding of its own, so replacing the background does not disturb the
        // padding the callers set (that is also why the original code could set padding and background in either order).
        view.background = GradientDrawable().apply {
            setColor(if (dark) DARK_PILL_BG else LIGHT_PILL_BG)
            cornerRadius = cornerPx
            setStroke(strokePx, if (dark) DARK_PILL_STROKE else LIGHT_PILL_STROKE)
        }
    }
}
