package com.vectorforge.app.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Shapes

val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(VfRadius.default), // rounded (DEFAULT): 4dp
    small = RoundedCornerShape(VfRadius.lg),           // rounded-lg: 8dp
    medium = RoundedCornerShape(VfRadius.xl),          // rounded-xl: 12dp
    large = RoundedCornerShape(VfRadius.xl2),          // rounded-2xl: 16dp
    extraLarge = RoundedCornerShape(VfRadius.xl3),     // rounded-[24px]: 24dp
)
