package com.vectorforge.app.ncviewer

import android.app.Activity
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.Space
import android.widget.TextView
import com.vectorforge.app.engine.gcode.transform.formatNumber
import kotlin.math.abs

/** How long a button must be held before it starts repeating, and the pause between repeats. */
private const val REPEAT_DELAY_MS = 400L
private const val REPEAT_INTERVAL_MS = 120L

/**
 * The remote-control overlay of the G-Code Viewer, built from the same pills NC Viewer uses: 20 dp corners,
 * 13 sp text, 0.85 alpha, 6 dp elevation, no other chrome. Their colours come from [ViewerTheme]: the original
 * translucent dark (#CC202124) with white text in the dark theme, a light teal pill with dark text in the light one.
 *
 *      [ status: X 0-40 . Y 0-40 . 0 deg ]            <- drag this to move the whole remote
 *      [ UL ] [ Up ] [ UR ]    [ Rotate Left  ]
 *      [Left] [    ] [Right]   [ Rotate Right ]
 *      [ DL ] [Down] [ DR ]    [ Step ] [ Angle ]
 *                              [ Reset ] [ Save ] ( [ Viewer 1 ] in split view )
 *
 * The eight arrows and the two rotate buttons repeat while held. Step, Angle and Viewer are tap-to-cycle.
 * Up / Right increase Y / X, exactly as in the G-code.
 */
class RemoteControl(
    private val activity: Activity,
    private val post: ViewerPostProcess,
    private val onSave: () -> Unit,
) {
    /** The whole overlay. Hidden until the "Post-process" pill is tapped. */
    val view = LinearLayout(activity)

    private val handler = Handler(Looper.getMainLooper())
    private val statusPill: TextView
    private val stepPill: TextView
    private val anglePill: TextView
    private val targetPill: TextView

    private fun dp(v: Int): Int = (v * activity.resources.displayMetrics.density).toInt()

    init {
        view.orientation = LinearLayout.VERTICAL
        view.gravity = Gravity.END
        view.visibility = View.GONE

        // status: the current X/Y extent and angle; also the handle that drags the whole remote
        statusPill = pill("", "Current X/Y extent and angle of the G-code. Drag to move the remote.")
        statusPill.maxLines = 1
        statusPill.ellipsize = TextUtils.TruncateAt.END
        statusPill.maxWidth = dp(300)
        statusPill.gravity = Gravity.CENTER
        attachDrag(statusPill, view)
        view.addView(statusPill, cell())

        // left column: the 3 x 3 arrow pad (the centre cell stays open)
        val pad = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            addView(row(arrow("\u2196", "Up-Left", -1, +1), arrow("\u2191", "Up", 0, +1), arrow("\u2197", "Up-Right", +1, +1)))
            addView(row(arrow("\u2190", "Left", -1, 0), spacer(), arrow("\u2192", "Right", +1, 0)))
            addView(row(arrow("\u2199", "Down-Left", -1, -1), arrow("\u2193", "Down", 0, -1), arrow("\u2198", "Down-Right", +1, -1)))
        }

        // right column: rotate, step / angle, reset / save (and the viewer switch in split view)
        stepPill = tap("", "Distance of one move. Tap to change.") { post.cycleStep() }
        anglePill = tap("", "Angle of one rotation. Tap to change.") { post.cycleAngle() }
        targetPill = tap("", "Which viewer the remote controls. Tap to switch.") { post.cycleTarget() }
        val controls = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            addView(row(repeating("\u21BA Rotate Left", "Rotate Left") { post.rotate(left = true) }))
            addView(row(repeating("Rotate Right \u21BB", "Rotate Right") { post.rotate(left = false) }))
            addView(row(stepPill, anglePill))
            addView(
                row(
                    tap("Reset", "Put the original G-code back") { post.reset() },
                    tap("Save", "Save the G-code shown in the viewer") { onSave() },
                    targetPill,
                )
            )
        }

        val body = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(pad, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(
                controls,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                    .apply { leftMargin = dp(6) }
            )
        }
        view.addView(body, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        post.onChanged = { refresh() }
        refresh()
    }

    /** Brings every label and the visibility in line with the session's state. */
    fun refresh() {
        view.visibility = if (post.visible) View.VISIBLE else View.GONE
        statusPill.text = post.status
        stepPill.text = "Step ${formatNumber(post.stepMm, 2)} mm"
        anglePill.text = "Angle ${formatNumber(post.stepAngleDeg, 2)}\u00B0"
        targetPill.visibility = if (post.splitMode) View.VISIBLE else View.GONE
        targetPill.text = "Viewer ${post.pane + 1}"
    }

    /** Back to the default corner (after a rotation of the screen a dragged position may be off-screen). */
    fun resetPosition() {
        view.translationX = 0f
        view.translationY = 0f
    }

    // ------------------------------------------------------------------ building blocks

    private fun cell(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            setMargins(dp(2), dp(2), dp(2), dp(2))
        }

    private fun row(vararg cells: View): LinearLayout = LinearLayout(activity).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        // a view that carries its own layout params (the fixed-size spacer) keeps them
        for (c in cells) if (c.layoutParams != null) addView(c) else addView(c, cell())
    }

    /**
     * The open centre of the arrow pad: exactly one arrow button wide, one line high.
     * It must have FIXED layout params. A plain View with wrap_content takes ALL the space it is offered (a View's
     * default measure for "at most N" is N), which blew this cell up to the size of the whole viewer and pushed
     * every row below it out of sight; Space is the class meant for this, and fixed params leave no doubt.
     */
    private fun spacer(): View = Space(activity).apply {
        layoutParams = LinearLayout.LayoutParams(dp(ARROW_WIDTH_DP), dp(1)).apply {
            setMargins(dp(2), dp(2), dp(2), dp(2))
        }
    }

    /** The NC Viewer pill: same colours, corners, text, alpha and elevation as its "Single view" / "Open file" pills. */
    private fun pill(label: String, contentDesc: String): TextView = TextView(activity).apply {
        text = label
        textSize = 13f
        setPadding(dp(14), dp(8), dp(14), dp(8))
        ViewerTheme.stylePill(this, dp(20).toFloat(), dp(1)) // text colour + translucent rounded background, per theme
        alpha = 0.85f
        elevation = dp(6).toFloat()
        contentDescription = contentDesc
    }

    /** A direction button: arrow glyph, compact, repeats while held. [ux] grows to the right, [uy] grows up. */
    private fun arrow(glyph: String, desc: String, ux: Int, uy: Int): TextView =
        repeating(glyph, desc) { post.move(ux, uy) }.apply {
            textSize = 16f
            gravity = Gravity.CENTER
            minWidth = dp(ARROW_WIDTH_DP)
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }

    /** A pill that performs [action] when pressed and keeps repeating it while it stays pressed. */
    private fun repeating(label: String, desc: String, action: () -> Unit): TextView {
        val repeater = object : Runnable {
            override fun run() {
                action()
                handler.postDelayed(this, REPEAT_INTERVAL_MS)
            }
        }
        return pill(label, desc).apply {
            setOnTouchListener { v, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        v.alpha = 1f
                        action()
                        handler.postDelayed(repeater, REPEAT_DELAY_MS)
                        true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        v.alpha = 0.85f
                        handler.removeCallbacks(repeater)
                        true
                    }
                    else -> false
                }
            }
        }
    }

    /** A pill that performs [action] once per tap, like NC Viewer's own pills (a press that turns into a drag does nothing). */
    private fun tap(label: String, desc: String, action: () -> Unit): TextView = pill(label, desc).apply {
        val slop = ViewConfiguration.get(activity).scaledTouchSlop.toFloat()
        var downX = 0f
        var downY = 0f
        var moved = false
        setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    moved = false
                    v.alpha = 1f
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.rawX - downX) > slop || abs(e.rawY - downY) > slop) moved = true
                    true
                }
                MotionEvent.ACTION_UP -> {
                    v.alpha = 0.85f
                    if (!moved) action()
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    v.alpha = 0.85f
                    true
                }
                else -> false
            }
        }
    }

    /** Drag [handle] to move [target]: the same drag the NC Viewer pills have, kept inside the viewer. */
    private fun attachDrag(handle: View, target: View) {
        val slop = ViewConfiguration.get(activity).scaledTouchSlop.toFloat()
        var downX = 0f
        var downY = 0f
        var startX = 0f
        var startY = 0f
        var dragging = false
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = target.translationX
                    startY = target.translationY
                    dragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!dragging && (abs(dx) > slop || abs(dy) > slop)) dragging = true
                    if (dragging) {
                        var nx = startX + dx
                        var ny = startY + dy
                        (target.parent as? View)?.let { p ->
                            nx = minOf(maxOf(nx, -target.left.toFloat()), (p.width - target.right).toFloat())
                            ny = minOf(maxOf(ny, -target.top.toFloat()), (p.height - target.bottom).toFloat())
                        }
                        target.translationX = nx
                        target.translationY = ny
                    }
                    true
                }
                else -> true
            }
        }
    }

    private companion object {
        const val ARROW_WIDTH_DP = 46
    }
}
