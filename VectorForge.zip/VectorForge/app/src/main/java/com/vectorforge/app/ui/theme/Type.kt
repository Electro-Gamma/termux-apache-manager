package com.vectorforge.app.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp

/**
 * The reference specifies "Plus Jakarta Sans" for every text token (loaded
 * in code.html via a Google Fonts <link>). Bundling that exact font's
 * binary isn't possible from a text-only source delivery, so this uses the
 * platform sans-serif (Roboto on stock Android) as a stand-in -- every
 * size, line-height, weight and letter-spacing value below is still copied
 * exactly from the reference's `fontSize` scale. To get pixel-identical
 * typography, drop the four "Plus Jakarta Sans" .ttf weights (400/600/700,
 * regular + any italics you need) into res/font/ and point this
 * FontFamily at them -- everything else (VfType, AppTypography) needs no
 * further changes.
 */
val AppFontFamily = FontFamily.SansSerif

/**
 * One TextStyle per named token in the reference's `theme.extend.fontSize`
 * block, so screens can reach for e.g. `VfType.labelMd` directly instead of
 * squeezing eleven distinct text roles into Material 3's fixed 15 slots.
 */
object VfType {
    val headlineSm = TextStyle(
        fontFamily = AppFontFamily, fontWeight = FontWeight.SemiBold,
        fontSize = 18.sp, lineHeight = 24.sp
    )
    val headlineLgMobile = TextStyle(
        fontFamily = AppFontFamily, fontWeight = FontWeight.Bold,
        fontSize = 26.sp, lineHeight = 32.sp
    )
    val bodyLg = TextStyle(
        fontFamily = AppFontFamily, fontWeight = FontWeight.Normal,
        fontSize = 15.sp, lineHeight = 22.sp
    )
    val labelMd = TextStyle(
        fontFamily = AppFontFamily, fontWeight = FontWeight.Bold,
        fontSize = 11.sp, lineHeight = 14.sp, letterSpacing = 0.06.em
    )
    val titleMd = TextStyle(
        fontFamily = AppFontFamily, fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp, lineHeight = 22.sp
    )
    val bodyMd = TextStyle(
        fontFamily = AppFontFamily, fontWeight = FontWeight.Normal,
        fontSize = 14.sp, lineHeight = 20.sp
    )
    val labelSm = TextStyle(
        fontFamily = AppFontFamily, fontWeight = FontWeight.SemiBold,
        fontSize = 10.sp, lineHeight = 12.sp, letterSpacing = 0.04.em
    )
    val headlineLg = TextStyle(
        fontFamily = AppFontFamily, fontWeight = FontWeight.Bold,
        fontSize = 32.sp, lineHeight = 40.sp
    )
    val headlineMd = TextStyle(
        fontFamily = AppFontFamily, fontWeight = FontWeight.SemiBold,
        fontSize = 22.sp, lineHeight = 28.sp
    )
    val labelLg = TextStyle(
        fontFamily = AppFontFamily, fontWeight = FontWeight.SemiBold,
        fontSize = 13.sp, lineHeight = 18.sp
    )
    val bodySm = TextStyle(
        fontFamily = AppFontFamily, fontWeight = FontWeight.Normal,
        fontSize = 12.sp, lineHeight = 16.sp
    )
}

/**
 * Material3's fixed 15-slot Typography, mapped onto the closest VfType
 * token so stock components (buttons, switches' internal text, default
 * TopAppBar title, etc.) that read MaterialTheme.typography stay visually
 * consistent with the custom screens that reach for VfType directly.
 */
val AppTypography = Typography(
    headlineLarge = VfType.headlineLg,
    headlineMedium = VfType.headlineMd,
    headlineSmall = VfType.headlineSm,
    titleLarge = VfType.headlineLgMobile,
    titleMedium = VfType.titleMd,
    titleSmall = VfType.labelLg,
    bodyLarge = VfType.bodyLg,
    bodyMedium = VfType.bodyMd,
    bodySmall = VfType.bodySm,
    labelLarge = VfType.labelLg,
    labelMedium = VfType.labelMd,
    labelSmall = VfType.labelSm,
)
