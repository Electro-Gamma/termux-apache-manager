package com.vectorforge.app.engine.gcode.transform

/**
 * Every post-processing parameter (the TRANSFORM arguments plus the FINAL NORMALIZE pair) and the one pipeline
 * that applies them. There is exactly one implementation of "post-process this G-code", used by both
 *  - "Generate" / "Generate + Viewer ..." on the Convert screen (applied to the freshly generated file), and
 *  - the live Post-process panel of the G-Code Viewer (applied to what the viewer currently shows),
 * so a preview in the viewer is, by construction, identical to what the same values produce when generating.
 *
 * Blank / off = not passed, like every other optional parameter:
 *
 *  rotateLeft / rotateRight   --rotate-left / --rotate-right DEG   (mutually exclusive, like the CLI)
 *  offsetX / offsetY          --offset-x / --offset-y
 *  keepPositive ... keepSouth --keep-positive / -negative / -east / -west / -north / -south
 *  noFixedHome                --no-fixed-home
 *  maxX / maxY                --max-x / --max-y   (warning only)
 *  precision                  --precision         (blank = the transformer's default)
 *  finalNewMin / finalNewMax  NEW MIN / NEW MAX applied again at the very end (blank half = fallback value)
 */
data class PostProcessParams(
    val rotateLeft: Double? = null,
    val rotateRight: Double? = null,
    val offsetX: Double? = null,
    val offsetY: Double? = null,
    val keepPositive: Boolean = false,
    val keepNegative: Boolean = false,
    val keepEast: Boolean = false,
    val keepWest: Boolean = false,
    val keepNorth: Boolean = false,
    val keepSouth: Boolean = false,
    val noFixedHome: Boolean = false,
    val maxX: Double? = null,
    val maxY: Double? = null,
    val precision: Int? = null,
    val finalNewMin: Double? = null,
    val finalNewMax: Double? = null,
) {
    /**
     * True when a setting that actually moves or checks the toolpath is in use (rotate, offset, keep, max-x/y).
     * --no-fixed-home and --precision on their own change nothing, so they do not trigger the transform.
     */
    val transformActive: Boolean
        get() = rotateLeft != null || rotateRight != null ||
            offsetX != null || offsetY != null ||
            keepPositive || keepNegative || keepEast || keepWest || keepNorth || keepSouth ||
            maxX != null || maxY != null

    val finalNormalizeActive: Boolean
        get() = finalNewMin != null || finalNewMax != null

    /** True when [process] would change or check anything at all. */
    val isActive: Boolean get() = transformActive || finalNormalizeActive

    /**
     * The transformer's options, or null when no transform setting is in use.
     * Throws IllegalArgumentException for --rotate-left together with --rotate-right, which the CLI rejects too
     * (the other conflicts, east+west and north+south, are checked by the transformer itself).
     */
    fun toTransformOptionsOrNull(): TransformOptions? {
        if (!transformActive) return null
        require(rotateLeft == null || rotateRight == null) {
            "argument --rotate-left: not allowed with argument --rotate-right"
        }
        return TransformOptions(
            direction = when {
                rotateLeft != null -> "left"
                rotateRight != null -> "right"
                else -> null
            },
            angle = rotateLeft ?: rotateRight ?: 0.0,
            offsetX = offsetX ?: 0.0,
            offsetY = offsetY ?: 0.0,
            keepPositive = keepPositive,
            keepNegative = keepNegative,
            keepEast = keepEast,
            keepWest = keepWest,
            keepNorth = keepNorth,
            keepSouth = keepSouth,
            noFixedHome = noFixedHome,
            maxX = maxX,
            maxY = maxY,
            precision = precision ?: TransformOptions().precision,
        )
    }

    /**
     * Runs the pipeline on [gcode]: transform (rotate -> keep -> offset) and then, last of all, the final
     * normalize. [fallbackMin] / [fallbackMax] stand in for a blank half of the FINAL NEW MIN / NEW MAX pair
     * (the Convert screen passes its header NEW MIN / NEW MAX). Returns [gcode] itself, untouched, when
     * nothing is set. Throws IllegalArgumentException (message already prefixed with the failing stage) for
     * the values the CLI rejects, instead of silently correcting them.
     */
    fun process(gcode: String, fallbackMin: Double, fallbackMax: Double): PostProcessOutput {
        val transformed = try {
            toTransformOptionsOrNull()?.let { transformGcode(gcode, it) }
        } catch (e: IllegalArgumentException) {
            throw IllegalArgumentException("G-code transform: ${e.message}", e)
        }
        var text = transformed?.text ?: gcode

        var finalNote: String? = null
        if (finalNormalizeActive) {
            val lo = finalNewMin ?: fallbackMin
            val hi = finalNewMax ?: fallbackMax
            val normalized = try {
                normalizeGcodeText(text, lo, hi)
            } catch (e: IllegalArgumentException) {
                throw IllegalArgumentException("Final normalize: ${e.message}", e)
            }
            finalNote = if (normalized == text) {
                // normalizeLines only touches G1 moves inside "(Label: N points)" stroke blocks
                "Final normalize \u2192 nothing to change (already in range, or no stroke blocks found)"
            } else {
                "Final normalize \u2192 X and Y mapped to [${formatNumber(lo, 4)}, ${formatNumber(hi, 4)}] mm"
            }
            text = normalized
        }
        return PostProcessOutput(text = text, transform = transformed, finalNormalizeNote = finalNote)
    }
}

/** [text] is the processed G-code; [transform] the transformer's report (null if no transform ran); [finalNormalizeNote] the final-normalize line (null if it did not run). */
class PostProcessOutput(
    val text: String,
    val transform: TransformResult?,
    val finalNormalizeNote: String?,
) {
    /** The status lines for the UI: the CLI's transform report followed by the final-normalize note. */
    val reportLines: List<String>
        get() = (transform?.report ?: emptyList()) + listOfNotNull(finalNormalizeNote)
}
