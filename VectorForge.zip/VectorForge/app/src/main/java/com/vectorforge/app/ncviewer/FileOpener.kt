package com.vectorforge.app.ncviewer

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.SystemClock
import android.provider.OpenableColumns
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import kotlin.math.abs

/**
 * One "Open file" pill for ONE pane (one WebView): pick a G-code file from phone storage, put it into that
 * pane's G-code editor (replace the current text, or append to it) and press PLOT, all in one go.
 *
 * Ported 1:1 from NC Viewer Offline's FileOpener.kt. The only addition is [openGeneratedFile], which feeds a
 * file that VectorForge just generated through exactly the same path a file picked with the pill takes
 * (same editor-state check, same Replace/Append/Cancel dialog when the editor already holds G-code, same
 * loader script, same PLOT press) -- it just doesn't need the system file picker first.
 *
 * Single view has one pane, split view has two, and each pane gets its own FileOpener with its own pill
 * (bottom-left of that pane), so a file always goes into the window whose button you tapped.
 *
 * How it works
 *  1. Tap the pill -> the system file picker opens (same ACTION_GET_CONTENT the site's own Open button uses).
 *  2. The picked Uri is kept in [pickedUri]. It is exposed to the page at [pickedPath] (unique per pane);
 *     [intercept] answers that request from the content resolver, so a big file never has to be pasted
 *     into a JavaScript string.
 *  3. assets/open_file_loader.js (evaluated in the pane's page) fetches it, fills the Ace editor and clicks PLOT.
 *
 * If the editor already holds G-code, a small dialog asks Replace / Append / Cancel.
 * If it is empty (or still shows NC Viewer's welcome text) the file is simply loaded.
 *
 * The WebView needs the [NCVNativeBridge] registered as "NCVNative" before its first page load
 * ([NcViewerController] does that). [id] must differ per pane (0 = top, 1 = bottom).
 */
class FileOpener(
    private val activity: Activity,
    private val webView: WebView,
    container: FrameLayout,
    val id: Int
) {
    companion object {
        private const val REQUEST_CODE_BASE = 51427 // 51426 is the site's own file chooser
        private const val TAG = "NCViewer"
        private const val LOADER_ASSET = "open_file_loader.js"

        /** How often / how long [openGeneratedFile] waits for the pane and the editor to come up. */
        private const val READY_POLL_MS = 250L
        private const val READY_TIMEOUT_MS = 30_000L
    }

    private val requestCode = REQUEST_CODE_BASE + id
    private val pickedPath = "/__ncv_picked_file_$id"

    @Volatile private var pickedUri: Uri? = null
    private val button: TextView

    private val loaderJs: String by lazy {
        activity.assets.open(LOADER_ASSET).bufferedReader().use { it.readText() }
    }

    init {
        button = buildButton()
        container.addView(
            button,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.START
            ).apply { setMargins(dp(12), 0, 0, dp(12)) }
        )
    }

    // ------------------------------------------------------------------ picking

    private fun openPicker() {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*" // .gcode / .nc / .tap have no reliable MIME type
        }
        try {
            @Suppress("DEPRECATION")
            activity.startActivityForResult(Intent.createChooser(intent, "Open G-code file"), requestCode)
        } catch (e: Exception) {
            Log.e(TAG, "file picker failed: ${e.message}")
            toast("No file picker available", long = true)
        }
    }

    /** Returns true if the result belonged to this pane's picker (so the Activity should stop handling it). */
    fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?): Boolean {
        if (requestCode != this.requestCode) return false
        val uri = if (resultCode == Activity.RESULT_OK) data?.data else null
        if (uri != null) onPicked(uri)
        return true
    }

    private fun onPicked(uri: Uri) {
        pickedUri = uri
        val name = displayName(uri)
        // Ask the page whether the editor already holds G-code.
        webView.evaluateJavascript("$loaderJs\nwindow.__ncvOpen.state();") { raw ->
            when (raw?.trim('"')) {
                "has" -> askReplaceOrAppend(name)
                "noeditor" -> toast("Open the editor page first, then try again", long = true)
                else -> load("replace", name) // empty editor or the welcome text
            }
        }
    }

    // ------------------------------------------------------------------ VectorForge: open a generated file

    /**
     * Loads [file] (freshly generated G-code) into this pane and plots it -- the same thing that happens
     * after picking it with the pill, minus the picker.
     *
     * A pane that has just been shown (tab switch) or just been created (first use of split view) is not
     * necessarily laid out yet, and its page may still be booting. Plotting into a 0x0 WebView or before the
     * editor exists would silently do nothing, so this polls until the pane is attached and has a size AND the
     * page reports an editor, then continues exactly like [onPicked]. Gives up (with a toast) after 30 s.
     */
    fun openGeneratedFile(file: File) {
        val deadline = SystemClock.uptimeMillis() + READY_TIMEOUT_MS
        val name = file.name

        fun retryOrGiveUp(attempt: () -> Unit) {
            if (SystemClock.uptimeMillis() >= deadline) {
                toast("G-code viewer is not ready. Open the G-Code Viewer tab and try again.", long = true)
            } else {
                webView.postDelayed(Runnable { attempt() }, READY_POLL_MS)
            }
        }

        fun attempt() {
            if (!webView.isAttachedToWindow || webView.width == 0 || webView.height == 0) {
                retryOrGiveUp(::attempt)
                return
            }
            webView.evaluateJavascript("$loaderJs\nwindow.__ncvOpen.state();") { raw ->
                when (raw?.trim('"')) {
                    "noeditor", "null", null -> retryOrGiveUp(::attempt) // page still loading
                    "has" -> {
                        pickedUri = Uri.fromFile(file)
                        askReplaceOrAppend(name)
                    }
                    else -> {
                        pickedUri = Uri.fromFile(file)
                        load("replace", name) // empty editor or the welcome text
                    }
                }
            }
        }
        attempt()
    }

    // ------------------------------------------------------------------ VectorForge: live post-processing

    /** What this pane's editor holds: [name] is the file name NC Viewer shows, [text] the G-code. */
    class PaneText(val name: String, val text: String)

    /**
     * Reads the G-code currently in this pane's editor. [callback] runs on the main thread with null if the
     * editor is missing, empty, or still showing NC Viewer's welcome text.
     */
    fun readEditorText(callback: (PaneText?) -> Unit) {
        webView.evaluateJavascript("$loaderJs\nwindow.__ncvOpen.getText();") { raw ->
            val parsed = try {
                if (raw == null || raw == "null") null else {
                    // evaluateJavascript hands back a JSON-encoded string; the string itself is JSON {name, text}
                    val o = JSONObject(JSONArray("[$raw]").getString(0))
                    PaneText(o.optString("name").ifBlank { "viewer.gcode" }, o.getString("text"))
                }
            } catch (e: Exception) {
                Log.w(TAG, "could not read the editor text: ${e.message}")
                null
            }
            callback(parsed)
        }
    }

    /**
     * Puts [file]'s G-code into this pane's editor in place of whatever is there and plots it -- no
     * Replace / Append / Cancel prompt, because the live preview re-sends its result on every change.
     * [displayName] is what NC Viewer shows as the file name (the processed copy is a temp file).
     */
    fun replaceWithFile(file: File, displayName: String) {
        pickedUri = Uri.fromFile(file)
        load("replace", displayName)
    }

    private fun askReplaceOrAppend(name: String) {
        // Light dialog theme = what the NC Viewer app itself shows (its Activity theme was Material Light).
        AlertDialog.Builder(activity, android.R.style.Theme_Material_Light_Dialog_Alert)
            .setTitle(name)
            .setMessage("The editor already contains G-code. What should happen to this file?")
            .setPositiveButton("Replace") { _, _ -> load("replace", name) }
            .setNeutralButton("Append") { _, _ -> load("append", name) }
            .setNegativeButton("Cancel") { _, _ -> pickedUri = null }
            .setOnCancelListener { pickedUri = null }
            .show()
    }

    /** mode = "replace" or "append". The page does the rest: fetch, fill the editor, press PLOT. */
    private fun load(mode: String, name: String) {
        val url = "$pickedPath?t=${System.currentTimeMillis()}"
        val js = "$loaderJs\nwindow.__ncvOpen.load(" +
            "${JSONObject.quote(mode)}, ${JSONObject.quote(name)}, ${JSONObject.quote(url)});"
        webView.evaluateJavascript(js, null)
    }

    private fun displayName(uri: Uri): String {
        try {
            activity.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                val col = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (col >= 0 && c.moveToFirst()) {
                    val n = c.getString(col)
                    if (!n.isNullOrBlank()) return n
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "could not read file name: ${e.message}")
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "file.gcode"
    }

    // ------------------------------------------------------------------ serving the picked file to the page

    private fun openPicked(uri: Uri): InputStream? =
        if (uri.scheme == "file") {
            // a file VectorForge generated itself (app-specific storage), no content resolver involved
            uri.path?.let { FileInputStream(File(it)) }
        } else {
            activity.contentResolver.openInputStream(uri)
        }

    /**
     * Call from WebViewClient.shouldInterceptRequest (background thread). Returns the picked file's bytes for
     * this pane's [pickedPath] on the app's own origin, or null for every other request.
     */
    fun intercept(request: WebResourceRequest): WebResourceResponse? {
        val url = request.url
        if (url.path != pickedPath) return null
        val host = url.host
        if (host != AppAssetHandler.HOST && host != "127.0.0.1" && host != "localhost") return null

        val headers = mapOf("Cache-Control" to "no-store")
        val stream = try {
            pickedUri?.let { openPicked(it) }
        } catch (e: Exception) {
            Log.w(TAG, "could not open picked file: ${e.message}")
            null
        }
        return if (stream != null) {
            WebResourceResponse("text/plain", "utf-8", 200, "OK", headers, stream)
        } else {
            WebResourceResponse("text/plain", "utf-8", 404, "Not Found", headers, ByteArrayInputStream(ByteArray(0)))
        }
    }

    // ------------------------------------------------------------------ the pill

    private fun dp(v: Int): Int = (v * activity.resources.displayMetrics.density).toInt()

    private fun toast(message: String, long: Boolean = false) {
        Toast.makeText(activity, message, if (long) Toast.LENGTH_LONG else Toast.LENGTH_SHORT).show()
    }

    /** Back to the default corner (after a rotation, or when the pane changes size). */
    fun resetPosition() {
        button.translationX = 0f
        button.translationY = 0f
    }

    /** Same look as the "Mobile view" / "Single view" pills. Tap = open a file, drag = move it out of the way. */
    private fun buildButton(): TextView = TextView(activity).apply {
        text = "Open file"
        textSize = 13f
        setTextColor(Color.WHITE)
        setPadding(dp(14), dp(8), dp(14), dp(8))
        background = GradientDrawable().apply {
            setColor(Color.argb(204, 32, 33, 36))
            cornerRadius = dp(20).toFloat()
        }
        alpha = 0.85f
        elevation = dp(6).toFloat()
        contentDescription = "Open a G-code file from phone storage and plot it"

        val slop = ViewConfiguration.get(activity).scaledTouchSlop.toFloat()
        var downX = 0f
        var downY = 0f
        var startX = 0f
        var startY = 0f
        var dragging = false
        setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = v.translationX
                    startY = v.translationY
                    dragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!dragging && (abs(dx) > slop || abs(dy) > slop)) dragging = true
                    if (dragging) {
                        // keep the pill inside its own pane, so it can never be dragged out of reach
                        var nx = startX + dx
                        var ny = startY + dy
                        (v.parent as? View)?.let { p ->
                            nx = minOf(maxOf(nx, -v.left.toFloat()), (p.width - v.right).toFloat())
                            ny = minOf(maxOf(ny, -v.top.toFloat()), (p.height - v.bottom).toFloat())
                        }
                        v.translationX = nx
                        v.translationY = ny
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!dragging) openPicker()
                    true
                }
                else -> false
            }
        }
    }
}

/**
 * Page -> app: the loader script reports success or failure here (shown as a toast).
 * Registered by [NcViewerController] (before the first page load). Deliberately a public top-level
 * class: WebView reaches @JavascriptInterface methods by reflection.
 */
class NCVNativeBridge(private val activity: Activity) {
    @JavascriptInterface
    fun onResult(ok: Boolean, message: String) {
        Log.d("NCViewer", "open file: ok=$ok $message")
        activity.runOnUiThread {
            Toast.makeText(activity, message, if (ok) Toast.LENGTH_SHORT else Toast.LENGTH_LONG).show()
        }
    }
}
