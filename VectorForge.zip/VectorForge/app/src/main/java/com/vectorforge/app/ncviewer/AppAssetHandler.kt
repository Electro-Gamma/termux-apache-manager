package com.vectorforge.app.ncviewer

import android.content.res.AssetManager
import android.util.Log
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream
import java.io.IOException
import java.io.InputStream

/**
 * Serves the bundled site (assets/www) to the WebView without any socket or port.
 *
 * The WebView is pointed at a virtual origin, https://appassets.androidplatform.net/, and every request
 * to that host is answered here, straight from the APK's assets, from WebViewClient.shouldInterceptRequest.
 * No DNS lookup or connection ever happens for that host, and nothing listens on the device.
 *
 * Behaviour deliberately mirrors what Serve.kt did for this site:
 *  - "/" (or any directory URL) serves index.html / index.htm from that directory
 *  - same file-extension to MIME-type table (.js is text/javascript, .woff2 is font/woff2, ...)
 *  - a missing file is a real 404
 * plus one addition: the site uses history-mode routing (/privacy, /download, ...), so an extension-less
 * path with no matching file gets index.html and the router takes over (a plain file server would 404 there).
 *
 * Requests to any other host (CDN fonts and the like) return null, so the WebView handles them as usual.
 */
class AppAssetHandler(private val assets: AssetManager) {

    /** The response for [request], or null if it is not for our virtual origin. Called on a background thread. */
    fun handle(request: WebResourceRequest): WebResourceResponse? {
        val url = request.url
        if (url.scheme != "https" || url.host != HOST) return null

        val path = url.path ?: "/"
        val segments = path.split('/').filter { it.isNotEmpty() }
        if (segments.any { it == "." || it == ".." }) return notFound(path)

        val rel = segments.joinToString("/")
        val wantsDirectory = rel.isEmpty() || path.endsWith("/")

        // 1) the exact file, or the index page of the requested directory
        val candidates = if (wantsDirectory) {
            INDEX_PAGES.map { page -> if (rel.isEmpty()) page else "$rel/$page" }
        } else {
            listOf(rel)
        }
        for (candidate in candidates) {
            val stream = openOrNull(candidate) ?: continue
            return ok(candidate, stream)
        }

        // 2) history-mode routes such as /privacy: no file extension, so hand the app shell to the router
        val last = segments.lastOrNull() ?: ""
        if (!last.contains('.')) {
            val shell = openOrNull("index.html")
            if (shell != null) return ok("index.html", shell)
        }

        return notFound(path)
    }

    private fun openOrNull(rel: String): InputStream? =
        try {
            assets.open("$ROOT/$rel")
        } catch (e: IOException) {
            null // missing file, or a directory
        }

    private fun ok(rel: String, stream: InputStream): WebResourceResponse {
        val mime = guessType(rel)
        val encoding = if (isText(mime)) "utf-8" else null
        // The one file that is not served byte-for-byte: the page shell gets the dark-theme hook (see ViewerTheme).
        if (rel == "index.html" || rel.endsWith("/index.html")) {
            return WebResourceResponse(mime, encoding, withThemeHook(stream))
        }
        return WebResourceResponse(mime, encoding, stream)
    }

    /** index.html with [THEME_HOOK] inserted right after <head>, so the page is dark from its first paint. */
    private fun withThemeHook(stream: InputStream): InputStream {
        val html = stream.use { String(it.readBytes(), Charsets.UTF_8) }
        val at = html.indexOf("<head>")
        if (at < 0) return ByteArrayInputStream(html.toByteArray(Charsets.UTF_8)) // unexpected shell: serve as it is
        val patched = html.substring(0, at + "<head>".length) + THEME_HOOK + html.substring(at + "<head>".length)
        return ByteArrayInputStream(patched.toByteArray(Charsets.UTF_8))
    }

    private fun notFound(path: String): WebResourceResponse {
        Log.w(TAG, "asset 404: $path")
        return WebResourceResponse(
            "text/plain",
            "utf-8",
            404,
            "Not Found",
            mapOf("Cache-Control" to "no-store"),
            ByteArrayInputStream("404 Not Found".toByteArray())
        )
    }

    private fun guessType(name: String): String {
        val file = name.substringAfterLast('/')
        val dot = file.lastIndexOf('.')
        val ext = if (dot > 0) file.substring(dot).lowercase() else ""
        return MIME_TYPES[ext] ?: "application/octet-stream"
    }

    private fun isText(mime: String): Boolean =
        mime.startsWith("text/") || mime.endsWith("json") || mime.endsWith("xml") || mime.endsWith("javascript")

    companion object {
        const val HOST = "appassets.androidplatform.net"
        const val ORIGIN = "https://$HOST"

        private const val TAG = "NCViewer"

        /**
         * Dark mode for the bundled site, which has no theme of its own. Two parts:
         *  - the whole page (G-code editor, toolbars, view cube) is inverted with a CSS filter (invert + 180 degree
         *    hue rotation: light becomes dark, hues are kept);
         *  - the main plot canvas is NOT left to that filter, because inverting would also turn the blue toolpath
         *    into lavender. It gets the inverse filter (which cancels the page filter exactly, so its colours are
         *    the site's own: blue cuts, orange rapids, red / green axes) and a dark background and grid chosen in
         *    the site's config instead (see the three small patches under assets/www/_nuxt, documented in README).
         * window.__ncvDark is set before any site script runs; ViewerTheme calls __ncvApplyTheme on a live change.
         * __ncvCfg / __ncvPlot are the handles those patches expose; every use is guarded, so a site that lacks them
         * still gets the page filter.
         */
        private const val THEME_HOOK =
            "<style id=\"ncv-theme\">" +
            "html.ncv-dark{filter:invert(1) hue-rotate(180deg);background:#fff;color-scheme:dark}" +
            "html.ncv-dark #nc-plot canvas{filter:invert(1) hue-rotate(180deg)}" +
            "</style>" +
            "<script>(function(){" +
            "try{window.__ncvDark=!!(window.NCVNative&&window.NCVNative.isDark())}catch(e){window.__ncvDark=false}" +
            "if(window.__ncvDark)document.documentElement.classList.add('ncv-dark');" +
            "window.__ncvApplyTheme=function(d){try{" +
            "window.__ncvDark=d;document.documentElement.classList.toggle('ncv-dark',d);" +
            "var c=window.__ncvCfg,p=window.__ncvPlot;" +
            "if(c){c.backgroundColor.setHex(d?0x1a1c20:0xf2f2f2);c.gridMajorColor.setHex(d?0x4a4f57:0x999999);" +
            "c.gridMinorColor.setHex(d?0x2a2d32:0xc8c8c8)}" +
            "if(c&&p&&p.view&&p.view.renderer){p.view.renderer.setClearColor(c.backgroundColor);" +
            "if(p.mgr)p.mgr.createGrid();p.view.render()}" +
            "}catch(e){}};" +
            "})()</script>"
        private const val ROOT = "www"
        private val INDEX_PAGES = listOf("index.html", "index.htm")

        // Same table as Serve.kt.
        private val MIME_TYPES = mapOf(
            ".html" to "text/html",
            ".htm" to "text/html",
            ".css" to "text/css",
            ".js" to "text/javascript",
            ".mjs" to "text/javascript",
            ".json" to "application/json",
            ".webmanifest" to "application/manifest+json",
            ".xml" to "application/xml",
            ".txt" to "text/plain",
            ".csv" to "text/csv",
            ".md" to "text/markdown",
            ".png" to "image/png",
            ".jpg" to "image/jpeg",
            ".jpeg" to "image/jpeg",
            ".jpe" to "image/jpeg",
            ".gif" to "image/gif",
            ".bmp" to "image/bmp",
            ".svg" to "image/svg+xml",
            ".ico" to "image/vnd.microsoft.icon",
            ".webp" to "image/webp",
            ".avif" to "image/avif",
            ".woff" to "font/woff",
            ".woff2" to "font/woff2",
            ".ttf" to "font/ttf",
            ".otf" to "font/otf",
            ".wasm" to "application/wasm",
            ".pdf" to "application/pdf",
            ".zip" to "application/zip",
            ".mp3" to "audio/mpeg",
            ".wav" to "audio/x-wav",
            ".mp4" to "video/mp4",
            ".webm" to "video/webm"
        )
    }
}
