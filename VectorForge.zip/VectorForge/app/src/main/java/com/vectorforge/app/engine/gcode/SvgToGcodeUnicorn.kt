/**
 * SvgToGcodeUnicorn.kt -- single-file SVG -> G-code converter (Kotlin port)
 * ===========================================================================
 *
 * A line-for-line Kotlin port of `svg2gcode_unicorn.py`, itself a
 * self-contained rewrite of the old "svg2gcode / unicorn" Inkscape-extension
 * pen-plotter converter (MakerBot-era "Unicorn" G-code dialect: pen up/down
 * via an `M300 Sxx` servo command, motion via `G1`, `G4 Pxx` for millisecond
 * delays).
 *
 * This file uses nothing but the JDK standard library (java.xml's DOM parser
 * stands in for Python's `xml.etree.ElementTree`) so it compiles with a bare
 * `kotlinc SvgToGcodeUnicorn.kt -include-runtime -d svg2gcode.jar` -- no
 * Gradle/Maven project needed.
 *
 * PIPELINE (identical to the Python version):
 * 1. Parse the SVG with a namespace-aware DOM parser.
 * 2. Compute a root transform mapping the document's user-unit coordinate
 *    system (honouring `viewBox`, `width`/`height` and their units) into
 *    millimetres, flip the Y axis (SVG: Y grows down; plotter: Y grows up)
 *    and center the drawing on (0, 0).
 * 3. Walk the document tree, composing `transform="..."` attributes,
 *    resolving `<use>` (clones) and skipping hidden layers/elements.
 * 4. Convert every drawable element (path/rect/line/polyline/polygon/
 *    circle/ellipse) into cubic-Bezier "subpaths" (lists of
 *    [inHandle, point, outHandle] nodes -- the classic "cubic superpath").
 *    `<path>` arcs are converted with the standard SVG endpoint-to-center
 *    arc algorithm.
 * 5. Flatten every subpath into a polyline via adaptive recursive
 *    subdivision (split in half until control points are within
 *    `--flatness` mm of the chord).
 * 6. Emit G-code: preamble, optional pen-registration test, one
 *    travel/draw/lift sequence per polyline, postscript. Multi-copy
 *    ("sheet") and `--continuous` modes are supported.
 * 7. Post-process: remap the drawing into a `--new-min`..`--new-max` mm
 *    square, then thin out points closer together than `--min-change` mm
 *    (bounded by `--skip-factor`).
 *
 * See the Python original's header comment for the list of original bugs
 * this rewrite fixed (wrong pen angle on lower, hidden-node skip that never
 * skipped, unclosed `<polygon>`, thinning tied to a hard-coded pen angle
 * string, lost stroke endpoints, divide-by-zero on a degenerate bounding
 * box). This port preserves every one of those fixes and every CLI flag
 * (as fields on `Args` -- see the ANDROID PORT NOTE near the bottom of
 * this file for what changed to run inside the app instead of a CLI).
 *
 * ANDROID PORT NOTE: javax.xml.parsers / org.w3c.dom / org.xml.sax are all
 * part of the Android SDK (Android ships a DOM-capable XML parser), so the
 * SVG-parsing and G-code-emitting pipeline below required zero changes.
 * Only the argv-based CLI wrapper at the bottom (`parseArgs`, `main`, help
 * text, exit-code handling) was removed, since an Android app has no argv
 * and must not call exitProcess() mid-lifecycle; the app's UI builds an
 * `Args` directly instead. Every parameter, default value and algorithm
 * above that point is unchanged.
 */

package com.vectorforge.app.engine.gcode

import java.io.File
import java.io.StringReader
import java.util.Locale
import javax.xml.parsers.DocumentBuilder
import javax.xml.parsers.DocumentBuilderFactory
import org.w3c.dom.Document
import org.w3c.dom.Element
import org.w3c.dom.Node
import org.xml.sax.InputSource
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

const val PROG = "svg2gcode_unicorn"

/** Locale-safe stand-in for Python's "%.2f" % x style formatting -- always
 *  uses '.' as the decimal separator regardless of the JVM's default locale. */
fun fmt(format: String, vararg args: Any?): String = String.format(Locale.ROOT, format, *args)

/** DOM's getAttribute() returns "" for a missing attribute (never null); this
 *  turns that into a proper null, matching Python's ElementTree `.get(name)`. */
fun String.orNullIfEmpty(): String? = if (this.isEmpty()) null else this

// ======================================================================
//  Affine transforms:  Mat(a, b, c, d, e, f)  meaning  x' = a*x + c*y + e
//                                                       y' = b*x + d*y + f
// ======================================================================

data class Pt(val x: Double, val y: Double)

data class Mat(val a: Double, val b: Double, val c: Double, val d: Double, val e: Double, val f: Double)

val IDENTITY = Mat(1.0, 0.0, 0.0, 1.0, 0.0, 0.0)

private val NUM_REGEX = Regex("""[-+]?(?:\d+\.\d*|\.\d+|\d+)(?:[eE][-+]?\d+)?""")

fun nums(s: String): List<Double> = NUM_REGEX.findAll(s).map { it.value.toDouble() }.toList()

/** Compose two transforms: the result applies m2 first, then m1. */
fun matMul(m1: Mat, m2: Mat): Mat {
    val (a1, b1, c1, d1, e1, f1) = m1
    val (a2, b2, c2, d2, e2, f2) = m2
    return Mat(
        a1 * a2 + c1 * b2,
        b1 * a2 + d1 * b2,
        a1 * c2 + c1 * d2,
        b1 * c2 + d1 * d2,
        a1 * e2 + c1 * f2 + e1,
        b1 * e2 + d1 * f2 + f1
    )
}

fun applyPoint(m: Mat, pt: Pt): Pt = Pt(m.a * pt.x + m.c * pt.y + m.e, m.b * pt.x + m.d * pt.y + m.f)

private val TRANSFORM_REGEX = Regex("""(matrix|translate|scale|rotate|skewX|skewY)\s*\(([^)]*)\)""")

/** Parse an SVG `transform` attribute into a Mat. */
fun parseTransform(s: String?): Mat {
    var m = IDENTITY
    if (s.isNullOrEmpty()) return m
    for (match in TRANSFORM_REGEX.findAll(s)) {
        val name = match.groupValues[1]
        val args = nums(match.groupValues[2])
        val t: Mat? = when (name) {
            "matrix" -> if (args.size == 6) Mat(args[0], args[1], args[2], args[3], args[4], args[5]) else null
            "translate" -> {
                val tx = if (args.isNotEmpty()) args[0] else 0.0
                val ty = if (args.size > 1) args[1] else 0.0
                Mat(1.0, 0.0, 0.0, 1.0, tx, ty)
            }
            "scale" -> {
                val sx = if (args.isNotEmpty()) args[0] else 1.0
                val sy = if (args.size > 1) args[1] else sx
                Mat(sx, 0.0, 0.0, sy, 0.0, 0.0)
            }
            "rotate" -> {
                val ang = if (args.isNotEmpty()) Math.toRadians(args[0]) else 0.0
                val co = cos(ang); val si = sin(ang)
                if (args.size >= 3) {
                    val cx = args[1]; val cy = args[2]
                    matMul(matMul(Mat(1.0, 0.0, 0.0, 1.0, cx, cy), Mat(co, si, -si, co, 0.0, 0.0)),
                           Mat(1.0, 0.0, 0.0, 1.0, -cx, -cy))
                } else {
                    Mat(co, si, -si, co, 0.0, 0.0)
                }
            }
            "skewX" -> if (args.isNotEmpty()) Mat(1.0, 0.0, tan(Math.toRadians(args[0])), 1.0, 0.0, 0.0) else IDENTITY
            "skewY" -> if (args.isNotEmpty()) Mat(1.0, tan(Math.toRadians(args[0])), 0.0, 1.0, 0.0, 0.0) else IDENTITY
            else -> null
        }
        if (t != null) m = matMul(m, t)
    }
    return m
}

// ======================================================================
//  SVG path 'd' string -> cubic "superpath":
//  list of subpaths, each a list of SNode(inHandle, point, outHandle).
//  A straight edge has handles coincident with its own point.
// ======================================================================

class SvgParseException(message: String) : Exception(message)

class PathTokenizer(private val s: String) {
    private var i = 0
    private val n = s.length

    fun skipWs() {
        while (i < n && s[i] in " \t\r\n,") i++
    }

    fun nextCommand(): Char? {
        skipWs()
        if (i < n && s[i].isLetter()) {
            val c = s[i]
            i++
            return c
        }
        return null
    }

    fun nextNumber(): Double {
        skipWs()
        val result = NUM_REGEX.matchAt(s, i)
            ?: throw SvgParseException("expected a number at position $i in path data")
        i = result.range.last + 1
        return result.value.toDouble()
    }

    fun nextFlag(): Int {
        skipWs()
        if (i < n && (s[i] == '0' || s[i] == '1')) {
            val c = s[i]
            i++
            return c - '0'
        }
        throw SvgParseException("expected an arc flag (0/1) at position $i in path data")
    }

    fun moreArgs(): Boolean {
        skipWs()
        if (i >= n) return false
        val c = s[i]
        return c.isDigit() || c in "+-."
    }
}

typealias ArcSeg = Triple<Pt, Pt, Pt>

/**
 * SVG elliptical-arc (endpoint parameterization) -> list of
 * (ctrl1, ctrl2, end) cubic Bezier pieces, each <= 90 degrees of arc.
 * Returns an empty list if start == end (degenerate, per spec), or null if
 * the radii are (numerically) zero, meaning the caller should draw a
 * straight line instead.
 */
fun arcToCubics(x1: Double, y1: Double, rx0: Double, ry0: Double, phiDeg: Double,
                largeArc: Int, sweep: Int, x2: Double, y2: Double): List<ArcSeg>? {
    if (x1 == x2 && y1 == y2) return emptyList()
    var rx = abs(rx0)
    var ry = abs(ry0)
    if (rx < 1e-9 || ry < 1e-9) return null

    val phi = Math.toRadians(phiDeg % 360.0)
    val cosPhi = cos(phi)
    val sinPhi = sin(phi)

    val dx2 = (x1 - x2) / 2.0
    val dy2 = (y1 - y2) / 2.0
    val x1p = cosPhi * dx2 + sinPhi * dy2
    val y1p = -sinPhi * dx2 + cosPhi * dy2

    val lam = (x1p * x1p) / (rx * rx) + (y1p * y1p) / (ry * ry)
    if (lam > 1) {
        val s = sqrt(lam)
        rx *= s
        ry *= s
    }

    val num = rx * rx * ry * ry - rx * rx * y1p * y1p - ry * ry * x1p * x1p
    val den = rx * rx * y1p * y1p + ry * ry * x1p * x1p
    var co = if (den != 0.0) sqrt(max(num, 0.0) / den) else 0.0
    if (largeArc == sweep) co = -co
    val cxp = co * (rx * y1p / ry)
    val cyp = co * (-ry * x1p / rx)

    val cx = cosPhi * cxp - sinPhi * cyp + (x1 + x2) / 2.0
    val cy = sinPhi * cxp + cosPhi * cyp + (y1 + y2) / 2.0

    fun vangle(ux: Double, uy: Double, vx: Double, vy: Double): Double {
        val dot = ux * vx + uy * vy
        val length = hypot(ux, uy) * hypot(vx, vy)
        if (length == 0.0) return 0.0
        val cosang = max(-1.0, min(1.0, dot / length))
        var ang = acos(cosang)
        if (ux * vy - uy * vx < 0) ang = -ang
        return ang
    }

    val ux = (x1p - cxp) / rx
    val uy = (y1p - cyp) / ry
    val vx = (-x1p - cxp) / rx
    val vy = (-y1p - cyp) / ry
    val theta1 = vangle(1.0, 0.0, ux, uy)
    var dtheta = vangle(ux, uy, vx, vy)
    if (sweep == 0 && dtheta > 0) dtheta -= 2 * PI
    else if (sweep != 0 && dtheta < 0) dtheta += 2 * PI

    val nSegs = max(1, ceil(abs(dtheta) / (PI / 2.0) - 1e-9).toInt())
    val segAngle = dtheta / nSegs

    fun epoint(theta: Double): Pt {
        val ct = cos(theta); val st = sin(theta)
        return Pt(cx + rx * ct * cosPhi - ry * st * sinPhi,
                  cy + rx * ct * sinPhi + ry * st * cosPhi)
    }

    fun etangent(theta: Double): Pt {
        val ct = cos(theta); val st = sin(theta)
        return Pt(-rx * st * cosPhi - ry * ct * sinPhi,
                  -rx * st * sinPhi + ry * ct * cosPhi)
    }

    val alpha = (4.0 / 3.0) * tan(segAngle / 4.0)
    val segments = mutableListOf<ArcSeg>()
    var t0 = theta1
    var p0 = Pt(x1, y1)
    for (k in 0 until nSegs) {
        val t1 = t0 + segAngle
        val p1 = if (k < nSegs - 1) epoint(t1) else Pt(x2, y2)
        val d0 = etangent(t0)
        val d1 = etangent(t1)
        val c1 = Pt(p0.x + alpha * d0.x, p0.y + alpha * d0.y)
        val c2 = Pt(p1.x - alpha * d1.x, p1.y - alpha * d1.y)
        segments.add(Triple(c1, c2, p1))
        t0 = t1
        p0 = p1
    }
    return segments
}

/** One node of a cubic "superpath": [inHandle, point, outHandle]. A
 *  straight edge has handles coincident with its own point. Mutable
 *  because path parsing and curve flattening both patch handles in place,
 *  exactly like the Python original. */
class SNode(var inH: Pt, var point: Pt, var outH: Pt)

typealias Subpath = MutableList<SNode>
typealias Superpath = MutableList<Subpath>

/**
 * Parse an SVG path 'd' attribute into a list of subpaths.
 * Throws SvgParseException on malformed data.
 */
fun pathToSuperpath(d: String): Superpath {
    val tok = PathTokenizer(d)
    val subpaths: Superpath = mutableListOf()
    var cur: Subpath? = null
    var curX = 0.0
    var curY = 0.0
    var startX = 0.0
    var startY = 0.0
    var lastCubicCtrl: Pt? = null
    var lastQuadCtrl: Pt? = null

    fun newSubpath(x: Double, y: Double): Subpath {
        val p = Pt(x, y)
        val node = SNode(p, p, p)
        val sp: Subpath = mutableListOf(node)
        subpaths.add(sp)
        return sp
    }

    fun addLine(x: Double, y: Double) {
        val c = cur!!
        c[c.size - 1].outH = c[c.size - 1].point
        val p = Pt(x, y)
        c.add(SNode(p, p, p))
    }

    fun addCubic(c1: Pt, c2: Pt, end: Pt) {
        val c = cur!!
        c[c.size - 1].outH = c1
        c.add(SNode(c2, end, end))
    }

    var cmd = tok.nextCommand()
    while (cmd != null) {
        val relative = cmd.isLowerCase()
        val C = cmd.uppercaseChar()

        when (C) {
            'M' -> {
                var x = tok.nextNumber(); var y = tok.nextNumber()
                if (relative && cur != null) { x += curX; y += curY }
                curX = x; curY = y
                startX = x; startY = y
                cur = newSubpath(x, y)
                while (tok.moreArgs()) {
                    x = tok.nextNumber(); y = tok.nextNumber()
                    if (relative) { x += curX; y += curY }
                    addLine(x, y)
                    curX = x; curY = y
                }
                lastCubicCtrl = null; lastQuadCtrl = null
            }

            'L' -> {
                do {
                    var x = tok.nextNumber(); var y = tok.nextNumber()
                    if (relative) { x += curX; y += curY }
                    addLine(x, y)
                    curX = x; curY = y
                } while (tok.moreArgs())
                lastCubicCtrl = null; lastQuadCtrl = null
            }

            'H' -> {
                do {
                    var x = tok.nextNumber()
                    if (relative) x += curX
                    addLine(x, curY)
                    curX = x
                } while (tok.moreArgs())
                lastCubicCtrl = null; lastQuadCtrl = null
            }

            'V' -> {
                do {
                    var y = tok.nextNumber()
                    if (relative) y += curY
                    addLine(curX, y)
                    curY = y
                } while (tok.moreArgs())
                lastCubicCtrl = null; lastQuadCtrl = null
            }

            'C' -> {
                do {
                    var x1 = tok.nextNumber(); var y1 = tok.nextNumber()
                    var x2 = tok.nextNumber(); var y2 = tok.nextNumber()
                    var x = tok.nextNumber(); var y = tok.nextNumber()
                    if (relative) {
                        x1 += curX; y1 += curY; x2 += curX; y2 += curY; x += curX; y += curY
                    }
                    addCubic(Pt(x1, y1), Pt(x2, y2), Pt(x, y))
                    lastCubicCtrl = Pt(x2, y2)
                    curX = x; curY = y
                } while (tok.moreArgs())
                lastQuadCtrl = null
            }

            'S' -> {
                do {
                    var x2 = tok.nextNumber(); var y2 = tok.nextNumber()
                    var x = tok.nextNumber(); var y = tok.nextNumber()
                    if (relative) { x2 += curX; y2 += curY; x += curX; y += curY }
                    val (x1, y1) = if (lastCubicCtrl != null)
                        Pair(2 * curX - lastCubicCtrl.x, 2 * curY - lastCubicCtrl.y)
                    else Pair(curX, curY)
                    addCubic(Pt(x1, y1), Pt(x2, y2), Pt(x, y))
                    lastCubicCtrl = Pt(x2, y2)
                    curX = x; curY = y
                } while (tok.moreArgs())
                lastQuadCtrl = null
            }

            'Q' -> {
                do {
                    var x1 = tok.nextNumber(); var y1 = tok.nextNumber()
                    var x = tok.nextNumber(); var y = tok.nextNumber()
                    if (relative) { x1 += curX; y1 += curY; x += curX; y += curY }
                    val c1 = Pt(curX + 2.0 / 3.0 * (x1 - curX), curY + 2.0 / 3.0 * (y1 - curY))
                    val c2 = Pt(x + 2.0 / 3.0 * (x1 - x), y + 2.0 / 3.0 * (y1 - y))
                    addCubic(c1, c2, Pt(x, y))
                    lastQuadCtrl = Pt(x1, y1)
                    curX = x; curY = y
                } while (tok.moreArgs())
                lastCubicCtrl = null
            }

            'T' -> {
                do {
                    var x = tok.nextNumber(); var y = tok.nextNumber()
                    if (relative) { x += curX; y += curY }
                    val (x1, y1) = if (lastQuadCtrl != null)
                        Pair(2 * curX - lastQuadCtrl.x, 2 * curY - lastQuadCtrl.y)
                    else Pair(curX, curY)
                    val c1 = Pt(curX + 2.0 / 3.0 * (x1 - curX), curY + 2.0 / 3.0 * (y1 - curY))
                    val c2 = Pt(x + 2.0 / 3.0 * (x1 - x), y + 2.0 / 3.0 * (y1 - y))
                    addCubic(c1, c2, Pt(x, y))
                    lastQuadCtrl = Pt(x1, y1)
                    curX = x; curY = y
                } while (tok.moreArgs())
                lastCubicCtrl = null
            }

            'A' -> {
                do {
                    val rx = tok.nextNumber(); val ry = tok.nextNumber()
                    val phi = tok.nextNumber()
                    val large = tok.nextFlag(); val sweep = tok.nextFlag()
                    var x = tok.nextNumber(); var y = tok.nextNumber()
                    if (relative) { x += curX; y += curY }
                    val beziers = arcToCubics(curX, curY, rx, ry, phi, large, sweep, x, y)
                    if (beziers == null) {
                        addLine(x, y)
                    } else {
                        for ((c1, c2, end) in beziers) addCubic(c1, c2, end)
                    }
                    curX = x; curY = y
                } while (tok.moreArgs())
                lastCubicCtrl = null; lastQuadCtrl = null
            }

            'Z' -> {
                if (cur != null && (curX != startX || curY != startY)) {
                    addLine(startX, startY)
                }
                curX = startX; curY = startY
                lastCubicCtrl = null; lastQuadCtrl = null
            }

            else -> throw SvgParseException("unsupported path command '$cmd'")
        }

        cmd = tok.nextCommand()
    }

    return subpaths
}

fun transformSuperpath(matrix: Mat, subpaths: Superpath): Superpath {
    val out: Superpath = mutableListOf()
    for (sp in subpaths) {
        val newSp: Subpath = mutableListOf()
        for (node in sp) {
            newSp.add(SNode(applyPoint(matrix, node.inH), applyPoint(matrix, node.point), applyPoint(matrix, node.outH)))
        }
        out.add(newSp)
    }
    return out
}

// ======================================================================
//  Adaptive flattening: cubic Bezier subpath -> polyline
// ======================================================================

const val MAX_SUBDIV_NODES = 200_000 // safety cap against pathological/degenerate curves

private fun tpoint(p1: Pt, p2: Pt, t: Double): Pt = Pt(p1.x + t * (p2.x - p1.x), p1.y + t * (p2.y - p1.y))

private fun splitCubic(p0: Pt, p1: Pt, p2: Pt, p3: Pt, t: Double = 0.5): Pair<List<Pt>, List<Pt>> {
    val m1 = tpoint(p0, p1, t); val m2 = tpoint(p1, p2, t); val m3 = tpoint(p2, p3, t)
    val m4 = tpoint(m1, m2, t); val m5 = tpoint(m2, m3, t)
    val m = tpoint(m4, m5, t)
    return Pair(listOf(p0, m1, m4, m), listOf(m, m5, m3, p3))
}

private fun pointSegDistance(px: Double, py: Double, ax: Double, ay: Double, bx: Double, by: Double): Double {
    val dx = bx - ax; val dy = by - ay
    val segLen2 = dx * dx + dy * dy
    if (segLen2 == 0.0) return hypot(px - ax, py - ay)
    val t = ((px - ax) * dx + (py - ay) * dy) / segLen2
    if (t <= 0) return hypot(px - ax, py - ay)
    if (t >= 1) return hypot(px - bx, py - by)
    return hypot(px - (ax + t * dx), py - (ay + t * dy))
}

private fun maxdist(p0: Pt, p1: Pt, p2: Pt, p3: Pt): Double =
    max(pointSegDistance(p1.x, p1.y, p0.x, p0.y, p3.x, p3.y),
        pointSegDistance(p2.x, p2.y, p0.x, p0.y, p3.x, p3.y))

/** subpath: list of [in, point, out] nodes. Returns the flattened list of (x, y) vertices. */
fun flattenSubpath(subpath: Subpath, flatness: Double): List<Pt> {
    val sp: MutableList<Array<Pt>> = mutableListOf()
    for (node in subpath) sp.add(arrayOf(node.inH, node.point, node.outH))
    var i = 1
    while (i < sp.size) {
        val p0 = sp[i - 1][1]; val p1 = sp[i - 1][2]; val p2 = sp[i][0]; val p3 = sp[i][1]
        if (maxdist(p0, p1, p2, p3) <= flatness || sp.size >= MAX_SUBDIV_NODES) {
            i++
        } else {
            val (left, right) = splitCubic(p0, p1, p2, p3, 0.5)
            sp[i - 1][2] = left[1]
            sp[i][0] = right[2]
            sp.add(i, arrayOf(left[2], left[3], right[1]))
        }
    }
    return sp.map { it[1] }
}

// ======================================================================
//  Basic shapes -> superpath (rect/line/polyline/polygon/circle/ellipse)
// ======================================================================

fun attrNum(el: Element, name: String, default: Double = 0.0): Double {
    val v = el.getAttribute(name)
    if (v.isEmpty()) return default
    val trimmed = v.trim()
    val result = NUM_REGEX.matchAt(trimmed, 0) ?: return default
    return result.value.toDoubleOrNull() ?: default
}

fun rectSuperpath(node: Element): Superpath? {
    val x = attrNum(node, "x"); val y = attrNum(node, "y")
    val w = attrNum(node, "width"); val h = attrNum(node, "height")
    if (w <= 0 || h <= 0) return null
    val p0 = Pt(x, y); val p1 = Pt(x + w, y); val p2 = Pt(x + w, y + h); val p3 = Pt(x, y + h)
    val sp: Subpath = mutableListOf(
        SNode(p0, p0, p0), SNode(p1, p1, p1), SNode(p2, p2, p2), SNode(p3, p3, p3), SNode(p0, p0, p0)
    )
    return mutableListOf(sp)
}

fun lineSuperpath(node: Element): Superpath {
    val p0 = Pt(attrNum(node, "x1"), attrNum(node, "y1"))
    val p1 = Pt(attrNum(node, "x2"), attrNum(node, "y2"))
    val sp: Subpath = mutableListOf(SNode(p0, p0, p0), SNode(p1, p1, p1))
    return mutableListOf(sp)
}

fun polylineSuperpath(node: Element, close: Boolean): Superpath? {
    val coords = nums(node.getAttribute("points"))
    val pts = mutableListOf<Pt>()
    var idx = 0
    while (idx + 1 < coords.size) {
        pts.add(Pt(coords[idx], coords[idx + 1]))
        idx += 2
    }
    if (pts.size < 2) return null
    val sp: Subpath = mutableListOf()
    for (p in pts) sp.add(SNode(p, p, p))
    if (close && (pts.first().x != pts.last().x || pts.first().y != pts.last().y)) {
        val p0 = pts.first()
        sp.add(SNode(p0, p0, p0))
    }
    return mutableListOf(sp)
}

const val KAPPA = 0.5522847498307936 // 4/3 * (sqrt(2) - 1), standard circle/ellipse Bezier constant

fun ellipseSuperpathXY(cx: Double, cy: Double, rx: Double, ry: Double): Superpath? {
    if (rx <= 0 || ry <= 0) return null
    val k = KAPPA
    val p0 = Pt(cx + rx, cy); val p1 = Pt(cx, cy + ry); val p2 = Pt(cx - rx, cy); val p3 = Pt(cx, cy - ry)
    val c0o = Pt(cx + rx, cy + ry * k); val c1i = Pt(cx + rx * k, cy + ry)
    val c1o = Pt(cx - rx * k, cy + ry); val c2i = Pt(cx - rx, cy + ry * k)
    val c2o = Pt(cx - rx, cy - ry * k); val c3i = Pt(cx - rx * k, cy - ry)
    val c3o = Pt(cx + rx * k, cy - ry); val c0i = Pt(cx + rx, cy - ry * k)
    val sp: Subpath = mutableListOf(
        SNode(c0i, p0, c0o),
        SNode(c1i, p1, c1o),
        SNode(c2i, p2, c2o),
        SNode(c3i, p3, c3o),
        SNode(c0i, p0, p0)
    )
    return mutableListOf(sp)
}

fun circleSuperpath(node: Element): Superpath? {
    val r = attrNum(node, "r")
    return ellipseSuperpathXY(attrNum(node, "cx"), attrNum(node, "cy"), r, r)
}

fun ellipseShapeSuperpath(node: Element): Superpath? =
    ellipseSuperpathXY(attrNum(node, "cx"), attrNum(node, "cy"), attrNum(node, "rx"), attrNum(node, "ry"))

val DRAWABLE_TAGS = setOf("path", "rect", "line", "polyline", "polygon", "circle", "ellipse")

fun shapeToSuperpath(tag: String, node: Element): Superpath? = when (tag) {
    "path" -> pathToSuperpath(node.getAttribute("d"))
    "rect" -> rectSuperpath(node)
    "line" -> lineSuperpath(node)
    "polyline" -> polylineSuperpath(node, close = false)
    "polygon" -> polylineSuperpath(node, close = true)
    "circle" -> circleSuperpath(node)
    "ellipse" -> ellipseShapeSuperpath(node)
    else -> null
}

fun strokeLabel(tag: String): String = when (tag) {
    "path" -> "Path"; "rect" -> "Rectangle"; "line" -> "Line"; "polyline" -> "Polyline"
    "polygon" -> "Polygon"; "circle" -> "Circle"; "ellipse" -> "Ellipse"
    else -> tag
}

// Elements that are never drawn directly (templates, metadata, styling, etc.)
val IGNORED_TAGS = setOf(
    "defs", "symbol", "clipPath", "mask", "linearGradient", "radialGradient",
    "pattern", "filter", "style", "script", "title", "desc", "marker",
    "metadata", "namedview", "guide", "grid", "eggbot", "font", "glyph"
)

const val XLINK_NS = "http://www.w3.org/1999/xlink"
const val INKSCAPE_NS = "http://www.inkscape.org/namespaces/inkscape"

/**
 * True if this node (and hence its subtree) should not be drawn.
 * Checks `display:none` in `style=` (the way Inkscape actually hides a
 * layer), the `display` attribute, and the `visibility` attribute; falls
 * back to the inherited state from the parent.
 */
fun nodeVisibility(node: Element, parentHidden: Boolean): Boolean {
    val style = node.getAttribute("style")
    if (Regex("""display\s*:\s*none\b""").containsMatchIn(style)) return true
    val disp = node.getAttribute("display")
    if (disp == "none") return true
    if (disp == "inline") return false
    val vis = node.getAttribute("visibility")
    if (vis == "hidden" || vis == "collapse") return true
    if (vis == "visible") return false
    return parentHidden
}

// ======================================================================
//  Length / unit parsing and the document root transform
// ======================================================================

private val LENGTH_REGEX = Regex(
    """^\s*([-+]?(?:\d+\.\d*|\.\d+|\d+)(?:[eE][-+]?\d+)?)\s*(px|mm|cm|in|pt|pc|%)?\s*$""")

fun lengthToPx(value: String?, dpi: Double, defaultPx: Double, percentRefPx: Double? = null): Double {
    if (value.isNullOrEmpty()) return defaultPx
    val m = LENGTH_REGEX.find(value) ?: return defaultPx
    val num = m.groupValues[1].toDouble()
    val unit = m.groupValues[2].ifEmpty { "px" }
    if (unit == "px") return num
    if (unit == "%") {
        val ref = percentRefPx ?: defaultPx
        return ref * num / 100.0
    }
    val inchesPerUnit = when (unit) {
        "in" -> 1.0; "cm" -> 1.0 / 2.54; "mm" -> 1.0 / 25.4
        "pt" -> 1.0 / 72.0; "pc" -> 1.0 / 6.0
        else -> return defaultPx
    }
    return num * inchesPerUnit * dpi
}

/**
 * Return the transform that maps this document's raw user-unit coordinates
 * (the space path data/x/y attributes live in) into millimetres, flips Y,
 * and centers the artwork on the origin. Honours `viewBox` when present;
 * otherwise 1 user unit = 1 px at `dpi`, matching plain SVG semantics.
 */
fun documentRootTransform(svgRoot: Element, dpi: Double, defaultUu: Double = 354.0): Mat {
    val viewboxAttr = svgRoot.getAttribute("viewBox").ifEmpty { svgRoot.getAttribute("viewbox") }
    var vb: DoubleArray? = null
    if (viewboxAttr.isNotEmpty()) {
        val parts = nums(viewboxAttr)
        if (parts.size == 4) vb = parts.toDoubleArray()
    }

    val widthAttr = svgRoot.getAttribute("width").orNullIfEmpty()
    val heightAttr = svgRoot.getAttribute("height").orNullIfEmpty()

    val vbX: Double; val vbY: Double; val vbW: Double; val vbH: Double
    val widthPx: Double; val heightPx: Double

    if (vb != null) {
        vbX = vb[0]; vbY = vb[1]; vbW = vb[2]; vbH = vb[3]
        widthPx = if (widthAttr != null) lengthToPx(widthAttr, dpi, vbW) else vbW
        heightPx = if (heightAttr != null) lengthToPx(heightAttr, dpi, vbH) else vbH
    } else {
        vbX = 0.0; vbY = 0.0
        vbW = if (widthAttr != null) lengthToPx(widthAttr, dpi, defaultUu) else defaultUu
        vbH = if (heightAttr != null) lengthToPx(heightAttr, dpi, defaultUu) else defaultUu
        widthPx = vbW; heightPx = vbH
    }

    val mmPerPx = 25.4 / dpi
    val widthMm = widthPx * mmPerPx
    val heightMm = heightPx * mmPerPx
    val scaleX = if (vbW != 0.0) widthMm / vbW else mmPerPx
    val scaleY = if (vbH != 0.0) heightMm / vbH else mmPerPx

    val a = scaleX
    val d = -scaleY
    val e = -scaleX * vbX - widthMm / 2.0
    val f = scaleY * vbY + heightMm / 2.0
    return Mat(a, 0.0, 0.0, d, e, f)
}

// ======================================================================
//  SVG document walker: transform, <use>, layers, visibility -> "events"
// ======================================================================

sealed class Event
data class StrokeEvent(val label: String, val points: List<Pt>) : Event()
data class LayerEvent(val name: String) : Event()

fun elementChildren(node: Node): List<Element> {
    val result = mutableListOf<Element>()
    val children = node.childNodes
    for (i in 0 until children.length) {
        val child = children.item(i)
        if (child.nodeType == Node.ELEMENT_NODE) result.add(child as Element)
    }
    return result
}

fun localTag(el: Element): String = el.localName ?: el.tagName

/**
 * Walks the SVG tree and collects a flat list of "events" in document
 * order: StrokeEvent for every drawable polyline, and LayerEvent markers
 * when pauseOnLayerChange is requested.
 */
class SvgWalker(private val idMap: Map<String, Element>, private val flatness: Double,
                private val pauseOnLayerChange: Boolean) {

    val events: MutableList<Event> = mutableListOf()
    private val warnedTags = mutableSetOf<String>()
    private val groupTags = setOf("g", "a", "svg")

    private fun warnOnce(key: String, message: String) {
        if (warnedTags.add(key)) {
            System.err.println("Warning: $message")
        }
    }

    fun walk(node: Element, matrix: Mat, hidden: Boolean, useStack: Set<String>) {
        for (child in elementChildren(node)) {
            val tag = localTag(child)

            val childHidden = nodeVisibility(child, hidden)
            val ownXf = parseTransform(child.getAttribute("transform").orNullIfEmpty())
            val childMatrix = matMul(matrix, ownXf)

            if (tag in IGNORED_TAGS || childHidden) continue

            if (tag in groupTags) {
                if (child.getAttributeNS(INKSCAPE_NS, "groupmode") == "layer" && pauseOnLayerChange) {
                    val label = child.getAttributeNS(INKSCAPE_NS, "label").ifEmpty { child.getAttribute("id") }
                    events.add(LayerEvent(label))
                }
                walk(child, childMatrix, childHidden, useStack)
                continue
            }

            if (tag == "use") {
                handleUse(child, childMatrix, childHidden, useStack)
                continue
            }

            if (tag in DRAWABLE_TAGS) {
                emitShape(child, tag, childMatrix)
                continue
            }

            if (tag == "text" || tag == "tspan" || tag == "flowRoot") {
                warnOnce("text", "<text> elements are not supported; convert text to paths first (skipped).")
                continue
            }

            if (tag == "image") {
                warnOnce("image", "<image> (raster) elements are not supported (skipped).")
                continue
            }

            warnOnce(tag, "unsupported element <$tag> (skipped).")
        }
    }

    private fun handleUse(node: Element, matrix: Mat, hidden: Boolean, useStack: Set<String>) {
        val href = node.getAttributeNS(XLINK_NS, "href").ifEmpty { node.getAttribute("href") }
        if (href.isEmpty() || !href.startsWith("#")) return
        val targetId = href.substring(1)
        if (targetId in useStack) return // cyclic <use> reference; ignore rather than recurse forever
        val target = idMap[targetId] ?: return
        val ux = attrNum(node, "x"); val uy = attrNum(node, "y")
        val useMatrix = if (ux == 0.0 && uy == 0.0) matrix else matMul(matrix, Mat(1.0, 0.0, 0.0, 1.0, ux, uy))
        val targetTag = localTag(target)
        val targetHidden = nodeVisibility(target, hidden)
        if (targetHidden) return
        val targetMatrix = matMul(useMatrix, parseTransform(target.getAttribute("transform").orNullIfEmpty()))
        val newStack = useStack + targetId
        if (targetTag in groupTags || targetTag == "symbol") {
            walk(target, targetMatrix, targetHidden, newStack)
        } else if (targetTag in DRAWABLE_TAGS) {
            emitShape(target, targetTag, targetMatrix)
        }
    }

    private fun emitShape(node: Element, tag: String, matrix: Mat) {
        val raw: Superpath? = try {
            shapeToSuperpath(tag, node)
        } catch (exc: Exception) {
            System.err.println("Warning: could not parse <$tag>: ${exc.message} (skipped).")
            return
        }
        if (raw.isNullOrEmpty()) return
        val label = strokeLabel(tag)
        for (sp in transformSuperpath(matrix, raw)) {
            if (sp.size < 2) continue
            val pts = flattenSubpath(sp, flatness)
            if (pts.size >= 2) events.add(StrokeEvent(label, pts))
        }
    }
}

// ======================================================================
//  G-code generation (Unicorn/EggBot-style dialect)
// ======================================================================

class GCodeBuilder(private val o: Args, private val svgFilename: String, private val argvForComment: List<String>) {
    private var drawing = false
    private var last: Pt? = null
    private var lines: MutableList<String> = mutableListOf()

    // -- pen state -----------------------------------------------------
    private fun penUp() {
        lines.add(fmt("M300 S%.2f (pen up)", o.penUpAngle))
        lines.add(fmt("G4 P%d (wait %dms)", o.stopDelay, o.stopDelay))
        drawing = false
    }

    private fun penDown() {
        lines.add(fmt("M300 S%.2f (pen down)", o.penDownAngle))
        lines.add(fmt("G4 P%d (wait %dms)", o.startDelay, o.startDelay))
        drawing = true
    }

    private fun travelTo(x: Double, y: Double) {
        if (last == Pt(x, y)) return
        if (drawing) penUp()
        lines.add(fmt("G1 X%.2f Y%.2f F%.2f", x, y, o.xyFeedrate))
        last = Pt(x, y)
    }

    private fun drawTo(x: Double, y: Double) {
        if (last == Pt(x, y)) return
        if (!drawing) penDown()
        lines.add(fmt("G1 X%.2f Y%.2f F%.2f", x, y, o.xyFeedrate))
        last = Pt(x, y)
    }

    // -- fixed code blocks ----------------------------------------------
    private fun preamble(): List<String> = listOf(
        "(Generated from $svgFilename)",
        "( ${argvForComment.joinToString(" ")} )",
        "G21 (metric ftw)",
        "G90 (absolute mode)",
        fmt("G92 X%.2f Y%.2f Z%.2f (you are here)", o.xHome, o.yHome, o.zHeight),
        ""
    )

    private fun registration(): List<String> = listOf(
        fmt("M300 S%d (pen down)", o.penDownAngle.toInt()),
        fmt("G4 P%d (wait %dms)", o.startDelay, o.startDelay),
        fmt("M300 S%d (pen up)", o.penUpAngle.toInt()),
        fmt("G4 P%d (wait %dms)", o.stopDelay, o.stopDelay),
        "M18 (disengage drives)",
        "M01 (Was registration test successful?)",
        "M17 (engage drives if YES, and continue)",
        ""
    )

    private fun sheetHeader(): List<String> {
        val lines = mutableListOf(
            "(start of sheet header)",
            fmt("G92 X%.2f Y%.2f Z%.2f (you are here)", o.xHome, o.yHome, o.zHeight)
        )
        if (o.registerPen) lines.addAll(registration())
        lines.add("(end of sheet header)")
        return lines
    }

    private fun sheetFooter(): List<String> = listOf(
        "(Start of sheet footer.)",
        fmt("M300 S%d (pen up)", o.penUpAngle.toInt()),
        fmt("G4 P%d (wait %dms)", o.stopDelay, o.stopDelay),
        "G91 (relative mode)",
        fmt("G0 Z15 F%.2f", o.zFeedrate),
        "G90 (absolute mode)",
        fmt("G0 X%.2f Y%.2f F%.2f", o.xHome, o.yHome, o.xyFeedrate),
        "M01 (Have you retrieved the print?)",
        "(machine halts until 'okay')",
        fmt("G4 P%d (wait %dms)", o.startDelay, o.startDelay),
        "G91 (relative mode)",
        fmt("G0 Z-15 F%.2f (return to start position of current sheet)", o.zFeedrate),
        fmt("G0 Z-0.01 F%.2f (move down one sheet)", o.zFeedrate),
        "G90 (absolute mode)",
        "M18 (disengage drives)",
        "(End of sheet footer)"
    )

    private fun postscript(): List<String> = listOf(
        "",
        "(end of print job)",
        fmt("M300 S%.2f (pen up)", o.penUpAngle),
        fmt("G4 P%d (wait %dms)", o.stopDelay, o.stopDelay),
        "M300 S255 (turn off servo)",
        fmt("G1 X0 Y0 F%.2f", o.xyFeedrate),
        fmt("G1 Z%.2f F%.2f (go up to finished level)", o.finishedHeight, o.zFeedrate),
        fmt("G1 X%.2f Y%.2f F%.2f (go home)", o.xHome, o.yHome, o.xyFeedrate),
        "M18 (drives off)"
    )

    // -- drawing ----------------------------------------------------------
    private fun emitEvents(events: List<Event>) {
        for (event in events) {
            when (event) {
                is LayerEvent -> lines.add("M01 (Plotting layer '${event.name}')")
                is StrokeEvent -> {
                    lines.add("(${event.label}: ${event.points.size} points)")
                    val (x0, y0) = event.points[0]
                    travelTo(x0, y0)
                    for (i in 1 until event.points.size) {
                        val (x, y) = event.points[i]
                        drawTo(x, y)
                    }
                    if (drawing) penUp()
                    lines.add("")
                }
            }
        }
    }

    fun build(events: List<Event>): List<String> {
        val multi = o.continuous || o.numCopies > 1
        val numPages = if (o.continuous) 1 else max(1, o.numCopies)
        val out = mutableListOf<String>()
        for (page in 0 until numPages) {
            out.addAll(preamble())
            if (multi) out.addAll(sheetHeader())
            else if (o.registerPen) out.addAll(registration())
            lines = mutableListOf()
            drawing = false
            last = null
            emitEvents(events)
            out.addAll(lines)
            if (multi) out.addAll(sheetFooter())
            out.addAll(postscript())
        }
        if (o.continuous) out.add("M30 (Plot again?)")
        return out
    }
}

// ======================================================================
//  Post-processing: normalize into a target range, then thin points
// ======================================================================

private val G1_REGEX = Regex("""^G1 X(-?[\d.]+) Y(-?[\d.]+)""")
private val STROKE_HEADER_REGEX = Regex("""^\(.+: \d+ points\)$""")

data class Coord(val matchEnd: Int, val x: Double, val y: Double)
data class TaggedLine(val line: String, val coord: Coord?)

/**
 * Walk `lines` and, for each one, produce a TaggedLine whose `coord` is set
 * if -- and only if -- the line is a `G1 X.. Y..` move that belongs to a
 * drawn stroke (i.e. sits between a "(Label: N points)" header and the
 * blank line that ends that stroke's block). `coord` is null for every
 * other line, including the fixed preamble/postscript/sheet-footer moves
 * (e.g. the "go home" G1 at the end), which must NOT be swept up by
 * normalize/reduce.
 */
fun strokeScopedCoords(lines: List<String>): List<TaggedLine> {
    val result = mutableListOf<TaggedLine>()
    var inStroke = false
    for (line in lines) {
        if (STROKE_HEADER_REGEX.matches(line)) {
            inStroke = true
            result.add(TaggedLine(line, null))
            continue
        }
        if (inStroke && line == "") {
            inStroke = false
            result.add(TaggedLine(line, null))
            continue
        }
        if (inStroke) {
            val m = G1_REGEX.find(line)
            if (m != null) {
                val end = m.range.last + 1
                result.add(TaggedLine(line, Coord(end, m.groupValues[1].toDouble(), m.groupValues[2].toDouble())))
                continue
            }
        }
        result.add(TaggedLine(line, null))
    }
    return result
}

/**
 * Rescale every in-stroke G1 X/Y pair so the drawing's bounding box maps
 * onto [newMin, newMax] on each axis independently. Fixed-purpose moves
 * outside of a stroke (homing, travel to 0,0, etc.) are left as-is.
 */
fun normalizeLines(lines: List<String>, newMin: Double, newMax: Double): List<String> {
    val tagged = strokeScopedCoords(lines)
    val xs = tagged.mapNotNull { it.coord?.x }
    val ys = tagged.mapNotNull { it.coord?.y }
    if (xs.isEmpty()) return lines.toList()
    val xLo = xs.min(); val xHi = xs.max()
    val yLo = ys.min(); val yHi = ys.max()

    fun remap(v: Double, lo: Double, hi: Double): Double {
        // degenerate (all-one-value) axis: fixed the original ZeroDivisionError
        if (hi - lo < 1e-9) return (newMin + newMax) / 2.0
        return (v - lo) / (hi - lo) * (newMax - newMin) + newMin
    }

    val out = mutableListOf<String>()
    for (t in tagged) {
        val c = t.coord
        if (c == null) {
            out.add(t.line)
        } else {
            val nx = remap(c.x, xLo, xHi)
            val ny = remap(c.y, yLo, yHi)
            out.add(fmt("G1 X%.2f Y%.2f", nx, ny) + t.line.substring(c.matchEnd))
        }
    }
    return out
}

/**
 * Thin consecutive in-stroke points that move less than `minChange` mm,
 * forcing a kept point at least every `skipFactor` skips. Always keeps the
 * true last point of the stroke, even if it was about to be thinned away,
 * and leaves non-stroke G1 moves (homing, etc.) untouched.
 */
fun reduceLines(lines: List<String>, minChange: Double, skipFactor: Int): List<String> {
    fun significant(a: Pt, b: Pt): Boolean = abs(a.x - b.x) > minChange || abs(a.y - b.y) > minChange

    val out = mutableListOf<String>()
    var prev: Pt? = null
    var skipCount = 0
    var pending: String? = null // most recently dropped line, in case it's actually the stroke's last point
    var tracking = false // true only while inside a stroke's run of G1 points

    for (t in strokeScopedCoords(lines)) {
        val line = t.line
        val c = t.coord
        if (STROKE_HEADER_REGEX.matches(line)) {
            prev = null; skipCount = 0; pending = null; tracking = true
            out.add(line)
            continue
        }
        if (c == null) {
            if (tracking && line == "") {
                if (pending != null) {
                    out.add(pending)
                    pending = null
                }
                tracking = false
            }
            out.add(line)
            continue
        }
        val cur = Pt(c.x, c.y)
        if (prev == null || significant(prev, cur) || skipCount >= skipFactor) {
            out.add(line)
            prev = cur; skipCount = 0; pending = null
        } else {
            skipCount++
            pending = line
        }
    }

    if (pending != null) out.add(pending)
    return out
}

// ======================================================================
//  Args: every parameter the original CLI accepted, now bound directly to
//  the app's UI state instead of being parsed from argv.
// ======================================================================

class Args {
    var svgFile: String = ""
    var output: String? = null
    var penUpAngle: Double = 50.0
    var penDownAngle: Double = 30.0
    var startDelay: Int = 150
    var stopDelay: Int = 150
    var registerPen: Boolean = true
    var xyFeedrate: Double = 3500.0
    var zFeedrate: Double = 150.0
    var zHeight: Double = 0.0
    var finishedHeight: Double = 0.0
    var xHome: Double = 0.0
    var yHome: Double = 0.0
    var numCopies: Int = 1
    var continuous: Boolean = false
    var pauseOnLayerChange: Boolean = false
    var tab: String? = null
    var flatness: Double = 0.2
    var dpi: Double = 96.0
    var minChange: Double = 0.5
    var skipFactor: Int = 3
    var newMin: Double = 0.0
    var newMax: Double = 40.0
    var noNormalize: Boolean = false
    var noReduce: Boolean = false
}

fun basename(path: String): String = path.substringAfterLast('/').substringAfterLast('\\')

fun defaultOutputPath(svgFile: String): String {
    val sepIndex = svgFile.lastIndexOfAny(charArrayOf('/', '\\'))
    val dir = if (sepIndex >= 0) svgFile.substring(0, sepIndex + 1) else ""
    val base = if (sepIndex >= 0) svgFile.substring(sepIndex + 1) else svgFile
    val dotIndex = base.lastIndexOf('.')
    val baseNoExt = if (dotIndex > 0) base.substring(0, dotIndex) else base
    return dir + baseNoExt + ".gcode"
}

/** A namespace-aware DOM builder that never fetches an external DTD/entity
 *  over the network (SVG files sometimes carry an old DOCTYPE pointing at
 *  the W3C SVG 1.0 DTD; this keeps parsing fast and fully offline). */
fun newDocumentBuilder(): DocumentBuilder {
    val dbf = DocumentBuilderFactory.newInstance()
    dbf.isNamespaceAware = true
    dbf.isValidating = false
    // ANDROID PORT NOTE: Android's JAXP implementation does not support XInclude at
    // all and throws UnsupportedOperationException ("This parser does not support
    // specification "Unknown" version "0.0"") even for setXIncludeAware(false),
    // which is fine on a desktop JVM. Guarded so it stays a no-op where unsupported.
    try { dbf.isXIncludeAware = false } catch (e: Exception) { /* unsupported on Android; nothing to disable */ }
    try { dbf.isExpandEntityReferences = false } catch (e: Exception) { /* not supported by this JAXP impl; ignore */ }
    val features = listOf(
        "http://apache.org/xml/features/nonvalidating/load-external-dtd" to false,
        "http://xml.org/sax/features/external-general-entities" to false,
        "http://xml.org/sax/features/external-parameter-entities" to false
    )
    for ((name, value) in features) {
        try { dbf.setFeature(name, value) } catch (e: Exception) { /* not supported by this JAXP impl; ignore */ }
    }
    val builder = dbf.newDocumentBuilder()
    builder.setEntityResolver { _, _ -> InputSource(StringReader("")) }
    return builder
}

// =============================================================================
// ANDROID PORT NOTE: the original file ended with a `fun main(args: Array
// <String>)` CLI entry point that parsed argv into an `Args`, ran the
// pipeline below, and wrote the result to stdout or a file before calling
// exitProcess(). None of that argv/exit-code machinery makes sense inside
// an Android app, so it is replaced with `svgFileToGcode` below: the exact
// same pipeline (parse -> walk -> build -> normalize -> reduce), minus the
// CLI plumbing, returning the finished G-code as a String plus a small
// result summary for the UI. Every step, and every default in `Args`, is
// unchanged from the original main().
// =============================================================================

/** Non-fatal summary of one G-code generation run, for status UI. */
data class GcodeResult(
    val gcode: String,
    val lineCount: Int,
    val shapeCount: Int,
    val noDrawableShapesFound: Boolean
)

/**
 * Convert an already-on-disk SVG file into Unicorn/EggBot-style G-code,
 * exactly as the original CLI's `main()` did for a single (non-continuous,
 * single-copy-loop-independent) run. `args.svgFile` is informational only
 * (used for the `(Generated from ...)` comment and the default output name
 * some callers may still want); the file actually read is `svgFile`.
 *
 * Throws on a malformed SVG (mirrors the original's "could not parse as
 * XML" failure) -- callers (the app's ViewModel) should catch and surface
 * that as a status/error message instead of a process exit code.
 */
fun svgFileToGcode(svgFile: File, args: Args): GcodeResult {
    require(svgFile.exists() && svgFile.isFile) { "No such file: ${svgFile.path}" }

    val document: Document = newDocumentBuilder().parse(svgFile)
    document.documentElement.normalize()
    val root = document.documentElement

    val idMap = HashMap<String, Element>()
    val allElements = document.getElementsByTagName("*")
    for (i in 0 until allElements.length) {
        val el = allElements.item(i) as Element
        val id = el.getAttribute("id")
        if (id.isNotEmpty()) idMap[id] = el
    }

    val rootMatrix = documentRootTransform(root, args.dpi)
    val walker = SvgWalker(idMap, args.flatness, args.pauseOnLayerChange)
    walker.walk(root, rootMatrix, false, emptySet())

    val noShapes = walker.events.isEmpty()

    val argvForComment = listOf(PROG, basename(svgFile.path))
    val builder = GCodeBuilder(args, basename(svgFile.path), argvForComment)
    var lines = builder.build(walker.events)

    if (!args.noNormalize) lines = normalizeLines(lines, args.newMin, args.newMax)
    if (!args.noReduce) lines = reduceLines(lines, args.minChange, args.skipFactor)

    val text = lines.joinToString("\n") + "\n"
    return GcodeResult(
        gcode = text,
        lineCount = lines.size,
        shapeCount = walker.events.count { it is StrokeEvent },
        noDrawableShapesFound = noShapes
    )
}
