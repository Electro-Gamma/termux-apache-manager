package com.vectorforge.app.sender

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException
import java.util.UUID

/**
 * A byte pipe to the machine. Three implementations: Bluetooth Classic SPP (HC-05 / HC-06 style modules),
 * a TCP socket (ESP8266 / ESP32 "serial over Wi-Fi" bridges) and a native USB-OTG CDC-ACM port
 * (Arduino Uno R3 / Mega / Leonardo / Nano Every ... boards whose USB chip speaks standard CDC-ACM).
 *
 * All calls are blocking and are made from background threads; [close] may be called from any thread and must
 * make a blocked [read] return (or throw) promptly.
 */
interface SerialLink {
    /** Human-readable name for the status line. */
    val label: String

    /** How long the machine needs after the port opens before it listens (USB toggles DTR, which resets an Arduino). */
    val settleMillis: Long

    @Throws(IOException::class)
    fun open()

    @Throws(IOException::class)
    fun write(data: ByteArray)

    /** Returns the number of bytes read, 0 on a short timeout (nothing yet), or -1 when the link is closed. */
    @Throws(IOException::class)
    fun read(buffer: ByteArray): Int

    fun close()
}

// ---------------------------------------------------------------------------------------------------------------
// Bluetooth Classic (RFCOMM / SPP)
// ---------------------------------------------------------------------------------------------------------------

class BluetoothSerialLink(private val device: BluetoothDevice, private val deviceName: String) : SerialLink {
    private var socket: BluetoothSocket? = null
    private var input: InputStream? = null
    private var output: OutputStream? = null

    override val label: String get() = deviceName
    override val settleMillis: Long get() = 600L

    // The caller (SenderScreen) only offers this link after BLUETOOTH_CONNECT has been granted.
    @SuppressLint("MissingPermission")
    override fun open() {
        val s = device.createRfcommSocketToServiceRecord(SPP_UUID)
        try {
            s.connect()
        } catch (e: IOException) {
            try { s.close() } catch (_: IOException) { }
            throw IOException("Could not connect to $deviceName (is it powered, paired and in range?): ${e.message}", e)
        }
        socket = s
        input = s.inputStream
        output = s.outputStream
    }

    override fun write(data: ByteArray) {
        val o = output ?: throw IOException("Bluetooth link is closed")
        o.write(data)
        o.flush()
    }

    override fun read(buffer: ByteArray): Int {
        val i = input ?: return -1
        return i.read(buffer)
    }

    override fun close() {
        try { socket?.close() } catch (_: IOException) { }
        socket = null
        input = null
        output = null
    }

    companion object {
        /** The well-known Serial Port Profile UUID every HC-05 / HC-06 offers. */
        val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    }
}

// ---------------------------------------------------------------------------------------------------------------
// TCP (Wi-Fi serial bridges)
// ---------------------------------------------------------------------------------------------------------------

class TcpSerialLink(private val host: String, private val port: Int) : SerialLink {
    private var socket: Socket? = null
    private var input: InputStream? = null
    private var output: OutputStream? = null

    override val label: String get() = "$host:$port"
    override val settleMillis: Long get() = 300L

    override fun open() {
        val s = Socket()
        try {
            s.connect(InetSocketAddress(host, port), 5000)
            s.tcpNoDelay = true
            s.soTimeout = 250 // short read timeouts keep the reader loop responsive
        } catch (e: IOException) {
            try { s.close() } catch (_: IOException) { }
            throw IOException("Could not reach $host:$port: ${e.message}", e)
        }
        socket = s
        input = s.getInputStream()
        output = s.getOutputStream()
    }

    override fun write(data: ByteArray) {
        val o = output ?: throw IOException("Wi-Fi link is closed")
        o.write(data)
        o.flush()
    }

    override fun read(buffer: ByteArray): Int {
        val i = input ?: return -1
        return try {
            i.read(buffer)
        } catch (_: SocketTimeoutException) {
            0
        }
    }

    override fun close() {
        try { socket?.close() } catch (_: IOException) { }
        socket = null
        input = null
        output = null
    }
}

// ---------------------------------------------------------------------------------------------------------------
// USB OTG, CDC-ACM
// ---------------------------------------------------------------------------------------------------------------

/**
 * Standard CDC-ACM serial over Android's USB host API, no third-party library. Works with boards whose USB chip
 * is a real CDC-ACM device (Arduino Uno R3 / Mega 2560 with the ATmega16U2, Leonardo, Micro, Nano Every, many
 * ESP32-S2/S3 / RP2040 boards). CH340 / CP210x / FTDI adapters (most cheap Nano clones) use vendor protocols and
 * are NOT supported here -- [open] reports that clearly.
 *
 * The caller must already hold USB permission for [device].
 */
class UsbCdcSerialLink(
    private val manager: UsbManager,
    private val device: UsbDevice,
    private val baudRate: Int,
) : SerialLink {
    private var connection: UsbDeviceConnection? = null
    private var controlInterface: UsbInterface? = null
    private var dataInterface: UsbInterface? = null
    private var endpointIn: UsbEndpoint? = null
    private var endpointOut: UsbEndpoint? = null

    override val label: String get() = device.productName ?: "USB ${device.vendorId.toString(16)}:${device.productId.toString(16)}"
    override val settleMillis: Long get() = 2200L // opening toggles DTR: the Arduino bootloader runs for ~1.5 s

    override fun open() {
        var ctrl: UsbInterface? = null
        var data: UsbInterface? = null
        for (n in 0 until device.interfaceCount) {
            val itf = device.getInterface(n)
            if (itf.interfaceClass == UsbConstants.USB_CLASS_COMM && ctrl == null) ctrl = itf
            if (itf.interfaceClass == UsbConstants.USB_CLASS_CDC_DATA && data == null) data = itf
        }
        var epIn: UsbEndpoint? = null
        var epOut: UsbEndpoint? = null
        if (data != null) {
            for (e in 0 until data.endpointCount) {
                val ep = data.getEndpoint(e)
                if (ep.type != UsbConstants.USB_ENDPOINT_XFER_BULK) continue
                if (ep.direction == UsbConstants.USB_DIR_IN) epIn = ep else epOut = ep
            }
        }
        if (data == null || epIn == null || epOut == null) {
            throw IOException(
                "This USB device is not a standard CDC-ACM serial port (CH340 / CP210x / FTDI adapters need " +
                    "their own driver). Use the Bluetooth or Wi-Fi link instead."
            )
        }
        val conn = manager.openDevice(device) ?: throw IOException("Android refused to open the USB device (permission?)")
        try {
            if (ctrl != null && !conn.claimInterface(ctrl, true)) throw IOException("Could not claim the USB control interface")
            if (!conn.claimInterface(data, true)) throw IOException("Could not claim the USB data interface")

            val controlId = (ctrl ?: data).id
            // SET_LINE_CODING: baud (LE 32 bit), 1 stop bit, no parity, 8 data bits
            val lineCoding = byteArrayOf(
                (baudRate and 0xFF).toByte(),
                ((baudRate shr 8) and 0xFF).toByte(),
                ((baudRate shr 16) and 0xFF).toByte(),
                ((baudRate shr 24) and 0xFF).toByte(),
                0, 0, 8,
            )
            conn.controlTransfer(0x21, 0x20, 0, controlId, lineCoding, lineCoding.size, 1000)
            // SET_CONTROL_LINE_STATE: DTR + RTS on (what a terminal program does when it opens the port)
            conn.controlTransfer(0x21, 0x22, 0x03, controlId, null, 0, 1000)
        } catch (e: IOException) {
            conn.close()
            throw e
        }
        connection = conn
        controlInterface = ctrl
        dataInterface = data
        endpointIn = epIn
        endpointOut = epOut
    }

    override fun write(data: ByteArray) {
        val conn = connection ?: throw IOException("USB link is closed")
        val out = endpointOut ?: throw IOException("USB link is closed")
        var offset = 0
        while (offset < data.size) {
            val chunk = minOf(data.size - offset, 64)
            val n = conn.bulkTransfer(out, data, offset, chunk, 2000)
            if (n < 0) throw IOException("USB write failed (cable unplugged?)")
            offset += n
        }
    }

    override fun read(buffer: ByteArray): Int {
        val conn = connection ?: return -1
        val inp = endpointIn ?: return -1
        val n = conn.bulkTransfer(inp, buffer, buffer.size, 200)
        if (n >= 0) return n
        // -1 means "timeout" and "error" alike: tell them apart by checking the device is still attached.
        return if (manager.deviceList.containsKey(device.deviceName)) 0 else -1
    }

    override fun close() {
        val conn = connection
        connection = null
        if (conn != null) {
            try { controlInterface?.let { conn.releaseInterface(it) } } catch (_: Exception) { }
            try { dataInterface?.let { conn.releaseInterface(it) } } catch (_: Exception) { }
            conn.close()
        }
        endpointIn = null
        endpointOut = null
    }
}
