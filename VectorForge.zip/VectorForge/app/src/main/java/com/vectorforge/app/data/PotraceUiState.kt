package com.vectorforge.app.data

import java.io.File

/**
 * Every field here is either bound directly to a control shown in the
 * reference's "IMAGE -> SVG" section, or is status/result data that same
 * section displays back (dimensions, status card, path count).
 */
data class PotraceUiState(
    // -- Input Source ---------------------------------------------------
    val imageFile: File? = null,
    val imageFileName: String = "",
    val imageDimensionsLabel: String = "", // e.g. "1024×1024 px · PNG"

    // -- Output SVG Path --------------------------------------------------
    val outputSvgPath: String = "",

    // -- Trace Strategy ---------------------------------------------------
    val traceMode: TraceMode = TraceMode.MODE_1_DIRECT,

    // -- Invert Luminance ---------------------------------------------------
    val invertLuminance: Boolean = false,

    // -- PBM Output Path (Mode 2 only) --------------------------------------
    val pbmOutputPath: String = "",

    // -- Potrace Parameters (collapsible) ------------------------------------
    val threshold: Double = 0.5,
    val turdsize: Int = 2,
    val alphamax: Double = 1.0,
    val opticurve: Boolean = true,
    val opttolerance: Double = 0.2,
    val turnPolicy: TurnPolicyOption = TurnPolicyOption.MINORITY,

    // -- Run state / status card --------------------------------------------
    val isConverting: Boolean = false,
    val statusTitle: String = "Engine Online",
    val statusDetail: String =
        "High-fidelity binary edge tracer prepared. Raster will vectorize with default Bézier fitting.",
    val pathCount: Int? = null,
    val errorMessage: String? = null,
    val generatedSvgFile: File? = null,
) {
    val hasImage: Boolean get() = imageFile != null
    val canConvert: Boolean get() = hasImage && !isConverting
    val isMode2: Boolean get() = traceMode == TraceMode.MODE_2_PBM
}
