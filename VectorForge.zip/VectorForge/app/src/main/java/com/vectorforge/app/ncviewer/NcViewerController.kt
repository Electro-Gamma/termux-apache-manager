package com.vectorforge.app.ncviewer

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.webkit.ConsoleMessage
import android.webkit.ServiceWorkerClient
import android.webkit.ServiceWorkerController
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.math.abs

private const val TAG = "NCViewer"

private const val PREFS = "ncviewer_prefs"
private const val PREF_SPLIT_MODE = "split_mode"

/** Request code of the system "Save As" dialog opened by the remote control's Save pill. */
private const val SAVE_REQUEST_CODE = 51440

/**
 * The complete NC Viewer Offline UI, hosted inside VectorForge's "G-Code Viewer" tab.
 *
 * This is NC Viewer Offline's MainActivity, moved 1:1 into a plain object that owns the views, so it can be
 * embedded in a Compose screen (see GcodeViewerScreen) instead of being an Activity of its own:
 *
 *  - the same bundled Nuxt site (assets/www) served through the same [AppAssetHandler] (no server, no port),
 *  - the same one-or-two-pane layout: a top WebView, and in split view a second WebView below a 2 dp divider,
 *  - the same draggable "Single view" / "Split view" pill (bottom-right), persisted across launches,
 *  - the same per-pane draggable "Open file" pill (bottom-left of each pane) from [FileOpener],
 *  - the same file chooser for the site's own Open button.
 *
 * What is intentionally NOT carried over from the NC Viewer app: its optional 127.0.0.1 [Serve] fallback
 * (dead code behind a `false` constant there), its system-bar inset handling (VectorForge's Scaffold already
 * keeps the tab clear of its own top bar and bottom navigation), its startup diagnostics logging, and its
 * global crash handler (an app-level concern, not part of the viewer).
 *
 * The two WebViews are created once and live as long as [activity], so what is loaded in them survives
 * switching between VectorForge's tabs; [rootView] is simply re-attached each time the tab is shown.
 */
class NcViewerController(private val activity: Activity) {

    private val assetHandler = AppAssetHandler(activity.assets)

    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private val fileChooserRequestCode = 51426

    // webView is the always-present top/primary pane ("Viewer 1"); secondWebView exists only once split view
    // has been switched on (bottom pane, "Viewer 2"), so two G-code files can be open side by side.
    private val webView: WebView
    private var secondWebView: WebView? = null
    private val webViews = mutableListOf<WebView>()

    // Each pane is a FrameLayout holding its WebView plus that pane's own "Open file" pill (FileOpener).
    // The list is copy-on-write because shouldInterceptRequest walks it on a WebView background thread.
    private val panes = HashMap<WebView, FrameLayout>()
    private val fileOpeners = CopyOnWriteArrayList<FileOpener>()

    /**
     * The remote control (the "Post-process" pill + the overlay of arrow / rotate pills, see ViewerPostProcess and
     * RemoteControl). Not part of the original NC Viewer app: a VectorForge addition.
     */
    val postProcess = ViewerPostProcess(activity) { pane -> fileOpeners.firstOrNull { it.id == pane } }
    private lateinit var remote: RemoteControl

    private val paneContainer: LinearLayout
    private val splitButton: TextView

    /** Everything the Compose screen has to host: the pane stack plus the floating Single/Split pill. */
    val rootView: FrameLayout

    private var splitMode: Boolean

    init {
        // Lets a PC's Chrome (chrome://inspect/#devices) attach a full DevTools console+network panel to
        // this exact WebView over USB. Same as NC Viewer Offline.
        WebView.setWebContentsDebuggingEnabled(true)

        val prefs = activity.getSharedPreferences(PREFS, Activity.MODE_PRIVATE)
        splitMode = prefs.getBoolean(PREF_SPLIT_MODE, false)
        postProcess.splitMode = splitMode

        // Requests made by a service worker do not pass through WebViewClient, so route them here too.
        try {
            ServiceWorkerController.getInstance().setServiceWorkerClient(object : ServiceWorkerClient() {
                override fun shouldInterceptRequest(request: WebResourceRequest?): WebResourceResponse? =
                    if (request != null) assetHandler.handle(request) else null
            })
        } catch (e: Exception) {
            Log.w(TAG, "service worker interception unavailable: ${e.message}")
        }

        webView = createWebView()
        webViews.add(webView)

        splitButton = makeToggleButton(::splitLabel, "Switch between split and single view") { toggleSplit() }

        paneContainer = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL }

        rootView = FrameLayout(activity)
        rootView.addView(
            paneContainer,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        rootView.addView(
            splitButton,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.END
            ).apply { setMargins(0, 0, dp(12), dp(12)) }
        )

        // "Post-process": shows / hides the remote control. Same pill as Single/Split view, stacked above it.
        val postButton = makeToggleButton({ "Post-process" }, "Live post-processing of the viewed G-code") { postProcess.toggle() }
        rootView.addView(
            postButton,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.END
            ).apply { setMargins(0, 0, dp(12), dp(56)) }
        )

        // the remote-control overlay (hidden until the pill above is tapped), above both pills, drag its status pill to move it
        remote = RemoteControl(activity, postProcess) { requestSave() }
        rootView.addView(
            remote.view,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.END
            ).apply { setMargins(0, 0, dp(12), dp(100)) }
        )

        rebuildPanes() // lays out webView (+ secondWebView if splitMode was restored from prefs)

        // No server, no port: AppAssetHandler answers each WebView's requests from assets/www.
        val problem = verifyBundledSite()
        if (problem != null) {
            Log.e(TAG, problem)
            showAlert("Site files missing", problem)
        }
        webViews.forEach { it.loadUrl("${AppAssetHandler.ORIGIN}/") }
    }

    // ---------------------------------------------------------------- VectorForge integration

    /**
     * "Generate + Viewer 1" ([split] = false) and "Generate + Viewer 2 (Split)" ([split] = true).
     *
     *  - Viewer 1: NC Viewer goes to single view (no splitting) and [file] is opened in the one pane.
     *  - Viewer 2: NC Viewer goes to split view and [file] is opened in the second (bottom) pane; the top pane
     *    and whatever it shows are left alone.
     *
     * The file then goes through the pane's [FileOpener], i.e. exactly the same handling as a file picked with
     * the "Open file" pill: an empty editor (or the welcome text) simply loads it and plots; if the editor
     * already holds G-code, the usual Replace / Append / Cancel dialog asks what to do.
     */
    fun openGeneratedGcode(file: File, split: Boolean) {
        postProcess.dismissBecauseViewerChanged()
        setSplitMode(split)
        val opener = fileOpeners.firstOrNull { it.id == if (split) 1 else 0 } ?: return
        opener.openGeneratedFile(file)
    }

    // ---------------------------------------------------------------- lifecycle plumbing (called by MainActivity)

    /** The remote's Save pill: the system "Save As" dialog (same type and naming as the Convert screen's export). */
    private fun requestSave() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/plain"
            putExtra(Intent.EXTRA_TITLE, postProcess.suggestedFileName())
        }
        try {
            @Suppress("DEPRECATION")
            activity.startActivityForResult(intent, SAVE_REQUEST_CODE)
        } catch (e: Exception) {
            Log.e(TAG, "save dialog failed: ${e.message}")
            Toast.makeText(activity, "No file picker available", Toast.LENGTH_LONG).show()
        }
    }

    /** Routes an Activity result to the remote's Save dialog, the site's own file chooser or a pane's "Open file" pill. */
    @Suppress("DEPRECATION")
    fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?): Boolean {
        if (requestCode == SAVE_REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK) data?.data?.let(postProcess::saveTo)
            return true
        }
        // result of an "Open file" pill (each pane has its own request code)
        if (fileOpeners.any { it.onActivityResult(requestCode, resultCode, data) }) {
            if (resultCode == Activity.RESULT_OK) postProcess.dismissBecauseViewerChanged()
            return true
        }
        if (requestCode != fileChooserRequestCode) return false
        if (resultCode == Activity.RESULT_OK) postProcess.dismissBecauseViewerChanged()

        val callback = filePathCallback
        filePathCallback = null
        if (callback == null) return true
        val results: Array<Uri>? = if (resultCode == Activity.RESULT_OK && data != null) {
            val clipData = data.clipData
            val dataUri = data.data
            when {
                clipData != null -> Array(clipData.itemCount) { i -> clipData.getItemAt(i).uri }
                dataUri != null -> arrayOf(dataUri)
                else -> null
            }
        } else null
        callback.onReceiveValue(results)
        return true
    }

    fun onConfigurationChanged(@Suppress("UNUSED_PARAMETER") newConfig: Configuration) {
        // after a rotation a dragged position may be off-screen, so snap the buttons back
        splitButton.translationX = 0f
        splitButton.translationY = 0f
        remote.resetPosition()
        fileOpeners.forEach { it.resetPosition() }
    }

    /** Frees the WebViews when the Activity is really going away. */
    fun destroy() {
        postProcess.shutdown()
        (rootView.parent as? ViewGroup)?.removeView(rootView)
        paneContainer.removeAllViews()
        panes.values.forEach { it.removeAllViews() }
        webViews.forEach { it.destroy() }
        webViews.clear()
        panes.clear()
        fileOpeners.clear()
    }

    private fun showAlert(title: String, message: String) {
        android.app.AlertDialog.Builder(activity, android.R.style.Theme_Material_Light_Dialog_Alert)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("OK", null)
            .show()
    }

    // ---------------------------------------------------------------- WebView construction

    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView(): WebView {
        val wv = WebView(activity)
        val settings = wv.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        @Suppress("DEPRECATION")
        settings.databaseEnabled = true
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true
        settings.textZoom = 100
        settings.builtInZoomControls = true
        settings.displayZoomControls = false
        // used by the "Open file" pill to report back (must be registered before the first page load)
        wv.addJavascriptInterface(NCVNativeBridge(activity), "NCVNative")
        wv.webViewClient = buildWebViewClient()
        wv.webChromeClient = buildWebChromeClient()
        return wv
    }

    private fun buildWebViewClient(): WebViewClient = object : WebViewClient() {
        // Answers every request to https://appassets.androidplatform.net/ from the APK's assets
        // (runs on a WebView background thread). Any other host returns null = normal network.
        override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
            if (request == null) return null
            for (opener in fileOpeners) opener.intercept(request)?.let { return it } // file picked with "Open file"
            return assetHandler.handle(request)
        }

        override fun onReceivedError(
            view: WebView?,
            request: WebResourceRequest?,
            error: WebResourceError?
        ) {
            Log.e(TAG, "onReceivedError url=${request?.url} error=${error?.description}")
        }

        @Suppress("DEPRECATION")
        override fun onReceivedError(
            view: WebView?,
            errorCode: Int,
            description: String?,
            failingUrl: String?
        ) {
            Log.e(TAG, "onReceivedError(legacy) url=$failingUrl code=$errorCode desc=$description")
        }

        override fun onReceivedHttpError(
            view: WebView?,
            request: WebResourceRequest?,
            errorResponse: WebResourceResponse?
        ) {
            Log.e(TAG, "onReceivedHttpError url=${request?.url} status=${errorResponse?.statusCode}")
        }
    }

    private fun buildWebChromeClient(): WebChromeClient = object : WebChromeClient() {
        override fun onConsoleMessage(message: ConsoleMessage?): Boolean {
            Log.d(TAG, "console: ${message?.message()} (${message?.sourceId()}:${message?.lineNumber()})")
            return true
        }

        override fun onShowFileChooser(
            view: WebView?,
            callback: ValueCallback<Array<Uri>>?,
            params: FileChooserParams?
        ): Boolean {
            filePathCallback?.onReceiveValue(null)
            filePathCallback = callback
            val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
            }
            return try {
                @Suppress("DEPRECATION")
                activity.startActivityForResult(Intent.createChooser(intent, "Select a file"), fileChooserRequestCode)
                true
            } catch (e: Exception) {
                filePathCallback = null
                false
            }
        }
    }

    private fun dp(v: Int): Int = (v * activity.resources.displayMetrics.density).toInt()

    // ---------------------------------------------------------------- split / single view

    private fun splitLabel(): String = if (splitMode) "Split view" else "Single view"

    private fun toggleSplit() {
        splitMode = !splitMode
        activity.getSharedPreferences(PREFS, Activity.MODE_PRIVATE).edit().putBoolean(PREF_SPLIT_MODE, splitMode).apply()
        splitButton.text = splitLabel()
        Toast.makeText(
            activity,
            if (splitMode) "Split view: compare two G-code files" else "Single view",
            Toast.LENGTH_SHORT
        ).show()
        rebuildPanes()
        postProcess.onSplitChanged(splitMode)
    }

    /** Switches to [split] the same way tapping the pill would (persisted, pill label updated), silently. */
    private fun setSplitMode(split: Boolean) {
        if (splitMode == split) return
        splitMode = split
        activity.getSharedPreferences(PREFS, Activity.MODE_PRIVATE).edit().putBoolean(PREF_SPLIT_MODE, splitMode).apply()
        splitButton.text = splitLabel()
        rebuildPanes()
        postProcess.onSplitChanged(splitMode)
    }

    /**
     * Lays paneContainer out as either one full-height pane (webView) or two equal panes stacked
     * top/bottom with a thin divider between them, matching splitMode. Creating the second pane the
     * first time it's needed loads it fresh; toggling back to single view keeps it around (paused, not
     * destroyed) so its own open file and scroll position are still there if the user splits again.
     */
    private fun rebuildPanes() {
        paneContainer.removeAllViews()

        paneContainer.addView(paneFor(webView, 0), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        if (splitMode) {
            val bottom: WebView = secondWebView ?: createWebView().also { created ->
                secondWebView = created
                webViews.add(created)
                created.loadUrl("${AppAssetHandler.ORIGIN}/")
            }
            paneContainer.addView(buildDivider(), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(2)))
            paneContainer.addView(paneFor(bottom, 1), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }

        // the panes changed size, so put every "Open file" pill back in its corner
        fileOpeners.forEach { it.resetPosition() }
    }

    /**
     * The FrameLayout for [wv]: the WebView filling it, plus its own "Open file" pill at the bottom-left.
     * Created once per WebView and reused, so toggling split/single keeps each pane (and its open file) alive.
     * [id] is 0 for the top pane and 1 for the bottom pane.
     */
    private fun paneFor(wv: WebView, id: Int): FrameLayout = panes.getOrPut(wv) {
        FrameLayout(activity).also { pane ->
            pane.addView(wv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            fileOpeners.add(FileOpener(activity, wv, pane, id))
        }
    }

    private fun buildDivider(): View = View(activity).apply {
        setBackgroundColor(Color.rgb(60, 63, 68))
    }

    // ---------------------------------------------------------------- floating buttons

    /** Small translucent pill: tap = run [onTap], drag = move it out of the way. Reused for each toggle. */
    private fun makeToggleButton(label: () -> String, contentDesc: String, onTap: () -> Unit): TextView =
        TextView(activity).apply {
            text = label()
            textSize = 13f
            setTextColor(Color.WHITE)
            setPadding(dp(14), dp(8), dp(14), dp(8))
            background = GradientDrawable().apply {
                setColor(Color.argb(204, 32, 33, 36))
                cornerRadius = dp(20).toFloat()
            }
            alpha = 0.85f
            elevation = dp(6).toFloat()
            contentDescription = contentDesc

            val slop = ViewConfiguration.get(activity).scaledTouchSlop.toFloat()
            var downX = 0f
            var downY = 0f
            var startX = 0f
            var startY = 0f
            var dragging = false
            setOnTouchListener { v, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = e.rawX
                        downY = e.rawY
                        startX = v.translationX
                        startY = v.translationY
                        dragging = false
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - downX
                        val dy = e.rawY - downY
                        if (!dragging && (abs(dx) > slop || abs(dy) > slop)) dragging = true
                        if (dragging) {
                            v.translationX = startX + dx
                            v.translationY = startY + dy
                        }
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!dragging) onTap()
                        true
                    }
                    else -> false
                }
            }
        }

    /** Null if the APK really contains index.html and the site's .js files, otherwise what is missing. */
    private fun verifyBundledSite(): String? {
        val root = activity.assets.list("www")?.toList() ?: emptyList()
        val hasNuxtJs = activity.assets.list("www/_nuxt")?.any { it.endsWith(".js") } == true
        Log.d(TAG, "bundled site: www=$root _nuxt has .js=$hasNuxtJs")
        return when {
            "index.html" !in root -> "index.html is missing from the APK's assets/www."
            !hasNuxtJs -> "index.html is there but assets/www/_nuxt has no .js files. " +
                "The APK was built without www/_nuxt (check androidResources.ignoreAssetsPattern in app/build.gradle.kts)."
            else -> null
        }
    }
}
