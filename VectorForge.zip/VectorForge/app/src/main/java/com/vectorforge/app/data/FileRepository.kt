package com.vectorforge.app.data

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import androidx.core.content.FileProvider
import java.io.File
import kotlin.math.log10
import kotlin.math.pow

/**
 * All file I/O for the app goes through here, and it all lands on real
 * `java.io.File`s inside this app's own app-specific external storage
 * (`Context.getExternalFilesDir`) -- which needs no storage permission on
 * any supported API level and requires no change to the ported engine
 * files, since they already read/write plain `File`s.
 *
 * Layout mirrors the two folders the reference's placeholder paths hint at
 * (`/storage/emulated/0/Vectors/...`, `/storage/emulated/0/GCode/...|`):
 *   <app-specific external files dir>/Vectors/  -- copied-in source images,
 *       generated SVGs, intermediate .pbm files
 *   <app-specific external files dir>/GCode/    -- generated G-code
 *
 * Picking an input file goes through the system Photo Picker / Storage
 * Access Framework document picker (see MainActivity's ActivityResultContracts),
 * which grants per-file read access with no manifest permission; the
 * resulting content:// Uri is then copied here so the rest of the pipeline
 * only ever deals with ordinary Files.
 */
class FileRepository(private val context: Context) {

    private fun rootDir(): File = context.getExternalFilesDir(null) ?: context.filesDir

    val vectorsDir: File by lazy { File(rootDir(), "Vectors").apply { mkdirs() } }
    val gcodeDir: File by lazy { File(rootDir(), "GCode").apply { mkdirs() } }

    /** Resolves a content:// (or file://) Uri's display name, falling back to its last path segment. */
    fun displayNameOf(uri: Uri): String {
        if (uri.scheme == "content") {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { cursor ->
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0 && cursor.moveToFirst()) return cursor.getString(idx)
                }
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "file"
    }

    /** Copies a picked content Uri's bytes into [destDir] under its own display name, returning the new File. */
    fun copyUriInto(uri: Uri, destDir: File): File {
        val name = sanitizeFileName(displayNameOf(uri))
        val dest = uniqueFile(destDir, name)
        context.contentResolver.openInputStream(uri)?.use { input ->
            dest.outputStream().use { output -> input.copyTo(output) }
        } ?: error("Could not open input stream for $uri")
        return dest
    }

    /** Copies a picked input image into the Vectors/ folder. */
    fun importImage(uri: Uri): File = copyUriInto(uri, vectorsDir)

    /** Copies a picked input SVG into the Vectors/ folder. */
    fun importSvg(uri: Uri): File = copyUriInto(uri, vectorsDir)

    fun defaultSvgOutputPath(imageFile: File): String =
        File(vectorsDir, imageFile.nameWithoutExtension + ".svg").path

    fun defaultPbmPath(imageFile: File): String =
        File(vectorsDir, imageFile.nameWithoutExtension + ".pbm").path

    fun defaultGcodeOutputPath(svgFile: File): String =
        File(gcodeDir, svgFile.nameWithoutExtension + ".gcode").path

    fun writeText(path: String, text: String): File {
        val file = File(path)
        file.parentFile?.mkdirs()
        file.writeText(text)
        return file
    }

    /** Copies an already-generated file's bytes into a user-chosen SAF destination (e.g. from CreateDocument). */
    fun exportFileTo(source: File, destUri: Uri) {
        context.contentResolver.openOutputStream(destUri)?.use { output ->
            source.inputStream().use { input -> input.copyTo(output) }
        } ?: error("Could not open output stream for $destUri")
    }

    /** Reads just the pixel dimensions of an image file without loading the whole bitmap. */
    fun imageDimensionsLabel(file: File): String {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.path, opts)
        val type = file.extension.uppercase().ifBlank { "IMG" }
        return if (opts.outWidth > 0 && opts.outHeight > 0) {
            "${opts.outWidth}\u00D7${opts.outHeight} px \u00B7 $type"
        } else {
            type
        }
    }

    fun humanFileSize(bytes: Long): String {
        if (bytes < 1024) return "$bytes B"
        val units = arrayOf("KB", "MB", "GB")
        val digitGroup = (log10(bytes.toDouble()) / log10(1024.0)).toInt().coerceIn(1, units.size)
        val value = bytes / 1024.0.pow(digitGroup.toDouble())
        return String.format(java.util.Locale.ROOT, "%.1f %s", value, units[digitGroup - 1])
    }

    /** Opens the system share sheet for a generated output file via FileProvider. */
    fun shareFile(file: File, mimeType: String) {
        val uri = FileProvider.getUriForFile(context, "com.vectorforge.app.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Share ${file.name}").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        })
    }

    private fun sanitizeFileName(name: String): String =
        name.replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "file" }

    private fun uniqueFile(dir: File, name: String): File {
        var candidate = File(dir, name)
        if (!candidate.exists()) return candidate
        val base = candidate.nameWithoutExtension
        val ext = candidate.extension
        var i = 1
        while (candidate.exists()) {
            candidate = File(dir, if (ext.isNotEmpty()) "${base}_$i.$ext" else "${base}_$i")
            i++
        }
        return candidate
    }
}
