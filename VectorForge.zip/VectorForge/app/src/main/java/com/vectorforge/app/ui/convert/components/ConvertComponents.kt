package com.vectorforge.app.ui.convert.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.HorizontalSplit
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.vectorforge.app.ui.theme.LocalVfDarkTheme
import com.vectorforge.app.ui.theme.VfRadius
import com.vectorforge.app.ui.theme.VfSpacing
import com.vectorforge.app.ui.theme.VfType

/** Small uppercase pill, e.g. "POTRACE" / "CNC / PLOTTER" / "Ready to trace". */
@Composable
fun PillBadge(text: String, color: Color, containerAlpha: Float = 0.1f, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(CircleShape)
            .background(color.copy(alpha = containerAlpha))
            .padding(horizontal = VfSpacing.sm, vertical = 2.dp)
    ) {
        Text(text, style = VfType.labelSm, color = color)
    }
}

/** A rounded, tonal container used for input rows (image/SVG picker, path fields, motion inputs, ...). */
@Composable
fun TonalContainer(
    modifier: Modifier = Modifier,
    shape: androidx.compose.ui.graphics.Shape = RoundedCornerShape(VfRadius.xl2),
    color: Color = MaterialTheme.colorScheme.surfaceContainerHigh,
    contentPadding: PaddingValues = PaddingValues(VfSpacing.sm),
    content: @Composable RowScope.() -> Unit,
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .background(color)
            .padding(contentPadding),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(VfSpacing.xs),
        content = content
    )
}

/** Two-option pill segmented control ("Trace Strategy": Mode 1 / Mode 2). */
@Composable
fun SegmentedControl(
    options: List<String>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(VfRadius.xl))
            .background(MaterialTheme.colorScheme.surfaceContainerLowest)
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        options.forEachIndexed { index, label ->
            val selected = index == selectedIndex
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(VfRadius.lg))
                    .background(if (selected) MaterialTheme.colorScheme.surfaceContainerHigh else Color.Transparent)
                    .clickable { onSelect(index) }
                    .padding(vertical = 10.dp, horizontal = VfSpacing.sm),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    label,
                    style = VfType.labelMd,
                    color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                )
            }
        }
    }
}

/** A titled row with a trailing switch ("Invert Luminance", "OPTICURVE", "REGISTER PEN", ...). */
@Composable
fun ToggleRow(
    title: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    leadingIcon: ImageVector? = null,
    tonal: Boolean = false,
    enabled: Boolean = true,
) {
    // Locked rows stay visible but are dimmed.
    val base = modifier.alpha(if (enabled) 1f else 0.6f)
    val rowModifier = if (tonal) {
        base
            .fillMaxWidth()
            .clip(RoundedCornerShape(VfRadius.xl))
            .background(MaterialTheme.colorScheme.surfaceContainerHigh)
            .padding(VfSpacing.sm)
    } else {
        base.fillMaxWidth()
    }
    Row(
        modifier = rowModifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(VfSpacing.sm)) {
            if (leadingIcon != null) {
                Icon(leadingIcon, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(20.dp))
            }
            Column {
                Text(title, style = VfType.labelLg, color = MaterialTheme.colorScheme.onSurface)
                if (subtitle != null) {
                    Text(subtitle, style = VfType.labelSm, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            enabled = enabled,
            colors = SwitchDefaults.colors(
                checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
                checkedTrackColor = MaterialTheme.colorScheme.primary,
                uncheckedThumbColor = MaterialTheme.colorScheme.onSurfaceVariant,
                uncheckedTrackColor = MaterialTheme.colorScheme.surfaceContainerHighest,
                uncheckedBorderColor = Color.Transparent,
                checkedBorderColor = Color.Transparent,
            )
        )
    }
}

/** A collapsible group with a chevron header, matching "Potrace Parameters" / the five SVG->G-code groups. */
@Composable
fun AccordionSection(
    title: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    initiallyExpanded: Boolean = false,
    accentColor: Color = MaterialTheme.colorScheme.primary,
    content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit,
) {
    var expanded by remember { mutableStateOf(initiallyExpanded) }
    val accordionShape = RoundedCornerShape(VfRadius.xl2)
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(accordionShape)
            .background(MaterialTheme.colorScheme.surfaceContainerLow)
            .then(
                if (LocalVfDarkTheme.current) Modifier
                else Modifier.border(1.dp, MaterialTheme.colorScheme.outlineVariant, accordionShape)
            )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { expanded = !expanded }
                .padding(VfSpacing.md),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(VfSpacing.xs)) {
                Icon(icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(18.dp))
                Text(title, style = VfType.labelLg, color = MaterialTheme.colorScheme.onSurface)
            }
            val rotation by androidx.compose.animation.core.animateFloatAsState(if (expanded) 180f else 0f, label = "chevron")
            Icon(
                Icons.Filled.ExpandMore,
                contentDescription = if (expanded) "Collapse" else "Expand",
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier
                    .size(20.dp)
                    .graphicsLayerRotation(rotation)
            )
        }
        AnimatedVisibility(
            visible = expanded,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically(),
        ) {
            Column(
                modifier = Modifier.padding(start = VfSpacing.md, end = VfSpacing.md, bottom = VfSpacing.md),
                verticalArrangement = Arrangement.spacedBy(VfSpacing.sm),
            ) {
                content()
            }
        }
    }
}

private fun Modifier.graphicsLayerRotation(degrees: Float): Modifier =
    this.rotate(degrees)

/** A labelled 0..1 style slider row ("THRESHOLD"). */
@Composable
fun LabeledSlider(
    label: String,
    value: Float,
    onValueChange: (Float) -> Unit,
    valueRange: ClosedFloatingPointRange<Float>,
    valueLabel: String,
    modifier: Modifier = Modifier,
    steps: Int = 0,
    onValueChangeFinished: (() -> Unit)? = null,
) {
    Column(modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, style = VfType.labelMd, color = MaterialTheme.colorScheme.onSurface)
            Text(valueLabel, style = VfType.labelSm, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = valueRange,
            steps = steps,
            onValueChangeFinished = onValueChangeFinished,
            colors = SliderDefaults.colors(
                thumbColor = MaterialTheme.colorScheme.primary,
                activeTrackColor = MaterialTheme.colorScheme.primary,
                inactiveTrackColor = MaterialTheme.colorScheme.surfaceContainerHighest,
            )
        )
    }
}

/** A "+ / value / -" stepper row ("TURDSIZE", "ALPHAMAX"). */
@Composable
fun StepperField(
    title: String,
    subtitle: String?,
    valueLabel: String,
    onDecrement: () -> Unit,
    onIncrement: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = VfType.labelMd, color = MaterialTheme.colorScheme.onSurface)
            if (subtitle != null) Text(subtitle, style = VfType.labelSm, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(VfRadius.xl))
                .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                .padding(4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            StepperButton("-", onDecrement)
            Text(
                valueLabel,
                style = VfType.labelLg,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.padding(horizontal = 6.dp),
            )
            StepperButton("+", onIncrement)
        }
    }
}

@Composable
private fun StepperButton(symbol: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(28.dp)
            .clip(RoundedCornerShape(VfRadius.lg))
            .background(MaterialTheme.colorScheme.surfaceContainerHighest)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(symbol, style = VfType.titleMd, color = MaterialTheme.colorScheme.onSurface)
    }
}

/**
 * A compact numeric field with an optional trailing unit ("deg", "ms", "mm").
 * Used throughout PEN/SERVO, MOTION, GEOMETRY and POST-PROCESSING groups.
 *
 * Keeps its own local text buffer (seeded once from [value]) rather than
 * echoing [value] straight back into the field on every keystroke: with a
 * plain `value.toString()`, typing "0." for a decimal like 0.2 would fail
 * to parse, the parent would never call back with a new value, and the
 * field would immediately "snap back" to the last valid number -- making
 * it impossible to type a decimal at all. Committing only on successful
 * parse (and keeping whatever the user typed otherwise) avoids that.
 */
@Composable
fun DoubleField(
    label: String,
    value: Double,
    onValueChange: (Double) -> Unit,
    modifier: Modifier = Modifier,
    unit: String? = null,
    enabled: Boolean = true,
) {
    var text by remember { mutableStateOf(formatNumber(value)) }
    NumberFieldShell(label, text, { newText ->
        text = newText
        newText.toDoubleOrNull()?.let(onValueChange)
    }, unit, modifier, enabled = enabled)
}

/** Int counterpart of [DoubleField] (COPIES, SKIP FACTOR, delays in ms, ...). */
@Composable
fun IntField(
    label: String,
    value: Int,
    onValueChange: (Int) -> Unit,
    modifier: Modifier = Modifier,
    unit: String? = null,
    enabled: Boolean = true,
) {
    var text by remember { mutableStateOf(value.toString()) }
    NumberFieldShell(label, text, { newText ->
        text = newText
        newText.toIntOrNull()?.let(onValueChange)
    }, unit, modifier, enabled = enabled)
}

/** Free-text field with the same visual shell as the numeric fields (COMPATIBILITY TAB). */
@Composable
fun TextFieldRow(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    placeholder: String = "",
    enabled: Boolean = true,
) {
    NumberFieldShell(label, value, onValueChange, unit = null, modifier = modifier, placeholder = placeholder, enabled = enabled)
}

/**
 * Optional numeric input: starts EMPTY and shows the engine default only as a
 * faint placeholder. While empty the value is `null` and is NOT used by the
 * generator; typing a number sets it, clearing the field un-sets it again.
 */
@Composable
fun OptionalDoubleField(
    label: String,
    value: Double?,
    default: Double,
    onValueChange: (Double?) -> Unit,
    modifier: Modifier = Modifier,
    unit: String? = null,
) {
    var text by remember { mutableStateOf(value?.let { formatNumber(it) } ?: "") }
    NumberFieldShell(
        label = label,
        text = text,
        onTextChange = { newText ->
            text = newText
            if (newText.isBlank()) onValueChange(null) else newText.toDoubleOrNull()?.let { onValueChange(it) }
        },
        unit = unit,
        modifier = modifier,
        placeholder = formatNumber(default),
    )
}

/** Int counterpart of [OptionalDoubleField]. */
@Composable
fun OptionalIntField(
    label: String,
    value: Int?,
    default: Int,
    onValueChange: (Int?) -> Unit,
    modifier: Modifier = Modifier,
    unit: String? = null,
) {
    var text by remember { mutableStateOf(value?.toString() ?: "") }
    NumberFieldShell(
        label = label,
        text = text,
        onTextChange = { newText ->
            text = newText
            if (newText.isBlank()) onValueChange(null) else newText.toIntOrNull()?.let { onValueChange(it) }
        },
        unit = unit,
        modifier = modifier,
        placeholder = default.toString(),
    )
}

/**
 * Optional switch: until it is touched the engine default is shown dimmed and
 * is NOT used by the generator. Flipping it sets an explicit value; the small
 * reset button then appears to return it to "unused / default".
 */
@Composable
fun OptionalToggleRow(
    title: String,
    value: Boolean?,
    default: Boolean,
    onValueChange: (Boolean?) -> Unit,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
) {
    val isSet = value != null
    val shown = value ?: default
    val note = if (isSet) subtitle ?: "Custom value" else
        listOfNotNull(subtitle, "Default ${if (default) "ON" else "OFF"} \u00B7 not used").joinToString(" \u00B7 ")
    Row(
        modifier = modifier
            .fillMaxWidth()
            .alpha(if (isSet) 1f else 0.6f),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = VfType.labelLg, color = MaterialTheme.colorScheme.onSurface)
            Text(note, style = VfType.labelSm, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (isSet) {
            IconButton(onClick = { onValueChange(null) }, modifier = Modifier.size(32.dp)) {
                Icon(Icons.Filled.Refresh, contentDescription = "Reset to default", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
            }
        }
        Switch(
            checked = shown,
            onCheckedChange = { onValueChange(it) },
            colors = SwitchDefaults.colors(
                checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
                checkedTrackColor = MaterialTheme.colorScheme.primary,
                uncheckedThumbColor = MaterialTheme.colorScheme.onSurfaceVariant,
                uncheckedTrackColor = MaterialTheme.colorScheme.surfaceContainerHighest,
                uncheckedBorderColor = Color.Transparent,
                checkedBorderColor = Color.Transparent,
            )
        )
    }
}

@Composable
private fun NumberFieldShell(
    label: String,
    text: String,
    onTextChange: (String) -> Unit,
    unit: String?,
    modifier: Modifier = Modifier,
    placeholder: String = "",
    enabled: Boolean = true,
) {
    // Locked fields stay fully visible (just slightly dimmed) but can't be edited.
    Column(modifier.fillMaxWidth().alpha(if (enabled) 1f else 0.6f)) {
        Text(label, style = VfType.labelSm, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 2.dp)
                .clip(RoundedCornerShape(VfRadius.xl))
                .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                .padding(horizontal = VfSpacing.sm, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.weight(1f)) {
                if (text.isEmpty() && placeholder.isNotEmpty()) {
                    // still a faint hint, but a touch stronger on the light theme so it keeps enough contrast on the light field
                    val hintAlpha = if (LocalVfDarkTheme.current) 0.6f else 0.72f
                    Text(placeholder, style = VfType.labelMd, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = hintAlpha))
                }
                androidx.compose.foundation.text.BasicTextField(
                    value = text,
                    onValueChange = onTextChange,
                    enabled = enabled,
                    readOnly = !enabled,
                    singleLine = true,
                    textStyle = VfType.labelMd.copy(color = MaterialTheme.colorScheme.onSurface),
                    cursorBrush = androidx.compose.ui.graphics.SolidColor(MaterialTheme.colorScheme.primary),
                )
            }
            if (unit != null) Text(unit, style = VfType.labelSm, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

/** Trims a trailing ".0" for whole numbers, otherwise shows up to 2 decimal places without trailing zeros. */
private fun formatNumber(v: Double): String {
    val s = String.format(java.util.Locale.ROOT, "%.2f", v)
    return s.trimEnd('0').trimEnd('.')
}

/** A read-only or editable path field, styled as the reference's flat tonal container (not an outlined box). */
@Composable
fun PathField(
    value: String,
    onValueChange: ((String) -> Unit)?,
    modifier: Modifier = Modifier,
    placeholder: String = "",
) {
    androidx.compose.material3.TextField(
        value = value,
        onValueChange = { if (onValueChange != null) onValueChange(it) },
        readOnly = onValueChange == null,
        singleLine = true,
        placeholder = { Text(placeholder, style = VfType.bodySm) },
        textStyle = VfType.bodySm,
        shape = RoundedCornerShape(VfRadius.xl2),
        modifier = modifier.fillMaxWidth(),
        colors = TextFieldDefaults.colors(
            focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
            disabledContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
            focusedIndicatorColor = Color.Transparent,
            unfocusedIndicatorColor = Color.Transparent,
            disabledIndicatorColor = Color.Transparent,
            focusedTextColor = MaterialTheme.colorScheme.onSurface,
            unfocusedTextColor = MaterialTheme.colorScheme.onSurface,
        )
    )
}

/**
 * The pill "CONVERT TO SVG" primary action button. Full width by default; with [fillWidth] = false it is only as
 * wide as its label (plus [horizontalPadding]), and the caller positions it.
 */
@Composable
fun PrimaryActionButton(
    text: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    fillWidth: Boolean = true,
    horizontalPadding: androidx.compose.ui.unit.Dp = 28.dp,
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        shape = CircleShape,
        colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
        ),
        modifier = modifier
            .then(if (fillWidth) Modifier.fillMaxWidth() else Modifier)
            .padding(vertical = 0.dp),
        contentPadding = if (fillWidth) PaddingValues(vertical = 14.dp) else PaddingValues(horizontal = horizontalPadding, vertical = 14.dp),
    ) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(22.dp))
        Text(text, style = VfType.titleMd, modifier = Modifier.padding(start = VfSpacing.xs))
    }
}

/**
 * The three compact G-code actions, on one line, only as wide as their labels and centred horizontally:
 *  - **G-code**   generates the G-code file and opens nothing.
 *  - **Viewer 1** generates it and loads it into the G-Code Viewer (single view, no split).
 *  - **Viewer 2** generates it and loads it into the G-Code Viewer's second pane (split view).
 *
 * "G-code" is filled, the two viewer variants are outlined, so the plain action stays distinct. While a run is in
 * progress ([busy]) all three are disabled and a small spinner appears after them; it takes no space otherwise.
 */
@Composable
fun GenerateButtonsRow(
    onGcode: () -> Unit,
    onViewer1: () -> Unit,
    onViewer2: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    busy: Boolean = false,
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(VfSpacing.sm, Alignment.CenterHorizontally),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CompactActionButton("G-code", Icons.Filled.Terminal, filled = true, onClick = onGcode, enabled = enabled)
        CompactActionButton("Viewer 1", Icons.Filled.Visibility, filled = false, onClick = onViewer1, enabled = enabled)
        CompactActionButton("Viewer 2", Icons.Filled.HorizontalSplit, filled = false, onClick = onViewer2, enabled = enabled)
        if (busy) {
            androidx.compose.material3.CircularProgressIndicator(
                modifier = Modifier.size(18.dp),
                strokeWidth = 2.dp,
                color = MaterialTheme.colorScheme.primary,
            )
        }
    }
}

/**
 * The compact "CONVERT TO SVG" action: same small pill as the three G-code buttons, centred on its own row, with the
 * same little spinner while the conversion runs.
 */
@Composable
fun ConvertButtonRow(
    text: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    busy: Boolean = false,
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(VfSpacing.sm, Alignment.CenterHorizontally),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CompactActionButton(text, icon, filled = true, onClick = onClick, enabled = enabled)
        if (busy) {
            androidx.compose.material3.CircularProgressIndicator(
                modifier = Modifier.size(18.dp),
                strokeWidth = 2.dp,
                color = MaterialTheme.colorScheme.primary,
            )
        }
    }
}

@Composable
private fun CompactActionButton(
    text: String,
    icon: ImageVector,
    filled: Boolean,
    onClick: () -> Unit,
    enabled: Boolean,
    modifier: Modifier = Modifier,
) {
    val primary = MaterialTheme.colorScheme.primary
    Button(
        onClick = onClick,
        enabled = enabled,
        shape = CircleShape,
        colors = if (filled) {
            ButtonDefaults.buttonColors(
                containerColor = primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
            )
        } else {
            ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                contentColor = primary,
            )
        },
        border = if (filled) null else BorderStroke(1.dp, primary.copy(alpha = if (enabled) 0.6f else 0.2f)),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 0.dp),
        modifier = modifier.height(36.dp),
    ) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(16.dp))
        Text(text, style = VfType.labelMd, modifier = Modifier.padding(start = 6.dp), maxLines = 1)
    }
}

/** The status card shown at the bottom of each pipeline stage ("Engine Online" / "Vector to CNC Ready" / errors). */
@Composable
fun StatusCard(
    icon: ImageVector,
    kicker: String,
    kickerSuffix: String,
    title: String,
    detail: String,
    accentColor: Color,
    modifier: Modifier = Modifier,
    trailingBadge: (@Composable () -> Unit)? = null,
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(VfRadius.xl2))
            .background(MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.6f))
            .padding(VfSpacing.md),
        horizontalArrangement = Arrangement.spacedBy(VfSpacing.sm),
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(accentColor.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(20.dp))
        }
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(kicker, style = VfType.labelSm, color = accentColor)
                Text(kickerSuffix, style = VfType.labelSm, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Text(title, style = VfType.headlineSm, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.padding(top = 2.dp))
            Text(detail, style = VfType.bodySm, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 2.dp))
            if (trailingBadge != null) {
                Box(Modifier.padding(top = VfSpacing.sm)) { trailingBadge() }
            }
        }
    }
}

/** Stage header row: icon chip + "Stage 0N" kicker + title, with a trailing badge pill. */
@Composable
fun StageHeader(
    icon: ImageVector,
    stageLabel: String,
    title: String,
    badgeText: String,
    accentColor: Color,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(VfSpacing.sm)) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(accentColor.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(22.dp))
            }
            Column {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(Modifier.size(width = 10.dp, height = 2.dp).background(accentColor, RoundedCornerShape(50)))
                    Text(stageLabel, style = VfType.labelSm, color = accentColor)
                }
                Text(title, style = VfType.titleMd, color = MaterialTheme.colorScheme.onSurface)
            }
        }
        PillBadge(badgeText, accentColor)
    }
}

/**
 * Outer rounded card wrapping each pipeline stage's whole section.
 * [contentPadding] is the inner padding (the Convert screen narrows it on small screens so the fields get more
 * of the width). In the light theme the card gets a hairline outline, since it is only a few percent darker than
 * the page; the dark theme never had one.
 */
@Composable
fun SectionCard(
    modifier: Modifier = Modifier,
    contentPadding: Dp = VfSpacing.lg,
    content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit,
) {
    val shape = RoundedCornerShape(VfRadius.xl3)
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .background(MaterialTheme.colorScheme.surfaceContainer)
            .then(
                if (LocalVfDarkTheme.current) Modifier
                else Modifier.border(1.dp, MaterialTheme.colorScheme.outlineVariant, shape)
            )
            .padding(contentPadding),
        verticalArrangement = Arrangement.spacedBy(VfSpacing.md),
        content = content,
    )
}

/** "TURN POLICY" dropdown selector. Uses the plain, long-stable `DropdownMenu`
 *  (anchored to a Box) rather than `ExposedDropdownMenuBox`/`ExposedDropdownMenu`,
 *  whose exact API shape has changed across Material3 versions. */
@Composable
fun <T> LabeledDropdown(
    label: String,
    options: List<T>,
    selected: T,
    optionLabel: (T) -> String,
    onSelect: (T) -> Unit,
    modifier: Modifier = Modifier,
) {
    var expanded by remember { mutableStateOf(false) }
    Column(modifier.fillMaxWidth()) {
        Text(label, style = VfType.labelMd, color = MaterialTheme.colorScheme.onSurface)
        Box(Modifier.padding(top = 4.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(VfRadius.xl))
                    .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                    .clickable { expanded = true }
                    .padding(horizontal = VfSpacing.md, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(optionLabel(selected), style = VfType.labelMd, color = MaterialTheme.colorScheme.onSurface)
                Icon(Icons.Filled.ExpandMore, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            androidx.compose.material3.DropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false },
            ) {
                options.forEach { option ->
                    androidx.compose.material3.DropdownMenuItem(
                        text = { Text(optionLabel(option), style = VfType.labelMd) },
                        onClick = { onSelect(option); expanded = false },
                    )
                }
            }
        }
    }
}

