package com.vectorforge.app.data

import com.vectorforge.app.engine.gcode.Args

/**
 * The generator's own default for every parameter, read straight from a
 * fresh `Args()` so it can never drift from the engine. Used only to show a
 * faint placeholder in inputs the user hasn't touched -- these values are
 * NOT passed to the generator unless the user types something.
 */
object GcodeDefaults {
    private val d = Args()

    val startDelayMs: Int = d.startDelay
    val stopDelayMs: Int = d.stopDelay
    val registerPen: Boolean = d.registerPen
    val zFeedrate: Double = d.zFeedrate
    val zHeight: Double = d.zHeight
    val finishedHeight: Double = d.finishedHeight
    val xHome: Double = d.xHome
    val yHome: Double = d.yHome
    val numCopies: Int = d.numCopies
    val continuousPlotting: Boolean = d.continuous
    val pauseOnLayerChange: Boolean = d.pauseOnLayerChange
    val flatness: Double = d.flatness
    val dpi: Double = d.dpi
    val minChange: Double = d.minChange
    val skipFactor: Int = d.skipFactor
    val normalizeOutputBounds: Boolean = !d.noNormalize
}
