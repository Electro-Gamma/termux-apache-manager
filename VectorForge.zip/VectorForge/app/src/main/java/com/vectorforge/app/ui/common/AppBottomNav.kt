package com.vectorforge.app.ui.common

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Transform
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import com.vectorforge.app.ui.theme.VfType

enum class AppTab(val label: String, val icon: ImageVector) {
    CONVERT("Convert", Icons.Filled.Transform),
    GCODE_VIEWER("G-Code Viewer", Icons.Filled.Terminal),
}

/**
 * The bottom bar: the two screen tabs, plus (when [onToggleTheme] is given) the Light / Dark theme switch.
 * The switch is here because this bar is the one element visible on every screen, so the theme can be changed
 * from anywhere. [darkTheme] is the currently active theme.
 */
@Composable
fun AppBottomNav(
    selected: AppTab,
    onSelect: (AppTab) -> Unit,
    modifier: Modifier = Modifier,
    darkTheme: Boolean = true,
    onToggleTheme: (() -> Unit)? = null,
) {
    val separator = MaterialTheme.colorScheme.outlineVariant
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceContainerLowest.copy(alpha = 0.95f))
            // The light bar is white on a near-white page, so it gets a hairline on top; the dark bar never had one.
            .then(
                if (darkTheme) Modifier else Modifier.drawBehind {
                    drawLine(separator, Offset(0f, 0f), Offset(size.width, 0f), strokeWidth = 1.dp.toPx())
                }
            )
            .windowInsetsPadding(WindowInsets.navigationBars),
        horizontalArrangement = Arrangement.SpaceAround,
    ) {
        AppTab.entries.forEach { tab ->
            val isSelected = tab == selected
            val tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
            Column(
                modifier = Modifier
                    .height(64.dp)
                    .width(96.dp)
                    .clickable { onSelect(tab) },
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f) else androidx.compose.ui.graphics.Color.Transparent)
                        .padding(horizontal = 20.dp, vertical = 2.dp),
                ) {
                    Icon(tab.icon, contentDescription = tab.label, tint = tint)
                }
                Text(tab.label.uppercase(), style = VfType.labelMd, color = tint, modifier = Modifier.padding(top = 4.dp))
            }
        }
        if (onToggleTheme != null) {
            ThemeSwitch(darkTheme = darkTheme, onToggle = onToggleTheme)
        }
    }
}

/**
 * The Light / Dark switch: a real Switch whose thumb shows a sun (light) or moon (dark), with the active theme
 * named below it. The whole cell is the touch target (the Switch itself is display-only, which is the recommended
 * pattern so the row has a single, accessible toggle).
 */
@Composable
private fun ThemeSwitch(darkTheme: Boolean, onToggle: () -> Unit) {
    val colors = MaterialTheme.colorScheme
    Column(
        modifier = Modifier
            .height(64.dp)
            .width(96.dp)
            .toggleable(value = darkTheme, role = Role.Switch, onValueChange = { onToggle() }),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Switch(
            checked = darkTheme,
            onCheckedChange = null,
            thumbContent = {
                Icon(
                    imageVector = if (darkTheme) Icons.Filled.DarkMode else Icons.Filled.LightMode,
                    contentDescription = if (darkTheme) "Dark theme on" else "Light theme on",
                    modifier = Modifier.size(SwitchDefaults.IconSize),
                )
            },
            colors = SwitchDefaults.colors(
                checkedThumbColor = colors.onPrimary,
                checkedTrackColor = colors.primary,
                checkedIconColor = colors.primary,
                checkedBorderColor = androidx.compose.ui.graphics.Color.Transparent,
                uncheckedThumbColor = colors.onSurfaceVariant,
                uncheckedTrackColor = colors.surfaceContainerHighest,
                uncheckedIconColor = colors.surfaceContainerHighest,
                uncheckedBorderColor = colors.outline,
            ),
        )
        Text(
            if (darkTheme) "DARK" else "LIGHT",
            style = VfType.labelMd,
            color = colors.onSurfaceVariant,
            modifier = Modifier.padding(top = 4.dp),
        )
    }
}
