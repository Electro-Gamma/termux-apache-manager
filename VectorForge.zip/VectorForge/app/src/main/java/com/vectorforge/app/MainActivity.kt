package com.vectorforge.app

import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import com.vectorforge.app.data.ConvertViewModel
import com.vectorforge.app.data.ViewerTarget
import com.vectorforge.app.ncviewer.NcViewerController
import com.vectorforge.app.ncviewer.ViewerTheme
import com.vectorforge.app.ui.common.AppBottomNav
import com.vectorforge.app.ui.common.AppTab
import com.vectorforge.app.ui.convert.ConvertScreen
import com.vectorforge.app.ui.theme.ThemePreference
import com.vectorforge.app.ui.theme.VectorForgeTheme
import com.vectorforge.app.ui.theme.WindowBackgroundDarkArgb
import com.vectorforge.app.ui.theme.WindowBackgroundLightArgb
import com.vectorforge.app.ui.viewer.GcodeViewerScreen

class MainActivity : ComponentActivity() {

    // The NC Viewer (G-Code Viewer tab). Created the first time it is needed -- the first time the tab is
    // shown, or the first "Generate + Viewer" press -- and then kept for the life of this Activity, so the
    // files loaded into it survive switching tabs.
    private var ncViewerInstance: NcViewerController? = null

    private fun ncViewer(): NcViewerController =
        ncViewerInstance ?: NcViewerController(this).also { ncViewerInstance = it }

    // The Light / Dark choice. Loaded from the saved preference (dark = the original look, the default), changed
    // by the switch in the bottom bar, saved again on every change. Being Compose state, changing it recomposes
    // the whole UI with the other colour scheme without recreating any screen (so nothing typed or loaded is lost).
    private var darkTheme by mutableStateOf(true)

    private fun applyTheme(dark: Boolean) {
        darkTheme = dark
        ViewerTheme.setDark(dark) // the native viewer pills / divider / dialogs follow the same switch
        window.setBackgroundDrawable(ColorDrawable(if (dark) WindowBackgroundDarkArgb else WindowBackgroundLightArgb))
    }

    private fun toggleTheme() {
        val dark = !darkTheme
        ThemePreference.setDark(this, dark)
        applyTheme(dark)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Before anything is created: the viewer's pills read the theme when they are built.
        applyTheme(ThemePreference.isDark(this))
        enableEdgeToEdge(
            statusBarStyle = statusBarStyle(darkTheme),
            navigationBarStyle = navigationBarStyle(darkTheme),
        )
        setContent {
            VectorForgeTheme(darkTheme = darkTheme) {
                // Status / navigation bar icons must be light on the dark theme and dark on the light theme; the
                // system's own dark mode says nothing about which one the app is showing.
                DisposableEffect(darkTheme) {
                    enableEdgeToEdge(
                        statusBarStyle = statusBarStyle(darkTheme),
                        navigationBarStyle = navigationBarStyle(darkTheme),
                    )
                    onDispose { }
                }
                VectorForgeApp(
                    ncViewer = { ncViewer() },
                    darkTheme = darkTheme,
                    onToggleTheme = ::toggleTheme,
                )
            }
        }
    }

    private fun statusBarStyle(dark: Boolean): SystemBarStyle =
        if (dark) SystemBarStyle.dark(Color.TRANSPARENT)
        else SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT)

    // Same scrims enableEdgeToEdge() uses by default (they only show with the 3-button navigation bar).
    private fun navigationBarStyle(dark: Boolean): SystemBarStyle =
        if (dark) SystemBarStyle.dark(Color.argb(0x80, 0x1b, 0x1b, 0x1b))
        else SystemBarStyle.light(Color.argb(0xe6, 0xFF, 0xFF, 0xFF), Color.argb(0x80, 0x1b, 0x1b, 0x1b))

    // NC Viewer's file pickers (its "Open file" pills and the site's own Open button) return through here.
    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (ncViewerInstance?.onActivityResult(requestCode, resultCode, data) == true) return
        super.onActivityResult(requestCode, resultCode, data)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        ncViewerInstance?.onConfigurationChanged(newConfig)
    }

    override fun onDestroy() {
        ncViewerInstance?.destroy()
        ncViewerInstance = null
        super.onDestroy()
    }
}

@Composable
private fun VectorForgeApp(
    ncViewer: () -> NcViewerController,
    darkTheme: Boolean,
    onToggleTheme: () -> Unit,
) {
    val viewModel: ConvertViewModel = viewModel()
    var selectedTab by rememberSaveable { mutableStateOf(AppTab.CONVERT) }

    // "Generate + Viewer 1" / "Generate + Viewer 2 (Split)": once the G-code file has been written, show the
    // G-Code Viewer tab and hand the file to the requested viewer pane (Viewer 1 = single view, no split;
    // Viewer 2 = split view, second pane). The plain "Generate" button never produces a request.
    LaunchedEffect(viewModel) {
        viewModel.viewerRequests.collect { request ->
            selectedTab = AppTab.GCODE_VIEWER
            ncViewer().openGeneratedGcode(
                file = request.gcodeFile,
                split = request.target == ViewerTarget.VIEWER_2_SPLIT,
            )
        }
    }

    // Short "it worked" toasts ("SVG ready: ...", "G-code ready: ..."). The permanent status cards are gone from the
    // Convert screen: failures show in a dialog, the full status is at the top of each Parameters dropdown.
    val context = LocalContext.current
    LaunchedEffect(viewModel) {
        viewModel.messages.collect { Toast.makeText(context, it, Toast.LENGTH_SHORT).show() }
    }

    // -- Input pickers: system Photo Picker (images) / SAF document picker (SVG) --
    // Neither requires a manifest permission; both grant per-file read access.
    val pickImageLauncher = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        uri?.let(viewModel::onImageSelected)
    }
    val pickSvgLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let(viewModel::onSvgSelected)
    }

    // -- "Export to..." (the reference's folder/drive_file_move icon buttons): SAF "Save As" --
    val exportSvgLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/svg+xml")) { uri ->
        uri?.let(viewModel::exportSvgTo)
    }
    val exportGcodeLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        uri?.let(viewModel::exportGcodeTo)
    }

    Scaffold(
        bottomBar = {
            AppBottomNav(
                selected = selectedTab,
                onSelect = { selectedTab = it },
                darkTheme = darkTheme,
                onToggleTheme = onToggleTheme,
            )
        },
    ) { innerPadding ->
        Box(Modifier.fillMaxSize().padding(innerPadding)) {
            when (selectedTab) {
                AppTab.CONVERT -> ConvertScreen(
                    viewModel = viewModel,
                    onPickImage = {
                        pickImageLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                    onPickSvg = {
                        pickSvgLauncher.launch(arrayOf("image/svg+xml", "text/xml", "*/*"))
                    },
                    onExportSvg = {
                        val name = viewModel.potrace.value.generatedSvgFile?.name ?: "traced.svg"
                        exportSvgLauncher.launch(name)
                    },
                    onExportGcode = {
                        val name = viewModel.gcode.value.generatedGcodeFile?.name ?: "output.gcode"
                        exportGcodeLauncher.launch(name)
                    },
                )
                AppTab.GCODE_VIEWER -> GcodeViewerScreen(controller = ncViewer())
            }
        }
    }
}
