package com.vectorforge.app

import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.vectorforge.app.data.ConvertViewModel
import com.vectorforge.app.data.ViewerTarget
import com.vectorforge.app.ncviewer.NcViewerController
import com.vectorforge.app.ui.common.AppBottomNav
import com.vectorforge.app.ui.common.AppTab
import com.vectorforge.app.ui.common.AppTopBar
import com.vectorforge.app.ui.convert.ConvertScreen
import com.vectorforge.app.ui.theme.VectorForgeTheme
import com.vectorforge.app.ui.viewer.GcodeViewerScreen

class MainActivity : ComponentActivity() {

    // The NC Viewer (G-Code Viewer tab). Created the first time it is needed -- the first time the tab is
    // shown, or the first "Generate + Viewer" press -- and then kept for the life of this Activity, so the
    // files loaded into it survive switching tabs.
    private var ncViewerInstance: NcViewerController? = null

    private fun ncViewer(): NcViewerController =
        ncViewerInstance ?: NcViewerController(this).also { ncViewerInstance = it }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            VectorForgeTheme {
                VectorForgeApp(ncViewer = { ncViewer() })
            }
        }
    }

    // NC Viewer's file pickers (its "Open file" pills and the site's own Open button) return through here.
    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (ncViewerInstance?.onActivityResult(requestCode, resultCode, data) == true) return
        super.onActivityResult(requestCode, resultCode, data)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        ncViewerInstance?.onConfigurationChanged(newConfig)
    }

    override fun onDestroy() {
        ncViewerInstance?.destroy()
        ncViewerInstance = null
        super.onDestroy()
    }
}

@Composable
private fun VectorForgeApp(ncViewer: () -> NcViewerController) {
    val viewModel: ConvertViewModel = viewModel()
    var selectedTab by rememberSaveable { mutableStateOf(AppTab.CONVERT) }

    // "Generate + Viewer 1" / "Generate + Viewer 2 (Split)": once the G-code file has been written, show the
    // G-Code Viewer tab and hand the file to the requested viewer pane (Viewer 1 = single view, no split;
    // Viewer 2 = split view, second pane). The plain "Generate" button never produces a request.
    LaunchedEffect(viewModel) {
        viewModel.viewerRequests.collect { request ->
            selectedTab = AppTab.GCODE_VIEWER
            ncViewer().openGeneratedGcode(
                file = request.gcodeFile,
                split = request.target == ViewerTarget.VIEWER_2_SPLIT,
            )
        }
    }

    // -- Input pickers: system Photo Picker (images) / SAF document picker (SVG) --
    // Neither requires a manifest permission; both grant per-file read access.
    val pickImageLauncher = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        uri?.let(viewModel::onImageSelected)
    }
    val pickSvgLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let(viewModel::onSvgSelected)
    }

    // -- "Export to..." (the reference's folder/drive_file_move icon buttons): SAF "Save As" --
    val exportSvgLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/svg+xml")) { uri ->
        uri?.let(viewModel::exportSvgTo)
    }
    val exportGcodeLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        uri?.let(viewModel::exportGcodeTo)
    }

    Scaffold(
        topBar = { AppTopBar() },
        bottomBar = { AppBottomNav(selected = selectedTab, onSelect = { selectedTab = it }) },
    ) { innerPadding ->
        Box(Modifier.fillMaxSize().padding(innerPadding)) {
            when (selectedTab) {
                AppTab.CONVERT -> ConvertScreen(
                    viewModel = viewModel,
                    onPickImage = {
                        pickImageLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                    onPickSvg = {
                        pickSvgLauncher.launch(arrayOf("image/svg+xml", "text/xml", "*/*"))
                    },
                    onExportSvg = {
                        val name = viewModel.potrace.value.generatedSvgFile?.name ?: "traced.svg"
                        exportSvgLauncher.launch(name)
                    },
                    onExportGcode = {
                        val name = viewModel.gcode.value.generatedGcodeFile?.name ?: "output.gcode"
                        exportGcodeLauncher.launch(name)
                    },
                )
                AppTab.GCODE_VIEWER -> {
                    GcodeViewerScreen(controller = ncViewer())
                }
            }
        }
    }
}
