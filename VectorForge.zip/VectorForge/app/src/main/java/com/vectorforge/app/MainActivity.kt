package com.vectorforge.app

import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import com.vectorforge.app.data.ConvertViewModel
import com.vectorforge.app.ncviewer.NCViewerHost
import com.vectorforge.app.ui.common.AppBottomNav
import com.vectorforge.app.ui.common.AppTab
import com.vectorforge.app.ui.common.AppTopBar
import com.vectorforge.app.ui.convert.ConvertScreen
import com.vectorforge.app.ui.theme.VectorForgeTheme
import com.vectorforge.app.ui.viewer.GcodeViewerScreen

class MainActivity : ComponentActivity() {

    // Built once, here, and reused for the Activity's whole lifetime (matching this Activity's own
    // configChanges below, which already avoids recreation on rotation) -- see NCViewerHost's own
    // doc comment for why this is a plain field rather than something Compose creates/disposes.
    lateinit var ncViewerHost: NCViewerHost
        private set

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        ncViewerHost = NCViewerHost(this)
        setContent {
            VectorForgeTheme {
                VectorForgeApp()
            }
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        ncViewerHost.onConfigurationChanged()
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (ncViewerHost.onActivityResult(requestCode, resultCode, data)) return
        super.onActivityResult(requestCode, resultCode, data)
    }
}

@Composable
private fun VectorForgeApp() {
    val activity = LocalContext.current as MainActivity
    val viewModel: ConvertViewModel = viewModel()
    var selectedTab by rememberSaveable { mutableStateOf(AppTab.CONVERT) }

    // -- Input pickers: system Photo Picker (images) / SAF document picker (SVG) --
    // Neither requires a manifest permission; both grant per-file read access.
    val pickImageLauncher = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        uri?.let(viewModel::onImageSelected)
    }
    val pickSvgLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let(viewModel::onSvgSelected)
    }

    // -- "Export to..." (the reference's folder/drive_file_move icon buttons): SAF "Save As" --
    val exportSvgLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/svg+xml")) { uri ->
        uri?.let(viewModel::exportSvgTo)
    }
    val exportGcodeLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        uri?.let(viewModel::exportGcodeTo)
    }

    Scaffold(
        topBar = { AppTopBar() },
        bottomBar = { AppBottomNav(selected = selectedTab, onSelect = { selectedTab = it }) },
    ) { innerPadding ->
        Box(Modifier.fillMaxSize().padding(innerPadding)) {
            when (selectedTab) {
                AppTab.CONVERT -> ConvertScreen(
                    viewModel = viewModel,
                    onPickImage = {
                        pickImageLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                    onPickSvg = {
                        pickSvgLauncher.launch(arrayOf("image/svg+xml", "text/xml", "*/*"))
                    },
                    onExportSvg = {
                        val name = viewModel.potrace.value.generatedSvgFile?.name ?: "traced.svg"
                        exportSvgLauncher.launch(name)
                    },
                    onExportGcode = {
                        val name = viewModel.gcode.value.generatedGcodeFile?.name ?: "output.gcode"
                        exportGcodeLauncher.launch(name)
                    },
                    // "Generate -> Viewer 1/2" buttons: push the file into the embedded NC Viewer
                    // (see NCViewerHost.sendGeneratedFile) and switch to its tab so the result is
                    // immediately visible.
                    onSendToViewer = { file, paneId, mode ->
                        activity.ncViewerHost.sendGeneratedFile(file, paneId, mode)
                        selectedTab = AppTab.GCODE_VIEWER
                    },
                )
                AppTab.GCODE_VIEWER -> GcodeViewerScreen(ncViewerHost = activity.ncViewerHost)
            }
        }
    }
}
