package com.vectorforge.app.sender

import android.Manifest
import android.annotation.SuppressLint
import android.app.Application
import android.app.PendingIntent
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.vectorforge.app.data.FileRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.io.IOException
import java.util.Locale

enum class LinkType(val label: String) { BLUETOOTH("Bluetooth"), WIFI("Wi-Fi"), USB("USB") }

enum class Firmware(val label: String) {
    PLOTTER("Mini CNC Plotter sketch"),
    GRBL("GRBL 1.1 / grblHAL / FluidNC"),
    GRBL09("GRBL 0.9"),
    GENERIC("Marlin / Smoothieware / Repetier");

    val isGrbl: Boolean get() = this == GRBL || this == GRBL09
}

enum class ConnState { DISCONNECTED, CONNECTING, CONNECTED }
enum class JobState { IDLE, RUNNING, PAUSED }
enum class LogKind { TX, RX, INFO, ERROR }

data class ConsoleLine(val id: Long, val kind: LogKind, val text: String)

/** One selectable port: a paired Bluetooth device (id = MAC address) or an attached USB device (id = device name). */
data class PortChoice(val id: String, val name: String)

data class SenderUiState(
    // -- connection -----------------------------------------------------------------------------------------
    val linkType: LinkType = LinkType.BLUETOOTH,
    val firmware: Firmware = Firmware.PLOTTER,
    val conn: ConnState = ConnState.DISCONNECTED,
    val connLabel: String = "",
    val baud: Int = 9600,
    val host: String = "192.168.4.1",
    val port: Int = 23,
    val btDevices: List<PortChoice> = emptyList(),
    val selectedBt: String? = null,
    val usbDevices: List<PortChoice> = emptyList(),
    val selectedUsb: String? = null,
    // -- machine / jog --------------------------------------------------------------------------------------
    val x: Double = 0.0,
    val y: Double = 0.0,
    val z: Double = 0.0,
    val penDown: Boolean? = null,
    val machineState: String = "",
    val stepMm: Double = 1.0,
    val jogFeed: Int = 3000,
    val feedPercent: Int = 100,
    val workX: Double = 40.0,
    val workY: Double = 40.0,
    val penUpS: Int = 50,
    val penDownS: Int = 30,
    val statusNote: String? = null,
    val rapidPercent: Int = 100,
    val translatePen: Boolean = true,
    val penUpCmd: String = "M5",
    val penDownCmd: String = "M3 S1000",
    val macros: List<String> = listOf("", "", "", ""),
    // -- job -------------------------------------------------------------------------------------------------
    val fileName: String = "",
    val summary: GcodeLineTools.Summary? = null,
    val job: JobState = JobState.IDLE,
    val sentLines: Int = 0,
    val totalLines: Int = 0,
    val elapsedSec: Int = 0,
    val notice: String? = null,
    val noticeIsError: Boolean = false,
    val ignoreErrors: Boolean = false,
    val logJobTraffic: Boolean = true,
    // -- dialogs ---------------------------------------------------------------------------------------------
    val errorDialog: String? = null,
) {
    val connected: Boolean get() = conn == ConnState.CONNECTED
    // GRBL keeps streaming from its own buffer while held, so only real-time commands make sense then.
    val canJog: Boolean get() = connected && (job == JobState.IDLE || (job == JobState.PAUSED && !firmware.isGrbl))
    val progress: Float get() = if (totalLines <= 0) 0f else (sentLines.toFloat() / totalLines).coerceIn(0f, 1f)
}

/**
 * The G-code controller / sender behind the "Controller" tab.
 *
 * Protocol: strictly one line in flight. Every line is written terminated by a single '\n' and the next one is only
 * written once the machine answers "ok" (what the Mini CNC Plotter sketch and GRBL / Marlin all do). A single '\n'
 * matters: the stock sketch prints one "ok" per CR *and* per LF, so CR+LF would produce two acknowledgements.
 */
class SenderViewModel(application: Application) : AndroidViewModel(application) {

    private val app: Application = application
    private val prefs = app.getSharedPreferences("controller", Context.MODE_PRIVATE)

    private val _ui = MutableStateFlow(SenderUiState())
    val ui: StateFlow<SenderUiState> = _ui.asStateFlow()

    private val _console = MutableStateFlow<List<ConsoleLine>>(emptyList())
    val console: StateFlow<List<ConsoleLine>> = _console.asStateFlow()

    // -- link / protocol state ------------------------------------------------------------------------------------
    private var link: SerialLink? = null
    private var readerJob: Job? = null
    private var connectJob: Job? = null
    private var pollJob: Job? = null

    private data class Ack(val ok: Boolean, val text: String)

    private sealed class Reply {
        object Ok : Reply()
        data class Err(val message: String) : Reply()
        object Timeout : Reply()
        object NotConnected : Reply()
    }

    private val acks = Channel<Ack>(Channel.UNLIMITED)
    private var outstanding = 0        // lines written whose "ok" has not been consumed yet (Main thread only)
    private val cmdMutex = Mutex()     // one line in flight
    private val writeMutex = Mutex()   // serialises raw writes (lines vs. real-time bytes)
    private val manualMutex = Mutex()  // keeps multi-line manual sequences (G91 / move / G90) together

    // -- job state (Main thread only) ---------------------------------------------------------------------------------
    private var program: List<String> = emptyList()
    private var jobIndex = 0
    private var jobCoroutine: Job? = null
    private val pauseFlag = MutableStateFlow(false)

    // -- console buffering ----------------------------------------------------------------------------------------------
    private val consoleBuf = ArrayDeque<ConsoleLine>()
    private var consoleSeq = 0L
    @Volatile private var consoleDirty = false

    // -- USB permission -----------------------------------------------------------------------------------------------------
    private var usbPermission: CompletableDeferred<Boolean>? = null
    private val usbReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == ACTION_USB_PERMISSION) {
                usbPermission?.complete(intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false))
            }
        }
    }

    private val usbManager: UsbManager? get() = app.getSystemService(Context.USB_SERVICE) as? UsbManager
    private val btAdapter: BluetoothAdapter?
        get() = (app.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter

    init {
        loadPrefs()
        ContextCompat.registerReceiver(
            app, usbReceiver, IntentFilter(ACTION_USB_PERMISSION), ContextCompat.RECEIVER_NOT_EXPORTED,
        )
        // Publishes the console at most ~8x per second so a fast job cannot flood the UI.
        viewModelScope.launch {
            while (true) {
                delay(120)
                if (consoleDirty) {
                    consoleDirty = false
                    _console.value = synchronized(consoleBuf) { consoleBuf.toList() }
                }
            }
        }
        // Job clock.
        viewModelScope.launch {
            while (true) {
                delay(1000)
                if (_ui.value.job == JobState.RUNNING) _ui.update { it.copy(elapsedSec = it.elapsedSec + 1) }
            }
        }
        refreshPorts()
    }

    override fun onCleared() {
        try { app.unregisterReceiver(usbReceiver) } catch (_: Exception) { }
        val l = link
        link = null
        if (l != null) Thread { l.close() }.start()
        super.onCleared()
    }

    // ==========================================================================================================
    // Settings
    // ==========================================================================================================

    private fun loadPrefs() {
        val d = SenderUiState()
        _ui.update {
            it.copy(
                linkType = LinkType.entries.firstOrNull { t -> t.name == prefs.getString("linkType", null) } ?: d.linkType,
                firmware = Firmware.entries.firstOrNull { f -> f.name == prefs.getString("firmware", null) } ?: d.firmware,
                baud = prefs.getInt("baud", d.baud),
                host = prefs.getString("host", d.host) ?: d.host,
                port = prefs.getInt("port", d.port),
                selectedBt = prefs.getString("bt", null),
                stepMm = prefs.getFloat("step", d.stepMm.toFloat()).toDouble(),
                jogFeed = prefs.getInt("jogFeed", d.jogFeed),
                workX = prefs.getFloat("workX", d.workX.toFloat()).toDouble(),
                workY = prefs.getFloat("workY", d.workY.toFloat()).toDouble(),
                penUpS = prefs.getInt("penUp", d.penUpS),
                penDownS = prefs.getInt("penDown", d.penDownS),
                ignoreErrors = prefs.getBoolean("ignoreErrors", d.ignoreErrors),
                logJobTraffic = prefs.getBoolean("logJob", d.logJobTraffic),
                translatePen = prefs.getBoolean("translatePen", d.translatePen),
                penUpCmd = prefs.getString("penUpCmd", d.penUpCmd) ?: d.penUpCmd,
                penDownCmd = prefs.getString("penDownCmd", d.penDownCmd) ?: d.penDownCmd,
                macros = List(4) { i -> prefs.getString("macro$i", "") ?: "" },
            )
        }
    }

    private fun savePrefs() {
        val s = _ui.value
        prefs.edit()
            .putString("linkType", s.linkType.name)
            .putString("firmware", s.firmware.name)
            .putInt("baud", s.baud)
            .putString("host", s.host)
            .putInt("port", s.port)
            .putString("bt", s.selectedBt)
            .putFloat("step", s.stepMm.toFloat())
            .putInt("jogFeed", s.jogFeed)
            .putFloat("workX", s.workX.toFloat())
            .putFloat("workY", s.workY.toFloat())
            .putInt("penUp", s.penUpS)
            .putInt("penDown", s.penDownS)
            .putBoolean("ignoreErrors", s.ignoreErrors)
            .putBoolean("logJob", s.logJobTraffic)
            .putBoolean("translatePen", s.translatePen)
            .putString("penUpCmd", s.penUpCmd)
            .putString("penDownCmd", s.penDownCmd)
            .putString("macro0", s.macros[0])
            .putString("macro1", s.macros[1])
            .putString("macro2", s.macros[2])
            .putString("macro3", s.macros[3])
            .apply()
    }

    private fun edit(block: (SenderUiState) -> SenderUiState) {
        _ui.update(block)
        savePrefs()
    }

    fun setLinkType(v: LinkType) = edit { it.copy(linkType = v) }
    fun setFirmware(v: Firmware) = edit {
        // 9600 is what the Mini CNC Plotter sketch uses; GRBL ships at 115200.
        it.copy(firmware = v, baud = if (v == Firmware.GRBL && it.baud == 9600) 115200 else if (v == Firmware.PLOTTER && it.baud == 115200) 9600 else it.baud)
    }
    fun setBaud(v: Int) = edit { it.copy(baud = v) }
    fun setHost(v: String) = edit { it.copy(host = v.trim()) }
    fun setPort(v: Int) = edit { it.copy(port = v.coerceIn(1, 65535)) }
    fun selectBluetooth(id: String) = edit { it.copy(selectedBt = id) }
    fun selectUsb(id: String) = edit { it.copy(selectedUsb = id) }
    fun setStep(v: Double) = edit { it.copy(stepMm = v) }
    fun setJogFeed(v: Int) = edit { it.copy(jogFeed = v.coerceIn(10, 20000)) }
    fun setWorkX(v: Double) = edit { it.copy(workX = v.coerceAtLeast(1.0)) }
    fun setWorkY(v: Double) = edit { it.copy(workY = v.coerceAtLeast(1.0)) }
    fun setPenUpS(v: Int) = edit { it.copy(penUpS = v.coerceIn(0, 255)) }
    fun setPenDownS(v: Int) = edit { it.copy(penDownS = v.coerceIn(0, 255)) }
    fun setIgnoreErrors(v: Boolean) = edit { it.copy(ignoreErrors = v) }
    fun setLogJobTraffic(v: Boolean) = edit { it.copy(logJobTraffic = v) }
    fun setTranslatePen(v: Boolean) = edit { it.copy(translatePen = v) }
    fun setPenUpCmd(v: String) = edit { it.copy(penUpCmd = v) }
    fun setPenDownCmd(v: String) = edit { it.copy(penDownCmd = v) }
    fun setMacro(index: Int, text: String) = edit { s ->
        s.copy(macros = s.macros.mapIndexed { i, old -> if (i == index) text else old })
    }
    fun dismissError() = _ui.update { it.copy(errorDialog = null) }
    fun clearConsole() {
        synchronized(consoleBuf) { consoleBuf.clear() }
        _console.value = emptyList()
    }

    // ==========================================================================================================
    // Ports
    // ==========================================================================================================

    fun hasBluetoothPermission(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
            ContextCompat.checkSelfPermission(app, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    /** Re-reads the paired Bluetooth devices and the attached USB devices. */
    @SuppressLint("MissingPermission")
    fun refreshPorts() {
        var bt: List<PortChoice> = emptyList()
        if (hasBluetoothPermission()) {
            try {
                bt = btAdapter?.bondedDevices.orEmpty()
                    .map { PortChoice(it.address, (it.name ?: it.address)) }
                    .sortedBy { it.name.lowercase(Locale.ROOT) }
            } catch (_: SecurityException) {
            }
        }
        val usb = usbManager?.deviceList?.values.orEmpty().map { PortChoice(it.deviceName, usbName(it)) }
        _ui.update { s ->
            s.copy(
                btDevices = bt,
                selectedBt = s.selectedBt?.takeIf { id -> bt.any { it.id == id } } ?: bt.firstOrNull()?.id,
                usbDevices = usb,
                selectedUsb = s.selectedUsb?.takeIf { id -> usb.any { it.id == id } } ?: usb.firstOrNull()?.id,
            )
        }
    }

    private fun usbName(d: UsbDevice): String {
        val id = String.format(Locale.ROOT, "%04X:%04X", d.vendorId, d.productId)
        val n = d.productName
        return if (n.isNullOrBlank()) "USB $id" else "$n ($id)"
    }

    // ==========================================================================================================
    // Connect / disconnect
    // ==========================================================================================================

    fun connect() {
        val s = _ui.value
        if (s.conn != ConnState.DISCONNECTED) return
        connectJob = viewModelScope.launch {
            _ui.update { it.copy(conn = ConnState.CONNECTING, statusNote = null) }
            outstanding = 0
            while (acks.tryReceive().isSuccess) { /* nothing from an earlier session */ }
            var l: SerialLink? = null
            try {
                l = buildLink(s)
                val opened = l
                withContext(Dispatchers.IO) { opened.open() }
                link = opened
                startReader(opened)
                log(LogKind.INFO, "Connected to ${opened.label}. Waiting for the machine to be ready...")
                delay(opened.settleMillis)
                _ui.update { it.copy(conn = ConnState.CONNECTED, connLabel = opened.label, statusNote = null) }
                afterConnect()
            } catch (e: CancellationException) {
                val half = l
                if (half != null) viewModelScope.launch(Dispatchers.IO) { half.close() }
                throw e
            } catch (e: Exception) {
                val dead = l
                if (dead != null) viewModelScope.launch(Dispatchers.IO) { dead.close() }
                link = null
                readerJob?.cancel()
                _ui.update { it.copy(conn = ConnState.DISCONNECTED, errorDialog = e.message ?: e.toString()) }
                log(LogKind.ERROR, "Connect failed: ${e.message}")
            }
        }
    }

    private suspend fun buildLink(s: SenderUiState): SerialLink = when (s.linkType) {
        LinkType.BLUETOOTH -> {
            if (!hasBluetoothPermission()) throw IOException("Bluetooth permission not granted")
            val adapter = btAdapter ?: throw IOException("This device has no Bluetooth")
            if (!adapter.isEnabled) throw IOException("Bluetooth is switched off")
            val id = s.selectedBt ?: throw IOException("Pair your HC-05 / HC-06 in Android's Bluetooth settings first, then pick it here")
            val dev = adapter.getRemoteDevice(id)
            val name = s.btDevices.firstOrNull { it.id == id }?.name ?: id
            BluetoothSerialLink(dev, name)
        }
        LinkType.WIFI -> {
            if (s.host.isBlank()) throw IOException("Enter the IP address of the Wi-Fi serial bridge")
            TcpSerialLink(s.host, s.port)
        }
        LinkType.USB -> {
            val mgr = usbManager ?: throw IOException("This device has no USB host support")
            val dev = mgr.deviceList.values.firstOrNull { it.deviceName == s.selectedUsb }
                ?: throw IOException("No USB device selected. Plug the board in with an OTG cable and press refresh")
            if (!ensureUsbPermission(mgr, dev)) throw IOException("USB permission was denied")
            UsbCdcSerialLink(mgr, dev, s.baud)
        }
    }

    private suspend fun ensureUsbPermission(mgr: UsbManager, dev: UsbDevice): Boolean {
        if (mgr.hasPermission(dev)) return true
        val waiter = CompletableDeferred<Boolean>()
        usbPermission = waiter
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0)
        val pi = PendingIntent.getBroadcast(app, 0, Intent(ACTION_USB_PERMISSION).setPackage(app.packageName), flags)
        mgr.requestPermission(dev, pi)
        val granted = withTimeoutOrNull(60_000L) { waiter.await() } ?: false
        usbPermission = null
        return granted
    }

    private fun afterConnect() {
        val s = _ui.value
        when (s.firmware) {
            Firmware.PLOTTER -> viewModelScope.launch { sendCommand("M114", MANUAL_TIMEOUT) }
            Firmware.GRBL, Firmware.GRBL09 -> {
                pollJob?.cancel()
                pollJob = viewModelScope.launch {
                    while (true) {
                        delay(400)
                        try { writeRealtime(byteArrayOf('?'.code.toByte())) } catch (_: IOException) { }
                    }
                }
            }
            Firmware.GENERIC -> viewModelScope.launch { sendCommand("M114", MANUAL_TIMEOUT) }
        }
    }

    /** Lines that were in GRBL's buffer when the link dropped may not have run: send them again on Resume. */
    private fun rewindGrblWindow() {
        jobIndex = (jobIndex - grblPending.size).coerceAtLeast(0)
        resetGrblStream()
    }

    fun disconnect() {
        rewindGrblWindow()
        connectJob?.cancel()
        pollJob?.cancel()
        jobCoroutine?.cancel()
        val l = link
        link = null
        readerJob?.cancel()
        if (l != null) viewModelScope.launch(Dispatchers.IO) { l.close() }
        val hadJob = _ui.value.job != JobState.IDLE
        _ui.update {
            it.copy(
                conn = ConnState.DISCONNECTED,
                machineState = "",
                job = if (hadJob) JobState.PAUSED else JobState.IDLE,
                notice = if (hadJob) "Disconnected at line ${jobIndex + 1}. Reconnect, then press Resume." else it.notice,
                noticeIsError = false,
            )
        }
        log(LogKind.INFO, "Disconnected")
    }

    private fun onLinkLost(l: SerialLink) {
        if (link !== l) return
        link = null
        rewindGrblWindow()
        pollJob?.cancel()
        jobCoroutine?.cancel()
        viewModelScope.launch(Dispatchers.IO) { l.close() }
        log(LogKind.ERROR, "Connection lost")
        _ui.update {
            val hadJob = it.job != JobState.IDLE
            it.copy(
                conn = ConnState.DISCONNECTED,
                machineState = "",
                job = if (hadJob) JobState.PAUSED else JobState.IDLE,
                notice = if (hadJob) "Connection lost at line ${jobIndex + 1}. Reconnect, then press Resume." else it.notice,
                noticeIsError = hadJob,
                statusNote = "Connection lost",
            )
        }
    }

    // ==========================================================================================================
    // Low level I/O
    // ==========================================================================================================

    private fun startReader(l: SerialLink) {
        readerJob?.cancel()
        readerJob = viewModelScope.launch {
            withContext(Dispatchers.IO) { readLoop(l) }
            onLinkLost(l)
        }
    }

    private fun readLoop(l: SerialLink) {
        val buf = ByteArray(512)
        val sb = StringBuilder()
        try {
            while (true) {
                val n = l.read(buf)
                if (n < 0) return
                for (k in 0 until n) {
                    val c = buf[k].toInt() and 0xFF
                    if (c == 10 || c == 13) {
                        if (sb.isNotEmpty()) {
                            handleRx(sb.toString().trim())
                            sb.setLength(0)
                        }
                    } else if (sb.length < 1024) {
                        sb.append(c.toChar())
                    }
                }
            }
        } catch (_: IOException) {
        }
    }

    private fun handleRx(line: String) {
        if (line.isEmpty()) return
        val lower = line.lowercase(Locale.ROOT)
        val quiet = !_ui.value.logJobTraffic && _ui.value.job == JobState.RUNNING
        when {
            lower == "ok" || lower.startsWith("ok ") -> {
                if (!quiet) log(LogKind.RX, line)
                acks.trySend(Ack(true, line))
            }
            lower.startsWith("error") -> {
                val text = GrblCodes.explain(line)
                log(LogKind.ERROR, text)
                acks.trySend(Ack(false, text))
            }
            lower.startsWith("alarm") -> {
                val text = GrblCodes.explain(line)
                log(LogKind.ERROR, text)
                _ui.update { it.copy(machineState = "ALARM") }
                acks.trySend(Ack(false, text))
            }
            line.startsWith("<") && line.endsWith(">") -> parseGrblStatus(line)
            else -> {
                log(LogKind.RX, line)
                parsePosition(line)
            }
        }
    }

    private var wco = Triple(0.0, 0.0, 0.0)

    private fun triple(m: MatchResult): Triple<Double, Double, Double>? {
        val a = m.groupValues[1].toDoubleOrNull() ?: return null
        val b = m.groupValues[2].toDoubleOrNull() ?: return null
        val c = m.groupValues[3].toDoubleOrNull() ?: return null
        return Triple(a, b, c)
    }

    /** `<Idle|MPos:..|WCO:..>` (GRBL 1.1) and `<Idle,MPos:..,WPos:..>` (GRBL 0.9). Shows the WORK position. */
    private fun parseGrblStatus(line: String) {
        val body = line.removePrefix("<").removeSuffix(">")
        val state = body.substringBefore('|').substringBefore(',')
        GRBL_WCO.find(body)?.let { m -> triple(m)?.let { wco = it } }
        val work = GRBL_WPOS.find(body)?.let { triple(it) }
        val machine = GRBL_MPOS.find(body)?.let { triple(it) }
        val pos = work ?: machine?.let { Triple(it.first - wco.first, it.second - wco.second, it.third - wco.third) }
        _ui.update { s ->
            if (pos != null) s.copy(machineState = state, x = pos.first, y = pos.second, z = pos.third)
            else s.copy(machineState = state)
        }
    }

    private fun parsePosition(line: String) {
        val m = M114_PLOTTER.find(line) ?: M114_MARLIN.find(line) ?: return
        val nx = m.groupValues[1].toDoubleOrNull() ?: return
        val ny = m.groupValues[2].toDoubleOrNull() ?: return
        _ui.update { it.copy(x = nx, y = ny) }
    }

    private fun log(kind: LogKind, text: String) {
        synchronized(consoleBuf) {
            consoleSeq += 1
            consoleBuf.addLast(ConsoleLine(consoleSeq, kind, text))
            while (consoleBuf.size > CONSOLE_MAX) consoleBuf.removeFirst()
        }
        consoleDirty = true
    }

    private suspend fun rawWrite(l: SerialLink, bytes: ByteArray) {
        withContext(Dispatchers.IO) { writeMutex.withLock { l.write(bytes) } }
    }

    private suspend fun writeRealtime(bytes: ByteArray) {
        val l = link ?: return
        rawWrite(l, bytes)
    }

    /** Writes one line and waits for the machine's "ok" / "error". Only one call is in flight at a time. */
    private suspend fun sendCommand(line: String, timeoutMs: Long, quiet: Boolean = false): Reply =
        cmdMutex.withLock {
            val l = link ?: return@withLock Reply.NotConnected
            // A line we stopped waiting for (timeout, Stop, cancelled job) is still answered later. Absorb those
            // late answers first, otherwise every following command would be "acknowledged" by the previous one.
            while (outstanding > 0) {
                val late = withTimeoutOrNull(LATE_ACK_WAIT) { acks.receive() }
                if (late == null) { outstanding = 0; break }
                outstanding -= 1
            }
            try {
                rawWrite(l, (line + "\n").toByteArray(Charsets.US_ASCII))
            } catch (e: IOException) {
                onLinkLost(l)
                return@withLock Reply.NotConnected
            }
            outstanding += 1
            if (!quiet && (_ui.value.logJobTraffic || _ui.value.job != JobState.RUNNING)) log(LogKind.TX, line)
            val ack = withTimeoutOrNull(timeoutMs) { acks.receive() }
            if (ack != null) outstanding -= 1
            when {
                ack == null -> Reply.Timeout
                ack.ok -> Reply.Ok
                else -> Reply.Err(ack.text)
            }
        }

    private fun describe(r: Reply): String = when (r) {
        is Reply.Ok -> "ok"
        is Reply.Err -> r.message
        is Reply.Timeout -> "No answer from the machine (timeout)"
        is Reply.NotConnected -> "Not connected"
    }

    // ==========================================================================================================
    // Manual control: jog / home / pen / speed / raw commands
    // ==========================================================================================================

    private fun noteFailure(r: Reply) {
        if (r is Reply.Ok) _ui.update { it.copy(statusNote = null) }
        else _ui.update { it.copy(statusNote = describe(r)) }
    }

    /** Jogs by [dx] / [dy] (each -1, 0 or +1) times the current step size. */
    fun jog(dx: Int, dy: Int) {
        if (!_ui.value.canJog) return
        viewModelScope.launch {
            manualMutex.withLock {
                val s = _ui.value
                if (!s.canJog) return@withLock
                val step = s.stepMm
                when (s.firmware) {
                    Firmware.PLOTTER -> {
                        // The sketch only understands absolute G1 X.. Y.., so the app tracks the position itself.
                        val nx = (s.x + dx * step).coerceIn(0.0, s.workX)
                        val ny = (s.y + dy * step).coerceIn(0.0, s.workY)
                        if (nx == s.x && ny == s.y) {
                            _ui.update { it.copy(statusNote = "Work-area limit reached (change it under Machine settings)") }
                            return@withLock
                        }
                        val r = sendCommand("G1 X${GcodeLineTools.num(nx)} Y${GcodeLineTools.num(ny)} F${s.jogFeed}", MANUAL_TIMEOUT)
                        if (r is Reply.Ok) _ui.update { it.copy(x = nx, y = ny) }
                        noteFailure(r)
                    }
                    Firmware.GRBL -> {
                        val r = sendCommand(
                            "\$J=G91 G21 X${GcodeLineTools.num(dx * step)} Y${GcodeLineTools.num(dy * step)} F${s.jogFeed}",
                            MANUAL_TIMEOUT,
                        )
                        noteFailure(r)
                    }
                    Firmware.GENERIC, Firmware.GRBL09 -> {
                        val r = relativeMove("X${GcodeLineTools.num(dx * step)} Y${GcodeLineTools.num(dy * step)}", s.jogFeed)
                        if (r is Reply.Ok) _ui.update { it.copy(x = it.x + dx * step, y = it.y + dy * step) }
                        noteFailure(r)
                    }
                }
            }
        }
    }

    /** Z axis jog (GRBL / generic). The Mini CNC Plotter has no Z axis: it uses [penUp] / [penDown] instead. */
    fun jogZ(dz: Int) {
        if (!_ui.value.canJog) return
        viewModelScope.launch {
            manualMutex.withLock {
                val s = _ui.value
                if (!s.canJog) return@withLock
                val d = GcodeLineTools.num(dz * s.stepMm)
                when (s.firmware) {
                    Firmware.GRBL -> noteFailure(sendCommand("\$J=G91 G21 Z$d F${s.jogFeed}", MANUAL_TIMEOUT))
                    Firmware.GENERIC, Firmware.GRBL09 -> {
                        val r = relativeMove("Z$d", s.jogFeed)
                        if (r is Reply.Ok) _ui.update { it.copy(z = it.z + dz * s.stepMm) }
                        noteFailure(r)
                    }
                    Firmware.PLOTTER -> Unit
                }
            }
        }
    }

    private var jogHeld = false

    /**
     * GRBL 1.1 continuous jog: while a direction key is held a long jog is queued, and releasing the key sends the
     * real-time jog-cancel byte (0x85), which stops the machine at once. The distance is capped at the work area.
     */
    fun startContinuousJog(dx: Int, dy: Int) {
        val s = _ui.value
        if (!s.canJog || s.firmware != Firmware.GRBL) return
        jogHeld = true
        val words = StringBuilder()
        if (dx != 0) words.append(" X").append(GcodeLineTools.num(dx * s.workX))
        if (dy != 0) words.append(" Y").append(GcodeLineTools.num(dy * s.workY))
        viewModelScope.launch {
            val r = sendCommand("\$J=G91 G21${words} F${s.jogFeed}", MANUAL_TIMEOUT)
            noteFailure(r)
            if (!jogHeld) cancelJog() // the key was released before the jog even started
        }
    }

    fun stopContinuousJog() {
        if (!jogHeld) return
        jogHeld = false
        viewModelScope.launch { cancelJog() }
    }

    private suspend fun cancelJog() {
        try { writeRealtime(byteArrayOf(0x85.toByte())) } catch (_: IOException) { }
    }

    private suspend fun relativeMove(words: String, feed: Int): Reply {
        val a = sendCommand("G91", MANUAL_TIMEOUT)
        if (a !is Reply.Ok) return a
        val b = sendCommand("G1 $words F$feed", MANUAL_TIMEOUT)
        val c = sendCommand("G90", MANUAL_TIMEOUT) // always return to absolute mode, even after a failed move
        return if (b is Reply.Ok) c else b
    }

    fun penUp() = pen(up = true)
    fun penDown() = pen(up = false)

    private fun pen(up: Boolean) {
        if (!_ui.value.canJog) return
        viewModelScope.launch {
            manualMutex.withLock {
                val s = _ui.value
                val cmd = when (s.firmware) {
                    Firmware.PLOTTER -> "M300 S${if (up) s.penUpS else s.penDownS}"
                    Firmware.GRBL, Firmware.GRBL09 -> if (up) s.penUpCmd else s.penDownCmd
                    Firmware.GENERIC -> "M280 P0 S${if (up) s.penUpS else s.penDownS}" // Marlin servo
                }
                val r = sendCommand(cmd, MANUAL_TIMEOUT)
                if (r is Reply.Ok) _ui.update { it.copy(penDown = !up) }
                noteFailure(r)
            }
        }
    }

    /** Firmware homing. The stock plotter has no end-stops, so there "home" means: pen up, back to X0 Y0. */
    fun home() {
        if (!_ui.value.canJog) return
        viewModelScope.launch {
            manualMutex.withLock {
                val s = _ui.value
                when (s.firmware) {
                    Firmware.PLOTTER -> goToOrigin(s)
                    Firmware.GRBL, Firmware.GRBL09 -> {
                        val r = sendCommand("\$H", HOMING_TIMEOUT)
                        if (r is Reply.Err && r.message.contains("error:5")) {
                            log(LogKind.INFO, "Homing is disabled in GRBL (\$22=0). Use 'Go to 0,0' or enable homing.")
                        }
                        noteFailure(r)
                    }
                    Firmware.GENERIC -> {
                        val r = sendCommand("G28 X Y", HOMING_TIMEOUT)
                        if (r is Reply.Ok) _ui.update { it.copy(x = 0.0, y = 0.0) }
                        noteFailure(r)
                    }
                }
            }
        }
    }

    /** Pen up, then rapid move to X0 Y0 (work origin). */
    fun goToZero() {
        if (!_ui.value.canJog) return
        viewModelScope.launch { manualMutex.withLock { goToOrigin(_ui.value) } }
    }

    private suspend fun goToOrigin(s: SenderUiState) {
        if (s.firmware == Firmware.PLOTTER) {
            val up = sendCommand("M300 S${s.penUpS}", MANUAL_TIMEOUT)
            if (up !is Reply.Ok) { noteFailure(up); return }
            _ui.update { it.copy(penDown = false) }
        } else {
            val abs = sendCommand("G90", MANUAL_TIMEOUT)
            if (abs !is Reply.Ok) { noteFailure(abs); return }
        }
        val r = sendCommand("G0 X0 Y0", MANUAL_TIMEOUT)
        if (r is Reply.Ok && !s.firmware.isGrbl) _ui.update { it.copy(x = 0.0, y = 0.0) }
        noteFailure(r)
    }

    /** Declares the current head position as X0 Y0 (GRBL / generic only: the stock plotter sketch cannot do it). */
    fun setZero() {
        if (!_ui.value.canJog) return
        viewModelScope.launch {
            manualMutex.withLock {
                val s = _ui.value
                val cmd = when (s.firmware) {
                    Firmware.GRBL, Firmware.GRBL09 -> "G10 L20 P1 X0 Y0"
                    Firmware.GENERIC -> "G92 X0 Y0"
                    Firmware.PLOTTER -> return@withLock
                }
                val r = sendCommand(cmd, MANUAL_TIMEOUT)
                if (r is Reply.Ok && s.firmware == Firmware.GENERIC) _ui.update { it.copy(x = 0.0, y = 0.0) }
                noteFailure(r)
            }
        }
    }

    /** Asks the machine where it is (M114, or a GRBL status report). */
    fun syncPosition() {
        if (!_ui.value.connected) return
        viewModelScope.launch {
            if (_ui.value.firmware.isGrbl) {
                try { writeRealtime(byteArrayOf('?'.code.toByte())) } catch (_: IOException) { }
            } else if (_ui.value.job != JobState.RUNNING) {
                noteFailure(sendCommand("M114", MANUAL_TIMEOUT))
            }
        }
    }

    /** GRBL: clear an alarm / lock ($X). */
    fun unlock() {
        if (!_ui.value.connected) return
        viewModelScope.launch { manualMutex.withLock { noteFailure(sendCommand("\$X", MANUAL_TIMEOUT)) } }
    }

    /** GRBL: soft reset (Ctrl-X). */
    fun softReset() {
        if (!_ui.value.connected) return
        viewModelScope.launch {
            try { writeRealtime(byteArrayOf(0x18)) } catch (_: IOException) { }
            log(LogKind.INFO, "Soft reset sent")
        }
    }

    fun setFeedPercent(v: Int) = _ui.update { it.copy(feedPercent = v.coerceIn(10, 200)) }

    /** GRBL real-time feed override: 0x90 resets to 100 %, then 0x91/0x92 move +-10 % and 0x93/0x94 +-1 %. */
    private fun feedOverrideBytes(percent: Int): ByteArray {
        val d = percent.coerceIn(10, 200) - 100
        val out = ArrayList<Byte>()
        out.add(0x90.toByte())
        repeat(Math.abs(d) / 10) { out.add((if (d >= 0) 0x91 else 0x92).toByte()) }
        repeat(Math.abs(d) % 10) { out.add((if (d >= 0) 0x93 else 0x94).toByte()) }
        return out.toByteArray()
    }

    /**
     * Called when the speed slider is released.
     *  - GRBL 1.1: real-time feed override bytes (applies instantly, even to moves already queued).
     *  - GRBL 0.9: no overrides exist, so the percentage rescales the F word of every job line (see [prepareJobLine]).
     *  - Marlin and the plotter firmware: `M220 S<percent>`. The stock plotter sketch does not know M220 (it answers
     *    "Command not recognized"); the patched sketch in docs/firmware turns it into a speed override.
     */
    fun commitFeedPercent() {
        val s = _ui.value
        if (!s.connected) return
        when (s.firmware) {
            Firmware.GRBL -> viewModelScope.launch {
                try { writeRealtime(feedOverrideBytes(s.feedPercent)) } catch (_: IOException) { }
                log(LogKind.INFO, "Feed override ${s.feedPercent} %")
            }
            Firmware.GRBL09 -> Unit
            else -> viewModelScope.launch { noteFailure(sendCommand("M220 S${s.feedPercent}", MANUAL_TIMEOUT)) }
        }
    }

    /** GRBL 1.1 rapid override: 100 %, 50 % or 25 %. */
    fun setRapidPercent(percent: Int) {
        val s = _ui.value
        if (!s.connected || s.firmware != Firmware.GRBL) return
        val code = when (percent) { 50 -> 0x96; 25 -> 0x97; else -> 0x95 }
        _ui.update { it.copy(rapidPercent = if (percent == 50 || percent == 25) percent else 100) }
        viewModelScope.launch { try { writeRealtime(byteArrayOf(code.toByte())) } catch (_: IOException) { } }
    }

    // -- macros -----------------------------------------------------------------------------------------------------

    /** Runs macro button [index]: every non-empty line in order, stopping at the first error. */
    fun runMacro(index: Int) {
        val lines = _ui.value.macros.getOrNull(index).orEmpty().lines()
            .map { GcodeLineTools.clean(it) }.filter { it.isNotEmpty() }
        if (lines.isEmpty() || !_ui.value.canJog) return
        viewModelScope.launch {
            manualMutex.withLock {
                for (line in lines) {
                    val timeout = if (line.startsWith("\$H")) HOMING_TIMEOUT else MANUAL_TIMEOUT
                    val r = sendCommand(line, timeout)
                    if (r is Reply.Ok) trackPosition(line) else { noteFailure(r); break }
                }
            }
        }
    }

    /** A line typed into the console. */
    fun sendConsole(text: String) {
        val cleaned = GcodeLineTools.clean(text)
        if (cleaned.isEmpty() || !_ui.value.canJog) return
        viewModelScope.launch {
            manualMutex.withLock {
                val r = sendCommand(cleaned, MANUAL_TIMEOUT)
                if (r is Reply.Ok) trackPosition(cleaned)
                noteFailure(r)
            }
        }
    }

    private var absoluteMode = true

    private fun trackPosition(cleaned: String) {
        val u = cleaned.uppercase(Locale.ROOT).replace(" ", "")
        if (u.startsWith("G91")) absoluteMode = false
        if (u.startsWith("G90")) absoluteMode = true
        if (_ui.value.firmware.isGrbl || !absoluteMode) return
        val (x, y) = GcodeLineTools.parseXy(cleaned)
        if (x != null || y != null) _ui.update { it.copy(x = x ?: it.x, y = y ?: it.y) }
    }

    // ==========================================================================================================
    // Stopping
    // ==========================================================================================================

    /** Stops the job and tells the machine to stop. [emergency] uses the hardest stop the firmware offers. */
    fun halt(emergency: Boolean) {
        val s = _ui.value
        jobCoroutine?.cancel()
        jobCoroutine = null
        pauseFlag.value = false
        jobIndex = 0
        resetGrblStream()
        _ui.update {
            it.copy(job = JobState.IDLE, sentLines = 0, notice = if (emergency) "Emergency stop" else "Stopped", noticeIsError = emergency)
        }
        if (!s.connected) return
        viewModelScope.launch {
            try {
                when (s.firmware) {
                    Firmware.GRBL, Firmware.GRBL09 -> {
                        writeRealtime(byteArrayOf('!'.code.toByte()))   // feed hold
                        delay(100)
                        writeRealtime(byteArrayOf(0x18))               // soft reset flushes the planner
                        outstanding = 0
                        while (acks.tryReceive().isSuccess) { /* the reset discards pending lines */ }
                    }
                    Firmware.GENERIC -> {
                        writeRealtime(((if (emergency) "M112" else "M410") + "\n").toByteArray())
                        outstanding = if (emergency) 0 else outstanding + 1
                    }
                    Firmware.PLOTTER -> {
                        // The stock sketch is single-threaded: it finishes the move it is on. Queue a pen lift.
                        writeRealtime("M300 S${s.penUpS}\n".toByteArray())
                        outstanding += 1
                        if (emergency) log(LogKind.ERROR, "The stock plotter firmware cannot abort a move in progress. Cut the power for a hard stop.")
                    }
                }
                log(LogKind.ERROR, if (emergency) "EMERGENCY STOP" else "Stopped")
            } catch (_: IOException) {
            }
        }
    }

    // ==========================================================================================================
    // G-code program
    // ==========================================================================================================

    fun loadFile(file: File) = loadProgram(file.name) { file.useLines { it.toList() } }

    fun loadUri(uri: Uri) {
        val name = try { FileRepository(app).displayNameOf(uri) } catch (_: Exception) { "gcode" }
        loadProgram(name) {
            app.contentResolver.openInputStream(uri)?.bufferedReader()?.useLines { it.toList() }
                ?: throw IOException("Could not open the file")
        }
    }

    private fun loadProgram(name: String, reader: () -> List<String>) {
        if (_ui.value.job == JobState.RUNNING) return
        viewModelScope.launch {
            try {
                val prog = withContext(Dispatchers.IO) {
                    reader().map { it.trim() }.filter { GcodeLineTools.clean(it).isNotEmpty() }
                }
                val summary = withContext(Dispatchers.Default) { GcodeLineTools.summarize(prog) }
                program = prog
                jobIndex = 0
                _ui.update {
                    it.copy(
                        fileName = name, summary = summary, job = JobState.IDLE, sentLines = 0,
                        totalLines = prog.size, elapsedSec = 0, notice = null,
                    )
                }
                log(LogKind.INFO, "Loaded $name: ${prog.size} lines")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _ui.update { it.copy(errorDialog = "Could not read the G-code file: ${e.message}") }
            }
        }
    }

    fun start() {
        val s = _ui.value
        if (!s.connected || program.isEmpty() || s.job != JobState.IDLE) return
        jobIndex = 0
        absoluteMode = true
        resetGrblStream()
        if (s.firmware.isGrbl) {
            outstanding = 0
            while (acks.tryReceive().isSuccess) { /* nothing is pending on an idle GRBL */ }
        }
        _ui.update { it.copy(sentLines = 0, elapsedSec = 0, notice = null) }
        launchJob()
    }

    fun pause() {
        if (_ui.value.job != JobState.RUNNING) return
        pauseFlag.value = true
        val grbl = _ui.value.firmware.isGrbl
        _ui.update { it.copy(job = JobState.PAUSED, notice = if (grbl) "Feed hold" else "Paused after the current line") }
        if (grbl) viewModelScope.launch { try { writeRealtime(byteArrayOf('!'.code.toByte())) } catch (_: IOException) { } }
    }

    fun resume() {
        val s = _ui.value
        if (s.job != JobState.PAUSED) return
        if (!s.connected) {
            _ui.update { it.copy(notice = "Connect to the machine first", noticeIsError = true) }
            return
        }
        if (s.firmware.isGrbl) {
            viewModelScope.launch { try { writeRealtime(byteArrayOf('~'.code.toByte())) } catch (_: IOException) { } }
        }
        pauseFlag.value = false
        _ui.update { it.copy(job = JobState.RUNNING, notice = null) }
        if (jobCoroutine?.isActive != true) launchJob()
    }

    /** After an error: skip the failing line instead of retrying it on Resume. */
    fun skipLine() {
        if (_ui.value.job != JobState.PAUSED || jobIndex >= program.size || _ui.value.firmware.isGrbl) return
        jobIndex += 1
        _ui.update { it.copy(sentLines = jobIndex, notice = "Skipped. Press Resume to continue.", noticeIsError = false) }
    }

    /** Pen command translation for firmware that has no M300 servo command. Null = drop the line. */
    private fun translatePen(cleaned: String, s: SenderUiState): String? {
        val v = GcodeLineTools.penValue(cleaned) ?: return cleaned
        if (!s.translatePen) return cleaned
        return when (s.firmware) {
            Firmware.GRBL, Firmware.GRBL09 -> when {
                v >= 255.0 -> null // "servo off"
                Math.abs(v - s.penUpS) <= Math.abs(v - s.penDownS) -> s.penUpCmd
                else -> s.penDownCmd
            }
            Firmware.GENERIC -> if (v >= 255.0) null else "M280 P0 S${GcodeLineTools.num(v)}"
            Firmware.PLOTTER -> cleaned
        }
    }

    /** What actually goes on the wire for one cleaned program line (null = this firmware cannot use the line). */
    private fun prepareJobLine(cleaned: String, s: SenderUiState): String? = when (s.firmware) {
        Firmware.PLOTTER ->
            if (GcodeLineTools.isNoiseForPlotter(cleaned) || GcodeLineTools.isMoveWithoutXy(cleaned)) null else cleaned
        Firmware.GRBL, Firmware.GRBL09 -> {
            if (GcodeLineTools.isNoiseForGrbl(cleaned)) null
            else translatePen(cleaned, s)?.let { line ->
                val dwell = GcodeLineTools.dwellMsToSeconds(line)
                if (s.firmware == Firmware.GRBL09) GcodeLineTools.scaleFeed(dwell, s.feedPercent) else dwell
            }
        }
        Firmware.GENERIC -> translatePen(cleaned, s)
    }

    // ---- GRBL character-counting streaming -----------------------------------------------------------------------
    // Instead of waiting for "ok" after every line, lines are written while the total size of the lines GRBL has
    // not acknowledged yet stays below its serial RX buffer. Motion stays smooth because GRBL's planner is always
    // fed, which matters with the many tiny segments a traced drawing produces.

    private val grblPending = ArrayDeque<Int>()      // size in bytes of every line still in GRBL's buffer, oldest first
    private val grblPendingIdx = ArrayDeque<Int>()   // program index of each of those lines
    private var grblPendingBytes = 0
    private var grblFiltered = 0

    private fun resetGrblStream() {
        grblPending.clear()
        grblPendingIdx.clear()
        grblPendingBytes = 0
    }

    private sealed class StreamEnd {
        object Done : StreamEnd()
        object Paused : StreamEnd()
        object Stop : StreamEnd()
        object NotConnected : StreamEnd()
        data class Failed(val message: String) : StreamEnd()
    }

    private suspend fun streamGrbl(): StreamEnd = cmdMutex.withLock {
        val l = link ?: return@withLock StreamEnd.NotConnected
        var lastProgress = System.currentTimeMillis()
        while (true) {
            if (pauseFlag.value) return@withLock StreamEnd.Paused

            // 1. top up GRBL's receive buffer
            while (jobIndex < program.size) {
                val s = _ui.value
                val raw = program[jobIndex]
                val cleaned = GcodeLineTools.clean(raw)
                if (GcodeLineTools.isOptionalStop(cleaned)) {
                    if (grblPending.isNotEmpty()) break // let everything before the stop finish first
                    jobIndex += 1
                    _ui.update { it.copy(sentLines = jobIndex, notice = "Program stop at line $jobIndex: $raw. Press Resume to continue.", noticeIsError = false) }
                    return@withLock StreamEnd.Stop
                }
                val out = prepareJobLine(cleaned, s)
                if (out == null) {
                    grblFiltered += 1
                    jobIndex += 1
                    continue
                }
                val size = out.length + 1
                if (grblPending.isNotEmpty() && grblPendingBytes + size > GRBL_RX_LIMIT) break
                try {
                    rawWrite(l, (out + "\n").toByteArray(Charsets.US_ASCII))
                } catch (e: IOException) {
                    onLinkLost(l)
                    return@withLock StreamEnd.NotConnected
                }
                grblPending.addLast(size)
                grblPendingIdx.addLast(jobIndex)
                grblPendingBytes += size
                if (s.logJobTraffic) log(LogKind.TX, out)
                jobIndex += 1
                lastProgress = System.currentTimeMillis()
            }
            if (grblPending.isEmpty()) return@withLock StreamEnd.Done

            // 2. wait for one acknowledgement (short slices, so Pause is noticed quickly)
            val ack = withTimeoutOrNull(200L) { acks.receive() }
            if (ack == null) {
                if (System.currentTimeMillis() - lastProgress > JOB_TIMEOUT) {
                    return@withLock StreamEnd.Failed("No answer from the machine (timeout)")
                }
                continue
            }
            lastProgress = System.currentTimeMillis()
            val size = grblPending.removeFirst()
            val idx = grblPendingIdx.removeFirst()
            grblPendingBytes -= size
            _ui.update { it.copy(sentLines = (jobIndex - grblPending.size).coerceAtLeast(0)) }
            if (!ack.ok) {
                if (_ui.value.ignoreErrors) {
                    log(LogKind.INFO, "Ignored error on line ${idx + 1}")
                    continue
                }
                return@withLock StreamEnd.Failed("Line ${idx + 1} (${GcodeLineTools.clean(program[idx])}): ${ack.text}. The line was skipped; Resume continues.")
            }
        }
        @Suppress("UNREACHABLE_CODE")
        StreamEnd.Done
    }

    private fun launchGrblJob() {
        jobCoroutine?.cancel()
        jobCoroutine = viewModelScope.launch {
            _ui.update { it.copy(job = JobState.RUNNING, notice = null) }
            log(LogKind.INFO, "Streaming ${program.size} lines (GRBL character counting)")
            grblFiltered = 0
            while (true) {
                if (pauseFlag.value) {
                    _ui.update { it.copy(job = JobState.PAUSED) }
                    pauseFlag.first { paused -> !paused }
                    _ui.update { it.copy(job = JobState.RUNNING, notice = null) }
                }
                when (val end = streamGrbl()) {
                    StreamEnd.Done -> break
                    StreamEnd.Paused -> Unit
                    StreamEnd.Stop -> pauseFlag.value = true
                    StreamEnd.NotConnected -> {
                        _ui.update { it.copy(job = JobState.PAUSED, notice = "Connection lost at line ${jobIndex + 1}. Reconnect, then press Resume.", noticeIsError = true) }
                        return@launch
                    }
                    is StreamEnd.Failed -> {
                        try { writeRealtime(byteArrayOf('!'.code.toByte())) } catch (_: IOException) { }
                        _ui.update { it.copy(job = JobState.PAUSED, notice = end.message, noticeIsError = true) }
                        pauseFlag.value = true
                    }
                }
            }
            if (grblFiltered > 0) log(LogKind.INFO, "$grblFiltered line(s) were not sent because GRBL cannot use them")
            log(LogKind.INFO, "Job finished")
            jobIndex = 0
            resetGrblStream()
            _ui.update { it.copy(job = JobState.IDLE, notice = "Finished in ${formatTime(it.elapsedSec)}", noticeIsError = false) }
        }
    }

    private fun launchJob() {
        if (_ui.value.firmware.isGrbl) {
            launchGrblJob()
            return
        }
        jobCoroutine?.cancel()
        jobCoroutine = viewModelScope.launch {
            _ui.update { it.copy(job = JobState.RUNNING, notice = null) }
            log(LogKind.INFO, "Sending ${program.size} lines (from line ${jobIndex + 1})")
            var filtered = 0
            while (jobIndex < program.size) {
                if (pauseFlag.value) {
                    _ui.update { it.copy(job = JobState.PAUSED) }
                    pauseFlag.first { paused -> !paused }
                    _ui.update { it.copy(job = JobState.RUNNING, notice = null) }
                }
                val s = _ui.value
                if (!s.connected) {
                    _ui.update { it.copy(job = JobState.PAUSED, notice = "Connection lost at line ${jobIndex + 1}. Reconnect, then press Resume.", noticeIsError = true) }
                    return@launch
                }
                val raw = program[jobIndex]
                val cleaned = GcodeLineTools.clean(raw)

                if (GcodeLineTools.isOptionalStop(cleaned)) {
                    jobIndex += 1
                    _ui.update { it.copy(sentLines = jobIndex, notice = "Program stop at line $jobIndex: $raw. Press Resume to continue.", noticeIsError = false) }
                    pauseFlag.value = true
                    continue
                }

                val out = prepareJobLine(cleaned, s)
                if (out == null) {
                    filtered += 1
                    jobIndex += 1
                    _ui.update { it.copy(sentLines = jobIndex) }
                    continue
                }

                val reply = sendCommand(out, JOB_TIMEOUT)
                if (reply is Reply.Ok) {
                    trackPosition(out)
                    jobIndex += 1
                    _ui.update { it.copy(sentLines = jobIndex) }
                } else if (reply is Reply.NotConnected) {
                    _ui.update { it.copy(job = JobState.PAUSED, notice = "Connection lost at line ${jobIndex + 1}. Reconnect, then press Resume.", noticeIsError = true) }
                    return@launch
                } else if (reply is Reply.Err && s.ignoreErrors) {
                    log(LogKind.INFO, "Ignored error on line ${jobIndex + 1}: $out")
                    jobIndex += 1
                    _ui.update { it.copy(sentLines = jobIndex) }
                } else {
                    // Error or timeout: stop here. Resume retries the line, Skip jumps over it.
                    _ui.update {
                        it.copy(
                            job = JobState.PAUSED,
                            notice = "Line ${jobIndex + 1} ($out): ${describe(reply)}",
                            noticeIsError = true,
                        )
                    }
                    pauseFlag.value = true
                }
            }
            if (filtered > 0) log(LogKind.INFO, "$filtered line(s) were not sent because this firmware cannot use them")
            log(LogKind.INFO, "Job finished")
            jobIndex = 0
            _ui.update { it.copy(job = JobState.IDLE, notice = "Finished in ${formatTime(it.elapsedSec)}", noticeIsError = false) }
        }
    }

    companion object {
        private const val ACTION_USB_PERMISSION = "com.vectorforge.app.USB_PERMISSION"
        private const val MANUAL_TIMEOUT = 30_000L
        private const val HOMING_TIMEOUT = 120_000L
        private const val JOB_TIMEOUT = 120_000L
        private const val LATE_ACK_WAIT = 60_000L
        private const val CONSOLE_MAX = 400
        private const val GRBL_RX_LIMIT = 120 // GRBL's RX buffer is 128 bytes; keep a little spare

        private val M114_PLOTTER = Regex("""X\s*=\s*(-?\d+(?:\.\d+)?).*?Y\s*=\s*(-?\d+(?:\.\d+)?)""")
        private val M114_MARLIN = Regex("""X:\s*(-?\d+(?:\.\d+)?)\s+Y:\s*(-?\d+(?:\.\d+)?)""")
        private const val N = """(-?\d+(?:\.\d+)?)"""
        private val GRBL_WPOS = Regex("WPos:$N,$N,$N")
        private val GRBL_MPOS = Regex("MPos:$N,$N,$N")
        private val GRBL_WCO = Regex("WCO:$N,$N,$N")

        fun formatTime(totalSec: Int): String {
            val h = totalSec / 3600
            val m = (totalSec % 3600) / 60
            val s = totalSec % 60
            return if (h > 0) String.format(Locale.ROOT, "%d:%02d:%02d", h, m, s) else String.format(Locale.ROOT, "%d:%02d", m, s)
        }
    }
}
