package com.vectorforge.app.ui.viewer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.key
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.vectorforge.app.engine.gcode.transform.PostProcessParams
import com.vectorforge.app.ncviewer.ViewerPostProcess
import com.vectorforge.app.ui.convert.components.OptionalDoubleField
import com.vectorforge.app.ui.convert.components.OptionalIntField
import com.vectorforge.app.ui.convert.components.SegmentedControl
import com.vectorforge.app.ui.convert.components.ToggleRow
import com.vectorforge.app.ui.theme.VfRadius
import com.vectorforge.app.ui.theme.VfSpacing
import com.vectorforge.app.ui.theme.VfType

/**
 * The live post-processing panel shown under the G-Code Viewer. It carries every post-processing parameter (the
 * TRANSFORM arguments and the FINAL NORMALIZE pair) with the same controls as POST-PROCESSING on the Convert
 * screen; every change is applied straight away to the G-code in the chosen viewer (see [ViewerPostProcess]).
 * [onSave] opens the "Save As" dialog for the G-code currently shown.
 */
@Composable
fun PostProcessPanel(
    post: ViewerPostProcess,
    onSave: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val muted = MaterialTheme.colorScheme.onSurfaceVariant

    Column(
        modifier = modifier
            .clip(RoundedCornerShape(topStart = VfRadius.xl2, topEnd = VfRadius.xl2))
            .background(MaterialTheme.colorScheme.surfaceContainer),
    ) {
        // ---- title row: collapse (to see the whole viewer) / close ----
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = VfSpacing.md, end = VfSpacing.xs),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Filled.Tune, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
            Text(
                "POST-PROCESS \u00B7 LIVE",
                style = VfType.labelLg,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier
                    .weight(1f)
                    .padding(start = VfSpacing.xs),
            )
            IconButton(onClick = { post.collapsed = !post.collapsed }) {
                Icon(
                    if (post.collapsed) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                    contentDescription = if (post.collapsed) "Show the parameters" else "Hide the parameters",
                )
            }
            IconButton(onClick = post::close) {
                Icon(Icons.Filled.Close, contentDescription = "Close post-processing (the viewer keeps what it shows)")
            }
        }

        // ---- actions: re-read the viewer / reset / save ----
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = VfSpacing.md),
            horizontalArrangement = Arrangement.spacedBy(VfSpacing.sm),
        ) {
            PanelButton("RE-READ", Icons.Filled.Refresh, filled = false, enabled = true, onClick = post::capture)
            PanelButton("RESET", Icons.Filled.RestartAlt, filled = false, enabled = post.hasBase, onClick = post::reset)
            PanelButton("SAVE", Icons.Filled.Save, filled = true, enabled = post.hasBase, onClick = onSave)
        }

        // ---- status: what was done, or why it could not be ----
        if (post.status.isNotBlank()) {
            Text(
                post.status,
                style = VfType.bodySm,
                color = if (post.statusIsError) MaterialTheme.colorScheme.error else muted,
                modifier = Modifier.padding(horizontal = VfSpacing.md, vertical = VfSpacing.sm),
            )
        }

        if (!post.collapsed) {
            Column(
                modifier = Modifier
                    .heightIn(max = 320.dp)
                    .verticalScroll(rememberScrollState())
                    .padding(start = VfSpacing.md, end = VfSpacing.md, bottom = VfSpacing.md),
                verticalArrangement = Arrangement.spacedBy(VfSpacing.sm),
            ) {
                if (post.splitMode) {
                    Text("TARGET VIEWER", style = VfType.labelSm, color = muted)
                    SegmentedControl(
                        options = listOf("Viewer 1", "Viewer 2"),
                        selectedIndex = post.pane,
                        onSelect = post::selectPane,
                    )
                }

                if (post.hasBase) {
                    // A reset / re-read bumps resetToken, which re-creates the fields so they drop their typed text.
                    key(post.resetToken) { ParameterFields(post) }
                }
            }
        }
    }
}

/** All post-processing parameters, in the same order and with the same controls as POST-PROCESSING on the Convert screen. */
@Composable
private fun ParameterFields(post: ViewerPostProcess) {
    val p = post.params
    // callbacks always read post.params afresh, so two quick edits never overwrite each other
    fun change(block: (PostProcessParams) -> PostProcessParams) = post.update(block(post.params))

    TwoCol {
        OptionalDoubleField("ROTATE LEFT (deg)", p.rotateLeft, 0.0, { v -> change { it.copy(rotateLeft = v) } }, modifier = Modifier.weight(1f))
        OptionalDoubleField("ROTATE RIGHT (deg)", p.rotateRight, 0.0, { v -> change { it.copy(rotateRight = v) } }, modifier = Modifier.weight(1f))
    }
    TwoCol {
        OptionalDoubleField("OFFSET X (mm)", p.offsetX, 0.0, { v -> change { it.copy(offsetX = v) } }, modifier = Modifier.weight(1f))
        OptionalDoubleField("OFFSET Y (mm)", p.offsetY, 0.0, { v -> change { it.copy(offsetY = v) } }, modifier = Modifier.weight(1f))
    }
    ToggleRow(title = "KEEP POSITIVE", subtitle = "X\u22650 and Y\u22650 (--keep-positive)", checked = p.keepPositive, onCheckedChange = { v -> change { it.copy(keepPositive = v) } })
    ToggleRow(title = "KEEP NEGATIVE", subtitle = "X\u22640 and Y\u22640 (--keep-negative)", checked = p.keepNegative, onCheckedChange = { v -> change { it.copy(keepNegative = v) } })
    ToggleRow(title = "KEEP EAST", subtitle = "X\u22650, right of the Y axis (--keep-east)", checked = p.keepEast, onCheckedChange = { v -> change { it.copy(keepEast = v) } })
    ToggleRow(title = "KEEP WEST", subtitle = "X\u22640, left of the Y axis (--keep-west)", checked = p.keepWest, onCheckedChange = { v -> change { it.copy(keepWest = v) } })
    ToggleRow(title = "KEEP NORTH", subtitle = "Y\u22650, above the X axis (--keep-north)", checked = p.keepNorth, onCheckedChange = { v -> change { it.copy(keepNorth = v) } })
    ToggleRow(title = "KEEP SOUTH", subtitle = "Y\u22640, below the X axis (--keep-south)", checked = p.keepSouth, onCheckedChange = { v -> change { it.copy(keepSouth = v) } })
    ToggleRow(title = "NO FIXED HOME", subtitle = "Also transform the start/end moves to X0 Y0 (--no-fixed-home)", checked = p.noFixedHome, onCheckedChange = { v -> change { it.copy(noFixedHome = v) } })
    TwoCol {
        OptionalDoubleField("MAX X (warn)", p.maxX, 0.0, { v -> change { it.copy(maxX = v) } }, modifier = Modifier.weight(1f))
        OptionalDoubleField("MAX Y (warn)", p.maxY, 0.0, { v -> change { it.copy(maxY = v) } }, modifier = Modifier.weight(1f))
    }
    OptionalIntField("PRECISION (0\u201310)", p.precision, 4, { v -> change { it.copy(precision = v) } })

    // FINAL NORMALIZE: NEW MIN / NEW MAX applied last, after the transform above
    TwoCol {
        OptionalDoubleField("NEW MIN (mm) \u00B7 FINAL", p.finalNewMin, 0.0, { v -> change { it.copy(finalNewMin = v) } }, modifier = Modifier.weight(1f))
        OptionalDoubleField("NEW MAX (mm) \u00B7 FINAL", p.finalNewMax, 40.0, { v -> change { it.copy(finalNewMax = v) } }, modifier = Modifier.weight(1f))
    }
}

@Composable
private fun TwoCol(content: @Composable RowScope.() -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(VfSpacing.sm),
        content = content,
    )
}

@Composable
private fun RowScope.PanelButton(
    text: String,
    icon: ImageVector,
    filled: Boolean,
    enabled: Boolean,
    onClick: () -> Unit,
) {
    val shape = RoundedCornerShape(VfRadius.xl)
    val padding = PaddingValues(horizontal = VfSpacing.sm, vertical = VfSpacing.sm)
    val content: @Composable RowScope.() -> Unit = {
        Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp))
        Text(text, style = VfType.labelLg, modifier = Modifier.padding(start = VfSpacing.xs))
    }
    if (filled) {
        Button(onClick = onClick, enabled = enabled, shape = shape, contentPadding = padding, modifier = Modifier.weight(1f), content = content)
    } else {
        OutlinedButton(onClick = onClick, enabled = enabled, shape = shape, contentPadding = padding, modifier = Modifier.weight(1f), content = content)
    }
}
