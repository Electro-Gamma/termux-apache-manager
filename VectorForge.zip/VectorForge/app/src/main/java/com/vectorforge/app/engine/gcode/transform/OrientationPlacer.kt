package com.vectorforge.app.engine.gcode.transform

/**
 * The outcome of one [OrientationPlacer.place] call: the moved / turned G-code text, where its bounding box is
 * centred, and the X/Y extent it now covers.
 */
class PlacementResult(
    val text: String,
    val angleDeg: Double,
    val centerX: Double,
    val centerY: Double,
    val minX: Double,
    val maxX: Double,
    val minY: Double,
    val maxY: Double,
    val warningCount: Int,
)

/**
 * Free placement of a toolpath: the maths behind the viewer's remote control. There are NO limits of any kind: any
 * G-code (0..40, 0..80, 70..120, negative, crossing zero, ...) can be moved any distance in any direction and turned
 * to any angle.
 *
 * What it does, in this order, always starting again from the ORIGINAL G-code (so nothing accumulates, it is exactly
 * reversible, and rotating left then right gives the original back byte for byte):
 *
 *   1. rotate by the angle about the drawing's OWN centre. Rotating about X0 Y0 instead would swing a drawing that
 *      sits far from the origin across the plane, into another quadrant;
 *   2. translate so the bounding box is centred on the requested point.
 *
 * Nothing else is ever done to it: no scaling, no clamping, no re-normalising, no mirroring. The drawing's size and
 * handedness never change.
 *
 * All geometry is done by [GCodeTransformer] (absolute and relative moves, arcs; the fixed X0 Y0 home moves stay
 * where they are), so this only decides the angle and the shift to hand to it.
 */
class OrientationPlacer(private val baseText: String, private val precision: Int = 4) {

    val baseMinX: Double
    val baseMaxX: Double
    val baseMinY: Double
    val baseMaxY: Double

    init {
        // identity run: nothing is changed, it only measures the toolpath
        val probe = GCodeTransformer(null, 0.0, 0.0, 0.0, precision, true)
        probe.processText(baseText)
        baseMinX = probe.minX
        baseMaxX = probe.maxX
        baseMinY = probe.minY
        baseMaxY = probe.maxY
    }

    /** False when the text contains no X/Y toolpath moves at all (nothing to place). */
    val hasToolpath: Boolean
        get() = baseMinX.isFinite() && baseMaxX.isFinite() && baseMinY.isFinite() && baseMaxY.isFinite()

    val baseCenterX: Double get() = (baseMinX + baseMaxX) / 2
    val baseCenterY: Double get() = (baseMinY + baseMaxY) / 2

    /**
     * The original G-code rotated by [angleDeg] (counter-clockwise positive) with its bounding box centred on
     * ([centerX], [centerY]). With angle 0 and the original centre this returns the original unchanged.
     */
    fun place(angleDeg: Double, centerX: Double, centerY: Double): PlacementResult {
        require(hasToolpath) { "there is no toolpath to place" }
        val angle = ((angleDeg % 360.0) + 360.0) % 360.0

        // the original rotated about the origin and not yet shifted: only the position of its bounding box matters here
        val rMinX: Double
        val rMaxX: Double
        val rMinY: Double
        val rMaxY: Double
        if (angle == 0.0) {
            rMinX = baseMinX; rMaxX = baseMaxX; rMinY = baseMinY; rMaxY = baseMaxY
        } else {
            val rotated = GCodeTransformer("left", angle, 0.0, 0.0, precision, true)
            rotated.processText(baseText)
            rMinX = rotated.minX; rMaxX = rotated.maxX; rMinY = rotated.minY; rMaxY = rotated.maxY
        }

        // shift that puts the rotated bounding box's centre on the requested centre
        val offsetX = centerX - (rMinX + rMaxX) / 2
        val offsetY = centerY - (rMinY + rMaxY) / 2

        val fin = GCodeTransformer(
            direction = if (angle == 0.0) null else "left",
            angle = angle,
            offsetX = offsetX,
            offsetY = offsetY,
            precision = precision,
            fixedHome = true,
        )
        val text = fin.processText(baseText)

        return PlacementResult(
            text = text,
            angleDeg = angle,
            centerX = centerX,
            centerY = centerY,
            minX = fin.minX,
            maxX = fin.maxX,
            minY = fin.minY,
            maxY = fin.maxY,
            warningCount = fin.warnings.size,
        )
    }
}
