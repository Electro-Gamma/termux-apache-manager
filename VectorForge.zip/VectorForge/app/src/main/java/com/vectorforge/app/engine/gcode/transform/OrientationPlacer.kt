package com.vectorforge.app.engine.gcode.transform

import kotlin.math.cos
import kotlin.math.sin

/**
 * The outcome of one [OrientationPlacer.place] call: the transformed G-code and its resulting extent.
 */
class PlacementResult(
    val text: String,
    val angleDeg: Double,
    val minX: Double,
    val maxX: Double,
    val minY: Double,
    val maxY: Double,
    val warningCount: Int,
)

/**
 * Pure rotation + translation of a toolpath: the maths behind the viewer's remote control.
 *
 * There is NO workspace, NO limit window, NO clamping and NO scaling here. Whatever the coordinates of the loaded
 * G-code are (0..40, 70..120, -100..+100, anything), every move and every rotation is applied exactly as asked.
 * The only things ever done to the drawing are
 *
 *   1. rotation about the drawing's OWN centre (the centre of its original bounding box, never about X0 Y0), and
 *   2. translation, so that this centre sits at the requested position.
 *
 * The shape is never resized, refitted, distorted or flipped. Every call starts again from the original G-code,
 * so nothing accumulates and it is fully reversible (rotate left then right and you are back at the original).
 *
 * All geometry is done by [GCodeTransformer] (absolute and relative moves, arcs, the fixed X0 Y0 home moves stay
 * where they are), so this only decides the angle and the shift to hand to it.
 */
class OrientationPlacer(private val baseText: String, private val precision: Int = 4) {

    val baseMinX: Double
    val baseMaxX: Double
    val baseMinY: Double
    val baseMaxY: Double

    init {
        // identity run: nothing is changed, it only measures the toolpath
        val probe = GCodeTransformer(null, 0.0, 0.0, 0.0, precision, true, 1.0)
        probe.processText(baseText)
        baseMinX = probe.minX
        baseMaxX = probe.maxX
        baseMinY = probe.minY
        baseMaxY = probe.maxY
    }

    /** False when the text contains no X/Y toolpath moves at all (nothing to place). */
    val hasToolpath: Boolean
        get() = baseMinX.isFinite() && baseMaxX.isFinite() && baseMinY.isFinite() && baseMaxY.isFinite()

    /** The drawing's own centre in the original G-code: the pivot of every rotation. */
    val baseCenterX: Double get() = (baseMinX + baseMaxX) / 2
    val baseCenterY: Double get() = (baseMinY + baseMaxY) / 2

    /**
     * The original G-code rotated by [angleDeg] (counter-clockwise positive, any value, 360 degrees wraps) about
     * its own centre, with that centre moved to ([centerX], [centerY]). Nothing is clamped, checked or scaled.
     */
    fun place(angleDeg: Double, centerX: Double, centerY: Double): PlacementResult {
        require(hasToolpath) { "there is no toolpath to place" }
        val angle = ((angleDeg % 360.0) + 360.0) % 360.0

        // GCodeTransformer rotates about the origin and then adds the offset. To turn the drawing about its own
        // centre P and land P on (centerX, centerY), the offset is  target - rotate(P).
        val theta = Math.toRadians(angle)
        val pivotX = baseCenterX
        val pivotY = baseCenterY
        val rotatedPivotX = pivotX * cos(theta) - pivotY * sin(theta)
        val rotatedPivotY = pivotX * sin(theta) + pivotY * cos(theta)

        val fin = GCodeTransformer(
            direction = if (angle == 0.0) null else "left",
            angle = angle,
            offsetX = centerX - rotatedPivotX,
            offsetY = centerY - rotatedPivotY,
            precision = precision,
            fixedHome = true,
            scale = 1.0,
        )
        val text = fin.processText(baseText)

        return PlacementResult(
            text = text,
            angleDeg = angle,
            minX = fin.minX,
            maxX = fin.maxX,
            minY = fin.minY,
            maxY = fin.maxY,
            warningCount = fin.warnings.size,
        )
    }
}
