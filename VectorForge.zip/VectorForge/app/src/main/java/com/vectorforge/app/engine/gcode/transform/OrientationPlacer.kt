package com.vectorforge.app.engine.gcode.transform

import kotlin.math.max
import kotlin.math.min

/** Which side of zero the original toolpath lies on, for one axis. */
enum class AxisSide {
    /** all coordinates >= 0 (East on X, North on Y) */
    POSITIVE,

    /** all coordinates <= 0 (West on X, South on Y) */
    NEGATIVE,

    /** the toolpath crosses zero: no sign constraint to preserve */
    BOTH,
}

/**
 * The outcome of one [OrientationPlacer.place] call.
 *
 * [centerX] / [centerY] are the placement that was actually achieved: the requested centre pulled back inside the
 * window if it had to be ([clampedX] / [clampedY]). The window* values are the limits the toolpath is kept inside.
 */
class PlacementResult(
    val text: String,
    val angleDeg: Double,
    val scale: Double,
    val centerX: Double,
    val centerY: Double,
    val halfWidth: Double,
    val halfHeight: Double,
    val minX: Double,
    val maxX: Double,
    val minY: Double,
    val maxY: Double,
    val windowMinX: Double,
    val windowMaxX: Double,
    val windowMinY: Double,
    val windowMaxY: Double,
    val clampedX: Boolean,
    val clampedY: Boolean,
    val warningCount: Int,
)

/**
 * Orientation-locked placement of a toolpath inside fixed limits: the maths behind the viewer's remote control.
 *
 * The problem it solves: normalising the final X/Y min/max per axis after a rotation (or move) can stretch the
 * drawing and, worse, pull it into a different quadrant -- e.g. a drawing lying in the South (Y <= 0) gets forced
 * to positive coordinates. Here the limits are a WINDOW and the only things ever done to the drawing are
 *
 *   1. rotation about the drawing's OWN centre (never about X0 Y0, which would swing it into another quadrant),
 *   2. a UNIFORM scale, and only when the rotated drawing is too big for the window (a 40 x 40 square turned by 30
 *      degrees needs 54.6 mm of room; the window has 40), so the shape is never distorted or flipped, and
 *   3. the smallest TRANSLATION that brings it back inside the window.
 *
 * Every call starts again from the original G-code, so nothing accumulates and it is fully reversible (rotate left
 * then right and you are back at the original, byte for byte).
 *
 * How the window is built, per axis, from the limits [limitMin, limitMax] (e.g. 0 and 40) and the ORIGINAL toolpath:
 *   - original entirely >= 0 (East / North):  [limitMin, limitMax]      -> coordinates stay positive
 *   - original entirely <= 0 (West / South):  [-limitMax, -limitMin]    -> the same range, kept on the same side
 *   - original crosses zero:                  [-limitMax, limitMax]
 * and the window is always widened just enough to contain the original itself, so doing nothing never changes
 * anything even if the original already sticks out of the limits.
 *
 * All geometry is done by [GCodeTransformer] (absolute and relative moves, arcs, the fixed X0 Y0 home moves stay
 * where they are), so this only decides the angle, scale and shift to hand to it.
 */
class OrientationPlacer(private val baseText: String, private val precision: Int = 4) {

    val baseMinX: Double
    val baseMaxX: Double
    val baseMinY: Double
    val baseMaxY: Double

    init {
        // identity run: nothing is changed, it only measures the toolpath
        val probe = GCodeTransformer(null, 0.0, 0.0, 0.0, precision, true, 1.0)
        probe.processText(baseText)
        baseMinX = probe.minX
        baseMaxX = probe.maxX
        baseMinY = probe.minY
        baseMaxY = probe.maxY
    }

    /** False when the text contains no X/Y toolpath moves at all (nothing to place). */
    val hasToolpath: Boolean
        get() = baseMinX.isFinite() && baseMaxX.isFinite() && baseMinY.isFinite() && baseMaxY.isFinite()

    val baseCenterX: Double get() = (baseMinX + baseMaxX) / 2
    val baseCenterY: Double get() = (baseMinY + baseMaxY) / 2

    val sideX: AxisSide get() = sideOf(baseMinX, baseMaxX)
    val sideY: AxisSide get() = sideOf(baseMinY, baseMaxY)

    /** Window for X as (min, max) for the given limits. */
    fun windowX(limitMin: Double, limitMax: Double): Pair<Double, Double> =
        window(baseMinX, baseMaxX, sideX, limitMin, limitMax)

    /** Window for Y as (min, max) for the given limits. */
    fun windowY(limitMin: Double, limitMax: Double): Pair<Double, Double> =
        window(baseMinY, baseMaxY, sideY, limitMin, limitMax)

    /**
     * The original G-code rotated by [angleDeg] (counter-clockwise positive), fitted into the limits and with its
     * bounding box centred as close to ([desiredCx], [desiredCy]) as the window allows.
     * [limitMin] / [limitMax] are the two limits in either order (e.g. 0 and 40).
     */
    fun place(
        angleDeg: Double,
        desiredCx: Double,
        desiredCy: Double,
        limitMin: Double,
        limitMax: Double,
    ): PlacementResult {
        require(hasToolpath) { "there is no toolpath to place" }
        val lo = min(limitMin, limitMax)
        val hi = max(limitMin, limitMax)
        val angle = ((angleDeg % 360.0) + 360.0) % 360.0

        // 1) the original rotated about the origin, unscaled and unshifted: only its SHAPE (size) matters here
        val rMinX: Double
        val rMaxX: Double
        val rMinY: Double
        val rMaxY: Double
        if (angle == 0.0) {
            rMinX = baseMinX; rMaxX = baseMaxX; rMinY = baseMinY; rMaxY = baseMaxY
        } else {
            val rotated = GCodeTransformer("left", angle, 0.0, 0.0, precision, true, 1.0)
            rotated.processText(baseText)
            rMinX = rotated.minX; rMaxX = rotated.maxX; rMinY = rotated.minY; rMaxY = rotated.maxY
        }
        val width = rMaxX - rMinX
        val height = rMaxY - rMinY

        // 2) the window, and the uniform scale (never above 1) that makes the rotated drawing fit it
        val (wxLo, wxHi) = windowX(lo, hi)
        val (wyLo, wyHi) = windowY(lo, hi)
        var scale = 1.0
        if (width > EPS) scale = min(scale, (wxHi - wxLo) / width)
        if (height > EPS) scale = min(scale, (wyHi - wyLo) / height)
        scale = max(scale, MIN_SCALE)
        val halfW = scale * width / 2
        val halfH = scale * height / 2

        // 3) the smallest translation that keeps the (scaled) bounding box inside the window
        val cx = clamp(desiredCx, wxLo + halfW, wxHi - halfW)
        val cy = clamp(desiredCy, wyLo + halfH, wyHi - halfH)

        // bounding-box centre after scaling about the origin is scale * (min + max) / 2; move it onto (cx, cy)
        val offsetX = cx - scale * (rMinX + rMaxX) / 2
        val offsetY = cy - scale * (rMinY + rMaxY) / 2

        val fin = GCodeTransformer(
            direction = if (angle == 0.0) null else "left",
            angle = angle,
            offsetX = offsetX,
            offsetY = offsetY,
            precision = precision,
            fixedHome = true,
            scale = scale,
        )
        val text = fin.processText(baseText)

        return PlacementResult(
            text = text,
            angleDeg = angle,
            scale = scale,
            centerX = cx,
            centerY = cy,
            halfWidth = halfW,
            halfHeight = halfH,
            minX = fin.minX,
            maxX = fin.maxX,
            minY = fin.minY,
            maxY = fin.maxY,
            windowMinX = wxLo,
            windowMaxX = wxHi,
            windowMinY = wyLo,
            windowMaxY = wyHi,
            clampedX = kotlin.math.abs(cx - desiredCx) > 1e-9,
            clampedY = kotlin.math.abs(cy - desiredCy) > 1e-9,
            warningCount = fin.warnings.size,
        )
    }

    private fun sideOf(lo: Double, hi: Double): AxisSide = when {
        lo >= -EPS -> AxisSide.POSITIVE
        hi <= EPS -> AxisSide.NEGATIVE
        else -> AxisSide.BOTH
    }

    private fun window(
        axisMin: Double,
        axisMax: Double,
        side: AxisSide,
        limitMin: Double,
        limitMax: Double,
    ): Pair<Double, Double> {
        val lo = min(limitMin, limitMax)
        val hi = max(limitMin, limitMax)
        return when (side) {
            AxisSide.POSITIVE -> Pair(min(lo, axisMin), max(hi, axisMax))
            AxisSide.NEGATIVE -> Pair(min(-hi, axisMin), max(-lo, axisMax))
            AxisSide.BOTH -> Pair(min(-hi, axisMin), max(hi, axisMax))
        }
    }

    companion object {
        private const val EPS = 1e-9
        private const val MIN_SCALE = 1e-3

        /** Clamp that cannot throw when float noise makes the interval empty by a hair. */
        fun clamp(v: Double, lo: Double, hi: Double): Double =
            if (lo > hi) (lo + hi) / 2 else min(max(v, lo), hi)
    }
}
