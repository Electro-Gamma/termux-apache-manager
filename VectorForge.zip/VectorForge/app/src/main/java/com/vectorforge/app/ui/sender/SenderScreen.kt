package com.vectorforge.app.ui.sender

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.East
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.LinkOff
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.North
import androidx.compose.material.icons.filled.NorthEast
import androidx.compose.material.icons.filled.NorthWest
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.South
import androidx.compose.material.icons.filled.SouthEast
import androidx.compose.material.icons.filled.SouthWest
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Usb
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.West
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.vectorforge.app.sender.ConnState
import com.vectorforge.app.sender.ConsoleLine
import com.vectorforge.app.sender.Firmware
import com.vectorforge.app.sender.GcodeLineTools
import com.vectorforge.app.sender.JobState
import com.vectorforge.app.sender.LinkType
import com.vectorforge.app.sender.LogKind
import com.vectorforge.app.sender.SenderUiState
import com.vectorforge.app.sender.SenderViewModel
import com.vectorforge.app.ui.convert.components.AccordionSection
import com.vectorforge.app.ui.convert.components.DoubleField
import com.vectorforge.app.ui.convert.components.IntField
import com.vectorforge.app.ui.convert.components.LabeledDropdown
import com.vectorforge.app.ui.convert.components.LabeledSlider
import com.vectorforge.app.ui.convert.components.PillBadge
import com.vectorforge.app.ui.convert.components.SectionCard
import com.vectorforge.app.ui.convert.components.SegmentedControl
import com.vectorforge.app.ui.convert.components.TextFieldRow
import com.vectorforge.app.ui.convert.components.ToggleRow
import com.vectorforge.app.ui.theme.VfRadius
import com.vectorforge.app.ui.theme.VfSpacing
import com.vectorforge.app.ui.theme.VfType
import java.io.File
import java.util.Locale
import kotlin.math.roundToInt

private val BAUD_RATES = listOf(9600, 19200, 38400, 57600, 115200, 250000)
private val STEP_SIZES = listOf(0.1, 0.5, 1.0, 5.0, 10.0, 20.0)

/**
 * Tab 3: the G-code controller / sender. Connects to the machine (Bluetooth, Wi-Fi bridge or USB-OTG), jogs it,
 * homes it, sets the speed and streams a G-code file to it line by line (see [SenderViewModel]).
 */
@Composable
fun SenderScreen(
    vm: SenderViewModel,
    latestGcode: File?,
    onPickGcode: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val ui by vm.ui.collectAsState()
    val console by vm.console.collectAsState()

    // Keep the screen on while a job streams: a sleeping phone would drop the Bluetooth / Wi-Fi link.
    val view = LocalView.current
    val running = ui.job == JobState.RUNNING
    DisposableEffect(running) {
        view.keepScreenOn = running
        onDispose { view.keepScreenOn = false }
    }

    val bluetoothPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        vm.refreshPorts()
    }
    LaunchedEffect(Unit) { vm.refreshPorts() }

    Box(modifier.fillMaxWidth(), contentAlignment = Alignment.TopCenter) {
        Column(
            modifier = Modifier
                .widthIn(max = 640.dp)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = VfSpacing.marginMobile),
            verticalArrangement = Arrangement.spacedBy(VfSpacing.md),
        ) {
            Spacer(Modifier.height(VfSpacing.xs))
            HeaderRow(ui, onEmergencyStop = { vm.halt(emergency = true) })

            ConnectionCard(
                ui = ui,
                vm = vm,
                onRequestBluetooth = {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        bluetoothPermission.launch(Manifest.permission.BLUETOOTH_CONNECT)
                    }
                },
            )
            JogCard(ui, vm)
            SpeedCard(ui, vm)
            SendCard(ui, vm, latestGcode, onPickGcode)
            ConsoleCard(ui, vm, console)
            SettingsSection(ui, vm)

            Spacer(Modifier.height(VfSpacing.xl))
        }
    }

    ui.errorDialog?.let { message ->
        AlertDialog(
            onDismissRequest = vm::dismissError,
            confirmButton = { TextButton(onClick = vm::dismissError) { Text("OK") } },
            title = { Text("Controller", style = VfType.headlineSm) },
            text = { Text(message, style = VfType.bodyMd) },
        )
    }
}

// ==========================================================================================================
// Header
// ==========================================================================================================

@Composable
private fun HeaderRow(ui: SenderUiState, onEmergencyStop: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text("CONTROLLER", style = VfType.headlineMd, color = scheme.onSurface)
            Row(horizontalArrangement = Arrangement.spacedBy(VfSpacing.xs), verticalAlignment = Alignment.CenterVertically) {
                when (ui.conn) {
                    ConnState.CONNECTED -> PillBadge("CONNECTED · ${ui.connLabel}".uppercase(Locale.ROOT), scheme.primary)
                    ConnState.CONNECTING -> PillBadge("CONNECTING…", scheme.secondary)
                    ConnState.DISCONNECTED -> PillBadge("NOT CONNECTED", scheme.onSurfaceVariant)
                }
                if (ui.machineState.isNotEmpty()) {
                    PillBadge(ui.machineState.uppercase(Locale.ROOT), if (ui.machineState.startsWith("ALARM", ignoreCase = true)) scheme.error else scheme.tertiary)
                }
            }
        }
        Button(
            onClick = onEmergencyStop,
            enabled = ui.connected || ui.job != JobState.IDLE,
            shape = CircleShape,
            colors = ButtonDefaults.buttonColors(containerColor = scheme.error, contentColor = scheme.onError),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 10.dp),
        ) {
            Icon(Icons.Filled.PowerSettingsNew, contentDescription = null, modifier = Modifier.size(18.dp))
            Text("E-STOP", style = VfType.labelLg, modifier = Modifier.padding(start = 6.dp))
        }
    }
}

// ==========================================================================================================
// Connection
// ==========================================================================================================

@Composable
private fun ConnectionCard(ui: SenderUiState, vm: SenderViewModel, onRequestBluetooth: () -> Unit) {
    val idle = ui.conn == ConnState.DISCONNECTED
    SectionCard {
        CardTitle(Icons.Filled.Link, "CONNECTION")

        SegmentedControl(
            options = listOf("BLUETOOTH", "WI-FI", "USB"),
            selectedIndex = ui.linkType.ordinal,
            onSelect = { if (idle) vm.setLinkType(LinkType.entries[it]) },
        )

        when (ui.linkType) {
            LinkType.BLUETOOTH -> {
                if (!vm.hasBluetoothPermission()) {
                    Hint("Bluetooth permission is needed to list your paired HC-05 / HC-06 modules.")
                    ActionPill("ALLOW BLUETOOTH", Icons.Filled.Bluetooth, onClick = onRequestBluetooth)
                } else if (ui.btDevices.isEmpty()) {
                    Hint("No paired devices. Pair the module in Android's Bluetooth settings first (PIN is usually 1234 or 0000), then refresh.")
                    ActionPill("REFRESH", Icons.Filled.Refresh, onClick = vm::refreshPorts)
                } else {
                    val selected = ui.btDevices.firstOrNull { it.id == ui.selectedBt } ?: ui.btDevices.first()
                    Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(VfSpacing.xs)) {
                        Box(Modifier.weight(1f)) {
                            LabeledDropdown(
                                label = "PAIRED DEVICE",
                                options = ui.btDevices,
                                selected = selected,
                                optionLabel = { it.name },
                                onSelect = { if (idle) vm.selectBluetooth(it.id) },
                            )
                        }
                        IconButton(onClick = vm::refreshPorts) { Icon(Icons.Filled.Refresh, contentDescription = "Refresh devices") }
                    }
                }
            }
            LinkType.WIFI -> {
                Hint("For an ESP8266 / ESP32 running a serial-to-TCP bridge (default port 23 or 8888).")
                TextFieldRow("HOST / IP ADDRESS", ui.host, onValueChange = { if (idle) vm.setHost(it) }, placeholder = "192.168.4.1", enabled = idle)
                IntField("PORT", ui.port, onValueChange = { if (idle) vm.setPort(it) }, enabled = idle)
            }
            LinkType.USB -> {
                if (ui.usbDevices.isEmpty()) {
                    Hint("Plug the board into the phone with a USB-OTG cable, then refresh. Boards with a CH340 / CP210x / FTDI chip are not supported over USB: use Bluetooth or Wi-Fi for those.")
                    ActionPill("REFRESH", Icons.Filled.Refresh, onClick = vm::refreshPorts)
                } else {
                    val selected = ui.usbDevices.firstOrNull { it.id == ui.selectedUsb } ?: ui.usbDevices.first()
                    Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(VfSpacing.xs)) {
                        Box(Modifier.weight(1f)) {
                            LabeledDropdown(
                                label = "USB DEVICE",
                                options = ui.usbDevices,
                                selected = selected,
                                optionLabel = { it.name },
                                onSelect = { if (idle) vm.selectUsb(it.id) },
                            )
                        }
                        IconButton(onClick = vm::refreshPorts) { Icon(Icons.Filled.Refresh, contentDescription = "Refresh devices") }
                    }
                    LabeledDropdown(
                        label = "BAUD RATE",
                        options = BAUD_RATES,
                        selected = if (ui.baud in BAUD_RATES) ui.baud else BAUD_RATES.first(),
                        optionLabel = { it.toString() },
                        onSelect = { if (idle) vm.setBaud(it) },
                    )
                }
            }
        }

        LabeledDropdown(
            label = "FIRMWARE ON THE MACHINE",
            options = Firmware.entries.toList(),
            selected = ui.firmware,
            optionLabel = { it.label },
            onSelect = { if (idle) vm.setFirmware(it) },
        )

        when (ui.conn) {
            ConnState.DISCONNECTED -> {
                val needsPermission = ui.linkType == LinkType.BLUETOOTH && !vm.hasBluetoothPermission()
                ActionPill(
                    text = "CONNECT",
                    icon = Icons.Filled.Link,
                    filled = true,
                    full = true,
                    onClick = { if (needsPermission) onRequestBluetooth() else vm.connect() },
                )
            }
            ConnState.CONNECTING -> ActionPill("CANCEL", Icons.Filled.LinkOff, full = true, onClick = vm::disconnect)
            ConnState.CONNECTED -> ActionPill("DISCONNECT", Icons.Filled.LinkOff, full = true, onClick = vm::disconnect)
        }
    }
}

// ==========================================================================================================
// Jog / home / pen
// ==========================================================================================================

@Composable
private fun JogCard(ui: SenderUiState, vm: SenderViewModel) {
    val enabled = ui.canJog
    SectionCard {
        CardTitle(Icons.Filled.MyLocation, "JOG & HOME")

        // Position read-out
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(VfRadius.xl2))
                .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                .padding(VfSpacing.md),
            horizontalArrangement = Arrangement.SpaceAround,
        ) {
            Readout("X", ui.x)
            Readout("Y", ui.y)
            if (ui.firmware == Firmware.PLOTTER) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("PEN", style = VfType.labelSm, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        when (ui.penDown) { true -> "DOWN"; false -> "UP"; null -> "?" },
                        style = VfType.headlineSm,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                }
            } else {
                Readout("Z", ui.z)
            }
        }

        // Direction pad: up = Y+, right = X+
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Column(
                Modifier.widthIn(max = 280.dp).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(VfSpacing.sm),
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(VfSpacing.sm)) {
                    PadKey(Icons.Filled.NorthWest, "Left and up", enabled) { vm.jog(-1, 1) }
                    PadKey(Icons.Filled.North, "Up (Y+)", enabled) { vm.jog(0, 1) }
                    PadKey(Icons.Filled.NorthEast, "Right and up", enabled) { vm.jog(1, 1) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(VfSpacing.sm)) {
                    PadKey(Icons.Filled.West, "Left (X-)", enabled) { vm.jog(-1, 0) }
                    PadKey(Icons.Filled.Home, "Home", enabled, accent = true) { vm.home() }
                    PadKey(Icons.Filled.East, "Right (X+)", enabled) { vm.jog(1, 0) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(VfSpacing.sm)) {
                    PadKey(Icons.Filled.SouthWest, "Left and down", enabled) { vm.jog(-1, -1) }
                    PadKey(Icons.Filled.South, "Down (Y-)", enabled) { vm.jog(0, -1) }
                    PadKey(Icons.Filled.SouthEast, "Right and down", enabled) { vm.jog(1, -1) }
                }
            }
        }

        // Step size
        Column {
            Text("STEP SIZE (mm)", style = VfType.labelMd, color = MaterialTheme.colorScheme.onSurface)
            Spacer(Modifier.height(4.dp))
            SegmentedControl(
                options = STEP_SIZES.map { GcodeLineTools.num(it) },
                selectedIndex = STEP_SIZES.indexOf(ui.stepMm).let { if (it < 0) 2 else it },
                onSelect = { vm.setStep(STEP_SIZES[it]) },
            )
        }

        // Pen (plotter) or Z axis (everything else)
        if (ui.firmware == Firmware.PLOTTER) {
            Row(horizontalArrangement = Arrangement.spacedBy(VfSpacing.sm)) {
                ActionPill("PEN UP", Icons.Filled.North, enabled = enabled, full = true, modifier = Modifier.weight(1f), onClick = vm::penUp)
                ActionPill("PEN DOWN", Icons.Filled.South, enabled = enabled, full = true, modifier = Modifier.weight(1f), onClick = vm::penDown)
            }
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(VfSpacing.sm)) {
                ActionPill("Z +", Icons.Filled.North, enabled = enabled, full = true, modifier = Modifier.weight(1f)) { vm.jogZ(1) }
                ActionPill("Z −", Icons.Filled.South, enabled = enabled, full = true, modifier = Modifier.weight(1f)) { vm.jogZ(-1) }
            }
        }

        // Machine actions
        Row(
            Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(VfSpacing.sm),
        ) {
            ActionPill("HOME", Icons.Filled.Home, enabled = enabled, onClick = vm::home)
            ActionPill("GO TO 0,0", Icons.Filled.MyLocation, enabled = enabled, onClick = vm::goToZero)
            if (ui.firmware != Firmware.PLOTTER) ActionPill("SET ZERO", Icons.Filled.Tune, enabled = enabled, onClick = vm::setZero)
            if (ui.firmware == Firmware.GRBL) {
                ActionPill("UNLOCK", Icons.Filled.LockOpen, enabled = ui.connected, onClick = vm::unlock)
                ActionPill("RESET", Icons.Filled.Replay, enabled = ui.connected, onClick = vm::softReset)
            }
            ActionPill("SYNC", Icons.Filled.Refresh, enabled = ui.connected, onClick = vm::syncPosition)
        }

        ui.statusNote?.let { Hint(it, error = true) }
        if (ui.firmware == Firmware.PLOTTER) {
            Hint("The stock sketch has no end-stops and no homing: Home lifts the pen and returns to X0 Y0, and the position shown is tracked by this app (limits: ${GcodeLineTools.num(ui.workX)} × ${GcodeLineTools.num(ui.workY)} mm).")
        }
    }
}

@Composable
private fun Readout(axis: String, value: Double) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(axis, style = VfType.labelSm, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(
            String.format(Locale.ROOT, "%.2f", value),
            style = VfType.headlineSm,
            fontFamily = FontFamily.Monospace,
            color = MaterialTheme.colorScheme.onSurface,
        )
    }
}

@Composable
private fun RowScope.PadKey(
    icon: ImageVector,
    description: String,
    enabled: Boolean,
    accent: Boolean = false,
    onClick: () -> Unit,
) {
    val scheme = MaterialTheme.colorScheme
    val background = if (accent) scheme.primary.copy(alpha = 0.18f) else scheme.surfaceContainerHighest
    val tint = if (accent) scheme.primary else scheme.onSurface
    Box(
        modifier = Modifier
            .weight(1f)
            .aspectRatio(1f)
            .clip(RoundedCornerShape(VfRadius.xl2))
            .background(if (enabled) background else background.copy(alpha = 0.4f))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = description, tint = if (enabled) tint else tint.copy(alpha = 0.4f), modifier = Modifier.size(30.dp))
    }
}

// ==========================================================================================================
// Speed
// ==========================================================================================================

@Composable
private fun SpeedCard(ui: SenderUiState, vm: SenderViewModel) {
    SectionCard {
        CardTitle(Icons.Filled.Speed, "SPEED")
        LabeledSlider(
            label = "JOG SPEED",
            value = ui.jogFeed.toFloat(),
            onValueChange = { vm.setJogFeed((it / 50f).roundToInt() * 50) },
            valueRange = 50f..6000f,
            valueLabel = "${ui.jogFeed} mm/min",
        )
        LabeledSlider(
            label = "FEED OVERRIDE",
            value = ui.feedPercent.toFloat(),
            onValueChange = { vm.setFeedPercent(it.roundToInt()) },
            valueRange = 10f..200f,
            valueLabel = "${ui.feedPercent} %",
            onValueChangeFinished = vm::commitFeedPercent,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(VfSpacing.sm)) {
            listOf(25, 50, 100, 150, 200).forEach { pct ->
                ActionPill(
                    text = "$pct%",
                    icon = null,
                    filled = ui.feedPercent == pct,
                    enabled = true,
                    modifier = Modifier.weight(1f),
                    full = true,
                ) {
                    vm.setFeedPercent(pct)
                    vm.commitFeedPercent()
                }
            }
        }
        Hint(
            when (ui.firmware) {
                Firmware.GRBL -> "The override rescales the F word of every line that is sent. Jog speed applies to the jog pad."
                Firmware.GENERIC -> "The override is sent as M220 S<percent> (feed-rate override). Jog speed applies to the jog pad."
                Firmware.PLOTTER -> "The override is sent as M220 S<percent>. The stock plotter sketch ignores F words and M220 (its speed is fixed in the code); the patched sketch in docs/firmware makes M220 change the stepper speed."
            }
        )
    }
}

// ==========================================================================================================
// Send G-code
// ==========================================================================================================

@Composable
private fun SendCard(ui: SenderUiState, vm: SenderViewModel, latestGcode: File?, onPickGcode: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    val idle = ui.job == JobState.IDLE
    SectionCard {
        CardTitle(Icons.Filled.Terminal, "SEND G-CODE")

        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(VfRadius.xl2))
                .background(scheme.surfaceContainerHigh)
                .padding(VfSpacing.md),
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            Text(
                ui.fileName.ifEmpty { "No G-code loaded" },
                style = VfType.titleMd,
                color = if (ui.fileName.isEmpty()) scheme.onSurfaceVariant else scheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            val s = ui.summary
            if (s != null) {
                val extent = if (s.hasBounds) {
                    " · X ${GcodeLineTools.num(s.minX ?: 0.0)}–${GcodeLineTools.num(s.maxX ?: 0.0)}" +
                        " · Y ${GcodeLineTools.num(s.minY ?: 0.0)}–${GcodeLineTools.num(s.maxY ?: 0.0)} mm"
                } else ""
                Text("${ui.totalLines} lines$extent", style = VfType.bodySm, color = scheme.onSurfaceVariant)
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(VfSpacing.sm)) {
            ActionPill("OPEN FILE", Icons.Filled.FileOpen, enabled = ui.job != JobState.RUNNING, full = true, modifier = Modifier.weight(1f), onClick = onPickGcode)
            ActionPill(
                "LATEST GENERATED", Icons.Filled.History,
                enabled = ui.job != JobState.RUNNING && latestGcode != null,
                full = true, modifier = Modifier.weight(1f),
            ) { latestGcode?.let(vm::loadFile) }
        }

        jobWarnings(ui).forEach { Hint(it, warning = true) }

        // Progress
        if (ui.totalLines > 0 && (ui.job != JobState.IDLE || ui.sentLines > 0)) {
            LinearProgressIndicator(
                progress = { ui.progress },
                modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape),
                color = scheme.primary,
                trackColor = scheme.surfaceContainerHighest,
            )
            Text(
                "Line ${ui.sentLines} / ${ui.totalLines} · ${(ui.progress * 100).roundToInt()} % · ${SenderViewModel.formatTime(ui.elapsedSec)}",
                style = VfType.labelSm,
                color = scheme.onSurfaceVariant,
            )
        }

        ui.notice?.let { Hint(it, error = ui.noticeIsError) }

        // Controls
        when (ui.job) {
            JobState.IDLE -> ActionPill(
                "START", Icons.Filled.PlayArrow, filled = true, full = true,
                enabled = ui.connected && ui.totalLines > 0, onClick = vm::start,
            )
            JobState.RUNNING -> Row(horizontalArrangement = Arrangement.spacedBy(VfSpacing.sm)) {
                ActionPill("PAUSE", Icons.Filled.Pause, full = true, modifier = Modifier.weight(1f), onClick = vm::pause)
                ActionPill("STOP", Icons.Filled.Stop, full = true, danger = true, modifier = Modifier.weight(1f)) { vm.halt(emergency = false) }
            }
            JobState.PAUSED -> {
                Row(horizontalArrangement = Arrangement.spacedBy(VfSpacing.sm)) {
                    ActionPill("RESUME", Icons.Filled.PlayArrow, filled = true, full = true, modifier = Modifier.weight(1f), onClick = vm::resume)
                    ActionPill("STOP", Icons.Filled.Stop, full = true, danger = true, modifier = Modifier.weight(1f)) { vm.halt(emergency = false) }
                }
                if (ui.noticeIsError) {
                    ActionPill("SKIP THIS LINE", Icons.Filled.SkipNext, full = true, onClick = vm::skipLine)
                }
            }
        }
        if (idle && ui.totalLines > 0 && !ui.connected) Hint("Connect to the machine to start.")

        ToggleRow(
            title = "Continue after errors",
            subtitle = "Log a failing line and carry on instead of pausing",
            checked = ui.ignoreErrors,
            onCheckedChange = vm::setIgnoreErrors,
        )
    }
}

private fun jobWarnings(ui: SenderUiState): List<String> {
    val s = ui.summary ?: return emptyList()
    val out = ArrayList<String>()
    if (s.hasBounds) {
        val minX = s.minX ?: 0.0
        val maxX = s.maxX ?: 0.0
        val minY = s.minY ?: 0.0
        val maxY = s.maxY ?: 0.0
        if (minX < -0.001 || minY < -0.001 || maxX > ui.workX + 0.001 || maxY > ui.workY + 0.001) {
            out.add(
                "The drawing spans X ${GcodeLineTools.num(minX)}–${GcodeLineTools.num(maxX)}, Y ${GcodeLineTools.num(minY)}–${GcodeLineTools.num(maxY)} mm, " +
                    "outside the ${GcodeLineTools.num(ui.workX)} × ${GcodeLineTools.num(ui.workY)} mm work area. The plotter firmware clamps moves to its limits."
            )
        }
    }
    if (ui.firmware == Firmware.PLOTTER) {
        val odd = s.penValues.filter { it != 30.0 && it != 50.0 && it != 255.0 }
        if (odd.isNotEmpty()) {
            out.add(
                "This file uses pen angles ${odd.joinToString { GcodeLineTools.num(it) }}. The stock sketch only reacts to M300 S30 (down) and S50 (up): " +
                    "generate with 50 / 30 on the Convert tab or change penZUp / penZDown in the sketch."
            )
        }
        if (s.usesRelative) out.add("The file switches to relative moves (G91). The stock plotter sketch only understands absolute coordinates.")
    }
    return out
}

// ==========================================================================================================
// Console
// ==========================================================================================================

@Composable
private fun ConsoleCard(ui: SenderUiState, vm: SenderViewModel, console: List<ConsoleLine>) {
    val scheme = MaterialTheme.colorScheme
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    LaunchedEffect(console.lastOrNull()?.id) {
        if (console.isNotEmpty()) listState.scrollToItem(console.lastIndex)
    }
    val submit = {
        if (input.isNotBlank()) {
            vm.sendConsole(input)
            input = ""
        }
    }
    SectionCard {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            CardTitle(Icons.Filled.Terminal, "CONSOLE")
            IconButton(onClick = vm::clearConsole) { Icon(Icons.Filled.DeleteSweep, contentDescription = "Clear console") }
        }

        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxWidth()
                .height(220.dp)
                .clip(RoundedCornerShape(VfRadius.xl))
                .background(scheme.surfaceContainerLowest)
                .padding(VfSpacing.sm),
        ) {
            items(console, key = { it.id }) { line ->
                val (prefix, color) = when (line.kind) {
                    LogKind.TX -> "> " to scheme.primary
                    LogKind.RX -> "< " to scheme.onSurface
                    LogKind.INFO -> "# " to scheme.onSurfaceVariant
                    LogKind.ERROR -> "! " to scheme.error
                }
                Text(prefix + line.text, style = VfType.bodySm, fontFamily = FontFamily.Monospace, color = color)
            }
        }

        // Quick commands fill the input line; the user decides whether to send them.
        val quick = when (ui.firmware) {
            Firmware.PLOTTER -> listOf("M114", "G0 X0 Y0", "M300 S50", "M300 S30")
            Firmware.GRBL -> listOf("\$\$", "\$#", "\$G", "\$X", "\$H")
            Firmware.GENERIC -> listOf("M114", "M115", "G28", "M503")
        }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(VfSpacing.xs)) {
            quick.forEach { cmd ->
                ActionPill(cmd, icon = null, enabled = true) { input = cmd }
            }
        }

        TextField(
            value = input,
            onValueChange = { input = it },
            singleLine = true,
            enabled = ui.canJog,
            placeholder = { Text(if (ui.job == JobState.RUNNING) "Busy: a job is running" else "G-code command", style = VfType.bodySm) },
            textStyle = VfType.bodyMd.copy(fontFamily = FontFamily.Monospace),
            shape = RoundedCornerShape(VfRadius.xl2),
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters, imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(onSend = { submit() }),
            trailingIcon = {
                IconButton(onClick = { submit() }, enabled = ui.canJog && input.isNotBlank()) {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send")
                }
            },
            modifier = Modifier.fillMaxWidth(),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = scheme.surfaceContainerHigh,
                unfocusedContainerColor = scheme.surfaceContainerHigh,
                disabledContainerColor = scheme.surfaceContainerHigh,
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
                disabledIndicatorColor = Color.Transparent,
                focusedTextColor = scheme.onSurface,
                unfocusedTextColor = scheme.onSurface,
            ),
        )

        ToggleRow(
            title = "Log job traffic",
            subtitle = "Show every line sent during a job",
            checked = ui.logJobTraffic,
            onCheckedChange = vm::setLogJobTraffic,
        )
    }
}

// ==========================================================================================================
// Machine settings
// ==========================================================================================================

@Composable
private fun SettingsSection(ui: SenderUiState, vm: SenderViewModel) {
    AccordionSection(title = "Machine settings", icon = Icons.Filled.Tune) {
        Text(
            "Work area is used to limit the jog pad (the stock plotter sketch uses 40 × 40 mm) and to warn when a file does not fit.",
            style = VfType.bodySm, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        DoubleField("WORK AREA X", ui.workX, onValueChange = vm::setWorkX, unit = "mm")
        DoubleField("WORK AREA Y", ui.workY, onValueChange = vm::setWorkY, unit = "mm")
        IntField("PEN UP  (M300 S...)", ui.penUpS, onValueChange = vm::setPenUpS)
        IntField("PEN DOWN  (M300 S...)", ui.penDownS, onValueChange = vm::setPenDownS)
        Text(
            "The stock sketch only understands S50 (up) and S30 (down).",
            style = VfType.bodySm, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

// ==========================================================================================================
// Small shared pieces
// ==========================================================================================================

@Composable
private fun CardTitle(icon: ImageVector, title: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(VfSpacing.xs)) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
        Text(title, style = VfType.titleMd, color = MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
private fun Hint(text: String, error: Boolean = false, warning: Boolean = false) {
    val scheme = MaterialTheme.colorScheme
    val color = when {
        error -> scheme.error
        warning -> scheme.secondary
        else -> scheme.onSurfaceVariant
    }
    Row(horizontalArrangement = Arrangement.spacedBy(VfSpacing.xs)) {
        if (warning || error) {
            Icon(Icons.Filled.Warning, contentDescription = null, tint = color, modifier = Modifier.size(16.dp))
        }
        Text(text, style = VfType.bodySm, color = color)
    }
}

/** The pill button used all over this screen. [filled] = primary colour, [danger] = red, otherwise tonal. */
@Composable
private fun ActionPill(
    text: String,
    icon: ImageVector?,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    filled: Boolean = false,
    danger: Boolean = false,
    full: Boolean = false,
    onClick: () -> Unit,
) {
    val scheme = MaterialTheme.colorScheme
    val container = when {
        danger -> scheme.error
        filled -> scheme.primary
        else -> scheme.surfaceContainerHighest
    }
    val content = when {
        danger -> scheme.onError
        filled -> scheme.onPrimary
        else -> scheme.onSurface
    }
    Button(
        onClick = onClick,
        enabled = enabled,
        shape = CircleShape,
        colors = ButtonDefaults.buttonColors(
            containerColor = container,
            contentColor = content,
            disabledContainerColor = container.copy(alpha = 0.35f),
            disabledContentColor = content.copy(alpha = 0.5f),
        ),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 14.dp, vertical = if (full) 12.dp else 8.dp),
        modifier = if (full) modifier.fillMaxWidth() else modifier,
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.size(6.dp))
        }
        Text(text, style = VfType.labelLg, maxLines = 1)
    }
}
