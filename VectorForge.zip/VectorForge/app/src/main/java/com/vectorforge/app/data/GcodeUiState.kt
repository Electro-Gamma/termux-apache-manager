package com.vectorforge.app.data

import com.vectorforge.app.engine.gcode.transform.TransformOptions
import java.io.File

/**
 * PREFILLED and always passed (the settings verified on the desktop CLI run
 * `--pen-up-angle 50 --pen-down-angle 30 --xy-feedrate 3500 --new-min 0
 * --new-max 40 --no-reduce`): penUpAngle, penDownAngle, xyFeedrate, newMin,
 * newMax, reduceThinPoints (default OFF == --no-reduce).
 *
 * OPTIONAL OVERRIDES (nullable): every other generator parameter. `null`
 * means untouched -- the input only shows the engine default (see
 * [GcodeDefaults]) as a faint placeholder and the value is NOT passed to the
 * generator. It is used only once the user types a value / flips the toggle;
 * clearing the input (or resetting the toggle) makes it unused again.
 *
 * Field names match `Args` in SvgToGcodeUnicorn.kt.
 */
data class GcodeUiState(
    // -- Input SVG Source ---------------------------------------------------
    val svgFile: File? = null,
    val svgFileName: String = "",
    val svgFileSizeLabel: String = "", // e.g. "24.8 KB"

    // -- Output G-Code Path --------------------------------------------------
    val outputGcodePath: String = "",

    // -- Prefilled + always passed ---------------------------------------------
    val penUpAngle: Double = 50.0,
    val penDownAngle: Double = 30.0,
    val xyFeedrate: Double = 3500.0,
    val newMin: Double = 0.0,
    val newMax: Double = 40.0,
    val reduceThinPoints: Boolean = false, // --no-reduce

    // -- Optional overrides: null = untouched, not passed -------------------------
    val startDelayMs: Int? = null,
    val stopDelayMs: Int? = null,
    val registerPen: Boolean? = null,
    val zFeedrate: Double? = null,
    val zHeight: Double? = null,
    val finishedHeight: Double? = null,
    val xHome: Double? = null,
    val yHome: Double? = null,
    val numCopies: Int? = null,
    val continuousPlotting: Boolean? = null,
    val pauseOnLayerChange: Boolean? = null,
    val compatibilityTab: String = "", // blank = untouched
    val flatness: Double? = null,
    val dpi: Double? = null,
    val minChange: Double? = null,
    val skipFactor: Int? = null,
    val normalizeOutputBounds: Boolean? = null,

    // -- G-code transform (post-processing, applied to the generated G-code) ----------------------------------
    // One field per argument of GcodeTransform. Blank / off = not passed. The transform runs as soon as any
    // of them (other than --no-fixed-home and --precision alone) is set. See engine/gcode/transform/.
    val transformRotateLeft: Double? = null,    // --rotate-left DEG   (counter-clockwise)
    val transformRotateRight: Double? = null,   // --rotate-right DEG  (clockwise)
    val transformOffsetX: Double? = null,       // --offset-x
    val transformOffsetY: Double? = null,       // --offset-y
    val keepPositive: Boolean = false,          // --keep-positive  (X>=0 and Y>=0)
    val keepNegative: Boolean = false,          // --keep-negative  (X<=0 and Y<=0)
    val keepEast: Boolean = false,              // --keep-east      (X>=0)
    val keepWest: Boolean = false,              // --keep-west      (X<=0)
    val keepNorth: Boolean = false,             // --keep-north     (Y>=0)
    val keepSouth: Boolean = false,             // --keep-south     (Y<=0)
    val transformNoFixedHome: Boolean = false,  // --no-fixed-home
    val transformMaxX: Double? = null,          // --max-x (warning only)
    val transformMaxY: Double? = null,          // --max-y (warning only)
    val transformPrecision: Int? = null,        // --precision (blank = transformer default)

    // -- Run state / status card --------------------------------------------
    val isGenerating: Boolean = false,
    val statusTitle: String = "Vector to CNC Ready",
    val statusDetail: String =
        "Configured for standard 2-axis pen carriage with servo stroke commands (M03 S30 / M05 S50).",
    val lineCount: Int? = null,
    val errorMessage: String? = null,
    val generatedGcodeFile: File? = null,
) {
    /** True when any transform setting is in use, i.e. the generated G-code must go through the transformer. */
    val transformActive: Boolean
        get() = transformRotateLeft != null || transformRotateRight != null ||
            transformOffsetX != null || transformOffsetY != null ||
            keepPositive || keepNegative || keepEast || keepWest || keepNorth || keepSouth ||
            transformMaxX != null || transformMaxY != null

    /**
     * The transformer's options for the current settings, or null when nothing is set (no post-processing).
     * Throws IllegalArgumentException for --rotate-left together with --rotate-right, which the CLI rejects too
     * (the other conflicts, east+west and north+south, are checked by the transformer itself).
     */
    fun transformOptionsOrNull(): TransformOptions? {
        if (!transformActive) return null
        require(transformRotateLeft == null || transformRotateRight == null) {
            "argument --rotate-left: not allowed with argument --rotate-right"
        }
        return TransformOptions(
            direction = when {
                transformRotateLeft != null -> "left"
                transformRotateRight != null -> "right"
                else -> null
            },
            angle = transformRotateLeft ?: transformRotateRight ?: 0.0,
            offsetX = transformOffsetX ?: 0.0,
            offsetY = transformOffsetY ?: 0.0,
            keepPositive = keepPositive,
            keepNegative = keepNegative,
            keepEast = keepEast,
            keepWest = keepWest,
            keepNorth = keepNorth,
            keepSouth = keepSouth,
            noFixedHome = transformNoFixedHome,
            maxX = transformMaxX,
            maxY = transformMaxY,
            precision = transformPrecision ?: GcodeDefaults.transformPrecision,
        )
    }

    val hasSvg: Boolean get() = svgFile != null
    val canConvert: Boolean get() = hasSvg && !isGenerating
}
