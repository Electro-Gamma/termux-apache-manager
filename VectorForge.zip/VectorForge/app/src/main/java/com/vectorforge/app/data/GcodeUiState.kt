package com.vectorforge.app.data

import java.io.File

/**
 * Every field here is either bound directly to a control shown in the
 * reference's "SVG -> G-CODE" section (its five expandable groups: PEN /
 * SERVO, MOTION CONFIG, JOB OPTIONS, GEOMETRY RESOLUTION, POST-PROCESSING),
 * or is status/result data that same section displays back. Field names
 * and default values match `Args` in SvgToGcodeUnicorn.kt one-for-one.
 */
data class GcodeUiState(
    // -- Input SVG Source ---------------------------------------------------
    val svgFile: File? = null,
    val svgFileName: String = "",
    val svgFileSizeLabel: String = "", // e.g. "24.8 KB"

    // -- Output G-Code Path --------------------------------------------------
    val outputGcodePath: String = "",

    // -- PEN / SERVO ---------------------------------------------------------
    val penUpAngle: Double = 50.0,
    val penDownAngle: Double = 30.0,
    val startDelayMs: Int = 150,
    val stopDelayMs: Int = 150,
    val registerPen: Boolean = true,

    // -- MOTION CONFIG ---------------------------------------------------------
    val xyFeedrate: Double = 3500.0,
    val zFeedrate: Double = 150.0,
    val zHeight: Double = 0.0,
    val finishedHeight: Double = 0.0,
    val xHome: Double = 0.0,
    val yHome: Double = 0.0,

    // -- JOB OPTIONS ---------------------------------------------------------
    val numCopies: Int = 1,
    val continuousPlotting: Boolean = false,
    val pauseOnLayerChange: Boolean = false,
    val compatibilityTab: String = "",

    // -- GEOMETRY RESOLUTION ---------------------------------------------------
    val flatness: Double = 0.2,
    val dpi: Double = 96.0,

    // -- POST-PROCESSING ---------------------------------------------------------
    val minChange: Double = 0.5,
    val skipFactor: Int = 3,
    val newMin: Double = 0.0,
    val newMax: Double = 40.0,
    val normalizeOutputBounds: Boolean = true,
    val reduceThinPoints: Boolean = true,

    // -- Run state / status card --------------------------------------------
    val isGenerating: Boolean = false,
    val statusTitle: String = "Vector to CNC Ready",
    val statusDetail: String =
        "Configured for standard 2-axis pen carriage with servo stroke commands (M03 S30 / M05 S50).",
    val lineCount: Int? = null,
    val errorMessage: String? = null,
    val generatedGcodeFile: File? = null,
) {
    val hasSvg: Boolean get() = svgFile != null
    val canConvert: Boolean get() = hasSvg && !isGenerating
}
