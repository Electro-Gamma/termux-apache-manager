package com.vectorforge.app.data

import java.io.File

/**
 * PREFILLED and always passed (the settings verified on the desktop CLI run
 * `--pen-up-angle 50 --pen-down-angle 30 --xy-feedrate 3500 --new-min 0
 * --new-max 40 --no-reduce`): penUpAngle, penDownAngle, xyFeedrate, newMin,
 * newMax, reduceThinPoints (default OFF == --no-reduce).
 *
 * OPTIONAL OVERRIDES (nullable): every other generator parameter. `null`
 * means untouched -- the input only shows the engine default (see
 * [GcodeDefaults]) as a faint placeholder and the value is NOT passed to the
 * generator. It is used only once the user types a value / flips the toggle;
 * clearing the input (or resetting the toggle) makes it unused again.
 *
 * Field names match `Args` in SvgToGcodeUnicorn.kt.
 */
data class GcodeUiState(
    // -- Input SVG Source ---------------------------------------------------
    val svgFile: File? = null,
    val svgFileName: String = "",
    val svgFileSizeLabel: String = "", // e.g. "24.8 KB"

    // -- Output G-Code Path --------------------------------------------------
    val outputGcodePath: String = "",

    // -- Prefilled + always passed ---------------------------------------------
    val penUpAngle: Double = 50.0,
    val penDownAngle: Double = 30.0,
    val xyFeedrate: Double = 3500.0,
    val newMin: Double = 0.0,
    val newMax: Double = 40.0,
    val reduceThinPoints: Boolean = false, // --no-reduce

    // -- Optional overrides: null = untouched, not passed -------------------------
    val startDelayMs: Int? = null,
    val stopDelayMs: Int? = null,
    val registerPen: Boolean? = null,
    val zFeedrate: Double? = null,
    val zHeight: Double? = null,
    val finishedHeight: Double? = null,
    val xHome: Double? = null,
    val yHome: Double? = null,
    val numCopies: Int? = null,
    val continuousPlotting: Boolean? = null,
    val pauseOnLayerChange: Boolean? = null,
    val compatibilityTab: String = "", // blank = untouched
    val flatness: Double? = null,
    val dpi: Double? = null,
    val minChange: Double? = null,
    val skipFactor: Int? = null,
    val normalizeOutputBounds: Boolean? = null,

    // -- Run state / status card --------------------------------------------
    val isGenerating: Boolean = false,
    val statusTitle: String = "Vector to CNC Ready",
    val statusDetail: String =
        "Configured for standard 2-axis pen carriage with servo stroke commands (M03 S30 / M05 S50).",
    val lineCount: Int? = null,
    val errorMessage: String? = null,
    val generatedGcodeFile: File? = null,
) {
    val hasSvg: Boolean get() = svgFile != null
    val canConvert: Boolean get() = hasSvg && !isGenerating
}
