package com.vectorforge.app.ui.convert

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DriveFileMove
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.InvertColors
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material.icons.filled.PrecisionManufacturing
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Straighten
import androidx.compose.material.icons.filled.Gesture
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.vectorforge.app.data.ConvertViewModel
import com.vectorforge.app.data.GcodeUiState
import com.vectorforge.app.data.PotraceUiState
import com.vectorforge.app.data.TraceMode
import com.vectorforge.app.data.TurnPolicyOption
import com.vectorforge.app.ui.convert.components.AccordionSection
import com.vectorforge.app.ui.convert.components.BridgeButton
import com.vectorforge.app.ui.convert.components.DoubleField
import com.vectorforge.app.ui.convert.components.IntField
import com.vectorforge.app.ui.convert.components.LabeledDropdown
import com.vectorforge.app.ui.convert.components.LabeledSlider
import com.vectorforge.app.ui.convert.components.PathField
import com.vectorforge.app.ui.convert.components.PillBadge
import com.vectorforge.app.ui.convert.components.PipelineStepper
import com.vectorforge.app.ui.convert.components.PrimaryActionButton
import com.vectorforge.app.ui.convert.components.SectionCard
import com.vectorforge.app.ui.convert.components.SegmentedControl
import com.vectorforge.app.ui.convert.components.StageHeader
import com.vectorforge.app.ui.convert.components.StatusCard
import com.vectorforge.app.ui.convert.components.StepperField
import com.vectorforge.app.ui.convert.components.TextFieldRow
import com.vectorforge.app.ui.convert.components.ToggleRow
import com.vectorforge.app.ui.convert.components.TonalContainer
import com.vectorforge.app.ui.theme.VfSpacing
import com.vectorforge.app.ui.theme.VfType
import java.util.Locale

@Composable
fun ConvertScreen(
    viewModel: ConvertViewModel,
    onPickImage: () -> Unit,
    onPickSvg: () -> Unit,
    onExportSvg: () -> Unit,
    onExportGcode: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val potrace by viewModel.potrace.collectAsState()
    val gcode by viewModel.gcode.collectAsState()

    Column(
        modifier = modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = VfSpacing.marginMobile),
        verticalArrangement = Arrangement.spacedBy(VfSpacing.md),
    ) {
        Spacer(Modifier.height(VfSpacing.xs))
        PipelineStepper(stage2Active = gcode.hasSvg)

        PotraceSectionCard(
            state = potrace,
            viewModel = viewModel,
            onPickImage = onPickImage,
            onExportSvg = onExportSvg,
        )

        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.width(2.dp).height(16.dp).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)))
            BridgeButton(
                text = "Feed Output SVG to Generator",
                leadingIcon = Icons.Filled.ArrowDownward,
                trailingIcon = Icons.Filled.Bolt,
                onClick = viewModel::feedSvgToGenerator,
                enabled = potrace.generatedSvgFile != null,
            )
            Box(Modifier.width(2.dp).height(16.dp).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)))
        }

        GcodeSectionCard(
            state = gcode,
            viewModel = viewModel,
            onPickSvg = onPickSvg,
            onExportGcode = onExportGcode,
        )

        Spacer(Modifier.height(VfSpacing.xl))
    }
}

// ==========================================================================
// Stage 1: IMAGE -> SVG (Potrace)
// ==========================================================================

@Composable
private fun PotraceSectionCard(
    state: PotraceUiState,
    viewModel: ConvertViewModel,
    onPickImage: () -> Unit,
    onExportSvg: () -> Unit,
) {
    val primary = MaterialTheme.colorScheme.primary
    SectionCard {
        StageHeader(
            icon = Icons.Filled.Brush,
            stageLabel = "Stage 01",
            title = "IMAGE \u2192 SVG",
            badgeText = "POTRACE",
            accentColor = primary,
        )

        // -- Input Source -----------------------------------------------
        LabeledGroup("INPUT SOURCE") {
            TonalContainer {
                SelectButton(
                    text = "Select Image",
                    icon = Icons.Filled.AddPhotoAlternate,
                    accentColor = primary,
                    onClick = onPickImage,
                )
                Column(Modifier.weight(1f)) {
                    if (state.hasImage) {
                        Text(state.imageFileName, style = VfType.bodySm, color = MaterialTheme.colorScheme.onSurface, maxLines = 1)
                        Text(state.imageDimensionsLabel, style = VfType.labelSm, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        Text("No image selected", style = VfType.bodySm, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                if (state.hasImage) {
                    IconButton(onClick = viewModel::clearImage, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Filled.Close, contentDescription = "Remove image", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }

        // -- Output SVG Path ----------------------------------------------
        LabeledGroup(
            label = "OUTPUT SVG PATH",
            trailing = {
                PillBadge(
                    text = when {
                        state.isConverting -> "Tracing\u2026"
                        state.generatedSvgFile != null -> "Traced"
                        else -> "Ready to trace"
                    },
                    color = primary,
                )
            }
        ) {
            TonalContainer {
                Icon(Icons.Filled.FolderOpen, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(20.dp))
                PathField(value = state.outputSvgPath, onValueChange = viewModel::setOutputSvgPath, modifier = Modifier.weight(1f))
                IconButton(onClick = onExportSvg, enabled = state.generatedSvgFile != null, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Filled.DriveFileMove, contentDescription = "Export SVG", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
                }
            }
        }

        // -- Trace Strategy ----------------------------------------------
        LabeledGroup("TRACE STRATEGY") {
            SegmentedControl(
                options = listOf("Mode 1 (Direct trace)", "Mode 2 (PBM intermediate)"),
                selectedIndex = if (state.traceMode == TraceMode.MODE_1_DIRECT) 0 else 1,
                onSelect = { viewModel.setTraceMode(if (it == 0) TraceMode.MODE_1_DIRECT else TraceMode.MODE_2_PBM) },
            )
        }

        // -- Invert Luminance ----------------------------------------------
        ToggleRow(
            title = "Invert Luminance",
            subtitle = "Trace lighter foreground pixels",
            checked = state.invertLuminance,
            onCheckedChange = viewModel::setInvertLuminance,
            leadingIcon = Icons.Filled.InvertColors,
            tonal = true,
        )

        // -- PBM Output Path (Mode 2 only) ----------------------------------
        if (state.isMode2) {
            LabeledGroup(
                label = "PBM OUTPUT PATH",
                trailing = { Text("Mode 2 required", style = VfType.labelSm, color = MaterialTheme.colorScheme.secondary) }
            ) {
                TonalContainer {
                    PathField(value = state.pbmOutputPath, onValueChange = viewModel::setPbmOutputPath, modifier = Modifier.weight(1f), placeholder = "Optional raster buffer path")
                    Icon(Icons.Filled.EditNote, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
                }
            }
        }

        // -- Collapsible Potrace Parameters ----------------------------------
        AccordionSection(title = "Potrace Parameters", icon = Icons.Filled.Tune, accentColor = primary) {
            LabeledSlider(
                label = "THRESHOLD",
                value = state.threshold.toFloat(),
                onValueChange = { viewModel.setThreshold(it.toDouble()) },
                valueRange = 0f..1f,
                steps = 19, // step = 0.05 over [0,1] -> 20 discrete positions, 19 steps between them
                valueLabel = String.format(Locale.ROOT, "%.2f", state.threshold),
            )
            StepperField(
                title = "TURDSIZE (Despeckle)",
                subtitle = "Suppress speckles < N px",
                valueLabel = state.turdsize.toString(),
                onDecrement = viewModel::decTurdsize,
                onIncrement = viewModel::incTurdsize,
            )
            StepperField(
                title = "ALPHAMAX (Corners)",
                subtitle = "Corner threshold value",
                valueLabel = String.format(Locale.ROOT, "%.1f", state.alphamax),
                onDecrement = viewModel::decAlphamax,
                onIncrement = viewModel::incAlphamax,
            )
            ToggleRow(
                title = "OPTICURVE",
                subtitle = "Curve optimization algorithm",
                checked = state.opticurve,
                onCheckedChange = viewModel::setOpticurve,
            )
            DoubleField(
                label = "OPTTOLERANCE \u00B7 curve error tolerance",
                value = state.opttolerance,
                onValueChange = viewModel::setOpttolerance,
            )
            LabeledDropdown(
                label = "TURN POLICY",
                options = TurnPolicyOption.entries,
                selected = state.turnPolicy,
                optionLabel = { it.label },
                onSelect = viewModel::setTurnPolicy,
            )
        }

        PrimaryActionButton(
            text = "CONVERT TO SVG",
            icon = Icons.Filled.Timeline,
            onClick = viewModel::convertToSvg,
            enabled = state.canConvert,
        )

        StatusCard(
            icon = if (state.errorMessage != null) Icons.Filled.Error else Icons.Filled.CheckCircle,
            kicker = "STATUS",
            kickerSuffix = "\u00B7 " + when {
                state.isConverting -> "Tracing"
                state.errorMessage != null -> "Error"
                state.generatedSvgFile != null -> "Traced"
                else -> "Ready for conversion"
            },
            title = state.statusTitle,
            detail = state.statusDetail,
            accentColor = if (state.errorMessage != null) MaterialTheme.colorScheme.error else primary,
            trailingBadge = { PillBadge("Potrace Engine v1.16", primary) },
        )
    }
}

// ==========================================================================
// Stage 2: SVG -> G-CODE
// ==========================================================================

@Composable
private fun GcodeSectionCard(
    state: GcodeUiState,
    viewModel: ConvertViewModel,
    onPickSvg: () -> Unit,
    onExportGcode: () -> Unit,
) {
    val secondary = MaterialTheme.colorScheme.secondary
    SectionCard {
        StageHeader(
            icon = Icons.Filled.PrecisionManufacturing,
            stageLabel = "Stage 02",
            title = "SVG \u2192 G-CODE",
            badgeText = "CNC / PLOTTER",
            accentColor = secondary,
        )

        // -- Input SVG Source ----------------------------------------------
        LabeledGroup(
            label = "INPUT SVG SOURCE",
            trailing = {
                if (state.hasSvg) {
                    Text(state.svgFileSizeLabel, style = VfType.labelSm, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        ) {
            TonalContainer {
                SelectButton(text = "Select SVG", icon = Icons.Filled.FileOpen, accentColor = secondary, onClick = onPickSvg)
                Text(
                    state.svgFileName.ifEmpty { "No SVG selected" },
                    style = VfType.bodySm,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    modifier = Modifier.weight(1f),
                )
                IconButton(onClick = viewModel::autoFillLatestSvg, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Filled.Sync, contentDescription = "Auto-fill latest", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                }
            }
        }

        // -- Output G-Code Path ----------------------------------------------
        LabeledGroup("OUTPUT G-CODE PATH") {
            TonalContainer {
                Icon(Icons.Filled.FolderOpen, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(20.dp))
                PathField(value = state.outputGcodePath, onValueChange = viewModel::setOutputGcodePath, modifier = Modifier.weight(1f))
                IconButton(onClick = onExportGcode, enabled = state.generatedGcodeFile != null, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Filled.DriveFileMove, contentDescription = "Export G-code", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
                }
            }
        }

        // -- Five expandable groups ----------------------------------------------
        AccordionSection(title = "PEN / SERVO", icon = Icons.Filled.Gesture, accentColor = secondary) {
            TwoColumnRow {
                DoubleField("PEN-UP ANGLE", state.penUpAngle, viewModel::setPenUpAngle, unit = "deg", modifier = Modifier.weight(1f))
                DoubleField("PEN-DOWN ANGLE", state.penDownAngle, viewModel::setPenDownAngle, unit = "deg", modifier = Modifier.weight(1f))
            }
            TwoColumnRow {
                IntField("START DELAY", state.startDelayMs, viewModel::setStartDelayMs, unit = "ms", modifier = Modifier.weight(1f))
                IntField("STOP DELAY", state.stopDelayMs, viewModel::setStopDelayMs, unit = "ms", modifier = Modifier.weight(1f))
            }
            ToggleRow(title = "REGISTER PEN (M3/M5)", checked = state.registerPen, onCheckedChange = viewModel::setRegisterPen)
        }

        AccordionSection(title = "MOTION CONFIG", icon = Icons.Filled.Speed, accentColor = secondary) {
            TwoColumnRow {
                DoubleField("XY FEEDRATE", state.xyFeedrate, viewModel::setXyFeedrate, modifier = Modifier.weight(1f))
                DoubleField("Z FEEDRATE", state.zFeedrate, viewModel::setZFeedrate, modifier = Modifier.weight(1f))
            }
            TwoColumnRow {
                DoubleField("Z HEIGHT", state.zHeight, viewModel::setZHeight, modifier = Modifier.weight(1f))
                DoubleField("FINISHED HEIGHT", state.finishedHeight, viewModel::setFinishedHeight, modifier = Modifier.weight(1f))
            }
            TwoColumnRow {
                DoubleField("X HOME", state.xHome, viewModel::setXHome, modifier = Modifier.weight(1f))
                DoubleField("Y HOME", state.yHome, viewModel::setYHome, modifier = Modifier.weight(1f))
            }
        }

        AccordionSection(title = "JOB OPTIONS", icon = Icons.Filled.Layers, accentColor = secondary) {
            IntField("COPIES", state.numCopies, viewModel::setNumCopies)
            ToggleRow(title = "CONTINUOUS PLOTTING", subtitle = "Loop job without pause", checked = state.continuousPlotting, onCheckedChange = viewModel::setContinuousPlotting)
            ToggleRow(title = "PAUSE ON LAYER", subtitle = "Add M00 between layers", checked = state.pauseOnLayerChange, onCheckedChange = viewModel::setPauseOnLayerChange)
            TextFieldRow(label = "COMPATIBILITY TAB (--tab)", value = state.compatibilityTab, onValueChange = viewModel::setCompatibilityTab, placeholder = "Default: None")
        }

        AccordionSection(title = "GEOMETRY RESOLUTION", icon = Icons.Filled.Straighten, accentColor = secondary) {
            TwoColumnRow {
                DoubleField("FLATNESS (mm)", state.flatness, viewModel::setFlatness, modifier = Modifier.weight(1f))
                DoubleField("DPI RESOLUTION", state.dpi, viewModel::setDpi, modifier = Modifier.weight(1f))
            }
        }

        AccordionSection(title = "POST-PROCESSING", icon = Icons.Filled.AutoFixHigh, accentColor = secondary) {
            TwoColumnRow {
                DoubleField("MIN CHANGE (mm)", state.minChange, viewModel::setMinChange, modifier = Modifier.weight(1f))
                IntField("SKIP FACTOR", state.skipFactor, viewModel::setSkipFactor, modifier = Modifier.weight(1f))
            }
            TwoColumnRow {
                DoubleField("NEW MIN (mm)", state.newMin, viewModel::setNewMin, modifier = Modifier.weight(1f))
                DoubleField("NEW MAX (mm)", state.newMax, viewModel::setNewMax, modifier = Modifier.weight(1f))
            }
            ToggleRow(title = "NORMALIZE OUTPUT BOUNDS", checked = state.normalizeOutputBounds, onCheckedChange = viewModel::setNormalizeOutputBounds)
            ToggleRow(title = "REDUCE / THIN POINTS", checked = state.reduceThinPoints, onCheckedChange = viewModel::setReduceThinPoints)
        }

        PrimaryActionButton(
            text = "CONVERT TO G-CODE",
            icon = Icons.Filled.Terminal,
            onClick = viewModel::convertToGcode,
            enabled = state.canConvert,
        )

        StatusCard(
            icon = if (state.errorMessage != null) Icons.Filled.Error else Icons.Filled.Info,
            kicker = "GENERATOR",
            kickerSuffix = "\u00B7 " + when {
                state.isGenerating -> "Generating"
                state.errorMessage != null -> "Error"
                state.generatedGcodeFile != null -> "Post-processor complete"
                else -> "Post-processor armed"
            },
            title = state.statusTitle,
            detail = state.statusDetail,
            accentColor = if (state.errorMessage != null) MaterialTheme.colorScheme.error else secondary,
        )
    }
}

// ==========================================================================
// Small local helpers shared by both stages
// ==========================================================================

@Composable
private fun LabeledGroup(
    label: String,
    modifier: Modifier = Modifier,
    trailing: (@Composable () -> Unit)? = null,
    content: @Composable () -> Unit,
) {
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(label, style = VfType.labelMd, color = MaterialTheme.colorScheme.onSurfaceVariant)
            trailing?.invoke()
        }
        content()
    }
}

/**
 * Lays out exactly two fields side by side, each taking half the width --
 * matching the reference's `grid grid-cols-2` groups (MOTION, GEOMETRY,
 * POST-PROCESSING). Callers give each child `Modifier.weight(1f)` (the
 * `RowScope` receiver makes that available at the call site).
 */
@Composable
private fun TwoColumnRow(content: @Composable RowScope.() -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(VfSpacing.sm),
        content = content,
    )
}

@Composable
private fun SelectButton(text: String, icon: androidx.compose.ui.graphics.vector.ImageVector, accentColor: androidx.compose.ui.graphics.Color, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .clip(MaterialTheme.shapes.medium)
            .background(MaterialTheme.colorScheme.surfaceContainerHighest)
            .clickable(onClick = onClick)
            .padding(horizontal = VfSpacing.md, vertical = VfSpacing.xs),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(VfSpacing.xs),
    ) {
        Icon(icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(18.dp))
        Text(text, style = VfType.labelLg, color = MaterialTheme.colorScheme.onSurface, textAlign = TextAlign.Center)
    }
}
