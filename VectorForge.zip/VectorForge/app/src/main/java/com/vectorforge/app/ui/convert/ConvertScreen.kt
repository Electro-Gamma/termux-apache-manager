package com.vectorforge.app.ui.convert

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DriveFileMove
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.InvertColors
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material.icons.filled.PrecisionManufacturing
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Straighten
import androidx.compose.material.icons.filled.Gesture
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.vectorforge.app.data.ConvertViewModel
import com.vectorforge.app.data.GcodeDefaults
import com.vectorforge.app.data.GcodeUiState
import com.vectorforge.app.data.PotraceUiState
import com.vectorforge.app.data.TraceMode
import com.vectorforge.app.data.TurnPolicyOption
import com.vectorforge.app.data.ViewerTarget
import com.vectorforge.app.ui.convert.components.AccordionSection
import com.vectorforge.app.ui.convert.components.DoubleField
import com.vectorforge.app.ui.convert.components.GenerateButtonsRow
import com.vectorforge.app.ui.convert.components.LabeledDropdown
import com.vectorforge.app.ui.convert.components.LabeledSlider
import com.vectorforge.app.ui.convert.components.OptionalDoubleField
import com.vectorforge.app.ui.convert.components.OptionalIntField
import com.vectorforge.app.ui.convert.components.OptionalToggleRow
import com.vectorforge.app.ui.convert.components.PathField
import com.vectorforge.app.ui.convert.components.PillBadge
import com.vectorforge.app.ui.convert.components.PrimaryActionButton
import com.vectorforge.app.ui.convert.components.SectionCard
import com.vectorforge.app.ui.convert.components.SegmentedControl
import com.vectorforge.app.ui.convert.components.StageHeader
import com.vectorforge.app.ui.convert.components.StatusCard
import com.vectorforge.app.ui.convert.components.StepperField
import com.vectorforge.app.ui.convert.components.TextFieldRow
import com.vectorforge.app.ui.convert.components.ToggleRow
import com.vectorforge.app.ui.convert.components.TonalContainer
import com.vectorforge.app.ui.theme.VfSpacing
import com.vectorforge.app.ui.theme.VfType
import java.util.Locale

@Composable
fun ConvertScreen(
    viewModel: ConvertViewModel,
    onPickImage: () -> Unit,
    onPickSvg: () -> Unit,
    onExportSvg: () -> Unit,
    onExportGcode: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val potrace by viewModel.potrace.collectAsState()
    val gcode by viewModel.gcode.collectAsState()

    // The G-code buttons work when an SVG is ready, or -- with "Auto Convert Previous Stage" on -- when one can be
    // had from Image -> SVG (already traced, or an image to trace). Never while a conversion is running.
    val canGenerate = !gcode.isGenerating && !potrace.isConverting &&
        (gcode.hasSvg || (gcode.autoConvertPreviousStage && (potrace.generatedSvgFile != null || potrace.hasImage)))

    // Responsive layout: the two stage panels use the whole width of the screen (slim margins, no centred column),
    // and on wide screens (tablet, foldable, landscape) they sit side by side instead of leaving the sides empty.
    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val layout = ConvertLayout.forWidth(maxWidth)

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = layout.edgeMargin),
            verticalArrangement = Arrangement.spacedBy(VfSpacing.md),
        ) {
            Spacer(Modifier.height(VfSpacing.xs))

            // One fixed structure in every width class (only the placement changes), so rotating the device or
            // unfolding it never rebuilds the cards and never loses which dropdowns are open.
            StageColumns(
                columns = if (layout.twoColumns) 2 else 1,
                gap = layout.gap,
                modifier = Modifier.fillMaxWidth(),
            ) {
                PotraceSectionCard(
                    state = potrace,
                    viewModel = viewModel,
                    onPickImage = onPickImage,
                    onExportSvg = onExportSvg,
                    contentPadding = layout.cardPadding,
                )

                GcodeSectionCard(
                    state = gcode,
                    viewModel = viewModel,
                    onPickSvg = onPickSvg,
                    onExportGcode = onExportGcode,
                    canGenerate = canGenerate,
                    busy = potrace.isConverting || gcode.isGenerating,
                    canFeedSvg = potrace.generatedSvgFile != null,
                    contentPadding = layout.cardPadding,
                )
            }

            Spacer(Modifier.height(VfSpacing.xl))
        }
    }

    // Failures are reported in a dialog (the permanent status cards are gone from this screen). One at a time:
    // a failed Image -> SVG run (also when "Auto Convert Previous Stage" started it) comes first.
    val potraceError = potrace.errorDialog
    val gcodeError = gcode.errorDialog
    if (potraceError != null) {
        ErrorDialog("IMAGE \u2192 SVG failed", potraceError, viewModel::dismissPotraceError)
    } else if (gcodeError != null) {
        ErrorDialog("G-CODE generation failed", gcodeError, viewModel::dismissGcodeError)
    }
}

// ==========================================================================
// Stage 1: IMAGE -> SVG (Potrace)
// ==========================================================================

@Composable
private fun PotraceSectionCard(
    state: PotraceUiState,
    viewModel: ConvertViewModel,
    onPickImage: () -> Unit,
    onExportSvg: () -> Unit,
    modifier: Modifier = Modifier,
    contentPadding: Dp = VfSpacing.lg,
) {
    val primary = MaterialTheme.colorScheme.primary
    SectionCard(modifier = modifier, contentPadding = contentPadding) {
        StageHeader(
            icon = Icons.Filled.Brush,
            stageLabel = "Stage 01",
            title = "IMAGE \u2192 SVG",
            badgeText = "POTRACE",
            accentColor = primary,
        )

        // -- Input Source -----------------------------------------------
        LabeledGroup("INPUT SOURCE") {
            TonalContainer {
                SelectButton(
                    text = "Select Image",
                    icon = Icons.Filled.AddPhotoAlternate,
                    accentColor = primary,
                    onClick = onPickImage,
                )
                Column(Modifier.weight(1f)) {
                    if (state.hasImage) {
                        Text(state.imageFileName, style = VfType.bodySm, color = MaterialTheme.colorScheme.onSurface, maxLines = 1)
                        Text(state.imageDimensionsLabel, style = VfType.labelSm, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        Text("No image selected", style = VfType.bodySm, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                if (state.hasImage) {
                    IconButton(onClick = viewModel::clearImage, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Filled.Close, contentDescription = "Remove image", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }

        // -- Trace Strategy ----------------------------------------------
        LabeledGroup("TRACE STRATEGY") {
            SegmentedControl(
                options = listOf("Mode 1 (Direct trace)", "Mode 2 (PBM intermediate)"),
                selectedIndex = if (state.traceMode == TraceMode.MODE_1_DIRECT) 0 else 1,
                onSelect = { viewModel.setTraceMode(if (it == 0) TraceMode.MODE_1_DIRECT else TraceMode.MODE_2_PBM) },
            )
        }

        // -- PBM Output Path (Mode 2 only) ----------------------------------
        if (state.isMode2) {
            LabeledGroup(
                label = "PBM OUTPUT PATH",
                trailing = { Text("Mode 2 required", style = VfType.labelSm, color = MaterialTheme.colorScheme.secondary) }
            ) {
                TonalContainer {
                    PathField(value = state.pbmOutputPath, onValueChange = viewModel::setPbmOutputPath, modifier = Modifier.weight(1f), placeholder = "Optional raster buffer path")
                    Icon(Icons.Filled.EditNote, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
                }
            }
        }

        // -- Collapsible Potrace Parameters ----------------------------------
        AccordionSection(title = "Potrace Parameters", icon = Icons.Filled.Tune, accentColor = primary) {
            // -- Status (moved here from the main Image -> SVG stage; the same card, shown when this dropdown is open) --
            StatusCard(
                icon = if (state.errorMessage != null) Icons.Filled.Error else Icons.Filled.CheckCircle,
                kicker = "STATUS",
                kickerSuffix = "\u00B7 " + when {
                    state.isConverting -> "Tracing"
                    state.errorMessage != null -> "Error"
                    state.generatedSvgFile != null -> "Traced"
                    else -> "Ready for conversion"
                },
                title = state.statusTitle,
                detail = state.statusDetail,
                accentColor = if (state.errorMessage != null) MaterialTheme.colorScheme.error else primary,
                trailingBadge = { PillBadge("Potrace Engine v1.16", primary) },
            )

            // -- Output SVG Path (moved here from the main Image -> SVG settings; UI location only) --
            LabeledGroup(
                label = "OUTPUT SVG PATH",
                trailing = {
                    PillBadge(
                        text = when {
                            state.isConverting -> "Tracing\u2026"
                            state.generatedSvgFile != null -> "Traced"
                            else -> "Ready to trace"
                        },
                        color = primary,
                    )
                }
            ) {
                TonalContainer {
                    Icon(Icons.Filled.FolderOpen, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(20.dp))
                    PathField(value = state.outputSvgPath, onValueChange = viewModel::setOutputSvgPath, modifier = Modifier.weight(1f))
                    IconButton(onClick = onExportSvg, enabled = state.generatedSvgFile != null, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Filled.DriveFileMove, contentDescription = "Export SVG", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
                    }
                }
            }

            LabeledSlider(
                label = "THRESHOLD",
                value = state.threshold.toFloat(),
                onValueChange = { viewModel.setThreshold(it.toDouble()) },
                valueRange = 0f..1f,
                steps = 19, // step = 0.05 over [0,1] -> 20 discrete positions, 19 steps between them
                valueLabel = String.format(Locale.ROOT, "%.2f", state.threshold),
            )
            // Moved here from the main Image -> SVG settings (UI location only;
            // behaviour is unchanged -- still bound to setInvertLuminance).
            ToggleRow(
                title = "Invert Luminance",
                subtitle = "Trace lighter foreground pixels",
                checked = state.invertLuminance,
                onCheckedChange = viewModel::setInvertLuminance,
                leadingIcon = Icons.Filled.InvertColors,
                tonal = true,
            )
            StepperField(
                title = "TURDSIZE (Despeckle)",
                subtitle = "Suppress speckles < N px",
                valueLabel = state.turdsize.toString(),
                onDecrement = viewModel::decTurdsize,
                onIncrement = viewModel::incTurdsize,
            )
            StepperField(
                title = "ALPHAMAX (Corners)",
                subtitle = "Corner threshold value",
                valueLabel = String.format(Locale.ROOT, "%.1f", state.alphamax),
                onDecrement = viewModel::decAlphamax,
                onIncrement = viewModel::incAlphamax,
            )
            ToggleRow(
                title = "OPTICURVE",
                subtitle = "Curve optimization algorithm",
                checked = state.opticurve,
                onCheckedChange = viewModel::setOpticurve,
            )
            DoubleField(
                label = "OPTTOLERANCE \u00B7 curve error tolerance",
                value = state.opttolerance,
                onValueChange = viewModel::setOpttolerance,
            )
            LabeledDropdown(
                label = "TURN POLICY",
                options = TurnPolicyOption.entries,
                selected = state.turnPolicy,
                optionLabel = { it.label },
                onSelect = viewModel::setTurnPolicy,
            )
        }

        PrimaryActionButton(
            text = "CONVERT TO SVG",
            icon = Icons.Filled.Timeline,
            onClick = viewModel::convertToSvg,
            enabled = state.canConvert,
        )
    }
}

// ==========================================================================
// Stage 2: SVG -> G-CODE
// ==========================================================================

@Composable
private fun GcodeSectionCard(
    state: GcodeUiState,
    viewModel: ConvertViewModel,
    onPickSvg: () -> Unit,
    onExportGcode: () -> Unit,
    canGenerate: Boolean,
    busy: Boolean,
    canFeedSvg: Boolean,
    modifier: Modifier = Modifier,
    contentPadding: Dp = VfSpacing.lg,
) {
    val secondary = MaterialTheme.colorScheme.secondary
    SectionCard(modifier = modifier, contentPadding = contentPadding) {
        StageHeader(
            icon = Icons.Filled.PrecisionManufacturing,
            stageLabel = "Stage 02",
            title = "SVG \u2192 G-CODE",
            badgeText = "CNC / PLOTTER",
            accentColor = secondary,
        )

        // -- Input SVG Source ----------------------------------------------
        LabeledGroup(
            label = "INPUT SVG SOURCE",
            trailing = {
                if (state.hasSvg) {
                    Text(state.svgFileSizeLabel, style = VfType.labelSm, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        ) {
            TonalContainer {
                SelectButton(text = "Select SVG", icon = Icons.Filled.FileOpen, accentColor = secondary, onClick = onPickSvg)
                Text(
                    state.svgFileName.ifEmpty { "No SVG selected" },
                    style = VfType.bodySm,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    modifier = Modifier.weight(1f),
                )
                IconButton(onClick = viewModel::autoFillLatestSvg, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Filled.Sync, contentDescription = "Auto-fill latest", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                }
            }
        }

        // -- Five expandable groups ----------------------------------------------
        // Prefilled + always passed (working desktop CLI run): pen-up/down angle,
        // XY feedrate, new min/max, reduce OFF (--no-reduce).
        // Every other input starts EMPTY, showing the engine default only as a
        // faint placeholder, and is NOT passed to the generator until you type
        // something in it (see ConvertViewModel.convertToGcode).
        // Single parent section, collapsed by default: tapping its arrow reveals all
        // five groups below exactly as they were; tapping again hides them all.
        AccordionSection(title = "SVG2GCODE Parameters", icon = Icons.Filled.Tune, accentColor = secondary) {
            // -- Status (moved here from the main SVG -> G-code stage; the same card, shown when this dropdown is open) --
            StatusCard(
                icon = if (state.errorMessage != null) Icons.Filled.Error else Icons.Filled.Info,
                kicker = "GENERATOR",
                kickerSuffix = "\u00B7 " + when {
                    state.isGenerating -> "Generating"
                    state.errorMessage != null -> "Error"
                    state.generatedGcodeFile != null -> "Post-processor complete"
                    else -> "Post-processor armed"
                },
                title = state.statusTitle,
                detail = state.statusDetail,
                accentColor = if (state.errorMessage != null) MaterialTheme.colorScheme.error else secondary,
            )

            // -- Feed Output SVG to Generator (moved here from between the two stages; same action) --
            FeedSvgButton(enabled = canFeedSvg, onClick = viewModel::feedSvgToGenerator)

            // -- Auto Convert Previous Stage --
            ToggleRow(
                title = "Auto Convert Previous Stage",
                subtitle = "No SVG yet? Run IMAGE \u2192 SVG first, then generate",
                checked = state.autoConvertPreviousStage,
                onCheckedChange = viewModel::setAutoConvertPreviousStage,
            )

            // -- Output G-Code Path (moved here from the main SVG -> G-code settings; UI location only) --
            LabeledGroup("OUTPUT G-CODE PATH") {
                TonalContainer {
                    Icon(Icons.Filled.FolderOpen, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(20.dp))
                    PathField(value = state.outputGcodePath, onValueChange = viewModel::setOutputGcodePath, modifier = Modifier.weight(1f))
                    IconButton(onClick = onExportGcode, enabled = state.generatedGcodeFile != null, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Filled.DriveFileMove, contentDescription = "Export G-code", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
                    }
                }
            }

            AccordionSection(title = "PEN / SERVO", icon = Icons.Filled.Gesture, accentColor = secondary) {
                TwoColumnRow {
                    DoubleField("PEN-UP ANGLE", state.penUpAngle, viewModel::setPenUpAngle, unit = "deg", modifier = Modifier.weight(1f))
                    DoubleField("PEN-DOWN ANGLE", state.penDownAngle, viewModel::setPenDownAngle, unit = "deg", modifier = Modifier.weight(1f))
                }
                TwoColumnRow {
                    OptionalIntField("START DELAY", state.startDelayMs, GcodeDefaults.startDelayMs, viewModel::setStartDelayMs, unit = "ms", modifier = Modifier.weight(1f))
                    OptionalIntField("STOP DELAY", state.stopDelayMs, GcodeDefaults.stopDelayMs, viewModel::setStopDelayMs, unit = "ms", modifier = Modifier.weight(1f))
                }
                OptionalToggleRow(title = "REGISTER PEN (M3/M5)", value = state.registerPen, default = GcodeDefaults.registerPen, onValueChange = viewModel::setRegisterPen)
            }

            AccordionSection(title = "MOTION CONFIG", icon = Icons.Filled.Speed, accentColor = secondary) {
                TwoColumnRow {
                    DoubleField("XY FEEDRATE", state.xyFeedrate, viewModel::setXyFeedrate, modifier = Modifier.weight(1f))
                    OptionalDoubleField("Z FEEDRATE", state.zFeedrate, GcodeDefaults.zFeedrate, viewModel::setZFeedrate, modifier = Modifier.weight(1f))
                }
                TwoColumnRow {
                    OptionalDoubleField("Z HEIGHT", state.zHeight, GcodeDefaults.zHeight, viewModel::setZHeight, modifier = Modifier.weight(1f))
                    OptionalDoubleField("FINISHED HEIGHT", state.finishedHeight, GcodeDefaults.finishedHeight, viewModel::setFinishedHeight, modifier = Modifier.weight(1f))
                }
                TwoColumnRow {
                    OptionalDoubleField("X HOME", state.xHome, GcodeDefaults.xHome, viewModel::setXHome, modifier = Modifier.weight(1f))
                    OptionalDoubleField("Y HOME", state.yHome, GcodeDefaults.yHome, viewModel::setYHome, modifier = Modifier.weight(1f))
                }
            }

            AccordionSection(title = "JOB OPTIONS", icon = Icons.Filled.Layers, accentColor = secondary) {
                OptionalIntField("COPIES", state.numCopies, GcodeDefaults.numCopies, viewModel::setNumCopies)
                OptionalToggleRow(title = "CONTINUOUS PLOTTING", subtitle = "Loop job without pause", value = state.continuousPlotting, default = GcodeDefaults.continuousPlotting, onValueChange = viewModel::setContinuousPlotting)
                OptionalToggleRow(title = "PAUSE ON LAYER", subtitle = "Add M00 between layers", value = state.pauseOnLayerChange, default = GcodeDefaults.pauseOnLayerChange, onValueChange = viewModel::setPauseOnLayerChange)
                TextFieldRow(label = "COMPATIBILITY TAB (--tab)", value = state.compatibilityTab, onValueChange = viewModel::setCompatibilityTab, placeholder = "Default: None")
            }

            AccordionSection(title = "GEOMETRY RESOLUTION", icon = Icons.Filled.Straighten, accentColor = secondary) {
                TwoColumnRow {
                    OptionalDoubleField("FLATNESS (mm)", state.flatness, GcodeDefaults.flatness, viewModel::setFlatness, modifier = Modifier.weight(1f))
                    OptionalDoubleField("DPI RESOLUTION", state.dpi, GcodeDefaults.dpi, viewModel::setDpi, modifier = Modifier.weight(1f))
                }
            }

            AccordionSection(title = "POST-PROCESSING", icon = Icons.Filled.AutoFixHigh, accentColor = secondary) {
                TwoColumnRow {
                    OptionalDoubleField("MIN CHANGE (mm)", state.minChange, GcodeDefaults.minChange, viewModel::setMinChange, modifier = Modifier.weight(1f))
                    OptionalIntField("SKIP FACTOR", state.skipFactor, GcodeDefaults.skipFactor, viewModel::setSkipFactor, modifier = Modifier.weight(1f))
                }
                TwoColumnRow {
                    DoubleField("NEW MIN (mm)", state.newMin, viewModel::setNewMin, modifier = Modifier.weight(1f))
                    DoubleField("NEW MAX (mm)", state.newMax, viewModel::setNewMax, modifier = Modifier.weight(1f))
                }
                OptionalToggleRow(title = "NORMALIZE OUTPUT BOUNDS", value = state.normalizeOutputBounds, default = GcodeDefaults.normalizeOutputBounds, onValueChange = viewModel::setNormalizeOutputBounds)
                ToggleRow(title = "REDUCE / THIN POINTS", subtitle = "Off = --no-reduce", checked = state.reduceThinPoints, onCheckedChange = viewModel::setReduceThinPoints)

                // G-code transform (GcodeTransform), one control per argument, like every other parameter here.
                // Blank / off = not passed; nothing set = the transform is not applied. Order: rotate -> keep -> offset.
                TwoColumnRow {
                    OptionalDoubleField("ROTATE LEFT (deg)", state.transformRotateLeft, 0.0, viewModel::setTransformRotateLeft, modifier = Modifier.weight(1f))
                    OptionalDoubleField("ROTATE RIGHT (deg)", state.transformRotateRight, 0.0, viewModel::setTransformRotateRight, modifier = Modifier.weight(1f))
                }
                TwoColumnRow {
                    OptionalDoubleField("OFFSET X (mm)", state.transformOffsetX, 0.0, viewModel::setTransformOffsetX, modifier = Modifier.weight(1f))
                    OptionalDoubleField("OFFSET Y (mm)", state.transformOffsetY, 0.0, viewModel::setTransformOffsetY, modifier = Modifier.weight(1f))
                }
                ToggleRow(title = "KEEP POSITIVE", subtitle = "X\u22650 and Y\u22650 (--keep-positive)", checked = state.keepPositive, onCheckedChange = viewModel::setKeepPositive)
                ToggleRow(title = "KEEP NEGATIVE", subtitle = "X\u22640 and Y\u22640 (--keep-negative)", checked = state.keepNegative, onCheckedChange = viewModel::setKeepNegative)
                ToggleRow(title = "KEEP EAST", subtitle = "X\u22650, right of the Y axis (--keep-east)", checked = state.keepEast, onCheckedChange = viewModel::setKeepEast)
                ToggleRow(title = "KEEP WEST", subtitle = "X\u22640, left of the Y axis (--keep-west)", checked = state.keepWest, onCheckedChange = viewModel::setKeepWest)
                ToggleRow(title = "KEEP NORTH", subtitle = "Y\u22650, above the X axis (--keep-north)", checked = state.keepNorth, onCheckedChange = viewModel::setKeepNorth)
                ToggleRow(title = "KEEP SOUTH", subtitle = "Y\u22640, below the X axis (--keep-south)", checked = state.keepSouth, onCheckedChange = viewModel::setKeepSouth)
                ToggleRow(title = "NO FIXED HOME", subtitle = "Also transform the start/end moves to X0 Y0 (--no-fixed-home)", checked = state.transformNoFixedHome, onCheckedChange = viewModel::setTransformNoFixedHome)
                TwoColumnRow {
                    OptionalDoubleField("MAX X (warn)", state.transformMaxX, 0.0, viewModel::setTransformMaxX, modifier = Modifier.weight(1f))
                    OptionalDoubleField("MAX Y (warn)", state.transformMaxY, 0.0, viewModel::setTransformMaxY, modifier = Modifier.weight(1f))
                }
                OptionalIntField("PRECISION (0\u201310)", state.transformPrecision, GcodeDefaults.transformPrecision, viewModel::setTransformPrecision)

                // FINAL NORMALIZE: the header's NEW MIN / NEW MAX again, applied last, after the transform above
                // (a rotation of e.g. 30 deg pushes the toolpath out of the 0..40 range). Blank = not applied.
                TwoColumnRow {
                    OptionalDoubleField("NEW MIN (mm) \u00B7 FINAL", state.finalNewMin, state.newMin, viewModel::setFinalNewMin, modifier = Modifier.weight(1f))
                    OptionalDoubleField("NEW MAX (mm) \u00B7 FINAL", state.finalNewMax, state.newMax, viewModel::setFinalNewMax, modifier = Modifier.weight(1f))
                }
            }
        }

        // Three compact actions on one line. The generation is the same for all of them; the argument only
        // decides where the finished file goes afterwards: nowhere ("G-code"), Viewer 1, or Viewer 2 (split view).
        GenerateButtonsRow(
            onGcode = { viewModel.convertToGcode(ViewerTarget.NONE) },
            onViewer1 = { viewModel.convertToGcode(ViewerTarget.VIEWER_1) },
            onViewer2 = { viewModel.convertToGcode(ViewerTarget.VIEWER_2_SPLIT) },
            enabled = canGenerate,
            busy = busy,
        )
    }
}

// ==========================================================================
// Responsive layout
// ==========================================================================

/**
 * Spacing and column count for the Convert screen, chosen from the width actually available to it
 * (the same breakpoints Material uses for window size classes: 600dp and 840dp).
 *
 *  - under 600dp (phones):        slim 8dp margins and 14dp card padding, so fields get as much width as possible
 *  - 600dp up to 840dp (tablets): 16dp margins, full-width panels stacked
 *  - 840dp and up (wide / landscape / foldable): the two stage panels side by side, each taking half the width
 *
 * There is deliberately no maximum width: the panels always run from the left edge to the right edge.
 */
private class ConvertLayout(
    val edgeMargin: Dp,
    val gap: Dp,
    val cardPadding: Dp,
    val twoColumns: Boolean,
) {
    companion object {
        fun forWidth(width: Dp): ConvertLayout = when {
            width >= 840.dp -> ConvertLayout(edgeMargin = 20.dp, gap = 16.dp, cardPadding = VfSpacing.lg, twoColumns = true)
            width >= 600.dp -> ConvertLayout(edgeMargin = 16.dp, gap = VfSpacing.md, cardPadding = VfSpacing.lg, twoColumns = false)
            else -> ConvertLayout(edgeMargin = 8.dp, gap = VfSpacing.md, cardPadding = VfSpacing.md, twoColumns = false)
        }
    }
}

/**
 * Places its children in [columns] equal-width columns, left to right then top to bottom, [gap] apart, each child
 * keeping its own height (so the two stage panels line up at the top and are as tall as their content).
 * With one column it is a plain vertical stack, i.e. exactly what the screen always looked like.
 * It must sit where the height is unbounded (inside the screen's vertical scroll), which is where it is used.
 */
@Composable
private fun StageColumns(
    columns: Int,
    gap: Dp,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    Layout(content = content, modifier = modifier) { measurables, constraints ->
        val cols = columns.coerceAtLeast(1)
        val gapPx = gap.roundToPx()
        val width = constraints.maxWidth
        val colWidth = ((width - gapPx * (cols - 1)) / cols).coerceAtLeast(0)
        val childConstraints = Constraints(
            minWidth = colWidth,
            maxWidth = colWidth,
            minHeight = 0,
            maxHeight = constraints.maxHeight,
        )
        val rows = measurables.map { it.measure(childConstraints) }.chunked(cols)
        val rowHeights = rows.map { row -> row.maxOf { it.height } }
        val totalHeight = rowHeights.sum() + gapPx * (rows.size - 1).coerceAtLeast(0)
        layout(width, totalHeight) {
            var y = 0
            rows.forEachIndexed { rowIndex, row ->
                var x = 0
                row.forEach { placeable ->
                    placeable.placeRelative(x, y)
                    x += colWidth + gapPx
                }
                y += rowHeights[rowIndex] + gapPx
            }
        }
    }
}

// ==========================================================================
// Small local helpers shared by both stages
// ==========================================================================

@Composable
private fun LabeledGroup(
    label: String,
    modifier: Modifier = Modifier,
    trailing: (@Composable () -> Unit)? = null,
    content: @Composable () -> Unit,
) {
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(label, style = VfType.labelMd, color = MaterialTheme.colorScheme.onSurfaceVariant)
            trailing?.invoke()
        }
        content()
    }
}

/**
 * Lays out exactly two fields side by side, each taking half the width --
 * matching the reference's `grid grid-cols-2` groups (MOTION, GEOMETRY,
 * POST-PROCESSING). Callers give each child `Modifier.weight(1f)` (the
 * `RowScope` receiver makes that available at the call site).
 */
@Composable
private fun TwoColumnRow(content: @Composable RowScope.() -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(VfSpacing.sm),
        content = content,
    )
}

/** Modal error report for a failed run, replacing the permanent status cards. */
@Composable
private fun ErrorDialog(title: String, message: String, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(message) },
        confirmButton = { TextButton(onClick = onDismiss) { Text("OK") } },
    )
}

/** "Feed Output SVG to Generator": a compact button now that it lives inside the SVG2GCODE Parameters dropdown. */
@Composable
private fun FeedSvgButton(enabled: Boolean, onClick: () -> Unit) {
    FilledTonalButton(
        onClick = onClick,
        enabled = enabled,
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
    ) {
        Icon(Icons.Filled.ArrowDownward, contentDescription = null, modifier = Modifier.size(16.dp))
        Text("Feed output SVG to generator", style = VfType.labelMd, modifier = Modifier.padding(start = 6.dp))
    }
}

@Composable
private fun SelectButton(text: String, icon: androidx.compose.ui.graphics.vector.ImageVector, accentColor: androidx.compose.ui.graphics.Color, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .clip(MaterialTheme.shapes.medium)
            .background(MaterialTheme.colorScheme.surfaceContainerHighest)
            .clickable(onClick = onClick)
            .padding(horizontal = VfSpacing.md, vertical = VfSpacing.xs),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(VfSpacing.xs),
    ) {
        Icon(icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(18.dp))
        Text(text, style = VfType.labelLg, color = MaterialTheme.colorScheme.onSurface, textAlign = TextAlign.Center)
    }
}
