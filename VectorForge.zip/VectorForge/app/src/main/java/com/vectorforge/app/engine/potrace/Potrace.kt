/*
 * Potrace.kt
 * =============================================================================
 * A single-file Kotlin port of the core Potrace algorithm.
 *
 * Potrace ("polygon trace") turns a black-and-white bitmap into a smooth
 * vector outline (a set of closed Bezier-curve paths). This file is a
 * line-by-line transcription of the core algorithm in potrace-1.16 by Peter
 * Selinger (http://potrace.sourceforge.net), released under the GNU GPL v2
 * (see http://potrace.sourceforge.net/ for the original C sources and full
 * license text). BECAUSE THE ORIGINAL IS GPL-LICENSED, this derivative port
 * is subject to the same copyleft terms: if you distribute a program built
 * from this file (source or binary), GPL v2 requires you to make the
 * complete corresponding source available under the same license. Purely
 * personal/internal use (e.g. running this in your own Colab notebook)
 * carries no distribution obligation. If you need a permissively-licensed
 * engine for a closed-source product, Potrace also offers a commercial
 * license from its author -- this port does not change that.
 *
 * ----------------------------------------------------------------------------
 * ALGORITHM OVERVIEW (the "deep learning" part -- what potrace actually does)
 * ----------------------------------------------------------------------------
 * Tracing a bitmap happens in two big phases:
 *
 *  PHASE A -- DECOMPOSE (bitmap -> raw pixel-corner polygons)
 *    1. Scan the bitmap top-to-bottom, left-to-right for the next
 *       unprocessed black pixel (findNext).
 *    2. Walk the boundary of the connected region containing that pixel,
 *       one grid-corner step at a time, using a simple 4-neighborhood rule
 *       to decide which way to turn at ambiguous (checkerboard) corners --
 *       this is the "turn policy" (findPath).
 *    3. XOR the traced region's interior out of a scratch copy of the
 *       bitmap (xorPath). This is the key trick that makes the whole
 *       algorithm simple: XOR-filling a *positive* (black) region's
 *       interior automatically *reveals* any holes inside it as new
 *       "regions" to be found on subsequent scans -- so holes, and holes
 *       within holes, fall out of the same simple scan+trace+XOR loop
 *       without any special-case code.
 *    4. Tiny regions (area <= turdsize) are discarded as speckle noise.
 *    5. The surviving regions are organized into a containment tree
 *       (buildTree) so renderers know which "negative" (hole) paths
 *       belong inside which "positive" paths.
 *
 *  PHASE B -- TRACE (raw polygon -> smooth Bezier curve)
 *    For each traced region, independently:
 *    1. calcLon: for every point on the boundary, find the furthest other
 *       point that is still "in a straight line" from it (allowing for
 *       pixel-grid staircase noise). This uses a clever incremental
 *       "constraint cone" argument to run in time roughly linear in the
 *       boundary length, rather than the naive quadratic scan.
 *    2. bestPolygon: choose a minimal-penalty subset of those straight
 *       runs that together form a closed polygon visiting every boundary
 *       point's neighborhood -- a shortest-path search (dynamic
 *       programming) over the polygon's vertices.
 *    3. adjustVertices: nudge each polygon vertex to the point that best
 *       fits the two adjacent straight-line segments simultaneously
 *       (minimizing a sum-of-squares / quadratic-form error), giving
 *       sub-pixel accuracy instead of raw pixel-grid vertices.
 *    4. smooth: decide, at each vertex, whether the turn is sharp enough
 *       to render as a hard CORNER or gentle enough to render as a round
 *       CURVETO (cubic Bezier), based on the angle between adjacent
 *       segments (the `alphamax` parameter controls this threshold).
 *    5. opticurve (optional): greedily merge consecutive Bezier segments
 *       into a single longer Bezier wherever doing so stays within
 *       `opttolerance` of the original curve -- this is what gives
 *       potrace's output its characteristically small number of anchor
 *       points compared to naively tracing every pixel corner.
 *
 * This file keeps that same two-phase structure and the same function
 * names as the original C sources (decompose.c, trace.c, curve.c,
 * potracelib.c) so it can be read side-by-side with them.
 *
 * WHAT THIS PORT DELIBERATELY LEAVES OUT (for a smaller, single-file demo):
 *   - The original's word-packed bitmap representation and its
 *     bit-twiddling scanline tricks (here: a plain BooleanArray -- see
 *     the `xorPath` doc comment for why this is still efficient enough).
 *   - Output backends other than SVG (the original also has PDF, EPS,
 *     PostScript, DXF, XFIG, GeoJSON, PGM writers -- all driven by the
 *     same Curve data this file produces).
 *   - PBM/PGM/PPM/BMP file parsing (this port loads any format Java's
 *     ImageIO understands -- PNG, JPEG, GIF, BMP -- instead).
 *
 * Coordinate note: internally, bitmap row 0 is the BOTTOM of the image
 * (matching potrace's own convention -- see bitmap_io.c's bm_read, which
 * flips the image vertically right after loading it). `loadBitmap` below
 * performs the same flip when reading a file, and the SVG writer flips
 * back on output, so none of this is visible from the outside.
 * =============================================================================
 *
 * ANDROID PORT NOTE: this is otherwise an unmodified transcription of the
 * original single-file source. The only changes are confined to the
 * bitmap-loading / PBM read-write section near the bottom of this file,
 * where `java.awt.image.BufferedImage` and `javax.imageio.ImageIO` (desktop
 * JDK only -- not present on Android) are replaced with
 * `android.graphics.Bitmap` / `BitmapFactory`, and the JDK-only CLI
 * `main()` entry point (which depended on those same classes) is removed in
 * favor of being driven from the app's UI instead. The core two-phase
 * decompose/trace algorithm below is byte-for-byte identical to the
 * original -- it never touched AWT in the first place.
 * =============================================================================
 */

package com.vectorforge.app.engine.potrace

import android.graphics.Bitmap as AndroidBitmap
import android.graphics.BitmapFactory
import java.io.File
import java.util.Locale
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.max
import kotlin.math.sqrt

// =============================================================================
// Basic geometry
// =============================================================================

/** A point on the pixel-corner grid (integer coordinates). */
data class Point(val x: Int, val y: Int)

/** A point in real (floating point) coordinates. */
data class DPoint(var x: Double = 0.0, var y: Double = 0.0)

/** interval(lambda, a, b): the point at parameter `lambda` along segment a->b. */
private fun interval(lambda: Double, a: DPoint, b: DPoint): DPoint =
    DPoint(a.x + lambda * (b.x - a.x), a.y + lambda * (b.y - a.y))

private fun sign(x: Int): Int = if (x > 0) 1 else if (x < 0) -1 else 0
private fun sign(x: Double): Int = if (x > 0) 1 else if (x < 0) -1 else 0
private fun sq(x: Double): Double = x * x

/** mod(a,n): result is always in [0,n) even for negative a (n>0). */
private fun mod(a: Int, n: Int): Int = Math.floorMod(a, n)

/** floordiv(a,n): floor(a/n) using integer arithmetic (n>0). Kotlin's Math.floorDiv does this directly. */
private fun floordiv(a: Int, n: Int): Int = Math.floorDiv(a, n)

/** cross product of two integer grid points: p1.x*p2.y - p1.y*p2.x.
 *  NOTE: computed in Long to avoid 32-bit overflow on very large images
 *  (the original C sources use `long` coordinates for the same reason);
 *  the result is narrowed back to Int, which is safe for any bitmap up
 *  to roughly 46000 pixels on a side. */
private fun xprod(p1: Point, p2: Point): Int =
    (p1.x.toLong() * p2.y.toLong() - p1.y.toLong() * p2.x.toLong()).toInt()

/** true if a<=b<c<a in a cyclic sense (mod n). */
private fun cyclic(a: Int, b: Int, c: Int): Boolean =
    if (a <= c) (a <= b && b < c) else (a <= b || b < c)

// Curve segment tags (matches POTRACE_CORNER / POTRACE_CURVETO)
const val CORNER = 2
const val CURVETO = 1

/** A closed sequence of curve segments ("privcurve_t" in the original). */
class Curve(val n: Int) {
    val tag = IntArray(n)
    /** c[i][0..2]: the three Bezier control points ending segment i (c[i][2] is the on-curve vertex). */
    val c: Array<Array<DPoint>> = Array(n) { Array(3) { DPoint() } }
    val vertex: Array<DPoint> = Array(n) { DPoint() }
    val alpha = DoubleArray(n)
    val alpha0 = DoubleArray(n)
    val beta = DoubleArray(n)
}

// =============================================================================
// Path (one traced bitmap boundary) and its private working state
// =============================================================================

// Note: Sums and PrivPath must be at least as visible as PathObj.priv
// (a public property of the public PathObj class) — Kotlin's visibility
// consistency check forbids a public member from exposing a less-visible
// type, even within a single file. They're still "private" in spirit
// (pure implementation detail, not part of the intended public API) —
// just not marked with Kotlin's `private` keyword.
class Sums {
    var x = 0.0
    var y = 0.0
    var x2 = 0.0
    var xy = 0.0
    var y2 = 0.0
}

/** Per-path working data used while it travels through the pipeline. */
class PrivPath {
    var len = 0
    lateinit var pt: Array<Point>   // the raw traced boundary
    lateinit var lon: IntArray      // lon[i] = furthest index reachable in a straight line from i

    var x0 = 0
    var y0 = 0
    lateinit var sums: Array<Sums>  // running-sum cache, length len+1

    var m = 0                       // length of the optimal polygon
    lateinit var po: IntArray       // po[m]: optimal polygon vertex indices (into pt)

    lateinit var curve: Curve       // curve[m], after adjustVertices/smooth
    var ocurve: Curve? = null       // ocurve[om], after opticurve
    lateinit var fcurve: Curve      // the FINAL curve (== curve or ocurve)
}

/** One traced region, with sign/area/tree links (mirrors potrace_path_t). */
class PathObj {
    var area: Int = 0
    var sign: Char = '+'            // '+' for a black region, '-' for a hole
    lateinit var curve: Curve       // the final curve -- what consumers should read

    var next: PathObj? = null       // flat list order, as produced by decompose
    var childlist: PathObj? = null  // tree structure: first child
    var sibling: PathObj? = null    // tree structure: next sibling

    val priv = PrivPath()
}

// =============================================================================
// Bitmap: a plain boolean grid.
//
// Row 0 is the BOTTOM of the image (see the file-level doc comment above).
// Out-of-range reads return false, matching the original's bounds-checked
// BM_GET macro -- this lets the tracing code freely probe one pixel beyond
// the image edge without special-casing the border.
// =============================================================================
class Bitmap(val w: Int, val h: Int) {
    private val data = BooleanArray(w * h)

    fun get(x: Int, y: Int): Boolean {
        if (x < 0 || x >= w || y < 0 || y >= h) return false
        return data[y * w + x]
    }

    fun set(x: Int, y: Int, v: Boolean) {
        if (x < 0 || x >= w || y < 0 || y >= h) return
        data[y * w + x] = v
    }

    fun toggle(x: Int, y: Int) {
        if (x < 0 || x >= w || y < 0 || y >= h) return
        data[y * w + x] = !data[y * w + x]
    }

    fun copyOf(): Bitmap {
        val b = Bitmap(w, h)
        System.arraycopy(data, 0, b.data, 0, data.size)
        return b
    }

    fun clearRect(x0: Int, x1: Int, y0: Int, y1: Int) {
        for (y in max(0, y0) until min(h, y1)) {
            for (x in max(0, x0) until min(w, x1)) {
                data[y * w + x] = false
            }
        }
    }
}

// =============================================================================
// Tracing parameters (mirrors potrace_param_t)
// =============================================================================
object TurnPolicy {
    const val BLACK = 0
    const val WHITE = 1
    const val LEFT = 2
    const val RIGHT = 3
    const val MINORITY = 4
    const val MAJORITY = 5
    const val RANDOM = 6
}

class Params(
    /** Suppress traced regions with area <= turdsize ("speckle" removal). */
    var turdsize: Int = 2,
    /** How to resolve ambiguous (checkerboard) corners during boundary tracing. */
    var turnpolicy: Int = TurnPolicy.MINORITY,
    /** Corner vs. smooth-curve threshold; higher = more corners preserved. Typically 0..1.334. */
    var alphamax: Double = 1.0,
    /** Whether to run the Bezier-segment-merging optimization pass. */
    var opticurve: Boolean = true,
    /** Maximum deviation allowed while merging segments in opticurve. */
    var opttolerance: Double = 0.2
)

// =============================================================================
// PHASE A -- DECOMPOSE: bitmap -> tree of raw pixel-corner paths.
// Transcribed from decompose.c.
// =============================================================================

/** Deterministic pseudo-random bit, used only by TurnPolicy.RANDOM. */
private val DETRAND_T = intArrayOf(
    0, 1, 1, 0, 1, 0, 1, 1, 0, 1, 1, 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 1,
    0, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 1, 1, 0, 0, 1, 0, 0, 0, 0,
    0, 1, 0, 0, 1, 1, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1,
    1, 0, 1, 1, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 0, 1, 1,
    0, 0, 1, 1, 1, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0,
    0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 0, 1, 1, 1, 0, 1, 0,
    0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0, 1, 1, 0, 1, 0,
    0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1,
    1, 0, 1, 1, 0, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 1, 0, 1, 1, 1, 0, 0,
    0, 1, 0, 1, 1, 0, 0, 1, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 1, 1, 0, 0, 1,
    1, 1, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0
)

/** 32-bit hash, bit-identical to the original's `unsigned int` arithmetic
 *  (Kotlin's Int multiplication already wraps mod 2^32 the same way C's
 *  unsigned int does; `ushr` gives the needed *unsigned* right shift). */
private fun detrand(x: Int, y: Int): Int {
    var z = (0x04b3e375 * x) xor y
    z *= 0x05a8ef93
    return DETRAND_T[z and 0xff] xor
           DETRAND_T[(z ushr 8) and 0xff] xor
           DETRAND_T[(z ushr 16) and 0xff] xor
           DETRAND_T[(z ushr 24) and 0xff]
}

/** "Majority" value of bm around (x,y), used by TurnPolicy.MAJORITY/MINORITY. */
private fun majority(bm: Bitmap, x: Int, y: Int): Boolean {
    for (i in 2 until 5) {
        var ct = 0
        for (a in -i + 1..i - 1) {
            ct += if (bm.get(x + a, y + i - 1)) 1 else -1
            ct += if (bm.get(x + i - 1, y + a - 1)) 1 else -1
            ct += if (bm.get(x + a - 1, y - i)) 1 else -1
            ct += if (bm.get(x - i, y + a)) 1 else -1
        }
        if (ct > 0) return true
        if (ct < 0) return false
    }
    return false
}

/**
 * XOR the interior of the given path into bm: the standard rectilinear
 * scanline XOR-fill, where every vertical unit edge at column x toggles
 * the "inside" state for every column to its right. We only toggle up to
 * the path's own rightmost x: beyond that, every row crosses the path an
 * even number of times (a closed polygon always does) so the toggles
 * there always cancel to zero anyway -- this bounds the cost by the
 * path's own bounding box rather than the full bitmap width, without
 * needing the original's word-packed-bitmap tricks.
 */
private fun xorPath(bm: Bitmap, pp: PrivPath) {
    val len = pp.len
    if (len <= 0) return
    val pt = pp.pt

    var maxX = 0
    for (k in 0 until len) if (pt[k].x > maxX) maxX = pt[k].x

    var y1 = pt[len - 1].y
    for (k in 0 until len) {
        val x = pt[k].x
        val y = pt[k].y
        if (y != y1) {
            val row = min(y, y1)
            for (col in x until maxX) bm.toggle(col, row)
            y1 = y
        }
    }
}

/** Bounding box of a path: (x0, x1, y0, y1), all inclusive. */
private data class BBox(val x0: Int, val x1: Int, val y0: Int, val y1: Int)

private fun setBboxPath(pp: PrivPath): BBox {
    var x0 = Int.MAX_VALUE; var x1 = 0; var y0 = Int.MAX_VALUE; var y1 = 0
    for (k in 0 until pp.len) {
        val x = pp.pt[k].x; val y = pp.pt[k].y
        if (x < x0) x0 = x
        if (x > x1) x1 = x
        if (y < y0) y0 = y
        if (y > y1) y1 = y
    }
    return BBox(x0, x1, y0, y1)
}

/**
 * Find the next set pixel at or after (xFrom,yStart) in reading order --
 * top-to-bottom, then left-to-right within a row -- resuming the given
 * row from xFrom (subsequent rows are scanned from column 0).
 */
private fun findNext(bm: Bitmap, xFrom: Int, yStart: Int): Point? {
    var y = yStart
    var xs = xFrom
    while (y >= 0) {
        for (x in xs until bm.w) {
            if (bm.get(x, y)) return Point(x, y)
        }
        xs = 0
        y--
    }
    return null
}

/**
 * Trace one boundary path in bm, starting at grid-corner (x0,y0) (which
 * must be the upper-left corner of the region). Walks the boundary one
 * unit step at a time, resolving ambiguous corners via `turnpolicy`.
 */
private fun findPath(bm: Bitmap, x0: Int, y0: Int, pathSign: Char, turnpolicy: Int): PathObj {
    var x = x0
    var y = y0
    var dirx = 0
    var diry = -1
    val pts = ArrayList<Point>()
    var area = 0L

    while (true) {
        pts.add(Point(x, y))

        x += dirx
        y += diry
        area += x.toLong() * diry

        if (x == x0 && y == y0) break

        val c = bm.get(x + (dirx + diry - 1) / 2, y + (diry - dirx - 1) / 2)
        val d = bm.get(x + (dirx - diry - 1) / 2, y + (diry + dirx - 1) / 2)

        if (c && !d) {
            val rightTurn =
                turnpolicy == TurnPolicy.RIGHT ||
                (turnpolicy == TurnPolicy.BLACK && pathSign == '+') ||
                (turnpolicy == TurnPolicy.WHITE && pathSign == '-') ||
                (turnpolicy == TurnPolicy.RANDOM && detrand(x, y) != 0) ||
                (turnpolicy == TurnPolicy.MAJORITY && majority(bm, x, y)) ||
                (turnpolicy == TurnPolicy.MINORITY && !majority(bm, x, y))
            if (rightTurn) {
                val tmp = dirx; dirx = diry; diry = -tmp
            } else {
                val tmp = dirx; dirx = -diry; diry = tmp
            }
        } else if (c) {
            val tmp = dirx; dirx = diry; diry = -tmp
        } else if (!d) {
            val tmp = dirx; dirx = -diry; diry = tmp
        }
    }

    val p = PathObj()
    p.priv.pt = pts.toTypedArray()
    p.priv.len = p.priv.pt.size
    p.area = area.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
    p.sign = pathSign
    return p
}

/**
 * Build the containment tree for a list of paths that is already ordered
 * "outer before inner" (as produced by the scan order of bmToPathList).
 * `scratch` is scratch space the size of the traced bitmap, assumed
 * all-clear on entry and restored to all-clear on exit. Returns the head
 * of the top-level sibling chain.
 *
 * This mirrors decompose.c's pathlist_to_tree, re-expressed as plain
 * recursion instead of the original's pointer-reusing tail-recursive
 * "heap" (which existed purely to avoid deep C-stack recursion); the
 * containment logic itself is unchanged.
 */
private fun buildTree(paths: List<PathObj>, scratch: Bitmap): PathObj? {
    if (paths.isEmpty()) return null
    val head = paths[0]

    xorPath(scratch, head.priv)
    val bbox = setBboxPath(head.priv)

    val inList = ArrayList<PathObj>()
    val outList = ArrayList<PathObj>()

    var i = 1
    while (i < paths.size) {
        val p = paths[i]
        if (p.priv.pt[0].y <= bbox.y0) {
            // Scan order is monotonic top-to-bottom, so this path (and
            // everything after it) cannot be inside head.
            break
        }
        if (scratch.get(p.priv.pt[0].x, p.priv.pt[0].y - 1)) inList.add(p) else outList.add(p)
        i++
    }
    while (i < paths.size) { outList.add(paths[i]); i++ }

    scratch.clearRect(bbox.x0, bbox.x1 + 1, bbox.y0, bbox.y1 + 1)

    head.childlist = buildTree(inList, scratch)
    head.sibling = buildTree(outList, scratch)
    return head
}

/**
 * Flatten a containment tree (as built by buildTree) into potrace's
 * canonical order: each path is immediately followed by its direct
 * children, while deeper descendants are appended in a later pass
 * (breadth-first over "childlist" generations). Sets `.next` links.
 */
private fun flattenTree(topChainHead: PathObj?): PathObj? {
    val result = ArrayList<PathObj>()
    val queue = ArrayDeque<PathObj>()
    if (topChainHead != null) queue.addLast(topChainHead)

    while (queue.isNotEmpty()) {
        val chainHead = queue.removeFirst()
        var p: PathObj? = chainHead
        while (p != null) {
            result.add(p)
            var c = p.childlist
            while (c != null) {
                result.add(c)
                if (c.childlist != null) queue.addLast(c.childlist!!)
                c = c.sibling
            }
            p = p.sibling
        }
    }

    for (k in 0 until result.size - 1) result[k].next = result[k + 1]
    if (result.isNotEmpty()) result[result.size - 1].next = null
    return if (result.isEmpty()) null else result[0]
}

/**
 * Decompose bm into a flat, tree-linked list of raw paths. Regions with
 * area <= param.turdsize ("speckles") are discarded. Does not modify bm.
 */
private fun bmToPathList(bm: Bitmap, param: Params): PathObj? {
    val work = bm.copyOf()
    val plist = ArrayList<PathObj>()

    var x = 0
    var y = work.h - 1
    while (true) {
        val found = findNext(work, x, y) ?: break
        x = found.x
        y = found.y

        val pathSign = if (bm.get(x, y)) '+' else '-'
        val p = findPath(work, x, y + 1, pathSign, param.turnpolicy)
        xorPath(work, p.priv)

        if (p.area > param.turdsize) plist.add(p)
        // else: discard as a "speckle"
    }

    // Tree-building needs its own clean scratch bitmap (the original C
    // code explicitly re-clears its scratch bitmap here too, rather than
    // relying on the decomposition loop having already reduced it to
    // all-zero).
    val treeScratch = Bitmap(bm.w, bm.h)
    val tree = buildTree(plist, treeScratch)
    return flattenTree(tree)
}

// =============================================================================
// PHASE B -- TRACE: raw polygon -> optimized Bezier curve.
// Transcribed from trace.c.
// =============================================================================

private const val INFTY = 10000000
private const val COS179 = -0.999847695156  // cos(179 degrees), used as a near-straight-line tolerance

/** 90-degree-CCW direction of (p2-p0), snapped to the major axis. */
private fun dorthInfty(p0: DPoint, p2: DPoint): Point = Point(-sign(p2.y - p0.y), sign(p2.x - p0.x))

/** (p1-p0) x (p2-p0): twice the signed area of triangle p0,p1,p2. */
private fun dpara(p0: DPoint, p1: DPoint, p2: DPoint): Double {
    val x1 = p1.x - p0.x; val y1 = p1.y - p0.y
    val x2 = p2.x - p0.x; val y2 = p2.y - p0.y
    return x1 * y2 - x2 * y1
}

private fun ddenom(p0: DPoint, p2: DPoint): Double {
    val r = dorthInfty(p0, p2)
    return r.y * (p2.x - p0.x) - r.x * (p2.y - p0.y)
}

/** (p1-p0) x (p3-p2) */
private fun cprod(p0: DPoint, p1: DPoint, p2: DPoint, p3: DPoint): Double {
    val x1 = p1.x - p0.x; val y1 = p1.y - p0.y
    val x2 = p3.x - p2.x; val y2 = p3.y - p2.y
    return x1 * y2 - x2 * y1
}

/** (p1-p0) . (p2-p0) */
private fun iprod(p0: DPoint, p1: DPoint, p2: DPoint): Double {
    val x1 = p1.x - p0.x; val y1 = p1.y - p0.y
    val x2 = p2.x - p0.x; val y2 = p2.y - p0.y
    return x1 * x2 + y1 * y2
}

/** (p1-p0) . (p3-p2) */
private fun iprod1(p0: DPoint, p1: DPoint, p2: DPoint, p3: DPoint): Double {
    val x1 = p1.x - p0.x; val y1 = p1.y - p0.y
    val x2 = p3.x - p2.x; val y2 = p3.y - p2.y
    return x1 * x2 + y1 * y2
}

private fun ddist(p: DPoint, q: DPoint): Double = sqrt(sq(p.x - q.x) + sq(p.y - q.y))

private fun bezier(t: Double, p0: DPoint, p1: DPoint, p2: DPoint, p3: DPoint): DPoint {
    val s = 1 - t
    val x = s*s*s*p0.x + 3*(s*s*t)*p1.x + 3*(t*t*s)*p2.x + t*t*t*p3.x
    val y = s*s*s*p0.y + 3*(s*s*t)*p1.y + 3*(t*t*s)*p2.y + t*t*t*p3.y
    return DPoint(x, y)
}

/** t in [0,1] where bezier(p0,p1,p2,p3) is tangent to line q0-q1, or -1 if none. */
private fun tangent(p0: DPoint, p1: DPoint, p2: DPoint, p3: DPoint, q0: DPoint, q1: DPoint): Double {
    val A = cprod(p0, p1, q0, q1)
    val B = cprod(p1, p2, q0, q1)
    val C = cprod(p2, p3, q0, q1)

    val a = A - 2*B + C
    val b = -2*A + 2*B
    val c = A

    val d = b*b - 4*a*c
    if (a == 0.0 || d < 0) return -1.0

    val s = sqrt(d)
    val r1 = (-b + s) / (2 * a)
    val r2 = (-b - s) / (2 * a)

    if (r1 in 0.0..1.0) return r1
    if (r2 in 0.0..1.0) return r2
    return -1.0
}

/** quadratic form v^T Q v where v = (w.x, w.y, 1). */
private fun quadform(q: Array<DoubleArray>, w: DPoint): Double {
    val v = doubleArrayOf(w.x, w.y, 1.0)
    var sum = 0.0
    for (i in 0..2) for (j in 0..2) sum += v[i] * q[i][j] * v[j]
    return sum
}

// -----------------------------------------------------------------------
// Preparation: a running-sum cache for fast summation over arbitrary
// sub-ranges of the path (used by penalty3 and pointslope).
// -----------------------------------------------------------------------
private fun calcSums(pp: PrivPath) {
    val n = pp.len
    pp.sums = Array(n + 1) { Sums() }
    pp.x0 = pp.pt[0].x
    pp.y0 = pp.pt[0].y

    for (i in 0 until n) {
        val x = pp.pt[i].x - pp.x0
        val y = pp.pt[i].y - pp.y0
        val prev = pp.sums[i]; val cur = pp.sums[i + 1]
        cur.x = prev.x + x
        cur.y = prev.y + y
        cur.x2 = prev.x2 + x.toDouble() * x
        cur.xy = prev.xy + x.toDouble() * y
        cur.y2 = prev.y2 + y.toDouble() * y
    }
}

// -----------------------------------------------------------------------
// Stage 1: for every point i, find lon[i] = the furthest index such that
// a straight line can be drawn from i to lon[i] (allowing for pixel-grid
// staircase noise). See trace.c's own extensive comments for the
// "constraint cone" argument that makes this run in close to linear time.
// -----------------------------------------------------------------------
private fun calcLon(pp: PrivPath) {
    val pt = pp.pt
    val n = pp.len
    val pivk = IntArray(n)
    val nc = IntArray(n)
    pp.lon = IntArray(n)

    var k = 0
    for (i in n - 1 downTo 0) {
        if (pt[i].x != pt[k].x && pt[i].y != pt[k].y) k = i + 1
        nc[i] = k
    }

    val ct = IntArray(4)
    var c0 = Point(0, 0)
    var c1 = Point(0, 0)

    for (i in n - 1 downTo 0) {
        ct[0] = 0; ct[1] = 0; ct[2] = 0; ct[3] = 0

        val dir0 = (3 + 3 * sign(pt[mod(i + 1, n)].x - pt[i].x) + sign(pt[mod(i + 1, n)].y - pt[i].y)) / 2
        ct[dir0]++

        c0 = Point(0, 0)
        c1 = Point(0, 0)

        k = nc[i]
        var k1 = i
        var found = false

        while (true) {
            val dir = (3 + 3 * sign(pt[k].x - pt[k1].x) + sign(pt[k].y - pt[k1].y)) / 2
            ct[dir]++

            if (ct[0] != 0 && ct[1] != 0 && ct[2] != 0 && ct[3] != 0) {
                pivk[i] = k1
                found = true
                break
            }

            val cur = Point(pt[k].x - pt[i].x, pt[k].y - pt[i].y)

            if (xprod(c0, cur) < 0 || xprod(c1, cur) > 0) break // constraint violated

            if (abs(cur.x) <= 1 && abs(cur.y) <= 1) {
                // no additional constraint
            } else {
                var offx = cur.x + (if (cur.y >= 0 && (cur.y > 0 || cur.x < 0)) 1 else -1)
                var offy = cur.y + (if (cur.x <= 0 && (cur.x < 0 || cur.y < 0)) 1 else -1)
                var off = Point(offx, offy)
                if (xprod(c0, off) >= 0) c0 = off

                offx = cur.x + (if (cur.y <= 0 && (cur.y < 0 || cur.x < 0)) 1 else -1)
                offy = cur.y + (if (cur.x >= 0 && (cur.x > 0 || cur.y < 0)) 1 else -1)
                off = Point(offx, offy)
                if (xprod(c1, off) <= 0) c1 = off
            }

            k1 = k
            k = nc[k1]
            if (!cyclic(k, i, k1)) break
        }

        if (!found) {
            val dk = Point(sign(pt[k].x - pt[k1].x), sign(pt[k].y - pt[k1].y))
            val cur = Point(pt[k1].x - pt[i].x, pt[k1].y - pt[i].y)

            val a = xprod(c0, cur)
            val b = xprod(c0, dk)
            val c = xprod(c1, cur)
            val d = xprod(c1, dk)

            var j = INFTY
            if (b < 0) j = floordiv(a, -b)
            if (d > 0) j = min(j, floordiv(-c, d))
            pivk[i] = mod(k1 + j, n)
        }
    }

    var j = pivk[n - 1]
    pp.lon[n - 1] = j
    for (i in n - 2 downTo 0) {
        if (cyclic(i + 1, pivk[i], j)) j = pivk[i]
        pp.lon[i] = j
    }
    var i = n - 1
    while (cyclic(mod(i + 1, n), j, pp.lon[i])) {
        pp.lon[i] = j
        i--
    }
}

// -----------------------------------------------------------------------
// Stage 2: find the optimal polygon (a subset of the boundary points,
// chosen so the pixel path deviates as little as possible from the
// straight segments between them, via a shortest-path search).
// -----------------------------------------------------------------------

/** Penalty of a candidate edge from boundary index i to j (0<=i<j<=n). */
private fun penalty3(pp: PrivPath, i: Int, jIn: Int): Double {
    val n = pp.len
    val pt = pp.pt
    val sums = pp.sums
    var j = jIn
    var r = 0
    if (j >= n) { j -= n; r = 1 }

    val x: Double; val y: Double; val x2: Double; val xy: Double; val y2: Double; val k: Double
    if (r == 0) {
        x = sums[j+1].x - sums[i].x
        y = sums[j+1].y - sums[i].y
        x2 = sums[j+1].x2 - sums[i].x2
        xy = sums[j+1].xy - sums[i].xy
        y2 = sums[j+1].y2 - sums[i].y2
        k = (j + 1 - i).toDouble()
    } else {
        x = sums[j+1].x - sums[i].x + sums[n].x
        y = sums[j+1].y - sums[i].y + sums[n].y
        x2 = sums[j+1].x2 - sums[i].x2 + sums[n].x2
        xy = sums[j+1].xy - sums[i].xy + sums[n].xy
        y2 = sums[j+1].y2 - sums[i].y2 + sums[n].y2
        k = (j + 1 - i + n).toDouble()
    }

    val px = (pt[i].x + pt[j].x) / 2.0 - pt[0].x
    val py = (pt[i].y + pt[j].y) / 2.0 - pt[0].y
    val ey = (pt[j].x - pt[i].x).toDouble()
    val ex = -(pt[j].y - pt[i].y).toDouble()

    val a = (x2 - 2*x*px) / k + px*px
    val b = (xy - x*py - y*px) / k + px*py
    val c = (y2 - 2*y*py) / k + py*py

    val s = ex*ex*a + 2*ex*ey*b + ey*ey*c
    return sqrt(s)
}

/** Find the optimal polygon; fills pp.m and pp.po. */
private fun bestPolygon(pp: PrivPath) {
    val n = pp.len
    val pen = DoubleArray(n + 1)
    val prev = IntArray(n + 1)
    val clip0 = IntArray(n)
    val clip1 = IntArray(n + 1)
    val seg0 = IntArray(n + 1)
    val seg1 = IntArray(n + 1)

    for (i in 0 until n) {
        var c = mod(pp.lon[mod(i - 1, n)] - 1, n)
        if (c == i) c = mod(i + 1, n)
        clip0[i] = if (c < i) n else c
    }

    var j = 1
    for (i in 0 until n) {
        while (j <= clip0[i]) { clip1[j] = i; j++ }
    }

    var i = 0
    j = 0
    while (i < n) { seg0[j] = i; i = clip0[i]; j++ }
    seg0[j] = n
    val m = j

    i = n
    for (jj in m downTo 1) { seg1[jj] = i; i = clip1[i] }
    seg1[0] = 0

    pen[0] = 0.0
    for (jj in 1..m) {
        for (ii in seg1[jj]..seg0[jj]) {
            var best = -1.0
            for (k in seg0[jj - 1] downTo clip1[ii]) {
                val thisPen = penalty3(pp, k, ii) + pen[k]
                if (best < 0 || thisPen < best) { prev[ii] = k; best = thisPen }
            }
            pen[ii] = best
        }
    }

    pp.m = m
    pp.po = IntArray(m)
    i = n
    var jj = m - 1
    while (i > 0) { i = prev[i]; pp.po[jj] = i; jj-- }
}

// -----------------------------------------------------------------------
// Stage 3: vertex adjustment -- move each polygon vertex to the point
// that best fits its two adjacent straight-line segments simultaneously.
// -----------------------------------------------------------------------

/** Least-squares center/direction of the line through path points i..j (i<j, cyclic). */
private fun pointslope(pp: PrivPath, iIn: Int, jIn: Int, ctr: DPoint, dir: DPoint) {
    val n = pp.len
    val sums = pp.sums
    var i = iIn
    var j = jIn
    var r = 0

    while (j >= n) { j -= n; r += 1 }
    while (i >= n) { i -= n; r -= 1 }
    while (j < 0) { j += n; r -= 1 }
    while (i < 0) { i += n; r += 1 }

    val x = sums[j+1].x - sums[i].x + r * sums[n].x
    val y = sums[j+1].y - sums[i].y + r * sums[n].y
    val x2 = sums[j+1].x2 - sums[i].x2 + r * sums[n].x2
    val xy = sums[j+1].xy - sums[i].xy + r * sums[n].xy
    val y2 = sums[j+1].y2 - sums[i].y2 + r * sums[n].y2
    val k = (j + 1 - i + r * n).toDouble()

    ctr.x = x / k
    ctr.y = y / k

    var a = (x2 - x * x / k) / k
    var b = (xy - x * y / k) / k
    var c = (y2 - y * y / k) / k

    val lambda2 = (a + c + sqrt((a - c) * (a - c) + 4 * b * b)) / 2

    a -= lambda2
    c -= lambda2

    var l: Double
    if (abs(a) >= abs(c)) {
        l = sqrt(a * a + b * b)
        if (l != 0.0) { dir.x = -b / l; dir.y = a / l }
    } else {
        l = sqrt(c * c + b * b)
        if (l != 0.0) { dir.x = -c / l; dir.y = b / l }
    }
    if (l == 0.0) { dir.x = 0.0; dir.y = 0.0 }
}

private fun adjustVertices(pp: PrivPath) {
    val m = pp.m
    val po = pp.po
    val n = pp.len
    val pt = pp.pt
    val x0 = pp.x0
    val y0 = pp.y0

    val ctr = Array(m) { DPoint() }
    val dir = Array(m) { DPoint() }
    val q = Array(m) { Array(3) { DoubleArray(3) } }

    pp.curve = Curve(m)

    for (i in 0 until m) {
        var j = po[mod(i + 1, m)]
        j = mod(j - po[i], n) + po[i]
        pointslope(pp, po[i], j, ctr[i], dir[i])
    }

    for (i in 0 until m) {
        val d = sq(dir[i].x) + sq(dir[i].y)
        if (d == 0.0) {
            for (a in 0..2) for (b in 0..2) q[i][a][b] = 0.0
        } else {
            val v0 = dir[i].y
            val v1 = -dir[i].x
            val v2 = -v1 * ctr[i].y - v0 * ctr[i].x
            val v = doubleArrayOf(v0, v1, v2)
            for (l in 0..2) for (k in 0..2) q[i][l][k] = v[l] * v[k] / d
        }
    }

    for (i in 0 until m) {
        val qq = Array(3) { DoubleArray(3) }
        val w = DPoint()
        val sx = (pt[po[i]].x - x0).toDouble()
        val sy = (pt[po[i]].y - y0).toDouble()

        val j0 = mod(i - 1, m)
        for (l in 0..2) for (k in 0..2) qq[l][k] = q[j0][l][k] + q[i][l][k]

        var dx: Double
        var dy: Double
        while (true) {
            val det = qq[0][0] * qq[1][1] - qq[0][1] * qq[1][0]
            if (det != 0.0) {
                w.x = (-qq[0][2] * qq[1][1] + qq[1][2] * qq[0][1]) / det
                w.y = (qq[0][2] * qq[1][0] - qq[1][2] * qq[0][0]) / det
                break
            }
            // Degenerate (rank-deficient) quadratic form: nudge it with an
            // extra constraint orthogonal to its existing null direction
            // and retry, exactly as the original does.
            var v0: Double; var v1: Double
            if (qq[0][0] > qq[1][1]) {
                v0 = -qq[0][1]; v1 = qq[0][0]
            } else if (qq[1][1] != 0.0) {
                v0 = -qq[1][1]; v1 = qq[1][0]
            } else {
                v0 = 1.0; v1 = 0.0
            }
            val dd = sq(v0) + sq(v1)
            val v2 = -v1 * sy - v0 * sx
            val v = doubleArrayOf(v0, v1, v2)
            for (l in 0..2) for (k in 0..2) qq[l][k] += v[l] * v[k] / dd
        }

        dx = abs(w.x - sx)
        dy = abs(w.y - sy)
        if (dx <= .5 && dy <= .5) {
            pp.curve.vertex[i].x = w.x + x0
            pp.curve.vertex[i].y = w.y + y0
            continue
        }

        // The unconstrained optimum lands outside the pixel the vertex
        // must stay within: search the boundary/corners of that pixel
        // for the best-scoring point instead.
        var min = quadform(qq, DPoint(sx, sy))
        var xmin = sx
        var ymin = sy

        if (qq[0][0] != 0.0) {
            for (z in 0..1) {
                val wy = sy - 0.5 + z
                val wx = -(qq[0][1] * wy + qq[0][2]) / qq[0][0]
                dx = abs(wx - sx)
                val cand = quadform(qq, DPoint(wx, wy))
                if (dx <= .5 && cand < min) { min = cand; xmin = wx; ymin = wy }
            }
        }
        if (qq[1][1] != 0.0) {
            for (z in 0..1) {
                val wx = sx - 0.5 + z
                val wy = -(qq[1][0] * wx + qq[1][2]) / qq[1][1]
                dy = abs(wy - sy)
                val cand = quadform(qq, DPoint(wx, wy))
                if (dy <= .5 && cand < min) { min = cand; xmin = wx; ymin = wy }
            }
        }
        for (l in 0..1) {
            for (k in 0..1) {
                val wx = sx - 0.5 + l
                val wy = sy - 0.5 + k
                val cand = quadform(qq, DPoint(wx, wy))
                if (cand < min) { min = cand; xmin = wx; ymin = wy }
            }
        }

        pp.curve.vertex[i].x = xmin + x0
        pp.curve.vertex[i].y = ymin + y0
    }
}

// -----------------------------------------------------------------------
// Stage 4: smoothing -- classify each vertex as a hard CORNER or a round
// CURVETO, and compute the Bezier control points for the CURVETO case.
// -----------------------------------------------------------------------

private fun reverse(curve: Curve) {
    var i = 0
    var j = curve.n - 1
    while (i < j) {
        val tmp = curve.vertex[i]; curve.vertex[i] = curve.vertex[j]; curve.vertex[j] = tmp
        i++; j--
    }
}

private fun smooth(curve: Curve, alphamax: Double) {
    val m = curve.n
    for (i in 0 until m) {
        val j = mod(i + 1, m)
        val k = mod(i + 2, m)
        val p4 = interval(0.5, curve.vertex[k], curve.vertex[j])

        val denom = ddenom(curve.vertex[i], curve.vertex[k])
        var alpha: Double
        if (denom != 0.0) {
            var dd = dpara(curve.vertex[i], curve.vertex[j], curve.vertex[k]) / denom
            dd = abs(dd)
            alpha = if (dd > 1) (1 - 1.0 / dd) else 0.0
            alpha /= 0.75
        } else {
            alpha = 4 / 3.0
        }
        curve.alpha0[j] = alpha

        if (alpha >= alphamax) {
            curve.tag[j] = CORNER
            curve.c[j][1] = curve.vertex[j].copy()
            curve.c[j][2] = p4
        } else {
            val a = if (alpha < 0.55) 0.55 else if (alpha > 1) 1.0 else alpha
            val p2 = interval(.5 + .5 * a, curve.vertex[i], curve.vertex[j])
            val p3 = interval(.5 + .5 * a, curve.vertex[k], curve.vertex[j])
            curve.tag[j] = CURVETO
            curve.c[j][0] = p2
            curve.c[j][1] = p3
            curve.c[j][2] = p4
            alpha = a
        }
        curve.alpha[j] = alpha
        curve.beta[j] = 0.5
    }
}

// -----------------------------------------------------------------------
// Stage 5: curve optimization -- greedily merge consecutive Bezier
// segments into a single longer Bezier wherever that stays within
// `opttolerance` of the original curve (a shortest-path search, same
// shape as bestPolygon above but operating on curve segments instead of
// raw boundary points).
// -----------------------------------------------------------------------

private class Opti {
    var pen = 0.0
    var c0 = DPoint()
    var c1 = DPoint()
    var t = 0.0
    var s = 0.0
    var alpha = 0.0
}

/** Best single-Bezier fit replacing segments i+1..j (cyclic); null if not achievable within tolerance. */
private fun optiPenalty(
    pp: PrivPath, i: Int, j: Int, opttolerance: Double, convc: IntArray, areac: DoubleArray
): Opti? {
    val m = pp.curve.n
    if (i == j) return null

    var k = i
    val i1 = mod(i + 1, m)
    var k1 = mod(k + 1, m)
    val conv = convc[k1]
    if (conv == 0) return null

    val d = ddist(pp.curve.vertex[i], pp.curve.vertex[i1])
    k = k1
    while (k != j) {
        k1 = mod(k + 1, m)
        val k2 = mod(k + 2, m)
        if (convc[k1] != conv) return null
        if (sign(cprod(pp.curve.vertex[i], pp.curve.vertex[i1], pp.curve.vertex[k1], pp.curve.vertex[k2])) != conv) return null
        if (iprod1(pp.curve.vertex[i], pp.curve.vertex[i1], pp.curve.vertex[k1], pp.curve.vertex[k2]) <
            d * ddist(pp.curve.vertex[k1], pp.curve.vertex[k2]) * COS179) return null
        k = k1
    }

    val p0 = pp.curve.c[mod(i, m)][2]
    val p1 = pp.curve.vertex[mod(i + 1, m)]
    val p2 = pp.curve.vertex[mod(j, m)]
    val p3 = pp.curve.c[mod(j, m)][2]

    var area = areac[j] - areac[i]
    area -= dpara(pp.curve.vertex[0], pp.curve.c[i][2], pp.curve.c[j][2]) / 2
    if (i >= j) area += areac[m]

    val a1 = dpara(p0, p1, p2)
    val a2 = dpara(p0, p1, p3)
    val a3 = dpara(p0, p2, p3)
    val a4 = a1 + a3 - a2

    if (a2 == a1) return null

    val t = a3 / (a3 - a4)
    val s = a2 / (a2 - a1)
    val a = a2 * t / 2.0
    if (a == 0.0) return null

    val r = area / a
    val disc = 4 - r / 0.3
    if (disc < 0) return null
    val alpha = 2 - sqrt(disc)

    val res = Opti()
    res.c0 = interval(t * alpha, p0, p1)
    res.c1 = interval(s * alpha, p3, p2)
    res.alpha = alpha
    res.t = t
    res.s = s
    res.pen = 0.0

    val rp1 = res.c0
    val rp2 = res.c1

    k = mod(i + 1, m)
    while (k != j) {
        k1 = mod(k + 1, m)
        val tt = tangent(p0, rp1, rp2, p3, pp.curve.vertex[k], pp.curve.vertex[k1])
        if (tt < -.5) return null
        val pt = bezier(tt, p0, rp1, rp2, p3)
        val dd = ddist(pp.curve.vertex[k], pp.curve.vertex[k1])
        if (dd == 0.0) return null
        val d1 = dpara(pp.curve.vertex[k], pp.curve.vertex[k1], pt) / dd
        if (abs(d1) > opttolerance) return null
        if (iprod(pp.curve.vertex[k], pp.curve.vertex[k1], pt) < 0 ||
            iprod(pp.curve.vertex[k1], pp.curve.vertex[k], pt) < 0) return null
        res.pen += sq(d1)
        k = k1
    }

    k = i
    while (k != j) {
        k1 = mod(k + 1, m)
        val tt = tangent(p0, rp1, rp2, p3, pp.curve.c[k][2], pp.curve.c[k1][2])
        if (tt < -.5) return null
        val pt = bezier(tt, p0, rp1, rp2, p3)
        val dd = ddist(pp.curve.c[k][2], pp.curve.c[k1][2])
        if (dd == 0.0) return null
        var d1 = dpara(pp.curve.c[k][2], pp.curve.c[k1][2], pt) / dd
        var d2 = dpara(pp.curve.c[k][2], pp.curve.c[k1][2], pp.curve.vertex[k1]) / dd
        d2 *= 0.75 * pp.curve.alpha[k1]
        if (d2 < 0) { d1 = -d1; d2 = -d2 }
        if (d1 < d2 - opttolerance) return null
        if (d1 < d2) res.pen += sq(d1 - d2)
        k = k1
    }

    return res
}

private fun opticurve(pp: PrivPath, opttolerance: Double) {
    val m = pp.curve.n
    val pt = IntArray(m + 1)
    val pen = DoubleArray(m + 1)
    val len = IntArray(m + 1)
    val opt = arrayOfNulls<Opti>(m + 1)
    val convc = IntArray(m)
    val areac = DoubleArray(m + 1)

    for (i in 0 until m) {
        convc[i] = if (pp.curve.tag[i] == CURVETO)
            sign(dpara(pp.curve.vertex[mod(i - 1, m)], pp.curve.vertex[i], pp.curve.vertex[mod(i + 1, m)]))
        else 0
    }

    var area = 0.0
    areac[0] = 0.0
    val p0 = pp.curve.vertex[0]
    for (i in 0 until m) {
        val i1 = mod(i + 1, m)
        if (pp.curve.tag[i1] == CURVETO) {
            val alpha = pp.curve.alpha[i1]
            area += 0.3 * alpha * (4 - alpha) * dpara(pp.curve.c[i][2], pp.curve.vertex[i1], pp.curve.c[i1][2]) / 2
            area += dpara(p0, pp.curve.c[i][2], pp.curve.c[i1][2]) / 2
        }
        areac[i + 1] = area
    }

    pt[0] = -1
    pen[0] = 0.0
    len[0] = 0

    for (j in 1..m) {
        pt[j] = j - 1
        pen[j] = pen[j - 1]
        len[j] = len[j - 1] + 1
        for (i in j - 2 downTo 0) {
            val o = optiPenalty(pp, i, mod(j, m), opttolerance, convc, areac) ?: break
            if (len[j] > len[i] + 1 || (len[j] == len[i] + 1 && pen[j] > pen[i] + o.pen)) {
                pt[j] = i
                pen[j] = pen[i] + o.pen
                len[j] = len[i] + 1
                opt[j] = o
            }
        }
    }

    val om = len[m]
    val ocurve = Curve(om)
    pp.ocurve = ocurve
    val s = DoubleArray(om)
    val t = DoubleArray(om)

    var j = m
    for (i in om - 1 downTo 0) {
        if (pt[j] == j - 1) {
            val jm = mod(j, m)
            ocurve.tag[i] = pp.curve.tag[jm]
            ocurve.c[i][0] = pp.curve.c[jm][0].copy()
            ocurve.c[i][1] = pp.curve.c[jm][1].copy()
            ocurve.c[i][2] = pp.curve.c[jm][2].copy()
            ocurve.vertex[i] = pp.curve.vertex[jm].copy()
            ocurve.alpha[i] = pp.curve.alpha[jm]
            ocurve.alpha0[i] = pp.curve.alpha0[jm]
            ocurve.beta[i] = pp.curve.beta[jm]
            s[i] = 1.0; t[i] = 1.0
        } else {
            val jm = mod(j, m)
            val o = opt[j]!!
            ocurve.tag[i] = CURVETO
            ocurve.c[i][0] = o.c0.copy()
            ocurve.c[i][1] = o.c1.copy()
            ocurve.c[i][2] = pp.curve.c[jm][2].copy()
            ocurve.vertex[i] = interval(o.s, pp.curve.c[jm][2], pp.curve.vertex[jm])
            ocurve.alpha[i] = o.alpha
            ocurve.alpha0[i] = o.alpha
            s[i] = o.s
            t[i] = o.t
        }
        j = pt[j]
    }

    for (i in 0 until om) {
        val i1 = mod(i + 1, om)
        ocurve.beta[i] = s[i] / (s[i] + t[i1])
    }
}

// -----------------------------------------------------------------------
// Top-level per-path pipeline and public entry point.
// -----------------------------------------------------------------------
private fun processPath(plistHead: PathObj?, param: Params) {
    var p = plistHead
    while (p != null) {
        calcSums(p.priv)
        calcLon(p.priv)
        bestPolygon(p.priv)
        adjustVertices(p.priv)
        if (p.sign == '-') reverse(p.priv.curve)
        smooth(p.priv.curve, param.alphamax)
        if (param.opticurve) {
            opticurve(p.priv, param.opttolerance)
            p.priv.fcurve = p.priv.ocurve!!
        } else {
            p.priv.fcurve = p.priv.curve
        }
        p.curve = p.priv.fcurve
        p = p.next
    }
}

/**
 * Trace a bitmap, returning the head of the flat, tree-linked list of
 * paths (see PathObj.next / .childlist / .sibling), each with its final
 * `curve` filled in. This is the single function that runs the whole
 * pipeline described in the file-level doc comment above.
 */
fun potraceTrace(bm: Bitmap, param: Params = Params()): PathObj? {
    val plist = bmToPathList(bm, param)
    processPath(plist, param)
    return plist
}

// =============================================================================
// Bitmap loading: any raster format android.graphics.BitmapFactory understands
// (PNG, JPEG, GIF, WebP, BMP, ...) -> a thresholded black/white Bitmap.
//
// Matches potrace's own bm_read(): pixels below `threshold` (0..1, as a
// fraction of full brightness) are "black" (set); the loaded image is
// flipped vertically so that bitmap row 0 is the BOTTOM of the image,
// exactly like potrace's own file reader does (see bitmap_io.c).
//
// (Android port: BitmapFactory.decodeFile stands in for ImageIO.read.
// AndroidBitmap.getPixel() returns the same packed 0xAARRGGBB int that
// BufferedImage.getRGB() did, so the channel-extraction math below is
// untouched from the original.)
// =============================================================================
fun loadBitmap(file: File, threshold: Double = 0.5): Bitmap {
    val img: AndroidBitmap = BitmapFactory.decodeFile(file.path)
        ?: error("Could not decode image: ${file.path}")
    val w = img.width
    val h = img.height
    val bm = Bitmap(w, h)
    for (imgY in 0 until h) {
        val bmY = h - 1 - imgY // vertical flip, see doc comment above
        for (x in 0 until w) {
            val argb = img.getPixel(x, imgY)
            val a = (argb ushr 24) and 0xff
            val r = (argb ushr 16) and 0xff
            val g = (argb ushr 8) and 0xff
            val b = argb and 0xff
            // Treat fully-transparent pixels as white (background).
            val luma = if (a == 0) 255.0 else (0.299 * r + 0.587 * g + 0.114 * b)
            bm.set(x, bmY, luma < threshold * 255.0)
        }
    }
    img.recycle()
    return bm
}

// =============================================================================
// SVG output: renders the whole traced tree as a single <path> element
// using the default "nonzero" fill rule -- this works because `reverse()`
// above already wound negative (hole) paths in the opposite direction
// from their positive parents, exactly as potrace's own SVG backend
// relies on (see backend_svg.c's write_paths_transparent, grouping=0
// case). Traversal order matches write_paths_transparent_rec exactly.
// =============================================================================

private fun emitSubpath(sb: StringBuilder, curve: Curve) {
    val n = curve.n
    val p0 = curve.c[n - 1][2]
    sb.append("M ").append(fmt(p0.x)).append(' ').append(fmt(p0.y)).append(' ')
    for (i in 0 until n) {
        val c = curve.c[i]
        if (curve.tag[i] == CORNER) {
            sb.append("L ").append(fmt(c[1].x)).append(' ').append(fmt(c[1].y)).append(' ')
            sb.append("L ").append(fmt(c[2].x)).append(' ').append(fmt(c[2].y)).append(' ')
        } else {
            sb.append("C ")
                .append(fmt(c[0].x)).append(' ').append(fmt(c[0].y)).append(' ')
                .append(fmt(c[1].x)).append(' ').append(fmt(c[1].y)).append(' ')
                .append(fmt(c[2].x)).append(' ').append(fmt(c[2].y)).append(' ')
        }
    }
    sb.append("z ")
}

private fun fmt(v: Double): String {
    // Fixed-point, trimmed of trailing zeros -- keeps the SVG readable.
    // Locale.ROOT pins the decimal separator to '.' regardless of device
    // locale (a bare String.format would emit ',' on e.g. German/Arabic
    // devices and silently corrupt the SVG path data).
    val s = String.format(Locale.ROOT, "%.3f", v)
    return s.trimEnd('0').trimEnd('.')
}

/** Recursively emit p and its direct children, then descend into grandchildren -- see write_paths_transparent_rec. */
private fun emitTree(sb: StringBuilder, chain: PathObj?, height: Int) {
    var p = chain
    while (p != null) {
        emitSubpath(sb, flipCurveY(p.curve, height))
        var q = p.childlist
        while (q != null) {
            emitSubpath(sb, flipCurveY(q.curve, height))
            q = q.sibling
        }
        q = p.childlist
        while (q != null) {
            emitTree(sb, q.childlist, height)
            q = q.sibling
        }
        p = p.sibling
    }
}

/** Flip a curve's Y coordinates (height - y) to undo the internal
 *  bottom-up convention for on-screen (top-down) SVG output. Returns a
 *  new Curve; the traced data itself is left untouched. */
private fun flipCurveY(curve: Curve, height: Int): Curve {
    val out = Curve(curve.n)
    for (i in 0 until curve.n) {
        out.tag[i] = curve.tag[i]
        for (k in 0..2) out.c[i][k] = DPoint(curve.c[i][k].x, height - curve.c[i][k].y)
        out.vertex[i] = DPoint(curve.vertex[i].x, height - curve.vertex[i].y)
    }
    return out
}

/**
 * Word-wraps a stream of space-separated SVG path tokens to a maximum
 * column width, mirroring potrace's own `ship`/`shiptoken` line-wrapping
 * (see backend_svg.c) so the `d` attribute is spread across multiple
 * lines instead of one very long line. This only affects how the text is
 * laid out -- the tokens/coordinates themselves are untouched.
 */
private fun wrapTokens(tokens: String, startColumn: Int, maxColumn: Int = 75): String {
    val out = StringBuilder()
    var column = startColumn
    var atLineStart = true
    for (token in tokens.trim().split(Regex("\\s+"))) {
        if (token.isEmpty()) continue
        if (!atLineStart && column + token.length + 1 > maxColumn) {
            out.append('\n')
            column = 0
            atLineStart = true
        } else if (!atLineStart) {
            out.append(' ')
            column++
        }
        out.append(token)
        column += token.length
        atLineStart = false
    }
    return out.toString()
}

/**
 * Render a traced path tree as a complete, standalone SVG document
 * string. `fillColor` is any valid SVG color (e.g. "#000000" or "black").
 */
fun tracedTreeToSvg(tree: PathObj?, width: Int, height: Int, fillColor: String = "#000000"): String {
    val body = StringBuilder()
    emitTree(body, tree, height)

    return buildString {
        append("<?xml version=\"1.0\" standalone=\"no\"?>\n")
        append("<svg xmlns=\"http://www.w3.org/2000/svg\"\n")
        append(" width=\"$width\" height=\"$height\" viewBox=\"0 0 $width $height\">\n")
        val pathPrefix = "<path fill-rule=\"nonzero\" fill=\"$fillColor\" stroke=\"none\" d=\""
        append(pathPrefix)
        append(wrapTokens(body.toString(), pathPrefix.length))
        append("\"/>\n")
        append("</svg>\n")
    }
}

/** Convenience one-call wrapper: load an image file, trace it, return an SVG document string. */
fun traceImageToSvg(file: File, param: Params = Params(), threshold: Double = 0.5, fillColor: String = "#000000"): String {
    val bm = loadBitmap(file, threshold)
    val tree = potraceTrace(bm, param)
    return tracedTreeToSvg(tree, bm.w, bm.h, fillColor)
}

// =============================================================================
// MODE 2: image -> a real .pbm file on disk -> trace that file.
//
// This mirrors image2svg.kt's "mode 2" pipeline exactly: the same
// fixed-point grayscale formula Pillow's Image.convert('L') uses (so
// results match that pipeline byte-for-byte), the same threshold
// semantics, and the same PBM writer -- but the resulting .pbm is
// traced by the engine above instead of shelling out to an external
// `potrace` binary. Where `loadBitmap` above goes straight from image
// to Bitmap in memory ("mode 1"), this path always produces a real,
// inspectable intermediate .pbm file.
// =============================================================================

/** Pillow's `Image.convert('L')` luma, as a fixed-point Rec.601 formula (byte-for-byte match). */
private fun pillowLuma(r: Int, g: Int, b: Int): Int = (r * 19595 + g * 38470 + b * 7471) shr 16

/**
 * A plain single-channel 8-bit grayscale sample buffer, standing in for
 * `java.awt.image.BufferedImage.TYPE_BYTE_GRAY` + its `Raster` (Android has
 * no AWT, so there is no built-in single-channel image/raster type). Only
 * used internally by the mode-2 (PBM intermediate) pipeline below.
 */
class GrayImage(val w: Int, val h: Int) {
    val samples = IntArray(w * h)
    fun getSample(x: Int, y: Int): Int = samples[y * w + x]
    fun setSample(x: Int, y: Int, v: Int) { samples[y * w + x] = v }
}

/**
 * Grayscale-convert (Pillow-compatible) and threshold an image into a
 * binary (0/255) grayscale sample buffer. Pixels with luma > threshold
 * become background (255, white); darker pixels become foreground (0,
 * black) -- i.e. `threshold` is the brightness cutoff below which a
 * pixel gets traced. `invert` swaps the two afterward.
 *
 * (Android port of the BufferedImage/Raster version -- same formula,
 * same semantics, just reading pixels via AndroidBitmap.getPixel and
 * writing samples into a GrayImage instead of a Raster.)
 */
fun pillowGrayscaleThreshold(img: AndroidBitmap, threshold: Int, invert: Boolean = false): GrayImage {
    val out = GrayImage(img.width, img.height)
    for (y in 0 until img.height) {
        for (x in 0 until img.width) {
            val argb = img.getPixel(x, y)
            val r = (argb shr 16) and 0xFF
            val g = (argb shr 8) and 0xFF
            val b = argb and 0xFF
            val l = pillowLuma(r, g, b)
            var nv = if (l > threshold) 255 else 0
            if (invert) nv = 255 - nv
            out.setSample(x, y, nv)
        }
    }
    return out
}

/**
 * Write a grayscale image as a standard binary (P4) PBM file. Any
 * sample < 128 is written as a set bit ("black"/foreground); this
 * matches the NetPBM PBM convention (1 = black) as well as `Bitmap`'s
 * own convention (a `true` pixel is foreground/traced) -- so a value
 * already thresholded to exactly {0, 255} (e.g. by
 * `pillowGrayscaleThreshold`) round-trips through this writer and
 * `readPbmP4` without changing meaning.
 */
fun writePbmP4(img: GrayImage, path: String) {
    val w = img.w; val h = img.h
    val rowBytes = (w + 7) / 8
    File(path).outputStream().use { fos ->
        fos.write("P4\n$w $h\n".toByteArray(Charsets.US_ASCII))
        for (y in 0 until h) {
            val row = ByteArray(rowBytes)
            for (x in 0 until w) {
                if (img.getSample(x, y) < 128) {
                    row[x / 8] = (row[x / 8].toInt() or (0x80 ushr (x % 8))).toByte()
                }
            }
            fos.write(row)
        }
    }
}

/**
 * Read a binary (P4) PBM file into a Bitmap. Applies the same
 * top-to-bottom vertical flip as `loadBitmap` (internal row 0 is the
 * BOTTOM of the image, matching potrace's own convention -- see the
 * file-level doc comment) so a traced result looks identical regardless
 * of which loading path was used to get there.
 */
fun readPbmP4(path: String): Bitmap {
    File(path).inputStream().buffered().use { ins ->
        fun readToken(): String {
            val sb = StringBuilder()
            var c = ins.read()
            while (c == ' '.code || c == '\n'.code || c == '\r'.code || c == '\t'.code) c = ins.read()
            while (c != -1 && c != ' '.code && c != '\n'.code && c != '\r'.code && c != '\t'.code) {
                sb.append(c.toChar())
                c = ins.read()
            }
            return sb.toString()
        }

        val magic = readToken()
        require(magic == "P4") { "Not a binary (P4) PBM file: $path (got magic '$magic')" }
        val w = readToken().toInt()
        val h = readToken().toInt()
        // readToken() already consumed the single whitespace byte that
        // separates the header from the raw raster data.

        val rowBytes = (w + 7) / 8
        val bm = Bitmap(w, h)
        val rowBuf = ByteArray(rowBytes)
        for (imgY in 0 until h) {
            var off = 0
            while (off < rowBytes) {
                val n = ins.read(rowBuf, off, rowBytes - off)
                if (n < 0) error("Unexpected end of PBM data in $path")
                off += n
            }
            val bmY = h - 1 - imgY // vertical flip, see doc comment above
            for (x in 0 until w) {
                val byte = rowBuf[x / 8].toInt()
                val bit = (byte ushr (7 - (x % 8))) and 1
                bm.set(x, bmY, bit == 1)
            }
        }
        return bm
    }
}

/**
 * Mode 2, as a single call: convert `imageFile` to grayscale using the
 * exact fixed-point formula Pillow's `Image.convert('L')` uses,
 * threshold it, write the result to `pbmPath` as a real file, read that
 * file back in, and trace it. Returns the resulting SVG document
 * string; the .pbm file is left on disk (it's the point of this mode).
 *
 * @param threshold 0..255. Pixels with luma > threshold become
 *   background (white); darker pixels become foreground (traced).
 */
fun traceImageMode2(
    imageFile: File,
    pbmPath: String,
    threshold: Int = 128,
    invert: Boolean = false,
    param: Params = Params(),
    fillColor: String = "#000000"
): String {
    val img: AndroidBitmap = BitmapFactory.decodeFile(imageFile.path)
        ?: error("Could not decode image: ${imageFile.path}")
    val binary = pillowGrayscaleThreshold(img, threshold, invert)
    img.recycle()
    writePbmP4(binary, pbmPath)

    val bm = readPbmP4(pbmPath)
    val tree = potraceTrace(bm, param)
    return tracedTreeToSvg(tree, bm.w, bm.h, fillColor)
}

// =============================================================================
// ANDROID PORT NOTE: the original file ended with a `fun main(args: Array
// <String>)` CLI entry point (for `kotlin PotraceKt.jar --mode 1|2 ...` use
// from Colab/local use). An Android app has no argv and cannot call
// System.exit()-style termination mid-lifecycle, so that entry point is
// removed here; the app's ViewModel layer (see
// `com.vectorforge.app.data.ConvertViewModel`) calls `traceImageToSvg` /
// `traceImageMode2` directly instead, with parameters coming from the UI.
// Everything above this line -- every function, class and parameter the
// CLI used -- is unchanged and still fully available to call.
// =============================================================================

/** Counts the paths in a traced tree's flat sibling chain -- handy for status/progress UI. */
fun countTracedPaths(tree: PathObj?): Int {
    var count = 0
    var p = tree
    while (p != null) { count++; p = p.next }
    return count
}





