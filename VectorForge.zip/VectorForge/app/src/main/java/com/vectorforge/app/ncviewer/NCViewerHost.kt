package com.vectorforge.app.ncviewer

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.res.AssetManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.webkit.ConsoleMessage
import android.webkit.ServiceWorkerClient
import android.webkit.ServiceWorkerController
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.math.abs

private const val TAG = "NCViewer"

/**
 * =============================================================================
 * ANDROID PORT NOTE (VectorForge integration)
 * =============================================================================
 * This is NCViewerOffline's MainActivity.kt, unmodified in behaviour, restructured
 * from "IS an Activity that owns the whole screen" into "a controller a Compose
 * screen can embed and drive". Concretely:
 *
 *  - Was `class MainActivity : Activity()`; is now a plain class taking the host
 *    Activity (VectorForge's own MainActivity) as a constructor parameter. Every
 *    API it used from Activity (assets, getSharedPreferences, filesDir,
 *    runOnUiThread, startActivityForResult) is still called on that same host
 *    Activity, so behaviour is identical.
 *  - `onCreate`'s body is now the init block below, building [rootView] instead
 *    of calling `setContentView` (which would replace VectorForge's whole Compose
 *    UI). GcodeViewerScreen hosts [rootView] itself via Compose's AndroidView.
 *  - The original's own root-level window-insets padding is dropped: that was
 *    Activity-level "keep content clear of the status/nav bar" handling, which
 *    VectorForge's Scaffold (AppTopBar/AppBottomNav) already does for this tab's
 *    content area. Everything else -- WebView settings, the asset handler, split
 *    view, the floating "Open file" and split/single pills, the file chooser and
 *    diagnostics -- is untouched.
 *  - `onConfigurationChanged` is exposed as [onConfigurationChanged] for
 *    VectorForge's Activity to call, and `onActivityResult` as [onActivityResult],
 *    for the same reason: those are real Activity callbacks, so VectorForge's
 *    single Activity has to be the one the system calls, and it just forwards
 *    here.
 *
 * ADDED (not present in the original app): [sendGeneratedFile], used by the
 * Convert tab's "Generate -> Viewer" buttons to push a just-generated G-code
 * file straight into pane 1 or pane 2 the same way FileOpener loads a manually
 * picked file -- see its doc comment below.
 * =============================================================================
 */
class NCViewerHost(private val activity: Activity) {

    private val port = 8000 // preferred port = the one in the tested Termux command (see choosePort)
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private val fileChooserRequestCode = 51426

    // webView is the always-present top/primary pane; secondWebView exists only while splitMode is on
    // (bottom pane), so two G-code files can be open side by side for comparison. Both are plain,
    // independent WebView instances pointed at the same site — each keeps its own JS state, so loading
    // a different file into one never affects the other.
    private val webView: WebView
    private var secondWebView: WebView? = null
    private val webViews = mutableListOf<WebView>()
    private val pageReady = HashMap<WebView, Boolean>()

    // Each pane is a FrameLayout holding its WebView plus that pane's own "Open file" pill (FileOpener),
    // so in split view there is one pill in each window. The list is copy-on-write because
    // shouldInterceptRequest walks it on a WebView background thread.
    private val panes = HashMap<WebView, FrameLayout>()
    private val fileOpeners = java.util.concurrent.CopyOnWriteArrayList<FileOpener>()

    private val paneContainer: LinearLayout
    private val assetHandler: AppAssetHandler
    private val splitButton: TextView

    private var splitMode: Boolean

    /** The root View: pass this to Compose's `AndroidView(factory = { ncViewerHost.rootView })`. */
    val rootView: FrameLayout

    companion object {
        private const val USE_LOCAL_SERVER = false
        private const val PREFS = "ncviewer_prefs"
        private const val PREF_SPLIT_MODE = "split_mode"

        // The embedded server must be started once per process, not once per NCViewerHost instance.
        private val serverLock = Any()
        @Volatile private var serverPort = 0
    }

    @SuppressLint("SetJavaScriptEnabled")
    init {
        // Lets a PC's Chrome (chrome://inspect/#devices) attach a full DevTools
        // console+network panel to this exact WebView over USB.
        WebView.setWebContentsDebuggingEnabled(true)

        assetHandler = AppAssetHandler(activity.assets)

        val prefs = activity.getSharedPreferences(PREFS, Activity.MODE_PRIVATE)
        splitMode = prefs.getBoolean(PREF_SPLIT_MODE, false)

        if (!USE_LOCAL_SERVER) {
            // Requests made by a service worker do not pass through WebViewClient, so route them here too.
            try {
                ServiceWorkerController.getInstance().setServiceWorkerClient(object : ServiceWorkerClient() {
                    override fun shouldInterceptRequest(request: WebResourceRequest?): WebResourceResponse? =
                        if (request != null) assetHandler.handle(request) else null
                })
            } catch (e: Exception) {
                Log.w(TAG, "service worker interception unavailable: ${e.message}")
            }
        }

        webView = createWebView()
        webViews.add(webView)

        splitButton = makeToggleButton(::splitLabel, "Switch between split and single view") { toggleSplit() }

        paneContainer = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL }

        rootView = FrameLayout(activity)
        rootView.addView(
            paneContainer,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        rootView.addView(
            splitButton,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.END
            ).apply { setMargins(0, 0, dp(12), dp(12)) }
        )

        rebuildPanes() // lays out webView (+ secondWebView if splitMode was restored from prefs)

        // Serve.kt (unmodified) reads from a real filesystem directory via java.io.File, same as it did
        // under Termux — it has no idea it's inside an APK. Kept only behind USE_LOCAL_SERVER as a fallback;
        // the default path below (AppAssetHandler) needs no directory extraction and no socket at all.
        if (USE_LOCAL_SERVER) {
            val siteDir = File(activity.filesDir, "ncviewer-offline")
            // Everything here touches disk or a socket, so it all runs off the main thread —
            // a raw Socket().connect() call in waitForPort(), even to 127.0.0.1, throws
            // NetworkOnMainThreadException if done directly here. Only the final
            // loadUrl() needs to be back on the main thread, since WebView isn't thread-safe.
            Thread {
                // Started once per process. If the Activity is ever re-created (system-initiated), reuse the
                // running server instead of starting a second one on another port (which would also change
                // the page's origin and lose its localStorage).
                val servePort = synchronized(serverLock) {
                    if (serverPort == 0) {
                        extractAssetDir(activity.assets, "www", siteDir)

                        val problem = verifySite(siteDir)
                        if (problem != null) {
                            Log.e(TAG, problem)
                            activity.runOnUiThread { showAlert("Site files missing", problem) }
                        }

                        val chosen = choosePort(port)
                        Log.d(TAG, "Serve.kt main(folder=${siteDir.absolutePath}, port=$chosen)")
                        Thread {
                            main(arrayOf(siteDir.absolutePath, chosen.toString()))
                        }.apply { isDaemon = true }.start()
                        waitForPort(chosen)
                        serverPort = chosen
                    }
                    serverPort
                }
                activity.runOnUiThread { webViews.forEach { it.loadUrl("http://127.0.0.1:$servePort/") } }
            }.start()
        } else {
            // No server, no port: AppAssetHandler answers each WebView's requests from assets/www.
            val problem = verifyBundledSite()
            if (problem != null) {
                Log.e(TAG, problem)
                showAlert("Site files missing", problem)
            }
            webViews.forEach { it.loadUrl("${AppAssetHandler.ORIGIN}/") }
        }
    }

    private fun showAlert(title: String, message: String) {
        android.app.AlertDialog.Builder(activity)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("OK", null)
            .show()
    }

    // ---------------------------------------------------------------- WebView construction

    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView(): WebView {
        val wv = WebView(activity)
        val settings = wv.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        @Suppress("DEPRECATION")
        settings.databaseEnabled = true
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true
        settings.textZoom = 100
        settings.builtInZoomControls = true
        settings.displayZoomControls = false
        // used by the "Open file" pill to report back (must be registered before the first page load)
        wv.addJavascriptInterface(NCVNativeBridge(activity), "NCVNative")
        pageReady[wv] = false
        wv.webViewClient = buildWebViewClient()
        wv.webChromeClient = buildWebChromeClient()
        return wv
    }

    private fun buildWebViewClient(): WebViewClient = object : WebViewClient() {
        // Answers every request to https://appassets.androidplatform.net/ from the APK's assets
        // (runs on a WebView background thread). Any other host returns null = normal network.
        override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
            if (request == null) return null
            for (opener in fileOpeners) opener.intercept(request)?.let { return it } // file picked with "Open file"
            if (USE_LOCAL_SERVER) return null
            return assetHandler.handle(request)
        }

        override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
            super.onPageStarted(view, url, favicon)
            if (view != null) pageReady[view] = false
        }

        override fun onPageFinished(view: WebView?, url: String?) {
            super.onPageFinished(view, url)
            if (view != null) pageReady[view] = true
            val js = """
                (function(){
                  var hamburger = document.querySelector('.hamburger,.menu-icon,.navbar-toggler,[class*="menu"]');
                  var social = document.querySelector('[class*="social"] svg, [class*="social"] img, header svg, header img');
                  function box(el){ if(!el) return 'not found'; var r = el.getBoundingClientRect(); return Math.round(r.width)+'x'+Math.round(r.height); }
                  return 'innerWidth: ' + window.innerWidth + '\n' +
                         'innerHeight: ' + window.innerHeight + '\n' +
                         'devicePixelRatio: ' + window.devicePixelRatio + '\n' +
                         'documentElement.clientWidth: ' + document.documentElement.clientWidth + '\n' +
                         'documentElement.clientHeight: ' + document.documentElement.clientHeight + '\n' +
                         'visualViewport.scale: ' + (window.visualViewport ? window.visualViewport.scale : 'n/a') + '\n' +
                         'fonts.status: ' + (document.fonts ? document.fonts.status : 'n/a') + '\n' +
                         'serviceWorker supported: ' + (!!navigator.serviceWorker) + '\n' +
                         'serviceWorker controller: ' + (navigator.serviceWorker && navigator.serviceWorker.controller ? navigator.serviceWorker.controller.scriptURL : 'none (not controlled yet)') + '\n' +
                         'hamburger element: ' + (hamburger ? box(hamburger) : 'not found') + '\n' +
                         'first header icon box: ' + box(social) + '\n' +
                         'userAgent: ' + navigator.userAgent;
                })();
            """.trimIndent()
            view?.evaluateJavascript(js) { result ->
                val decoded = result?.trim('"')?.replace("\\n", "\n")?.replace("\\\"", "\"") ?: "null"
                Log.d(TAG, "diagnostics:\n$decoded")
            }
        }

        override fun onReceivedError(
            view: WebView?,
            request: WebResourceRequest?,
            error: WebResourceError?
        ) {
            Log.e(TAG, "onReceivedError url=${request?.url} error=${error?.description}")
        }

        @Suppress("DEPRECATION")
        override fun onReceivedError(
            view: WebView?,
            errorCode: Int,
            description: String?,
            failingUrl: String?
        ) {
            Log.e(TAG, "onReceivedError(legacy) url=$failingUrl code=$errorCode desc=$description")
        }

        override fun onReceivedHttpError(
            view: WebView?,
            request: WebResourceRequest?,
            errorResponse: WebResourceResponse?
        ) {
            Log.e(TAG, "onReceivedHttpError url=${request?.url} status=${errorResponse?.statusCode}")
        }
    }

    private fun buildWebChromeClient(): WebChromeClient = object : WebChromeClient() {
        override fun onConsoleMessage(message: ConsoleMessage?): Boolean {
            Log.d(TAG, "console: ${message?.message()} (${message?.sourceId()}:${message?.lineNumber()})")
            return true
        }

        override fun onShowFileChooser(
            view: WebView?,
            callback: ValueCallback<Array<Uri>>?,
            params: FileChooserParams?
        ): Boolean {
            filePathCallback?.onReceiveValue(null)
            filePathCallback = callback
            val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
            }
            return try {
                @Suppress("DEPRECATION")
                activity.startActivityForResult(Intent.createChooser(intent, "Select a file"), fileChooserRequestCode)
                true
            } catch (e: Exception) {
                filePathCallback = null
                false
            }
        }
    }

    private fun dp(v: Int): Int = (v * activity.resources.displayMetrics.density).toInt()

    // ---------------------------------------------------------------- split / single view

    private fun splitLabel(): String = if (splitMode) "Split view" else "Single view"

    /** [currentSiteUrl] is what any newly created pane should load — same URL either serving mode uses. */
    private fun currentSiteUrl(): String? =
        if (USE_LOCAL_SERVER) {
            if (serverPort != 0) "http://127.0.0.1:$serverPort/" else null
        } else {
            "${AppAssetHandler.ORIGIN}/"
        }

    private fun toggleSplit() {
        setSplitMode(!splitMode, announce = true)
    }

    /**
     * Sets split view on/off, exactly like tapping the pill would, minus the toast when
     * [announce] is false (used by [sendGeneratedFile], which shouldn't talk over itself).
     */
    private fun setSplitMode(enabled: Boolean, announce: Boolean) {
        if (splitMode == enabled) return
        splitMode = enabled
        activity.getSharedPreferences(PREFS, Activity.MODE_PRIVATE).edit().putBoolean(PREF_SPLIT_MODE, splitMode).apply()
        splitButton.text = splitLabel()
        if (announce) {
            Toast.makeText(
                activity,
                if (splitMode) "Split view: compare two G-code files" else "Single view",
                Toast.LENGTH_SHORT
            ).show()
        }
        rebuildPanes()
    }

    /**
     * Lays paneContainer out as either one full-height pane (webView) or two equal panes stacked
     * top/bottom with a thin divider between them, matching splitMode. Creating the second pane the
     * first time it's needed loads it fresh; toggling back to single view keeps it around (paused, not
     * destroyed) so its own open file and scroll position are still there if the user splits again.
     */
    private fun rebuildPanes() {
        paneContainer.removeAllViews()

        paneContainer.addView(paneFor(webView, 0), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        if (splitMode) {
            val bottom: WebView = secondWebView ?: createWebView().also { created ->
                secondWebView = created
                webViews.add(created)
                currentSiteUrl()?.let { created.loadUrl(it) }
            }
            paneContainer.addView(buildDivider(), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(2)))
            paneContainer.addView(paneFor(bottom, 1), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }

        // the panes changed size, so put every "Open file" pill back in its corner
        fileOpeners.forEach { it.resetPosition() }
    }

    /**
     * The FrameLayout for [wv]: the WebView filling it, plus its own "Open file" pill at the bottom-left.
     * Created once per WebView and reused, so toggling split/single keeps each pane (and its open file) alive.
     * [id] is 0 for the top pane and 1 for the bottom pane.
     */
    private fun paneFor(wv: WebView, id: Int): FrameLayout = panes.getOrPut(wv) {
        FrameLayout(activity).also { pane ->
            pane.addView(wv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            fileOpeners.add(FileOpener(activity, wv, pane, id))
        }
    }

    private fun buildDivider(): View = View(activity).apply {
        setBackgroundColor(Color.rgb(60, 63, 68))
    }

    // ---------------------------------------------------------------- floating buttons

    /** Small translucent pill: tap = run [onTap], drag = move it out of the way. Reused for each toggle. */
    private fun makeToggleButton(label: () -> String, contentDesc: String, onTap: () -> Unit): TextView =
        TextView(activity).apply {
            text = label()
            textSize = 13f
            setTextColor(Color.WHITE)
            setPadding(dp(14), dp(8), dp(14), dp(8))
            background = GradientDrawable().apply {
                setColor(Color.argb(204, 32, 33, 36))
                cornerRadius = dp(20).toFloat()
            }
            alpha = 0.85f
            elevation = dp(6).toFloat()
            contentDescription = contentDesc

            val slop = ViewConfiguration.get(activity).scaledTouchSlop.toFloat()
            var downX = 0f
            var downY = 0f
            var startX = 0f
            var startY = 0f
            var dragging = false
            setOnTouchListener { v, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = e.rawX
                        downY = e.rawY
                        startX = v.translationX
                        startY = v.translationY
                        dragging = false
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - downX
                        val dy = e.rawY - downY
                        if (!dragging && (abs(dx) > slop || abs(dy) > slop)) dragging = true
                        if (dragging) {
                            v.translationX = startX + dx
                            v.translationY = startY + dy
                        }
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!dragging) onTap()
                        true
                    }
                    else -> false
                }
            }
        }

    /** Call from VectorForge's Activity.onConfigurationChanged. */
    fun onConfigurationChanged() {
        // after a rotation a dragged position may be off-screen, so snap the buttons back
        splitButton.translationX = 0f
        splitButton.translationY = 0f
        fileOpeners.forEach { it.resetPosition() }
    }

    /** Call from VectorForge's Activity.onActivityResult; returns true if this handled it. */
    @Suppress("DEPRECATION")
    fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?): Boolean {
        // result of an "Open file" pill (each pane has its own request code)
        if (fileOpeners.any { it.onActivityResult(requestCode, resultCode, data) }) return true
        if (requestCode == fileChooserRequestCode) {
            val callback = filePathCallback
            filePathCallback = null
            if (callback == null) return true
            val results: Array<Uri>? = if (resultCode == Activity.RESULT_OK && data != null) {
                val clipData = data.clipData
                val dataUri = data.data
                when {
                    clipData != null -> Array(clipData.itemCount) { i -> clipData.getItemAt(i).uri }
                    dataUri != null -> arrayOf(dataUri)
                    else -> null
                }
            } else null
            callback.onReceiveValue(results)
            return true
        }
        return false
    }

    // ---------------------------------------------------------------- Convert tab integration (added)

    /**
     * ADDED for VectorForge. Pushes [file] into pane [paneId] (0 = top/primary, 1 = bottom/secondary)
     * exactly as if its own "Open file" pill had been used and [mode] ("replace" or "append") chosen
     * from the resulting dialog — same JS bridge, same PLOT trigger, no picker and no dialog since the
     * caller already decided both.
     *
     * Requesting pane 1 turns split view on first (creating that pane if this is the first time), and
     * requesting pane 0 turns split view off, matching the Convert screen's "tab 1 / no split" vs
     * "tab 2 / with split" buttons. If the target pane's page hasn't finished its own load yet (only
     * realistically possible the very first time pane 1 is created), this waits for it rather than
     * risking a silent no-op.
     */
    fun sendGeneratedFile(file: File, paneId: Int, mode: String) {
        setSplitMode(enabled = paneId == 1, announce = false)
        waitForPaneThen(paneId) {
            val opener = fileOpeners.firstOrNull { it.id == paneId } ?: return@waitForPaneThen
            opener.loadFile(Uri.fromFile(file), mode)
        }
    }

    private fun waitForPaneThen(paneId: Int, timeoutMs: Long = 6000, action: () -> Unit) {
        val handler = Handler(Looper.getMainLooper())
        val deadline = System.currentTimeMillis() + timeoutMs
        fun attempt() {
            val wv = webViews.getOrNull(paneId)
            if (wv != null && pageReady[wv] == true) {
                action()
            } else if (System.currentTimeMillis() < deadline) {
                handler.postDelayed(::attempt, 50)
            } else {
                Log.w(TAG, "sendGeneratedFile: pane $paneId did not finish loading within ${timeoutMs}ms; sending anyway")
                action()
            }
        }
        attempt()
    }

    // ---------------------------------------------------------------- Serve.kt fallback plumbing

    /**
     * Recursively copies assets/<assetPath> onto real disk at destDir, so Serve.kt's
     * plain java.io.File-based server can read it exactly as it did under Termux.
     * AssetManager.list() can't tell a file from an empty directory by itself, so this
     * tries open() first and falls back to treating it as a directory.
     */
    private fun extractAssetDir(assetManager: AssetManager, assetPath: String, destDir: File) {
        val children = assetManager.list(assetPath)
        if (children == null || children.isEmpty()) {
            try {
                assetManager.open(assetPath).use { input ->
                    destDir.parentFile?.mkdirs()
                    FileOutputStream(destDir).use { output -> input.copyTo(output) }
                }
            } catch (e: IOException) {
                destDir.mkdirs() // was actually an empty directory
            }
        } else {
            destDir.mkdirs()
            for (child in children) {
                extractAssetDir(assetManager, "$assetPath/$child", File(destDir, child))
            }
        }
    }

    /**
     * Returns null if siteDir looks like the real site root (index.html plus .js files under _nuxt), otherwise a
     * human-readable description of what is missing. Also logs the facts (tag NCViewer).
     */
    private fun verifySite(siteDir: File): String? {
        val hasIndex = File(siteDir, "index.html").isFile
        val jsCount = File(siteDir, "_nuxt").walkTopDown().count { it.isFile && it.extension == "js" }
        Log.d(TAG, "site root=${siteDir.absolutePath} index.html=$hasIndex _nuxt/*.js files=$jsCount " +
            "top-level=${siteDir.list()?.sorted()}")
        return when {
            !hasIndex -> "index.html is missing in ${siteDir.absolutePath}"
            jsCount == 0 -> "index.html is there but ${siteDir.absolutePath}/_nuxt contains no .js files. " +
                "The APK was built without www/_nuxt (check androidResources.ignoreAssetsPattern in app/build.gradle.kts)."
            else -> null
        }
    }

    /** Null if the APK really contains index.html and the site's .js files, otherwise what is missing. */
    private fun verifyBundledSite(): String? {
        val root = activity.assets.list("www")?.toList() ?: emptyList()
        val hasNuxtJs = activity.assets.list("www/_nuxt")?.any { it.endsWith(".js") } == true
        Log.d(TAG, "bundled site: www=$root _nuxt has .js=$hasNuxtJs")
        return when {
            "index.html" !in root -> "index.html is missing from the APK's assets/www."
            !hasNuxtJs -> "index.html is there but assets/www/_nuxt has no .js files. " +
                "The APK was built without www/_nuxt (check androidResources.ignoreAssetsPattern in app/build.gradle.kts)."
            else -> null
        }
    }

    /** [preferred] if it can be bound right now, otherwise any free port. */
    private fun choosePort(preferred: Int): Int = try {
        java.net.ServerSocket().use { s ->
            s.reuseAddress = true
            s.bind(InetSocketAddress("0.0.0.0", preferred))
        }
        preferred
    } catch (e: IOException) {
        val free = java.net.ServerSocket(0).use { it.localPort }
        Log.w(TAG, "port $preferred is busy (${e.message}); using $free instead")
        free
    }

    /** Polls 127.0.0.1:port until a TCP connection succeeds, so loadUrl() never races main(). */
    private fun waitForPort(port: Int, timeoutMs: Long = 5000) {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            try {
                Socket().use { it.connect(InetSocketAddress("127.0.0.1", port), 200) }
                return
            } catch (e: IOException) {
                Thread.sleep(20)
            }
        }
        Log.e(TAG, "waitForPort: server did not come up on port $port within ${timeoutMs}ms")
    }
}
