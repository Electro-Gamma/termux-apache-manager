package com.vectorforge.app.data

import com.vectorforge.app.engine.potrace.TurnPolicy
import java.io.File

/** "Trace Strategy" segmented control -- Mode 1 (direct) vs Mode 2 (PBM intermediate). */
enum class TraceMode { MODE_1_DIRECT, MODE_2_PBM }

/**
 * The "TURN POLICY" dropdown's seven options, in the exact order shown in
 * the reference, each carrying the [TurnPolicy] int constant Potrace.kt
 * actually expects.
 */
enum class TurnPolicyOption(val label: String, val value: Int) {
    MINORITY("Minority (Default)", TurnPolicy.MINORITY),
    BLACK("Black", TurnPolicy.BLACK),
    WHITE("White", TurnPolicy.WHITE),
    LEFT("Left", TurnPolicy.LEFT),
    RIGHT("Right", TurnPolicy.RIGHT),
    MAJORITY("Majority", TurnPolicy.MAJORITY),
    RANDOM("Random", TurnPolicy.RANDOM);

    companion object {
        fun fromValue(value: Int): TurnPolicyOption = entries.first { it.value == value }
    }
}

/**
 * Where a freshly generated G-code file goes once it has been written, chosen by which of the three
 * generate buttons was pressed:
 *  - [NONE]            "Generate"                      -- just write the file, touch no viewer.
 *  - [VIEWER_1]        "Generate + Viewer 1"           -- load it into the G-Code Viewer, single view (no split).
 *  - [VIEWER_2_SPLIT]  "Generate + Viewer 2 (Split)"   -- load it into the G-Code Viewer's second pane, split view.
 */
enum class ViewerTarget { NONE, VIEWER_1, VIEWER_2_SPLIT }

/** "G-code file [gcodeFile] was just generated -- open it in [target]." Emitted by ConvertViewModel, consumed by MainActivity. */
data class ViewerRequest(val gcodeFile: File, val target: ViewerTarget)
