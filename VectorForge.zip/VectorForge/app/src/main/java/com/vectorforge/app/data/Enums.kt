package com.vectorforge.app.data

import com.vectorforge.app.engine.potrace.TurnPolicy

/** "Trace Strategy" segmented control -- Mode 1 (direct) vs Mode 2 (PBM intermediate). */
enum class TraceMode { MODE_1_DIRECT, MODE_2_PBM }

/**
 * The "TURN POLICY" dropdown's seven options, in the exact order shown in
 * the reference, each carrying the [TurnPolicy] int constant Potrace.kt
 * actually expects.
 */
enum class TurnPolicyOption(val label: String, val value: Int) {
    MINORITY("Minority (Default)", TurnPolicy.MINORITY),
    BLACK("Black", TurnPolicy.BLACK),
    WHITE("White", TurnPolicy.WHITE),
    LEFT("Left", TurnPolicy.LEFT),
    RIGHT("Right", TurnPolicy.RIGHT),
    MAJORITY("Majority", TurnPolicy.MAJORITY),
    RANDOM("Random", TurnPolicy.RANDOM);

    companion object {
        fun fromValue(value: Int): TurnPolicyOption = entries.first { it.value == value }
    }
}
