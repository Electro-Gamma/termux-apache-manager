package com.vectorforge.app.ui.theme

import android.content.Context

/**
 * Remembers the Light / Dark choice across launches.
 *
 * Uses plain SharedPreferences, the same mechanism the app already uses for the viewer's single/split mode
 * (NcViewerController, "ncviewer_prefs"), so no new dependency is needed.
 *
 * Dark is the default: it is the look the app always had, so nothing changes until the switch is used.
 */
object ThemePreference {
    private const val PREFS = "vectorforge_prefs"
    private const val KEY_DARK_THEME = "dark_theme"

    fun isDark(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_DARK_THEME, true)

    fun setDark(context: Context, dark: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_DARK_THEME, dark).apply()
    }
}
