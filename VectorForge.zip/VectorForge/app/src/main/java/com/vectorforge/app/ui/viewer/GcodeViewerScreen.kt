package com.vectorforge.app.ui.viewer

import android.view.ViewGroup
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.vectorforge.app.ncviewer.NcViewerController

/**
 * Tab 2: the G-Code Viewer. It hosts the complete NC Viewer Offline app -- same bundled web app, same
 * single/split layout, same "Open file" pills, same behaviour (see [NcViewerController]).
 *
 * The controller (and the WebViews inside it) outlives this composable, so whatever is loaded in the viewer
 * is still there after switching to the Convert tab and back. Each time the tab is shown its persistent root
 * view is simply re-attached; it is first detached from the previous, now-disposed, AndroidView holder.
 *
 * The remote control (the "Post-process" pill and its overlay) lives inside the viewer itself, made of the same
 * pills as NC Viewer. It needs nothing from the rest of the app: it only moves and rotates, with no limits.
 */
@Composable
fun GcodeViewerScreen(
    controller: NcViewerController,
    modifier: Modifier = Modifier,
) {
    AndroidView(
        modifier = modifier.fillMaxSize(),
        factory = {
            controller.rootView.also { root ->
                (root.parent as? ViewGroup)?.removeView(root)
            }
        },
    )
}
