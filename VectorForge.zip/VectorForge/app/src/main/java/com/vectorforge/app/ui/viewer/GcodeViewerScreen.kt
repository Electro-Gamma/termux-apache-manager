package com.vectorforge.app.ui.viewer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

/**
 * Tab 2, exactly as specified: the tab exists, has its navigation entry
 * (see AppBottomNav) and picks up the app theme, and its content area is
 * otherwise completely empty. No viewer, editor, canvas, file picker,
 * zoom/pan controls, placeholder text, or anything else is implemented
 * here yet -- this is reserved for a future G-code viewer/editor.
 */
@Composable
fun GcodeViewerScreen(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.surface)
    )
}
