package com.vectorforge.app.ui.viewer

import android.view.ViewGroup
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.vectorforge.app.ncviewer.NcViewerController

/**
 * Tab 2: the G-Code Viewer. It hosts the complete NC Viewer Offline app -- same bundled web app, same
 * single/split layout, same "Open file" pills, same behaviour (see [NcViewerController]).
 *
 * The controller (and the WebViews inside it) outlives this composable, so whatever is loaded in the viewer
 * is still there after switching to the Convert tab and back. Each time the tab is shown its persistent root
 * view is simply re-attached; it is first detached from the previous, now-disposed, AndroidView holder.
 *
 * The "Post-process" pill inside the viewer opens [PostProcessPanel] below it: live post-processing of the G-code
 * the viewer shows, with a Save button. The panel sits below the viewer (rather than over it) so it never covers
 * NC Viewer's own pills.
 */
@Composable
fun GcodeViewerScreen(
    controller: NcViewerController,
    modifier: Modifier = Modifier,
) {
    val post = controller.postProcess

    // "Save As" for the post-processed G-code: the same system dialog and MIME type the Convert screen's export uses.
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        uri?.let(post::saveTo)
    }

    Column(modifier = modifier.fillMaxSize()) {
        AndroidView(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            factory = {
                controller.rootView.also { root ->
                    (root.parent as? ViewGroup)?.removeView(root)
                }
            },
        )
        if (post.isOpen) {
            PostProcessPanel(
                post = post,
                onSave = { saveLauncher.launch(post.suggestedFileName()) },
                modifier = Modifier
                    .fillMaxWidth()
                    .imePadding(),
            )
        }
    }
}
