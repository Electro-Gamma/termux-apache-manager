package com.vectorforge.app.ui.viewer

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.vectorforge.app.ncviewer.NCViewerHost

/**
 * Tab 2: hosts NCViewerOffline's own UI (its WebView pane(s), the split/single-view pill, and each
 * pane's "Open file" pill) exactly as that app renders it -- see NCViewerHost's doc comment for what
 * had to change structurally to embed it here versus running it as its own Activity, and
 * FileOpener/AppAssetHandler/Serve.kt for the rest, which are otherwise unmodified.
 *
 * [ncViewerHost] is created once by MainActivity and handed down, not created here: its WebViews
 * must survive this composable leaving composition (switching back to the Convert tab), since the
 * Convert tab's "Generate -> Viewer" buttons can push a new file in while this tab isn't the one on
 * screen. AndroidView's factory therefore returns that same already-built root view every time this
 * composable (re)enters composition, rather than building a new one.
 */
@Composable
fun GcodeViewerScreen(ncViewerHost: NCViewerHost, modifier: Modifier = Modifier) {
    AndroidView(
        modifier = modifier.fillMaxSize(),
        factory = { ncViewerHost.rootView },
    )
}
