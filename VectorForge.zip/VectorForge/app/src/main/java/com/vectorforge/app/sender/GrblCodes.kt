package com.vectorforge.app.sender

/** Human-readable texts for GRBL's `error:N` and `ALARM:N` replies (from GRBL's public documentation). */
object GrblCodes {
    private val errors = mapOf(
        1 to "G-code letter expected",
        2 to "Bad number format",
        3 to "Invalid \$ statement",
        4 to "Negative value not allowed",
        5 to "Homing cycle is not enabled (\$22)",
        6 to "Minimum step pulse must be at least 3 us",
        7 to "EEPROM read failed",
        8 to "\$ command only works while the machine is idle",
        9 to "G-code is locked out during alarm or jog (try Unlock)",
        10 to "Soft limits need homing enabled",
        11 to "Line is too long",
        12 to "\$ setting exceeds the maximum step rate",
        13 to "Safety door detected as opened",
        14 to "Startup line is too long for EEPROM",
        15 to "Jog target exceeds machine travel",
        16 to "Jog command is missing '=' or has a prohibited G-code",
        17 to "Laser mode needs a PWM spindle output",
        20 to "Unsupported or invalid G-code command",
        21 to "More than one command from the same modal group",
        22 to "Feed rate not set yet",
        23 to "G-code command needs an integer value",
        24 to "Two commands both need axis words",
        25 to "A G-code word is repeated",
        26 to "Command needs axis words",
        27 to "Invalid line number",
        28 to "Command is missing a required value word",
        29 to "G59.x work coordinate systems are not supported",
        30 to "G53 is only valid with G0 and G1",
        31 to "Axis words present but no command uses them",
        32 to "Arc needs at least one in-plane axis word",
        33 to "Motion target is invalid",
        34 to "Arc radius is invalid",
        35 to "Arc needs at least one in-plane offset word",
        36 to "Unused value words found in the block",
        37 to "G43.1 offset not assigned to the tool length axis",
        38 to "Tool number is higher than supported",
    )

    private val alarms = mapOf(
        1 to "Hard limit triggered. Position is probably lost: re-home",
        2 to "Soft limit: the target is outside the machine travel",
        3 to "Reset while moving. Position may be lost: re-home",
        4 to "Probe fail: not in the expected start state",
        5 to "Probe fail: no contact within travel",
        6 to "Homing fail: reset during the homing cycle",
        7 to "Homing fail: safety door opened",
        8 to "Homing fail: pull-off did not clear the limit switch",
        9 to "Homing fail: limit switch not found",
    )

    private val number = Regex("""(\d+)""")

    /** "error:20" -> "error:20 - Unsupported or invalid G-code command". Other text is returned unchanged. */
    fun explain(line: String): String {
        val lower = line.lowercase()
        val table = when {
            lower.startsWith("error") -> errors
            lower.startsWith("alarm") -> alarms
            else -> return line
        }
        val code = number.find(line)?.groupValues?.get(1)?.toIntOrNull() ?: return line
        val text = table[code] ?: return line
        return "$line - $text"
    }
}
