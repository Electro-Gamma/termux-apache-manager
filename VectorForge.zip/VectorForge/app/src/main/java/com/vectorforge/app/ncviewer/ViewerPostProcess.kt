package com.vectorforge.app.ncviewer

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.widget.Toast
import com.vectorforge.app.engine.gcode.transform.OrientationPlacer
import com.vectorforge.app.engine.gcode.transform.formatNumber
import java.io.File
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

private const val TAG = "NCViewer"

/** After a change, wait this long before re-processing; changes that arrive in the meantime are merged into one render. */
private const val RENDER_DELAY_MS = 60L

private val STEP_CHOICES_MM = doubleArrayOf(0.1, 0.5, 1.0, 5.0, 10.0)
private val ANGLE_CHOICES_DEG = doubleArrayOf(1.0, 5.0, 15.0, 45.0, 90.0)

/**
 * The remote control for the G-Code Viewer: move and rotate the G-code in NC Viewer and see it change live, then save it.
 *
 * It is a small state machine over three numbers, always applied to the ORIGINAL G-code (the "base"):
 *   - [angle]   how far the drawing is turned (counter-clockwise positive),
 *   - centre X / Y where the drawing's bounding box is centred.
 * Every button changes one of those and asks for a render. A render ([OrientationPlacer.place]) rotates the base
 * about its own centre and centres it on the requested point, and nothing else: there are no limits, no clamping and
 * no scaling, so the drawing can be moved any distance in any direction (whatever range the G-code has) and turned
 * to any angle, and its size and handedness never change. The result goes into the viewer's editor and is plotted,
 * exactly like opening a file.
 *
 * All methods must be called on the main thread; [onChanged] runs on the main thread after every visible change.
 */
class ViewerPostProcess(
    private val context: Context,
    /** The pane's FileOpener (0 = top / Viewer 1, 1 = bottom / Viewer 2), or null if that pane does not exist. */
    private val openerFor: (pane: Int) -> FileOpener?,
) {
    // ---- what the remote shows ----
    var visible = false
        private set
    var pane = 0
        private set
    var splitMode = false
    var status = ""
        private set
    var stepMm = 1.0
        private set
    var stepAngleDeg = 5.0
        private set

    /** True once a snapshot with a toolpath exists; until then the movement buttons do nothing. */
    val ready: Boolean get() = placer != null

    /** Called (on the main thread) whenever something the remote displays changed. */
    var onChanged: (() -> Unit)? = null

    // ---- session ----
    private val main = Handler(Looper.getMainLooper())
    private val worker: ExecutorService = Executors.newSingleThreadExecutor()
    private var placer: OrientationPlacer? = null
    private var baseName = "viewer.gcode"
    private var shownText: String? = null

    private var angle = 0.0
    private var cx = 0.0
    private var cy = 0.0

    private var session = 0            // bumped to invalidate in-flight work (new snapshot, close, ...)
    private var renderScheduled = false
    private var renderInFlight = false
    private var renderAgain = false
    private val renderRunnable = Runnable {
        renderScheduled = false
        startRender()
    }

    // ------------------------------------------------------------------ show / hide

    fun toggle() = if (visible) close() else show()

    private fun show() {
        visible = true
        if (!splitMode) pane = 0
        capture()
        changed()
    }

    /** Hides the remote. The viewer keeps showing whatever it shows now. */
    fun close() {
        visible = false
        invalidate()
        changed()
    }

    /**
     * The viewer's content was replaced from outside (a generated file, a picked file): the snapshot is stale, so the
     * remote closes rather than let its next move overwrite the new file with an old base.
     */
    fun dismissBecauseViewerChanged() {
        if (visible) close()
    }

    /** Called when single / split view is switched. */
    fun onSplitChanged(split: Boolean) {
        splitMode = split
        if (visible && !split && pane != 0) {
            pane = 0
            capture()
        }
        changed()
    }

    fun shutdown() {
        invalidate()
        worker.shutdownNow()
    }

    /** Split view only: which of the two viewers the remote controls. */
    fun cycleTarget() {
        if (!splitMode) return
        pane = if (pane == 0) 1 else 0
        capture()
        changed()
    }

    fun cycleStep() {
        stepMm = next(STEP_CHOICES_MM, stepMm)
        changed()
    }

    fun cycleAngle() {
        stepAngleDeg = next(ANGLE_CHOICES_DEG, stepAngleDeg)
        changed()
    }

    private fun next(choices: DoubleArray, current: Double): Double {
        val i = choices.indexOfFirst { it == current }
        return choices[(i + 1) % choices.size]
    }

    // ------------------------------------------------------------------ snapshot

    /** Reads the target viewer's current G-code as the new base and puts the drawing back to "not moved, not turned". */
    private fun capture() {
        invalidate()
        placer = null
        shownText = null
        val opener = openerFor(pane)
        if (opener == null) {
            setStatus("This viewer is not available")
            return
        }
        setStatus("Reading Viewer ${pane + 1}\u2026")
        val mySession = session
        opener.readEditorText { text ->
            if (mySession != session) return@readEditorText // the user moved on
            if (text == null) {
                setStatus("Viewer ${pane + 1} has no G-code yet")
                return@readEditorText
            }
            baseName = text.name
            worker.execute {
                val built = runCatching { OrientationPlacer(text.text) }
                main.post {
                    if (mySession != session) return@post
                    built.onSuccess { p ->
                        if (!p.hasToolpath) {
                            setStatus("No X/Y toolpath found in this G-code")
                            return@onSuccess
                        }
                        placer = p
                        shownText = text.text
                        angle = 0.0
                        cx = p.baseCenterX
                        cy = p.baseCenterY
                        setStatus(boundsText(p.baseMinX, p.baseMaxX, p.baseMinY, p.baseMaxY, 0.0))
                    }.onFailure { e ->
                        Log.w(TAG, "could not analyse the G-code: ${e.message}")
                        setStatus("Could not read this G-code")
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------------ the controls

    /**
     * Moves the drawing one step. [ux] / [uy] are -1, 0 or +1: X grows to the Right, Y grows Up. A pure translation:
     * nothing blocks it, in any direction, at any position.
     */
    fun move(ux: Int, uy: Int) {
        if (!ready) return
        cx += ux * stepMm
        cy += uy * stepMm
        requestRender()
    }

    /** Turns the drawing one step, counter-clockwise for [left] = true, clockwise otherwise. */
    fun rotate(left: Boolean) {
        if (!ready) return
        angle = ((angle + if (left) stepAngleDeg else -stepAngleDeg) % 360.0 + 360.0) % 360.0
        requestRender()
    }

    /** Puts the original G-code back: not moved, not turned. */
    fun reset() {
        val p = placer ?: return
        angle = 0.0
        cx = p.baseCenterX
        cy = p.baseCenterY
        requestRender()
    }

    // ------------------------------------------------------------------ live render

    /** A change happened: render soon, merging changes that arrive meanwhile (so holding a button keeps up). */
    private fun requestRender() {
        if (renderInFlight) {
            renderAgain = true
            return
        }
        if (renderScheduled) return
        renderScheduled = true
        main.postDelayed(renderRunnable, RENDER_DELAY_MS)
    }

    private fun startRender() {
        val p = placer ?: return
        val opener = openerFor(pane)
        if (opener == null) {
            setStatus("This viewer is not available")
            return
        }
        renderInFlight = true
        renderAgain = false
        val mySession = session
        val a = angle
        val wantX = cx
        val wantY = cy
        val name = baseName
        val targetPane = pane
        worker.execute {
            val outcome = runCatching {
                val r = p.place(a, wantX, wantY)
                val file = File(context.cacheDir, "ncv_remote_$targetPane.gcode")
                file.writeText(r.text)
                Pair(r, file)
            }
            main.post {
                renderInFlight = false
                if (mySession != session) return@post
                outcome.onSuccess { (r, file) ->
                    shownText = r.text
                    opener.replaceWithFile(file, name)
                    setStatus(boundsText(r.minX, r.maxX, r.minY, r.maxY, r.angleDeg))
                }.onFailure { e ->
                    Log.w(TAG, "remote render failed: ${e.message}")
                    setStatus(e.message ?: "Could not process the G-code")
                }
                if (renderAgain) requestRender()
            }
        }
    }

    private fun boundsText(minX: Double, maxX: Double, minY: Double, maxY: Double, angleDeg: Double): String {
        fun f(v: Double) = formatNumber(v, 2)
        return "X ${f(minX)}\u2013${f(maxX)} \u00B7 Y ${f(minY)}\u2013${f(maxY)} \u00B7 ${f(angleDeg)}\u00B0"
    }

    /** Drops anything in flight or scheduled: its result would belong to a snapshot that no longer applies. */
    private fun invalidate() {
        main.removeCallbacks(renderRunnable)
        renderScheduled = false
        renderAgain = false
        session++
    }

    // ------------------------------------------------------------------ save

    /** The file name offered in the Save dialog: the viewed file's name + "_processed.gcode". */
    fun suggestedFileName(): String {
        val stem = baseName.substringBeforeLast('.', baseName).ifBlank { "viewer" }
        return "${stem}_processed.gcode"
    }

    /**
     * Writes the G-code the viewer shows right now to [uri] (chosen with the system "Save As" dialog). It is read
     * from the pane's editor at this moment, so it is exactly what is on screen, including any manual edit made
     * in NC Viewer after previewing; only if that read fails does it fall back to the last render.
     */
    fun saveTo(uri: Uri) {
        val fallback = shownText
        val opener = openerFor(pane)
        if (opener == null) {
            writeTo(uri, fallback)
            return
        }
        opener.readEditorText { current -> writeTo(uri, current?.text ?: fallback) }
    }

    private fun writeTo(uri: Uri, text: String?) {
        if (text == null) {
            toast("Nothing to save yet.")
            return
        }
        worker.execute {
            val failure = runCatching {
                context.contentResolver.openOutputStream(uri, "wt")?.use { it.write(text.toByteArray(Charsets.UTF_8)) }
                    ?: throw IllegalStateException("could not open the destination")
            }.exceptionOrNull()
            main.post {
                toast(if (failure == null) "Saved the viewed G-code" else "Could not save: ${failure.message}")
            }
        }
    }

    // ------------------------------------------------------------------ helpers

    private fun setStatus(message: String) {
        status = message
        changed()
    }

    private fun changed() {
        onChanged?.invoke()
    }

    private fun toast(message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }
}
