package com.vectorforge.app.ncviewer

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.vectorforge.app.engine.gcode.transform.PostProcessParams
import java.io.File
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

private const val TAG = "NCViewer"

/** Debounce between the last parameter change and the re-plot, so typing "30" does not plot "3" first. */
private const val LIVE_DELAY_MS = 350L

/** Stand-ins for a blank half of FINAL NEW MIN / NEW MAX: the Convert screen's header defaults (0 .. 40 mm). */
private const val FALLBACK_MIN = 0.0
private const val FALLBACK_MAX = 40.0

/**
 * Live post-processing for the G-Code Viewer: change rotate / offset / keep / ... / final normalize and watch
 * the toolpath change in NC Viewer, then save the result.
 *
 * How it works
 *  1. Opening the panel takes a snapshot ("base") of the G-code currently in the chosen viewer pane's editor.
 *  2. Every parameter change re-runs [PostProcessParams.process] -- the very same pipeline "Generate" uses --
 *     on that base (never on the previous preview, so nothing compounds), off the main thread and debounced.
 *  3. The result goes into the pane's editor and is plotted, exactly like opening a file ([FileOpener.replaceWithFile]).
 *  4. [saveTo] writes whatever is currently shown to a file the user picks. [reset] puts the base back.
 *
 * The properties marked "observed by Compose" are read by the panel UI; all of them change on the main thread.
 */
class ViewerPostProcess(
    private val context: Context,
    /** The pane's FileOpener (0 = top / Viewer 1, 1 = bottom / Viewer 2), or null if that pane does not exist. */
    private val openerFor: (pane: Int) -> FileOpener?,
) {
    // ---- observed by Compose ----
    var isOpen by mutableStateOf(false)
        private set
    var collapsed by mutableStateOf(false)
    var pane by mutableIntStateOf(0)
        private set
    var params by mutableStateOf(PostProcessParams())
        private set
    var splitMode by mutableStateOf(false)
    /** The status line(s) under the panel header. */
    var status by mutableStateOf("")
        private set
    var statusIsError by mutableStateOf(false)
        private set
    /** True once a snapshot of the pane's G-code exists; without it there is nothing to process. */
    var hasBase by mutableStateOf(false)
        private set
    /** Bumped on reset / re-read so the panel's input fields drop their typed text and show the new params. */
    var resetToken by mutableIntStateOf(0)
        private set

    // ---- session ----
    private val main = Handler(Looper.getMainLooper())
    private val worker: ExecutorService = Executors.newSingleThreadExecutor()
    private var baseText: String? = null
    private var baseName: String = "viewer.gcode"
    private var shownText: String? = null          // what the viewer shows right now (what Save writes)
    private var generation = 0                     // bumped to invalidate in-flight work
    private val pendingRun = Runnable { runNow() }

    // ------------------------------------------------------------------ open / close

    fun toggle() = if (isOpen) close() else show()

    private fun show() {
        isOpen = true
        collapsed = false
        if (!splitMode) pane = 0
        capture()
    }

    /** Hides the panel. The viewer keeps showing whatever it shows now (the current preview). */
    fun close() {
        isOpen = false
        cancelPending()
    }

    /**
     * The viewer's content was replaced from outside (a generated file, a picked file): the snapshot is stale,
     * so close the panel rather than let the next change overwrite the new file with an old base.
     */
    fun dismissBecauseViewerChanged() {
        if (isOpen) close()
    }

    /** Called when single / split view is switched. */
    fun onSplitChanged(split: Boolean) {
        splitMode = split
        if (isOpen && !split && pane != 0) {
            pane = 0
            capture()
        }
    }

    fun shutdown() {
        cancelPending()
        worker.shutdownNow()
    }

    // ------------------------------------------------------------------ snapshot

    fun selectPane(index: Int) {
        if (index == pane) return
        cancelPending()
        pane = index
        capture()
    }

    /** (Re-)reads the pane's current G-code as the new base and clears the parameters. */
    fun capture() {
        cancelPending()
        val opener = openerFor(pane)
        params = PostProcessParams()
        resetToken++
        hasBase = false
        baseText = null
        shownText = null
        if (opener == null) {
            setStatus("This viewer pane is not available.", error = true)
            return
        }
        setStatus("Reading the G-code from Viewer ${pane + 1}\u2026", error = false)
        val requestedPane = pane
        opener.readEditorText { text ->
            if (requestedPane != pane || !isOpen) return@readEditorText // the user moved on
            if (text == null) {
                setStatus("Viewer ${pane + 1} has no G-code yet. Load a file (or use Generate + Viewer) first.", error = true)
            } else {
                baseText = text.text
                baseName = text.name
                shownText = text.text
                hasBase = true
                setStatus("Ready: change a parameter to preview it live. Save keeps what you see.", error = false)
            }
        }
    }

    // ------------------------------------------------------------------ live update

    /** A parameter changed: remember it and (debounced) re-process the base and re-plot. */
    fun update(newParams: PostProcessParams) {
        params = newParams
        if (!hasBase) return
        main.removeCallbacks(pendingRun)
        main.postDelayed(pendingRun, LIVE_DELAY_MS)
    }

    /** Puts the original G-code back in the viewer and clears every parameter. */
    fun reset() {
        if (!hasBase) return
        params = PostProcessParams()
        resetToken++
        main.removeCallbacks(pendingRun)
        runNow()
    }

    private fun cancelPending() {
        main.removeCallbacks(pendingRun)
        generation++ // anything already computing is now stale
    }

    private fun runNow() {
        val base = baseText ?: return
        val p = params
        val myGeneration = ++generation
        val requestedPane = pane
        val name = baseName
        worker.execute {
            // the same pipeline as "Generate": transform -> final normalize
            val outcome = runCatching {
                val out = p.process(base, FALLBACK_MIN, FALLBACK_MAX)
                val file = File(context.cacheDir, "ncv_postprocess_$requestedPane.gcode")
                file.writeText(out.text)
                Triple(out, file, out.reportLines)
            }
            main.post {
                if (myGeneration != generation) return@post // a newer change superseded this one
                outcome
                    .onSuccess { (out, file, lines) ->
                        val opener = openerFor(requestedPane)
                        if (opener == null) {
                            setStatus("This viewer pane is not available.", error = true)
                            return@onSuccess
                        }
                        shownText = out.text
                        opener.replaceWithFile(file, name)
                        setStatus(
                            if (lines.isEmpty()) "Original G-code (no post-processing set)." else lines.joinToString("\n"),
                            error = false,
                        )
                    }
                    .onFailure { e ->
                        // invalid combination / out-of-range value: say why, leave the viewer as it was
                        Log.w(TAG, "live post-process failed: ${e.message}")
                        setStatus(e.message ?: "Post-processing failed.", error = true)
                    }
            }
        }
    }

    // ------------------------------------------------------------------ save

    /** The file name offered in the Save dialog: the viewed file's name + "_processed.gcode". */
    fun suggestedFileName(): String {
        val stem = baseName.substringBeforeLast('.', baseName).ifBlank { "viewer" }
        return "${stem}_processed.gcode"
    }

    /**
     * Writes the G-code the viewer shows right now to [uri] (chosen with the system "Save As" dialog). It is read
     * from the pane's editor at this moment, so it is exactly what is on screen, including any manual edit made
     * in NC Viewer after previewing; only if that read fails does it fall back to the last preview computed.
     */
    fun saveTo(uri: Uri) {
        val fallback = shownText
        val opener = openerFor(pane)
        if (opener == null) {
            writeTo(uri, fallback)
            return
        }
        opener.readEditorText { current -> writeTo(uri, current?.text ?: fallback) }
    }

    private fun writeTo(uri: Uri, text: String?) {
        if (text == null) {
            toast("Nothing to save yet.")
            return
        }
        worker.execute {
            val failure = runCatching {
                context.contentResolver.openOutputStream(uri, "wt")?.use { it.write(text.toByteArray(Charsets.UTF_8)) }
                    ?: throw IllegalStateException("could not open the destination")
            }.exceptionOrNull()
            main.post {
                toast(if (failure == null) "Saved the viewed G-code" else "Could not save: ${failure.message}")
            }
        }
    }

    // ------------------------------------------------------------------ helpers

    private fun setStatus(message: String, error: Boolean) {
        status = message
        statusIsError = error
    }

    private fun toast(message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }
}
