package com.vectorforge.app.ui.theme

import androidx.compose.ui.unit.dp

/**
 * Spacing scale copied from the reference's `theme.extend.spacing` block
 * (rem values converted at the reference's implicit 16px root: 1rem = 16dp).
 */
object VfSpacing {
    val xs = 4.dp   // space-xs: 0.25rem
    val sm = 8.dp   // space-sm: 0.5rem
    val md = 14.dp  // space-md: 0.875rem
    val lg = 20.dp  // space-lg: 1.25rem
    val xl = 28.dp  // space-xl: 1.75rem

    val marginMobile = 16.dp // margin-mobile: 1rem
    val gutterMobile = 12.dp // gutter-mobile: 0.75rem
    val gutter = 16.dp       // gutter: 1rem
    val margin = 20.dp       // margin: 1.25rem
}

/**
 * Corner radii. `default`/`lg`/`xl`/`full` are the reference's explicit
 * overrides in `theme.extend.borderRadius`; `xl2` and `xl3` are Tailwind's
 * own (un-overridden) defaults, which the reference uses directly as
 * `rounded-2xl` (cards) and as the explicit `rounded-[24px]` on the two
 * pipeline-stage sections.
 */
object VfRadius {
    val default = 4.dp   // borderRadius.DEFAULT: 0.25rem
    val lg = 8.dp         // borderRadius.lg: 0.5rem
    val xl = 12.dp        // borderRadius.xl: 0.75rem
    val xl2 = 16.dp       // Tailwind default rounded-2xl (unmodified)
    val xl3 = 24.dp       // rounded-[24px] (stage section cards)
    // borderRadius.full (9999px) -> use CircleShape / very large corner instead of a dp value.
}
