package com.vectorforge.app.sender

import java.util.Locale
import kotlin.math.max
import kotlin.math.min

/**
 * Pure helpers (no Android) used by the sender: cleaning a G-code line, rescaling its feed rate, deciding
 * whether the stock "Mini CNC Plotter" firmware can digest it, and summarising a whole program.
 */
object GcodeLineTools {

    private val parenComment = Regex("""\([^)]*\)""")
    private val feedWord = Regex("""(?<![A-Z])F(\d+(?:\.\d+)?)""")
    private val moveWord = Regex("""^G0*[01](?!\d)""")
    private val optionalStop = Regex("""^M0*[01](?!\d)""")
    private val axisX = Regex("""X(-?\d*\.?\d+)""")
    private val axisY = Regex("""Y(-?\d*\.?\d+)""")
    // G20 G21 G90 G92 M17 M18 M30, but not a longer code that merely starts the same way (M300, G92.1 is fine to drop).
    private val noiseCode = Regex("""^(?:G2[01]|G9[02]|M1[78]|M30)(?!\d)""")
    private val dwellWord = Regex("""^G0*4\s*P(\d+(?:\.\d+)?)""")
    private val grblNoise = Regex("""^M1[78](?!\d)""")
    private val penWord = Regex("""^M300(?!\d).*?S(-?\d+(?:\.\d+)?)""")

    /** Removes `( ... )` and `; ...` comments and surrounding whitespace. Returns "" for a comment-only line. */
    fun clean(raw: String): String {
        var s = raw
        val semi = s.indexOf(';')
        if (semi >= 0) s = s.substring(0, semi)
        s = parenComment.replace(s, "")
        // An unterminated "(" swallows the rest of the line, like most controllers do.
        val open = s.indexOf('(')
        if (open >= 0) s = s.substring(0, open)
        return s.trim()
    }

    /** True for M0 / M00 / M1 / M01 -- the program-stop / optional-stop codes the sender turns into a pause. */
    fun isOptionalStop(cleaned: String): Boolean = optionalStop.containsMatchIn(cleaned.uppercase(Locale.ROOT))

    /** Multiplies every `F<number>` in the line by [percent]/100 (no change at 100 %). */
    fun scaleFeed(cleaned: String, percent: Int): String {
        if (percent == 100) return cleaned
        val factor = percent / 100.0
        return feedWord.replace(cleaned.uppercase(Locale.ROOT)) { m ->
            val v = m.groupValues[1].toDouble() * factor
            "F" + String.format(Locale.ROOT, "%.1f", max(1.0, v))
        }
    }

    /**
     * The stock sketch reads X/Y with `strchr(...)` and never checks for NULL, so a G0/G1 that has neither X nor Y
     * (a Z-only move, or just an F word) makes it read garbage and jump. Those lines must not be sent to it.
     */
    fun isMoveWithoutXy(cleaned: String): Boolean {
        val u = cleaned.uppercase(Locale.ROOT).replace(" ", "")
        if (!moveWord.containsMatchIn(u)) return false
        return !u.contains('X') && !u.contains('Y')
    }

    /** Lines that mean nothing to the stock sketch (it would only answer "Command not recognized"). */
    fun isNoiseForPlotter(cleaned: String): Boolean {
        val u = cleaned.uppercase(Locale.ROOT).replace(" ", "")
        return noiseCode.containsMatchIn(u) || u.startsWith("M300S255")
    }

    data class Summary(
        val lines: Int,
        val minX: Double?, val maxX: Double?,
        val minY: Double?, val maxY: Double?,
        val usesRelative: Boolean,
        val penValues: Set<Double>,
    ) {
        val hasBounds: Boolean get() = minX != null && minY != null && maxX != null && maxY != null
    }

    /** Scans a program once for its XY extent (absolute moves only) and the distinct M300 servo values. */
    fun summarize(program: List<String>): Summary {
        var minX: Double? = null; var maxX: Double? = null
        var minY: Double? = null; var maxY: Double? = null
        var relative = false
        var curX = 0.0; var curY = 0.0
        val pens = LinkedHashSet<Double>()
        for (raw in program) {
            val u = clean(raw).uppercase(Locale.ROOT).replace(" ", "")
            if (u.isEmpty()) continue
            if (u.startsWith("G91")) relative = true
            if (u.startsWith("G90")) relative = false
            penWord.find(clean(raw).uppercase(Locale.ROOT))?.let { m -> m.groupValues[1].toDoubleOrNull()?.let { pens.add(it) } }
            if (!moveWord.containsMatchIn(u)) continue
            val x = axisX.find(u)?.groupValues?.get(1)?.toDoubleOrNull()
            val y = axisY.find(u)?.groupValues?.get(1)?.toDoubleOrNull()
            if (relative) continue
            if (x != null) curX = x
            if (y != null) curY = y
            if (x != null || y != null) {
                minX = if (minX == null) curX else min(minX, curX)
                maxX = if (maxX == null) curX else max(maxX, curX)
                minY = if (minY == null) curY else min(minY, curY)
                maxY = if (maxY == null) curY else max(maxY, curY)
            }
        }
        return Summary(program.size, minX, maxX, minY, maxY, relative, pens)
    }

    /** The S value of an `M300 S..` pen command, or null when the line is not one. */
    fun penValue(cleaned: String): Double? =
        penWord.find(cleaned.uppercase(Locale.ROOT))?.groupValues?.get(1)?.toDoubleOrNull()

    /**
     * G-code `G4 P` is milliseconds in the stock plotter / Marlin dialect (what the generator writes) but SECONDS
     * in GRBL, so "G4 P150" would stall a GRBL machine for 150 s. Rewrites it as "G4 P0.15".
     */
    fun dwellMsToSeconds(cleaned: String): String {
        val u = cleaned.uppercase(Locale.ROOT).replace(" ", "")
        val m = dwellWord.find(u) ?: return cleaned
        val ms = m.groupValues[1].toDoubleOrNull() ?: return cleaned
        return "G4 P" + num(ms / 1000.0)
    }

    /** Lines vanilla GRBL does not know (motor enable / disable). */
    fun isNoiseForGrbl(cleaned: String): Boolean =
        grblNoise.containsMatchIn(cleaned.uppercase(Locale.ROOT).replace(" ", ""))

    /** The X / Y words of an absolute G0 / G1 line (null when the line is not a move or the axis is absent). */
    fun parseXy(cleaned: String): Pair<Double?, Double?> {
        val u = cleaned.uppercase(Locale.ROOT).replace(" ", "")
        if (!moveWord.containsMatchIn(u)) return Pair(null, null)
        return Pair(
            axisX.find(u)?.groupValues?.get(1)?.toDoubleOrNull(),
            axisY.find(u)?.groupValues?.get(1)?.toDoubleOrNull(),
        )
    }

    /** "12.5" instead of "12.500000"; used when building jog commands. */
    fun num(v: Double): String {
        val s = String.format(Locale.ROOT, "%.3f", v).trimEnd('0').trimEnd('.')
        return if (s.isEmpty() || s == "-0") "0" else s
    }
}
