package com.vectorforge.app.data

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.vectorforge.app.engine.gcode.Args
import com.vectorforge.app.engine.gcode.GcodeResult
import com.vectorforge.app.engine.gcode.svgFileToGcode
import com.vectorforge.app.engine.gcode.transform.TransformResult
import com.vectorforge.app.engine.potrace.Params
import com.vectorforge.app.engine.potrace.countTracedPaths
import com.vectorforge.app.engine.potrace.loadBitmap
import com.vectorforge.app.engine.potrace.pillowGrayscaleThreshold
import com.vectorforge.app.engine.potrace.potraceTrace
import com.vectorforge.app.engine.potrace.readPbmP4
import com.vectorforge.app.engine.potrace.tracedTreeToSvg
import com.vectorforge.app.engine.potrace.writePbmP4
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Drives both pipeline stages shown on the Convert tab. Every control the
 * UI exposes maps to exactly one field here (see PotraceUiState /
 * GcodeUiState); every "Convert" button maps to exactly one function here
 * that calls straight into the ported engine code -- no parameter is
 * simulated or short-circuited.
 */
class ConvertViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = FileRepository(application)

    private val _potrace = MutableStateFlow(PotraceUiState())
    val potrace: StateFlow<PotraceUiState> = _potrace.asStateFlow()

    private val _gcode = MutableStateFlow(GcodeUiState())
    val gcode: StateFlow<GcodeUiState> = _gcode.asStateFlow()

    // "Generate + Viewer 1 / 2" hand-off to the G-Code Viewer tab. A buffered Channel (not a SharedFlow) so a
    // request emitted while nothing is collecting yet (e.g. mid-recreation) is delivered, not dropped.
    private val _viewerRequests = Channel<ViewerRequest>(Channel.BUFFERED)
    val viewerRequests: Flow<ViewerRequest> = _viewerRequests.receiveAsFlow()

    // One-shot "it worked" messages (shown as a short toast by MainActivity). The permanent status cards are gone
    // from the main UI: failures go to a dialog, the full status lives at the top of each Parameters dropdown.
    private val _messages = Channel<String>(Channel.BUFFERED)
    val messages: Flow<String> = _messages.receiveAsFlow()

    fun dismissPotraceError() = _potrace.update { it.copy(errorDialog = null) }
    fun dismissGcodeError() = _gcode.update { it.copy(errorDialog = null) }

    // ======================================================================
    // Stage 1: IMAGE -> SVG (Potrace)
    // ======================================================================

    fun onImageSelected(uri: Uri) {
        val file = repo.importImage(uri)
        _potrace.update {
            it.copy(
                imageFile = file,
                imageFileName = file.name,
                imageDimensionsLabel = repo.imageDimensionsLabel(file),
                outputSvgPath = repo.defaultSvgOutputPath(file),
                pbmOutputPath = repo.defaultPbmPath(file),
                statusTitle = "Engine Online",
                statusDetail = "High-fidelity binary edge tracer prepared. Raster will vectorize with default Bézier fitting.",
                pathCount = null,
                errorMessage = null,
                generatedSvgFile = null,
            )
        }
    }

    fun clearImage() {
        _potrace.update {
            it.copy(
                imageFile = null, imageFileName = "", imageDimensionsLabel = "",
                generatedSvgFile = null, pathCount = null, errorMessage = null
            )
        }
    }

    fun setTraceMode(mode: TraceMode) = _potrace.update { it.copy(traceMode = mode) }
    fun setInvertLuminance(value: Boolean) = _potrace.update { it.copy(invertLuminance = value) }
    fun setPbmOutputPath(path: String) = _potrace.update { it.copy(pbmOutputPath = path) }
    fun setOutputSvgPath(path: String) = _potrace.update { it.copy(outputSvgPath = path) }
    fun setThreshold(value: Double) = _potrace.update { it.copy(threshold = value.coerceIn(0.0, 1.0)) }
    fun setTurdsize(value: Int) = _potrace.update { it.copy(turdsize = value.coerceAtLeast(0)) }
    fun incTurdsize() = setTurdsize(_potrace.value.turdsize + 1)
    fun decTurdsize() = setTurdsize(_potrace.value.turdsize - 1)
    fun setAlphamax(value: Double) = _potrace.update { it.copy(alphamax = value.coerceAtLeast(0.0)) }
    fun incAlphamax() = setAlphamax(_potrace.value.alphamax + 0.1)
    fun decAlphamax() = setAlphamax(_potrace.value.alphamax - 0.1)
    fun setOpticurve(value: Boolean) = _potrace.update { it.copy(opticurve = value) }
    fun setOpttolerance(value: Double) = _potrace.update { it.copy(opttolerance = value) }
    fun setTurnPolicy(option: TurnPolicyOption) = _potrace.update { it.copy(turnPolicy = option) }

    /** "CONVERT TO SVG" -- runs Mode 1 (direct) or Mode 2 (PBM intermediate) per the segmented control. */
    fun convertToSvg() {
        if (_potrace.value.imageFile == null) return
        viewModelScope.launch { runSvgConversion() }
    }

    /**
     * The Image -> SVG conversion itself, exactly as "CONVERT TO SVG" ran it, as a suspend function so that
     * "Auto Convert Previous Stage" can await it. Returns the SVG file that was written, or null if it failed
     * (the failure is already in the Potrace state and its error dialog).
     */
    private suspend fun runSvgConversion(): File? {
        val state = _potrace.value
        val imageFile = state.imageFile ?: return null
        _potrace.update { it.copy(isConverting = true, errorMessage = null, errorDialog = null, statusTitle = "Tracing…", statusDetail = "Running the Potrace engine on the selected raster.") }

        val result = withContext(Dispatchers.Default) {
            runCatching {
                val params = Params(
                    turdsize = state.turdsize,
                    turnpolicy = state.turnPolicy.value,
                    alphamax = state.alphamax,
                    opticurve = state.opticurve,
                    opttolerance = state.opttolerance,
                )
                if (state.traceMode == TraceMode.MODE_1_DIRECT) {
                    val bm = loadBitmap(imageFile, state.threshold)
                    val tree = potraceTrace(bm, params)
                    val svg = tracedTreeToSvg(tree, bm.w, bm.h)
                    svg to countTracedPaths(tree)
                } else {
                    // Mode 2: mirrors traceImageMode2 step-for-step, but keeps
                    // the traced tree around so we can report a path count.
                    val decodedBitmap = android.graphics.BitmapFactory.decodeFile(imageFile.path)
                        ?: error("Could not decode image: ${imageFile.path}")
                    val gray = pillowGrayscaleThreshold(decodedBitmap, (state.threshold * 255).toInt(), state.invertLuminance)
                    decodedBitmap.recycle()
                    writePbmP4(gray, state.pbmOutputPath)
                    val bm = readPbmP4(state.pbmOutputPath)
                    val tree = potraceTrace(bm, params)
                    val svg = tracedTreeToSvg(tree, bm.w, bm.h)
                    svg to countTracedPaths(tree)
                }
            }
        }

        var written: File? = null
        result.onSuccess { (svg, pathCount) ->
            val outFile = repo.writeText(_potrace.value.outputSvgPath, svg)
            _potrace.update {
                it.copy(
                    isConverting = false,
                    statusTitle = "Traced Successfully",
                    statusDetail = "Wrote ${outFile.name} with $pathCount closed path(s).",
                    pathCount = pathCount,
                    generatedSvgFile = outFile,
                    errorMessage = null,
                )
            }
            _messages.trySend("SVG ready: ${outFile.name} \u00B7 $pathCount path(s)")
            written = outFile
        }.onFailure { e ->
            _potrace.update {
                it.copy(
                    isConverting = false,
                    statusTitle = "Trace Failed",
                    statusDetail = e.message ?: "Unknown error while tracing.",
                    errorMessage = e.message,
                    errorDialog = e.message ?: "Unknown error while tracing.",
                )
            }
        }
        return written
    }

    fun shareGeneratedSvg() {
        _potrace.value.generatedSvgFile?.let { repo.shareFile(it, "image/svg+xml") }
    }

    /** Copies the already-generated SVG to a location the user picked via the system "Save As" (SAF CreateDocument) dialog. */
    fun exportSvgTo(uri: Uri) {
        val file = _potrace.value.generatedSvgFile ?: return
        runCatching { repo.exportFileTo(file, uri) }
    }

    // ======================================================================
    // Pipeline bridge: "Feed Output SVG to Generator"
    // ======================================================================

    /** Copies stage 1's freshly generated SVG into stage 2's input, exactly like the "Feed Output SVG to Generator" button. */
    fun feedSvgToGenerator() {
        val svg = _potrace.value.generatedSvgFile ?: return
        applySvgToStage2(svg)
    }

    /** "sync" auto-fill button in stage 2: re-pulls the latest traced SVG, if any. */
    fun autoFillLatestSvg() {
        val svg = _potrace.value.generatedSvgFile ?: return
        applySvgToStage2(svg)
    }

    fun onSvgSelected(uri: Uri) {
        val file = repo.importSvg(uri)
        applySvgToStage2(file)
    }

    private fun applySvgToStage2(file: File) {
        _gcode.update {
            it.copy(
                svgFile = file,
                svgFileName = file.name,
                svgFileSizeLabel = repo.humanFileSize(file.length()),
                outputGcodePath = repo.defaultGcodeOutputPath(file),
                statusTitle = "Vector to CNC Ready",
                statusDetail = "Configured for standard 2-axis pen carriage with servo stroke commands (M03 S30 / M05 S50).",
                lineCount = null,
                errorMessage = null,
                generatedGcodeFile = null,
            )
        }
    }

    // ======================================================================
    // Stage 2: SVG -> G-CODE
    // ======================================================================

    fun setOutputGcodePath(path: String) = _gcode.update { it.copy(outputGcodePath = path) }
    fun setAutoConvertPreviousStage(v: Boolean) = _gcode.update { it.copy(autoConvertPreviousStage = v) }

    // Prefilled with the values from the working desktop CLI run and always passed.
    fun setPenUpAngle(v: Double) = _gcode.update { it.copy(penUpAngle = v) }
    fun setPenDownAngle(v: Double) = _gcode.update { it.copy(penDownAngle = v) }
    fun setXyFeedrate(v: Double) = _gcode.update { it.copy(xyFeedrate = v) }
    fun setNewMin(v: Double) = _gcode.update { it.copy(newMin = v) }
    fun setNewMax(v: Double) = _gcode.update { it.copy(newMax = v) }
    fun setReduceThinPoints(v: Boolean) = _gcode.update { it.copy(reduceThinPoints = v) }

    // Optional overrides: null (empty input / reset toggle) = untouched = not passed.
    fun setStartDelayMs(v: Int?) = _gcode.update { it.copy(startDelayMs = v) }
    fun setStopDelayMs(v: Int?) = _gcode.update { it.copy(stopDelayMs = v) }
    fun setRegisterPen(v: Boolean?) = _gcode.update { it.copy(registerPen = v) }
    fun setZFeedrate(v: Double?) = _gcode.update { it.copy(zFeedrate = v) }
    fun setZHeight(v: Double?) = _gcode.update { it.copy(zHeight = v) }
    fun setFinishedHeight(v: Double?) = _gcode.update { it.copy(finishedHeight = v) }
    fun setXHome(v: Double?) = _gcode.update { it.copy(xHome = v) }
    fun setYHome(v: Double?) = _gcode.update { it.copy(yHome = v) }
    fun setNumCopies(v: Int?) = _gcode.update { it.copy(numCopies = v?.coerceAtLeast(1)) }
    fun setContinuousPlotting(v: Boolean?) = _gcode.update { it.copy(continuousPlotting = v) }
    fun setPauseOnLayerChange(v: Boolean?) = _gcode.update { it.copy(pauseOnLayerChange = v) }
    fun setCompatibilityTab(v: String) = _gcode.update { it.copy(compatibilityTab = v) }
    fun setFlatness(v: Double?) = _gcode.update { it.copy(flatness = v) }
    fun setDpi(v: Double?) = _gcode.update { it.copy(dpi = v) }
    fun setMinChange(v: Double?) = _gcode.update { it.copy(minChange = v) }
    fun setSkipFactor(v: Int?) = _gcode.update { it.copy(skipFactor = v) }
    fun setNormalizeOutputBounds(v: Boolean?) = _gcode.update { it.copy(normalizeOutputBounds = v) }

    // G-code transform (post-processing) -- one setter per argument. Blank / off = not passed.
    fun setTransformRotateLeft(v: Double?) = _gcode.update { it.copy(transformRotateLeft = v) }
    fun setTransformRotateRight(v: Double?) = _gcode.update { it.copy(transformRotateRight = v) }
    fun setTransformOffsetX(v: Double?) = _gcode.update { it.copy(transformOffsetX = v) }
    fun setTransformOffsetY(v: Double?) = _gcode.update { it.copy(transformOffsetY = v) }
    fun setKeepPositive(v: Boolean) = _gcode.update { it.copy(keepPositive = v) }
    fun setKeepNegative(v: Boolean) = _gcode.update { it.copy(keepNegative = v) }
    fun setKeepEast(v: Boolean) = _gcode.update { it.copy(keepEast = v) }
    fun setKeepWest(v: Boolean) = _gcode.update { it.copy(keepWest = v) }
    fun setKeepNorth(v: Boolean) = _gcode.update { it.copy(keepNorth = v) }
    fun setKeepSouth(v: Boolean) = _gcode.update { it.copy(keepSouth = v) }
    fun setTransformNoFixedHome(v: Boolean) = _gcode.update { it.copy(transformNoFixedHome = v) }
    fun setTransformMaxX(v: Double?) = _gcode.update { it.copy(transformMaxX = v) }
    fun setTransformMaxY(v: Double?) = _gcode.update { it.copy(transformMaxY = v) }
    fun setTransformPrecision(v: Int?) = _gcode.update { it.copy(transformPrecision = v) }
    fun setFinalNewMin(v: Double?) = _gcode.update { it.copy(finalNewMin = v) }
    fun setFinalNewMax(v: Double?) = _gcode.update { it.copy(finalNewMax = v) }

    /**
     * The three G-code buttons ("G-code", "Viewer 1", "Viewer 2"). [viewerTarget] only decides what happens to the
     * finished file afterwards (see [ViewerTarget]); with [ViewerTarget.NONE] nothing is sent to any viewer.
     *
     * Where the SVG comes from:
     *  1. A valid SVG already in this stage (selected, or fed in from Image -> SVG): used directly.
     *  2. Otherwise, if "Auto Convert Previous Stage" is on: the SVG Image -> SVG has already produced is used as
     *     is, and only if there is none is Image -> SVG run first (the very same conversion as "CONVERT TO SVG").
     *     If that cannot produce a valid SVG, its error dialog is shown and no G-code is attempted.
     *  3. Option off and no SVG: nothing happens (the buttons are disabled in that state).
     * A valid SVG is never converted again.
     */
    fun convertToGcode(viewerTarget: ViewerTarget = ViewerTarget.NONE) {
        val g = _gcode.value
        if (g.isGenerating || _potrace.value.isConverting) return

        // 1. an SVG is already here. (With the option off, a missing / broken file still goes to the generator, as
        //    before, so it reports its own error.)
        if (g.svgFile.isUsableSvg() || (g.svgFile != null && !g.autoConvertPreviousStage)) {
            generateGcode(viewerTarget)
            return
        }
        // 3. nothing to use and nothing allowed to fetch one
        if (!g.autoConvertPreviousStage) return

        // 2. get the SVG from the previous stage, then generate
        viewModelScope.launch {
            val svg = obtainSvgFromPreviousStage() ?: return@launch
            applySvgToStage2(svg) // exactly what "Feed Output SVG to Generator" does
            generateGcode(viewerTarget)
        }
    }

    /**
     * The SVG for the G-code stage when it has none: the one Image -> SVG already wrote if it is valid (no second
     * conversion), else a fresh Image -> SVG run. Returns null, with a dialog shown, if no valid SVG can be had.
     */
    private suspend fun obtainSvgFromPreviousStage(): File? {
        val already = _potrace.value.generatedSvgFile
        if (already.isUsableSvg()) return already

        if (_potrace.value.imageFile == null) {
            _gcode.update {
                it.copy(
                    errorDialog = "Auto Convert Previous Stage: there is no SVG yet and no image is selected. " +
                        "Select an image in IMAGE \u2192 SVG (or select an SVG here) and try again.",
                )
            }
            return null
        }

        val produced = runSvgConversion() ?: return null // its failure dialog is already showing
        if (!produced.isUsableSvg() || (_potrace.value.pathCount ?: 0) <= 0) {
            val why = "Image \u2192 SVG did not produce any paths, so there is nothing to turn into G-code. " +
                "Try a different threshold or Invert Luminance."
            _potrace.update { it.copy(errorMessage = why, errorDialog = why, statusTitle = "No Paths Traced", statusDetail = why) }
            return null
        }
        return produced
    }

    /** True for a file that exists, is not empty and starts like an SVG; the generator itself still does the real parsing. */
    private fun File?.isUsableSvg(): Boolean {
        if (this == null || !exists() || length() == 0L) return false
        return runCatching {
            bufferedReader().use { r ->
                val buf = CharArray(4096)
                val n = r.read(buf)
                n > 0 && String(buf, 0, n).contains("<svg", ignoreCase = true)
            }
        }.getOrDefault(false)
    }

    /** Builds an Args from the current UI state and calls the ported generator. Identical for all three buttons. */
    private fun generateGcode(viewerTarget: ViewerTarget) {
        val state = _gcode.value
        val svgFile = state.svgFile ?: return
        _gcode.update { it.copy(isGenerating = true, errorMessage = null, errorDialog = null, statusTitle = "Generating…", statusDetail = "Walking the SVG and emitting G-code.") }

        viewModelScope.launch {
            val result = withContext(Dispatchers.Default) {
                runCatching {
                    // The six prefilled settings mirror the working desktop CLI run and are
                    // always passed. Every other parameter is passed ONLY if the user typed
                    // a value / flipped the toggle (non-null); otherwise the Args() default
                    // applies, exactly as if that CLI flag had been left off.
                    val args = Args().apply {
                        this.svgFile = svgFile.path
                        penUpAngle = state.penUpAngle       // --pen-up-angle
                        penDownAngle = state.penDownAngle   // --pen-down-angle
                        xyFeedrate = state.xyFeedrate       // --xy-feedrate
                        newMin = state.newMin               // --new-min
                        newMax = state.newMax               // --new-max
                        noReduce = !state.reduceThinPoints  // --no-reduce

                        state.startDelayMs?.let { startDelay = it }
                        state.stopDelayMs?.let { stopDelay = it }
                        state.registerPen?.let { registerPen = it }
                        state.zFeedrate?.let { zFeedrate = it }
                        state.zHeight?.let { zHeight = it }
                        state.finishedHeight?.let { finishedHeight = it }
                        state.xHome?.let { xHome = it }
                        state.yHome?.let { yHome = it }
                        state.numCopies?.let { numCopies = it }
                        state.continuousPlotting?.let { continuous = it }
                        state.pauseOnLayerChange?.let { pauseOnLayerChange = it }
                        if (state.compatibilityTab.isNotBlank()) tab = state.compatibilityTab
                        state.flatness?.let { flatness = it }
                        state.dpi?.let { dpi = it }
                        state.minChange?.let { minChange = it }
                        state.skipFactor?.let { skipFactor = it }
                        state.normalizeOutputBounds?.let { noNormalize = !it }
                    }
                    val generated = svgFileToGcode(svgFile, args)

                    // POST-PROCESSING (PostProcessParams.process): rotate / keep / offset the finished G-code, then the
                    // FINAL NORMALIZE pair, last of all. Runs only if a setting is in use and there is a toolpath; the
                    // same pipeline the viewer's live Post-process panel uses. Invalid values (angle > 360,
                    // precision > 10, east+west ...) surface as a normal generation error, never silently corrected.
                    val params = state.postProcessParams()
                    if (params.isActive && !generated.noDrawableShapesFound) {
                        val processed = params.process(generated.gcode, state.newMin, state.newMax)
                        GenerationOutput(
                            generated.copy(gcode = processed.text),
                            processed.transform,
                            processed.finalNormalizeNote,
                        )
                    } else {
                        GenerationOutput(generated, null, null)
                    }
                }
            }

            result.onSuccess { output ->
                val gcodeResult = output.result
                val outFile = repo.writeText(_gcode.value.outputGcodePath, gcodeResult.gcode)
                _gcode.update {
                    it.copy(
                        isGenerating = false,
                        statusTitle = if (gcodeResult.noDrawableShapesFound) "No Drawable Shapes" else "G-Code Ready",
                        statusDetail = if (gcodeResult.noDrawableShapesFound)
                            "No drawable shapes were found in ${svgFile.name}."
                        else
                            "Wrote ${outFile.name}: ${gcodeResult.lineCount} lines across ${gcodeResult.shapeCount} stroke(s)." +
                                (output.transform?.let { "\nTransform \u2192 " + it.report.joinToString("\n") } ?: "") +
                                (output.finalNormalizeNote?.let { "\n$it" } ?: ""),
                        lineCount = gcodeResult.lineCount,
                        generatedGcodeFile = outFile,
                        errorMessage = null,
                        errorDialog = if (gcodeResult.noDrawableShapesFound) "No drawable shapes were found in ${svgFile.name}." else null,
                    )
                }
                if (!gcodeResult.noDrawableShapesFound) {
                    _messages.trySend("G-code ready: ${outFile.name} \u00B7 ${gcodeResult.lineCount} lines")
                }
                // Only the two "+ Viewer" buttons get here with a target, and only when there is a toolpath to show.
                if (viewerTarget != ViewerTarget.NONE && !gcodeResult.noDrawableShapesFound) {
                    _viewerRequests.trySend(ViewerRequest(outFile, viewerTarget))
                }
            }.onFailure { e ->
                _gcode.update {
                    it.copy(
                        isGenerating = false,
                        statusTitle = "Generation Failed",
                        statusDetail = e.message ?: "Unknown error while generating G-code.",
                        errorMessage = e.message,
                        errorDialog = e.message ?: "Unknown error while generating G-code.",
                    )
                }
            }
        }
    }

    fun shareGeneratedGcode() {
        _gcode.value.generatedGcodeFile?.let { repo.shareFile(it, "text/plain") }
    }

    /** Copies the already-generated G-code to a location the user picked via the system "Save As" (SAF CreateDocument) dialog. */
    fun exportGcodeTo(uri: Uri) {
        val file = _gcode.value.generatedGcodeFile ?: return
        runCatching { repo.exportFileTo(file, uri) }
    }
}

/** What one generation run produced: the generator's result (its gcode already transformed, if it was) + the transform report. */
private class GenerationOutput(val result: GcodeResult, val transform: TransformResult?, val finalNormalizeNote: String?)

private inline fun <T> MutableStateFlow<T>.update(transform: (T) -> T) {
    value = transform(value)
}
