package com.vectorforge.app.engine.gcode.transform

/*
 * ANDROID PORT NOTE
 * -----------------
 * Everything from "Parsing helpers" down to the end of `GCodeTransformer` below is the provided
 * GcodeTransform.kt, unchanged except for one line: formatNumber() pins Locale.ROOT (see the note there).
 * The command-line shell of that file (argv parsing, --help, interactive prompts, reading/writing files,
 * exit codes) is not part of this port. One addition to the core: an optional uniform `scale` (default 1.0 =
 * unchanged behaviour; the viewer's remote control does not use it); `transformGcode()` at the bottom of this file replaces it and runs the
 * exact same pipeline as its `runMain()` on a String instead of a file. It lives in its own package so the
 * top-level names of the original (`Args`, `main`, ...) cannot clash with the SVG->G-code engine's.
 */

/*
 * GcodeTransform.kt - rotate and/or translate the X/Y toolpath of a G-code file.
 *
 * 1:1 Kotlin port of gcode_transform.py. Same CLI, same options, same output
 * text and warnings.
 *
 * Transformation order (always the same):
 *
 *     original X/Y  ->  rotation about the global origin (0,0)
 *                   ->  (optional) --keep-* : shift the whole path into a quadrant/half
 *                   ->  X/Y offset   (--offset-x / --offset-y are ALWAYS applied last)
 *
 *     left  = counter-clockwise:  X' = X*cos(a) - Y*sin(a)   Y' = X*sin(a) + Y*cos(a)
 *     right = clockwise:          X' = X*cos(a) + Y*sin(a)   Y' = -X*sin(a) + Y*cos(a)
 *
 * Only X/Y values are touched. Everything else (Z, F, S, M-codes, comments,
 * line numbers, blank lines, line endings, unknown commands) is copied
 * through byte for byte.
 *
 * Keeping the toolpath on one side of the axes (--keep-*)
 * ---------------------------------------------------------
 *                     N (+Y)
 *                       |
 *       W (-X) ---------+--------- E (+X)
 *                       |
 *                     S (-Y)
 *
 * --keep-east / --keep-west / --keep-north / --keep-south each constrain ONE
 * axis and can be combined: north+east = --keep-positive (X>=0, Y>=0),
 * south+west = --keep-negative (X<=0, Y<=0), north+west = upper-left
 * quadrant, south+east = lower-right quadrant.
 *
 * After the rotation, the tool measures the real extent of the toolpath
 * (including the bulge of G2/G3 arcs) and, if any part is on the wrong side,
 * shifts the WHOLE path by the smallest amount that brings it onto the
 * requested side (its edge touches the axis). Nothing is scaled and nothing
 * is moved if it already fits. Only then are --offset-x / --offset-y added,
 * so the offset is always visible in the result (e.g. --keep-positive
 * --offset-x 10 -> lowest X is exactly 10).
 *
 * Pen starts and ends at 0 (fixed home, on by default)
 * ------------------------------------------------------
 * Plotter programs begin at the origin (e.g. "G92 X0 Y0") and finish with a
 * "go home" move (e.g. "G1 X0 Y0"). Those leading/trailing moves to exactly
 * X0 Y0 are NOT rotated/offset/shifted: the pen still starts from 0 and ends
 * at 0, and only the drawing itself is moved. Moves through 0,0 in the
 * middle of the drawing are transformed normally. Use --no-fixed-home to
 * transform them too. (A start/end move is never added if the file does
 * not have one.)
 *
 * Modal handling
 * ----------------
 * - The tool tracks the position in the ORIGINAL coordinate frame. A line
 *   with only "X20" stays X-only whenever the transformed Y is unchanged
 *   (pure translation, 180-degree rotation, ...). If the rotation makes the
 *   untouched axis change (e.g. 45 degrees), the missing axis is added to
 *   that line - this is required for the toolpath to stay valid.
 * - G90 / G91 are honoured: in incremental mode (G91) values are treated as
 *   vectors, so they are rotated but the offset is NOT added.
 * - Arc centre words I/J are rotated as vectors (G91.1, the default).
 *   Without this every G2/G3 arc would be geometrically wrong after a
 *   rotation. With G90.1 (absolute arc centres) I/J are transformed like
 *   coordinates.
 * - Lines with G10, G28, G30, G53 or G92 are copied unchanged (with a
 *   warning) - they refer to machine/work-offset positions, not toolpath
 *   points.
 * - Values that are not plain numbers (X#5, X[#1+2], ...) are left
 *   unchanged (with a warning).
 *
 * Examples
 * ----------
 *     kotlin GcodeTransform.kt in.gcode -o out.gcode --rotate-left 90
 *     kotlin GcodeTransform.kt in.gcode -o out.gcode --rotate-right 90
 *     kotlin GcodeTransform.kt in.gcode -o out.gcode --offset-x 4 --offset-y 2
 *     kotlin GcodeTransform.kt in.gcode -o out.gcode --rotate-left 90 --offset-x 4 --offset-y 2
 *     kotlin GcodeTransform.kt in.gcode --in-place --rotate-left 45 --precision 3
 *     kotlin GcodeTransform.kt in.gcode -o out.gcode --rotate-right 90 --keep-positive
 *     kotlin GcodeTransform.kt in.gcode -o out.gcode --rotate-left 90 --keep-north --keep-west
 *     kotlin GcodeTransform.kt in.gcode -o out.gcode --rotate-left 90 --keep-positive --offset-x 10
 *     kotlin GcodeTransform.kt --interactive
 */

import com.vectorforge.app.engine.gcode.normalizeLines
import java.util.Locale
import kotlin.math.*

// --------------------------------------------------------------------------- //
// Parsing helpers
// --------------------------------------------------------------------------- //

// Comments: (...) or ; to end of line. We split keeping the delimiter, so
// even indexes (0, 2, 4, ...) of the resulting list are code.
val COMMENT_RE = Regex("""\([^)]*\)|;.*""")

// A numeric axis word, e.g. X10  x-3.5  Y.25  (letter must not follow a letter)
val WORD_RE = Regex("""(?<![A-Za-z])([XYIJxyij])([ \t]*)([+-]?(?:\d+\.?\d*|\.\d+))""")

// Axis words with non-numeric values: X#5, X[#1+2]
val EXPR_RE = Regex("""(?<![A-Za-z])[XYIJxyij][ \t]*[#\[]""")
val G_RE = Regex("""(?<![A-Za-z])[Gg]0*(\d+(?:\.\d+)?)""")

// VectorForge addition: an arc radius word (R5 / r-2.5). Only used to warn when a scale is applied, because the
// radius is a length that would have to scale too (the app's own generator never emits R arcs).
val R_WORD_RE = Regex("""(?<![A-Za-z])[Rr][ \t]*[+-]?(?:\d+\.?\d*|\.\d+)""")

// G-codes whose X/Y are NOT toolpath points -> leave the line untouched
val PASSTHROUGH_G = setOf(10, 28, 30, 53, 92)

fun formatNumber(value: Double, precision: Int): String {
    // ANDROID PORT NOTE: pinned to Locale.ROOT. The default-locale String.format would print "1,5" instead of
    // "1.5" on a device set to a comma-decimal language, which would corrupt the G-code.
    var text = String.format(Locale.ROOT, "%.${precision}f", value)
    if (text.contains('.')) {
        text = text.trimEnd('0').trimEnd('.')
    }
    if (text == "" || text == "-" || text == "-0") {
        text = "0"
    }
    return text
}

/** Split `s` on `regex`, keeping the matched delimiters as separate elements
 *  (equivalent to Python's `re.split` with a capturing group). Even indices
 *  (0, 2, 4, ...) are the non-matching pieces; odd indices are the matches. */
fun splitKeepDelims(s: String, regex: Regex): List<String> {
    val out = mutableListOf<String>()
    var last = 0
    for (m in regex.findAll(s)) {
        out.add(s.substring(last, m.range.first))
        out.add(m.value)
        last = m.range.last + 1
    }
    out.add(s.substring(last))
    return out
}

/** One matched axis word, with positions made absolute within the whole line
 *  (the regex was run against a substring, so `off` is that substring's
 *  start offset in the line). Mirrors the small `W` wrapper class in the
 *  Python version. */
class Word(val off: Int, val m: MatchResult) {
    // group 1 = letter, group 3 = numeric value
    val letter: String get() = m.groupValues[1]
    val valueText: String get() = m.groupValues[3]
    val value: Double get() = valueText.toDouble()
    val valueRange: IntRange get() = m.groups[3]!!.range
    fun startValue(): Int = off + valueRange.first
    fun endValue(): Int = off + valueRange.last + 1
    fun endWhole(): Int = off + m.range.last + 1
}

data class Edit(val start: Int, val end: Int, val text: String)

// --------------------------------------------------------------------------- //
// Transformer
// --------------------------------------------------------------------------- //

class GCodeTransformer(
    direction: String? = null,
    angle: Double = 0.0,
    val offsetX: Double = 0.0,
    val offsetY: Double = 0.0,
    val precision: Int = 4,
    val fixedHome: Boolean = true,
    // VectorForge addition (see the port note): uniform scale about X0 Y0, applied together with the rotation.
    // 1.0 (the default) = exactly the original behaviour.
    val scale: Double = 1.0,
) {
    val tol: Double = 0.5 * 10.0.pow(-precision)
    var homeLines: Set<Int> = emptySet()
    var homeKept: Int = 0

    val cosA: Double
    val sinA: Double

    // modal state (positions are in the ORIGINAL frame)
    var absolute = true                // G90 / G91
    var arcAbsolute = false            // G90.1 / G91.1
    var x = 0.0
    var y = 0.0
    var motion: Int? = null            // last modal motion G-code (0,1,2,3)
    // where the pen physically is in the OUTPUT frame (program starts at 0,0)
    var px = 0.0
    var py = 0.0

    // extent of the transformed toolpath
    var minX = Double.POSITIVE_INFINITY
    var minY = Double.POSITIVE_INFINITY
    var maxX = Double.NEGATIVE_INFINITY
    var maxY = Double.NEGATIVE_INFINITY

    val warnings = mutableListOf<String>()
    var linesChanged = 0

    init {
        val theta = Math.toRadians(((angle % 360.0) + 360.0) % 360.0)
        var c = cos(theta)
        var s = sin(theta)
        // snap floating-point noise (cos(90deg) = 6.1e-17 ...)
        c = if (abs(c) < 1e-12) 0.0 else round(c * 1e12) / 1e12
        s = if (abs(s) < 1e-12) 0.0 else round(s * 1e12) / 1e12
        if (direction == "right") {        // clockwise
            s = -s
        }
        cosA = c
        sinA = s
    }

    // -- math -------------------------------------------------------------- //
    // rotation followed by the (optional) uniform scale. rotate() is the ONE place coordinates, relative moves and
    // arc centre offsets (I/J) are converted, and full() builds on it, so scale reaches all of them consistently.
    fun rotate(px0: Double, py0: Double): Pair<Double, Double> =
        Pair((px0 * cosA - py0 * sinA) * scale, (px0 * sinA + py0 * cosA) * scale)

    fun full(px0: Double, py0: Double): Pair<Double, Double> {
        val (rx, ry) = rotate(px0, py0)
        return Pair(rx + offsetX, ry + offsetY)
    }

    private fun track(px0: Double, py0: Double) {
        minX = min(minX, px0)
        maxX = max(maxX, px0)
        minY = min(minY, py0)
        maxY = max(maxY, py0)
    }

    /** Extent of a G2/G3 arc (all points already in the output frame).
     *  Includes the axis-extreme points the arc passes through. */
    private fun trackArc(
        sx: Double, sy: Double, ex: Double, ey: Double,
        cx: Double, cy: Double, clockwise: Boolean,
    ) {
        track(ex, ey)
        val r = hypot(sx - cx, sy - cy)
        if (r == 0.0) return
        val twoPi = 2 * PI
        val a0 = atan2(sy - cy, sx - cx)
        val a1 = atan2(ey - cy, ex - cx)
        var sweep = (if (clockwise) (a0 - a1) else (a1 - a0)).mod(twoPi)
        if (sweep < 1e-9) sweep = twoPi     // start == end -> full circle
        for (k in 0 until 4) {
            val ang = k * PI / 2
            val d = (if (clockwise) (a0 - ang) else (ang - a0)).mod(twoPi)
            if (d <= sweep) {
                track(cx + r * cos(ang), cy + r * sin(ang))
            }
        }
    }

    private fun warn(lineno: Int, msg: String) {
        warnings.add("line $lineno: $msg")
    }

    /** Core conversion for one X/Y-like pair.
     *  px/py: values found on the line (or null).
     *  absolute: true -> coordinates (rotate + offset); false -> vectors (rotate).
     *  base: previous position in original frame (used for absolute mode).
     *  Returns (tx, ty, emitX, emitY). */
    private fun convert(
        px0: Double?, py0: Double?, absoluteMode: Boolean,
        base: Pair<Double, Double>, phys: Pair<Double, Double>?,
    ): DoubleArray {
        val tx: Double; val ty: Double
        val emitX: Boolean; val emitY: Boolean
        if (absoluteMode) {
            val (bx, by) = base
            val nx = px0 ?: bx
            val ny = py0 ?: by
            val (ttx, tty) = full(nx, ny)
            val (ptx, pty) = phys ?: full(bx, by)
            tx = ttx; ty = tty
            emitX = px0 != null || abs(tx - ptx) > tol
            emitY = py0 != null || abs(ty - pty) > tol
        } else {
            val dx = px0 ?: 0.0
            val dy = py0 ?: 0.0
            val (ttx, tty) = rotate(dx, dy)
            tx = ttx; ty = tty
            emitX = px0 != null || abs(tx) > tol
            emitY = py0 != null || abs(ty) > tol
        }
        // pack emit flags as 1.0/0.0 alongside tx,ty for a simple 4-tuple return
        return doubleArrayOf(tx, ty, if (emitX) 1.0 else 0.0, if (emitY) 1.0 else 0.0)
    }

    /** Add edits for an (X,Y) or (I,J) pair. `words`: letter(upper) -> Word. */
    private fun pairEdits(
        words: Map<String, Word>, letters: Pair<String, String>,
        absoluteMode: Boolean, base: Pair<Double, Double>,
        edits: MutableList<Edit>, phys: Pair<Double, Double>? = null,
    ) {
        val (la, lb) = letters
        val ma = words[la]
        val mb = words[lb]
        if (ma == null && mb == null) return
        val pa = ma?.value
        val pb = mb?.value
        val conv = convert(pa, pb, absoluteMode, base, phys)
        val tx = conv[0]; val ty = conv[1]
        val emitA = conv[2] != 0.0; val emitB = conv[3] != 0.0

        val present = listOfNotNull(ma, mb)
        val anchor = present.maxByOrNull { it.endWhole() }!!
        val lower = anchor.letter[0].isLowerCase()

        // (match, original value, new value, emit, letter)
        val items = listOf(
            Triple(ma, pa, Pair(tx, emitA)) to la,
            Triple(mb, pb, Pair(ty, emitB)) to lb,
        )
        for ((triple, letter) in items) {
            val (m, orig, newEmit) = triple
            val (newVal, emit) = newEmit
            if (m != null) {
                // keep original text if the value is numerically unchanged
                if (abs(newVal - (orig ?: 0.0)) > tol) {
                    edits.add(Edit(m.startValue(), m.endValue(), formatNumber(newVal, precision)))
                }
            } else if (emit) {
                val ch = if (lower) letter.lowercase() else letter
                edits.add(Edit(anchor.endWhole(), anchor.endWhole(), " $ch${formatNumber(newVal, precision)}"))
            }
        }
    }

    // -- one line ------------------------------------------------------------ //
    fun processLine(line: String, lineno: Int): String {
        val stripped = line.trimEnd('\r', '\n')
        val newline = line.substring(stripped.length)

        val parts = splitKeepDelims(stripped, COMMENT_RE)
        val codePieces = mutableListOf<String>()
        val matches = mutableListOf<Pair<Int, MatchResult>>()
        var pos = 0
        var exprFound = false
        for ((i, seg) in parts.withIndex()) {
            if (i % 2 == 0) {
                codePieces.add(seg)
                for (m in WORD_RE.findAll(seg)) {
                    matches.add(Pair(pos, m))
                }
                if (EXPR_RE.containsMatchIn(seg)) exprFound = true
            }
            pos += seg.length
        }
        val codeText = codePieces.joinToString(" ")

        // modal updates
        val gCodes = G_RE.findAll(codeText).map { it.groupValues[1] }.toList()
        var skip = false
        for (g in gCodes) {
            when (g) {
                "90" -> absolute = true
                "91" -> absolute = false
                "90.1" -> arcAbsolute = true
                "91.1" -> arcAbsolute = false
                "0", "1", "2", "3" -> motion = g.toInt()
            }
            val gInt = g.toDouble().toInt()
            if (gInt in PASSTHROUGH_G && g.toDouble() != 90.1 && g.toDouble() != 91.1) {
                skip = true
            }
        }

        if (scale != 1.0 && motion in setOf(2, 3) && R_WORD_RE.containsMatchIn(codeText)) {
            warn(lineno, "arc radius (R) is not scaled")
        }

        if (matches.isEmpty() && !exprFound) return line
        if (skip) {
            val pt = gCodes
                .filter { it.toDouble().toInt() in PASSTHROUGH_G && it.toDouble() != 90.1 && it.toDouble() != 91.1 }
                .map { it.toDouble().toInt() }
                .toSet()
            val nonzero = matches.any { (_, m) -> abs(m.groupValues[3].toDouble()) > 0 }
            // "G92 X0 Y0" only declares the current spot as the origin: it is
            // correct as-is for rotation and offset, so no warning is needed
            if (matches.isNotEmpty() && (nonzero || pt != setOf(92))) {
                warn(lineno, "G10/G28/G30/G53/G92 line left unchanged")
            }
            return line
        }
        if (exprFound) {
            warn(lineno, "non-numeric axis value (parameter/expression) left unchanged")
        }

        // collect first occurrence of each letter, with absolute positions
        val words = LinkedHashMap<String, Word>()
        for ((off, m) in matches) {
            val key = m.groupValues[1].uppercase()
            words.getOrPut(key) { Word(off, m) }
        }

        val edits = mutableListOf<Edit>()
        val prev = Pair(x, y)
        val physPrev = Pair(px, py)

        // fixed start/end move to X0 Y0: keep it at 0 (add a missing axis if the
        // pen is not already at 0 on it)
        if (lineno in homeLines && absolute &&
            "I" !in words && "J" !in words &&
            ("X" in words || "Y" in words)
        ) {
            val anchor = listOfNotNull(words["X"], words["Y"]).maxByOrNull { it.endWhole() }!!
            val lower = anchor.letter[0].isLowerCase()
            for ((letter, phys) in listOf("X" to px, "Y" to py)) {
                if (letter !in words && abs(phys) > tol) {
                    val ch = if (lower) letter.lowercase() else letter
                    edits.add(Edit(anchor.endWhole(), anchor.endWhole(), " ${ch}0"))
                }
            }
            x = 0.0; y = 0.0
            px = 0.0; py = 0.0
            homeKept += 1
            return applyEdits(line, stripped, newline, edits)
        }

        // arc centre words first (they use the position BEFORE the move)
        if ("I" in words || "J" in words) {
            pairEdits(words, Pair("I", "J"), arcAbsolute, prev, edits)
        }

        // end point
        val arc = motion in setOf(2, 3) && ("I" in words || "J" in words)
        if ("X" in words || "Y" in words) {
            pairEdits(words, Pair("X", "Y"), absolute, prev, edits, phys = physPrev)
            val pxv = words["X"]?.value
            val pyv = words["Y"]?.value
            if (absolute) {
                x = pxv ?: x
                y = pyv ?: y
                val (fx, fy) = full(x, y)
                px = fx; py = fy
            } else {
                x += pxv ?: 0.0
                y += pyv ?: 0.0
                val (dx, dy) = rotate(pxv ?: 0.0, pyv ?: 0.0)
                px += dx
                py += dy
            }
        }

        // extent bookkeeping (for --keep-* and the bounds report)
        if (arc) {
            val i = words["I"]?.value
            val j = words["J"]?.value
            val sx = physPrev.first; val sy = physPrev.second
            val ex = px; val ey = py
            val ccx: Double; val ccy: Double
            if (arcAbsolute) {
                val cx = i ?: prev.first
                val cy = j ?: prev.second
                val (fcx, fcy) = full(cx, cy)
                ccx = fcx; ccy = fcy
            } else {
                val (rx, ry) = rotate(i ?: 0.0, j ?: 0.0)
                ccx = sx + rx; ccy = sy + ry
            }
            trackArc(sx, sy, ex, ey, ccx, ccy, motion == 2)
        } else if ("X" in words || "Y" in words) {
            track(px, py)
        }

        return applyEdits(line, stripped, newline, edits)
    }

    private fun applyEdits(line: String, stripped: String, newline: String, edits: List<Edit>): String {
        if (edits.isEmpty()) return line

        var out = stripped
        // apply from the end so earlier offsets stay valid; inserts (start==end)
        // at the same spot keep their relative order
        val sorted = edits.sortedWith(compareByDescending<Edit> { it.start }.thenByDescending { it.end })
        for (e in sorted) {
            out = out.substring(0, e.start) + e.text + out.substring(e.end)
        }
        linesChanged += 1
        return out + newline
    }

    /** Line numbers of the leading and trailing absolute moves whose target
     *  is exactly X0 Y0 (the pen's start / "go home" moves). */
    private fun findHomeLines(lines: List<String>): Set<Int> {
        var absoluteMode = true
        var motionMode: Int? = null
        var xx = 0.0
        var yy = 0.0
        data class Move(val lineno: Int, val isHome: Boolean)
        val moves = mutableListOf<Move>()

        for ((idx, rawLine) in lines.withIndex()) {
            val n = idx + 1
            val stripped = rawLine.trimEnd('\r', '\n')
            val parts = splitKeepDelims(stripped, COMMENT_RE)
            val code = parts.filterIndexed { i, _ -> i % 2 == 0 }.joinToString(" ")
            val gCodes = G_RE.findAll(code).map { it.groupValues[1] }.toList()
            for (g in gCodes) {
                when (g) {
                    "90" -> absoluteMode = true
                    "91" -> absoluteMode = false
                    "0", "1", "2", "3" -> motionMode = g.toInt()
                }
            }
            if (gCodes.any { it.toDouble().toInt() in PASSTHROUGH_G && it.toDouble() != 90.1 && it.toDouble() != 91.1 }) {
                continue
            }
            val w = LinkedHashMap<String, Double>()
            for (m in WORD_RE.findAll(code)) {
                val key = m.groupValues[1].uppercase()
                w.getOrPut(key) { m.groupValues[3].toDouble() }
            }
            if ("X" !in w && "Y" !in w) continue
            if (absoluteMode) {
                xx = w["X"] ?: xx
                yy = w["Y"] ?: yy
            } else {
                xx += w["X"] ?: 0.0
                yy += w["Y"] ?: 0.0
            }
            val arcIj = motionMode in setOf(2, 3) && ("I" in w || "J" in w)
            val isHome = absoluteMode && !arcIj && abs(xx) < 1e-9 && abs(yy) < 1e-9
            moves.add(Move(n, isHome))
        }
        val real = moves.indices.filter { !moves[it].isHome }
        if (real.isEmpty()) return emptySet()
        val lead = real.first()
        val trail = real.last()
        val result = mutableSetOf<Int>()
        for (i in 0 until lead) result.add(moves[i].lineno)
        for (i in (trail + 1) until moves.size) result.add(moves[i].lineno)
        return result
    }

    fun processText(text: String): String {
        // splitlines(keepends=True) equivalent
        val lines = mutableListOf<String>()
        var start = 0
        var i = 0
        while (i < text.length) {
            val c = text[i]
            if (c == '\r') {
                val end = if (i + 1 < text.length && text[i + 1] == '\n') i + 2 else i + 1
                lines.add(text.substring(start, end))
                i = end; start = end
            } else if (c == '\n') {
                lines.add(text.substring(start, i + 1))
                i += 1; start = i
            } else {
                i += 1
            }
        }
        if (start < text.length) lines.add(text.substring(start))

        if (fixedHome) {
            homeLines = findHomeLines(lines)
        }
        val sb = StringBuilder()
        for ((idx, l) in lines.withIndex()) {
            sb.append(processLine(l, idx + 1))
        }
        return sb.toString()
    }
}

// --------------------------------------------------------------------------- //
// In-app entry point (replaces the CLI's runMain)
// --------------------------------------------------------------------------- //

/**
 * Every processing option of the original CLI. (Its `input`, `-o/--output`, `--in-place` and `--interactive`
 * are file / prompt plumbing that the app does not need: it transforms the text it has just generated.)
 *
 *  CLI flag                          field
 *  --rotate-left DEG / --rotate-right DEG   [direction] = "left" / "right" (null = no rotation) + [angle]
 *  --offset-x X / --offset-y Y       [offsetX] / [offsetY]
 *  --keep-positive / --keep-negative [keepPositive] (= north + east) / [keepNegative] (= south + west)
 *  --keep-east / -west / -north / -south    [keepEast] / [keepWest] / [keepNorth] / [keepSouth]
 *  --no-fixed-home                   [noFixedHome]
 *  --max-x X / --max-y Y             [maxX] / [maxY]
 *  --precision N                     [precision]
 */
class TransformOptions(
    val direction: String? = null,
    val angle: Double = 0.0,
    val offsetX: Double = 0.0,
    val offsetY: Double = 0.0,
    val keepPositive: Boolean = false,
    val keepNegative: Boolean = false,
    val keepEast: Boolean = false,
    val keepWest: Boolean = false,
    val keepNorth: Boolean = false,
    val keepSouth: Boolean = false,
    val noFixedHome: Boolean = false,
    val maxX: Double? = null,
    val maxY: Double? = null,
    val precision: Int = 4,
)

/**
 * [text] is the transformed G-code. [report] is what the CLI printed to stderr, line for line and in the same
 * order (home / keep shift / offset / bounds / warnings / "done"), for the app to show. [warningCount] is how
 * many of those lines are warnings.
 */
class TransformResult(
    val text: String,
    val report: List<String>,
    val warningCount: Int,
    val linesChanged: Int,
)

/**
 * The CLI's `runMain()` on a String. Throws IllegalArgumentException for exactly the inputs the CLI rejects
 * (angle outside 0-360, precision outside 0-10, non-finite numbers, east+west or north+south together).
 *
 * Steps (same as the CLI):
 *  1. rotation only (offset 0) -> measure the toolpath (only if a --keep-* is requested)
 *  2. --keep-* : shift the whole path by the smallest amount that brings it onto the requested side
 *  3. user offsets on top, always last
 */
fun transformGcode(text: String, o: TransformOptions): TransformResult {
    require(o.precision in 0..10) { "precision must be between 0 and 10" }
    if (o.direction != null) require(o.angle.isFinite() && o.angle in 0.0..360.0) { "angle must be between 0 and 360" }
    require(o.offsetX.isFinite() && o.offsetY.isFinite()) { "offset must be a finite number" }
    require((o.maxX?.isFinite() ?: true) && (o.maxY?.isFinite() ?: true)) { "max-x / max-y must be a finite number" }

    val direction = o.direction
    val angle = if (direction != null) o.angle else 0.0

    // keep-region: one constraint per axis (E/W for X, N/S for Y)
    val east = o.keepEast || o.keepPositive
    val west = o.keepWest || o.keepNegative
    val north = o.keepNorth || o.keepPositive
    val south = o.keepSouth || o.keepNegative
    require(!(east && west)) { "conflicting options: east (X>=0) and west (X<=0) cannot be combined" }
    require(!(north && south)) { "conflicting options: north (Y>=0) and south (Y<=0) cannot be combined" }
    val keepAny = east || west || north || south
    val region = (if (north || south) (if (north) "N" else "S") else "") +
        (if (east || west) (if (east) "E" else "W") else "")

    fun run(ox: Double, oy: Double): Pair<GCodeTransformer, String> {
        val t = GCodeTransformer(direction, angle, ox, oy, o.precision, fixedHome = !o.noFixedHome)
        return Pair(t, t.processText(text))
    }

    var shiftX = 0.0
    var shiftY = 0.0
    val trResult = if (keepAny) run(0.0, 0.0) else null
    if (keepAny) {
        val tr0 = trResult!!.first
        if (tr0.minX != Double.POSITIVE_INFINITY) {
            val tiny = 1e-9
            if (east && tr0.minX < -tiny) shiftX = -tr0.minX
            if (west && tr0.maxX > tiny) shiftX = -tr0.maxX
            if (north && tr0.minY < -tiny) shiftY = -tr0.minY
            if (south && tr0.maxY > tiny) shiftY = -tr0.maxY
        }
    }
    val totalX = shiftX + o.offsetX
    val totalY = shiftY + o.offsetY
    val finalResult: Pair<GCodeTransformer, String> =
        if (keepAny && totalX == 0.0 && totalY == 0.0) trResult!! else run(totalX, totalY)
    val tr = finalResult.first
    val result = finalResult.second

    // ---- the report the CLI printed (warnings first, then the summary lines) ----
    val report = mutableListOf<String>()
    var warnings = 0
    fun warning(msg: String) { report.add("warning: $msg"); warnings++ }

    for (w in tr.warnings) warning(w)
    if (tr.minX != Double.POSITIVE_INFINITY) {
        fun fmt(v: Double) = formatNumber(v, 4)
        if (tr.homeKept > 0) {
            report.add("home: ${tr.homeKept} start/end move(s) to X0 Y0 kept at 0 (pen begins and ends at 0)")
        }
        if (keepAny) {
            report.add("keep-$region: shift X${fmt(shiftX)} Y${fmt(shiftY)} (applied before the offset)")
        }
        if (o.offsetX != 0.0 || o.offsetY != 0.0) {
            report.add("offset: X${fmt(o.offsetX)} Y${fmt(o.offsetY)} (applied last)")
        }
        report.add("toolpath bounds: X[${fmt(tr.minX)}, ${fmt(tr.maxX)}]  Y[${fmt(tr.minY)}, ${fmt(tr.maxY)}]")
        if (o.maxX != null && tr.maxX > o.maxX + 1e-9) {
            warning("toolpath exceeds --max-x ${o.maxX} (reaches X${fmt(tr.maxX)})")
        }
        if (o.maxY != null && tr.maxY > o.maxY + 1e-9) {
            warning("toolpath exceeds --max-y ${o.maxY} (reaches Y${fmt(tr.maxY)})")
        }
        val tol = 1e-9
        if (keepAny) {
            val bad = mutableListOf<String>()
            if (east && tr.minX < -tol) bad.add("X down to ${fmt(tr.minX)}")
            if (west && tr.maxX > tol) bad.add("X up to ${fmt(tr.maxX)}")
            if (north && tr.minY < -tol) bad.add("Y down to ${fmt(tr.minY)}")
            if (south && tr.maxY > tol) bad.add("Y up to ${fmt(tr.maxY)}")
            if (bad.isNotEmpty()) {
                warning(
                    "because the offset is applied last, the toolpath leaves the requested $region region (" +
                        bad.joinToString(", ") + ")"
                )
            }
        } else if (tr.minX < -tol || tr.minY < -tol) {
            warning("part of the toolpath is at negative X/Y (use --keep-positive to shift it inside the axes)")
        }
    }
    report.add("done: ${tr.linesChanged} line(s) transformed")

    return TransformResult(text = result, report = report, warningCount = warnings, linesChanged = tr.linesChanged)
}

/**
 * FINAL NORMALIZE: the generator's own normalize step (`normalizeLines`, the one behind NEW MIN / NEW MAX in the
 * header of POST-PROCESSING) run again on finished G-code text -- normally the output of [transformGcode].
 *
 * Why it exists: a rotation (or keep / offset) moves the toolpath off the range the first normalize produced,
 * e.g. rotating a 0..40 drawing by 30 degrees grows its X/Y extent and pushes part of it below 0. This maps the
 * drawing's bounding box back onto [newMin, newMax] on each axis, exactly as the header pair does. Like the
 * original it only touches the G1 moves inside drawn strokes; the fixed home moves stay where they are.
 * The line structure is unchanged, so the line count stays the same.
 */
fun normalizeGcodeText(text: String, newMin: Double, newMax: Double): String {
    require(newMin.isFinite() && newMax.isFinite()) { "new min / new max must be finite numbers" }
    val hadTrailingNewline = text.endsWith("\n")
    val lines = text.removeSuffix("\n").split("\n")
    val out = normalizeLines(lines, newMin, newMax).joinToString("\n")
    return if (hadTrailingNewline) out + "\n" else out
}
