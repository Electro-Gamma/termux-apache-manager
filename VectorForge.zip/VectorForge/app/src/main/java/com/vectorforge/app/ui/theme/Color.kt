package com.vectorforge.app.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * Every one of these hex values is copied verbatim from the Tailwind
 * `theme.extend.colors` block in the supplied UI reference (code.html).
 * The token names there already match Material 3's expanded `ColorScheme`
 * role names one-for-one (kebab-case vs. camelCase), which is what
 * `Theme.kt` maps them onto below -- nothing here was re-picked or
 * "improved"; it is the provided palette, unmodified.
 */

// -- Primary ------------------------------------------------------------
val Primary = Color(0xFF4FDBC8)
val OnPrimary = Color(0xFF003731)
val PrimaryContainer = Color(0xFF14B8A6)
val OnPrimaryContainer = Color(0xFF00423B)
val InversePrimary = Color(0xFF006B5F)
val PrimaryFixed = Color(0xFF71F8E4)
val PrimaryFixedDim = Color(0xFF4FDBC8)
val OnPrimaryFixed = Color(0xFF00201C)
val OnPrimaryFixedVariant = Color(0xFF005048)

// -- Secondary ------------------------------------------------------------
val Secondary = Color(0xFFFFB95F)
val OnSecondary = Color(0xFF472A00)
val SecondaryContainer = Color(0xFFEE9800)
val OnSecondaryContainer = Color(0xFF5B3800)
val SecondaryFixed = Color(0xFFFFDDB8)
val SecondaryFixedDim = Color(0xFFFFB95F)
val OnSecondaryFixed = Color(0xFF2A1700)
val OnSecondaryFixedVariant = Color(0xFF653E00)

// -- Tertiary ------------------------------------------------------------
val Tertiary = Color(0xFFFFB3AD)
val OnTertiary = Color(0xFF68000A)
val TertiaryContainer = Color(0xFFFF7D76)
val OnTertiaryContainer = Color(0xFF7B000E)
val TertiaryFixed = Color(0xFFFFDAD7)
val TertiaryFixedDim = Color(0xFFFFB3AD)
val OnTertiaryFixed = Color(0xFF410004)
val OnTertiaryFixedVariant = Color(0xFF930013)

// -- Error ------------------------------------------------------------
val Error = Color(0xFFFFB4AB)
val OnError = Color(0xFF690005)
val ErrorContainer = Color(0xFF93000A)
val OnErrorContainer = Color(0xFFFFDAD6)

// -- Surface / background ------------------------------------------------
val Background = Color(0xFF051424)
val OnBackground = Color(0xFFD4E4FA)
val Surface = Color(0xFF051424)
val OnSurface = Color(0xFFD4E4FA)
val SurfaceVariant = Color(0xFF273647)
val OnSurfaceVariant = Color(0xFFBBCAC6)
val SurfaceTint = Color(0xFF4FDBC8)
val InverseSurface = Color(0xFFD4E4FA)
val InverseOnSurface = Color(0xFF233143)
val Outline = Color(0xFF859490)
val OutlineVariant = Color(0xFF3C4947)

val SurfaceDim = Color(0xFF051424)
val SurfaceBright = Color(0xFF2C3A4C)
val SurfaceContainerLowest = Color(0xFF010F1F)
val SurfaceContainerLow = Color(0xFF0D1C2D)
val SurfaceContainer = Color(0xFF122131)
val SurfaceContainerHigh = Color(0xFF1C2B3C)
val SurfaceContainerHighest = Color(0xFF273647)
