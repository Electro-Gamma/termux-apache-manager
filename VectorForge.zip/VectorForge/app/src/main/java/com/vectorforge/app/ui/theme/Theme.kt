package com.vectorforge.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

/**
 * The reference (code.html) only ever defines one palette -- the dark one
 * above -- and applies it unconditionally (its "Toggle Theme" button just
 * flips a class with no second palette behind it). Per the brief ("do not
 * choose different colors... do not invent a different visual theme"),
 * this app therefore always renders in this exact scheme; there is no
 * light-mode variant to fall back to, and none is invented here.
 *
 * The "fixed"/"fixed dim"/"on...fixed"/"on...fixed variant" roles from the
 * reference palette (see Color.kt) are deliberately NOT applied here: the
 * Material3 version this project resolves has no such fields on
 * ColorScheme -- neither as darkColorScheme() parameters nor via
 * ColorScheme.copy() (the compiler rejected both). No screen reads them, so
 * nothing visual is lost; the constants stay in Color.kt as a record of
 * the full supplied palette, ready to wire in if the Material3 dependency
 * is ever upgraded to a version that has those roles.
 */
private val VectorForgeColorScheme = darkColorScheme(
    primary = Primary,
    onPrimary = OnPrimary,
    primaryContainer = PrimaryContainer,
    onPrimaryContainer = OnPrimaryContainer,
    inversePrimary = InversePrimary,

    secondary = Secondary,
    onSecondary = OnSecondary,
    secondaryContainer = SecondaryContainer,
    onSecondaryContainer = OnSecondaryContainer,

    tertiary = Tertiary,
    onTertiary = OnTertiary,
    tertiaryContainer = TertiaryContainer,
    onTertiaryContainer = OnTertiaryContainer,

    error = Error,
    onError = OnError,
    errorContainer = ErrorContainer,
    onErrorContainer = OnErrorContainer,

    background = Background,
    onBackground = OnBackground,
    surface = Surface,
    onSurface = OnSurface,
    surfaceVariant = SurfaceVariant,
    onSurfaceVariant = OnSurfaceVariant,
    surfaceTint = SurfaceTint,
    inverseSurface = InverseSurface,
    inverseOnSurface = InverseOnSurface,
    outline = Outline,
    outlineVariant = OutlineVariant,

    surfaceDim = SurfaceDim,
    surfaceBright = SurfaceBright,
    surfaceContainerLowest = SurfaceContainerLowest,
    surfaceContainerLow = SurfaceContainerLow,
    surfaceContainer = SurfaceContainer,
    surfaceContainerHigh = SurfaceContainerHigh,
    surfaceContainerHighest = SurfaceContainerHighest,
)

@Composable
fun VectorForgeTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = VectorForgeColorScheme,
        typography = AppTypography,
        shapes = AppShapes,
        content = content
    )
}
