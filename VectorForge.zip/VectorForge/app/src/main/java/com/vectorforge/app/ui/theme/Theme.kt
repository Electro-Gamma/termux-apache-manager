package com.vectorforge.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf

/**
 * VectorForge has two themes and follows the system's Light / Dark setting automatically (MainActivity passes
 * isSystemInDarkTheme() in; there is no in-app switch).
 *
 *  - Dark: the palette supplied with the UI reference (code.html), unchanged.
 *  - Light: derived from that same palette (see the LIGHT PALETTE section in Color.kt): same hues, same role
 *    names, same surface-tier ordering, so every screen keeps its visual hierarchy.
 *
 * Every composable reads its colours from MaterialTheme.colorScheme, so the whole app follows the active
 * scheme. The few places that need to know which theme is active (hairline borders that only the light
 * theme needs) read [LocalVfDarkTheme].
 *
 * The "fixed"/"fixed dim"/"on...fixed"/"on...fixed variant" roles from the reference palette (see Color.kt)
 * are deliberately NOT applied here: the Material3 version this project resolves has no such fields on
 * ColorScheme -- neither as darkColorScheme() parameters nor via ColorScheme.copy() (the compiler rejected
 * both). No screen reads them; the light palette borrows a few of their tone values instead.
 */
private val VectorForgeColorScheme = darkColorScheme(
    primary = Primary,
    onPrimary = OnPrimary,
    primaryContainer = PrimaryContainer,
    onPrimaryContainer = OnPrimaryContainer,
    inversePrimary = InversePrimary,

    secondary = Secondary,
    onSecondary = OnSecondary,
    secondaryContainer = SecondaryContainer,
    onSecondaryContainer = OnSecondaryContainer,

    tertiary = Tertiary,
    onTertiary = OnTertiary,
    tertiaryContainer = TertiaryContainer,
    onTertiaryContainer = OnTertiaryContainer,

    error = Error,
    onError = OnError,
    errorContainer = ErrorContainer,
    onErrorContainer = OnErrorContainer,

    background = Background,
    onBackground = OnBackground,
    surface = Surface,
    onSurface = OnSurface,
    surfaceVariant = SurfaceVariant,
    onSurfaceVariant = OnSurfaceVariant,
    surfaceTint = SurfaceTint,
    inverseSurface = InverseSurface,
    inverseOnSurface = InverseOnSurface,
    outline = Outline,
    outlineVariant = OutlineVariant,

    surfaceDim = SurfaceDim,
    surfaceBright = SurfaceBright,
    surfaceContainerLowest = SurfaceContainerLowest,
    surfaceContainerLow = SurfaceContainerLow,
    surfaceContainer = SurfaceContainer,
    surfaceContainerHigh = SurfaceContainerHigh,
    surfaceContainerHighest = SurfaceContainerHighest,
)

private val VectorForgeLightColorScheme = lightColorScheme(
    primary = LightPrimary,
    onPrimary = LightOnPrimary,
    primaryContainer = LightPrimaryContainer,
    onPrimaryContainer = LightOnPrimaryContainer,
    inversePrimary = LightInversePrimary,

    secondary = LightSecondary,
    onSecondary = LightOnSecondary,
    secondaryContainer = LightSecondaryContainer,
    onSecondaryContainer = LightOnSecondaryContainer,

    tertiary = LightTertiary,
    onTertiary = LightOnTertiary,
    tertiaryContainer = LightTertiaryContainer,
    onTertiaryContainer = LightOnTertiaryContainer,

    error = LightError,
    onError = LightOnError,
    errorContainer = LightErrorContainer,
    onErrorContainer = LightOnErrorContainer,

    background = LightBackground,
    onBackground = LightOnBackground,
    surface = LightSurface,
    onSurface = LightOnSurface,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = LightOnSurfaceVariant,
    surfaceTint = LightSurfaceTint,
    inverseSurface = LightInverseSurface,
    inverseOnSurface = LightInverseOnSurface,
    outline = LightOutline,
    outlineVariant = LightOutlineVariant,

    surfaceDim = LightSurfaceDim,
    surfaceBright = LightSurfaceBright,
    surfaceContainerLowest = LightSurfaceContainerLowest,
    surfaceContainerLow = LightSurfaceContainerLow,
    surfaceContainer = LightSurfaceContainer,
    surfaceContainerHigh = LightSurfaceContainerHigh,
    surfaceContainerHighest = LightSurfaceContainerHighest,
)

/** True while the dark theme is active. Only needed where the two themes differ in more than colour values. */
val LocalVfDarkTheme = staticCompositionLocalOf { true }

/**
 * @param darkTheme which scheme to apply. Defaults to dark (the app's original look), so a caller that does not
 * pass it keeps getting exactly what it got before.
 */
@Composable
fun VectorForgeTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit,
) {
    CompositionLocalProvider(LocalVfDarkTheme provides darkTheme) {
        MaterialTheme(
            colorScheme = if (darkTheme) VectorForgeColorScheme else VectorForgeLightColorScheme,
            typography = AppTypography,
            shapes = AppShapes,
            content = content
        )
    }
}
