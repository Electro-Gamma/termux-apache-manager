# Add project specific ProGuard rules here.
# minifyEnabled is off by default for this project (see app/build.gradle.kts);
# these rules only take effect if you turn it on for a release build.

# Keep the ported G-code / Potrace engine classes intact -- they're pure
# data/algorithm classes with no reflection use, but keeping them unobfuscated
# makes reading a stack trace from a field bug report far easier.
-keep class com.vectorforge.app.engine.** { *; }
