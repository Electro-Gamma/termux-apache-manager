plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.vectorforge.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.vectorforge.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }

    // ROOT CAUSE FIX (carried over from NCViewerOffline's own build.gradle.kts): AGP/aapt2's
    // default ignoreAssetsPattern is
    //   !.svn:!.git:!.ds_store:!*.scc:.*:<dir>_*:!CVS:!thumbs.db:!picasa.ini:!*~
    // and its "<dir>_*" entry silently drops every assets directory whose name starts with "_".
    // That would remove assets/www/_nuxt/ (all of the embedded G-code viewer's JavaScript/CSS)
    // from the APK while index.html and the rest of assets/www survive -- the viewer would load
    // a blank/broken page with every /_nuxt/*.js a 404, with no build error to explain why.
    // Same default pattern with only "<dir>_*" removed:
    androidResources {
        ignoreAssetsPattern = "!.svn:!.git:!.ds_store:!*.scc:.*:!CVS:!thumbs.db:!picasa.ini:!*~"
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    // -- Compose (BOM pins all androidx.compose.* versions together) -------
    implementation(platform("androidx.compose:compose-bom:2024.09.03"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")
    implementation("androidx.compose.material:material-icons-extended")
    debugImplementation("androidx.compose.ui:ui-tooling")

    // -- Core Android / lifecycle / activity ---------------------------------
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.6")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.6")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("androidx.activity:activity-compose:1.9.2")

    // -- Coroutines (background thread for tracing / G-code generation) -----
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
