// Top-level build file: plugin versions are declared here (with apply
// false) and actually applied in app/build.gradle.kts. This keeps a
// single source of truth for versions across (a future) multi-module setup.
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "2.0.20" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.20" apply false
}

tasks.register("clean", Delete::class) {
    delete(rootProject.layout.buildDirectory)
}
