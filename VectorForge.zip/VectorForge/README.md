# VectorForge (Android)

A native Android/Kotlin app that ports the provided `Potrace.kt` (raster
image -> SVG tracing) and `SvgToGcodeUnicorn.kt` (SVG -> pen-plotter
G-code) engines into a two-tab app themed exactly from the supplied
`code.html` UI reference.

- **Tab 1 -- Convert**: the full functional pipeline. Pick an image, trace
  it to SVG with every Potrace parameter exposed, feed that SVG into the
  G-code generator with every one of its parameters exposed, and get a
  real, on-disk G-code file out the other end.
- **Tab 2 -- G-Code Viewer**: the complete NC Viewer Offline app (see
  "G-Code Viewer tab" below). Generated G-code can be sent straight into it.

## Opening it

Open the `VectorForge/` folder directly in Android Studio (Ladybug/Koala
or newer) via **File > Open**. Gradle sync will pull every dependency
from Google's/Maven Central's repositories, so you'll need network access
the first time. If Android Studio warns about the Gradle wrapper, let it
regenerate `gradlew`/`gradle-wrapper.jar` -- **that one binary file
couldn't be included** in this delivery (everything else here is plain
text); Android Studio creates it automatically on first sync, or you can
run `gradle wrapper` yourself with any local Gradle 8.x install.

You'll need the Android SDK Platform for API 35 installed (Android
Studio will prompt you if it's missing). If you'd rather not install it,
drop `compileSdk`/`targetSdk` to `34` in `app/build.gradle.kts`.

## What the two engine files needed to change

Both files live under `app/src/main/java/com/vectorforge/app/engine/`,
each with an "ANDROID PORT NOTE" comment at the point of every change.
In short:

- **`SvgToGcodeUnicorn.kt` needed no algorithmic changes at all.** Android
  ships the same `javax.xml.parsers`/`org.w3c.dom` DOM parser the file
  already used. The only thing removed was the argv-parsing CLI wrapper
  (`parseArgs`, `main`, `--help` text) -- replaced with one plain function,
  `svgFileToGcode(file, args)`, that the UI calls directly with an `Args`
  built from the on-screen controls. Every field, default, and the whole
  parse -> walk -> build -> normalize -> reduce pipeline is unchanged.
- **`Potrace.kt` needed its image I/O swapped**, since
  `java.awt.image.BufferedImage`/`javax.imageio.ImageIO` (desktop JDK
  only) don't exist on Android. `loadBitmap`, `pillowGrayscaleThreshold`,
  and `traceImageMode2` now use `android.graphics.Bitmap`/`BitmapFactory`
  instead -- same formulas, same thresholding, same PBM output. The core
  two-phase decompose/trace algorithm (everything from `Curve`/`PrivPath`
  through `potraceTrace`) is byte-for-byte untouched, since it never
  touched AWT to begin with. Its CLI `main()` was removed the same way.
  One latent bug was also fixed in the port: `fmt()`'s `String.format` now
  pins `Locale.ROOT`, so SVG coordinates can't come out with a comma
  decimal separator on a non-English device.

Both engine files are direct, otherwise-unmodified transcriptions of what
you provided -- every parameter you can see in the UI maps to one field on
`Params`/`Args`.

## Design/assumption notes

- **No Android build-example project was provided** -- only the theme
  (`code.html`) and the two Kotlin engine files came through, not an
  example app to mirror the project/Gradle structure from. This is built
  as a standard modern single-module Compose + Material 3 app instead
  (Kotlin 2.0.20, AGP 8.5.2, compose-bom 2024.09.03). If you do have that
  example project, share it and the structure can be adjusted to match.
- **Color palette**: `ui/theme/Color.kt`/`Theme.kt` reproduce the
  reference's Tailwind color tokens exactly -- they already use Material
  3's own `ColorScheme` role names (primary/secondary/tertiary, error,
  surface-container tiers, etc.), so each one maps onto
  `darkColorScheme(...)` one-for-one with no re-picking (the light scheme is derived from the same palette). The one
  exception: the twelve "fixed"/"fixed dim" roles are kept in `Color.kt`
  but not applied, because the Material3 version this project resolves
  has no such fields on `ColorScheme` (confirmed by the compiler). No
  screen uses them.
- **Two themes (Light / Dark)**, following the system setting: see "Light / Dark theme and responsive layout" below.
  Dark is the supplied palette, unchanged; Light is derived from it.
- **Typography**: sizes, weights, line-heights and letter-spacing all
  match the reference's type scale exactly (see `ui/theme/Type.kt`). The
  font family itself is the platform sans-serif (Roboto) standing in for
  "Plus Jakarta Sans", since embedding that font's actual binary isn't
  possible from a text-only delivery. Drop the four .ttf weights into
  `res/font/` and point `AppFontFamily` at them for a pixel-exact match.
- **Storage**: no storage permission is requested anywhere. Input images
  go through the system Photo Picker; input SVGs through the Storage
  Access Framework document picker; both are copied into this app's own
  app-specific external storage, where the ported engine code reads/writes
  them as plain `File`s exactly as originally written. The folder/
  "drive_file_move" icon buttons next to each output path use SAF's
  "Save As" dialog to additionally copy a finished file wherever you
  choose.
- **No header**: the top app bar (logo, "VectorForge / CONVERT", ENGINE READY chip and its static icons) and the
  "Workflow Pipeline" card (Local Engine v1.16, IMAGE -> SVG / SVG -> GCODE steps) were removed on request, so the
  Stage 01 card starts right under the status bar. The icons had no click handlers, so no function was lost.
- **Output paths live in the parameter dropdowns**: OUTPUT SVG PATH (with its "Ready to trace / Traced" badge and
  Export button) is the first item inside "Potrace Parameters", and OUTPUT G-CODE PATH (with its Export button) is
  the first item inside "SVG2GCODE Parameters". Both dropdowns are collapsed by default, so the paths are only
  visible when expanded. The fields, handlers and export behaviour are unchanged.
- **Licensing**: the Potrace port keeps the original file's GPL v2 header
  comment as-authored -- worth knowing if this app is ever distributed.

## SVG -> G-code: prefilled vs. optional settings

The G-code generator starts from the desktop CLI run that is known to work:

    java -jar svg2gcode.jar in.svg -o out.gcode --pen-up-angle 50 \
        --pen-down-angle 30 --xy-feedrate 3500 --new-min 0 --new-max 40 --no-reduce

- **Prefilled, always passed**: pen-up angle (50), pen-down angle (30), XY
  feedrate (3500), new min (0), new max (40), and the reduce / thin points
  toggle (OFF, which is `--no-reduce`).
- **Everything else is optional**: the input starts *empty* and shows the
  engine's default value only as a faint hint. While it is empty it is
  **not passed** to the generator (same as leaving that CLI flag off). Type
  a value and it is used; clear the input and it is unused again. The
  on/off switches (register pen, continuous, pause on layer, normalize) show
  the default dimmed until you flip them; a small reset button then returns
  them to "unused". See `ConvertViewModel.convertToGcode()`.

## Android XML parser note

`SvgToGcodeUnicorn.kt`'s `newDocumentBuilder()` originally called
`isXIncludeAware = false`. Android's XML parser throws
`This parser does not support specification "Unknown" version "0.0"` on
*any* XInclude call, even with `false` (desktop Java accepts it). It is now
wrapped in try/catch, so it is a no-op on Android.

## One honest limitation

This was written and reviewed carefully (including a full pass matching
every function signature the UI/ViewModel calls against the actual ported
engine code), but there's no Android SDK/Gradle available in the
environment this was built in, so **none of this has been compiled**.
Everything here is source code ready to build, not a build that's been
verified green. If Android Studio's first sync turns up an error, it's
almost certainly a small one (an import, an icon name) -- the
architecture and the engine integration underneath it are solid.

## Building a signed release APK

`app/build.gradle.kts` signs the release build when `VECTORFORGE_KEYSTORE` (path), `VECTORFORGE_KEYSTORE_PASSWORD`,
`VECTORFORGE_KEY_ALIAS` and `VECTORFORGE_KEY_PASSWORD` are set; otherwise `assembleRelease` yields an unsigned APK,
which cannot be installed. The Colab notebook (`VectorForge_APK.ipynb`) generates a throwaway keystore, sets those
variables, builds debug and release together and downloads both APKs plus the keystore. An APK signed with a
different key cannot upgrade an existing install in place (uninstall first), so keep the keystore and its password
if you want later builds to upgrade over this one. R8 minification stays off (`isMinifyEnabled = false`).

## Light / Dark theme and responsive layout

**Automatic.** There is no switch: the app follows the system's Light / Dark setting (Settings > Display) and
changes live when the system does (scheduled dark mode, quick-settings tile). The Activity handles uiMode changes
itself, so nothing is recreated and nothing typed or loaded is lost.

**How it is applied.**

- `ui/theme/Color.kt` has a LIGHT PALETTE section; `Theme.kt` builds `lightColorScheme(...)` from it and
  `VectorForgeTheme(darkTheme)` picks the scheme. Every composable already read `MaterialTheme.colorScheme`, so the
  Convert screen, dialogs, dropdown menus, switches, sliders, text fields and the bottom bar all follow it. No screen
  hard-codes a dark colour. Two things the light theme needs that the dark one did not: hairline outlines on the
  stage cards, dropdown sections and bottom bar (white-on-near-white needs them), via `LocalVfDarkTheme`.
- Status / navigation bar icons are re-styled on every theme change (`enableEdgeToEdge` with a matching `SystemBarStyle`),
  because the system's own dark mode says nothing about which theme the app shows. The window background follows too.
- The native viewer chrome (the floating pills, the pane divider, the Replace / Append / Cancel dialogs) goes through
  `ncviewer/ViewerTheme.kt`, which restyles whatever is already on screen when the theme changes.
- **Viewer 1 / Viewer 2 follow the theme too.** Their content is the bundled NC Viewer website (Ace editor, three.js
  backplot), which is fixed-light and has no theme of its own. In the dark theme everything on the page is darkened
  with a CSS filter (`invert(1) hue-rotate(180deg)`, hues kept) **except the branch that holds the plot canvas**:
  a small script (added by `AppAssetHandler` to the served `index.html`) finds `#nc-plot`, filters every sibling along
  its ancestor chain and gives the chain a dark background. The canvas therefore shows the site's own colours: blue
  cuts (`#0000FF`), orange rapids, red / green axes. (Filtering the canvas and cancelling the filter does not work:
  a saturated colour like pure blue is clamped in the middle and comes back as navy.) The canvas background and grid
  are made dark through the site's own config, via two small anchored patches in the bundled JS
  (`pages/index.*.js`: config colours made theme-dependent and exposed; `10.*.js`: a handle on the plot objects).
  `NCVNative.isDark()` tells the page the theme before first paint and `ViewerTheme` switches it live
  (background, grid and filters) without a reload, so a loaded program and editor text are untouched.
  Pure `#0000FF` is dim on a dark background by nature; changing the dark-mode feed colour is one value
  (`a={segments:15,feed:{color:new i.Color(255)` in `pages/index.*.js`).

**Responsive Convert screen.** The two stage panels run edge to edge (no centred column, no maximum width) and the
spacing follows the width available (`ConvertLayout` in `ConvertScreen.kt`, breakpoints 600 dp and 840 dp):
under 600 dp, 8 dp screen margins and 14 dp card padding (it was 16 + 20); 600-840 dp, full-width panels stacked;
840 dp and up (tablet, foldable, landscape), IMAGE -> SVG and SVG -> G-CODE side by side, half the width each. The
placement is done by one custom layout with a fixed composition structure, so crossing a breakpoint (rotating the
device) does not reset which dropdowns are open.

## G-Code Viewer tab (NC Viewer Offline)

Tab 2 hosts the NC Viewer Offline app you provided: the same bundled web app
(`assets/www`, copied byte-for-byte), the same single / split layout, the same
draggable "Single view" / "Split view" pill, the same per-pane "Open file" pills
(with the Replace / Append / Cancel prompt), and the same file chooser for the
site's own Open button. The code lives in `com.vectorforge.app.ncviewer`:

- `AppAssetHandler.kt` -- unchanged apart from its package.
- `FileOpener.kt` -- unchanged apart from its package, plus one added entry
  point, `openGeneratedFile()`, which feeds a generated file through exactly
  the path a picked file takes.
- `NcViewerController.kt` -- NC Viewer's `MainActivity` viewer logic (panes,
  split mode saved in prefs, pills, WebView setup) moved into an object that
  `GcodeViewerScreen` embeds. It lives as long as the Activity, so what is
  loaded survives switching tabs.

Not carried over from the standalone NC Viewer app: its 127.0.0.1 `Serve.kt`
fallback (dead code behind a `false` flag there), its system-bar inset handling
(VectorForge's Scaffold already keeps the tab clear of the status bar and bottom
navigation), its startup diagnostics logging, and its global crash handler.

Build notes carried over from NC Viewer: `app/build.gradle.kts` sets
`androidResources.ignoreAssetsPattern` (without it AGP silently drops
`assets/www/_nuxt/`, the site's JavaScript, and the viewer stays blank); the
manifest declares `INTERNET` and NC Viewer's full `configChanges` list (the
WebViews belong to the Activity, so a font-size/density/locale change must not
recreate it and discard the loaded G-code).

## G-code transform (in POST-PROCESSING)

`GcodeTransform.kt` is ported to `engine/gcode/transform/GcodeTransform.kt` (own
package, so its top-level names cannot clash with the SVG->G-code engine's). Each of
its arguments is its own field or switch directly inside **POST-PROCESSING**, laid
out like every other parameter. It runs on the generated G-code *after* the
generator's own normalize/reduce steps, for all three generate buttons, so the file
on disk (and what the viewer shows) is the transformed result. Order is always
rotate -> keep -> offset (offset last); only X/Y values change, everything else is
copied through untouched.

| CLI argument | Control |
| --- | --- |
| `--rotate-left DEG` | ROTATE LEFT (deg) field (counter-clockwise) |
| `--rotate-right DEG` | ROTATE RIGHT (deg) field (clockwise) |
| `--offset-x` / `--offset-y` | OFFSET X / OFFSET Y fields |
| `--keep-positive` | KEEP POSITIVE switch (X>=0 and Y>=0) |
| `--keep-negative` | KEEP NEGATIVE switch (X<=0 and Y<=0) |
| `--keep-east` / `--keep-west` | KEEP EAST / KEEP WEST switches |
| `--keep-north` / `--keep-south` | KEEP NORTH / KEEP SOUTH switches |
| `--no-fixed-home` | NO FIXED HOME switch |
| `--max-x` / `--max-y` | MAX X / MAX Y fields (warning only) |
| `--precision N` | PRECISION field (0-10, blank = 4) |

Blank / off = not passed, exactly like the other optional parameters. If nothing
in the table is set (other than NO FIXED HOME / PRECISION on their own) the
transform is not applied and generation is unchanged. As in the CLI, combinations
it rejects (rotate left + rotate right, east + west, north + south, keep-positive
with west, ...) and out-of-range values (angle outside 0-360, precision outside
0-10) show as an error dialog instead of being silently corrected.
The CLI's report (home moves kept, keep shift, offset, toolpath bounds, warnings,
lines changed) is appended to the G-code STATUS block at the top of the SVG2GCODE Parameters dropdown.

### Final normalize (NEW MIN / NEW MAX at the bottom of POST-PROCESSING)

A second NEW MIN (mm) / NEW MAX (mm) pair sits at the very bottom of
POST-PROCESSING, after the transform controls. It is the header pair's normalize
step (`normalizeLines`, unchanged) run once more on the finished, transformed
G-code, because a rotation such as 30 degrees grows the X/Y extent and pushes part
of the toolpath outside the 0..40 range the first normalize produced. The drawing's
bounding box is mapped back onto [min, max] on each axis, and, as with the header
pair, only G1 moves inside drawn strokes are touched (the fixed home moves stay).

Blank = not applied (generation is unchanged). Fill either field to turn it on; a
blank half falls back to the header's NEW MIN / NEW MAX. Pipeline order is now:
generate -> header normalize / reduce -> transform (rotate, keep, offset) -> final
normalize. Because it runs last it decides the final range, so it overrides the
shift that KEEP / OFFSET produced; and, as with the header pair, each axis is scaled
independently, so a rotated drawing is stretched to fill the range, not just moved.

Not exposed, because the app already does that job: `input`, `-o/--output`,
`--in-place` (files are handled by the Convert screen) and `-i/--interactive`
(the screen itself is the interactive mode).

The one change to the ported code: number formatting is pinned to `Locale.ROOT`,
so a device set to a comma-decimal language cannot write `1,5` into the G-code.

## Remote control in the G-Code Viewer

The **Post-process** pill (same style as the Single/Split pill, stacked above it) shows a remote control built
from the same pills NC Viewer uses (20 dp corners, 13 sp text, 0.85 alpha, 6 dp elevation). In the dark theme
they are the original translucent dark `#CC202124` with white text; in the light theme they switch to a light
teal pill with a thin outline and dark text (see `ncviewer/ViewerTheme.kt`). There are no input fields.

    [ status: X 0-40 . Y 0-40 . 0 deg ]               <- drag it to move the whole remote
    [ UL ] [ Up ] [ UR ]    [ Rotate Left  ]
    [Left] [    ] [Right]   [ Rotate Right ]
    [ DL ] [Down] [ DR ]    [ Step ] [ Angle ]
                            [ Reset ] [ Save ] ( [ Viewer 1 ] in split view )

The remote is two columns (about 180 dp high, 300 dp wide) so it fits a phone-height viewer. Its empty centre
cell is a fixed-size `Space`: a plain `View` with `wrap_content` takes all the space it is offered, which once
blew that cell up to the size of the viewer and pushed every row below it out of sight.

The eight arrows and both rotate buttons repeat while held. **Up** increases Y and **Right** increases X, as in
the G-code; **Rotate Left** is counter-clockwise. Tap **Step** (0.1 / 0.5 / 1 / 5 / 10 mm) and **Angle**
(1 / 5 / 15 / 45 / 90 deg) to change how far one press goes. **Save** writes what the viewer shows to a file you
pick (same "Save As" dialog as the Convert screen, suggesting `<name>_processed.gcode`); it is read from the
editor at that moment, so manual edits are included. **Reset** puts the original back. In split view the third
pill chooses which viewer is controlled.

### Free movement: `OrientationPlacer`

The remote has **no limits**. Any G-code (0..40, 0..80, 70..120, negative, crossing zero, ...) can be moved any
distance in any direction and turned to any angle; nothing is ever blocked, clamped, scaled or re-normalised, and
it does not use the Convert screen's NEW MIN / NEW MAX. Every step is computed again from the ORIGINAL G-code:

1. **Rotation about the drawing's own centre**, never about X0 Y0 (a drawing that sits far from the origin would
   swing across the plane into another quadrant).
2. **Translation** so its bounding box is centred on the requested point (each arrow press moves that point by the
   Step; Up is +Y, Right is +X).

So the drawing's size and handedness never change (no stretching, no mirroring), it is exactly reversible
(rotating left then right, or moving back, gives the original again), and the status pill shows the resulting X/Y
extent and angle after every step.

All geometry is done by `GCodeTransformer` (absolute and relative moves, arcs; the fixed X0 Y0 home moves stay
put), which is the provided GcodeTransform.kt with only the `Locale.ROOT` number-format fix.

The remote closes by itself when the viewer's content is replaced from elsewhere (the Viewer 1 / Viewer 2 buttons, Open file),
so an old snapshot can never overwrite a newer file. This remote is separate from POST-PROCESSING on the Convert
screen; that one is unchanged and still has its own FINAL NORMALIZE.

## The three G-code buttons: G-code, Viewer 1, Viewer 2

The G-code stage ends in three small pill buttons on one line, named exactly **G-code**, **Viewer 1** and
**Viewer 2**. The generation itself (`ConvertViewModel.generateGcode`) is the same for all three; the
`ViewerTarget` only decides what happens to the finished file:

| Button | Result |
| --- | --- |
| **G-code** | Writes the G-code file. Opens / appends / loads nothing. |
| **Viewer 1** | Writes it, switches to the G-Code Viewer tab in **single view** (no split) and loads it into the viewer. |
| **Viewer 2** | Writes it, switches to the G-Code Viewer tab in **split view** and loads it into the second (bottom) pane; the top pane is left as it was. |

Wiring: after a successful write the ViewModel emits a `ViewerRequest` on `viewerRequests`; `MainActivity`
collects it, selects the G-Code Viewer tab and calls `NcViewerController.openGeneratedGcode()`. The file is only
handed over once the pane is on screen with a size and the page's editor exists (a WebView that isn't laid out
yet would plot into a 0x0 canvas). If the target editor already holds G-code, NC Viewer's usual Replace / Append /
Cancel prompt appears; an empty editor loads and plots with no prompt. If the SVG has no drawable shapes, nothing
is sent. While a run is in progress the buttons are disabled and a small spinner follows them.

## Auto Convert Previous Stage

A switch at the top of the **SVG2GCODE Parameters** dropdown (on by default). With it on, the three G-code
buttons also work before an SVG exists, and the SVG is obtained in this order (`convertToGcode` /
`obtainSvgFromPreviousStage`):

1. A valid SVG already in the G-code stage (selected, or fed in) is used directly.
2. Otherwise the SVG that IMAGE -> SVG has already written, if valid, is fed in and used: no second conversion.
3. Otherwise IMAGE -> SVG runs first, through the very same function as "CONVERT TO SVG"
   (`runSvgConversion`), and its output is fed to the generator exactly as "Feed Output SVG to Generator" does.

"Valid" means the file exists, is not empty and begins like an SVG; a trace that yields zero paths also counts as
failure here. If the previous stage cannot produce a valid SVG, its error dialog is shown and no G-code is
attempted; with no SVG and no image selected a dialog says so. With the switch off, the buttons need an SVG as
before. A valid SVG is never converted twice.

## Status and errors are no longer permanent cards

The STATUS cards under both stages and the "Feed Output SVG to Generator" bridge (with its separators and
lightning icon) were removed from the main screen, so the stages stack with no gaps. Their content moved into the
Parameters dropdowns: each dropdown opens with its STATUS card (the same card: state, title, detail, engine
badge). The manual "Feed output SVG to generator" button has since been removed: the SVG that IMAGE -> SVG writes is
now passed to the SVG -> G-CODE stage automatically as soon as the conversion succeeds (the same action the button
performed; `ConvertViewModel.runSvgConversion`). Failures now appear as a dialog (Image -> SVG first, then G-code), and a successful run shows a short
toast ("SVG ready: ...", "G-code ready: ... lines").

## Controller tab (G-code sender)

The third tab connects to the machine and drives it.

- **Connection**: Bluetooth (paired HC-05 / HC-06), Wi-Fi (TCP serial bridge such as an ESP8266/ESP32) or USB-OTG
  (CDC-ACM boards such as Uno R3 / Mega / Leonardo; CH340 / CP210x / FTDI adapters are not supported over USB).
- **Firmware profiles**: *Mini CNC Plotter sketch* (the example receiver), *GRBL*, *Marlin / generic*.
- **Jog & home**: 8-direction pad, step 0.1 to 20 mm, Home, Go to 0,0, Set zero, pen up/down (or Z+/Z-), GRBL unlock/reset, position sync.
- **Speed**: jog speed and a 10-200 % feed override.
- **Send**: open a file or the latest generated G-code, start / pause / resume / stop, progress, skip a failing line, optional stop (M0/M1) pauses, E-STOP.
- **Console**: live TX/RX log and a command line with quick commands.

Lines are sent one at a time (terminated with a single `\n`) and the next is sent after the machine answers `ok`.
The stock plotter sketch ignores F words, has no homing and misbehaves on Z-only moves, so the sender filters those lines.
`docs/firmware/Mini_CNC_Arduino_Plotter_VectorForge.ino` is the original sketch plus: one `ok` per line for CR+LF,
NULL-safe G0/G1, G28 home, `M220 S<percent>` speed override.
