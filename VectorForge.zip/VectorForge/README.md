# VectorForge (Android)

A native Android/Kotlin app that ports the provided `Potrace.kt` (raster
image -> SVG tracing) and `SvgToGcodeUnicorn.kt` (SVG -> pen-plotter
G-code) engines into a two-tab app themed exactly from the supplied
`code.html` UI reference.

- **Tab 1 -- Convert**: the full functional pipeline. Pick an image, trace
  it to SVG with every Potrace parameter exposed, feed that SVG into the
  G-code generator with every one of its parameters exposed, and get a
  real, on-disk G-code file out the other end.
- **Tab 2 -- G-Code Viewer**: the complete NC Viewer Offline app (see
  "G-Code Viewer tab" below). Generated G-code can be sent straight into it.

## Opening it

Open the `VectorForge/` folder directly in Android Studio (Ladybug/Koala
or newer) via **File > Open**. Gradle sync will pull every dependency
from Google's/Maven Central's repositories, so you'll need network access
the first time. If Android Studio warns about the Gradle wrapper, let it
regenerate `gradlew`/`gradle-wrapper.jar` -- **that one binary file
couldn't be included** in this delivery (everything else here is plain
text); Android Studio creates it automatically on first sync, or you can
run `gradle wrapper` yourself with any local Gradle 8.x install.

You'll need the Android SDK Platform for API 35 installed (Android
Studio will prompt you if it's missing). If you'd rather not install it,
drop `compileSdk`/`targetSdk` to `34` in `app/build.gradle.kts`.

## What the two engine files needed to change

Both files live under `app/src/main/java/com/vectorforge/app/engine/`,
each with an "ANDROID PORT NOTE" comment at the point of every change.
In short:

- **`SvgToGcodeUnicorn.kt` needed no algorithmic changes at all.** Android
  ships the same `javax.xml.parsers`/`org.w3c.dom` DOM parser the file
  already used. The only thing removed was the argv-parsing CLI wrapper
  (`parseArgs`, `main`, `--help` text) -- replaced with one plain function,
  `svgFileToGcode(file, args)`, that the UI calls directly with an `Args`
  built from the on-screen controls. Every field, default, and the whole
  parse -> walk -> build -> normalize -> reduce pipeline is unchanged.
- **`Potrace.kt` needed its image I/O swapped**, since
  `java.awt.image.BufferedImage`/`javax.imageio.ImageIO` (desktop JDK
  only) don't exist on Android. `loadBitmap`, `pillowGrayscaleThreshold`,
  and `traceImageMode2` now use `android.graphics.Bitmap`/`BitmapFactory`
  instead -- same formulas, same thresholding, same PBM output. The core
  two-phase decompose/trace algorithm (everything from `Curve`/`PrivPath`
  through `potraceTrace`) is byte-for-byte untouched, since it never
  touched AWT to begin with. Its CLI `main()` was removed the same way.
  One latent bug was also fixed in the port: `fmt()`'s `String.format` now
  pins `Locale.ROOT`, so SVG coordinates can't come out with a comma
  decimal separator on a non-English device.

Both engine files are direct, otherwise-unmodified transcriptions of what
you provided -- every parameter you can see in the UI maps to one field on
`Params`/`Args`.

## Design/assumption notes

- **No Android build-example project was provided** -- only the theme
  (`code.html`) and the two Kotlin engine files came through, not an
  example app to mirror the project/Gradle structure from. This is built
  as a standard modern single-module Compose + Material 3 app instead
  (Kotlin 2.0.20, AGP 8.5.2, compose-bom 2024.09.03). If you do have that
  example project, share it and the structure can be adjusted to match.
- **Color palette**: `ui/theme/Color.kt`/`Theme.kt` reproduce the
  reference's Tailwind color tokens exactly -- they already use Material
  3's own `ColorScheme` role names (primary/secondary/tertiary, error,
  surface-container tiers, etc.), so each one maps onto
  `darkColorScheme(...)` one-for-one with no re-picking. The one
  exception: the twelve "fixed"/"fixed dim" roles are kept in `Color.kt`
  but not applied, because the Material3 version this project resolves
  has no such fields on `ColorScheme` (confirmed by the compiler). No
  screen uses them.
- **One theme only**: the reference never defines a second (light)
  palette -- its theme-toggle button just flips a CSS class with nothing
  behind it. Rather than invent colors that weren't supplied, this app
  always renders in the one supplied dark scheme.
- **Typography**: sizes, weights, line-heights and letter-spacing all
  match the reference's type scale exactly (see `ui/theme/Type.kt`). The
  font family itself is the platform sans-serif (Roboto) standing in for
  "Plus Jakarta Sans", since embedding that font's actual binary isn't
  possible from a text-only delivery. Drop the four .ttf weights into
  `res/font/` and point `AppFontFamily` at them for a pixel-exact match.
- **Storage**: no storage permission is requested anywhere. Input images
  go through the system Photo Picker; input SVGs through the Storage
  Access Framework document picker; both are copied into this app's own
  app-specific external storage, where the ported engine code reads/writes
  them as plain `File`s exactly as originally written. The folder/
  "drive_file_move" icon buttons next to each output path use SAF's
  "Save As" dialog to additionally copy a finished file wherever you
  choose.
- **Header chrome**: the reference's theme-toggle and settings icons in
  the top bar are rendered as static icons (no click handler). No second
  theme and no settings screen exist anywhere in what was provided, so
  wiring a fake action to either would be exactly the kind of decorative,
  do-nothing control the brief says to avoid.
- **Licensing**: the Potrace port keeps the original file's GPL v2 header
  comment as-authored -- worth knowing if this app is ever distributed.

## SVG -> G-code: prefilled vs. optional settings

The G-code generator starts from the desktop CLI run that is known to work:

    java -jar svg2gcode.jar in.svg -o out.gcode --pen-up-angle 50 \
        --pen-down-angle 30 --xy-feedrate 3500 --new-min 0 --new-max 40 --no-reduce

- **Prefilled, always passed**: pen-up angle (50), pen-down angle (30), XY
  feedrate (3500), new min (0), new max (40), and the reduce / thin points
  toggle (OFF, which is `--no-reduce`).
- **Everything else is optional**: the input starts *empty* and shows the
  engine's default value only as a faint hint. While it is empty it is
  **not passed** to the generator (same as leaving that CLI flag off). Type
  a value and it is used; clear the input and it is unused again. The
  on/off switches (register pen, continuous, pause on layer, normalize) show
  the default dimmed until you flip them; a small reset button then returns
  them to "unused". See `ConvertViewModel.convertToGcode()`.

## Android XML parser note

`SvgToGcodeUnicorn.kt`'s `newDocumentBuilder()` originally called
`isXIncludeAware = false`. Android's XML parser throws
`This parser does not support specification "Unknown" version "0.0"` on
*any* XInclude call, even with `false` (desktop Java accepts it). It is now
wrapped in try/catch, so it is a no-op on Android.

## One honest limitation

This was written and reviewed carefully (including a full pass matching
every function signature the UI/ViewModel calls against the actual ported
engine code), but there's no Android SDK/Gradle available in the
environment this was built in, so **none of this has been compiled**.
Everything here is source code ready to build, not a build that's been
verified green. If Android Studio's first sync turns up an error, it's
almost certainly a small one (an import, an icon name) -- the
architecture and the engine integration underneath it are solid.

## G-Code Viewer tab (NC Viewer Offline)

Tab 2 hosts the NC Viewer Offline app you provided: the same bundled web app
(`assets/www`, copied byte-for-byte), the same single / split layout, the same
draggable "Single view" / "Split view" pill, the same per-pane "Open file" pills
(with the Replace / Append / Cancel prompt), and the same file chooser for the
site's own Open button. The code lives in `com.vectorforge.app.ncviewer`:

- `AppAssetHandler.kt` -- unchanged apart from its package.
- `FileOpener.kt` -- unchanged apart from its package, plus one added entry
  point, `openGeneratedFile()`, which feeds a generated file through exactly
  the path a picked file takes.
- `NcViewerController.kt` -- NC Viewer's `MainActivity` viewer logic (panes,
  split mode saved in prefs, pills, WebView setup) moved into an object that
  `GcodeViewerScreen` embeds. It lives as long as the Activity, so what is
  loaded survives switching tabs.

Not carried over from the standalone NC Viewer app: its 127.0.0.1 `Serve.kt`
fallback (dead code behind a `false` flag there), its system-bar inset handling
(VectorForge's Scaffold already keeps the tab clear of the top bar and bottom
navigation), its startup diagnostics logging, and its global crash handler.

Build notes carried over from NC Viewer: `app/build.gradle.kts` sets
`androidResources.ignoreAssetsPattern` (without it AGP silently drops
`assets/www/_nuxt/`, the site's JavaScript, and the viewer stays blank); the
manifest declares `INTERNET` and NC Viewer's full `configChanges` list (the
WebViews belong to the Activity, so a font-size/density/locale change must not
recreate it and discard the loaded G-code).

## G-code transform (in POST-PROCESSING)

`GcodeTransform.kt` is ported to `engine/gcode/transform/GcodeTransform.kt` (own
package, so its top-level names cannot clash with the SVG->G-code engine's). Each of
its arguments is its own field or switch directly inside **POST-PROCESSING**, laid
out like every other parameter. It runs on the generated G-code *after* the
generator's own normalize/reduce steps, for all three generate buttons, so the file
on disk (and what the viewer shows) is the transformed result. Order is always
rotate -> keep -> offset (offset last); only X/Y values change, everything else is
copied through untouched.

| CLI argument | Control |
| --- | --- |
| `--rotate-left DEG` | ROTATE LEFT (deg) field (counter-clockwise) |
| `--rotate-right DEG` | ROTATE RIGHT (deg) field (clockwise) |
| `--offset-x` / `--offset-y` | OFFSET X / OFFSET Y fields |
| `--keep-positive` | KEEP POSITIVE switch (X>=0 and Y>=0) |
| `--keep-negative` | KEEP NEGATIVE switch (X<=0 and Y<=0) |
| `--keep-east` / `--keep-west` | KEEP EAST / KEEP WEST switches |
| `--keep-north` / `--keep-south` | KEEP NORTH / KEEP SOUTH switches |
| `--no-fixed-home` | NO FIXED HOME switch |
| `--max-x` / `--max-y` | MAX X / MAX Y fields (warning only) |
| `--precision N` | PRECISION field (0-10, blank = 4) |

Blank / off = not passed, exactly like the other optional parameters. If nothing
in the table is set (other than NO FIXED HOME / PRECISION on their own) the
transform is not applied and generation is unchanged. As in the CLI, combinations
it rejects (rotate left + rotate right, east + west, north + south, keep-positive
with west, ...) and out-of-range values (angle outside 0-360, precision outside
0-10) show as an error on the status card instead of being silently corrected.
The CLI's report (home moves kept, keep shift, offset, toolpath bounds, warnings,
lines changed) is appended to that status card.

Not exposed, because the app already does that job: `input`, `-o/--output`,
`--in-place` (files are handled by the Convert screen) and `-i/--interactive`
(the screen itself is the interactive mode).

The one change to the ported code: number formatting is pinned to `Locale.ROOT`,
so a device set to a comma-decimal language cannot write `1,5` into the G-code.

## The three G-code buttons

The single "CONVERT TO G-CODE" button is now three buttons on one line. The
generation itself (`ConvertViewModel.convertToGcode`) is the same for all three;
its `ViewerTarget` argument only decides what happens to the finished file:

| Button | Result |
| --- | --- |
| **Generate** | Writes the G-code file. Opens / appends / loads nothing. |
| **Generate + Viewer 1** | Writes it, switches to the G-Code Viewer tab in **single view** (no split) and loads it into the viewer. |
| **Generate + Viewer 2 (Split)** | Writes it, switches to the G-Code Viewer tab in **split view** and loads it into the second (bottom) pane; the top pane is left as it was. |

Wiring: after a successful write the ViewModel emits a `ViewerRequest` on
`viewerRequests`; `MainActivity` collects it, selects the G-Code Viewer tab and
calls `NcViewerController.openGeneratedGcode()`. The file is only handed over
once the pane is on screen with a size and the page's editor exists (a WebView
that isn't laid out yet would plot into a 0x0 canvas). If the target editor
already holds G-code, NC Viewer's usual Replace / Append / Cancel prompt
appears, as it does for the "Open file" pill; an empty editor loads and plots
with no prompt. If the SVG has no drawable shapes, nothing is sent.

Still un-compiled: as noted above, no Android SDK was available here either, so
this integration has been reviewed statically, not built.
