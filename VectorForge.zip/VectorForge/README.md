# VectorForge (Android)

A native Android/Kotlin app that ports the provided `Potrace.kt` (raster
image -> SVG tracing) and `SvgToGcodeUnicorn.kt` (SVG -> pen-plotter
G-code) engines into a two-tab app themed exactly from the supplied
`code.html` UI reference.

- **Tab 1 -- Convert**: the full functional pipeline. Pick an image, trace
  it to SVG with every Potrace parameter exposed, feed that SVG into the
  G-code generator with every one of its parameters exposed, and get a
  real, on-disk G-code file out the other end.
- **Tab 2 -- G-Code Viewer**: intentionally empty (nav entry + theme only),
  reserved for a future viewer/editor, exactly as specified.

## Opening it

Open the `VectorForge/` folder directly in Android Studio (Ladybug/Koala
or newer) via **File > Open**. Gradle sync will pull every dependency
from Google's/Maven Central's repositories, so you'll need network access
the first time. If Android Studio warns about the Gradle wrapper, let it
regenerate `gradlew`/`gradle-wrapper.jar` -- **that one binary file
couldn't be included** in this delivery (everything else here is plain
text); Android Studio creates it automatically on first sync, or you can
run `gradle wrapper` yourself with any local Gradle 8.x install.

You'll need the Android SDK Platform for API 35 installed (Android
Studio will prompt you if it's missing). If you'd rather not install it,
drop `compileSdk`/`targetSdk` to `34` in `app/build.gradle.kts`.

## What the two engine files needed to change

Both files live under `app/src/main/java/com/vectorforge/app/engine/`,
each with an "ANDROID PORT NOTE" comment at the point of every change.
In short:

- **`SvgToGcodeUnicorn.kt` needed no algorithmic changes at all.** Android
  ships the same `javax.xml.parsers`/`org.w3c.dom` DOM parser the file
  already used. The only thing removed was the argv-parsing CLI wrapper
  (`parseArgs`, `main`, `--help` text) -- replaced with one plain function,
  `svgFileToGcode(file, args)`, that the UI calls directly with an `Args`
  built from the on-screen controls. Every field, default, and the whole
  parse -> walk -> build -> normalize -> reduce pipeline is unchanged.
- **`Potrace.kt` needed its image I/O swapped**, since
  `java.awt.image.BufferedImage`/`javax.imageio.ImageIO` (desktop JDK
  only) don't exist on Android. `loadBitmap`, `pillowGrayscaleThreshold`,
  and `traceImageMode2` now use `android.graphics.Bitmap`/`BitmapFactory`
  instead -- same formulas, same thresholding, same PBM output. The core
  two-phase decompose/trace algorithm (everything from `Curve`/`PrivPath`
  through `potraceTrace`) is byte-for-byte untouched, since it never
  touched AWT to begin with. Its CLI `main()` was removed the same way.
  One latent bug was also fixed in the port: `fmt()`'s `String.format` now
  pins `Locale.ROOT`, so SVG coordinates can't come out with a comma
  decimal separator on a non-English device.

Both engine files are direct, otherwise-unmodified transcriptions of what
you provided -- every parameter you can see in the UI maps to one field on
`Params`/`Args`.

## Design/assumption notes

- **No Android build-example project was provided** -- only the theme
  (`code.html`) and the two Kotlin engine files came through, not an
  example app to mirror the project/Gradle structure from. This is built
  as a standard modern single-module Compose + Material 3 app instead
  (Kotlin 2.0.20, AGP 8.5.2, compose-bom 2024.09.03). If you do have that
  example project, share it and the structure can be adjusted to match.
- **Color palette**: `ui/theme/Color.kt`/`Theme.kt` reproduce the
  reference's Tailwind color tokens exactly -- they already use Material
  3's own `ColorScheme` role names (primary/secondary/tertiary, error,
  surface-container tiers, etc.), so each one maps onto
  `darkColorScheme(...)` one-for-one with no re-picking. The one
  exception: the twelve "fixed"/"fixed dim" roles are kept in `Color.kt`
  but not applied, because the Material3 version this project resolves
  has no such fields on `ColorScheme` (confirmed by the compiler). No
  screen uses them.
- **One theme only**: the reference never defines a second (light)
  palette -- its theme-toggle button just flips a CSS class with nothing
  behind it. Rather than invent colors that weren't supplied, this app
  always renders in the one supplied dark scheme.
- **Typography**: sizes, weights, line-heights and letter-spacing all
  match the reference's type scale exactly (see `ui/theme/Type.kt`). The
  font family itself is the platform sans-serif (Roboto) standing in for
  "Plus Jakarta Sans", since embedding that font's actual binary isn't
  possible from a text-only delivery. Drop the four .ttf weights into
  `res/font/` and point `AppFontFamily` at them for a pixel-exact match.
- **Storage**: no storage permission is requested anywhere. Input images
  go through the system Photo Picker; input SVGs through the Storage
  Access Framework document picker; both are copied into this app's own
  app-specific external storage, where the ported engine code reads/writes
  them as plain `File`s exactly as originally written. The folder/
  "drive_file_move" icon buttons next to each output path use SAF's
  "Save As" dialog to additionally copy a finished file wherever you
  choose.
- **Header chrome**: the reference's theme-toggle and settings icons in
  the top bar are rendered as static icons (no click handler). No second
  theme and no settings screen exist anywhere in what was provided, so
  wiring a fake action to either would be exactly the kind of decorative,
  do-nothing control the brief says to avoid.
- **Licensing**: the Potrace port keeps the original file's GPL v2 header
  comment as-authored -- worth knowing if this app is ever distributed.

## Tab 2: the embedded NC Viewer

Tab 2 is no longer empty. It now hosts NCViewerOffline (the uploaded
`NCViewerOffline_5_.zip`) -- a WebView wrapper around a bundled, fully
offline copy of ncviewer.com's G-code viewer/simulator -- essentially
unmodified:

- `assets/www/` and `assets/open_file_loader.js` are copied verbatim.
- `AppAssetHandler.kt`, `Serve.kt` and `FileOpener.kt` are copied with only
  their package line changed (`Serve.kt` is the app's own local-HTTP-server
  fallback; it's kept for fidelity but unused by default, same as in the
  original app). `FileOpener.kt` gained two small *additions*, nothing
  removed: its constructor's `id` is now a public property, and a new
  `loadFile(uri, mode)` does exactly what picking a file by hand does
  (same JS bridge, same PLOT trigger) without the system picker or the
  Replace/Append/Cancel dialog, for when the app itself decides the file
  and the mode.
- `NCViewerHost.kt` is new: it's the original `MainActivity.kt`'s own logic
  (WebView setup, the two panes, the split/single-view pill, each pane's
  "Open file" pill, the file chooser, diagnostics) restructured from *is*
  an Activity into a controller a Compose screen can hold and embed, since
  VectorForge already has its own single Activity. See its doc comment for
  the exact, small set of structural changes; the WebView/viewer behavior
  itself is untouched. `MainActivity.kt` now owns one `NCViewerHost` for
  the app's lifetime and forwards `onActivityResult`/`onConfigurationChanged`
  to it (both real Activity callbacks the original app relied on).
- `app/build.gradle.kts` gained an `androidResources.ignoreAssetsPattern`
  override, copied from the original app's own build file: AGP's default
  pattern silently drops any assets directory starting with `_`, which
  would have stripped `assets/www/_nuxt/` (the site's JS) with no build
  error to explain why. `AndroidManifest.xml` gained the `INTERNET`
  permission and `usesCleartextTraffic="true"` the original app declares
  (WebView needs the former even for local-only content; the latter is
  only exercised by the unused `Serve.kt` fallback path).
- **Left out on purpose**: the original app's crash handler
  (`NCViewerApplication`/`GlobalCrashHandler`/`CrashActivity`). It's a
  general-purpose safety net unrelated to viewing G-code, so it felt like
  scope the request didn't ask for -- say the word and it's a quick add.

## Convert tab: three G-code buttons instead of one

"CONVERT TO G-CODE" is now three compact buttons in one row
(`ConvertViewModel.convertToGcode` gained an optional `onGenerated`
callback to support this -- called with the finished file only on a real
success, so the plain "Generate" button's own behavior is exactly what it
was before):

- **Generate**: unchanged -- writes the file, nothing else.
- **Viewer 1**: generates, then loads the result into the NC Viewer's top
  pane in single view (split forced off), and switches to that tab.
- **Viewer 2**: generates, then loads the result into the bottom pane in
  split view (split forced on, creating that pane the first time), and
  switches to that tab.

Both viewer buttons use FileOpener's "append" mode, and both switch
VectorForge's own bottom tab to G-Code Viewer so the result is immediately
visible. If either pane's page is still on its very first load (only
realistically possible the moment split view is first turned on),
sending waits briefly for it rather than silently doing nothing.

One judgment call worth flagging: the request said "tab 1" / "tab 2" for
where a generated file lands. NCViewerOffline itself has no concept of
numbered tabs -- what it has is a top ("pane 0") and bottom ("pane 1") pane
that appear when split view is on. That's what "Viewer 1" / "Viewer 2"
above map onto. If a different meaning was intended, say so and it's a
quick change.

## SVG -> G-code: prefilled vs. optional settings

The G-code generator starts from the desktop CLI run that is known to work:

    java -jar svg2gcode.jar in.svg -o out.gcode --pen-up-angle 50 \
        --pen-down-angle 30 --xy-feedrate 3500 --new-min 0 --new-max 40 --no-reduce

- **Prefilled, always passed**: pen-up angle (50), pen-down angle (30), XY
  feedrate (3500), new min (0), new max (40), and the reduce / thin points
  toggle (OFF, which is `--no-reduce`).
- **Everything else is optional**: the input starts *empty* and shows the
  engine's default value only as a faint hint. While it is empty it is
  **not passed** to the generator (same as leaving that CLI flag off). Type
  a value and it is used; clear the input and it is unused again. The
  on/off switches (register pen, continuous, pause on layer, normalize) show
  the default dimmed until you flip them; a small reset button then returns
  them to "unused". See `ConvertViewModel.convertToGcode()`.

## Android XML parser note

`SvgToGcodeUnicorn.kt`'s `newDocumentBuilder()` originally called
`isXIncludeAware = false`. Android's XML parser throws
`This parser does not support specification "Unknown" version "0.0"` on
*any* XInclude call, even with `false` (desktop Java accepts it). It is now
wrapped in try/catch, so it is a no-op on Android.

## One honest limitation

This was written and reviewed carefully (including a full pass matching
every function signature the UI/ViewModel calls against the actual ported
engine code), but there's no Android SDK/Gradle available in the
environment this was built in, so **none of this has been compiled**.
Everything here is source code ready to build, not a build that's been
verified green. If Android Studio's first sync turns up an error, it's
almost certainly a small one (an import, an icon name) -- the
architecture and the engine integration underneath it are solid.
