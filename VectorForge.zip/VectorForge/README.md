# VectorForge (Android)

A native Android/Kotlin app that ports the provided `Potrace.kt` (raster
image -> SVG tracing) and `SvgToGcodeUnicorn.kt` (SVG -> pen-plotter
G-code) engines into a two-tab app themed exactly from the supplied
`code.html` UI reference.

- **Tab 1 -- Convert**: the full functional pipeline. Pick an image, trace
  it to SVG with every Potrace parameter exposed, feed that SVG into the
  G-code generator with every one of its parameters exposed, and get a
  real, on-disk G-code file out the other end.
- **Tab 2 -- G-Code Viewer**: intentionally empty (nav entry + theme only),
  reserved for a future viewer/editor, exactly as specified.

## Opening it

Open the `VectorForge/` folder directly in Android Studio (Ladybug/Koala
or newer) via **File > Open**. Gradle sync will pull every dependency
from Google's/Maven Central's repositories, so you'll need network access
the first time. If Android Studio warns about the Gradle wrapper, let it
regenerate `gradlew`/`gradle-wrapper.jar` -- **that one binary file
couldn't be included** in this delivery (everything else here is plain
text); Android Studio creates it automatically on first sync, or you can
run `gradle wrapper` yourself with any local Gradle 8.x install.

You'll need the Android SDK Platform for API 35 installed (Android
Studio will prompt you if it's missing). If you'd rather not install it,
drop `compileSdk`/`targetSdk` to `34` in `app/build.gradle.kts`.

## What the two engine files needed to change

Both files live under `app/src/main/java/com/vectorforge/app/engine/`,
each with an "ANDROID PORT NOTE" comment at the point of every change.
In short:

- **`SvgToGcodeUnicorn.kt` needed no algorithmic changes at all.** Android
  ships the same `javax.xml.parsers`/`org.w3c.dom` DOM parser the file
  already used. The only thing removed was the argv-parsing CLI wrapper
  (`parseArgs`, `main`, `--help` text) -- replaced with one plain function,
  `svgFileToGcode(file, args)`, that the UI calls directly with an `Args`
  built from the on-screen controls. Every field, default, and the whole
  parse -> walk -> build -> normalize -> reduce pipeline is unchanged.
- **`Potrace.kt` needed its image I/O swapped**, since
  `java.awt.image.BufferedImage`/`javax.imageio.ImageIO` (desktop JDK
  only) don't exist on Android. `loadBitmap`, `pillowGrayscaleThreshold`,
  and `traceImageMode2` now use `android.graphics.Bitmap`/`BitmapFactory`
  instead -- same formulas, same thresholding, same PBM output. The core
  two-phase decompose/trace algorithm (everything from `Curve`/`PrivPath`
  through `potraceTrace`) is byte-for-byte untouched, since it never
  touched AWT to begin with. Its CLI `main()` was removed the same way.
  One latent bug was also fixed in the port: `fmt()`'s `String.format` now
  pins `Locale.ROOT`, so SVG coordinates can't come out with a comma
  decimal separator on a non-English device.

Both engine files are direct, otherwise-unmodified transcriptions of what
you provided -- every parameter you can see in the UI maps to one field on
`Params`/`Args`.

## Design/assumption notes

- **No Android build-example project was provided** -- only the theme
  (`code.html`) and the two Kotlin engine files came through, not an
  example app to mirror the project/Gradle structure from. This is built
  as a standard modern single-module Compose + Material 3 app instead
  (Kotlin 2.0.20, AGP 8.5.2, compose-bom 2024.09.03). If you do have that
  example project, share it and the structure can be adjusted to match.
- **Color palette**: `ui/theme/Color.kt`/`Theme.kt` reproduce the
  reference's Tailwind color tokens exactly -- they already use Material
  3's own expanded `ColorScheme` role names (primary/secondary/tertiary
  fixed-dim variants, surface-container tiers, etc.), so each one maps
  onto `darkColorScheme(...)` one-for-one with no re-picking.
- **One theme only**: the reference never defines a second (light)
  palette -- its theme-toggle button just flips a CSS class with nothing
  behind it. Rather than invent colors that weren't supplied, this app
  always renders in the one supplied dark scheme.
- **Typography**: sizes, weights, line-heights and letter-spacing all
  match the reference's type scale exactly (see `ui/theme/Type.kt`). The
  font family itself is the platform sans-serif (Roboto) standing in for
  "Plus Jakarta Sans", since embedding that font's actual binary isn't
  possible from a text-only delivery. Drop the four .ttf weights into
  `res/font/` and point `AppFontFamily` at them for a pixel-exact match.
- **Storage**: no storage permission is requested anywhere. Input images
  go through the system Photo Picker; input SVGs through the Storage
  Access Framework document picker; both are copied into this app's own
  app-specific external storage, where the ported engine code reads/writes
  them as plain `File`s exactly as originally written. The folder/
  "drive_file_move" icon buttons next to each output path use SAF's
  "Save As" dialog to additionally copy a finished file wherever you
  choose.
- **Header chrome**: the reference's theme-toggle and settings icons in
  the top bar are rendered as static icons (no click handler). No second
  theme and no settings screen exist anywhere in what was provided, so
  wiring a fake action to either would be exactly the kind of decorative,
  do-nothing control the brief says to avoid.
- **Licensing**: the Potrace port keeps the original file's GPL v2 header
  comment as-authored -- worth knowing if this app is ever distributed.

## One honest limitation

This was written and reviewed carefully (including a full pass matching
every function signature the UI/ViewModel calls against the actual ported
engine code), but there's no Android SDK/Gradle available in the
environment this was built in, so **none of this has been compiled**.
Everything here is source code ready to build, not a build that's been
verified green. If Android Studio's first sync turns up an error, it's
almost certainly a small one (an import, an icon name) -- the
architecture and the engine integration underneath it are solid.
