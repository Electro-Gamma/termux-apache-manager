// Top-level build file: declares plugin versions once, applied per-module below.
// Versions chosen for compatibility with Gradle 8.7 / JDK 17 / compileSdk 35
// (Kotlin Gradle Plugin 2.1.20 officially supports Gradle 7.6.3-8.12.1 and
// AGP 7.3.1-8.7.2; AGP 8.6.0+ is required for compileSdk 35).
plugins {
    id("com.android.application") version "8.6.1" apply false
    id("org.jetbrains.kotlin.android") version "2.1.20" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.1.20" apply false
}
