# Add project specific ProGuard rules here.
# Minification is off by default for this project (see app/build.gradle.kts);
# these rules only take effect if you turn isMinifyEnabled back on.
