package com.mon3ix.imageconverter.ui.screens

import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Snackbar
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.mon3ix.imageconverter.model.ByteOrientation
import com.mon3ix.imageconverter.ui.AppViewModel
import com.mon3ix.imageconverter.ui.components.ImagePreviewCard
import kotlinx.coroutines.launch

private val SUPPORTED_MIME_TYPES = arrayOf(
    "image/png", "image/jpeg", "image/gif", "image/bmp", "image/x-portable-bitmap", "image/*"
)

@Composable
fun HomeScreen(viewModel: AppViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val openImage = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            val name = context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && cursor.moveToFirst()) cursor.getString(idx) else null
            }
            viewModel.onImagePicked(uri, name)
        }
    }
    val createPbm = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/x-portable-bitmap")) { uri ->
        if (uri != null) scope.launch { viewModel.savePbm(uri) }
    }
    val createPng = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/png")) { uri ->
        if (uri != null) scope.launch { viewModel.saveConvertedPng(uri) }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("1. Input image", style = MaterialTheme.typography.titleMedium)
        Button(onClick = { openImage.launch(SUPPORTED_MIME_TYPES) }) { Text("Choose image (PNG/JPG/GIF/BMP/PBM)") }
        ImagePreviewCard("Input Image", viewModel.inputBitmap)

        Text("2. Conversion settings", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(
                value = viewModel.targetWidth.toString(),
                onValueChange = { it.toIntOrNull()?.let { w -> viewModel.targetWidth = w } },
                label = { Text("Width") },
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = viewModel.targetHeight.toString(),
                onValueChange = { it.toIntOrNull()?.let { h -> viewModel.targetHeight = h } },
                label = { Text("Height") },
                modifier = Modifier.weight(1f)
            )
        }
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Checkbox(checked = viewModel.invert, onCheckedChange = { viewModel.invert = it })
            Text("Invert colors")
        }
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Checkbox(
                checked = viewModel.orientation == ByteOrientation.VERTICAL,
                onCheckedChange = { viewModel.orientation = if (it) ByteOrientation.VERTICAL else ByteOrientation.HORIZONTAL }
            )
            Text("Vertical (page) byte orientation — used by byte array / C++ / grid screens")
        }
        Text(
            "Threshold: luma < 128 → black (matches the original app's rule).",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Button(onClick = { viewModel.convertNow() }) { Text("Convert") }

        Text("3. Output", style = MaterialTheme.typography.titleMedium)
        ImagePreviewCard("Converted Image (monochrome)", viewModel.convertedBitmapPreview())
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = { createPbm.launch("${viewModel.inputName}.pbm") }) { Text("Save as PBM (P4)") }
            Button(onClick = { createPng.launch("${viewModel.inputName}_converted.png") }) { Text("Save as PNG") }
        }
        Text(
            "The Byte Array, C/C++, and Grid Editor screens all use this converted image and the settings above.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        viewModel.statusMessage?.let { message ->
            LaunchedEffect(message) { kotlinx.coroutines.delay(4000); viewModel.clearStatus() }
            Snackbar { Text(message) }
        }
    }
}
