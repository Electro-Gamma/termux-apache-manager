package com.mon3ix.imageconverter.ui.theme

import androidx.compose.ui.graphics.Color

// A small, deliberately monochrome-leaning palette -- fitting for an app whose entire subject
// is 1-bit bitmaps -- with one accent colour for actions.
val Ink90 = Color(0xFF1A1B1E)
val Ink70 = Color(0xFF43474E)
val Ink40 = Color(0xFF74777F)
val Ink10 = Color(0xFFE2E2E6)
val Paper = Color(0xFFFBFAFE)

val AccentLight = Color(0xFF3E5F8A)
val AccentDark = Color(0xFFA7C8FF)
val AccentContainerLight = Color(0xFFD6E3FF)
val AccentContainerDark = Color(0xFF23477A)
