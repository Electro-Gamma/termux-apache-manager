package com.mon3ix.imageconverter.ui

sealed class Destination(val route: String, val label: String) {
    data object Home : Destination("home", "Input Image")
    data object ByteArrayOut : Destination("byte_array", "Image → Byte Array")
    data object CppCode : Destination("cpp_code", "Image → C/C++")
    data object Batch : Destination("batch", "Batch Conversion")
    data object GifTools : Destination("gif_tools", "GIF Tools")
    data object GridEditor : Destination("grid_editor", "Bitmap Grid Editor")
    data object ArrayToImage : Destination("array_to_image", "Array → Image")

    companion object {
        val all = listOf(Home, ByteArrayOut, CppCode, Batch, GifTools, GridEditor, ArrayToImage)
    }
}
