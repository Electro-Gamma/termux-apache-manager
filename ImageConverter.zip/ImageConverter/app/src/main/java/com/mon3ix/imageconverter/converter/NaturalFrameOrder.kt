package com.mon3ix.imageconverter.converter

/**
 * Sorts frame filenames such as "fnum1.pbm", "fnum2.pbm", ..., "fnum10.pbm"
 * by the numeric value embedded in the name rather than lexicographically
 * (which would otherwise put "fnum10" before "fnum2"). Matches the intent
 * of `generate_header()`'s `extract_number()` helper.
 *
 * FIX vs. the original: `play_images()` instead *reconstructs* filenames
 * from a guessed common-prefix + sequential integer range, which silently
 * drops any frame if the numbering isn't perfectly contiguous from 1. Here
 * we just sort the files that actually exist, so gaps in numbering don't
 * lose frames.
 */
object NaturalFrameOrder {
    private val numberRegex = Regex("\\d+")

    fun extractNumber(fileName: String): Int? = numberRegex.find(fileName)?.value?.toIntOrNull()

    fun <T> sortByEmbeddedNumber(items: List<T>, nameOf: (T) -> String): List<T> =
        items.sortedWith(compareBy { nameOf(it).let(::extractNumber) ?: Int.MAX_VALUE })
}
