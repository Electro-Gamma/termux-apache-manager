package com.mon3ix.imageconverter.storage

import android.content.ContentResolver
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.DocumentsContract
import androidx.documentfile.provider.DocumentFile
import com.mon3ix.imageconverter.model.ByteOrientation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * All filesystem access goes through here, and all of it goes through
 * Android's Storage Access Framework -- `ACTION_OPEN_DOCUMENT` /
 * `ACTION_CREATE_DOCUMENT` / `ACTION_OPEN_DOCUMENT_TREE` and the Photo
 * Picker, selected in [MainActivity]'s `registerForActivityResult` launchers
 * and passed in here as [Uri]s.
 *
 * This replaces every hardcoded desktop path in the Python app
 * (`/home/{user}/image_converter/...`, `os.path.join(folder, ...)`,
 * `os.listdir()`, `os.makedirs()`) with SAF equivalents. There is no
 * "default output folder" on Android the way there was on the Python app's
 * host machine -- every save operation here asks the user where to put the
 * result via the system file/folder picker, which is the idiomatic (and, on
 * modern Android, the *only* generally available) way to write outside the
 * app's private sandbox without `MANAGE_EXTERNAL_STORAGE`.
 */
class FileRepository(private val context: Context) {

    private val resolver: ContentResolver get() = context.contentResolver

    suspend fun loadBitmap(uri: Uri): Bitmap = withContext(Dispatchers.IO) {
        resolver.openInputStream(uri)?.use { stream ->
            BitmapFactory.decodeStream(stream) ?: error("Could not decode image at $uri")
        } ?: error("Could not open $uri")
    }

    suspend fun loadBytes(uri: Uri): ByteArray = withContext(Dispatchers.IO) {
        resolver.openInputStream(uri)?.use { it.readBytes() } ?: error("Could not open $uri")
    }

    suspend fun loadText(uri: Uri): String = withContext(Dispatchers.IO) {
        resolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: error("Could not open $uri")
    }

    /** Writes [bytes] to a document the user already picked via `ACTION_CREATE_DOCUMENT`. */
    suspend fun writeBytes(uri: Uri, bytes: ByteArray) = withContext(Dispatchers.IO) {
        resolver.openOutputStream(uri, "w")?.use { it.write(bytes) } ?: error("Could not open $uri for writing")
    }

    suspend fun writeText(uri: Uri, text: String) = writeBytes(uri, text.toByteArray(Charsets.UTF_8))

    suspend fun writeBitmapPng(uri: Uri, bitmap: Bitmap) = withContext(Dispatchers.IO) {
        resolver.openOutputStream(uri, "w")?.use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
            ?: error("Could not open $uri for writing")
    }

    data class TreeImage(val uri: Uri, val name: String)

    /** Lists image files (by extension) directly inside a tree the user picked via `ACTION_OPEN_DOCUMENT_TREE`. */
    suspend fun listImagesInTree(
        treeUri: Uri,
        extensions: Set<String> = setOf("png", "jpg", "jpeg", "gif", "bmp", "pbm")
    ): List<TreeImage> = withContext(Dispatchers.IO) {
        val dir = DocumentFile.fromTreeUri(context, treeUri) ?: return@withContext emptyList()
        dir.listFiles()
            .filter { it.isFile && it.name != null && it.name!!.substringAfterLast('.', "").lowercase() in extensions }
            .map { TreeImage(it.uri, it.name!!) }
    }

    /** Creates (or reuses, if already present) a same-named file inside a picked tree, returning its Uri. */
    suspend fun createFileInTree(treeUri: Uri, displayName: String, mimeType: String): Uri = withContext(Dispatchers.IO) {
        val dir = DocumentFile.fromTreeUri(context, treeUri) ?: error("Could not open folder $treeUri")
        val existing = dir.findFile(displayName)
        (existing ?: dir.createFile(mimeType, displayName))?.uri
            ?: error("Could not create $displayName in $treeUri")
    }

    /** Creates a subfolder (or reuses it) inside a picked tree. */
    suspend fun getOrCreateSubfolder(treeUri: Uri, folderName: String): Uri = withContext(Dispatchers.IO) {
        val dir = DocumentFile.fromTreeUri(context, treeUri) ?: error("Could not open folder $treeUri")
        val existing = dir.findFile(folderName)
        val folder = if (existing != null && existing.isDirectory) existing else dir.createDirectory(folderName)
        (folder ?: error("Could not create folder $folderName")).uri
    }

    companion object {
        val IMAGE_MIME_TYPES = arrayOf("image/png", "image/jpeg", "image/gif", "image/bmp", "image/x-portable-bitmap")

        /** Orientation isn't a file-system concern, but batch/GIF screens need it alongside a folder pick. */
        fun defaultOrientation() = ByteOrientation.HORIZONTAL

        fun childDocumentUri(treeUri: Uri, documentId: String): Uri =
            DocumentsContract.buildDocumentUriUsingTree(treeUri, documentId)
    }
}
