package com.mon3ix.imageconverter.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val LightColors = lightColorScheme(
    primary = AccentLight,
    onPrimary = Paper,
    primaryContainer = AccentContainerLight,
    onPrimaryContainer = Ink90,
    background = Paper,
    onBackground = Ink90,
    surface = Paper,
    onSurface = Ink90,
    surfaceVariant = Ink10,
    onSurfaceVariant = Ink70
)

private val DarkColors = darkColorScheme(
    primary = AccentDark,
    onPrimary = Ink90,
    primaryContainer = AccentContainerDark,
    onPrimaryContainer = AccentContainerLight,
    background = Ink90,
    onBackground = Ink10,
    surface = Ink90,
    onSurface = Ink10,
    surfaceVariant = Ink70,
    onSurfaceVariant = Ink10
)

@Composable
fun ImageConverterTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        darkTheme -> DarkColors
        else -> LightColors
    }
    MaterialTheme(
        colorScheme = colorScheme,
        typography = ImageConverterTypography,
        content = content
    )
}
