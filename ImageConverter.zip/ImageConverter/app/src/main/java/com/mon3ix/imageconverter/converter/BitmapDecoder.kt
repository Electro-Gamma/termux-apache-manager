package com.mon3ix.imageconverter.converter

import com.mon3ix.imageconverter.model.BitmapData
import com.mon3ix.imageconverter.model.ByteOrientation

/**
 * Turns pasted byte/C-array text back into images. This is where
 * [ByteDataParser] (safe tokenizing) and [ByteArrayConverter] (bit
 * unpacking) meet, plus multi-frame header parsing for re-importing a
 * previously generated `.h` file -- reproducing `list_to_image_horizontal()`
 * / `list_to_image_vertical()` (items 8/9) and `parse_header_file()`
 * (used by `play_images()` to rebuild frames from a header).
 */
object BitmapDecoder {

    /** Parses [rawInput] (bytearray literal, C array, or bare hex/decimal list) into one [BitmapData]. */
    fun parseImage(rawInput: String, width: Int, height: Int, orientation: ByteOrientation): BitmapData {
        val bytes = ByteDataParser.parse(rawInput)
        return ByteArrayConverter.unpack(bytes, width, height, orientation)
    }

    data class HeaderFrame(val comment: String, val width: Int, val height: Int, val bitmap: BitmapData)
    data class HeaderParseResult(val arrayName: String?, val frames: List<HeaderFrame>)

    /**
     * Parses a generated `.h` file (as produced by [CCodeGenerator.generateHeader])
     * back into its array name and per-frame bitmaps, matching
     * `ImageConverterApp.parse_header_file()` / `extract_folder_name()`.
     */
    fun parseHeaderFile(content: String, orientation: ByteOrientation = ByteOrientation.HORIZONTAL): HeaderParseResult {
        val arrayName = extractArrayName(content)

        val framePattern = Regex(
            "//\\s*'(.*?)',\\s*(\\d+)x(\\d+)px[^{]*\\{(.*?)}",
            RegexOption.DOT_MATCHES_ALL
        )
        val frames = framePattern.findAll(content).map { match ->
            val (comment, widthStr, heightStr, body) = match.destructured
            val width = widthStr.toInt()
            val height = heightStr.toInt()
            val bytes = ByteDataParser.parse(body)
            HeaderFrame(comment, width, height, ByteArrayConverter.unpack(bytes, width, height, orientation))
        }.toList()

        return HeaderParseResult(arrayName, frames)
    }

    /** Extracts the array's declared name, e.g. "foo" from "const unsigned char foo[10][32] PROGMEM = {". */
    private fun extractArrayName(content: String): String? {
        val prefix = "const unsigned char "
        val start = content.indexOf(prefix)
        if (start == -1) return null
        val nameStart = start + prefix.length
        val bracket = content.indexOf('[', nameStart)
        if (bracket == -1) return null
        return content.substring(nameStart, bracket).trim().ifEmpty { null }
    }
}
