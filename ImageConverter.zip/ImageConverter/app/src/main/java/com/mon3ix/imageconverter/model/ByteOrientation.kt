package com.mon3ix.imageconverter.model

/**
 * Orientation used when packing/unpacking monochrome pixel data into bytes.
 *
 * Mirrors the Python app's `list_to_image_horizontal()` / `list_to_image_vertical()`
 * pair. In both modes bits are packed MSB-first (bit 7 = first pixel of the
 * byte, bit 0 = eighth), and a **set bit (1) means "black"** — see
 * [com.mon3ix.imageconverter.converter.ByteArrayConverter] for why this
 * polarity was chosen as the single canonical convention for this app.
 *
 * - [HORIZONTAL]: each byte covers 8 consecutive pixels **along a row**
 *   (left to right). This is the layout used for PBM files and for simple
 *   `drawBitmap()`-style Arduino images.
 * - [VERTICAL]: each byte covers 8 consecutive pixels **down a column**
 *   within an 8-pixel-tall "page". This is the layout used by SSD1306-style
 *   OLED controllers in "page addressing" mode.
 */
enum class ByteOrientation {
    HORIZONTAL,
    VERTICAL
}
