package com.mon3ix.imageconverter.converter

import com.mon3ix.imageconverter.model.BitmapData
import com.mon3ix.imageconverter.model.ByteOrientation

/**
 * Packs / unpacks [BitmapData] to and from raw monochrome byte data. This is
 * the deterministic core the whole app is built on (PBM writer, C-code
 * generator, grid editor, C-array/byte-array reconstruction all route
 * through here) -- see item 17/21 of the porting brief.
 *
 * ## Bit order
 * MSB-first within each byte, in both orientations: bit 7 is the first
 * pixel represented by that byte, bit 0 is the eighth. This matches the
 * grid editor's own `get_pixels()`/`get_cpp_pixels()` (`value |= 1 << (7-i)`)
 * and `image_to_c_array()` (`byte |= (1 << (7 - (x % 8)))`).
 *
 * ## Bit polarity: a bug found and fixed
 * **A set bit (1) always means "black" here.** That is the real PBM P4
 * standard's convention, and it's what `image_to_c_array()`, the grid
 * editor, and `image_to_byte_array()` (via Pillow's own PPM/PBM encoder)
 * all agree on in the original app. Two other code paths in the Python
 * source get this backwards:
 *
 * 1. Both `convert_to_pbm()` implementations write `binary_image.tobytes()`
 *    straight to a `.pbm` file. Pillow's raw mode-"1" `tobytes()` uses its
 *    own internal convention (non-zero pixel value = bit 1 = "on"), and
 *    Pillow's internal "on" for mode "1" is *white*, not black. That's the
 *    opposite of the real PBM spec (where a set bit means ink/black).
 *    Bypassing Pillow's actual PBM encoder (`Image.save(path, "PPM")`, which
 *    does perform this inversion correctly) means the app's own `.pbm`
 *    files are polarity-inverted relative to the format they claim to be.
 * 2. The two module-level `list_to_image_horizontal()` / `list_to_image_vertical()`
 *    functions (used only by the "Drawcpp" button) build an RGB image with
 *    `color = 255 if bit == "1" else 0`, i.e. bit 1 -> white -- backwards
 *    compared to every other reconstruction path in the app (the class-level
 *    `list_to_image_horizontal()` used by the GIF pipeline, and the grid
 *    editor's `draw_pixels()`, both use bit 1 -> black).
 *
 * Both of those are fixed here rather than reproduced: every pack/unpack
 * function below uses the single "1 = black" convention consistently, which
 * also happens to be the convention the *majority* of the original app
 * already relied on.
 */
object ByteArrayConverter {

    /**
     * Row-major ("horizontal") packing: each row is packed left-to-right, 8
     * pixels per byte. If width isn't a multiple of 8, the last byte of each
     * row is padded with zero bits (white) at the low-order end, and every
     * row starts a fresh byte -- exactly PBM's own row-packing rule.
     */
    fun packHorizontal(data: BitmapData): ByteArray {
        val bytesPerRow = bytesPerRow(data.width)
        val out = ByteArray(bytesPerRow * data.height)
        for (y in 0 until data.height) {
            for (x in 0 until data.width) {
                if (data.get(x, y)) {
                    val byteIndex = y * bytesPerRow + (x / 8)
                    val bitIndex = 7 - (x % 8)
                    out[byteIndex] = (out[byteIndex].toInt() or (1 shl bitIndex)).toByte()
                }
            }
        }
        return out
    }

    /**
     * Column-major ("vertical"/"page") packing used by SSD1306-style OLED
     * controllers: the bitmap is divided into 8-pixel-tall pages; within a
     * page, each byte represents one vertical column of 8 pixels, MSB =
     * topmost pixel of the page. If height isn't a multiple of 8, the last
     * page is padded with zero bits for the missing rows.
     */
    fun packVertical(data: BitmapData): ByteArray {
        val pages = pagesFor(data.height)
        val out = ByteArray(pages * data.width)
        for (page in 0 until pages) {
            for (x in 0 until data.width) {
                var b = 0
                for (bit in 0 until 8) {
                    val y = page * 8 + bit
                    if (y < data.height && data.get(x, y)) {
                        b = b or (1 shl (7 - bit))
                    }
                }
                out[page * data.width + x] = b.toByte()
            }
        }
        return out
    }

    fun pack(data: BitmapData, orientation: ByteOrientation): ByteArray = when (orientation) {
        ByteOrientation.HORIZONTAL -> packHorizontal(data)
        ByteOrientation.VERTICAL -> packVertical(data)
    }

    fun unpackHorizontal(bytes: ByteArray, width: Int, height: Int): BitmapData {
        val bytesPerRow = bytesPerRow(width)
        require(bytes.size >= bytesPerRow * height) {
            "Not enough bytes: need ${bytesPerRow * height} for ${width}x$height, got ${bytes.size}"
        }
        val pixels = BooleanArray(width * height)
        for (y in 0 until height) {
            for (x in 0 until width) {
                val byteIndex = y * bytesPerRow + (x / 8)
                val bitIndex = 7 - (x % 8)
                pixels[y * width + x] = (bytes[byteIndex].toInt() shr bitIndex) and 1 == 1
            }
        }
        return BitmapData(width, height, pixels)
    }

    fun unpackVertical(bytes: ByteArray, width: Int, height: Int): BitmapData {
        val pages = pagesFor(height)
        require(bytes.size >= pages * width) {
            "Not enough bytes: need ${pages * width} for ${width}x$height, got ${bytes.size}"
        }
        val pixels = BooleanArray(width * height)
        for (page in 0 until pages) {
            for (x in 0 until width) {
                val b = bytes[page * width + x].toInt()
                for (bit in 0 until 8) {
                    val y = page * 8 + bit
                    if (y < height) {
                        pixels[y * width + x] = (b shr (7 - bit)) and 1 == 1
                    }
                }
            }
        }
        return BitmapData(width, height, pixels)
    }

    fun unpack(bytes: ByteArray, width: Int, height: Int, orientation: ByteOrientation): BitmapData =
        when (orientation) {
            ByteOrientation.HORIZONTAL -> unpackHorizontal(bytes, width, height)
            ByteOrientation.VERTICAL -> unpackVertical(bytes, width, height)
        }

    fun bytesPerRow(width: Int): Int = (width + 7) / 8
    fun pagesFor(height: Int): Int = (height + 7) / 8

    /** Formats bytes as a `bytearray(b'\x00\x18...')` literal, matching the grid editor's `get_pixels()` clipboard output. */
    fun toBytearrayLiteral(bytes: ByteArray): String =
        bytes.joinToString(prefix = "bytearray(b'", separator = "", postfix = "')") { "\\x%02x".format(it) }

    /** Formats bytes as a flat `0x00, 0x01, 0xFF, ...` hex list (used both standalone and inside generated C arrays). */
    fun toHexList(bytes: ByteArray, perLine: Int = 12): String {
        val sb = StringBuilder()
        for (i in bytes.indices) {
            sb.append("0x%02X".format(bytes[i]))
            if (i != bytes.lastIndex) sb.append(", ")
            if ((i + 1) % perLine == 0 && i != bytes.lastIndex) sb.append("\n    ")
        }
        return sb.toString()
    }
}
