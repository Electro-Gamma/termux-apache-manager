package com.mon3ix.imageconverter.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mon3ix.imageconverter.converter.ImageConverter
import com.mon3ix.imageconverter.model.ByteOrientation
import com.mon3ix.imageconverter.ui.AppViewModel
import com.mon3ix.imageconverter.ui.components.ImagePreviewCard
import com.mon3ix.imageconverter.ui.components.PixelGridCanvas

/**
 * Reproduces `draw_pixels()` / `draw_pixels_all()` / `list_to_image_horizontal()`
 * / `list_to_image_vertical()`: paste a `bytearray(b'\x..')` literal, a
 * `0x.., 0x..` list, or a whole `const unsigned char foo[] PROGMEM = {...}`
 * declaration, give it a width/height/orientation, and see the resulting
 * bitmap. "Parse as header" additionally understands a multi-frame
 * `name[FRAMES][BYTES]` header (each frame's own `WxHpx` size taken from its
 * `// 'name', WxHpx` comment) -- reproducing `parse_header_file()`.
 *
 * All parsing goes through [com.mon3ix.imageconverter.converter.ByteDataParser],
 * a safe hand-written tokenizer -- see that file for why this replaces the
 * original's `eval()` call.
 */
@Composable
fun ArrayToImageScreen(viewModel: AppViewModel) {
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            "Paste a byte array, bytearray(b'\\x..') literal, or a full C/C++ array declaration.",
            style = MaterialTheme.typography.bodyLarge
        )
        OutlinedTextField(
            value = viewModel.arrayInputText,
            onValueChange = { viewModel.arrayInputText = it },
            label = { Text("Byte / C array data") },
            modifier = Modifier.fillMaxWidth().height(140.dp)
        )
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(
                value = viewModel.arrayWidth.toString(),
                onValueChange = { it.toIntOrNull()?.let { w -> viewModel.arrayWidth = w } },
                label = { Text("Width") },
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = viewModel.arrayHeight.toString(),
                onValueChange = { it.toIntOrNull()?.let { h -> viewModel.arrayHeight = h } },
                label = { Text("Height") },
                modifier = Modifier.weight(1f)
            )
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Orientation: ", style = MaterialTheme.typography.bodyMedium)
            Button(onClick = {
                viewModel.arrayOrientation = if (viewModel.arrayOrientation == ByteOrientation.HORIZONTAL)
                    ByteOrientation.VERTICAL else ByteOrientation.HORIZONTAL
            }) { Text(if (viewModel.arrayOrientation == ByteOrientation.HORIZONTAL) "Horizontal" else "Vertical (page)") }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = { viewModel.decodeArrayInput() }) { Text("Decode single image") }
            Button(onClick = { viewModel.decodeHeaderInput() }) { Text("Parse as header (multi-frame)") }
            Button(onClick = { viewModel.decodedFromArray?.let { viewModel.loadIntoGrid(it) } }) { Text("Send to Grid Editor") }
        }

        viewModel.statusMessage?.let {
            Text(it, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
        }

        viewModel.decodedFromArray?.let { data ->
            Text("Result (${data.width}x${data.height})", style = MaterialTheme.typography.titleMedium)
            PixelGridCanvas(data = data, onPixelChanged = { _, _, _ -> }, editable = false)
        }

        if (viewModel.decodedHeaderFrames.isNotEmpty()) {
            Text("${viewModel.decodedHeaderFrames.size} frame(s) found", style = MaterialTheme.typography.titleMedium)
            viewModel.decodedHeaderFrames.forEachIndexed { i, frame ->
                ImagePreviewCard(
                    "Frame ${i + 1}: ${frame.comment} (${frame.width}x${frame.height})",
                    ImageConverter.toBitmap(frame.bitmap),
                    height = 120.dp
                )
            }
        }
    }
}
