package com.mon3ix.imageconverter.converter

import com.mon3ix.imageconverter.model.BitmapData
import com.mon3ix.imageconverter.model.ByteOrientation

/**
 * Reproduces `generate_cpp_code()` / `generate_header()` from the Python
 * app: Arduino/PROGMEM-friendly C arrays.
 *
 * Two things are deliberately fixed relative to the original:
 * - **Identifier sanitizing.** The Python app never sanitizes
 *   `image_name = os.path.basename(path).split('.')[0]` at all in
 *   `generate_cpp_code()`/`copy_image_to_byte_array()` (a name like
 *   "my image-1.png" becomes the invalid identifier `my image-1`), and in
 *   `generate_cpp_array()`/`generate_header()` it re-derives an ad hoc,
 *   slightly-different `.replace()` chain at *three* separate call sites,
 *   none of which guard against a leading digit or the full set of invalid
 *   C identifier characters. [sanitizeIdentifier] is the one place that
 *   logic lives now.
 * - **Line wrapping.** `generate_cpp_code()` inserts a newline every time
 *   `(i + 1) % width == 0`, using the image's *pixel* width as the byte-index
 *   modulus instead of bytes-per-row -- so generated code wraps at
 *   essentially arbitrary points unrelated to the image's actual rows. This
 *   only affects formatting, never the byte values, so we just wrap at a
 *   fixed, readable column count instead (see [ByteArrayConverter.toHexList]).
 */
object CCodeGenerator {

    /** Turns an arbitrary name into a valid, non-empty C/C++ identifier. */
    fun sanitizeIdentifier(raw: String): String {
        var name = raw.trim()
        // Strip a trailing file extension only (e.g. "my.image.v2.png" -> "my.image.v2"),
        // unlike the original's `split('.')[0]` which truncated at the *first* dot.
        val dot = name.lastIndexOf('.')
        if (dot > 0) name = name.substring(0, dot)
        // Collapse any run of invalid characters into a single underscore.
        name = name.replace(Regex("[^A-Za-z0-9_]+"), "_").trim('_')
        if (name.isEmpty()) name = "image"
        if (name[0].isDigit()) name = "_$name"
        return name
    }

    /** Single-image `const unsigned char name[] PROGMEM = {...};` declaration, e.g. for "Image -> C/C++". */
    fun generateImageCode(
        data: BitmapData,
        rawName: String,
        orientation: ByteOrientation = ByteOrientation.HORIZONTAL
    ): String {
        val name = sanitizeIdentifier(rawName)
        val bytes = ByteArrayConverter.pack(data, orientation)
        return buildString {
            append("// '$name', ${data.width}x${data.height}px\n")
            append("const unsigned char $name[] PROGMEM = {\n    ")
            append(ByteArrayConverter.toHexList(bytes))
            append("\n};\n")
        }
    }

    /**
     * Multi-frame header: `const unsigned char name[FRAMES][BYTES] PROGMEM = { {...}, {...} };`
     * matching `generate_header()`. [frames] must already be in display order
     * -- see [NaturalFrameOrder] for reproducing the "fnum1, fnum2, ..." sort.
     */
    fun generateHeader(
        frames: List<BitmapData>,
        rawName: String,
        orientation: ByteOrientation = ByteOrientation.HORIZONTAL
    ): String {
        require(frames.isNotEmpty()) { "Need at least one frame to generate a header" }
        val name = sanitizeIdentifier(rawName)
        val bytesPerFrame = ByteArrayConverter.pack(frames[0], orientation).size
        return buildString {
            append("// Generated image arrays\n")
            append("const unsigned char $name[${frames.size}][$bytesPerFrame] PROGMEM = {\n")
            frames.forEachIndexed { i, frame ->
                val bytes = ByteArrayConverter.pack(frame, orientation)
                // Quoted, comma-separated name+size comment -- same shape as generateImageCode()'s
                // single-image comment, and what BitmapDecoder.parseHeaderFile()'s regex expects
                // back out again (see that file, and item 4's `// 'image_name', 128x64px` example).
                append("    // '${name}_${i + 1}', ${frame.width}x${frame.height}px\n")
                append("    {\n        ")
                append(ByteArrayConverter.toHexList(bytes))
                append("\n    }")
                append(if (i != frames.lastIndex) ",\n" else "\n")
            }
            append("};\n")
        }
    }

    /**
     * Companion Arduino `.ino` sketch for an SSD1306 OLED, matching the
     * app's `generate_cpp_array()` output. [headerBaseName] should be the
     * sanitized array name used in [generateHeader] (without "_Arduino").
     */
    fun generateArduinoSketch(
        headerFileName: String,
        arrayName: String,
        frameCount: Int,
        width: Int,
        height: Int
    ): String {
        val initialCount = (frameCount - 1).coerceAtLeast(0)
        return """
            |#include <Wire.h>
            |#include <Adafruit_GFX.h>
            |#include <Adafruit_SSD1306.h>
            |#include "$headerFileName"  // Header file with your image data
            |
            |#define SCREEN_WIDTH 128 // OLED display width, in pixels
            |#define SCREEN_HEIGHT 64 // OLED display height, in pixels
            |
            |#define OLED_RESET    -1  // Reset pin # (or -1 if sharing Arduino reset pin)
            |Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);
            |
            |void setup() {
            |    Serial.begin(115200);
            |    delay(2000);
            |    if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
            |        Serial.println(F("SSD1306 allocation failed"));
            |        for (;;); // Don't proceed, loop forever
            |    }
            |    display.clearDisplay();
            |    display.setRotation(1);
            |    delay(2000);
            |}
            |
            |int count = $initialCount;
            |void loop() {
            |  display.clearDisplay();
            |  display.drawBitmap(0, 0, $arrayName[count], $width, $height, WHITE);
            |  display.display();
            |  count++;
            |  if (count >= $frameCount) count = 0;
            |  delay(40); // Adjust for animation speed
            |}
            |
        """.trimMargin()
    }
}
