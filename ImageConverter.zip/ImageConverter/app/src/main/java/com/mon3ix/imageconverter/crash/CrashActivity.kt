// Adapted from the user-supplied CrashHandlerKit, moved into this app's own package.
package com.mon3ix.imageconverter.crash

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Process
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.system.exitProcess

/**
 * Deliberately independent of the rest of the app: plain platform widgets, built in code (no
 * XML layout, no ViewBinding, no Material components), and given a stock platform theme in the
 * manifest rather than the app's own. It also runs in its own process
 * (android:process=":crash" in the manifest), so it comes up fresh even when the main app
 * process just died. The goal is a screen with as little as possible that could itself go wrong.
 */
class CrashActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val report = intent.getStringExtra(EXTRA_REPORT).orEmpty()
        val filePath = intent.getStringExtra(EXTRA_FILE_PATH)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            setPadding(32, 64, 32, 32)
        }

        root.addView(TextView(this).apply {
            text = "App crashed"
            setTextColor(Color.BLACK)
            textSize = 20f
            setTypeface(null, Typeface.BOLD)
        })

        root.addView(TextView(this).apply {
            text = "Copy this and send it back so the real cause can be fixed."
            setTextColor(Color.DKGRAY)
            textSize = 14f
            setPadding(0, 8, 0, 20)
        })

        val reportView = TextView(this).apply {
            text = report.ifBlank { "No crash details were captured." }
            setTextColor(Color.BLACK)
            setBackgroundColor(Color.parseColor("#F0F0F0"))
            typeface = Typeface.MONOSPACE
            textSize = 12f
            setPadding(24, 24, 24, 24)
            setTextIsSelectable(true)
        }

        val scroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
            )
            addView(reportView)
        }
        root.addView(scroll)

        val buttonRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = 20 }
        }

        buttonRow.addView(Button(this).apply {
            text = "Copy to clipboard"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("Crash report", report))
                Toast.makeText(this@CrashActivity, "Copied", Toast.LENGTH_SHORT).show()
            }
        })

        buttonRow.addView(Button(this).apply {
            text = "Close"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                Process.killProcess(Process.myPid())
                exitProcess(0)
            }
        })
        root.addView(buttonRow)

        if (!filePath.isNullOrBlank()) {
            root.addView(TextView(this).apply {
                text = "Also saved on-device at: $filePath"
                setTextColor(Color.GRAY)
                textSize = 11f
                gravity = Gravity.START
                setPadding(0, 12, 0, 0)
            })
        }

        setContentView(root)
    }

    companion object {
        const val EXTRA_REPORT = "extra_report"
        const val EXTRA_FILE_PATH = "extra_file_path"
    }
}
