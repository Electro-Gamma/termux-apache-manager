package com.mon3ix.imageconverter.model

import android.graphics.Bitmap

/**
 * One frame extracted from (or destined for) an animated GIF, alongside its
 * display duration. Mirrors the "fnum1.pbm, fnum2.pbm, ..." frame sequence
 * the Python app builds up during GIF splitting / header generation.
 */
data class ImageFrame(
    val index: Int,
    val bitmap: Bitmap,
    val durationMs: Int
)
