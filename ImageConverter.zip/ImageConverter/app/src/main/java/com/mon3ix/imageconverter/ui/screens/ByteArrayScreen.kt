package com.mon3ix.imageconverter.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mon3ix.imageconverter.ui.AppViewModel
import com.mon3ix.imageconverter.ui.components.CodeOutputCard
import com.mon3ix.imageconverter.ui.components.ImagePreviewCard

/**
 * Reproduces `copy_image_to_byte_array()` / `image_to_byte_array()`: shows
 * the currently converted image (from the Input Image screen) as both a
 * `bytearray(b'\x..')` literal and a flat `0x.., 0x..` hex list, each with
 * its own Copy button.
 */
@Composable
fun ByteArrayScreen(viewModel: AppViewModel) {
    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        if (viewModel.converted == null) {
            Text(
                "Convert an image on the Input Image screen first.",
                style = MaterialTheme.typography.bodyLarge
            )
        } else {
            ImagePreviewCard("Converted Image", viewModel.convertedBitmapPreview(), height = 160.dp)
            CodeOutputCard(title = "bytearray literal", code = viewModel.bytesLiteral())
            CodeOutputCard(title = "Hex list", code = viewModel.bytesHex())
        }
    }
}
