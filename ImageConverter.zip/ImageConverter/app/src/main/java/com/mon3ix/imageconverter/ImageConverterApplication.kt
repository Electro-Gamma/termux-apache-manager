package com.mon3ix.imageconverter

import android.app.Application
import com.mon3ix.imageconverter.crash.GlobalCrashHandler

class ImageConverterApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        GlobalCrashHandler.install(this)
    }
}
