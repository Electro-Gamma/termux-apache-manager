package com.mon3ix.imageconverter.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp

/**
 * A scrollable, selectable, monospace output box with a "Copy" button --
 * used everywhere the original app called `pyperclip.copy(...)`: generated
 * C/C++ code, byte-array literals, and headers.
 */
@Composable
fun CodeOutputCard(
    title: String,
    code: String,
    modifier: Modifier = Modifier,
    onSave: (() -> Unit)? = null
) {
    val clipboard = LocalClipboardManager.current
    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(title, style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (onSave != null) {
                    Button(onClick = onSave) { Text("Save") }
                }
                Button(onClick = { clipboard.setText(AnnotatedString(code)) }) { Text("Copy") }
            }
        }
        SelectionContainer {
            Text(
                text = code.ifBlank { "(nothing generated yet)" },
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp)
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(10.dp)
                    .verticalScroll(rememberScrollState())
            )
        }
    }
}
