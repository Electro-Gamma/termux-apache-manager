package com.mon3ix.imageconverter.converter

/**
 * Parses pasted byte data into a plain [ByteArray]. Covers everything the
 * Python app's "Byte/C Array -> Image" and grid-editor "Draw" inputs accept:
 *
 * - Python bytes/bytearray escapes: `bytearray(b'\x00\x18\x3c')`, `b'\x00\x18'`
 * - C/C++ arrays: `const unsigned char image[] PROGMEM = { 0x00, 0x18, ... };`
 * - A bare comma/whitespace-separated list of hex (`0x1F`) or decimal values
 *
 * ## Why this exists
 * The original app parses both of these with
 * `bytearray(eval('b"' + cleaned_data + '"'))` (`draw_pixels()`,
 * `draw_pixels_all()`) or a hand-rolled string-strip + `split(',')` for the
 * C-array case (`draw_cpp_pixels()`). `eval()` on attacker-influenced text
 * is arbitrary code execution -- item 22 of the porting brief calls this out
 * explicitly. This is a small hand-written tokenizer instead: it only ever
 * recognises byte-sized numeric literals and never executes anything.
 *
 * KNOWN LIMITATION vs. Python's `\x` literal handling: a genuine Python
 * `bytes`/`bytearray` `repr()` only escapes non-printable bytes as `\xNN`;
 * printable ASCII bytes (0x20-0x7E, e.g. `A` for 0x41) appear as literal
 * characters instead. This parser only recognises the `\xNN` form. For this
 * app's use case -- pasting monochrome bitmap byte data, which is
 * overwhelmingly non-printable -- that's the form every code path in the
 * original app actually produces (`get_pixels()` always emits `\xNN` for
 * every byte, never a literal character), so this covers real inputs; a
 * hand-typed literal-character byte would need to be given as `0x..` hex
 * instead.
 */
object ByteDataParser {

    class ParseException(message: String) : Exception(message)

    private val declarationWords = setOf(
        "const", "unsigned", "char", "int", "static", "progmem", "byte", "uint8_t", "bytearray", "b"
    )

    fun parse(rawInput: String): ByteArray {
        val text = rawInput.trim()
        if (text.isEmpty()) throw ParseException("Input is empty")

        if (text.contains("\\x")) {
            val escaped = Regex("\\\\x([0-9A-Fa-f]{2})").findAll(text)
                .map { it.groupValues[1].toInt(16).toByte() }
                .toList()
            if (escaped.isNotEmpty()) return escaped.toByteArray()
        }

        return parseNumericList(text)
    }

    private fun parseNumericList(text: String): ByteArray {
        var cleaned = text
            .replace(Regex("//[^\n]*"), "")
            .replace(Regex("/\\*.*?\\*/", RegexOption.DOT_MATCHES_ALL), "")

        // If this looks like a declaration ("... = { ... };"), keep only the braced payload.
        // Multi-dimensional header arrays ("{ {..}, {..} }") just get their inner braces
        // stripped too -- flattening every frame's bytes into one sequential list, which the
        // caller (BitmapDecoder) is responsible for re-splitting per frame if needed.
        val braceStart = cleaned.indexOf('{')
        val braceEnd = cleaned.lastIndexOf('}')
        if (braceStart != -1 && braceEnd != -1 && braceEnd > braceStart) {
            cleaned = cleaned.substring(braceStart + 1, braceEnd)
        }
        cleaned = cleaned.replace('{', ' ').replace('}', ' ')

        val tokens = cleaned.split(Regex("[,\\s]+")).filter { it.isNotBlank() }
        if (tokens.isEmpty()) throw ParseException("No byte values found in input")

        val bytes = ArrayList<Byte>(tokens.size)
        for (rawToken in tokens) {
            val token = rawToken.trim().trimEnd(';')
            if (token.isEmpty()) continue
            if (token.lowercase() in declarationWords) continue
            if (token.contains('[') || token.contains(']') || token.contains('=')) continue

            val value = parseNumericToken(token)
                ?: throw ParseException("Could not parse byte value: '$token'")
            if (value !in 0..255) throw ParseException("Value $value out of byte range (0-255): '$token'")
            bytes.add(value.toByte())
        }
        if (bytes.isEmpty()) throw ParseException("No byte values found in input")
        return bytes.toByteArray()
    }

    private fun parseNumericToken(token: String): Int? = try {
        when {
            token.startsWith("0x", ignoreCase = true) -> token.substring(2).toInt(16)
            Regex("^[0-9]+$").matches(token) -> token.toInt()
            else -> null
        }
    } catch (e: NumberFormatException) {
        null
    }
}
