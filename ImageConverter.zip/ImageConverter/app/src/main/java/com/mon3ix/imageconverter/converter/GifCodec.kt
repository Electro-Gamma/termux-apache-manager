package com.mon3ix.imageconverter.converter

import android.graphics.Bitmap
import java.io.ByteArrayOutputStream

/**
 * Self-contained GIF89a decoder and LZW encoder.
 *
 * The Python app leans on Pillow for both directions (`Image.open(gif)` +
 * `gif.seek()` for splitting, `Image.save(..., save_all=True)` for
 * creating). Android has no first-party GIF *encoder*, and no supported API
 * cleanly exposes individual decoded frames + per-frame delay either. Per
 * item 6 of the porting brief ("implement the required encoder locally" if
 * platform APIs can't do it reliably), this hand-rolled codec covers both
 * directions instead of pulling in a third-party dependency -- which also
 * means the build has one fewer thing that can fail to resolve.
 *
 * ## Known, documented simplifications (vs. Pillow)
 * - **Colour quantization on encode** is a simple exact-palette-if-it-fits,
 *   else uniform per-channel bit-depth reduction fallback -- not Pillow's
 *   proper octree/median-cut quantizer. This app's own frames are almost
 *   always black/white (derived from PBM/monochrome data), where an exact
 *   2-colour palette is trivially correct; the fallback only engages for
 *   arbitrary full-colour source images.
 * - **Disposal methods** 0 (unspecified) and 1 (do not dispose) are handled
 *   identically (frames simply accumulate on the canvas), which covers the
 *   vast majority of simple, non-optimized animations. Disposal 2 (restore
 *   to background) and 3 (restore to previous) are also implemented.
 * - No support for a global colour table with a *sorted* flag, and no
 *   Plain Text extension rendering (both vanishingly rare in practice and
 *   have no bearing on pixel decoding).
 */
object GifCodec {

    data class DecodedFrame(val bitmap: Bitmap, val delayMs: Int)

    // ---------------------------------------------------------------- encode

    fun encode(frames: List<Bitmap>, delaysMs: List<Int>, loop: Boolean = true): ByteArray {
        require(frames.isNotEmpty()) { "Need at least one frame to build a GIF" }
        require(frames.size == delaysMs.size) { "frames and delaysMs must be the same size" }
        val width = frames[0].width
        val height = frames[0].height

        val palette = buildPalette(frames)
        val out = ByteArrayOutputStream()

        fun u16le(v: Int) {
            out.write(v and 0xFF)
            out.write((v shr 8) and 0xFF)
        }

        out.write("GIF89a".toByteArray(Charsets.US_ASCII))
        u16le(width)
        u16le(height)
        val gctSizeField = palette.colorBits - 1 // table has 2^(N+1) entries
        out.write(0x80 or ((palette.colorBits - 1) shl 4) or gctSizeField)
        out.write(0) // background color index
        out.write(0) // pixel aspect ratio
        for (c in palette.colors) {
            out.write((c shr 16) and 0xFF); out.write((c shr 8) and 0xFF); out.write(c and 0xFF)
        }

        if (loop) {
            out.write(0x21); out.write(0xFF); out.write(11)
            out.write("NETSCAPE2.0".toByteArray(Charsets.US_ASCII))
            out.write(3); out.write(1); u16le(0); out.write(0)
        }

        for ((i, bmp) in frames.withIndex()) {
            require(bmp.width == width && bmp.height == height) {
                "All frames must share the first frame's dimensions (${width}x$height)"
            }
            val delayCentis = (delaysMs[i] / 10).coerceIn(1, 65535)

            out.write(0x21); out.write(0xF9); out.write(4)
            out.write(0x00) // no transparency, disposal unspecified
            u16le(delayCentis)
            out.write(0)
            out.write(0)

            out.write(0x2C)
            u16le(0); u16le(0)
            u16le(width); u16le(height)
            out.write(0x00) // no local color table, not interlaced

            val px = IntArray(width * height)
            bmp.getPixels(px, 0, width, 0, 0, width, height)
            val indices = IntArray(px.size) { palette.indexOf(px[it]) }

            out.write(palette.colorBits)
            writeSubBlocks(out, lzwEncode(indices, palette.colorBits))
        }

        out.write(0x3B)
        return out.toByteArray()
    }

    private fun writeSubBlocks(out: ByteArrayOutputStream, data: ByteArray) {
        var pos = 0
        while (pos < data.size) {
            val len = minOf(255, data.size - pos)
            out.write(len)
            out.write(data, pos, len)
            pos += len
        }
        out.write(0)
    }

    private class Palette(val colors: IntArray, private val quantizeShift: Int) {
        val colorBits: Int = run {
            var n = 1
            while ((1 shl n) < colors.size) n++
            n
        }
        private val lookup = HashMap<Int, Int>().apply {
            colors.forEachIndexed { i, c -> if (!containsKey(c)) put(c, i) }
        }

        fun indexOf(argb: Int): Int {
            val rgb = quantize(argb and 0x00FFFFFF)
            lookup[rgb]?.let { return it }
            var best = 0
            var bestDist = Int.MAX_VALUE
            val r = (rgb shr 16) and 0xFF; val g = (rgb shr 8) and 0xFF; val b = rgb and 0xFF
            for (i in colors.indices) {
                val c = colors[i]
                val cr = (c shr 16) and 0xFF; val cg = (c shr 8) and 0xFF; val cb = c and 0xFF
                val d = (r - cr) * (r - cr) + (g - cg) * (g - cg) + (b - cb) * (b - cb)
                if (d < bestDist) { bestDist = d; best = i }
            }
            return best
        }

        private fun quantize(rgb: Int): Int {
            if (quantizeShift == 0) return rgb
            val r = (((rgb shr 16) and 0xFF) shr quantizeShift) shl quantizeShift
            val g = (((rgb shr 8) and 0xFF) shr quantizeShift) shl quantizeShift
            val b = ((rgb and 0xFF) shr quantizeShift) shl quantizeShift
            return (r shl 16) or (g shl 8) or b
        }
    }

    private fun buildPalette(bitmaps: List<Bitmap>): Palette {
        val seen = LinkedHashSet<Int>()
        outer@ for (bmp in bitmaps) {
            val px = IntArray(bmp.width * bmp.height)
            bmp.getPixels(px, 0, bmp.width, 0, 0, bmp.width, bmp.height)
            for (p in px) {
                seen.add(p and 0x00FFFFFF)
                if (seen.size > 8192) break@outer // cap scan cost; quantization below still applies
            }
        }
        var colors = seen.toList()
        var shift = 0
        if (colors.size > 256) {
            for (candidateShift in 1..7) {
                val bucket = LinkedHashSet<Int>()
                for (c in colors) {
                    val r = (((c shr 16) and 0xFF) shr candidateShift) shl candidateShift
                    val g = (((c shr 8) and 0xFF) shr candidateShift) shl candidateShift
                    val b = ((c and 0xFF) shr candidateShift) shl candidateShift
                    bucket.add((r shl 16) or (g shl 8) or b)
                }
                if (bucket.size <= 256) {
                    colors = bucket.toList()
                    shift = candidateShift
                    break
                }
            }
            if (colors.size > 256) { colors = colors.take(256); shift = 7 }
        }
        if (colors.isEmpty()) colors = listOf(0x000000, 0xFFFFFF)

        var size = 2
        while (size < colors.size) size *= 2
        val padded = colors + List(size - colors.size) { colors.last() }
        return Palette(padded.toIntArray(), shift)
    }

    private fun lzwEncode(indices: IntArray, colorBits: Int): ByteArray {
        val clearCode = 1 shl colorBits
        val endCode = clearCode + 1
        val writer = LsbBitWriter()
        var codeSize = colorBits + 1
        var nextCode = endCode + 1
        val table = HashMap<Long, Int>()

        writer.writeBits(clearCode, codeSize)
        if (indices.isEmpty()) {
            writer.writeBits(endCode, codeSize)
            return writer.toByteArray()
        }

        var currentCode = indices[0]
        for (k in 1 until indices.size) {
            val next = indices[k]
            val key = (currentCode.toLong() shl 16) or next.toLong()
            val existing = table[key]
            if (existing != null) {
                currentCode = existing
            } else {
                writer.writeBits(currentCode, codeSize)
                if (nextCode < 4096) {
                    table[key] = nextCode
                    nextCode++
                    if (nextCode >= (1 shl codeSize) && codeSize < 12) codeSize++
                }
                currentCode = next
            }
        }
        writer.writeBits(currentCode, codeSize)
        writer.writeBits(endCode, codeSize)
        return writer.toByteArray()
    }

    private class LsbBitWriter {
        private val bytes = ArrayList<Byte>()
        private var current = 0
        private var bitCount = 0
        fun writeBits(value: Int, numBits: Int) {
            var v = value
            repeat(numBits) {
                current = current or ((v and 1) shl bitCount)
                v = v shr 1
                bitCount++
                if (bitCount == 8) {
                    bytes.add(current.toByte())
                    current = 0
                    bitCount = 0
                }
            }
        }
        fun toByteArray(): ByteArray {
            if (bitCount > 0) bytes.add(current.toByte())
            return bytes.toByteArray()
        }
    }

    // ---------------------------------------------------------------- decode

    fun decode(data: ByteArray): List<DecodedFrame> {
        require(data.size > 13) { "Not a valid GIF file (too short)" }
        val magic = String(data, 0, 6, Charsets.US_ASCII)
        require(magic == "GIF87a" || magic == "GIF89a") { "Not a GIF file (unexpected header: $magic)" }

        val cursor = intArrayOf(6)
        fun u8(): Int = data[cursor[0]++].toInt() and 0xFF
        fun u16(): Int { val lo = u8(); val hi = u8(); return lo or (hi shl 8) }

        val screenWidth = u16()
        val screenHeight = u16()
        val screenPacked = u8()
        u8(); u8() // background color index, pixel aspect ratio (both unused here)

        var globalTable: IntArray? = null
        if ((screenPacked and 0x80) != 0) {
            val n = 1 shl ((screenPacked and 0x07) + 1)
            globalTable = IntArray(n) { (u8() shl 16) or (u8() shl 8) or u8() }
        }

        val frames = ArrayList<DecodedFrame>()
        val canvas = IntArray(screenWidth * screenHeight)

        var delayCentis = 10
        var transparentIndex = -1
        var pendingDisposal = 0
        var nextFrameDisposal = 0
        var prevRect: IntArray? = null // left, top, w, h
        var prevSnapshot: IntArray? = null

        fun applyPendingDisposal() {
            val rect = prevRect ?: return
            val (left, top, w, h) = rect
            when (pendingDisposal) {
                2 -> for (y in 0 until h) for (x in 0 until w) {
                    val cx = left + x; val cy = top + y
                    if (cx < screenWidth && cy < screenHeight) canvas[cy * screenWidth + cx] = 0
                }
                3 -> prevSnapshot?.let { snap ->
                    var s = 0
                    for (y in 0 until h) for (x in 0 until w) {
                        val cx = left + x; val cy = top + y
                        if (cx < screenWidth && cy < screenHeight) canvas[cy * screenWidth + cx] = snap[s]
                        s++
                    }
                }
            }
        }

        loop@ while (cursor[0] < data.size) {
            when (u8()) {
                0x21 -> {
                    val label = u8()
                    if (label == 0xF9) {
                        u8() // block size = 4
                        val flags = u8()
                        val frameDisposal = (flags shr 2) and 0x07
                        val hasTransparency = (flags and 0x01) != 0
                        delayCentis = u16()
                        val tIndex = u8()
                        transparentIndex = if (hasTransparency) tIndex else -1
                        u8() // terminator
                        nextFrameDisposal = frameDisposal
                    } else {
                        skipSubBlocks(data, cursor)
                    }
                }
                0x2C -> {
                    val left = u16(); val top = u16(); val w = u16(); val h = u16()
                    val imgPacked = u8()
                    val interlaced = (imgPacked and 0x40) != 0
                    val localTable = if ((imgPacked and 0x80) != 0) {
                        val n = 1 shl ((imgPacked and 0x07) + 1)
                        IntArray(n) { (u8() shl 16) or (u8() shl 8) or u8() }
                    } else null
                    val colorTable = localTable ?: globalTable ?: intArrayOf(0x000000, 0xFFFFFF)

                    val minCodeSize = u8()
                    val compressed = readSubBlocks(data, cursor)
                    val indices = lzwDecode(compressed, minCodeSize, w * h)
                    val ordered = if (interlaced) deinterlace(indices, w, h) else indices

                    applyPendingDisposal()

                    val snapshotForThisFrame = if (nextFrameDisposal == 3) {
                        IntArray(w * h).also { snap ->
                            var s = 0
                            for (y in 0 until h) for (x in 0 until w) {
                                val cx = left + x; val cy = top + y
                                snap[s++] = if (cx < screenWidth && cy < screenHeight) canvas[cy * screenWidth + cx] else 0
                            }
                        }
                    } else null

                    for (y in 0 until h) {
                        for (x in 0 until w) {
                            val idx = ordered[y * w + x]
                            if (idx == transparentIndex) continue
                            val cx = left + x; val cy = top + y
                            if (cx in 0 until screenWidth && cy in 0 until screenHeight) {
                                val rgb = colorTable.getOrElse(idx) { 0x000000 }
                                canvas[cy * screenWidth + cx] = (0xFF shl 24) or rgb
                            }
                        }
                    }

                    val bmp = Bitmap.createBitmap(screenWidth, screenHeight, Bitmap.Config.ARGB_8888)
                    bmp.setPixels(canvas, 0, screenWidth, 0, 0, screenWidth, screenHeight)
                    val ms = (delayCentis * 10).let { if (it <= 0) 100 else it }
                    frames.add(DecodedFrame(bmp, ms))

                    pendingDisposal = nextFrameDisposal
                    prevRect = intArrayOf(left, top, w, h)
                    prevSnapshot = snapshotForThisFrame
                    transparentIndex = -1
                    nextFrameDisposal = 0
                }
                0x3B -> break@loop
                else -> break@loop // corrupt/unrecognised data -- stop instead of looping forever
            }
        }
        return frames
    }

    private operator fun IntArray.component1() = this[0]
    private operator fun IntArray.component2() = this[1]
    private operator fun IntArray.component3() = this[2]
    private operator fun IntArray.component4() = this[3]

    private fun skipSubBlocks(data: ByteArray, cursor: IntArray) {
        while (true) {
            val len = data[cursor[0]++].toInt() and 0xFF
            if (len == 0) break
            cursor[0] += len
        }
    }

    private fun readSubBlocks(data: ByteArray, cursor: IntArray): ByteArray {
        val out = ByteArrayOutputStream()
        while (true) {
            val len = data[cursor[0]++].toInt() and 0xFF
            if (len == 0) break
            out.write(data, cursor[0], len)
            cursor[0] += len
        }
        return out.toByteArray()
    }

    private fun deinterlace(data: IntArray, width: Int, height: Int): IntArray {
        val out = IntArray(width * height)
        var srcRow = 0
        for ((start, step) in listOf(0 to 8, 4 to 8, 2 to 4, 1 to 2)) {
            var row = start
            while (row < height) {
                System.arraycopy(data, srcRow * width, out, row * width, width)
                srcRow++
                row += step
            }
        }
        return out
    }

    private fun lzwDecode(data: ByteArray, minCodeSize: Int, expectedPixelCount: Int): IntArray {
        val clearCode = 1 shl minCodeSize
        val endCode = clearCode + 1
        val reader = LsbBitReader(data)

        var dict = ArrayList<IntArray>()
        fun resetDict() {
            dict = ArrayList(4096)
            for (i in 0 until clearCode) dict.add(intArrayOf(i))
            dict.add(IntArray(0)) // clearCode slot (unused as data)
            dict.add(IntArray(0)) // endCode slot (unused as data)
        }
        resetDict()

        var codeSize = minCodeSize + 1
        val out = IntArray(expectedPixelCount)
        var outPos = 0
        var prevEntry: IntArray? = null

        while (outPos < expectedPixelCount) {
            val code = reader.readBits(codeSize) ?: break
            if (code == clearCode) {
                resetDict(); codeSize = minCodeSize + 1; prevEntry = null
                continue
            }
            if (code == endCode) break

            val entry: IntArray = when {
                code < dict.size && dict[code].isNotEmpty() -> dict[code]
                code == dict.size && prevEntry != null -> prevEntry!! + prevEntry!![0]
                else -> break
            }

            var i = 0
            while (i < entry.size && outPos < expectedPixelCount) { out[outPos++] = entry[i]; i++ }

            if (prevEntry != null && dict.size < 4096) {
                dict.add(prevEntry!! + entry[0])
                if (dict.size >= (1 shl codeSize) && codeSize < 12) codeSize++
            }
            prevEntry = entry
        }
        return out
    }

    private class LsbBitReader(private val data: ByteArray) {
        private var bitPos = 0
        private val totalBits = data.size * 8
        fun readBits(n: Int): Int? {
            if (bitPos >= totalBits) return null
            var result = 0
            for (i in 0 until n) {
                val bytePos = bitPos / 8
                val bit = if (bytePos < data.size) (data[bytePos].toInt() shr (bitPos % 8)) and 1 else 0
                result = result or (bit shl i)
                bitPos++
            }
            return result
        }
    }
}
