package com.mon3ix.imageconverter.ui

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mon3ix.imageconverter.converter.BitmapDecoder
import com.mon3ix.imageconverter.converter.ByteArrayConverter
import com.mon3ix.imageconverter.converter.ByteDataParser
import com.mon3ix.imageconverter.converter.CCodeGenerator
import com.mon3ix.imageconverter.converter.GifCodec
import com.mon3ix.imageconverter.converter.ImageConverter
import com.mon3ix.imageconverter.converter.NaturalFrameOrder
import com.mon3ix.imageconverter.converter.PbmConverter
import com.mon3ix.imageconverter.model.BitmapData
import com.mon3ix.imageconverter.model.ByteOrientation
import com.mon3ix.imageconverter.model.ConversionOptions
import com.mon3ix.imageconverter.model.ImageFrame
import com.mon3ix.imageconverter.storage.FileRepository
import kotlinx.coroutines.launch

/**
 * Holds every screen's working state and calls into the pure `converter/`
 * engine + `storage/FileRepository` to do actual work -- per item 16 of the
 * porting brief, MainActivity and the Composable screens stay thin; this is
 * where the Tkinter app's callback-method logic (`convert_image()`,
 * `generate_cpp_code()`, `batch_convert_images()`, `play_images()`, ...)
 * actually lives now.
 */
class AppViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = FileRepository(application)

    // ---- Input image (shared by Home / Byte Array / C++ screens) ----
    var inputBitmap by mutableStateOf<Bitmap?>(null); private set
    var inputName by mutableStateOf("image"); private set
    var targetWidth by mutableStateOf(128); set
    var targetHeight by mutableStateOf(64); set
    var invert by mutableStateOf(false); set
    var orientation by mutableStateOf(ByteOrientation.HORIZONTAL); set
    var converted by mutableStateOf<BitmapData?>(null); private set
    var statusMessage by mutableStateOf<String?>(null); private set

    private fun options() = ConversionOptions(targetWidth, targetHeight, invert, threshold = 128, orientation = orientation)

    fun onImagePicked(uri: Uri, displayName: String?) = viewModelScope.launch {
        runCatching {
            val bmp = repository.loadBitmap(uri)
            inputBitmap = bmp
            inputName = displayName?.let { CCodeGenerator.sanitizeIdentifier(it) } ?: "image"
            converted = null
        }.onFailure { statusMessage = "Couldn't open image: ${it.message}" }
    }

    fun convertNow() {
        val bmp = inputBitmap ?: run { statusMessage = "Pick an image first"; return }
        converted = ImageConverter.toMonochrome(bmp, options())
    }

    fun convertedBitmapPreview(): Bitmap? = converted?.let { ImageConverter.toBitmap(it) }

    fun bytesHex(): String = converted?.let { ByteArrayConverter.toHexList(ByteArrayConverter.pack(it, orientation)) }.orEmpty()
    fun bytesLiteral(): String = converted?.let { ByteArrayConverter.toBytearrayLiteral(ByteArrayConverter.pack(it, orientation)) }.orEmpty()
    fun cppCode(): String = converted?.let { CCodeGenerator.generateImageCode(it, inputName, orientation) }.orEmpty()

    suspend fun savePbm(uri: Uri) {
        val data = converted ?: return
        repository.writeBytes(uri, PbmConverter.toPbmP4(data))
    }

    suspend fun saveConvertedPng(uri: Uri) {
        val data = converted ?: return
        repository.writeBitmapPng(uri, ImageConverter.toBitmap(data))
    }

    suspend fun saveText(uri: Uri, text: String) = repository.writeText(uri, text)

    fun clearStatus() { statusMessage = null }
    fun setStatus(message: String) { statusMessage = message }

    // ---- Batch conversion ----
    var batchLog by mutableStateOf<List<String>>(emptyList()); private set
    var batchRunning by mutableStateOf(false); private set

    fun batchConvert(inputTree: Uri, outputTree: Uri, width: Int, height: Int, doInvert: Boolean) = viewModelScope.launch {
        batchRunning = true
        batchLog = emptyList()
        runCatching {
            val images = repository.listImagesInTree(inputTree)
            val opts = ConversionOptions(width, height, doInvert)
            val log = mutableListOf<String>()
            for (img in images) {
                runCatching {
                    val bmp = repository.loadBitmap(img.uri)
                    val mono = ImageConverter.toMonochrome(bmp, opts)
                    val outName = CCodeGenerator.sanitizeIdentifier(img.name) + ".pbm"
                    val outUri = repository.createFileInTree(outputTree, outName, "image/x-portable-bitmap")
                    repository.writeBytes(outUri, PbmConverter.toPbmP4(mono))
                    log.add("✓ ${img.name} -> $outName")
                }.onFailure { log.add("✗ ${img.name}: ${it.message}") }
                batchLog = log.toList()
            }
        }.onFailure { batchLog = batchLog + "Batch failed: ${it.message}" }
        batchRunning = false
    }

    // ---- GIF tools ----
    var gifFrames by mutableStateOf<List<ImageFrame>>(emptyList()); private set
    var gifPlaying by mutableStateOf(false); private set
    var gifPlaybackFrame by mutableStateOf(0); private set
    var gifFrameDurationMs by mutableStateOf(100); set

    fun loadGif(uri: Uri) = viewModelScope.launch {
        runCatching {
            val bytes = repository.loadBytes(uri)
            val decoded = GifCodec.decode(bytes)
            gifFrames = decoded.mapIndexed { i, f -> ImageFrame(i, f.bitmap, f.delayMs) }
            statusMessage = "Loaded ${decoded.size} frame(s)"
        }.onFailure { statusMessage = "Couldn't read GIF: ${it.message}" }
    }

    fun startGifPlayback() = viewModelScope.launch {
        if (gifFrames.isEmpty()) return@launch
        gifPlaying = true
        gifPlaybackFrame = 0
        while (gifPlaying) {
            val frame = gifFrames.getOrNull(gifPlaybackFrame) ?: break
            kotlinx.coroutines.delay(frame.durationMs.toLong().coerceAtLeast(20))
            if (!gifPlaying) break
            gifPlaybackFrame = (gifPlaybackFrame + 1) % gifFrames.size
        }
    }

    fun stopGifPlayback() { gifPlaying = false }

    /** Resizes + thresholds every loaded GIF frame and writes each as PBM + PNG, then a combined header, to [outputTree]. */
    fun exportGifFrames(outputTree: Uri, width: Int, height: Int, doInvert: Boolean, baseName: String) = viewModelScope.launch {
        if (gifFrames.isEmpty()) { statusMessage = "Load a GIF first"; return@launch }
        runCatching {
            val opts = ConversionOptions(width, height, doInvert)
            val monoFrames = gifFrames.map { ImageConverter.toMonochrome(it.bitmap, opts) }
            val pbmFolder = repository.getOrCreateSubfolder(outputTree, "${baseName}_PBM")
            monoFrames.forEachIndexed { i, frame ->
                val fname = "fnum${i + 1}.pbm"
                val uri = repository.createFileInTree(pbmFolder, fname, "image/x-portable-bitmap")
                repository.writeBytes(uri, PbmConverter.toPbmP4(frame))
            }
            val header = CCodeGenerator.generateHeader(monoFrames, baseName, orientation)
            val headerUri = repository.createFileInTree(outputTree, "$baseName.h", "text/plain")
            repository.writeText(headerUri, header)
            statusMessage = "Exported ${monoFrames.size} frame(s) + header to ${baseName}_PBM / $baseName.h"
        }.onFailure { statusMessage = "Export failed: ${it.message}" }
    }

    /** Reads every PNG in [inputTree] (sorted by embedded frame number) and encodes them into one animated GIF at [outputUri]. */
    fun createGifFromFolder(inputTree: Uri, outputUri: Uri, durationMs: Int) = viewModelScope.launch {
        runCatching {
            val images = repository.listImagesInTree(inputTree, setOf("png"))
            val ordered = NaturalFrameOrder.sortByEmbeddedNumber(images) { it.name }
            if (ordered.isEmpty()) { statusMessage = "No PNG frames found in that folder"; return@launch }
            val bitmaps = ordered.map { repository.loadBitmap(it.uri) }
            val gifBytes = GifCodec.encode(bitmaps, List(bitmaps.size) { durationMs }, loop = true)
            repository.writeBytes(outputUri, gifBytes)
            statusMessage = "Created GIF from ${bitmaps.size} frame(s)"
        }.onFailure { statusMessage = "GIF creation failed: ${it.message}" }
    }

    // ---- Pixel grid editor ----
    var gridData by mutableStateOf(BitmapData.empty(8, 8)); private set

    fun resizeGrid(cols: Int, rows: Int) {
        if (cols <= 0 || rows <= 0) return
        val fresh = BitmapData.empty(cols, rows)
        gridData = fresh
    }

    fun setGridPixel(x: Int, y: Int, value: Boolean) { gridData = gridData.withPixel(x, y, value) }
    fun clearGrid() { gridData = BitmapData.empty(gridData.width, gridData.height) }
    fun invertGrid() { gridData = gridData.inverted() }
    fun loadIntoGrid(data: BitmapData) { gridData = data }

    suspend fun saveGridPng(uri: Uri) = repository.writeBitmapPng(uri, ImageConverter.toBitmap(gridData))

    // ---- C/C++ array & byte array -> image ----
    var arrayInputText by mutableStateOf(""); set
    var arrayWidth by mutableStateOf(8); set
    var arrayHeight by mutableStateOf(8); set
    var arrayOrientation by mutableStateOf(ByteOrientation.HORIZONTAL); set
    var decodedFromArray by mutableStateOf<BitmapData?>(null); private set
    var decodedHeaderFrames by mutableStateOf<List<BitmapDecoder.HeaderFrame>>(emptyList()); private set

    fun decodeArrayInput() {
        runCatching {
            decodedFromArray = BitmapDecoder.parseImage(arrayInputText, arrayWidth, arrayHeight, arrayOrientation)
            decodedHeaderFrames = emptyList()
            statusMessage = null
        }.onFailure { statusMessage = "Couldn't parse input: ${it.message}" }
    }

    fun decodeHeaderInput() {
        runCatching {
            val result = BitmapDecoder.parseHeaderFile(arrayInputText, arrayOrientation)
            if (result.frames.isEmpty()) throw ByteDataParser.ParseException("No frames found (expected // 'name', WxHpx comments)")
            decodedHeaderFrames = result.frames
            decodedFromArray = null
            statusMessage = "Parsed ${result.frames.size} frame(s)" + (result.arrayName?.let { " from array '$it'" } ?: "")
        }.onFailure { statusMessage = "Couldn't parse header: ${it.message}" }
    }

    companion object {
        val SUPPORTED_IMAGE_EXTENSIONS = setOf("png", "jpg", "jpeg", "gif", "bmp", "pbm")
    }
}
