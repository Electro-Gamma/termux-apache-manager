package com.mon3ix.imageconverter.model

/**
 * Settings for turning a colour image into a [BitmapData].
 *
 * @param threshold Matches the Python app's fixed rule `pixel < 128` -> black.
 *   Exposed here (rather than hard-coded) so tests can exercise edge values,
 *   but the UI always defaults it to 128 to preserve original behaviour.
 */
data class ConversionOptions(
    val targetWidth: Int,
    val targetHeight: Int,
    val invert: Boolean = false,
    val threshold: Int = 128,
    val orientation: ByteOrientation = ByteOrientation.HORIZONTAL
)
