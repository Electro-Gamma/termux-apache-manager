package com.mon3ix.imageconverter.converter

import com.mon3ix.imageconverter.model.BitmapData
import java.io.ByteArrayOutputStream

/**
 * Produces binary PBM (P4) data:
 *
 * ```
 * P4
 * # Created by Mon3ix
 * WIDTH HEIGHT
 * <binary row-major, MSB-first packed bits, 1 = black>
 * ```
 *
 * matching the header the Python app writes in `convert_to_pbm()`. The
 * payload comes from [ByteArrayConverter.packHorizontal], which uses the
 * spec-correct 1=black polarity -- see that file's doc comment for why the
 * original app's raw `binary_image.tobytes()` approach produced
 * polarity-inverted PBM files and why we don't reproduce that here.
 */
object PbmConverter {

    private const val MAGIC = "P4\n"
    private const val COMMENT = "# Created by Mon3ix\n"

    fun toPbmP4(data: BitmapData): ByteArray {
        val out = ByteArrayOutputStream()
        out.write(MAGIC.toByteArray(Charsets.US_ASCII))
        out.write(COMMENT.toByteArray(Charsets.US_ASCII))
        out.write("${data.width} ${data.height}\n".toByteArray(Charsets.US_ASCII))
        out.write(ByteArrayConverter.packHorizontal(data))
        return out.toByteArray()
    }

    /**
     * Parses binary PBM (P4) data back into a [BitmapData]. Used by the GIF
     * frame-playback path, which in the original app re-reads its own
     * `.pbm` files (`play_images()`'s manual `f.readline()` x3 + raw read).
     * Only P4 (binary) is supported, matching what this app ever produces;
     * ASCII P1 input is rejected with a clear error rather than silently
     * misparsed.
     */
    fun fromPbmP4(bytes: ByteArray): BitmapData {
        // Header is three newline-terminated ASCII lines: magic, comment(s)/whitespace, "W H".
        var pos = 0
        fun readLine(): String {
            val start = pos
            while (pos < bytes.size && bytes[pos] != '\n'.code.toByte()) pos++
            val line = String(bytes, start, pos - start, Charsets.US_ASCII)
            pos++ // skip the newline
            return line
        }

        val magic = readLine().trim()
        require(magic == "P4") { "Not a binary PBM (P4) file, got magic '$magic'" }

        var dimensionsLine = readLine().trim()
        while (dimensionsLine.startsWith("#") || dimensionsLine.isEmpty()) {
            dimensionsLine = readLine().trim()
        }
        val parts = dimensionsLine.split(Regex("\\s+"))
        require(parts.size == 2) { "Malformed PBM dimensions line: '$dimensionsLine'" }
        val width = parts[0].toInt()
        val height = parts[1].toInt()

        val payload = bytes.copyOfRange(pos, bytes.size)
        return ByteArrayConverter.unpackHorizontal(payload, width, height)
    }
}
