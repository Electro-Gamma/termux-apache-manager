package com.mon3ix.imageconverter

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.mon3ix.imageconverter.ui.AppViewModel
import com.mon3ix.imageconverter.ui.Destination
import com.mon3ix.imageconverter.ui.screens.ArrayToImageScreen
import com.mon3ix.imageconverter.ui.screens.BatchConversionScreen
import com.mon3ix.imageconverter.ui.screens.CppCodeScreen
import com.mon3ix.imageconverter.ui.screens.ByteArrayScreen
import com.mon3ix.imageconverter.ui.screens.GifToolsScreen
import com.mon3ix.imageconverter.ui.screens.GridEditorScreen
import com.mon3ix.imageconverter.ui.screens.HomeScreen
import com.mon3ix.imageconverter.ui.theme.ImageConverterTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ImageConverterTheme {
                ImageConverterApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ImageConverterApp() {
    val navController: NavHostController = rememberNavController()
    // One ViewModel instance, scoped to the Activity, shared by every screen -- so a converted
    // image on the "Input Image" screen is still there when you switch to "Image -> C/C++".
    val viewModel: AppViewModel = viewModel()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                Text(
                    "Image Converter",
                    style = androidx.compose.material3.MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(16.dp)
                )
                Destination.all.forEach { destination ->
                    NavigationDrawerItem(
                        label = { Text(destination.label) },
                        selected = destination.route == currentRoute,
                        onClick = {
                            scope.launch { drawerState.close() }
                            navController.navigate(destination.route) {
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        colors = NavigationDrawerItemDefaults.colors(),
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                }
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(Destination.all.find { it.route == currentRoute }?.label ?: "Image Converter") },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Filled.Menu, contentDescription = "Open navigation menu")
                        }
                    }
                )
            }
        ) { padding ->
            NavHost(
                navController = navController,
                startDestination = Destination.Home.route,
                modifier = Modifier.padding(padding)
            ) {
                composable(Destination.Home.route) { HomeScreen(viewModel) }
                composable(Destination.ByteArrayOut.route) { ByteArrayScreen(viewModel) }
                composable(Destination.CppCode.route) { CppCodeScreen(viewModel) }
                composable(Destination.Batch.route) { BatchConversionScreen(viewModel) }
                composable(Destination.GifTools.route) { GifToolsScreen(viewModel) }
                composable(Destination.GridEditor.route) { GridEditorScreen(viewModel) }
                composable(Destination.ArrayToImage.route) { ArrayToImageScreen(viewModel) }
            }
        }
    }
}
