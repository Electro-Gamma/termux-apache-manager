package com.mon3ix.imageconverter.model

/**
 * A width x height monochrome bitmap stored as one boolean per pixel.
 * `true` = black (set/drawn) pixel, `false` = white (unset) pixel.
 *
 * This is the single in-memory representation shared by every converter in
 * the app (PBM writer, byte-array packer, C-code generator, grid editor,
 * GIF frame, C-array/byte-array parser). Keeping one canonical model here
 * -- instead of the original Python app's mix of PIL `Image` objects, raw
 * `bytearray`s and nested pixel lists -- is what lets every conversion path
 * share the exact same bit-packing logic instead of quietly disagreeing
 * with each other (see [com.mon3ix.imageconverter.converter.ByteArrayConverter]
 * for why that mattered).
 */
data class BitmapData(
    val width: Int,
    val height: Int,
    val pixels: BooleanArray
) {
    init {
        require(width > 0 && height > 0) { "width and height must both be > 0 (got ${width}x$height)" }
        require(pixels.size == width * height) {
            "pixels.size (${pixels.size}) must equal width*height (${width * height})"
        }
    }

    fun get(x: Int, y: Int): Boolean {
        require(x in 0 until width && y in 0 until height) { "($x,$y) out of bounds for ${width}x$height" }
        return pixels[y * width + x]
    }

    fun withPixel(x: Int, y: Int, value: Boolean): BitmapData {
        val copy = pixels.copyOf()
        copy[y * width + x] = value
        return BitmapData(width, height, copy)
    }

    /** Flips every pixel: black becomes white and vice versa. */
    fun inverted(): BitmapData = BitmapData(width, height, BooleanArray(pixels.size) { !pixels[it] })

    companion object {
        fun empty(width: Int, height: Int, black: Boolean = false): BitmapData =
            BitmapData(width, height, BooleanArray(width * height) { black })
    }

    // BooleanArray needs manual equals/hashCode for data class value semantics.
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is BitmapData) return false
        return width == other.width && height == other.height && pixels.contentEquals(other.pixels)
    }

    override fun hashCode(): Int {
        var result = width
        result = 31 * result + height
        result = 31 * result + pixels.contentHashCode()
        return result
    }
}
