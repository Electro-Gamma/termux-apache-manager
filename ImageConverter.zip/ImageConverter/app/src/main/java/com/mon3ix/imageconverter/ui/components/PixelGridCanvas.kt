package com.mon3ix.imageconverter.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.mon3ix.imageconverter.model.BitmapData
import kotlin.math.floor

/**
 * Reproduces the Python app's `DrawableGrid`: a tappable/draggable pixel
 * grid used both to hand-draw a bitmap from scratch (item 10) and to
 * preview the result of decoding pasted byte data (items 8/9).
 *
 * Tapping a cell flips it. Dragging paints every cell the pointer passes
 * over with whichever value (draw or erase) the drag *started* with -- so
 * dragging from a blank cell draws, dragging from a filled cell erases,
 * matching the original's `<B1-Motion>` canvas binding.
 */
@Composable
fun PixelGridCanvas(
    data: BitmapData,
    onPixelChanged: (x: Int, y: Int, value: Boolean) -> Unit,
    modifier: Modifier = Modifier,
    cellSize: Dp = 20.dp,
    editable: Boolean = true
) {
    val cellPx = with(LocalDensity.current) { cellSize.toPx() }
    val gridColor = MaterialTheme.colorScheme.outlineVariant
    val pixelColor = MaterialTheme.colorScheme.onSurface
    val backgroundColor = MaterialTheme.colorScheme.surface

    fun cellAt(pos: Offset): Pair<Int, Int> {
        val x = floor(pos.x / cellPx).toInt().coerceIn(0, data.width - 1)
        val y = floor(pos.y / cellPx).toInt().coerceIn(0, data.height - 1)
        return x to y
    }

    Canvas(
        modifier = modifier
            .background(backgroundColor)
            .then(
                if (editable) {
                    Modifier.pointerInput(data.width, data.height) {
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            var lastCell = cellAt(down.position)
                            val paintValue = !data.get(lastCell.first, lastCell.second)
                            onPixelChanged(lastCell.first, lastCell.second, paintValue)
                            down.consume()
                            while (true) {
                                val event = awaitPointerEvent(PointerEventPass.Main)
                                val change = event.changes.firstOrNull() ?: break
                                if (!change.pressed) break
                                val cell = cellAt(change.position)
                                if (cell != lastCell) {
                                    lastCell = cell
                                    onPixelChanged(cell.first, cell.second, paintValue)
                                }
                                change.consume()
                            }
                        }
                    }
                } else Modifier
            )
    ) {
        for (y in 0 until data.height) {
            for (x in 0 until data.width) {
                if (data.get(x, y)) {
                    drawRect(
                        color = pixelColor,
                        topLeft = Offset(x * cellPx, y * cellPx),
                        size = Size(cellPx, cellPx)
                    )
                }
            }
        }
        for (x in 0..data.width) {
            drawLine(gridColor, Offset(x * cellPx, 0f), Offset(x * cellPx, data.height * cellPx))
        }
        for (y in 0..data.height) {
            drawLine(gridColor, Offset(0f, y * cellPx), Offset(data.width * cellPx, y * cellPx))
        }
    }
}
