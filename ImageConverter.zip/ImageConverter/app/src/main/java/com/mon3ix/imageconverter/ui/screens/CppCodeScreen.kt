package com.mon3ix.imageconverter.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mon3ix.imageconverter.converter.CCodeGenerator
import com.mon3ix.imageconverter.ui.AppViewModel
import com.mon3ix.imageconverter.ui.components.CodeOutputCard
import com.mon3ix.imageconverter.ui.components.ImagePreviewCard
import kotlinx.coroutines.launch

/**
 * Reproduces `generate_cpp_code()`: a single `const unsigned char name[] PROGMEM = {...}`
 * declaration for the currently converted image, with the identifier
 * properly sanitized (see [CCodeGenerator.sanitizeIdentifier]).
 */
@Composable
fun CppCodeScreen(viewModel: AppViewModel) {
    val scope = rememberCoroutineScope()
    var identifier by remember(viewModel.inputName) { mutableStateOf(viewModel.inputName) }

    val saveCode = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri: Uri? ->
        if (uri != null) {
            val code = viewModel.converted?.let { CCodeGenerator.generateImageCode(it, identifier, viewModel.orientation) }.orEmpty()
            scope.launch { viewModel.saveText(uri, code) }
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        if (viewModel.converted == null) {
            Text(
                "Convert an image on the Input Image screen first.",
                style = MaterialTheme.typography.bodyLarge
            )
        } else {
            ImagePreviewCard("Converted Image", viewModel.convertedBitmapPreview(), height = 160.dp)
            OutlinedTextField(
                value = identifier,
                onValueChange = { identifier = it },
                label = { Text("Variable name") },
                modifier = Modifier.fillMaxWidth()
            )
            val code = viewModel.converted?.let { CCodeGenerator.generateImageCode(it, identifier, viewModel.orientation) }.orEmpty()
            CodeOutputCard(
                title = "Generated C/C++",
                code = code,
                onSave = { saveCode.launch("${CCodeGenerator.sanitizeIdentifier(identifier)}.h") }
            )
        }
    }
}
