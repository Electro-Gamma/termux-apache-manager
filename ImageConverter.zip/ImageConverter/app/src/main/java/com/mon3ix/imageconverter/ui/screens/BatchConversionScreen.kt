package com.mon3ix.imageconverter.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mon3ix.imageconverter.ui.AppViewModel

/**
 * Reproduces `batch_convert_images()`: converts every supported image
 * directly inside a chosen input folder to PBM, written into a chosen
 * output folder -- both picked via `ACTION_OPEN_DOCUMENT_TREE`, never a
 * hardcoded path.
 *
 * COMPATIBILITY NOTE: the original additionally hardcodes writing PBM
 * output into an `Oled_gif`/parent-folder pair derived from the *input*
 * path. Android's SAF sandboxes every folder the user hasn't explicitly
 * granted access to, so there's no equivalent of silently writing next to
 * the source folder -- the user picks the destination explicitly instead.
 */
@Composable
fun BatchConversionScreen(viewModel: AppViewModel) {
    var inputTree by remember { mutableStateOf<Uri?>(null) }
    var outputTree by remember { mutableStateOf<Uri?>(null) }
    var width by remember { mutableStateOf("128") }
    var height by remember { mutableStateOf("64") }
    var invert by remember { mutableStateOf(false) }

    val pickInput = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri -> if (uri != null) inputTree = uri }
    val pickOutput = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri -> if (uri != null) outputTree = uri }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Convert every PNG/JPG/GIF/BMP in a folder to PBM.", style = MaterialTheme.typography.bodyLarge)

        Button(onClick = { pickInput.launch(null) }) {
            Text(if (inputTree == null) "Choose input folder" else "Input folder selected ✓")
        }
        Button(onClick = { pickOutput.launch(null) }) {
            Text(if (outputTree == null) "Choose output folder" else "Output folder selected ✓")
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(value = width, onValueChange = { width = it }, label = { Text("Width") }, modifier = Modifier.weight(1f))
            OutlinedTextField(value = height, onValueChange = { height = it }, label = { Text("Height") }, modifier = Modifier.weight(1f))
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = invert, onCheckedChange = { invert = it })
            Text("Invert colors")
        }

        Button(
            enabled = inputTree != null && outputTree != null && !viewModel.batchRunning,
            onClick = {
                val w = width.toIntOrNull() ?: 128
                val h = height.toIntOrNull() ?: 64
                viewModel.batchConvert(inputTree!!, outputTree!!, w, h, invert)
            }
        ) { Text("Convert all") }

        if (viewModel.batchRunning) CircularProgressIndicator(modifier = Modifier.align(Alignment.CenterHorizontally))

        LazyColumn(modifier = Modifier.fillMaxWidth()) {
            items(viewModel.batchLog) { line -> Text(line, style = MaterialTheme.typography.bodySmall) }
        }
    }
}
