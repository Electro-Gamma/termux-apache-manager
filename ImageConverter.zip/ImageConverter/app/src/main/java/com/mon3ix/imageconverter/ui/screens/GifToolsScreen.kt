package com.mon3ix.imageconverter.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mon3ix.imageconverter.ui.AppViewModel
import com.mon3ix.imageconverter.ui.components.ImagePreviewCard

/**
 * Reproduces the GIF half of the app: `split_and_resize_gif()` (frame
 * extraction + PBM/PNG export + header generation), `play_images()` /
 * `stop_playback()` (in-app preview), and `create_gif_from_pngs()` (folder
 * of PNGs -> one animated GIF). All decoding/encoding runs through
 * [com.mon3ix.imageconverter.converter.GifCodec] -- see that file for why
 * this is hand-rolled instead of relying on a platform GIF encoder.
 */
@Composable
fun GifToolsScreen(viewModel: AppViewModel) {
    var exportTarget by remember { mutableStateOf<Uri?>(null) }
    var pngFolder by remember { mutableStateOf<Uri?>(null) }
    var baseName by remember { mutableStateOf("anim") }
    var width by remember { mutableStateOf("128") }
    var height by remember { mutableStateOf("64") }
    var invert by remember { mutableStateOf(false) }
    var gifDurationMs by remember { mutableStateOf("100") }

    val pickGif = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) viewModel.loadGif(uri)
    }
    val pickExportFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) exportTarget = uri
    }
    val pickPngFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) pngFolder = uri
    }
    val createGif = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/gif")) { uri: Uri? ->
        if (uri != null && pngFolder != null) viewModel.createGifFromFolder(pngFolder!!, uri, gifDurationMs.toIntOrNull() ?: 100)
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Split a GIF into frames", style = MaterialTheme.typography.titleMedium)
        Button(onClick = { pickGif.launch(arrayOf("image/gif")) }) { Text("Choose GIF") }
        Text("${viewModel.gifFrames.size} frame(s) loaded", style = MaterialTheme.typography.bodyMedium)

        if (viewModel.gifFrames.isNotEmpty()) {
            val previewBitmap = viewModel.gifFrames.getOrNull(viewModel.gifPlaybackFrame)?.bitmap
                ?: viewModel.gifFrames.first().bitmap
            ImagePreviewCard("Frame ${viewModel.gifPlaybackFrame + 1} / ${viewModel.gifFrames.size}", previewBitmap)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = { viewModel.startGifPlayback() }, enabled = !viewModel.gifPlaying) { Text("Play") }
                Button(onClick = { viewModel.stopGifPlayback() }, enabled = viewModel.gifPlaying) { Text("Stop") }
            }
        }

        Text("Export frames as PBM + header", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(value = baseName, onValueChange = { baseName = it }, label = { Text("Base name") })
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(value = width, onValueChange = { width = it }, label = { Text("Width") }, modifier = Modifier.weight(1f))
            OutlinedTextField(value = height, onValueChange = { height = it }, label = { Text("Height") }, modifier = Modifier.weight(1f))
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = invert, onCheckedChange = { invert = it })
            Text("Invert colors")
        }
        Button(onClick = { pickExportFolder.launch(null) }) {
            Text(if (exportTarget == null) "Choose export folder" else "Export folder selected ✓")
        }
        Button(
            enabled = exportTarget != null && viewModel.gifFrames.isNotEmpty(),
            onClick = {
                val w = width.toIntOrNull() ?: 128
                val h = height.toIntOrNull() ?: 64
                viewModel.exportGifFrames(exportTarget!!, w, h, invert, baseName)
            }
        ) { Text("Export frames + generate header") }

        Text("Create a GIF from a folder of PNG frames", style = MaterialTheme.typography.titleMedium)
        Text(
            "Frames are read in numeric order (frame1.png, frame2.png, ...).",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        OutlinedTextField(value = gifDurationMs, onValueChange = { gifDurationMs = it }, label = { Text("Frame duration (ms)") })
        Button(onClick = { pickPngFolder.launch(null) }) {
            Text(if (pngFolder == null) "Choose PNG frames folder" else "PNG folder selected ✓")
        }
        Button(enabled = pngFolder != null, onClick = { createGif.launch("$baseName.gif") }) { Text("Create GIF") }

        viewModel.statusMessage?.let {
            Text(it, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
        }
    }
}
