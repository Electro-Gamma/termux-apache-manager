package com.mon3ix.imageconverter.converter

import android.graphics.Bitmap
import android.graphics.Color
import com.mon3ix.imageconverter.model.BitmapData
import com.mon3ix.imageconverter.model.ConversionOptions

/**
 * Core colour-image -> monochrome pixel conversion.
 *
 * Reproduces the Python app's resize -> grayscale -> threshold pipeline
 * (`image.convert("L")` then `.point(lambda x: 0 if x < 128 else 1, "1")`,
 * as seen in both `convert_to_pbm()` implementations and `image_to_c_array()`).
 *
 * Pillow's `convert("L")` uses the ITU-R 601-2 luma transform:
 * `L = R*299/1000 + G*587/1000 + B*114/1000` (integer division). We use the
 * same weights and the same `luma < 128` threshold so a given source image
 * produces the same black/white decision on both platforms.
 *
 * KNOWN COMPATIBILITY DIFFERENCE: resizing itself is not guaranteed to be
 * bit-identical to Pillow. `Bitmap.createScaledBitmap` and Pillow's default
 * resampling filter use different interpolation kernels, so pixels very
 * close to a black/white edge in the resized image can occasionally land on
 * different sides of the threshold. The thresholding, inversion and bit
 * packing logic downstream of resize is exact and deterministic.
 */
object ImageConverter {

    /** Pillow's ITU-R 601-2 luma weights (per-mille), used by `Image.convert("L")`. */
    private const val LUMA_R = 299
    private const val LUMA_G = 587
    private const val LUMA_B = 114

    fun resize(source: Bitmap, targetWidth: Int, targetHeight: Int): Bitmap {
        require(targetWidth > 0 && targetHeight > 0) { "target size must be positive" }
        if (source.width == targetWidth && source.height == targetHeight) return source
        return Bitmap.createScaledBitmap(source, targetWidth, targetHeight, /* filter = */ true)
    }

    /** Pillow-equivalent luma (0..255) for one RGB pixel. */
    fun luma(r: Int, g: Int, b: Int): Int = (r * LUMA_R + g * LUMA_G + b * LUMA_B) / 1000

    /**
     * Converts a colour [source] bitmap into a monochrome [BitmapData], resizing
     * to [ConversionOptions.targetWidth] x [ConversionOptions.targetHeight] first
     * if the source doesn't already match, then applying `luma < threshold` ->
     * black, then inverting if requested.
     */
    fun toMonochrome(source: Bitmap, options: ConversionOptions): BitmapData {
        val resized = resize(source, options.targetWidth, options.targetHeight)
        val w = resized.width
        val h = resized.height
        val argb = IntArray(w * h)
        resized.getPixels(argb, 0, w, 0, 0, w, h)

        val pixels = BooleanArray(w * h)
        for (i in argb.indices) {
            val px = argb[i]
            val y = luma(Color.red(px), Color.green(px), Color.blue(px))
            var black = y < options.threshold
            if (options.invert) black = !black
            pixels[i] = black
        }
        return BitmapData(w, h, pixels)
    }

    /** Renders [data] back to an opaque ARGB [Bitmap] for preview (black pixel -> black, white -> white). */
    fun toBitmap(data: BitmapData): Bitmap {
        val bmp = Bitmap.createBitmap(data.width, data.height, Bitmap.Config.ARGB_8888)
        val argb = IntArray(data.width * data.height)
        for (i in argb.indices) {
            argb[i] = if (data.pixels[i]) Color.BLACK else Color.WHITE
        }
        bmp.setPixels(argb, 0, data.width, 0, 0, data.width, data.height)
        return bmp
    }
}
