package com.mon3ix.imageconverter.converter

import com.mon3ix.imageconverter.model.BitmapData
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CCodeGeneratorTest {

    @Test
    fun `sanitizeIdentifier strips only the last extension`() {
        // The original Python app used split('.')[0], which would mangle this to "my".
        assertEquals("my_image_v2", CCodeGenerator.sanitizeIdentifier("my.image.v2.png"))
    }

    @Test
    fun `sanitizeIdentifier replaces invalid characters with underscores`() {
        assertEquals("my_image_1", CCodeGenerator.sanitizeIdentifier("my image-1.png"))
    }

    @Test
    fun `sanitizeIdentifier prefixes a leading digit`() {
        assertEquals("_123abc", CCodeGenerator.sanitizeIdentifier("123abc"))
    }

    @Test
    fun `sanitizeIdentifier falls back to a default name when nothing valid remains`() {
        assertEquals("image", CCodeGenerator.sanitizeIdentifier(""))
        assertEquals("image", CCodeGenerator.sanitizeIdentifier("!!!"))
    }

    @Test
    fun `generateImageCode emits a valid PROGMEM declaration`() {
        val data = BitmapData.empty(8, 8, black = true)
        val code = CCodeGenerator.generateImageCode(data, "my sprite.png")
        assertTrue(code.contains("const unsigned char my_sprite[] PROGMEM = {"))
        assertTrue(code.contains("0xFF"))
        assertTrue(code.trim().endsWith("};"))
    }

    @Test
    fun `generateHeader emits one bracketed block per frame in order`() {
        val frames = listOf(
            BitmapData.empty(8, 8, black = false),
            BitmapData.empty(8, 8, black = true)
        )
        val header = CCodeGenerator.generateHeader(frames, "anim")
        assertTrue(header.contains("const unsigned char anim[2][8] PROGMEM = {"))
        // Frame order must be preserved: frame 1 (all white) before frame 2 (all black).
        val frame1Index = header.indexOf("'anim_1'")
        val frame2Index = header.indexOf("'anim_2'")
        assertTrue(frame1Index in 0 until frame2Index)
    }
}
