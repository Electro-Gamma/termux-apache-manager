package com.mon3ix.imageconverter.converter

import com.mon3ix.imageconverter.model.BitmapData
import com.mon3ix.imageconverter.model.ByteOrientation
import org.junit.Assert.assertEquals
import org.junit.Test

class BitmapDecoderTest {

    @Test
    fun `parseImage decodes a plain hex list at the given size`() {
        val decoded = BitmapDecoder.parseImage("0xAA", 8, 1, ByteOrientation.HORIZONTAL)
        val expected = ByteArrayConverter.unpackHorizontal(byteArrayOf(0xAA.toByte()), 8, 1)
        assertEquals(expected, decoded)
    }

    @Test
    fun `parseHeaderFile round-trips generateHeader's output`() {
        val frame1 = BitmapData(8, 8, BooleanArray(64) { it % 3 == 0 })
        val frame2 = BitmapData(8, 8, BooleanArray(64) { it % 5 == 0 })
        val header = CCodeGenerator.generateHeader(listOf(frame1, frame2), "anim")

        val result = BitmapDecoder.parseHeaderFile(header)

        assertEquals("anim", result.arrayName)
        assertEquals(2, result.frames.size)
        assertEquals(frame1, result.frames[0].bitmap)
        assertEquals(frame2, result.frames[1].bitmap)
        assertEquals(8, result.frames[0].width)
        assertEquals(8, result.frames[0].height)
    }
}
