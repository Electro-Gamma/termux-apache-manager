package com.mon3ix.imageconverter.converter

import com.mon3ix.imageconverter.model.BitmapData
import com.mon3ix.imageconverter.model.ByteOrientation
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Test

class ByteArrayConverterTest {

    private fun checkerboard(width: Int, height: Int): BitmapData =
        BitmapData(width, height, BooleanArray(width * height) { i -> ((i % width) + (i / width)) % 2 == 0 })

    @Test
    fun `8x8 all black packs to all 0xFF`() {
        val data = BitmapData.empty(8, 8, black = true)
        val bytes = ByteArrayConverter.packHorizontal(data)
        assertArrayEquals(ByteArray(8) { 0xFF.toByte() }, bytes)
    }

    @Test
    fun `8x8 all white packs to all zero`() {
        val data = BitmapData.empty(8, 8, black = false)
        val bytes = ByteArrayConverter.packHorizontal(data)
        assertArrayEquals(ByteArray(8), bytes)
    }

    @Test
    fun `8x8 checkerboard packs to alternating 0xAA 0x55`() {
        val bytes = ByteArrayConverter.packHorizontal(checkerboard(8, 8))
        val expected = ByteArray(8) { row -> if (row % 2 == 0) 0xAA.toByte() else 0x55.toByte() }
        assertArrayEquals(expected, bytes)
    }

    @Test
    fun `16x8 bitmap with one white corner pixel`() {
        val pixels = BooleanArray(16 * 8) { true }
        pixels[0] = false // top-left pixel is white, everything else black
        val data = BitmapData(16, 8, pixels)
        val bytes = ByteArrayConverter.packHorizontal(data)

        assertEquals(16, bytes.size) // 2 bytes/row * 8 rows
        assertEquals(0x7F.toByte(), bytes[0]) // row 0, byte 0: white,black,black,black,black,black,black,black
        assertEquals(0xFF.toByte(), bytes[1]) // row 0, byte 1: all black
        for (row in 1 until 8) {
            assertEquals(0xFF.toByte(), bytes[row * 2])
            assertEquals(0xFF.toByte(), bytes[row * 2 + 1])
        }
    }

    @Test
    fun `non-multiple-of-8 width pads the row with zero bits`() {
        val data = BitmapData.empty(10, 1, black = true)
        val bytes = ByteArrayConverter.packHorizontal(data)
        assertArrayEquals(byteArrayOf(0xFF.toByte(), 0xC0.toByte()), bytes)
    }

    @Test
    fun `non-multiple-of-8 height pads the last page with zero bits (vertical)`() {
        val data = BitmapData.empty(1, 10, black = true)
        val bytes = ByteArrayConverter.packVertical(data)
        assertArrayEquals(byteArrayOf(0xFF.toByte(), 0xC0.toByte()), bytes)
    }

    @Test
    fun `inverted checkerboard swaps 0xAA and 0x55`() {
        val inverted = checkerboard(8, 8).inverted()
        val bytes = ByteArrayConverter.packHorizontal(inverted)
        val expected = ByteArray(8) { row -> if (row % 2 == 0) 0x55.toByte() else 0xAA.toByte() }
        assertArrayEquals(expected, bytes)
    }

    @Test
    fun `horizontal pack then unpack round-trips`() {
        val original = checkerboard(13, 9) // deliberately not a multiple of 8
        val bytes = ByteArrayConverter.packHorizontal(original)
        val decoded = ByteArrayConverter.unpackHorizontal(bytes, 13, 9)
        assertEquals(original, decoded)
    }

    @Test
    fun `vertical pack then unpack round-trips`() {
        val original = checkerboard(9, 13)
        val bytes = ByteArrayConverter.packVertical(original)
        val decoded = ByteArrayConverter.unpackVertical(bytes, 9, 13)
        assertEquals(original, decoded)
    }

    @Test
    fun `unpackHorizontal known bytes decode to expected pixels`() {
        // 0xAA = 10101010 -> black,white,black,white,black,white,black,white
        val decoded = ByteArrayConverter.unpackHorizontal(byteArrayOf(0xAA.toByte()), 8, 1)
        val expectedRow = booleanArrayOf(true, false, true, false, true, false, true, false)
        assertArrayEquals(expectedRow.toTypedArray(), decoded.pixels.toTypedArray())
    }

    @Test
    fun `unpackVertical known bytes decode to expected pixels`() {
        // page byte 0xC0 = 11000000 -> top two pixels of the column are black, rest white
        val decoded = ByteArrayConverter.unpackVertical(byteArrayOf(0xC0.toByte()), 1, 8)
        val expectedColumn = booleanArrayOf(true, true, false, false, false, false, false, false)
        assertArrayEquals(expectedColumn.toTypedArray(), decoded.pixels.toTypedArray())
    }

    @Test
    fun `pack dispatches to the requested orientation`() {
        val data = checkerboard(8, 8)
        assertArrayEquals(ByteArrayConverter.packHorizontal(data), ByteArrayConverter.pack(data, ByteOrientation.HORIZONTAL))
        assertArrayEquals(ByteArrayConverter.packVertical(data), ByteArrayConverter.pack(data, ByteOrientation.VERTICAL))
    }

    @Test
    fun `bytesPerRow and pagesFor round up`() {
        assertEquals(1, ByteArrayConverter.bytesPerRow(1))
        assertEquals(1, ByteArrayConverter.bytesPerRow(8))
        assertEquals(2, ByteArrayConverter.bytesPerRow(9))
        assertEquals(2, ByteArrayConverter.pagesFor(9))
    }
}
