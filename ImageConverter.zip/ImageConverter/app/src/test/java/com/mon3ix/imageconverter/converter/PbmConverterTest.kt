package com.mon3ix.imageconverter.converter

import com.mon3ix.imageconverter.model.BitmapData
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PbmConverterTest {

    @Test
    fun `toPbmP4 writes the binary P4 header, not ASCII P1`() {
        val data = BitmapData.empty(8, 4, black = true)
        val bytes = PbmConverter.toPbmP4(data)
        val text = String(bytes, 0, minOf(30, bytes.size), Charsets.US_ASCII)
        assertTrue("Expected binary P4 magic number", text.startsWith("P4\n"))
        assertTrue(text.contains("# Created by Mon3ix\n"))
        assertTrue(text.contains("8 4\n"))
    }

    @Test
    fun `toPbmP4 payload matches horizontal packing, not raw tobytes polarity`() {
        val data = BitmapData.empty(8, 1, black = true)
        val bytes = PbmConverter.toPbmP4(data)
        // Header is "P4\n# Created by Mon3ix\n8 1\n" = 3 + 20 + 4 = 27 bytes; payload follows.
        val header = "P4\n# Created by Mon3ix\n8 1\n"
        val payload = bytes.copyOfRange(header.length, bytes.size)
        assertEquals(1, payload.size)
        // All-black row, MSB-first, 1 = black -> 0xFF (the spec-correct polarity; see ByteArrayConverter's doc comment).
        assertEquals(0xFF.toByte(), payload[0])
    }

    @Test
    fun `fromPbmP4 round-trips toPbmP4`() {
        val original = BitmapData(5, 3, booleanArrayOf(
            true, false, true, false, true,
            false, true, false, true, false,
            true, true, true, false, false
        ))
        val roundTripped = PbmConverter.fromPbmP4(PbmConverter.toPbmP4(original))
        assertEquals(original, roundTripped)
    }

    @Test(expected = IllegalArgumentException::class)
    fun `fromPbmP4 rejects non-P4 input`() {
        PbmConverter.fromPbmP4("P1\n1 1\n1\n".toByteArray(Charsets.US_ASCII))
    }
}
