package com.mon3ix.imageconverter.converter

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * These tests exercise [ImageConverter.luma] directly since it's pure
 * integer arithmetic with no `android.graphics.Bitmap` dependency, which
 * means it (unlike `toMonochrome`/`toBitmap`) can run as a plain local JVM
 * unit test without Robolectric or an emulator -- see the class doc comment
 * for the same ITU-R 601-2 weights Pillow's `convert("L")` uses.
 */
class ImageConverterTest {

    @Test
    fun `pure black has luma 0`() {
        assertEquals(0, ImageConverter.luma(0, 0, 0))
    }

    @Test
    fun `pure white has luma 255`() {
        assertEquals(255, ImageConverter.luma(255, 255, 255))
    }

    @Test
    fun `luma below 128 is the black threshold boundary`() {
        // A mid-gray around the (r,g,b) = (127,127,127) mark should land just under 128.
        val luma = ImageConverter.luma(127, 127, 127)
        assertTrue("Expected luma just under 128, got $luma", luma in 120..127)
    }

    @Test
    fun `green is weighted most heavily, matching Pillow's ITU-R 601-2 weights`() {
        val greenOnly = ImageConverter.luma(0, 255, 0)
        val redOnly = ImageConverter.luma(255, 0, 0)
        val blueOnly = ImageConverter.luma(0, 0, 255)
        assertTrue(greenOnly > redOnly)
        assertTrue(redOnly > blueOnly)
    }
}
