package com.mon3ix.imageconverter.converter

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class ByteDataParserTest {

    @Test
    fun `parses a bare hex list`() {
        val result = ByteDataParser.parse("0x00, 0x18, 0x3C, 0x7E")
        assertArrayEquals(byteArrayOf(0x00, 0x18, 0x3C, 0x7E), result)
    }

    @Test
    fun `parses a bare decimal list`() {
        val result = ByteDataParser.parse("0, 24, 60, 126")
        assertArrayEquals(byteArrayOf(0, 24, 60, 126), result)
    }

    @Test
    fun `parses a Python bytearray escape literal`() {
        val result = ByteDataParser.parse("bytearray(b'\\x00\\x18\\x3c\\x7e')")
        assertArrayEquals(byteArrayOf(0x00, 0x18, 0x3C, 0x7E), result)
    }

    @Test
    fun `parses a full C array declaration, ignoring the declaration and comments`() {
        val input = """
            // 'image', 8x8px
            const unsigned char image[] PROGMEM = {
                0x00, 0x18, 0x3C, 0x7E, 0x7E, 0x3C, 0x18, 0x00
            };
        """.trimIndent()
        val result = ByteDataParser.parse(input)
        assertArrayEquals(byteArrayOf(0x00, 0x18, 0x3C, 0x7E, 0x7E, 0x3C, 0x18, 0x00), result)
    }

    @Test
    fun `rejects empty input`() {
        assertThrows(ByteDataParser.ParseException::class.java) { ByteDataParser.parse("") }
        assertThrows(ByteDataParser.ParseException::class.java) { ByteDataParser.parse("   ") }
    }

    @Test
    fun `rejects a value out of byte range`() {
        assertThrows(ByteDataParser.ParseException::class.java) { ByteDataParser.parse("0x1FF, 0x00") }
    }

    @Test
    fun `rejects input with no recognisable byte values`() {
        assertThrows(ByteDataParser.ParseException::class.java) { ByteDataParser.parse("hello world") }
    }
}
