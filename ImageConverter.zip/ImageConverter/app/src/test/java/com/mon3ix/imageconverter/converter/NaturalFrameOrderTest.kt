package com.mon3ix.imageconverter.converter

import org.junit.Assert.assertEquals
import org.junit.Test

class NaturalFrameOrderTest {

    @Test
    fun `sorts fnum-style names numerically, not lexicographically`() {
        val files = listOf("fnum10.pbm", "fnum2.pbm", "fnum1.pbm", "fnum20.pbm", "fnum3.pbm")
        val sorted = NaturalFrameOrder.sortByEmbeddedNumber(files) { it }
        assertEquals(listOf("fnum1.pbm", "fnum2.pbm", "fnum3.pbm", "fnum10.pbm", "fnum20.pbm"), sorted)
    }

    @Test
    fun `extractNumber finds the embedded integer`() {
        assertEquals(42, NaturalFrameOrder.extractNumber("frame42.png"))
        assertEquals(null, NaturalFrameOrder.extractNumber("no_number_here.png"))
    }
}
